; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/listing:Namer" = type { { i64, ptr } }
%"compiler/build:Unit" = type { { i64, ptr }, i32, { i64, ptr }, { i64, ptr } }
%"compiler/build:Program" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/listing:Sources" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr } }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/build:Code" = type { { i64, ptr }, { i64, ptr }, i64, { i64, ptr } }
%"compiler/listing:Inputs" = type { ptr, ptr, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/build:Listed" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/listing:Remark" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/listing:Writer" = type { { i64, ptr }, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, { i64, ptr }, { i64, ptr }, i64, %"std/prelude/text:StringBuilder", i64 }
%"compiler/build:Config" = type { { i64, ptr }, { i64, ptr }, %"compiler/target:Target", %"compiler/cond:Consts", i1, i1, i1, i1, i1, i1, { i64, ptr }, i64, i1, i1, { i64, ptr }, i1, i1, i1, i64, i1, i1, { i64, ptr }, { i64, ptr }, i64, i64, i1, { i64, ptr }, { i64, ptr } }
%"compiler/target:Target" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i1, i1 }
%"compiler/cond:Consts" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
define dso_local %"compiler/listing:Namer" @compiler_2flisting_2eNamer_2eMake(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %lp1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/build:Unit"
  %l5 = alloca %"compiler/listing:Namer"
  %l8 = alloca i64
  %l10 = alloca i64
  %l15 = alloca %"compiler/build:Unit"
  %l18 = alloca i1
  %rv = alloca %"compiler/listing:Namer"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"compiler/listing:Namer" @compiler_2flisting_3aNamer_2ector(ptr %v1)
  store %"compiler/listing:Namer" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"compiler/listing:Namer", ptr %l5
  %t4 = load ptr, ptr %lp1
  store %"compiler/listing:Namer" %t3, ptr %t4
  %t7 = getelementptr %"compiler/build:Program", ptr %a0, i32 0, i32 0
  store ptr %t7, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  store i64 %t9, ptr %l8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l10
  br label %bb3
bb3:
  %t13 = load i64, ptr %l8, !tbaa !24
  %t14 = load i64, ptr %l10, !tbaa !24
  %t15 = icmp slt i64 %t13, %t14
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb4, label %bb5
bb4:
  br label %bb15
bb5:
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = call %"compiler/build:Unit" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eAt_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %v0, ptr %t19, i64 %t20)
  store %"compiler/build:Unit" %t23, ptr %l15
  br label %bb7
bb7:
  %t24 = load %"compiler/build:Unit", ptr %l15
  store %"compiler/build:Unit" %t24, ptr %l4
  %t25 = getelementptr %"compiler/build:Unit", ptr %l4, i32 0, i32 1
  %t26 = load i32, ptr %t25, !range !{i32 0, i32 5}
  %t28 = trunc i64 1 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb10
bb9:
  %t31 = getelementptr %"compiler/build:Unit", ptr %l4, i32 0, i32 1
  %t32 = load i32, ptr %t31, !range !{i32 0, i32 5}
  %t34 = trunc i64 2 to i32
  %t35 = icmp eq i32 %t32, %t34
  store i1 %t35, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t37 = load i1, ptr %l18, !tbaa !21
  br i1 %t37, label %bb11, label %bb12
bb11:
  %t38 = getelementptr %"compiler/build:Unit", ptr %l4, i32 0, i32 0
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 1
  %t42 = extractvalue { i64, ptr } %t39, 0
  %t43 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t42)
  call void @olang_textcopy(ptr %t43, ptr %t41, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = extractvalue { i64, ptr } %t45, 1
  %t49 = mul i64 %t47, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t48, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  %t54 = load ptr, ptr %lp1
  %t55 = getelementptr %"compiler/listing:Namer", ptr %t54, i32 0, i32 0
  store { i64, ptr } %t52, ptr %t55, !tbaa !27
  br label %bb13
bb12:
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t56 = load i64, ptr %l3, !tbaa !24
  %t58 = add i64 %t56, 1
  store i64 %t58, ptr %l3, !tbaa !24
  br label %bb2
bb15:
  %t60 = load ptr, ptr %lp1
  %t61 = load %"compiler/listing:Namer", ptr %t60
  store %"compiler/listing:Namer" %t61, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/listing:Namer", ptr %rv
  ret %"compiler/listing:Namer" %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2flisting_2eRemarks(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %a2) #0 {
entry:
  %lp3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca i64
  %l12 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i32
  %l23 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2flisting_3aRemark_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store ptr %t2, ptr %lp3
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  %t4 = load ptr, ptr %lp3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  store ptr %a0, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l5, !tbaa !24
  store i64 %t7, ptr %l10, !tbaa !24
  %t8 = load ptr, ptr %l4, !tbaa !29
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l12
  br label %bb3
bb3:
  %t11 = load i64, ptr %l10, !tbaa !24
  %t12 = load i64, ptr %l12, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb5:
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t18 = load i64, ptr %l5, !tbaa !24
  %t21 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t17, i64 %t18)
  store { i64, ptr } %t21, ptr %l17
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t25 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %s2, { i64, ptr } %t22)
  %t26 = extractvalue { i32, { i64, ptr } } %t25, 1
  %t27 = extractvalue { i32, { i64, ptr } } %t25, 0
  store i32 %t27, ptr %l21
  %t28 = icmp ne i32 %t27, 0
  br i1 %t28, label %bb9, label %ok.29, !prof !99
ok.29:
  store { i64, ptr } %t26, ptr %l20
  br label %bb8
bb8:
  %t30 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t30, ptr %l18, !tbaa !27
  br label %bb11
bb9:
  %t31 = load i32, ptr %l21, !tbaa !23
  %t32 = ashr i32 %t31, 16
  %t34 = icmp eq i32 %t32, 1
  store i1 %t34, ptr %l23, !tbaa !21
  br label %bb10
bb10:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %l18, !tbaa !27
  br label %bb11
bb11:
  %t35 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t39 = load ptr, ptr %lp3
  call void @compiler_2flisting_2ereadRemarks(ptr %s2, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %t35, { i64, ptr } %a1, ptr %a2, ptr %t39)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  %t44 = load i64, ptr %l5, !tbaa !24
  %t46 = add i64 %t44, 1
  store i64 %t46, ptr %l5, !tbaa !24
  br label %bb2
bb14:
  %t48 = load ptr, ptr %lp3
  %t49 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local { i64, ptr } @compiler_2flisting_2eRender(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca %"compiler/listing:Namer"
  %l3 = alloca %"compiler/listing:Sources"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/build:Code"
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l12 = alloca %"compiler/listing:Namer"
  %l13 = alloca %"compiler/listing:Sources"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca i64
  %l23 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l29 = alloca i64
  %l33 = alloca { i64, ptr }
  %l37 = alloca i64
  %l39 = alloca i64
  %l45 = alloca %"compiler/build:Code"
  %l49 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/listing:Inputs", ptr %t3, i32 0, i32 0
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = call %"compiler/listing:Namer" @compiler_2flisting_2eNamer_2eMake(ptr %v0, ptr %s0, ptr %t6)
  store %"compiler/listing:Namer" %t8, ptr %l12
  br label %bb2
bb2:
  %t9 = load %"compiler/listing:Namer", ptr %l12
  store %"compiler/listing:Namer" %t9, ptr %l2
  %t10 = call %"compiler/listing:Sources" @compiler_2flisting_2eSources_2eMake(ptr %s0)
  store %"compiler/listing:Sources" %t10, ptr %l13
  br label %bb3
bb3:
  %t11 = load %"compiler/listing:Sources", ptr %l13
  store %"compiler/listing:Sources" %t11, ptr %l3
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/listing:Inputs", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/build:Listed", ptr %t15, i32 0, i32 0
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2flisting_2ereadParts(ptr %v0, ptr %s0, ptr %t17)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l17
  br label %bb4
bb4:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l4
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/listing:Inputs", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/build:Program", ptr %t24, i32 0, i32 8
  %t28 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aCode_3e_2eLen_3ccompiler_2fbuild_3aCode_3e(ptr %v0, ptr %t26)
  store i64 %t28, ptr %l21
  br label %bb5
bb5:
  %t29 = load i64, ptr %l21, !tbaa !24
  %t30 = icmp eq i64 %t29, 0
  br i1 %t30, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  store ptr %l1, ptr %l23, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/listing:Inputs", ptr %t32, i32 0, i32 3
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  store { i64, ptr } %t35, ptr %l25, !tbaa !27
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/listing:Inputs", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = getelementptr %"compiler/build:Program", ptr %t39, i32 0, i32 8
  %t43 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aCode_3e_2eLen_3ccompiler_2fbuild_3aCode_3e(ptr %v0, ptr %t41)
  store i64 %t43, ptr %l29
  br label %bb8
bb7:
  br label %bb11
bb8:
  %t44 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t44, 1
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t47 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t48 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t49 = add i64 %t46, %t48
  %t50 = load i64, ptr %l29, !tbaa !24
  %t51 = call i64 @__olang_fmt_i64(ptr null, i64 %t50)
  %t52 = add i64 %t49, %t51
  %t53 = extractvalue { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t54 = extractvalue { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t55 = add i64 %t52, %t54
  %t56 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t55)
  call void @olang_textcopy(ptr %t56, ptr %t45, i64 %t46)
  %t57 = getelementptr i8, ptr %t56, i64 %t46
  call void @olang_textcopy(ptr %t57, ptr %t47, i64 %t48)
  %t58 = getelementptr i8, ptr %t57, i64 %t48
  %t59 = call i64 @__olang_fmt_i64(ptr %t58, i64 %t50)
  %t60 = getelementptr i8, ptr %t58, i64 %t51
  call void @olang_textcopy(ptr %t60, ptr %t53, i64 %t54)
  %t61 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t56, 1
  %t64 = extractvalue { i64, ptr } %t62, 0
  %t65 = extractvalue { i64, ptr } %t62, 1
  %t66 = mul i64 %t64, 1
  %t67 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t66)
  call void @llvm.memcpy.p0.p0.i64(ptr %t67, ptr %t65, i64 %t66, i1 false)
  %t68 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  %t70 = load ptr, ptr %l23, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %t70, { i64, ptr } %t69)
  br label %bb9
bb9:
  %t73 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t73, ptr %l33
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t74 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t74, ptr %rv
  br label %ret
bb11:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/listing:Inputs", ptr %t75, i32 0, i32 0
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = getelementptr %"compiler/build:Program", ptr %t78, i32 0, i32 8
  store ptr %t80, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t82 = load i64, ptr %l6, !tbaa !24
  store i64 %t82, ptr %l37, !tbaa !24
  %t83 = load ptr, ptr %l5, !tbaa !29
  %t85 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aCode_3e_2eLen_3ccompiler_2fbuild_3aCode_3e(ptr %v0, ptr %t83)
  store i64 %t85, ptr %l39
  br label %bb13
bb13:
  %t86 = load i64, ptr %l37, !tbaa !24
  %t87 = load i64, ptr %l39, !tbaa !24
  %t88 = icmp slt i64 %t86, %t87
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb25
bb15:
  br label %bb16
bb16:
  %t92 = load i64, ptr %l6, !tbaa !24
  store i64 %t92, ptr %l7, !tbaa !24
  %t94 = load ptr, ptr %l5, !tbaa !29
  %t95 = load i64, ptr %l6, !tbaa !24
  %t98 = call %"compiler/build:Code" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aCode_3e_2eAt_3ccompiler_2fbuild_3aCode_3e(ptr %v0, ptr %v0, ptr %t94, i64 %t95)
  store %"compiler/build:Code" %t98, ptr %l45
  br label %bb17
bb17:
  %t99 = load %"compiler/build:Code", ptr %l45
  store %"compiler/build:Code" %t99, ptr %l8
  %t100 = load i64, ptr %l7, !tbaa !24
  %t102 = icmp sgt i64 %t100, 0
  br i1 %t102, label %bb18, label %bb19
bb18:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 10)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  store ptr %l1, ptr %l49, !tbaa !29
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t111 = call { i64, ptr } @compiler_2flisting_2einstance(ptr %v0, ptr %s4, ptr %s0, ptr %s0, ptr %s0, ptr %s4, ptr %t105, ptr %l8, ptr %l4, ptr %l2, ptr %l3)
  store { i64, ptr } %t111, ptr %l55
  br label %bb22
bb22:
  %t112 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t112, 0
  %t114 = extractvalue { i64, ptr } %t112, 1
  %t115 = mul i64 %t113, 1
  %t116 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t115)
  call void @llvm.memcpy.p0.p0.i64(ptr %t116, ptr %t114, i64 %t115, i1 false)
  %t117 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t116, 1
  %t119 = load ptr, ptr %l49, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t119, { i64, ptr } %t118)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s4)
  br label %bb24
bb24:
  %t121 = load i64, ptr %l6, !tbaa !24
  %t123 = add i64 %t121, 1
  store i64 %t123, ptr %l6, !tbaa !24
  br label %bb12
bb25:
  %t126 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t126, ptr %l60
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  %t127 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t127, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/listing:Sources" @compiler_2flisting_2eSources_2eMake(ptr %v0) #0 {
entry:
  %lp0 = alloca ptr
  %l1 = alloca %"compiler/listing:Sources"
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/listing:Sources"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/listing:Sources" @compiler_2flisting_3aSources_2ector(ptr %v0)
  store %"compiler/listing:Sources" %t1, ptr %l1
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 88, i64 8)
  store ptr %t2, ptr %lp0
  %t3 = load %"compiler/listing:Sources", ptr %l1
  %t4 = load ptr, ptr %lp0
  store %"compiler/listing:Sources" %t3, ptr %t4
  %t5 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %s0)
  store { i64, ptr } %t5, ptr %l3
  br label %bb2
bb2:
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  %t8 = extractvalue { i64, ptr } %t6, 1
  %t9 = mul i64 %t7, 1
  %t10 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t8, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  %t14 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %s0, ptr %s0, { i64, ptr } %t12)
  %t15 = extractvalue { i32, { i64, ptr } } %t14, 1
  %t16 = extractvalue { i32, { i64, ptr } } %t14, 0
  store i32 %t16, ptr %l6
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb4, label %ok.18, !prof !99
ok.18:
  store { i64, ptr } %t15, ptr %l5
  br label %bb3
bb3:
  %t19 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t19, ptr %l2, !tbaa !27
  br label %bb7
bb4:
  br label %bb5
bb5:
  call void @__olang_ert_req_clear()
  %t20 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %s0)
  store { i64, ptr } %t20, ptr %l7
  br label %bb6
bb6:
  %t21 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l2, !tbaa !27
  br label %bb7
bb7:
  %t29 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t31)
  call void @olang_textcopy(ptr %t32, ptr %t30, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t37 = extractvalue { i64, ptr } %t34, 1
  %t38 = mul i64 %t36, 1
  %t39 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t38)
  call void @llvm.memcpy.p0.p0.i64(ptr %t39, ptr %t37, i64 %t38, i1 false)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  %t43 = load ptr, ptr %lp0
  %t44 = getelementptr %"compiler/listing:Sources", ptr %t43, i32 0, i32 1
  store { i64, ptr } %t41, ptr %t44, !tbaa !27
  %t45 = load ptr, ptr %lp0
  %t46 = load %"compiler/listing:Sources", ptr %t45
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/listing:Sources" %t46, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/listing:Sources", ptr %rv
  ret %"compiler/listing:Sources" %rr
}

define dso_local { i64, ptr } @compiler_2flisting_2ealiasee(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l19 = alloca i1
  %l20 = alloca { i64, ptr }
  %l23 = alloca i1
  %l24 = alloca i1
  %l25 = alloca { i64, ptr }
  %l28 = alloca i1
  %l29 = alloca i1
  %l30 = alloca { i64, ptr }
  %l34 = alloca i1
  %l35 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l6
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i64 %t4, ptr %l5
  br label %bb1
bb1:
  %t8 = load i64, ptr %l5, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t9 = load i64, ptr %l3, !tbaa !24
  store i64 %t9, ptr %l1, !tbaa !24
  %t10 = load i64, ptr %l1, !tbaa !24
  %t12 = icmp slt i64 %t10, 0
  br i1 %t12, label %bb5, label %bb6
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l9, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t14, ptr %l10, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 0
  store i64 %t16, ptr %l11, !tbaa !24
  %t17 = load i64, ptr %l11, !tbaa !24
  %t18 = mul i64 %t17, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  %t20 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l12, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = load i64, ptr %l11, !tbaa !24
  %t27 = mul i64 %t26, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t23, ptr %t25, i64 %t27, i1 false)
  %t28 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t28, ptr %l10, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t29 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t29, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t30 = load i64, ptr %l1, !tbaa !24
  %t32 = add i64 %t30, 1
  store i64 %t32, ptr %l2, !tbaa !24
  br label %bb8
bb8:
  %t34 = load i64, ptr %l2, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t40 = icmp slt i64 %t34, %t37
  br i1 %t40, label %bb9, label %bb10
bb9:
  %t42 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t42, ptr %l20, !tbaa !27
  %t43 = load i64, ptr %l2, !tbaa !24
  %t45 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr i8, ptr %t46, i64 %t43
  %t48 = load i8, ptr %t47, !tbaa !32
  %t50 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t48)
  store i1 %t50, ptr %l23
  br label %bb11
bb10:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb22
bb11:
  %t51 = load i1, ptr %l23, !tbaa !21
  br i1 %t51, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb15
bb13:
  %t52 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t52, ptr %l25, !tbaa !27
  %t53 = load i64, ptr %l2, !tbaa !24
  %t55 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr i8, ptr %t56, i64 %t53
  %t58 = load i8, ptr %t57, !tbaa !32
  %t60 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t58)
  store i1 %t60, ptr %l28
  br label %bb14
bb14:
  %t61 = load i1, ptr %l28, !tbaa !21
  store i1 %t61, ptr %l24, !tbaa !21
  br label %bb15
bb15:
  %t62 = load i1, ptr %l24, !tbaa !21
  br i1 %t62, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb18
bb17:
  %t63 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t63, ptr %l30, !tbaa !27
  %t64 = load i64, ptr %l2, !tbaa !24
  %t66 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr i8, ptr %t67, i64 %t64
  %t69 = load i8, ptr %t68, !tbaa !32
  %t71 = icmp eq i8 %t69, 95
  store i1 %t71, ptr %l29, !tbaa !21
  br label %bb18
bb18:
  %t73 = load i1, ptr %l29, !tbaa !21
  br i1 %t73, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb21
bb20:
  %t74 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t74, ptr %l35, !tbaa !27
  %t75 = load i64, ptr %l2, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr i8, ptr %t78, i64 %t75
  %t80 = load i8, ptr %t79, !tbaa !32
  %t82 = icmp eq i8 %t80, 46
  store i1 %t82, ptr %l34, !tbaa !21
  br label %bb21
bb21:
  %t84 = load i1, ptr %l34, !tbaa !21
  store i1 %t84, ptr %l19, !tbaa !21
  br label %bb22
bb22:
  %t85 = load i1, ptr %l19, !tbaa !21
  %t86 = xor i1 %t85, true
  br i1 %t86, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t88 = load i64, ptr %l2, !tbaa !24
  %t90 = add i64 %t88, 1
  store i64 %t90, ptr %l2, !tbaa !24
  br label %bb26
bb26:
  br label %bb8
bb27:
  %t92 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t92, ptr %l42, !tbaa !27
  %t93 = load i64, ptr %l1, !tbaa !24
  %t95 = add i64 %t93, 1
  store i64 %t95, ptr %l44, !tbaa !24
  %t96 = load i64, ptr %l2, !tbaa !24
  store i64 %t96, ptr %l45, !tbaa !24
  %t97 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 0
  store i64 %t98, ptr %l46, !tbaa !24
  %t99 = load i64, ptr %l44, !tbaa !24
  %t100 = icmp sge i64 %t99, 0
  br i1 %t100, label %bb28, label %bb29
bb28:
  %t102 = load i64, ptr %l44, !tbaa !24
  %t103 = load i64, ptr %l45, !tbaa !24
  %t104 = icmp sle i64 %t102, %t103
  br i1 %t104, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_60a4feb33ac0cdc_badaef821bc3f128)
  unreachable
bb30:
  %t106 = load i64, ptr %l45, !tbaa !24
  %t107 = load i64, ptr %l46, !tbaa !24
  %t108 = icmp sle i64 %t106, %t107
  br i1 %t108, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_60a4feb33ac0cdc_badaef821bc3f128)
  unreachable
bb32:
  %t110 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = load i64, ptr %l44, !tbaa !24
  %t113 = load i64, ptr %l45, !tbaa !24
  %t114 = getelementptr i8, ptr %t111, i64 %t112
  %t115 = sub i64 %t113, %t112
  %t116 = insertvalue { i64, ptr } undef, i64 %t115, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t114, 1
  %t119 = extractvalue { i64, ptr } %t117, 1
  %t120 = extractvalue { i64, ptr } %t117, 0
  %t121 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t120)
  call void @olang_textcopy(ptr %t121, ptr %t119, i64 %t120)
  %t122 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t121, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t123, ptr %rv
  br label %ret
bb33:
  call void @__olang_check_failed(ptr @olang_loc_60a4feb33ac0cdc_badaef821bc3f128)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2flisting_2ebody(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %v7, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4, ptr %a5, ptr %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca %"std/prelude/text:StringBuilder"
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca %"compiler/listing:Remark"
  %l23 = alloca { i64, ptr }
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l32 = alloca { i64, ptr }
  %l47 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l51 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l53 = alloca { i64, ptr }
  %l54 = alloca ptr
  %l55 = alloca ptr
  %l57 = alloca { i64, ptr }
  %l58 = alloca %"compiler/listing:Writer"
  %l61 = alloca i64
  %l63 = alloca i64
  %l68 = alloca { i64, ptr }
  %l79 = alloca i64
  %l83 = alloca %"std/prelude/text:StringBuilder"
  %l84 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l86 = alloca i64
  %l88 = alloca i64
  %l93 = alloca %"compiler/listing:Remark"
  %l95 = alloca i1
  %l96 = alloca i1
  %l98 = alloca i1
  %l99 = alloca i1
  %l103 = alloca i1
  %l104 = alloca i1
  %l107 = alloca { i64, ptr }
  %l110 = alloca i1
  %l112 = alloca ptr
  %l115 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l122 = alloca i64
  %l125 = alloca { i64, ptr }
  %l129 = alloca i1
  %l131 = alloca { i64, ptr }
  %l134 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l137 = alloca i64
  %l140 = alloca i64
  %l142 = alloca { i64, ptr }
  %l144 = alloca { i64, ptr }
  %l145 = alloca { i64, ptr }
  %l147 = alloca i64
  %l153 = alloca ptr
  %l156 = alloca { i64, ptr }
  %l158 = alloca ptr
  %l160 = alloca { i64, ptr }
  %l163 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t82 = alloca %"compiler/listing:Writer", align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l24
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l7
  store { i64, ptr } %a3, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l10, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l9, !tbaa !24
  %t10 = load i64, ptr %l10, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t17, ptr %l32, !tbaa !27
  %t18 = load i64, ptr %l9, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %t21, i64 %t18
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !37
  %t27 = extractvalue { i64, ptr } %t23, 1
  %t28 = extractvalue { i64, ptr } %t23, 0
  %t29 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t27, i64 %t28)
  %t30 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } %t38)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t41 = load i64, ptr %l9, !tbaa !24
  %t43 = add i64 %t41, 1
  store i64 %t43, ptr %l9, !tbaa !24
  br label %bb2
bb8:
  %t45 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 1
  %t48 = extractvalue { i64, ptr } %t45, 0
  %t49 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t48)
  call void @olang_textcopy(ptr %t49, ptr %t47, i64 %t48)
  %t50 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  %t53 = extractvalue { i64, ptr } %t51, 0
  %t54 = extractvalue { i64, ptr } %t51, 1
  %t55 = mul i64 %t53, 1
  %t56 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t55)
  call void @llvm.memcpy.p0.p0.i64(ptr %t56, ptr %t54, i64 %t55, i1 false)
  %t57 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } %t58)
  br label %bb9
bb9:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/listing:Inputs", ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = getelementptr %"compiler/build:Listed", ptr %t64, i32 0, i32 1
  store ptr %t66, ptr %l47, !tbaa !29
  %t68 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s0, ptr %s0, ptr %l7)
  store { i64, ptr } %t68, ptr %l49
  br label %bb10
bb10:
  %t69 = load ptr, ptr %l5, !tbaa !29
  %t70 = load ptr, ptr %l47, !tbaa !29
  %t71 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t73 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2flisting_2eRemarks(ptr %v0, ptr %s0, ptr %v5, ptr %s0, ptr %t70, { i64, ptr } %t71, ptr %t69)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t73, ptr %l51
  br label %bb11
bb11:
  %t74 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l51
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t74, ptr %l12
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/listing:Inputs", ptr %t75, i32 0, i32 3
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !27
  store { i64, ptr } %t78, ptr %l53, !tbaa !27
  store ptr %a6, ptr %l54, !tbaa !29
  store ptr %l12, ptr %l55, !tbaa !29
  %t81 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s0, ptr %s0, ptr %l7)
  store { i64, ptr } %t81, ptr %l57
  br label %bb12
bb12:
  %t83 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t84 = load ptr, ptr %l54, !tbaa !29
  %t85 = load ptr, ptr %l55, !tbaa !29
  %t86 = load { i64, ptr }, ptr %l57, !tbaa !27
  call void @compiler_2flisting_3aWriter_2ector(ptr %t82, ptr %v0, ptr %v6, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t83, ptr %t84, ptr %t85, { i64, ptr } %t86)
  call void @llvm.memmove.p0.p0.i64(ptr %l58, ptr %t82, i64 184, i1 false)
  br label %bb13
bb13:
  %t87 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 184, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t87, ptr %l58, i64 184, i1 false)
  store ptr %t87, ptr %l13, !tbaa !29
  store ptr %a4, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb14
bb14:
  %t91 = load i64, ptr %l15, !tbaa !24
  store i64 %t91, ptr %l61, !tbaa !24
  %t92 = load ptr, ptr %l14, !tbaa !29
  %t94 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v4, ptr %t92)
  store i64 %t94, ptr %l63
  br label %bb15
bb15:
  %t95 = load i64, ptr %l61, !tbaa !24
  %t96 = load i64, ptr %l63, !tbaa !24
  %t97 = icmp slt i64 %t95, %t96
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb16, label %bb17
bb16:
  br label %bb30
bb17:
  br label %bb18
bb18:
  %t101 = load ptr, ptr %l14, !tbaa !29
  %t102 = load i64, ptr %l15, !tbaa !24
  %t105 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v4, ptr %v4, ptr %t101, i64 %t102)
  store { i64, ptr } %t105, ptr %l68
  br label %bb19
bb19:
  %t106 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t106, ptr %l16, !tbaa !27
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/listing:Inputs", ptr %t107, i32 0, i32 4
  %t110 = load i1, ptr %t109, !tbaa !21
  br i1 %t110, label %bb20, label %bb21
bb20:
  %t112 = load ptr, ptr %l13, !tbaa !29
  %t113 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t114 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @compiler_2flisting_2ecompiler_2flisting_3aWriter_2eirPart(ptr %s0, ptr %v4, ptr %v1, ptr %t112, { i64, ptr } %t113, { i64, ptr } %t114)
  br label %bb22
bb21:
  %t118 = load ptr, ptr %l13, !tbaa !29
  %t119 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t120 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @compiler_2flisting_2ecompiler_2flisting_3aWriter_2easmPart(ptr %s0, ptr %v4, ptr %v1, ptr %t118, { i64, ptr } %t119, { i64, ptr } %t120)
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb24
bb24:
  %t124 = load ptr, ptr %l13, !tbaa !29
  %t126 = getelementptr %"compiler/listing:Writer", ptr %t124, i32 0, i32 10
  %t128 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %t126)
  store i64 %t128, ptr %l79
  br label %bb25
bb25:
  %t129 = load i64, ptr %l79, !tbaa !24
  %t130 = icmp sgt i64 %t129, 0
  br i1 %t130, label %bb26, label %bb27
bb26:
  br label %bb30
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t132 = load i64, ptr %l15, !tbaa !24
  %t134 = add i64 %t132, 1
  store i64 %t134, ptr %l15, !tbaa !24
  br label %bb14
bb30:
  %t136 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t136, ptr %l83
  br label %bb31
bb31:
  %t137 = load %"std/prelude/text:StringBuilder", ptr %l83
  store %"std/prelude/text:StringBuilder" %t137, ptr %l17
  %t138 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t138, ptr %l84
  br label %bb32
bb32:
  %t139 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l84
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t139, ptr %l18
  store ptr %l12, ptr %l19, !tbaa !29
  store i64 0, ptr %l20, !tbaa !24
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s13
  %t141 = load i64, ptr %l20, !tbaa !24
  store i64 %t141, ptr %l86, !tbaa !24
  %t142 = load ptr, ptr %l19, !tbaa !29
  %t144 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flisting_3aRemark_3e_2eLen_3ccompiler_2flisting_3aRemark_3e(ptr %s0, ptr %t142)
  store i64 %t144, ptr %l88
  br label %bb34
bb34:
  %t145 = load i64, ptr %l86, !tbaa !24
  %t146 = load i64, ptr %l88, !tbaa !24
  %t147 = icmp slt i64 %t145, %t146
  %t149 = xor i1 %t147, true
  br i1 %t149, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s13)
  br label %bb59
bb36:
  br label %bb37
bb37:
  %t151 = load ptr, ptr %l19, !tbaa !29
  %t152 = load i64, ptr %l20, !tbaa !24
  %t155 = call %"compiler/listing:Remark" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flisting_3aRemark_3e_2eAt_3ccompiler_2flisting_3aRemark_3e(ptr %s0, ptr %s0, ptr %t151, i64 %t152)
  store %"compiler/listing:Remark" %t155, ptr %l93
  br label %bb38
bb38:
  %t156 = load %"compiler/listing:Remark", ptr %l93
  store %"compiler/listing:Remark" %t156, ptr %l21
  %t157 = getelementptr %"compiler/listing:Remark", ptr %l21, i32 0, i32 1
  %t158 = load { i64, ptr }, ptr %t157, !tbaa !27
  %t160 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s13, { i64, ptr } %t158, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i1 %t160, ptr %l95
  br label %bb39
bb39:
  %t161 = load i1, ptr %l95, !tbaa !21
  br i1 %t161, label %bb40, label %bb41
bb40:
  %t162 = getelementptr %"compiler/listing:Remark", ptr %l21, i32 0, i32 0
  %t163 = load { i64, ptr }, ptr %t162, !tbaa !27
  %t165 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s13, { i64, ptr } %t163, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store i1 %t165, ptr %l98
  br label %bb42
bb41:
  store i1 false, ptr %l96, !tbaa !21
  br label %bb43
bb42:
  %t166 = load i1, ptr %l98, !tbaa !21
  store i1 %t166, ptr %l96, !tbaa !21
  br label %bb43
bb43:
  %t167 = load i1, ptr %l96, !tbaa !21
  br i1 %t167, label %bb44, label %bb45
bb44:
  %t168 = getelementptr %"compiler/listing:Remark", ptr %l21, i32 0, i32 5
  %t169 = load { i64, ptr }, ptr %t168, !tbaa !27
  %t170 = load ptr, ptr %l13, !tbaa !29
  %t172 = getelementptr %"compiler/listing:Writer", ptr %t170, i32 0, i32 3
  %t173 = load { i64, ptr }, ptr %t172, !tbaa !27
  %t176 = call i1 @compiler_2flisting_2eofAny(ptr %s0, ptr %s0, { i64, ptr } %t169, { i64, ptr } %t173)
  store i1 %t176, ptr %l103
  br label %bb46
bb45:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb47
bb46:
  %t177 = load i1, ptr %l103, !tbaa !21
  store i1 %t177, ptr %l99, !tbaa !21
  br label %bb47
bb47:
  %t178 = load i1, ptr %l99, !tbaa !21
  br i1 %t178, label %bb48, label %bb49
bb48:
  %t179 = load ptr, ptr %l5, !tbaa !29
  %t180 = getelementptr %"compiler/listing:Remark", ptr %l21, i32 0, i32 6
  %t181 = load { i64, ptr }, ptr %t180, !tbaa !27
  %t184 = call { i64, ptr } @compiler_2flisting_2ecompiler_2flisting_3aNamer_2eName(ptr %v5, ptr %s0, ptr %s13, ptr %t179, { i64, ptr } %t181)
  store { i64, ptr } %t184, ptr %l107
  br label %bb50
bb49:
  store i1 false, ptr %l104, !tbaa !21
  br label %bb52
bb50:
  %t185 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t189 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %s0, ptr %s13, ptr %l18, { i64, ptr } %t185)
  store i1 %t189, ptr %l110
  br label %bb51
bb51:
  %t190 = load i1, ptr %l110, !tbaa !21
  %t191 = xor i1 %t190, true
  store i1 %t191, ptr %l104, !tbaa !21
  br label %bb52
bb52:
  %t193 = load i1, ptr %l104, !tbaa !21
  br i1 %t193, label %bb53, label %bb54
bb53:
  store ptr %l18, ptr %l112, !tbaa !29
  %t194 = load ptr, ptr %l5, !tbaa !29
  %t195 = getelementptr %"compiler/listing:Remark", ptr %l21, i32 0, i32 6
  %t196 = load { i64, ptr }, ptr %t195, !tbaa !27
  %t199 = call { i64, ptr } @compiler_2flisting_2ecompiler_2flisting_3aNamer_2eName(ptr %v5, ptr %s0, ptr %s0, ptr %t194, { i64, ptr } %t196)
  store { i64, ptr } %t199, ptr %l115
  br label %bb55
bb54:
  br label %bb57
bb55:
  %t200 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t201 = extractvalue { i64, ptr } %t200, 0
  %t202 = extractvalue { i64, ptr } %t200, 1
  %t203 = mul i64 %t201, 1
  %t204 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t203)
  call void @llvm.memcpy.p0.p0.i64(ptr %t204, ptr %t202, i64 %t203, i1 false)
  %t205 = insertvalue { i64, ptr } undef, i64 %t201, 0
  %t206 = insertvalue { i64, ptr } %t205, ptr %t204, 1
  %t207 = load ptr, ptr %l112, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t207, { i64, ptr } %t206)
  br label %bb56
bb56:
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s13)
  br label %bb58
bb58:
  %t209 = load i64, ptr %l20, !tbaa !24
  %t211 = add i64 %t209, 1
  store i64 %t211, ptr %l20, !tbaa !24
  br label %bb33
bb59:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/listing:Inputs", ptr %t213, i32 0, i32 3
  %t216 = load { i64, ptr }, ptr %t215, !tbaa !27
  store { i64, ptr } %t216, ptr %l120, !tbaa !27
  %t217 = load ptr, ptr %l13, !tbaa !29
  %t219 = getelementptr %"compiler/listing:Writer", ptr %t217, i32 0, i32 11
  %t220 = load i64, ptr %t219, !tbaa !24
  store i64 %t220, ptr %l122, !tbaa !24
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/listing:Inputs", ptr %t221, i32 0, i32 4
  %t224 = load i1, ptr %t223, !tbaa !21
  br i1 %t224, label %bb60, label %bb61
bb60:
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l125, !tbaa !27
  br label %bb62
bb61:
  store { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l125, !tbaa !27
  br label %bb62
bb62:
  %t226 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t227 = extractvalue { i64, ptr } %t226, 1
  %t228 = extractvalue { i64, ptr } %t226, 0
  %t229 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t230 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t231 = add i64 %t228, %t230
  %t232 = load i64, ptr %l122, !tbaa !24
  %t233 = call i64 @__olang_fmt_i64(ptr null, i64 %t232)
  %t234 = add i64 %t231, %t233
  %t235 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t236 = extractvalue { i64, ptr } %t235, 1
  %t237 = extractvalue { i64, ptr } %t235, 0
  %t238 = add i64 %t234, %t237
  %t239 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t238)
  call void @olang_textcopy(ptr %t239, ptr %t227, i64 %t228)
  %t240 = getelementptr i8, ptr %t239, i64 %t228
  call void @olang_textcopy(ptr %t240, ptr %t229, i64 %t230)
  %t241 = getelementptr i8, ptr %t240, i64 %t230
  %t242 = call i64 @__olang_fmt_i64(ptr %t241, i64 %t232)
  %t243 = getelementptr i8, ptr %t241, i64 %t233
  call void @olang_textcopy(ptr %t243, ptr %t236, i64 %t237)
  %t244 = insertvalue { i64, ptr } undef, i64 %t238, 0
  %t245 = insertvalue { i64, ptr } %t244, ptr %t239, 1
  store { i64, ptr } %t245, ptr %l23, !tbaa !27
  %t247 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t251 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %v2, { i64, ptr } %t247, { i64, ptr } %a2)
  store i1 %t251, ptr %l129
  br label %bb63
bb63:
  %t252 = load i1, ptr %l129, !tbaa !21
  %t253 = xor i1 %t252, true
  br i1 %t253, label %bb64, label %bb65
bb64:
  store %olang.scope zeroinitializer, ptr %s17
  %t255 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t255, ptr %l131, !tbaa !27
  %t256 = load ptr, ptr %l5, !tbaa !29
  %t257 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t260 = call { i64, ptr } @compiler_2flisting_2ecompiler_2flisting_3aNamer_2eName(ptr %v5, ptr %v1, ptr %s17, ptr %t256, { i64, ptr } %t257)
  store { i64, ptr } %t260, ptr %l134
  br label %bb66
bb65:
  br label %bb70
bb66:
  %t261 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t262 = extractvalue { i64, ptr } %t261, 1
  %t263 = extractvalue { i64, ptr } %t261, 0
  %t264 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t265 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t266 = add i64 %t263, %t265
  %t267 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t268 = extractvalue { i64, ptr } %t267, 1
  %t269 = extractvalue { i64, ptr } %t267, 0
  %t270 = add i64 %t266, %t269
  %t271 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t272 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t273 = add i64 %t270, %t272
  %t274 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t273)
  call void @olang_textcopy(ptr %t274, ptr %t262, i64 %t263)
  %t275 = getelementptr i8, ptr %t274, i64 %t263
  call void @olang_textcopy(ptr %t275, ptr %t264, i64 %t265)
  %t276 = getelementptr i8, ptr %t275, i64 %t265
  call void @olang_textcopy(ptr %t276, ptr %t268, i64 %t269)
  %t277 = getelementptr i8, ptr %t276, i64 %t269
  call void @olang_textcopy(ptr %t277, ptr %t271, i64 %t272)
  %t278 = insertvalue { i64, ptr } undef, i64 %t273, 0
  %t279 = insertvalue { i64, ptr } %t278, ptr %t274, 1
  store { i64, ptr } %t279, ptr %l135, !tbaa !27
  %t280 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t281 = extractvalue { i64, ptr } %t280, 0
  %t282 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t283 = extractvalue { i64, ptr } %t282, 0
  store i64 %t283, ptr %l137, !tbaa !24
  %t285 = load i64, ptr %l137, !tbaa !24
  %t286 = icmp eq i64 %t281, %t285
  br i1 %t286, label %bb67, label %bb68
bb67:
  %t288 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t289 = load ptr, ptr %t288, !tbaa !27
  %t290 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t291 = load ptr, ptr %t290, !tbaa !27
  %t292 = load i64, ptr %l137, !tbaa !24
  %t293 = mul i64 %t292, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t289, ptr %t291, i64 %t293, i1 false)
  br label %bb69
bb68:
  %t294 = load { i64, ptr }, ptr %l135, !tbaa !27
  store { i64, ptr } %t294, ptr %l23, !tbaa !27
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s17)
  br label %bb70
bb70:
  %t296 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l18)
  store i64 %t296, ptr %l140
  br label %bb71
bb71:
  %t297 = load i64, ptr %l140, !tbaa !24
  %t298 = icmp sgt i64 %t297, 0
  br i1 %t298, label %bb72, label %bb73
bb72:
  store %olang.scope zeroinitializer, ptr %s19
  %t300 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t300, ptr %l142, !tbaa !27
  %t302 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s0, ptr %s19, ptr %s19, ptr %l18, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store { i64, ptr } %t302, ptr %l144
  br label %bb74
bb73:
  br label %bb78
bb74:
  %t303 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t304 = extractvalue { i64, ptr } %t303, 1
  %t305 = extractvalue { i64, ptr } %t303, 0
  %t306 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t307 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t308 = add i64 %t305, %t307
  %t309 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t310 = extractvalue { i64, ptr } %t309, 1
  %t311 = extractvalue { i64, ptr } %t309, 0
  %t312 = add i64 %t308, %t311
  %t313 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t312)
  call void @olang_textcopy(ptr %t313, ptr %t304, i64 %t305)
  %t314 = getelementptr i8, ptr %t313, i64 %t305
  call void @olang_textcopy(ptr %t314, ptr %t306, i64 %t307)
  %t315 = getelementptr i8, ptr %t314, i64 %t307
  call void @olang_textcopy(ptr %t315, ptr %t310, i64 %t311)
  %t316 = insertvalue { i64, ptr } undef, i64 %t312, 0
  %t317 = insertvalue { i64, ptr } %t316, ptr %t313, 1
  store { i64, ptr } %t317, ptr %l145, !tbaa !27
  %t318 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t319 = extractvalue { i64, ptr } %t318, 0
  %t320 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t321 = extractvalue { i64, ptr } %t320, 0
  store i64 %t321, ptr %l147, !tbaa !24
  %t323 = load i64, ptr %l147, !tbaa !24
  %t324 = icmp eq i64 %t319, %t323
  br i1 %t324, label %bb75, label %bb76
bb75:
  %t326 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t327 = load ptr, ptr %t326, !tbaa !27
  %t328 = getelementptr { i64, ptr }, ptr %l145, i32 0, i32 1
  %t329 = load ptr, ptr %t328, !tbaa !27
  %t330 = load i64, ptr %l147, !tbaa !24
  %t331 = mul i64 %t330, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t327, ptr %t329, i64 %t331, i1 false)
  br label %bb77
bb76:
  %t332 = load { i64, ptr }, ptr %l145, !tbaa !27
  store { i64, ptr } %t332, ptr %l23, !tbaa !27
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s19)
  br label %bb78
bb78:
  %t333 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t335 = extractvalue { i64, ptr } %t333, 1
  %t336 = extractvalue { i64, ptr } %t333, 0
  %t337 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t338 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t339 = add i64 %t336, %t338
  %t340 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t339)
  call void @olang_textcopy(ptr %t340, ptr %t335, i64 %t336)
  %t341 = getelementptr i8, ptr %t340, i64 %t336
  call void @olang_textcopy(ptr %t341, ptr %t337, i64 %t338)
  %t342 = insertvalue { i64, ptr } undef, i64 %t339, 0
  %t343 = insertvalue { i64, ptr } %t342, ptr %t340, 1
  %t345 = extractvalue { i64, ptr } %t343, 0
  %t346 = extractvalue { i64, ptr } %t343, 1
  %t347 = mul i64 %t345, 1
  %t348 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t347)
  call void @llvm.memcpy.p0.p0.i64(ptr %t348, ptr %t346, i64 %t347, i1 false)
  %t349 = insertvalue { i64, ptr } undef, i64 %t345, 0
  %t350 = insertvalue { i64, ptr } %t349, ptr %t348, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l17, { i64, ptr } %t350)
  br label %bb79
bb79:
  store ptr %l17, ptr %l153, !tbaa !29
  %t353 = load ptr, ptr %l13, !tbaa !29
  %t355 = getelementptr %"compiler/listing:Writer", ptr %t353, i32 0, i32 10
  %t357 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %t355)
  store { i64, ptr } %t357, ptr %l156
  br label %bb80
bb80:
  %t358 = load { i64, ptr }, ptr %l156, !tbaa !27
  %t359 = extractvalue { i64, ptr } %t358, 0
  %t360 = extractvalue { i64, ptr } %t358, 1
  %t361 = mul i64 %t359, 1
  %t362 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t361)
  call void @llvm.memcpy.p0.p0.i64(ptr %t362, ptr %t360, i64 %t361, i1 false)
  %t363 = insertvalue { i64, ptr } undef, i64 %t359, 0
  %t364 = insertvalue { i64, ptr } %t363, ptr %t362, 1
  %t365 = load ptr, ptr %l153, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t365, { i64, ptr } %t364)
  br label %bb81
bb81:
  store ptr %l17, ptr %l158, !tbaa !29
  %t367 = load ptr, ptr %l13, !tbaa !29
  %t369 = call { i64, ptr } @compiler_2flisting_2ecompiler_2flisting_3aWriter_2eleftover(ptr %s0, ptr %s0, ptr %t367)
  store { i64, ptr } %t369, ptr %l160
  br label %bb82
bb82:
  %t370 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t371 = extractvalue { i64, ptr } %t370, 0
  %t372 = extractvalue { i64, ptr } %t370, 1
  %t373 = mul i64 %t371, 1
  %t374 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t373)
  call void @llvm.memcpy.p0.p0.i64(ptr %t374, ptr %t372, i64 %t373, i1 false)
  %t375 = insertvalue { i64, ptr } undef, i64 %t371, 0
  %t376 = insertvalue { i64, ptr } %t375, ptr %t374, 1
  %t377 = load ptr, ptr %l158, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t377, { i64, ptr } %t376)
  br label %bb83
bb83:
  %t380 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v7, ptr %l17)
  store { i64, ptr } %t380, ptr %l163
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s0)
  %t381 = load { i64, ptr }, ptr %l163, !tbaa !27
  store { i64, ptr } %t381, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2flisting_2ecallersOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/listing:Remark"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca i64
  %l11 = alloca i64
  %l16 = alloca %"compiler/listing:Remark"
  %l18 = alloca i1
  %l20 = alloca i1
  %l22 = alloca i1
  %l24 = alloca i1
  %l27 = alloca i1
  %l32 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  store ptr %a0, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l4, !tbaa !24
  store i64 %t7, ptr %l9, !tbaa !24
  %t8 = load ptr, ptr %l3, !tbaa !29
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flisting_3aRemark_3e_2eLen_3ccompiler_2flisting_3aRemark_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l11
  br label %bb3
bb3:
  %t11 = load i64, ptr %l9, !tbaa !24
  %t12 = load i64, ptr %l11, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb5:
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = call %"compiler/listing:Remark" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flisting_3aRemark_3e_2eAt_3ccompiler_2flisting_3aRemark_3e(ptr %v0, ptr %v0, ptr %t17, i64 %t18)
  store %"compiler/listing:Remark" %t21, ptr %l16
  br label %bb7
bb7:
  %t22 = load %"compiler/listing:Remark", ptr %l16
  store %"compiler/listing:Remark" %t22, ptr %l5
  %t23 = getelementptr %"compiler/listing:Remark", ptr %l5, i32 0, i32 1
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t24, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t26, ptr %l18
  br label %bb8
bb8:
  %t27 = load i1, ptr %l18, !tbaa !21
  %t28 = xor i1 %t27, true
  br i1 %t28, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb12
bb10:
  %t30 = getelementptr %"compiler/listing:Remark", ptr %l5, i32 0, i32 0
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  %t33 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t31, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store i1 %t33, ptr %l22
  br label %bb11
bb11:
  %t34 = load i1, ptr %l22, !tbaa !21
  %t35 = xor i1 %t34, true
  store i1 %t35, ptr %l20, !tbaa !21
  br label %bb12
bb12:
  %t37 = load i1, ptr %l20, !tbaa !21
  br i1 %t37, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb16
bb14:
  %t38 = getelementptr %"compiler/listing:Remark", ptr %l5, i32 0, i32 6
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  %t43 = call i1 @compiler_2flisting_2eofSym(ptr %v0, ptr %v1, { i64, ptr } %t39, { i64, ptr } %a1)
  store i1 %t43, ptr %l27
  br label %bb15
bb15:
  %t44 = load i1, ptr %l27, !tbaa !21
  %t45 = xor i1 %t44, true
  store i1 %t45, ptr %l24, !tbaa !21
  br label %bb16
bb16:
  %t47 = load i1, ptr %l24, !tbaa !21
  br i1 %t47, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb18:
  br label %bb19
bb19:
  %t48 = getelementptr %"compiler/listing:Remark", ptr %l5, i32 0, i32 5
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  %t51 = load ptr, ptr %lp2
  %t55 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %v2, ptr %v0, ptr %t51, { i64, ptr } %t49)
  store i1 %t55, ptr %l32
  br label %bb20
bb20:
  %t56 = load i1, ptr %l32, !tbaa !21
  %t57 = xor i1 %t56, true
  br i1 %t57, label %bb21, label %bb22
bb21:
  %t59 = load ptr, ptr %lp2
  %t60 = getelementptr %"compiler/listing:Remark", ptr %l5, i32 0, i32 5
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t61, 1
  %t64 = extractvalue { i64, ptr } %t61, 0
  %t65 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t64)
  call void @olang_textcopy(ptr %t65, ptr %t63, i64 %t64)
  %t66 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t65, 1
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t70 = extractvalue { i64, ptr } %t67, 1
  %t71 = mul i64 %t69, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t70, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t59, { i64, ptr } %t74)
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb25:
  %t77 = load i64, ptr %l4, !tbaa !24
  %t79 = add i64 %t77, 1
  store i64 %t79, ptr %l4, !tbaa !24
  br label %bb2
bb26:
  %t81 = load ptr, ptr %lp2
  %t82 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t81
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t82, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local { i64, ptr } @compiler_2flisting_2ecommentOf(ptr %v0, ptr %v1, ptr %a0, i1 %a1) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l9 = alloca i1
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  br i1 %a1, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, ptr %l3, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t3, ptr %l4, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  store i64 %t5, ptr %l5, !tbaa !24
  %t6 = load i64, ptr %l5, !tbaa !24
  %t7 = mul i64 %t6, 1
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  %t9 = insertvalue { i64, ptr } undef, i64 %t6, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  store { i64, ptr } %t10, ptr %l6, !tbaa !27
  %t11 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = load i64, ptr %l5, !tbaa !24
  %t16 = mul i64 %t15, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t12, ptr %t14, i64 %t16, i1 false)
  %t17 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t17, ptr %l4, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t21 = getelementptr %"compiler/build:Config", ptr %a0, i32 0, i32 2
  %t22 = getelementptr %"compiler/target:Target", ptr %t21, i32 0, i32 2
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t23, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d18, i32 0, i32 1) })
  store i1 %t25, ptr %l9
  br label %bb4
bb4:
  %t26 = load i1, ptr %l9, !tbaa !21
  br i1 %t26, label %bb5, label %bb6
bb5:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l11, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t27, ptr %l10, !tbaa !27
  br label %bb7
bb6:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l13, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t29, ptr %l10, !tbaa !27
  br label %bb7
bb7:
  %t31 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l15, !tbaa !24
  %t33 = load i64, ptr %l15, !tbaa !24
  %t34 = mul i64 %t33, 1
  %t35 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t34)
  %t36 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  store { i64, ptr } %t37, ptr %l16, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = load i64, ptr %l15, !tbaa !24
  %t43 = mul i64 %t42, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t39, ptr %t41, i64 %t43, i1 false)
  %t44 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t44, ptr %l10, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t45 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t45, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2flisting_2ecompiler_2flisting_3aNamer_2eName(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i32
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l27 = alloca { i64, ptr }
  %l30 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l41 = alloca { i64, ptr }
  %l44 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca i64
  %l55 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l60 = alloca i1
  %l63 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i32
  %l69 = alloca { i64, ptr }
  %l70 = alloca i64
  %l71 = alloca i64
  %l77 = alloca i1
  %l79 = alloca i1
  %l82 = alloca { i64, ptr }
  %l83 = alloca i1
  %l85 = alloca i1
  %l88 = alloca { i64, ptr }
  %l89 = alloca i1
  %l91 = alloca i1
  %l94 = alloca { i64, ptr }
  %l95 = alloca i1
  %l98 = alloca i64
  %l100 = alloca i64
  %l101 = alloca i64
  %l108 = alloca { i64, ptr }
  %l109 = alloca i1
  %l110 = alloca { i64, ptr }
  %l113 = alloca { i64, ptr }
  %l117 = alloca i1
  %l118 = alloca { i64, ptr }
  %l122 = alloca i64
  %l126 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d21, i32 0, i32 1) })
  store i1 %t3, ptr %l8
  br label %bb1
bb1:
  %t4 = load i1, ptr %l8, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l9, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t5, ptr %l10, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l11, !tbaa !24
  %t8 = load i64, ptr %l11, !tbaa !24
  %t9 = mul i64 %t8, 1
  %t10 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l12, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = load i64, ptr %l11, !tbaa !24
  %t18 = mul i64 %t17, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %t16, i64 %t18, i1 false)
  %t19 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t19, ptr %l10, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t20 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t20, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t21 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t23 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s0, { i64, ptr } %t21, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d23, i32 0, i32 1) })
  %t24 = extractvalue { i32, i64 } %t23, 1
  %t25 = extractvalue { i32, i64 } %t23, 0
  store i32 %t25, ptr %l16
  %t26 = icmp ne i32 %t25, 0
  br i1 %t26, label %bb6, label %ok.27, !prof !99
ok.27:
  store i64 %t24, ptr %l15
  br label %bb5
bb5:
  %t28 = load i64, ptr %l15, !tbaa !24
  store i64 %t28, ptr %l13, !tbaa !24
  br label %bb8
bb6:
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l13, !tbaa !24
  br label %bb8
bb8:
  %t29 = load i64, ptr %l13, !tbaa !24
  store i64 %t29, ptr %l2, !tbaa !24
  %t30 = load i64, ptr %l2, !tbaa !24
  %t32 = icmp sgt i64 %t30, 0
  br i1 %t32, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l19, !tbaa !29
  %t35 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t35, ptr %l20, !tbaa !27
  %t36 = load i64, ptr %l2, !tbaa !24
  store i64 %t36, ptr %l21, !tbaa !24
  %t37 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  store i64 %t38, ptr %l22, !tbaa !24
  %t39 = icmp sge i64 0, 0
  br i1 %t39, label %bb11, label %bb12
bb10:
  br label %bb18
bb11:
  %t41 = load i64, ptr %l21, !tbaa !24
  %t42 = icmp sle i64 0, %t41
  br i1 %t42, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_4c5476cd02c9d569_d2b16f8f5de4ce55)
  unreachable
bb13:
  %t44 = load i64, ptr %l21, !tbaa !24
  %t45 = load i64, ptr %l22, !tbaa !24
  %t46 = icmp sle i64 %t44, %t45
  br i1 %t46, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_4c5476cd02c9d569_d2b16f8f5de4ce55)
  unreachable
bb15:
  %t48 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l21, !tbaa !24
  %t51 = getelementptr i8, ptr %t49, i64 0
  %t52 = sub i64 %t50, 0
  %t53 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t51, 1
  %t55 = load ptr, ptr %l19, !tbaa !29
  %t57 = call { i64, ptr } @compiler_2flisting_2ecompiler_2flisting_3aNamer_2eName(ptr %v0, ptr %v1, ptr %s2, ptr %t55, { i64, ptr } %t54)
  store { i64, ptr } %t57, ptr %l27
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_4c5476cd02c9d569_d2b16f8f5de4ce55)
  unreachable
bb17:
  %t58 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t58, 1
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t61 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t62 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t63 = add i64 %t60, %t62
  %t64 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t63)
  call void @olang_textcopy(ptr %t64, ptr %t59, i64 %t60)
  %t65 = getelementptr i8, ptr %t64, i64 %t60
  call void @olang_textcopy(ptr %t65, ptr %t61, i64 %t62)
  %t66 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t64, 1
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t67, ptr %rv
  br label %ret
bb18:
  %t69 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t71 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v1, ptr %s0, { i64, ptr } %t69, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d25, i32 0, i32 1) })
  store i1 %t71, ptr %l30
  br label %bb19
bb19:
  %t72 = load i1, ptr %l30, !tbaa !21
  br i1 %t72, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s4
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l31, !tbaa !29
  %t74 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t74, ptr %l32, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t75, 0
  %t79 = sub i64 %t77, 8
  store i64 %t79, ptr %l35, !tbaa !24
  %t80 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 0
  store i64 %t81, ptr %l36, !tbaa !24
  %t82 = icmp sge i64 0, 0
  br i1 %t82, label %bb22, label %bb23
bb21:
  br label %bb29
bb22:
  %t84 = load i64, ptr %l35, !tbaa !24
  %t85 = icmp sle i64 0, %t84
  br i1 %t85, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_82458c7f9e0fa77c_b0b89e2c08a7ae78)
  unreachable
bb24:
  %t87 = load i64, ptr %l35, !tbaa !24
  %t88 = load i64, ptr %l36, !tbaa !24
  %t89 = icmp sle i64 %t87, %t88
  br i1 %t89, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_82458c7f9e0fa77c_b0b89e2c08a7ae78)
  unreachable
bb26:
  %t91 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = load i64, ptr %l35, !tbaa !24
  %t94 = getelementptr i8, ptr %t92, i64 0
  %t95 = sub i64 %t93, 0
  %t96 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t94, 1
  %t98 = load ptr, ptr %l31, !tbaa !29
  %t100 = call { i64, ptr } @compiler_2flisting_2ecompiler_2flisting_3aNamer_2eName(ptr %v0, ptr %v1, ptr %s4, ptr %t98, { i64, ptr } %t97)
  store { i64, ptr } %t100, ptr %l41
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_82458c7f9e0fa77c_b0b89e2c08a7ae78)
  unreachable
bb28:
  %t101 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 1
  %t103 = extractvalue { i64, ptr } %t101, 0
  %t104 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t105 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t106 = add i64 %t103, %t105
  %t107 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t106)
  call void @olang_textcopy(ptr %t107, ptr %t102, i64 %t103)
  %t108 = getelementptr i8, ptr %t107, i64 %t103
  call void @olang_textcopy(ptr %t108, ptr %t104, i64 %t105)
  %t109 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t107, 1
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t110, ptr %rv
  br label %ret
bb29:
  %t112 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t114 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v1, ptr %s0, { i64, ptr } %t112, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d27, i32 0, i32 1) })
  store i1 %t114, ptr %l44
  br label %bb30
bb30:
  %t115 = load i1, ptr %l44, !tbaa !21
  br i1 %t115, label %bb31, label %bb32
bb31:
  %t116 = load ptr, ptr %l0, !tbaa !29
  store ptr %t116, ptr %l45, !tbaa !29
  %t117 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t117, ptr %l46, !tbaa !27
  %t118 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t118, 0
  %t122 = sub i64 %t120, 7
  store i64 %t122, ptr %l49, !tbaa !24
  %t123 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  store i64 %t124, ptr %l50, !tbaa !24
  %t125 = icmp sge i64 0, 0
  br i1 %t125, label %bb33, label %bb34
bb32:
  br label %bb40
bb33:
  %t127 = load i64, ptr %l49, !tbaa !24
  %t128 = icmp sle i64 0, %t127
  br i1 %t128, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_1aee9fefcdd9cd27_6fa15990af9654d3)
  unreachable
bb35:
  %t130 = load i64, ptr %l49, !tbaa !24
  %t131 = load i64, ptr %l50, !tbaa !24
  %t132 = icmp sle i64 %t130, %t131
  br i1 %t132, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_1aee9fefcdd9cd27_6fa15990af9654d3)
  unreachable
bb37:
  %t134 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = load i64, ptr %l49, !tbaa !24
  %t137 = getelementptr i8, ptr %t135, i64 0
  %t138 = sub i64 %t136, 0
  %t139 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr %t137, 1
  %t141 = load ptr, ptr %l45, !tbaa !29
  %t143 = call { i64, ptr } @compiler_2flisting_2ecompiler_2flisting_3aNamer_2eName(ptr %v0, ptr %v1, ptr %v2, ptr %t141, { i64, ptr } %t140)
  store { i64, ptr } %t143, ptr %l55
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_1aee9fefcdd9cd27_6fa15990af9654d3)
  unreachable
bb39:
  call void @__olang_scope_close(ptr %s0)
  %t144 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t144, ptr %rv
  br label %ret
bb40:
  %t145 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t147 = call { i64, ptr } @compiler_2ftypes_2eDemangle(ptr %v1, ptr %s0, { i64, ptr } %t145)
  store { i64, ptr } %t147, ptr %l57
  br label %bb41
bb41:
  %t148 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t148, ptr %l3, !tbaa !27
  %t149 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t150 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t153 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %v1, { i64, ptr } %t149, { i64, ptr } %t150)
  store i1 %t153, ptr %l60
  br label %bb42
bb42:
  %t154 = load i1, ptr %l60, !tbaa !21
  br i1 %t154, label %bb43, label %bb44
bb43:
  %t155 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t155, 1
  %t158 = extractvalue { i64, ptr } %t155, 0
  %t159 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t158)
  call void @olang_textcopy(ptr %t159, ptr %t157, i64 %t158)
  %t160 = insertvalue { i64, ptr } undef, i64 %t158, 0
  %t161 = insertvalue { i64, ptr } %t160, ptr %t159, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t161, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t163 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t165 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s0, ptr %s0, { i64, ptr } %t163, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) })
  %t166 = extractvalue { i32, i64 } %t165, 1
  %t167 = extractvalue { i32, i64 } %t165, 0
  store i32 %t167, ptr %l66
  %t168 = icmp ne i32 %t167, 0
  br i1 %t168, label %bb47, label %ok.169, !prof !99
ok.169:
  store i64 %t166, ptr %l65
  br label %bb46
bb46:
  %t170 = load i64, ptr %l65, !tbaa !24
  store i64 %t170, ptr %l63, !tbaa !24
  br label %bb49
bb47:
  br label %bb48
bb48:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l63, !tbaa !24
  br label %bb49
bb49:
  %t171 = load i64, ptr %l63, !tbaa !24
  store i64 %t171, ptr %l4, !tbaa !24
  %t172 = load i64, ptr %l4, !tbaa !24
  %t174 = icmp sgt i64 %t172, 0
  br i1 %t174, label %bb50, label %bb51
bb50:
  %t176 = load i64, ptr %l4, !tbaa !24
  store i64 %t176, ptr %l70, !tbaa !24
  %t177 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t177, 0
  store i64 %t178, ptr %l71, !tbaa !24
  %t179 = icmp sge i64 0, 0
  br i1 %t179, label %bb52, label %bb53
bb51:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) }, ptr %l69, !tbaa !27
  br label %bb58
bb52:
  %t181 = load i64, ptr %l70, !tbaa !24
  %t182 = icmp sle i64 0, %t181
  br i1 %t182, label %bb54, label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_6a5ec5f2c3534a4a_bf3e4e4bffc8a476)
  unreachable
bb54:
  %t184 = load i64, ptr %l70, !tbaa !24
  %t185 = load i64, ptr %l71, !tbaa !24
  %t186 = icmp sle i64 %t184, %t185
  br i1 %t186, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_6a5ec5f2c3534a4a_bf3e4e4bffc8a476)
  unreachable
bb56:
  %t188 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = load i64, ptr %l70, !tbaa !24
  %t191 = getelementptr i8, ptr %t189, i64 0
  %t192 = sub i64 %t190, 0
  %t193 = insertvalue { i64, ptr } undef, i64 %t192, 0
  %t194 = insertvalue { i64, ptr } %t193, ptr %t191, 1
  store { i64, ptr } %t194, ptr %l69, !tbaa !27
  br label %bb58
bb57:
  call void @__olang_check_failed(ptr @olang_loc_6a5ec5f2c3534a4a_bf3e4e4bffc8a476)
  unreachable
bb58:
  %t196 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t196, ptr %l5, !tbaa !27
  %t197 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t199 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t197, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store i1 %t199, ptr %l77
  br label %bb59
bb59:
  %t200 = load i1, ptr %l77, !tbaa !21
  %t201 = xor i1 %t200, true
  br i1 %t201, label %bb60, label %bb61
bb60:
  %t203 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %l82, !tbaa !27
  %t206 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t207 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s0, { i64, ptr } %t203, { i64, ptr } %t206)
  store i1 %t207, ptr %l83
  br label %bb62
bb61:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb63
bb62:
  %t208 = load i1, ptr %l83, !tbaa !21
  %t209 = xor i1 %t208, true
  store i1 %t209, ptr %l79, !tbaa !21
  br label %bb63
bb63:
  %t211 = load i1, ptr %l79, !tbaa !21
  br i1 %t211, label %bb64, label %bb65
bb64:
  %t212 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, ptr %l88, !tbaa !27
  %t215 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t216 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s0, { i64, ptr } %t212, { i64, ptr } %t215)
  store i1 %t216, ptr %l89
  br label %bb66
bb65:
  store i1 false, ptr %l85, !tbaa !21
  br label %bb67
bb66:
  %t217 = load i1, ptr %l89, !tbaa !21
  %t218 = xor i1 %t217, true
  store i1 %t218, ptr %l85, !tbaa !21
  br label %bb67
bb67:
  %t220 = load i1, ptr %l85, !tbaa !21
  br i1 %t220, label %bb68, label %bb69
bb68:
  %t221 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) }, ptr %l94, !tbaa !27
  %t224 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t225 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s0, { i64, ptr } %t221, { i64, ptr } %t224)
  store i1 %t225, ptr %l95
  br label %bb70
bb69:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb71
bb70:
  %t226 = load i1, ptr %l95, !tbaa !21
  %t227 = xor i1 %t226, true
  store i1 %t227, ptr %l91, !tbaa !21
  br label %bb71
bb71:
  %t229 = load i1, ptr %l91, !tbaa !21
  br i1 %t229, label %bb72, label %bb73
bb72:
  store %olang.scope zeroinitializer, ptr %s9
  %t230 = load i64, ptr %l4, !tbaa !24
  %t232 = add i64 %t230, 1
  store i64 %t232, ptr %l98, !tbaa !24
  %t233 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t235 = extractvalue { i64, ptr } %t233, 0
  store i64 %t235, ptr %l100, !tbaa !24
  %t236 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t237 = extractvalue { i64, ptr } %t236, 0
  store i64 %t237, ptr %l101, !tbaa !24
  %t238 = load i64, ptr %l98, !tbaa !24
  %t239 = icmp sge i64 %t238, 0
  br i1 %t239, label %bb74, label %bb75
bb73:
  br label %bb89
bb74:
  %t241 = load i64, ptr %l98, !tbaa !24
  %t242 = load i64, ptr %l100, !tbaa !24
  %t243 = icmp sle i64 %t241, %t242
  br i1 %t243, label %bb76, label %bb77
bb75:
  call void @__olang_check_failed(ptr @olang_loc_af9ac36a56bc89c5_7398c12160466739)
  unreachable
bb76:
  %t245 = load i64, ptr %l100, !tbaa !24
  %t246 = load i64, ptr %l101, !tbaa !24
  %t247 = icmp sle i64 %t245, %t246
  br i1 %t247, label %bb78, label %bb79
bb77:
  call void @__olang_check_failed(ptr @olang_loc_af9ac36a56bc89c5_7398c12160466739)
  unreachable
bb78:
  %t249 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !27
  %t251 = load i64, ptr %l98, !tbaa !24
  %t252 = load i64, ptr %l100, !tbaa !24
  %t253 = getelementptr i8, ptr %t250, i64 %t251
  %t254 = sub i64 %t252, %t251
  %t255 = insertvalue { i64, ptr } undef, i64 %t254, 0
  %t256 = insertvalue { i64, ptr } %t255, ptr %t253, 1
  store { i64, ptr } %t256, ptr %l6, !tbaa !27
  %t258 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, ptr %l108, !tbaa !27
  %t261 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t262 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s9, { i64, ptr } %t258, { i64, ptr } %t261)
  store i1 %t262, ptr %l109
  br label %bb80
bb79:
  call void @__olang_check_failed(ptr @olang_loc_af9ac36a56bc89c5_7398c12160466739)
  unreachable
bb80:
  %t263 = load i1, ptr %l109, !tbaa !21
  br i1 %t263, label %bb81, label %bb82
bb81:
  %t264 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t266 = extractvalue { i64, ptr } %t264, 1
  %t267 = extractvalue { i64, ptr } %t264, 0
  %t268 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t267)
  call void @olang_textcopy(ptr %t268, ptr %t266, i64 %t267)
  %t269 = insertvalue { i64, ptr } undef, i64 %t267, 0
  %t270 = insertvalue { i64, ptr } %t269, ptr %t268, 1
  store { i64, ptr } %t270, ptr %l110, !tbaa !27
  br label %bb85
bb82:
  %t272 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t272, ptr %l113, !tbaa !27
  %t273 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/listing:Namer", ptr %t274, i32 0, i32 0
  %t277 = load { i64, ptr }, ptr %t276, !tbaa !27
  %t280 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %v0, { i64, ptr } %t273, { i64, ptr } %t277)
  store i1 %t280, ptr %l117
  br label %bb83
bb83:
  %t281 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t282 = load i1, ptr %l117, !tbaa !21
  %t283 = call { i64, ptr } @compiler_2fload_2eErrQualifier(ptr %s0, ptr %s9, { i64, ptr } %t281, i1 %t282)
  store { i64, ptr } %t283, ptr %l118
  br label %bb84
bb84:
  %t284 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t285 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t286 = extractvalue { i64, ptr } %t285, 1
  %t287 = extractvalue { i64, ptr } %t285, 0
  %t289 = extractvalue { i64, ptr } %t284, 1
  %t290 = extractvalue { i64, ptr } %t284, 0
  %t291 = add i64 %t287, %t290
  %t292 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t291)
  call void @olang_textcopy(ptr %t292, ptr %t286, i64 %t287)
  %t293 = getelementptr i8, ptr %t292, i64 %t287
  call void @olang_textcopy(ptr %t293, ptr %t289, i64 %t290)
  %t294 = insertvalue { i64, ptr } undef, i64 %t291, 0
  %t295 = insertvalue { i64, ptr } %t294, ptr %t292, 1
  store { i64, ptr } %t295, ptr %l110, !tbaa !27
  br label %bb85
bb85:
  %t297 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t298 = extractvalue { i64, ptr } %t297, 0
  %t299 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t300 = extractvalue { i64, ptr } %t299, 0
  store i64 %t300, ptr %l122, !tbaa !24
  %t302 = load i64, ptr %l122, !tbaa !24
  %t303 = icmp eq i64 %t298, %t302
  br i1 %t303, label %bb86, label %bb87
bb86:
  %t305 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t306 = load ptr, ptr %t305, !tbaa !27
  %t307 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !27
  %t309 = load i64, ptr %l122, !tbaa !24
  %t310 = mul i64 %t309, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t306, ptr %t308, i64 %t310, i1 false)
  br label %bb88
bb87:
  %t311 = load { i64, ptr }, ptr %l110, !tbaa !27
  store { i64, ptr } %t311, ptr %l3, !tbaa !27
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s9)
  br label %bb89
bb89:
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t313 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t316 = call { i64, ptr } @compiler_2flisting_2ecompiler_2flisting_3aNamer_2etypesNamed(ptr %v0, ptr %s0, ptr %v2, ptr %t312, { i64, ptr } %t313)
  store { i64, ptr } %t316, ptr %l126
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s0)
  %t317 = load { i64, ptr }, ptr %l126, !tbaa !27
  store { i64, ptr } %t317, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2flisting_2ecompiler_2flisting_3aNamer_2etypesNamed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"std/prelude/text:StringBuilder"
  %l20 = alloca { i64, ptr }
  %l29 = alloca i1
  %l30 = alloca { i64, ptr }
  %l34 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l56 = alloca ptr
  %l57 = alloca { i64, ptr }
  %l61 = alloca i1
  %l62 = alloca { i64, ptr }
  %l68 = alloca ptr
  %l69 = alloca { i64, ptr }
  %l70 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i64
  %l80 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l11
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t3, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load i64, ptr %l5, !tbaa !24
  %t10 = load i64, ptr %l6, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb36
bb4:
  br label %bb5
bb5:
  %t17 = load i64, ptr %l5, !tbaa !24
  store i64 %t17, ptr %l7, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t19, ptr %l20, !tbaa !27
  %t20 = load i64, ptr %l5, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i8, ptr %t23, i64 %t20
  %t25 = load i8, ptr %t24, !tbaa !32
  %t29 = icmp ne i8 %t25, 58
  br i1 %t29, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb35
bb7:
  br label %bb8
bb8:
  %t31 = load i64, ptr %l7, !tbaa !24
  store i64 %t31, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  %t33 = load i64, ptr %l9, !tbaa !24
  %t34 = load i64, ptr %l3, !tbaa !24
  %t37 = icmp sgt i64 %t33, %t34
  br i1 %t37, label %bb10, label %bb11
bb10:
  %t39 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t39, ptr %l30, !tbaa !27
  %t40 = load i64, ptr %l9, !tbaa !24
  %t42 = sub i64 %t40, 1
  %t44 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr i8, ptr %t45, i64 %t42
  %t47 = load i8, ptr %t46, !tbaa !32
  %t49 = call i1 @compiler_2flisting_2etypeDelim(i8 %t47)
  store i1 %t49, ptr %l34
  br label %bb12
bb11:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb13
bb12:
  %t50 = load i1, ptr %l34, !tbaa !21
  %t51 = xor i1 %t50, true
  store i1 %t51, ptr %l29, !tbaa !21
  br label %bb13
bb13:
  %t53 = load i1, ptr %l29, !tbaa !21
  %t54 = xor i1 %t53, true
  br i1 %t54, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t56 = load i64, ptr %l9, !tbaa !24
  %t58 = sub i64 %t56, 1
  store i64 %t58, ptr %l9, !tbaa !24
  br label %bb17
bb17:
  br label %bb9
bb18:
  store ptr %l2, ptr %l39, !tbaa !29
  %t60 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t60, ptr %l40, !tbaa !27
  %t61 = load i64, ptr %l3, !tbaa !24
  store i64 %t61, ptr %l41, !tbaa !24
  %t62 = load i64, ptr %l9, !tbaa !24
  store i64 %t62, ptr %l42, !tbaa !24
  %t63 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 0
  store i64 %t64, ptr %l43, !tbaa !24
  %t65 = load i64, ptr %l41, !tbaa !24
  %t66 = icmp sge i64 %t65, 0
  br i1 %t66, label %bb19, label %bb20
bb19:
  %t68 = load i64, ptr %l41, !tbaa !24
  %t69 = load i64, ptr %l42, !tbaa !24
  %t70 = icmp sle i64 %t68, %t69
  br i1 %t70, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_49807d4f96be5ab6_2af2c5a6dfc4a7ea)
  unreachable
bb21:
  %t72 = load i64, ptr %l42, !tbaa !24
  %t73 = load i64, ptr %l43, !tbaa !24
  %t74 = icmp sle i64 %t72, %t73
  br i1 %t74, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_49807d4f96be5ab6_2af2c5a6dfc4a7ea)
  unreachable
bb23:
  %t76 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = load i64, ptr %l41, !tbaa !24
  %t79 = load i64, ptr %l42, !tbaa !24
  %t80 = getelementptr i8, ptr %t77, i64 %t78
  %t81 = sub i64 %t79, %t78
  %t82 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t80, 1
  %t84 = load ptr, ptr %l39, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v1, ptr %t84, { i64, ptr } %t83)
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_49807d4f96be5ab6_2af2c5a6dfc4a7ea)
  unreachable
bb25:
  %t86 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t86, ptr %l48, !tbaa !27
  %t87 = load i64, ptr %l9, !tbaa !24
  store i64 %t87, ptr %l49, !tbaa !24
  %t88 = load i64, ptr %l7, !tbaa !24
  store i64 %t88, ptr %l50, !tbaa !24
  %t89 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t89, 0
  store i64 %t90, ptr %l51, !tbaa !24
  %t91 = load i64, ptr %l49, !tbaa !24
  %t92 = icmp sge i64 %t91, 0
  br i1 %t92, label %bb26, label %bb27
bb26:
  %t94 = load i64, ptr %l49, !tbaa !24
  %t95 = load i64, ptr %l50, !tbaa !24
  %t96 = icmp sle i64 %t94, %t95
  br i1 %t96, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_4991736aef41bf13_e517855ef6f4ebc7)
  unreachable
bb28:
  %t98 = load i64, ptr %l50, !tbaa !24
  %t99 = load i64, ptr %l51, !tbaa !24
  %t100 = icmp sle i64 %t98, %t99
  br i1 %t100, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_4991736aef41bf13_e517855ef6f4ebc7)
  unreachable
bb30:
  %t102 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = load i64, ptr %l49, !tbaa !24
  %t105 = load i64, ptr %l50, !tbaa !24
  %t106 = getelementptr i8, ptr %t103, i64 %t104
  %t107 = sub i64 %t105, %t104
  %t108 = insertvalue { i64, ptr } undef, i64 %t107, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t106, 1
  store { i64, ptr } %t109, ptr %l10, !tbaa !27
  store ptr %l2, ptr %l56, !tbaa !29
  %t111 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t111, ptr %l57, !tbaa !27
  %t112 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t115 = getelementptr %"compiler/listing:Namer", ptr %a0, i32 0, i32 0
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  %t119 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %v0, { i64, ptr } %t112, { i64, ptr } %t116)
  store i1 %t119, ptr %l61
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_4991736aef41bf13_e517855ef6f4ebc7)
  unreachable
bb32:
  %t120 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t121 = load i1, ptr %l61, !tbaa !21
  %t122 = call { i64, ptr } @compiler_2fload_2eErrQualifier(ptr %v1, ptr %s2, { i64, ptr } %t120, i1 %t121)
  store { i64, ptr } %t122, ptr %l62
  br label %bb33
bb33:
  %t123 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  %t125 = extractvalue { i64, ptr } %t123, 1
  %t126 = mul i64 %t124, 1
  %t127 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t126)
  call void @llvm.memcpy.p0.p0.i64(ptr %t127, ptr %t125, i64 %t126, i1 false)
  %t128 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  %t130 = load ptr, ptr %l56, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t130, { i64, ptr } %t129)
  br label %bb34
bb34:
  %t132 = load i64, ptr %l7, !tbaa !24
  %t134 = add i64 %t132, 1
  store i64 %t134, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb35
bb35:
  %t136 = load i64, ptr %l5, !tbaa !24
  %t138 = add i64 %t136, 1
  store i64 %t138, ptr %l5, !tbaa !24
  br label %bb2
bb36:
  store ptr %l2, ptr %l68, !tbaa !29
  %t140 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t140, ptr %l69, !tbaa !27
  %t141 = load i64, ptr %l3, !tbaa !24
  store i64 %t141, ptr %l70, !tbaa !24
  %t142 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t142, 0
  store i64 %t145, ptr %l73, !tbaa !24
  %t146 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t146, 0
  store i64 %t147, ptr %l74, !tbaa !24
  %t148 = load i64, ptr %l70, !tbaa !24
  %t149 = icmp sge i64 %t148, 0
  br i1 %t149, label %bb37, label %bb38
bb37:
  %t151 = load i64, ptr %l70, !tbaa !24
  %t152 = load i64, ptr %l73, !tbaa !24
  %t153 = icmp sle i64 %t151, %t152
  br i1 %t153, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_3adca15b088d1ab8_ad89d21976d6c71c)
  unreachable
bb39:
  %t155 = load i64, ptr %l73, !tbaa !24
  %t156 = load i64, ptr %l74, !tbaa !24
  %t157 = icmp sle i64 %t155, %t156
  br i1 %t157, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_3adca15b088d1ab8_ad89d21976d6c71c)
  unreachable
bb41:
  %t159 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = load i64, ptr %l70, !tbaa !24
  %t162 = load i64, ptr %l73, !tbaa !24
  %t163 = getelementptr i8, ptr %t160, i64 %t161
  %t164 = sub i64 %t162, %t161
  %t165 = insertvalue { i64, ptr } undef, i64 %t164, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t163, 1
  %t167 = load ptr, ptr %l68, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v1, ptr %t167, { i64, ptr } %t166)
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_3adca15b088d1ab8_ad89d21976d6c71c)
  unreachable
bb43:
  %t170 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t170, ptr %l80
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s0)
  %t171 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t171, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2flisting_2ecompiler_2flisting_3aSources_2eShown(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l4 = alloca i1
  %l6 = alloca i1
  %l12 = alloca i1
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l18 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/listing:Sources", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t4, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store i1 %t6, ptr %l4
  br label %bb1
bb1:
  %t7 = load i1, ptr %l4, !tbaa !21
  %t8 = xor i1 %t7, true
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/listing:Sources", ptr %t11, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 1
  %t17 = extractvalue { i64, ptr } %t14, 0
  %t18 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t20 = add i64 %t17, %t19
  %t21 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t20)
  call void @olang_textcopy(ptr %t21, ptr %t16, i64 %t17)
  %t22 = getelementptr i8, ptr %t21, i64 %t17
  call void @olang_textcopy(ptr %t22, ptr %t18, i64 %t19)
  %t23 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t21, 1
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t27 = extractvalue { i64, ptr } %t24, 1
  %t28 = mul i64 %t26, 1
  %t29 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t28)
  call void @llvm.memcpy.p0.p0.i64(ptr %t29, ptr %t27, i64 %t28, i1 false)
  %t30 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  %t34 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t10, { i64, ptr } %t31)
  store i1 %t34, ptr %l12
  br label %bb4
bb3:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb5
bb4:
  %t35 = load i1, ptr %l12, !tbaa !21
  store i1 %t35, ptr %l6, !tbaa !21
  br label %bb5
bb5:
  %t36 = load i1, ptr %l6, !tbaa !21
  br i1 %t36, label %bb6, label %bb7
bb6:
  %t37 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t37, ptr %l14, !tbaa !27
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/listing:Sources", ptr %t38, i32 0, i32 1
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t45 = add i64 %t43, 1
  store i64 %t45, ptr %l18, !tbaa !24
  %t46 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t46, 0
  store i64 %t49, ptr %l21, !tbaa !24
  %t50 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t50, 0
  store i64 %t51, ptr %l22, !tbaa !24
  %t52 = load i64, ptr %l18, !tbaa !24
  %t53 = icmp sge i64 %t52, 0
  br i1 %t53, label %bb8, label %bb9
bb7:
  %t55 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 1
  %t58 = extractvalue { i64, ptr } %t55, 0
  %t59 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t58)
  call void @olang_textcopy(ptr %t59, ptr %t57, i64 %t58)
  %t60 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l13, !tbaa !27
  br label %bb14
bb8:
  %t63 = load i64, ptr %l18, !tbaa !24
  %t64 = load i64, ptr %l21, !tbaa !24
  %t65 = icmp sle i64 %t63, %t64
  br i1 %t65, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_1b7d32817576de5e_73fc7def7ca382d2)
  unreachable
bb10:
  %t67 = load i64, ptr %l21, !tbaa !24
  %t68 = load i64, ptr %l22, !tbaa !24
  %t69 = icmp sle i64 %t67, %t68
  br i1 %t69, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_1b7d32817576de5e_73fc7def7ca382d2)
  unreachable
bb12:
  %t71 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = load i64, ptr %l18, !tbaa !24
  %t74 = load i64, ptr %l21, !tbaa !24
  %t75 = getelementptr i8, ptr %t72, i64 %t73
  %t76 = sub i64 %t74, %t73
  %t77 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t75, 1
  %t79 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t82 = extractvalue { i64, ptr } %t78, 1
  %t83 = extractvalue { i64, ptr } %t78, 0
  %t84 = add i64 %t80, %t83
  %t85 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t84)
  call void @olang_textcopy(ptr %t85, ptr %t79, i64 %t80)
  %t86 = getelementptr i8, ptr %t85, i64 %t80
  call void @olang_textcopy(ptr %t86, ptr %t82, i64 %t83)
  %t87 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t85, 1
  store { i64, ptr } %t88, ptr %l13, !tbaa !27
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_1b7d32817576de5e_73fc7def7ca382d2)
  unreachable
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t90 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t90, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2flisting_2ecompiler_2flisting_3aSources_2eText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %lp3 = alloca ptr
  %l5 = alloca %"std/prelude/text:LineIter"
  %l7 = alloca { i64, ptr }
  %l11 = alloca i1
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i32
  %l19 = alloca i1
  %l21 = alloca %"std/prelude/text:LineIter"
  %l22 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i32
  %l27 = alloca i1
  %l33 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca i32
  %l50 = alloca i1
  %l55 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l64 = alloca i64
  %l65 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/listing:Sources", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H7e371d56fd28e687545500cc2dc4b78e(ptr %v0, ptr %v1, ptr %t3, { i64, ptr } %t4)
  store i1 %t7, ptr %l11
  br label %bb1
bb1:
  %t8 = load i1, ptr %l11, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l13
  br label %bb4
bb3:
  br label %bb20
bb4:
  %t12 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store ptr %t12, ptr %lp3
  %t13 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  %t14 = load ptr, ptr %lp3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %t14
  %t15 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t17 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v1, ptr %s1, { i64, ptr } %t15)
  %t18 = extractvalue { i32, { i64, ptr } } %t17, 1
  %t19 = extractvalue { i32, { i64, ptr } } %t17, 0
  store i32 %t19, ptr %l17
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb6, label %ok.21, !prof !99
ok.21:
  store { i64, ptr } %t18, ptr %l16
  br label %bb5
bb5:
  %t22 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t22, ptr %l14, !tbaa !27
  br label %bb8
bb6:
  %t23 = load i32, ptr %l17, !tbaa !23
  %t24 = ashr i32 %t23, 16
  %t26 = icmp eq i32 %t24, 1
  store i1 %t26, ptr %l19, !tbaa !21
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l14, !tbaa !27
  br label %bb8
bb8:
  %t27 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t30 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %s1, ptr %s1, { i64, ptr } %t27)
  store %"std/prelude/text:LineIter" %t30, ptr %l21
  br label %bb9
bb9:
  %t31 = load %"std/prelude/text:LineIter", ptr %l21
  store %"std/prelude/text:LineIter" %t31, ptr %l5
  br label %bb10
bb10:
  %t33 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %s1, ptr %s1, ptr %l5)
  %t34 = extractvalue { i32, { i64, ptr } } %t33, 1
  %t35 = extractvalue { i32, { i64, ptr } } %t33, 0
  store i32 %t35, ptr %l25
  %t36 = icmp ne i32 %t35, 0
  br i1 %t36, label %bb12, label %ok.37, !prof !99
ok.37:
  store { i64, ptr } %t34, ptr %l24
  br label %bb11
bb11:
  %t38 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t38, ptr %l22, !tbaa !27
  br label %bb14
bb12:
  %t39 = load i32, ptr %l25, !tbaa !23
  %t40 = ashr i32 %t39, 16
  %t42 = icmp eq i32 %t40, 1
  store i1 %t42, ptr %l27, !tbaa !21
  br label %bb13
bb13:
  call void @__olang_ert_req_clear()
  br label %bb17
bb14:
  %t43 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t44 = load ptr, ptr %lp3
  %t47 = extractvalue { i64, ptr } %t43, 1
  %t48 = extractvalue { i64, ptr } %t43, 0
  %t49 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t48)
  call void @olang_textcopy(ptr %t49, ptr %t47, i64 %t48)
  %t50 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  %t53 = extractvalue { i64, ptr } %t51, 0
  %t54 = extractvalue { i64, ptr } %t51, 1
  %t55 = mul i64 %t53, 1
  %t56 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t55)
  call void @llvm.memcpy.p0.p0.i64(ptr %t56, ptr %t54, i64 %t55, i1 false)
  %t57 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t44, { i64, ptr } %t58)
  br label %bb15
bb15:
  br label %bb16
bb16:
  br label %bb10
bb17:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/listing:Sources", ptr %t61, i32 0, i32 0
  store ptr %t63, ptr %l33, !tbaa !29
  %t64 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t64, 1
  %t67 = extractvalue { i64, ptr } %t64, 0
  %t68 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t67)
  call void @olang_textcopy(ptr %t68, ptr %t66, i64 %t67)
  %t69 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t68, 1
  %t72 = extractvalue { i64, ptr } %t70, 0
  %t73 = extractvalue { i64, ptr } %t70, 1
  %t74 = mul i64 %t72, 1
  %t75 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t74)
  call void @llvm.memcpy.p0.p0.i64(ptr %t75, ptr %t73, i64 %t74, i1 false)
  %t76 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  store { i64, ptr } %t77, ptr %l36, !tbaa !27
  %t78 = load ptr, ptr %lp3
  %t80 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v0, ptr %t78)
  store { i64, ptr } %t80, ptr %l38
  br label %bb18
bb18:
  %t81 = load ptr, ptr %l33, !tbaa !29
  %t82 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t83 = load { i64, ptr }, ptr %l38, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_He566606ea489086acfe37a2d8fe143fc(ptr %v0, ptr %v0, ptr %v0, ptr %t81, { i64, ptr } %t82, { i64, ptr } %t83)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s1)
  br label %bb20
bb20:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/listing:Sources", ptr %t84, i32 0, i32 0
  %t87 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t90 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H1a06a15e944bd533c307ed632a66227d(ptr %v0, ptr %v1, ptr %v0, ptr %t86, { i64, ptr } %t87)
  %t91 = extractvalue { i32, { i64, ptr } } %t90, 1
  %t92 = extractvalue { i32, { i64, ptr } } %t90, 0
  store i32 %t92, ptr %l44
  %t93 = icmp ne i32 %t92, 0
  br i1 %t93, label %bb22, label %ok.94, !prof !99
ok.94:
  store { i64, ptr } %t91, ptr %l43
  br label %bb21
bb21:
  %t95 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t95, ptr %l39, !tbaa !27
  br label %bb28
bb22:
  br label %bb23
bb23:
  call void @__olang_ert_req_clear()
  %t96 = icmp sge i64 0, 0
  br i1 %t96, label %bb24, label %bb25
bb24:
  %t98 = icmp sle i64 0, 576460752303423487
  br i1 %t98, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_3ba8e4c8ab4044f8_de2322bbe0a12f8c)
  unreachable
bb26:
  %t100 = mul i64 0, 16
  %t101 = insertvalue { i64, ptr } undef, i64 0, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t102, ptr %l39, !tbaa !27
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_3ba8e4c8ab4044f8_de2322bbe0a12f8c)
  unreachable
bb28:
  %t104 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t104, ptr %l7, !tbaa !27
  %t105 = load i64, ptr %l2, !tbaa !24
  %t107 = icmp sge i64 %t105, 1
  br i1 %t107, label %bb29, label %bb30
bb29:
  %t109 = load i64, ptr %l2, !tbaa !24
  %t110 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t110, 0
  %t115 = icmp sle i64 %t109, %t112
  store i1 %t115, ptr %l50, !tbaa !21
  br label %bb31
bb30:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb31
bb31:
  %t117 = load i1, ptr %l50, !tbaa !21
  br i1 %t117, label %bb32, label %bb33
bb32:
  %t118 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t118, ptr %l56, !tbaa !27
  %t119 = load i64, ptr %l2, !tbaa !24
  %t121 = sub i64 %t119, 1
  %t123 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = getelementptr { i64, ptr }, ptr %t124, i64 %t121
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !37
  %t128 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v0, ptr %s0, { i64, ptr } %t126)
  store { i64, ptr } %t128, ptr %l60
  br label %bb34
bb33:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d39, i32 0, i32 1) }, ptr %l62, !tbaa !27
  %t129 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t129, ptr %l55, !tbaa !27
  br label %bb35
bb34:
  %t131 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t131, 1
  %t133 = extractvalue { i64, ptr } %t131, 0
  %t134 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t133)
  call void @olang_textcopy(ptr %t134, ptr %t132, i64 %t133)
  %t135 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t134, 1
  store { i64, ptr } %t136, ptr %l55, !tbaa !27
  br label %bb35
bb35:
  %t138 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t138, 0
  store i64 %t139, ptr %l64, !tbaa !24
  %t140 = load i64, ptr %l64, !tbaa !24
  %t141 = mul i64 %t140, 1
  %t142 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t141)
  %t143 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t142, 1
  store { i64, ptr } %t144, ptr %l65, !tbaa !27
  %t145 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = load i64, ptr %l64, !tbaa !24
  %t150 = mul i64 %t149, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t146, ptr %t148, i64 %t150, i1 false)
  %t151 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t151, ptr %l55, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t152 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t152, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2flisting_2ecompiler_2flisting_3aWriter_2easmLine(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l5 = alloca { i64, i64 }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i1
  %l16 = alloca i1
  %l18 = alloca i1
  %l20 = alloca { i64, i64 }
  %l23 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i32
  %l28 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca i32
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i1
  %l37 = alloca i1
  %l39 = alloca i1
  %l40 = alloca { i64, ptr }
  %l60 = alloca i1
  %l64 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca { i64, ptr }
  %l68 = alloca i1
  %l70 = alloca i1
  %l72 = alloca i1
  %l74 = alloca i1
  %l76 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v2, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d40, i32 0, i32 1) })
  store i1 %t3, ptr %l15
  br label %bb1
bb1:
  %t4 = load i1, ptr %l15, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb5
bb3:
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v2, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d41, i32 0, i32 1) })
  store i1 %t7, ptr %l18
  br label %bb4
bb4:
  %t8 = load i1, ptr %l18, !tbaa !21
  store i1 %t8, ptr %l16, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l16, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = call { i64, i64 } @compiler_2flisting_2elocOf(ptr %v2, { i64, ptr } %t10)
  store { i64, i64 } %t12, ptr %l20
  br label %bb8
bb7:
  br label %bb26
bb8:
  %t13 = load { i64, i64 }, ptr %l20
  store { i64, i64 } %t13, ptr %l5
  %t14 = getelementptr { i64, i64 }, ptr %l5, i32 0, i32 0
  %t15 = load i64, ptr %t14, !tbaa !24
  store i64 %t15, ptr %l6, !tbaa !24
  %t17 = getelementptr { i64, i64 }, ptr %l5, i32 0, i32 1
  %t18 = load i64, ptr %t17, !tbaa !24
  store i64 %t18, ptr %l7, !tbaa !24
  %t21 = load i64, ptr %l6, !tbaa !24
  %t24 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v3, ptr %v3, ptr %a3, i64 %t21)
  %t25 = extractvalue { i32, { i64, ptr } } %t24, 1
  %t26 = extractvalue { i32, { i64, ptr } } %t24, 0
  store i32 %t26, ptr %l27
  %t27 = icmp ne i32 %t26, 0
  br i1 %t27, label %bb10, label %ok.28, !prof !99
ok.28:
  store { i64, ptr } %t25, ptr %l26
  br label %bb9
bb9:
  %t29 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t29, ptr %l23, !tbaa !27
  br label %bb12
bb10:
  br label %bb11
bb11:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d42, i32 0, i32 1) }, ptr %l23, !tbaa !27
  br label %bb12
bb12:
  %t30 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t30, ptr %l8, !tbaa !27
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v4, ptr %v4, ptr %a4, i64 %t32)
  %t36 = extractvalue { i32, { i64, ptr } } %t35, 1
  %t37 = extractvalue { i32, { i64, ptr } } %t35, 0
  store i32 %t37, ptr %l32
  %t38 = icmp ne i32 %t37, 0
  br i1 %t38, label %bb14, label %ok.39, !prof !99
ok.39:
  store { i64, ptr } %t36, ptr %l31
  br label %bb13
bb13:
  %t40 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t40, ptr %l28, !tbaa !27
  br label %bb16
bb14:
  br label %bb15
bb15:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d43, i32 0, i32 1) }, ptr %l28, !tbaa !27
  br label %bb16
bb16:
  %t41 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t41, ptr %l9, !tbaa !27
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l33, !tbaa !29
  %t43 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t43, ptr %l34, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t46 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v3, ptr %s1, { i64, ptr } %t44, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) })
  store i1 %t46, ptr %l36
  br label %bb17
bb17:
  %t47 = load i1, ptr %l36, !tbaa !21
  br i1 %t47, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb21
bb19:
  %t48 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t50 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s1, { i64, ptr } %t48, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d45, i32 0, i32 1) })
  store i1 %t50, ptr %l39
  br label %bb20
bb20:
  %t51 = load i1, ptr %l39, !tbaa !21
  store i1 %t51, ptr %l37, !tbaa !21
  br label %bb21
bb21:
  %t52 = load i1, ptr %l37, !tbaa !21
  br i1 %t52, label %bb22, label %bb23
bb22:
  %t53 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t53, ptr %l40, !tbaa !27
  br label %bb24
bb23:
  %t55 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t55, 1
  %t59 = extractvalue { i64, ptr } %t55, 0
  %t60 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t61 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t62 = add i64 %t59, %t61
  %t64 = extractvalue { i64, ptr } %t56, 1
  %t65 = extractvalue { i64, ptr } %t56, 0
  %t66 = add i64 %t62, %t65
  %t67 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t66)
  call void @olang_textcopy(ptr %t67, ptr %t58, i64 %t59)
  %t68 = getelementptr i8, ptr %t67, i64 %t59
  call void @olang_textcopy(ptr %t68, ptr %t60, i64 %t61)
  %t69 = getelementptr i8, ptr %t68, i64 %t61
  call void @olang_textcopy(ptr %t69, ptr %t64, i64 %t65)
  %t70 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t67, 1
  %t73 = extractvalue { i64, ptr } %t71, 0
  %t74 = extractvalue { i64, ptr } %t71, 1
  %t75 = mul i64 %t73, 1
  %t76 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t75)
  call void @llvm.memcpy.p0.p0.i64(ptr %t76, ptr %t74, i64 %t75, i1 false)
  %t77 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t76, 1
  store { i64, ptr } %t78, ptr %l40, !tbaa !27
  br label %bb24
bb24:
  %t80 = load i64, ptr %l7, !tbaa !24
  %t81 = load ptr, ptr %l33, !tbaa !29
  %t82 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t83 = load { i64, ptr }, ptr %l40, !tbaa !27
  call void @compiler_2flisting_2ecompiler_2flisting_3aWriter_2ereach(ptr %v0, ptr %v3, ptr %v3, ptr %t81, { i64, ptr } %t82, { i64, ptr } %t83, i64 %t80)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb26:
  store %olang.scope zeroinitializer, ptr %s3
  %t85 = insertvalue [6 x { i64, ptr }] undef, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  %t86 = insertvalue [6 x { i64, ptr }] %t85, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t87 = insertvalue [6 x { i64, ptr }] %t86, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d49, i32 0, i32 1) }, 2
  %t88 = insertvalue [6 x { i64, ptr }] %t87, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d50, i32 0, i32 1) }, 3
  %t89 = insertvalue [6 x { i64, ptr }] %t88, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d51, i32 0, i32 1) }, 4
  %t90 = insertvalue [6 x { i64, ptr }] %t89, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d52, i32 0, i32 1) }, 5
  %t92 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 96, i64 8)
  store [6 x { i64, ptr }] %t90, ptr %t92
  store ptr %t92, ptr %l10
  store i64 0, ptr %l11, !tbaa !24
  %t94 = load ptr, ptr %l10
  store i64 6, ptr %l12, !tbaa !24
  br label %bb27
bb27:
  %t97 = load i64, ptr %l11, !tbaa !24
  %t98 = load i64, ptr %l12, !tbaa !24
  %t101 = icmp slt i64 %t97, %t98
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb28, label %bb29
bb28:
  br label %bb36
bb29:
  br label %bb30
bb30:
  %t105 = load ptr, ptr %l10
  %t106 = load i64, ptr %l11, !tbaa !24
  %t109 = getelementptr [6 x { i64, ptr }], ptr %t105, i64 0, i64 %t106
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !37
  %t112 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t114 = load ptr, ptr @__olang_prog_scope
  %t117 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v2, ptr %t114, { i64, ptr } %t112, { i64, ptr } %t110)
  store i1 %t117, ptr %l60
  br label %bb31
bb31:
  %t118 = load i1, ptr %l60, !tbaa !21
  br i1 %t118, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb33:
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t119 = load i64, ptr %l11, !tbaa !24
  %t121 = add i64 %t119, 1
  store i64 %t121, ptr %l11, !tbaa !24
  br label %bb27
bb36:
  call void @__olang_scope_close(ptr %s3)
  %t123 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t125 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t123, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d53, i32 0, i32 1) })
  store i1 %t125, ptr %l64
  br label %bb37
bb37:
  %t126 = load i1, ptr %l64, !tbaa !21
  br i1 %t126, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb39:
  br label %bb40
bb40:
  %t127 = load ptr, ptr %l0, !tbaa !29
  store ptr %t127, ptr %l65, !tbaa !29
  store { i64, ptr } %a1, ptr %l66, !tbaa !27
  %t129 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t131 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v2, ptr %s0, { i64, ptr } %t129, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d54, i32 0, i32 1) })
  store i1 %t131, ptr %l68
  br label %bb41
bb41:
  %t132 = load i1, ptr %l68, !tbaa !21
  %t133 = xor i1 %t132, true
  br i1 %t133, label %bb42, label %bb43
bb42:
  %t135 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t137 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v2, ptr %s0, { i64, ptr } %t135, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d55, i32 0, i32 1) })
  store i1 %t137, ptr %l72
  br label %bb44
bb43:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb45
bb44:
  %t138 = load i1, ptr %l72, !tbaa !21
  %t139 = xor i1 %t138, true
  store i1 %t139, ptr %l70, !tbaa !21
  br label %bb45
bb45:
  %t141 = load i1, ptr %l70, !tbaa !21
  br i1 %t141, label %bb46, label %bb47
bb46:
  %t142 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t144 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v2, ptr %s0, { i64, ptr } %t142, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d56, i32 0, i32 1) })
  store i1 %t144, ptr %l76
  br label %bb48
bb47:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb49
bb48:
  %t145 = load i1, ptr %l76, !tbaa !21
  %t146 = xor i1 %t145, true
  store i1 %t146, ptr %l74, !tbaa !21
  br label %bb49
bb49:
  %t148 = load ptr, ptr %l65, !tbaa !29
  %t149 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t150 = load i1, ptr %l74, !tbaa !21
  call void @compiler_2flisting_2ecompiler_2flisting_3aWriter_2ecode(ptr %v0, ptr %v1, ptr %t148, { i64, ptr } %t149, i1 %t150)
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flisting_2ecompiler_2flisting_3aWriter_2easmPart(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l4 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l5 = alloca i1
  %l6 = alloca %"std/prelude/text:LineIter"
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i1
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l12 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l14 = alloca %"std/prelude/text:LineIter"
  %l15 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l20 = alloca i1
  %l22 = alloca { i64, ptr }
  %l24 = alloca i1
  %l25 = alloca i1
  %l27 = alloca i1
  %l32 = alloca i1
  %l33 = alloca i1
  %l35 = alloca i1
  %l37 = alloca i1
  %l39 = alloca i1
  %l41 = alloca i1
  %l43 = alloca i1
  %l46 = alloca { i64, ptr }
  %l47 = alloca i1
  %l48 = alloca i1
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i32
  %l56 = alloca i64
  %l62 = alloca i1
  %l66 = alloca i1
  %l68 = alloca i1
  %l70 = alloca i1
  %l72 = alloca i1
  %l74 = alloca i1
  %l76 = alloca i1
  %l78 = alloca i1
  %l81 = alloca { i64, ptr }
  %l82 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l11
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l3
  %t3 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t3, ptr %l12
  br label %bb2
bb2:
  %t4 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l12
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t4, ptr %l4
  store i1 false, ptr %l5, !tbaa !21
  %t7 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v1, ptr %v1, { i64, ptr } %a1)
  store %"std/prelude/text:LineIter" %t7, ptr %l14
  br label %bb3
bb3:
  %t8 = load %"std/prelude/text:LineIter", ptr %l14
  store %"std/prelude/text:LineIter" %t8, ptr %l6
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v1, ptr %v1, ptr %l6)
  %t11 = extractvalue { i32, { i64, ptr } } %t10, 1
  %t12 = extractvalue { i32, { i64, ptr } } %t10, 0
  store i32 %t12, ptr %l18
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb6, label %ok.14, !prof !99
ok.14:
  store { i64, ptr } %t11, ptr %l17
  br label %bb5
bb5:
  %t15 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t15, ptr %l15, !tbaa !27
  br label %bb8
bb6:
  %t16 = load i32, ptr %l18, !tbaa !23
  %t17 = ashr i32 %t16, 16
  %t19 = icmp eq i32 %t17, 1
  store i1 %t19, ptr %l20, !tbaa !21
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb79
bb8:
  %t20 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t20, ptr %l7, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t23 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v1, ptr %v1, { i64, ptr } %t21)
  store { i64, ptr } %t23, ptr %l22
  br label %bb9
bb9:
  %t24 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t24, ptr %l8, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s2, { i64, ptr } %t25, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d57, i32 0, i32 1) })
  store i1 %t27, ptr %l24
  br label %bb10
bb10:
  %t28 = load i1, ptr %l24, !tbaa !21
  br i1 %t28, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb14
bb12:
  %t29 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t31 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s2, { i64, ptr } %t29, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d58, i32 0, i32 1) })
  store i1 %t31, ptr %l27
  br label %bb13
bb13:
  %t32 = load i1, ptr %l27, !tbaa !21
  store i1 %t32, ptr %l25, !tbaa !21
  br label %bb14
bb14:
  %t33 = load i1, ptr %l25, !tbaa !21
  br i1 %t33, label %bb15, label %bb16
bb15:
  %t34 = load { i64, ptr }, ptr %l8, !tbaa !27
  call void @compiler_2flisting_2efileLine(ptr %v1, ptr %s0, ptr %s0, { i64, ptr } %t34, ptr %l3, ptr %l4)
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb78
bb18:
  %t38 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t40 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s2, { i64, ptr } %t38, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) })
  store i1 %t40, ptr %l32
  br label %bb19
bb19:
  %t41 = load i1, ptr %l32, !tbaa !21
  br i1 %t41, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb23
bb21:
  %t42 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t44 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s2, { i64, ptr } %t42, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d60, i32 0, i32 1) })
  store i1 %t44, ptr %l35
  br label %bb22
bb22:
  %t45 = load i1, ptr %l35, !tbaa !21
  store i1 %t45, ptr %l33, !tbaa !21
  br label %bb23
bb23:
  %t46 = load i1, ptr %l33, !tbaa !21
  store i1 %t46, ptr %l9, !tbaa !21
  %t47 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t49 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s2, { i64, ptr } %t47, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) })
  store i1 %t49, ptr %l37
  br label %bb24
bb24:
  %t50 = load i1, ptr %l37, !tbaa !21
  %t51 = xor i1 %t50, true
  br i1 %t51, label %bb25, label %bb26
bb25:
  %t53 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t55 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s2, { i64, ptr } %t53, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) })
  store i1 %t55, ptr %l41
  br label %bb27
bb26:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb28
bb27:
  %t56 = load i1, ptr %l41, !tbaa !21
  %t57 = xor i1 %t56, true
  store i1 %t57, ptr %l39, !tbaa !21
  br label %bb28
bb28:
  %t59 = load i1, ptr %l39, !tbaa !21
  br i1 %t59, label %bb29, label %bb30
bb29:
  %t60 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d63, i32 0, i32 1) }, ptr %l46, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t64 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s2, { i64, ptr } %t60, { i64, ptr } %t63)
  store i1 %t64, ptr %l47
  br label %bb31
bb30:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb32
bb31:
  %t65 = load i1, ptr %l47, !tbaa !21
  store i1 %t65, ptr %l43, !tbaa !21
  br label %bb32
bb32:
  %t66 = load i1, ptr %l43, !tbaa !21
  br i1 %t66, label %bb33, label %bb34
bb33:
  %t67 = load i1, ptr %l9, !tbaa !21
  %t69 = xor i1 %t67, true
  store i1 %t69, ptr %l48, !tbaa !21
  br label %bb35
bb34:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb35
bb35:
  %t71 = load i1, ptr %l48, !tbaa !21
  br i1 %t71, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s4
  %t72 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t72, ptr %l51, !tbaa !27
  %t73 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t75 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s4, { i64, ptr } %t73, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) })
  %t76 = extractvalue { i32, i64 } %t75, 1
  %t77 = extractvalue { i32, i64 } %t75, 0
  store i32 %t77, ptr %l55
  %t78 = icmp ne i32 %t77, 0
  br i1 %t78, label %bb39, label %ok.79, !prof !99
ok.79:
  store i64 %t76, ptr %l54
  br label %bb38
bb37:
  br label %bb73
bb38:
  %t80 = load i64, ptr %l54, !tbaa !24
  store i64 %t80, ptr %l52, !tbaa !24
  br label %bb41
bb39:
  br label %bb40
bb40:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l52, !tbaa !24
  br label %bb41
bb41:
  %t81 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t81, 0
  store i64 %t82, ptr %l56, !tbaa !24
  %t83 = icmp sge i64 0, 0
  br i1 %t83, label %bb42, label %bb43
bb42:
  %t85 = load i64, ptr %l52, !tbaa !24
  %t86 = icmp sle i64 0, %t85
  br i1 %t86, label %bb44, label %bb45
bb43:
  call void @__olang_check_failed(ptr @olang_loc_499282f3f30fac94_8f31adef023c0138)
  unreachable
bb44:
  %t88 = load i64, ptr %l52, !tbaa !24
  %t89 = load i64, ptr %l56, !tbaa !24
  %t90 = icmp sle i64 %t88, %t89
  br i1 %t90, label %bb46, label %bb47
bb45:
  call void @__olang_check_failed(ptr @olang_loc_499282f3f30fac94_8f31adef023c0138)
  unreachable
bb46:
  %t92 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = load i64, ptr %l52, !tbaa !24
  %t95 = getelementptr i8, ptr %t93, i64 0
  %t96 = sub i64 %t94, 0
  %t97 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t95, 1
  store { i64, ptr } %t98, ptr %l10, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t102 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s4, { i64, ptr } %t100, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d65, i32 0, i32 1) })
  store i1 %t102, ptr %l62
  br label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_499282f3f30fac94_8f31adef023c0138)
  unreachable
bb48:
  %t103 = load i1, ptr %l62, !tbaa !21
  %t104 = xor i1 %t103, true
  br i1 %t104, label %bb49, label %bb50
bb49:
  %t106 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t110 = call i1 @compiler_2flisting_2eofSym(ptr %v1, ptr %v2, { i64, ptr } %t106, { i64, ptr } %a2)
  store i1 %t110, ptr %l66
  br label %bb51
bb50:
  br label %bb52
bb51:
  %t111 = load i1, ptr %l66, !tbaa !21
  store i1 %t111, ptr %l5, !tbaa !21
  br label %bb52
bb52:
  %t112 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t114 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s4, { i64, ptr } %t112, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d66, i32 0, i32 1) })
  store i1 %t114, ptr %l68
  br label %bb53
bb53:
  %t115 = load i1, ptr %l68, !tbaa !21
  br i1 %t115, label %bb54, label %bb55
bb54:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb56
bb55:
  br label %bb56
bb56:
  %t116 = load i1, ptr %l5, !tbaa !21
  br i1 %t116, label %bb57, label %bb58
bb57:
  %t118 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t120 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s4, { i64, ptr } %t118, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d67, i32 0, i32 1) })
  store i1 %t120, ptr %l72
  br label %bb59
bb58:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb60
bb59:
  %t121 = load i1, ptr %l72, !tbaa !21
  %t122 = xor i1 %t121, true
  store i1 %t122, ptr %l70, !tbaa !21
  br label %bb60
bb60:
  %t124 = load i1, ptr %l70, !tbaa !21
  br i1 %t124, label %bb61, label %bb62
bb61:
  %t125 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t127 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s4, { i64, ptr } %t125, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d68, i32 0, i32 1) })
  store i1 %t127, ptr %l76
  br label %bb63
bb62:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb64
bb63:
  %t128 = load i1, ptr %l76, !tbaa !21
  %t129 = xor i1 %t128, true
  store i1 %t129, ptr %l74, !tbaa !21
  br label %bb64
bb64:
  %t131 = load i1, ptr %l74, !tbaa !21
  br i1 %t131, label %bb65, label %bb66
bb65:
  %t132 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d69, i32 0, i32 1) }, ptr %l81, !tbaa !27
  %t135 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t136 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s4, { i64, ptr } %t132, { i64, ptr } %t135)
  store i1 %t136, ptr %l82
  br label %bb67
bb66:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb68
bb67:
  %t137 = load i1, ptr %l82, !tbaa !21
  %t138 = xor i1 %t137, true
  store i1 %t138, ptr %l78, !tbaa !21
  br label %bb68
bb68:
  %t140 = load i1, ptr %l78, !tbaa !21
  br i1 %t140, label %bb69, label %bb70
bb69:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @compiler_2flisting_2ecompiler_2flisting_3aWriter_2ecode(ptr %v0, ptr %v1, ptr %t141, { i64, ptr } %t142, i1 false)
  br label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  br label %bb78
bb73:
  %t145 = load i1, ptr %l5, !tbaa !21
  br i1 %t145, label %bb74, label %bb75
bb74:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t149 = load { i64, ptr }, ptr %l8, !tbaa !27
  call void @compiler_2flisting_2ecompiler_2flisting_3aWriter_2easmLine(ptr %v0, ptr %v1, ptr %v1, ptr %s0, ptr %s0, ptr %t147, { i64, ptr } %t148, { i64, ptr } %t149, ptr %l3, ptr %l4)
  br label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s2)
  br label %bb78
bb78:
  br label %bb4
bb79:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flisting_2ecompiler_2flisting_3aWriter_2ecode(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i1
  %l4 = alloca i1
  %l8 = alloca i1
  %l14 = alloca i1
  %l19 = alloca i1
  %l23 = alloca ptr
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i1, ptr %l2, !tbaa !21
  br i1 %t1, label %bb1, label %bb2
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/listing:Writer", ptr %t3, i32 0, i32 9
  %t6 = load i64, ptr %t5, !tbaa !24
  %t8 = icmp sge i64 %t6, 0
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t10 = load i1, ptr %l4, !tbaa !21
  br i1 %t10, label %bb4, label %bb5
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/listing:Writer", ptr %t11, i32 0, i32 9
  %t14 = load i64, ptr %t13, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/listing:Writer", ptr %t15, i32 0, i32 6
  %t18 = load i64, ptr %t17, !tbaa !24
  %t21 = icmp ne i64 %t14, %t18
  br i1 %t21, label %bb6, label %bb7
bb5:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb10
bb6:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb9
bb7:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/listing:Writer", ptr %t23, i32 0, i32 7
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/listing:Writer", ptr %t27, i32 0, i32 5
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  %t33 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v0, { i64, ptr } %t26, { i64, ptr } %t30)
  store i1 %t33, ptr %l19
  br label %bb8
bb8:
  %t34 = load i1, ptr %l19, !tbaa !21
  %t35 = xor i1 %t34, true
  store i1 %t35, ptr %l14, !tbaa !21
  br label %bb9
bb9:
  %t37 = load i1, ptr %l14, !tbaa !21
  store i1 %t37, ptr %l8, !tbaa !21
  br label %bb10
bb10:
  %t38 = load i1, ptr %l8, !tbaa !21
  br i1 %t38, label %bb11, label %bb12
bb11:
  %t39 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flisting_2ecompiler_2flisting_3aWriter_2eplace(ptr %v0, ptr %t39)
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  %t41 = load i1, ptr %l2, !tbaa !21
  br i1 %t41, label %bb15, label %bb16
bb15:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l23, !tbaa !29
  %t44 = load ptr, ptr %l23, !tbaa !29
  %t45 = getelementptr %"compiler/listing:Writer", ptr %t44, i32 0, i32 11
  %t46 = load i64, ptr %t45, !tbaa !24
  %t48 = add i64 %t46, 1
  %t50 = load ptr, ptr %l23, !tbaa !29
  %t51 = getelementptr %"compiler/listing:Writer", ptr %t50, i32 0, i32 11
  store i64 %t48, ptr %t51, !tbaa !24
  br label %bb17
bb16:
  br label %bb17
bb17:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/listing:Writer", ptr %t52, i32 0, i32 10
  %t57 = extractvalue { i64, ptr } %a1, 1
  %t58 = extractvalue { i64, ptr } %a1, 0
  %t59 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t61 = add i64 %t58, %t60
  %t62 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t61)
  call void @olang_textcopy(ptr %t62, ptr %t57, i64 %t58)
  %t63 = getelementptr i8, ptr %t62, i64 %t58
  call void @olang_textcopy(ptr %t63, ptr %t59, i64 %t60)
  %t64 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t62, 1
  %t67 = extractvalue { i64, ptr } %t65, 0
  %t68 = extractvalue { i64, ptr } %t65, 1
  %t69 = mul i64 %t67, 1
  %t70 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t69)
  call void @llvm.memcpy.p0.p0.i64(ptr %t70, ptr %t68, i64 %t69, i1 false)
  %t71 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t54, { i64, ptr } %t72)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flisting_2ecompiler_2flisting_3aWriter_2eirLine(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l22 = alloca i1
  %l23 = alloca { i64, ptr }
  %l26 = alloca i1
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca i32
  %l42 = alloca i64
  %l43 = alloca i32
  %l46 = alloca i1
  %l47 = alloca { i64, ptr }
  %l52 = alloca i64
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i64
  %l63 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l65 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i64
  %l74 = alloca { i64, ptr }
  %l76 = alloca i64
  %l79 = alloca i1
  %l83 = alloca ptr
  %l84 = alloca { i64, ptr }
  %l86 = alloca i1
  %l87 = alloca i1
  %l89 = alloca { i64, ptr }
  %l90 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d71, i32 0, i32 1) })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l11
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i64 %t4, ptr %l10
  br label %bb1
bb1:
  %t8 = load i64, ptr %l10, !tbaa !24
  store i64 %t8, ptr %l8, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l8, !tbaa !24
  br label %bb4
bb4:
  %t9 = load i64, ptr %l8, !tbaa !24
  store i64 %t9, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 1
  %t13 = extractvalue { i64, ptr } %t10, 0
  %t14 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t13)
  call void @olang_textcopy(ptr %t14, ptr %t12, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l4, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = icmp sge i64 %t18, 0
  br i1 %t20, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t22 = load i64, ptr %l3, !tbaa !24
  %t24 = add i64 %t22, 6
  store i64 %t24, ptr %l5, !tbaa !24
  br label %bb7
bb6:
  br label %bb55
bb7:
  %t26 = load i64, ptr %l5, !tbaa !24
  %t27 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t32 = icmp slt i64 %t26, %t29
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t34, ptr %l23, !tbaa !27
  %t35 = load i64, ptr %l5, !tbaa !24
  %t37 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr i8, ptr %t38, i64 %t35
  %t40 = load i8, ptr %t39, !tbaa !32
  %t42 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t40)
  store i1 %t42, ptr %l26
  br label %bb10
bb9:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb11
bb10:
  %t43 = load i1, ptr %l26, !tbaa !21
  store i1 %t43, ptr %l22, !tbaa !21
  br label %bb11
bb11:
  %t44 = load i1, ptr %l22, !tbaa !21
  %t45 = xor i1 %t44, true
  br i1 %t45, label %bb12, label %bb13
bb12:
  br label %bb16
bb13:
  br label %bb14
bb14:
  %t47 = load i64, ptr %l5, !tbaa !24
  %t49 = add i64 %t47, 1
  store i64 %t49, ptr %l5, !tbaa !24
  br label %bb15
bb15:
  br label %bb7
bb16:
  %t51 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t51, ptr %l31, !tbaa !27
  %t52 = load i64, ptr %l3, !tbaa !24
  %t54 = add i64 %t52, 6
  store i64 %t54, ptr %l33, !tbaa !24
  %t55 = load i64, ptr %l5, !tbaa !24
  store i64 %t55, ptr %l34, !tbaa !24
  %t56 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t56, 0
  store i64 %t57, ptr %l35, !tbaa !24
  %t58 = load i64, ptr %l33, !tbaa !24
  %t59 = icmp sge i64 %t58, 0
  br i1 %t59, label %bb17, label %bb18
bb17:
  %t61 = load i64, ptr %l33, !tbaa !24
  %t62 = load i64, ptr %l34, !tbaa !24
  %t63 = icmp sle i64 %t61, %t62
  br i1 %t63, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_6783e9980d688233_30d5d90792fe0dc7)
  unreachable
bb19:
  %t65 = load i64, ptr %l34, !tbaa !24
  %t66 = load i64, ptr %l35, !tbaa !24
  %t67 = icmp sle i64 %t65, %t66
  br i1 %t67, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_6783e9980d688233_30d5d90792fe0dc7)
  unreachable
bb21:
  %t69 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = load i64, ptr %l33, !tbaa !24
  %t72 = load i64, ptr %l34, !tbaa !24
  %t73 = getelementptr i8, ptr %t70, i64 %t71
  %t74 = sub i64 %t72, %t71
  %t75 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t73, 1
  store { i64, ptr } %t76, ptr %l39, !tbaa !27
  %t77 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s2, i64 10)
  %t78 = extractvalue { i32, i64 } %t77, 1
  %t79 = extractvalue { i32, i64 } %t77, 0
  store i32 %t79, ptr %l41
  %t80 = icmp ne i32 %t79, 0
  br i1 %t80, label %bb24, label %ok.81, !prof !99
ok.81:
  store i64 %t78, ptr %l40
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_6783e9980d688233_30d5d90792fe0dc7)
  unreachable
bb23:
  %t82 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t83 = load i64, ptr %l40, !tbaa !24
  %t84 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v1, { i64, ptr } %t82, i64 %t83)
  %t85 = extractvalue { i32, i64 } %t84, 1
  %t86 = extractvalue { i32, i64 } %t84, 0
  store i32 %t86, ptr %l43
  %t87 = icmp ne i32 %t86, 0
  br i1 %t87, label %bb27, label %ok.88, !prof !99
ok.88:
  store i64 %t85, ptr %l42
  br label %bb26
bb24:
  br label %bb25
bb25:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l30, !tbaa !24
  br label %bb28
bb26:
  %t89 = load i64, ptr %l42, !tbaa !24
  store i64 %t89, ptr %l30, !tbaa !24
  br label %bb28
bb27:
  br label %bb25
bb28:
  %t90 = load i64, ptr %l30, !tbaa !24
  store i64 %t90, ptr %l6, !tbaa !24
  %t91 = load i64, ptr %l3, !tbaa !24
  %t93 = icmp sge i64 %t91, 2
  br i1 %t93, label %bb29, label %bb30
bb29:
  %t95 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t95, ptr %l47, !tbaa !27
  %t96 = load i64, ptr %l3, !tbaa !24
  %t98 = sub i64 %t96, 2
  %t100 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr i8, ptr %t101, i64 %t98
  %t103 = load i8, ptr %t102, !tbaa !32
  %t105 = icmp eq i8 %t103, 44
  store i1 %t105, ptr %l46, !tbaa !21
  br label %bb31
bb30:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb31
bb31:
  %t107 = load i1, ptr %l46, !tbaa !21
  br i1 %t107, label %bb32, label %bb33
bb32:
  %t108 = load i64, ptr %l3, !tbaa !24
  %t110 = sub i64 %t108, 2
  store i64 %t110, ptr %l52, !tbaa !24
  br label %bb34
bb33:
  %t112 = load i64, ptr %l3, !tbaa !24
  %t114 = sub i64 %t112, 1
  store i64 %t114, ptr %l52, !tbaa !24
  br label %bb34
bb34:
  %t116 = load i64, ptr %l52, !tbaa !24
  %t117 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t117, ptr %l57, !tbaa !27
  store i64 %t116, ptr %l58, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t119, 0
  store i64 %t120, ptr %l59, !tbaa !24
  %t121 = icmp sge i64 0, 0
  br i1 %t121, label %bb35, label %bb36
bb35:
  %t123 = load i64, ptr %l58, !tbaa !24
  %t124 = icmp sle i64 0, %t123
  br i1 %t124, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_681ac7b531dd0cd6_76b1194f7bcdc9ea)
  unreachable
bb37:
  %t126 = load i64, ptr %l58, !tbaa !24
  %t127 = load i64, ptr %l59, !tbaa !24
  %t128 = icmp sle i64 %t126, %t127
  br i1 %t128, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_681ac7b531dd0cd6_76b1194f7bcdc9ea)
  unreachable
bb39:
  %t130 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = load i64, ptr %l58, !tbaa !24
  %t133 = getelementptr i8, ptr %t131, i64 0
  %t134 = sub i64 %t132, 0
  %t135 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t133, 1
  store { i64, ptr } %t136, ptr %l63, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t137, ptr %l64, !tbaa !27
  %t138 = load i64, ptr %l5, !tbaa !24
  store i64 %t138, ptr %l65, !tbaa !24
  %t139 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t139, 0
  store i64 %t142, ptr %l68, !tbaa !24
  %t143 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t143, 0
  store i64 %t144, ptr %l69, !tbaa !24
  %t145 = load i64, ptr %l65, !tbaa !24
  %t146 = icmp sge i64 %t145, 0
  br i1 %t146, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_681ac7b531dd0cd6_76b1194f7bcdc9ea)
  unreachable
bb41:
  %t148 = load i64, ptr %l65, !tbaa !24
  %t149 = load i64, ptr %l68, !tbaa !24
  %t150 = icmp sle i64 %t148, %t149
  br i1 %t150, label %bb43, label %bb44
bb42:
  call void @__olang_check_failed(ptr @olang_loc_681ac7b531dd0cd6_76b1194f7bcdc9ea)
  unreachable
bb43:
  %t152 = load i64, ptr %l68, !tbaa !24
  %t153 = load i64, ptr %l69, !tbaa !24
  %t154 = icmp sle i64 %t152, %t153
  br i1 %t154, label %bb45, label %bb46
bb44:
  call void @__olang_check_failed(ptr @olang_loc_681ac7b531dd0cd6_76b1194f7bcdc9ea)
  unreachable
bb45:
  %t156 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = load i64, ptr %l65, !tbaa !24
  %t159 = load i64, ptr %l68, !tbaa !24
  %t160 = getelementptr i8, ptr %t157, i64 %t158
  %t161 = sub i64 %t159, %t158
  %t162 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t160, 1
  %t164 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t164, 1
  %t166 = extractvalue { i64, ptr } %t164, 0
  %t168 = extractvalue { i64, ptr } %t163, 1
  %t169 = extractvalue { i64, ptr } %t163, 0
  %t170 = add i64 %t166, %t169
  %t171 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t170)
  call void @olang_textcopy(ptr %t171, ptr %t165, i64 %t166)
  %t172 = getelementptr i8, ptr %t171, i64 %t166
  call void @olang_textcopy(ptr %t172, ptr %t168, i64 %t169)
  %t173 = insertvalue { i64, ptr } undef, i64 %t170, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t171, 1
  store { i64, ptr } %t174, ptr %l74, !tbaa !27
  %t175 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t176 = extractvalue { i64, ptr } %t175, 0
  %t177 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t177, 0
  store i64 %t178, ptr %l76, !tbaa !24
  %t180 = load i64, ptr %l76, !tbaa !24
  %t181 = icmp eq i64 %t176, %t180
  br i1 %t181, label %bb47, label %bb48
bb46:
  call void @__olang_check_failed(ptr @olang_loc_681ac7b531dd0cd6_76b1194f7bcdc9ea)
  unreachable
bb47:
  %t183 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !27
  %t187 = load i64, ptr %l76, !tbaa !24
  %t188 = mul i64 %t187, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t184, ptr %t186, i64 %t188, i1 false)
  br label %bb49
bb48:
  %t189 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t189, ptr %l4, !tbaa !27
  br label %bb49
bb49:
  %t190 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t192 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s2, { i64, ptr } %t190, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d72, i32 0, i32 1) })
  store i1 %t192, ptr %l79
  br label %bb50
bb50:
  %t193 = load i1, ptr %l79, !tbaa !21
  br i1 %t193, label %bb51, label %bb52
bb51:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2flisting_2ecompiler_2flisting_3aWriter_2eirPlace(ptr %v0, ptr %v2, ptr %t194, i64 %t195, ptr %a2)
  br label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s2)
  br label %bb55
bb55:
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l83, !tbaa !29
  %t201 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t201, ptr %l84, !tbaa !27
  %t202 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t204 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t202, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d73, i32 0, i32 1) })
  store i1 %t204, ptr %l86
  br label %bb56
bb56:
  %t205 = load i1, ptr %l86, !tbaa !21
  br i1 %t205, label %bb57, label %bb58
bb57:
  %t206 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t208 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v1, ptr %v1, { i64, ptr } %t206)
  store { i64, ptr } %t208, ptr %l89
  br label %bb59
bb58:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb61
bb59:
  %t209 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t210 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t209, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d74, i32 0, i32 1) })
  store i1 %t210, ptr %l90
  br label %bb60
bb60:
  %t211 = load i1, ptr %l90, !tbaa !21
  %t212 = xor i1 %t211, true
  store i1 %t212, ptr %l87, !tbaa !21
  br label %bb61
bb61:
  %t214 = load ptr, ptr %l83, !tbaa !29
  %t215 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t216 = load i1, ptr %l87, !tbaa !21
  call void @compiler_2flisting_2ecompiler_2flisting_3aWriter_2ecode(ptr %v0, ptr %s0, ptr %t214, { i64, ptr } %t215, i1 %t216)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flisting_2ecompiler_2flisting_3aWriter_2eirPart(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l4 = alloca %"std/prelude/text:LineIter"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca %"std/prelude/text:LineIter"
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l12 = alloca %"std/prelude/text:LineIter"
  %l13 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i32
  %l18 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i1
  %l24 = alloca { i64, ptr }
  %l25 = alloca i1
  %l26 = alloca i1
  %l29 = alloca { i64, ptr }
  %l30 = alloca i1
  %l31 = alloca i1
  %l34 = alloca { i64, ptr }
  %l35 = alloca i1
  %l36 = alloca i1
  %l39 = alloca { i64, ptr }
  %l40 = alloca i1
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i32
  %l47 = alloca i64
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca i32
  %l54 = alloca i64
  %l55 = alloca i32
  %l64 = alloca %"std/prelude/text:LineIter"
  %l65 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l68 = alloca i32
  %l70 = alloca i1
  %l72 = alloca i1
  %l73 = alloca i1
  %l76 = alloca i1
  %l83 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l10
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l3
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v1, ptr %v1, { i64, ptr } %t3)
  store %"std/prelude/text:LineIter" %t5, ptr %l12
  br label %bb2
bb2:
  %t6 = load %"std/prelude/text:LineIter", ptr %l12
  store %"std/prelude/text:LineIter" %t6, ptr %l4
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v1, ptr %v1, ptr %l4)
  %t9 = extractvalue { i32, { i64, ptr } } %t8, 1
  %t10 = extractvalue { i32, { i64, ptr } } %t8, 0
  store i32 %t10, ptr %l16
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb5, label %ok.12, !prof !99
ok.12:
  store { i64, ptr } %t9, ptr %l15
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t13, ptr %l13, !tbaa !27
  br label %bb7
bb5:
  %t14 = load i32, ptr %l16, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  store i1 %t17, ptr %l18, !tbaa !21
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb49
bb7:
  %t18 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t18, ptr %l5, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t21 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s2, { i64, ptr } %t19, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d75, i32 0, i32 1) })
  store i1 %t21, ptr %l20
  br label %bb8
bb8:
  %t22 = load i1, ptr %l20, !tbaa !21
  br i1 %t22, label %bb9, label %bb10
bb9:
  %t23 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d76, i32 0, i32 1) }, ptr %l24, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t27 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s2, { i64, ptr } %t23, { i64, ptr } %t26)
  store i1 %t27, ptr %l25
  br label %bb11
bb10:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb24
bb11:
  %t28 = load i1, ptr %l25, !tbaa !21
  br i1 %t28, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb15
bb13:
  %t29 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d77, i32 0, i32 1) }, ptr %l29, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t33 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s2, { i64, ptr } %t29, { i64, ptr } %t32)
  store i1 %t33, ptr %l30
  br label %bb14
bb14:
  %t34 = load i1, ptr %l30, !tbaa !21
  store i1 %t34, ptr %l26, !tbaa !21
  br label %bb15
bb15:
  %t35 = load i1, ptr %l26, !tbaa !21
  br i1 %t35, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb19
bb17:
  %t36 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d78, i32 0, i32 1) }, ptr %l34, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t40 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s2, { i64, ptr } %t36, { i64, ptr } %t39)
  store i1 %t40, ptr %l35
  br label %bb18
bb18:
  %t41 = load i1, ptr %l35, !tbaa !21
  store i1 %t41, ptr %l31, !tbaa !21
  br label %bb19
bb19:
  %t42 = load i1, ptr %l31, !tbaa !21
  br i1 %t42, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb23
bb21:
  %t43 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d79, i32 0, i32 1) }, ptr %l39, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t47 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s2, { i64, ptr } %t43, { i64, ptr } %t46)
  store i1 %t47, ptr %l40
  br label %bb22
bb22:
  %t48 = load i1, ptr %l40, !tbaa !21
  store i1 %t48, ptr %l36, !tbaa !21
  br label %bb23
bb23:
  %t49 = load i1, ptr %l36, !tbaa !21
  store i1 %t49, ptr %l21, !tbaa !21
  br label %bb24
bb24:
  %t50 = load i1, ptr %l21, !tbaa !21
  br i1 %t50, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s3
  %t51 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t51, ptr %l42, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t54 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s3, { i64, ptr } %t52, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d80, i32 0, i32 1) })
  %t55 = extractvalue { i32, i64 } %t54, 1
  %t56 = extractvalue { i32, i64 } %t54, 0
  store i32 %t56, ptr %l46
  %t57 = icmp ne i32 %t56, 0
  br i1 %t57, label %bb28, label %ok.58, !prof !99
ok.58:
  store i64 %t55, ptr %l45
  br label %bb27
bb26:
  br label %bb47
bb27:
  %t59 = load i64, ptr %l45, !tbaa !24
  store i64 %t59, ptr %l43, !tbaa !24
  br label %bb30
bb28:
  br label %bb29
bb29:
  call void @__olang_ert_req_clear()
  store i64 1, ptr %l43, !tbaa !24
  br label %bb30
bb30:
  %t60 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t60, 0
  store i64 %t61, ptr %l47, !tbaa !24
  %t62 = icmp sge i64 1, 0
  br i1 %t62, label %bb31, label %bb32
bb31:
  %t64 = load i64, ptr %l43, !tbaa !24
  %t65 = icmp sle i64 1, %t64
  br i1 %t65, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_4e22a6b8cb4b0f4e_d8ececdffd9edfc2)
  unreachable
bb33:
  %t67 = load i64, ptr %l43, !tbaa !24
  %t68 = load i64, ptr %l47, !tbaa !24
  %t69 = icmp sle i64 %t67, %t68
  br i1 %t69, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_4e22a6b8cb4b0f4e_d8ececdffd9edfc2)
  unreachable
bb35:
  %t71 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = load i64, ptr %l43, !tbaa !24
  %t74 = getelementptr i8, ptr %t72, i64 1
  %t75 = sub i64 %t73, 1
  %t76 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t74, 1
  store { i64, ptr } %t77, ptr %l51, !tbaa !27
  %t78 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s3, i64 10)
  %t79 = extractvalue { i32, i64 } %t78, 1
  %t80 = extractvalue { i32, i64 } %t78, 0
  store i32 %t80, ptr %l53
  %t81 = icmp ne i32 %t80, 0
  br i1 %t81, label %bb38, label %ok.82, !prof !99
ok.82:
  store i64 %t79, ptr %l52
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_4e22a6b8cb4b0f4e_d8ececdffd9edfc2)
  unreachable
bb37:
  %t83 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t84 = load i64, ptr %l52, !tbaa !24
  %t85 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v1, { i64, ptr } %t83, i64 %t84)
  %t86 = extractvalue { i32, i64 } %t85, 1
  %t87 = extractvalue { i32, i64 } %t85, 0
  store i32 %t87, ptr %l55
  %t88 = icmp ne i32 %t87, 0
  br i1 %t88, label %bb41, label %ok.89, !prof !99
ok.89:
  store i64 %t86, ptr %l54
  br label %bb40
bb38:
  br label %bb39
bb39:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l41, !tbaa !24
  br label %bb42
bb40:
  %t90 = load i64, ptr %l54, !tbaa !24
  store i64 %t90, ptr %l41, !tbaa !24
  br label %bb42
bb41:
  br label %bb39
bb42:
  %t91 = load i64, ptr %l41, !tbaa !24
  store i64 %t91, ptr %l6, !tbaa !24
  %t92 = load i64, ptr %l6, !tbaa !24
  %t94 = icmp sge i64 %t92, 0
  br i1 %t94, label %bb43, label %bb44
bb43:
  %t96 = load i64, ptr %l6, !tbaa !24
  %t97 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 1
  %t100 = extractvalue { i64, ptr } %t97, 0
  %t101 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t100)
  call void @olang_textcopy(ptr %t101, ptr %t99, i64 %t100)
  %t102 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t101, 1
  %t105 = extractvalue { i64, ptr } %t103, 0
  %t106 = extractvalue { i64, ptr } %t103, 1
  %t107 = mul i64 %t105, 1
  %t108 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t107)
  call void @llvm.memcpy.p0.p0.i64(ptr %t108, ptr %t106, i64 %t107, i1 false)
  %t109 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Hc3dff1927e5c626a9d95abfdf4e9a462(ptr %s0, ptr %s0, ptr %l3, i64 %t96, { i64, ptr } %t110)
  br label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s3)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s2)
  br label %bb48
bb48:
  br label %bb3
bb49:
  store i1 false, ptr %l7, !tbaa !21
  %t114 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t116 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v1, ptr %v1, { i64, ptr } %t114)
  store %"std/prelude/text:LineIter" %t116, ptr %l64
  br label %bb50
bb50:
  %t117 = load %"std/prelude/text:LineIter", ptr %l64
  store %"std/prelude/text:LineIter" %t117, ptr %l8
  br label %bb51
bb51:
  store %olang.scope zeroinitializer, ptr %s7
  %t119 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v1, ptr %v1, ptr %l8)
  %t120 = extractvalue { i32, { i64, ptr } } %t119, 1
  %t121 = extractvalue { i32, { i64, ptr } } %t119, 0
  store i32 %t121, ptr %l68
  %t122 = icmp ne i32 %t121, 0
  br i1 %t122, label %bb53, label %ok.123, !prof !99
ok.123:
  store { i64, ptr } %t120, ptr %l67
  br label %bb52
bb52:
  %t124 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t124, ptr %l65, !tbaa !27
  br label %bb55
bb53:
  %t125 = load i32, ptr %l68, !tbaa !23
  %t126 = ashr i32 %t125, 16
  %t128 = icmp eq i32 %t126, 1
  store i1 %t128, ptr %l70, !tbaa !21
  br label %bb54
bb54:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s7)
  br label %bb73
bb55:
  %t129 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t129, ptr %l9, !tbaa !27
  %t130 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t132 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s7, { i64, ptr } %t130, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d81, i32 0, i32 1) })
  store i1 %t132, ptr %l72
  br label %bb56
bb56:
  %t133 = load i1, ptr %l72, !tbaa !21
  br i1 %t133, label %bb57, label %bb58
bb57:
  %t134 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t138 = call i1 @compiler_2flisting_2eirDefines(ptr %v1, ptr %v2, { i64, ptr } %t134, { i64, ptr } %a2)
  store i1 %t138, ptr %l76
  br label %bb59
bb58:
  store i1 false, ptr %l73, !tbaa !21
  br label %bb60
bb59:
  %t139 = load i1, ptr %l76, !tbaa !21
  store i1 %t139, ptr %l73, !tbaa !21
  br label %bb60
bb60:
  %t140 = load i1, ptr %l73, !tbaa !21
  br i1 %t140, label %bb61, label %bb62
bb61:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb63
bb62:
  br label %bb63
bb63:
  %t141 = load i1, ptr %l7, !tbaa !21
  %t143 = xor i1 %t141, true
  br i1 %t143, label %bb64, label %bb65
bb64:
  call void @__olang_scope_close(ptr %s7)
  br label %bb72
bb65:
  br label %bb66
bb66:
  %t146 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @compiler_2flisting_2ecompiler_2flisting_3aWriter_2eirLine(ptr %v0, ptr %v1, ptr %s0, ptr %a0, { i64, ptr } %t146, ptr %l3)
  br label %bb67
bb67:
  %t150 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t152 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s7, { i64, ptr } %t150, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d82, i32 0, i32 1) })
  store i1 %t152, ptr %l83
  br label %bb68
bb68:
  %t153 = load i1, ptr %l83, !tbaa !21
  br i1 %t153, label %bb69, label %bb70
bb69:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb71
bb70:
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s7)
  br label %bb72
bb72:
  br label %bb51
bb73:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flisting_2ecompiler_2flisting_3aWriter_2eirPlace(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l17 = alloca { i64, ptr }
  %l18 = alloca i1
  %l20 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i32
  %l26 = alloca i64
  %l27 = alloca i32
  %l28 = alloca i64
  %l30 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca i32
  %l42 = alloca i64
  %l43 = alloca i32
  %l44 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i32
  %l49 = alloca { i64, ptr }
  %l50 = alloca ptr
  %l51 = alloca i64
  %l53 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca i64
  %l62 = alloca { i64, ptr }
  %l63 = alloca i64
  %l64 = alloca i32
  %l65 = alloca i64
  %l66 = alloca i32
  %l67 = alloca { i64, ptr }
  %l68 = alloca i32
  %l70 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l73 = alloca ptr
  %l74 = alloca { i64, ptr }
  %l76 = alloca i1
  %l77 = alloca i1
  %l79 = alloca i1
  %l80 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t5 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v1, ptr %v1, ptr %t1, i64 %a1)
  %t6 = extractvalue { i32, { i64, ptr } } %t5, 1
  %t7 = extractvalue { i32, { i64, ptr } } %t5, 0
  store i32 %t7, ptr %l14
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store { i64, ptr } %t6, ptr %l13
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t10, ptr %l10, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d83, i32 0, i32 1) }, ptr %l10, !tbaa !27
  br label %bb4
bb4:
  %t11 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d84, i32 0, i32 1) }, ptr %l17, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t16 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t12, { i64, ptr } %t15)
  store i1 %t16, ptr %l18
  br label %bb5
bb5:
  %t17 = load i1, ptr %l18, !tbaa !21
  %t18 = xor i1 %t17, true
  br i1 %t18, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  br label %bb8
bb8:
  %t20 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t22 = call { i64, ptr } @compiler_2flisting_2emetaField(ptr %v1, ptr %s0, ptr %s0, { i64, ptr } %t20, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d85, i32 0, i32 1) })
  store { i64, ptr } %t22, ptr %l22
  br label %bb9
bb9:
  %t23 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 0
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = mul i64 %t24, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t26)
  call void @llvm.memcpy.p0.p0.i64(ptr %t27, ptr %t25, i64 %t26, i1 false)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  store { i64, ptr } %t29, ptr %l23, !tbaa !27
  %t30 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 10)
  %t31 = extractvalue { i32, i64 } %t30, 1
  %t32 = extractvalue { i32, i64 } %t30, 0
  store i32 %t32, ptr %l25
  %t33 = icmp ne i32 %t32, 0
  br i1 %t33, label %bb11, label %ok.34, !prof !99
ok.34:
  store i64 %t31, ptr %l24
  br label %bb10
bb10:
  %t35 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t36 = load i64, ptr %l24, !tbaa !24
  %t37 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s0, { i64, ptr } %t35, i64 %t36)
  %t38 = extractvalue { i32, i64 } %t37, 1
  %t39 = extractvalue { i32, i64 } %t37, 0
  store i32 %t39, ptr %l27
  %t40 = icmp ne i32 %t39, 0
  br i1 %t40, label %bb14, label %ok.41, !prof !99
ok.41:
  store i64 %t38, ptr %l26
  br label %bb13
bb11:
  br label %bb12
bb12:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l20, !tbaa !24
  br label %bb15
bb13:
  %t42 = load i64, ptr %l26, !tbaa !24
  store i64 %t42, ptr %l20, !tbaa !24
  br label %bb15
bb14:
  br label %bb12
bb15:
  %t43 = load i64, ptr %l20, !tbaa !24
  store i64 %t43, ptr %l4, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t46 = call { i64, ptr } @compiler_2flisting_2emetaField(ptr %v1, ptr %s0, ptr %s0, { i64, ptr } %t44, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d86, i32 0, i32 1) })
  store { i64, ptr } %t46, ptr %l30
  br label %bb16
bb16:
  %t47 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t49 = call { i64, ptr } @compiler_2flisting_2emetaField(ptr %v1, ptr %s0, ptr %s0, { i64, ptr } %t47, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d86, i32 0, i32 1) })
  store { i64, ptr } %t49, ptr %l32
  br label %bb17
bb17:
  %t50 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t50, 0
  store i64 %t52, ptr %l34, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 0
  store i64 %t54, ptr %l35, !tbaa !24
  %t55 = icmp sge i64 1, 0
  br i1 %t55, label %bb18, label %bb19
bb18:
  %t57 = load i64, ptr %l34, !tbaa !24
  %t58 = icmp sle i64 1, %t57
  br i1 %t58, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_b8d38b69b79cf91c_5a0dc70c1127b970)
  unreachable
bb20:
  %t60 = load i64, ptr %l34, !tbaa !24
  %t61 = load i64, ptr %l35, !tbaa !24
  %t62 = icmp sle i64 %t60, %t61
  br i1 %t62, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_b8d38b69b79cf91c_5a0dc70c1127b970)
  unreachable
bb22:
  %t64 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = load i64, ptr %l34, !tbaa !24
  %t67 = getelementptr i8, ptr %t65, i64 1
  %t68 = sub i64 %t66, 1
  %t69 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t67, 1
  store { i64, ptr } %t70, ptr %l39, !tbaa !27
  %t71 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 10)
  %t72 = extractvalue { i32, i64 } %t71, 1
  %t73 = extractvalue { i32, i64 } %t71, 0
  store i32 %t73, ptr %l41
  %t74 = icmp ne i32 %t73, 0
  br i1 %t74, label %bb25, label %ok.75, !prof !99
ok.75:
  store i64 %t72, ptr %l40
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_b8d38b69b79cf91c_5a0dc70c1127b970)
  unreachable
bb24:
  %t76 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t77 = load i64, ptr %l40, !tbaa !24
  %t78 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s0, { i64, ptr } %t76, i64 %t77)
  %t79 = extractvalue { i32, i64 } %t78, 1
  %t80 = extractvalue { i32, i64 } %t78, 0
  store i32 %t80, ptr %l43
  %t81 = icmp ne i32 %t80, 0
  br i1 %t81, label %bb28, label %ok.82, !prof !99
ok.82:
  store i64 %t79, ptr %l42
  br label %bb27
bb25:
  br label %bb26
bb26:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l28, !tbaa !24
  br label %bb29
bb27:
  %t83 = load i64, ptr %l42, !tbaa !24
  store i64 %t83, ptr %l28, !tbaa !24
  br label %bb29
bb28:
  br label %bb26
bb29:
  %t84 = load i64, ptr %l28, !tbaa !24
  %t85 = load ptr, ptr %l2, !tbaa !29
  %t89 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v1, ptr %v1, ptr %t85, i64 %t84)
  %t90 = extractvalue { i32, { i64, ptr } } %t89, 1
  %t91 = extractvalue { i32, { i64, ptr } } %t89, 0
  store i32 %t91, ptr %l48
  %t92 = icmp ne i32 %t91, 0
  br i1 %t92, label %bb31, label %ok.93, !prof !99
ok.93:
  store { i64, ptr } %t90, ptr %l47
  br label %bb30
bb30:
  %t94 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t94, ptr %l44, !tbaa !27
  br label %bb33
bb31:
  br label %bb32
bb32:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d87, i32 0, i32 1) }, ptr %l44, !tbaa !27
  br label %bb33
bb33:
  %t95 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t95, ptr %l6, !tbaa !27
  %t96 = load ptr, ptr %l2, !tbaa !29
  store ptr %t96, ptr %l50, !tbaa !29
  %t97 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t99 = call { i64, ptr } @compiler_2flisting_2emetaField(ptr %v1, ptr %s0, ptr %s0, { i64, ptr } %t97, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d88, i32 0, i32 1) })
  store { i64, ptr } %t99, ptr %l53
  br label %bb34
bb34:
  %t100 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t102 = call { i64, ptr } @compiler_2flisting_2emetaField(ptr %v1, ptr %s0, ptr %s0, { i64, ptr } %t100, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d88, i32 0, i32 1) })
  store { i64, ptr } %t102, ptr %l55
  br label %bb35
bb35:
  %t103 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t103, 0
  store i64 %t105, ptr %l57, !tbaa !24
  %t106 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t106, 0
  store i64 %t107, ptr %l58, !tbaa !24
  %t108 = icmp sge i64 1, 0
  br i1 %t108, label %bb36, label %bb37
bb36:
  %t110 = load i64, ptr %l57, !tbaa !24
  %t111 = icmp sle i64 1, %t110
  br i1 %t111, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_43ec7269e82cf689_7116d248b5a11b4d)
  unreachable
bb38:
  %t113 = load i64, ptr %l57, !tbaa !24
  %t114 = load i64, ptr %l58, !tbaa !24
  %t115 = icmp sle i64 %t113, %t114
  br i1 %t115, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_43ec7269e82cf689_7116d248b5a11b4d)
  unreachable
bb40:
  %t117 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = load i64, ptr %l57, !tbaa !24
  %t120 = getelementptr i8, ptr %t118, i64 1
  %t121 = sub i64 %t119, 1
  %t122 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t120, 1
  store { i64, ptr } %t123, ptr %l62, !tbaa !27
  %t124 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 10)
  %t125 = extractvalue { i32, i64 } %t124, 1
  %t126 = extractvalue { i32, i64 } %t124, 0
  store i32 %t126, ptr %l64
  %t127 = icmp ne i32 %t126, 0
  br i1 %t127, label %bb43, label %ok.128, !prof !99
ok.128:
  store i64 %t125, ptr %l63
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_43ec7269e82cf689_7116d248b5a11b4d)
  unreachable
bb42:
  %t129 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t130 = load i64, ptr %l63, !tbaa !24
  %t131 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s0, { i64, ptr } %t129, i64 %t130)
  %t132 = extractvalue { i32, i64 } %t131, 1
  %t133 = extractvalue { i32, i64 } %t131, 0
  store i32 %t133, ptr %l66
  %t134 = icmp ne i32 %t133, 0
  br i1 %t134, label %bb46, label %ok.135, !prof !99
ok.135:
  store i64 %t132, ptr %l65
  br label %bb45
bb43:
  br label %bb44
bb44:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l51, !tbaa !24
  br label %bb47
bb45:
  %t136 = load i64, ptr %l65, !tbaa !24
  store i64 %t136, ptr %l51, !tbaa !24
  br label %bb47
bb46:
  br label %bb44
bb47:
  %t137 = load ptr, ptr %l50, !tbaa !29
  %t138 = load i64, ptr %l51, !tbaa !24
  %t139 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v1, ptr %v1, ptr %t137, i64 %t138)
  %t140 = extractvalue { i32, { i64, ptr } } %t139, 1
  %t141 = extractvalue { i32, { i64, ptr } } %t139, 0
  store i32 %t141, ptr %l68
  %t142 = icmp ne i32 %t141, 0
  br i1 %t142, label %bb49, label %ok.143, !prof !99
ok.143:
  store { i64, ptr } %t140, ptr %l67
  br label %bb48
bb48:
  %t144 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t144, ptr %l49, !tbaa !27
  br label %bb51
bb49:
  br label %bb50
bb50:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d89, i32 0, i32 1) }, ptr %l49, !tbaa !27
  br label %bb51
bb51:
  %t145 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t145, ptr %l7, !tbaa !27
  %t146 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t148 = call { i64, ptr } @compiler_2flisting_2emetaField(ptr %v1, ptr %s0, ptr %s0, { i64, ptr } %t146, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d90, i32 0, i32 1) })
  store { i64, ptr } %t148, ptr %l70
  br label %bb52
bb52:
  %t149 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t149, ptr %l8, !tbaa !27
  %t150 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t152 = call { i64, ptr } @compiler_2flisting_2emetaField(ptr %v1, ptr %s0, ptr %s0, { i64, ptr } %t150, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d91, i32 0, i32 1) })
  store { i64, ptr } %t152, ptr %l72
  br label %bb53
bb53:
  %t153 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t153, ptr %l9, !tbaa !27
  store ptr %a0, ptr %l73, !tbaa !29
  %t155 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t155, ptr %l74, !tbaa !27
  %t156 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t158 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s0, { i64, ptr } %t156, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) })
  store i1 %t158, ptr %l76
  br label %bb54
bb54:
  %t159 = load i1, ptr %l76, !tbaa !21
  br i1 %t159, label %bb55, label %bb56
bb55:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb58
bb56:
  %t160 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t162 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t160, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d93, i32 0, i32 1) })
  store i1 %t162, ptr %l79
  br label %bb57
bb57:
  %t163 = load i1, ptr %l79, !tbaa !21
  store i1 %t163, ptr %l77, !tbaa !21
  br label %bb58
bb58:
  %t164 = load i1, ptr %l77, !tbaa !21
  br i1 %t164, label %bb59, label %bb60
bb59:
  %t165 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t165, ptr %l80, !tbaa !27
  br label %bb61
bb60:
  %t167 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t168 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t167, 1
  %t171 = extractvalue { i64, ptr } %t167, 0
  %t172 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t173 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  %t174 = add i64 %t171, %t173
  %t176 = extractvalue { i64, ptr } %t168, 1
  %t177 = extractvalue { i64, ptr } %t168, 0
  %t178 = add i64 %t174, %t177
  %t179 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t178)
  call void @olang_textcopy(ptr %t179, ptr %t170, i64 %t171)
  %t180 = getelementptr i8, ptr %t179, i64 %t171
  call void @olang_textcopy(ptr %t180, ptr %t172, i64 %t173)
  %t181 = getelementptr i8, ptr %t180, i64 %t173
  call void @olang_textcopy(ptr %t181, ptr %t176, i64 %t177)
  %t182 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t179, 1
  %t185 = extractvalue { i64, ptr } %t183, 0
  %t186 = extractvalue { i64, ptr } %t183, 1
  %t187 = mul i64 %t185, 1
  %t188 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t187)
  call void @llvm.memcpy.p0.p0.i64(ptr %t188, ptr %t186, i64 %t187, i1 false)
  %t189 = insertvalue { i64, ptr } undef, i64 %t185, 0
  %t190 = insertvalue { i64, ptr } %t189, ptr %t188, 1
  store { i64, ptr } %t190, ptr %l80, !tbaa !27
  br label %bb61
bb61:
  %t192 = load i64, ptr %l4, !tbaa !24
  %t193 = load ptr, ptr %l73, !tbaa !29
  %t194 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t195 = load { i64, ptr }, ptr %l80, !tbaa !27
  call void @compiler_2flisting_2ecompiler_2flisting_3aWriter_2ereach(ptr %v0, ptr %s0, ptr %s0, ptr %t193, { i64, ptr } %t194, { i64, ptr } %t195, i64 %t192)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2flisting_2ecompiler_2flisting_3aWriter_2eleftover(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca %"compiler/listing:Remark"
  %l6 = alloca { i64, ptr }
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca i64
  %l19 = alloca i64
  %l25 = alloca %"compiler/listing:Remark"
  %l28 = alloca i64
  %l30 = alloca i1
  %l34 = alloca i1
  %l35 = alloca i1
  %l39 = alloca i1
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l48 = alloca i1
  %l55 = alloca i64
  %l57 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l59 = alloca i64
  %l60 = alloca { i64, ptr }
  %l63 = alloca %"std/prelude/text:StringBuilder"
  %l70 = alloca i64
  %l72 = alloca i64
  %l77 = alloca { i64, ptr }
  %l78 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i32
  %l83 = alloca i1
  %l84 = alloca { i64, ptr }
  %l86 = alloca ptr
  %l87 = alloca { i64, ptr }
  %l88 = alloca i64
  %l89 = alloca i64
  %l94 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l96 = alloca i64
  %l99 = alloca i64
  %l100 = alloca i64
  %l113 = alloca ptr
  %l116 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l14
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/listing:Writer", ptr %t3, i32 0, i32 2
  %t6 = load ptr, ptr %t5, !tbaa !29
  store ptr %t6, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = load i64, ptr %l3, !tbaa !24
  store i64 %t8, ptr %l17, !tbaa !24
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t10 = load ptr, ptr @__olang_prog_scope
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flisting_3aRemark_3e_2eLen_3ccompiler_2flisting_3aRemark_3e(ptr %t10, ptr %t9)
  store i64 %t12, ptr %l19
  br label %bb3
bb3:
  %t13 = load i64, ptr %l17, !tbaa !24
  %t14 = load i64, ptr %l19, !tbaa !24
  %t15 = icmp slt i64 %t13, %t14
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb5:
  br label %bb6
bb6:
  %t19 = load i64, ptr %l3, !tbaa !24
  store i64 %t19, ptr %l4, !tbaa !24
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t22 = load i64, ptr %l3, !tbaa !24
  %t23 = load ptr, ptr @__olang_prog_scope
  %t26 = call %"compiler/listing:Remark" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flisting_3aRemark_3e_2eAt_3ccompiler_2flisting_3aRemark_3e(ptr %t23, ptr %s2, ptr %t21, i64 %t22)
  store %"compiler/listing:Remark" %t26, ptr %l25
  br label %bb7
bb7:
  %t27 = load %"compiler/listing:Remark", ptr %l25
  store %"compiler/listing:Remark" %t27, ptr %l5
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/listing:Writer", ptr %t28, i32 0, i32 4
  %t32 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t30)
  store i64 %t32, ptr %l28
  br label %bb8
bb8:
  %t33 = load i64, ptr %l28, !tbaa !24
  %t34 = icmp sgt i64 %t33, 0
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/listing:Writer", ptr %t36, i32 0, i32 4
  %t39 = load i64, ptr %l4, !tbaa !24
  %t42 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t38, i64 %t39)
  store i1 %t42, ptr %l34
  br label %bb11
bb10:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb12
bb11:
  %t43 = load i1, ptr %l34, !tbaa !21
  store i1 %t43, ptr %l30, !tbaa !21
  br label %bb12
bb12:
  %t44 = load i1, ptr %l30, !tbaa !21
  br i1 %t44, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb16
bb14:
  %t45 = getelementptr %"compiler/listing:Remark", ptr %l5, i32 0, i32 5
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/listing:Writer", ptr %t47, i32 0, i32 3
  %t50 = load { i64, ptr }, ptr %t49, !tbaa !27
  %t51 = load ptr, ptr @__olang_prog_scope
  %t54 = call i1 @compiler_2flisting_2eofAny(ptr %s2, ptr %t51, { i64, ptr } %t46, { i64, ptr } %t50)
  store i1 %t54, ptr %l39
  br label %bb15
bb15:
  %t55 = load i1, ptr %l39, !tbaa !21
  %t56 = xor i1 %t55, true
  store i1 %t56, ptr %l35, !tbaa !21
  br label %bb16
bb16:
  %t58 = load i1, ptr %l35, !tbaa !21
  br i1 %t58, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb18:
  br label %bb19
bb19:
  %t60 = call { i64, ptr } @compiler_2flisting_2eplaceOf(ptr %s2, ptr %s0, ptr %l5)
  store { i64, ptr } %t60, ptr %l42
  br label %bb20
bb20:
  %t61 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t61, ptr %l6, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t62, ptr %l43, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 0
  store i64 %t64, ptr %l44, !tbaa !24
  %t65 = load i64, ptr %l44, !tbaa !24
  %t66 = mul i64 %t65, 1
  %t67 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  store { i64, ptr } %t69, ptr %l45, !tbaa !27
  %t70 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = load i64, ptr %l44, !tbaa !24
  %t75 = mul i64 %t74, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t71, ptr %t73, i64 %t75, i1 false)
  %t76 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t80 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %s0, ptr %s2, ptr %l1, { i64, ptr } %t76)
  store i1 %t80, ptr %l48
  br label %bb21
bb21:
  %t81 = load i1, ptr %l48, !tbaa !21
  %t82 = xor i1 %t81, true
  br i1 %t82, label %bb22, label %bb23
bb22:
  %t84 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } %t84)
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb26:
  %t87 = load i64, ptr %l3, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l3, !tbaa !24
  br label %bb2
bb27:
  %t92 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l1)
  store i64 %t92, ptr %l55
  br label %bb28
bb28:
  %t93 = load i64, ptr %l55, !tbaa !24
  %t94 = icmp eq i64 %t93, 0
  br i1 %t94, label %bb29, label %bb30
bb29:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d95, i32 0, i32 1) }, ptr %l57, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t96, ptr %l58, !tbaa !27
  %t97 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 0
  store i64 %t98, ptr %l59, !tbaa !24
  %t99 = load i64, ptr %l59, !tbaa !24
  %t100 = mul i64 %t99, 1
  %t101 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t100)
  %t102 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t101, 1
  store { i64, ptr } %t103, ptr %l60, !tbaa !27
  %t104 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = load i64, ptr %l59, !tbaa !24
  %t109 = mul i64 %t108, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t105, ptr %t107, i64 %t109, i1 false)
  %t110 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t110, ptr %l58, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t111 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t111, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  %t112 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_96, 0
  %t113 = insertvalue { ptr, ptr } %t112, ptr null, 1
  %t116 = extractvalue { ptr, ptr } %t113, 0
  %t117 = extractvalue { ptr, ptr } %t113, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H1642129570dad448bb7dcc47c334de83(ptr %s0, ptr %s0, ptr %l1, ptr %t116, ptr %t117)
  br label %bb32
bb32:
  %t118 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t118, ptr %l63
  br label %bb33
bb33:
  %t119 = load %"std/prelude/text:StringBuilder", ptr %l63
  store %"std/prelude/text:StringBuilder" %t119, ptr %l8
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/listing:Writer", ptr %t120, i32 0, i32 0
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t123, 1
  %t126 = extractvalue { i64, ptr } %t123, 0
  %t127 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d97, i32 0, i32 1) }, 1
  %t128 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d97, i32 0, i32 1) }, 0
  %t129 = add i64 %t126, %t128
  %t130 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t129)
  call void @olang_textcopy(ptr %t130, ptr %t125, i64 %t126)
  %t131 = getelementptr i8, ptr %t130, i64 %t126
  call void @olang_textcopy(ptr %t131, ptr %t127, i64 %t128)
  %t132 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t130, 1
  %t135 = extractvalue { i64, ptr } %t133, 0
  %t136 = extractvalue { i64, ptr } %t133, 1
  %t137 = mul i64 %t135, 1
  %t138 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t137)
  call void @llvm.memcpy.p0.p0.i64(ptr %t138, ptr %t136, i64 %t137, i1 false)
  %t139 = insertvalue { i64, ptr } undef, i64 %t135, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr %t138, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l8, { i64, ptr } %t140)
  br label %bb34
bb34:
  store ptr %l1, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb35
bb35:
  store %olang.scope zeroinitializer, ptr %s9
  %t144 = load i64, ptr %l10, !tbaa !24
  store i64 %t144, ptr %l70, !tbaa !24
  %t145 = load ptr, ptr %l9, !tbaa !29
  %t147 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t145)
  store i64 %t147, ptr %l72
  br label %bb36
bb36:
  %t148 = load i64, ptr %l70, !tbaa !24
  %t149 = load i64, ptr %l72, !tbaa !24
  %t150 = icmp slt i64 %t148, %t149
  %t152 = xor i1 %t150, true
  br i1 %t152, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s9)
  br label %bb66
bb38:
  br label %bb39
bb39:
  %t154 = load ptr, ptr %l9, !tbaa !29
  %t155 = load i64, ptr %l10, !tbaa !24
  %t158 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t154, i64 %t155)
  store { i64, ptr } %t158, ptr %l77
  br label %bb40
bb40:
  %t159 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t159, ptr %l11, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t162 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %s0, ptr %s9, { i64, ptr } %t160, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d98, i32 0, i32 1) })
  %t163 = extractvalue { i32, i64 } %t162, 1
  %t164 = extractvalue { i32, i64 } %t162, 0
  store i32 %t164, ptr %l81
  %t165 = icmp ne i32 %t164, 0
  br i1 %t165, label %bb42, label %ok.166, !prof !99
ok.166:
  store i64 %t163, ptr %l80
  br label %bb41
bb41:
  %t167 = load i64, ptr %l80, !tbaa !24
  store i64 %t167, ptr %l78, !tbaa !24
  br label %bb44
bb42:
  br label %bb43
bb43:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l78, !tbaa !24
  br label %bb44
bb44:
  %t168 = load i64, ptr %l78, !tbaa !24
  store i64 %t168, ptr %l12, !tbaa !24
  %t169 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t171 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s9, { i64, ptr } %t169, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d99, i32 0, i32 1) })
  store i1 %t171, ptr %l83
  br label %bb45
bb45:
  %t172 = load i1, ptr %l83, !tbaa !21
  br i1 %t172, label %bb46, label %bb47
bb46:
  store { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d100, i32 0, i32 1) }, ptr %l84, !tbaa !27
  br label %bb61
bb47:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/listing:Writer", ptr %t173, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !29
  store ptr %t176, ptr %l86, !tbaa !29
  %t177 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t177, ptr %l87, !tbaa !27
  %t178 = load i64, ptr %l12, !tbaa !24
  store i64 %t178, ptr %l88, !tbaa !24
  %t179 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t179, 0
  store i64 %t180, ptr %l89, !tbaa !24
  %t181 = icmp sge i64 0, 0
  br i1 %t181, label %bb48, label %bb49
bb48:
  %t183 = load i64, ptr %l88, !tbaa !24
  %t184 = icmp sle i64 0, %t183
  br i1 %t184, label %bb50, label %bb51
bb49:
  call void @__olang_check_failed(ptr @olang_loc_c76de25993fa5b69_1c32ce588582e85d)
  unreachable
bb50:
  %t186 = load i64, ptr %l88, !tbaa !24
  %t187 = load i64, ptr %l89, !tbaa !24
  %t188 = icmp sle i64 %t186, %t187
  br i1 %t188, label %bb52, label %bb53
bb51:
  call void @__olang_check_failed(ptr @olang_loc_c76de25993fa5b69_1c32ce588582e85d)
  unreachable
bb52:
  %t190 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = load i64, ptr %l88, !tbaa !24
  %t193 = getelementptr i8, ptr %t191, i64 0
  %t194 = sub i64 %t192, 0
  %t195 = insertvalue { i64, ptr } undef, i64 %t194, 0
  %t196 = insertvalue { i64, ptr } %t195, ptr %t193, 1
  %t197 = load ptr, ptr @__olang_prog_scope
  %t198 = load ptr, ptr %l86, !tbaa !29
  %t200 = call { i64, ptr } @compiler_2flisting_2ecompiler_2flisting_3aSources_2eShown(ptr %t197, ptr %s0, ptr %s9, ptr %t198, { i64, ptr } %t196)
  store { i64, ptr } %t200, ptr %l94
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_c76de25993fa5b69_1c32ce588582e85d)
  unreachable
bb54:
  %t201 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t201, ptr %l95, !tbaa !27
  %t202 = load i64, ptr %l12, !tbaa !24
  store i64 %t202, ptr %l96, !tbaa !24
  %t203 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t206 = extractvalue { i64, ptr } %t203, 0
  store i64 %t206, ptr %l99, !tbaa !24
  %t207 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t207, 0
  store i64 %t208, ptr %l100, !tbaa !24
  %t209 = load i64, ptr %l96, !tbaa !24
  %t210 = icmp sge i64 %t209, 0
  br i1 %t210, label %bb55, label %bb56
bb55:
  %t212 = load i64, ptr %l96, !tbaa !24
  %t213 = load i64, ptr %l99, !tbaa !24
  %t214 = icmp sle i64 %t212, %t213
  br i1 %t214, label %bb57, label %bb58
bb56:
  call void @__olang_check_failed(ptr @olang_loc_c76de25993fa5b69_1c32ce588582e85d)
  unreachable
bb57:
  %t216 = load i64, ptr %l99, !tbaa !24
  %t217 = load i64, ptr %l100, !tbaa !24
  %t218 = icmp sle i64 %t216, %t217
  br i1 %t218, label %bb59, label %bb60
bb58:
  call void @__olang_check_failed(ptr @olang_loc_c76de25993fa5b69_1c32ce588582e85d)
  unreachable
bb59:
  %t220 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !27
  %t222 = load i64, ptr %l96, !tbaa !24
  %t223 = load i64, ptr %l99, !tbaa !24
  %t224 = getelementptr i8, ptr %t221, i64 %t222
  %t225 = sub i64 %t223, %t222
  %t226 = insertvalue { i64, ptr } undef, i64 %t225, 0
  %t227 = insertvalue { i64, ptr } %t226, ptr %t224, 1
  %t228 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t229 = extractvalue { i64, ptr } %t228, 1
  %t230 = extractvalue { i64, ptr } %t228, 0
  %t232 = extractvalue { i64, ptr } %t227, 1
  %t233 = extractvalue { i64, ptr } %t227, 0
  %t234 = add i64 %t230, %t233
  %t235 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t234)
  call void @olang_textcopy(ptr %t235, ptr %t229, i64 %t230)
  %t236 = getelementptr i8, ptr %t235, i64 %t230
  call void @olang_textcopy(ptr %t236, ptr %t232, i64 %t233)
  %t237 = insertvalue { i64, ptr } undef, i64 %t234, 0
  %t238 = insertvalue { i64, ptr } %t237, ptr %t235, 1
  %t240 = extractvalue { i64, ptr } %t238, 0
  %t241 = extractvalue { i64, ptr } %t238, 1
  %t242 = mul i64 %t240, 1
  %t243 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t242)
  call void @llvm.memcpy.p0.p0.i64(ptr %t243, ptr %t241, i64 %t242, i1 false)
  %t244 = insertvalue { i64, ptr } undef, i64 %t240, 0
  %t245 = insertvalue { i64, ptr } %t244, ptr %t243, 1
  store { i64, ptr } %t245, ptr %l84, !tbaa !27
  br label %bb61
bb60:
  call void @__olang_check_failed(ptr @olang_loc_c76de25993fa5b69_1c32ce588582e85d)
  unreachable
bb61:
  %t247 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t250 = getelementptr %"compiler/listing:Writer", ptr %t248, i32 0, i32 0
  %t251 = load { i64, ptr }, ptr %t250, !tbaa !27
  %t254 = extractvalue { i64, ptr } %t251, 1
  %t255 = extractvalue { i64, ptr } %t251, 0
  %t256 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d101, i32 0, i32 1) }, 1
  %t257 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d101, i32 0, i32 1) }, 0
  %t258 = add i64 %t255, %t257
  %t260 = extractvalue { i64, ptr } %t247, 1
  %t261 = extractvalue { i64, ptr } %t247, 0
  %t262 = add i64 %t258, %t261
  %t263 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d102, i32 0, i32 1) }, 1
  %t264 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d102, i32 0, i32 1) }, 0
  %t265 = add i64 %t262, %t264
  %t266 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t265)
  call void @olang_textcopy(ptr %t266, ptr %t254, i64 %t255)
  %t267 = getelementptr i8, ptr %t266, i64 %t255
  call void @olang_textcopy(ptr %t267, ptr %t256, i64 %t257)
  %t268 = getelementptr i8, ptr %t267, i64 %t257
  call void @olang_textcopy(ptr %t268, ptr %t260, i64 %t261)
  %t269 = getelementptr i8, ptr %t268, i64 %t261
  call void @olang_textcopy(ptr %t269, ptr %t263, i64 %t264)
  %t270 = insertvalue { i64, ptr } undef, i64 %t265, 0
  %t271 = insertvalue { i64, ptr } %t270, ptr %t266, 1
  %t273 = extractvalue { i64, ptr } %t271, 0
  %t274 = extractvalue { i64, ptr } %t271, 1
  %t275 = mul i64 %t273, 1
  %t276 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t275)
  call void @llvm.memcpy.p0.p0.i64(ptr %t276, ptr %t274, i64 %t275, i1 false)
  %t277 = insertvalue { i64, ptr } undef, i64 %t273, 0
  %t278 = insertvalue { i64, ptr } %t277, ptr %t276, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s9, ptr %l8, { i64, ptr } %t278)
  br label %bb62
bb62:
  store ptr %l8, ptr %l113, !tbaa !29
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t282 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t285 = call { i64, ptr } @compiler_2flisting_2ecompiler_2flisting_3aWriter_2eremarksAt(ptr %v0, ptr %s0, ptr %s9, ptr %s9, ptr %t281, { i64, ptr } %t282, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d103, i32 0, i32 1) })
  store { i64, ptr } %t285, ptr %l116
  br label %bb63
bb63:
  %t286 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t287 = extractvalue { i64, ptr } %t286, 0
  %t288 = extractvalue { i64, ptr } %t286, 1
  %t289 = mul i64 %t287, 1
  %t290 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t289)
  call void @llvm.memcpy.p0.p0.i64(ptr %t290, ptr %t288, i64 %t289, i1 false)
  %t291 = insertvalue { i64, ptr } undef, i64 %t287, 0
  %t292 = insertvalue { i64, ptr } %t291, ptr %t290, 1
  %t293 = load ptr, ptr %l113, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s9, ptr %t293, { i64, ptr } %t292)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s9)
  br label %bb65
bb65:
  %t295 = load i64, ptr %l10, !tbaa !24
  %t297 = add i64 %t295, 1
  store i64 %t297, ptr %l10, !tbaa !24
  br label %bb35
bb66:
  %t300 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l8)
  store { i64, ptr } %t300, ptr %l121
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s0)
  %t301 = load { i64, ptr }, ptr %l121, !tbaa !27
  store { i64, ptr } %t301, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2flisting_2ecompiler_2flisting_3aWriter_2eplace(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l8 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %l17 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l37 = alloca i64
  %l44 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l50 = alloca ptr
  %l58 = alloca { i64, ptr }
  %l65 = alloca ptr
  %l67 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/listing:Writer", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/listing:Writer", ptr %t6, i32 0, i32 9
  %t9 = load i64, ptr %t8, !tbaa !24
  %t11 = icmp eq i64 %t9, 0
  br i1 %t11, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb4
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/listing:Writer", ptr %t13, i32 0, i32 7
  %t16 = load { i64, ptr }, ptr %t15, !tbaa !27
  %t18 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t16, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d104, i32 0, i32 1) })
  store i1 %t18, ptr %l11
  br label %bb3
bb3:
  %t19 = load i1, ptr %l11, !tbaa !21
  store i1 %t19, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t20 = load i1, ptr %l8, !tbaa !21
  br i1 %t20, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb8
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/listing:Writer", ptr %t21, i32 0, i32 7
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t24, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d105, i32 0, i32 1) })
  store i1 %t26, ptr %l15
  br label %bb7
bb7:
  %t27 = load i1, ptr %l15, !tbaa !21
  store i1 %t27, ptr %l12, !tbaa !21
  br label %bb8
bb8:
  %t28 = load i1, ptr %l12, !tbaa !21
  store i1 %t28, ptr %l2, !tbaa !21
  %t29 = load i1, ptr %l2, !tbaa !21
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/listing:Writer", ptr %t31, i32 0, i32 6
  %t34 = load i64, ptr %t33, !tbaa !24
  %t36 = icmp ne i64 %t34, 0
  store i1 %t36, ptr %l17, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb11
bb11:
  %t38 = load i1, ptr %l17, !tbaa !21
  br i1 %t38, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s1
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/listing:Writer", ptr %t39, i32 0, i32 10
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 1
  %t45 = extractvalue { i64, ptr } %t42, 0
  %t46 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d106, i32 0, i32 1) }, 1
  %t47 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d106, i32 0, i32 1) }, 0
  %t48 = add i64 %t45, %t47
  %t49 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t48)
  call void @olang_textcopy(ptr %t49, ptr %t44, i64 %t45)
  %t50 = getelementptr i8, ptr %t49, i64 %t45
  call void @olang_textcopy(ptr %t50, ptr %t46, i64 %t47)
  %t51 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t49, 1
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t55 = extractvalue { i64, ptr } %t52, 1
  %t56 = mul i64 %t54, 1
  %t57 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t56)
  call void @llvm.memcpy.p0.p0.i64(ptr %t57, ptr %t55, i64 %t56, i1 false)
  %t58 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s1, ptr %t41, { i64, ptr } %t59)
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s1)
  br label %bb15
bb15:
  %t62 = load i1, ptr %l2, !tbaa !21
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/listing:Writer", ptr %t66, i32 0, i32 10
  store ptr %t68, ptr %l29, !tbaa !29
  %t69 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t69, ptr %l30, !tbaa !27
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/listing:Writer", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/listing:Writer", ptr %t74, i32 0, i32 7
  %t77 = load { i64, ptr }, ptr %t76, !tbaa !27
  %t78 = load ptr, ptr @__olang_prog_scope
  %t81 = call { i64, ptr } @compiler_2flisting_2ecompiler_2flisting_3aSources_2eShown(ptr %t78, ptr %v0, ptr %s3, ptr %t73, { i64, ptr } %t77)
  store { i64, ptr } %t81, ptr %l35
  br label %bb18
bb17:
  br label %bb24
bb18:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/listing:Writer", ptr %t82, i32 0, i32 9
  %t85 = load i64, ptr %t84, !tbaa !24
  store i64 %t85, ptr %l37, !tbaa !24
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/listing:Writer", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/listing:Writer", ptr %t90, i32 0, i32 8
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/listing:Writer", ptr %t94, i32 0, i32 9
  %t97 = load i64, ptr %t96, !tbaa !24
  %t98 = load ptr, ptr @__olang_prog_scope
  %t102 = call { i64, ptr } @compiler_2flisting_2ecompiler_2flisting_3aSources_2eText(ptr %t98, ptr %v0, ptr %s3, ptr %t89, { i64, ptr } %t93, i64 %t97)
  store { i64, ptr } %t102, ptr %l44
  br label %bb19
bb19:
  %t103 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 0
  %t105 = extractvalue { i64, ptr } %t103, 1
  %t106 = mul i64 %t104, 1
  %t107 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t106)
  call void @llvm.memcpy.p0.p0.i64(ptr %t107, ptr %t105, i64 %t106, i1 false)
  %t108 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t107, 1
  %t111 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %s3, ptr %s3, { i64, ptr } %t109)
  store { i64, ptr } %t111, ptr %l46
  br label %bb20
bb20:
  %t112 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t112, 1
  %t114 = extractvalue { i64, ptr } %t112, 0
  %t115 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d107, i32 0, i32 1) }, 1
  %t116 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d107, i32 0, i32 1) }, 0
  %t117 = add i64 %t114, %t116
  %t118 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t118, 1
  %t120 = extractvalue { i64, ptr } %t118, 0
  %t121 = add i64 %t117, %t120
  %t122 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d108, i32 0, i32 1) }, 1
  %t123 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d108, i32 0, i32 1) }, 0
  %t124 = add i64 %t121, %t123
  %t125 = load i64, ptr %l37, !tbaa !24
  %t126 = call i64 @__olang_fmt_i64(ptr null, i64 %t125)
  %t127 = add i64 %t124, %t126
  %t128 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d109, i32 0, i32 1) }, 1
  %t129 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d109, i32 0, i32 1) }, 0
  %t130 = add i64 %t127, %t129
  %t131 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t131, 1
  %t133 = extractvalue { i64, ptr } %t131, 0
  %t134 = add i64 %t130, %t133
  %t135 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d110, i32 0, i32 1) }, 1
  %t136 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d110, i32 0, i32 1) }, 0
  %t137 = add i64 %t134, %t136
  %t138 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t137)
  call void @olang_textcopy(ptr %t138, ptr %t113, i64 %t114)
  %t139 = getelementptr i8, ptr %t138, i64 %t114
  call void @olang_textcopy(ptr %t139, ptr %t115, i64 %t116)
  %t140 = getelementptr i8, ptr %t139, i64 %t116
  call void @olang_textcopy(ptr %t140, ptr %t119, i64 %t120)
  %t141 = getelementptr i8, ptr %t140, i64 %t120
  call void @olang_textcopy(ptr %t141, ptr %t122, i64 %t123)
  %t142 = getelementptr i8, ptr %t141, i64 %t123
  %t143 = call i64 @__olang_fmt_i64(ptr %t142, i64 %t125)
  %t144 = getelementptr i8, ptr %t142, i64 %t126
  call void @olang_textcopy(ptr %t144, ptr %t128, i64 %t129)
  %t145 = getelementptr i8, ptr %t144, i64 %t129
  call void @olang_textcopy(ptr %t145, ptr %t132, i64 %t133)
  %t146 = getelementptr i8, ptr %t145, i64 %t133
  call void @olang_textcopy(ptr %t146, ptr %t135, i64 %t136)
  %t147 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t138, 1
  %t150 = extractvalue { i64, ptr } %t148, 0
  %t151 = extractvalue { i64, ptr } %t148, 1
  %t152 = mul i64 %t150, 1
  %t153 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t152)
  call void @llvm.memcpy.p0.p0.i64(ptr %t153, ptr %t151, i64 %t152, i1 false)
  %t154 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t153, 1
  %t156 = load ptr, ptr %l29, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s3, ptr %t156, { i64, ptr } %t155)
  br label %bb21
bb21:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/listing:Writer", ptr %t158, i32 0, i32 10
  store ptr %t160, ptr %l50, !tbaa !29
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/listing:Writer", ptr %t162, i32 0, i32 7
  %t165 = load { i64, ptr }, ptr %t164, !tbaa !27
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/listing:Writer", ptr %t166, i32 0, i32 9
  %t169 = load i64, ptr %t168, !tbaa !24
  %t171 = extractvalue { i64, ptr } %t165, 1
  %t172 = extractvalue { i64, ptr } %t165, 0
  %t173 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d111, i32 0, i32 1) }, 1
  %t174 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d111, i32 0, i32 1) }, 0
  %t175 = add i64 %t172, %t174
  %t177 = call i64 @__olang_fmt_i64(ptr null, i64 %t169)
  %t178 = add i64 %t175, %t177
  %t179 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t178)
  call void @olang_textcopy(ptr %t179, ptr %t171, i64 %t172)
  %t180 = getelementptr i8, ptr %t179, i64 %t172
  call void @olang_textcopy(ptr %t180, ptr %t173, i64 %t174)
  %t181 = getelementptr i8, ptr %t180, i64 %t174
  %t182 = call i64 @__olang_fmt_i64(ptr %t181, i64 %t169)
  %t183 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t179, 1
  %t186 = extractvalue { i64, ptr } %t184, 0
  %t187 = extractvalue { i64, ptr } %t184, 1
  %t188 = mul i64 %t186, 1
  %t189 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t188)
  call void @llvm.memcpy.p0.p0.i64(ptr %t189, ptr %t187, i64 %t188, i1 false)
  %t190 = insertvalue { i64, ptr } undef, i64 %t186, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr %t189, 1
  %t194 = call { i64, ptr } @compiler_2flisting_2ecompiler_2flisting_3aWriter_2eremarksAt(ptr %v0, ptr %s3, ptr %s3, ptr %s3, ptr %t161, { i64, ptr } %t191, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d112, i32 0, i32 1) })
  store { i64, ptr } %t194, ptr %l58
  br label %bb22
bb22:
  %t195 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t195, 0
  %t197 = extractvalue { i64, ptr } %t195, 1
  %t198 = mul i64 %t196, 1
  %t199 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t198)
  call void @llvm.memcpy.p0.p0.i64(ptr %t199, ptr %t197, i64 %t198, i1 false)
  %t200 = insertvalue { i64, ptr } undef, i64 %t196, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %t199, 1
  %t202 = load ptr, ptr %l50, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s3, ptr %t202, { i64, ptr } %t201)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb24:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/listing:Writer", ptr %t205, i32 0, i32 7
  %t208 = load { i64, ptr }, ptr %t207, !tbaa !27
  %t210 = extractvalue { i64, ptr } %t208, 1
  %t211 = extractvalue { i64, ptr } %t208, 0
  %t212 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t211)
  call void @olang_textcopy(ptr %t212, ptr %t210, i64 %t211)
  %t213 = insertvalue { i64, ptr } undef, i64 %t211, 0
  %t214 = insertvalue { i64, ptr } %t213, ptr %t212, 1
  %t216 = extractvalue { i64, ptr } %t214, 0
  %t217 = extractvalue { i64, ptr } %t214, 1
  %t218 = mul i64 %t216, 1
  %t219 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t218)
  call void @llvm.memcpy.p0.p0.i64(ptr %t219, ptr %t217, i64 %t218, i1 false)
  %t220 = insertvalue { i64, ptr } undef, i64 %t216, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr %t219, 1
  %t224 = getelementptr %"compiler/listing:Writer", ptr %t204, i32 0, i32 5
  store { i64, ptr } %t221, ptr %t224, !tbaa !27
  %t225 = load ptr, ptr %l0, !tbaa !29
  store ptr %t225, ptr %l65, !tbaa !29
  %t226 = load i1, ptr %l2, !tbaa !21
  br i1 %t226, label %bb25, label %bb26
bb25:
  store i64 0, ptr %l67, !tbaa !24
  br label %bb27
bb26:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/listing:Writer", ptr %t228, i32 0, i32 9
  %t231 = load i64, ptr %t230, !tbaa !24
  store i64 %t231, ptr %l67, !tbaa !24
  br label %bb27
bb27:
  %t233 = load i64, ptr %l67, !tbaa !24
  %t234 = load ptr, ptr %l65, !tbaa !29
  %t235 = getelementptr %"compiler/listing:Writer", ptr %t234, i32 0, i32 6
  store i64 %t233, ptr %t235, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flisting_2ecompiler_2flisting_3aWriter_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = extractvalue { i64, ptr } %a1, 1
  %t5 = extractvalue { i64, ptr } %a1, 0
  %t6 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t5)
  call void @olang_textcopy(ptr %t6, ptr %t4, i64 %t5)
  %t7 = insertvalue { i64, ptr } undef, i64 %t5, 0
  %t8 = insertvalue { i64, ptr } %t7, ptr %t6, 1
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t11 = extractvalue { i64, ptr } %t8, 1
  %t12 = mul i64 %t10, 1
  %t13 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t12)
  call void @llvm.memcpy.p0.p0.i64(ptr %t13, ptr %t11, i64 %t12, i1 false)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  %t18 = getelementptr %"compiler/listing:Writer", ptr %t1, i32 0, i32 7
  store { i64, ptr } %t15, ptr %t18, !tbaa !27
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t22 = extractvalue { i64, ptr } %a2, 1
  %t23 = extractvalue { i64, ptr } %a2, 0
  %t24 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t22, i64 %t23)
  %t25 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t29 = extractvalue { i64, ptr } %t26, 1
  %t30 = mul i64 %t28, 1
  %t31 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t30)
  call void @llvm.memcpy.p0.p0.i64(ptr %t31, ptr %t29, i64 %t30, i1 false)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  %t36 = getelementptr %"compiler/listing:Writer", ptr %t19, i32 0, i32 8
  store { i64, ptr } %t33, ptr %t36, !tbaa !27
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/listing:Writer", ptr %t37, i32 0, i32 9
  store i64 %a3, ptr %t41, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2flisting_2ecompiler_2flisting_3aWriter_2eremarksAt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/listing:Remark"
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"compiler/listing:Remark"
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca %"compiler/listing:Remark"
  %l18 = alloca i64
  %l22 = alloca i64
  %l24 = alloca i64
  %l29 = alloca %"compiler/listing:Remark"
  %l34 = alloca %"std/prelude/text:StringBuilder"
  %l37 = alloca i64
  %l39 = alloca i64
  %l45 = alloca %"compiler/listing:Remark"
  %l49 = alloca i1
  %l50 = alloca i1
  %l52 = alloca { i64, ptr }
  %l55 = alloca i1
  %l57 = alloca i1
  %l61 = alloca i1
  %l65 = alloca i64
  %l67 = alloca i64
  %l73 = alloca %"compiler/listing:Remark"
  %l76 = alloca i1
  %l77 = alloca i1
  %l81 = alloca i1
  %l82 = alloca i1
  %l86 = alloca i1
  %l95 = alloca ptr
  %l97 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l101 = alloca i64
  %l102 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l116 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/listing:Writer", ptr %t1, i32 0, i32 4
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l18
  br label %bb1
bb1:
  %t6 = load i64, ptr %l18, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/listing:Writer", ptr %t9, i32 0, i32 2
  %t12 = load ptr, ptr %t11, !tbaa !29
  store ptr %t12, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb4
bb3:
  br label %bb13
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t14 = load i64, ptr %l4, !tbaa !24
  store i64 %t14, ptr %l22, !tbaa !24
  %t15 = load ptr, ptr %l3, !tbaa !29
  %t16 = load ptr, ptr @__olang_prog_scope
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flisting_3aRemark_3e_2eLen_3ccompiler_2flisting_3aRemark_3e(ptr %t16, ptr %t15)
  store i64 %t18, ptr %l24
  br label %bb5
bb5:
  %t19 = load i64, ptr %l22, !tbaa !24
  %t20 = load i64, ptr %l24, !tbaa !24
  %t21 = icmp slt i64 %t19, %t20
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb7:
  br label %bb8
bb8:
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t26 = load i64, ptr %l4, !tbaa !24
  %t27 = load ptr, ptr @__olang_prog_scope
  %t30 = call %"compiler/listing:Remark" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flisting_3aRemark_3e_2eAt_3ccompiler_2flisting_3aRemark_3e(ptr %t27, ptr %s3, ptr %t25, i64 %t26)
  store %"compiler/listing:Remark" %t30, ptr %l29
  br label %bb9
bb9:
  %t31 = load %"compiler/listing:Remark", ptr %l29
  store %"compiler/listing:Remark" %t31, ptr %l5
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/listing:Writer", ptr %t32, i32 0, i32 4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t34, i1 false)
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb11
bb11:
  %t36 = load i64, ptr %l4, !tbaa !24
  %t38 = add i64 %t36, 1
  store i64 %t38, ptr %l4, !tbaa !24
  br label %bb4
bb12:
  br label %bb13
bb13:
  %t40 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t40, ptr %l34
  br label %bb14
bb14:
  %t41 = load %"std/prelude/text:StringBuilder", ptr %l34
  store %"std/prelude/text:StringBuilder" %t41, ptr %l6
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/listing:Writer", ptr %t42, i32 0, i32 2
  %t45 = load ptr, ptr %t44, !tbaa !29
  store ptr %t45, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s6
  %t47 = load i64, ptr %l8, !tbaa !24
  store i64 %t47, ptr %l37, !tbaa !24
  %t48 = load ptr, ptr %l7, !tbaa !29
  %t49 = load ptr, ptr @__olang_prog_scope
  %t51 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flisting_3aRemark_3e_2eLen_3ccompiler_2flisting_3aRemark_3e(ptr %t49, ptr %t48)
  store i64 %t51, ptr %l39
  br label %bb16
bb16:
  %t52 = load i64, ptr %l37, !tbaa !24
  %t53 = load i64, ptr %l39, !tbaa !24
  %t54 = icmp slt i64 %t52, %t53
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s6)
  br label %bb61
bb18:
  br label %bb19
bb19:
  %t58 = load i64, ptr %l8, !tbaa !24
  store i64 %t58, ptr %l9, !tbaa !24
  %t60 = load ptr, ptr %l7, !tbaa !29
  %t61 = load i64, ptr %l8, !tbaa !24
  %t62 = load ptr, ptr @__olang_prog_scope
  %t65 = call %"compiler/listing:Remark" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flisting_3aRemark_3e_2eAt_3ccompiler_2flisting_3aRemark_3e(ptr %t62, ptr %s6, ptr %t60, i64 %t61)
  store %"compiler/listing:Remark" %t65, ptr %l45
  br label %bb20
bb20:
  %t66 = load %"compiler/listing:Remark", ptr %l45
  store %"compiler/listing:Remark" %t66, ptr %l10
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/listing:Writer", ptr %t67, i32 0, i32 4
  %t70 = load i64, ptr %l9, !tbaa !24
  %t73 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t69, i64 %t70)
  store i1 %t73, ptr %l49
  br label %bb21
bb21:
  %t74 = load i1, ptr %l49, !tbaa !21
  br i1 %t74, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb26
bb23:
  %t76 = call { i64, ptr } @compiler_2flisting_2eplaceOf(ptr %s6, ptr %s6, ptr %l10)
  store { i64, ptr } %t76, ptr %l52
  br label %bb24
bb24:
  %t77 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t77, 0
  %t79 = extractvalue { i64, ptr } %t77, 1
  %t80 = mul i64 %t78, 1
  %t81 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t80)
  call void @llvm.memcpy.p0.p0.i64(ptr %t81, ptr %t79, i64 %t80, i1 false)
  %t82 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t81, 1
  %t87 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s6, ptr %v1, { i64, ptr } %t83, { i64, ptr } %a1)
  store i1 %t87, ptr %l55
  br label %bb25
bb25:
  %t88 = load i1, ptr %l55, !tbaa !21
  %t89 = xor i1 %t88, true
  store i1 %t89, ptr %l50, !tbaa !21
  br label %bb26
bb26:
  %t91 = load i1, ptr %l50, !tbaa !21
  br i1 %t91, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb30
bb28:
  %t92 = getelementptr %"compiler/listing:Remark", ptr %l10, i32 0, i32 5
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/listing:Writer", ptr %t94, i32 0, i32 3
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !27
  %t98 = load ptr, ptr @__olang_prog_scope
  %t101 = call i1 @compiler_2flisting_2eofAny(ptr %s6, ptr %t98, { i64, ptr } %t93, { i64, ptr } %t97)
  store i1 %t101, ptr %l61
  br label %bb29
bb29:
  %t102 = load i1, ptr %l61, !tbaa !21
  %t103 = xor i1 %t102, true
  store i1 %t103, ptr %l57, !tbaa !21
  br label %bb30
bb30:
  %t105 = load i1, ptr %l57, !tbaa !21
  br i1 %t105, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s6)
  br label %bb60
bb32:
  br label %bb33
bb33:
  store i64 0, ptr %l11, !tbaa !24
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/listing:Writer", ptr %t106, i32 0, i32 2
  %t109 = load ptr, ptr %t108, !tbaa !29
  store ptr %t109, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s9
  %t111 = load i64, ptr %l13, !tbaa !24
  store i64 %t111, ptr %l65, !tbaa !24
  %t112 = load ptr, ptr %l12, !tbaa !29
  %t113 = load ptr, ptr @__olang_prog_scope
  %t115 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flisting_3aRemark_3e_2eLen_3ccompiler_2flisting_3aRemark_3e(ptr %t113, ptr %t112)
  store i64 %t115, ptr %l67
  br label %bb35
bb35:
  %t116 = load i64, ptr %l65, !tbaa !24
  %t117 = load i64, ptr %l67, !tbaa !24
  %t118 = icmp slt i64 %t116, %t117
  %t120 = xor i1 %t118, true
  br i1 %t120, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s9)
  br label %bb54
bb37:
  br label %bb38
bb38:
  %t122 = load i64, ptr %l13, !tbaa !24
  store i64 %t122, ptr %l14, !tbaa !24
  %t124 = load ptr, ptr %l12, !tbaa !29
  %t125 = load i64, ptr %l13, !tbaa !24
  %t126 = load ptr, ptr @__olang_prog_scope
  %t129 = call %"compiler/listing:Remark" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flisting_3aRemark_3e_2eAt_3ccompiler_2flisting_3aRemark_3e(ptr %t126, ptr %s9, ptr %t124, i64 %t125)
  store %"compiler/listing:Remark" %t129, ptr %l73
  br label %bb39
bb39:
  %t130 = load %"compiler/listing:Remark", ptr %l73
  store %"compiler/listing:Remark" %t130, ptr %l15
  %t133 = call i1 @compiler_2flisting_2esame(ptr %s6, ptr %s9, ptr %l10, ptr %l15)
  store i1 %t133, ptr %l76
  br label %bb40
bb40:
  %t134 = load i1, ptr %l76, !tbaa !21
  br i1 %t134, label %bb41, label %bb42
bb41:
  %t135 = getelementptr %"compiler/listing:Remark", ptr %l15, i32 0, i32 5
  %t136 = load { i64, ptr }, ptr %t135, !tbaa !27
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/listing:Writer", ptr %t137, i32 0, i32 3
  %t140 = load { i64, ptr }, ptr %t139, !tbaa !27
  %t141 = load ptr, ptr @__olang_prog_scope
  %t144 = call i1 @compiler_2flisting_2eofAny(ptr %s9, ptr %t141, { i64, ptr } %t136, { i64, ptr } %t140)
  store i1 %t144, ptr %l81
  br label %bb43
bb42:
  store i1 false, ptr %l77, !tbaa !21
  br label %bb44
bb43:
  %t145 = load i1, ptr %l81, !tbaa !21
  store i1 %t145, ptr %l77, !tbaa !21
  br label %bb44
bb44:
  %t146 = load i1, ptr %l77, !tbaa !21
  br i1 %t146, label %bb45, label %bb46
bb45:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/listing:Writer", ptr %t147, i32 0, i32 4
  %t150 = load i64, ptr %l14, !tbaa !24
  %t153 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t149, i64 %t150)
  store i1 %t153, ptr %l86
  br label %bb47
bb46:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb48
bb47:
  %t154 = load i1, ptr %l86, !tbaa !21
  %t155 = xor i1 %t154, true
  store i1 %t155, ptr %l82, !tbaa !21
  br label %bb48
bb48:
  %t157 = load i1, ptr %l82, !tbaa !21
  br i1 %t157, label %bb49, label %bb50
bb49:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/listing:Writer", ptr %t158, i32 0, i32 4
  %t161 = load i64, ptr %l14, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t160, i64 %t161, i1 true)
  br label %bb51
bb50:
  br label %bb52
bb51:
  %t164 = load i64, ptr %l11, !tbaa !24
  %t166 = add i64 %t164, 1
  store i64 %t166, ptr %l11, !tbaa !24
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s9)
  br label %bb53
bb53:
  %t168 = load i64, ptr %l13, !tbaa !24
  %t170 = add i64 %t168, 1
  store i64 %t170, ptr %l13, !tbaa !24
  br label %bb34
bb54:
  store ptr %l6, ptr %l95, !tbaa !29
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"compiler/listing:Writer", ptr %t172, i32 0, i32 0
  %t175 = load { i64, ptr }, ptr %t174, !tbaa !27
  store { i64, ptr } %t175, ptr %l97, !tbaa !27
  store { i64, ptr } %a2, ptr %l98, !tbaa !27
  %t177 = getelementptr %"compiler/listing:Remark", ptr %l10, i32 0, i32 0
  %t178 = load { i64, ptr }, ptr %t177, !tbaa !27
  %t180 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadEnd(ptr %s6, ptr %s6, { i64, ptr } %t178, i64 9, i8 32)
  store { i64, ptr } %t180, ptr %l100
  br label %bb55
bb55:
  %t181 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t181, 0
  store i64 %t182, ptr %l101, !tbaa !24
  %t183 = load i64, ptr %l101, !tbaa !24
  %t184 = mul i64 %t183, 1
  %t185 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t184)
  %t186 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t185, 1
  store { i64, ptr } %t187, ptr %l102, !tbaa !27
  %t188 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = getelementptr { i64, ptr }, ptr %l100, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = load i64, ptr %l101, !tbaa !24
  %t193 = mul i64 %t192, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t189, ptr %t191, i64 %t193, i1 false)
  %t194 = getelementptr %"compiler/listing:Remark", ptr %l10, i32 0, i32 1
  %t195 = load { i64, ptr }, ptr %t194, !tbaa !27
  store { i64, ptr } %t195, ptr %l103, !tbaa !27
  %t196 = getelementptr %"compiler/listing:Remark", ptr %l10, i32 0, i32 7
  %t197 = load { i64, ptr }, ptr %t196, !tbaa !27
  store { i64, ptr } %t197, ptr %l104, !tbaa !27
  %t198 = load i64, ptr %l11, !tbaa !24
  %t200 = icmp sgt i64 %t198, 1
  br i1 %t200, label %bb56, label %bb57
bb56:
  %t202 = load i64, ptr %l11, !tbaa !24
  %t203 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d113, i32 0, i32 1) }, 1
  %t204 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d113, i32 0, i32 1) }, 0
  %t206 = call i64 @__olang_fmt_i64(ptr null, i64 %t202)
  %t207 = add i64 %t204, %t206
  %t208 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d114, i32 0, i32 1) }, 1
  %t209 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d114, i32 0, i32 1) }, 0
  %t210 = add i64 %t207, %t209
  %t211 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t210)
  call void @olang_textcopy(ptr %t211, ptr %t203, i64 %t204)
  %t212 = getelementptr i8, ptr %t211, i64 %t204
  %t213 = call i64 @__olang_fmt_i64(ptr %t212, i64 %t202)
  %t214 = getelementptr i8, ptr %t212, i64 %t206
  call void @olang_textcopy(ptr %t214, ptr %t208, i64 %t209)
  %t215 = insertvalue { i64, ptr } undef, i64 %t210, 0
  %t216 = insertvalue { i64, ptr } %t215, ptr %t211, 1
  %t218 = extractvalue { i64, ptr } %t216, 0
  %t219 = extractvalue { i64, ptr } %t216, 1
  %t220 = mul i64 %t218, 1
  %t221 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t220)
  call void @llvm.memcpy.p0.p0.i64(ptr %t221, ptr %t219, i64 %t220, i1 false)
  %t222 = insertvalue { i64, ptr } undef, i64 %t218, 0
  %t223 = insertvalue { i64, ptr } %t222, ptr %t221, 1
  store { i64, ptr } %t223, ptr %l107, !tbaa !27
  br label %bb58
bb57:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d115, i32 0, i32 1) }, ptr %l107, !tbaa !27
  br label %bb58
bb58:
  %t225 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t226 = extractvalue { i64, ptr } %t225, 1
  %t227 = extractvalue { i64, ptr } %t225, 0
  %t228 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t229 = extractvalue { i64, ptr } %t228, 1
  %t230 = extractvalue { i64, ptr } %t228, 0
  %t231 = add i64 %t227, %t230
  %t232 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t233 = extractvalue { i64, ptr } %t232, 1
  %t234 = extractvalue { i64, ptr } %t232, 0
  %t235 = add i64 %t231, %t234
  %t236 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t237 = extractvalue { i64, ptr } %t236, 1
  %t238 = extractvalue { i64, ptr } %t236, 0
  %t239 = add i64 %t235, %t238
  %t240 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d116, i32 0, i32 1) }, 1
  %t241 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d116, i32 0, i32 1) }, 0
  %t242 = add i64 %t239, %t241
  %t243 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t244 = extractvalue { i64, ptr } %t243, 1
  %t245 = extractvalue { i64, ptr } %t243, 0
  %t246 = add i64 %t242, %t245
  %t247 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t248 = extractvalue { i64, ptr } %t247, 1
  %t249 = extractvalue { i64, ptr } %t247, 0
  %t250 = add i64 %t246, %t249
  %t251 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d117, i32 0, i32 1) }, 1
  %t252 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d117, i32 0, i32 1) }, 0
  %t253 = add i64 %t250, %t252
  %t254 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t253)
  call void @olang_textcopy(ptr %t254, ptr %t226, i64 %t227)
  %t255 = getelementptr i8, ptr %t254, i64 %t227
  call void @olang_textcopy(ptr %t255, ptr %t229, i64 %t230)
  %t256 = getelementptr i8, ptr %t255, i64 %t230
  call void @olang_textcopy(ptr %t256, ptr %t233, i64 %t234)
  %t257 = getelementptr i8, ptr %t256, i64 %t234
  call void @olang_textcopy(ptr %t257, ptr %t237, i64 %t238)
  %t258 = getelementptr i8, ptr %t257, i64 %t238
  call void @olang_textcopy(ptr %t258, ptr %t240, i64 %t241)
  %t259 = getelementptr i8, ptr %t258, i64 %t241
  call void @olang_textcopy(ptr %t259, ptr %t244, i64 %t245)
  %t260 = getelementptr i8, ptr %t259, i64 %t245
  call void @olang_textcopy(ptr %t260, ptr %t248, i64 %t249)
  %t261 = getelementptr i8, ptr %t260, i64 %t249
  call void @olang_textcopy(ptr %t261, ptr %t251, i64 %t252)
  %t262 = insertvalue { i64, ptr } undef, i64 %t253, 0
  %t263 = insertvalue { i64, ptr } %t262, ptr %t254, 1
  %t265 = extractvalue { i64, ptr } %t263, 0
  %t266 = extractvalue { i64, ptr } %t263, 1
  %t267 = mul i64 %t265, 1
  %t268 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t267)
  call void @llvm.memcpy.p0.p0.i64(ptr %t268, ptr %t266, i64 %t267, i1 false)
  %t269 = insertvalue { i64, ptr } undef, i64 %t265, 0
  %t270 = insertvalue { i64, ptr } %t269, ptr %t268, 1
  %t271 = load ptr, ptr %l95, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %t271, { i64, ptr } %t270)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s6)
  br label %bb60
bb60:
  %t273 = load i64, ptr %l8, !tbaa !24
  %t275 = add i64 %t273, 1
  store i64 %t275, ptr %l8, !tbaa !24
  br label %bb15
bb61:
  %t278 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v3, ptr %l6)
  store { i64, ptr } %t278, ptr %l116
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s0)
  %t279 = load { i64, ptr }, ptr %l116, !tbaa !27
  store { i64, ptr } %t279, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2flisting_2edefinedIn(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca %"std/prelude/text:LineIter"
  %l4 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/text:LineIter"
  %l7 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l12 = alloca i1
  %l14 = alloca i1
  %l16 = alloca i1
  %l17 = alloca i1
  %l20 = alloca i1
  %l24 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i1
  %l33 = alloca { i64, ptr }
  %l34 = alloca i1
  %l36 = alloca { i64, ptr }
  %l39 = alloca i1
  %l44 = alloca i1
  %l45 = alloca i1
  %l50 = alloca i1
  %l51 = alloca i1
  %l56 = alloca i1
  %l61 = alloca i1
  %l63 = alloca { i64, ptr }
  %l67 = alloca i1
  %l69 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l73 = alloca i64
  %l75 = alloca { i64, ptr }
  %l78 = alloca i64
  %l79 = alloca i64
  %l84 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l88 = alloca i64
  %l89 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store %"std/prelude/text:LineIter" %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load %"std/prelude/text:LineIter", ptr %l6
  store %"std/prelude/text:LineIter" %t4, ptr %l3
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t6 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v0, ptr %l3)
  %t7 = extractvalue { i32, { i64, ptr } } %t6, 1
  %t8 = extractvalue { i32, { i64, ptr } } %t6, 0
  store i32 %t8, ptr %l10
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb4, label %ok.10, !prof !99
ok.10:
  store { i64, ptr } %t7, ptr %l9
  br label %bb3
bb3:
  %t11 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t11, ptr %l7, !tbaa !27
  br label %bb6
bb4:
  %t12 = load i32, ptr %l10, !tbaa !23
  %t13 = ashr i32 %t12, 16
  %t15 = icmp eq i32 %t13, 1
  store i1 %t15, ptr %l12, !tbaa !21
  br label %bb5
bb5:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb63
bb6:
  %t16 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t16, ptr %l4, !tbaa !27
  %t17 = load i1, ptr %l2, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  %t19 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t21 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t19, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d118, i32 0, i32 1) })
  store i1 %t21, ptr %l16
  br label %bb9
bb8:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb10
bb9:
  %t22 = load i1, ptr %l16, !tbaa !21
  store i1 %t22, ptr %l14, !tbaa !21
  br label %bb10
bb10:
  %t23 = load i1, ptr %l14, !tbaa !21
  br i1 %t23, label %bb11, label %bb12
bb11:
  %t24 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t28 = call i1 @compiler_2flisting_2eirDefines(ptr %v0, ptr %v1, { i64, ptr } %t24, { i64, ptr } %t25)
  store i1 %t28, ptr %l20
  br label %bb13
bb12:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb14
bb13:
  %t29 = load i1, ptr %l20, !tbaa !21
  store i1 %t29, ptr %l17, !tbaa !21
  br label %bb14
bb14:
  %t30 = load i1, ptr %l17, !tbaa !21
  br i1 %t30, label %bb15, label %bb16
bb15:
  %t31 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 1
  %t34 = extractvalue { i64, ptr } %t31, 0
  %t35 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t34)
  call void @olang_textcopy(ptr %t35, ptr %t33, i64 %t34)
  %t36 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  call void @__olang_scope_close(ptr %s2)
  store { i64, ptr } %t37, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t39 = load i1, ptr %l2, !tbaa !21
  br i1 %t39, label %bb18, label %bb19
bb18:
  %t41 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t43 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d119, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d119, i32 0, i32 1) }, 0
  %t46 = extractvalue { i64, ptr } %t42, 1
  %t47 = extractvalue { i64, ptr } %t42, 0
  %t48 = add i64 %t44, %t47
  %t49 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d120, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d120, i32 0, i32 1) }, 0
  %t51 = add i64 %t48, %t50
  %t52 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t51)
  call void @olang_textcopy(ptr %t52, ptr %t43, i64 %t44)
  %t53 = getelementptr i8, ptr %t52, i64 %t44
  call void @olang_textcopy(ptr %t53, ptr %t46, i64 %t47)
  %t54 = getelementptr i8, ptr %t53, i64 %t47
  call void @olang_textcopy(ptr %t54, ptr %t49, i64 %t50)
  %t55 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t52, 1
  %t58 = extractvalue { i64, ptr } %t56, 0
  %t59 = extractvalue { i64, ptr } %t56, 1
  %t60 = mul i64 %t58, 1
  %t61 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t60)
  call void @llvm.memcpy.p0.p0.i64(ptr %t61, ptr %t59, i64 %t60, i1 false)
  %t62 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t61, 1
  %t66 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t41, { i64, ptr } %t63)
  store i1 %t66, ptr %l29
  br label %bb20
bb19:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb21
bb20:
  %t67 = load i1, ptr %l29, !tbaa !21
  store i1 %t67, ptr %l24, !tbaa !21
  br label %bb21
bb21:
  %t68 = load i1, ptr %l24, !tbaa !21
  br i1 %t68, label %bb22, label %bb23
bb22:
  %t69 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d121, i32 0, i32 1) }, ptr %l33, !tbaa !27
  %t72 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t73 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s2, { i64, ptr } %t69, { i64, ptr } %t72)
  store i1 %t73, ptr %l34
  br label %bb24
bb23:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb25
bb24:
  %t74 = load i1, ptr %l34, !tbaa !21
  store i1 %t74, ptr %l30, !tbaa !21
  br label %bb25
bb25:
  %t75 = load i1, ptr %l30, !tbaa !21
  br i1 %t75, label %bb26, label %bb27
bb26:
  %t76 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t78 = call { i64, ptr } @compiler_2flisting_2ealiasee(ptr %v0, ptr %v2, { i64, ptr } %t76)
  store { i64, ptr } %t78, ptr %l36
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_scope_close(ptr %s2)
  %t79 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t79, ptr %rv
  br label %ret
bb29:
  %t80 = load i1, ptr %l2, !tbaa !21
  %t82 = xor i1 %t80, true
  br i1 %t82, label %bb30, label %bb31
bb30:
  %t84 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t85, 1
  %t88 = extractvalue { i64, ptr } %t85, 0
  %t89 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t88)
  call void @olang_textcopy(ptr %t89, ptr %t87, i64 %t88)
  %t90 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  %t93 = extractvalue { i64, ptr } %t91, 0
  %t94 = extractvalue { i64, ptr } %t91, 1
  %t95 = mul i64 %t93, 1
  %t96 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t95)
  call void @llvm.memcpy.p0.p0.i64(ptr %t96, ptr %t94, i64 %t95, i1 false)
  %t97 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t96, 1
  %t101 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t84, { i64, ptr } %t98)
  store i1 %t101, ptr %l44
  br label %bb32
bb31:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb33
bb32:
  %t102 = load i1, ptr %l44, !tbaa !21
  store i1 %t102, ptr %l39, !tbaa !21
  br label %bb33
bb33:
  %t103 = load i1, ptr %l39, !tbaa !21
  br i1 %t103, label %bb34, label %bb35
bb34:
  %t104 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t105, 1
  %t108 = extractvalue { i64, ptr } %t105, 0
  %t109 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d122, i32 0, i32 1) }, 1
  %t110 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d122, i32 0, i32 1) }, 0
  %t111 = add i64 %t108, %t110
  %t112 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t111)
  call void @olang_textcopy(ptr %t112, ptr %t107, i64 %t108)
  %t113 = getelementptr i8, ptr %t112, i64 %t108
  call void @olang_textcopy(ptr %t113, ptr %t109, i64 %t110)
  %t114 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t112, 1
  %t117 = extractvalue { i64, ptr } %t115, 0
  %t118 = extractvalue { i64, ptr } %t115, 1
  %t119 = mul i64 %t117, 1
  %t120 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t119)
  call void @llvm.memcpy.p0.p0.i64(ptr %t120, ptr %t118, i64 %t119, i1 false)
  %t121 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t120, 1
  %t125 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t104, { i64, ptr } %t122)
  store i1 %t125, ptr %l50
  br label %bb36
bb35:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb41
bb36:
  %t126 = load i1, ptr %l50, !tbaa !21
  br i1 %t126, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb40
bb38:
  %t127 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t128 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t128, 1
  %t131 = extractvalue { i64, ptr } %t128, 0
  %t132 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d123, i32 0, i32 1) }, 1
  %t133 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d123, i32 0, i32 1) }, 0
  %t134 = add i64 %t131, %t133
  %t135 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t134)
  call void @olang_textcopy(ptr %t135, ptr %t130, i64 %t131)
  %t136 = getelementptr i8, ptr %t135, i64 %t131
  call void @olang_textcopy(ptr %t136, ptr %t132, i64 %t133)
  %t137 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t135, 1
  %t140 = extractvalue { i64, ptr } %t138, 0
  %t141 = extractvalue { i64, ptr } %t138, 1
  %t142 = mul i64 %t140, 1
  %t143 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t142)
  call void @llvm.memcpy.p0.p0.i64(ptr %t143, ptr %t141, i64 %t142, i1 false)
  %t144 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t143, 1
  %t148 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t127, { i64, ptr } %t145)
  store i1 %t148, ptr %l56
  br label %bb39
bb39:
  %t149 = load i1, ptr %l56, !tbaa !21
  store i1 %t149, ptr %l51, !tbaa !21
  br label %bb40
bb40:
  %t150 = load i1, ptr %l51, !tbaa !21
  store i1 %t150, ptr %l45, !tbaa !21
  br label %bb41
bb41:
  %t151 = load i1, ptr %l45, !tbaa !21
  br i1 %t151, label %bb42, label %bb43
bb42:
  %t152 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t154 = extractvalue { i64, ptr } %t152, 1
  %t155 = extractvalue { i64, ptr } %t152, 0
  %t156 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t155)
  call void @olang_textcopy(ptr %t156, ptr %t154, i64 %t155)
  %t157 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t156, 1
  call void @__olang_scope_close(ptr %s2)
  store { i64, ptr } %t158, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  %t160 = load i1, ptr %l2, !tbaa !21
  %t162 = xor i1 %t160, true
  br i1 %t162, label %bb45, label %bb46
bb45:
  %t164 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t166 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v0, { i64, ptr } %t164)
  store { i64, ptr } %t166, ptr %l63
  br label %bb47
bb46:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb49
bb47:
  %t167 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t168 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d124, i32 0, i32 1) }, 1
  %t169 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d124, i32 0, i32 1) }, 0
  %t171 = extractvalue { i64, ptr } %t167, 1
  %t172 = extractvalue { i64, ptr } %t167, 0
  %t173 = add i64 %t169, %t172
  %t174 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d125, i32 0, i32 1) }, 1
  %t175 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d125, i32 0, i32 1) }, 0
  %t176 = add i64 %t173, %t175
  %t177 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t176)
  call void @olang_textcopy(ptr %t177, ptr %t168, i64 %t169)
  %t178 = getelementptr i8, ptr %t177, i64 %t169
  call void @olang_textcopy(ptr %t178, ptr %t171, i64 %t172)
  %t179 = getelementptr i8, ptr %t178, i64 %t172
  call void @olang_textcopy(ptr %t179, ptr %t174, i64 %t175)
  %t180 = insertvalue { i64, ptr } undef, i64 %t176, 0
  %t181 = insertvalue { i64, ptr } %t180, ptr %t177, 1
  %t183 = extractvalue { i64, ptr } %t181, 0
  %t184 = extractvalue { i64, ptr } %t181, 1
  %t185 = mul i64 %t183, 1
  %t186 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t185)
  call void @llvm.memcpy.p0.p0.i64(ptr %t186, ptr %t184, i64 %t185, i1 false)
  %t187 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t186, 1
  %t189 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t191 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t189, { i64, ptr } %t188)
  store i1 %t191, ptr %l67
  br label %bb48
bb48:
  %t192 = load i1, ptr %l67, !tbaa !21
  store i1 %t192, ptr %l61, !tbaa !21
  br label %bb49
bb49:
  %t193 = load i1, ptr %l61, !tbaa !21
  br i1 %t193, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s13
  %t194 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t196 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v0, { i64, ptr } %t194)
  store { i64, ptr } %t196, ptr %l69
  br label %bb52
bb51:
  br label %bb61
bb52:
  %t197 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t197, ptr %l70, !tbaa !27
  %t198 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t200 = extractvalue { i64, ptr } %t198, 0
  %t202 = add i64 %t200, 7
  store i64 %t202, ptr %l73, !tbaa !24
  %t203 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t205 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v0, { i64, ptr } %t203)
  store { i64, ptr } %t205, ptr %l75
  br label %bb53
bb53:
  %t206 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t209 = extractvalue { i64, ptr } %t206, 0
  store i64 %t209, ptr %l78, !tbaa !24
  %t210 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t210, 0
  store i64 %t211, ptr %l79, !tbaa !24
  %t212 = load i64, ptr %l73, !tbaa !24
  %t213 = icmp sge i64 %t212, 0
  br i1 %t213, label %bb54, label %bb55
bb54:
  %t215 = load i64, ptr %l73, !tbaa !24
  %t216 = load i64, ptr %l78, !tbaa !24
  %t217 = icmp sle i64 %t215, %t216
  br i1 %t217, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_5a79b11f9a8ea358_a6600b1bb9cded74)
  unreachable
bb56:
  %t219 = load i64, ptr %l78, !tbaa !24
  %t220 = load i64, ptr %l79, !tbaa !24
  %t221 = icmp sle i64 %t219, %t220
  br i1 %t221, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_5a79b11f9a8ea358_a6600b1bb9cded74)
  unreachable
bb58:
  %t223 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !27
  %t225 = load i64, ptr %l73, !tbaa !24
  %t226 = load i64, ptr %l78, !tbaa !24
  %t227 = getelementptr i8, ptr %t224, i64 %t225
  %t228 = sub i64 %t226, %t225
  %t229 = insertvalue { i64, ptr } undef, i64 %t228, 0
  %t230 = insertvalue { i64, ptr } %t229, ptr %t227, 1
  %t232 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %s13, { i64, ptr } %t230)
  store { i64, ptr } %t232, ptr %l84
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_5a79b11f9a8ea358_a6600b1bb9cded74)
  unreachable
bb60:
  %t233 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t234 = extractvalue { i64, ptr } %t233, 1
  %t235 = extractvalue { i64, ptr } %t233, 0
  %t236 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t235)
  call void @olang_textcopy(ptr %t236, ptr %t234, i64 %t235)
  %t237 = insertvalue { i64, ptr } undef, i64 %t235, 0
  %t238 = insertvalue { i64, ptr } %t237, ptr %t236, 1
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s2)
  store { i64, ptr } %t238, ptr %rv
  br label %ret
bb61:
  call void @__olang_scope_close(ptr %s2)
  br label %bb62
bb62:
  br label %bb2
bb63:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d126, i32 0, i32 1) }, ptr %l86, !tbaa !27
  %t240 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t240, ptr %l87, !tbaa !27
  %t241 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t242 = extractvalue { i64, ptr } %t241, 0
  store i64 %t242, ptr %l88, !tbaa !24
  %t243 = load i64, ptr %l88, !tbaa !24
  %t244 = mul i64 %t243, 1
  %t245 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t244)
  %t246 = insertvalue { i64, ptr } undef, i64 %t243, 0
  %t247 = insertvalue { i64, ptr } %t246, ptr %t245, 1
  store { i64, ptr } %t247, ptr %l89, !tbaa !27
  %t248 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !27
  %t250 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !27
  %t252 = load i64, ptr %l88, !tbaa !24
  %t253 = mul i64 %t252, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t249, ptr %t251, i64 %t253, i1 false)
  %t254 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t254, ptr %l87, !tbaa !27
  %t255 = load { i64, ptr }, ptr %l87, !tbaa !27
  store { i64, ptr } %t255, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2flisting_2efield(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i8
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l25 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l35 = alloca i1
  %l36 = alloca i1
  %l38 = alloca i1
  %l39 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l51 = alloca i1
  %l54 = alloca i1
  %l60 = alloca i1
  %l61 = alloca { i64, ptr }
  %l66 = alloca i64
  %l69 = alloca i1
  %l70 = alloca { i64, ptr }
  %l75 = alloca i64
  %l77 = alloca { i64, ptr }
  %l82 = alloca i64
  %l86 = alloca i64
  %l91 = alloca { i64, ptr }
  %l92 = alloca i64
  %l94 = alloca i64
  %l95 = alloca i32
  %l98 = alloca i64
  %l100 = alloca i64
  %l101 = alloca i32
  %l104 = alloca { i64, ptr }
  %l105 = alloca i64
  %l106 = alloca i64
  %l111 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t2, 1
  %t5 = extractvalue { i64, ptr } %t2, 0
  %t6 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d127, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d127, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t9 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t8)
  call void @olang_textcopy(ptr %t9, ptr %t4, i64 %t5)
  %t10 = getelementptr i8, ptr %t9, i64 %t5
  call void @olang_textcopy(ptr %t10, ptr %t6, i64 %t7)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t9, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t15 = extractvalue { i64, ptr } %t12, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  %t22 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } %t19)
  %t23 = extractvalue { i32, i64 } %t22, 1
  %t24 = extractvalue { i32, i64 } %t22, 0
  store i32 %t24, ptr %l13
  %t25 = icmp ne i32 %t24, 0
  br i1 %t25, label %bb2, label %ok.26, !prof !99
ok.26:
  store i64 %t23, ptr %l12
  br label %bb1
bb1:
  %t27 = load i64, ptr %l12, !tbaa !24
  store i64 %t27, ptr %l7, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  %t28 = load i64, ptr %l7, !tbaa !24
  store i64 %t28, ptr %l2, !tbaa !24
  %t29 = load i64, ptr %l2, !tbaa !24
  %t31 = icmp slt i64 %t29, 0
  br i1 %t31, label %bb5, label %bb6
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d128, i32 0, i32 1) }, ptr %l16, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t33, ptr %l17, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  store i64 %t35, ptr %l18, !tbaa !24
  %t36 = load i64, ptr %l18, !tbaa !24
  %t37 = mul i64 %t36, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t37)
  %t39 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  store { i64, ptr } %t40, ptr %l19, !tbaa !27
  %t41 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = load i64, ptr %l18, !tbaa !24
  %t46 = mul i64 %t45, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t42, ptr %t44, i64 %t46, i1 false)
  %t47 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t47, ptr %l17, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t48 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t48, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t49 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t49, ptr %l20, !tbaa !27
  %t50 = load i64, ptr %l2, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t51, 0
  %t56 = add i64 %t50, %t53
  %t58 = add i64 %t56, 2
  store i64 %t58, ptr %l25, !tbaa !24
  %t59 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t59, 0
  store i64 %t62, ptr %l28, !tbaa !24
  %t63 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 0
  store i64 %t64, ptr %l29, !tbaa !24
  %t65 = load i64, ptr %l25, !tbaa !24
  %t66 = icmp sge i64 %t65, 0
  br i1 %t66, label %bb8, label %bb9
bb8:
  %t68 = load i64, ptr %l25, !tbaa !24
  %t69 = load i64, ptr %l28, !tbaa !24
  %t70 = icmp sle i64 %t68, %t69
  br i1 %t70, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_6afa1fda02b1904e_762f30cdf4bfe02)
  unreachable
bb10:
  %t72 = load i64, ptr %l28, !tbaa !24
  %t73 = load i64, ptr %l29, !tbaa !24
  %t74 = icmp sle i64 %t72, %t73
  br i1 %t74, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_6afa1fda02b1904e_762f30cdf4bfe02)
  unreachable
bb12:
  %t76 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = load i64, ptr %l25, !tbaa !24
  %t79 = load i64, ptr %l28, !tbaa !24
  %t80 = getelementptr i8, ptr %t77, i64 %t78
  %t81 = sub i64 %t79, %t78
  %t82 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t80, 1
  store { i64, ptr } %t83, ptr %l3, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t87 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t85, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d129, i32 0, i32 1) })
  store i1 %t87, ptr %l35
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_6afa1fda02b1904e_762f30cdf4bfe02)
  unreachable
bb14:
  %t88 = load i1, ptr %l35, !tbaa !21
  br i1 %t88, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb18
bb16:
  %t89 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t91 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t89, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d130, i32 0, i32 1) })
  store i1 %t91, ptr %l38
  br label %bb17
bb17:
  %t92 = load i1, ptr %l38, !tbaa !21
  store i1 %t92, ptr %l36, !tbaa !21
  br label %bb18
bb18:
  %t93 = load i1, ptr %l36, !tbaa !21
  br i1 %t93, label %bb19, label %bb20
bb19:
  %t94 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t94, ptr %l39, !tbaa !27
  %t95 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr i8, ptr %t96, i64 0
  %t98 = load i8, ptr %t97, !tbaa !32
  store i8 %t98, ptr %l4, !tbaa !22
  store i64 1, ptr %l5, !tbaa !24
  br label %bb21
bb20:
  br label %bb55
bb21:
  %t100 = load i64, ptr %l5, !tbaa !24
  %t101 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t101, 0
  %t106 = icmp slt i64 %t100, %t103
  %t108 = xor i1 %t106, true
  br i1 %t108, label %bb22, label %bb23
bb22:
  br label %bb44
bb23:
  br label %bb24
bb24:
  %t110 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t110, ptr %l46, !tbaa !27
  %t111 = load i64, ptr %l5, !tbaa !24
  %t113 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr i8, ptr %t114, i64 %t111
  %t116 = load i8, ptr %t115, !tbaa !32
  %t117 = load i8, ptr %l4, !tbaa !22
  %t120 = icmp eq i8 %t116, %t117
  br i1 %t120, label %bb25, label %bb26
bb25:
  %t122 = load i8, ptr %l4, !tbaa !22
  %t124 = icmp ne i8 %t122, 39
  br i1 %t124, label %bb27, label %bb28
bb26:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb33
bb27:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb29
bb28:
  %t126 = load i64, ptr %l5, !tbaa !24
  %t128 = add i64 %t126, 1
  %t129 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t129, 0
  %t134 = icmp sge i64 %t128, %t131
  store i1 %t134, ptr %l54, !tbaa !21
  br label %bb29
bb29:
  %t136 = load i1, ptr %l54, !tbaa !21
  br i1 %t136, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb32
bb31:
  %t137 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t137, ptr %l61, !tbaa !27
  %t138 = load i64, ptr %l5, !tbaa !24
  %t140 = add i64 %t138, 1
  %t142 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr i8, ptr %t143, i64 %t140
  %t145 = load i8, ptr %t144, !tbaa !32
  %t147 = icmp ne i8 %t145, 39
  store i1 %t147, ptr %l60, !tbaa !21
  br label %bb32
bb32:
  %t149 = load i1, ptr %l60, !tbaa !21
  store i1 %t149, ptr %l51, !tbaa !21
  br label %bb33
bb33:
  %t150 = load i1, ptr %l51, !tbaa !21
  br i1 %t150, label %bb34, label %bb35
bb34:
  br label %bb44
bb35:
  br label %bb36
bb36:
  %t151 = load i64, ptr %l5, !tbaa !24
  store i64 %t151, ptr %l66, !tbaa !24
  %t152 = load i8, ptr %l4, !tbaa !22
  %t154 = icmp eq i8 %t152, 39
  br i1 %t154, label %bb37, label %bb38
bb37:
  %t156 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t156, ptr %l70, !tbaa !27
  %t157 = load i64, ptr %l5, !tbaa !24
  %t159 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr i8, ptr %t160, i64 %t157
  %t162 = load i8, ptr %t161, !tbaa !32
  %t163 = load i8, ptr %l4, !tbaa !22
  %t166 = icmp eq i8 %t162, %t163
  store i1 %t166, ptr %l69, !tbaa !21
  br label %bb39
bb38:
  store i1 false, ptr %l69, !tbaa !21
  br label %bb39
bb39:
  %t168 = load i1, ptr %l69, !tbaa !21
  br i1 %t168, label %bb40, label %bb41
bb40:
  store i64 2, ptr %l75, !tbaa !24
  br label %bb42
bb41:
  store i64 1, ptr %l75, !tbaa !24
  br label %bb42
bb42:
  %t169 = load i64, ptr %l66, !tbaa !24
  %t170 = load i64, ptr %l75, !tbaa !24
  %t171 = add i64 %t169, %t170
  store i64 %t171, ptr %l5, !tbaa !24
  br label %bb43
bb43:
  br label %bb21
bb44:
  %t173 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t173, ptr %l77, !tbaa !27
  %t174 = load i64, ptr %l5, !tbaa !24
  %t175 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t175, 0
  %t180 = icmp slt i64 %t174, %t177
  br i1 %t180, label %bb45, label %bb46
bb45:
  %t182 = load i64, ptr %l5, !tbaa !24
  %t184 = add i64 %t182, 1
  store i64 %t184, ptr %l82, !tbaa !24
  br label %bb47
bb46:
  %t186 = load i64, ptr %l5, !tbaa !24
  store i64 %t186, ptr %l82, !tbaa !24
  br label %bb47
bb47:
  %t188 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t188, 0
  store i64 %t189, ptr %l86, !tbaa !24
  %t190 = icmp sge i64 0, 0
  br i1 %t190, label %bb48, label %bb49
bb48:
  %t192 = load i64, ptr %l82, !tbaa !24
  %t193 = icmp sle i64 0, %t192
  br i1 %t193, label %bb50, label %bb51
bb49:
  call void @__olang_check_failed(ptr @olang_loc_a32004acca342e4b_53d1fb3a96a10aff)
  unreachable
bb50:
  %t195 = load i64, ptr %l82, !tbaa !24
  %t196 = load i64, ptr %l86, !tbaa !24
  %t197 = icmp sle i64 %t195, %t196
  br i1 %t197, label %bb52, label %bb53
bb51:
  call void @__olang_check_failed(ptr @olang_loc_a32004acca342e4b_53d1fb3a96a10aff)
  unreachable
bb52:
  %t199 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !27
  %t201 = load i64, ptr %l82, !tbaa !24
  %t202 = getelementptr i8, ptr %t200, i64 0
  %t203 = sub i64 %t201, 0
  %t204 = insertvalue { i64, ptr } undef, i64 %t203, 0
  %t205 = insertvalue { i64, ptr } %t204, ptr %t202, 1
  %t207 = call { i64, ptr } @compiler_2flisting_2eunquote(ptr %v0, ptr %v2, { i64, ptr } %t205)
  store { i64, ptr } %t207, ptr %l91
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_a32004acca342e4b_53d1fb3a96a10aff)
  unreachable
bb54:
  call void @__olang_scope_close(ptr %s0)
  %t208 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t208, ptr %rv
  br label %ret
bb55:
  %t209 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t211 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s0, { i64, ptr } %t209, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d131, i32 0, i32 1) })
  %t212 = extractvalue { i32, i64 } %t211, 1
  %t213 = extractvalue { i32, i64 } %t211, 0
  store i32 %t213, ptr %l95
  %t214 = icmp ne i32 %t213, 0
  br i1 %t214, label %bb57, label %ok.215, !prof !99
ok.215:
  store i64 %t212, ptr %l94
  br label %bb56
bb56:
  %t216 = load i64, ptr %l94, !tbaa !24
  store i64 %t216, ptr %l92, !tbaa !24
  br label %bb59
bb57:
  br label %bb58
bb58:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l92, !tbaa !24
  br label %bb59
bb59:
  %t217 = load i64, ptr %l92, !tbaa !24
  store i64 %t217, ptr %l6, !tbaa !24
  %t218 = load i64, ptr %l6, !tbaa !24
  %t220 = icmp slt i64 %t218, 0
  br i1 %t220, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s6
  %t222 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t224 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s6, { i64, ptr } %t222, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d132, i32 0, i32 1) })
  %t225 = extractvalue { i32, i64 } %t224, 1
  %t226 = extractvalue { i32, i64 } %t224, 0
  store i32 %t226, ptr %l101
  %t227 = icmp ne i32 %t226, 0
  br i1 %t227, label %bb63, label %ok.228, !prof !99
ok.228:
  store i64 %t225, ptr %l100
  br label %bb62
bb61:
  br label %bb66
bb62:
  %t229 = load i64, ptr %l100, !tbaa !24
  store i64 %t229, ptr %l98, !tbaa !24
  br label %bb65
bb63:
  br label %bb64
bb64:
  call void @__olang_ert_req_clear()
  %t230 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t230, 0
  store i64 %t232, ptr %l98, !tbaa !24
  br label %bb65
bb65:
  %t234 = load i64, ptr %l98, !tbaa !24
  store i64 %t234, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb66
bb66:
  %t235 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t235, ptr %l104, !tbaa !27
  %t236 = load i64, ptr %l6, !tbaa !24
  store i64 %t236, ptr %l105, !tbaa !24
  %t237 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t238 = extractvalue { i64, ptr } %t237, 0
  store i64 %t238, ptr %l106, !tbaa !24
  %t239 = icmp sge i64 0, 0
  br i1 %t239, label %bb67, label %bb68
bb67:
  %t241 = load i64, ptr %l105, !tbaa !24
  %t242 = icmp sle i64 0, %t241
  br i1 %t242, label %bb69, label %bb70
bb68:
  call void @__olang_check_failed(ptr @olang_loc_f323dd54c7e2a5d0_8d4c3c3918b6d694)
  unreachable
bb69:
  %t244 = load i64, ptr %l105, !tbaa !24
  %t245 = load i64, ptr %l106, !tbaa !24
  %t246 = icmp sle i64 %t244, %t245
  br i1 %t246, label %bb71, label %bb72
bb70:
  call void @__olang_check_failed(ptr @olang_loc_f323dd54c7e2a5d0_8d4c3c3918b6d694)
  unreachable
bb71:
  %t248 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !27
  %t250 = load i64, ptr %l105, !tbaa !24
  %t251 = getelementptr i8, ptr %t249, i64 0
  %t252 = sub i64 %t250, 0
  %t253 = insertvalue { i64, ptr } undef, i64 %t252, 0
  %t254 = insertvalue { i64, ptr } %t253, ptr %t251, 1
  %t256 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %s0, { i64, ptr } %t254)
  store { i64, ptr } %t256, ptr %l111
  br label %bb73
bb72:
  call void @__olang_check_failed(ptr @olang_loc_f323dd54c7e2a5d0_8d4c3c3918b6d694)
  unreachable
bb73:
  %t257 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t258 = extractvalue { i64, ptr } %t257, 1
  %t259 = extractvalue { i64, ptr } %t257, 0
  %t260 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t259)
  call void @olang_textcopy(ptr %t260, ptr %t258, i64 %t259)
  %t261 = insertvalue { i64, ptr } undef, i64 %t259, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t260, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t262, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2flisting_2efileLine(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l26 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i32
  %l32 = alloca i1
  %l35 = alloca i1
  %l39 = alloca i64
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca i64
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca i32
  %l54 = alloca i64
  %l55 = alloca i32
  %l58 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l59 = alloca { i64, ptr }
  %l60 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l71 = alloca { i64, ptr }
  %l72 = alloca i1
  %l73 = alloca i1
  %l75 = alloca i64
  %l78 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i32
  %l82 = alloca i64
  %l83 = alloca { i64, ptr }
  %l85 = alloca i64
  %l88 = alloca i64
  %l89 = alloca i64
  %l94 = alloca i64
  %l95 = alloca i32
  %l98 = alloca ptr
  %l99 = alloca { i64, ptr }
  %l101 = alloca i64
  %l105 = alloca i64
  %l106 = alloca i64
  %l113 = alloca { i64, ptr }
  %l117 = alloca i64
  %l120 = alloca i64
  %l121 = alloca i64
  %l127 = alloca i64
  %l129 = alloca ptr
  %l130 = alloca i64
  %l131 = alloca ptr
  %l133 = alloca i64
  %l135 = alloca { i64, ptr }
  %l138 = alloca ptr
  %l139 = alloca i64
  %l141 = alloca i64
  %l143 = alloca { i64, ptr }
  %l145 = alloca { i64, ptr }
  %l147 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l12, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t2, 0
  store i64 %t5, ptr %l15, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l16, !tbaa !24
  %t8 = icmp sge i64 5, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i64, ptr %l15, !tbaa !24
  %t11 = icmp sle i64 5, %t10
  br i1 %t11, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_2238304466d31cdc_a18281d53071ef08)
  unreachable
bb3:
  %t13 = load i64, ptr %l15, !tbaa !24
  %t14 = load i64, ptr %l16, !tbaa !24
  %t15 = icmp sle i64 %t13, %t14
  br i1 %t15, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_2238304466d31cdc_a18281d53071ef08)
  unreachable
bb5:
  %t17 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l15, !tbaa !24
  %t20 = getelementptr i8, ptr %t18, i64 5
  %t21 = sub i64 %t19, 5
  %t22 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t20, 1
  %t25 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v0, { i64, ptr } %t23)
  store { i64, ptr } %t25, ptr %l21
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_2238304466d31cdc_a18281d53071ef08)
  unreachable
bb7:
  %t26 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t26, ptr %l3, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t29 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s0, { i64, ptr } %t27, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d133, i32 0, i32 1) })
  %t30 = extractvalue { i32, i64 } %t29, 1
  %t31 = extractvalue { i32, i64 } %t29, 0
  store i32 %t31, ptr %l25
  %t32 = icmp ne i32 %t31, 0
  br i1 %t32, label %bb9, label %ok.33, !prof !99
ok.33:
  store i64 %t30, ptr %l24
  br label %bb8
bb8:
  %t34 = load i64, ptr %l24, !tbaa !24
  store i64 %t34, ptr %l22, !tbaa !24
  br label %bb11
bb9:
  br label %bb10
bb10:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l22, !tbaa !24
  br label %bb11
bb11:
  %t35 = load i64, ptr %l22, !tbaa !24
  store i64 %t35, ptr %l4, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t38 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s0, { i64, ptr } %t36, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d134, i32 0, i32 1) })
  %t39 = extractvalue { i32, i64 } %t38, 1
  %t40 = extractvalue { i32, i64 } %t38, 0
  store i32 %t40, ptr %l29
  %t41 = icmp ne i32 %t40, 0
  br i1 %t41, label %bb13, label %ok.42, !prof !99
ok.42:
  store i64 %t39, ptr %l28
  br label %bb12
bb12:
  %t43 = load i64, ptr %l28, !tbaa !24
  store i64 %t43, ptr %l26, !tbaa !24
  br label %bb15
bb13:
  br label %bb14
bb14:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l26, !tbaa !24
  br label %bb15
bb15:
  %t44 = load i64, ptr %l26, !tbaa !24
  store i64 %t44, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t47 = icmp sge i64 %t45, 0
  br i1 %t47, label %bb16, label %bb17
bb16:
  %t49 = load i64, ptr %l5, !tbaa !24
  %t51 = icmp slt i64 %t49, 0
  br i1 %t51, label %bb18, label %bb19
bb17:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb21
bb18:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb20
bb19:
  %t53 = load i64, ptr %l4, !tbaa !24
  %t54 = load i64, ptr %l5, !tbaa !24
  %t57 = icmp slt i64 %t53, %t54
  store i1 %t57, ptr %l35, !tbaa !21
  br label %bb20
bb20:
  %t59 = load i1, ptr %l35, !tbaa !21
  store i1 %t59, ptr %l32, !tbaa !21
  br label %bb21
bb21:
  %t60 = load i1, ptr %l32, !tbaa !21
  br i1 %t60, label %bb22, label %bb23
bb22:
  %t61 = load i64, ptr %l4, !tbaa !24
  store i64 %t61, ptr %l39, !tbaa !24
  br label %bb24
bb23:
  %t63 = load i64, ptr %l5, !tbaa !24
  store i64 %t63, ptr %l39, !tbaa !24
  br label %bb24
bb24:
  %t65 = load i64, ptr %l39, !tbaa !24
  store i64 %t65, ptr %l6, !tbaa !24
  %t66 = load i64, ptr %l6, !tbaa !24
  %t68 = icmp slt i64 %t66, 0
  br i1 %t68, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb26:
  br label %bb27
bb27:
  %t70 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t70, ptr %l45, !tbaa !27
  %t71 = load i64, ptr %l6, !tbaa !24
  store i64 %t71, ptr %l46, !tbaa !24
  %t72 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 0
  store i64 %t73, ptr %l47, !tbaa !24
  %t74 = icmp sge i64 0, 0
  br i1 %t74, label %bb28, label %bb29
bb28:
  %t76 = load i64, ptr %l46, !tbaa !24
  %t77 = icmp sle i64 0, %t76
  br i1 %t77, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_a0e57960875e3249_f03c8e9377147565)
  unreachable
bb30:
  %t79 = load i64, ptr %l46, !tbaa !24
  %t80 = load i64, ptr %l47, !tbaa !24
  %t81 = icmp sle i64 %t79, %t80
  br i1 %t81, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_a0e57960875e3249_f03c8e9377147565)
  unreachable
bb32:
  %t83 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = load i64, ptr %l46, !tbaa !24
  %t86 = getelementptr i8, ptr %t84, i64 0
  %t87 = sub i64 %t85, 0
  %t88 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t86, 1
  store { i64, ptr } %t89, ptr %l51, !tbaa !27
  %t90 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 10)
  %t91 = extractvalue { i32, i64 } %t90, 1
  %t92 = extractvalue { i32, i64 } %t90, 0
  store i32 %t92, ptr %l53
  %t93 = icmp ne i32 %t92, 0
  br i1 %t93, label %bb35, label %ok.94, !prof !99
ok.94:
  store i64 %t91, ptr %l52
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_a0e57960875e3249_f03c8e9377147565)
  unreachable
bb34:
  %t95 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t96 = load i64, ptr %l52, !tbaa !24
  %t97 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %t95, i64 %t96)
  %t98 = extractvalue { i32, i64 } %t97, 1
  %t99 = extractvalue { i32, i64 } %t97, 0
  store i32 %t99, ptr %l55
  %t100 = icmp ne i32 %t99, 0
  br i1 %t100, label %bb38, label %ok.101, !prof !99
ok.101:
  store i64 %t98, ptr %l54
  br label %bb37
bb35:
  br label %bb36
bb36:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l44, !tbaa !24
  br label %bb39
bb37:
  %t102 = load i64, ptr %l54, !tbaa !24
  store i64 %t102, ptr %l44, !tbaa !24
  br label %bb39
bb38:
  br label %bb36
bb39:
  %t103 = load i64, ptr %l44, !tbaa !24
  store i64 %t103, ptr %l7, !tbaa !24
  %t104 = load i64, ptr %l7, !tbaa !24
  %t106 = icmp slt i64 %t104, 0
  br i1 %t106, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb41:
  br label %bb42
bb42:
  %t108 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t108, ptr %l58
  br label %bb43
bb43:
  %t109 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l58
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t109, ptr %l8
  %t110 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t110, ptr %l59, !tbaa !27
  %t111 = load i64, ptr %l6, !tbaa !24
  store i64 %t111, ptr %l60, !tbaa !24
  %t112 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t112, 0
  store i64 %t115, ptr %l63, !tbaa !24
  %t116 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t116, 0
  store i64 %t117, ptr %l64, !tbaa !24
  %t118 = load i64, ptr %l60, !tbaa !24
  %t119 = icmp sge i64 %t118, 0
  br i1 %t119, label %bb44, label %bb45
bb44:
  %t121 = load i64, ptr %l60, !tbaa !24
  %t122 = load i64, ptr %l63, !tbaa !24
  %t123 = icmp sle i64 %t121, %t122
  br i1 %t123, label %bb46, label %bb47
bb45:
  call void @__olang_check_failed(ptr @olang_loc_96c24661ddd014aa_b59c706e032d6c46)
  unreachable
bb46:
  %t125 = load i64, ptr %l63, !tbaa !24
  %t126 = load i64, ptr %l64, !tbaa !24
  %t127 = icmp sle i64 %t125, %t126
  br i1 %t127, label %bb48, label %bb49
bb47:
  call void @__olang_check_failed(ptr @olang_loc_96c24661ddd014aa_b59c706e032d6c46)
  unreachable
bb48:
  %t129 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = load i64, ptr %l60, !tbaa !24
  %t132 = load i64, ptr %l63, !tbaa !24
  %t133 = getelementptr i8, ptr %t130, i64 %t131
  %t134 = sub i64 %t132, %t131
  %t135 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t133, 1
  store { i64, ptr } %t136, ptr %l9, !tbaa !27
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_96c24661ddd014aa_b59c706e032d6c46)
  unreachable
bb50:
  store %olang.scope zeroinitializer, ptr %s3
  %t138 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d135, i32 0, i32 1) }, ptr %l71, !tbaa !27
  %t141 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t142 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s3, { i64, ptr } %t138, { i64, ptr } %t141)
  store i1 %t142, ptr %l72
  br label %bb51
bb51:
  %t143 = load i1, ptr %l72, !tbaa !21
  br i1 %t143, label %bb52, label %bb53
bb52:
  %t145 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l8)
  store i64 %t145, ptr %l75
  br label %bb54
bb53:
  store i1 false, ptr %l73, !tbaa !21
  br label %bb55
bb54:
  %t146 = load i64, ptr %l75, !tbaa !24
  %t147 = icmp slt i64 %t146, 2
  store i1 %t147, ptr %l73, !tbaa !21
  br label %bb55
bb55:
  %t149 = load i1, ptr %l73, !tbaa !21
  %t150 = xor i1 %t149, true
  br i1 %t150, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s3)
  br label %bb90
bb57:
  br label %bb58
bb58:
  %t152 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t154 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s3, { i64, ptr } %t152, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d136, i32 0, i32 1) })
  %t155 = extractvalue { i32, i64 } %t154, 1
  %t156 = extractvalue { i32, i64 } %t154, 0
  store i32 %t156, ptr %l81
  %t157 = icmp ne i32 %t156, 0
  br i1 %t157, label %bb60, label %ok.158, !prof !99
ok.158:
  store i64 %t155, ptr %l80
  br label %bb59
bb59:
  %t159 = load i64, ptr %l80, !tbaa !24
  store i64 %t159, ptr %l78, !tbaa !24
  br label %bb62
bb60:
  br label %bb61
bb61:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l78, !tbaa !24
  br label %bb62
bb62:
  %t160 = load i64, ptr %l78, !tbaa !24
  store i64 %t160, ptr %l10, !tbaa !24
  %t161 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t161, ptr %l83, !tbaa !27
  %t162 = load i64, ptr %l10, !tbaa !24
  %t164 = add i64 %t162, 1
  store i64 %t164, ptr %l85, !tbaa !24
  %t165 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t165, 0
  store i64 %t168, ptr %l88, !tbaa !24
  %t169 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t169, 0
  store i64 %t170, ptr %l89, !tbaa !24
  %t171 = load i64, ptr %l85, !tbaa !24
  %t172 = icmp sge i64 %t171, 0
  br i1 %t172, label %bb63, label %bb64
bb63:
  %t174 = load i64, ptr %l85, !tbaa !24
  %t175 = load i64, ptr %l88, !tbaa !24
  %t176 = icmp sle i64 %t174, %t175
  br i1 %t176, label %bb65, label %bb66
bb64:
  call void @__olang_check_failed(ptr @olang_loc_5830759408577a87_15470f09e840e423)
  unreachable
bb65:
  %t178 = load i64, ptr %l88, !tbaa !24
  %t179 = load i64, ptr %l89, !tbaa !24
  %t180 = icmp sle i64 %t178, %t179
  br i1 %t180, label %bb67, label %bb68
bb66:
  call void @__olang_check_failed(ptr @olang_loc_5830759408577a87_15470f09e840e423)
  unreachable
bb67:
  %t182 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !27
  %t184 = load i64, ptr %l85, !tbaa !24
  %t185 = load i64, ptr %l88, !tbaa !24
  %t186 = getelementptr i8, ptr %t183, i64 %t184
  %t187 = sub i64 %t185, %t184
  %t188 = insertvalue { i64, ptr } undef, i64 %t187, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t186, 1
  %t191 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s3, { i64, ptr } %t189, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d137, i32 0, i32 1) })
  %t192 = extractvalue { i32, i64 } %t191, 1
  %t193 = extractvalue { i32, i64 } %t191, 0
  store i32 %t193, ptr %l95
  %t194 = icmp ne i32 %t193, 0
  br i1 %t194, label %bb70, label %ok.195, !prof !99
ok.195:
  store i64 %t192, ptr %l94
  br label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_5830759408577a87_15470f09e840e423)
  unreachable
bb69:
  %t196 = load i64, ptr %l94, !tbaa !24
  store i64 %t196, ptr %l82, !tbaa !24
  br label %bb72
bb70:
  br label %bb71
bb71:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l82, !tbaa !24
  br label %bb72
bb72:
  %t197 = load i64, ptr %l82, !tbaa !24
  store i64 %t197, ptr %l11, !tbaa !24
  %t198 = load i64, ptr %l11, !tbaa !24
  %t200 = icmp slt i64 %t198, 0
  br i1 %t200, label %bb73, label %bb74
bb73:
  call void @__olang_scope_close(ptr %s3)
  br label %bb90
bb74:
  br label %bb75
bb75:
  store ptr %l8, ptr %l98, !tbaa !29
  %t202 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t202, ptr %l99, !tbaa !27
  %t203 = load i64, ptr %l10, !tbaa !24
  %t205 = add i64 %t203, 1
  store i64 %t205, ptr %l101, !tbaa !24
  %t206 = load i64, ptr %l10, !tbaa !24
  %t208 = add i64 %t206, 1
  %t209 = load i64, ptr %l11, !tbaa !24
  %t212 = add i64 %t208, %t209
  store i64 %t212, ptr %l105, !tbaa !24
  %t213 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t214 = extractvalue { i64, ptr } %t213, 0
  store i64 %t214, ptr %l106, !tbaa !24
  %t215 = load i64, ptr %l101, !tbaa !24
  %t216 = icmp sge i64 %t215, 0
  br i1 %t216, label %bb76, label %bb77
bb76:
  %t218 = load i64, ptr %l101, !tbaa !24
  %t219 = load i64, ptr %l105, !tbaa !24
  %t220 = icmp sle i64 %t218, %t219
  br i1 %t220, label %bb78, label %bb79
bb77:
  call void @__olang_check_failed(ptr @olang_loc_89a4da7eaed16d48_97b863eee78c099c)
  unreachable
bb78:
  %t222 = load i64, ptr %l105, !tbaa !24
  %t223 = load i64, ptr %l106, !tbaa !24
  %t224 = icmp sle i64 %t222, %t223
  br i1 %t224, label %bb80, label %bb81
bb79:
  call void @__olang_check_failed(ptr @olang_loc_89a4da7eaed16d48_97b863eee78c099c)
  unreachable
bb80:
  %t226 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !27
  %t228 = load i64, ptr %l101, !tbaa !24
  %t229 = load i64, ptr %l105, !tbaa !24
  %t230 = getelementptr i8, ptr %t227, i64 %t228
  %t231 = sub i64 %t229, %t228
  %t232 = insertvalue { i64, ptr } undef, i64 %t231, 0
  %t233 = insertvalue { i64, ptr } %t232, ptr %t230, 1
  %t235 = extractvalue { i64, ptr } %t233, 1
  %t236 = extractvalue { i64, ptr } %t233, 0
  %t237 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t236)
  call void @olang_textcopy(ptr %t237, ptr %t235, i64 %t236)
  %t238 = insertvalue { i64, ptr } undef, i64 %t236, 0
  %t239 = insertvalue { i64, ptr } %t238, ptr %t237, 1
  %t241 = extractvalue { i64, ptr } %t239, 0
  %t242 = extractvalue { i64, ptr } %t239, 1
  %t243 = mul i64 %t241, 1
  %t244 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t243)
  call void @llvm.memcpy.p0.p0.i64(ptr %t244, ptr %t242, i64 %t243, i1 false)
  %t245 = insertvalue { i64, ptr } undef, i64 %t241, 0
  %t246 = insertvalue { i64, ptr } %t245, ptr %t244, 1
  %t247 = load ptr, ptr %l98, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t247, { i64, ptr } %t246)
  br label %bb82
bb81:
  call void @__olang_check_failed(ptr @olang_loc_89a4da7eaed16d48_97b863eee78c099c)
  unreachable
bb82:
  %t249 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t249, ptr %l113, !tbaa !27
  %t250 = load i64, ptr %l10, !tbaa !24
  %t252 = add i64 %t250, 2
  %t253 = load i64, ptr %l11, !tbaa !24
  %t256 = add i64 %t252, %t253
  store i64 %t256, ptr %l117, !tbaa !24
  %t257 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t260 = extractvalue { i64, ptr } %t257, 0
  store i64 %t260, ptr %l120, !tbaa !24
  %t261 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t262 = extractvalue { i64, ptr } %t261, 0
  store i64 %t262, ptr %l121, !tbaa !24
  %t263 = load i64, ptr %l117, !tbaa !24
  %t264 = icmp sge i64 %t263, 0
  br i1 %t264, label %bb83, label %bb84
bb83:
  %t266 = load i64, ptr %l117, !tbaa !24
  %t267 = load i64, ptr %l120, !tbaa !24
  %t268 = icmp sle i64 %t266, %t267
  br i1 %t268, label %bb85, label %bb86
bb84:
  call void @__olang_check_failed(ptr @olang_loc_4256a3bf93089da5_22d14aef181c0709)
  unreachable
bb85:
  %t270 = load i64, ptr %l120, !tbaa !24
  %t271 = load i64, ptr %l121, !tbaa !24
  %t272 = icmp sle i64 %t270, %t271
  br i1 %t272, label %bb87, label %bb88
bb86:
  call void @__olang_check_failed(ptr @olang_loc_4256a3bf93089da5_22d14aef181c0709)
  unreachable
bb87:
  %t274 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t275 = load ptr, ptr %t274, !tbaa !27
  %t276 = load i64, ptr %l117, !tbaa !24
  %t277 = load i64, ptr %l120, !tbaa !24
  %t278 = getelementptr i8, ptr %t275, i64 %t276
  %t279 = sub i64 %t277, %t276
  %t280 = insertvalue { i64, ptr } undef, i64 %t279, 0
  %t281 = insertvalue { i64, ptr } %t280, ptr %t278, 1
  store { i64, ptr } %t281, ptr %l9, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  br label %bb89
bb88:
  call void @__olang_check_failed(ptr @olang_loc_4256a3bf93089da5_22d14aef181c0709)
  unreachable
bb89:
  br label %bb50
bb90:
  %t284 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l8)
  store i64 %t284, ptr %l127
  br label %bb91
bb91:
  %t285 = load i64, ptr %l127, !tbaa !24
  %t286 = icmp eq i64 %t285, 0
  br i1 %t286, label %bb92, label %bb93
bb92:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb93:
  br label %bb94
bb94:
  store ptr %a1, ptr %l129, !tbaa !29
  %t289 = load i64, ptr %l7, !tbaa !24
  store i64 %t289, ptr %l130, !tbaa !24
  store ptr %l8, ptr %l131, !tbaa !29
  %t291 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l8)
  store i64 %t291, ptr %l133
  br label %bb95
bb95:
  %t292 = load i64, ptr %l133, !tbaa !24
  %t293 = sub i64 %t292, 1
  %t294 = load ptr, ptr %l131, !tbaa !29
  %t296 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t294, i64 %t293)
  store { i64, ptr } %t296, ptr %l135
  br label %bb96
bb96:
  %t297 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t298 = extractvalue { i64, ptr } %t297, 1
  %t299 = extractvalue { i64, ptr } %t297, 0
  %t300 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t299)
  call void @olang_textcopy(ptr %t300, ptr %t298, i64 %t299)
  %t301 = insertvalue { i64, ptr } undef, i64 %t299, 0
  %t302 = insertvalue { i64, ptr } %t301, ptr %t300, 1
  %t304 = extractvalue { i64, ptr } %t302, 0
  %t305 = extractvalue { i64, ptr } %t302, 1
  %t306 = mul i64 %t304, 1
  %t307 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t306)
  call void @llvm.memcpy.p0.p0.i64(ptr %t307, ptr %t305, i64 %t306, i1 false)
  %t308 = insertvalue { i64, ptr } undef, i64 %t304, 0
  %t309 = insertvalue { i64, ptr } %t308, ptr %t307, 1
  %t310 = load ptr, ptr %l129, !tbaa !29
  %t311 = load i64, ptr %l130, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Hc3dff1927e5c626a9d95abfdf4e9a462(ptr %v1, ptr %v1, ptr %t310, i64 %t311, { i64, ptr } %t309)
  br label %bb97
bb97:
  store ptr %a2, ptr %l138, !tbaa !29
  %t314 = load i64, ptr %l7, !tbaa !24
  store i64 %t314, ptr %l139, !tbaa !24
  %t316 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l8)
  store i64 %t316, ptr %l141
  br label %bb98
bb98:
  %t317 = load i64, ptr %l141, !tbaa !24
  %t318 = icmp eq i64 %t317, 2
  br i1 %t318, label %bb99, label %bb100
bb99:
  %t321 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l8, i64 0)
  store { i64, ptr } %t321, ptr %l145
  br label %bb101
bb100:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d138, i32 0, i32 1) }, ptr %l147, !tbaa !27
  %t322 = load { i64, ptr }, ptr %l147, !tbaa !27
  store { i64, ptr } %t322, ptr %l143, !tbaa !27
  br label %bb102
bb101:
  %t324 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t325 = extractvalue { i64, ptr } %t324, 1
  %t326 = extractvalue { i64, ptr } %t324, 0
  %t327 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t326)
  call void @olang_textcopy(ptr %t327, ptr %t325, i64 %t326)
  %t328 = insertvalue { i64, ptr } undef, i64 %t326, 0
  %t329 = insertvalue { i64, ptr } %t328, ptr %t327, 1
  store { i64, ptr } %t329, ptr %l143, !tbaa !27
  br label %bb102
bb102:
  %t331 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t332 = extractvalue { i64, ptr } %t331, 0
  %t333 = extractvalue { i64, ptr } %t331, 1
  %t334 = mul i64 %t332, 1
  %t335 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t334)
  call void @llvm.memcpy.p0.p0.i64(ptr %t335, ptr %t333, i64 %t334, i1 false)
  %t336 = insertvalue { i64, ptr } undef, i64 %t332, 0
  %t337 = insertvalue { i64, ptr } %t336, ptr %t335, 1
  %t338 = load ptr, ptr %l138, !tbaa !29
  %t339 = load i64, ptr %l139, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Hc3dff1927e5c626a9d95abfdf4e9a462(ptr %v2, ptr %v2, ptr %t338, i64 %t339, { i64, ptr } %t337)
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2flisting_2efound(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca i64
  %lp6 = alloca ptr
  %l8 = alloca i64
  %l10 = alloca i64
  %l15 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l21 = alloca i1
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t3 = load i64, ptr %l4, !tbaa !24
  store i64 %t3, ptr %l8, !tbaa !24
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t4)
  store i64 %t6, ptr %l10
  br label %bb2
bb2:
  %t7 = load i64, ptr %l8, !tbaa !24
  %t8 = load i64, ptr %l10, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l3, !tbaa !29
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t13, i64 %t14)
  store { i64, ptr } %t17, ptr %l15
  br label %bb6
bb6:
  %t18 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t25 = call { i64, ptr } @compiler_2flisting_2edefinedIn(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %t18, { i64, ptr } %a1, i1 %a2)
  store { i64, ptr } %t25, ptr %l19
  br label %bb7
bb7:
  %t26 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t26, ptr %lp6
  %t27 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t28 = load ptr, ptr %lp6
  store { i64, ptr } %t27, ptr %t28, !tbaa !27
  %t29 = load ptr, ptr %lp6
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  %t32 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s2, { i64, ptr } %t30, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d139, i32 0, i32 1) })
  store i1 %t32, ptr %l21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l21, !tbaa !21
  %t34 = xor i1 %t33, true
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t36 = load ptr, ptr %lp6
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  store { i64, ptr } %t37, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb12:
  %t39 = load i64, ptr %l4, !tbaa !24
  %t41 = add i64 %t39, 1
  store i64 %t41, ptr %l4, !tbaa !24
  br label %bb1
bb13:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d140, i32 0, i32 1) }, ptr %l26, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t43, ptr %l27, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t44, 0
  store i64 %t45, ptr %l28, !tbaa !24
  %t46 = load i64, ptr %l28, !tbaa !24
  %t47 = mul i64 %t46, 1
  %t48 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  store { i64, ptr } %t50, ptr %l29, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = load i64, ptr %l28, !tbaa !24
  %t56 = mul i64 %t55, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t52, ptr %t54, i64 %t56, i1 false)
  %t57 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t57, ptr %l27, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t58, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2flisting_2ehow(ptr %v0, ptr %v1, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  br i1 %a1, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d141, i32 0, i32 1) }, ptr %l5, !tbaa !27
  br label %bb3
bb2:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/build:Config", ptr %t3, i32 0, i32 2
  %t6 = getelementptr %"compiler/target:Target", ptr %t5, i32 0, i32 2
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 1
  %t10 = extractvalue { i64, ptr } %t7, 0
  %t11 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d142, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d142, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t14 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t13)
  call void @olang_textcopy(ptr %t14, ptr %t9, i64 %t10)
  %t15 = getelementptr i8, ptr %t14, i64 %t10
  call void @olang_textcopy(ptr %t15, ptr %t11, i64 %t12)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t14, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  store { i64, ptr } %t24, ptr %l5, !tbaa !27
  br label %bb3
bb3:
  %t26 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t26, ptr %l2, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/build:Config", ptr %t27, i32 0, i32 5
  %t30 = load i1, ptr %t29, !tbaa !21
  br i1 %t30, label %bb4, label %bb5
bb4:
  store { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d143, i32 0, i32 1) }, ptr %l12, !tbaa !27
  br label %bb6
bb5:
  store { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d144, i32 0, i32 1) }, ptr %l12, !tbaa !27
  br label %bb6
bb6:
  %t32 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/build:Config", ptr %t35, i32 0, i32 2
  %t38 = getelementptr %"compiler/target:Target", ptr %t37, i32 0, i32 4
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t33, 1
  %t42 = extractvalue { i64, ptr } %t33, 0
  %t43 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d145, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d145, i32 0, i32 1) }, 0
  %t45 = add i64 %t42, %t44
  %t47 = extractvalue { i64, ptr } %t32, 1
  %t48 = extractvalue { i64, ptr } %t32, 0
  %t49 = add i64 %t45, %t48
  %t50 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d146, i32 0, i32 1) }, 1
  %t51 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d146, i32 0, i32 1) }, 0
  %t52 = add i64 %t49, %t51
  %t54 = extractvalue { i64, ptr } %t39, 1
  %t55 = extractvalue { i64, ptr } %t39, 0
  %t56 = add i64 %t52, %t55
  %t57 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t41, i64 %t42)
  %t58 = getelementptr i8, ptr %t57, i64 %t42
  call void @olang_textcopy(ptr %t58, ptr %t43, i64 %t44)
  %t59 = getelementptr i8, ptr %t58, i64 %t44
  call void @olang_textcopy(ptr %t59, ptr %t47, i64 %t48)
  %t60 = getelementptr i8, ptr %t59, i64 %t48
  call void @olang_textcopy(ptr %t60, ptr %t50, i64 %t51)
  %t61 = getelementptr i8, ptr %t60, i64 %t51
  call void @olang_textcopy(ptr %t61, ptr %t54, i64 %t55)
  %t62 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t57, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t63, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2flisting_2einstance(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca %"std/prelude/text:StringBuilder"
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca { i64, ptr }
  %l46 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l64 = alloca i64
  %l65 = alloca { i64, ptr }
  %l67 = alloca i1
  %l68 = alloca i1
  %l70 = alloca i64
  %l73 = alloca ptr
  %l75 = alloca i64
  %l77 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l86 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l89 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l91 = alloca i64
  %l93 = alloca ptr
  %l98 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l104 = alloca i1
  %l105 = alloca { i64, ptr }
  %l106 = alloca ptr
  %l108 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l112 = alloca i64
  %l114 = alloca ptr
  %l116 = alloca { i64, ptr }
  %l119 = alloca ptr
  %l121 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l126 = alloca i64
  %l129 = alloca i1
  %l136 = alloca { i64, ptr }
  %l142 = alloca ptr
  %l143 = alloca ptr
  %l144 = alloca { i64, ptr }
  %l145 = alloca { i64, ptr }
  %l147 = alloca { i64, ptr }
  %l151 = alloca { i64, ptr }
  %l154 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l12
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l12
  store %"std/prelude/text:StringBuilder" %t2, ptr %l5
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/listing:Inputs", ptr %t3, i32 0, i32 3
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  store { i64, ptr } %t6, ptr %l6, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/build:Code", ptr %t9, i32 0, i32 0
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t8, 1
  %t15 = extractvalue { i64, ptr } %t8, 0
  %t16 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d147, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d147, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t20 = extractvalue { i64, ptr } %t12, 1
  %t21 = extractvalue { i64, ptr } %t12, 0
  %t22 = add i64 %t18, %t21
  %t23 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d148, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d148, i32 0, i32 1) }, 0
  %t25 = add i64 %t22, %t24
  %t26 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t25)
  call void @olang_textcopy(ptr %t26, ptr %t14, i64 %t15)
  %t27 = getelementptr i8, ptr %t26, i64 %t15
  call void @olang_textcopy(ptr %t27, ptr %t16, i64 %t17)
  %t28 = getelementptr i8, ptr %t27, i64 %t17
  call void @olang_textcopy(ptr %t28, ptr %t20, i64 %t21)
  %t29 = getelementptr i8, ptr %t28, i64 %t21
  call void @olang_textcopy(ptr %t29, ptr %t23, i64 %t24)
  %t30 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t26, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l5, { i64, ptr } %t38)
  br label %bb2
bb2:
  store ptr %l5, ptr %l21, !tbaa !29
  %t41 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t41, ptr %l22, !tbaa !27
  %t42 = load ptr, ptr %l4, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr %"compiler/build:Code", ptr %t43, i32 0, i32 1
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  %t49 = call { i64, ptr } @compiler_2flisting_2ecompiler_2flisting_3aSources_2eShown(ptr %v4, ptr %v1, ptr %s0, ptr %t42, { i64, ptr } %t46)
  store { i64, ptr } %t49, ptr %l26
  br label %bb3
bb3:
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr %"compiler/build:Code", ptr %t50, i32 0, i32 2
  %t53 = load i64, ptr %t52, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/listing:Inputs", ptr %t54, i32 0, i32 2
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t58, 1
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t61 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d149, i32 0, i32 1) }, 1
  %t62 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d149, i32 0, i32 1) }, 0
  %t63 = add i64 %t60, %t62
  %t64 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 1
  %t66 = extractvalue { i64, ptr } %t64, 0
  %t67 = add i64 %t63, %t66
  %t68 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d150, i32 0, i32 1) }, 1
  %t69 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d150, i32 0, i32 1) }, 0
  %t70 = add i64 %t67, %t69
  %t72 = call i64 @__olang_fmt_i64(ptr null, i64 %t53)
  %t73 = add i64 %t70, %t72
  %t74 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d151, i32 0, i32 1) }, 1
  %t75 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d151, i32 0, i32 1) }, 0
  %t76 = add i64 %t73, %t75
  %t78 = extractvalue { i64, ptr } %t57, 1
  %t79 = extractvalue { i64, ptr } %t57, 0
  %t80 = add i64 %t76, %t79
  %t81 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d152, i32 0, i32 1) }, 1
  %t82 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d152, i32 0, i32 1) }, 0
  %t83 = add i64 %t80, %t82
  %t84 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t83)
  call void @olang_textcopy(ptr %t84, ptr %t59, i64 %t60)
  %t85 = getelementptr i8, ptr %t84, i64 %t60
  call void @olang_textcopy(ptr %t85, ptr %t61, i64 %t62)
  %t86 = getelementptr i8, ptr %t85, i64 %t62
  call void @olang_textcopy(ptr %t86, ptr %t65, i64 %t66)
  %t87 = getelementptr i8, ptr %t86, i64 %t66
  call void @olang_textcopy(ptr %t87, ptr %t68, i64 %t69)
  %t88 = getelementptr i8, ptr %t87, i64 %t69
  %t89 = call i64 @__olang_fmt_i64(ptr %t88, i64 %t53)
  %t90 = getelementptr i8, ptr %t88, i64 %t72
  call void @olang_textcopy(ptr %t90, ptr %t74, i64 %t75)
  %t91 = getelementptr i8, ptr %t90, i64 %t75
  call void @olang_textcopy(ptr %t91, ptr %t78, i64 %t79)
  %t92 = getelementptr i8, ptr %t91, i64 %t79
  call void @olang_textcopy(ptr %t92, ptr %t81, i64 %t82)
  %t93 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t84, 1
  %t96 = extractvalue { i64, ptr } %t94, 0
  %t97 = extractvalue { i64, ptr } %t94, 1
  %t98 = mul i64 %t96, 1
  %t99 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t98)
  call void @llvm.memcpy.p0.p0.i64(ptr %t99, ptr %t97, i64 %t98, i1 false)
  %t100 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %t99, 1
  %t102 = load ptr, ptr %l21, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t102, { i64, ptr } %t101)
  br label %bb4
bb4:
  %t104 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t104, ptr %l33
  br label %bb5
bb5:
  %t105 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t105, ptr %l7
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr %"compiler/build:Code", ptr %t106, i32 0, i32 3
  %t109 = load { i64, ptr }, ptr %t108, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t109, 1
  %t112 = extractvalue { i64, ptr } %t109, 0
  %t113 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t112)
  call void @olang_textcopy(ptr %t113, ptr %t111, i64 %t112)
  %t114 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t113, 1
  %t117 = extractvalue { i64, ptr } %t115, 0
  %t118 = extractvalue { i64, ptr } %t115, 1
  %t119 = mul i64 %t117, 1
  %t120 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t119)
  call void @llvm.memcpy.p0.p0.i64(ptr %t120, ptr %t118, i64 %t119, i1 false)
  %t121 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t120, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } %t122)
  br label %bb6
bb6:
  %t125 = load ptr, ptr %l2, !tbaa !29
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t128 = getelementptr %"compiler/build:Code", ptr %t126, i32 0, i32 3
  %t129 = load { i64, ptr }, ptr %t128, !tbaa !27
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/listing:Inputs", ptr %t130, i32 0, i32 4
  %t133 = load i1, ptr %t132, !tbaa !21
  %t137 = call { i64, ptr } @compiler_2flisting_2efound(ptr %v2, ptr %v1, ptr %s0, ptr %t125, { i64, ptr } %t129, i1 %t133)
  store { i64, ptr } %t137, ptr %l44
  br label %bb7
bb7:
  %t138 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t138, ptr %l8, !tbaa !27
  %t139 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t141 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t139, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d153, i32 0, i32 1) })
  store i1 %t141, ptr %l46
  br label %bb8
bb8:
  %t142 = load i1, ptr %l46, !tbaa !21
  %t143 = xor i1 %t142, true
  br i1 %t143, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %l5, ptr %l48, !tbaa !29
  %t145 = load ptr, ptr %l0, !tbaa !29
  store ptr %t145, ptr %l49, !tbaa !29
  %t146 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t146, ptr %l50, !tbaa !27
  %t147 = load ptr, ptr %l1, !tbaa !29
  %t149 = getelementptr %"compiler/build:Code", ptr %t147, i32 0, i32 3
  %t150 = load { i64, ptr }, ptr %t149, !tbaa !27
  store { i64, ptr } %t150, ptr %l52, !tbaa !27
  %t152 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s0, ptr %s0, ptr %l7)
  store { i64, ptr } %t152, ptr %l54
  br label %bb11
bb10:
  br label %bb15
bb11:
  %t153 = load ptr, ptr %l2, !tbaa !29
  %t154 = load ptr, ptr %l3, !tbaa !29
  %t155 = load ptr, ptr %l4, !tbaa !29
  %t156 = load ptr, ptr %l49, !tbaa !29
  %t157 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t158 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t159 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t163 = call { i64, ptr } @compiler_2flisting_2ebody(ptr %v0, ptr %s0, ptr %v1, ptr %s0, ptr %v2, ptr %v3, ptr %v4, ptr %s4, ptr %t156, { i64, ptr } %t157, { i64, ptr } %t158, { i64, ptr } %t159, ptr %t153, ptr %t154, ptr %t155)
  store { i64, ptr } %t163, ptr %l58
  br label %bb12
bb12:
  %t164 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t164, 0
  %t166 = extractvalue { i64, ptr } %t164, 1
  %t167 = mul i64 %t165, 1
  %t168 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t167)
  call void @llvm.memcpy.p0.p0.i64(ptr %t168, ptr %t166, i64 %t167, i1 false)
  %t169 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t168, 1
  %t171 = load ptr, ptr %l48, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t171, { i64, ptr } %t170)
  br label %bb13
bb13:
  %t174 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v5, ptr %l5)
  store { i64, ptr } %t174, ptr %l61
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t175 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t175, ptr %rv
  br label %ret
bb15:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d154, i32 0, i32 1) }, ptr %l62, !tbaa !27
  %t176 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t176, ptr %l63, !tbaa !27
  %t177 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t177, 0
  store i64 %t178, ptr %l64, !tbaa !24
  %t179 = load i64, ptr %l64, !tbaa !24
  %t180 = mul i64 %t179, 1
  %t181 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t180)
  %t182 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t181, 1
  store { i64, ptr } %t183, ptr %l65, !tbaa !27
  %t184 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !27
  %t188 = load i64, ptr %l64, !tbaa !24
  %t189 = mul i64 %t188, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t185, ptr %t187, i64 %t189, i1 false)
  %t190 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t190, ptr %l9, !tbaa !27
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s5
  %t191 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t193 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s5, { i64, ptr } %t191, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d155, i32 0, i32 1) })
  store i1 %t193, ptr %l67
  br label %bb17
bb17:
  %t194 = load i1, ptr %l67, !tbaa !21
  br i1 %t194, label %bb18, label %bb19
bb18:
  %t196 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l7)
  store i64 %t196, ptr %l70
  br label %bb20
bb19:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb21
bb20:
  %t197 = load i64, ptr %l70, !tbaa !24
  %t198 = icmp sle i64 %t197, 8
  store i1 %t198, ptr %l68, !tbaa !21
  br label %bb21
bb21:
  %t200 = load i1, ptr %l68, !tbaa !21
  %t201 = xor i1 %t200, true
  br i1 %t201, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s5)
  br label %bb53
bb23:
  br label %bb24
bb24:
  store ptr %l7, ptr %l73, !tbaa !29
  %t204 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l7)
  store i64 %t204, ptr %l75
  br label %bb25
bb25:
  %t205 = load i64, ptr %l75, !tbaa !24
  %t206 = sub i64 %t205, 1
  %t207 = load ptr, ptr %l73, !tbaa !29
  %t209 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t207, i64 %t206)
  store { i64, ptr } %t209, ptr %l77
  br label %bb26
bb26:
  %t210 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t210, ptr %l10, !tbaa !27
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/listing:Inputs", ptr %t211, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t216 = getelementptr %"compiler/build:Listed", ptr %t214, i32 0, i32 1
  %t217 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t219 = extractvalue { i64, ptr } %t217, 1
  %t220 = extractvalue { i64, ptr } %t217, 0
  %t221 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t220)
  call void @olang_textcopy(ptr %t221, ptr %t219, i64 %t220)
  %t222 = insertvalue { i64, ptr } undef, i64 %t220, 0
  %t223 = insertvalue { i64, ptr } %t222, ptr %t221, 1
  %t225 = extractvalue { i64, ptr } %t223, 0
  %t226 = extractvalue { i64, ptr } %t223, 1
  %t227 = mul i64 %t225, 1
  %t228 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t227)
  call void @llvm.memcpy.p0.p0.i64(ptr %t228, ptr %t226, i64 %t227, i1 false)
  %t229 = insertvalue { i64, ptr } undef, i64 %t225, 0
  %t230 = insertvalue { i64, ptr } %t229, ptr %t228, 1
  %t231 = mul i64 1, 16
  %t232 = call ptr @__olang_scope_alloc_zeroed(ptr %s5, i64 %t231)
  %t233 = insertvalue { i64, ptr } undef, i64 1, 0
  %t234 = insertvalue { i64, ptr } %t233, ptr %t232, 1
  store { i64, ptr } %t234, ptr %l84, !tbaa !27
  %t236 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t237 = load ptr, ptr %t236, !tbaa !27
  %t238 = getelementptr { i64, ptr }, ptr %t237, i64 0
  store { i64, ptr } %t230, ptr %t238, !tbaa !37
  %t239 = load ptr, ptr %l3, !tbaa !29
  %t241 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t243 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2flisting_2eRemarks(ptr %v0, ptr %s5, ptr %v3, ptr %s5, ptr %t216, { i64, ptr } %t241, ptr %t239)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t243, ptr %l86
  br label %bb27
bb27:
  %t244 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l86
  %t245 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t244, ptr %t245
  %t246 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t249 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2flisting_2ecallersOf(ptr %s5, ptr %s0, ptr %s5, ptr %t245, { i64, ptr } %t246)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t249, ptr %l89
  br label %bb28
bb28:
  %t250 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l89
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t250, ptr %l11
  %t252 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s5, ptr %l11)
  store i64 %t252, ptr %l91
  br label %bb29
bb29:
  %t253 = load i64, ptr %l91, !tbaa !24
  %t254 = icmp ne i64 %t253, 1
  br i1 %t254, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s7
  store ptr %l5, ptr %l93, !tbaa !29
  %t256 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t257 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t258 = load ptr, ptr %l3, !tbaa !29
  %t263 = call { i64, ptr } @compiler_2flisting_2enoCode(ptr %v0, ptr %s0, ptr %s5, ptr %v3, ptr %s7, { i64, ptr } %t256, { i64, ptr } %t257, ptr %l11, ptr %t258)
  store { i64, ptr } %t263, ptr %l98
  br label %bb32
bb31:
  br label %bb35
bb32:
  %t264 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t265 = extractvalue { i64, ptr } %t264, 0
  %t266 = extractvalue { i64, ptr } %t264, 1
  %t267 = mul i64 %t265, 1
  %t268 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t267)
  call void @llvm.memcpy.p0.p0.i64(ptr %t268, ptr %t266, i64 %t267, i1 false)
  %t269 = insertvalue { i64, ptr } undef, i64 %t265, 0
  %t270 = insertvalue { i64, ptr } %t269, ptr %t268, 1
  %t271 = load ptr, ptr %l93, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %t271, { i64, ptr } %t270)
  br label %bb33
bb33:
  %t274 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v5, ptr %l5)
  store { i64, ptr } %t274, ptr %l101
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t275 = load { i64, ptr }, ptr %l101, !tbaa !27
  store { i64, ptr } %t275, ptr %rv
  br label %ret
bb35:
  %t276 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t276, ptr %l102, !tbaa !27
  %t277 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t279 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s5, { i64, ptr } %t277, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d156, i32 0, i32 1) })
  store i1 %t279, ptr %l104
  br label %bb36
bb36:
  %t280 = load i1, ptr %l104, !tbaa !21
  br i1 %t280, label %bb37, label %bb38
bb37:
  store { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d157, i32 0, i32 1) }, ptr %l105, !tbaa !27
  br label %bb39
bb38:
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d158, i32 0, i32 1) }, ptr %l105, !tbaa !27
  br label %bb39
bb39:
  %t281 = load ptr, ptr %l3, !tbaa !29
  store ptr %t281, ptr %l106, !tbaa !29
  %t283 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s5, ptr %s5, ptr %l11, i64 0)
  store { i64, ptr } %t283, ptr %l108
  br label %bb40
bb40:
  %t284 = load ptr, ptr %l106, !tbaa !29
  %t285 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t286 = call { i64, ptr } @compiler_2flisting_2ecompiler_2flisting_3aNamer_2eName(ptr %v3, ptr %s5, ptr %s5, ptr %t284, { i64, ptr } %t285)
  store { i64, ptr } %t286, ptr %l109
  br label %bb41
bb41:
  %t287 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t288 = extractvalue { i64, ptr } %t287, 1
  %t289 = extractvalue { i64, ptr } %t287, 0
  %t290 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t291 = extractvalue { i64, ptr } %t290, 1
  %t292 = extractvalue { i64, ptr } %t290, 0
  %t293 = add i64 %t289, %t292
  %t294 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t295 = extractvalue { i64, ptr } %t294, 1
  %t296 = extractvalue { i64, ptr } %t294, 0
  %t297 = add i64 %t293, %t296
  %t298 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t297)
  call void @olang_textcopy(ptr %t298, ptr %t288, i64 %t289)
  %t299 = getelementptr i8, ptr %t298, i64 %t289
  call void @olang_textcopy(ptr %t299, ptr %t291, i64 %t292)
  %t300 = getelementptr i8, ptr %t299, i64 %t292
  call void @olang_textcopy(ptr %t300, ptr %t295, i64 %t296)
  %t301 = insertvalue { i64, ptr } undef, i64 %t297, 0
  %t302 = insertvalue { i64, ptr } %t301, ptr %t298, 1
  store { i64, ptr } %t302, ptr %l110, !tbaa !27
  %t303 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t304 = extractvalue { i64, ptr } %t303, 0
  %t305 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t306 = extractvalue { i64, ptr } %t305, 0
  store i64 %t306, ptr %l112, !tbaa !24
  %t308 = load i64, ptr %l112, !tbaa !24
  %t309 = icmp eq i64 %t304, %t308
  br i1 %t309, label %bb42, label %bb43
bb42:
  %t311 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t312 = load ptr, ptr %t311, !tbaa !27
  %t313 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t314 = load ptr, ptr %t313, !tbaa !27
  %t315 = load i64, ptr %l112, !tbaa !24
  %t316 = mul i64 %t315, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t312, ptr %t314, i64 %t316, i1 false)
  br label %bb44
bb43:
  %t317 = load { i64, ptr }, ptr %l110, !tbaa !27
  store { i64, ptr } %t317, ptr %l9, !tbaa !27
  br label %bb44
bb44:
  store ptr %l7, ptr %l114, !tbaa !29
  %t319 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s5, ptr %s5, ptr %l11, i64 0)
  store { i64, ptr } %t319, ptr %l116
  br label %bb45
bb45:
  %t320 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t321 = extractvalue { i64, ptr } %t320, 1
  %t322 = extractvalue { i64, ptr } %t320, 0
  %t323 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t322)
  call void @olang_textcopy(ptr %t323, ptr %t321, i64 %t322)
  %t324 = insertvalue { i64, ptr } undef, i64 %t322, 0
  %t325 = insertvalue { i64, ptr } %t324, ptr %t323, 1
  %t327 = extractvalue { i64, ptr } %t325, 0
  %t328 = extractvalue { i64, ptr } %t325, 1
  %t329 = mul i64 %t327, 1
  %t330 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t329)
  call void @llvm.memcpy.p0.p0.i64(ptr %t330, ptr %t328, i64 %t329, i1 false)
  %t331 = insertvalue { i64, ptr } undef, i64 %t327, 0
  %t332 = insertvalue { i64, ptr } %t331, ptr %t330, 1
  %t333 = load ptr, ptr %l114, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t333, { i64, ptr } %t332)
  br label %bb46
bb46:
  %t335 = load ptr, ptr %l2, !tbaa !29
  store ptr %t335, ptr %l119, !tbaa !29
  %t337 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s5, ptr %s5, ptr %l11, i64 0)
  store { i64, ptr } %t337, ptr %l121
  br label %bb47
bb47:
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t340 = getelementptr %"compiler/listing:Inputs", ptr %t338, i32 0, i32 4
  %t341 = load i1, ptr %t340, !tbaa !21
  %t342 = load ptr, ptr %l119, !tbaa !29
  %t343 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t345 = call { i64, ptr } @compiler_2flisting_2efound(ptr %v2, ptr %s5, ptr %s0, ptr %t342, { i64, ptr } %t343, i1 %t341)
  store { i64, ptr } %t345, ptr %l124
  br label %bb48
bb48:
  %t346 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t347 = extractvalue { i64, ptr } %t346, 0
  %t348 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t349 = extractvalue { i64, ptr } %t348, 0
  store i64 %t349, ptr %l126, !tbaa !24
  %t351 = load i64, ptr %l126, !tbaa !24
  %t352 = icmp eq i64 %t347, %t351
  br i1 %t352, label %bb49, label %bb50
bb49:
  %t354 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t355 = load ptr, ptr %t354, !tbaa !27
  %t356 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t357 = load ptr, ptr %t356, !tbaa !27
  %t358 = load i64, ptr %l126, !tbaa !24
  %t359 = mul i64 %t358, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t355, ptr %t357, i64 %t359, i1 false)
  br label %bb51
bb50:
  %t360 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t360, ptr %l8, !tbaa !27
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s5)
  br label %bb52
bb52:
  br label %bb16
bb53:
  %t361 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t363 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t361, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d159, i32 0, i32 1) })
  store i1 %t363, ptr %l129
  br label %bb54
bb54:
  %t364 = load i1, ptr %l129, !tbaa !21
  br i1 %t364, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s10
  %t365 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t366 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t368 = extractvalue { i64, ptr } %t365, 1
  %t369 = extractvalue { i64, ptr } %t365, 0
  %t370 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d160, i32 0, i32 1) }, 1
  %t371 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d160, i32 0, i32 1) }, 0
  %t372 = add i64 %t369, %t371
  %t374 = extractvalue { i64, ptr } %t366, 1
  %t375 = extractvalue { i64, ptr } %t366, 0
  %t376 = add i64 %t372, %t375
  %t377 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d161, i32 0, i32 1) }, 1
  %t378 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d161, i32 0, i32 1) }, 0
  %t379 = add i64 %t376, %t378
  %t380 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t379)
  call void @olang_textcopy(ptr %t380, ptr %t368, i64 %t369)
  %t381 = getelementptr i8, ptr %t380, i64 %t369
  call void @olang_textcopy(ptr %t381, ptr %t370, i64 %t371)
  %t382 = getelementptr i8, ptr %t381, i64 %t371
  call void @olang_textcopy(ptr %t382, ptr %t374, i64 %t375)
  %t383 = getelementptr i8, ptr %t382, i64 %t375
  call void @olang_textcopy(ptr %t383, ptr %t377, i64 %t378)
  %t384 = insertvalue { i64, ptr } undef, i64 %t379, 0
  %t385 = insertvalue { i64, ptr } %t384, ptr %t380, 1
  %t387 = extractvalue { i64, ptr } %t385, 0
  %t388 = extractvalue { i64, ptr } %t385, 1
  %t389 = mul i64 %t387, 1
  %t390 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t389)
  call void @llvm.memcpy.p0.p0.i64(ptr %t390, ptr %t388, i64 %t389, i1 false)
  %t391 = insertvalue { i64, ptr } undef, i64 %t387, 0
  %t392 = insertvalue { i64, ptr } %t391, ptr %t390, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s10, ptr %l5, { i64, ptr } %t392)
  br label %bb57
bb56:
  br label %bb59
bb57:
  %t396 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v5, ptr %l5)
  store { i64, ptr } %t396, ptr %l136
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t397 = load { i64, ptr }, ptr %l136, !tbaa !27
  store { i64, ptr } %t397, ptr %rv
  br label %ret
bb59:
  %t398 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t399 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t401 = extractvalue { i64, ptr } %t398, 1
  %t402 = extractvalue { i64, ptr } %t398, 0
  %t403 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d162, i32 0, i32 1) }, 1
  %t404 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d162, i32 0, i32 1) }, 0
  %t405 = add i64 %t402, %t404
  %t407 = extractvalue { i64, ptr } %t399, 1
  %t408 = extractvalue { i64, ptr } %t399, 0
  %t409 = add i64 %t405, %t408
  %t410 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d163, i32 0, i32 1) }, 1
  %t411 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d163, i32 0, i32 1) }, 0
  %t412 = add i64 %t409, %t411
  %t413 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t412)
  call void @olang_textcopy(ptr %t413, ptr %t401, i64 %t402)
  %t414 = getelementptr i8, ptr %t413, i64 %t402
  call void @olang_textcopy(ptr %t414, ptr %t403, i64 %t404)
  %t415 = getelementptr i8, ptr %t414, i64 %t404
  call void @olang_textcopy(ptr %t415, ptr %t407, i64 %t408)
  %t416 = getelementptr i8, ptr %t415, i64 %t408
  call void @olang_textcopy(ptr %t416, ptr %t410, i64 %t411)
  %t417 = insertvalue { i64, ptr } undef, i64 %t412, 0
  %t418 = insertvalue { i64, ptr } %t417, ptr %t413, 1
  %t420 = extractvalue { i64, ptr } %t418, 0
  %t421 = extractvalue { i64, ptr } %t418, 1
  %t422 = mul i64 %t420, 1
  %t423 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t422)
  call void @llvm.memcpy.p0.p0.i64(ptr %t423, ptr %t421, i64 %t422, i1 false)
  %t424 = insertvalue { i64, ptr } undef, i64 %t420, 0
  %t425 = insertvalue { i64, ptr } %t424, ptr %t423, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l5, { i64, ptr } %t425)
  br label %bb60
bb60:
  store ptr %l5, ptr %l142, !tbaa !29
  %t428 = load ptr, ptr %l0, !tbaa !29
  store ptr %t428, ptr %l143, !tbaa !29
  %t429 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t429, ptr %l144, !tbaa !27
  %t430 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t430, ptr %l145, !tbaa !27
  %t432 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s0, ptr %s0, ptr %l7)
  store { i64, ptr } %t432, ptr %l147
  br label %bb61
bb61:
  %t433 = load ptr, ptr %l2, !tbaa !29
  %t434 = load ptr, ptr %l3, !tbaa !29
  %t435 = load ptr, ptr %l4, !tbaa !29
  %t436 = load ptr, ptr %l143, !tbaa !29
  %t437 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t438 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t439 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t443 = call { i64, ptr } @compiler_2flisting_2ebody(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %v2, ptr %v3, ptr %v4, ptr %s0, ptr %t436, { i64, ptr } %t437, { i64, ptr } %t438, { i64, ptr } %t439, ptr %t433, ptr %t434, ptr %t435)
  store { i64, ptr } %t443, ptr %l151
  br label %bb62
bb62:
  %t444 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t445 = extractvalue { i64, ptr } %t444, 0
  %t446 = extractvalue { i64, ptr } %t444, 1
  %t447 = mul i64 %t445, 1
  %t448 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t447)
  call void @llvm.memcpy.p0.p0.i64(ptr %t448, ptr %t446, i64 %t447, i1 false)
  %t449 = insertvalue { i64, ptr } undef, i64 %t445, 0
  %t450 = insertvalue { i64, ptr } %t449, ptr %t448, 1
  %t451 = load ptr, ptr %l142, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t451, { i64, ptr } %t450)
  br label %bb63
bb63:
  %t454 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v5, ptr %l5)
  store { i64, ptr } %t454, ptr %l154
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s0)
  %t455 = load { i64, ptr }, ptr %l154, !tbaa !27
  store { i64, ptr } %t455, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2flisting_2eirDefines(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca i1
  %l16 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d164, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d164, i32 0, i32 1) }, 0
  %t7 = extractvalue { i64, ptr } %t3, 1
  %t8 = extractvalue { i64, ptr } %t3, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d165, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d165, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t7, i64 %t8)
  %t15 = getelementptr i8, ptr %t14, i64 %t8
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  %t20 = extractvalue { i64, ptr } %t17, 0
  %t21 = extractvalue { i64, ptr } %t17, 1
  %t22 = mul i64 %t20, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  %t28 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } %t25)
  store i1 %t28, ptr %l8
  br label %bb1
bb1:
  %t29 = load i1, ptr %l8, !tbaa !21
  br i1 %t29, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb5
bb3:
  %t30 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t33 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d166, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d166, i32 0, i32 1) }, 0
  %t36 = extractvalue { i64, ptr } %t32, 1
  %t37 = extractvalue { i64, ptr } %t32, 0
  %t38 = add i64 %t34, %t37
  %t39 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d167, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d167, i32 0, i32 1) }, 0
  %t41 = add i64 %t38, %t40
  %t42 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t41)
  call void @olang_textcopy(ptr %t42, ptr %t33, i64 %t34)
  %t43 = getelementptr i8, ptr %t42, i64 %t34
  call void @olang_textcopy(ptr %t43, ptr %t36, i64 %t37)
  %t44 = getelementptr i8, ptr %t43, i64 %t37
  call void @olang_textcopy(ptr %t44, ptr %t39, i64 %t40)
  %t45 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t42, 1
  %t49 = extractvalue { i64, ptr } %t46, 0
  %t50 = extractvalue { i64, ptr } %t46, 1
  %t51 = mul i64 %t49, 1
  %t52 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t51)
  call void @llvm.memcpy.p0.p0.i64(ptr %t52, ptr %t50, i64 %t51, i1 false)
  %t53 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  %t57 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s0, { i64, ptr } %t30, { i64, ptr } %t54)
  store i1 %t57, ptr %l16
  br label %bb4
bb4:
  %t58 = load i1, ptr %l16, !tbaa !21
  store i1 %t58, ptr %l9, !tbaa !21
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t59 = load i1, ptr %l9, !tbaa !21
  store i1 %t59, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { { i64, ptr }, { i64, ptr } } @compiler_2flisting_2ekeyValue(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l8 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l12 = alloca { { i64, ptr }, { i64, ptr } }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l30 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l39 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, { i64, ptr } }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d168, i32 0, i32 1) })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i64 %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load i64, ptr %l4, !tbaa !24
  store i64 %t8, ptr %l2, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l2, !tbaa !24
  br label %bb4
bb4:
  %t9 = load i64, ptr %l2, !tbaa !24
  store i64 %t9, ptr %l1, !tbaa !24
  %t10 = load i64, ptr %l1, !tbaa !24
  %t12 = icmp slt i64 %t10, 0
  br i1 %t12, label %bb5, label %bb6
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d169, i32 0, i32 1) }, ptr %l8, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d170, i32 0, i32 1) }, ptr %l10, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t17 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t14, 0
  %t19 = insertvalue { { i64, ptr }, { i64, ptr } } %t17, { i64, ptr } %t15, 1
  store { { i64, ptr }, { i64, ptr } } %t19, ptr %l12
  %t20 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l12, i32 0, i32 0
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l13, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l14, !tbaa !24
  %t24 = load i64, ptr %l14, !tbaa !24
  %t25 = mul i64 %t24, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l15, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l14, !tbaa !24
  %t34 = mul i64 %t33, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t36 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l12, i32 0, i32 0
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l12, i32 0, i32 1
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l16, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l17, !tbaa !24
  %t41 = load i64, ptr %l17, !tbaa !24
  %t42 = mul i64 %t41, 1
  %t43 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l18, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l17, !tbaa !24
  %t51 = mul i64 %t50, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t53 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l12, i32 0, i32 1
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t54 = load { { i64, ptr }, { i64, ptr } }, ptr %l12
  store { { i64, ptr }, { i64, ptr } } %t54, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t55 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t55, ptr %l19, !tbaa !27
  %t56 = load i64, ptr %l1, !tbaa !24
  store i64 %t56, ptr %l20, !tbaa !24
  %t57 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t57, 0
  store i64 %t58, ptr %l21, !tbaa !24
  %t59 = icmp sge i64 0, 0
  br i1 %t59, label %bb8, label %bb9
bb8:
  %t61 = load i64, ptr %l20, !tbaa !24
  %t62 = icmp sle i64 0, %t61
  br i1 %t62, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_419e18d9533a9898_764a2322a7d2db2c)
  unreachable
bb10:
  %t64 = load i64, ptr %l20, !tbaa !24
  %t65 = load i64, ptr %l21, !tbaa !24
  %t66 = icmp sle i64 %t64, %t65
  br i1 %t66, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_419e18d9533a9898_764a2322a7d2db2c)
  unreachable
bb12:
  %t68 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = load i64, ptr %l20, !tbaa !24
  %t71 = getelementptr i8, ptr %t69, i64 0
  %t72 = sub i64 %t70, 0
  %t73 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t71, 1
  %t76 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %s0, { i64, ptr } %t74)
  store { i64, ptr } %t76, ptr %l26
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_419e18d9533a9898_764a2322a7d2db2c)
  unreachable
bb14:
  %t77 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t77, 1
  %t79 = extractvalue { i64, ptr } %t77, 0
  %t80 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t79)
  call void @olang_textcopy(ptr %t80, ptr %t78, i64 %t79)
  %t81 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t80, 1
  store { i64, ptr } %t82, ptr %l27, !tbaa !27
  %t83 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t83, ptr %l28, !tbaa !27
  %t84 = load i64, ptr %l1, !tbaa !24
  %t86 = add i64 %t84, 1
  store i64 %t86, ptr %l30, !tbaa !24
  %t87 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t87, 0
  store i64 %t90, ptr %l33, !tbaa !24
  %t91 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t91, 0
  store i64 %t92, ptr %l34, !tbaa !24
  %t93 = load i64, ptr %l30, !tbaa !24
  %t94 = icmp sge i64 %t93, 0
  br i1 %t94, label %bb15, label %bb16
bb15:
  %t96 = load i64, ptr %l30, !tbaa !24
  %t97 = load i64, ptr %l33, !tbaa !24
  %t98 = icmp sle i64 %t96, %t97
  br i1 %t98, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_419e18d9533a9898_764a2322a7d2db2c)
  unreachable
bb17:
  %t100 = load i64, ptr %l33, !tbaa !24
  %t101 = load i64, ptr %l34, !tbaa !24
  %t102 = icmp sle i64 %t100, %t101
  br i1 %t102, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_419e18d9533a9898_764a2322a7d2db2c)
  unreachable
bb19:
  %t104 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = load i64, ptr %l30, !tbaa !24
  %t107 = load i64, ptr %l33, !tbaa !24
  %t108 = getelementptr i8, ptr %t105, i64 %t106
  %t109 = sub i64 %t107, %t106
  %t110 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t108, 1
  %t113 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %s0, { i64, ptr } %t111)
  store { i64, ptr } %t113, ptr %l39
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_419e18d9533a9898_764a2322a7d2db2c)
  unreachable
bb21:
  %t114 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t114, 1
  %t116 = extractvalue { i64, ptr } %t114, 0
  %t117 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t116)
  call void @olang_textcopy(ptr %t117, ptr %t115, i64 %t116)
  %t118 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t117, 1
  %t120 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t121 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t120, 0
  %t123 = insertvalue { { i64, ptr }, { i64, ptr } } %t121, { i64, ptr } %t119, 1
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, { i64, ptr } } %t123, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, { i64, ptr } }, ptr %rv
  ret { { i64, ptr }, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @compiler_2flisting_2ekindWord(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l14 = alloca i1
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d171, i32 0, i32 1) })
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d172, i32 0, i32 1) }, ptr %l3, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t5, ptr %l4, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = mul i64 %t8, 1
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l6, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = load i64, ptr %l5, !tbaa !24
  %t18 = mul i64 %t17, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %t16, i64 %t18, i1 false)
  %t19 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t19, ptr %l4, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t20 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t20, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t21 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t23 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t21, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d173, i32 0, i32 1) })
  store i1 %t23, ptr %l8
  br label %bb5
bb5:
  %t24 = load i1, ptr %l8, !tbaa !21
  br i1 %t24, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d174, i32 0, i32 1) }, ptr %l9, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t25, ptr %l10, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t26, 0
  store i64 %t27, ptr %l11, !tbaa !24
  %t28 = load i64, ptr %l11, !tbaa !24
  %t29 = mul i64 %t28, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t29)
  %t31 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  store { i64, ptr } %t32, ptr %l12, !tbaa !27
  %t33 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = load i64, ptr %l11, !tbaa !24
  %t38 = mul i64 %t37, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t34, ptr %t36, i64 %t38, i1 false)
  %t39 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t39, ptr %l10, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t40 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t40, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t41 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t43 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t41, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d175, i32 0, i32 1) })
  store i1 %t43, ptr %l14
  br label %bb9
bb9:
  %t44 = load i1, ptr %l14, !tbaa !21
  br i1 %t44, label %bb10, label %bb11
bb10:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d176, i32 0, i32 1) }, ptr %l15, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t45, ptr %l16, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 0
  store i64 %t47, ptr %l17, !tbaa !24
  %t48 = load i64, ptr %l17, !tbaa !24
  %t49 = mul i64 %t48, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t49)
  %t51 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  store { i64, ptr } %t52, ptr %l18, !tbaa !27
  %t53 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = load i64, ptr %l17, !tbaa !24
  %t58 = mul i64 %t57, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t54, ptr %t56, i64 %t58, i1 false)
  %t59 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t59, ptr %l16, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t60 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t60, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t61 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t63 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToLower(ptr %v0, ptr %v1, { i64, ptr } %t61)
  store { i64, ptr } %t63, ptr %l20
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t64 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t64, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, i64 } @compiler_2flisting_2elocOf(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l27 = alloca i1
  %l36 = alloca i64
  %l39 = alloca i64
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i32
  %l44 = alloca i64
  %l45 = alloca i32
  %l46 = alloca i64
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca i32
  %l51 = alloca i64
  %l52 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, i64 }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  store %olang.scope zeroinitializer, ptr %s1
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d177, i32 0, i32 1) }, ptr %l9, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d178, i32 0, i32 1) }, ptr %l10, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t8 = call { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %a0, { i64, ptr } %t6, { i64, ptr } %t7)
  store { i64, ptr } %t8, ptr %l11
  br label %bb2
bb2:
  %t9 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l12, !tbaa !24
  %t11 = load i64, ptr %l12, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l12, !tbaa !24
  %t21 = mul i64 %t20, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  %t22 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t25 = extractvalue { i64, ptr } %t22, 1
  %t26 = mul i64 %t24, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t26)
  call void @llvm.memcpy.p0.p0.i64(ptr %t27, ptr %t25, i64 %t26, i1 false)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  %t31 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t29, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d179, i32 0, i32 1) })
  store { i64, ptr } %t31, ptr %l16
  br label %bb3
bb3:
  %t32 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t32, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  store i64 %t35, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load i64, ptr %l3, !tbaa !24
  %t38 = load i64, ptr %l4, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb6:
  br label %bb7
bb7:
  %t45 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t45, ptr %l23, !tbaa !27
  %t46 = load i64, ptr %l3, !tbaa !24
  %t48 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr { i64, ptr }, ptr %t49, i64 %t46
  %t51 = load { i64, ptr }, ptr %t50, !tbaa !37
  store { i64, ptr } %t51, ptr %l5, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t55 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s2, { i64, ptr } %t53, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d180, i32 0, i32 1) })
  store i1 %t55, ptr %l27
  br label %bb8
bb8:
  %t56 = load i1, ptr %l27, !tbaa !21
  %t57 = xor i1 %t56, true
  br i1 %t57, label %bb9, label %bb10
bb9:
  %t59 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 1
  %t62 = extractvalue { i64, ptr } %t59, 0
  %t63 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t62)
  call void @olang_textcopy(ptr %t63, ptr %t61, i64 %t62)
  %t64 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  %t67 = extractvalue { i64, ptr } %t65, 0
  %t68 = extractvalue { i64, ptr } %t65, 1
  %t69 = mul i64 %t67, 1
  %t70 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t69)
  call void @llvm.memcpy.p0.p0.i64(ptr %t70, ptr %t68, i64 %t69, i1 false)
  %t71 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } %t72)
  br label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  %t75 = load i64, ptr %l3, !tbaa !24
  %t77 = add i64 %t75, 1
  store i64 %t77, ptr %l3, !tbaa !24
  br label %bb4
bb14:
  call void @__olang_scope_close(ptr %s1)
  %t80 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l1)
  store i64 %t80, ptr %l36
  br label %bb15
bb15:
  %t81 = load i64, ptr %l36, !tbaa !24
  %t82 = icmp slt i64 %t81, 3
  br i1 %t82, label %bb16, label %bb17
bb16:
  %t84 = insertvalue { i64, i64 } undef, i64 -1, 0
  %t85 = insertvalue { i64, i64 } %t84, i64 0, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, i64 } %t85, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t88 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l1, i64 1)
  store { i64, ptr } %t88, ptr %l41
  br label %bb19
bb19:
  %t89 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 10)
  %t90 = extractvalue { i32, i64 } %t89, 1
  %t91 = extractvalue { i32, i64 } %t89, 0
  store i32 %t91, ptr %l43
  %t92 = icmp ne i32 %t91, 0
  br i1 %t92, label %bb21, label %ok.93, !prof !99
ok.93:
  store i64 %t90, ptr %l42
  br label %bb20
bb20:
  %t94 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t95 = load i64, ptr %l42, !tbaa !24
  %t96 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s0, { i64, ptr } %t94, i64 %t95)
  %t97 = extractvalue { i32, i64 } %t96, 1
  %t98 = extractvalue { i32, i64 } %t96, 0
  store i32 %t98, ptr %l45
  %t99 = icmp ne i32 %t98, 0
  br i1 %t99, label %bb24, label %ok.100, !prof !99
ok.100:
  store i64 %t97, ptr %l44
  br label %bb23
bb21:
  br label %bb22
bb22:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l39, !tbaa !24
  br label %bb25
bb23:
  %t101 = load i64, ptr %l44, !tbaa !24
  store i64 %t101, ptr %l39, !tbaa !24
  br label %bb25
bb24:
  br label %bb22
bb25:
  %t103 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l1, i64 2)
  store { i64, ptr } %t103, ptr %l48
  br label %bb26
bb26:
  %t104 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 10)
  %t105 = extractvalue { i32, i64 } %t104, 1
  %t106 = extractvalue { i32, i64 } %t104, 0
  store i32 %t106, ptr %l50
  %t107 = icmp ne i32 %t106, 0
  br i1 %t107, label %bb28, label %ok.108, !prof !99
ok.108:
  store i64 %t105, ptr %l49
  br label %bb27
bb27:
  %t109 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t110 = load i64, ptr %l49, !tbaa !24
  %t111 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s0, { i64, ptr } %t109, i64 %t110)
  %t112 = extractvalue { i32, i64 } %t111, 1
  %t113 = extractvalue { i32, i64 } %t111, 0
  store i32 %t113, ptr %l52
  %t114 = icmp ne i32 %t113, 0
  br i1 %t114, label %bb31, label %ok.115, !prof !99
ok.115:
  store i64 %t112, ptr %l51
  br label %bb30
bb28:
  br label %bb29
bb29:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l46, !tbaa !24
  br label %bb32
bb30:
  %t116 = load i64, ptr %l51, !tbaa !24
  store i64 %t116, ptr %l46, !tbaa !24
  br label %bb32
bb31:
  br label %bb29
bb32:
  %t117 = load i64, ptr %l39, !tbaa !24
  %t118 = insertvalue { i64, i64 } undef, i64 %t117, 0
  %t119 = load i64, ptr %l46, !tbaa !24
  %t120 = insertvalue { i64, i64 } %t118, i64 %t119, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, i64 } %t120, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local { i64, ptr } @compiler_2flisting_2emetaField(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i32
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l21 = alloca i1
  %l22 = alloca i1
  %l23 = alloca { i64, ptr }
  %l27 = alloca i1
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l32 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i32
  %l48 = alloca i64
  %l55 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l64 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l74 = alloca i1
  %l75 = alloca i64
  %l76 = alloca { i64, ptr }
  %l79 = alloca i64
  %l80 = alloca i64
  %l85 = alloca i64
  %l86 = alloca i32
  %l89 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l93 = alloca i64
  %l94 = alloca i64
  %l100 = alloca { i64, ptr }
  %l102 = alloca i64
  %l103 = alloca i64
  %l113 = alloca i1
  %l114 = alloca { i64, ptr }
  %l118 = alloca i1
  %l119 = alloca { i64, ptr }
  %l126 = alloca { i64, ptr }
  %l127 = alloca i64
  %l128 = alloca i64
  %l133 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t2, 1
  %t5 = extractvalue { i64, ptr } %t2, 0
  %t6 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d181, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d181, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t9 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t8)
  call void @olang_textcopy(ptr %t9, ptr %t4, i64 %t5)
  %t10 = getelementptr i8, ptr %t9, i64 %t5
  call void @olang_textcopy(ptr %t10, ptr %t6, i64 %t7)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t9, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t15 = extractvalue { i64, ptr } %t12, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  %t22 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } %t19)
  %t23 = extractvalue { i32, i64 } %t22, 1
  %t24 = extractvalue { i32, i64 } %t22, 0
  store i32 %t24, ptr %l13
  %t25 = icmp ne i32 %t24, 0
  br i1 %t25, label %bb2, label %ok.26, !prof !99
ok.26:
  store i64 %t23, ptr %l12
  br label %bb1
bb1:
  %t27 = load i64, ptr %l12, !tbaa !24
  store i64 %t27, ptr %l7, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  %t28 = load i64, ptr %l7, !tbaa !24
  store i64 %t28, ptr %l2, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t29 = load i64, ptr %l2, !tbaa !24
  %t31 = icmp sgt i64 %t29, 0
  br i1 %t31, label %bb6, label %bb7
bb6:
  %t33 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t33, ptr %l17, !tbaa !27
  %t34 = load i64, ptr %l2, !tbaa !24
  %t36 = sub i64 %t34, 1
  %t38 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr i8, ptr %t39, i64 %t36
  %t41 = load i8, ptr %t40, !tbaa !32
  %t43 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t41)
  store i1 %t43, ptr %l21
  br label %bb8
bb7:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb13
bb8:
  %t44 = load i1, ptr %l21, !tbaa !21
  br i1 %t44, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb12
bb10:
  %t45 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t45, ptr %l23, !tbaa !27
  %t46 = load i64, ptr %l2, !tbaa !24
  %t48 = sub i64 %t46, 1
  %t50 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr i8, ptr %t51, i64 %t48
  %t53 = load i8, ptr %t52, !tbaa !32
  %t55 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t53)
  store i1 %t55, ptr %l27
  br label %bb11
bb11:
  %t56 = load i1, ptr %l27, !tbaa !21
  store i1 %t56, ptr %l22, !tbaa !21
  br label %bb12
bb12:
  %t57 = load i1, ptr %l22, !tbaa !21
  store i1 %t57, ptr %l16, !tbaa !21
  br label %bb13
bb13:
  %t58 = load i1, ptr %l16, !tbaa !21
  %t59 = xor i1 %t58, true
  br i1 %t59, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb31
bb15:
  br label %bb16
bb16:
  %t61 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t61, ptr %l30, !tbaa !27
  %t62 = load i64, ptr %l2, !tbaa !24
  %t64 = add i64 %t62, 1
  store i64 %t64, ptr %l32, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t65, 0
  store i64 %t68, ptr %l35, !tbaa !24
  %t69 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  store i64 %t70, ptr %l36, !tbaa !24
  %t71 = load i64, ptr %l32, !tbaa !24
  %t72 = icmp sge i64 %t71, 0
  br i1 %t72, label %bb17, label %bb18
bb17:
  %t74 = load i64, ptr %l32, !tbaa !24
  %t75 = load i64, ptr %l35, !tbaa !24
  %t76 = icmp sle i64 %t74, %t75
  br i1 %t76, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_61ce4b4de8e9e57b_f7600b48bd811137)
  unreachable
bb19:
  %t78 = load i64, ptr %l35, !tbaa !24
  %t79 = load i64, ptr %l36, !tbaa !24
  %t80 = icmp sle i64 %t78, %t79
  br i1 %t80, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_61ce4b4de8e9e57b_f7600b48bd811137)
  unreachable
bb21:
  %t82 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = load i64, ptr %l32, !tbaa !24
  %t85 = load i64, ptr %l35, !tbaa !24
  %t86 = getelementptr i8, ptr %t83, i64 %t84
  %t87 = sub i64 %t85, %t84
  %t88 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t86, 1
  %t90 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t90, 1
  %t93 = extractvalue { i64, ptr } %t90, 0
  %t94 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d182, i32 0, i32 1) }, 1
  %t95 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d182, i32 0, i32 1) }, 0
  %t96 = add i64 %t93, %t95
  %t97 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t96)
  call void @olang_textcopy(ptr %t97, ptr %t92, i64 %t93)
  %t98 = getelementptr i8, ptr %t97, i64 %t93
  call void @olang_textcopy(ptr %t98, ptr %t94, i64 %t95)
  %t99 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t97, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = extractvalue { i64, ptr } %t100, 1
  %t104 = mul i64 %t102, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t104)
  call void @llvm.memcpy.p0.p0.i64(ptr %t105, ptr %t103, i64 %t104, i1 false)
  %t106 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  %t110 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s2, { i64, ptr } %t89, { i64, ptr } %t107)
  %t111 = extractvalue { i32, i64 } %t110, 1
  %t112 = extractvalue { i32, i64 } %t110, 0
  store i32 %t112, ptr %l45
  %t113 = icmp ne i32 %t112, 0
  br i1 %t113, label %bb24, label %ok.114, !prof !99
ok.114:
  store i64 %t111, ptr %l44
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_61ce4b4de8e9e57b_f7600b48bd811137)
  unreachable
bb23:
  %t115 = load i64, ptr %l44, !tbaa !24
  store i64 %t115, ptr %l29, !tbaa !24
  br label %bb26
bb24:
  br label %bb25
bb25:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l29, !tbaa !24
  br label %bb26
bb26:
  %t116 = load i64, ptr %l29, !tbaa !24
  store i64 %t116, ptr %l3, !tbaa !24
  %t117 = load i64, ptr %l3, !tbaa !24
  %t119 = icmp slt i64 %t117, 0
  br i1 %t119, label %bb27, label %bb28
bb27:
  store i64 -1, ptr %l48, !tbaa !24
  br label %bb29
bb28:
  %t121 = load i64, ptr %l2, !tbaa !24
  %t123 = add i64 %t121, 1
  %t124 = load i64, ptr %l3, !tbaa !24
  %t127 = add i64 %t123, %t124
  store i64 %t127, ptr %l48, !tbaa !24
  br label %bb29
bb29:
  %t129 = load i64, ptr %l48, !tbaa !24
  store i64 %t129, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb30:
  br label %bb5
bb31:
  %t130 = load i64, ptr %l2, !tbaa !24
  %t132 = icmp slt i64 %t130, 0
  br i1 %t132, label %bb32, label %bb33
bb32:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d183, i32 0, i32 1) }, ptr %l55, !tbaa !27
  %t134 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t134, ptr %l56, !tbaa !27
  %t135 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 0
  store i64 %t136, ptr %l57, !tbaa !24
  %t137 = load i64, ptr %l57, !tbaa !24
  %t138 = mul i64 %t137, 1
  %t139 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t138)
  %t140 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t139, 1
  store { i64, ptr } %t141, ptr %l58, !tbaa !27
  %t142 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = load i64, ptr %l57, !tbaa !24
  %t147 = mul i64 %t146, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t143, ptr %t145, i64 %t147, i1 false)
  %t148 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t148, ptr %l56, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t149 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t149, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  %t150 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t150, ptr %l59, !tbaa !27
  %t151 = load i64, ptr %l2, !tbaa !24
  %t152 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t154 = extractvalue { i64, ptr } %t152, 0
  %t157 = add i64 %t151, %t154
  %t159 = add i64 %t157, 2
  store i64 %t159, ptr %l64, !tbaa !24
  %t160 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t160, 0
  store i64 %t163, ptr %l67, !tbaa !24
  %t164 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t164, 0
  store i64 %t165, ptr %l68, !tbaa !24
  %t166 = load i64, ptr %l64, !tbaa !24
  %t167 = icmp sge i64 %t166, 0
  br i1 %t167, label %bb35, label %bb36
bb35:
  %t169 = load i64, ptr %l64, !tbaa !24
  %t170 = load i64, ptr %l67, !tbaa !24
  %t171 = icmp sle i64 %t169, %t170
  br i1 %t171, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_bcaef50f3ad362fe_b83702f58870efda)
  unreachable
bb37:
  %t173 = load i64, ptr %l67, !tbaa !24
  %t174 = load i64, ptr %l68, !tbaa !24
  %t175 = icmp sle i64 %t173, %t174
  br i1 %t175, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_bcaef50f3ad362fe_b83702f58870efda)
  unreachable
bb39:
  %t177 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = load i64, ptr %l64, !tbaa !24
  %t180 = load i64, ptr %l67, !tbaa !24
  %t181 = getelementptr i8, ptr %t178, i64 %t179
  %t182 = sub i64 %t180, %t179
  %t183 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t181, 1
  store { i64, ptr } %t184, ptr %l4, !tbaa !27
  %t186 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t188 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t186, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d184, i32 0, i32 1) })
  store i1 %t188, ptr %l74
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_bcaef50f3ad362fe_b83702f58870efda)
  unreachable
bb41:
  %t189 = load i1, ptr %l74, !tbaa !21
  br i1 %t189, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s5
  %t190 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t190, ptr %l76, !tbaa !27
  %t191 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t194 = extractvalue { i64, ptr } %t191, 0
  store i64 %t194, ptr %l79, !tbaa !24
  %t195 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t195, 0
  store i64 %t196, ptr %l80, !tbaa !24
  %t197 = icmp sge i64 1, 0
  br i1 %t197, label %bb44, label %bb45
bb43:
  br label %bb69
bb44:
  %t199 = load i64, ptr %l79, !tbaa !24
  %t200 = icmp sle i64 1, %t199
  br i1 %t200, label %bb46, label %bb47
bb45:
  call void @__olang_check_failed(ptr @olang_loc_f4e5321dee5c23dd_4262af410e6ad879)
  unreachable
bb46:
  %t202 = load i64, ptr %l79, !tbaa !24
  %t203 = load i64, ptr %l80, !tbaa !24
  %t204 = icmp sle i64 %t202, %t203
  br i1 %t204, label %bb48, label %bb49
bb47:
  call void @__olang_check_failed(ptr @olang_loc_f4e5321dee5c23dd_4262af410e6ad879)
  unreachable
bb48:
  %t206 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !27
  %t208 = load i64, ptr %l79, !tbaa !24
  %t209 = getelementptr i8, ptr %t207, i64 1
  %t210 = sub i64 %t208, 1
  %t211 = insertvalue { i64, ptr } undef, i64 %t210, 0
  %t212 = insertvalue { i64, ptr } %t211, ptr %t209, 1
  %t214 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s5, { i64, ptr } %t212, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d185, i32 0, i32 1) })
  %t215 = extractvalue { i32, i64 } %t214, 1
  %t216 = extractvalue { i32, i64 } %t214, 0
  store i32 %t216, ptr %l86
  %t217 = icmp ne i32 %t216, 0
  br i1 %t217, label %bb51, label %ok.218, !prof !99
ok.218:
  store i64 %t215, ptr %l85
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_f4e5321dee5c23dd_4262af410e6ad879)
  unreachable
bb50:
  %t219 = load i64, ptr %l85, !tbaa !24
  store i64 %t219, ptr %l75, !tbaa !24
  br label %bb53
bb51:
  br label %bb52
bb52:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l75, !tbaa !24
  br label %bb53
bb53:
  %t220 = load i64, ptr %l75, !tbaa !24
  store i64 %t220, ptr %l5, !tbaa !24
  %t221 = load i64, ptr %l5, !tbaa !24
  %t223 = icmp slt i64 %t221, 0
  br i1 %t223, label %bb54, label %bb55
bb54:
  %t225 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t225, ptr %l90, !tbaa !27
  %t226 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t229 = extractvalue { i64, ptr } %t226, 0
  store i64 %t229, ptr %l93, !tbaa !24
  %t230 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t231 = extractvalue { i64, ptr } %t230, 0
  store i64 %t231, ptr %l94, !tbaa !24
  %t232 = icmp sge i64 1, 0
  br i1 %t232, label %bb56, label %bb57
bb55:
  %t234 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t234, ptr %l100, !tbaa !27
  %t235 = load i64, ptr %l5, !tbaa !24
  %t237 = add i64 1, %t235
  store i64 %t237, ptr %l102, !tbaa !24
  %t238 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t239 = extractvalue { i64, ptr } %t238, 0
  store i64 %t239, ptr %l103, !tbaa !24
  %t240 = icmp sge i64 1, 0
  br i1 %t240, label %bb62, label %bb63
bb56:
  %t242 = load i64, ptr %l93, !tbaa !24
  %t243 = icmp sle i64 1, %t242
  br i1 %t243, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_b06da0308285dd80_9593e16f44f2444c)
  unreachable
bb58:
  %t245 = load i64, ptr %l93, !tbaa !24
  %t246 = load i64, ptr %l94, !tbaa !24
  %t247 = icmp sle i64 %t245, %t246
  br i1 %t247, label %bb60, label %bb61
bb59:
  call void @__olang_check_failed(ptr @olang_loc_b06da0308285dd80_9593e16f44f2444c)
  unreachable
bb60:
  %t249 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !27
  %t251 = load i64, ptr %l93, !tbaa !24
  %t252 = getelementptr i8, ptr %t250, i64 1
  %t253 = sub i64 %t251, 1
  %t254 = insertvalue { i64, ptr } undef, i64 %t253, 0
  %t255 = insertvalue { i64, ptr } %t254, ptr %t252, 1
  %t257 = extractvalue { i64, ptr } %t255, 1
  %t258 = extractvalue { i64, ptr } %t255, 0
  %t259 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t258)
  call void @olang_textcopy(ptr %t259, ptr %t257, i64 %t258)
  %t260 = insertvalue { i64, ptr } undef, i64 %t258, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t259, 1
  store { i64, ptr } %t261, ptr %l89, !tbaa !27
  br label %bb68
bb61:
  call void @__olang_check_failed(ptr @olang_loc_b06da0308285dd80_9593e16f44f2444c)
  unreachable
bb62:
  %t263 = load i64, ptr %l102, !tbaa !24
  %t264 = icmp sle i64 1, %t263
  br i1 %t264, label %bb64, label %bb65
bb63:
  call void @__olang_check_failed(ptr @olang_loc_b06da0308285dd80_9593e16f44f2444c)
  unreachable
bb64:
  %t266 = load i64, ptr %l102, !tbaa !24
  %t267 = load i64, ptr %l103, !tbaa !24
  %t268 = icmp sle i64 %t266, %t267
  br i1 %t268, label %bb66, label %bb67
bb65:
  call void @__olang_check_failed(ptr @olang_loc_b06da0308285dd80_9593e16f44f2444c)
  unreachable
bb66:
  %t270 = getelementptr { i64, ptr }, ptr %l100, i32 0, i32 1
  %t271 = load ptr, ptr %t270, !tbaa !27
  %t272 = load i64, ptr %l102, !tbaa !24
  %t273 = getelementptr i8, ptr %t271, i64 1
  %t274 = sub i64 %t272, 1
  %t275 = insertvalue { i64, ptr } undef, i64 %t274, 0
  %t276 = insertvalue { i64, ptr } %t275, ptr %t273, 1
  %t278 = extractvalue { i64, ptr } %t276, 1
  %t279 = extractvalue { i64, ptr } %t276, 0
  %t280 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t279)
  call void @olang_textcopy(ptr %t280, ptr %t278, i64 %t279)
  %t281 = insertvalue { i64, ptr } undef, i64 %t279, 0
  %t282 = insertvalue { i64, ptr } %t281, ptr %t280, 1
  store { i64, ptr } %t282, ptr %l89, !tbaa !27
  br label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_b06da0308285dd80_9593e16f44f2444c)
  unreachable
bb68:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t284 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t284, ptr %rv
  br label %ret
bb69:
  store i64 0, ptr %l6, !tbaa !24
  br label %bb70
bb70:
  %t285 = load i64, ptr %l6, !tbaa !24
  %t286 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t288 = extractvalue { i64, ptr } %t286, 0
  %t291 = icmp slt i64 %t285, %t288
  br i1 %t291, label %bb71, label %bb72
bb71:
  %t293 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t293, ptr %l114, !tbaa !27
  %t294 = load i64, ptr %l6, !tbaa !24
  %t296 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t297 = load ptr, ptr %t296, !tbaa !27
  %t298 = getelementptr i8, ptr %t297, i64 %t294
  %t299 = load i8, ptr %t298, !tbaa !32
  %t301 = icmp ne i8 %t299, 44
  store i1 %t301, ptr %l113, !tbaa !21
  br label %bb73
bb72:
  store i1 false, ptr %l113, !tbaa !21
  br label %bb73
bb73:
  %t303 = load i1, ptr %l113, !tbaa !21
  br i1 %t303, label %bb74, label %bb75
bb74:
  %t304 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t304, ptr %l119, !tbaa !27
  %t305 = load i64, ptr %l6, !tbaa !24
  %t307 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !27
  %t309 = getelementptr i8, ptr %t308, i64 %t305
  %t310 = load i8, ptr %t309, !tbaa !32
  %t312 = icmp ne i8 %t310, 41
  store i1 %t312, ptr %l118, !tbaa !21
  br label %bb76
bb75:
  store i1 false, ptr %l118, !tbaa !21
  br label %bb76
bb76:
  %t314 = load i1, ptr %l118, !tbaa !21
  %t315 = xor i1 %t314, true
  br i1 %t315, label %bb77, label %bb78
bb77:
  br label %bb81
bb78:
  br label %bb79
bb79:
  %t317 = load i64, ptr %l6, !tbaa !24
  %t319 = add i64 %t317, 1
  store i64 %t319, ptr %l6, !tbaa !24
  br label %bb80
bb80:
  br label %bb70
bb81:
  %t321 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t321, ptr %l126, !tbaa !27
  %t322 = load i64, ptr %l6, !tbaa !24
  store i64 %t322, ptr %l127, !tbaa !24
  %t323 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t324 = extractvalue { i64, ptr } %t323, 0
  store i64 %t324, ptr %l128, !tbaa !24
  %t325 = icmp sge i64 0, 0
  br i1 %t325, label %bb82, label %bb83
bb82:
  %t327 = load i64, ptr %l127, !tbaa !24
  %t328 = icmp sle i64 0, %t327
  br i1 %t328, label %bb84, label %bb85
bb83:
  call void @__olang_check_failed(ptr @olang_loc_50111c761c56dd5f_b5d6bbb7817ca613)
  unreachable
bb84:
  %t330 = load i64, ptr %l127, !tbaa !24
  %t331 = load i64, ptr %l128, !tbaa !24
  %t332 = icmp sle i64 %t330, %t331
  br i1 %t332, label %bb86, label %bb87
bb85:
  call void @__olang_check_failed(ptr @olang_loc_50111c761c56dd5f_b5d6bbb7817ca613)
  unreachable
bb86:
  %t334 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t335 = load ptr, ptr %t334, !tbaa !27
  %t336 = load i64, ptr %l127, !tbaa !24
  %t337 = getelementptr i8, ptr %t335, i64 0
  %t338 = sub i64 %t336, 0
  %t339 = insertvalue { i64, ptr } undef, i64 %t338, 0
  %t340 = insertvalue { i64, ptr } %t339, ptr %t337, 1
  %t342 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %s0, { i64, ptr } %t340)
  store { i64, ptr } %t342, ptr %l133
  br label %bb88
bb87:
  call void @__olang_check_failed(ptr @olang_loc_50111c761c56dd5f_b5d6bbb7817ca613)
  unreachable
bb88:
  %t343 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t344 = extractvalue { i64, ptr } %t343, 1
  %t345 = extractvalue { i64, ptr } %t343, 0
  %t346 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t345)
  call void @olang_textcopy(ptr %t346, ptr %t344, i64 %t345)
  %t347 = insertvalue { i64, ptr } undef, i64 %t345, 0
  %t348 = insertvalue { i64, ptr } %t347, ptr %t346, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t348, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2flisting_2enoCode(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca i64
  %l12 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l26 = alloca i1
  %l27 = alloca i1
  %l29 = alloca i64
  %l34 = alloca i1
  %l35 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l40 = alloca i64
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l4
  %t3 = load ptr, ptr %l2, !tbaa !29
  store ptr %t3, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  %t5 = load i64, ptr %l6, !tbaa !24
  store i64 %t5, ptr %l10, !tbaa !24
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v2, ptr %t6)
  store i64 %t8, ptr %l12
  br label %bb3
bb3:
  %t9 = load i64, ptr %l10, !tbaa !24
  %t10 = load i64, ptr %l12, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb4, label %bb5
bb4:
  br label %bb11
bb5:
  br label %bb6
bb6:
  %t15 = load ptr, ptr %l5, !tbaa !29
  %t16 = load i64, ptr %l6, !tbaa !24
  %t19 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %v2, ptr %t15, i64 %t16)
  store { i64, ptr } %t19, ptr %l17
  br label %bb7
bb7:
  %t20 = load { i64, ptr }, ptr %l17, !tbaa !27
  store ptr %l4, ptr %l18, !tbaa !29
  %t25 = call { i64, ptr } @compiler_2flisting_2ecompiler_2flisting_3aNamer_2eName(ptr %v3, ptr %v2, ptr %s0, ptr %a3, { i64, ptr } %t20)
  store { i64, ptr } %t25, ptr %l21
  br label %bb8
bb8:
  %t26 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t26, 0
  %t28 = extractvalue { i64, ptr } %t26, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t33 = load ptr, ptr %l18, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t33, { i64, ptr } %t32)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t35 = load i64, ptr %l6, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l6, !tbaa !24
  br label %bb2
bb11:
  %t39 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t41 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t39, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d186, i32 0, i32 1) })
  store i1 %t41, ptr %l26
  br label %bb12
bb12:
  %t42 = load i1, ptr %l26, !tbaa !21
  br i1 %t42, label %bb13, label %bb14
bb13:
  %t43 = load ptr, ptr %l2, !tbaa !29
  %t45 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v2, ptr %t43)
  store i64 %t45, ptr %l29
  br label %bb15
bb14:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb16
bb15:
  %t46 = load i64, ptr %l29, !tbaa !24
  %t47 = icmp eq i64 %t46, 0
  store i1 %t47, ptr %l27, !tbaa !21
  br label %bb16
bb16:
  %t49 = load i1, ptr %l27, !tbaa !21
  br i1 %t49, label %bb17, label %bb18
bb17:
  %t50 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t50, 1
  %t53 = extractvalue { i64, ptr } %t50, 0
  %t54 = extractvalue { i64, ptr } { i64 65, ptr getelementptr inbounds (<{ i64, [65 x i8] }>, ptr @.d187, i32 0, i32 1) }, 1
  %t55 = extractvalue { i64, ptr } { i64 65, ptr getelementptr inbounds (<{ i64, [65 x i8] }>, ptr @.d187, i32 0, i32 1) }, 0
  %t56 = add i64 %t53, %t55
  %t57 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t52, i64 %t53)
  %t58 = getelementptr i8, ptr %t57, i64 %t53
  call void @olang_textcopy(ptr %t58, ptr %t54, i64 %t55)
  %t59 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t57, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t60, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t62 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t64 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t62, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d188, i32 0, i32 1) })
  store i1 %t64, ptr %l34
  br label %bb20
bb20:
  %t65 = load i1, ptr %l34, !tbaa !21
  br i1 %t65, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s6
  %t66 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t66, ptr %l35, !tbaa !27
  %t68 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s0, ptr %s6, ptr %s6, ptr %l4, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d189, i32 0, i32 1) })
  store { i64, ptr } %t68, ptr %l37
  br label %bb23
bb22:
  br label %bb24
bb23:
  %t69 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 1
  %t71 = extractvalue { i64, ptr } %t69, 0
  %t72 = extractvalue { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d190, i32 0, i32 1) }, 1
  %t73 = extractvalue { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d190, i32 0, i32 1) }, 0
  %t74 = add i64 %t71, %t73
  %t75 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 1
  %t77 = extractvalue { i64, ptr } %t75, 0
  %t78 = add i64 %t74, %t77
  %t79 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d191, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d191, i32 0, i32 1) }, 0
  %t81 = add i64 %t78, %t80
  %t82 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t81)
  call void @olang_textcopy(ptr %t82, ptr %t70, i64 %t71)
  %t83 = getelementptr i8, ptr %t82, i64 %t71
  call void @olang_textcopy(ptr %t83, ptr %t72, i64 %t73)
  %t84 = getelementptr i8, ptr %t83, i64 %t73
  call void @olang_textcopy(ptr %t84, ptr %t76, i64 %t77)
  %t85 = getelementptr i8, ptr %t84, i64 %t77
  call void @olang_textcopy(ptr %t85, ptr %t79, i64 %t80)
  %t86 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t82, 1
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t87, ptr %rv
  br label %ret
bb24:
  %t89 = load ptr, ptr %l2, !tbaa !29
  %t91 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v2, ptr %t89)
  store i64 %t91, ptr %l40
  br label %bb25
bb25:
  %t92 = load i64, ptr %l40, !tbaa !24
  %t93 = icmp eq i64 %t92, 0
  br i1 %t93, label %bb26, label %bb27
bb26:
  %t95 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t95, 1
  %t99 = extractvalue { i64, ptr } %t95, 0
  %t100 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d192, i32 0, i32 1) }, 1
  %t101 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d192, i32 0, i32 1) }, 0
  %t102 = add i64 %t99, %t101
  %t104 = extractvalue { i64, ptr } %t96, 1
  %t105 = extractvalue { i64, ptr } %t96, 0
  %t106 = add i64 %t102, %t105
  %t107 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d193, i32 0, i32 1) }, 1
  %t108 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d193, i32 0, i32 1) }, 0
  %t109 = add i64 %t106, %t108
  %t110 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t109)
  call void @olang_textcopy(ptr %t110, ptr %t98, i64 %t99)
  %t111 = getelementptr i8, ptr %t110, i64 %t99
  call void @olang_textcopy(ptr %t111, ptr %t100, i64 %t101)
  %t112 = getelementptr i8, ptr %t111, i64 %t101
  call void @olang_textcopy(ptr %t112, ptr %t104, i64 %t105)
  %t113 = getelementptr i8, ptr %t112, i64 %t105
  call void @olang_textcopy(ptr %t113, ptr %t107, i64 %t108)
  %t114 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t110, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t115, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t117 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t117, ptr %l45, !tbaa !27
  %t118 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t118, ptr %l46, !tbaa !27
  %t120 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s0, ptr %s0, ptr %s0, ptr %l4, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d194, i32 0, i32 1) })
  store { i64, ptr } %t120, ptr %l48
  br label %bb29
bb29:
  %t121 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t121, 1
  %t123 = extractvalue { i64, ptr } %t121, 0
  %t124 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d195, i32 0, i32 1) }, 1
  %t125 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d195, i32 0, i32 1) }, 0
  %t126 = add i64 %t123, %t125
  %t127 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t127, 1
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t130 = add i64 %t126, %t129
  %t131 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d196, i32 0, i32 1) }, 1
  %t132 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d196, i32 0, i32 1) }, 0
  %t133 = add i64 %t130, %t132
  %t134 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t134, 1
  %t136 = extractvalue { i64, ptr } %t134, 0
  %t137 = add i64 %t133, %t136
  %t138 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d197, i32 0, i32 1) }, 1
  %t139 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d197, i32 0, i32 1) }, 0
  %t140 = add i64 %t137, %t139
  %t141 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t140)
  call void @olang_textcopy(ptr %t141, ptr %t122, i64 %t123)
  %t142 = getelementptr i8, ptr %t141, i64 %t123
  call void @olang_textcopy(ptr %t142, ptr %t124, i64 %t125)
  %t143 = getelementptr i8, ptr %t142, i64 %t125
  call void @olang_textcopy(ptr %t143, ptr %t128, i64 %t129)
  %t144 = getelementptr i8, ptr %t143, i64 %t129
  call void @olang_textcopy(ptr %t144, ptr %t131, i64 %t132)
  %t145 = getelementptr i8, ptr %t144, i64 %t132
  call void @olang_textcopy(ptr %t145, ptr %t135, i64 %t136)
  %t146 = getelementptr i8, ptr %t145, i64 %t136
  call void @olang_textcopy(ptr %t146, ptr %t138, i64 %t139)
  %t147 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t141, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t148, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2flisting_2eofAny(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l13 = alloca { i64, ptr }
  %l18 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %t19, i64 %t16
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !37
  %t27 = call i1 @compiler_2flisting_2eofSym(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %t21)
  store i1 %t27, ptr %l18
  br label %bb5
bb5:
  %t28 = load i1, ptr %l18, !tbaa !21
  br i1 %t28, label %bb6, label %bb7
bb6:
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t30 = load i64, ptr %l3, !tbaa !24
  %t32 = add i64 %t30, 1
  store i64 %t32, ptr %l3, !tbaa !24
  br label %bb1
bb10:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flisting_2eofSym(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca i1
  %l10 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t1, { i64, ptr } %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb5
bb3:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 1
  %t11 = extractvalue { i64, ptr } %t8, 0
  %t12 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d198, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d198, i32 0, i32 1) }, 0
  %t14 = add i64 %t11, %t13
  %t15 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t14)
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = getelementptr i8, ptr %t15, i64 %t11
  call void @olang_textcopy(ptr %t16, ptr %t12, i64 %t13)
  %t17 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t15, 1
  %t20 = extractvalue { i64, ptr } %t18, 0
  %t21 = extractvalue { i64, ptr } %t18, 1
  %t22 = mul i64 %t20, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  %t28 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t7, { i64, ptr } %t25)
  store i1 %t28, ptr %l10
  br label %bb4
bb4:
  %t29 = load i1, ptr %l10, !tbaa !21
  store i1 %t29, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t30 = load i1, ptr %l5, !tbaa !21
  store i1 %t30, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flisting_2eplaceLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l26 = alloca i1
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l42 = alloca i1
  %l43 = alloca i64
  %l44 = alloca { i64, ptr }
  %l46 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l54 = alloca { i64, ptr }
  %l55 = alloca i64
  %l56 = alloca i32
  %l57 = alloca i64
  %l58 = alloca i32
  %l59 = alloca i64
  %l60 = alloca { i64, ptr }
  %l62 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l70 = alloca { i64, ptr }
  %l71 = alloca i64
  %l72 = alloca i32
  %l73 = alloca i64
  %l74 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d199, i32 0, i32 1) })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l7
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i64 %t4, ptr %l6
  br label %bb1
bb1:
  %t8 = load i64, ptr %l6, !tbaa !24
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t9 = load i64, ptr %l4, !tbaa !24
  store i64 %t9, ptr %l2, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t12 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v1, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d200, i32 0, i32 1) })
  %t13 = extractvalue { i32, i64 } %t12, 1
  %t14 = extractvalue { i32, i64 } %t12, 0
  store i32 %t14, ptr %l11
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb6, label %ok.16, !prof !99
ok.16:
  store i64 %t13, ptr %l10
  br label %bb5
bb5:
  %t17 = load i64, ptr %l10, !tbaa !24
  store i64 %t17, ptr %l8, !tbaa !24
  br label %bb8
bb6:
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  %t18 = load i64, ptr %l8, !tbaa !24
  store i64 %t18, ptr %l3, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t19, ptr %l12, !tbaa !27
  %t20 = load i64, ptr %l2, !tbaa !24
  store i64 %t20, ptr %l13, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  store i64 %t22, ptr %l14, !tbaa !24
  %t23 = icmp sge i64 0, 0
  br i1 %t23, label %bb9, label %bb10
bb9:
  %t25 = load i64, ptr %l13, !tbaa !24
  %t26 = icmp sle i64 0, %t25
  br i1 %t26, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_17a8c3c34efffa58_c9c69620944e8c6c)
  unreachable
bb11:
  %t28 = load i64, ptr %l13, !tbaa !24
  %t29 = load i64, ptr %l14, !tbaa !24
  %t30 = icmp sle i64 %t28, %t29
  br i1 %t30, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_17a8c3c34efffa58_c9c69620944e8c6c)
  unreachable
bb13:
  %t32 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = load i64, ptr %l13, !tbaa !24
  %t35 = getelementptr i8, ptr %t33, i64 0
  %t36 = sub i64 %t34, 0
  %t37 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t35, 1
  store { i64, ptr } %t38, ptr %l18, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t39, ptr %l19, !tbaa !27
  %t40 = load i64, ptr %l3, !tbaa !24
  store i64 %t40, ptr %l20, !tbaa !24
  %t41 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 0
  store i64 %t42, ptr %l21, !tbaa !24
  %t43 = icmp sge i64 0, 0
  br i1 %t43, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_17a8c3c34efffa58_c9c69620944e8c6c)
  unreachable
bb15:
  %t45 = load i64, ptr %l20, !tbaa !24
  %t46 = icmp sle i64 0, %t45
  br i1 %t46, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_17a8c3c34efffa58_c9c69620944e8c6c)
  unreachable
bb17:
  %t48 = load i64, ptr %l20, !tbaa !24
  %t49 = load i64, ptr %l21, !tbaa !24
  %t50 = icmp sle i64 %t48, %t49
  br i1 %t50, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_17a8c3c34efffa58_c9c69620944e8c6c)
  unreachable
bb19:
  %t52 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = load i64, ptr %l20, !tbaa !24
  %t55 = getelementptr i8, ptr %t53, i64 0
  %t56 = sub i64 %t54, 0
  %t57 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t55, 1
  %t59 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t61 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t59, { i64, ptr } %t58)
  store i1 %t61, ptr %l26
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_17a8c3c34efffa58_c9c69620944e8c6c)
  unreachable
bb21:
  %t62 = load i1, ptr %l26, !tbaa !21
  %t63 = xor i1 %t62, true
  br i1 %t63, label %bb22, label %bb23
bb22:
  %t65 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t65, ptr %l28, !tbaa !27
  %t66 = load i64, ptr %l2, !tbaa !24
  store i64 %t66, ptr %l29, !tbaa !24
  %t67 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 0
  store i64 %t68, ptr %l30, !tbaa !24
  %t69 = icmp sge i64 0, 0
  br i1 %t69, label %bb24, label %bb25
bb23:
  br label %bb37
bb24:
  %t71 = load i64, ptr %l29, !tbaa !24
  %t72 = icmp sle i64 0, %t71
  br i1 %t72, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_17a8c3c34efffa58_c9c69620944e8c6c)
  unreachable
bb26:
  %t74 = load i64, ptr %l29, !tbaa !24
  %t75 = load i64, ptr %l30, !tbaa !24
  %t76 = icmp sle i64 %t74, %t75
  br i1 %t76, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_17a8c3c34efffa58_c9c69620944e8c6c)
  unreachable
bb28:
  %t78 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = load i64, ptr %l29, !tbaa !24
  %t81 = getelementptr i8, ptr %t79, i64 0
  %t82 = sub i64 %t80, 0
  %t83 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t81, 1
  store { i64, ptr } %t84, ptr %l34, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t85, ptr %l35, !tbaa !27
  %t86 = load i64, ptr %l3, !tbaa !24
  store i64 %t86, ptr %l36, !tbaa !24
  %t87 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  store i64 %t88, ptr %l37, !tbaa !24
  %t89 = icmp sge i64 0, 0
  br i1 %t89, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_17a8c3c34efffa58_c9c69620944e8c6c)
  unreachable
bb30:
  %t91 = load i64, ptr %l36, !tbaa !24
  %t92 = icmp sle i64 0, %t91
  br i1 %t92, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_17a8c3c34efffa58_c9c69620944e8c6c)
  unreachable
bb32:
  %t94 = load i64, ptr %l36, !tbaa !24
  %t95 = load i64, ptr %l37, !tbaa !24
  %t96 = icmp sle i64 %t94, %t95
  br i1 %t96, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_17a8c3c34efffa58_c9c69620944e8c6c)
  unreachable
bb34:
  %t98 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = load i64, ptr %l36, !tbaa !24
  %t101 = getelementptr i8, ptr %t99, i64 0
  %t102 = sub i64 %t100, 0
  %t103 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t101, 1
  %t105 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t107 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %t105, { i64, ptr } %t104)
  store i1 %t107, ptr %l42
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_17a8c3c34efffa58_c9c69620944e8c6c)
  unreachable
bb36:
  call void @__olang_scope_close(ptr %s0)
  %t108 = load i1, ptr %l42, !tbaa !21
  store i1 %t108, ptr %rv
  br label %ret
bb37:
  %t109 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t109, ptr %l44, !tbaa !27
  %t110 = load i64, ptr %l2, !tbaa !24
  %t112 = add i64 %t110, 1
  store i64 %t112, ptr %l46, !tbaa !24
  %t113 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t113, 0
  store i64 %t116, ptr %l49, !tbaa !24
  %t117 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t117, 0
  store i64 %t118, ptr %l50, !tbaa !24
  %t119 = load i64, ptr %l46, !tbaa !24
  %t120 = icmp sge i64 %t119, 0
  br i1 %t120, label %bb38, label %bb39
bb38:
  %t122 = load i64, ptr %l46, !tbaa !24
  %t123 = load i64, ptr %l49, !tbaa !24
  %t124 = icmp sle i64 %t122, %t123
  br i1 %t124, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_f8bac9f6e1e646b5_a02e035c32962b19)
  unreachable
bb40:
  %t126 = load i64, ptr %l49, !tbaa !24
  %t127 = load i64, ptr %l50, !tbaa !24
  %t128 = icmp sle i64 %t126, %t127
  br i1 %t128, label %bb42, label %bb43
bb41:
  call void @__olang_check_failed(ptr @olang_loc_f8bac9f6e1e646b5_a02e035c32962b19)
  unreachable
bb42:
  %t130 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = load i64, ptr %l46, !tbaa !24
  %t133 = load i64, ptr %l49, !tbaa !24
  %t134 = getelementptr i8, ptr %t131, i64 %t132
  %t135 = sub i64 %t133, %t132
  %t136 = insertvalue { i64, ptr } undef, i64 %t135, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t134, 1
  store { i64, ptr } %t137, ptr %l54, !tbaa !27
  %t138 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 10)
  %t139 = extractvalue { i32, i64 } %t138, 1
  %t140 = extractvalue { i32, i64 } %t138, 0
  store i32 %t140, ptr %l56
  %t141 = icmp ne i32 %t140, 0
  br i1 %t141, label %bb45, label %ok.142, !prof !99
ok.142:
  store i64 %t139, ptr %l55
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_f8bac9f6e1e646b5_a02e035c32962b19)
  unreachable
bb44:
  %t143 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t144 = load i64, ptr %l55, !tbaa !24
  %t145 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %t143, i64 %t144)
  %t146 = extractvalue { i32, i64 } %t145, 1
  %t147 = extractvalue { i32, i64 } %t145, 0
  store i32 %t147, ptr %l58
  %t148 = icmp ne i32 %t147, 0
  br i1 %t148, label %bb48, label %ok.149, !prof !99
ok.149:
  store i64 %t146, ptr %l57
  br label %bb47
bb45:
  br label %bb46
bb46:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l43, !tbaa !24
  br label %bb49
bb47:
  %t150 = load i64, ptr %l57, !tbaa !24
  store i64 %t150, ptr %l43, !tbaa !24
  br label %bb49
bb48:
  br label %bb46
bb49:
  %t151 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t151, ptr %l60, !tbaa !27
  %t152 = load i64, ptr %l3, !tbaa !24
  %t154 = add i64 %t152, 1
  store i64 %t154, ptr %l62, !tbaa !24
  %t155 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t155, 0
  store i64 %t158, ptr %l65, !tbaa !24
  %t159 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t159, 0
  store i64 %t160, ptr %l66, !tbaa !24
  %t161 = load i64, ptr %l62, !tbaa !24
  %t162 = icmp sge i64 %t161, 0
  br i1 %t162, label %bb50, label %bb51
bb50:
  %t164 = load i64, ptr %l62, !tbaa !24
  %t165 = load i64, ptr %l65, !tbaa !24
  %t166 = icmp sle i64 %t164, %t165
  br i1 %t166, label %bb52, label %bb53
bb51:
  call void @__olang_check_failed(ptr @olang_loc_f8bac9f6e1e646b5_a02e035c32962b19)
  unreachable
bb52:
  %t168 = load i64, ptr %l65, !tbaa !24
  %t169 = load i64, ptr %l66, !tbaa !24
  %t170 = icmp sle i64 %t168, %t169
  br i1 %t170, label %bb54, label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_f8bac9f6e1e646b5_a02e035c32962b19)
  unreachable
bb54:
  %t172 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = load i64, ptr %l62, !tbaa !24
  %t175 = load i64, ptr %l65, !tbaa !24
  %t176 = getelementptr i8, ptr %t173, i64 %t174
  %t177 = sub i64 %t175, %t174
  %t178 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t176, 1
  store { i64, ptr } %t179, ptr %l70, !tbaa !27
  %t180 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 10)
  %t181 = extractvalue { i32, i64 } %t180, 1
  %t182 = extractvalue { i32, i64 } %t180, 0
  store i32 %t182, ptr %l72
  %t183 = icmp ne i32 %t182, 0
  br i1 %t183, label %bb57, label %ok.184, !prof !99
ok.184:
  store i64 %t181, ptr %l71
  br label %bb56
bb55:
  call void @__olang_check_failed(ptr @olang_loc_f8bac9f6e1e646b5_a02e035c32962b19)
  unreachable
bb56:
  %t185 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t186 = load i64, ptr %l71, !tbaa !24
  %t187 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v1, { i64, ptr } %t185, i64 %t186)
  %t188 = extractvalue { i32, i64 } %t187, 1
  %t189 = extractvalue { i32, i64 } %t187, 0
  store i32 %t189, ptr %l74
  %t190 = icmp ne i32 %t189, 0
  br i1 %t190, label %bb60, label %ok.191, !prof !99
ok.191:
  store i64 %t188, ptr %l73
  br label %bb59
bb57:
  br label %bb58
bb58:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l59, !tbaa !24
  br label %bb61
bb59:
  %t192 = load i64, ptr %l73, !tbaa !24
  store i64 %t192, ptr %l59, !tbaa !24
  br label %bb61
bb60:
  br label %bb58
bb61:
  %t193 = load i64, ptr %l43, !tbaa !24
  %t194 = load i64, ptr %l59, !tbaa !24
  %t195 = icmp slt i64 %t193, %t194
  call void @__olang_scope_close(ptr %s0)
  store i1 %t195, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2flisting_2eplaceOf(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca i1
  %l7 = alloca i1
  %l8 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/listing:Remark", ptr %t1, i32 0, i32 3
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t4, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d201, i32 0, i32 1) })
  store i1 %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load i1, ptr %l3, !tbaa !21
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb5
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/listing:Remark", ptr %t8, i32 0, i32 3
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t11, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d202, i32 0, i32 1) })
  store i1 %t13, ptr %l7
  br label %bb4
bb4:
  %t14 = load i1, ptr %l7, !tbaa !21
  store i1 %t14, ptr %l4, !tbaa !21
  br label %bb5
bb5:
  %t15 = load i1, ptr %l4, !tbaa !21
  br i1 %t15, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb8
bb7:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/listing:Remark", ptr %t16, i32 0, i32 4
  %t19 = load i64, ptr %t18, !tbaa !24
  %t21 = icmp sle i64 %t19, 0
  store i1 %t21, ptr %l8, !tbaa !21
  br label %bb8
bb8:
  %t23 = load i1, ptr %l8, !tbaa !21
  br i1 %t23, label %bb9, label %bb10
bb9:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d203, i32 0, i32 1) }, ptr %l13, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t24, ptr %l12, !tbaa !27
  br label %bb11
bb10:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/listing:Remark", ptr %t26, i32 0, i32 3
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/listing:Remark", ptr %t30, i32 0, i32 4
  %t33 = load i64, ptr %t32, !tbaa !24
  %t35 = extractvalue { i64, ptr } %t29, 1
  %t36 = extractvalue { i64, ptr } %t29, 0
  %t37 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d204, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d204, i32 0, i32 1) }, 0
  %t39 = add i64 %t36, %t38
  %t41 = call i64 @__olang_fmt_i64(ptr null, i64 %t33)
  %t42 = add i64 %t39, %t41
  %t43 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t42)
  call void @olang_textcopy(ptr %t43, ptr %t35, i64 %t36)
  %t44 = getelementptr i8, ptr %t43, i64 %t36
  call void @olang_textcopy(ptr %t44, ptr %t37, i64 %t38)
  %t45 = getelementptr i8, ptr %t44, i64 %t38
  %t46 = call i64 @__olang_fmt_i64(ptr %t45, i64 %t33)
  %t47 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t43, 1
  store { i64, ptr } %t48, ptr %l12, !tbaa !27
  br label %bb11
bb11:
  %t50 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t50, 0
  store i64 %t51, ptr %l20, !tbaa !24
  %t52 = load i64, ptr %l20, !tbaa !24
  %t53 = mul i64 %t52, 1
  %t54 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t53)
  %t55 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t54, 1
  store { i64, ptr } %t56, ptr %l21, !tbaa !27
  %t57 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = load i64, ptr %l20, !tbaa !24
  %t62 = mul i64 %t61, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t58, ptr %t60, i64 %t62, i1 false)
  %t63 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t63, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t64 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t64, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2flisting_2ereadParts(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %lp1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca i64
  %l9 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i32
  %l21 = alloca i1
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  store ptr %a0, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l3, !tbaa !24
  store i64 %t7, ptr %l7, !tbaa !24
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l9
  br label %bb3
bb3:
  %t11 = load i64, ptr %l7, !tbaa !24
  %t12 = load i64, ptr %l9, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb4, label %bb5
bb4:
  br label %bb14
bb5:
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t17, i64 %t18)
  store { i64, ptr } %t21, ptr %l14
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t23 = load ptr, ptr %lp1
  store ptr %t23, ptr %l15, !tbaa !29
  %t26 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %t22)
  %t27 = extractvalue { i32, { i64, ptr } } %t26, 1
  %t28 = extractvalue { i32, { i64, ptr } } %t26, 0
  store i32 %t28, ptr %l19
  %t29 = icmp ne i32 %t28, 0
  br i1 %t29, label %bb9, label %ok.30, !prof !99
ok.30:
  store { i64, ptr } %t27, ptr %l18
  br label %bb8
bb8:
  %t31 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t31, ptr %l16, !tbaa !27
  br label %bb11
bb9:
  %t32 = load i32, ptr %l19, !tbaa !23
  %t33 = ashr i32 %t32, 16
  %t35 = icmp eq i32 %t33, 1
  store i1 %t35, ptr %l21, !tbaa !21
  br label %bb10
bb10:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d205, i32 0, i32 1) }, ptr %l16, !tbaa !27
  br label %bb11
bb11:
  %t36 = load ptr, ptr %l15, !tbaa !29
  %t37 = load { i64, ptr }, ptr %l16, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t36, { i64, ptr } %t37)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb2
bb14:
  %t42 = load ptr, ptr %lp1
  %t43 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t42
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t43, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2flisting_2ereadRemarks(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca i1
  %l7 = alloca %"std/prelude/text:LineIter"
  %l8 = alloca { i64, ptr }
  %l9 = alloca { { i64, ptr }, { i64, ptr } }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca %"compiler/listing:Remark"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca %"std/prelude/text:LineIter"
  %l22 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i32
  %l27 = alloca i1
  %l29 = alloca i1
  %l30 = alloca %"compiler/listing:Remark"
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l43 = alloca { i64, ptr }
  %l46 = alloca i1
  %l47 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l59 = alloca i1
  %l60 = alloca i1
  %l64 = alloca i1
  %l65 = alloca i1
  %l68 = alloca i1
  %l69 = alloca i1
  %l72 = alloca i1
  %l77 = alloca i1
  %l78 = alloca i1
  %l80 = alloca i1
  %l83 = alloca i1
  %l87 = alloca { i64, ptr }
  %l90 = alloca i64
  %l91 = alloca i64
  %l96 = alloca { { i64, ptr }, { i64, ptr } }
  %l98 = alloca { i64, ptr }
  %l99 = alloca i64
  %l100 = alloca { i64, ptr }
  %l102 = alloca i1
  %l103 = alloca ptr
  %l105 = alloca { i64, ptr }
  %l108 = alloca i1
  %l112 = alloca i1
  %l115 = alloca { i64, ptr }
  %l117 = alloca i1
  %l118 = alloca i1
  %l120 = alloca i1
  %l122 = alloca i1
  %l123 = alloca i1
  %l125 = alloca i1
  %l126 = alloca i1
  %l128 = alloca i1
  %l131 = alloca { i64, ptr }
  %l133 = alloca i64
  %l144 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/listing:Remark" @compiler_2flisting_3aRemark_2ector(ptr %v3)
  store %"compiler/listing:Remark" %t1, ptr %l17
  br label %bb1
bb1:
  %t2 = load %"compiler/listing:Remark", ptr %l17
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 120, i64 8)
  store %"compiler/listing:Remark" %t2, ptr %t3
  store ptr %t3, ptr %l4, !tbaa !29
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aChar_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l19
  br label %bb2
bb2:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l5
  store i1 false, ptr %l6, !tbaa !21
  %t9 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store %"std/prelude/text:LineIter" %t9, ptr %l21
  br label %bb3
bb3:
  %t10 = load %"std/prelude/text:LineIter", ptr %l21
  store %"std/prelude/text:LineIter" %t10, ptr %l7
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t12 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v0, ptr %l7)
  %t13 = extractvalue { i32, { i64, ptr } } %t12, 1
  %t14 = extractvalue { i32, { i64, ptr } } %t12, 0
  store i32 %t14, ptr %l25
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb6, label %ok.16, !prof !99
ok.16:
  store { i64, ptr } %t13, ptr %l24
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t17, ptr %l22, !tbaa !27
  br label %bb8
bb6:
  %t18 = load i32, ptr %l25, !tbaa !23
  %t19 = ashr i32 %t18, 16
  %t21 = icmp eq i32 %t19, 1
  store i1 %t21, ptr %l27, !tbaa !21
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb113
bb8:
  %t22 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t22, ptr %l8, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t25 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t23, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d206, i32 0, i32 1) })
  store i1 %t25, ptr %l29
  br label %bb9
bb9:
  %t26 = load i1, ptr %l29, !tbaa !21
  br i1 %t26, label %bb10, label %bb11
bb10:
  %t27 = call %"compiler/listing:Remark" @compiler_2flisting_3aRemark_2ector(ptr %v3)
  store %"compiler/listing:Remark" %t27, ptr %l30
  br label %bb12
bb11:
  br label %bb21
bb12:
  %t28 = load %"compiler/listing:Remark", ptr %l30
  %t29 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 120, i64 8)
  store %"compiler/listing:Remark" %t28, ptr %t29
  store ptr %t29, ptr %l4, !tbaa !29
  %t31 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aChar_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t31, ptr %l32
  br label %bb13
bb13:
  %t32 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %l5
  store i1 false, ptr %l6, !tbaa !21
  %t33 = load ptr, ptr %l4, !tbaa !29
  store ptr %t33, ptr %l33, !tbaa !29
  %t34 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t34, ptr %l34, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t35, 0
  store i64 %t38, ptr %l37, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l38, !tbaa !24
  %t41 = icmp sge i64 5, 0
  br i1 %t41, label %bb14, label %bb15
bb14:
  %t43 = load i64, ptr %l37, !tbaa !24
  %t44 = icmp sle i64 5, %t43
  br i1 %t44, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_1658fd7d2958cee1_67b9b3ad391c8d45)
  unreachable
bb16:
  %t46 = load i64, ptr %l37, !tbaa !24
  %t47 = load i64, ptr %l38, !tbaa !24
  %t48 = icmp sle i64 %t46, %t47
  br i1 %t48, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_1658fd7d2958cee1_67b9b3ad391c8d45)
  unreachable
bb18:
  %t50 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = load i64, ptr %l37, !tbaa !24
  %t53 = getelementptr i8, ptr %t51, i64 5
  %t54 = sub i64 %t52, 5
  %t55 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t53, 1
  %t58 = call { i64, ptr } @compiler_2flisting_2ekindWord(ptr %v0, ptr %v3, { i64, ptr } %t56)
  store { i64, ptr } %t58, ptr %l43
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_1658fd7d2958cee1_67b9b3ad391c8d45)
  unreachable
bb20:
  %t59 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 0
  %t61 = extractvalue { i64, ptr } %t59, 1
  %t62 = mul i64 %t60, 1
  %t63 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t62)
  call void @llvm.memcpy.p0.p0.i64(ptr %t63, ptr %t61, i64 %t62, i1 false)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  %t67 = load ptr, ptr %l33, !tbaa !29
  %t68 = getelementptr %"compiler/listing:Remark", ptr %t67, i32 0, i32 0
  store { i64, ptr } %t65, ptr %t68, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  br label %bb112
bb21:
  %t69 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t71 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t69, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d207, i32 0, i32 1) })
  store i1 %t71, ptr %l46
  br label %bb22
bb22:
  %t72 = load i1, ptr %l46, !tbaa !21
  br i1 %t72, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  %t73 = load ptr, ptr %l4, !tbaa !29
  store ptr %t73, ptr %l47, !tbaa !29
  %t75 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aChar_3e_2eToArr_H8081e04b38a8da5362a19182ff2ab7d7(ptr %s0, ptr %s4, ptr %l5)
  store { i64, ptr } %t75, ptr %l49
  br label %bb25
bb24:
  br label %bb44
bb25:
  %t76 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t76, ptr %l50, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t77, 0
  store i64 %t78, ptr %l51, !tbaa !24
  %t79 = load i64, ptr %l51, !tbaa !24
  %t80 = mul i64 %t79, 1
  %t81 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t80)
  %t82 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t81, 1
  store { i64, ptr } %t83, ptr %l52, !tbaa !27
  %t84 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = load i64, ptr %l51, !tbaa !24
  %t89 = mul i64 %t88, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t85, ptr %t87, i64 %t89, i1 false)
  %t90 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t93 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v3, ptr %v3, { i64, ptr } %t90)
  store { i64, ptr } %t93, ptr %l55
  br label %bb26
bb26:
  %t94 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t95 = load ptr, ptr %l47, !tbaa !29
  %t96 = getelementptr %"compiler/listing:Remark", ptr %t95, i32 0, i32 7
  store { i64, ptr } %t94, ptr %t96, !tbaa !27
  %t97 = load ptr, ptr %l4, !tbaa !29
  %t99 = getelementptr %"compiler/listing:Remark", ptr %t97, i32 0, i32 5
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t104 = call i1 @compiler_2flisting_2eofAny(ptr %v3, ptr %v1, { i64, ptr } %t100, { i64, ptr } %t101)
  store i1 %t104, ptr %l59
  br label %bb27
bb27:
  %t105 = load i1, ptr %l59, !tbaa !21
  br i1 %t105, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb39
bb29:
  %t106 = load ptr, ptr %l4, !tbaa !29
  %t108 = getelementptr %"compiler/listing:Remark", ptr %t106, i32 0, i32 6
  %t109 = load { i64, ptr }, ptr %t108, !tbaa !27
  %t110 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t113 = call i1 @compiler_2flisting_2eofAny(ptr %v3, ptr %v1, { i64, ptr } %t109, { i64, ptr } %t110)
  store i1 %t113, ptr %l64
  br label %bb30
bb30:
  %t114 = load i1, ptr %l64, !tbaa !21
  br i1 %t114, label %bb31, label %bb32
bb31:
  %t115 = load ptr, ptr %l4, !tbaa !29
  %t117 = getelementptr %"compiler/listing:Remark", ptr %t115, i32 0, i32 0
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !27
  %t120 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s4, { i64, ptr } %t118, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d208, i32 0, i32 1) })
  store i1 %t120, ptr %l68
  br label %bb33
bb32:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb34
bb33:
  %t121 = load i1, ptr %l68, !tbaa !21
  store i1 %t121, ptr %l65, !tbaa !21
  br label %bb34
bb34:
  %t122 = load i1, ptr %l65, !tbaa !21
  br i1 %t122, label %bb35, label %bb36
bb35:
  %t123 = load ptr, ptr %l4, !tbaa !29
  %t125 = getelementptr %"compiler/listing:Remark", ptr %t123, i32 0, i32 1
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  %t128 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s4, { i64, ptr } %t126, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d209, i32 0, i32 1) })
  store i1 %t128, ptr %l72
  br label %bb37
bb36:
  store i1 false, ptr %l69, !tbaa !21
  br label %bb38
bb37:
  %t129 = load i1, ptr %l72, !tbaa !21
  store i1 %t129, ptr %l69, !tbaa !21
  br label %bb38
bb38:
  %t130 = load i1, ptr %l69, !tbaa !21
  store i1 %t130, ptr %l60, !tbaa !21
  br label %bb39
bb39:
  %t131 = load i1, ptr %l60, !tbaa !21
  br i1 %t131, label %bb40, label %bb41
bb40:
  %t133 = load ptr, ptr %l4, !tbaa !29
  %t135 = load %"compiler/listing:Remark", ptr %t133
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flisting_3aRemark_3e_2ePush_3ccompiler_2flisting_3aRemark_3e(ptr %v3, ptr %v3, ptr %a3, %"compiler/listing:Remark" %t135)
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  br label %bb112
bb44:
  %t138 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t140 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t138, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d210, i32 0, i32 1) })
  store i1 %t140, ptr %l77
  br label %bb45
bb45:
  %t141 = load i1, ptr %l77, !tbaa !21
  br i1 %t141, label %bb46, label %bb47
bb46:
  %t142 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t144 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t142, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d211, i32 0, i32 1) })
  store i1 %t144, ptr %l80
  br label %bb48
bb47:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb49
bb48:
  %t145 = load i1, ptr %l80, !tbaa !21
  %t146 = xor i1 %t145, true
  store i1 %t146, ptr %l78, !tbaa !21
  br label %bb49
bb49:
  %t148 = load i1, ptr %l78, !tbaa !21
  br i1 %t148, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s2)
  br label %bb112
bb51:
  br label %bb52
bb52:
  %t149 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t151 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t149, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d212, i32 0, i32 1) })
  store i1 %t151, ptr %l83
  br label %bb53
bb53:
  %t152 = load i1, ptr %l83, !tbaa !21
  %t153 = xor i1 %t152, true
  br i1 %t153, label %bb54, label %bb55
bb54:
  %t155 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t156 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2flisting_2etopLevel(ptr %v0, ptr %v3, { i64, ptr } %t155, ptr %t156)
  br label %bb56
bb55:
  br label %bb57
bb56:
  call void @__olang_scope_close(ptr %s2)
  br label %bb112
bb57:
  %t159 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t159, ptr %l87, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t160, 0
  store i64 %t163, ptr %l90, !tbaa !24
  %t164 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t164, 0
  store i64 %t165, ptr %l91, !tbaa !24
  %t166 = icmp sge i64 4, 0
  br i1 %t166, label %bb58, label %bb59
bb58:
  %t168 = load i64, ptr %l90, !tbaa !24
  %t169 = icmp sle i64 4, %t168
  br i1 %t169, label %bb60, label %bb61
bb59:
  call void @__olang_check_failed(ptr @olang_loc_679d421df08030f4_bd0b7978ad4d2168)
  unreachable
bb60:
  %t171 = load i64, ptr %l90, !tbaa !24
  %t172 = load i64, ptr %l91, !tbaa !24
  %t173 = icmp sle i64 %t171, %t172
  br i1 %t173, label %bb62, label %bb63
bb61:
  call void @__olang_check_failed(ptr @olang_loc_679d421df08030f4_bd0b7978ad4d2168)
  unreachable
bb62:
  %t175 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !27
  %t177 = load i64, ptr %l90, !tbaa !24
  %t178 = getelementptr i8, ptr %t176, i64 4
  %t179 = sub i64 %t177, 4
  %t180 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t181 = insertvalue { i64, ptr } %t180, ptr %t178, 1
  %t183 = call { { i64, ptr }, { i64, ptr } } @compiler_2flisting_2ekeyValue(ptr %v0, ptr %s2, { i64, ptr } %t181)
  store { { i64, ptr }, { i64, ptr } } %t183, ptr %l96
  br label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_679d421df08030f4_bd0b7978ad4d2168)
  unreachable
bb64:
  %t184 = load { { i64, ptr }, { i64, ptr } }, ptr %l96
  store { { i64, ptr }, { i64, ptr } } %t184, ptr %l9
  %t185 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l9, i32 0, i32 0
  %t186 = load { i64, ptr }, ptr %t185, !tbaa !27
  store { i64, ptr } %t186, ptr %l10, !tbaa !27
  %t188 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l9, i32 0, i32 1
  %t189 = load { i64, ptr }, ptr %t188, !tbaa !27
  store { i64, ptr } %t189, ptr %l98, !tbaa !27
  %t190 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t190, 0
  store i64 %t191, ptr %l99, !tbaa !24
  %t192 = load i64, ptr %l99, !tbaa !24
  %t193 = mul i64 %t192, 1
  %t194 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t193)
  %t195 = insertvalue { i64, ptr } undef, i64 %t192, 0
  %t196 = insertvalue { i64, ptr } %t195, ptr %t194, 1
  store { i64, ptr } %t196, ptr %l100, !tbaa !27
  %t197 = getelementptr { i64, ptr }, ptr %l100, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !27
  %t199 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !27
  %t201 = load i64, ptr %l99, !tbaa !24
  %t202 = mul i64 %t201, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t198, ptr %t200, i64 %t202, i1 false)
  %t203 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t203, ptr %l11, !tbaa !27
  %t204 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t206 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t204, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d213, i32 0, i32 1) })
  store i1 %t206, ptr %l102
  br label %bb65
bb65:
  %t207 = load i1, ptr %l102, !tbaa !21
  br i1 %t207, label %bb66, label %bb67
bb66:
  %t208 = load ptr, ptr %l4, !tbaa !29
  store ptr %t208, ptr %l103, !tbaa !29
  %t209 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t211 = call { i64, ptr } @compiler_2flisting_2eunquote(ptr %s2, ptr %v3, { i64, ptr } %t209)
  store { i64, ptr } %t211, ptr %l105
  br label %bb68
bb67:
  br label %bb69
bb68:
  %t212 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t212, 0
  %t214 = extractvalue { i64, ptr } %t212, 1
  %t215 = mul i64 %t213, 1
  %t216 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t215)
  call void @llvm.memcpy.p0.p0.i64(ptr %t216, ptr %t214, i64 %t215, i1 false)
  %t217 = insertvalue { i64, ptr } undef, i64 %t213, 0
  %t218 = insertvalue { i64, ptr } %t217, ptr %t216, 1
  %t220 = load ptr, ptr %l103, !tbaa !29
  %t221 = getelementptr %"compiler/listing:Remark", ptr %t220, i32 0, i32 6
  store { i64, ptr } %t218, ptr %t221, !tbaa !27
  br label %bb69
bb69:
  %t222 = load i1, ptr %l6, !tbaa !21
  br i1 %t222, label %bb70, label %bb71
bb70:
  store i1 true, ptr %l108, !tbaa !21
  br label %bb73
bb71:
  %t224 = load ptr, ptr %l4, !tbaa !29
  %t226 = getelementptr %"compiler/listing:Remark", ptr %t224, i32 0, i32 5
  %t227 = load { i64, ptr }, ptr %t226, !tbaa !27
  %t228 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t231 = call i1 @compiler_2flisting_2eofAny(ptr %v3, ptr %v1, { i64, ptr } %t227, { i64, ptr } %t228)
  store i1 %t231, ptr %l112
  br label %bb72
bb72:
  %t232 = load i1, ptr %l112, !tbaa !21
  %t233 = xor i1 %t232, true
  store i1 %t233, ptr %l108, !tbaa !21
  br label %bb73
bb73:
  %t235 = load i1, ptr %l108, !tbaa !21
  br i1 %t235, label %bb74, label %bb75
bb74:
  call void @__olang_scope_close(ptr %s2)
  br label %bb112
bb75:
  br label %bb76
bb76:
  %t236 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t238 = call { i64, ptr } @compiler_2flisting_2eunquote(ptr %s2, ptr %s2, { i64, ptr } %t236)
  store { i64, ptr } %t238, ptr %l115
  br label %bb77
bb77:
  %t239 = load { i64, ptr }, ptr %l115, !tbaa !27
  store { i64, ptr } %t239, ptr %l12, !tbaa !27
  %t240 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t242 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t240, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d214, i32 0, i32 1) })
  store i1 %t242, ptr %l117
  br label %bb78
bb78:
  %t243 = load i1, ptr %l117, !tbaa !21
  br i1 %t243, label %bb79, label %bb80
bb79:
  %t244 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t246 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t244, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d215, i32 0, i32 1) })
  store i1 %t246, ptr %l120
  br label %bb81
bb80:
  store i1 false, ptr %l118, !tbaa !21
  br label %bb82
bb81:
  %t247 = load i1, ptr %l120, !tbaa !21
  store i1 %t247, ptr %l118, !tbaa !21
  br label %bb82
bb82:
  %t248 = load i1, ptr %l118, !tbaa !21
  br i1 %t248, label %bb83, label %bb84
bb83:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb85
bb84:
  br label %bb85
bb85:
  %t249 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t251 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t249, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d216, i32 0, i32 1) })
  store i1 %t251, ptr %l122
  br label %bb86
bb86:
  %t252 = load i1, ptr %l122, !tbaa !21
  br i1 %t252, label %bb87, label %bb88
bb87:
  store i1 true, ptr %l123, !tbaa !21
  br label %bb90
bb88:
  %t253 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t255 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t253, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d217, i32 0, i32 1) })
  store i1 %t255, ptr %l125
  br label %bb89
bb89:
  %t256 = load i1, ptr %l125, !tbaa !21
  store i1 %t256, ptr %l123, !tbaa !21
  br label %bb90
bb90:
  %t257 = load i1, ptr %l123, !tbaa !21
  br i1 %t257, label %bb91, label %bb92
bb91:
  store i1 true, ptr %l126, !tbaa !21
  br label %bb94
bb92:
  %t258 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t260 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t258, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d218, i32 0, i32 1) })
  store i1 %t260, ptr %l128
  br label %bb93
bb93:
  %t261 = load i1, ptr %l128, !tbaa !21
  store i1 %t261, ptr %l126, !tbaa !21
  br label %bb94
bb94:
  %t262 = load i1, ptr %l126, !tbaa !21
  br i1 %t262, label %bb95, label %bb96
bb95:
  %t264 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t267 = call { i64, ptr } @compiler_2flisting_2ecompiler_2flisting_3aNamer_2eName(ptr %v2, ptr %s2, ptr %s2, ptr %a2, { i64, ptr } %t264)
  store { i64, ptr } %t267, ptr %l131
  br label %bb97
bb96:
  br label %bb101
bb97:
  %t268 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t269 = extractvalue { i64, ptr } %t268, 0
  %t270 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t271 = extractvalue { i64, ptr } %t270, 0
  store i64 %t271, ptr %l133, !tbaa !24
  %t273 = load i64, ptr %l133, !tbaa !24
  %t274 = icmp eq i64 %t269, %t273
  br i1 %t274, label %bb98, label %bb99
bb98:
  %t276 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !27
  %t278 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = load i64, ptr %l133, !tbaa !24
  %t281 = mul i64 %t280, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t277, ptr %t279, i64 %t281, i1 false)
  br label %bb100
bb99:
  %t282 = load { i64, ptr }, ptr %l131, !tbaa !27
  store { i64, ptr } %t282, ptr %l12, !tbaa !27
  br label %bb100
bb100:
  br label %bb101
bb101:
  %t283 = load i1, ptr %l6, !tbaa !21
  %t285 = xor i1 %t283, true
  br i1 %t285, label %bb102, label %bb103
bb102:
  %t287 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t287, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t289 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t291 = extractvalue { i64, ptr } %t289, 0
  store i64 %t291, ptr %l15, !tbaa !24
  br label %bb104
bb103:
  br label %bb111
bb104:
  %t293 = load i64, ptr %l14, !tbaa !24
  %t294 = load i64, ptr %l15, !tbaa !24
  %t297 = icmp slt i64 %t293, %t294
  %t299 = xor i1 %t297, true
  br i1 %t299, label %bb105, label %bb106
bb105:
  br label %bb110
bb106:
  br label %bb107
bb107:
  %t301 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t301, ptr %l144, !tbaa !27
  %t302 = load i64, ptr %l14, !tbaa !24
  %t304 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t305 = load ptr, ptr %t304, !tbaa !27
  %t306 = getelementptr i8, ptr %t305, i64 %t302
  %t307 = load i8, ptr %t306, !tbaa !32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aChar_3e_2ePush_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %l5, i8 %t307)
  br label %bb108
bb108:
  br label %bb109
bb109:
  %t312 = load i64, ptr %l14, !tbaa !24
  %t314 = add i64 %t312, 1
  store i64 %t314, ptr %l14, !tbaa !24
  br label %bb104
bb110:
  br label %bb111
bb111:
  call void @__olang_scope_close(ptr %s2)
  br label %bb112
bb112:
  br label %bb4
bb113:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2flisting_2esame(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca i1
  %l12 = alloca i1
  %l13 = alloca i1
  %l18 = alloca i1
  %l19 = alloca i1
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l26 = alloca i1
  %l27 = alloca i1
  %l32 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/listing:Remark", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/listing:Remark", ptr %t5, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t11 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t4, { i64, ptr } %t8)
  store i1 %t11, ptr %l6
  br label %bb1
bb1:
  %t12 = load i1, ptr %l6, !tbaa !21
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/listing:Remark", ptr %t13, i32 0, i32 1
  %t16 = load { i64, ptr }, ptr %t15, !tbaa !27
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr %"compiler/listing:Remark", ptr %t17, i32 0, i32 1
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  %t23 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t16, { i64, ptr } %t20)
  store i1 %t23, ptr %l12
  br label %bb4
bb3:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb5
bb4:
  %t24 = load i1, ptr %l12, !tbaa !21
  store i1 %t24, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l7, !tbaa !21
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/listing:Remark", ptr %t26, i32 0, i32 2
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = getelementptr %"compiler/listing:Remark", ptr %t30, i32 0, i32 2
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  %t36 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t29, { i64, ptr } %t33)
  store i1 %t36, ptr %l18
  br label %bb8
bb7:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb9
bb8:
  %t37 = load i1, ptr %l18, !tbaa !21
  store i1 %t37, ptr %l13, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l13, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = call { i64, ptr } @compiler_2flisting_2eplaceOf(ptr %v0, ptr %s0, ptr %t39)
  store { i64, ptr } %t41, ptr %l21
  br label %bb12
bb11:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb15
bb12:
  %t42 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  %t44 = extractvalue { i64, ptr } %t42, 1
  %t45 = mul i64 %t43, 1
  %t46 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t45)
  call void @llvm.memcpy.p0.p0.i64(ptr %t46, ptr %t44, i64 %t45, i1 false)
  %t47 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  store { i64, ptr } %t48, ptr %l22, !tbaa !27
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = call { i64, ptr } @compiler_2flisting_2eplaceOf(ptr %v1, ptr %s0, ptr %t49)
  store { i64, ptr } %t51, ptr %l24
  br label %bb13
bb13:
  %t52 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 0
  %t54 = extractvalue { i64, ptr } %t52, 1
  %t55 = mul i64 %t53, 1
  %t56 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t55)
  call void @llvm.memcpy.p0.p0.i64(ptr %t56, ptr %t54, i64 %t55, i1 false)
  %t57 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  %t59 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t61 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t59, { i64, ptr } %t58)
  store i1 %t61, ptr %l26
  br label %bb14
bb14:
  %t62 = load i1, ptr %l26, !tbaa !21
  store i1 %t62, ptr %l19, !tbaa !21
  br label %bb15
bb15:
  %t63 = load i1, ptr %l19, !tbaa !21
  br i1 %t63, label %bb16, label %bb17
bb16:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/listing:Remark", ptr %t64, i32 0, i32 7
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !27
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr %"compiler/listing:Remark", ptr %t68, i32 0, i32 7
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  %t74 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t67, { i64, ptr } %t71)
  store i1 %t74, ptr %l32
  br label %bb18
bb17:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb19
bb18:
  %t75 = load i1, ptr %l32, !tbaa !21
  store i1 %t75, ptr %l27, !tbaa !21
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  %t76 = load i1, ptr %l27, !tbaa !21
  store i1 %t76, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2flisting_2esay(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca i32
  %l4 = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0)
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  br label %bb1
bb1:
  br label %bb4
bb2:
  %t6 = load i32, ptr %l2, !tbaa !23
  %t7 = ashr i32 %t6, 16
  %t9 = icmp eq i32 %t7, 1
  store i1 %t9, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flisting_2etopLevel(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { { i64, ptr }, { i64, ptr } }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l6 = alloca { { i64, ptr }, { i64, ptr } }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l12 = alloca i1
  %l13 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l18 = alloca i1
  %l19 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l24 = alloca i1
  %l25 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l30 = alloca i1
  %l31 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l35 = alloca ptr
  %l36 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca i32
  %l42 = alloca i64
  %l43 = alloca i32
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { { i64, ptr }, { i64, ptr } } @compiler_2flisting_2ekeyValue(ptr %v0, ptr %s0, { i64, ptr } %a0)
  store { { i64, ptr }, { i64, ptr } } %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load { { i64, ptr }, { i64, ptr } }, ptr %l6
  store { { i64, ptr }, { i64, ptr } } %t4, ptr %l2
  %t5 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l2, i32 0, i32 0
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  %t8 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l2, i32 0, i32 1
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l8, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l9, !tbaa !24
  %t12 = load i64, ptr %l9, !tbaa !24
  %t13 = mul i64 %t12, 1
  %t14 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l10, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = load i64, ptr %l9, !tbaa !24
  %t22 = mul i64 %t21, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t18, ptr %t20, i64 %t22, i1 false)
  %t23 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t23, ptr %l4, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t26 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t24, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d219, i32 0, i32 1) })
  store i1 %t26, ptr %l12
  br label %bb2
bb2:
  %t27 = load i1, ptr %l12, !tbaa !21
  br i1 %t27, label %bb3, label %bb4
bb3:
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %l13, !tbaa !29
  %t29 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t31 = call { i64, ptr } @compiler_2flisting_2eunquote(ptr %s0, ptr %v1, { i64, ptr } %t29)
  store { i64, ptr } %t31, ptr %l15
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t32 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 0
  %t34 = extractvalue { i64, ptr } %t32, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t40 = load ptr, ptr %l13, !tbaa !29
  %t41 = getelementptr %"compiler/listing:Remark", ptr %t40, i32 0, i32 1
  store { i64, ptr } %t38, ptr %t41, !tbaa !27
  br label %bb6
bb6:
  %t42 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t44 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t42, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d220, i32 0, i32 1) })
  store i1 %t44, ptr %l18
  br label %bb7
bb7:
  %t45 = load i1, ptr %l18, !tbaa !21
  br i1 %t45, label %bb8, label %bb9
bb8:
  %t46 = load ptr, ptr %l1, !tbaa !29
  store ptr %t46, ptr %l19, !tbaa !29
  %t47 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t49 = call { i64, ptr } @compiler_2flisting_2eunquote(ptr %s0, ptr %v1, { i64, ptr } %t47)
  store { i64, ptr } %t49, ptr %l21
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t50 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t50, 0
  %t52 = extractvalue { i64, ptr } %t50, 1
  %t53 = mul i64 %t51, 1
  %t54 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t53)
  call void @llvm.memcpy.p0.p0.i64(ptr %t54, ptr %t52, i64 %t53, i1 false)
  %t55 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t54, 1
  %t58 = load ptr, ptr %l19, !tbaa !29
  %t59 = getelementptr %"compiler/listing:Remark", ptr %t58, i32 0, i32 2
  store { i64, ptr } %t56, ptr %t59, !tbaa !27
  br label %bb11
bb11:
  %t60 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t62 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t60, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d221, i32 0, i32 1) })
  store i1 %t62, ptr %l24
  br label %bb12
bb12:
  %t63 = load i1, ptr %l24, !tbaa !21
  br i1 %t63, label %bb13, label %bb14
bb13:
  %t64 = load ptr, ptr %l1, !tbaa !29
  store ptr %t64, ptr %l25, !tbaa !29
  %t65 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t67 = call { i64, ptr } @compiler_2flisting_2eunquote(ptr %s0, ptr %v1, { i64, ptr } %t65)
  store { i64, ptr } %t67, ptr %l27
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t68 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  %t70 = extractvalue { i64, ptr } %t68, 1
  %t71 = mul i64 %t69, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t70, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  %t76 = load ptr, ptr %l25, !tbaa !29
  %t77 = getelementptr %"compiler/listing:Remark", ptr %t76, i32 0, i32 5
  store { i64, ptr } %t74, ptr %t77, !tbaa !27
  br label %bb16
bb16:
  %t78 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t80 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t78, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d222, i32 0, i32 1) })
  store i1 %t80, ptr %l30
  br label %bb17
bb17:
  %t81 = load i1, ptr %l30, !tbaa !21
  br i1 %t81, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  %t82 = load ptr, ptr %l1, !tbaa !29
  store ptr %t82, ptr %l31, !tbaa !29
  %t83 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t85 = call { i64, ptr } @compiler_2flisting_2efield(ptr %s0, ptr %v1, ptr %v1, { i64, ptr } %t83, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d223, i32 0, i32 1) })
  store { i64, ptr } %t85, ptr %l33
  br label %bb20
bb19:
  br label %bb28
bb20:
  %t86 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 0
  %t88 = extractvalue { i64, ptr } %t86, 1
  %t89 = mul i64 %t87, 1
  %t90 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t89)
  call void @llvm.memcpy.p0.p0.i64(ptr %t90, ptr %t88, i64 %t89, i1 false)
  %t91 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t90, 1
  %t94 = load ptr, ptr %l31, !tbaa !29
  %t95 = getelementptr %"compiler/listing:Remark", ptr %t94, i32 0, i32 3
  store { i64, ptr } %t92, ptr %t95, !tbaa !27
  %t96 = load ptr, ptr %l1, !tbaa !29
  store ptr %t96, ptr %l35, !tbaa !29
  %t97 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t99 = call { i64, ptr } @compiler_2flisting_2efield(ptr %s0, ptr %s4, ptr %s4, { i64, ptr } %t97, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d224, i32 0, i32 1) })
  store { i64, ptr } %t99, ptr %l38
  br label %bb21
bb21:
  %t100 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t102 = extractvalue { i64, ptr } %t100, 1
  %t103 = mul i64 %t101, 1
  %t104 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t103)
  call void @llvm.memcpy.p0.p0.i64(ptr %t104, ptr %t102, i64 %t103, i1 false)
  %t105 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  store { i64, ptr } %t106, ptr %l39, !tbaa !27
  %t107 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s4, i64 10)
  %t108 = extractvalue { i32, i64 } %t107, 1
  %t109 = extractvalue { i32, i64 } %t107, 0
  store i32 %t109, ptr %l41
  %t110 = icmp ne i32 %t109, 0
  br i1 %t110, label %bb23, label %ok.111, !prof !99
ok.111:
  store i64 %t108, ptr %l40
  br label %bb22
bb22:
  %t112 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t113 = load i64, ptr %l40, !tbaa !24
  %t114 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s4, { i64, ptr } %t112, i64 %t113)
  %t115 = extractvalue { i32, i64 } %t114, 1
  %t116 = extractvalue { i32, i64 } %t114, 0
  store i32 %t116, ptr %l43
  %t117 = icmp ne i32 %t116, 0
  br i1 %t117, label %bb26, label %ok.118, !prof !99
ok.118:
  store i64 %t115, ptr %l42
  br label %bb25
bb23:
  br label %bb24
bb24:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l36, !tbaa !24
  br label %bb27
bb25:
  %t119 = load i64, ptr %l42, !tbaa !24
  store i64 %t119, ptr %l36, !tbaa !24
  br label %bb27
bb26:
  br label %bb24
bb27:
  %t120 = load i64, ptr %l36, !tbaa !24
  %t121 = load ptr, ptr %l35, !tbaa !29
  %t122 = getelementptr %"compiler/listing:Remark", ptr %t121, i32 0, i32 4
  store i64 %t120, ptr %t122, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2flisting_2etypeDelim(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i1
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = icmp eq i8 %t1, 60
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i8, ptr %l0, !tbaa !22
  %t7 = icmp eq i8 %t5, 44
  store i1 %t7, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t10 = load i8, ptr %l0, !tbaa !22
  %t12 = icmp eq i8 %t10, 32
  store i1 %t12, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb9
bb8:
  %t15 = load i8, ptr %l0, !tbaa !22
  %t17 = icmp eq i8 %t15, 40
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb12
bb11:
  %t20 = load i8, ptr %l0, !tbaa !22
  %t22 = icmp eq i8 %t20, 91
  store i1 %t22, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb15
bb14:
  %t25 = load i8, ptr %l0, !tbaa !22
  %t27 = icmp eq i8 %t25, 38
  store i1 %t27, ptr %l15, !tbaa !21
  br label %bb15
bb15:
  %t29 = load i1, ptr %l15, !tbaa !21
  br i1 %t29, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb18
bb17:
  %t30 = load i8, ptr %l0, !tbaa !22
  %t32 = icmp eq i8 %t30, 63
  store i1 %t32, ptr %l18, !tbaa !21
  br label %bb18
bb18:
  %t34 = load i1, ptr %l18, !tbaa !21
  store i1 %t34, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2flisting_2eunquote(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i64
  %l4 = alloca i8
  %l5 = alloca i8
  %l7 = alloca { i64, ptr }
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l41 = alloca i1
  %l42 = alloca { i64, ptr }
  %l45 = alloca i1
  %l46 = alloca { i64, ptr }
  %l54 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l61 = alloca { i64, ptr }
  %l66 = alloca i1
  %l75 = alloca { i64, ptr }
  %l78 = alloca ptr
  %l81 = alloca i8
  %l84 = alloca i8
  %l91 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l93 = alloca i64
  %l94 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store { i64, ptr } %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t9 = icmp sge i64 %t7, 2
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t11, ptr %l12, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i8, ptr %t13, i64 0
  %t15 = load i8, ptr %t14, !tbaa !32
  %t17 = icmp eq i8 %t15, 39
  store i1 %t17, ptr %l11, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l11, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t20 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t20, ptr %l16, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t25 = sub i64 %t23, 1
  %t27 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i8, ptr %t28, i64 %t25
  %t30 = load i8, ptr %t29, !tbaa !32
  %t32 = icmp eq i8 %t30, 39
  store i1 %t32, ptr %l15, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb7
bb7:
  %t34 = load i1, ptr %l15, !tbaa !21
  br i1 %t34, label %bb8, label %bb9
bb8:
  %t35 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t35, ptr %l22, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 0
  %t40 = sub i64 %t38, 1
  store i64 %t40, ptr %l25, !tbaa !24
  %t41 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 0
  store i64 %t42, ptr %l26, !tbaa !24
  %t43 = icmp sge i64 1, 0
  br i1 %t43, label %bb10, label %bb11
bb9:
  br label %bb17
bb10:
  %t45 = load i64, ptr %l25, !tbaa !24
  %t46 = icmp sle i64 1, %t45
  br i1 %t46, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_99b6d5da9346cc11_b8cfea66ec2c3f15)
  unreachable
bb12:
  %t48 = load i64, ptr %l25, !tbaa !24
  %t49 = load i64, ptr %l26, !tbaa !24
  %t50 = icmp sle i64 %t48, %t49
  br i1 %t50, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_99b6d5da9346cc11_b8cfea66ec2c3f15)
  unreachable
bb14:
  %t52 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = load i64, ptr %l25, !tbaa !24
  %t55 = getelementptr i8, ptr %t53, i64 1
  %t56 = sub i64 %t54, 1
  %t57 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t55, 1
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d225, i32 0, i32 1) }, ptr %l32, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d226, i32 0, i32 1) }, ptr %l33, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t63 = call { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t58, { i64, ptr } %t61, { i64, ptr } %t62)
  store { i64, ptr } %t63, ptr %l34
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_99b6d5da9346cc11_b8cfea66ec2c3f15)
  unreachable
bb16:
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l35, !tbaa !24
  %t66 = load i64, ptr %l35, !tbaa !24
  %t67 = mul i64 %t66, 1
  %t68 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t67)
  %t69 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t68, 1
  store { i64, ptr } %t70, ptr %l36, !tbaa !27
  %t71 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = load i64, ptr %l35, !tbaa !24
  %t76 = mul i64 %t75, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t72, ptr %t74, i64 %t76, i1 false)
  %t77 = load { i64, ptr }, ptr %l36, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t77, ptr %rv
  br label %ret
bb17:
  %t79 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t83 = icmp slt i64 %t81, 2
  br i1 %t83, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb20
bb19:
  %t85 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t85, ptr %l42, !tbaa !27
  %t86 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr i8, ptr %t87, i64 0
  %t89 = load i8, ptr %t88, !tbaa !32
  %t91 = icmp ne i8 %t89, 34
  store i1 %t91, ptr %l41, !tbaa !21
  br label %bb20
bb20:
  %t93 = load i1, ptr %l41, !tbaa !21
  br i1 %t93, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb23
bb22:
  %t94 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t94, ptr %l46, !tbaa !27
  %t95 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t95, 0
  %t99 = sub i64 %t97, 1
  %t101 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr i8, ptr %t102, i64 %t99
  %t104 = load i8, ptr %t103, !tbaa !32
  %t106 = icmp ne i8 %t104, 34
  store i1 %t106, ptr %l45, !tbaa !21
  br label %bb23
bb23:
  %t108 = load i1, ptr %l45, !tbaa !21
  br i1 %t108, label %bb24, label %bb25
bb24:
  %t109 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t109, 1
  %t112 = extractvalue { i64, ptr } %t109, 0
  %t113 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t112)
  call void @olang_textcopy(ptr %t113, ptr %t111, i64 %t112)
  %t114 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t113, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t115, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t117 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aChar_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t117, ptr %l54
  br label %bb27
bb27:
  %t118 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l54
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t118, ptr %l2
  store i64 1, ptr %l3, !tbaa !24
  br label %bb28
bb28:
  %t119 = load i64, ptr %l3, !tbaa !24
  %t120 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t120, 0
  %t124 = sub i64 %t122, 1
  %t127 = icmp slt i64 %t119, %t124
  %t129 = xor i1 %t127, true
  br i1 %t129, label %bb29, label %bb30
bb29:
  br label %bb47
bb30:
  br label %bb31
bb31:
  %t131 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t131, ptr %l61, !tbaa !27
  %t132 = load i64, ptr %l3, !tbaa !24
  %t134 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = getelementptr i8, ptr %t135, i64 %t132
  %t137 = load i8, ptr %t136, !tbaa !32
  store i8 %t137, ptr %l4, !tbaa !22
  %t139 = load i8, ptr %l4, !tbaa !22
  %t141 = icmp eq i8 %t139, 92
  br i1 %t141, label %bb32, label %bb33
bb32:
  %t143 = load i64, ptr %l3, !tbaa !24
  %t145 = add i64 %t143, 1
  %t146 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t146, 0
  %t150 = sub i64 %t148, 1
  %t153 = icmp slt i64 %t145, %t150
  store i1 %t153, ptr %l66, !tbaa !21
  br label %bb34
bb33:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb34
bb34:
  %t155 = load i1, ptr %l66, !tbaa !21
  br i1 %t155, label %bb35, label %bb36
bb35:
  %t156 = load i64, ptr %l3, !tbaa !24
  %t158 = add i64 %t156, 1
  store i64 %t158, ptr %l3, !tbaa !24
  %t160 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t160, ptr %l75, !tbaa !27
  %t161 = load i64, ptr %l3, !tbaa !24
  %t163 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !27
  %t165 = getelementptr i8, ptr %t164, i64 %t161
  %t166 = load i8, ptr %t165, !tbaa !32
  store i8 %t166, ptr %l5, !tbaa !22
  store ptr %l2, ptr %l78, !tbaa !29
  %t168 = load i8, ptr %l5, !tbaa !22
  %t170 = icmp eq i8 %t168, 110
  br i1 %t170, label %bb37, label %bb38
bb36:
  %t172 = load i8, ptr %l4, !tbaa !22
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aChar_3e_2ePush_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %l2, i8 %t172)
  br label %bb44
bb37:
  store i8 10, ptr %l81, !tbaa !22
  br label %bb42
bb38:
  %t175 = load i8, ptr %l5, !tbaa !22
  %t177 = icmp eq i8 %t175, 116
  br i1 %t177, label %bb39, label %bb40
bb39:
  store i8 9, ptr %l84, !tbaa !22
  br label %bb41
bb40:
  %t179 = load i8, ptr %l5, !tbaa !22
  store i8 %t179, ptr %l84, !tbaa !22
  br label %bb41
bb41:
  %t181 = load i8, ptr %l84, !tbaa !22
  store i8 %t181, ptr %l81, !tbaa !22
  br label %bb42
bb42:
  %t182 = load ptr, ptr %l78, !tbaa !29
  %t183 = load i8, ptr %l81, !tbaa !22
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aChar_3e_2ePush_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %t182, i8 %t183)
  br label %bb43
bb43:
  br label %bb45
bb44:
  br label %bb45
bb45:
  %t184 = load i64, ptr %l3, !tbaa !24
  %t186 = add i64 %t184, 1
  store i64 %t186, ptr %l3, !tbaa !24
  br label %bb46
bb46:
  br label %bb28
bb47:
  %t189 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aChar_3e_2eToArr_H8081e04b38a8da5362a19182ff2ab7d7(ptr %s0, ptr %s0, ptr %l2)
  store { i64, ptr } %t189, ptr %l91
  br label %bb48
bb48:
  %t190 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t190, ptr %l92, !tbaa !27
  %t191 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t191, 0
  store i64 %t192, ptr %l93, !tbaa !24
  %t193 = load i64, ptr %l93, !tbaa !24
  %t194 = mul i64 %t193, 1
  %t195 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t194)
  %t196 = insertvalue { i64, ptr } undef, i64 %t193, 0
  %t197 = insertvalue { i64, ptr } %t196, ptr %t195, 1
  store { i64, ptr } %t197, ptr %l94, !tbaa !27
  %t198 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !27
  %t202 = load i64, ptr %l93, !tbaa !24
  %t203 = mul i64 %t202, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t199, ptr %t201, i64 %t203, i1 false)
  %t204 = load { i64, ptr }, ptr %l94, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t204, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/listing:Inputs" @compiler_2flisting_3aInputs_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, i1 %a4) #0 {
entry:
  %rv = alloca %"compiler/listing:Inputs"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/listing:Inputs" undef, ptr %a0, 0
  %t14 = insertvalue %"compiler/listing:Inputs" %t12, ptr %a1, 1
  %t16 = insertvalue %"compiler/listing:Inputs" %t14, { i64, ptr } %a2, 2
  %t18 = insertvalue %"compiler/listing:Inputs" %t16, { i64, ptr } %a3, 3
  %t20 = insertvalue %"compiler/listing:Inputs" %t18, i1 %a4, 4
  store %"compiler/listing:Inputs" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/listing:Inputs", ptr %rv
  ret %"compiler/listing:Inputs" %rr
}

define dso_local %"compiler/listing:Namer" @compiler_2flisting_3aNamer_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %rv = alloca %"compiler/listing:Namer"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d227, i32 0, i32 1) }, ptr %l0, !tbaa !27
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = insertvalue %"compiler/listing:Namer" undef, { i64, ptr } %t1, 0
  store %"compiler/listing:Namer" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/listing:Namer", ptr %rv
  ret %"compiler/listing:Namer" %rr
}

define dso_local %"compiler/listing:Remark" @compiler_2flisting_3aRemark_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %rv = alloca %"compiler/listing:Remark"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d228, i32 0, i32 1) }, ptr %l0, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d229, i32 0, i32 1) }, ptr %l1, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d230, i32 0, i32 1) }, ptr %l2, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d231, i32 0, i32 1) }, ptr %l3, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d232, i32 0, i32 1) }, ptr %l5, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d233, i32 0, i32 1) }, ptr %l6, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d234, i32 0, i32 1) }, ptr %l7, !tbaa !27
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = insertvalue %"compiler/listing:Remark" undef, { i64, ptr } %t1, 0
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = insertvalue %"compiler/listing:Remark" %t2, { i64, ptr } %t3, 1
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = insertvalue %"compiler/listing:Remark" %t4, { i64, ptr } %t5, 2
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = insertvalue %"compiler/listing:Remark" %t6, { i64, ptr } %t7, 3
  %t10 = insertvalue %"compiler/listing:Remark" %t8, i64 0, 4
  %t11 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t12 = insertvalue %"compiler/listing:Remark" %t10, { i64, ptr } %t11, 5
  %t13 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t14 = insertvalue %"compiler/listing:Remark" %t12, { i64, ptr } %t13, 6
  %t15 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t16 = insertvalue %"compiler/listing:Remark" %t14, { i64, ptr } %t15, 7
  store %"compiler/listing:Remark" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/listing:Remark", ptr %rv
  ret %"compiler/listing:Remark" %rr
}

define dso_local %"compiler/listing:Sources" @compiler_2flisting_3aSources_2ector(ptr %v0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"compiler/listing:Sources"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_He7de1307999555e158a4a98542c4fa41(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l2
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l2
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d235, i32 0, i32 1) }, ptr %l1, !tbaa !27
  %t4 = insertvalue %"compiler/listing:Sources" undef, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, 0
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t6 = insertvalue %"compiler/listing:Sources" %t4, { i64, ptr } %t5, 1
  store %"compiler/listing:Sources" %t6, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/listing:Sources", ptr %rv
  ret %"compiler/listing:Sources" %rr
}

define dso_local void @compiler_2flisting_3aWriter_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, ptr %a1, ptr %a2, { i64, ptr } %a3) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca %"std/prelude/text:StringBuilder"
  %l22 = alloca %"compiler/listing:Writer"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l4, !tbaa !27
  store ptr %a1, ptr %l5, !tbaa !29
  store ptr %a2, ptr %l6, !tbaa !29
  store { i64, ptr } %a3, ptr %l7, !tbaa !27
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l20
  br label %bb1
bb1:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l8
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d236, i32 0, i32 1) }, ptr %l9, !tbaa !27
  store i64 -1, ptr %l10, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d237, i32 0, i32 1) }, ptr %l11, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d238, i32 0, i32 1) }, ptr %l12, !tbaa !27
  store i64 -1, ptr %l13, !tbaa !24
  %t11 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v4)
  store %"std/prelude/text:StringBuilder" %t11, ptr %l21
  br label %bb2
bb2:
  %t12 = load %"std/prelude/text:StringBuilder", ptr %l21
  %t13 = getelementptr %"compiler/listing:Writer", ptr %l22, i32 0, i32 0
  %t14 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t14, ptr %t13, !tbaa !27
  %t15 = getelementptr %"compiler/listing:Writer", ptr %l22, i32 0, i32 1
  %t16 = load ptr, ptr %l5, !tbaa !29
  store ptr %t16, ptr %t15, !tbaa !29
  %t17 = getelementptr %"compiler/listing:Writer", ptr %l22, i32 0, i32 2
  %t18 = load ptr, ptr %l6, !tbaa !29
  store ptr %t18, ptr %t17, !tbaa !29
  %t19 = getelementptr %"compiler/listing:Writer", ptr %l22, i32 0, i32 3
  %t20 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t20, ptr %t19, !tbaa !27
  %t21 = getelementptr %"compiler/listing:Writer", ptr %l22, i32 0, i32 4
  %t22 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %t21
  %t23 = getelementptr %"compiler/listing:Writer", ptr %l22, i32 0, i32 5
  %t24 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t24, ptr %t23, !tbaa !27
  %t25 = getelementptr %"compiler/listing:Writer", ptr %l22, i32 0, i32 6
  %t26 = load i64, ptr %l10, !tbaa !24
  store i64 %t26, ptr %t25, !tbaa !24
  %t27 = getelementptr %"compiler/listing:Writer", ptr %l22, i32 0, i32 7
  %t28 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t28, ptr %t27, !tbaa !27
  %t29 = getelementptr %"compiler/listing:Writer", ptr %l22, i32 0, i32 8
  %t30 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t30, ptr %t29, !tbaa !27
  %t31 = getelementptr %"compiler/listing:Writer", ptr %l22, i32 0, i32 9
  %t32 = load i64, ptr %l13, !tbaa !24
  store i64 %t32, ptr %t31, !tbaa !24
  %t33 = getelementptr %"compiler/listing:Writer", ptr %l22, i32 0, i32 10
  store %"std/prelude/text:StringBuilder" %t12, ptr %t33
  %t35 = getelementptr %"compiler/listing:Writer", ptr %l22, i32 0, i32 11
  store i64 0, ptr %t35, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l22, i64 184, i1 false)
  br label %ret
ret:
  ret void
}

define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_ert_req_clear()
@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d1 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d2 = private constant <{ i64, [67 x i8] }> <{ i64 0, [67 x i8] c" instances: the program makes no instance of it, so it has no code\0A" }>, align 8
@.d3 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d4 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_check_failed(ptr) cold noreturn
@.d5 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"inline" }>, align 8
@.d6 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"passed" }>, align 8
@.d7 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c" IR instructions" }>, align 8
@.d8 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" instructions" }>, align 8
@.d9 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d10 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c" (its code merged with " }>, align 8
@.d11 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"'s, which is the same)" }>, align 8
@.d12 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d13 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"; inlined into it: " }>, align 8
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d15 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"inline" }>, align 8
@.d16 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"passed" }>, align 8
@.d17 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c";" }>, align 8
@.d18 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"aarch64" }>, align 8
@.d19 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"//" }>, align 8
@.d20 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"#" }>, align 8
@.d21 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"main" }>, align 8
@.d22 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"startup" }>, align 8
@.d23 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"_fv_" }>, align 8
@.d24 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c" as a function value" }>, align 8
@.d25 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"_adapter" }>, align 8
@.d26 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" adapted" }>, align 8
@.d27 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"_copied" }>, align 8
@.d28 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d29 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d30 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d31 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d32 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d33 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d34 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d35 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d36 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d37 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
@.d38 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@__olang_empty_array = external constant [16 x i64]
@.d39 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d40 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".loc\09" }>, align 8
@.d41 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".loc " }>, align 8
@.d42 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d43 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d44 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d45 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d46 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d47 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".cfi_" }>, align 8
@.d48 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c".p2align" }>, align 8
@.d49 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"#DEBUG_VALUE" }>, align 8
@.d50 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".file" }>, align 8
@.d51 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".type" }>, align 8
@.d52 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".size" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d53 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d54 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d55 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"#" }>, align 8
@.d56 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"//" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d57 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".file\09" }>, align 8
@.d58 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".file " }>, align 8
@.d59 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"#" }>, align 8
@.d60 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"//" }>, align 8
@.d61 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\09" }>, align 8
@.d62 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d63 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d64 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d65 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d66 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c".Lfunc_end" }>, align 8
@.d67 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".Ltmp" }>, align 8
@.d68 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c".Lfunc_begin" }>, align 8
@.d69 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"$local" }>, align 8
@.d70 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d71 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"!dbg !" }>, align 8
@.d72 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d73 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d74 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c";" }>, align 8
@.d75 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"!" }>, align 8
@.d76 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"DILocation(" }>, align 8
@.d77 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"DIFile(" }>, align 8
@.d78 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"DISubprogram(" }>, align 8
@.d79 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"DILexicalBlock" }>, align 8
@.d80 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d81 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"define " }>, align 8
@.d82 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d83 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d84 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"DILocation(" }>, align 8
@.d85 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"line" }>, align 8
@.d86 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"scope" }>, align 8
@.d87 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d88 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"file" }>, align 8
@.d89 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d90 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"filename" }>, align 8
@.d91 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"directory" }>, align 8
@.d92 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d93 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d94 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d95 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define internal i1 @olang_lambda_96(ptr %env, ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l3 = alloca i1
  %l4 = alloca i1
  %l6 = alloca i1
  %l8 = alloca i1
  %l10 = alloca i1
  %l12 = alloca i1
  %l14 = alloca i1
  %l16 = alloca i1
  %l19 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d239, i32 0, i32 1) })
  store i1 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d240, i32 0, i32 1) })
  store i1 %t7, ptr %l6
  br label %bb4
bb3:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb5
bb4:
  %t8 = load i1, ptr %l6, !tbaa !21
  %t9 = xor i1 %t8, true
  store i1 %t9, ptr %l4, !tbaa !21
  br label %bb5
bb5:
  %t11 = load i1, ptr %l4, !tbaa !21
  br i1 %t11, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb17
bb7:
  %t12 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t14 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t12, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d241, i32 0, i32 1) })
  store i1 %t14, ptr %l10
  br label %bb8
bb8:
  %t15 = load i1, ptr %l10, !tbaa !21
  %t16 = xor i1 %t15, true
  br i1 %t16, label %bb9, label %bb10
bb9:
  %t18 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t20 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t18, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d242, i32 0, i32 1) })
  store i1 %t20, ptr %l14
  br label %bb11
bb10:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb12
bb11:
  %t21 = load i1, ptr %l14, !tbaa !21
  %t22 = xor i1 %t21, true
  store i1 %t22, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb13, label %bb14
bb13:
  %t25 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t29 = call i1 @compiler_2flisting_2eplaceLess(ptr %v0, ptr %v1, { i64, ptr } %t25, { i64, ptr } %t26)
  store i1 %t29, ptr %l19
  br label %bb15
bb14:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb16
bb15:
  %t30 = load i1, ptr %l19, !tbaa !21
  store i1 %t30, ptr %l16, !tbaa !21
  br label %bb16
bb16:
  %t31 = load i1, ptr %l16, !tbaa !21
  store i1 %t31, ptr %l8, !tbaa !21
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t32 = load i1, ptr %l8, !tbaa !21
  store i1 %t32, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d97 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c" remarks on lines left with no code here:\0A" }>, align 8
@.d98 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d99 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d100 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"(no line of the program)" }>, align 8
@.d101 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"   " }>, align 8
@.d102 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d103 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"      " }>, align 8
@.d104 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d105 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d106 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c" (no line of the program)\0A" }>, align 8
@.d107 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d108 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d109 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d110 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d111 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d112 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d113 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" (x" }>, align 8
@.d114 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d115 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d116 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d117 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d118 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"define " }>, align 8
@.d119 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d120 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d121 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" alias " }>, align 8
@.d122 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d123 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".llvm." }>, align 8
@.d124 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".set\09" }>, align 8
@.d125 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d126 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d127 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d128 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d129 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d130 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\22" }>, align 8
@.d131 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d132 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" }" }>, align 8
@.d133 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d134 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\09" }>, align 8
@.d135 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\22" }>, align 8
@.d136 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\22" }>, align 8
@.d137 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\22" }>, align 8
@.d138 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d139 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d140 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d141 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"optimized LLVM IR" }>, align 8
@.d142 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" machine code" }>, align 8
@.d143 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"-O2, each module on its own (-quick)" }>, align 8
@.d144 = private constant <{ i64, [45 x i8] }> <{ i64 0, [45 x i8] c"-O3, optimized again as the program is linked" }>, align 8
@.d145 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c" as build compiles it: " }>, align 8
@.d146 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", for " }>, align 8
@.d147 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d148 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d149 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d150 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d151 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" - " }>, align 8
@.d152 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d153 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d154 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d155 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d156 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d157 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c" inlined at every call, into " }>, align 8
@.d158 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c", and that into " }>, align 8
@.d159 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d160 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c" no code of its own:" }>, align 8
@.d161 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d162 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c" no code of its own:" }>, align 8
@.d163 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c", whose code follows\0A" }>, align 8
@.d164 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d165 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d166 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d167 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".llvm." }>, align 8
@.d168 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d169 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d170 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d171 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Passed" }>, align 8
@.d172 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"passed" }>, align 8
@.d173 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Missed" }>, align 8
@.d174 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"missed" }>, align 8
@.d175 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"Analysis" }>, align 8
@.d176 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"analysis" }>, align 8
@.d177 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\09" }>, align 8
@.d178 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d179 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d180 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d181 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d182 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d183 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d184 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\22" }>, align 8
@.d185 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\22" }>, align 8
@.d186 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d187 = private constant <{ i64, [65 x i8] }> <{ i64 0, [65 x i8] c" no code: nothing in the program calls it, so the link kept none\0A" }>, align 8
@.d188 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d189 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d190 = private constant <{ i64, [49 x i8] }> <{ i64 0, [49 x i8] c" no code of its own: inlined at every call, into " }>, align 8
@.d191 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d192 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c" no code of its own:" }>, align 8
@.d193 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c", which has none either\0A" }>, align 8
@.d194 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d195 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c" no code of its own:" }>, align 8
@.d196 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c", which is inlined in turn into " }>, align 8
@.d197 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d198 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d199 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d200 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d201 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d202 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d203 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d204 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d205 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d206 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"--- !" }>, align 8
@.d207 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"..." }>, align 8
@.d208 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"passed" }>, align 8
@.d209 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"inline" }>, align 8
@.d210 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d211 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"  - " }>, align 8
@.d212 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"  - " }>, align 8
@.d213 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Callee" }>, align 8
@.d214 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"String" }>, align 8
@.d215 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" at callsite " }>, align 8
@.d216 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Callee" }>, align 8
@.d217 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Caller" }>, align 8
@.d218 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"Function" }>, align 8
@.d219 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Pass" }>, align 8
@.d220 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Name" }>, align 8
@.d221 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"Function" }>, align 8
@.d222 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"DebugLoc" }>, align 8
@.d223 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"File" }>, align 8
@.d224 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Line" }>, align 8
@.d225 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"''" }>, align 8
@.d226 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d227 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d228 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d229 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d230 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d231 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d232 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d233 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d234 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_He7de1307999555e158a4a98542c4fa41(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Array_3cstd_2fprelude__Hb5aefc70e2d3852a6d29ec0a9aea78a4(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d235 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d236 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d237 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d238 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@.d239 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d240 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d241 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d242 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %a0)
declare %"compiler/build:Unit" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eAt_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2flisting_3aRemark_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aCode_3e_2eLen_3ccompiler_2fbuild_3aCode_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/build:Code" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aCode_3e_2eAt_3ccompiler_2fbuild_3aCode_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @compiler_2fload_2eStdDir(ptr %v0)
declare { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
@olang_loc_60a4feb33ac0cdc_badaef821bc3f128 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flisting_3aRemark_3e_2eLen_3ccompiler_2flisting_3aRemark_3e(ptr %v0, ptr %a0)
declare %"compiler/listing:Remark" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flisting_3aRemark_3e_2eAt_3ccompiler_2flisting_3aRemark_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_4c5476cd02c9d569_d2b16f8f5de4ce55 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_82458c7f9e0fa77c_b0b89e2c08a7ae78 = external constant [0 x i8]
@olang_loc_1aee9fefcdd9cd27_6fa15990af9654d3 = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftypes_2eDemangle(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_6a5ec5f2c3534a4a_bf3e4e4bffc8a476 = external constant [0 x i8]
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_af9ac36a56bc89c5_7398c12160466739 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fload_2eErrQualifier(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1)
@olang_loc_49807d4f96be5ab6_2af2c5a6dfc4a7ea = external constant [0 x i8]
@olang_loc_4991736aef41bf13_e517855ef6f4ebc7 = external constant [0 x i8]
@olang_loc_3adca15b088d1ab8_ad89d21976d6c71c = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_1b7d32817576de5e_73fc7def7ca382d2 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H7e371d56fd28e687545500cc2dc4b78e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_He566606ea489086acfe37a2d8fe143fc(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H1a06a15e944bd533c307ed632a66227d(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
@olang_loc_3ba8e4c8ab4044f8_de2322bbe0a12f8c = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_499282f3f30fac94_8f31adef023c0138 = external constant [0 x i8]
@olang_loc_6783e9980d688233_30d5d90792fe0dc7 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1)
@olang_loc_681ac7b531dd0cd6_76b1194f7bcdc9ea = external constant [0 x i8]
@olang_loc_4e22a6b8cb4b0f4e_d8ececdffd9edfc2 = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Hc3dff1927e5c626a9d95abfdf4e9a462(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
@olang_loc_b8d38b69b79cf91c_5a0dc70c1127b970 = external constant [0 x i8]
@olang_loc_43ec7269e82cf689_7116d248b5a11b4d = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H1642129570dad448bb7dcc47c334de83(ptr %v0, ptr %v1, ptr %a0, ptr %a1c, ptr %a1e)
@olang_loc_c76de25993fa5b69_1c32ce588582e85d = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadEnd(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2)
@olang_loc_5a79b11f9a8ea358_a6600b1bb9cded74 = external constant [0 x i8]
@olang_loc_6afa1fda02b1904e_762f30cdf4bfe02 = external constant [0 x i8]
@olang_loc_a32004acca342e4b_53d1fb3a96a10aff = external constant [0 x i8]
@olang_loc_f323dd54c7e2a5d0_8d4c3c3918b6d694 = external constant [0 x i8]
@olang_loc_2238304466d31cdc_a18281d53071ef08 = external constant [0 x i8]
@olang_loc_a0e57960875e3249_f03c8e9377147565 = external constant [0 x i8]
@olang_loc_96c24661ddd014aa_b59c706e032d6c46 = external constant [0 x i8]
@olang_loc_5830759408577a87_15470f09e840e423 = external constant [0 x i8]
@olang_loc_89a4da7eaed16d48_97b863eee78c099c = external constant [0 x i8]
@olang_loc_4256a3bf93089da5_22d14aef181c0709 = external constant [0 x i8]
@olang_loc_419e18d9533a9898_764a2322a7d2db2c = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToLower(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_61ce4b4de8e9e57b_f7600b48bd811137 = external constant [0 x i8]
@olang_loc_bcaef50f3ad362fe_b83702f58870efda = external constant [0 x i8]
@olang_loc_f4e5321dee5c23dd_4262af410e6ad879 = external constant [0 x i8]
@olang_loc_b06da0308285dd80_9593e16f44f2444c = external constant [0 x i8]
@olang_loc_50111c761c56dd5f_b5d6bbb7817ca613 = external constant [0 x i8]
@olang_loc_17a8c3c34efffa58_c9c69620944e8c6c = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_f8bac9f6e1e646b5_a02e035c32962b19 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aChar_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_1658fd7d2958cee1_67b9b3ad391c8d45 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aChar_3e_2eToArr_H8081e04b38a8da5362a19182ff2ab7d7(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flisting_3aRemark_3e_2ePush_3ccompiler_2flisting_3aRemark_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/listing:Remark" %a1)
@olang_loc_679d421df08030f4_bd0b7978ad4d2168 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aChar_3e_2ePush_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %a0, i8 %a1)
declare i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0)
@olang_loc_99b6d5da9346cc11_b8cfea66ec2c3f15 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Array_3cstd_2fprelude__Hb5aefc70e2d3852a6d29ec0a9aea78a4(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
