; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_14628e4c0e8a744_af20bcf949ea6d08 = weak_odr constant [55 x i8] c"std/prelude/list.olang:543: array length out of range\0A\00"
@olang_loc_196edb442714ccf0_ec433411f927a01c = weak_odr constant [49 x i8] c"std/prelude/list.olang:545: unreachable reached\0A\00"
@olang_loc_d19dc2adcb61446a_4a7b6e92029b81b6 = weak_odr constant [49 x i8] c"std/prelude/list.olang:541: unreachable reached\0A\00"
