; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i64, i1, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/text:StringBuilder", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/source:Span" = type { i32, i32 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/effects:Effects" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"compiler/effects:Facts", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/effects:Facts" = type { i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i64, [6 x i64], i64 }
%"compiler/generic:Unmet" = type { i64, i32, i32, i1, i1, i1 }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i32, i64, i64, i64, i1, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", i64, i1 }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/generic:Desc" = type { i64, i32, i64, i64 }
%"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" = type { { ptr, ptr } }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, { i64, ptr }, i32 }
%"compiler/ast:TypeParam" = type { %"compiler/source:Span", i32, ptr, { i64, ptr }, i1 }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, { i64, ptr }, i1 }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr, { i64, ptr } }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr } }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, ptr, i1, i1 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/check:factsMark" = type { i64, i64, i64 }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/check:reflList" = type { i1, i32, i64, i64 }
%"compiler/check:reflVal" = type { i1, i64, i64, { i64, ptr }, i32 }
%"compiler/typed:LocalUses" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i32 }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/check:narrowed" = type { i64, i64, i32, i64, i64, i1 }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr, { i64, ptr } }
%"compiler/names:Entry" = type { i32, %"compiler/source:Span", i32, i1, ptr }
%"compiler/msgs:Nearest" = type { { i64, ptr }, { i64, ptr }, i64 }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/names:Table" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:SiteInfo" = type { i32, %"compiler/source:Span" }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1 }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/check:seqOf" = type { i32, i64, i64, i64 }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/names:Unread" = type { i64, %"compiler/source:Span", i32, i1 }
%"compiler/generic:varRow" = type { i64, i32, i32, i32 }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/check:landing" = type { i64, i64, %"compiler/source:Span", i32, i64 }
%"compiler/check:collWalk" = type { ptr, i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/check:signMag" = type { i1, i128 }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1, i1, i1, i128 }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/check:b5aWalk" = type { i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1 }
%"compiler/check:elemsShape" = type { { i64, ptr }, i64 }
%"compiler/check:roFn" = type { i64, i64, { i64, [3 x i64] }, { i64, ptr } }
define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 20
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %a1)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l7
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l6
  br label %bb1
bb1:
  %t12 = load i64, ptr %l6, !tbaa !24
  store i64 %t12, ptr %l2, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l2, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l2, !tbaa !24
  store i64 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eEffects(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l6 = alloca ptr
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"compiler/effects:Effects"
  %l13 = alloca %"compiler/effects:Effects"
  %rv = alloca ptr
  %t19 = alloca %"compiler/effects:Effects", align 8
  %t22 = alloca %"compiler/effects:Effects", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 9
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  store ptr %t12, ptr %l6, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 14
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %l8
  %t18 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e(ptr %v0, ptr %l8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l10
  br label %bb3
bb2:
  br label %bb6
bb3:
  %t20 = load ptr, ptr %l6, !tbaa !29
  %t21 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  call void @compiler_2feffects_3aEffects_2ector(ptr %t19, ptr %v0, ptr %v0, ptr %v0, ptr %t20, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21)
  call void @llvm.memmove.p0.p0.i64(ptr %l11, ptr %t19, i64 1008, i1 false)
  br label %bb4
bb4:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2feffects_3aEffects(ptr %t22, ptr %v0, ptr %l11)
  call void @llvm.memmove.p0.p0.i64(ptr %l13, ptr %t22, i64 1008, i1 false)
  br label %bb5
bb5:
  %t24 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 1008, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t24, ptr %l13, i64 1008, i1 false)
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 9
  store ptr %t24, ptr %t27, !tbaa !29
  br label %bb6
bb6:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 9
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = icmp eq ptr %t31, null
  br i1 %t33, label %bb7, label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_76d1a478b1ca441c_29a7b400711a77a8)
  unreachable
bb8:
  br label %bb9
bb9:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 9
  %t38 = load ptr, ptr %t37, !tbaa !29
  store ptr %t38, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyMeets(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/generic:Unmet"
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca i64
  %l8 = alloca i64
  %l13 = alloca %"compiler/generic:Unmet"
  %l19 = alloca { i64, ptr }
  %l23 = alloca i1
  %l28 = alloca %"std/prelude/text:StringBuilder"
  %l29 = alloca ptr
  %l30 = alloca %"compiler/source:Span"
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l39 = alloca %"compiler/msgs:Msg"
  %l40 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca %"compiler/source:Span"
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l53 = alloca %"compiler/msgs:Msg"
  %l54 = alloca i64
  %l59 = alloca i64
  %l62 = alloca ptr
  %l63 = alloca i64
  %l64 = alloca i64
  %l67 = alloca { i64, ptr }
  %l68 = alloca %"compiler/msgs:Msg"
  %l69 = alloca ptr
  %l70 = alloca %"compiler/source:Span"
  %l73 = alloca { i64, ptr }
  %l76 = alloca %"compiler/msgs:Msg"
  %l77 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load i32, ptr %l2, !tbaa !23
  %t10 = call %"compiler/generic:Unmet" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMissing(ptr %v0, ptr %t4, i32 %t5, i32 %t6, i1 true, i64 0)
  store %"compiler/generic:Unmet" %t10, ptr %l13
  br label %bb1
bb1:
  %t11 = load %"compiler/generic:Unmet", ptr %l13
  store %"compiler/generic:Unmet" %t11, ptr %l4
  %t12 = getelementptr %"compiler/generic:Unmet", ptr %l4, i32 0, i32 0
  %t13 = load i64, ptr %t12, !tbaa !24
  %t15 = icmp slt i64 %t13, 0
  br i1 %t15, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l2, !tbaa !23
  %t22 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t18, i32 %t19)
  store { i64, ptr } %t22, ptr %l19
  br label %bb5
bb5:
  %t23 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t23, ptr %l5, !tbaa !27
  %t24 = getelementptr %"compiler/generic:Unmet", ptr %l4, i32 0, i32 5
  %t25 = load i1, ptr %t24, !tbaa !21
  br i1 %t25, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Unmet", ptr %l4, i32 0, i32 1
  %t29 = load i32, ptr %t28, !tbaa !23
  %t32 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emembersWritten(ptr %v0, ptr %t27, i32 %t29)
  store i1 %t32, ptr %l23
  br label %bb8
bb7:
  %t33 = getelementptr %"compiler/generic:Unmet", ptr %l4, i32 0, i32 3
  %t34 = load i1, ptr %t33, !tbaa !21
  br i1 %t34, label %bb17, label %bb18
bb8:
  %t36 = load i1, ptr %l23, !tbaa !21
  %t37 = xor i1 %t36, true
  br i1 %t37, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/generic:Unmet", ptr %l4, i32 0, i32 1
  %t42 = load i32, ptr %t41, !tbaa !23
  %t45 = call %"std/prelude/text:StringBuilder" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ememberListing(ptr %v0, ptr %s2, ptr %t40, i32 %t42)
  store %"std/prelude/text:StringBuilder" %t45, ptr %l28
  br label %bb12
bb12:
  %t46 = load %"std/prelude/text:StringBuilder", ptr %l28
  store %"std/prelude/text:StringBuilder" %t46, ptr %l6
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l29, !tbaa !29
  %t48 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t48, ptr %l30
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i32, ptr %l1, !tbaa !23
  %t53 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t49, i32 %t50)
  store { i64, ptr } %t53, ptr %l33
  br label %bb13
bb13:
  %t54 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 0
  %t56 = extractvalue { i64, ptr } %t54, 1
  %t57 = mul i64 %t55, 1
  %t58 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t57)
  call void @llvm.memcpy.p0.p0.i64(ptr %t58, ptr %t56, i64 %t57, i1 false)
  %t59 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  store { i64, ptr } %t60, ptr %l34, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t61, ptr %l35, !tbaa !27
  %t63 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s2, ptr %s2, ptr %l6)
  store { i64, ptr } %t63, ptr %l37
  br label %bb14
bb14:
  %t64 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  %t66 = extractvalue { i64, ptr } %t64, 1
  %t67 = mul i64 %t65, 1
  %t68 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t67)
  call void @llvm.memcpy.p0.p0.i64(ptr %t68, ptr %t66, i64 %t67, i1 false)
  %t69 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t68, 1
  %t71 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t72 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t74 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyNotMember(ptr %s2, ptr %s0, ptr %s2, ptr %s2, { i64, ptr } %t71, { i64, ptr } %t72, { i64, ptr } %t70)
  store %"compiler/msgs:Msg" %t74, ptr %l39
  br label %bb15
bb15:
  %t75 = load ptr, ptr %l29, !tbaa !29
  %t76 = load %"compiler/source:Span", ptr %l30
  %t77 = load %"compiler/msgs:Msg", ptr %l39
  %t78 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t75, %"compiler/source:Span" %t76, %"compiler/msgs:Msg" %t77)
  store i64 %t78, ptr %l40
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l42, !tbaa !29
  %t80 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t80, ptr %l43
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load i32, ptr %l1, !tbaa !23
  %t85 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t81, i32 %t82)
  store { i64, ptr } %t85, ptr %l46
  br label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s7
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l69, !tbaa !29
  %t87 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t87, ptr %l70
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load i32, ptr %l1, !tbaa !23
  %t92 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s7, ptr %t88, i32 %t89)
  store { i64, ptr } %t92, ptr %l73
  br label %bb30
bb19:
  %t93 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 0
  %t95 = extractvalue { i64, ptr } %t93, 1
  %t96 = mul i64 %t94, 1
  %t97 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t96)
  call void @llvm.memcpy.p0.p0.i64(ptr %t97, ptr %t95, i64 %t96, i1 false)
  %t98 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t97, 1
  store { i64, ptr } %t99, ptr %l47, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t100, ptr %l48, !tbaa !27
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Unmet", ptr %l4, i32 0, i32 2
  %t103 = load i32, ptr %t102, !tbaa !23
  %t106 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s5, ptr %t101, i32 %t103)
  store { i64, ptr } %t106, ptr %l51
  br label %bb20
bb20:
  %t107 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t107, 0
  %t109 = extractvalue { i64, ptr } %t107, 1
  %t110 = mul i64 %t108, 1
  %t111 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t110)
  call void @llvm.memcpy.p0.p0.i64(ptr %t111, ptr %t109, i64 %t110, i1 false)
  %t112 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t111, 1
  %t114 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t115 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t117 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyUnmetMethod(ptr %s5, ptr %s0, ptr %s5, ptr %s5, { i64, ptr } %t114, { i64, ptr } %t115, { i64, ptr } %t113)
  store %"compiler/msgs:Msg" %t117, ptr %l53
  br label %bb21
bb21:
  %t118 = load ptr, ptr %l42, !tbaa !29
  %t119 = load %"compiler/source:Span", ptr %l43
  %t120 = load %"compiler/msgs:Msg", ptr %l53
  %t121 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t118, %"compiler/source:Span" %t119, %"compiler/msgs:Msg" %t120)
  store i64 %t121, ptr %l54
  br label %bb22
bb22:
  %t122 = load i64, ptr %l54, !tbaa !24
  store i64 %t122, ptr %l7, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/check:Checker", ptr %t123, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t127 = load i32, ptr %l1, !tbaa !23
  %t128 = getelementptr %"compiler/generic:Unmet", ptr %l4, i32 0, i32 2
  %t129 = load i32, ptr %t128, !tbaa !23
  %t133 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t126, i32 %t127, i32 %t129)
  store i64 %t133, ptr %l59
  br label %bb23
bb23:
  %t134 = load i64, ptr %l59, !tbaa !24
  store i64 %t134, ptr %l8, !tbaa !24
  %t135 = load i64, ptr %l8, !tbaa !24
  %t137 = icmp sge i64 %t135, 0
  br i1 %t137, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s6
  %t139 = load ptr, ptr %l0, !tbaa !29
  store ptr %t139, ptr %l62, !tbaa !29
  %t140 = load i64, ptr %l7, !tbaa !24
  store i64 %t140, ptr %l63, !tbaa !24
  %t141 = load i64, ptr %l8, !tbaa !24
  store i64 %t141, ptr %l64, !tbaa !24
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/generic:Unmet", ptr %l4, i32 0, i32 2
  %t144 = load i32, ptr %t143, !tbaa !23
  %t147 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t142, i32 %t144)
  store { i64, ptr } %t147, ptr %l67
  br label %bb26
bb25:
  br label %bb29
bb26:
  %t148 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t149 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteOtherSignature(ptr %v0, ptr %s6, { i64, ptr } %t148)
  store %"compiler/msgs:Msg" %t149, ptr %l68
  br label %bb27
bb27:
  %t150 = load ptr, ptr %l62, !tbaa !29
  %t151 = load i64, ptr %l63, !tbaa !24
  %t152 = load i64, ptr %l64, !tbaa !24
  %t153 = load %"compiler/msgs:Msg", ptr %l68
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteAt(ptr %v0, ptr %s6, ptr %t150, i64 %t151, i64 %t152, %"compiler/msgs:Msg" %t153)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s6)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s5)
  br label %bb33
bb30:
  %t154 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t154, 0
  %t156 = extractvalue { i64, ptr } %t154, 1
  %t157 = mul i64 %t155, 1
  %t158 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t157)
  call void @llvm.memcpy.p0.p0.i64(ptr %t158, ptr %t156, i64 %t157, i1 false)
  %t159 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t158, 1
  %t161 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t164 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyUnmet(ptr %s7, ptr %s0, ptr %s7, { i64, ptr } %t160, { i64, ptr } %t161)
  store %"compiler/msgs:Msg" %t164, ptr %l76
  br label %bb31
bb31:
  %t165 = load ptr, ptr %l69, !tbaa !29
  %t166 = load %"compiler/source:Span", ptr %l70
  %t167 = load %"compiler/msgs:Msg", ptr %l76
  %t168 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t165, %"compiler/source:Span" %t166, %"compiler/msgs:Msg" %t167)
  store i64 %t168, ptr %l77
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s7)
  br label %bb33
bb33:
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayMade(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l6 = alloca i32
  %l8 = alloca i1
  %l9 = alloca ptr
  %l13 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t2)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load %"compiler/source:Span", ptr %l1
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t8 = load i32, ptr %l6, !tbaa !23
  %t10 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunArrayEnds(ptr %v0, ptr %t7, i32 %t8, %"compiler/source:Span" %t6)
  store i1 %t10, ptr %l8
  br label %bb2
bb2:
  %t11 = load i1, ptr %l8, !tbaa !21
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t12 = load ptr, ptr %l2, !tbaa !29
  store ptr %t12, ptr %l9, !tbaa !29
  br label %bb6
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load %"compiler/source:Span", ptr %l1
  %t18 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t14, %"compiler/source:Span" %t15)
  store ptr %t18, ptr %l13
  br label %bb5
bb5:
  %t19 = load ptr, ptr %l13, !tbaa !29
  store ptr %t19, ptr %l9, !tbaa !29
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l9, !tbaa !29
  store ptr %t20, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t6 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t2, i32 %a1)
  store i32 %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t8 = load i32, ptr %l6, !tbaa !23
  %t9 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t9, ptr %l7
  br label %bb2
bb2:
  %t10 = load i32, ptr %l7, !tbaa !23
  store i32 %t10, ptr %l2, !tbaa !23
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 2
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t16, i32 %t17)
  store i32 %t20, ptr %l12
  br label %bb3
bb3:
  %t21 = load i32, ptr %l12, !range !{i32 0, i32 33}
  %t23 = trunc i64 19 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb4, label %bb5
bb4:
  %t26 = load i32, ptr %l2, !tbaa !23
  store i32 %t26, ptr %l15, !tbaa !23
  br label %bb6
bb5:
  %t28 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t28, ptr %l15, !tbaa !23
  br label %bb6
bb6:
  %t30 = load i32, ptr %l15, !tbaa !23
  store i32 %t30, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2easCase(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %lp24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l42 = alloca i32
  %l45 = alloca i32
  %l50 = alloca i32
  %l58 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca i1
  %l68 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca i1
  %l80 = alloca i1
  %l81 = alloca i1
  %l85 = alloca i1
  %l93 = alloca { i64, ptr }
  %l99 = alloca i64
  %l102 = alloca i64
  %l120 = alloca { i64, ptr }
  %l123 = alloca { i64, ptr }
  %l139 = alloca ptr
  %l142 = alloca i1
  %l144 = alloca ptr
  %l145 = alloca ptr
  %l147 = alloca %"compiler/source:Span"
  %l149 = alloca %"compiler/source:Span"
  %l150 = alloca %"compiler/source:Span"
  %l153 = alloca { i64, ptr }
  %l155 = alloca %"compiler/msgs:Msg"
  %l156 = alloca i64
  %l157 = alloca ptr
  %l159 = alloca %"compiler/source:Span"
  %l162 = alloca { i64, ptr }
  %l163 = alloca { i64, ptr }
  %l164 = alloca ptr
  %l166 = alloca %"compiler/source:Span"
  %l167 = alloca { i64, ptr }
  %l170 = alloca %"compiler/msgs:Msg"
  %l171 = alloca i64
  %l174 = alloca ptr
  %l176 = alloca ptr
  %l179 = alloca i1
  %l187 = alloca %"compiler/source:Span"
  %l188 = alloca i32
  %l189 = alloca ptr
  %l193 = alloca i32
  %l196 = alloca ptr
  %l198 = alloca i32
  %l199 = alloca { i64, ptr }
  %l200 = alloca ptr
  %l202 = alloca %"compiler/source:Span"
  %l204 = alloca %"compiler/source:Span"
  %l205 = alloca %"compiler/source:Span"
  %l206 = alloca i32
  %l209 = alloca ptr
  %l214 = alloca i32
  %l215 = alloca { i64, ptr }
  %l216 = alloca { i64, ptr }
  %l221 = alloca ptr
  %l224 = alloca ptr
  %l229 = alloca i32
  %l230 = alloca i32
  %l231 = alloca { i64, ptr }
  %l239 = alloca { i64, ptr }
  %l240 = alloca ptr
  %l241 = alloca ptr
  %l243 = alloca %"compiler/source:Span"
  %l245 = alloca %"compiler/source:Span"
  %l246 = alloca %"compiler/source:Span"
  %l248 = alloca { i64, ptr }
  %l251 = alloca { i64, ptr }
  %l252 = alloca %"compiler/msgs:Msg"
  %l253 = alloca i64
  %l256 = alloca ptr
  %l257 = alloca %"compiler/source:Span"
  %l258 = alloca i32
  %l264 = alloca %"compiler/typed:Payload"
  %l273 = alloca { i64, ptr }
  %l278 = alloca ptr
  %l281 = alloca i64
  %l287 = alloca i64
  %l290 = alloca i64
  %l309 = alloca ptr
  %l313 = alloca { i64, ptr }
  %l320 = alloca ptr
  %l326 = alloca { i64, ptr }
  %l329 = alloca ptr
  %l334 = alloca i32
  %l335 = alloca i32
  %l336 = alloca %"compiler/source:Span"
  %l337 = alloca i32
  %l341 = alloca %"compiler/typed:Make"
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %rv = alloca ptr
  %t330 = alloca { i64, [4 x i64] }, align 8
  %t356 = alloca { i64, [4 x i64] }, align 8
  %t522 = alloca { i64, [4 x i64] }, align 8
  %t550 = alloca { i64, [4 x i64] }, align 8
  %t639 = alloca { i64, [4 x i64] }, align 8
  %t700 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 12
  store i1 true, ptr %t3, !tbaa !21
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t11 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v3, ptr %t4, ptr %t5, i32 %t7)
  store ptr %t11, ptr %l39
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l39, !tbaa !29
  store ptr %t12, ptr %l4, !tbaa !29
  %t13 = load ptr, ptr %l4, !tbaa !29
  %t16 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t13)
  store i32 %t16, ptr %l42
  br label %bb2
bb2:
  %t17 = load i32, ptr %l42, !tbaa !23
  store i32 %t17, ptr %l5, !tbaa !23
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l5, !tbaa !23
  %t22 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l45
  br label %bb3
bb3:
  %t23 = load i32, ptr %l45, !tbaa !23
  store i32 %t23, ptr %l6, !tbaa !23
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t30 = load i32, ptr %l6, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l50
  br label %bb4
bb4:
  %t34 = load i32, ptr %l50, !range !{i32 0, i32 33}
  %t36 = trunc i64 29 to i32
  %t37 = icmp eq i32 %t34, %t36
  br i1 %t37, label %bb5, label %bb6
bb5:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load %"compiler/source:Span", ptr %l1
  %t41 = load ptr, ptr %l4, !tbaa !29
  %t42 = load ptr, ptr %l2, !tbaa !29
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t49 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyAs(ptr %v0, ptr %v3, ptr %v1, ptr %v2, ptr %v3, ptr %t39, %"compiler/source:Span" %t40, ptr %t41, ptr %t42, ptr %t43)
  store ptr %t49, ptr %l58
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t50 = load ptr, ptr %l58, !tbaa !29
  store ptr %t50, ptr %rv
  br label %ret
bb8:
  store i64 -1, ptr %l7, !tbaa !24
  %t51 = load ptr, ptr %l3, !tbaa !29
  store ptr %t51, ptr %l8, !tbaa !29
  %t53 = load ptr, ptr %l3, !tbaa !29
  store ptr %t53, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t54 = load ptr, ptr %l60, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb9, label %bb10
bb9:
  %t57 = load ptr, ptr %l60, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 8}
  %t60 = icmp eq i64 %t58, 3
  store i1 %t60, ptr %l61, !tbaa !21
  br label %bb10
bb10:
  %t61 = load i1, ptr %l61, !tbaa !21
  br i1 %t61, label %bb11, label %bb12
bb11:
  %t62 = load ptr, ptr %l3, !tbaa !29
  %t64 = getelementptr { i64, [5 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t64, i32 0, i32 1
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l9, !tbaa !29
  br label %bb13
bb12:
  br label %bb18
bb13:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i32, ptr %l6, !tbaa !23
  %t72 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t68, i32 %t69)
  store i1 %t72, ptr %l68
  br label %bb14
bb14:
  %t73 = load i1, ptr %l68, !tbaa !21
  br i1 %t73, label %bb15, label %bb16
bb15:
  %t74 = load ptr, ptr %l9, !tbaa !29
  store ptr %t74, ptr %l8, !tbaa !29
  br label %bb17
bb16:
  br label %bb17
bb17:
  br label %bb23
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_30630aa0385ef6ff_761547ceb2a660b3)
  unreachable
bb23:
  %t76 = load ptr, ptr %l8, !tbaa !29
  store ptr %t76, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t77 = load ptr, ptr %l70, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb24, label %bb25
bb24:
  %t80 = load ptr, ptr %l70, !tbaa !29
  %t81 = load i64, ptr %t80, !range !{i64 0, i64 8}
  %t83 = icmp eq i64 %t81, 0
  store i1 %t83, ptr %l71, !tbaa !21
  br label %bb25
bb25:
  %t84 = load i1, ptr %l71, !tbaa !21
  br i1 %t84, label %bb26, label %bb27
bb26:
  %t85 = load ptr, ptr %l8, !tbaa !29
  %t87 = getelementptr { i64, [5 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t87, i32 0, i32 1
  %t89 = load { i64, ptr }, ptr %t88
  store { i64, ptr } %t89, ptr %l10, !tbaa !27
  %t91 = load ptr, ptr %l8, !tbaa !29
  %t93 = getelementptr { i64, [5 x i64] }, ptr %t91, i32 0, i32 1
  %t94 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t93, i32 0, i32 2
  %t95 = load { i64, ptr }, ptr %t94
  store { i64, ptr } %t95, ptr %l11, !tbaa !27
  br label %bb28
bb27:
  br label %bb55
bb28:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load i32, ptr %l6, !tbaa !23
  %t101 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t97, i32 %t98)
  store i1 %t101, ptr %l80
  br label %bb29
bb29:
  %t102 = load i1, ptr %l80, !tbaa !21
  br i1 %t102, label %bb30, label %bb31
bb30:
  %t103 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t103, 0
  %t107 = icmp sge i64 %t105, 2
  store i1 %t107, ptr %l81, !tbaa !21
  br label %bb32
bb31:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb32
bb32:
  %t109 = load i1, ptr %l81, !tbaa !21
  br i1 %t109, label %bb33, label %bb34
bb33:
  %t110 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t110, 0
  %t114 = icmp eq i64 %t112, 0
  store i1 %t114, ptr %l85, !tbaa !21
  br label %bb35
bb34:
  store i1 false, ptr %l85, !tbaa !21
  br label %bb35
bb35:
  %t116 = load i1, ptr %l85, !tbaa !21
  br i1 %t116, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s6
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = getelementptr %"compiler/generic:Program", ptr %t120, i32 0, i32 2
  %t123 = load i32, ptr %l6, !tbaa !23
  %t126 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %s6, ptr %t122, i32 %t123)
  store { i64, ptr } %t126, ptr %l93
  br label %bb38
bb37:
  br label %bb54
bb38:
  %t127 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t127, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t128 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t128, 0
  store i64 %t130, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t132 = load i64, ptr %l14, !tbaa !24
  %t133 = load i64, ptr %l13, !tbaa !24
  %t136 = icmp sgt i64 %t132, %t133
  br i1 %t136, label %bb39, label %bb40
bb39:
  %t138 = load i64, ptr %l15, !tbaa !24
  %t140 = icmp sgt i64 %t138, 0
  br i1 %t140, label %bb41, label %bb42
bb40:
  store i64 0, ptr %l99, !tbaa !24
  br label %bb44
bb41:
  %t142 = load i64, ptr %l14, !tbaa !24
  %t143 = load i64, ptr %l13, !tbaa !24
  %t146 = sub i64 %t142, %t143
  %t147 = load i64, ptr %l15, !tbaa !24
  %t150 = add i64 %t146, %t147
  %t152 = sub i64 %t150, 1
  %t153 = load i64, ptr %l15, !tbaa !24
  %t156 = sdiv i64 %t152, %t153
  store i64 %t156, ptr %l102, !tbaa !24
  br label %bb43
bb42:
  store i64 0, ptr %l102, !tbaa !24
  br label %bb43
bb43:
  %t158 = load i64, ptr %l102, !tbaa !24
  store i64 %t158, ptr %l99, !tbaa !24
  br label %bb44
bb44:
  %t159 = load i64, ptr %l99, !tbaa !24
  store i64 %t159, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb45
bb45:
  %t160 = load i64, ptr %l17, !tbaa !24
  %t161 = load i64, ptr %l16, !tbaa !24
  %t164 = icmp slt i64 %t160, %t161
  %t166 = xor i1 %t164, true
  br i1 %t166, label %bb46, label %bb47
bb46:
  br label %bb53
bb47:
  br label %bb48
bb48:
  %t168 = load i64, ptr %l13, !tbaa !24
  %t169 = load i64, ptr %l17, !tbaa !24
  %t170 = load i64, ptr %l15, !tbaa !24
  %t173 = mul i64 %t169, %t170
  %t176 = add i64 %t168, %t173
  store i64 %t176, ptr %l18, !tbaa !24
  %t178 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t178, ptr %l120, !tbaa !27
  %t179 = load i64, ptr %l18, !tbaa !24
  %t181 = getelementptr { i64, ptr }, ptr %l120, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !27
  %t183 = getelementptr i32, ptr %t182, i64 %t179
  %t184 = load i32, ptr %t183, !tbaa !33
  %t185 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t185, ptr %l123, !tbaa !27
  %t186 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t186, 0
  %t190 = sub i64 %t188, 1
  %t192 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = getelementptr i32, ptr %t193, i64 %t190
  %t195 = load i32, ptr %t194, !tbaa !33
  %t198 = icmp eq i32 %t184, %t195
  br i1 %t198, label %bb49, label %bb50
bb49:
  %t200 = load i64, ptr %l18, !tbaa !24
  store i64 %t200, ptr %l7, !tbaa !24
  br label %bb51
bb50:
  br label %bb51
bb51:
  br label %bb52
bb52:
  %t202 = load i64, ptr %l17, !tbaa !24
  %t204 = add i64 %t202, 1
  store i64 %t204, ptr %l17, !tbaa !24
  br label %bb45
bb53:
  call void @__olang_scope_close(ptr %s6)
  br label %bb54
bb54:
  br label %bb60
bb55:
  br i1 true, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_383f9ac3750cc0fe_a676b835dd8ab732)
  unreachable
bb60:
  %t206 = load i64, ptr %l7, !tbaa !24
  %t208 = icmp slt i64 %t206, 0
  br i1 %t208, label %bb61, label %bb62
bb61:
  %t210 = load i32, ptr %l5, !tbaa !23
  %t211 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t214 = icmp eq i32 %t210, %t211
  br i1 %t214, label %bb63, label %bb64
bb62:
  br label %bb84
bb63:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load %"compiler/source:Span", ptr %l1
  %t220 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t216, %"compiler/source:Span" %t217)
  store ptr %t220, ptr %l139
  br label %bb65
bb64:
  br label %bb66
bb65:
  call void @__olang_scope_close(ptr %s0)
  %t221 = load ptr, ptr %l139, !tbaa !29
  store ptr %t221, ptr %rv
  br label %ret
bb66:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t223 = load i32, ptr %l6, !tbaa !23
  %t226 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t222, i32 %t223)
  store i1 %t226, ptr %l142
  br label %bb67
bb67:
  %t227 = load i1, ptr %l142, !tbaa !21
  %t228 = xor i1 %t227, true
  br i1 %t228, label %bb68, label %bb69
bb68:
  store %olang.scope zeroinitializer, ptr %s14
  %t230 = load ptr, ptr %l0, !tbaa !29
  store ptr %t230, ptr %l144, !tbaa !29
  %t231 = load ptr, ptr %l0, !tbaa !29
  store ptr %t231, ptr %l145, !tbaa !29
  %t232 = load ptr, ptr %l2, !tbaa !29
  %t234 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t232)
  store %"compiler/source:Span" %t234, ptr %l147
  br label %bb70
bb69:
  store %olang.scope zeroinitializer, ptr %s15
  %t235 = load ptr, ptr %l0, !tbaa !29
  store ptr %t235, ptr %l157, !tbaa !29
  %t236 = load ptr, ptr %l3, !tbaa !29
  %t238 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %t236)
  store %"compiler/source:Span" %t238, ptr %l159
  br label %bb76
bb70:
  %t239 = load ptr, ptr %l3, !tbaa !29
  %t241 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %t239)
  store %"compiler/source:Span" %t241, ptr %l149
  br label %bb71
bb71:
  %t242 = load ptr, ptr %l145, !tbaa !29
  %t243 = load %"compiler/source:Span", ptr %l147
  %t244 = load %"compiler/source:Span", ptr %l149
  %t245 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t242, %"compiler/source:Span" %t243, %"compiler/source:Span" %t244, i64 2)
  store %"compiler/source:Span" %t245, ptr %l150
  br label %bb72
bb72:
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t247 = load i32, ptr %l5, !tbaa !23
  %t250 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s14, ptr %t246, i32 %t247)
  store { i64, ptr } %t250, ptr %l153
  br label %bb73
bb73:
  %t251 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t251, 0
  %t253 = extractvalue { i64, ptr } %t251, 1
  %t254 = mul i64 %t252, 1
  %t255 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t254)
  call void @llvm.memcpy.p0.p0.i64(ptr %t255, ptr %t253, i64 %t254, i1 false)
  %t256 = insertvalue { i64, ptr } undef, i64 %t252, 0
  %t257 = insertvalue { i64, ptr } %t256, ptr %t255, 1
  %t259 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsAsNotEnum(ptr %s14, ptr %s14, { i64, ptr } %t257)
  store %"compiler/msgs:Msg" %t259, ptr %l155
  br label %bb74
bb74:
  %t260 = load ptr, ptr %l144, !tbaa !29
  %t261 = load %"compiler/source:Span", ptr %l150
  %t262 = load %"compiler/msgs:Msg", ptr %l155
  %t263 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s14, ptr %t260, %"compiler/source:Span" %t261, %"compiler/msgs:Msg" %t262)
  store i64 %t263, ptr %l156
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s14)
  br label %bb82
bb76:
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t265 = load i32, ptr %l6, !tbaa !23
  %t268 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s15, ptr %t264, i32 %t265)
  store { i64, ptr } %t268, ptr %l162
  br label %bb77
bb77:
  %t269 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t270 = extractvalue { i64, ptr } %t269, 0
  %t271 = extractvalue { i64, ptr } %t269, 1
  %t272 = mul i64 %t270, 1
  %t273 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t272)
  call void @llvm.memcpy.p0.p0.i64(ptr %t273, ptr %t271, i64 %t272, i1 false)
  %t274 = insertvalue { i64, ptr } undef, i64 %t270, 0
  %t275 = insertvalue { i64, ptr } %t274, ptr %t273, 1
  store { i64, ptr } %t275, ptr %l163, !tbaa !27
  %t276 = load ptr, ptr %l0, !tbaa !29
  store ptr %t276, ptr %l164, !tbaa !29
  %t277 = load ptr, ptr %l3, !tbaa !29
  %t279 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %t277)
  store %"compiler/source:Span" %t279, ptr %l166
  br label %bb78
bb78:
  %t280 = load ptr, ptr %l164, !tbaa !29
  %t281 = load %"compiler/source:Span", ptr %l166
  %t282 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %s15, ptr %t280, %"compiler/source:Span" %t281)
  store { i64, ptr } %t282, ptr %l167
  br label %bb79
bb79:
  %t283 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t284 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t285 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t286 = extractvalue { i64, ptr } %t285, 1
  %t287 = extractvalue { i64, ptr } %t285, 0
  %t288 = add i64 %t284, %t287
  %t289 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t290 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t291 = add i64 %t288, %t290
  %t292 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t291)
  call void @olang_textcopy(ptr %t292, ptr %t283, i64 %t284)
  %t293 = getelementptr i8, ptr %t292, i64 %t284
  call void @olang_textcopy(ptr %t293, ptr %t286, i64 %t287)
  %t294 = getelementptr i8, ptr %t293, i64 %t287
  call void @olang_textcopy(ptr %t294, ptr %t289, i64 %t290)
  %t295 = insertvalue { i64, ptr } undef, i64 %t291, 0
  %t296 = insertvalue { i64, ptr } %t295, ptr %t292, 1
  %t298 = extractvalue { i64, ptr } %t296, 0
  %t299 = extractvalue { i64, ptr } %t296, 1
  %t300 = mul i64 %t298, 1
  %t301 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t300)
  call void @llvm.memcpy.p0.p0.i64(ptr %t301, ptr %t299, i64 %t300, i1 false)
  %t302 = insertvalue { i64, ptr } undef, i64 %t298, 0
  %t303 = insertvalue { i64, ptr } %t302, ptr %t301, 1
  %t304 = load { i64, ptr }, ptr %l163, !tbaa !27
  %t306 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAsNeedsCase(ptr %s15, ptr %s15, ptr %s15, { i64, ptr } %t304, { i64, ptr } %t303)
  store %"compiler/msgs:Msg" %t306, ptr %l170
  br label %bb80
bb80:
  %t307 = load ptr, ptr %l157, !tbaa !29
  %t308 = load %"compiler/source:Span", ptr %l159
  %t309 = load %"compiler/msgs:Msg", ptr %l170
  %t310 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s15, ptr %t307, %"compiler/source:Span" %t308, %"compiler/msgs:Msg" %t309)
  store i64 %t310, ptr %l171
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s15)
  br label %bb82
bb82:
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t312 = load %"compiler/source:Span", ptr %l1
  %t315 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t311, %"compiler/source:Span" %t312)
  store ptr %t315, ptr %l174
  br label %bb83
bb83:
  call void @__olang_scope_close(ptr %s0)
  %t316 = load ptr, ptr %l174, !tbaa !29
  store ptr %t316, ptr %rv
  br label %ret
bb84:
  %t317 = load ptr, ptr %l4, !tbaa !29
  %t319 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v3, ptr %v3, ptr %t317)
  store ptr %t319, ptr %l176
  br label %bb85
bb85:
  %t320 = load ptr, ptr %l176, !tbaa !29
  store ptr %t320, ptr %l19, !tbaa !29
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t322 = load i32, ptr %l5, !tbaa !23
  %t325 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t321, i32 %t322)
  store i1 %t325, ptr %l179
  br label %bb86
bb86:
  %t326 = load i1, ptr %l179, !tbaa !21
  br i1 %t326, label %bb87, label %bb88
bb87:
  %t327 = load %"compiler/source:Span", ptr %l1
  %t328 = load i32, ptr %l6, !tbaa !23
  %t329 = load ptr, ptr %l4, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t330
  %t331 = getelementptr { i64, [4 x i64] }, ptr %t330, i32 0, i32 0
  store i64 2, ptr %t331
  %t333 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t327, 0
  %t335 = insertvalue { %"compiler/source:Span", i32, ptr } %t333, i32 %t328, 1
  %t337 = insertvalue { %"compiler/source:Span", i32, ptr } %t335, ptr %t329, 2
  %t338 = getelementptr { i64, [4 x i64] }, ptr %t330, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t337, ptr %t338
  %t339 = load { i64, [4 x i64] }, ptr %t330
  %t341 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store { i64, [4 x i64] } %t339, ptr %t341
  store ptr %t341, ptr %l19, !tbaa !29
  br label %bb93
bb88:
  %t343 = load ptr, ptr %l19, !tbaa !29
  %t345 = icmp eq ptr %t343, null
  br i1 %t345, label %bb89, label %bb90
bb89:
  %t347 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t347, ptr %l187
  %t348 = load i32, ptr %l5, !tbaa !23
  store i32 %t348, ptr %l188, !tbaa !23
  %t349 = load ptr, ptr %l4, !tbaa !29
  store ptr %t349, ptr %l189, !tbaa !29
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t351 = load %"compiler/source:Span", ptr %l1
  %t355 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t350, i32 8, %"compiler/source:Span" %t351)
  store i32 %t355, ptr %l193
  br label %bb91
bb90:
  br label %bb92
bb91:
  store { i64, [4 x i64] } zeroinitializer, ptr %t356
  %t357 = getelementptr { i64, [4 x i64] }, ptr %t356, i32 0, i32 0
  store i64 6, ptr %t357
  %t358 = load %"compiler/source:Span", ptr %l187
  %t359 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t358, 0
  %t360 = load i32, ptr %l188, !tbaa !23
  %t361 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t359, i32 %t360, 1
  %t362 = load ptr, ptr %l189, !tbaa !29
  %t363 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t361, ptr %t362, 2
  %t364 = load i32, ptr %l193, !tbaa !23
  %t365 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t363, i32 %t364, 3
  %t366 = getelementptr { i64, [4 x i64] }, ptr %t356, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t365, ptr %t366
  %t367 = load { i64, [4 x i64] }, ptr %t356
  %t369 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store { i64, [4 x i64] } %t367, ptr %t369
  store ptr %t369, ptr %l19, !tbaa !29
  br label %bb92
bb92:
  br label %bb93
bb93:
  %t371 = load ptr, ptr %l0, !tbaa !29
  store ptr %t371, ptr %l196, !tbaa !29
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t374 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrongCase(ptr %v0, ptr %t372)
  store i32 %t374, ptr %l198
  br label %bb94
bb94:
  %t375 = mul i64 1, 4
  %t376 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t375)
  %t377 = insertvalue { i64, ptr } undef, i64 1, 0
  %t378 = insertvalue { i64, ptr } %t377, ptr %t376, 1
  store { i64, ptr } %t378, ptr %l199, !tbaa !27
  %t379 = load i32, ptr %l198, !tbaa !23
  %t380 = getelementptr { i64, ptr }, ptr %l199, i32 0, i32 1
  %t381 = load ptr, ptr %t380, !tbaa !27
  %t382 = getelementptr i32, ptr %t381, i64 0
  store i32 %t379, ptr %t382, !tbaa !33
  %t383 = load ptr, ptr %l0, !tbaa !29
  store ptr %t383, ptr %l200, !tbaa !29
  %t384 = load ptr, ptr %l2, !tbaa !29
  %t386 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t384)
  store %"compiler/source:Span" %t386, ptr %l202
  br label %bb95
bb95:
  %t387 = load ptr, ptr %l3, !tbaa !29
  %t389 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %t387)
  store %"compiler/source:Span" %t389, ptr %l204
  br label %bb96
bb96:
  %t390 = load ptr, ptr %l200, !tbaa !29
  %t391 = load %"compiler/source:Span", ptr %l202
  %t392 = load %"compiler/source:Span", ptr %l204
  %t393 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t390, %"compiler/source:Span" %t391, %"compiler/source:Span" %t392, i64 2)
  store %"compiler/source:Span" %t393, ptr %l205
  br label %bb97
bb97:
  %t394 = load ptr, ptr %l196, !tbaa !29
  %t395 = load { i64, ptr }, ptr %l199, !tbaa !27
  %t396 = load %"compiler/source:Span", ptr %l205
  %t397 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailOp(ptr %v0, ptr %s0, ptr %t394, { i64, ptr } %t395, %"compiler/source:Span" %t396, i1 true)
  store i32 %t397, ptr %l206
  br label %bb98
bb98:
  %t398 = load i32, ptr %l206, !range !{i32 0, i32 3}
  store i32 %t398, ptr %l20
  %t399 = load ptr, ptr %l0, !tbaa !29
  %t401 = getelementptr %"compiler/check:Checker", ptr %t399, i32 0, i32 1
  %t402 = load ptr, ptr %t401, !tbaa !29
  %t404 = getelementptr %"compiler/generic:Program", ptr %t402, i32 0, i32 2
  store ptr %t404, ptr %l209, !tbaa !29
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t407 = getelementptr %"compiler/check:Checker", ptr %t405, i32 0, i32 1
  %t408 = load ptr, ptr %t407, !tbaa !29
  %t410 = getelementptr %"compiler/generic:Program", ptr %t408, i32 0, i32 2
  %t411 = load i32, ptr %l6, !tbaa !23
  %t414 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t410, i32 %t411)
  store i32 %t414, ptr %l214
  br label %bb99
bb99:
  %t415 = load ptr, ptr %l209, !tbaa !29
  %t416 = load i32, ptr %l214, !tbaa !23
  %t417 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t415, i32 %t416)
  store { i64, ptr } %t417, ptr %l215
  br label %bb100
bb100:
  %t418 = load { i64, ptr }, ptr %l215, !tbaa !27
  store { i64, ptr } %t418, ptr %l216, !tbaa !27
  %t419 = load i64, ptr %l7, !tbaa !24
  %t421 = getelementptr { i64, ptr }, ptr %l216, i32 0, i32 1
  %t422 = load ptr, ptr %t421, !tbaa !27
  %t423 = getelementptr i32, ptr %t422, i64 %t419
  %t424 = load i32, ptr %t423, !tbaa !33
  store i32 %t424, ptr %l21, !tbaa !23
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t428 = getelementptr %"compiler/check:Checker", ptr %t426, i32 0, i32 1
  %t429 = load ptr, ptr %t428, !tbaa !29
  %t431 = getelementptr %"compiler/generic:Program", ptr %t429, i32 0, i32 2
  store ptr %t431, ptr %l221, !tbaa !29
  %t432 = load ptr, ptr %l0, !tbaa !29
  %t434 = getelementptr %"compiler/check:Checker", ptr %t432, i32 0, i32 1
  %t435 = load ptr, ptr %t434, !tbaa !29
  %t437 = getelementptr %"compiler/generic:Program", ptr %t435, i32 0, i32 2
  store ptr %t437, ptr %l224, !tbaa !29
  %t438 = load ptr, ptr %l0, !tbaa !29
  %t440 = getelementptr %"compiler/check:Checker", ptr %t438, i32 0, i32 1
  %t441 = load ptr, ptr %t440, !tbaa !29
  %t442 = load i32, ptr %l6, !tbaa !23
  %t443 = load i64, ptr %l7, !tbaa !24
  %t447 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %t441, i32 %t442, i64 %t443)
  store i32 %t447, ptr %l229
  br label %bb101
bb101:
  %t448 = load ptr, ptr %l224, !tbaa !29
  %t449 = load i32, ptr %l229, !tbaa !23
  %t450 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t448, i32 %t449)
  store i32 %t450, ptr %l230
  br label %bb102
bb102:
  %t451 = load ptr, ptr %l221, !tbaa !29
  %t452 = load i32, ptr %l230, !tbaa !23
  %t453 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t451, i32 %t452)
  store { i64, ptr } %t453, ptr %l231
  br label %bb103
bb103:
  %t454 = load { i64, ptr }, ptr %l231, !tbaa !27
  store { i64, ptr } %t454, ptr %l22, !tbaa !27
  %t455 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t457 = extractvalue { i64, ptr } %t455, 0
  %t459 = icmp eq i64 %t457, 0
  br i1 %t459, label %bb104, label %bb105
bb104:
  store %olang.scope zeroinitializer, ptr %s20
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t463 = getelementptr %"compiler/check:Checker", ptr %t461, i32 0, i32 1
  %t464 = load ptr, ptr %t463, !tbaa !29
  %t466 = getelementptr %"compiler/generic:Program", ptr %t464, i32 0, i32 2
  %t467 = load i32, ptr %l6, !tbaa !23
  %t470 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %s20, ptr %t466, i32 %t467)
  store { i64, ptr } %t470, ptr %l239
  br label %bb106
bb105:
  br label %bb114
bb106:
  %t471 = load { i64, ptr }, ptr %l239, !tbaa !27
  store { i64, ptr } %t471, ptr %l23, !tbaa !27
  %t472 = load ptr, ptr %l0, !tbaa !29
  store ptr %t472, ptr %l240, !tbaa !29
  %t473 = load ptr, ptr %l0, !tbaa !29
  store ptr %t473, ptr %l241, !tbaa !29
  %t474 = load ptr, ptr %l2, !tbaa !29
  %t476 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t474)
  store %"compiler/source:Span" %t476, ptr %l243
  br label %bb107
bb107:
  %t477 = load ptr, ptr %l3, !tbaa !29
  %t479 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %t477)
  store %"compiler/source:Span" %t479, ptr %l245
  br label %bb108
bb108:
  %t480 = load ptr, ptr %l241, !tbaa !29
  %t481 = load %"compiler/source:Span", ptr %l243
  %t482 = load %"compiler/source:Span", ptr %l245
  %t483 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t480, %"compiler/source:Span" %t481, %"compiler/source:Span" %t482, i64 2)
  store %"compiler/source:Span" %t483, ptr %l246
  br label %bb109
bb109:
  %t484 = load ptr, ptr %l0, !tbaa !29
  %t485 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t485, ptr %l248, !tbaa !27
  %t486 = load i64, ptr %l7, !tbaa !24
  %t488 = getelementptr { i64, ptr }, ptr %l248, i32 0, i32 1
  %t489 = load ptr, ptr %t488, !tbaa !27
  %t490 = getelementptr i32, ptr %t489, i64 %t486
  %t491 = load i32, ptr %t490, !tbaa !33
  %t494 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t484, i32 %t491)
  store { i64, ptr } %t494, ptr %l251
  br label %bb110
bb110:
  %t495 = load { i64, ptr }, ptr %l251, !tbaa !27
  %t496 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAsNothing(ptr %v0, ptr %s20, { i64, ptr } %t495)
  store %"compiler/msgs:Msg" %t496, ptr %l252
  br label %bb111
bb111:
  %t497 = load ptr, ptr %l240, !tbaa !29
  %t498 = load %"compiler/source:Span", ptr %l246
  %t499 = load %"compiler/msgs:Msg", ptr %l252
  %t500 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s20, ptr %t497, %"compiler/source:Span" %t498, %"compiler/msgs:Msg" %t499)
  store i64 %t500, ptr %l253
  br label %bb112
bb112:
  %t501 = load ptr, ptr %l0, !tbaa !29
  %t502 = load %"compiler/source:Span", ptr %l1
  %t505 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t501, %"compiler/source:Span" %t502)
  store ptr %t505, ptr %l256
  br label %bb113
bb113:
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s0)
  %t506 = load ptr, ptr %l256, !tbaa !29
  store ptr %t506, ptr %rv
  br label %ret
bb114:
  %t507 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t507, ptr %l257
  %t508 = load i32, ptr %l21, !tbaa !23
  store i32 %t508, ptr %l258, !tbaa !23
  %t509 = load ptr, ptr %l19, !tbaa !29
  %t511 = icmp eq ptr %t509, null
  br i1 %t511, label %bb115, label %bb116
bb115:
  call void @__olang_check_failed(ptr @olang_loc_d7812add9a78f336_89874a21e94d300a)
  unreachable
bb116:
  br label %bb117
bb117:
  %t513 = load ptr, ptr %l19, !tbaa !29
  %t514 = load i64, ptr %l7, !tbaa !24
  %t515 = load i32, ptr %l20, !range !{i32 0, i32 3}
  %t519 = call %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v3, ptr %v3, ptr %t513, i64 %t514, i32 %t515)
  store %"compiler/typed:Payload" %t519, ptr %l264
  br label %bb118
bb118:
  %t520 = load %"compiler/typed:Payload", ptr %l264
  %t521 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 24, i64 8)
  store %"compiler/typed:Payload" %t520, ptr %t521
  store { i64, [4 x i64] } zeroinitializer, ptr %t522
  %t523 = getelementptr { i64, [4 x i64] }, ptr %t522, i32 0, i32 0
  store i64 5, ptr %t523
  %t524 = load %"compiler/source:Span", ptr %l257
  %t525 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t524, 0
  %t526 = load i32, ptr %l258, !tbaa !23
  %t527 = insertvalue { %"compiler/source:Span", i32, ptr } %t525, i32 %t526, 1
  %t529 = insertvalue { %"compiler/source:Span", i32, ptr } %t527, ptr %t521, 2
  %t530 = getelementptr { i64, [4 x i64] }, ptr %t522, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t529, ptr %t530
  %t531 = load { i64, [4 x i64] }, ptr %t522
  %t532 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store ptr %t532, ptr %lp24
  %t534 = load ptr, ptr %lp24
  store { i64, [4 x i64] } %t531, ptr %t534
  %t535 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t537 = extractvalue { i64, ptr } %t535, 0
  %t539 = icmp eq i64 %t537, 1
  br i1 %t539, label %bb119, label %bb120
bb119:
  %t541 = load ptr, ptr %l0, !tbaa !29
  %t542 = load %"compiler/source:Span", ptr %l1
  %t543 = load %"compiler/source:Span", ptr %l1
  %t544 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t544, ptr %l273, !tbaa !27
  %t545 = getelementptr { i64, ptr }, ptr %l273, i32 0, i32 1
  %t546 = load ptr, ptr %t545, !tbaa !27
  %t547 = getelementptr i32, ptr %t546, i64 0
  %t548 = load i32, ptr %t547, !tbaa !33
  %t549 = load ptr, ptr %lp24
  store { i64, [4 x i64] } zeroinitializer, ptr %t550
  %t551 = getelementptr { i64, [4 x i64] }, ptr %t550, i32 0, i32 0
  store i64 3, ptr %t551
  %t553 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t543, 0
  %t555 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t553, i32 %t548, 1
  %t557 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t555, ptr %t549, 2
  %t558 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t557, i64 0, 3
  %t559 = getelementptr { i64, [4 x i64] }, ptr %t550, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t558, ptr %t559
  %t560 = load { i64, [4 x i64] }, ptr %t550
  %t562 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store { i64, [4 x i64] } %t560, ptr %t562
  %t566 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v3, ptr %v3, ptr %t541, %"compiler/source:Span" %t542, ptr %t562)
  store ptr %t566, ptr %l278
  br label %bb121
bb120:
  br label %bb122
bb121:
  call void @__olang_scope_close(ptr %s0)
  %t567 = load ptr, ptr %l278, !tbaa !29
  store ptr %t567, ptr %rv
  br label %ret
bb122:
  %t568 = load ptr, ptr %l0, !tbaa !29
  %t570 = getelementptr %"compiler/check:Checker", ptr %t568, i32 0, i32 36
  %t572 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t570)
  store i64 %t572, ptr %l281
  br label %bb123
bb123:
  %t573 = load i64, ptr %l281, !tbaa !24
  store i64 %t573, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  %t574 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t576 = extractvalue { i64, ptr } %t574, 0
  store i64 %t576, ptr %l27, !tbaa !24
  store i64 1, ptr %l28, !tbaa !24
  %t578 = load i64, ptr %l27, !tbaa !24
  %t579 = load i64, ptr %l26, !tbaa !24
  %t582 = icmp sgt i64 %t578, %t579
  br i1 %t582, label %bb124, label %bb125
bb124:
  %t584 = load i64, ptr %l28, !tbaa !24
  %t586 = icmp sgt i64 %t584, 0
  br i1 %t586, label %bb126, label %bb127
bb125:
  store i64 0, ptr %l287, !tbaa !24
  br label %bb129
bb126:
  %t588 = load i64, ptr %l27, !tbaa !24
  %t589 = load i64, ptr %l26, !tbaa !24
  %t592 = sub i64 %t588, %t589
  %t593 = load i64, ptr %l28, !tbaa !24
  %t596 = add i64 %t592, %t593
  %t598 = sub i64 %t596, 1
  %t599 = load i64, ptr %l28, !tbaa !24
  %t602 = sdiv i64 %t598, %t599
  store i64 %t602, ptr %l290, !tbaa !24
  br label %bb128
bb127:
  store i64 0, ptr %l290, !tbaa !24
  br label %bb128
bb128:
  %t604 = load i64, ptr %l290, !tbaa !24
  store i64 %t604, ptr %l287, !tbaa !24
  br label %bb129
bb129:
  %t605 = load i64, ptr %l287, !tbaa !24
  store i64 %t605, ptr %l29, !tbaa !24
  store i64 0, ptr %l30, !tbaa !24
  br label %bb130
bb130:
  %t606 = load i64, ptr %l30, !tbaa !24
  %t607 = load i64, ptr %l29, !tbaa !24
  %t610 = icmp slt i64 %t606, %t607
  %t612 = xor i1 %t610, true
  br i1 %t612, label %bb131, label %bb132
bb131:
  br label %bb137
bb132:
  br label %bb133
bb133:
  %t614 = load i64, ptr %l26, !tbaa !24
  %t615 = load i64, ptr %l30, !tbaa !24
  %t616 = load i64, ptr %l28, !tbaa !24
  %t619 = mul i64 %t615, %t616
  %t622 = add i64 %t614, %t619
  store i64 %t622, ptr %l31, !tbaa !24
  %t624 = load ptr, ptr %l0, !tbaa !29
  %t626 = getelementptr %"compiler/check:Checker", ptr %t624, i32 0, i32 36
  store ptr %t626, ptr %l309, !tbaa !29
  %t627 = load ptr, ptr %l0, !tbaa !29
  %t628 = load %"compiler/source:Span", ptr %l1
  %t629 = load %"compiler/source:Span", ptr %l1
  %t630 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t630, ptr %l313, !tbaa !27
  %t631 = load i64, ptr %l31, !tbaa !24
  %t633 = getelementptr { i64, ptr }, ptr %l313, i32 0, i32 1
  %t634 = load ptr, ptr %t633, !tbaa !27
  %t635 = getelementptr i32, ptr %t634, i64 %t631
  %t636 = load i32, ptr %t635, !tbaa !33
  %t637 = load ptr, ptr %lp24
  %t638 = load i64, ptr %l31, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t639
  %t640 = getelementptr { i64, [4 x i64] }, ptr %t639, i32 0, i32 0
  store i64 3, ptr %t640
  %t642 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t629, 0
  %t644 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t642, i32 %t636, 1
  %t646 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t644, ptr %t637, 2
  %t648 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t646, i64 %t638, 3
  %t649 = getelementptr { i64, [4 x i64] }, ptr %t639, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t648, ptr %t649
  %t650 = load { i64, [4 x i64] }, ptr %t639
  %t652 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t650, ptr %t652
  %t656 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t627, %"compiler/source:Span" %t628, ptr %t652)
  store ptr %t656, ptr %l320
  br label %bb134
bb134:
  %t657 = load ptr, ptr %l309, !tbaa !29
  %t658 = load ptr, ptr %l320, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t657, ptr %t658)
  br label %bb135
bb135:
  br label %bb136
bb136:
  %t659 = load i64, ptr %l30, !tbaa !24
  %t661 = add i64 %t659, 1
  store i64 %t661, ptr %l30, !tbaa !24
  br label %bb130
bb137:
  %t663 = load ptr, ptr %l0, !tbaa !29
  %t665 = getelementptr %"compiler/check:Checker", ptr %t663, i32 0, i32 36
  %t666 = load i64, ptr %l25, !tbaa !24
  %t669 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v3, ptr %t665, i64 %t666)
  store { i64, ptr } %t669, ptr %l326
  br label %bb138
bb138:
  %t670 = load { i64, ptr }, ptr %l326, !tbaa !27
  store { i64, ptr } %t670, ptr %l32, !tbaa !27
  %t671 = load ptr, ptr %l0, !tbaa !29
  %t673 = getelementptr %"compiler/check:Checker", ptr %t671, i32 0, i32 1
  %t674 = load ptr, ptr %t673, !tbaa !29
  %t676 = getelementptr %"compiler/generic:Program", ptr %t674, i32 0, i32 2
  store ptr %t676, ptr %l329, !tbaa !29
  %t677 = load ptr, ptr %l0, !tbaa !29
  %t679 = getelementptr %"compiler/check:Checker", ptr %t677, i32 0, i32 1
  %t680 = load ptr, ptr %t679, !tbaa !29
  %t682 = getelementptr %"compiler/generic:Program", ptr %t680, i32 0, i32 2
  %t683 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t686 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v0, ptr %t682, { i64, ptr } %t683)
  store i32 %t686, ptr %l334
  br label %bb139
bb139:
  %t687 = load ptr, ptr %l329, !tbaa !29
  %t688 = load i32, ptr %l334, !tbaa !23
  %t689 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %t687, i32 %t688)
  store i32 %t689, ptr %l335
  br label %bb140
bb140:
  %t690 = load i32, ptr %l335, !tbaa !23
  %t691 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t691, ptr %l336
  store i32 %t690, ptr %l337, !tbaa !23
  %t693 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t697 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v3, ptr %v3, ptr %v3, i32 0, i64 0, { i64, ptr } %t693, ptr null, i32 -1, i32 0, i1 false)
  store %"compiler/typed:Make" %t697, ptr %l341
  br label %bb141
bb141:
  %t698 = load %"compiler/typed:Make", ptr %l341
  %t699 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 56, i64 8)
  store %"compiler/typed:Make" %t698, ptr %t699
  store { i64, [5 x i64] } zeroinitializer, ptr %t700
  %t701 = getelementptr { i64, [5 x i64] }, ptr %t700, i32 0, i32 0
  store i64 7, ptr %t701
  %t702 = load %"compiler/source:Span", ptr %l336
  %t703 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t702, 0
  %t704 = load i32, ptr %l337, !tbaa !23
  %t705 = insertvalue { %"compiler/source:Span", i32, ptr } %t703, i32 %t704, 1
  %t707 = insertvalue { %"compiler/source:Span", i32, ptr } %t705, ptr %t699, 2
  %t708 = getelementptr { i64, [5 x i64] }, ptr %t700, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t707, ptr %t708
  %t709 = load { i64, [5 x i64] }, ptr %t700
  %t711 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store { i64, [5 x i64] } %t709, ptr %t711
  call void @__olang_scope_close(ptr %s0)
  store ptr %t711, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l8 = alloca ptr
  %l11 = alloca i64
  %l14 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l38 = alloca %"compiler/source:Span"
  %l41 = alloca i32
  %l43 = alloca ptr
  %l47 = alloca %"compiler/typed:Try"
  %rv = alloca ptr
  %t90 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l8
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l8, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 28
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l11
  br label %bb2
bb2:
  %t10 = load i64, ptr %l11, !tbaa !24
  store i64 %t10, ptr %l3, !tbaa !24
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = getelementptr %"compiler/check:frame", ptr %t11, i32 0, i32 16
  %t14 = load i64, ptr %t13, !tbaa !24
  store i64 %t14, ptr %l4, !tbaa !24
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %l14, !tbaa !29
  %t17 = load ptr, ptr %l14, !tbaa !29
  %t18 = getelementptr %"compiler/check:frame", ptr %t17, i32 0, i32 15
  %t19 = load i64, ptr %t18, !tbaa !24
  %t21 = add i64 %t19, 1
  %t23 = load ptr, ptr %l14, !tbaa !29
  %t24 = getelementptr %"compiler/check:frame", ptr %t23, i32 0, i32 15
  store i64 %t21, ptr %t24, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t32 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t25, ptr %t26, i32 %t28)
  store ptr %t32, ptr %l21
  br label %bb3
bb3:
  %t33 = load ptr, ptr %l21, !tbaa !29
  store ptr %t33, ptr %l5, !tbaa !29
  %t34 = load ptr, ptr %l2, !tbaa !29
  store ptr %t34, ptr %l22, !tbaa !29
  %t35 = load ptr, ptr %l22, !tbaa !29
  %t36 = getelementptr %"compiler/check:frame", ptr %t35, i32 0, i32 15
  %t37 = load i64, ptr %t36, !tbaa !24
  %t39 = sub i64 %t37, 1
  %t41 = load ptr, ptr %l22, !tbaa !29
  %t42 = getelementptr %"compiler/check:frame", ptr %t41, i32 0, i32 15
  store i64 %t39, ptr %t42, !tbaa !24
  %t43 = load ptr, ptr %l2, !tbaa !29
  %t45 = getelementptr %"compiler/check:frame", ptr %t43, i32 0, i32 16
  %t46 = load i64, ptr %t45, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = icmp ne i64 %t46, %t47
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t53 = load i64, ptr %l4, !tbaa !24
  %t56 = getelementptr %"compiler/check:frame", ptr %t52, i32 0, i32 16
  store i64 %t53, ptr %t56, !tbaa !24
  %t59 = xor i1 %t50, true
  br i1 %t59, label %bb4, label %bb5
bb4:
  %t61 = load ptr, ptr %l5, !tbaa !29
  store ptr %t61, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t63 = load ptr, ptr %l2, !tbaa !29
  %t65 = getelementptr %"compiler/check:frame", ptr %t63, i32 0, i32 28
  %t66 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t65, i64 %t66)
  br label %bb7
bb7:
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t71 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t69)
  store %"compiler/source:Span" %t71, ptr %l38
  br label %bb8
bb8:
  %t72 = load ptr, ptr %l5, !tbaa !29
  %t75 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t72)
  store i32 %t75, ptr %l41
  br label %bb9
bb9:
  %t76 = load ptr, ptr %l5, !tbaa !29
  store ptr %t76, ptr %l43, !tbaa !29
  %t78 = icmp sge i64 0, 0
  br i1 %t78, label %bb10, label %bb11
bb10:
  %t80 = icmp sle i64 0, 1152921504606846975
  br i1 %t80, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_ca088269e212954c_d643913a2551dac8)
  unreachable
bb12:
  %t82 = mul i64 0, 8
  %t83 = insertvalue { i64, ptr } undef, i64 0, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t85 = load ptr, ptr %l43, !tbaa !29
  %t87 = call %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %t85, { i64, ptr } %t84, i1 true, i1 false, i1 true)
  store %"compiler/typed:Try" %t87, ptr %l47
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_ca088269e212954c_d643913a2551dac8)
  unreachable
bb14:
  %t88 = load %"compiler/typed:Try", ptr %l47
  %t89 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"compiler/typed:Try" %t88, ptr %t89
  store { i64, [5 x i64] } zeroinitializer, ptr %t90
  %t91 = getelementptr { i64, [5 x i64] }, ptr %t90, i32 0, i32 0
  store i64 14, ptr %t91
  %t92 = load %"compiler/source:Span", ptr %l38
  %t93 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t92, 0
  %t94 = load i32, ptr %l41, !tbaa !23
  %t95 = insertvalue { %"compiler/source:Span", i32, ptr } %t93, i32 %t94, 1
  %t97 = insertvalue { %"compiler/source:Span", i32, ptr } %t95, ptr %t89, 2
  %t98 = getelementptr { i64, [5 x i64] }, ptr %t90, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t97, ptr %t98
  %t99 = load { i64, [5 x i64] }, ptr %t90
  %t101 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t99, ptr %t101
  store ptr %t101, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eboundMention(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"compiler/generic:Origin"
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l16 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l43 = alloca i1
  %l46 = alloca ptr
  %l50 = alloca i32
  %l51 = alloca { i64, ptr }
  %l57 = alloca %"compiler/generic:Origin"
  %l69 = alloca ptr
  %l73 = alloca i32
  %l74 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l84 = alloca ptr
  %l85 = alloca i32
  %l88 = alloca i32
  %l89 = alloca i1
  %l90 = alloca i1
  %l92 = alloca ptr
  %l95 = alloca i32
  %l96 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckedInst(ptr %v0, ptr %t1)
  store i64 %t3, ptr %l16
  br label %bb1
bb1:
  %t4 = load i64, ptr %l16, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  store i64 -1, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  store i64 64, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t5 = load i64, ptr %l5, !tbaa !24
  %t6 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l6, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb7
bb4:
  %t15 = load i64, ptr %l5, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l6, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l6, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l23, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb6
bb6:
  %t31 = load i64, ptr %l23, !tbaa !24
  store i64 %t31, ptr %l20, !tbaa !24
  br label %bb7
bb7:
  %t32 = load i64, ptr %l20, !tbaa !24
  store i64 %t32, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i64, ptr %l8, !tbaa !24
  %t34 = load i64, ptr %l7, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb10:
  br label %bb11
bb11:
  %t41 = load i64, ptr %l4, !tbaa !24
  %t42 = load i64, ptr %l8, !tbaa !24
  %t43 = load i64, ptr %l6, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l9, !tbaa !24
  %t51 = load i64, ptr %l2, !tbaa !24
  %t53 = icmp slt i64 %t51, 0
  br i1 %t53, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb16
bb13:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = getelementptr %"compiler/generic:Program", ptr %t58, i32 0, i32 2
  store ptr %t60, ptr %l46, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/check:Checker", ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t65 = load i64, ptr %l2, !tbaa !24
  %t68 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t64, i64 %t65)
  store i32 %t68, ptr %l50
  br label %bb14
bb14:
  %t69 = load ptr, ptr %l46, !tbaa !29
  %t70 = load i32, ptr %l50, !tbaa !23
  %t71 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s2, ptr %t69, i32 %t70)
  store { i64, ptr } %t71, ptr %l51
  br label %bb15
bb15:
  %t72 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 0
  %t75 = icmp eq i64 %t73, 0
  store i1 %t75, ptr %l43, !tbaa !21
  br label %bb16
bb16:
  %t77 = load i1, ptr %l43, !tbaa !21
  br i1 %t77, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb18:
  br label %bb19
bb19:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/check:Checker", ptr %t78, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t82 = load i64, ptr %l2, !tbaa !24
  %t85 = call %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceOrigin(ptr %v0, ptr %t81, i64 %t82)
  store %"compiler/generic:Origin" %t85, ptr %l57
  br label %bb20
bb20:
  %t86 = load %"compiler/generic:Origin", ptr %l57
  store %"compiler/generic:Origin" %t86, ptr %l10
  %t87 = getelementptr %"compiler/generic:Origin", ptr %l10, i32 0, i32 0
  %t88 = load i64, ptr %t87, !tbaa !24
  %t90 = icmp slt i64 %t88, 0
  br i1 %t90, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb22:
  br label %bb23
bb23:
  %t92 = load i64, ptr %l2, !tbaa !24
  store i64 %t92, ptr %l3, !tbaa !24
  %t94 = getelementptr %"compiler/generic:Origin", ptr %l10, i32 0, i32 2
  %t95 = load i64, ptr %t94, !tbaa !24
  store i64 %t95, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb24:
  %t97 = load i64, ptr %l8, !tbaa !24
  %t99 = add i64 %t97, 1
  store i64 %t99, ptr %l8, !tbaa !24
  br label %bb8
bb25:
  %t101 = load i64, ptr %l3, !tbaa !24
  %t103 = icmp slt i64 %t101, 0
  br i1 %t103, label %bb26, label %bb27
bb26:
  store i64 -1, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/generic:Program", ptr %t109, i32 0, i32 2
  store ptr %t111, ptr %l69, !tbaa !29
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/check:Checker", ptr %t112, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t116 = load i64, ptr %l3, !tbaa !24
  %t119 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t115, i64 %t116)
  store i32 %t119, ptr %l73
  br label %bb29
bb29:
  %t120 = load ptr, ptr %l69, !tbaa !29
  %t121 = load i32, ptr %l73, !tbaa !23
  %t122 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t120, i32 %t121)
  store { i64, ptr } %t122, ptr %l74
  br label %bb30
bb30:
  %t123 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t123, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t124 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t124, 0
  store i64 %t126, ptr %l13, !tbaa !24
  br label %bb31
bb31:
  %t128 = load i64, ptr %l12, !tbaa !24
  %t129 = load i64, ptr %l13, !tbaa !24
  %t132 = icmp slt i64 %t128, %t129
  %t134 = xor i1 %t132, true
  br i1 %t134, label %bb32, label %bb33
bb32:
  br label %bb46
bb33:
  br label %bb34
bb34:
  %t136 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t136, ptr %l81, !tbaa !27
  %t137 = load i64, ptr %l12, !tbaa !24
  %t139 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !27
  %t141 = getelementptr i32, ptr %t140, i64 %t137
  %t142 = load i32, ptr %t141, !tbaa !33
  store i32 %t142, ptr %l14, !tbaa !23
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l84, !tbaa !29
  store i32 %a1, ptr %l85, !tbaa !23
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load i32, ptr %l14, !tbaa !23
  %t150 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t146, i32 %t147)
  store i32 %t150, ptr %l88
  br label %bb35
bb35:
  %t151 = load ptr, ptr %l84, !tbaa !29
  %t152 = load i32, ptr %l85, !tbaa !23
  %t153 = load i32, ptr %l88, !tbaa !23
  %t154 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ementions(ptr %v0, ptr %t151, i32 %t152, i32 %t153, i64 0)
  store i1 %t154, ptr %l89
  br label %bb36
bb36:
  %t155 = load i1, ptr %l89, !tbaa !21
  br i1 %t155, label %bb37, label %bb38
bb37:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/check:Checker", ptr %t156, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !29
  store ptr %t159, ptr %l92, !tbaa !29
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load i32, ptr %l14, !tbaa !23
  %t164 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t160, i32 %t161)
  store i32 %t164, ptr %l95
  br label %bb39
bb38:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb41
bb39:
  %t165 = load ptr, ptr %l92, !tbaa !29
  %t166 = load i32, ptr %l95, !tbaa !23
  %t167 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnique(ptr %v0, ptr %t165, i32 %t166)
  store i1 %t167, ptr %l96
  br label %bb40
bb40:
  %t168 = load i1, ptr %l96, !tbaa !21
  store i1 %t168, ptr %l90, !tbaa !21
  br label %bb41
bb41:
  %t169 = load i1, ptr %l90, !tbaa !21
  br i1 %t169, label %bb42, label %bb43
bb42:
  %t170 = load i64, ptr %l3, !tbaa !24
  store i64 %t170, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t172 = load i64, ptr %l12, !tbaa !24
  %t174 = add i64 %t172, 1
  store i64 %t174, ptr %l12, !tbaa !24
  br label %bb31
bb46:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallPattern(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3, ptr %a4, i32 %a5, i32 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca i32
  %lp11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i1
  %l29 = alloca i32
  %l32 = alloca i1
  %l33 = alloca i1
  %l36 = alloca i1
  %l41 = alloca i32
  %l46 = alloca i32
  %l48 = alloca ptr
  %l49 = alloca %"compiler/source:Span"
  %l52 = alloca { i64, ptr }
  %l54 = alloca %"compiler/source:Span"
  %l58 = alloca %"compiler/msgs:Msg"
  %l59 = alloca i64
  %l63 = alloca ptr
  %l64 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l72 = alloca { i64, ptr }
  %l75 = alloca ptr
  %l76 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca i1
  %l89 = alloca ptr
  %l91 = alloca %"compiler/source:Span"
  %l95 = alloca ptr
  %l98 = alloca ptr
  %l99 = alloca %"compiler/source:Span"
  %l100 = alloca ptr
  %l101 = alloca %"compiler/source:Span"
  %l102 = alloca ptr
  %l104 = alloca { i64, ptr }
  %l108 = alloca ptr
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca ptr
  %t187 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t2 = load ptr, ptr %l17, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l17, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 14
  store i1 %t8, ptr %l18, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l18, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l7
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t18, i32 0, i32 1
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l8, !tbaa !29
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t24, i32 0, i32 2
  %t26 = load i32, ptr %t25
  store i32 %t26, ptr %l9, !tbaa !23
  br label %bb5
bb4:
  br label %bb24
bb5:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l8, !tbaa !29
  %t32 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t28, ptr %t29)
  store i32 %t32, ptr %l29
  br label %bb6
bb6:
  %t33 = load i32, ptr %l29, !tbaa !23
  store i32 %t33, ptr %l10, !tbaa !23
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i32, ptr %l6, !tbaa !23
  %t38 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t34, i32 %t35)
  store i1 %t38, ptr %l32
  br label %bb7
bb7:
  %t39 = load i1, ptr %l32, !tbaa !21
  br i1 %t39, label %bb8, label %bb9
bb8:
  %t40 = load i32, ptr %l10, !tbaa !23
  %t42 = icmp sge i32 %t40, 0
  store i1 %t42, ptr %l33, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb10
bb10:
  %t44 = load i1, ptr %l33, !tbaa !21
  br i1 %t44, label %bb11, label %bb12
bb11:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = getelementptr %"compiler/generic:Program", ptr %t48, i32 0, i32 2
  %t51 = load i32, ptr %l10, !tbaa !23
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t50, i32 %t51)
  store i32 %t54, ptr %l41
  br label %bb13
bb12:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb15
bb13:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = getelementptr %"compiler/generic:Program", ptr %t58, i32 0, i32 2
  %t61 = load i32, ptr %l6, !tbaa !23
  %t64 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t60, i32 %t61)
  store i32 %t64, ptr %l46
  br label %bb14
bb14:
  %t65 = load i32, ptr %l41, !tbaa !23
  %t66 = load i32, ptr %l46, !tbaa !23
  %t67 = icmp eq i32 %t65, %t66
  store i1 %t67, ptr %l36, !tbaa !21
  br label %bb15
bb15:
  %t69 = load i1, ptr %l36, !tbaa !21
  br i1 %t69, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s2
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l48, !tbaa !29
  %t71 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t71, ptr %l49
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i32, ptr %l9, !tbaa !23
  %t76 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s2, ptr %t72, i32 %t73)
  store { i64, ptr } %t76, ptr %l52
  br label %bb18
bb17:
  br label %bb23
bb18:
  %t77 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t77, 0
  %t79 = load %"compiler/source:Span", ptr %l49
  %t81 = call %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %t79, i64 %t78)
  store %"compiler/source:Span" %t81, ptr %l54
  br label %bb19
bb19:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i32, ptr %l6, !tbaa !23
  %t84 = load i32, ptr %l9, !tbaa !23
  %t88 = call %"compiler/msgs:Msg" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoCase(ptr %v0, ptr %s2, ptr %t82, i32 %t83, i32 %t84)
  store %"compiler/msgs:Msg" %t88, ptr %l58
  br label %bb20
bb20:
  %t89 = load ptr, ptr %l48, !tbaa !29
  %t90 = load %"compiler/source:Span", ptr %l54
  %t91 = load %"compiler/msgs:Msg", ptr %l58
  %t92 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t89, %"compiler/source:Span" %t90, %"compiler/msgs:Msg" %t91)
  store i64 %t92, ptr %l59
  br label %bb21
bb21:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load %"compiler/source:Span", ptr %l1
  %t95 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t99 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v4, ptr %t93, %"compiler/source:Span" %t94, i32 %t95, i64 0)
  store ptr %t99, ptr %l63
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s2)
  %t100 = load ptr, ptr %l63, !tbaa !29
  store ptr %t100, ptr %rv
  br label %ret
bb23:
  br label %bb29
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_1ea07ba70e71bd73_64b4b6dffcea6d07)
  unreachable
bb29:
  %t101 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t101, ptr %l64
  br label %bb30
bb30:
  %t102 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 32, i64 8)
  store ptr %t102, ptr %lp11
  %t103 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l64
  %t104 = load ptr, ptr %lp11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t103, ptr %t104
  store { i64, ptr } %a3, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t107 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t107, 0
  store i64 %t109, ptr %l14, !tbaa !24
  br label %bb31
bb31:
  %t111 = load i64, ptr %l13, !tbaa !24
  %t112 = load i64, ptr %l14, !tbaa !24
  %t115 = icmp slt i64 %t111, %t112
  %t117 = xor i1 %t115, true
  br i1 %t117, label %bb32, label %bb33
bb32:
  br label %bb55
bb33:
  br label %bb34
bb34:
  %t119 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t119, ptr %l72, !tbaa !27
  %t120 = load i64, ptr %l13, !tbaa !24
  %t122 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr ptr, ptr %t123, i64 %t120
  %t125 = load ptr, ptr %t124, !tbaa !39
  store ptr %t125, ptr %l15, !tbaa !29
  %t127 = load ptr, ptr %l15, !tbaa !29
  store ptr %t127, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t128 = load ptr, ptr %l75, !tbaa !29
  %t129 = icmp ne ptr %t128, null
  br i1 %t129, label %bb35, label %bb36
bb35:
  %t131 = load ptr, ptr %l75, !tbaa !29
  %t132 = load i64, ptr %t131, !range !{i64 0, i64 8}
  %t134 = icmp eq i64 %t132, 4
  store i1 %t134, ptr %l76, !tbaa !21
  br label %bb36
bb36:
  %t135 = load i1, ptr %l76, !tbaa !21
  br i1 %t135, label %bb37, label %bb38
bb37:
  %t136 = load ptr, ptr %l15, !tbaa !29
  %t138 = getelementptr { i64, [4 x i64] }, ptr %t136, i32 0, i32 1
  %t139 = getelementptr { %"compiler/source:Span", ptr }, ptr %t138, i32 0, i32 1
  %t140 = load ptr, ptr %t139
  store ptr %t140, ptr %l16, !tbaa !29
  br label %bb43
bb38:
  %t142 = load ptr, ptr %l15, !tbaa !29
  store ptr %t142, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t143 = load ptr, ptr %l81, !tbaa !29
  %t144 = icmp ne ptr %t143, null
  br i1 %t144, label %bb39, label %bb40
bb39:
  %t146 = load ptr, ptr %l81, !tbaa !29
  %t147 = load i64, ptr %t146, !range !{i64 0, i64 8}
  %t149 = icmp eq i64 %t147, 1
  store i1 %t149, ptr %l82, !tbaa !21
  br label %bb40
bb40:
  %t150 = load i1, ptr %l82, !tbaa !21
  br i1 %t150, label %bb41, label %bb42
bb41:
  %t151 = load ptr, ptr %l15, !tbaa !29
  %t153 = getelementptr { i64, [4 x i64] }, ptr %t151, i32 0, i32 1
  %t154 = getelementptr { %"compiler/source:Span", ptr }, ptr %t153, i32 0, i32 1
  %t155 = load ptr, ptr %t154
  store ptr %t155, ptr %l16, !tbaa !29
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t157 = load ptr, ptr %lp11
  %t158 = load ptr, ptr %l16, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v4, ptr %v2, ptr %t157, ptr %t158)
  br label %bb44
bb44:
  br label %bb53
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb52
bb48:
  store %olang.scope zeroinitializer, ptr %s7
  %t161 = load ptr, ptr %l0, !tbaa !29
  store ptr %t161, ptr %l89, !tbaa !29
  %t162 = load ptr, ptr %l15, !tbaa !29
  %t164 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v2, ptr %t162)
  store %"compiler/source:Span" %t164, ptr %l91
  br label %bb49
bb49:
  %t165 = load ptr, ptr %l89, !tbaa !29
  %t166 = load %"compiler/source:Span", ptr %l91
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s7, ptr %t165, %"compiler/source:Span" %t166, { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d1, i32 0, i32 1) })
  br label %bb50
bb50:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load %"compiler/source:Span", ptr %l1
  %t169 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t173 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v4, ptr %t167, %"compiler/source:Span" %t168, i32 %t169, i64 0)
  store ptr %t173, ptr %l95
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s7)
  %t174 = load ptr, ptr %l95, !tbaa !29
  store ptr %t174, ptr %rv
  br label %ret
bb52:
  call void @__olang_check_failed(ptr @olang_loc_be381b70f49fc8f2_3328b3c24d360da6)
  unreachable
bb53:
  br label %bb54
bb54:
  %t175 = load i64, ptr %l13, !tbaa !24
  %t177 = add i64 %t175, 1
  store i64 %t177, ptr %l13, !tbaa !24
  br label %bb31
bb55:
  %t179 = load ptr, ptr %l0, !tbaa !29
  store ptr %t179, ptr %l98, !tbaa !29
  %t180 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t180, ptr %l99
  store ptr %a4, ptr %l100, !tbaa !29
  %t182 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t182, ptr %l101
  %t183 = load ptr, ptr %l2, !tbaa !29
  store ptr %t183, ptr %l102, !tbaa !29
  %t184 = load ptr, ptr %lp11
  %t186 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eToArray_3ccompiler_2fast_3aExpr_26_3e(ptr %v4, ptr %v0, ptr %t184)
  store { i64, ptr } %t186, ptr %l104
  br label %bb56
bb56:
  store { i64, [4 x i64] } zeroinitializer, ptr %t187
  %t188 = getelementptr { i64, [4 x i64] }, ptr %t187, i32 0, i32 0
  store i64 12, ptr %t188
  %t189 = load %"compiler/source:Span", ptr %l101
  %t190 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t189, 0
  %t191 = load ptr, ptr %l102, !tbaa !29
  %t192 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t190, ptr %t191, 1
  %t193 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t194 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t192, { i64, ptr } %t193, 2
  %t195 = getelementptr { i64, [4 x i64] }, ptr %t187, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t194, ptr %t195
  %t196 = load { i64, [4 x i64] }, ptr %t187
  %t198 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t196, ptr %t198
  %t200 = load ptr, ptr %l98, !tbaa !29
  %t201 = load %"compiler/source:Span", ptr %l99
  %t202 = load ptr, ptr %l100, !tbaa !29
  %t205 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTest(ptr %v0, ptr %v3, ptr %v0, ptr %v4, ptr %t200, %"compiler/source:Span" %t201, ptr %t202, ptr %t198, i32 %a5)
  store ptr %t205, ptr %l108
  br label %bb57
bb57:
  %t206 = load ptr, ptr %l108, !tbaa !29
  store ptr %t206, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTest(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/generic:Desc"
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca ptr
  %lp17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %lp24 = alloca ptr
  %l27 = alloca i32
  %l29 = alloca %"compiler/source:Span"
  %l32 = alloca %"compiler/generic:Desc"
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca i1
  %l51 = alloca { i64, ptr }
  %l52 = alloca i1
  %l56 = alloca ptr
  %l57 = alloca ptr
  %l58 = alloca i1
  %l64 = alloca i64
  %l71 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca i1
  %l83 = alloca i64
  %l90 = alloca ptr
  %l93 = alloca ptr
  %l96 = alloca ptr
  %l101 = alloca i32
  %l102 = alloca i32
  %l103 = alloca { i64, ptr }
  %l109 = alloca ptr
  %l110 = alloca %"compiler/source:Span"
  %l112 = alloca i64
  %l116 = alloca { i64, ptr }
  %l119 = alloca %"compiler/msgs:Msg"
  %l120 = alloca i64
  %l124 = alloca ptr
  %l128 = alloca i1
  %l129 = alloca %"compiler/source:Span"
  %l130 = alloca i32
  %l134 = alloca ptr
  %l139 = alloca ptr
  %l144 = alloca i32
  %l145 = alloca { i64, ptr }
  %l146 = alloca { i64, ptr }
  %l149 = alloca %"compiler/source:Span"
  %l150 = alloca i32
  %l154 = alloca %"compiler/typed:Payload"
  %l162 = alloca i64
  %l165 = alloca i64
  %l183 = alloca { i64, ptr }
  %l186 = alloca %"compiler/source:Span"
  %l187 = alloca { i64, ptr }
  %l193 = alloca ptr
  %l194 = alloca %"compiler/source:Span"
  %l195 = alloca ptr
  %l197 = alloca { i64, ptr }
  %l201 = alloca { i64, ptr }
  %l204 = alloca ptr
  %l205 = alloca ptr
  %l214 = alloca ptr
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca ptr
  %t232 = alloca { i64, [4 x i64] }, align 8
  %t282 = alloca { i64, [4 x i64] }, align 8
  %t363 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l3, !tbaa !23
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l27
  br label %bb1
bb1:
  %t6 = load i32, ptr %l27, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t7)
  store %"compiler/source:Span" %t9, ptr %l29
  br label %bb2
bb2:
  %t10 = load %"compiler/source:Span", ptr %l29
  store %"compiler/source:Span" %t10, ptr %l5
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t15 = call %"compiler/generic:Desc" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseDesc(ptr %v0, ptr %v1, ptr %t11, ptr %t12)
  store %"compiler/generic:Desc" %t15, ptr %l32
  br label %bb3
bb3:
  %t16 = load %"compiler/generic:Desc", ptr %l32
  store %"compiler/generic:Desc" %t16, ptr %l6
  %t17 = getelementptr %"compiler/generic:Desc", ptr %l6, i32 0, i32 0
  %t18 = load i64, ptr %t17, !tbaa !24
  %t19 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescCase, !tbaa !24
  %t22 = icmp eq i64 %t18, %t19
  br i1 %t22, label %bb4, label %bb5
bb4:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load %"compiler/source:Span", ptr %l5
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Desc", ptr %l6, i32 0, i32 2
  %t28 = load i64, ptr %t27, !tbaa !24
  %t33 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCase(ptr %v0, ptr %v2, ptr %v3, ptr %t24, %"compiler/source:Span" %t25, ptr %t26, i64 %t28)
  store ptr %t33, ptr %l40
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t34 = load ptr, ptr %l40, !tbaa !29
  store ptr %t34, ptr %rv
  br label %ret
bb7:
  %t35 = load ptr, ptr %l1, !tbaa !29
  store ptr %t35, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t36 = load ptr, ptr %l41, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb8, label %bb9
bb8:
  %t39 = load ptr, ptr %l41, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 30}
  %t42 = icmp eq i64 %t40, 0
  store i1 %t42, ptr %l42, !tbaa !21
  br label %bb9
bb9:
  %t43 = load i1, ptr %l42, !tbaa !21
  br i1 %t43, label %bb10, label %bb11
bb10:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i32 }, ptr %t46, i32 0, i32 0
  %t48 = load %"compiler/source:Span", ptr %t47
  store %"compiler/source:Span" %t48, ptr %l7
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr { i64, [4 x i64] }, ptr %t50, i32 0, i32 1
  %t53 = getelementptr { %"compiler/source:Span", i32 }, ptr %t52, i32 0, i32 1
  %t54 = load i32, ptr %t53
  store i32 %t54, ptr %l8, !tbaa !23
  br label %bb12
bb11:
  br label %bb19
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i32, ptr %l8, !tbaa !23
  %t60 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t56, i32 %t57)
  store { i64, ptr } %t60, ptr %l51
  br label %bb13
bb13:
  %t61 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t62 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t61, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i1 %t62, ptr %l52
  br label %bb14
bb14:
  %t63 = load i1, ptr %l52, !tbaa !21
  br i1 %t63, label %bb15, label %bb16
bb15:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load %"compiler/source:Span", ptr %l7
  %t66 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t70 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t64, %"compiler/source:Span" %t65, i32 %t66, i64 1)
  store ptr %t70, ptr %l56
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  %t71 = load ptr, ptr %l56, !tbaa !29
  store ptr %t71, ptr %rv
  br label %ret
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb81
bb19:
  %t72 = load ptr, ptr %l1, !tbaa !29
  store ptr %t72, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t73 = load ptr, ptr %l57, !tbaa !29
  %t74 = icmp ne ptr %t73, null
  br i1 %t74, label %bb20, label %bb21
bb20:
  %t76 = load ptr, ptr %l57, !tbaa !29
  %t77 = load i64, ptr %t76, !range !{i64 0, i64 30}
  %t79 = icmp eq i64 %t77, 14
  store i1 %t79, ptr %l58, !tbaa !21
  br label %bb21
bb21:
  %t80 = load i1, ptr %l58, !tbaa !21
  br i1 %t80, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb30
bb24:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t83 = load i32, ptr %l4, !tbaa !23
  %t87 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %t81, ptr %t82, i32 %t83)
  store i64 %t87, ptr %l64
  br label %bb25
bb25:
  %t88 = load i64, ptr %l64, !tbaa !24
  store i64 %t88, ptr %l9, !tbaa !24
  %t89 = load i64, ptr %l9, !tbaa !24
  %t91 = icmp sge i64 %t89, 0
  br i1 %t91, label %bb26, label %bb27
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load %"compiler/source:Span", ptr %l5
  %t95 = load ptr, ptr %l2, !tbaa !29
  %t96 = load i64, ptr %l9, !tbaa !24
  %t101 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCase(ptr %v0, ptr %v2, ptr %v3, ptr %t93, %"compiler/source:Span" %t94, ptr %t95, i64 %t96)
  store ptr %t101, ptr %l71
  br label %bb28
bb27:
  br label %bb29
bb28:
  %t102 = load ptr, ptr %l71, !tbaa !29
  store ptr %t102, ptr %rv
  br label %ret
bb29:
  br label %bb81
bb30:
  %t103 = load ptr, ptr %l1, !tbaa !29
  store ptr %t103, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t104 = load ptr, ptr %l72, !tbaa !29
  %t105 = icmp ne ptr %t104, null
  br i1 %t105, label %bb31, label %bb32
bb31:
  %t107 = load ptr, ptr %l72, !tbaa !29
  %t108 = load i64, ptr %t107, !range !{i64 0, i64 30}
  %t110 = icmp eq i64 %t108, 12
  store i1 %t110, ptr %l73, !tbaa !21
  br label %bb32
bb32:
  %t111 = load i1, ptr %l73, !tbaa !21
  br i1 %t111, label %bb33, label %bb34
bb33:
  %t112 = load ptr, ptr %l1, !tbaa !29
  %t114 = getelementptr { i64, [4 x i64] }, ptr %t112, i32 0, i32 1
  %t115 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t114, i32 0, i32 1
  %t116 = load ptr, ptr %t115
  store ptr %t116, ptr %l10, !tbaa !29
  %t118 = load ptr, ptr %l1, !tbaa !29
  %t120 = getelementptr { i64, [4 x i64] }, ptr %t118, i32 0, i32 1
  %t121 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t120, i32 0, i32 2
  %t122 = load { i64, ptr }, ptr %t121
  store { i64, ptr } %t122, ptr %l11, !tbaa !27
  br label %bb35
bb34:
  br label %bb76
bb35:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load ptr, ptr %l10, !tbaa !29
  %t126 = load i32, ptr %l4, !tbaa !23
  %t130 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %t124, ptr %t125, i32 %t126)
  store i64 %t130, ptr %l83
  br label %bb36
bb36:
  %t131 = load i64, ptr %l83, !tbaa !24
  store i64 %t131, ptr %l12, !tbaa !24
  %t132 = load i64, ptr %l12, !tbaa !24
  %t134 = icmp sge i64 %t132, 0
  br i1 %t134, label %bb37, label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s7
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load %"compiler/source:Span", ptr %l5
  %t138 = load ptr, ptr %l2, !tbaa !29
  %t139 = load i64, ptr %l12, !tbaa !24
  %t144 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCase(ptr %v0, ptr %v2, ptr %v3, ptr %t136, %"compiler/source:Span" %t137, ptr %t138, i64 %t139)
  store ptr %t144, ptr %l90
  br label %bb39
bb38:
  br label %bb75
bb39:
  %t145 = load ptr, ptr %l90, !tbaa !29
  store ptr %t145, ptr %l13, !tbaa !29
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/check:Checker", ptr %t146, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t151 = getelementptr %"compiler/generic:Program", ptr %t149, i32 0, i32 2
  store ptr %t151, ptr %l93, !tbaa !29
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/check:Checker", ptr %t152, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t157 = getelementptr %"compiler/generic:Program", ptr %t155, i32 0, i32 2
  store ptr %t157, ptr %l96, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/check:Checker", ptr %t158, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t162 = load i32, ptr %l4, !tbaa !23
  %t163 = load i64, ptr %l12, !tbaa !24
  %t167 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %t161, i32 %t162, i64 %t163)
  store i32 %t167, ptr %l101
  br label %bb40
bb40:
  %t168 = load ptr, ptr %l96, !tbaa !29
  %t169 = load i32, ptr %l101, !tbaa !23
  %t170 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t168, i32 %t169)
  store i32 %t170, ptr %l102
  br label %bb41
bb41:
  %t171 = load ptr, ptr %l93, !tbaa !29
  %t172 = load i32, ptr %l102, !tbaa !23
  %t173 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t171, i32 %t172)
  store { i64, ptr } %t173, ptr %l103
  br label %bb42
bb42:
  %t174 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t174, ptr %l14, !tbaa !27
  %t175 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t175, 0
  %t178 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t183 = icmp ne i64 %t177, %t180
  br i1 %t183, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s8
  %t185 = load ptr, ptr %l0, !tbaa !29
  store ptr %t185, ptr %l109, !tbaa !29
  %t186 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t186, ptr %l110
  %t187 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t187, 0
  store i64 %t189, ptr %l112, !tbaa !24
  %t190 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t190, 0
  %t194 = icmp eq i64 %t192, 1
  br i1 %t194, label %bb45, label %bb46
bb44:
  br label %bb51
bb45:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %l116, !tbaa !27
  br label %bb47
bb46:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l116, !tbaa !27
  br label %bb47
bb47:
  %t196 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t196, 0
  %t199 = load i64, ptr %l112, !tbaa !24
  %t200 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t202 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %s8, ptr %s8, i64 %t199, { i64, ptr } %t200, i64 %t198)
  store %"compiler/msgs:Msg" %t202, ptr %l119
  br label %bb48
bb48:
  %t203 = load ptr, ptr %l109, !tbaa !29
  %t204 = load %"compiler/source:Span", ptr %l110
  %t205 = load %"compiler/msgs:Msg", ptr %l119
  %t206 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t203, %"compiler/source:Span" %t204, %"compiler/msgs:Msg" %t205)
  store i64 %t206, ptr %l120
  br label %bb49
bb49:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load %"compiler/source:Span", ptr %l5
  %t209 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t213 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t207, %"compiler/source:Span" %t208, i32 %t209, i64 0)
  store ptr %t213, ptr %l124
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s7)
  %t214 = load ptr, ptr %l124, !tbaa !29
  store ptr %t214, ptr %rv
  br label %ret
bb51:
  %t215 = load ptr, ptr %l2, !tbaa !29
  store ptr %t215, ptr %l15, !tbaa !29
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load i32, ptr %l3, !tbaa !23
  %t221 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t217, i32 %t218)
  store i1 %t221, ptr %l128
  br label %bb52
bb52:
  %t222 = load i1, ptr %l128, !tbaa !21
  br i1 %t222, label %bb53, label %bb54
bb53:
  %t223 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t223, ptr %l129
  %t224 = load i32, ptr %l4, !tbaa !23
  store i32 %t224, ptr %l130, !tbaa !23
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load %"compiler/source:Span", ptr %l5
  %t227 = load ptr, ptr %l2, !tbaa !29
  %t231 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v2, ptr %v2, ptr %t225, %"compiler/source:Span" %t226, ptr %t227)
  store ptr %t231, ptr %l134
  br label %bb55
bb54:
  br label %bb56
bb55:
  store { i64, [4 x i64] } zeroinitializer, ptr %t232
  %t233 = getelementptr { i64, [4 x i64] }, ptr %t232, i32 0, i32 0
  store i64 2, ptr %t233
  %t234 = load %"compiler/source:Span", ptr %l129
  %t235 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t234, 0
  %t236 = load i32, ptr %l130, !tbaa !23
  %t237 = insertvalue { %"compiler/source:Span", i32, ptr } %t235, i32 %t236, 1
  %t238 = load ptr, ptr %l134, !tbaa !29
  %t239 = insertvalue { %"compiler/source:Span", i32, ptr } %t237, ptr %t238, 2
  %t240 = getelementptr { i64, [4 x i64] }, ptr %t232, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t239, ptr %t240
  %t241 = load { i64, [4 x i64] }, ptr %t232
  %t243 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t241, ptr %t243
  store ptr %t243, ptr %l15, !tbaa !29
  br label %bb56
bb56:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t247 = getelementptr %"compiler/check:Checker", ptr %t245, i32 0, i32 1
  %t248 = load ptr, ptr %t247, !tbaa !29
  %t250 = getelementptr %"compiler/generic:Program", ptr %t248, i32 0, i32 2
  store ptr %t250, ptr %l139, !tbaa !29
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t253 = getelementptr %"compiler/check:Checker", ptr %t251, i32 0, i32 1
  %t254 = load ptr, ptr %t253, !tbaa !29
  %t256 = getelementptr %"compiler/generic:Program", ptr %t254, i32 0, i32 2
  %t257 = load i32, ptr %l4, !tbaa !23
  %t260 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t256, i32 %t257)
  store i32 %t260, ptr %l144
  br label %bb57
bb57:
  %t261 = load ptr, ptr %l139, !tbaa !29
  %t262 = load i32, ptr %l144, !tbaa !23
  %t263 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s7, ptr %t261, i32 %t262)
  store { i64, ptr } %t263, ptr %l145
  br label %bb58
bb58:
  %t264 = load { i64, ptr }, ptr %l145, !tbaa !27
  store { i64, ptr } %t264, ptr %l146, !tbaa !27
  %t265 = load i64, ptr %l12, !tbaa !24
  %t267 = getelementptr { i64, ptr }, ptr %l146, i32 0, i32 1
  %t268 = load ptr, ptr %t267, !tbaa !27
  %t269 = getelementptr i32, ptr %t268, i64 %t265
  %t270 = load i32, ptr %t269, !tbaa !33
  %t272 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t272, ptr %l149
  store i32 %t270, ptr %l150, !tbaa !23
  %t274 = load ptr, ptr %l15, !tbaa !29
  %t275 = load i64, ptr %l12, !tbaa !24
  %t279 = call %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v2, ptr %v3, ptr %t274, i64 %t275, i32 0)
  store %"compiler/typed:Payload" %t279, ptr %l154
  br label %bb59
bb59:
  %t280 = load %"compiler/typed:Payload", ptr %l154
  %t281 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 24, i64 8)
  store %"compiler/typed:Payload" %t280, ptr %t281
  store { i64, [4 x i64] } zeroinitializer, ptr %t282
  %t283 = getelementptr { i64, [4 x i64] }, ptr %t282, i32 0, i32 0
  store i64 5, ptr %t283
  %t284 = load %"compiler/source:Span", ptr %l149
  %t285 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t284, 0
  %t286 = load i32, ptr %l150, !tbaa !23
  %t287 = insertvalue { %"compiler/source:Span", i32, ptr } %t285, i32 %t286, 1
  %t289 = insertvalue { %"compiler/source:Span", i32, ptr } %t287, ptr %t281, 2
  %t290 = getelementptr { i64, [4 x i64] }, ptr %t282, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t289, ptr %t290
  %t291 = load { i64, [4 x i64] }, ptr %t282
  %t292 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store ptr %t292, ptr %lp17
  %t294 = load ptr, ptr %lp17
  store { i64, [4 x i64] } %t291, ptr %t294
  store i64 0, ptr %l18, !tbaa !24
  %t295 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t297 = extractvalue { i64, ptr } %t295, 0
  store i64 %t297, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t299 = load i64, ptr %l19, !tbaa !24
  %t300 = load i64, ptr %l18, !tbaa !24
  %t303 = icmp sgt i64 %t299, %t300
  br i1 %t303, label %bb60, label %bb61
bb60:
  %t305 = load i64, ptr %l20, !tbaa !24
  %t307 = icmp sgt i64 %t305, 0
  br i1 %t307, label %bb62, label %bb63
bb61:
  store i64 0, ptr %l162, !tbaa !24
  br label %bb65
bb62:
  %t309 = load i64, ptr %l19, !tbaa !24
  %t310 = load i64, ptr %l18, !tbaa !24
  %t313 = sub i64 %t309, %t310
  %t314 = load i64, ptr %l20, !tbaa !24
  %t317 = add i64 %t313, %t314
  %t319 = sub i64 %t317, 1
  %t320 = load i64, ptr %l20, !tbaa !24
  %t323 = sdiv i64 %t319, %t320
  store i64 %t323, ptr %l165, !tbaa !24
  br label %bb64
bb63:
  store i64 0, ptr %l165, !tbaa !24
  br label %bb64
bb64:
  %t325 = load i64, ptr %l165, !tbaa !24
  store i64 %t325, ptr %l162, !tbaa !24
  br label %bb65
bb65:
  %t326 = load i64, ptr %l162, !tbaa !24
  store i64 %t326, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb66
bb66:
  %t327 = load i64, ptr %l22, !tbaa !24
  %t328 = load i64, ptr %l21, !tbaa !24
  %t331 = icmp slt i64 %t327, %t328
  %t333 = xor i1 %t331, true
  br i1 %t333, label %bb67, label %bb68
bb67:
  br label %bb74
bb68:
  br label %bb69
bb69:
  %t335 = load i64, ptr %l18, !tbaa !24
  %t336 = load i64, ptr %l22, !tbaa !24
  %t337 = load i64, ptr %l20, !tbaa !24
  %t340 = mul i64 %t336, %t337
  %t343 = add i64 %t335, %t340
  store i64 %t343, ptr %l23, !tbaa !24
  %t345 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t345, ptr %l183, !tbaa !27
  %t346 = load i64, ptr %l23, !tbaa !24
  %t348 = getelementptr { i64, ptr }, ptr %l183, i32 0, i32 1
  %t349 = load ptr, ptr %t348, !tbaa !27
  %t350 = getelementptr ptr, ptr %t349, i64 %t346
  %t351 = load ptr, ptr %t350, !tbaa !39
  %t353 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t351)
  store %"compiler/source:Span" %t353, ptr %l186
  br label %bb70
bb70:
  %t354 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t354, ptr %l187, !tbaa !27
  %t355 = load i64, ptr %l23, !tbaa !24
  %t357 = getelementptr { i64, ptr }, ptr %l187, i32 0, i32 1
  %t358 = load ptr, ptr %t357, !tbaa !27
  %t359 = getelementptr i32, ptr %t358, i64 %t355
  %t360 = load i32, ptr %t359, !tbaa !33
  %t361 = load ptr, ptr %lp17
  %t362 = load i64, ptr %l23, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t363
  %t364 = getelementptr { i64, [4 x i64] }, ptr %t363, i32 0, i32 0
  store i64 3, ptr %t364
  %t365 = load %"compiler/source:Span", ptr %l186
  %t366 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t365, 0
  %t368 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t366, i32 %t360, 1
  %t370 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t368, ptr %t361, 2
  %t372 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t370, i64 %t362, 3
  %t373 = getelementptr { i64, [4 x i64] }, ptr %t363, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t372, ptr %t373
  %t374 = load { i64, [4 x i64] }, ptr %t363
  %t375 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store ptr %t375, ptr %lp24
  %t377 = load ptr, ptr %lp24
  store { i64, [4 x i64] } %t374, ptr %t377
  %t378 = load ptr, ptr %l0, !tbaa !29
  store ptr %t378, ptr %l193, !tbaa !29
  %t379 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t379, ptr %l194
  %t380 = load ptr, ptr %l13, !tbaa !29
  store ptr %t380, ptr %l195, !tbaa !29
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t382 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t382, ptr %l197, !tbaa !27
  %t383 = load i64, ptr %l23, !tbaa !24
  %t385 = getelementptr { i64, ptr }, ptr %l197, i32 0, i32 1
  %t386 = load ptr, ptr %t385, !tbaa !27
  %t387 = getelementptr ptr, ptr %t386, i64 %t383
  %t388 = load ptr, ptr %t387, !tbaa !39
  %t389 = load ptr, ptr %lp24
  %t390 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t390, ptr %l201, !tbaa !27
  %t391 = load i64, ptr %l23, !tbaa !24
  %t393 = getelementptr { i64, ptr }, ptr %l201, i32 0, i32 1
  %t394 = load ptr, ptr %t393, !tbaa !27
  %t395 = getelementptr i32, ptr %t394, i64 %t391
  %t396 = load i32, ptr %t395, !tbaa !33
  %t401 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTest(ptr %v0, ptr %v1, ptr %v3, ptr %v0, ptr %t381, ptr %t388, ptr %t389, i32 %t396)
  store ptr %t401, ptr %l204
  br label %bb71
bb71:
  %t402 = load ptr, ptr %l193, !tbaa !29
  %t403 = load %"compiler/source:Span", ptr %l194
  %t404 = load ptr, ptr %l195, !tbaa !29
  %t405 = load ptr, ptr %l204, !tbaa !29
  %t406 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eand2(ptr %v0, ptr %v3, ptr %v0, ptr %v3, ptr %t402, %"compiler/source:Span" %t403, ptr %t404, ptr %t405)
  store ptr %t406, ptr %l205
  br label %bb72
bb72:
  %t407 = load ptr, ptr %l205, !tbaa !29
  store ptr %t407, ptr %l13, !tbaa !29
  br label %bb73
bb73:
  %t408 = load i64, ptr %l22, !tbaa !24
  %t410 = add i64 %t408, 1
  store i64 %t410, ptr %l22, !tbaa !24
  br label %bb66
bb74:
  %t412 = load ptr, ptr %l13, !tbaa !29
  call void @__olang_scope_close(ptr %s7)
  store ptr %t412, ptr %rv
  br label %ret
bb75:
  br label %bb81
bb76:
  br i1 true, label %bb77, label %bb78
bb77:
  br label %bb79
bb78:
  br label %bb80
bb79:
  br label %bb81
bb80:
  call void @__olang_check_failed(ptr @olang_loc_82b73da87554a50f_4f07d83e7e807a5b)
  unreachable
bb81:
  %t414 = load ptr, ptr %l0, !tbaa !29
  %t415 = load %"compiler/source:Span", ptr %l5
  %t416 = load ptr, ptr %l2, !tbaa !29
  %t417 = load ptr, ptr %l1, !tbaa !29
  %t418 = load i32, ptr %l3, !tbaa !23
  %t424 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTest(ptr %v0, ptr %v2, ptr %v1, ptr %v3, ptr %t414, %"compiler/source:Span" %t415, ptr %t416, ptr %t417, i32 %t418)
  store ptr %t424, ptr %l214
  br label %bb82
bb82:
  %t425 = load ptr, ptr %l214, !tbaa !29
  store ptr %t425, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorVarRules(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l35 = alloca i32
  %l37 = alloca i32
  %l41 = alloca { i64, ptr }
  %l45 = alloca %"compiler/source:Span"
  %l49 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca %"compiler/msgs:Msg"
  %l59 = alloca i64
  %l62 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l67 = alloca %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd"
  %l68 = alloca ptr
  %l70 = alloca ptr
  %l71 = alloca i32
  %l73 = alloca i1
  %l80 = alloca i64
  %l83 = alloca i64
  %l104 = alloca i1
  %l109 = alloca ptr
  %l111 = alloca { i64, ptr }
  %l113 = alloca %"compiler/source:Span"
  %l116 = alloca { i64, ptr }
  %l119 = alloca { i64, ptr }
  %l122 = alloca %"compiler/msgs:Msg"
  %l123 = alloca i64
  %l128 = alloca i1
  %l133 = alloca i1
  %l146 = alloca { i64, ptr }
  %l152 = alloca { i64, ptr }
  %l170 = alloca { i64, ptr }
  %l173 = alloca ptr
  %l175 = alloca %"compiler/source:Span"
  %l179 = alloca { i64, ptr }
  %l180 = alloca %"compiler/source:Span"
  %l183 = alloca ptr
  %l185 = alloca { i64, ptr }
  %l187 = alloca %"compiler/source:Span"
  %l190 = alloca { i64, ptr }
  %l193 = alloca { i64, ptr }
  %l194 = alloca { i64, ptr }
  %l198 = alloca { i64, ptr }
  %l202 = alloca { i64, ptr }
  %l206 = alloca { i64, ptr }
  %l207 = alloca %"compiler/msgs:Msg"
  %l208 = alloca i64
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %wh3 = alloca ptr
  %wc3 = alloca ptr
  %ws3 = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:StructBody", ptr %t1, i32 0, i32 5
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/ast:TypeDecl", ptr %t10, i32 0, i32 1
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = getelementptr %"compiler/ast:StructBody", ptr %t19, i32 0, i32 5
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  store { i64, ptr } %t22, ptr %l31, !tbaa !27
  %t23 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr ptr, ptr %t24, i64 0
  %t26 = load ptr, ptr %t25, !tbaa !39
  store ptr %t26, ptr %l3, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l33, !tbaa !29
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = getelementptr %"compiler/ast:TypeParam", ptr %t29, i32 0, i32 0
  %t32 = getelementptr %"compiler/source:Span", ptr %t31, i32 0, i32 0
  %t33 = load i32, ptr %t32, !tbaa !23
  store i32 %t33, ptr %l35, !tbaa !23
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t36 = getelementptr %"compiler/ast:TypeParam", ptr %t34, i32 0, i32 0
  %t37 = getelementptr %"compiler/source:Span", ptr %t36, i32 0, i32 0
  %t38 = load i32, ptr %t37, !tbaa !23
  store i32 %t38, ptr %l37, !tbaa !23
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = getelementptr %"compiler/ast:TypeParam", ptr %t40, i32 0, i32 1
  %t43 = load i32, ptr %t42, !tbaa !23
  %t46 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s2, ptr %t39, i32 %t43)
  store { i64, ptr } %t46, ptr %l41
  br label %bb6
bb5:
  br label %bb13
bb6:
  %t47 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t47, 0
  %t50 = trunc i64 %t48 to i32
  %t51 = load i32, ptr %l37, !tbaa !23
  %t53 = add i32 %t51, %t50
  %t54 = load i32, ptr %l35, !tbaa !23
  %t56 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s2, i32 %t54, i32 %t53)
  store %"compiler/source:Span" %t56, ptr %l45
  br label %bb7
bb7:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l3, !tbaa !29
  %t60 = getelementptr %"compiler/ast:TypeParam", ptr %t58, i32 0, i32 1
  %t61 = load i32, ptr %t60, !tbaa !23
  %t64 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t57, i32 %t61)
  store { i64, ptr } %t64, ptr %l49
  br label %bb8
bb8:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr %"compiler/ast:TypeDecl", ptr %t66, i32 0, i32 0
  %t69 = load i32, ptr %t68, !tbaa !23
  %t72 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t65, i32 %t69)
  store { i64, ptr } %t72, ptr %l53
  br label %bb9
bb9:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load ptr, ptr %l3, !tbaa !29
  %t76 = getelementptr %"compiler/ast:TypeParam", ptr %t74, i32 0, i32 1
  %t77 = load i32, ptr %t76, !tbaa !23
  %t80 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t73, i32 %t77)
  store { i64, ptr } %t80, ptr %l57
  br label %bb10
bb10:
  %t81 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t83 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t84 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCtorVarOfGeneric(ptr %v0, ptr %v0, ptr %v0, ptr %s2, { i64, ptr } %t81, { i64, ptr } %t82, { i64, ptr } %t83)
  store %"compiler/msgs:Msg" %t84, ptr %l58
  br label %bb11
bb11:
  %t85 = load ptr, ptr %l33, !tbaa !29
  %t86 = load %"compiler/source:Span", ptr %l45
  %t87 = load %"compiler/msgs:Msg", ptr %l58
  %t88 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t85, %"compiler/source:Span" %t86, %"compiler/msgs:Msg" %t87)
  store i64 %t88, ptr %l59
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb13:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load ptr, ptr %l2, !tbaa !29
  %t92 = getelementptr %"compiler/ast:StructBody", ptr %t90, i32 0, i32 5
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  store { i64, ptr } %t93, ptr %l62, !tbaa !27
  %t94 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr ptr, ptr %t95, i64 0
  %t97 = load ptr, ptr %t96, !tbaa !39
  %t99 = getelementptr %"compiler/ast:TypeParam", ptr %t97, i32 0, i32 1
  %t100 = load i32, ptr %t99, !tbaa !23
  %t103 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t89, i32 %t100)
  store { i64, ptr } %t103, ptr %l65
  br label %bb14
bb14:
  %t104 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t104, ptr %l4, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s3
  %t105 = load ptr, ptr %l2, !tbaa !29
  %t107 = call %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" @compiler_2fgeneric_2eFieldDecls.walk(ptr %v2, ptr %s3, ptr %t105)
  %t108 = extractvalue %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t107, 0, 1
  %t109 = extractvalue %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t107, 0, 0
  store ptr %t108, ptr %wh3
  store ptr %t109, ptr %wc3
  store %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t107, ptr %l67
  br label %bb15
bb15:
  %t110 = load %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd", ptr %l67
  store %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t110, ptr %l5
  br label %bb16
bb16:
  %t112 = call { i32, ptr } @std_2fprelude_2fiterator_2estd_2fprelude_2fiterator_3aViewGenerator_3ccompiler_2fast_3aV_Hf179e857cb72c72900f4614cd5df5a25(ptr %s3, ptr %l5)
  %t113 = extractvalue { i32, ptr } %t112, 1
  %t114 = extractvalue { i32, ptr } %t112, 0
  store i32 %t114, ptr %l71
  %t115 = icmp ne i32 %t114, 0
  br i1 %t115, label %bb18, label %ok.116, !prof !99
ok.116:
  store ptr %t113, ptr %l70
  br label %bb17
bb17:
  %t117 = load ptr, ptr %l70, !tbaa !29
  store ptr %t117, ptr %l68, !tbaa !29
  br label %bb20
bb18:
  %t118 = load i32, ptr %l71, !tbaa !23
  %t119 = ashr i32 %t118, 16
  %t121 = icmp eq i32 %t119, 1
  store i1 %t121, ptr %l73, !tbaa !21
  br label %bb19
bb19:
  call void @__olang_ert_req_clear()
  br label %bb82
bb20:
  %t122 = load ptr, ptr %l68, !tbaa !29
  store ptr %t122, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  %t123 = load ptr, ptr %l6, !tbaa !29
  %t125 = getelementptr %"compiler/ast:VarDecl", ptr %t123, i32 0, i32 0
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t126, 0
  store i64 %t128, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t130 = load i64, ptr %l8, !tbaa !24
  %t131 = load i64, ptr %l7, !tbaa !24
  %t134 = icmp sgt i64 %t130, %t131
  br i1 %t134, label %bb21, label %bb22
bb21:
  %t136 = load i64, ptr %l9, !tbaa !24
  %t138 = icmp sgt i64 %t136, 0
  br i1 %t138, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l80, !tbaa !24
  br label %bb26
bb23:
  %t140 = load i64, ptr %l8, !tbaa !24
  %t141 = load i64, ptr %l7, !tbaa !24
  %t144 = sub i64 %t140, %t141
  %t145 = load i64, ptr %l9, !tbaa !24
  %t148 = add i64 %t144, %t145
  %t150 = sub i64 %t148, 1
  %t151 = load i64, ptr %l9, !tbaa !24
  %t154 = sdiv i64 %t150, %t151
  store i64 %t154, ptr %l83, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l83, !tbaa !24
  br label %bb25
bb25:
  %t156 = load i64, ptr %l83, !tbaa !24
  store i64 %t156, ptr %l80, !tbaa !24
  br label %bb26
bb26:
  %t157 = load i64, ptr %l80, !tbaa !24
  store i64 %t157, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb27
bb27:
  %t158 = load i64, ptr %l11, !tbaa !24
  %t159 = load i64, ptr %l10, !tbaa !24
  %t162 = icmp slt i64 %t158, %t159
  %t164 = xor i1 %t162, true
  br i1 %t164, label %bb28, label %bb29
bb28:
  br label %bb80
bb29:
  br label %bb30
bb30:
  %t166 = load i64, ptr %l7, !tbaa !24
  %t167 = load i64, ptr %l11, !tbaa !24
  %t168 = load i64, ptr %l9, !tbaa !24
  %t171 = mul i64 %t167, %t168
  %t174 = add i64 %t166, %t171
  store i64 %t174, ptr %l12, !tbaa !24
  %t176 = load ptr, ptr %l6, !tbaa !29
  %t178 = getelementptr %"compiler/ast:VarDecl", ptr %t176, i32 0, i32 2
  %t179 = load ptr, ptr %t178, !tbaa !29
  %t181 = icmp eq ptr %t179, null
  br i1 %t181, label %bb31, label %bb32
bb31:
  %t183 = load ptr, ptr %l6, !tbaa !29
  %t185 = getelementptr %"compiler/ast:VarDecl", ptr %t183, i32 0, i32 3
  %t186 = load { i64, ptr }, ptr %t185, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t186, 0
  %t190 = icmp sgt i64 %t188, 0
  store i1 %t190, ptr %l104, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l104, !tbaa !21
  br label %bb33
bb33:
  %t192 = load i1, ptr %l104, !tbaa !21
  br i1 %t192, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s7
  %t193 = load ptr, ptr %l0, !tbaa !29
  store ptr %t193, ptr %l109, !tbaa !29
  %t194 = load ptr, ptr %l6, !tbaa !29
  %t196 = getelementptr %"compiler/ast:VarDecl", ptr %t194, i32 0, i32 1
  %t197 = load { i64, ptr }, ptr %t196, !tbaa !27
  store { i64, ptr } %t197, ptr %l111, !tbaa !27
  %t198 = load i64, ptr %l12, !tbaa !24
  %t200 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !27
  %t202 = getelementptr %"compiler/source:Span", ptr %t201, i64 %t198
  %t203 = load %"compiler/source:Span", ptr %t202
  store %"compiler/source:Span" %t203, ptr %l113
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load ptr, ptr %l6, !tbaa !29
  %t207 = getelementptr %"compiler/ast:VarDecl", ptr %t205, i32 0, i32 0
  %t208 = load { i64, ptr }, ptr %t207, !tbaa !27
  store { i64, ptr } %t208, ptr %l116, !tbaa !27
  %t209 = load i64, ptr %l12, !tbaa !24
  %t211 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !27
  %t213 = getelementptr i32, ptr %t212, i64 %t209
  %t214 = load i32, ptr %t213, !tbaa !33
  %t217 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s7, ptr %t204, i32 %t214)
  store { i64, ptr } %t217, ptr %l119
  br label %bb36
bb35:
  br label %bb39
bb36:
  %t218 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t219 = extractvalue { i64, ptr } %t218, 0
  %t220 = extractvalue { i64, ptr } %t218, 1
  %t221 = mul i64 %t219, 1
  %t222 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t221)
  call void @llvm.memcpy.p0.p0.i64(ptr %t222, ptr %t220, i64 %t221, i1 false)
  %t223 = insertvalue { i64, ptr } undef, i64 %t219, 0
  %t224 = insertvalue { i64, ptr } %t223, ptr %t222, 1
  %t225 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t228 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCtorGenericInferredField(ptr %s7, ptr %v0, ptr %s7, { i64, ptr } %t224, { i64, ptr } %t225)
  store %"compiler/msgs:Msg" %t228, ptr %l122
  br label %bb37
bb37:
  %t229 = load ptr, ptr %l109, !tbaa !29
  %t230 = load %"compiler/source:Span", ptr %l113
  %t231 = load %"compiler/msgs:Msg", ptr %l122
  %t232 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t229, %"compiler/source:Span" %t230, %"compiler/msgs:Msg" %t231)
  store i64 %t232, ptr %l123
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s7)
  store i32 0, ptr %ws3
  br label %wend3
wend3.c0:
  call void @__olang_scope_close(ptr %s3)
  br label %ret
bb39:
  %t233 = load ptr, ptr %l6, !tbaa !29
  %t235 = getelementptr %"compiler/ast:VarDecl", ptr %t233, i32 0, i32 2
  %t236 = load ptr, ptr %t235, !tbaa !29
  store ptr %t236, ptr %l13, !tbaa !29
  %t238 = load ptr, ptr %l13, !tbaa !29
  %t240 = icmp eq ptr %t238, null
  br i1 %t240, label %bb40, label %bb41
bb40:
  %t242 = load ptr, ptr %l6, !tbaa !29
  %t244 = getelementptr %"compiler/ast:VarDecl", ptr %t242, i32 0, i32 3
  %t245 = load { i64, ptr }, ptr %t244, !tbaa !27
  %t247 = extractvalue { i64, ptr } %t245, 0
  %t249 = icmp eq i64 %t247, 0
  store i1 %t249, ptr %l128, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l128, !tbaa !21
  br label %bb42
bb42:
  %t251 = load i1, ptr %l128, !tbaa !21
  br i1 %t251, label %bb43, label %bb44
bb43:
  %t252 = load ptr, ptr %l2, !tbaa !29
  %t254 = getelementptr %"compiler/ast:StructBody", ptr %t252, i32 0, i32 0
  %t255 = load { i64, ptr }, ptr %t254, !tbaa !27
  %t257 = extractvalue { i64, ptr } %t255, 0
  %t259 = icmp sgt i64 %t257, 0
  store i1 %t259, ptr %l133, !tbaa !21
  br label %bb45
bb44:
  store i1 false, ptr %l133, !tbaa !21
  br label %bb45
bb45:
  %t261 = load i1, ptr %l133, !tbaa !21
  br i1 %t261, label %bb46, label %bb47
bb46:
  %t262 = load ptr, ptr %l2, !tbaa !29
  %t264 = getelementptr %"compiler/ast:StructBody", ptr %t262, i32 0, i32 0
  %t265 = load { i64, ptr }, ptr %t264, !tbaa !27
  store { i64, ptr } %t265, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t267 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t269 = extractvalue { i64, ptr } %t267, 0
  store i64 %t269, ptr %l16, !tbaa !24
  br label %bb48
bb47:
  br label %bb57
bb48:
  %t271 = load i64, ptr %l15, !tbaa !24
  %t272 = load i64, ptr %l16, !tbaa !24
  %t275 = icmp slt i64 %t271, %t272
  %t277 = xor i1 %t275, true
  br i1 %t277, label %bb49, label %bb50
bb49:
  br label %bb56
bb50:
  br label %bb51
bb51:
  %t279 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t279, ptr %l146, !tbaa !27
  %t280 = load i64, ptr %l15, !tbaa !24
  %t282 = getelementptr { i64, ptr }, ptr %l146, i32 0, i32 1
  %t283 = load ptr, ptr %t282, !tbaa !27
  %t284 = getelementptr ptr, ptr %t283, i64 %t280
  %t285 = load ptr, ptr %t284, !tbaa !39
  store ptr %t285, ptr %l17, !tbaa !29
  %t287 = load ptr, ptr %l17, !tbaa !29
  %t289 = getelementptr %"compiler/ast:Param", ptr %t287, i32 0, i32 1
  %t290 = load i32, ptr %t289, !tbaa !23
  %t291 = load ptr, ptr %l6, !tbaa !29
  %t293 = getelementptr %"compiler/ast:VarDecl", ptr %t291, i32 0, i32 0
  %t294 = load { i64, ptr }, ptr %t293, !tbaa !27
  store { i64, ptr } %t294, ptr %l152, !tbaa !27
  %t295 = load i64, ptr %l12, !tbaa !24
  %t297 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t298 = load ptr, ptr %t297, !tbaa !27
  %t299 = getelementptr i32, ptr %t298, i64 %t295
  %t300 = load i32, ptr %t299, !tbaa !33
  %t303 = icmp eq i32 %t290, %t300
  br i1 %t303, label %bb52, label %bb53
bb52:
  %t305 = load ptr, ptr %l17, !tbaa !29
  %t307 = getelementptr %"compiler/ast:Param", ptr %t305, i32 0, i32 2
  %t308 = load ptr, ptr %t307, !tbaa !29
  store ptr %t308, ptr %l13, !tbaa !29
  br label %bb54
bb53:
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t310 = load i64, ptr %l15, !tbaa !24
  %t312 = add i64 %t310, 1
  store i64 %t312, ptr %l15, !tbaa !24
  br label %bb48
bb56:
  br label %bb57
bb57:
  %t314 = load ptr, ptr %l13, !tbaa !29
  %t316 = icmp eq ptr %t314, null
  br i1 %t316, label %bb58, label %bb59
bb58:
  br label %bb79
bb59:
  br label %bb60
bb60:
  %t318 = load ptr, ptr %l2, !tbaa !29
  %t320 = getelementptr %"compiler/ast:StructBody", ptr %t318, i32 0, i32 5
  %t321 = load { i64, ptr }, ptr %t320, !tbaa !27
  store { i64, ptr } %t321, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t323 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t325 = extractvalue { i64, ptr } %t323, 0
  store i64 %t325, ptr %l20, !tbaa !24
  br label %bb61
bb61:
  store %olang.scope zeroinitializer, ptr %s15
  %t327 = load i64, ptr %l19, !tbaa !24
  %t328 = load i64, ptr %l20, !tbaa !24
  %t331 = icmp slt i64 %t327, %t328
  %t333 = xor i1 %t331, true
  br i1 %t333, label %bb62, label %bb63
bb62:
  call void @__olang_scope_close(ptr %s15)
  br label %bb78
bb63:
  br label %bb64
bb64:
  %t335 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t335, ptr %l170, !tbaa !27
  %t336 = load i64, ptr %l19, !tbaa !24
  %t338 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t339 = load ptr, ptr %t338, !tbaa !27
  %t340 = getelementptr ptr, ptr %t339, i64 %t336
  %t341 = load ptr, ptr %t340, !tbaa !39
  store ptr %t341, ptr %l21, !tbaa !29
  %t343 = load ptr, ptr %l0, !tbaa !29
  store ptr %t343, ptr %l173, !tbaa !29
  %t344 = load ptr, ptr %l13, !tbaa !29
  %t346 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %t344)
  store %"compiler/source:Span" %t346, ptr %l175
  br label %bb65
bb65:
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t348 = load ptr, ptr %l21, !tbaa !29
  %t350 = getelementptr %"compiler/ast:TypeParam", ptr %t348, i32 0, i32 1
  %t351 = load i32, ptr %t350, !tbaa !23
  %t354 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t347, i32 %t351)
  store { i64, ptr } %t354, ptr %l179
  br label %bb66
bb66:
  %t355 = load ptr, ptr %l173, !tbaa !29
  %t356 = load %"compiler/source:Span", ptr %l175
  %t357 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t358 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordIn(ptr %v0, ptr %v0, ptr %t355, %"compiler/source:Span" %t356, { i64, ptr } %t357)
  store %"compiler/source:Span" %t358, ptr %l180
  br label %bb67
bb67:
  %t359 = getelementptr %"compiler/source:Span", ptr %l180, i32 0, i32 0
  %t360 = load i32, ptr %t359, !tbaa !23
  %t362 = icmp slt i32 %t360, 0
  br i1 %t362, label %bb68, label %bb69
bb68:
  call void @__olang_scope_close(ptr %s15)
  br label %bb77
bb69:
  br label %bb70
bb70:
  %t364 = load ptr, ptr %l0, !tbaa !29
  store ptr %t364, ptr %l183, !tbaa !29
  %t365 = load ptr, ptr %l6, !tbaa !29
  %t367 = getelementptr %"compiler/ast:VarDecl", ptr %t365, i32 0, i32 1
  %t368 = load { i64, ptr }, ptr %t367, !tbaa !27
  store { i64, ptr } %t368, ptr %l185, !tbaa !27
  %t369 = load i64, ptr %l12, !tbaa !24
  %t371 = getelementptr { i64, ptr }, ptr %l185, i32 0, i32 1
  %t372 = load ptr, ptr %t371, !tbaa !27
  %t373 = getelementptr %"compiler/source:Span", ptr %t372, i64 %t369
  %t374 = load %"compiler/source:Span", ptr %t373
  store %"compiler/source:Span" %t374, ptr %l187
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t376 = load ptr, ptr %l6, !tbaa !29
  %t378 = getelementptr %"compiler/ast:VarDecl", ptr %t376, i32 0, i32 0
  %t379 = load { i64, ptr }, ptr %t378, !tbaa !27
  store { i64, ptr } %t379, ptr %l190, !tbaa !27
  %t380 = load i64, ptr %l12, !tbaa !24
  %t382 = getelementptr { i64, ptr }, ptr %l190, i32 0, i32 1
  %t383 = load ptr, ptr %t382, !tbaa !27
  %t384 = getelementptr i32, ptr %t383, i64 %t380
  %t385 = load i32, ptr %t384, !tbaa !33
  %t388 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s15, ptr %t375, i32 %t385)
  store { i64, ptr } %t388, ptr %l193
  br label %bb71
bb71:
  %t389 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t390 = extractvalue { i64, ptr } %t389, 0
  %t391 = extractvalue { i64, ptr } %t389, 1
  %t392 = mul i64 %t390, 1
  %t393 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t392)
  call void @llvm.memcpy.p0.p0.i64(ptr %t393, ptr %t391, i64 %t392, i1 false)
  %t394 = insertvalue { i64, ptr } undef, i64 %t390, 0
  %t395 = insertvalue { i64, ptr } %t394, ptr %t393, 1
  store { i64, ptr } %t395, ptr %l194, !tbaa !27
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t397 = load ptr, ptr %l21, !tbaa !29
  %t399 = getelementptr %"compiler/ast:TypeParam", ptr %t397, i32 0, i32 1
  %t400 = load i32, ptr %t399, !tbaa !23
  %t403 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t396, i32 %t400)
  store { i64, ptr } %t403, ptr %l198
  br label %bb72
bb72:
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t405 = load ptr, ptr %l1, !tbaa !29
  %t407 = getelementptr %"compiler/ast:TypeDecl", ptr %t405, i32 0, i32 0
  %t408 = load i32, ptr %t407, !tbaa !23
  %t411 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t404, i32 %t408)
  store { i64, ptr } %t411, ptr %l202
  br label %bb73
bb73:
  %t412 = load ptr, ptr %l0, !tbaa !29
  %t413 = load ptr, ptr %l21, !tbaa !29
  %t415 = getelementptr %"compiler/ast:TypeParam", ptr %t413, i32 0, i32 1
  %t416 = load i32, ptr %t415, !tbaa !23
  %t419 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t412, i32 %t416)
  store { i64, ptr } %t419, ptr %l206
  br label %bb74
bb74:
  %t420 = load { i64, ptr }, ptr %l194, !tbaa !27
  %t421 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t422 = load { i64, ptr }, ptr %l202, !tbaa !27
  %t423 = load { i64, ptr }, ptr %l206, !tbaa !27
  %t424 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCtorFieldNamesVar(ptr %s15, ptr %v0, ptr %v0, ptr %v0, ptr %s15, { i64, ptr } %t420, { i64, ptr } %t421, { i64, ptr } %t422, { i64, ptr } %t423)
  store %"compiler/msgs:Msg" %t424, ptr %l207
  br label %bb75
bb75:
  %t425 = load ptr, ptr %l183, !tbaa !29
  %t426 = load %"compiler/source:Span", ptr %l187
  %t427 = load %"compiler/msgs:Msg", ptr %l207
  %t428 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s15, ptr %t425, %"compiler/source:Span" %t426, %"compiler/msgs:Msg" %t427)
  store i64 %t428, ptr %l208
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s15)
  store i32 1, ptr %ws3
  br label %wend3
wend3.c1:
  call void @__olang_scope_close(ptr %s3)
  br label %ret
bb77:
  %t429 = load i64, ptr %l19, !tbaa !24
  %t431 = add i64 %t429, 1
  store i64 %t431, ptr %l19, !tbaa !24
  br label %bb61
bb78:
  br label %bb79
bb79:
  %t433 = load i64, ptr %l11, !tbaa !24
  %t435 = add i64 %t433, 1
  store i64 %t435, ptr %l11, !tbaa !24
  br label %bb27
bb80:
  br label %bb81
bb81:
  br label %bb16
bb82:
  store i32 2, ptr %ws3
  br label %wend3
wend3.c2:
  call void @__olang_scope_close(ptr %s3)
  br label %ret
wend3:
  %t437 = load ptr, ptr %wh3
  %t438 = load ptr, ptr %wc3
  %t439 = call ptr @llvm.coro.promise(ptr %t437, i32 8, i1 false)
  %t440 = getelementptr { { i32, ptr }, i32 }, ptr %t439, i32 0, i32 1
  store i32 2, ptr %t440
  %t441 = call { i32, ptr } %t438(ptr %t437, ptr null)
  %t442 = load i32, ptr %ws3
  switch i32 %t442, label %wend3.c0 [ i32 1, label %wend3.c1 i32 2, label %wend3.c2 ]
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorViewKey(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i32
  %l4 = alloca i32
  %l7 = alloca i64
  %l14 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Body", ptr %a1, i32 0, i32 1
  %t4 = load { i64, [2 x i64] }, ptr %t3
  store { i64, [2 x i64] } %t4, ptr %l2
  %t6 = load { i64, [2 x i64] }, ptr %l2
  %t8 = extractvalue { i64, [2 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 1
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t12 = getelementptr { i32, i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  store i32 %t13, ptr %l3, !tbaa !23
  %t15 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t16 = getelementptr { i32, i32 }, ptr %t15, i32 0, i32 1
  %t17 = load i32, ptr %t16
  store i32 %t17, ptr %l4, !tbaa !23
  br label %bb3
bb2:
  br label %bb7
bb3:
  %t19 = load i32, ptr %l4, !tbaa !23
  %t21 = icmp eq i32 %t19, 0
  br i1 %t21, label %bb4, label %bb5
bb4:
  %t23 = load i32, ptr %l3, !tbaa !23
  %t25 = sext i32 %t23 to i64
  store i64 %t25, ptr %l14, !tbaa !24
  br label %bb6
bb5:
  store i64 -1, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t27 = load i64, ptr %l14, !tbaa !24
  store i64 %t27, ptr %l7, !tbaa !24
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i64 -1, ptr %l7, !tbaa !24
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_7351608f8313d577_54e294ea81fa84bb)
  unreachable
bb12:
  %t28 = load i64, ptr %l7, !tbaa !24
  store i64 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edataAsFixed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i32 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i64
  %l7 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l21 = alloca i64
  %l25 = alloca %"compiler/source:Span"
  %l31 = alloca i32
  %l43 = alloca ptr
  %rv = alloca ptr
  %t54 = alloca { i64, [5 x i64] }, align 8
  %t74 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l5
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l6, !tbaa !24
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t24, i32 0, i32 3
  %t26 = load ptr, ptr %t25
  store ptr %t26, ptr %l7, !tbaa !29
  br label %bb5
bb4:
  br label %bb12
bb5:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t32 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edataLength(ptr %v0, ptr %v1, ptr %t28, ptr %t29)
  store i64 %t32, ptr %l21
  br label %bb6
bb6:
  %t34 = load i64, ptr %l21, !tbaa !24
  %t36 = icmp ne i64 %t34, %a4
  br i1 %t36, label %bb7, label %bb8
bb7:
  store ptr null, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t39 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t39, ptr %l25
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/check:Checker", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/generic:Program", ptr %t43, i32 0, i32 2
  %t46 = load i32, ptr %l3, !tbaa !23
  %t47 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t45, i32 %t46, i64 %t47)
  store i32 %t51, ptr %l31
  br label %bb10
bb10:
  %t52 = load i64, ptr %l6, !tbaa !24
  %t53 = load ptr, ptr %l7, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t54
  %t55 = getelementptr { i64, [5 x i64] }, ptr %t54, i32 0, i32 0
  store i64 1, ptr %t55
  %t56 = load %"compiler/source:Span", ptr %l25
  %t57 = insertvalue { %"compiler/source:Span", i32, i64, ptr } undef, %"compiler/source:Span" %t56, 0
  %t58 = load i32, ptr %l31, !tbaa !23
  %t59 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t57, i32 %t58, 1
  %t61 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t59, i64 %t52, 2
  %t63 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t61, ptr %t53, 3
  %t64 = getelementptr { i64, [5 x i64] }, ptr %t54, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, ptr } %t63, ptr %t64
  %t65 = load { i64, [5 x i64] }, ptr %t54
  %t67 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t65, ptr %t67
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load %"compiler/source:Span", ptr %l2
  %t71 = load %"compiler/source:Span", ptr %l2
  %t72 = load i32, ptr %l3, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t74
  %t75 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 0
  store i64 2, ptr %t75
  %t77 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t71, 0
  %t79 = insertvalue { %"compiler/source:Span", i32, ptr } %t77, i32 %t72, 1
  %t81 = insertvalue { %"compiler/source:Span", i32, ptr } %t79, ptr %t67, 2
  %t82 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t81, ptr %t82
  %t83 = load { i64, [4 x i64] }, ptr %t74
  %t85 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t83, ptr %t85
  %t89 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v2, ptr %v2, ptr %t69, %"compiler/source:Span" %t70, ptr %t85)
  store ptr %t89, ptr %l43
  br label %bb11
bb11:
  %t90 = load ptr, ptr %l43, !tbaa !29
  store ptr %t90, ptr %rv
  br label %ret
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store ptr null, ptr %rv
  br label %ret
bb16:
  call void @__olang_check_failed(ptr @olang_loc_3ca681ba130ec9b7_181dd48ce58d3c73)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edecided(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca i1
  %l5 = alloca ptr
  %rv = alloca ptr
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call i1 @compiler_2fcheck_2eleaves(ptr %v1, ptr %t1)
  store i1 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t7 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t7, ptr %l5
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t8 = load ptr, ptr %l5, !tbaa !29
  %t10 = getelementptr %"compiler/check:frame", ptr %t8, i32 0, i32 49
  store i1 true, ptr %t10, !tbaa !21
  br label %bb5
bb5:
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclAttrs(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca i1
  %l49 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 11}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [6 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb14
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i64, ptr %l1, !tbaa !24
  %t18 = load ptr, ptr %l3, !tbaa !29
  %t20 = getelementptr %"compiler/ast:TypeDecl", ptr %t18, i32 0, i32 4
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrsChecked(ptr %v0, ptr %v1, ptr %t16, i64 %t17, { i64, ptr } %t21)
  br label %bb6
bb6:
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t27 = getelementptr %"compiler/ast:TypeDecl", ptr %t25, i32 0, i32 3
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = icmp eq ptr %t28, null
  %t32 = xor i1 %t30, true
  br i1 %t32, label %bb7, label %bb8
bb7:
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l23, !tbaa !29
  %t35 = load i64, ptr %l1, !tbaa !24
  store i64 %t35, ptr %l24, !tbaa !24
  %t36 = load ptr, ptr %l3, !tbaa !29
  %t38 = getelementptr %"compiler/ast:TypeDecl", ptr %t36, i32 0, i32 3
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = icmp eq ptr %t39, null
  br i1 %t41, label %bb9, label %bb10
bb8:
  br label %bb13
bb9:
  call void @__olang_check_failed(ptr @olang_loc_e375dcd56c8db7ae_8ebec7f18eafef7a)
  unreachable
bb10:
  br label %bb11
bb11:
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t45 = getelementptr %"compiler/ast:TypeDecl", ptr %t43, i32 0, i32 3
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t47 = load ptr, ptr %l23, !tbaa !29
  %t48 = load i64, ptr %l24, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyAttrs(ptr %v0, ptr %v1, ptr %t47, i64 %t48, ptr %t46)
  br label %bb12
bb12:
  br label %bb13
bb13:
  br label %bb33
bb14:
  %t50 = load ptr, ptr %l2, !tbaa !29
  store ptr %t50, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t51 = load ptr, ptr %l30, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb15, label %bb16
bb15:
  %t54 = load ptr, ptr %l30, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 11}
  %t57 = icmp eq i64 %t55, 0
  store i1 %t57, ptr %l31, !tbaa !21
  br label %bb16
bb16:
  %t58 = load i1, ptr %l31, !tbaa !21
  br i1 %t58, label %bb17, label %bb18
bb17:
  %t59 = load ptr, ptr %l2, !tbaa !29
  %t61 = getelementptr { i64, [6 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { ptr }, ptr %t61, i32 0, i32 0
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb28
bb19:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load i64, ptr %l1, !tbaa !24
  %t67 = load ptr, ptr %l4, !tbaa !29
  %t69 = getelementptr %"compiler/ast:Func", ptr %t67, i32 0, i32 8
  %t70 = load { i64, ptr }, ptr %t69, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrsChecked(ptr %v0, ptr %v1, ptr %t65, i64 %t66, { i64, ptr } %t70)
  br label %bb20
bb20:
  %t74 = load ptr, ptr %l4, !tbaa !29
  %t76 = getelementptr %"compiler/ast:Func", ptr %t74, i32 0, i32 3
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/ast:Sig", ptr %t77, i32 0, i32 0
  %t80 = load { i64, ptr }, ptr %t79, !tbaa !27
  store { i64, ptr } %t80, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t82 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t82, 0
  store i64 %t84, ptr %l7, !tbaa !24
  br label %bb21
bb21:
  %t86 = load i64, ptr %l6, !tbaa !24
  %t87 = load i64, ptr %l7, !tbaa !24
  %t90 = icmp slt i64 %t86, %t87
  %t92 = xor i1 %t90, true
  br i1 %t92, label %bb22, label %bb23
bb22:
  br label %bb27
bb23:
  br label %bb24
bb24:
  %t94 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t94, ptr %l49, !tbaa !27
  %t95 = load i64, ptr %l6, !tbaa !24
  %t97 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr ptr, ptr %t98, i64 %t95
  %t100 = load ptr, ptr %t99, !tbaa !39
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load i64, ptr %l1, !tbaa !24
  %t106 = getelementptr %"compiler/ast:Param", ptr %t100, i32 0, i32 4
  %t107 = load { i64, ptr }, ptr %t106, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrsChecked(ptr %v0, ptr %v1, ptr %t102, i64 %t103, { i64, ptr } %t107)
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t111 = load i64, ptr %l6, !tbaa !24
  %t113 = add i64 %t111, 1
  store i64 %t113, ptr %l6, !tbaa !24
  br label %bb21
bb27:
  br label %bb33
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_f43f80063d96068c_f8dacab5994fea88)
  unreachable
bb33:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l6 = alloca i64
  %l13 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %t6, i32 %t7)
  store i64 %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = load i64, ptr %l6, !tbaa !24
  %t12 = icmp sgt i64 %t11, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  store i32 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/generic:Program", ptr %t18, i32 0, i32 2
  %t21 = load i32, ptr %l1, !tbaa !23
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamed(ptr %v0, ptr %t20, i32 %t21, i32 0)
  store i32 %t24, ptr %l13
  br label %bb5
bb5:
  %t25 = load i32, ptr %l13, !tbaa !23
  store i32 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaredCtor(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l9 = alloca i1
  %l13 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l38 = alloca i1
  %l48 = alloca i64
  %l51 = alloca ptr
  %l54 = alloca ptr
  %l59 = alloca i32
  %l60 = alloca i32
  %l61 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/ast:TypeDecl", ptr %t5, i32 0, i32 3
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = icmp eq ptr %t8, null
  store i1 %t10, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l9, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb6
bb5:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t15 = getelementptr %"compiler/ast:TypeDecl", ptr %t13, i32 0, i32 1
  %t16 = load { i64, ptr }, ptr %t15, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  %t20 = icmp sgt i64 %t18, 0
  store i1 %t20, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t22 = load i1, ptr %l13, !tbaa !21
  br i1 %t22, label %bb7, label %bb8
bb7:
  br label %ret
bb8:
  br label %bb9
bb9:
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t25 = getelementptr %"compiler/ast:TypeDecl", ptr %t23, i32 0, i32 3
  %t26 = load ptr, ptr %t25, !tbaa !29
  store ptr %t26, ptr %l3, !tbaa !29
  %t28 = load ptr, ptr %l3, !tbaa !29
  store ptr %t28, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t29 = load ptr, ptr %l20, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t32 = load ptr, ptr %l20, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 5}
  %t35 = icmp eq i64 %t33, 0
  store i1 %t35, ptr %l21, !tbaa !21
  br label %bb11
bb11:
  %t36 = load i1, ptr %l21, !tbaa !21
  br i1 %t36, label %bb12, label %bb13
bb12:
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t39 = getelementptr { i64, [6 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { ptr }, ptr %t39, i32 0, i32 0
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l4, !tbaa !29
  br label %bb14
bb13:
  br label %bb18
bb14:
  %t43 = load ptr, ptr %l4, !tbaa !29
  %t45 = getelementptr %"compiler/ast:StructBody", ptr %t43, i32 0, i32 5
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t46, 0
  %t50 = icmp sgt i64 %t48, 0
  br i1 %t50, label %bb15, label %bb16
bb15:
  br label %ret
bb16:
  br label %bb17
bb17:
  br label %bb35
bb18:
  %t52 = load ptr, ptr %l3, !tbaa !29
  store ptr %t52, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t53 = load ptr, ptr %l30, !tbaa !29
  %t54 = icmp ne ptr %t53, null
  br i1 %t54, label %bb19, label %bb20
bb19:
  %t56 = load ptr, ptr %l30, !tbaa !29
  %t57 = load i64, ptr %t56, !range !{i64 0, i64 5}
  %t59 = icmp eq i64 %t57, 3
  store i1 %t59, ptr %l31, !tbaa !21
  br label %bb20
bb20:
  %t60 = load i1, ptr %l31, !tbaa !21
  br i1 %t60, label %bb21, label %bb22
bb21:
  %t61 = load ptr, ptr %l3, !tbaa !29
  %t63 = getelementptr { i64, [6 x i64] }, ptr %t61, i32 0, i32 1
  %t64 = getelementptr { ptr, ptr }, ptr %t63, i32 0, i32 1
  %t65 = load ptr, ptr %t64
  store ptr %t65, ptr %l5, !tbaa !29
  br label %bb23
bb22:
  br label %bb30
bb23:
  %t67 = load ptr, ptr %l5, !tbaa !29
  %t69 = icmp eq ptr %t67, null
  br i1 %t69, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb26
bb25:
  %t71 = load ptr, ptr %l5, !tbaa !29
  %t73 = getelementptr %"compiler/ast:Func", ptr %t71, i32 0, i32 5
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t74, 0
  %t78 = icmp sgt i64 %t76, 0
  store i1 %t78, ptr %l38, !tbaa !21
  br label %bb26
bb26:
  %t80 = load i1, ptr %l38, !tbaa !21
  br i1 %t80, label %bb27, label %bb28
bb27:
  br label %ret
bb28:
  br label %bb29
bb29:
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %ret
bb34:
  call void @__olang_check_failed(ptr @olang_loc_f558fce6a2b003e7_933c1b66dd113bdb)
  unreachable
bb35:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/check:Checker", ptr %t81, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t85 = load i64, ptr %l1, !tbaa !24
  %t86 = load ptr, ptr %l2, !tbaa !29
  %t88 = getelementptr %"compiler/ast:TypeDecl", ptr %t86, i32 0, i32 0
  %t89 = load i32, ptr %t88, !tbaa !23
  %t93 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %t84, i64 %t85, i32 %t89)
  store i64 %t93, ptr %l48
  br label %bb36
bb36:
  %t94 = load i64, ptr %l48, !tbaa !24
  store i64 %t94, ptr %l6, !tbaa !24
  %t95 = load i64, ptr %l6, !tbaa !24
  %t97 = icmp slt i64 %t95, 0
  br i1 %t97, label %bb37, label %bb38
bb37:
  br label %ret
bb38:
  br label %bb39
bb39:
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l51, !tbaa !29
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/check:Checker", ptr %t100, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = getelementptr %"compiler/generic:Program", ptr %t103, i32 0, i32 2
  store ptr %t105, ptr %l54, !tbaa !29
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t110 = load i64, ptr %l1, !tbaa !24
  %t111 = load i64, ptr %l6, !tbaa !24
  %t115 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t109, i64 %t110, i64 %t111)
  store i32 %t115, ptr %l59
  br label %bb40
bb40:
  %t116 = load ptr, ptr %l54, !tbaa !29
  %t117 = load i32, ptr %l59, !tbaa !23
  %t118 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamed(ptr %v0, ptr %t116, i32 %t117, i32 0)
  store i32 %t118, ptr %l60
  br label %bb41
bb41:
  %t119 = load ptr, ptr %l51, !tbaa !29
  %t120 = load i32, ptr %l60, !tbaa !23
  %t121 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %t119, i32 %t120)
  store i64 %t121, ptr %l61
  br label %bb42
bb42:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultReads(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i1
  %l22 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l40 = alloca ptr
  %l44 = alloca i1
  %l47 = alloca i1
  %l51 = alloca ptr
  %l54 = alloca { i64, [3 x i64] }
  %l55 = alloca %"compiler/msgs:Msg"
  %l56 = alloca i64
  %l57 = alloca ptr
  %l58 = alloca i1
  %l70 = alloca { i64, ptr }
  %l78 = alloca ptr
  %l79 = alloca i1
  %l92 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t6 = load ptr, ptr %l18, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l18, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l19, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l19, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t19 = load ptr, ptr %l24, !tbaa !29
  %t20 = icmp ne ptr %t19, null
  br i1 %t20, label %bb8, label %bb9
bb7:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb10
bb8:
  %t22 = load ptr, ptr %l24, !tbaa !29
  %t23 = load i64, ptr %t22, !range !{i64 0, i64 8}
  %t25 = icmp eq i64 %t23, 1
  store i1 %t25, ptr %l25, !tbaa !21
  br label %bb9
bb9:
  %t26 = load i1, ptr %l25, !tbaa !21
  store i1 %t26, ptr %l22, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l22, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t30, i32 0, i32 0
  %t32 = load %"compiler/source:Span", ptr %t31
  store %"compiler/source:Span" %t32, ptr %l2
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr { i64, [5 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t36, i32 0, i32 2
  %t38 = load ptr, ptr %t37
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t40, i32 0, i32 2
  %t42 = load i64, ptr %t41
  store i64 %t42, ptr %l3, !tbaa !24
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr { i64, [5 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t46, i32 0, i32 2
  %t48 = load ptr, ptr %t47
  %t50 = getelementptr { i64, [4 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t50, i32 0, i32 3
  %t52 = load i32, ptr %t51
  store i32 %t52, ptr %l4, !tbaa !23
  br label %bb13
bb12:
  br label %bb25
bb13:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t58 = load i64, ptr %l3, !tbaa !24
  %t59 = load i32, ptr %l4, !tbaa !23
  %t63 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %v0, ptr %t57, i64 %t58, i32 %t59)
  store ptr %t63, ptr %l40
  br label %bb14
bb14:
  %t64 = load ptr, ptr %l40, !tbaa !29
  store ptr %t64, ptr %l5, !tbaa !29
  %t65 = load ptr, ptr %l5, !tbaa !29
  %t67 = icmp eq ptr %t65, null
  %t69 = xor i1 %t67, true
  br i1 %t69, label %bb15, label %bb16
bb15:
  %t71 = load ptr, ptr %l5, !tbaa !29
  %t73 = getelementptr %"compiler/ast:VarDecl", ptr %t71, i32 0, i32 2
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = call i1 @compiler_2fgeneric_2eWrittenMut(ptr %v0, ptr %t74)
  store i1 %t76, ptr %l47
  br label %bb17
bb16:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb18
bb17:
  %t77 = load i1, ptr %l47, !tbaa !21
  store i1 %t77, ptr %l44, !tbaa !21
  br label %bb18
bb18:
  %t78 = load i1, ptr %l44, !tbaa !21
  br i1 %t78, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/generic:Program", ptr %t82, i32 0, i32 0
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/load:Loader", ptr %t85, i32 0, i32 4
  %t88 = load ptr, ptr %t87, !tbaa !29
  store ptr %t88, ptr %l51, !tbaa !29
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load %"compiler/source:Span", ptr %l2
  %t93 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t89, %"compiler/source:Span" %t90)
  store { i64, [3 x i64] } %t93, ptr %l54
  br label %bb21
bb20:
  br label %bb24
bb21:
  %t94 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultNotComputable(ptr %s3, ptr %s3, { i64, ptr } { i64 63, ptr getelementptr inbounds (<{ i64, [63 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t94, ptr %l55
  br label %bb22
bb22:
  %t95 = load ptr, ptr %l51, !tbaa !29
  %t96 = load { i64, [3 x i64] }, ptr %l54
  %t97 = load %"compiler/msgs:Msg", ptr %l55
  %t98 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %s3, ptr %t95, { i64, [3 x i64] } %t96, %"compiler/msgs:Msg" %t97)
  store i64 %t98, ptr %l56
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb24:
  br label %bb56
bb25:
  %t99 = load ptr, ptr %l1, !tbaa !29
  store ptr %t99, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t100 = load ptr, ptr %l57, !tbaa !29
  %t101 = icmp ne ptr %t100, null
  br i1 %t101, label %bb26, label %bb27
bb26:
  %t103 = load ptr, ptr %l57, !tbaa !29
  %t104 = load i64, ptr %t103, !range !{i64 0, i64 18}
  %t106 = icmp eq i64 %t104, 9
  store i1 %t106, ptr %l58, !tbaa !21
  br label %bb27
bb27:
  %t107 = load i1, ptr %l58, !tbaa !21
  br i1 %t107, label %bb28, label %bb29
bb28:
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t110 = getelementptr { i64, [5 x i64] }, ptr %t108, i32 0, i32 1
  %t111 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t110, i32 0, i32 4
  %t112 = load { i64, ptr }, ptr %t111
  store { i64, ptr } %t112, ptr %l6, !tbaa !27
  br label %bb30
bb29:
  br label %bb38
bb30:
  %t114 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t114, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t116 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t116, 0
  store i64 %t118, ptr %l9, !tbaa !24
  br label %bb31
bb31:
  %t120 = load i64, ptr %l8, !tbaa !24
  %t121 = load i64, ptr %l9, !tbaa !24
  %t124 = icmp slt i64 %t120, %t121
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb32, label %bb33
bb32:
  br label %bb37
bb33:
  br label %bb34
bb34:
  %t128 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t128, ptr %l70, !tbaa !27
  %t129 = load i64, ptr %l8, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr ptr, ptr %t132, i64 %t129
  %t134 = load ptr, ptr %t133, !tbaa !39
  %t136 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultReads(ptr %v0, ptr %v1, ptr %t136, ptr %t134)
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t141 = load i64, ptr %l8, !tbaa !24
  %t143 = add i64 %t141, 1
  store i64 %t143, ptr %l8, !tbaa !24
  br label %bb31
bb37:
  br label %bb56
bb38:
  %t145 = load ptr, ptr %l1, !tbaa !29
  store ptr %t145, ptr %l78, !tbaa !29
  store i1 false, ptr %l79, !tbaa !21
  %t146 = load ptr, ptr %l78, !tbaa !29
  %t147 = icmp ne ptr %t146, null
  br i1 %t147, label %bb39, label %bb40
bb39:
  %t149 = load ptr, ptr %l78, !tbaa !29
  %t150 = load i64, ptr %t149, !range !{i64 0, i64 18}
  %t152 = icmp eq i64 %t150, 6
  store i1 %t152, ptr %l79, !tbaa !21
  br label %bb40
bb40:
  %t153 = load i1, ptr %l79, !tbaa !21
  br i1 %t153, label %bb41, label %bb42
bb41:
  %t154 = load ptr, ptr %l1, !tbaa !29
  %t156 = getelementptr { i64, [5 x i64] }, ptr %t154, i32 0, i32 1
  %t157 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t156, i32 0, i32 2
  %t158 = load ptr, ptr %t157
  store ptr %t158, ptr %l11, !tbaa !29
  br label %bb43
bb42:
  br label %bb51
bb43:
  %t160 = load ptr, ptr %l11, !tbaa !29
  %t162 = getelementptr %"compiler/typed:Call", ptr %t160, i32 0, i32 1
  %t163 = load { i64, ptr }, ptr %t162, !tbaa !27
  store { i64, ptr } %t163, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t165 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t167 = extractvalue { i64, ptr } %t165, 0
  store i64 %t167, ptr %l14, !tbaa !24
  br label %bb44
bb44:
  %t169 = load i64, ptr %l13, !tbaa !24
  %t170 = load i64, ptr %l14, !tbaa !24
  %t173 = icmp slt i64 %t169, %t170
  %t175 = xor i1 %t173, true
  br i1 %t175, label %bb45, label %bb46
bb45:
  br label %bb50
bb46:
  br label %bb47
bb47:
  %t177 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t177, ptr %l92, !tbaa !27
  %t178 = load i64, ptr %l13, !tbaa !24
  %t180 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !27
  %t182 = getelementptr ptr, ptr %t181, i64 %t178
  %t183 = load ptr, ptr %t182, !tbaa !39
  %t185 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultReads(ptr %v0, ptr %v1, ptr %t185, ptr %t183)
  br label %bb48
bb48:
  br label %bb49
bb49:
  %t190 = load i64, ptr %l13, !tbaa !24
  %t192 = add i64 %t190, 1
  store i64 %t192, ptr %l13, !tbaa !24
  br label %bb44
bb50:
  br label %bb56
bb51:
  br i1 true, label %bb52, label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb56
bb55:
  call void @__olang_check_failed(ptr @olang_loc_5535019c26f71449_86439f2d3bbcfbb5)
  unreachable
bb56:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrCompare(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %l20 = alloca i1
  %l24 = alloca i1
  %l25 = alloca i1
  %l28 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca %"compiler/msgs:Msg"
  %l33 = alloca i64
  %l37 = alloca ptr
  %l45 = alloca ptr
  %l52 = alloca ptr
  %s2 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrItemPath(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i1 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i1, ptr %l9, !tbaa !21
  store i1 %t6, ptr %l5, !tbaa !21
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load ptr, ptr %l4, !tbaa !29
  %t11 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrItemPath(ptr %v0, ptr %v2, ptr %t7, ptr %t8)
  store i1 %t11, ptr %l12
  br label %bb2
bb2:
  %t12 = load i1, ptr %l12, !tbaa !21
  store i1 %t12, ptr %l6, !tbaa !21
  %t13 = load i1, ptr %l5, !tbaa !21
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load i1, ptr %l6, !tbaa !21
  %t19 = xor i1 %t17, true
  store i1 %t19, ptr %l15, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb5
bb5:
  %t21 = load i1, ptr %l15, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  store ptr null, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t23 = load i1, ptr %l5, !tbaa !21
  br i1 %t23, label %bb9, label %bb10
bb9:
  %t25 = load i1, ptr %l6, !tbaa !21
  store i1 %t25, ptr %l20, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb11
bb11:
  %t27 = load i1, ptr %l20, !tbaa !21
  br i1 %t27, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t32 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrWordPath(ptr %v0, ptr %v1, ptr %t28, ptr %t29)
  store i1 %t32, ptr %l24
  br label %bb14
bb13:
  br label %bb25
bb14:
  %t33 = load i1, ptr %l24, !tbaa !21
  br i1 %t33, label %bb15, label %bb16
bb15:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load ptr, ptr %l4, !tbaa !29
  %t38 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrWordPath(ptr %v0, ptr %v2, ptr %t34, ptr %t35)
  store i1 %t38, ptr %l28
  br label %bb17
bb16:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb18
bb17:
  %t39 = load i1, ptr %l28, !tbaa !21
  store i1 %t39, ptr %l25, !tbaa !21
  br label %bb18
bb18:
  %t40 = load i1, ptr %l25, !tbaa !21
  br i1 %t40, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s2)
  store ptr null, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l30, !tbaa !29
  %t43 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t43, ptr %l31
  %t44 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtComparedToCaught(ptr %s2)
  store %"compiler/msgs:Msg" %t44, ptr %l32
  br label %bb22
bb22:
  %t45 = load ptr, ptr %l30, !tbaa !29
  %t46 = load %"compiler/source:Span", ptr %l31
  %t47 = load %"compiler/msgs:Msg", ptr %l32
  %t48 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t45, %"compiler/source:Span" %t46, %"compiler/msgs:Msg" %t47)
  store i64 %t48, ptr %l33
  br label %bb23
bb23:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load %"compiler/source:Span", ptr %l1
  %t51 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t55 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t49, %"compiler/source:Span" %t50, i32 %t51, i64 0)
  store ptr %t55, ptr %l37
  br label %bb24
bb24:
  %t56 = load ptr, ptr %l37, !tbaa !29
  call void @__olang_scope_close(ptr %s2)
  store ptr %t56, ptr %rv
  br label %ret
bb25:
  %t58 = load i1, ptr %l5, !tbaa !21
  br i1 %t58, label %bb26, label %bb27
bb26:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load %"compiler/source:Span", ptr %l1
  %t62 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t63 = load ptr, ptr %l4, !tbaa !29
  %t64 = load ptr, ptr %l3, !tbaa !29
  %t70 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrCompareItem(ptr %v0, ptr %v2, ptr %v1, ptr %v3, ptr %t60, %"compiler/source:Span" %t61, i32 %t62, ptr %t63, ptr %t64)
  store ptr %t70, ptr %l45
  br label %bb28
bb27:
  br label %bb29
bb28:
  %t71 = load ptr, ptr %l45, !tbaa !29
  store ptr %t71, ptr %rv
  br label %ret
bb29:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load %"compiler/source:Span", ptr %l1
  %t75 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t76 = load ptr, ptr %l3, !tbaa !29
  %t77 = load ptr, ptr %l4, !tbaa !29
  %t83 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrCompareItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t73, %"compiler/source:Span" %t74, i32 %t75, ptr %t76, ptr %t77)
  store ptr %t83, ptr %l52
  br label %bb30
bb30:
  %t84 = load ptr, ptr %l52, !tbaa !29
  store ptr %t84, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/check:factsMark" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsHeld(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l6 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i64
  %l13 = alloca %"compiler/check:factsMark"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/check:factsMark"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 50
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eLen_H4b13e48b0a317e727dbe35330ad8712a(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l6
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/check:frame", ptr %t10, i32 0, i32 46
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLen_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l9
  br label %bb3
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/check:frame", ptr %t15, i32 0, i32 59
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eLen__H3cdfcddd9c493bd8bcefc7b766e0438b(ptr %v0, ptr %t17)
  store i64 %t19, ptr %l12
  br label %bb4
bb4:
  %t20 = load i64, ptr %l6, !tbaa !24
  %t21 = load i64, ptr %l9, !tbaa !24
  %t22 = load i64, ptr %l12, !tbaa !24
  %t23 = call %"compiler/check:factsMark" @compiler_2fcheck_3afactsMark_2ector(ptr %s0, i64 %t20, i64 %t21, i64 %t22)
  store %"compiler/check:factsMark" %t23, ptr %l13
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t24 = load %"compiler/check:factsMark", ptr %l13
  store %"compiler/check:factsMark" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:factsMark", ptr %rv
  ret %"compiler/check:factsMark" %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnBody(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l17 = alloca i64
  %l21 = alloca i32
  %l22 = alloca ptr
  %l24 = alloca { i64, [2 x i64] }
  %l25 = alloca i32
  %l29 = alloca i64
  %l33 = alloca ptr
  %l36 = alloca i64
  %l43 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i64
  %t40 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 20
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l10
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l9
  br label %bb1
bb1:
  %t12 = load i64, ptr %l9, !tbaa !24
  store i64 %t12, ptr %l5, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l5, !tbaa !24
  store i64 %t13, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp sge i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load i64, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t18, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t24 = load i64, ptr %l1, !tbaa !24
  %t27 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t23, i64 %t24)
  store i64 %t27, ptr %l17
  br label %bb8
bb8:
  %t28 = load i64, ptr %l17, !tbaa !24
  store i64 %t28, ptr %l3, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t33 = load i64, ptr %l1, !tbaa !24
  %t36 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %t32, i64 %t33)
  store i32 %t36, ptr %l21
  br label %bb9
bb9:
  %t37 = load i32, ptr %l21, !tbaa !23
  store i32 %t37, ptr %l4, !tbaa !23
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l22, !tbaa !29
  %t39 = load i64, ptr %l1, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t40
  %t41 = getelementptr { i64, [2 x i64] }, ptr %t40, i32 0, i32 0
  store i64 0, ptr %t41
  %t43 = insertvalue { i64 } undef, i64 %t39, 0
  %t44 = getelementptr { i64, [2 x i64] }, ptr %t40, i32 0, i32 1
  store { i64 } %t43, ptr %t44
  %t45 = load { i64, [2 x i64] }, ptr %t40
  store { i64, [2 x i64] } %t45, ptr %l24
  %t46 = load i32, ptr %l4, !tbaa !23
  store i32 %t46, ptr %l25, !tbaa !23
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t51 = load i64, ptr %l3, !tbaa !24
  %t54 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t50, i64 %t51)
  store i64 %t54, ptr %l29
  br label %bb10
bb10:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  %t62 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s0, ptr %t58, i64 %t59)
  store ptr %t62, ptr %l33
  br label %bb11
bb11:
  %t63 = load ptr, ptr %l33, !tbaa !29
  %t65 = getelementptr %"compiler/ast:Func", ptr %t63, i32 0, i32 0
  %t66 = load %"compiler/source:Span", ptr %t65
  %t67 = load ptr, ptr %l22, !tbaa !29
  %t68 = load { i64, [2 x i64] }, ptr %l24
  %t69 = load i32, ptr %l25, !tbaa !23
  %t70 = load i64, ptr %l29, !tbaa !24
  %t72 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t67, { i64, [2 x i64] } %t68, i32 %t69, i64 %t70, %"compiler/source:Span" %t66)
  store i64 %t72, ptr %l36
  br label %bb12
bb12:
  %t73 = load i64, ptr %l36, !tbaa !24
  store i64 %t73, ptr %l2, !tbaa !24
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t74, i32 0, i32 20
  %t77 = load i64, ptr %l1, !tbaa !24
  %t78 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t76, i64 %t77, i64 %t78)
  br label %bb13
bb13:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i32, ptr %l4, !tbaa !23
  %t86 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %t82, i32 %t83)
  store i1 %t86, ptr %l43
  br label %bb14
bb14:
  %t87 = load i1, ptr %l43, !tbaa !21
  br i1 %t87, label %bb15, label %bb16
bb15:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/check:Checker", ptr %t88, i32 0, i32 54
  %t91 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t90, i64 %t91, i1 true)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  %t94 = load i64, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t94, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnNameAt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l13 = alloca ptr
  %l17 = alloca i64
  %l23 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l39 = alloca i64
  %l52 = alloca i64
  %l53 = alloca { i64, ptr }
  %l54 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i32
  %l68 = alloca i64
  %l80 = alloca ptr
  %rv = alloca { i64, [3 x i64] }
  %t179 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l13
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l13, !tbaa !29
  store ptr %t9, ptr %l2, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l17
  br label %bb2
bb2:
  %t18 = load i64, ptr %l17, !tbaa !24
  store i64 %t18, ptr %l3, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/load:Loader", ptr %t25, i32 0, i32 10
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t27, i64 %t28)
  store ptr %t31, ptr %l23
  br label %bb3
bb3:
  %t32 = load ptr, ptr %l23, !tbaa !29
  %t34 = getelementptr %"compiler/load:Module", ptr %t32, i32 0, i32 6
  %t35 = load ptr, ptr %t34, !tbaa !29
  store ptr %t35, ptr %l4, !tbaa !29
  %t37 = load ptr, ptr %l4, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  br i1 %t39, label %bb4, label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_a78beee7b0d01a06_c23e8f3cd3901b22)
  unreachable
bb5:
  br label %bb6
bb6:
  %t41 = load ptr, ptr %l4, !tbaa !29
  %t44 = getelementptr %"compiler/source:Source", ptr %t41, i32 0, i32 1
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  store { i64, ptr } %t45, ptr %l5, !tbaa !27
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t50 = getelementptr %"compiler/ast:Func", ptr %t48, i32 0, i32 2
  %t51 = load i32, ptr %t50, !tbaa !23
  %t54 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t47, i32 %t51)
  store { i64, ptr } %t54, ptr %l34
  br label %bb7
bb7:
  %t55 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t55, ptr %l6, !tbaa !27
  %t56 = load ptr, ptr %l2, !tbaa !29
  %t58 = getelementptr %"compiler/ast:Func", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = icmp eq ptr %t59, null
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb8, label %bb9
bb8:
  %t65 = load ptr, ptr %l2, !tbaa !29
  %t67 = getelementptr %"compiler/ast:Func", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = icmp eq ptr %t68, null
  br i1 %t70, label %bb10, label %bb11
bb9:
  %t72 = load ptr, ptr %l2, !tbaa !29
  %t74 = getelementptr %"compiler/ast:Func", ptr %t72, i32 0, i32 0
  %t75 = getelementptr %"compiler/source:Span", ptr %t74, i32 0, i32 0
  %t76 = load i32, ptr %t75, !tbaa !23
  %t78 = sext i32 %t76 to i64
  %t80 = add i64 %t78, 2
  store i64 %t80, ptr %l39, !tbaa !24
  br label %bb13
bb10:
  call void @__olang_check_failed(ptr @olang_loc_a9ac84188a5d3ced_8a30b05829c2589)
  unreachable
bb11:
  br label %bb12
bb12:
  %t82 = load ptr, ptr %l2, !tbaa !29
  %t84 = getelementptr %"compiler/ast:Func", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t88 = getelementptr %"compiler/ast:Param", ptr %t85, i32 0, i32 0
  %t89 = getelementptr %"compiler/source:Span", ptr %t88, i32 0, i32 1
  %t90 = load i32, ptr %t89, !tbaa !23
  %t92 = sext i32 %t90 to i64
  store i64 %t92, ptr %l39, !tbaa !24
  br label %bb13
bb13:
  %t94 = load i64, ptr %l39, !tbaa !24
  store i64 %t94, ptr %l7, !tbaa !24
  %t95 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t95, ptr %l53, !tbaa !27
  %t96 = load i64, ptr %l7, !tbaa !24
  store i64 %t96, ptr %l54, !tbaa !24
  %t97 = load ptr, ptr %l2, !tbaa !29
  %t99 = getelementptr %"compiler/ast:Func", ptr %t97, i32 0, i32 0
  %t100 = getelementptr %"compiler/source:Span", ptr %t99, i32 0, i32 1
  %t101 = load i32, ptr %t100, !tbaa !23
  %t103 = sext i32 %t101 to i64
  store i64 %t103, ptr %l57, !tbaa !24
  %t104 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  store i64 %t105, ptr %l58, !tbaa !24
  %t106 = load i64, ptr %l54, !tbaa !24
  %t107 = icmp sge i64 %t106, 0
  br i1 %t107, label %bb14, label %bb15
bb14:
  %t109 = load i64, ptr %l54, !tbaa !24
  %t110 = load i64, ptr %l57, !tbaa !24
  %t111 = icmp sle i64 %t109, %t110
  br i1 %t111, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_d343f6dbe85f33a0_61dfe5c423c7544c)
  unreachable
bb16:
  %t113 = load i64, ptr %l57, !tbaa !24
  %t114 = load i64, ptr %l58, !tbaa !24
  %t115 = icmp sle i64 %t113, %t114
  br i1 %t115, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_d343f6dbe85f33a0_61dfe5c423c7544c)
  unreachable
bb18:
  %t117 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = load i64, ptr %l54, !tbaa !24
  %t120 = load i64, ptr %l57, !tbaa !24
  %t121 = getelementptr i8, ptr %t118, i64 %t119
  %t122 = sub i64 %t120, %t119
  %t123 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t121, 1
  %t125 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t128 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v0, { i64, ptr } %t124, { i64, ptr } %t125)
  %t129 = extractvalue { i32, i64 } %t128, 1
  %t130 = extractvalue { i32, i64 } %t128, 0
  store i32 %t130, ptr %l65
  %t131 = icmp ne i32 %t130, 0
  br i1 %t131, label %bb21, label %ok.132, !prof !99
ok.132:
  store i64 %t129, ptr %l64
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_d343f6dbe85f33a0_61dfe5c423c7544c)
  unreachable
bb20:
  %t133 = load i64, ptr %l64, !tbaa !24
  store i64 %t133, ptr %l52, !tbaa !24
  br label %bb23
bb21:
  br label %bb22
bb22:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l52, !tbaa !24
  br label %bb23
bb23:
  %t134 = load i64, ptr %l52, !tbaa !24
  store i64 %t134, ptr %l8, !tbaa !24
  %t135 = load i64, ptr %l8, !tbaa !24
  %t137 = icmp slt i64 %t135, 0
  br i1 %t137, label %bb24, label %bb25
bb24:
  %t139 = load ptr, ptr %l2, !tbaa !29
  %t141 = getelementptr %"compiler/ast:Func", ptr %t139, i32 0, i32 0
  %t142 = getelementptr %"compiler/source:Span", ptr %t141, i32 0, i32 0
  %t143 = load i32, ptr %t142, !tbaa !23
  %t145 = sext i32 %t143 to i64
  store i64 %t145, ptr %l68, !tbaa !24
  br label %bb26
bb25:
  %t147 = load i64, ptr %l7, !tbaa !24
  %t148 = load i64, ptr %l8, !tbaa !24
  %t151 = add i64 %t147, %t148
  store i64 %t151, ptr %l68, !tbaa !24
  br label %bb26
bb26:
  %t153 = load i64, ptr %l68, !tbaa !24
  store i64 %t153, ptr %l9, !tbaa !24
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/check:Checker", ptr %t154, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = getelementptr %"compiler/generic:Program", ptr %t157, i32 0, i32 0
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t162 = getelementptr %"compiler/load:Loader", ptr %t160, i32 0, i32 10
  %t163 = load i64, ptr %l3, !tbaa !24
  %t166 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t162, i64 %t163)
  store ptr %t166, ptr %l80
  br label %bb27
bb27:
  %t167 = load ptr, ptr %l80, !tbaa !29
  %t169 = getelementptr %"compiler/load:Module", ptr %t167, i32 0, i32 4
  %t170 = load i64, ptr %t169, !tbaa !24
  %t171 = load i64, ptr %l9, !tbaa !24
  %t172 = load i64, ptr %l9, !tbaa !24
  %t173 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t175 = extractvalue { i64, ptr } %t173, 0
  %t178 = add i64 %t172, %t175
  store { i64, [3 x i64] } zeroinitializer, ptr %t179
  %t180 = getelementptr { i64, [3 x i64] }, ptr %t179, i32 0, i32 0
  store i64 3, ptr %t180
  %t182 = insertvalue { i64, i64, i64 } undef, i64 %t170, 0
  %t184 = insertvalue { i64, i64, i64 } %t182, i64 %t171, 1
  %t186 = insertvalue { i64, i64, i64 } %t184, i64 %t178, 2
  %t187 = getelementptr { i64, [3 x i64] }, ptr %t179, i32 0, i32 1
  store { i64, i64, i64 } %t186, ptr %t187
  %t188 = load { i64, [3 x i64] }, ptr %t179
  store { i64, [3 x i64] } %t188, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [3 x i64] }, ptr %rv
  ret { i64, [3 x i64] } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efuncFits(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca i32
  %l16 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca { i64, ptr }
  %l37 = alloca i1
  %l43 = alloca i1
  %l51 = alloca i64
  %l54 = alloca i64
  %l75 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l81 = alloca i1
  %l83 = alloca { i64, ptr }
  %l86 = alloca i1
  %l87 = alloca i1
  %l89 = alloca { i64, ptr }
  %l92 = alloca i1
  %l93 = alloca i1
  %l96 = alloca ptr
  %l98 = alloca { i64, ptr }
  %l101 = alloca i32
  %l103 = alloca { i64, ptr }
  %l106 = alloca i32
  %l107 = alloca i1
  %l113 = alloca { i64, ptr }
  %l116 = alloca i64
  %l120 = alloca i1
  %l124 = alloca { i64, ptr }
  %l127 = alloca i64
  %l138 = alloca i32
  %l143 = alloca i32
  %l147 = alloca i1
  %l151 = alloca i1
  %l154 = alloca ptr
  %l159 = alloca i32
  %l160 = alloca { i64, ptr }
  %l169 = alloca i1
  %l173 = alloca i1
  %l174 = alloca i1
  %l177 = alloca i1
  %l178 = alloca i1
  %l181 = alloca ptr
  %l184 = alloca i32
  %l187 = alloca i32
  %l188 = alloca i1
  %l195 = alloca i64
  %l199 = alloca i1
  %l204 = alloca i64
  %l213 = alloca i32
  %l218 = alloca i32
  %l222 = alloca i1
  %l223 = alloca ptr
  %l228 = alloca i32
  %l233 = alloca i32
  %l234 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l16, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l21
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l16, !tbaa !29
  %t18 = load i32, ptr %l21, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t17, i32 %t18)
  store { i64, ptr } %t19, ptr %l22
  br label %bb2
bb2:
  %t20 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 2
  store ptr %t26, ptr %l25, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/generic:Program", ptr %t30, i32 0, i32 2
  %t33 = load i32, ptr %l2, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t36, ptr %l30
  br label %bb3
bb3:
  %t37 = load ptr, ptr %l25, !tbaa !29
  %t38 = load i32, ptr %l30, !tbaa !23
  %t39 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t37, i32 %t38)
  store { i64, ptr } %t39, ptr %l31
  br label %bb4
bb4:
  %t40 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t40, ptr %l5, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t44 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t49 = icmp ne i64 %t43, %t46
  br i1 %t49, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb8
bb6:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/check:Checker", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/generic:Program", ptr %t54, i32 0, i32 2
  %t57 = load i32, ptr %l1, !tbaa !23
  %t58 = load i32, ptr %l2, !tbaa !23
  %t62 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %t56, i32 %t57, i32 %t58)
  store i1 %t62, ptr %l43
  br label %bb7
bb7:
  %t63 = load i1, ptr %l43, !tbaa !21
  %t64 = xor i1 %t63, true
  store i1 %t64, ptr %l37, !tbaa !21
  br label %bb8
bb8:
  %t66 = load i1, ptr %l37, !tbaa !21
  br i1 %t66, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  store i64 0, ptr %l6, !tbaa !24
  %t68 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t68, 0
  store i64 %t70, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t72 = load i64, ptr %l7, !tbaa !24
  %t73 = load i64, ptr %l6, !tbaa !24
  %t76 = icmp sgt i64 %t72, %t73
  br i1 %t76, label %bb12, label %bb13
bb12:
  %t78 = load i64, ptr %l8, !tbaa !24
  %t80 = icmp sgt i64 %t78, 0
  br i1 %t80, label %bb14, label %bb15
bb13:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb17
bb14:
  %t82 = load i64, ptr %l7, !tbaa !24
  %t83 = load i64, ptr %l6, !tbaa !24
  %t86 = sub i64 %t82, %t83
  %t87 = load i64, ptr %l8, !tbaa !24
  %t90 = add i64 %t86, %t87
  %t92 = sub i64 %t90, 1
  %t93 = load i64, ptr %l8, !tbaa !24
  %t96 = sdiv i64 %t92, %t93
  store i64 %t96, ptr %l54, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb16
bb16:
  %t98 = load i64, ptr %l54, !tbaa !24
  store i64 %t98, ptr %l51, !tbaa !24
  br label %bb17
bb17:
  %t99 = load i64, ptr %l51, !tbaa !24
  store i64 %t99, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb18
bb18:
  %t100 = load i64, ptr %l10, !tbaa !24
  %t101 = load i64, ptr %l9, !tbaa !24
  %t104 = icmp slt i64 %t100, %t101
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb19, label %bb20
bb19:
  br label %bb49
bb20:
  br label %bb21
bb21:
  %t108 = load i64, ptr %l6, !tbaa !24
  %t109 = load i64, ptr %l10, !tbaa !24
  %t110 = load i64, ptr %l8, !tbaa !24
  %t113 = mul i64 %t109, %t110
  %t116 = add i64 %t108, %t113
  store i64 %t116, ptr %l11, !tbaa !24
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/check:Checker", ptr %t118, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t123 = getelementptr %"compiler/generic:Program", ptr %t121, i32 0, i32 2
  %t124 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t124, ptr %l75, !tbaa !27
  %t125 = load i64, ptr %l11, !tbaa !24
  %t127 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = getelementptr i32, ptr %t128, i64 %t125
  %t130 = load i32, ptr %t129, !tbaa !33
  %t131 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t131, ptr %l78, !tbaa !27
  %t132 = load i64, ptr %l11, !tbaa !24
  %t134 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = getelementptr i32, ptr %t135, i64 %t132
  %t137 = load i32, ptr %t136, !tbaa !33
  %t141 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t123, i32 %t130, i32 %t137)
  store i1 %t141, ptr %l81
  br label %bb22
bb22:
  %t142 = load i1, ptr %l81, !tbaa !21
  br i1 %t142, label %bb23, label %bb24
bb23:
  br label %bb48
bb24:
  br label %bb25
bb25:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t144, ptr %l83, !tbaa !27
  %t145 = load i64, ptr %l11, !tbaa !24
  %t147 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = getelementptr i32, ptr %t148, i64 %t145
  %t150 = load i32, ptr %t149, !tbaa !33
  %t153 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t143, i32 %t150)
  store i1 %t153, ptr %l86
  br label %bb26
bb26:
  %t154 = load i1, ptr %l86, !tbaa !21
  br i1 %t154, label %bb27, label %bb28
bb27:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t156, ptr %l89, !tbaa !27
  %t157 = load i64, ptr %l11, !tbaa !24
  %t159 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr i32, ptr %t160, i64 %t157
  %t162 = load i32, ptr %t161, !tbaa !33
  %t165 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t155, i32 %t162)
  store i1 %t165, ptr %l92
  br label %bb29
bb28:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb30
bb29:
  %t166 = load i1, ptr %l92, !tbaa !21
  store i1 %t166, ptr %l87, !tbaa !21
  br label %bb30
bb30:
  %t167 = load i1, ptr %l87, !tbaa !21
  br i1 %t167, label %bb31, label %bb32
bb31:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/check:Checker", ptr %t168, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !29
  %t173 = getelementptr %"compiler/generic:Program", ptr %t171, i32 0, i32 2
  store ptr %t173, ptr %l96, !tbaa !29
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t175, ptr %l98, !tbaa !27
  %t176 = load i64, ptr %l11, !tbaa !24
  %t178 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !27
  %t180 = getelementptr i32, ptr %t179, i64 %t176
  %t181 = load i32, ptr %t180, !tbaa !33
  %t184 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t174, i32 %t181)
  store i32 %t184, ptr %l101
  br label %bb33
bb32:
  store i1 false, ptr %l93, !tbaa !21
  br label %bb36
bb33:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t186, ptr %l103, !tbaa !27
  %t187 = load i64, ptr %l11, !tbaa !24
  %t189 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !27
  %t191 = getelementptr i32, ptr %t190, i64 %t187
  %t192 = load i32, ptr %t191, !tbaa !33
  %t195 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t185, i32 %t192)
  store i32 %t195, ptr %l106
  br label %bb34
bb34:
  %t196 = load ptr, ptr %l96, !tbaa !29
  %t197 = load i32, ptr %l101, !tbaa !23
  %t198 = load i32, ptr %l106, !tbaa !23
  %t199 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t196, i32 %t197, i32 %t198)
  store i1 %t199, ptr %l107
  br label %bb35
bb35:
  %t200 = load i1, ptr %l107, !tbaa !21
  store i1 %t200, ptr %l93, !tbaa !21
  br label %bb36
bb36:
  %t201 = load i1, ptr %l93, !tbaa !21
  %t202 = xor i1 %t201, true
  br i1 %t202, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/check:Checker", ptr %t205, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !29
  %t210 = getelementptr %"compiler/generic:Program", ptr %t208, i32 0, i32 2
  %t211 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t211, ptr %l113, !tbaa !27
  %t212 = load i64, ptr %l11, !tbaa !24
  %t214 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr i32, ptr %t215, i64 %t212
  %t217 = load i32, ptr %t216, !tbaa !33
  %t220 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t210, i32 %t217)
  store i64 %t220, ptr %l116
  br label %bb40
bb40:
  %t221 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t222 = load i64, ptr %l116, !tbaa !24
  %t224 = and i64 %t222, %t221
  %t226 = icmp ne i64 %t224, 0
  br i1 %t226, label %bb41, label %bb42
bb41:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/check:Checker", ptr %t228, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !29
  %t233 = getelementptr %"compiler/generic:Program", ptr %t231, i32 0, i32 2
  %t234 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t234, ptr %l124, !tbaa !27
  %t235 = load i64, ptr %l11, !tbaa !24
  %t237 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t238 = load ptr, ptr %t237, !tbaa !27
  %t239 = getelementptr i32, ptr %t238, i64 %t235
  %t240 = load i32, ptr %t239, !tbaa !33
  %t243 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t233, i32 %t240)
  store i64 %t243, ptr %l127
  br label %bb43
bb42:
  store i1 false, ptr %l120, !tbaa !21
  br label %bb44
bb43:
  %t244 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t245 = load i64, ptr %l127, !tbaa !24
  %t247 = and i64 %t245, %t244
  %t249 = icmp eq i64 %t247, 0
  store i1 %t249, ptr %l120, !tbaa !21
  br label %bb44
bb44:
  %t251 = load i1, ptr %l120, !tbaa !21
  br i1 %t251, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t253 = load i64, ptr %l10, !tbaa !24
  %t255 = add i64 %t253, 1
  store i64 %t255, ptr %l10, !tbaa !24
  br label %bb18
bb49:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/check:Checker", ptr %t257, i32 0, i32 1
  %t260 = load ptr, ptr %t259, !tbaa !29
  %t262 = getelementptr %"compiler/generic:Program", ptr %t260, i32 0, i32 2
  %t263 = load i32, ptr %l1, !tbaa !23
  %t266 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t262, i32 %t263)
  store i32 %t266, ptr %l138
  br label %bb50
bb50:
  %t267 = load i32, ptr %l138, !tbaa !23
  store i32 %t267, ptr %l12, !tbaa !23
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = getelementptr %"compiler/check:Checker", ptr %t268, i32 0, i32 1
  %t271 = load ptr, ptr %t270, !tbaa !29
  %t273 = getelementptr %"compiler/generic:Program", ptr %t271, i32 0, i32 2
  %t274 = load i32, ptr %l2, !tbaa !23
  %t277 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t273, i32 %t274)
  store i32 %t277, ptr %l143
  br label %bb51
bb51:
  %t278 = load i32, ptr %l143, !tbaa !23
  store i32 %t278, ptr %l13, !tbaa !23
  %t279 = load i32, ptr %l12, !tbaa !23
  %t280 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t283 = icmp eq i32 %t279, %t280
  br i1 %t283, label %bb52, label %bb53
bb52:
  %t285 = load i32, ptr %l13, !tbaa !23
  %t286 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t289 = icmp eq i32 %t285, %t286
  store i1 %t289, ptr %l147, !tbaa !21
  br label %bb54
bb53:
  store i1 false, ptr %l147, !tbaa !21
  br label %bb54
bb54:
  %t291 = load i1, ptr %l147, !tbaa !21
  br i1 %t291, label %bb55, label %bb56
bb55:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"compiler/check:Checker", ptr %t292, i32 0, i32 1
  %t295 = load ptr, ptr %t294, !tbaa !29
  %t297 = getelementptr %"compiler/generic:Program", ptr %t295, i32 0, i32 2
  store ptr %t297, ptr %l154, !tbaa !29
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t300 = getelementptr %"compiler/check:Checker", ptr %t298, i32 0, i32 1
  %t301 = load ptr, ptr %t300, !tbaa !29
  %t303 = getelementptr %"compiler/generic:Program", ptr %t301, i32 0, i32 2
  %t304 = load i32, ptr %l2, !tbaa !23
  %t307 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t303, i32 %t304)
  store i32 %t307, ptr %l159
  br label %bb57
bb56:
  store i1 false, ptr %l151, !tbaa !21
  br label %bb59
bb57:
  %t308 = load ptr, ptr %l154, !tbaa !29
  %t309 = load i32, ptr %l159, !tbaa !23
  %t310 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t308, i32 %t309)
  store { i64, ptr } %t310, ptr %l160
  br label %bb58
bb58:
  %t311 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t311, 0
  %t314 = icmp eq i64 %t312, 0
  store i1 %t314, ptr %l151, !tbaa !21
  br label %bb59
bb59:
  %t316 = load i1, ptr %l151, !tbaa !21
  br i1 %t316, label %bb60, label %bb61
bb60:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb61:
  br label %bb62
bb62:
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t320 = getelementptr %"compiler/check:Checker", ptr %t318, i32 0, i32 1
  %t321 = load ptr, ptr %t320, !tbaa !29
  %t323 = getelementptr %"compiler/generic:Program", ptr %t321, i32 0, i32 2
  %t324 = load i32, ptr %l12, !tbaa !23
  %t325 = load i32, ptr %l13, !tbaa !23
  %t329 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t323, i32 %t324, i32 %t325)
  store i1 %t329, ptr %l169
  br label %bb63
bb63:
  %t330 = load i1, ptr %l169, !tbaa !21
  %t331 = xor i1 %t330, true
  br i1 %t331, label %bb64, label %bb65
bb64:
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t334 = load i32, ptr %l12, !tbaa !23
  %t337 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t333, i32 %t334)
  store i1 %t337, ptr %l173
  br label %bb66
bb65:
  br label %bb88
bb66:
  %t338 = load i1, ptr %l173, !tbaa !21
  br i1 %t338, label %bb67, label %bb68
bb67:
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t340 = load i32, ptr %l13, !tbaa !23
  %t343 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t339, i32 %t340)
  store i1 %t343, ptr %l177
  br label %bb69
bb68:
  store i1 false, ptr %l174, !tbaa !21
  br label %bb70
bb69:
  %t344 = load i1, ptr %l177, !tbaa !21
  store i1 %t344, ptr %l174, !tbaa !21
  br label %bb70
bb70:
  %t345 = load i1, ptr %l174, !tbaa !21
  br i1 %t345, label %bb71, label %bb72
bb71:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t348 = getelementptr %"compiler/check:Checker", ptr %t346, i32 0, i32 1
  %t349 = load ptr, ptr %t348, !tbaa !29
  %t351 = getelementptr %"compiler/generic:Program", ptr %t349, i32 0, i32 2
  store ptr %t351, ptr %l181, !tbaa !29
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t353 = load i32, ptr %l12, !tbaa !23
  %t356 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t352, i32 %t353)
  store i32 %t356, ptr %l184
  br label %bb73
bb72:
  store i1 false, ptr %l178, !tbaa !21
  br label %bb76
bb73:
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t358 = load i32, ptr %l13, !tbaa !23
  %t361 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t357, i32 %t358)
  store i32 %t361, ptr %l187
  br label %bb74
bb74:
  %t362 = load ptr, ptr %l181, !tbaa !29
  %t363 = load i32, ptr %l184, !tbaa !23
  %t364 = load i32, ptr %l187, !tbaa !23
  %t365 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t362, i32 %t363, i32 %t364)
  store i1 %t365, ptr %l188
  br label %bb75
bb75:
  %t366 = load i1, ptr %l188, !tbaa !21
  store i1 %t366, ptr %l178, !tbaa !21
  br label %bb76
bb76:
  %t367 = load i1, ptr %l178, !tbaa !21
  %t368 = xor i1 %t367, true
  br i1 %t368, label %bb77, label %bb78
bb77:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb78:
  br label %bb79
bb79:
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t373 = getelementptr %"compiler/check:Checker", ptr %t371, i32 0, i32 1
  %t374 = load ptr, ptr %t373, !tbaa !29
  %t376 = getelementptr %"compiler/generic:Program", ptr %t374, i32 0, i32 2
  %t377 = load i32, ptr %l13, !tbaa !23
  %t380 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t376, i32 %t377)
  store i64 %t380, ptr %l195
  br label %bb80
bb80:
  %t381 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t382 = load i64, ptr %l195, !tbaa !24
  %t384 = and i64 %t382, %t381
  %t386 = icmp ne i64 %t384, 0
  br i1 %t386, label %bb81, label %bb82
bb81:
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t390 = getelementptr %"compiler/check:Checker", ptr %t388, i32 0, i32 1
  %t391 = load ptr, ptr %t390, !tbaa !29
  %t393 = getelementptr %"compiler/generic:Program", ptr %t391, i32 0, i32 2
  %t394 = load i32, ptr %l12, !tbaa !23
  %t397 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t393, i32 %t394)
  store i64 %t397, ptr %l204
  br label %bb83
bb82:
  store i1 false, ptr %l199, !tbaa !21
  br label %bb84
bb83:
  %t398 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t399 = load i64, ptr %l204, !tbaa !24
  %t401 = and i64 %t399, %t398
  %t403 = icmp eq i64 %t401, 0
  store i1 %t403, ptr %l199, !tbaa !21
  br label %bb84
bb84:
  %t405 = load i1, ptr %l199, !tbaa !21
  br i1 %t405, label %bb85, label %bb86
bb85:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb86:
  br label %bb87
bb87:
  br label %bb88
bb88:
  %t407 = load ptr, ptr %l0, !tbaa !29
  %t409 = getelementptr %"compiler/check:Checker", ptr %t407, i32 0, i32 1
  %t410 = load ptr, ptr %t409, !tbaa !29
  %t412 = getelementptr %"compiler/generic:Program", ptr %t410, i32 0, i32 2
  %t413 = load i32, ptr %l1, !tbaa !23
  %t416 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t412, i32 %t413)
  store i32 %t416, ptr %l213
  br label %bb89
bb89:
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t419 = getelementptr %"compiler/check:Checker", ptr %t417, i32 0, i32 1
  %t420 = load ptr, ptr %t419, !tbaa !29
  %t422 = getelementptr %"compiler/generic:Program", ptr %t420, i32 0, i32 2
  %t423 = load i32, ptr %l2, !tbaa !23
  %t426 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t422, i32 %t423)
  store i32 %t426, ptr %l218
  br label %bb90
bb90:
  %t427 = load i32, ptr %l213, !tbaa !23
  %t428 = load i32, ptr %l218, !tbaa !23
  %t429 = icmp eq i32 %t427, %t428
  br i1 %t429, label %bb91, label %bb92
bb91:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb92:
  br label %bb93
bb93:
  br i1 %a3, label %bb94, label %bb95
bb94:
  %t434 = load ptr, ptr %l0, !tbaa !29
  store ptr %t434, ptr %l223, !tbaa !29
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t437 = getelementptr %"compiler/check:Checker", ptr %t435, i32 0, i32 1
  %t438 = load ptr, ptr %t437, !tbaa !29
  %t440 = getelementptr %"compiler/generic:Program", ptr %t438, i32 0, i32 2
  %t441 = load i32, ptr %l2, !tbaa !23
  %t444 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t440, i32 %t441)
  store i32 %t444, ptr %l228
  br label %bb96
bb95:
  store i1 false, ptr %l222, !tbaa !21
  br label %bb99
bb96:
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t447 = getelementptr %"compiler/check:Checker", ptr %t445, i32 0, i32 1
  %t448 = load ptr, ptr %t447, !tbaa !29
  %t450 = getelementptr %"compiler/generic:Program", ptr %t448, i32 0, i32 2
  %t451 = load i32, ptr %l1, !tbaa !23
  %t454 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t450, i32 %t451)
  store i32 %t454, ptr %l233
  br label %bb97
bb97:
  %t455 = load ptr, ptr %l223, !tbaa !29
  %t456 = load i32, ptr %l228, !tbaa !23
  %t457 = load i32, ptr %l233, !tbaa !23
  %t458 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrsCover(ptr %v0, ptr %t455, i32 %t456, i32 %t457)
  store i1 %t458, ptr %l234
  br label %bb98
bb98:
  %t459 = load i1, ptr %l234, !tbaa !21
  store i1 %t459, ptr %l222, !tbaa !21
  br label %bb99
bb99:
  call void @__olang_scope_close(ptr %s0)
  %t460 = load i1, ptr %l222, !tbaa !21
  store i1 %t460, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehandleCallee(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca { i64, [2 x i64] }
  %l6 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i1
  %l19 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l28 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Call", ptr %a1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t7 = load ptr, ptr %l9, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l9, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l10, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { i32 }, ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb19
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 14
  %t24 = load i32, ptr %l3, !tbaa !23
  %t26 = sext i32 %t24 to i64
  %t29 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t23, i64 %t26)
  store ptr %t29, ptr %l19
  br label %bb6
bb6:
  %t30 = load ptr, ptr %l19, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Body", ptr %t30, i32 0, i32 1
  %t34 = load { i64, [2 x i64] }, ptr %t33
  store { i64, [2 x i64] } %t34, ptr %l5
  %t36 = load { i64, [2 x i64] }, ptr %l5
  %t38 = extractvalue { i64, [2 x i64] } %t36, 0
  %t39 = icmp eq i64 %t38, 0
  br i1 %t39, label %bb7, label %bb8
bb7:
  %t41 = getelementptr { i64, [2 x i64] }, ptr %l5, i32 0, i32 1
  %t42 = getelementptr { i64 }, ptr %t41, i32 0, i32 0
  %t43 = load i64, ptr %t42
  store i64 %t43, ptr %l6, !tbaa !24
  br label %bb9
bb8:
  br label %bb13
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l26, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  store ptr %t49, ptr %l28, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t54 = load i64, ptr %l6, !tbaa !24
  %t57 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t53, i64 %t54)
  store i64 %t57, ptr %l32
  br label %bb10
bb10:
  %t58 = load ptr, ptr %l28, !tbaa !29
  %t59 = load i64, ptr %l32, !tbaa !24
  %t60 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s2, ptr %t58, i64 %t59)
  store ptr %t60, ptr %l33
  br label %bb11
bb11:
  %t61 = load ptr, ptr %l33, !tbaa !29
  %t63 = getelementptr %"compiler/ast:Func", ptr %t61, i32 0, i32 2
  %t64 = load i32, ptr %t63, !tbaa !23
  %t65 = load ptr, ptr %l26, !tbaa !29
  %t67 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v2, ptr %t65, i32 %t64)
  store { i64, ptr } %t67, ptr %l36
  br label %bb12
bb12:
  %t68 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t68, ptr %l22, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %l38, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t70, ptr %l22, !tbaa !27
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_b9703f47e3d93663_9ebf3615d73f11ff)
  unreachable
bb18:
  %t72 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 0
  store i64 %t73, ptr %l40, !tbaa !24
  %t74 = load i64, ptr %l40, !tbaa !24
  %t75 = mul i64 %t74, 1
  %t76 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t75)
  %t77 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t76, 1
  store { i64, ptr } %t78, ptr %l41, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = load i64, ptr %l40, !tbaa !24
  %t84 = mul i64 %t83, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t80, ptr %t82, i64 %t84, i1 false)
  %t85 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t85, ptr %l22, !tbaa !27
  %t86 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t86, ptr %rv
  br label %ret
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l42, !tbaa !27
  %t87 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t87, ptr %l43, !tbaa !27
  %t88 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 0
  store i64 %t89, ptr %l44, !tbaa !24
  %t90 = load i64, ptr %l44, !tbaa !24
  %t91 = mul i64 %t90, 1
  %t92 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t91)
  %t93 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  store { i64, ptr } %t94, ptr %l45, !tbaa !27
  %t95 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = load i64, ptr %l44, !tbaa !24
  %t100 = mul i64 %t99, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t96, ptr %t98, i64 %t100, i1 false)
  %t101 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t101, ptr %l43, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t102, ptr %rv
  br label %ret
bb23:
  call void @__olang_check_failed(ptr @olang_loc_1d4c1b6caa485862_a69bc63913ecdbfe)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimportPath(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i1
  %l12 = alloca ptr
  %l14 = alloca ptr
  %l18 = alloca %"compiler/names:Ref"
  %l21 = alloca ptr
  %l22 = alloca i1
  %l29 = alloca ptr
  %l31 = alloca ptr
  %l35 = alloca %"compiler/names:Ref"
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  store ptr %t22, ptr %l12, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t23)
  store ptr %t25, ptr %l14
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l14, !tbaa !29
  %t28 = getelementptr %"compiler/check:frame", ptr %t26, i32 0, i32 2
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t31 = load i32, ptr %t30, !tbaa !23
  %t32 = load ptr, ptr %l12, !tbaa !29
  %t35 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t32, i64 %t29, i32 %t31)
  store %"compiler/names:Ref" %t35, ptr %l18
  br label %bb7
bb7:
  %t36 = getelementptr %"compiler/names:Ref", ptr %l18, i32 0, i32 0
  %t37 = load i32, ptr %t36, !range !{i32 0, i32 9}
  %t39 = trunc i64 5 to i32
  %t40 = icmp eq i32 %t37, %t39
  store i1 %t40, ptr %rv
  br label %ret
bb8:
  %t42 = load ptr, ptr %l1, !tbaa !29
  store ptr %t42, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t43 = load ptr, ptr %l21, !tbaa !29
  %t44 = icmp ne ptr %t43, null
  br i1 %t44, label %bb9, label %bb10
bb9:
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t47 = load i64, ptr %t46, !range !{i64 0, i64 30}
  %t49 = icmp eq i64 %t47, 14
  store i1 %t49, ptr %l22, !tbaa !21
  br label %bb10
bb10:
  %t50 = load i1, ptr %l22, !tbaa !21
  br i1 %t50, label %bb11, label %bb12
bb11:
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr { i64, [4 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t53, i32 0, i32 0
  %t55 = load %"compiler/source:Span", ptr %t54
  store %"compiler/source:Span" %t55, ptr %l3
  br label %bb13
bb12:
  br label %bb16
bb13:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  store ptr %t63, ptr %l29, !tbaa !29
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t64)
  store ptr %t66, ptr %l31
  br label %bb14
bb14:
  %t67 = load ptr, ptr %l31, !tbaa !29
  %t69 = getelementptr %"compiler/check:frame", ptr %t67, i32 0, i32 2
  %t70 = load i64, ptr %t69, !tbaa !24
  %t71 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 1
  %t72 = load i32, ptr %t71, !tbaa !23
  %t73 = load ptr, ptr %l29, !tbaa !29
  %t76 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %t73, i64 %t70, i32 %t72)
  store %"compiler/names:Ref" %t76, ptr %l35
  br label %bb15
bb15:
  %t77 = getelementptr %"compiler/names:Ref", ptr %l35, i32 0, i32 0
  %t78 = load i32, ptr %t77, !range !{i32 0, i32 9}
  %t80 = trunc i64 5 to i32
  %t81 = icmp eq i32 %t78, %t80
  store i1 %t81, ptr %rv
  br label %ret
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i1 false, ptr %rv
  br label %ret
bb20:
  call void @__olang_check_failed(ptr @olang_loc_6c69e074d5382e65_c76aefb5b106fb41)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einWrittenOrder(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca i64
  %l31 = alloca { i64, ptr }
  %l48 = alloca i64
  %l51 = alloca i64
  %l74 = alloca i64
  %l77 = alloca i64
  %l95 = alloca { i64, ptr }
  %l100 = alloca i1
  %l103 = alloca i64
  %l106 = alloca i64
  %l113 = alloca ptr
  %l114 = alloca ptr
  %l115 = alloca i1
  %l119 = alloca %"compiler/source:Span"
  %l120 = alloca ptr
  %l121 = alloca %"compiler/source:Span"
  %l124 = alloca i32
  %l125 = alloca i64
  %l136 = alloca ptr
  %l139 = alloca i64
  %l143 = alloca ptr
  %t213 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 -1, ptr %l3, !tbaa !24
  store i1 true, ptr %l4, !tbaa !21
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l7, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l7, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb12
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t15, ptr %l31, !tbaa !27
  %t16 = load i64, ptr %l6, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i64, ptr %t19, i64 %t16
  %t21 = load i64, ptr %t20, !tbaa !34
  store i64 %t21, ptr %l8, !tbaa !24
  %t23 = load i64, ptr %l8, !tbaa !24
  %t25 = icmp slt i64 %t23, 0
  br i1 %t25, label %bb5, label %bb6
bb5:
  br label %bb11
bb6:
  br label %bb7
bb7:
  %t27 = load i64, ptr %l8, !tbaa !24
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = icmp slt i64 %t27, %t28
  br i1 %t31, label %bb8, label %bb9
bb8:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t33 = load i64, ptr %l8, !tbaa !24
  store i64 %t33, ptr %l3, !tbaa !24
  br label %bb11
bb11:
  %t35 = load i64, ptr %l6, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l6, !tbaa !24
  br label %bb1
bb12:
  %t39 = load i1, ptr %l4, !tbaa !21
  br i1 %t39, label %bb13, label %bb14
bb13:
  br label %ret
bb14:
  br label %bb15
bb15:
  store i64 0, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l3, !tbaa !24
  %t43 = add i64 %t41, 1
  store i64 %t43, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t45 = load i64, ptr %l10, !tbaa !24
  %t46 = load i64, ptr %l9, !tbaa !24
  %t49 = icmp sgt i64 %t45, %t46
  br i1 %t49, label %bb16, label %bb17
bb16:
  %t51 = load i64, ptr %l11, !tbaa !24
  %t53 = icmp sgt i64 %t51, 0
  br i1 %t53, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l48, !tbaa !24
  br label %bb21
bb18:
  %t55 = load i64, ptr %l10, !tbaa !24
  %t56 = load i64, ptr %l9, !tbaa !24
  %t59 = sub i64 %t55, %t56
  %t60 = load i64, ptr %l11, !tbaa !24
  %t63 = add i64 %t59, %t60
  %t65 = sub i64 %t63, 1
  %t66 = load i64, ptr %l11, !tbaa !24
  %t69 = sdiv i64 %t65, %t66
  store i64 %t69, ptr %l51, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb20
bb20:
  %t71 = load i64, ptr %l51, !tbaa !24
  store i64 %t71, ptr %l48, !tbaa !24
  br label %bb21
bb21:
  %t72 = load i64, ptr %l48, !tbaa !24
  store i64 %t72, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb22
bb22:
  %t73 = load i64, ptr %l13, !tbaa !24
  %t74 = load i64, ptr %l12, !tbaa !24
  %t77 = icmp slt i64 %t73, %t74
  %t79 = xor i1 %t77, true
  br i1 %t79, label %bb23, label %bb24
bb23:
  br label %bb64
bb24:
  br label %bb25
bb25:
  %t81 = load i64, ptr %l9, !tbaa !24
  %t82 = load i64, ptr %l13, !tbaa !24
  %t83 = load i64, ptr %l11, !tbaa !24
  %t86 = mul i64 %t82, %t83
  %t89 = add i64 %t81, %t86
  store i64 %t89, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  %t91 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t91, 0
  store i64 %t93, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t95 = load i64, ptr %l16, !tbaa !24
  %t96 = load i64, ptr %l15, !tbaa !24
  %t99 = icmp sgt i64 %t95, %t96
  br i1 %t99, label %bb26, label %bb27
bb26:
  %t101 = load i64, ptr %l17, !tbaa !24
  %t103 = icmp sgt i64 %t101, 0
  br i1 %t103, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb31
bb28:
  %t105 = load i64, ptr %l16, !tbaa !24
  %t106 = load i64, ptr %l15, !tbaa !24
  %t109 = sub i64 %t105, %t106
  %t110 = load i64, ptr %l17, !tbaa !24
  %t113 = add i64 %t109, %t110
  %t115 = sub i64 %t113, 1
  %t116 = load i64, ptr %l17, !tbaa !24
  %t119 = sdiv i64 %t115, %t116
  store i64 %t119, ptr %l77, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l77, !tbaa !24
  br label %bb30
bb30:
  %t121 = load i64, ptr %l77, !tbaa !24
  store i64 %t121, ptr %l74, !tbaa !24
  br label %bb31
bb31:
  %t122 = load i64, ptr %l74, !tbaa !24
  store i64 %t122, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb32
bb32:
  %t123 = load i64, ptr %l19, !tbaa !24
  %t124 = load i64, ptr %l18, !tbaa !24
  %t127 = icmp slt i64 %t123, %t124
  %t129 = xor i1 %t127, true
  br i1 %t129, label %bb33, label %bb34
bb33:
  br label %bb62
bb34:
  br label %bb35
bb35:
  %t131 = load i64, ptr %l15, !tbaa !24
  %t132 = load i64, ptr %l19, !tbaa !24
  %t133 = load i64, ptr %l17, !tbaa !24
  %t136 = mul i64 %t132, %t133
  %t139 = add i64 %t131, %t136
  store i64 %t139, ptr %l20, !tbaa !24
  %t141 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t141, ptr %l95, !tbaa !27
  %t142 = load i64, ptr %l20, !tbaa !24
  %t144 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = getelementptr i64, ptr %t145, i64 %t142
  %t147 = load i64, ptr %t146, !tbaa !34
  %t148 = load i64, ptr %l14, !tbaa !24
  %t151 = icmp ne i64 %t147, %t148
  br i1 %t151, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l100, !tbaa !21
  br label %bb39
bb37:
  %t153 = load i64, ptr %l2, !tbaa !24
  %t154 = load i64, ptr %l20, !tbaa !24
  %t157 = add i64 %t153, %t154
  store i64 %t157, ptr %l103, !tbaa !24
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/check:Checker", ptr %t158, i32 0, i32 36
  %t162 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t160)
  store i64 %t162, ptr %l106
  br label %bb38
bb38:
  %t163 = load i64, ptr %l103, !tbaa !24
  %t164 = load i64, ptr %l106, !tbaa !24
  %t165 = icmp sge i64 %t163, %t164
  store i1 %t165, ptr %l100, !tbaa !21
  br label %bb39
bb39:
  %t167 = load i1, ptr %l100, !tbaa !21
  br i1 %t167, label %bb40, label %bb41
bb40:
  br label %bb61
bb41:
  br label %bb42
bb42:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/check:Checker", ptr %t168, i32 0, i32 36
  %t171 = load i64, ptr %l2, !tbaa !24
  %t172 = load i64, ptr %l20, !tbaa !24
  %t175 = add i64 %t171, %t172
  %t178 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t170, i64 %t175)
  store ptr %t178, ptr %l113
  br label %bb43
bb43:
  %t179 = load ptr, ptr %l113, !tbaa !29
  store ptr %t179, ptr %l21, !tbaa !29
  %t180 = load ptr, ptr %l21, !tbaa !29
  store ptr %t180, ptr %l114, !tbaa !29
  store i1 false, ptr %l115, !tbaa !21
  %t181 = load ptr, ptr %l114, !tbaa !29
  %t182 = icmp ne ptr %t181, null
  br i1 %t182, label %bb44, label %bb45
bb44:
  %t184 = load ptr, ptr %l114, !tbaa !29
  %t185 = load i64, ptr %t184, !range !{i64 0, i64 18}
  %t187 = icmp eq i64 %t185, 0
  store i1 %t187, ptr %l115, !tbaa !21
  br label %bb45
bb45:
  %t188 = load i1, ptr %l115, !tbaa !21
  br i1 %t188, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb61
bb49:
  br i1 true, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_862846f5a5002b51_69e64f75e4a124a5)
  unreachable
bb54:
  %t189 = load ptr, ptr %l21, !tbaa !29
  %t191 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t189)
  store %"compiler/source:Span" %t191, ptr %l119
  br label %bb55
bb55:
  %t192 = load %"compiler/source:Span", ptr %l119
  store %"compiler/source:Span" %t192, ptr %l22
  %t193 = load ptr, ptr %l0, !tbaa !29
  store ptr %t193, ptr %l120, !tbaa !29
  %t194 = load %"compiler/source:Span", ptr %l22
  store %"compiler/source:Span" %t194, ptr %l121
  %t195 = load ptr, ptr %l21, !tbaa !29
  %t198 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t195)
  store i32 %t198, ptr %l124
  br label %bb56
bb56:
  %t199 = load ptr, ptr %l120, !tbaa !29
  %t200 = load %"compiler/source:Span", ptr %l121
  %t201 = load i32, ptr %l124, !tbaa !23
  %t202 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t199, %"compiler/source:Span" %t200, i32 %t201)
  store i64 %t202, ptr %l125
  br label %bb57
bb57:
  %t203 = load i64, ptr %l125, !tbaa !24
  store i64 %t203, ptr %l23, !tbaa !24
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/check:Checker", ptr %t204, i32 0, i32 37
  %t207 = load %"compiler/source:Span", ptr %l22
  %t208 = load i64, ptr %l23, !tbaa !24
  %t210 = trunc i64 %t208 to i32
  %t212 = load ptr, ptr %l21, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t213
  %t214 = getelementptr { i64, [3 x i64] }, ptr %t213, i32 0, i32 0
  store i64 0, ptr %t214
  %t216 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t207, 0
  %t218 = insertvalue { %"compiler/source:Span", i32, ptr } %t216, i32 %t210, 1
  %t220 = insertvalue { %"compiler/source:Span", i32, ptr } %t218, ptr %t212, 2
  %t221 = getelementptr { i64, [3 x i64] }, ptr %t213, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t220, ptr %t221
  %t222 = load { i64, [3 x i64] }, ptr %t213
  %t224 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t222, ptr %t224
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t206, ptr %t224)
  br label %bb58
bb58:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/check:Checker", ptr %t227, i32 0, i32 36
  store ptr %t229, ptr %l136, !tbaa !29
  %t230 = load i64, ptr %l2, !tbaa !24
  %t231 = load i64, ptr %l20, !tbaa !24
  %t234 = add i64 %t230, %t231
  store i64 %t234, ptr %l139, !tbaa !24
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load %"compiler/source:Span", ptr %l22
  %t237 = load i64, ptr %l23, !tbaa !24
  %t241 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t235, %"compiler/source:Span" %t236, i64 %t237)
  store ptr %t241, ptr %l143
  br label %bb59
bb59:
  %t242 = load ptr, ptr %l136, !tbaa !29
  %t243 = load i64, ptr %l139, !tbaa !24
  %t244 = load ptr, ptr %l143, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eSetAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t242, i64 %t243, ptr %t244)
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t245 = load i64, ptr %l19, !tbaa !24
  %t247 = add i64 %t245, 1
  store i64 %t247, ptr %l19, !tbaa !24
  br label %bb32
bb62:
  br label %bb63
bb63:
  %t249 = load i64, ptr %l13, !tbaa !24
  %t251 = add i64 %t249, 1
  store i64 %t251, ptr %l13, !tbaa !24
  br label %bb22
bb64:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eindex(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca %"compiler/check:reflList"
  %l6 = alloca %"compiler/check:reflVal"
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca ptr
  %l19 = alloca i32
  %l26 = alloca ptr
  %l29 = alloca %"compiler/check:reflList"
  %l36 = alloca ptr
  %l40 = alloca %"compiler/check:reflVal"
  %l42 = alloca { i64, ptr }
  %l44 = alloca %"compiler/check:reflVal"
  %l45 = alloca %"compiler/check:reflVal"
  %l48 = alloca ptr
  %l52 = alloca %"compiler/source:Span"
  %l53 = alloca { i64, ptr }
  %l55 = alloca %"compiler/source:Span"
  %l57 = alloca %"compiler/msgs:Msg"
  %l58 = alloca i64
  %l61 = alloca ptr
  %l66 = alloca i32
  %l72 = alloca ptr
  %l76 = alloca ptr
  %l79 = alloca ptr
  %l89 = alloca { i64, ptr }
  %l96 = alloca ptr
  %l101 = alloca ptr
  %l102 = alloca ptr
  %l104 = alloca i32
  %l105 = alloca i32
  %l108 = alloca i32
  %l111 = alloca i1
  %l120 = alloca ptr
  %l127 = alloca ptr
  %l128 = alloca ptr
  %l129 = alloca i32
  %l131 = alloca i64
  %l134 = alloca %"compiler/source:Span"
  %l135 = alloca i64
  %l138 = alloca ptr
  %l139 = alloca %"compiler/source:Span"
  %l140 = alloca %"compiler/source:Span"
  %l141 = alloca i64
  %l145 = alloca ptr
  %l146 = alloca ptr
  %l147 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l154 = alloca ptr
  %l155 = alloca ptr
  %l156 = alloca %"compiler/source:Span"
  %l157 = alloca i32
  %l159 = alloca i32
  %l164 = alloca ptr
  %l170 = alloca ptr
  %l175 = alloca ptr
  %l179 = alloca ptr
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i32 %t5, ptr %l19
  br label %bb1
bb1:
  %t6 = load i32, ptr %l19, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  %t7 = load i32, ptr %l4, !tbaa !23
  %t9 = icmp sge i32 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load %"compiler/source:Span", ptr %l1
  %t13 = load i32, ptr %l4, !tbaa !23
  %t14 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t19 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayLit(ptr %v0, ptr %v2, ptr %v3, ptr %t11, %"compiler/source:Span" %t12, i32 %t13, { i64, ptr } %t14)
  store ptr %t19, ptr %l26
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t20 = load ptr, ptr %l26, !tbaa !29
  store ptr %t20, ptr %rv
  br label %ret
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t25 = call %"compiler/check:reflList" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistOf(ptr %v0, ptr %v1, ptr %t21, ptr %t22)
  store %"compiler/check:reflList" %t25, ptr %l29
  br label %bb6
bb6:
  %t26 = load %"compiler/check:reflList", ptr %l29
  store %"compiler/check:reflList" %t26, ptr %l5
  %t27 = getelementptr %"compiler/check:reflList", ptr %l5, i32 0, i32 0
  %t28 = load i1, ptr %t27, !tbaa !21
  br i1 %t28, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t30 = getelementptr %"compiler/check:reflList", ptr %l5, i32 0, i32 1
  %t31 = load i32, ptr %t30, !tbaa !23
  %t32 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t35 = icmp eq i32 %t31, %t32
  br i1 %t35, label %bb9, label %bb10
bb8:
  br label %bb34
bb9:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load %"compiler/source:Span", ptr %l1
  %t41 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t37, %"compiler/source:Span" %t38)
  store ptr %t41, ptr %l36
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  %t42 = load ptr, ptr %l36, !tbaa !29
  store ptr %t42, ptr %rv
  br label %ret
bb12:
  %t43 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t47 = icmp eq i64 %t45, 1
  br i1 %t47, label %bb13, label %bb14
bb13:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t50, ptr %l42, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr ptr, ptr %t52, i64 0
  %t54 = load ptr, ptr %t53, !tbaa !39
  %t57 = call %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflInt(ptr %v0, ptr %v2, ptr %s2, ptr %t49, ptr %t54)
  store %"compiler/check:reflVal" %t57, ptr %l44
  br label %bb15
bb14:
  %t58 = call %"compiler/check:reflVal" @compiler_2fcheck_2enoRefl(ptr %s2)
  store %"compiler/check:reflVal" %t58, ptr %l45
  br label %bb16
bb15:
  %t59 = load %"compiler/check:reflVal", ptr %l44
  store %"compiler/check:reflVal" %t59, ptr %l40
  br label %bb17
bb16:
  %t60 = load %"compiler/check:reflVal", ptr %l45
  store %"compiler/check:reflVal" %t60, ptr %l40
  br label %bb17
bb17:
  %t61 = load %"compiler/check:reflVal", ptr %l40
  store %"compiler/check:reflVal" %t61, ptr %l6
  %t62 = getelementptr %"compiler/check:reflVal", ptr %l6, i32 0, i32 0
  %t63 = load i1, ptr %t62, !tbaa !21
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l48, !tbaa !29
  %t68 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t72 = icmp sgt i64 %t70, 0
  br i1 %t72, label %bb20, label %bb21
bb19:
  br label %bb27
bb20:
  %t74 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t74, ptr %l53, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr ptr, ptr %t76, i64 0
  %t78 = load ptr, ptr %t77, !tbaa !39
  %t80 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t78)
  store %"compiler/source:Span" %t80, ptr %l55
  br label %bb22
bb21:
  %t81 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t81, ptr %l52
  br label %bb23
bb22:
  %t83 = load %"compiler/source:Span", ptr %l55
  store %"compiler/source:Span" %t83, ptr %l52
  br label %bb23
bb23:
  %t84 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflIndexNotConst(ptr %s4)
  store %"compiler/msgs:Msg" %t84, ptr %l57
  br label %bb24
bb24:
  %t85 = load ptr, ptr %l48, !tbaa !29
  %t86 = load %"compiler/source:Span", ptr %l52
  %t87 = load %"compiler/msgs:Msg", ptr %l57
  %t88 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t85, %"compiler/source:Span" %t86, %"compiler/msgs:Msg" %t87)
  store i64 %t88, ptr %l58
  br label %bb25
bb25:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load %"compiler/source:Span", ptr %l1
  %t93 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t89, %"compiler/source:Span" %t90)
  store ptr %t93, ptr %l61
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  %t94 = load ptr, ptr %l61, !tbaa !29
  store ptr %t94, ptr %rv
  br label %ret
bb27:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load %"compiler/source:Span", ptr %l1
  %t97 = load %"compiler/check:reflList", ptr %l5
  %t98 = getelementptr %"compiler/check:reflVal", ptr %l6, i32 0, i32 2
  %t99 = load i64, ptr %t98, !tbaa !24
  %t104 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistItem(ptr %v0, ptr %t95, %"compiler/source:Span" %t96, %"compiler/check:reflList" %t97, i64 %t99)
  store i32 %t104, ptr %l66
  br label %bb28
bb28:
  %t105 = load i32, ptr %l66, !tbaa !23
  store i32 %t105, ptr %l7, !tbaa !23
  %t106 = load i32, ptr %l7, !tbaa !23
  %t107 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t110 = icmp eq i32 %t106, %t107
  br i1 %t110, label %bb29, label %bb30
bb29:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load %"compiler/source:Span", ptr %l1
  %t116 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t112, %"compiler/source:Span" %t113)
  store ptr %t116, ptr %l72
  br label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_scope_close(ptr %s2)
  %t117 = load ptr, ptr %l72, !tbaa !29
  store ptr %t117, ptr %rv
  br label %ret
bb32:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load %"compiler/source:Span", ptr %l1
  %t120 = load i32, ptr %l7, !tbaa !23
  %t124 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %v3, ptr %t118, %"compiler/source:Span" %t119, i32 %t120)
  store ptr %t124, ptr %l76
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s2)
  %t125 = load ptr, ptr %l76, !tbaa !29
  store ptr %t125, ptr %rv
  br label %ret
bb34:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load ptr, ptr %l2, !tbaa !29
  %t130 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %v3, ptr %t126, ptr %t127)
  store ptr %t130, ptr %l79
  br label %bb35
bb35:
  %t131 = load ptr, ptr %l79, !tbaa !29
  store ptr %t131, ptr %l8, !tbaa !29
  %t132 = load ptr, ptr %l8, !tbaa !29
  %t134 = icmp eq ptr %t132, null
  br i1 %t134, label %bb36, label %bb37
bb36:
  %t136 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t136, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t138 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t138, 0
  store i64 %t140, ptr %l11, !tbaa !24
  br label %bb38
bb37:
  br label %bb46
bb38:
  %t142 = load i64, ptr %l10, !tbaa !24
  %t143 = load i64, ptr %l11, !tbaa !24
  %t146 = icmp slt i64 %t142, %t143
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb39, label %bb40
bb39:
  br label %bb44
bb40:
  br label %bb41
bb41:
  %t150 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t150, ptr %l89, !tbaa !27
  %t151 = load i64, ptr %l10, !tbaa !24
  %t153 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr ptr, ptr %t154, i64 %t151
  %t156 = load ptr, ptr %t155, !tbaa !39
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t161 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t165 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %v0, ptr %t158, ptr %t156, i32 %t161)
  store ptr %t165, ptr %l96
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t166 = load i64, ptr %l10, !tbaa !24
  %t168 = add i64 %t166, 1
  store i64 %t168, ptr %l10, !tbaa !24
  br label %bb38
bb44:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load %"compiler/source:Span", ptr %l1
  %t174 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t170, %"compiler/source:Span" %t171)
  store ptr %t174, ptr %l101
  br label %bb45
bb45:
  %t175 = load ptr, ptr %l101, !tbaa !29
  store ptr %t175, ptr %rv
  br label %ret
bb46:
  %t176 = load ptr, ptr %l0, !tbaa !29
  store ptr %t176, ptr %l102, !tbaa !29
  %t177 = load ptr, ptr %l8, !tbaa !29
  %t179 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v3, ptr %t177)
  store i32 %t179, ptr %l104
  br label %bb47
bb47:
  %t180 = load ptr, ptr %l102, !tbaa !29
  %t181 = load i32, ptr %l104, !tbaa !23
  %t182 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t180, i32 %t181)
  store i32 %t182, ptr %l105
  br label %bb48
bb48:
  %t183 = load i32, ptr %l105, !tbaa !23
  store i32 %t183, ptr %l13, !tbaa !23
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t185 = load i32, ptr %l13, !tbaa !23
  %t188 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t184, i32 %t185)
  store i32 %t188, ptr %l108
  br label %bb49
bb49:
  %t189 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t190 = load i32, ptr %l108, !tbaa !23
  %t192 = icmp eq i32 %t190, %t189
  br i1 %t192, label %bb50, label %bb51
bb50:
  %t194 = load i32, ptr %l13, !tbaa !23
  %t195 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t198 = icmp ne i32 %t194, %t195
  store i1 %t198, ptr %l111, !tbaa !21
  br label %bb52
bb51:
  store i1 false, ptr %l111, !tbaa !21
  br label %bb52
bb52:
  %t200 = load i1, ptr %l111, !tbaa !21
  br i1 %t200, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s10
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load %"compiler/source:Span", ptr %l1
  %t203 = load ptr, ptr %l8, !tbaa !29
  %t204 = load i32, ptr %l13, !tbaa !23
  %t205 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t211 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueElem(ptr %v0, ptr %v3, ptr %v2, ptr %v3, ptr %t201, %"compiler/source:Span" %t202, ptr %t203, i32 %t204, { i64, ptr } %t205)
  store ptr %t211, ptr %l120
  br label %bb55
bb54:
  br label %bb78
bb55:
  %t212 = load ptr, ptr %l120, !tbaa !29
  store ptr %t212, ptr %l14, !tbaa !29
  %t213 = load ptr, ptr %l14, !tbaa !29
  %t215 = icmp eq ptr %t213, null
  %t217 = xor i1 %t215, true
  br i1 %t217, label %bb56, label %bb57
bb56:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load %"compiler/source:Span", ptr %l1
  %t221 = load ptr, ptr %l14, !tbaa !29
  %t225 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v3, ptr %v3, ptr %t219, %"compiler/source:Span" %t220, ptr %t221)
  store ptr %t225, ptr %l127
  br label %bb58
bb57:
  br label %bb59
bb58:
  call void @__olang_scope_close(ptr %s10)
  %t226 = load ptr, ptr %l127, !tbaa !29
  store ptr %t226, ptr %rv
  br label %ret
bb59:
  %t227 = load ptr, ptr %l0, !tbaa !29
  store ptr %t227, ptr %l128, !tbaa !29
  %t228 = load i32, ptr %l13, !tbaa !23
  store i32 %t228, ptr %l129, !tbaa !23
  %t229 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t231 = extractvalue { i64, ptr } %t229, 0
  store i64 %t231, ptr %l131, !tbaa !24
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load %"compiler/source:Span", ptr %l1
  %t236 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebracketIn(ptr %v0, ptr %t232, %"compiler/source:Span" %t233)
  store %"compiler/source:Span" %t236, ptr %l134
  br label %bb60
bb60:
  %t237 = load ptr, ptr %l128, !tbaa !29
  %t238 = load i32, ptr %l129, !tbaa !23
  %t239 = load i64, ptr %l131, !tbaa !24
  %t240 = load %"compiler/source:Span", ptr %l134
  %t241 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %s10, ptr %s10, ptr %t237, i32 %t238, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d8, i32 0, i32 1) }, i64 %t239, %"compiler/source:Span" %t240, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store i64 %t241, ptr %l135
  br label %bb61
bb61:
  %t242 = load i64, ptr %l135, !tbaa !24
  store i64 %t242, ptr %l15, !tbaa !24
  %t243 = load i64, ptr %l15, !tbaa !24
  %t245 = icmp sge i64 %t243, 0
  br i1 %t245, label %bb62, label %bb63
bb62:
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l138, !tbaa !29
  %t248 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t248, ptr %l139
  %t249 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t249, ptr %l140
  %t250 = load i64, ptr %l15, !tbaa !24
  store i64 %t250, ptr %l141, !tbaa !24
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t252 = load %"compiler/source:Span", ptr %l1
  %t253 = load ptr, ptr %l8, !tbaa !29
  %t257 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v3, ptr %v0, ptr %t251, %"compiler/source:Span" %t252, ptr %t253)
  store ptr %t257, ptr %l145
  br label %bb64
bb63:
  br label %bb74
bb64:
  %t258 = load ptr, ptr %l145, !tbaa !29
  store ptr %t258, ptr %l146, !tbaa !29
  %t259 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t259, ptr %l147, !tbaa !27
  %t260 = icmp sge i64 0, 0
  br i1 %t260, label %bb65, label %bb66
bb65:
  %t262 = icmp sle i64 0, 1152921504606846975
  br i1 %t262, label %bb67, label %bb68
bb66:
  call void @__olang_check_failed(ptr @olang_loc_23e55da1d35c3b26_9d147ecacbf30ffa)
  unreachable
bb67:
  %t264 = mul i64 0, 8
  %t265 = insertvalue { i64, ptr } undef, i64 0, 0
  %t266 = insertvalue { i64, ptr } %t265, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t266, ptr %l150, !tbaa !27
  %t267 = icmp sge i64 0, 0
  br i1 %t267, label %bb69, label %bb70
bb68:
  call void @__olang_check_failed(ptr @olang_loc_23e55da1d35c3b26_9d147ecacbf30ffa)
  unreachable
bb69:
  %t269 = icmp sle i64 0, 2305843009213693951
  br i1 %t269, label %bb71, label %bb72
bb70:
  call void @__olang_check_failed(ptr @olang_loc_2136f99ca1795ebb_470e73d5134ce74f)
  unreachable
bb71:
  %t271 = mul i64 0, 4
  %t272 = insertvalue { i64, ptr } undef, i64 0, 0
  %t273 = insertvalue { i64, ptr } %t272, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t274 = load ptr, ptr %l138, !tbaa !29
  %t275 = load %"compiler/source:Span", ptr %l139
  %t276 = load %"compiler/source:Span", ptr %l140
  %t277 = load i64, ptr %l141, !tbaa !24
  %t278 = load ptr, ptr %l146, !tbaa !29
  %t279 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t280 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t282 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %v2, ptr %v0, ptr %v3, ptr %v3, ptr %t274, %"compiler/source:Span" %t275, %"compiler/source:Span" %t276, i64 %t277, ptr %t278, { i64, ptr } %t279, { i64, ptr } %t280, { i64, ptr } %t273)
  store ptr %t282, ptr %l154
  br label %bb73
bb72:
  call void @__olang_check_failed(ptr @olang_loc_2136f99ca1795ebb_470e73d5134ce74f)
  unreachable
bb73:
  call void @__olang_scope_close(ptr %s10)
  %t283 = load ptr, ptr %l154, !tbaa !29
  store ptr %t283, ptr %rv
  br label %ret
bb74:
  %t284 = load ptr, ptr %l0, !tbaa !29
  store ptr %t284, ptr %l155, !tbaa !29
  %t285 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t285, ptr %l156
  %t286 = load i32, ptr %l13, !tbaa !23
  store i32 %t286, ptr %l157, !tbaa !23
  %t287 = load ptr, ptr %l8, !tbaa !29
  %t289 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v3, ptr %t287)
  store i32 %t289, ptr %l159
  br label %bb75
bb75:
  %t290 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t292 = extractvalue { i64, ptr } %t290, 0
  %t293 = load ptr, ptr %l155, !tbaa !29
  %t294 = load %"compiler/source:Span", ptr %l156
  %t295 = load i32, ptr %l157, !tbaa !23
  %t296 = load i32, ptr %l159, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoIndex(ptr %v0, ptr %t293, %"compiler/source:Span" %t294, i32 %t295, i32 %t296, i64 %t292)
  br label %bb76
bb76:
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t299 = load %"compiler/source:Span", ptr %l1
  %t302 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t298, %"compiler/source:Span" %t299)
  store ptr %t302, ptr %l164
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s10)
  %t303 = load ptr, ptr %l164, !tbaa !29
  store ptr %t303, ptr %rv
  br label %ret
bb78:
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t305 = load %"compiler/source:Span", ptr %l1
  %t306 = load ptr, ptr %l8, !tbaa !29
  %t307 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t313 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelemPlace(ptr %v0, ptr %v3, ptr %v2, ptr %v3, ptr %t304, %"compiler/source:Span" %t305, ptr %t306, { i64, ptr } %t307, i32 0)
  store ptr %t313, ptr %l170
  br label %bb79
bb79:
  %t314 = load ptr, ptr %l170, !tbaa !29
  store ptr %t314, ptr %l16, !tbaa !29
  %t315 = load ptr, ptr %l16, !tbaa !29
  %t317 = icmp eq ptr %t315, null
  br i1 %t317, label %bb80, label %bb81
bb80:
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t320 = load %"compiler/source:Span", ptr %l1
  %t323 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t319, %"compiler/source:Span" %t320)
  store ptr %t323, ptr %l175
  br label %bb82
bb81:
  br label %bb83
bb82:
  %t324 = load ptr, ptr %l175, !tbaa !29
  store ptr %t324, ptr %rv
  br label %ret
bb83:
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t326 = load %"compiler/source:Span", ptr %l1
  %t327 = load ptr, ptr %l16, !tbaa !29
  %t331 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v3, ptr %v3, ptr %t325, %"compiler/source:Span" %t326, ptr %t327)
  store ptr %t331, ptr %l179
  br label %bb84
bb84:
  %t332 = load ptr, ptr %l179, !tbaa !29
  store ptr %t332, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesMet(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l6 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t7 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesIn(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i64 0)
  store i1 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load i1, ptr %l6, !tbaa !21
  store i1 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaidAlike(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l10 = alloca i1
  %l14 = alloca i32
  %l17 = alloca i32
  %l22 = alloca i32
  %l26 = alloca i1
  %l31 = alloca i32
  %l38 = alloca i1
  %l43 = alloca i32
  %l48 = alloca i32
  %l50 = alloca i1
  %l51 = alloca ptr
  %l56 = alloca i32
  %l61 = alloca i32
  %l62 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t8 = load i32, ptr %l2, !tbaa !23
  %t12 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t6, i32 %t7, i32 %t8)
  store i1 %t12, ptr %l10
  br label %bb1
bb1:
  %t13 = load i1, ptr %l10, !tbaa !21
  br i1 %t13, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l1, !tbaa !23
  %t19 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t19, ptr %l14
  br label %bb5
bb5:
  %t20 = load i32, ptr %l14, !tbaa !23
  store i32 %t20, ptr %l3, !tbaa !23
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l17
  br label %bb6
bb6:
  %t26 = load i32, ptr %l17, !tbaa !23
  store i32 %t26, ptr %l4, !tbaa !23
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/generic:Program", ptr %t30, i32 0, i32 2
  %t33 = load i32, ptr %l3, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t36, ptr %l22
  br label %bb7
bb7:
  %t37 = load i32, ptr %l22, !range !{i32 0, i32 33}
  %t39 = trunc i64 19 to i32
  %t40 = icmp eq i32 %t37, %t39
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb11
bb9:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  %t50 = load i32, ptr %l4, !tbaa !23
  %t53 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t53, ptr %l31
  br label %bb10
bb10:
  %t54 = load i32, ptr %l31, !range !{i32 0, i32 33}
  %t56 = trunc i64 19 to i32
  %t57 = icmp eq i32 %t54, %t56
  %t59 = xor i1 %t57, true
  store i1 %t59, ptr %l26, !tbaa !21
  br label %bb11
bb11:
  %t61 = load i1, ptr %l26, !tbaa !21
  br i1 %t61, label %bb12, label %bb13
bb12:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i32, ptr %l1, !tbaa !23
  %t64 = load i32, ptr %l2, !tbaa !23
  %t68 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esameRepr(ptr %v0, ptr %t62, i32 %t63, i32 %t64)
  store i1 %t68, ptr %l38
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t69 = load i1, ptr %l38, !tbaa !21
  store i1 %t69, ptr %rv
  br label %ret
bb15:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/check:Checker", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/generic:Program", ptr %t73, i32 0, i32 2
  %t76 = load i32, ptr %l3, !tbaa !23
  %t79 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t75, i32 %t76)
  store i32 %t79, ptr %l43
  br label %bb16
bb16:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/check:Checker", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = getelementptr %"compiler/generic:Program", ptr %t83, i32 0, i32 2
  %t86 = load i32, ptr %l4, !tbaa !23
  %t89 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t85, i32 %t86)
  store i32 %t89, ptr %l48
  br label %bb17
bb17:
  %t90 = load i32, ptr %l43, !tbaa !23
  %t91 = load i32, ptr %l48, !tbaa !23
  %t92 = icmp eq i32 %t90, %t91
  br i1 %t92, label %bb18, label %bb19
bb18:
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l51, !tbaa !29
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/check:Checker", ptr %t95, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t100 = getelementptr %"compiler/generic:Program", ptr %t98, i32 0, i32 2
  %t101 = load i32, ptr %l3, !tbaa !23
  %t104 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t100, i32 %t101)
  store i32 %t104, ptr %l56
  br label %bb20
bb19:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb23
bb20:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/check:Checker", ptr %t105, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = getelementptr %"compiler/generic:Program", ptr %t108, i32 0, i32 2
  %t111 = load i32, ptr %l4, !tbaa !23
  %t114 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t110, i32 %t111)
  store i32 %t114, ptr %l61
  br label %bb21
bb21:
  %t115 = load ptr, ptr %l51, !tbaa !29
  %t116 = load i32, ptr %l56, !tbaa !23
  %t117 = load i32, ptr %l61, !tbaa !23
  %t118 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaidAlike(ptr %v0, ptr %t115, i32 %t116, i32 %t117)
  store i1 %t118, ptr %l62
  br label %bb22
bb22:
  %t119 = load i1, ptr %l62, !tbaa !21
  store i1 %t119, ptr %l50, !tbaa !21
  br label %bb23
bb23:
  %t120 = load i1, ptr %l50, !tbaa !21
  store i1 %t120, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elentAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i64
  %l15 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:LocalUses", ptr %a1, i32 0, i32 12
  store ptr %t3, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l4, !tbaa !24
  store i64 %t5, ptr %l8, !tbaa !24
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t6)
  store i64 %t8, ptr %l10
  br label %bb2
bb2:
  %t9 = load i64, ptr %l8, !tbaa !24
  %t10 = load i64, ptr %l10, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l3, !tbaa !29
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t15, i64 %t16)
  store i64 %t19, ptr %l15
  br label %bb6
bb6:
  %t20 = load i64, ptr %l15, !tbaa !24
  %t25 = icmp eq i64 %t20, %a2
  br i1 %t25, label %bb7, label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t28 = load i64, ptr %l4, !tbaa !24
  %t30 = add i64 %t28, 1
  store i64 %t30, ptr %l4, !tbaa !24
  br label %bb1
bb11:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsWritable(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l11 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l23 = alloca i1
  %l28 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t6, i32 %a1)
  store { i64, ptr } %t10, ptr %l11
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t16 = load i64, ptr %l4, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb3, label %bb4
bb3:
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t24, ptr %l18, !tbaa !27
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i32, ptr %t28, i64 %t25
  %t30 = load i32, ptr %t29, !tbaa !33
  store i32 %t30, ptr %l6, !tbaa !23
  %t32 = load i32, ptr %l6, !tbaa !23
  %t34 = icmp ne i32 %t32, 0
  br i1 %t34, label %bb6, label %bb7
bb6:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l6, !tbaa !23
  %t40 = add i64 %a2, 1
  %t44 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritableAt(ptr %v0, ptr %t36, i32 %t37, i64 %t40)
  store i1 %t44, ptr %l28
  br label %bb8
bb7:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb9
bb8:
  %t45 = load i1, ptr %l28, !tbaa !21
  store i1 %t45, ptr %l23, !tbaa !21
  br label %bb9
bb9:
  %t46 = load i1, ptr %l23, !tbaa !21
  br i1 %t46, label %bb10, label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t48 = load i64, ptr %l4, !tbaa !24
  %t50 = add i64 %t48, 1
  store i64 %t50, ptr %l4, !tbaa !24
  br label %bb2
bb14:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i1
  %l21 = alloca %"compiler/source:Span"
  %l27 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l45 = alloca i1
  %l46 = alloca i1
  %l48 = alloca i1
  %l49 = alloca i1
  %l51 = alloca i1
  %l53 = alloca i1
  %l54 = alloca i64
  %l60 = alloca ptr
  %l78 = alloca i64
  %l81 = alloca i64
  %l104 = alloca { i64, ptr }
  %l113 = alloca ptr
  %l133 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, [3 x i64] }
  %t10 = alloca { i64, [3 x i64] }, align 8
  %t129 = alloca { i64, [3 x i64] }, align 8
  %t245 = alloca { i64, [3 x i64] }, align 8
  %t285 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = icmp slt i64 %t5, 0
  store i1 %t7, ptr %l16, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l16, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store { i64, [3 x i64] } zeroinitializer, ptr %t10
  %t11 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 0
  store i64 0, ptr %t11
  %t12 = load { i64, [3 x i64] }, ptr %t10
  call void @__olang_scope_close(ptr %s0)
  store { i64, [3 x i64] } %t12, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t14)
  store %"compiler/source:Span" %t16, ptr %l21
  br label %bb7
bb7:
  %t17 = load %"compiler/source:Span", ptr %l21
  store %"compiler/source:Span" %t17, ptr %l3
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/load:Loader", ptr %t24, i32 0, i32 10
  %t27 = load i64, ptr %l1, !tbaa !24
  %t30 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t26, i64 %t27)
  store ptr %t30, ptr %l27
  br label %bb8
bb8:
  %t31 = load ptr, ptr %l27, !tbaa !29
  %t33 = getelementptr %"compiler/load:Module", ptr %t31, i32 0, i32 6
  %t34 = load ptr, ptr %t33, !tbaa !29
  store ptr %t34, ptr %l4, !tbaa !29
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t38 = icmp eq ptr %t36, null
  br i1 %t38, label %bb9, label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_9eba0537152ec68c_48ed4257e6d07438)
  unreachable
bb10:
  br label %bb11
bb11:
  %t40 = load ptr, ptr %l4, !tbaa !29
  %t43 = getelementptr %"compiler/source:Source", ptr %t40, i32 0, i32 1
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  store { i64, ptr } %t44, ptr %l34, !tbaa !27
  %t45 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t46 = load i32, ptr %t45, !tbaa !23
  %t48 = sext i32 %t46 to i64
  store i64 %t48, ptr %l36, !tbaa !24
  %t49 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 1
  %t50 = load i32, ptr %t49, !tbaa !23
  %t52 = sext i32 %t50 to i64
  store i64 %t52, ptr %l38, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 0
  store i64 %t54, ptr %l39, !tbaa !24
  %t55 = load i64, ptr %l36, !tbaa !24
  %t56 = icmp sge i64 %t55, 0
  br i1 %t56, label %bb12, label %bb13
bb12:
  %t58 = load i64, ptr %l36, !tbaa !24
  %t59 = load i64, ptr %l38, !tbaa !24
  %t60 = icmp sle i64 %t58, %t59
  br i1 %t60, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_cd7c953a3f1af3d1_dcd21a8e35cf56dd)
  unreachable
bb14:
  %t62 = load i64, ptr %l38, !tbaa !24
  %t63 = load i64, ptr %l39, !tbaa !24
  %t64 = icmp sle i64 %t62, %t63
  br i1 %t64, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_cd7c953a3f1af3d1_dcd21a8e35cf56dd)
  unreachable
bb16:
  %t66 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = load i64, ptr %l38, !tbaa !24
  %t70 = getelementptr i8, ptr %t67, i64 %t68
  %t71 = sub i64 %t69, %t68
  %t72 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t70, 1
  store { i64, ptr } %t73, ptr %l5, !tbaa !27
  %t75 = load ptr, ptr %l2, !tbaa !29
  %t77 = call i1 @compiler_2fcheck_2erefWrittenTop(ptr %v1, ptr %t75)
  store i1 %t77, ptr %l45
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_cd7c953a3f1af3d1_dcd21a8e35cf56dd)
  unreachable
bb18:
  %t78 = load i1, ptr %l45, !tbaa !21
  br i1 %t78, label %bb19, label %bb20
bb19:
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t81 = call i1 @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eIsFunc(ptr %v1, ptr %t79)
  store i1 %t81, ptr %l48
  br label %bb21
bb20:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb22
bb21:
  %t82 = load i1, ptr %l48, !tbaa !21
  store i1 %t82, ptr %l46, !tbaa !21
  br label %bb22
bb22:
  %t83 = load i1, ptr %l46, !tbaa !21
  br i1 %t83, label %bb23, label %bb24
bb23:
  %t84 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t86 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t84, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i1 %t86, ptr %l51
  br label %bb25
bb24:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb26
bb25:
  %t87 = load i1, ptr %l51, !tbaa !21
  store i1 %t87, ptr %l49, !tbaa !21
  br label %bb26
bb26:
  %t88 = load i1, ptr %l49, !tbaa !21
  br i1 %t88, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s2
  %t89 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t91 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t89, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i1 %t91, ptr %l53
  br label %bb29
bb28:
  br label %bb34
bb29:
  %t92 = load i1, ptr %l53, !tbaa !21
  br i1 %t92, label %bb30, label %bb31
bb30:
  store i64 3, ptr %l54, !tbaa !24
  br label %bb32
bb31:
  store i64 2, ptr %l54, !tbaa !24
  br label %bb32
bb32:
  %t93 = load i64, ptr %l54, !tbaa !24
  store i64 %t93, ptr %l6, !tbaa !24
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t99 = getelementptr %"compiler/generic:Program", ptr %t97, i32 0, i32 0
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/load:Loader", ptr %t100, i32 0, i32 10
  %t103 = load i64, ptr %l1, !tbaa !24
  %t106 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t102, i64 %t103)
  store ptr %t106, ptr %l60
  br label %bb33
bb33:
  %t107 = load ptr, ptr %l60, !tbaa !29
  %t109 = getelementptr %"compiler/load:Module", ptr %t107, i32 0, i32 4
  %t110 = load i64, ptr %t109, !tbaa !24
  %t111 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t112 = load i32, ptr %t111, !tbaa !23
  %t114 = sext i32 %t112 to i64
  %t115 = load i64, ptr %l6, !tbaa !24
  %t118 = add i64 %t114, %t115
  %t119 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t120 = load i32, ptr %t119, !tbaa !23
  %t122 = sext i32 %t120 to i64
  %t123 = load i64, ptr %l6, !tbaa !24
  %t126 = add i64 %t122, %t123
  %t128 = add i64 %t126, 1
  store { i64, [3 x i64] } zeroinitializer, ptr %t129
  %t130 = getelementptr { i64, [3 x i64] }, ptr %t129, i32 0, i32 0
  store i64 3, ptr %t130
  %t132 = insertvalue { i64, i64, i64 } undef, i64 %t110, 0
  %t134 = insertvalue { i64, i64, i64 } %t132, i64 %t118, 1
  %t136 = insertvalue { i64, i64, i64 } %t134, i64 %t128, 2
  %t137 = getelementptr { i64, [3 x i64] }, ptr %t129, i32 0, i32 1
  store { i64, i64, i64 } %t136, ptr %t137
  %t138 = load { i64, [3 x i64] }, ptr %t129
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store { i64, [3 x i64] } %t138, ptr %rv
  br label %ret
bb34:
  store i64 0, ptr %l7, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t140, 0
  store i64 %t142, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t144 = load i64, ptr %l8, !tbaa !24
  %t145 = load i64, ptr %l7, !tbaa !24
  %t148 = icmp sgt i64 %t144, %t145
  br i1 %t148, label %bb35, label %bb36
bb35:
  %t150 = load i64, ptr %l9, !tbaa !24
  %t152 = icmp sgt i64 %t150, 0
  br i1 %t152, label %bb37, label %bb38
bb36:
  store i64 0, ptr %l78, !tbaa !24
  br label %bb40
bb37:
  %t154 = load i64, ptr %l8, !tbaa !24
  %t155 = load i64, ptr %l7, !tbaa !24
  %t158 = sub i64 %t154, %t155
  %t159 = load i64, ptr %l9, !tbaa !24
  %t162 = add i64 %t158, %t159
  %t164 = sub i64 %t162, 1
  %t165 = load i64, ptr %l9, !tbaa !24
  %t168 = sdiv i64 %t164, %t165
  store i64 %t168, ptr %l81, !tbaa !24
  br label %bb39
bb38:
  store i64 0, ptr %l81, !tbaa !24
  br label %bb39
bb39:
  %t170 = load i64, ptr %l81, !tbaa !24
  store i64 %t170, ptr %l78, !tbaa !24
  br label %bb40
bb40:
  %t171 = load i64, ptr %l78, !tbaa !24
  store i64 %t171, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb41
bb41:
  %t172 = load i64, ptr %l11, !tbaa !24
  %t173 = load i64, ptr %l10, !tbaa !24
  %t176 = icmp slt i64 %t172, %t173
  %t178 = xor i1 %t176, true
  br i1 %t178, label %bb42, label %bb43
bb42:
  br label %bb50
bb43:
  br label %bb44
bb44:
  %t180 = load i64, ptr %l7, !tbaa !24
  %t181 = load i64, ptr %l11, !tbaa !24
  %t182 = load i64, ptr %l9, !tbaa !24
  %t185 = mul i64 %t181, %t182
  %t188 = add i64 %t180, %t185
  %t190 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t190, 0
  %t194 = sub i64 %t192, 1
  %t198 = sub i64 %t194, %t188
  store i64 %t198, ptr %l13, !tbaa !24
  %t200 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t200, ptr %l104, !tbaa !27
  %t201 = load i64, ptr %l13, !tbaa !24
  %t203 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !27
  %t205 = getelementptr i8, ptr %t204, i64 %t201
  %t206 = load i8, ptr %t205, !tbaa !32
  %t208 = icmp eq i8 %t206, 38
  br i1 %t208, label %bb45, label %bb46
bb45:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t212 = getelementptr %"compiler/check:Checker", ptr %t210, i32 0, i32 1
  %t213 = load ptr, ptr %t212, !tbaa !29
  %t215 = getelementptr %"compiler/generic:Program", ptr %t213, i32 0, i32 0
  %t216 = load ptr, ptr %t215, !tbaa !29
  %t218 = getelementptr %"compiler/load:Loader", ptr %t216, i32 0, i32 10
  %t219 = load i64, ptr %l1, !tbaa !24
  %t222 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t218, i64 %t219)
  store ptr %t222, ptr %l113
  br label %bb47
bb46:
  br label %bb48
bb47:
  %t223 = load ptr, ptr %l113, !tbaa !29
  %t225 = getelementptr %"compiler/load:Module", ptr %t223, i32 0, i32 4
  %t226 = load i64, ptr %t225, !tbaa !24
  %t227 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t228 = load i32, ptr %t227, !tbaa !23
  %t230 = sext i32 %t228 to i64
  %t231 = load i64, ptr %l13, !tbaa !24
  %t234 = add i64 %t230, %t231
  %t235 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t236 = load i32, ptr %t235, !tbaa !23
  %t238 = sext i32 %t236 to i64
  %t239 = load i64, ptr %l13, !tbaa !24
  %t242 = add i64 %t238, %t239
  %t244 = add i64 %t242, 1
  store { i64, [3 x i64] } zeroinitializer, ptr %t245
  %t246 = getelementptr { i64, [3 x i64] }, ptr %t245, i32 0, i32 0
  store i64 3, ptr %t246
  %t248 = insertvalue { i64, i64, i64 } undef, i64 %t226, 0
  %t250 = insertvalue { i64, i64, i64 } %t248, i64 %t234, 1
  %t252 = insertvalue { i64, i64, i64 } %t250, i64 %t244, 2
  %t253 = getelementptr { i64, [3 x i64] }, ptr %t245, i32 0, i32 1
  store { i64, i64, i64 } %t252, ptr %t253
  %t254 = load { i64, [3 x i64] }, ptr %t245
  call void @__olang_scope_close(ptr %s0)
  store { i64, [3 x i64] } %t254, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  %t256 = load i64, ptr %l11, !tbaa !24
  %t258 = add i64 %t256, 1
  store i64 %t258, ptr %l11, !tbaa !24
  br label %bb41
bb50:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t262 = getelementptr %"compiler/check:Checker", ptr %t260, i32 0, i32 1
  %t263 = load ptr, ptr %t262, !tbaa !29
  %t265 = getelementptr %"compiler/generic:Program", ptr %t263, i32 0, i32 0
  %t266 = load ptr, ptr %t265, !tbaa !29
  %t268 = getelementptr %"compiler/load:Loader", ptr %t266, i32 0, i32 10
  %t269 = load i64, ptr %l1, !tbaa !24
  %t272 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t268, i64 %t269)
  store ptr %t272, ptr %l133
  br label %bb51
bb51:
  %t273 = load ptr, ptr %l133, !tbaa !29
  %t275 = getelementptr %"compiler/load:Module", ptr %t273, i32 0, i32 4
  %t276 = load i64, ptr %t275, !tbaa !24
  %t277 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t278 = load i32, ptr %t277, !tbaa !23
  %t280 = sext i32 %t278 to i64
  %t281 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 1
  %t282 = load i32, ptr %t281, !tbaa !23
  %t284 = sext i32 %t282 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t285
  %t286 = getelementptr { i64, [3 x i64] }, ptr %t285, i32 0, i32 0
  store i64 3, ptr %t286
  %t288 = insertvalue { i64, i64, i64 } undef, i64 %t276, 0
  %t290 = insertvalue { i64, i64, i64 } %t288, i64 %t280, 1
  %t292 = insertvalue { i64, i64, i64 } %t290, i64 %t284, 2
  %t293 = getelementptr { i64, [3 x i64] }, ptr %t285, i32 0, i32 1
  store { i64, i64, i64 } %t292, ptr %t293
  %t294 = load { i64, [3 x i64] }, ptr %t285
  call void @__olang_scope_close(ptr %s0)
  store { i64, [3 x i64] } %t294, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [3 x i64] }, ptr %rv
  ret { i64, [3 x i64] } %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowCopy(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l18 = alloca i64
  %l20 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %v1, ptr %a1)
  store ptr %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l5, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l2, !tbaa !29
  store ptr %t10, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t11 = load ptr, ptr %l9, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l9, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 0
  store i1 %t17, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l10, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t21, i32 0, i32 2
  %t23 = load i32, ptr %t22
  store i32 %t23, ptr %l3, !tbaa !23
  br label %bb9
bb8:
  br label %bb14
bb9:
  %t26 = load i32, ptr %l3, !tbaa !23
  %t28 = sext i32 %t26 to i64
  %t31 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowOwner(ptr %v0, ptr %a0, i64 %t28)
  store i64 %t31, ptr %l18
  br label %bb10
bb10:
  %t32 = load i64, ptr %l18, !tbaa !24
  %t33 = icmp sge i64 %t32, 0
  br i1 %t33, label %bb11, label %bb12
bb11:
  %t35 = load i32, ptr %l3, !tbaa !23
  %t37 = sext i32 %t35 to i64
  store i64 %t37, ptr %l20, !tbaa !24
  br label %bb13
bb12:
  store i64 -1, ptr %l20, !tbaa !24
  br label %bb13
bb13:
  %t39 = load i64, ptr %l20, !tbaa !24
  store i64 %t39, ptr %rv
  br label %ret
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i64 -1, ptr %rv
  br label %ret
bb18:
  call void @__olang_check_failed(ptr @olang_loc_cd94e6a5e488a5b1_e9066543c2d4a76d)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowedBranch(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, i64, i64 }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l21 = alloca i64
  %l26 = alloca { i64, i64, i64 }
  %l46 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Branch", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sge i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t8, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/generic:Program", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/load:Loader", ptr %t14, i32 0, i32 4
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/ast:Branch", ptr %t18, i32 0, i32 2
  %t21 = load i64, ptr %t20, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eReopen(ptr %v0, ptr %t17, i64 %t21)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 37
  %t28 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t26)
  store i64 %t28, ptr %l21
  br label %bb5
bb5:
  %t29 = load i64, ptr %l21, !tbaa !24
  store i64 %t29, ptr %l4, !tbaa !24
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr %"compiler/ast:Branch", ptr %t31, i32 0, i32 0
  %t34 = load %"compiler/source:Span", ptr %t33
  %t38 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t30, i32 1, %"compiler/source:Span" %t34)
  store { i64, i64, i64 } %t38, ptr %l26
  br label %bb6
bb6:
  %t39 = load { i64, i64, i64 }, ptr %l26
  store { i64, i64, i64 } %t39, ptr %l5
  %t40 = getelementptr { i64, i64, i64 }, ptr %l5, i32 0, i32 0
  %t41 = load i64, ptr %t40, !tbaa !24
  store i64 %t41, ptr %l6, !tbaa !24
  %t43 = getelementptr { i64, i64, i64 }, ptr %l5, i32 0, i32 1
  %t44 = load i64, ptr %t43, !tbaa !24
  store i64 %t44, ptr %l7, !tbaa !24
  %t46 = getelementptr { i64, i64, i64 }, ptr %l5, i32 0, i32 2
  %t47 = load i64, ptr %t46, !tbaa !24
  store i64 %t47, ptr %l8, !tbaa !24
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr %"compiler/ast:Branch", ptr %t49, i32 0, i32 1
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t56 = icmp sgt i64 %t54, 0
  br i1 %t56, label %bb7, label %bb8
bb7:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t61 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushFacts(ptr %v0, ptr %v2, ptr %t58, ptr %a2, i1 %a3, i64 %t61)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t69 = getelementptr %"compiler/ast:Branch", ptr %t67, i32 0, i32 1
  %t70 = load { i64, ptr }, ptr %t69, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %t66, { i64, ptr } %t70)
  br label %bb11
bb11:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i64, ptr %l6, !tbaa !24
  %t75 = load i64, ptr %l7, !tbaa !24
  %t76 = load i64, ptr %l8, !tbaa !24
  %t77 = load i64, ptr %l4, !tbaa !24
  %t83 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v3, ptr %t73, i64 %t74, i64 %t75, i64 %t76, i64 %t77)
  store ptr %t83, ptr %l46
  br label %bb12
bb12:
  %t84 = load ptr, ptr %l46, !tbaa !29
  store ptr %t84, ptr %l9, !tbaa !29
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr %"compiler/ast:Branch", ptr %t85, i32 0, i32 2
  %t88 = load i64, ptr %t87, !tbaa !24
  %t90 = icmp sge i64 %t88, 0
  br i1 %t90, label %bb13, label %bb14
bb13:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = getelementptr %"compiler/generic:Program", ptr %t95, i32 0, i32 0
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t100 = getelementptr %"compiler/load:Loader", ptr %t98, i32 0, i32 4
  %t101 = load ptr, ptr %t100, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t101)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  %t103 = load ptr, ptr %l9, !tbaa !29
  store ptr %t103, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowedField(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"compiler/check:narrowed"
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca ptr
  %l23 = alloca i64
  %l27 = alloca i64
  %l30 = alloca i64
  %l49 = alloca ptr
  %l52 = alloca i64
  %l56 = alloca %"compiler/check:narrowed"
  %l60 = alloca i1
  %l63 = alloca ptr
  %l68 = alloca i32
  %l69 = alloca ptr
  %l71 = alloca ptr
  %l74 = alloca i1
  %l89 = alloca i64
  %l92 = alloca i64
  %l110 = alloca { i64, ptr }
  %l121 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l20
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l20, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 46
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLen_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l23
  br label %bb2
bb2:
  %t10 = load i64, ptr %l23, !tbaa !24
  store i64 %t10, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp sgt i64 %t11, %t12
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load i64, ptr %l6, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb8
bb5:
  %t21 = load i64, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = sub i64 %t21, %t22
  %t26 = load i64, ptr %l6, !tbaa !24
  %t29 = add i64 %t25, %t26
  %t31 = sub i64 %t29, 1
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = sdiv i64 %t31, %t32
  store i64 %t35, ptr %l30, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb7
bb7:
  %t37 = load i64, ptr %l30, !tbaa !24
  store i64 %t37, ptr %l27, !tbaa !24
  br label %bb8
bb8:
  %t38 = load i64, ptr %l27, !tbaa !24
  store i64 %t38, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  %t39 = load i64, ptr %l8, !tbaa !24
  %t40 = load i64, ptr %l7, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb10, label %bb11
bb10:
  br label %bb50
bb11:
  br label %bb12
bb12:
  %t47 = load i64, ptr %l4, !tbaa !24
  %t48 = load i64, ptr %l8, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = mul i64 %t48, %t49
  %t55 = add i64 %t47, %t52
  store i64 %t55, ptr %l9, !tbaa !24
  %t57 = load ptr, ptr %l3, !tbaa !29
  %t59 = getelementptr %"compiler/check:frame", ptr %t57, i32 0, i32 46
  store ptr %t59, ptr %l49, !tbaa !29
  %t60 = load ptr, ptr %l3, !tbaa !29
  %t62 = getelementptr %"compiler/check:frame", ptr %t60, i32 0, i32 46
  %t64 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLen_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t62)
  store i64 %t64, ptr %l52
  br label %bb13
bb13:
  %t65 = load i64, ptr %l52, !tbaa !24
  %t66 = sub i64 %t65, 1
  %t67 = load i64, ptr %l9, !tbaa !24
  %t70 = sub i64 %t66, %t67
  %t71 = load ptr, ptr %l49, !tbaa !29
  %t73 = call %"compiler/check:narrowed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eAt_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t71, i64 %t70)
  store %"compiler/check:narrowed" %t73, ptr %l56
  br label %bb14
bb14:
  %t74 = load %"compiler/check:narrowed", ptr %l56
  store %"compiler/check:narrowed" %t74, ptr %l10
  %t75 = getelementptr %"compiler/check:narrowed", ptr %l10, i32 0, i32 0
  %t76 = load i64, ptr %t75, !tbaa !24
  %t80 = icmp ne i64 %t76, %a1
  br i1 %t80, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb17
bb16:
  %t82 = getelementptr %"compiler/check:narrowed", ptr %l10, i32 0, i32 5
  %t83 = load i1, ptr %t82, !tbaa !21
  store i1 %t83, ptr %l60, !tbaa !21
  br label %bb17
bb17:
  %t85 = load i1, ptr %l60, !tbaa !21
  br i1 %t85, label %bb18, label %bb19
bb18:
  br label %bb49
bb19:
  br label %bb20
bb20:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  store ptr %t89, ptr %l63, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t90, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Program", ptr %t93, i32 0, i32 2
  %t96 = getelementptr %"compiler/check:narrowed", ptr %l10, i32 0, i32 2
  %t97 = load i32, ptr %t96, !tbaa !23
  %t100 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t95, i32 %t97)
  store i32 %t100, ptr %l68
  br label %bb21
bb21:
  %t101 = load ptr, ptr %l63, !tbaa !29
  %t102 = load i32, ptr %l68, !tbaa !23
  %t103 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t101, i32 %t102)
  store ptr %t103, ptr %l69
  br label %bb22
bb22:
  %t104 = getelementptr %"compiler/check:narrowed", ptr %l10, i32 0, i32 1
  %t105 = load i64, ptr %t104, !tbaa !24
  %t106 = load ptr, ptr %l69, !tbaa !29
  %t108 = call ptr @compiler_2fcheck_2ecaseDecl(ptr %v0, ptr %v0, ptr %t106, i64 %t105)
  store ptr %t108, ptr %l71
  br label %bb23
bb23:
  %t109 = load ptr, ptr %l71, !tbaa !29
  store ptr %t109, ptr %l11, !tbaa !29
  %t110 = load ptr, ptr %l11, !tbaa !29
  %t112 = icmp eq ptr %t110, null
  br i1 %t112, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb26
bb25:
  %t114 = load ptr, ptr %l11, !tbaa !29
  %t116 = getelementptr %"compiler/ast:CaseDecl", ptr %t114, i32 0, i32 3
  %t117 = load i1, ptr %t116, !tbaa !21
  store i1 %t117, ptr %l74, !tbaa !21
  br label %bb26
bb26:
  %t119 = load i1, ptr %l74, !tbaa !21
  br i1 %t119, label %bb27, label %bb28
bb27:
  store i64 -1, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t121 = load ptr, ptr %l11, !tbaa !29
  %t123 = getelementptr %"compiler/ast:CaseDecl", ptr %t121, i32 0, i32 2
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  store { i64, ptr } %t124, ptr %l12, !tbaa !27
  %t126 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t126, 0
  %t130 = icmp eq i64 %t128, 0
  br i1 %t130, label %bb30, label %bb31
bb30:
  store i64 -1, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  store i64 0, ptr %l13, !tbaa !24
  %t133 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t133, 0
  store i64 %t135, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t137 = load i64, ptr %l14, !tbaa !24
  %t138 = load i64, ptr %l13, !tbaa !24
  %t141 = icmp sgt i64 %t137, %t138
  br i1 %t141, label %bb33, label %bb34
bb33:
  %t143 = load i64, ptr %l15, !tbaa !24
  %t145 = icmp sgt i64 %t143, 0
  br i1 %t145, label %bb35, label %bb36
bb34:
  store i64 0, ptr %l89, !tbaa !24
  br label %bb38
bb35:
  %t147 = load i64, ptr %l14, !tbaa !24
  %t148 = load i64, ptr %l13, !tbaa !24
  %t151 = sub i64 %t147, %t148
  %t152 = load i64, ptr %l15, !tbaa !24
  %t155 = add i64 %t151, %t152
  %t157 = sub i64 %t155, 1
  %t158 = load i64, ptr %l15, !tbaa !24
  %t161 = sdiv i64 %t157, %t158
  store i64 %t161, ptr %l92, !tbaa !24
  br label %bb37
bb36:
  store i64 0, ptr %l92, !tbaa !24
  br label %bb37
bb37:
  %t163 = load i64, ptr %l92, !tbaa !24
  store i64 %t163, ptr %l89, !tbaa !24
  br label %bb38
bb38:
  %t164 = load i64, ptr %l89, !tbaa !24
  store i64 %t164, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb39
bb39:
  %t165 = load i64, ptr %l17, !tbaa !24
  %t166 = load i64, ptr %l16, !tbaa !24
  %t169 = icmp slt i64 %t165, %t166
  %t171 = xor i1 %t169, true
  br i1 %t171, label %bb40, label %bb41
bb40:
  br label %bb48
bb41:
  br label %bb42
bb42:
  %t173 = load i64, ptr %l13, !tbaa !24
  %t174 = load i64, ptr %l17, !tbaa !24
  %t175 = load i64, ptr %l15, !tbaa !24
  %t178 = mul i64 %t174, %t175
  %t181 = add i64 %t173, %t178
  store i64 %t181, ptr %l18, !tbaa !24
  %t183 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t183, ptr %l110, !tbaa !27
  %t184 = load i64, ptr %l18, !tbaa !24
  %t186 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !27
  %t188 = getelementptr ptr, ptr %t187, i64 %t184
  %t189 = load ptr, ptr %t188, !tbaa !39
  %t191 = getelementptr %"compiler/ast:Param", ptr %t189, i32 0, i32 1
  %t192 = load i32, ptr %t191, !tbaa !23
  %t196 = icmp eq i32 %t192, %a2
  br i1 %t196, label %bb43, label %bb44
bb43:
  %t198 = load ptr, ptr %l3, !tbaa !29
  %t200 = getelementptr %"compiler/check:frame", ptr %t198, i32 0, i32 47
  %t201 = getelementptr %"compiler/check:narrowed", ptr %l10, i32 0, i32 3
  %t202 = load i64, ptr %t201, !tbaa !24
  %t203 = load i64, ptr %l18, !tbaa !24
  %t206 = add i64 %t202, %t203
  %t209 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t200, i64 %t206)
  store i64 %t209, ptr %l121
  br label %bb45
bb44:
  br label %bb46
bb45:
  %t210 = load i64, ptr %l121, !tbaa !24
  store i64 %t210, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t211 = load i64, ptr %l17, !tbaa !24
  %t213 = add i64 %t211, 1
  store i64 %t213, ptr %l17, !tbaa !24
  br label %bb39
bb48:
  store i64 -1, ptr %rv
  br label %ret
bb49:
  %t216 = load i64, ptr %l8, !tbaa !24
  %t218 = add i64 %t216, 1
  store i64 %t218, ptr %l8, !tbaa !24
  br label %bb9
bb50:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l8 = alloca ptr
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t10 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v1, ptr %v0, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %t3, i32 2, ptr %a2, ptr null)
  store ptr %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l8, !tbaa !29
  store ptr %t11, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotInModule(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"compiler/names:Entry"
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i32
  %l25 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca %"compiler/source:Span"
  %l31 = alloca { i64, ptr }
  %l33 = alloca %"compiler/msgs:Msg"
  %l34 = alloca i64
  %l37 = alloca { i64, ptr }
  %l38 = alloca %"compiler/msgs:Nearest"
  %l45 = alloca ptr
  %l48 = alloca i64
  %l50 = alloca i64
  %l55 = alloca %"compiler/names:Entry"
  %l59 = alloca i1
  %l60 = alloca i64
  %l62 = alloca ptr
  %l66 = alloca i1
  %l69 = alloca { i64, ptr }
  %l70 = alloca i1
  %l71 = alloca i1
  %l74 = alloca ptr
  %l77 = alloca { i64, ptr }
  %l80 = alloca ptr
  %l81 = alloca %"compiler/source:Span"
  %l85 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l93 = alloca %"compiler/msgs:Msg"
  %l94 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 10
  %t10 = load i64, ptr %l1, !tbaa !24
  %t13 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t9, i64 %t10)
  store ptr %t13, ptr %l15
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l15, !tbaa !29
  store ptr %t14, ptr %l4, !tbaa !29
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t17 = getelementptr %"compiler/load:Module", ptr %t15, i32 0, i32 33
  store ptr %t17, ptr %l18, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l2, !tbaa !23
  %t22 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t18, i32 %t19)
  store { i64, ptr } %t22, ptr %l21
  br label %bb2
bb2:
  %t23 = load ptr, ptr %l18, !tbaa !29
  %t24 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t25 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %v0, ptr %v0, ptr %t23, { i64, ptr } %t24)
  %t26 = extractvalue { i32, { i64, ptr } } %t25, 1
  %t27 = extractvalue { i32, { i64, ptr } } %t25, 0
  store i32 %t27, ptr %l23
  %t28 = icmp ne i32 %t27, 0
  br i1 %t28, label %bb4, label %ok.29, !prof !99
ok.29:
  store { i64, ptr } %t26, ptr %l22
  br label %bb3
bb3:
  %t30 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t30, ptr %l16, !tbaa !27
  br label %bb6
bb4:
  br label %bb5
bb5:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr %l16, !tbaa !27
  br label %bb6
bb6:
  %t31 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t31, ptr %l5, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t34 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t32, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i1 %t34, ptr %l25
  br label %bb7
bb7:
  %t35 = load i1, ptr %l25, !tbaa !21
  %t36 = xor i1 %t35, true
  br i1 %t36, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s1
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l27, !tbaa !29
  %t39 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t39, ptr %l28
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l2, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t40, i32 %t41)
  store { i64, ptr } %t44, ptr %l31
  br label %bb10
bb9:
  br label %bb13
bb10:
  %t45 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t48 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCNoForm(ptr %v0, ptr %v0, ptr %s1, { i64, ptr } %t46, { i64, ptr } %t45)
  store %"compiler/msgs:Msg" %t48, ptr %l33
  br label %bb11
bb11:
  %t49 = load ptr, ptr %l27, !tbaa !29
  %t50 = load %"compiler/source:Span", ptr %l28
  %t51 = load %"compiler/msgs:Msg", ptr %l33
  %t52 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t49, %"compiler/source:Span" %t50, %"compiler/msgs:Msg" %t51)
  store i64 %t52, ptr %l34
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb13:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i32, ptr %l2, !tbaa !23
  %t57 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t53, i32 %t54)
  store { i64, ptr } %t57, ptr %l37
  br label %bb14
bb14:
  %t58 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t59 = call %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v0, ptr %s0, { i64, ptr } %t58)
  store %"compiler/msgs:Nearest" %t59, ptr %l38
  br label %bb15
bb15:
  %t60 = load %"compiler/msgs:Nearest", ptr %l38
  %t61 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 40, i64 8)
  store %"compiler/msgs:Nearest" %t60, ptr %t61
  store ptr %t61, ptr %l6, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = getelementptr %"compiler/names:Resolver", ptr %t69, i32 0, i32 1
  %t72 = load i64, ptr %l1, !tbaa !24
  %t75 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t71, i64 %t72)
  store ptr %t75, ptr %l45
  br label %bb16
bb16:
  %t76 = load ptr, ptr %l45, !tbaa !29
  %t78 = getelementptr %"compiler/names:Table", ptr %t76, i32 0, i32 0
  store ptr %t78, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb17
bb17:
  %t80 = load i64, ptr %l8, !tbaa !24
  store i64 %t80, ptr %l48, !tbaa !24
  %t81 = load ptr, ptr %l7, !tbaa !29
  %t83 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t81)
  store i64 %t83, ptr %l50
  br label %bb18
bb18:
  %t84 = load i64, ptr %l48, !tbaa !24
  %t85 = load i64, ptr %l50, !tbaa !24
  %t86 = icmp slt i64 %t84, %t85
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb19, label %bb20
bb19:
  br label %bb41
bb20:
  br label %bb21
bb21:
  %t90 = load ptr, ptr %l7, !tbaa !29
  %t91 = load i64, ptr %l8, !tbaa !24
  %t94 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t90, i64 %t91)
  store %"compiler/names:Entry" %t94, ptr %l55
  br label %bb22
bb22:
  %t95 = load %"compiler/names:Entry", ptr %l55
  store %"compiler/names:Entry" %t95, ptr %l9
  %t96 = getelementptr %"compiler/names:Entry", ptr %l9, i32 0, i32 2
  %t97 = load i32, ptr %t96, !range !{i32 0, i32 9}
  %t99 = trunc i64 5 to i32
  %t100 = icmp eq i32 %t97, %t99
  %t102 = xor i1 %t100, true
  br i1 %t102, label %bb23, label %bb24
bb23:
  %t104 = load i64, ptr %l1, !tbaa !24
  store i64 %t104, ptr %l60, !tbaa !24
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t105)
  store ptr %t107, ptr %l62
  br label %bb25
bb24:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb34
bb25:
  %t108 = load ptr, ptr %l62, !tbaa !29
  %t110 = getelementptr %"compiler/check:frame", ptr %t108, i32 0, i32 1
  %t111 = load i64, ptr %t110, !tbaa !24
  %t112 = load i64, ptr %l60, !tbaa !24
  %t114 = icmp eq i64 %t112, %t111
  br i1 %t114, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb30
bb27:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/names:Entry", ptr %l9, i32 0, i32 0
  %t118 = load i32, ptr %t117, !tbaa !23
  %t121 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t116, i32 %t118)
  store { i64, ptr } %t121, ptr %l69
  br label %bb28
bb28:
  %t122 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t123 = call i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %t122)
  store i1 %t123, ptr %l70
  br label %bb29
bb29:
  %t124 = load i1, ptr %l70, !tbaa !21
  store i1 %t124, ptr %l66, !tbaa !21
  br label %bb30
bb30:
  %t125 = load i1, ptr %l66, !tbaa !21
  br i1 %t125, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l71, !tbaa !21
  br label %bb33
bb32:
  %t126 = load ptr, ptr %l4, !tbaa !29
  %t128 = getelementptr %"compiler/load:Module", ptr %t126, i32 0, i32 30
  %t129 = load i1, ptr %t128, !tbaa !21
  store i1 %t129, ptr %l71, !tbaa !21
  br label %bb33
bb33:
  %t131 = load i1, ptr %l71, !tbaa !21
  store i1 %t131, ptr %l59, !tbaa !21
  br label %bb34
bb34:
  %t132 = load i1, ptr %l59, !tbaa !21
  br i1 %t132, label %bb35, label %bb36
bb35:
  %t133 = load ptr, ptr %l6, !tbaa !29
  store ptr %t133, ptr %l74, !tbaa !29
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/names:Entry", ptr %l9, i32 0, i32 0
  %t136 = load i32, ptr %t135, !tbaa !23
  %t139 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t134, i32 %t136)
  store { i64, ptr } %t139, ptr %l77
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t140 = load ptr, ptr %l74, !tbaa !29
  %t141 = load { i64, ptr }, ptr %l77, !tbaa !27
  call void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %s0, ptr %v0, ptr %t140, { i64, ptr } %t141)
  br label %bb38
bb38:
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t142 = load i64, ptr %l8, !tbaa !24
  %t144 = add i64 %t142, 1
  store i64 %t144, ptr %l8, !tbaa !24
  br label %bb17
bb41:
  %t146 = load ptr, ptr %l0, !tbaa !29
  store ptr %t146, ptr %l80, !tbaa !29
  %t147 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t147, ptr %l81
  %t148 = load ptr, ptr %l4, !tbaa !29
  %t150 = getelementptr %"compiler/load:Module", ptr %t148, i32 0, i32 2
  %t151 = load { i64, ptr }, ptr %t150, !tbaa !27
  %t152 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t153 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t155 = extractvalue { i64, ptr } %t151, 1
  %t156 = extractvalue { i64, ptr } %t151, 0
  %t157 = add i64 %t153, %t156
  %t158 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t157)
  call void @olang_textcopy(ptr %t158, ptr %t152, i64 %t153)
  %t159 = getelementptr i8, ptr %t158, i64 %t153
  call void @olang_textcopy(ptr %t159, ptr %t155, i64 %t156)
  %t160 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t161 = insertvalue { i64, ptr } %t160, ptr %t158, 1
  %t163 = extractvalue { i64, ptr } %t161, 0
  %t164 = extractvalue { i64, ptr } %t161, 1
  %t165 = mul i64 %t163, 1
  %t166 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t165)
  call void @llvm.memcpy.p0.p0.i64(ptr %t166, ptr %t164, i64 %t165, i1 false)
  %t167 = insertvalue { i64, ptr } undef, i64 %t163, 0
  %t168 = insertvalue { i64, ptr } %t167, ptr %t166, 1
  store { i64, ptr } %t168, ptr %l85, !tbaa !27
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load i32, ptr %l2, !tbaa !23
  %t173 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s0, ptr %t169, i32 %t170)
  store { i64, ptr } %t173, ptr %l88
  br label %bb42
bb42:
  %t174 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t175 = extractvalue { i64, ptr } %t174, 0
  %t176 = extractvalue { i64, ptr } %t174, 1
  %t177 = mul i64 %t175, 1
  %t178 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t177)
  call void @llvm.memcpy.p0.p0.i64(ptr %t178, ptr %t176, i64 %t177, i1 false)
  %t179 = insertvalue { i64, ptr } undef, i64 %t175, 0
  %t180 = insertvalue { i64, ptr } %t179, ptr %t178, 1
  store { i64, ptr } %t180, ptr %l89, !tbaa !27
  %t181 = load ptr, ptr %l6, !tbaa !29
  %t183 = call { i64, ptr } @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eHint(ptr %s0, ptr %s0, ptr %t181)
  store { i64, ptr } %t183, ptr %l91
  br label %bb43
bb43:
  %t184 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t184, 0
  %t186 = extractvalue { i64, ptr } %t184, 1
  %t187 = mul i64 %t185, 1
  %t188 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t187)
  call void @llvm.memcpy.p0.p0.i64(ptr %t188, ptr %t186, i64 %t187, i1 false)
  %t189 = insertvalue { i64, ptr } undef, i64 %t185, 0
  %t190 = insertvalue { i64, ptr } %t189, ptr %t188, 1
  %t191 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t192 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t194 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotInModule(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t191, { i64, ptr } %t192, { i64, ptr } %t190)
  store %"compiler/msgs:Msg" %t194, ptr %l93
  br label %bb44
bb44:
  %t195 = load ptr, ptr %l80, !tbaa !29
  %t196 = load %"compiler/source:Span", ptr %l81
  %t197 = load %"compiler/msgs:Msg", ptr %l93
  %t198 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t195, %"compiler/source:Span" %t196, %"compiler/msgs:Msg" %t197)
  store i64 %t198, ptr %l94
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperandParam(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l11 = alloca i32
  %l14 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca i64
  %l30 = alloca i32
  %l37 = alloca ptr
  %l42 = alloca i32
  %l43 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l49 = alloca i32
  %l54 = alloca { i64, ptr }
  %l56 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t5, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t11 = load i64, ptr %l1, !tbaa !24
  %t14 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t10, i64 %t11)
  store i32 %t14, ptr %l11
  br label %bb4
bb4:
  %t15 = load i32, ptr %l11, !tbaa !23
  store i32 %t15, ptr %l3, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  store ptr %t21, ptr %l14, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l3, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l19
  br label %bb5
bb5:
  %t32 = load ptr, ptr %l14, !tbaa !29
  %t33 = load i32, ptr %l19, !tbaa !23
  %t34 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t32, i32 %t33)
  store { i64, ptr } %t34, ptr %l20
  br label %bb6
bb6:
  %t35 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t35, ptr %l4, !tbaa !27
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !29
  store ptr %t39, ptr %l22, !tbaa !29
  %t40 = load i64, ptr %l1, !tbaa !24
  %t42 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t40)
  store i64 %t42, ptr %l24
  br label %bb7
bb7:
  %t43 = load ptr, ptr %l22, !tbaa !29
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t43, i64 %t44)
  store i64 %t45, ptr %l25
  br label %bb8
bb8:
  %t46 = load i64, ptr %l25, !tbaa !24
  %t47 = icmp sgt i64 %t46, 0
  br i1 %t47, label %bb9, label %bb10
bb9:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i64, ptr %l1, !tbaa !24
  %t55 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimplSig(ptr %v0, ptr %t49, i64 %t50, i32 %a2)
  store i32 %t55, ptr %l30
  br label %bb11
bb10:
  br label %bb21
bb11:
  %t56 = load i32, ptr %l30, !tbaa !23
  store i32 %t56, ptr %l3, !tbaa !23
  %t57 = load i32, ptr %l3, !tbaa !23
  %t58 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t61 = icmp eq i32 %t57, %t58
  br i1 %t61, label %bb12, label %bb13
bb12:
  %t63 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t63, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Program", ptr %t68, i32 0, i32 2
  store ptr %t70, ptr %l37, !tbaa !29
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 2
  %t77 = load i32, ptr %l3, !tbaa !23
  %t80 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t76, i32 %t77)
  store i32 %t80, ptr %l42
  br label %bb15
bb15:
  %t81 = load ptr, ptr %l37, !tbaa !29
  %t82 = load i32, ptr %l42, !tbaa !23
  %t83 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t81, i32 %t82)
  store { i64, ptr } %t83, ptr %l43
  br label %bb16
bb16:
  %t84 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t84, ptr %l4, !tbaa !27
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Program", ptr %t88, i32 0, i32 2
  %t91 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t91, ptr %l47, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr i32, ptr %t93, i64 1
  %t95 = load i32, ptr %t94, !tbaa !33
  %t98 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t90, i32 %t95)
  store i32 %t98, ptr %l49
  br label %bb17
bb17:
  %t99 = load i32, ptr %l49, !range !{i32 0, i32 33}
  %t101 = trunc i64 25 to i32
  %t102 = icmp eq i32 %t99, %t101
  br i1 %t102, label %bb18, label %bb19
bb18:
  %t104 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t104, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t107, ptr %l54, !tbaa !27
  %t108 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr i32, ptr %t109, i64 1
  %t111 = load i32, ptr %t110, !tbaa !33
  %t114 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t106, i32 %t111)
  store i32 %t114, ptr %l56
  br label %bb22
bb22:
  %t115 = load i32, ptr %l56, !tbaa !23
  store i32 %t115, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eorderGlobals(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i64
  %l18 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i64
  %l54 = alloca ptr
  %l74 = alloca i64
  %l78 = alloca i64
  %l81 = alloca i64
  %l109 = alloca i64
  %l111 = alloca i64
  %l116 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l18
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l18
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l19
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/generic:Program", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/load:Loader", ptr %t11, i32 0, i32 10
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l24
  br label %bb3
bb3:
  %t16 = load i64, ptr %l24, !tbaa !24
  store i64 %t16, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = icmp sgt i64 %t17, %t18
  br i1 %t21, label %bb4, label %bb5
bb4:
  %t23 = load i64, ptr %l5, !tbaa !24
  %t25 = icmp sgt i64 %t23, 0
  br i1 %t25, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb9
bb6:
  %t27 = load i64, ptr %l4, !tbaa !24
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = sub i64 %t27, %t28
  %t32 = load i64, ptr %l5, !tbaa !24
  %t35 = add i64 %t31, %t32
  %t37 = sub i64 %t35, 1
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = sdiv i64 %t37, %t38
  store i64 %t41, ptr %l31, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb8
bb8:
  %t43 = load i64, ptr %l31, !tbaa !24
  store i64 %t43, ptr %l28, !tbaa !24
  br label %bb9
bb9:
  %t44 = load i64, ptr %l28, !tbaa !24
  store i64 %t44, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb10
bb10:
  %t45 = load i64, ptr %l7, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb11, label %bb12
bb11:
  br label %bb20
bb12:
  br label %bb13
bb13:
  %t53 = load i64, ptr %l3, !tbaa !24
  %t54 = load i64, ptr %l7, !tbaa !24
  %t55 = load i64, ptr %l5, !tbaa !24
  %t58 = mul i64 %t54, %t55
  %t61 = add i64 %t53, %t58
  store i64 %t61, ptr %l8, !tbaa !24
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 0
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = getelementptr %"compiler/load:Loader", ptr %t69, i32 0, i32 10
  %t72 = load i64, ptr %l8, !tbaa !24
  %t75 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t71, i64 %t72)
  store ptr %t75, ptr %l54
  br label %bb14
bb14:
  %t76 = load ptr, ptr %l54, !tbaa !29
  %t78 = getelementptr %"compiler/load:Module", ptr %t76, i32 0, i32 3
  %t79 = load i1, ptr %t78, !tbaa !21
  br i1 %t79, label %bb15, label %bb16
bb15:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load i64, ptr %l8, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aModules(ptr %v0, ptr %s0, ptr %s0, ptr %t81, i64 %t82, ptr %l1, ptr %l2)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t87 = load i64, ptr %l7, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l7, !tbaa !24
  br label %bb10
bb20:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = getelementptr %"compiler/generic:Program", ptr %t95, i32 0, i32 0
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t100 = getelementptr %"compiler/load:Loader", ptr %t98, i32 0, i32 12
  %t101 = load i64, ptr %t100, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aModules(ptr %v0, ptr %s0, ptr %s0, ptr %t91, i64 %t101, ptr %l1, ptr %l2)
  br label %bb21
bb21:
  store i64 0, ptr %l9, !tbaa !24
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/generic:Program", ptr %t109, i32 0, i32 0
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = getelementptr %"compiler/load:Loader", ptr %t112, i32 0, i32 10
  %t116 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t114)
  store i64 %t116, ptr %l74
  br label %bb22
bb22:
  %t117 = load i64, ptr %l74, !tbaa !24
  store i64 %t117, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t118 = load i64, ptr %l10, !tbaa !24
  %t119 = load i64, ptr %l9, !tbaa !24
  %t122 = icmp sgt i64 %t118, %t119
  br i1 %t122, label %bb23, label %bb24
bb23:
  %t124 = load i64, ptr %l11, !tbaa !24
  %t126 = icmp sgt i64 %t124, 0
  br i1 %t126, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l78, !tbaa !24
  br label %bb28
bb25:
  %t128 = load i64, ptr %l10, !tbaa !24
  %t129 = load i64, ptr %l9, !tbaa !24
  %t132 = sub i64 %t128, %t129
  %t133 = load i64, ptr %l11, !tbaa !24
  %t136 = add i64 %t132, %t133
  %t138 = sub i64 %t136, 1
  %t139 = load i64, ptr %l11, !tbaa !24
  %t142 = sdiv i64 %t138, %t139
  store i64 %t142, ptr %l81, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l81, !tbaa !24
  br label %bb27
bb27:
  %t144 = load i64, ptr %l81, !tbaa !24
  store i64 %t144, ptr %l78, !tbaa !24
  br label %bb28
bb28:
  %t145 = load i64, ptr %l78, !tbaa !24
  store i64 %t145, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb29
bb29:
  %t146 = load i64, ptr %l13, !tbaa !24
  %t147 = load i64, ptr %l12, !tbaa !24
  %t150 = icmp slt i64 %t146, %t147
  %t152 = xor i1 %t150, true
  br i1 %t152, label %bb30, label %bb31
bb30:
  br label %bb35
bb31:
  br label %bb32
bb32:
  %t154 = load i64, ptr %l9, !tbaa !24
  %t155 = load i64, ptr %l13, !tbaa !24
  %t156 = load i64, ptr %l11, !tbaa !24
  %t159 = mul i64 %t155, %t156
  %t162 = add i64 %t154, %t159
  %t164 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aModules(ptr %v0, ptr %s0, ptr %s0, ptr %t164, i64 %t162, ptr %l1, ptr %l2)
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t170 = load i64, ptr %l13, !tbaa !24
  %t172 = add i64 %t170, 1
  store i64 %t172, ptr %l13, !tbaa !24
  br label %bb29
bb35:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/check:Checker", ptr %t174, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !29
  %t179 = getelementptr %"compiler/generic:Program", ptr %t177, i32 0, i32 47
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t179)
  br label %bb36
bb36:
  store ptr %l2, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb37
bb37:
  %t182 = load i64, ptr %l16, !tbaa !24
  store i64 %t182, ptr %l109, !tbaa !24
  %t183 = load ptr, ptr %l15, !tbaa !29
  %t185 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t183)
  store i64 %t185, ptr %l111
  br label %bb38
bb38:
  %t186 = load i64, ptr %l109, !tbaa !24
  %t187 = load i64, ptr %l111, !tbaa !24
  %t188 = icmp slt i64 %t186, %t187
  %t190 = xor i1 %t188, true
  br i1 %t190, label %bb39, label %bb40
bb39:
  br label %bb45
bb40:
  br label %bb41
bb41:
  %t192 = load ptr, ptr %l15, !tbaa !29
  %t193 = load i64, ptr %l16, !tbaa !24
  %t196 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t192, i64 %t193)
  store i64 %t196, ptr %l116
  br label %bb42
bb42:
  %t197 = load i64, ptr %l116, !tbaa !24
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/check:Checker", ptr %t200, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !29
  %t205 = getelementptr %"compiler/generic:Program", ptr %t203, i32 0, i32 47
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eorderModule(ptr %v0, ptr %v0, ptr %t198, i64 %t197, ptr %t205)
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t209 = load i64, ptr %l16, !tbaa !24
  %t211 = add i64 %t209, 1
  store i64 %t211, ptr %l16, !tbaa !24
  br label %bb37
bb45:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowValues(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca i32
  %l16 = alloca i1
  %l19 = alloca i32
  %l24 = alloca ptr
  %l28 = alloca i64
  %l33 = alloca i1
  %l34 = alloca i1
  %l37 = alloca i1
  %l39 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l48 = alloca ptr
  %l49 = alloca %"compiler/source:Span"
  %l52 = alloca { i64, ptr }
  %l55 = alloca %"compiler/msgs:Msg"
  %l56 = alloca i64
  %l59 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca ptr
  %l65 = alloca ptr
  %l68 = alloca { i64, ptr }
  %l69 = alloca ptr
  %l70 = alloca %"compiler/source:Span"
  %l71 = alloca %"compiler/source:Span"
  %l72 = alloca i64
  %l74 = alloca ptr
  %l77 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l84 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t2)
  store i32 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l8, !tbaa !29
  %t7 = load i32, ptr %l11, !tbaa !23
  %t8 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t8, ptr %l12
  br label %bb2
bb2:
  %t9 = load i32, ptr %l12, !tbaa !23
  store i32 %t9, ptr %l5, !tbaa !23
  %t10 = load i32, ptr %l5, !tbaa !23
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t14 = icmp eq i32 %t10, %t11
  br i1 %t14, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb6
bb4:
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t19 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t16)
  store i32 %t19, ptr %l19
  br label %bb5
bb5:
  %t20 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t21 = load i32, ptr %l19, !tbaa !23
  %t23 = icmp eq i32 %t21, %t20
  store i1 %t23, ptr %l16, !tbaa !21
  br label %bb6
bb6:
  %t25 = load i1, ptr %l16, !tbaa !21
  br i1 %t25, label %bb7, label %bb8
bb7:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load %"compiler/source:Span", ptr %l1
  %t30 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t26, %"compiler/source:Span" %t27)
  store ptr %t30, ptr %l24
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load ptr, ptr %l24, !tbaa !29
  store ptr %t31, ptr %rv
  br label %ret
bb10:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l5, !tbaa !23
  %t34 = load %"compiler/source:Span", ptr %l2
  %t38 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowMethod(ptr %v0, ptr %t32, i32 %t33, %"compiler/source:Span" %t34)
  store i64 %t38, ptr %l28
  br label %bb11
bb11:
  %t39 = load i64, ptr %l28, !tbaa !24
  store i64 %t39, ptr %l6, !tbaa !24
  %t40 = load i64, ptr %l6, !tbaa !24
  %t42 = icmp slt i64 %t40, 0
  br i1 %t42, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i32, ptr %l5, !tbaa !23
  %t48 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t44, i32 %t45)
  store i1 %t48, ptr %l33
  br label %bb14
bb13:
  br label %bb28
bb14:
  %t49 = load i1, ptr %l33, !tbaa !21
  br i1 %t49, label %bb15, label %bb16
bb15:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load i32, ptr %l5, !tbaa !23
  %t54 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t50, i32 %t51)
  store i1 %t54, ptr %l37
  br label %bb17
bb16:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb18
bb17:
  %t55 = load i1, ptr %l37, !tbaa !21
  %t56 = xor i1 %t55, true
  store i1 %t56, ptr %l34, !tbaa !21
  br label %bb18
bb18:
  %t58 = load i1, ptr %l34, !tbaa !21
  br i1 %t58, label %bb19, label %bb20
bb19:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i32, ptr %l5, !tbaa !23
  %t63 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t59, i32 %t60)
  store { i64, ptr } %t63, ptr %l42
  br label %bb21
bb20:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %l39, !tbaa !27
  br label %bb23
bb21:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load i32, ptr %l5, !tbaa !23
  %t68 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t64, i32 %t65)
  store { i64, ptr } %t68, ptr %l45
  br label %bb22
bb22:
  %t69 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t70 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t71 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 1
  %t73 = extractvalue { i64, ptr } %t71, 0
  %t74 = add i64 %t70, %t73
  %t75 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t76 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t77 = add i64 %t74, %t76
  %t78 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 1
  %t80 = extractvalue { i64, ptr } %t78, 0
  %t81 = add i64 %t77, %t80
  %t82 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t83 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t84 = add i64 %t81, %t83
  %t85 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t84)
  call void @olang_textcopy(ptr %t85, ptr %t69, i64 %t70)
  %t86 = getelementptr i8, ptr %t85, i64 %t70
  call void @olang_textcopy(ptr %t86, ptr %t72, i64 %t73)
  %t87 = getelementptr i8, ptr %t86, i64 %t73
  call void @olang_textcopy(ptr %t87, ptr %t75, i64 %t76)
  %t88 = getelementptr i8, ptr %t87, i64 %t76
  call void @olang_textcopy(ptr %t88, ptr %t79, i64 %t80)
  %t89 = getelementptr i8, ptr %t88, i64 %t80
  call void @olang_textcopy(ptr %t89, ptr %t82, i64 %t83)
  %t90 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t85, 1
  %t93 = extractvalue { i64, ptr } %t91, 0
  %t94 = extractvalue { i64, ptr } %t91, 1
  %t95 = mul i64 %t93, 1
  %t96 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t95)
  call void @llvm.memcpy.p0.p0.i64(ptr %t96, ptr %t94, i64 %t95, i1 false)
  %t97 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t96, 1
  store { i64, ptr } %t98, ptr %l39, !tbaa !27
  br label %bb23
bb23:
  %t100 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t100, ptr %l7, !tbaa !27
  %t101 = load ptr, ptr %l0, !tbaa !29
  store ptr %t101, ptr %l48, !tbaa !29
  %t102 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t102, ptr %l49
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load i32, ptr %l5, !tbaa !23
  %t107 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t103, i32 %t104)
  store { i64, ptr } %t107, ptr %l52
  br label %bb24
bb24:
  %t108 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t108, 0
  %t110 = extractvalue { i64, ptr } %t108, 1
  %t111 = mul i64 %t109, 1
  %t112 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t111)
  call void @llvm.memcpy.p0.p0.i64(ptr %t112, ptr %t110, i64 %t111, i1 false)
  %t113 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t112, 1
  %t115 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t118 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2ePowNone(ptr %s2, ptr %s2, ptr %s2, { i64, ptr } %t114, { i64, ptr } %t115)
  store %"compiler/msgs:Msg" %t118, ptr %l55
  br label %bb25
bb25:
  %t119 = load ptr, ptr %l48, !tbaa !29
  %t120 = load %"compiler/source:Span", ptr %l49
  %t121 = load %"compiler/msgs:Msg", ptr %l55
  %t122 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t119, %"compiler/source:Span" %t120, %"compiler/msgs:Msg" %t121)
  store i64 %t122, ptr %l56
  br label %bb26
bb26:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load %"compiler/source:Span", ptr %l1
  %t127 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t123, %"compiler/source:Span" %t124)
  store ptr %t127, ptr %l59
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t128 = load ptr, ptr %l59, !tbaa !29
  store ptr %t128, ptr %rv
  br label %ret
bb28:
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l60, !tbaa !29
  %t130 = load ptr, ptr %l0, !tbaa !29
  store ptr %t130, ptr %l61, !tbaa !29
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/check:Checker", ptr %t131, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !29
  %t135 = load i64, ptr %l6, !tbaa !24
  %t138 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s0, ptr %t134, i64 %t135)
  store ptr %t138, ptr %l65
  br label %bb29
bb29:
  %t139 = load ptr, ptr %l65, !tbaa !29
  %t141 = getelementptr %"compiler/ast:Func", ptr %t139, i32 0, i32 2
  %t142 = load i32, ptr %t141, !tbaa !23
  %t143 = load ptr, ptr %l61, !tbaa !29
  %t145 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t143, i32 %t142)
  store { i64, ptr } %t145, ptr %l68
  br label %bb30
bb30:
  %t146 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t147 = load ptr, ptr %l60, !tbaa !29
  %t148 = getelementptr %"compiler/check:Checker", ptr %t147, i32 0, i32 50
  store { i64, ptr } %t146, ptr %t148, !tbaa !27
  %t149 = load ptr, ptr %l0, !tbaa !29
  store ptr %t149, ptr %l69, !tbaa !29
  %t150 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t150, ptr %l70
  %t151 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t151, ptr %l71
  %t152 = load i64, ptr %l6, !tbaa !24
  store i64 %t152, ptr %l72, !tbaa !24
  %t153 = load ptr, ptr %l3, !tbaa !29
  store ptr %t153, ptr %l74, !tbaa !29
  %t155 = icmp sge i64 0, 0
  br i1 %t155, label %bb31, label %bb32
bb31:
  %t157 = icmp sle i64 0, 1152921504606846975
  br i1 %t157, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_40ba663ddc86f216_8a32628f26d9e82)
  unreachable
bb33:
  %t159 = mul i64 0, 8
  %t160 = insertvalue { i64, ptr } undef, i64 0, 0
  %t161 = insertvalue { i64, ptr } %t160, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t161, ptr %l77, !tbaa !27
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load ptr, ptr %l4, !tbaa !29
  %t166 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v2, ptr %v0, ptr %t162, ptr %t163)
  store { i64, ptr } %t166, ptr %l80
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_40ba663ddc86f216_8a32628f26d9e82)
  unreachable
bb35:
  %t167 = icmp sge i64 0, 0
  br i1 %t167, label %bb36, label %bb37
bb36:
  %t169 = icmp sle i64 0, 2305843009213693951
  br i1 %t169, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_e2e10646092ca22b_113878b4617d7337)
  unreachable
bb38:
  %t171 = mul i64 0, 4
  %t172 = insertvalue { i64, ptr } undef, i64 0, 0
  %t173 = insertvalue { i64, ptr } %t172, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t174 = load ptr, ptr %l69, !tbaa !29
  %t175 = load %"compiler/source:Span", ptr %l70
  %t176 = load %"compiler/source:Span", ptr %l71
  %t177 = load i64, ptr %l72, !tbaa !24
  %t178 = load ptr, ptr %l74, !tbaa !29
  %t179 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t180 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t182 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v0, ptr %v0, ptr %v3, ptr %v3, ptr %t174, %"compiler/source:Span" %t175, %"compiler/source:Span" %t176, i64 %t177, ptr %t178, { i64, ptr } %t179, { i64, ptr } %t180, { i64, ptr } %t173)
  store ptr %t182, ptr %l84
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_e2e10646092ca22b_113878b4617d7337)
  unreachable
bb40:
  call void @__olang_scope_close(ptr %s0)
  %t183 = load ptr, ptr %l84, !tbaa !29
  store ptr %t183, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l5 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l15 = alloca ptr
  %l20 = alloca %"compiler/check:frame"
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l29 = alloca i64
  %l32 = alloca i1
  %l33 = alloca i1
  %l37 = alloca i1
  %l38 = alloca i32
  %rv = alloca ptr
  %t25 = alloca %"compiler/check:frame", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 16
  store ptr %t3, ptr %l7, !tbaa !29
  %t4 = load i64, ptr %l1, !tbaa !24
  store i64 %t4, ptr %l8, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l9, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/load:Loader", ptr %t12, i32 0, i32 10
  %t15 = load i64, ptr %l2, !tbaa !24
  %t18 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t14, i64 %t15)
  store ptr %t18, ptr %l15
  br label %bb1
bb1:
  %t19 = load ptr, ptr %l15, !tbaa !29
  %t21 = getelementptr %"compiler/load:Module", ptr %t19, i32 0, i32 4
  %t22 = load i64, ptr %t21, !tbaa !24
  %t26 = load i64, ptr %l8, !tbaa !24
  %t27 = load i64, ptr %l9, !tbaa !24
  call void @compiler_2fcheck_3aframe_2ector(ptr %t25, ptr %v0, i64 %t26, i64 %t27, i64 %t22, i32 %a3, i32 %a4)
  call void @llvm.memmove.p0.p0.i64(ptr %l20, ptr %t25, i64 1488, i1 false)
  br label %bb2
bb2:
  %t31 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 1488, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t31, ptr %l20, i64 1488, i1 false)
  %t32 = load ptr, ptr %l7, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_Hc321aad2e90dd8996307445942f8d6e9(ptr %v0, ptr %v0, ptr %t32, ptr %t31)
  br label %bb3
bb3:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v1, ptr %t34)
  store ptr %t36, ptr %l23
  br label %bb4
bb4:
  %t37 = load ptr, ptr %l23, !tbaa !29
  store ptr %t37, ptr %l5, !tbaa !29
  %t38 = load ptr, ptr %l5, !tbaa !29
  store ptr %t38, ptr %l24, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/generic:Program", ptr %t42, i32 0, i32 0
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = getelementptr %"compiler/load:Loader", ptr %t45, i32 0, i32 4
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t48)
  store i64 %t50, ptr %l29
  br label %bb5
bb5:
  %t51 = load i64, ptr %l29, !tbaa !24
  %t52 = load ptr, ptr %l24, !tbaa !29
  %t53 = getelementptr %"compiler/check:frame", ptr %t52, i32 0, i32 42
  store i64 %t51, ptr %t53, !tbaa !24
  %t54 = load i64, ptr %l1, !tbaa !24
  %t56 = icmp sge i64 %t54, 0
  br i1 %t56, label %bb6, label %bb7
bb6:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 54
  %t61 = load i64, ptr %l1, !tbaa !24
  %t64 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %t60, i64 %t61)
  %t65 = extractvalue { i32, i1 } %t64, 1
  %t66 = extractvalue { i32, i1 } %t64, 0
  store i32 %t66, ptr %l38
  %t67 = icmp ne i32 %t66, 0
  br i1 %t67, label %bb9, label %ok.68, !prof !99
ok.68:
  store i1 %t65, ptr %l37
  br label %bb8
bb7:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb12
bb8:
  %t69 = load i1, ptr %l37, !tbaa !21
  store i1 %t69, ptr %l33, !tbaa !21
  br label %bb11
bb9:
  br label %bb10
bb10:
  call void @__olang_ert_req_clear()
  store i1 false, ptr %l33, !tbaa !21
  br label %bb11
bb11:
  %t70 = load i1, ptr %l33, !tbaa !21
  store i1 %t70, ptr %l32, !tbaa !21
  br label %bb12
bb12:
  %t71 = load i1, ptr %l32, !tbaa !21
  br i1 %t71, label %bb13, label %bb14
bb13:
  %t72 = load ptr, ptr %l5, !tbaa !29
  %t74 = getelementptr %"compiler/check:frame", ptr %t72, i32 0, i32 26
  store i1 true, ptr %t74, !tbaa !21
  %t75 = load ptr, ptr %l5, !tbaa !29
  %t77 = getelementptr %"compiler/check:frame", ptr %t75, i32 0, i32 27
  store i1 true, ptr %t77, !tbaa !21
  br label %bb15
bb14:
  br label %bb15
bb15:
  %t78 = load ptr, ptr %l5, !tbaa !29
  store ptr %t78, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereSite(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca %"compiler/typed:SiteInfo"
  %l10 = alloca ptr
  %l15 = alloca %"compiler/typed:SiteInfo"
  %l19 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp slt i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr %l1, !tbaa !23
  store i32 %t5, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 14
  %t13 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t9, i64 %a2)
  store ptr %t13, ptr %l10
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l10, !tbaa !29
  %t16 = getelementptr %"compiler/typed:Body", ptr %t14, i32 0, i32 9
  %t17 = load i32, ptr %l1, !tbaa !23
  %t19 = sext i32 %t17 to i64
  %t22 = call %"compiler/typed:SiteInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aSiteInfo_3e_2eAt_3ccompiler_2ftyped_3aSiteInfo_3e(ptr %v0, ptr %t16, i64 %t19)
  store %"compiler/typed:SiteInfo" %t22, ptr %l15
  br label %bb5
bb5:
  %t23 = load %"compiler/typed:SiteInfo", ptr %l15
  store %"compiler/typed:SiteInfo" %t23, ptr %l3
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/typed:SiteInfo", ptr %l3, i32 0, i32 0
  %t26 = load i32, ptr %t25, !range !{i32 0, i32 9}
  %t27 = getelementptr %"compiler/typed:SiteInfo", ptr %l3, i32 0, i32 1
  %t28 = load %"compiler/source:Span", ptr %t27
  %t32 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t24, i32 %t26, %"compiler/source:Span" %t28)
  store i32 %t32, ptr %l19
  br label %bb6
bb6:
  %t33 = load i32, ptr %l19, !tbaa !23
  store i32 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereferable(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l8 = alloca i32
  %l14 = alloca i1
  %l19 = alloca i32
  %l22 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca i1
  %l34 = alloca i1
  %l35 = alloca i1
  %l39 = alloca i1
  %l44 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i32, ptr %l8, !range !{i32 0, i32 33}
  %t14 = trunc i64 18 to i32
  %t15 = icmp eq i32 %t11, %t14
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  %t24 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t20, i32 %t21)
  store i1 %t24, ptr %l14
  br label %bb4
bb3:
  br label %bb14
bb4:
  %t25 = load i1, ptr %l14, !tbaa !21
  %t26 = xor i1 %t25, true
  br i1 %t26, label %bb5, label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l1, !tbaa !23
  %t33 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l19
  br label %bb8
bb8:
  %t34 = load i32, ptr %l19, !range !{i32 0, i32 6}
  %t37 = trunc i64 4 to i32
  %t38 = icmp eq i32 %t34, %t37
  br i1 %t38, label %bb9, label %bb10
bb9:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l22, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 2
  %t47 = load i32, ptr %l1, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t50, ptr %l27
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t51 = load ptr, ptr %l22, !tbaa !29
  %t52 = load i32, ptr %l27, !tbaa !23
  %t53 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereferable(ptr %v0, ptr %t51, i32 %t52)
  store i1 %t53, ptr %l28
  br label %bb12
bb12:
  %t54 = load i1, ptr %l28, !tbaa !21
  store i1 %t54, ptr %rv
  br label %ret
bb13:
  store i1 true, ptr %rv
  br label %ret
bb14:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  %t62 = load i32, ptr %l1, !tbaa !23
  %t65 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t61, i32 %t62)
  store i1 %t65, ptr %l34
  br label %bb15
bb15:
  %t66 = load i1, ptr %l34, !tbaa !21
  br i1 %t66, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb18
bb17:
  %t67 = load i32, ptr %l1, !tbaa !23
  %t68 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t71 = icmp eq i32 %t67, %t68
  store i1 %t71, ptr %l35, !tbaa !21
  br label %bb18
bb18:
  %t73 = load i1, ptr %l35, !tbaa !21
  br i1 %t73, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb22
bb20:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/generic:Program", ptr %t77, i32 0, i32 2
  %t80 = load i32, ptr %l1, !tbaa !23
  %t83 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %t79, i32 %t80)
  store i1 %t83, ptr %l44
  br label %bb21
bb21:
  %t84 = load i1, ptr %l44, !tbaa !21
  store i1 %t84, ptr %l39, !tbaa !21
  br label %bb22
bb22:
  %t85 = load i1, ptr %l39, !tbaa !21
  %t86 = xor i1 %t85, true
  store i1 %t86, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/generic:Desc"
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i32, { i64, ptr } }
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca %"compiler/check:narrowed"
  %l22 = alloca { i64, ptr }
  %lp24 = alloca ptr
  %l28 = alloca %"compiler/generic:Desc"
  %l32 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l37 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca %"compiler/msgs:Msg"
  %l43 = alloca i64
  %l50 = alloca ptr
  %l51 = alloca %"compiler/source:Span"
  %l54 = alloca %"compiler/msgs:Msg"
  %l55 = alloca i64
  %l60 = alloca { i64, ptr }
  %l62 = alloca ptr
  %l68 = alloca i32
  %l72 = alloca i64
  %l75 = alloca i64
  %l95 = alloca i1
  %l99 = alloca %"compiler/source:Span"
  %l104 = alloca i32
  %l108 = alloca ptr
  %l115 = alloca i32
  %l127 = alloca i1
  %l129 = alloca ptr
  %l130 = alloca { i64, ptr }
  %l132 = alloca %"compiler/source:Span"
  %l135 = alloca { i64, ptr }
  %l136 = alloca { i64, ptr }
  %l139 = alloca { i64, ptr }
  %l141 = alloca %"compiler/msgs:Msg"
  %l142 = alloca i64
  %l147 = alloca { i32, { i64, ptr } }
  %l151 = alloca i1
  %l159 = alloca { i64, ptr }
  %l161 = alloca i64
  %l163 = alloca ptr
  %l166 = alloca i64
  %l168 = alloca i64
  %l173 = alloca %"compiler/check:narrowed"
  %l177 = alloca i1
  %l181 = alloca i1
  %l192 = alloca { i64, ptr }
  %l193 = alloca ptr
  %l194 = alloca { i64, ptr }
  %l196 = alloca %"compiler/source:Span"
  %l199 = alloca { i64, ptr }
  %l200 = alloca { i64, ptr }
  %l202 = alloca { i64, ptr }
  %l205 = alloca { i64, ptr }
  %l208 = alloca { i64, ptr }
  %l211 = alloca %"compiler/msgs:Msg"
  %l212 = alloca i64
  %l216 = alloca ptr
  %l221 = alloca i32
  %l222 = alloca { i64, ptr }
  %l223 = alloca { i64, ptr }
  %l226 = alloca %"compiler/source:Span"
  %l227 = alloca i32
  %l231 = alloca %"compiler/typed:Payload"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca ptr
  %t164 = alloca { i64, [4 x i64] }, align 8
  %t279 = alloca { i64, [4 x i64] }, align 8
  %t474 = alloca { i64, [4 x i64] }, align 8
  %t492 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t4, i32 %a3)
  store %"compiler/generic:Desc" %t8, ptr %l28
  br label %bb1
bb1:
  %t9 = load %"compiler/generic:Desc", ptr %l28
  store %"compiler/generic:Desc" %t9, ptr %l5
  %t10 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 0
  %t11 = load i64, ptr %t10, !tbaa !24
  %t12 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescField, !tbaa !24
  %t15 = icmp ne i64 %t11, %t12
  br i1 %t15, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l32, !tbaa !29
  store %"compiler/source:Span" %a2, ptr %l33
  %t19 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 0
  %t20 = load i64, ptr %t19, !tbaa !24
  %t21 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescCase, !tbaa !24
  %t24 = icmp eq i64 %t20, %t21
  br i1 %t24, label %bb4, label %bb5
bb3:
  br label %bb13
bb4:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l37, !tbaa !27
  br label %bb9
bb5:
  %t26 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 0
  %t27 = load i64, ptr %t26, !tbaa !24
  %t28 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescParam, !tbaa !24
  %t31 = icmp eq i64 %t27, %t28
  br i1 %t31, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l41, !tbaa !27
  br label %bb8
bb7:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %l41, !tbaa !27
  br label %bb8
bb8:
  %t33 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t33, ptr %l37, !tbaa !27
  br label %bb9
bb9:
  %t34 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflDescNoMember(ptr %s1, ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t34, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d22, i32 0, i32 1) }, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d23, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t35, ptr %l42
  br label %bb10
bb10:
  %t36 = load ptr, ptr %l32, !tbaa !29
  %t37 = load %"compiler/source:Span", ptr %l33
  %t38 = load %"compiler/msgs:Msg", ptr %l42
  %t39 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t36, %"compiler/source:Span" %t37, %"compiler/msgs:Msg" %t38)
  store i64 %t39, ptr %l43
  br label %bb11
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t40, { i64, ptr } %t41)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb13:
  %t45 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t49 = icmp ne i64 %t47, 1
  br i1 %t49, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l50, !tbaa !29
  %t52 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t52, ptr %l51
  %t53 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t57 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflOfArgs(ptr %s2, i64 %t55)
  store %"compiler/msgs:Msg" %t57, ptr %l54
  br label %bb16
bb15:
  br label %bb19
bb16:
  %t58 = load ptr, ptr %l50, !tbaa !29
  %t59 = load %"compiler/source:Span", ptr %l51
  %t60 = load %"compiler/msgs:Msg", ptr %l54
  %t61 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t58, %"compiler/source:Span" %t59, %"compiler/msgs:Msg" %t60)
  store i64 %t61, ptr %l55
  br label %bb17
bb17:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t62, { i64, ptr } %t63)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb19:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t68, ptr %l60, !tbaa !27
  %t69 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr ptr, ptr %t70, i64 0
  %t72 = load ptr, ptr %t71, !tbaa !39
  %t75 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %t67, ptr %t72)
  store ptr %t75, ptr %l62
  br label %bb20
bb20:
  %t76 = load ptr, ptr %l62, !tbaa !29
  store ptr %t76, ptr %l6, !tbaa !29
  %t77 = load ptr, ptr %l6, !tbaa !29
  %t79 = icmp eq ptr %t77, null
  br i1 %t79, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t82 = load ptr, ptr %l6, !tbaa !29
  store ptr %t82, ptr %l7, !tbaa !29
  %t84 = load ptr, ptr %l7, !tbaa !29
  %t86 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v2, ptr %t84)
  store i32 %t86, ptr %l68
  br label %bb24
bb24:
  %t87 = load i32, ptr %l68, !tbaa !23
  store i32 %t87, ptr %l8, !tbaa !23
  store i64 0, ptr %l9, !tbaa !24
  store i64 4, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t88 = load i64, ptr %l10, !tbaa !24
  %t89 = load i64, ptr %l9, !tbaa !24
  %t92 = icmp sgt i64 %t88, %t89
  br i1 %t92, label %bb25, label %bb26
bb25:
  %t94 = load i64, ptr %l11, !tbaa !24
  %t96 = icmp sgt i64 %t94, 0
  br i1 %t96, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb30
bb27:
  %t98 = load i64, ptr %l10, !tbaa !24
  %t99 = load i64, ptr %l9, !tbaa !24
  %t102 = sub i64 %t98, %t99
  %t103 = load i64, ptr %l11, !tbaa !24
  %t106 = add i64 %t102, %t103
  %t108 = sub i64 %t106, 1
  %t109 = load i64, ptr %l11, !tbaa !24
  %t112 = sdiv i64 %t108, %t109
  store i64 %t112, ptr %l75, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb29
bb29:
  %t114 = load i64, ptr %l75, !tbaa !24
  store i64 %t114, ptr %l72, !tbaa !24
  br label %bb30
bb30:
  %t115 = load i64, ptr %l72, !tbaa !24
  store i64 %t115, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb31
bb31:
  %t116 = load i64, ptr %l13, !tbaa !24
  %t117 = load i64, ptr %l12, !tbaa !24
  %t120 = icmp slt i64 %t116, %t117
  %t122 = xor i1 %t120, true
  br i1 %t122, label %bb32, label %bb33
bb32:
  br label %bb44
bb33:
  br label %bb34
bb34:
  %t124 = load i64, ptr %l9, !tbaa !24
  %t125 = load i64, ptr %l13, !tbaa !24
  %t126 = load i64, ptr %l11, !tbaa !24
  %t129 = mul i64 %t125, %t126
  %t132 = add i64 %t124, %t129
  store i64 %t132, ptr %l14, !tbaa !24
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load i32, ptr %l8, !tbaa !23
  %t138 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t134, i32 %t135)
  store i1 %t138, ptr %l95
  br label %bb35
bb35:
  %t139 = load i1, ptr %l95, !tbaa !21
  %t140 = xor i1 %t139, true
  br i1 %t140, label %bb36, label %bb37
bb36:
  br label %bb44
bb37:
  br label %bb38
bb38:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullRead(ptr %v0, ptr %v2, ptr %t142, ptr %t143)
  br label %bb39
bb39:
  %t146 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t146, ptr %l99
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/check:Checker", ptr %t147, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t152 = getelementptr %"compiler/generic:Program", ptr %t150, i32 0, i32 2
  %t153 = load i32, ptr %l8, !tbaa !23
  %t156 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t152, i32 %t153)
  store i32 %t156, ptr %l104
  br label %bb40
bb40:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load %"compiler/source:Span", ptr %l1
  %t159 = load ptr, ptr %l7, !tbaa !29
  %t163 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v2, ptr %v2, ptr %t157, %"compiler/source:Span" %t158, ptr %t159)
  store ptr %t163, ptr %l108
  br label %bb41
bb41:
  store { i64, [4 x i64] } zeroinitializer, ptr %t164
  %t165 = getelementptr { i64, [4 x i64] }, ptr %t164, i32 0, i32 0
  store i64 2, ptr %t165
  %t166 = load %"compiler/source:Span", ptr %l99
  %t167 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t166, 0
  %t168 = load i32, ptr %l104, !tbaa !23
  %t169 = insertvalue { %"compiler/source:Span", i32, ptr } %t167, i32 %t168, 1
  %t170 = load ptr, ptr %l108, !tbaa !29
  %t171 = insertvalue { %"compiler/source:Span", i32, ptr } %t169, ptr %t170, 2
  %t172 = getelementptr { i64, [4 x i64] }, ptr %t164, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t171, ptr %t172
  %t173 = load { i64, [4 x i64] }, ptr %t164
  %t175 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t173, ptr %t175
  store ptr %t175, ptr %l7, !tbaa !29
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/check:Checker", ptr %t177, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !29
  %t182 = getelementptr %"compiler/generic:Program", ptr %t180, i32 0, i32 2
  %t183 = load i32, ptr %l8, !tbaa !23
  %t186 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t182, i32 %t183)
  store i32 %t186, ptr %l115
  br label %bb42
bb42:
  %t187 = load i32, ptr %l115, !tbaa !23
  store i32 %t187, ptr %l8, !tbaa !23
  br label %bb43
bb43:
  %t188 = load i64, ptr %l13, !tbaa !24
  %t190 = add i64 %t188, 1
  store i64 %t190, ptr %l13, !tbaa !24
  br label %bb31
bb44:
  %t192 = load i32, ptr %l8, !tbaa !23
  %t193 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t196 = icmp eq i32 %t192, %t193
  br i1 %t196, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr %"compiler/check:Checker", ptr %t199, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !29
  %t204 = getelementptr %"compiler/generic:Program", ptr %t202, i32 0, i32 2
  %t205 = load i32, ptr %l8, !tbaa !23
  %t206 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 1
  %t207 = load i32, ptr %t206, !tbaa !23
  %t211 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t204, i32 %t205, i32 %t207)
  store i1 %t211, ptr %l127
  br label %bb48
bb48:
  %t212 = load i1, ptr %l127, !tbaa !21
  %t213 = xor i1 %t212, true
  br i1 %t213, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s9
  %t215 = load ptr, ptr %l0, !tbaa !29
  store ptr %t215, ptr %l129, !tbaa !29
  %t216 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t216, ptr %l130, !tbaa !27
  %t217 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !27
  %t219 = getelementptr ptr, ptr %t218, i64 0
  %t220 = load ptr, ptr %t219, !tbaa !39
  %t222 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t220)
  store %"compiler/source:Span" %t222, ptr %l132
  br label %bb51
bb50:
  br label %bb56
bb51:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 1
  %t225 = load i32, ptr %t224, !tbaa !23
  %t228 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t223, i32 %t225)
  store { i64, ptr } %t228, ptr %l135
  br label %bb52
bb52:
  %t229 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t229, 0
  %t231 = extractvalue { i64, ptr } %t229, 1
  %t232 = mul i64 %t230, 1
  %t233 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t232)
  call void @llvm.memcpy.p0.p0.i64(ptr %t233, ptr %t231, i64 %t232, i1 false)
  %t234 = insertvalue { i64, ptr } undef, i64 %t230, 0
  %t235 = insertvalue { i64, ptr } %t234, ptr %t233, 1
  store { i64, ptr } %t235, ptr %l136, !tbaa !27
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t237 = load i32, ptr %l8, !tbaa !23
  %t240 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t236, i32 %t237)
  store { i64, ptr } %t240, ptr %l139
  br label %bb53
bb53:
  %t241 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t242 = extractvalue { i64, ptr } %t241, 0
  %t243 = extractvalue { i64, ptr } %t241, 1
  %t244 = mul i64 %t242, 1
  %t245 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t244)
  call void @llvm.memcpy.p0.p0.i64(ptr %t245, ptr %t243, i64 %t244, i1 false)
  %t246 = insertvalue { i64, ptr } undef, i64 %t242, 0
  %t247 = insertvalue { i64, ptr } %t246, ptr %t245, 1
  %t248 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t250 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflOfType(ptr %s9, ptr %s9, ptr %s9, { i64, ptr } %t248, { i64, ptr } %t247)
  store %"compiler/msgs:Msg" %t250, ptr %l141
  br label %bb54
bb54:
  %t251 = load ptr, ptr %l129, !tbaa !29
  %t252 = load %"compiler/source:Span", ptr %l132
  %t253 = load %"compiler/msgs:Msg", ptr %l141
  %t254 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s9, ptr %t251, %"compiler/source:Span" %t252, %"compiler/msgs:Msg" %t253)
  store i64 %t254, ptr %l142
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb56:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr %"compiler/check:Checker", ptr %t256, i32 0, i32 1
  %t259 = load ptr, ptr %t258, !tbaa !29
  %t260 = load %"compiler/generic:Desc", ptr %l5
  %t263 = call { i32, { i64, ptr } } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescType(ptr %v0, ptr %s0, ptr %t259, %"compiler/generic:Desc" %t260)
  store { i32, { i64, ptr } } %t263, ptr %l147
  br label %bb57
bb57:
  %t264 = load { i32, { i64, ptr } }, ptr %l147
  store { i32, { i64, ptr } } %t264, ptr %l15
  %t265 = getelementptr { i32, { i64, ptr } }, ptr %l15, i32 0, i32 0
  %t266 = load i32, ptr %t265, !tbaa !23
  store i32 %t266, ptr %l16, !tbaa !23
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = load i32, ptr %l8, !tbaa !23
  %t272 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t268, i32 %t269)
  store i1 %t272, ptr %l151
  br label %bb58
bb58:
  %t273 = load i1, ptr %l151, !tbaa !21
  br i1 %t273, label %bb59, label %bb60
bb59:
  %t274 = load %"compiler/source:Span", ptr %l1
  %t275 = load i32, ptr %l16, !tbaa !23
  %t276 = load ptr, ptr %l7, !tbaa !29
  %t277 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 3
  %t278 = load i64, ptr %t277, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t279
  %t280 = getelementptr { i64, [4 x i64] }, ptr %t279, i32 0, i32 0
  store i64 3, ptr %t280
  %t282 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t274, 0
  %t284 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t282, i32 %t275, 1
  %t286 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t284, ptr %t276, 2
  %t288 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t286, i64 %t278, 3
  %t289 = getelementptr { i64, [4 x i64] }, ptr %t279, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t288, ptr %t289
  %t290 = load { i64, [4 x i64] }, ptr %t279
  %t292 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t290, ptr %t292
  call void @__olang_scope_close(ptr %s0)
  store ptr %t292, ptr %rv
  br label %ret
bb60:
  br label %bb61
bb61:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t295, ptr %l159, !tbaa !27
  %t296 = getelementptr { i64, ptr }, ptr %l159, i32 0, i32 1
  %t297 = load ptr, ptr %t296, !tbaa !27
  %t298 = getelementptr ptr, ptr %t297, i64 0
  %t299 = load ptr, ptr %t298, !tbaa !39
  %t302 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowLocal(ptr %v0, ptr %v1, ptr %t294, ptr %t299)
  store i64 %t302, ptr %l161
  br label %bb62
bb62:
  %t303 = load i64, ptr %l161, !tbaa !24
  store i64 %t303, ptr %l17, !tbaa !24
  store i1 false, ptr %l18, !tbaa !21
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t306 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t304)
  store ptr %t306, ptr %l163
  br label %bb63
bb63:
  %t307 = load ptr, ptr %l163, !tbaa !29
  %t309 = getelementptr %"compiler/check:frame", ptr %t307, i32 0, i32 46
  store ptr %t309, ptr %l19, !tbaa !29
  store i64 0, ptr %l20, !tbaa !24
  br label %bb64
bb64:
  %t311 = load i64, ptr %l20, !tbaa !24
  store i64 %t311, ptr %l166, !tbaa !24
  %t312 = load ptr, ptr %l19, !tbaa !29
  %t314 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLen_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t312)
  store i64 %t314, ptr %l168
  br label %bb65
bb65:
  %t315 = load i64, ptr %l166, !tbaa !24
  %t316 = load i64, ptr %l168, !tbaa !24
  %t317 = icmp slt i64 %t315, %t316
  %t319 = xor i1 %t317, true
  br i1 %t319, label %bb66, label %bb67
bb66:
  br label %bb80
bb67:
  br label %bb68
bb68:
  %t321 = load ptr, ptr %l19, !tbaa !29
  %t322 = load i64, ptr %l20, !tbaa !24
  %t325 = call %"compiler/check:narrowed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eAt_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t321, i64 %t322)
  store %"compiler/check:narrowed" %t325, ptr %l173
  br label %bb69
bb69:
  %t326 = load %"compiler/check:narrowed", ptr %l173
  store %"compiler/check:narrowed" %t326, ptr %l21
  %t327 = getelementptr %"compiler/check:narrowed", ptr %l21, i32 0, i32 0
  %t328 = load i64, ptr %t327, !tbaa !24
  %t329 = load i64, ptr %l17, !tbaa !24
  %t332 = icmp eq i64 %t328, %t329
  br i1 %t332, label %bb70, label %bb71
bb70:
  %t334 = getelementptr %"compiler/check:narrowed", ptr %l21, i32 0, i32 1
  %t335 = load i64, ptr %t334, !tbaa !24
  %t336 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 2
  %t337 = load i64, ptr %t336, !tbaa !24
  %t340 = icmp eq i64 %t335, %t337
  store i1 %t340, ptr %l177, !tbaa !21
  br label %bb72
bb71:
  store i1 false, ptr %l177, !tbaa !21
  br label %bb72
bb72:
  %t342 = load i1, ptr %l177, !tbaa !21
  br i1 %t342, label %bb73, label %bb74
bb73:
  %t343 = getelementptr %"compiler/check:narrowed", ptr %l21, i32 0, i32 5
  %t344 = load i1, ptr %t343, !tbaa !21
  %t346 = xor i1 %t344, true
  store i1 %t346, ptr %l181, !tbaa !21
  br label %bb75
bb74:
  store i1 false, ptr %l181, !tbaa !21
  br label %bb75
bb75:
  %t348 = load i1, ptr %l181, !tbaa !21
  br i1 %t348, label %bb76, label %bb77
bb76:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb78
bb77:
  br label %bb78
bb78:
  br label %bb79
bb79:
  %t349 = load i64, ptr %l20, !tbaa !24
  %t351 = add i64 %t349, 1
  store i64 %t351, ptr %l20, !tbaa !24
  br label %bb64
bb80:
  %t353 = load i1, ptr %l18, !tbaa !21
  %t355 = xor i1 %t353, true
  br i1 %t355, label %bb81, label %bb82
bb81:
  store %olang.scope zeroinitializer, ptr %s15
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t359 = getelementptr %"compiler/check:Checker", ptr %t357, i32 0, i32 1
  %t360 = load ptr, ptr %t359, !tbaa !29
  %t362 = getelementptr %"compiler/generic:Program", ptr %t360, i32 0, i32 2
  %t363 = load i32, ptr %l8, !tbaa !23
  %t366 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %s15, ptr %t362, i32 %t363)
  store { i64, ptr } %t366, ptr %l192
  br label %bb83
bb82:
  br label %bb90
bb83:
  %t367 = load { i64, ptr }, ptr %l192, !tbaa !27
  store { i64, ptr } %t367, ptr %l22, !tbaa !27
  %t368 = load ptr, ptr %l0, !tbaa !29
  store ptr %t368, ptr %l193, !tbaa !29
  %t369 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t369, ptr %l194, !tbaa !27
  %t370 = getelementptr { i64, ptr }, ptr %l194, i32 0, i32 1
  %t371 = load ptr, ptr %t370, !tbaa !27
  %t372 = getelementptr ptr, ptr %t371, i64 0
  %t373 = load ptr, ptr %t372, !tbaa !39
  %t375 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t373)
  store %"compiler/source:Span" %t375, ptr %l196
  br label %bb84
bb84:
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t377 = load i32, ptr %l8, !tbaa !23
  %t380 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s15, ptr %t376, i32 %t377)
  store { i64, ptr } %t380, ptr %l199
  br label %bb85
bb85:
  %t381 = load { i64, ptr }, ptr %l199, !tbaa !27
  %t382 = extractvalue { i64, ptr } %t381, 0
  %t383 = extractvalue { i64, ptr } %t381, 1
  %t384 = mul i64 %t382, 1
  %t385 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t384)
  call void @llvm.memcpy.p0.p0.i64(ptr %t385, ptr %t383, i64 %t384, i1 false)
  %t386 = insertvalue { i64, ptr } undef, i64 %t382, 0
  %t387 = insertvalue { i64, ptr } %t386, ptr %t385, 1
  store { i64, ptr } %t387, ptr %l200, !tbaa !27
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t389 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t389, ptr %l202, !tbaa !27
  %t390 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 2
  %t391 = load i64, ptr %t390, !tbaa !24
  %t393 = getelementptr { i64, ptr }, ptr %l202, i32 0, i32 1
  %t394 = load ptr, ptr %t393, !tbaa !27
  %t395 = getelementptr i32, ptr %t394, i64 %t391
  %t396 = load i32, ptr %t395, !tbaa !33
  %t399 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s15, ptr %t388, i32 %t396)
  store { i64, ptr } %t399, ptr %l205
  br label %bb86
bb86:
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t401 = load %"compiler/generic:Desc", ptr %l5
  %t404 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescName(ptr %v0, ptr %s15, ptr %t400, %"compiler/generic:Desc" %t401)
  store { i64, ptr } %t404, ptr %l208
  br label %bb87
bb87:
  %t405 = load { i64, ptr }, ptr %l205, !tbaa !27
  %t406 = extractvalue { i64, ptr } %t405, 1
  %t407 = extractvalue { i64, ptr } %t405, 0
  %t408 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t409 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t410 = add i64 %t407, %t409
  %t411 = load { i64, ptr }, ptr %l208, !tbaa !27
  %t412 = extractvalue { i64, ptr } %t411, 1
  %t413 = extractvalue { i64, ptr } %t411, 0
  %t414 = add i64 %t410, %t413
  %t415 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t414)
  call void @olang_textcopy(ptr %t415, ptr %t406, i64 %t407)
  %t416 = getelementptr i8, ptr %t415, i64 %t407
  call void @olang_textcopy(ptr %t416, ptr %t408, i64 %t409)
  %t417 = getelementptr i8, ptr %t416, i64 %t409
  call void @olang_textcopy(ptr %t417, ptr %t412, i64 %t413)
  %t418 = insertvalue { i64, ptr } undef, i64 %t414, 0
  %t419 = insertvalue { i64, ptr } %t418, ptr %t415, 1
  %t421 = extractvalue { i64, ptr } %t419, 0
  %t422 = extractvalue { i64, ptr } %t419, 1
  %t423 = mul i64 %t421, 1
  %t424 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t423)
  call void @llvm.memcpy.p0.p0.i64(ptr %t424, ptr %t422, i64 %t423, i1 false)
  %t425 = insertvalue { i64, ptr } undef, i64 %t421, 0
  %t426 = insertvalue { i64, ptr } %t425, ptr %t424, 1
  %t427 = load { i64, ptr }, ptr %l200, !tbaa !27
  %t429 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eFieldOfEnum(ptr %s15, ptr %s15, ptr %s15, { i64, ptr } %t427, { i64, ptr } %t426)
  store %"compiler/msgs:Msg" %t429, ptr %l211
  br label %bb88
bb88:
  %t430 = load ptr, ptr %l193, !tbaa !29
  %t431 = load %"compiler/source:Span", ptr %l196
  %t432 = load %"compiler/msgs:Msg", ptr %l211
  %t433 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s15, ptr %t430, %"compiler/source:Span" %t431, %"compiler/msgs:Msg" %t432)
  store i64 %t433, ptr %l212
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb90:
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t437 = getelementptr %"compiler/check:Checker", ptr %t435, i32 0, i32 1
  %t438 = load ptr, ptr %t437, !tbaa !29
  %t440 = getelementptr %"compiler/generic:Program", ptr %t438, i32 0, i32 2
  store ptr %t440, ptr %l216, !tbaa !29
  %t441 = load ptr, ptr %l0, !tbaa !29
  %t443 = getelementptr %"compiler/check:Checker", ptr %t441, i32 0, i32 1
  %t444 = load ptr, ptr %t443, !tbaa !29
  %t446 = getelementptr %"compiler/generic:Program", ptr %t444, i32 0, i32 2
  %t447 = load i32, ptr %l8, !tbaa !23
  %t450 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t446, i32 %t447)
  store i32 %t450, ptr %l221
  br label %bb91
bb91:
  %t451 = load ptr, ptr %l216, !tbaa !29
  %t452 = load i32, ptr %l221, !tbaa !23
  %t453 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t451, i32 %t452)
  store { i64, ptr } %t453, ptr %l222
  br label %bb92
bb92:
  %t454 = load { i64, ptr }, ptr %l222, !tbaa !27
  store { i64, ptr } %t454, ptr %l223, !tbaa !27
  %t455 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 2
  %t456 = load i64, ptr %t455, !tbaa !24
  %t458 = getelementptr { i64, ptr }, ptr %l223, i32 0, i32 1
  %t459 = load ptr, ptr %t458, !tbaa !27
  %t460 = getelementptr i32, ptr %t459, i64 %t456
  %t461 = load i32, ptr %t460, !tbaa !33
  %t463 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t463, ptr %l226
  store i32 %t461, ptr %l227, !tbaa !23
  %t465 = load ptr, ptr %l7, !tbaa !29
  %t466 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 2
  %t467 = load i64, ptr %t466, !tbaa !24
  %t471 = call %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v2, ptr %v2, ptr %t465, i64 %t467, i32 0)
  store %"compiler/typed:Payload" %t471, ptr %l231
  br label %bb93
bb93:
  %t472 = load %"compiler/typed:Payload", ptr %l231
  %t473 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store %"compiler/typed:Payload" %t472, ptr %t473
  store { i64, [4 x i64] } zeroinitializer, ptr %t474
  %t475 = getelementptr { i64, [4 x i64] }, ptr %t474, i32 0, i32 0
  store i64 5, ptr %t475
  %t476 = load %"compiler/source:Span", ptr %l226
  %t477 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t476, 0
  %t478 = load i32, ptr %l227, !tbaa !23
  %t479 = insertvalue { %"compiler/source:Span", i32, ptr } %t477, i32 %t478, 1
  %t481 = insertvalue { %"compiler/source:Span", i32, ptr } %t479, ptr %t473, 2
  %t482 = getelementptr { i64, [4 x i64] }, ptr %t474, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t481, ptr %t482
  %t483 = load { i64, [4 x i64] }, ptr %t474
  %t484 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store ptr %t484, ptr %lp24
  %t486 = load ptr, ptr %lp24
  store { i64, [4 x i64] } %t483, ptr %t486
  %t487 = load %"compiler/source:Span", ptr %l1
  %t488 = load i32, ptr %l16, !tbaa !23
  %t489 = load ptr, ptr %lp24
  %t490 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 3
  %t491 = load i64, ptr %t490, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t492
  %t493 = getelementptr { i64, [4 x i64] }, ptr %t492, i32 0, i32 0
  store i64 3, ptr %t493
  %t495 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t487, 0
  %t497 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t495, i32 %t488, 1
  %t499 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t497, ptr %t489, 2
  %t501 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t499, i64 %t491, 3
  %t502 = getelementptr { i64, [4 x i64] }, ptr %t492, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t501, ptr %t502
  %t503 = load { i64, [4 x i64] }, ptr %t492
  %t505 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t503, ptr %t505
  call void @__olang_scope_close(ptr %s0)
  store ptr %t505, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflRendered(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca %"compiler/check:reflVal"
  %l5 = alloca %"compiler/check:reflVal"
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t5 = call %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflFold(ptr %v0, ptr %v1, ptr %s0, ptr %a0, ptr %a1)
  store %"compiler/check:reflVal" %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load %"compiler/check:reflVal", ptr %l5
  store %"compiler/check:reflVal" %t6, ptr %l2
  %t7 = getelementptr %"compiler/check:reflVal", ptr %l2, i32 0, i32 0
  %t8 = load i1, ptr %t7, !tbaa !21
  %t10 = xor i1 %t8, true
  br i1 %t10, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t13 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t13, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = getelementptr %"compiler/check:reflVal", ptr %l2, i32 0, i32 1
  %t15 = load i64, ptr %t14, !tbaa !24
  %t16 = load i64, ptr @G_2ecompiler_2fcheck_2eRvText, !tbaa !24
  %t19 = icmp eq i64 %t15, %t16
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t21 = getelementptr %"compiler/check:reflVal", ptr %l2, i32 0, i32 3
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  store { i64, ptr } %t22, ptr %l13, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 0
  store i64 %t25, ptr %l14, !tbaa !24
  %t26 = load i64, ptr %l14, !tbaa !24
  %t27 = mul i64 %t26, 1
  %t28 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t27)
  %t29 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  store { i64, ptr } %t30, ptr %l15, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = load i64, ptr %l14, !tbaa !24
  %t36 = mul i64 %t35, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t32, ptr %t34, i64 %t36, i1 false)
  %t37 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t37, ptr %l13, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t38 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t39 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t38, 1
  store { i32, { i64, ptr } } %t39, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t40 = getelementptr %"compiler/check:reflVal", ptr %l2, i32 0, i32 1
  %t41 = load i64, ptr %t40, !tbaa !24
  %t42 = load i64, ptr @G_2ecompiler_2fcheck_2eRvInt, !tbaa !24
  %t45 = icmp eq i64 %t41, %t42
  br i1 %t45, label %bb8, label %bb9
bb8:
  %t47 = getelementptr %"compiler/check:reflVal", ptr %l2, i32 0, i32 2
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = call i64 @__olang_fmt_i64(ptr null, i64 %t48)
  %t51 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t50)
  %t52 = call i64 @__olang_fmt_i64(ptr %t51, i64 %t48)
  %t53 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t51, 1
  call void @__olang_scope_close(ptr %s0)
  %t56 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t54, 1
  store { i32, { i64, ptr } } %t56, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t57 = getelementptr %"compiler/check:reflVal", ptr %l2, i32 0, i32 1
  %t58 = load i64, ptr %t57, !tbaa !24
  %t59 = load i64, ptr @G_2ecompiler_2fcheck_2eRvBool, !tbaa !24
  %t62 = icmp eq i64 %t58, %t59
  br i1 %t62, label %bb11, label %bb12
bb11:
  %t64 = getelementptr %"compiler/check:reflVal", ptr %l2, i32 0, i32 2
  %t65 = load i64, ptr %t64, !tbaa !24
  %t67 = icmp eq i64 %t65, 1
  br i1 %t67, label %bb13, label %bb14
bb12:
  br label %bb16
bb13:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %l27, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t69, ptr %l26, !tbaa !27
  br label %bb15
bb14:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %l29, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t71, ptr %l26, !tbaa !27
  br label %bb15
bb15:
  %t73 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 0
  store i64 %t74, ptr %l31, !tbaa !24
  %t75 = load i64, ptr %l31, !tbaa !24
  %t76 = mul i64 %t75, 1
  %t77 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t76)
  %t78 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  store { i64, ptr } %t79, ptr %l32, !tbaa !27
  %t80 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = load i64, ptr %l31, !tbaa !24
  %t85 = mul i64 %t84, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t81, ptr %t83, i64 %t85, i1 false)
  %t86 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t86, ptr %l26, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t87 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t88 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t87, 1
  store { i32, { i64, ptr } } %t88, ptr %rv
  br label %ret
bb16:
  call void @__olang_scope_close(ptr %s0)
  %t90 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t90, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/generic:Origin"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca ptr
  %l15 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l26 = alloca %"compiler/source:Span"
  %l27 = alloca %"compiler/source:Span"
  %l29 = alloca ptr
  %l31 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca %"compiler/source:Span"
  %l36 = alloca i64
  %l37 = alloca %"compiler/generic:Origin"
  %l39 = alloca ptr
  %l41 = alloca ptr
  %l46 = alloca i32
  %l53 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t5, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 38
  %t13 = load %"compiler/generic:Origin", ptr %t12
  store %"compiler/generic:Origin" %t13, ptr %l2
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t15)
  store %"compiler/source:Span" %t17, ptr %l13
  br label %bb4
bb4:
  %t18 = load %"compiler/source:Span", ptr %l13
  store %"compiler/source:Span" %t18, ptr %l3
  %t19 = load ptr, ptr %l1, !tbaa !29
  store ptr %t19, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t20 = load ptr, ptr %l14, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb5, label %bb6
bb5:
  %t23 = load ptr, ptr %l14, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 8}
  %t26 = icmp eq i64 %t24, 0
  store i1 %t26, ptr %l15, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l15, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t30, i32 0, i32 2
  %t32 = load { i64, ptr }, ptr %t31
  store { i64, ptr } %t32, ptr %l4, !tbaa !27
  br label %bb9
bb8:
  br label %bb15
bb9:
  %t34 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l23, !tbaa !29
  %t41 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t41, ptr %l24, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr ptr, ptr %t43, i64 0
  %t45 = load ptr, ptr %t44, !tbaa !39
  %t47 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t45)
  store %"compiler/source:Span" %t47, ptr %l26
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t48 = load ptr, ptr %l23, !tbaa !29
  %t49 = load %"compiler/source:Span", ptr %l26
  %t50 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleadWord(ptr %v0, ptr %t48, %"compiler/source:Span" %t49)
  store %"compiler/source:Span" %t50, ptr %l27
  br label %bb13
bb13:
  %t51 = load %"compiler/source:Span", ptr %l27
  store %"compiler/source:Span" %t51, ptr %l3
  br label %bb14
bb14:
  br label %bb20
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_af27478d58ae9a15_461e52858b358fe1)
  unreachable
bb20:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  store ptr %t55, ptr %l29, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t56)
  store ptr %t58, ptr %l31
  br label %bb21
bb21:
  %t59 = load ptr, ptr %l31, !tbaa !29
  %t61 = getelementptr %"compiler/check:frame", ptr %t59, i32 0, i32 2
  %t62 = load i64, ptr %t61, !tbaa !24
  store i64 %t62, ptr %l33, !tbaa !24
  %t63 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t63, ptr %l34
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecurInst(ptr %v0, ptr %t64)
  store i64 %t66, ptr %l36
  br label %bb22
bb22:
  %t67 = load i64, ptr %l33, !tbaa !24
  %t68 = load %"compiler/source:Span", ptr %l34
  %t69 = load i64, ptr %l36, !tbaa !24
  %t70 = call %"compiler/generic:Origin" @compiler_2fgeneric_3aOrigin_2ector(ptr %s0, i64 %t67, %"compiler/source:Span" %t68, i64 %t69)
  store %"compiler/generic:Origin" %t70, ptr %l37
  br label %bb23
bb23:
  %t71 = load %"compiler/generic:Origin", ptr %l37
  %t72 = load ptr, ptr %l29, !tbaa !29
  %t73 = getelementptr %"compiler/generic:Program", ptr %t72, i32 0, i32 38
  store %"compiler/generic:Origin" %t71, ptr %t73
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  store ptr %t77, ptr %l39, !tbaa !29
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t78)
  store ptr %t80, ptr %l41
  br label %bb24
bb24:
  %t81 = load ptr, ptr %l41, !tbaa !29
  %t83 = getelementptr %"compiler/check:frame", ptr %t81, i32 0, i32 4
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t86 = load ptr, ptr %l39, !tbaa !29
  %t89 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v0, ptr %v1, ptr %t86, ptr %t83, ptr %t84)
  store i32 %t89, ptr %l46
  br label %bb25
bb25:
  %t90 = load i32, ptr %l46, !tbaa !23
  store i32 %t90, ptr %l5, !tbaa !23
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/check:Checker", ptr %t91, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t95 = load %"compiler/generic:Origin", ptr %l2
  %t98 = getelementptr %"compiler/generic:Program", ptr %t94, i32 0, i32 38
  store %"compiler/generic:Origin" %t95, ptr %t98
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load ptr, ptr %l1, !tbaa !29
  %t104 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenMet(ptr %v0, ptr %v1, ptr %t99, ptr %t100)
  store i1 %t104, ptr %l53
  br label %bb26
bb26:
  %t105 = load i1, ptr %l53, !tbaa !21
  %t106 = xor i1 %t105, true
  br i1 %t106, label %bb27, label %bb28
bb27:
  %t108 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t108, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t110 = load i32, ptr %l5, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t110, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereturnStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca { i64, [3 x i64] }
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca { i64, [3 x i64] }
  %l17 = alloca ptr
  %l20 = alloca ptr
  %l24 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca %"compiler/source:Span"
  %l33 = alloca %"compiler/msgs:Msg"
  %l34 = alloca i64
  %l41 = alloca ptr
  %l42 = alloca %"compiler/source:Span"
  %l43 = alloca %"compiler/msgs:Msg"
  %l44 = alloca i64
  %l49 = alloca ptr
  %l53 = alloca %"compiler/source:Span"
  %l54 = alloca %"compiler/msgs:Msg"
  %l55 = alloca i64
  %l58 = alloca ptr
  %l59 = alloca %"compiler/source:Span"
  %l60 = alloca %"compiler/msgs:Msg"
  %l61 = alloca i64
  %l65 = alloca ptr
  %l69 = alloca %"compiler/source:Span"
  %l73 = alloca { i64, ptr }
  %l74 = alloca %"compiler/msgs:Msg"
  %l75 = alloca i64
  %l83 = alloca ptr
  %l87 = alloca %"compiler/source:Span"
  %l88 = alloca %"compiler/msgs:Msg"
  %l89 = alloca i64
  %l98 = alloca ptr
  %l102 = alloca %"compiler/source:Span"
  %l103 = alloca %"compiler/msgs:Msg"
  %l104 = alloca i64
  %l105 = alloca ptr
  %l108 = alloca ptr
  %l121 = alloca i1
  %l125 = alloca ptr
  %l126 = alloca %"compiler/source:Span"
  %l129 = alloca { i64, ptr }
  %l131 = alloca %"compiler/msgs:Msg"
  %l132 = alloca i64
  %l143 = alloca ptr
  %l144 = alloca %"compiler/source:Span"
  %l145 = alloca %"compiler/msgs:Msg"
  %l146 = alloca i64
  %l149 = alloca ptr
  %l151 = alloca { i64, [3 x i64] }
  %l153 = alloca { i64, ptr }
  %l156 = alloca ptr
  %l159 = alloca i32
  %l161 = alloca i32
  %l163 = alloca i1
  %l164 = alloca ptr
  %l167 = alloca i32
  %l168 = alloca i1
  %l176 = alloca ptr
  %l179 = alloca i1
  %l181 = alloca ptr
  %l183 = alloca ptr
  %l184 = alloca { i64, ptr }
  %l186 = alloca %"compiler/source:Span"
  %l188 = alloca i1
  %l194 = alloca i1
  %l196 = alloca ptr
  %l199 = alloca ptr
  %l200 = alloca ptr
  %l211 = alloca i32
  %l219 = alloca ptr
  %l224 = alloca i32
  %l225 = alloca { i64, ptr }
  %l235 = alloca i64
  %l241 = alloca i64
  %l244 = alloca i64
  %l264 = alloca ptr
  %l267 = alloca { i64, [3 x i64] }
  %l269 = alloca { i64, ptr }
  %l272 = alloca { i64, ptr }
  %l275 = alloca ptr
  %l277 = alloca { i64, ptr }
  %l280 = alloca i1
  %l282 = alloca ptr
  %l285 = alloca ptr
  %l286 = alloca ptr
  %l297 = alloca { i64, ptr }
  %l298 = alloca ptr
  %l299 = alloca %"compiler/source:Span"
  %l300 = alloca %"compiler/source:Span"
  %l301 = alloca i32
  %l305 = alloca %"compiler/typed:Make"
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %t34 = alloca { i64, [3 x i64] }, align 8
  %t126 = alloca { i64, [3 x i64] }, align 8
  %t161 = alloca { i64, [3 x i64] }, align 8
  %t259 = alloca { i64, [3 x i64] }, align 8
  %t341 = alloca { i64, [4 x i64] }, align 8
  %t409 = alloca { i64, [3 x i64] }, align 8
  %t624 = alloca { i64, [5 x i64] }, align 8
  %t636 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l20
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l20, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t9 = icmp sgt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l24, !tbaa !24
  br label %bb4
bb3:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb4
bb4:
  %t15 = load i64, ptr %l24, !tbaa !24
  store i64 %t15, ptr %l4, !tbaa !24
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t18 = getelementptr %"compiler/check:frame", ptr %t16, i32 0, i32 12
  %t19 = load i1, ptr %t18, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t21 = load i64, ptr %l4, !tbaa !24
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb7, label %bb8
bb6:
  br label %bb13
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l31, !tbaa !29
  %t26 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t26, ptr %l32
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnInTest(ptr %s2)
  store %"compiler/msgs:Msg" %t27, ptr %l33
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t28 = load ptr, ptr %l31, !tbaa !29
  %t29 = load %"compiler/source:Span", ptr %l32
  %t30 = load %"compiler/msgs:Msg", ptr %l33
  %t31 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t28, %"compiler/source:Span" %t29, %"compiler/msgs:Msg" %t30)
  store i64 %t31, ptr %l34
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb11:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load %"compiler/source:Span", ptr %l1
  store { i64, [3 x i64] } zeroinitializer, ptr %t34
  %t35 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 0
  store i64 6, ptr %t35
  %t37 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t33, 0
  %t38 = insertvalue { %"compiler/source:Span", ptr } %t37, ptr null, 1
  %t39 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t38, ptr %t39
  %t40 = load { i64, [3 x i64] }, ptr %t34
  %t42 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t40, ptr %t42
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t32, ptr %t42)
  br label %bb12
bb12:
  br label %ret
bb13:
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t47 = getelementptr %"compiler/check:frame", ptr %t45, i32 0, i32 13
  %t48 = load i1, ptr %t47, !tbaa !21
  br i1 %t48, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l41, !tbaa !29
  %t51 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t51, ptr %l42
  %t52 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnInCtor(ptr %s3)
  store %"compiler/msgs:Msg" %t52, ptr %l43
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t53 = load ptr, ptr %l41, !tbaa !29
  %t54 = load %"compiler/source:Span", ptr %l42
  %t55 = load %"compiler/msgs:Msg", ptr %l43
  %t56 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t53, %"compiler/source:Span" %t54, %"compiler/msgs:Msg" %t55)
  store i64 %t56, ptr %l44
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %ret
bb18:
  %t57 = load ptr, ptr %l3, !tbaa !29
  %t59 = getelementptr %"compiler/check:frame", ptr %t57, i32 0, i32 5
  %t60 = load i32, ptr %t59, !tbaa !23
  %t61 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t64 = icmp eq i32 %t60, %t61
  br i1 %t64, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t66 = load ptr, ptr %l0, !tbaa !29
  store ptr %t66, ptr %l49, !tbaa !29
  %t67 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t68 = load i32, ptr %t67, !tbaa !23
  %t69 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t70 = load i32, ptr %t69, !tbaa !23
  %t72 = add i32 %t70, 6
  %t75 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s4, i32 %t68, i32 %t72)
  store %"compiler/source:Span" %t75, ptr %l53
  br label %bb21
bb20:
  br label %bb24
bb21:
  %t76 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnInNoreturn(ptr %s4)
  store %"compiler/msgs:Msg" %t76, ptr %l54
  br label %bb22
bb22:
  %t77 = load ptr, ptr %l49, !tbaa !29
  %t78 = load %"compiler/source:Span", ptr %l53
  %t79 = load %"compiler/msgs:Msg", ptr %l54
  %t80 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t77, %"compiler/source:Span" %t78, %"compiler/msgs:Msg" %t79)
  store i64 %t80, ptr %l55
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s4)
  br label %ret
bb24:
  %t81 = load ptr, ptr %l3, !tbaa !29
  %t83 = getelementptr %"compiler/check:frame", ptr %t81, i32 0, i32 32
  %t84 = load i1, ptr %t83, !tbaa !21
  br i1 %t84, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s5
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l58, !tbaa !29
  %t87 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t87, ptr %l59
  %t88 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskClauseReturns(ptr %s5)
  store %"compiler/msgs:Msg" %t88, ptr %l60
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t89 = load ptr, ptr %l58, !tbaa !29
  %t90 = load %"compiler/source:Span", ptr %l59
  %t91 = load %"compiler/msgs:Msg", ptr %l60
  %t92 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t89, %"compiler/source:Span" %t90, %"compiler/msgs:Msg" %t91)
  store i64 %t92, ptr %l61
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s5)
  br label %ret
bb29:
  %t93 = load ptr, ptr %l3, !tbaa !29
  %t95 = getelementptr %"compiler/check:frame", ptr %t93, i32 0, i32 35
  %t96 = load i64, ptr %t95, !tbaa !24
  %t98 = icmp sge i64 %t96, 0
  br i1 %t98, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s6
  %t100 = load ptr, ptr %l0, !tbaa !29
  store ptr %t100, ptr %l65, !tbaa !29
  %t101 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t102 = load i32, ptr %t101, !tbaa !23
  %t103 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t104 = load i32, ptr %t103, !tbaa !23
  %t106 = add i32 %t104, 6
  %t109 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s6, i32 %t102, i32 %t106)
  store %"compiler/source:Span" %t109, ptr %l69
  br label %bb32
bb31:
  br label %bb37
bb32:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load ptr, ptr %l3, !tbaa !29
  %t113 = getelementptr %"compiler/check:frame", ptr %t111, i32 0, i32 36
  %t114 = load i1, ptr %t113, !tbaa !21
  %t117 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emsgOwner(ptr %v0, ptr %s6, ptr %t110, i1 %t114)
  store { i64, ptr } %t117, ptr %l73
  br label %bb33
bb33:
  %t118 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t119 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertMsgReturns(ptr %s6, ptr %s6, { i64, ptr } %t118)
  store %"compiler/msgs:Msg" %t119, ptr %l74
  br label %bb34
bb34:
  %t120 = load ptr, ptr %l65, !tbaa !29
  %t121 = load %"compiler/source:Span", ptr %l69
  %t122 = load %"compiler/msgs:Msg", ptr %l74
  %t123 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t120, %"compiler/source:Span" %t121, %"compiler/msgs:Msg" %t122)
  store i64 %t123, ptr %l75
  br label %bb35
bb35:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load %"compiler/source:Span", ptr %l1
  store { i64, [3 x i64] } zeroinitializer, ptr %t126
  %t127 = getelementptr { i64, [3 x i64] }, ptr %t126, i32 0, i32 0
  store i64 6, ptr %t127
  %t129 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t125, 0
  %t130 = insertvalue { %"compiler/source:Span", ptr } %t129, ptr null, 1
  %t131 = getelementptr { i64, [3 x i64] }, ptr %t126, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t130, ptr %t131
  %t132 = load { i64, [3 x i64] }, ptr %t126
  %t134 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t132, ptr %t134
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t124, ptr %t134)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s6)
  br label %ret
bb37:
  %t137 = load ptr, ptr %l3, !tbaa !29
  %t139 = getelementptr %"compiler/check:frame", ptr %t137, i32 0, i32 34
  %t140 = load i64, ptr %t139, !tbaa !24
  %t142 = icmp sge i64 %t140, 0
  br i1 %t142, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s7
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l83, !tbaa !29
  %t145 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t146 = load i32, ptr %t145, !tbaa !23
  %t147 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t148 = load i32, ptr %t147, !tbaa !23
  %t150 = add i32 %t148, 6
  %t153 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s7, i32 %t146, i32 %t150)
  store %"compiler/source:Span" %t153, ptr %l87
  br label %bb40
bb39:
  br label %bb44
bb40:
  %t154 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeferReturns(ptr %s7)
  store %"compiler/msgs:Msg" %t154, ptr %l88
  br label %bb41
bb41:
  %t155 = load ptr, ptr %l83, !tbaa !29
  %t156 = load %"compiler/source:Span", ptr %l87
  %t157 = load %"compiler/msgs:Msg", ptr %l88
  %t158 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t155, %"compiler/source:Span" %t156, %"compiler/msgs:Msg" %t157)
  store i64 %t158, ptr %l89
  br label %bb42
bb42:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load %"compiler/source:Span", ptr %l1
  store { i64, [3 x i64] } zeroinitializer, ptr %t161
  %t162 = getelementptr { i64, [3 x i64] }, ptr %t161, i32 0, i32 0
  store i64 6, ptr %t162
  %t164 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t160, 0
  %t165 = insertvalue { %"compiler/source:Span", ptr } %t164, ptr null, 1
  %t166 = getelementptr { i64, [3 x i64] }, ptr %t161, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t165, ptr %t166
  %t167 = load { i64, [3 x i64] }, ptr %t161
  %t169 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t167, ptr %t169
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t159, ptr %t169)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s7)
  br label %ret
bb44:
  %t172 = load ptr, ptr %l3, !tbaa !29
  %t174 = getelementptr %"compiler/check:frame", ptr %t172, i32 0, i32 20
  %t175 = load i1, ptr %t174, !tbaa !21
  br i1 %t175, label %bb45, label %bb46
bb45:
  %t177 = load i64, ptr %l4, !tbaa !24
  %t179 = icmp sgt i64 %t177, 0
  br i1 %t179, label %bb47, label %bb48
bb46:
  br label %bb55
bb47:
  store %olang.scope zeroinitializer, ptr %s9
  %t181 = load ptr, ptr %l0, !tbaa !29
  store ptr %t181, ptr %l98, !tbaa !29
  %t182 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t183 = load i32, ptr %t182, !tbaa !23
  %t184 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t185 = load i32, ptr %t184, !tbaa !23
  %t187 = add i32 %t185, 6
  %t190 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s9, i32 %t183, i32 %t187)
  store %"compiler/source:Span" %t190, ptr %l102
  br label %bb49
bb48:
  br label %bb52
bb49:
  %t191 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenReturnValue(ptr %s9)
  store %"compiler/msgs:Msg" %t191, ptr %l103
  br label %bb50
bb50:
  %t192 = load ptr, ptr %l98, !tbaa !29
  %t193 = load %"compiler/source:Span", ptr %l102
  %t194 = load %"compiler/msgs:Msg", ptr %l103
  %t195 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s9, ptr %t192, %"compiler/source:Span" %t193, %"compiler/msgs:Msg" %t194)
  store i64 %t195, ptr %l104
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s9)
  br label %bb52
bb52:
  %t196 = load ptr, ptr %l0, !tbaa !29
  store ptr %t196, ptr %l105, !tbaa !29
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load %"compiler/source:Span", ptr %l1
  %t201 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenEnd(ptr %v0, ptr %v0, ptr %t197, %"compiler/source:Span" %t198)
  store ptr %t201, ptr %l108
  br label %bb53
bb53:
  %t202 = load ptr, ptr %l105, !tbaa !29
  %t203 = load ptr, ptr %l108, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t202, ptr %t203)
  br label %bb54
bb54:
  br label %ret
bb55:
  %t204 = load ptr, ptr %l3, !tbaa !29
  %t206 = getelementptr %"compiler/check:frame", ptr %t204, i32 0, i32 25
  %t207 = load i1, ptr %t206, !tbaa !21
  br i1 %t207, label %bb56, label %bb57
bb56:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load %"compiler/source:Span", ptr %l1
  %t211 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferReturn(ptr %v0, ptr %v1, ptr %t209, %"compiler/source:Span" %t210, { i64, ptr } %t211)
  br label %bb58
bb57:
  br label %bb59
bb58:
  br label %ret
bb59:
  %t215 = load ptr, ptr %l3, !tbaa !29
  %t217 = getelementptr %"compiler/check:frame", ptr %t215, i32 0, i32 5
  %t218 = load i32, ptr %t217, !tbaa !23
  store i32 %t218, ptr %l5, !tbaa !23
  %t220 = load i64, ptr %l4, !tbaa !24
  %t222 = icmp eq i64 %t220, 0
  br i1 %t222, label %bb60, label %bb61
bb60:
  %t224 = load i32, ptr %l5, !tbaa !23
  %t225 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t228 = icmp ne i32 %t224, %t225
  br i1 %t228, label %bb62, label %bb63
bb61:
  br label %bb72
bb62:
  %t230 = load i32, ptr %l5, !tbaa !23
  %t231 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t234 = icmp ne i32 %t230, %t231
  store i1 %t234, ptr %l121, !tbaa !21
  br label %bb64
bb63:
  store i1 false, ptr %l121, !tbaa !21
  br label %bb64
bb64:
  %t236 = load i1, ptr %l121, !tbaa !21
  br i1 %t236, label %bb65, label %bb66
bb65:
  store %olang.scope zeroinitializer, ptr %s12
  %t237 = load ptr, ptr %l0, !tbaa !29
  store ptr %t237, ptr %l125, !tbaa !29
  %t238 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t238, ptr %l126
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load i32, ptr %l5, !tbaa !23
  %t243 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s12, ptr %t239, i32 %t240)
  store { i64, ptr } %t243, ptr %l129
  br label %bb67
bb66:
  br label %bb70
bb67:
  %t244 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t245 = extractvalue { i64, ptr } %t244, 0
  %t246 = extractvalue { i64, ptr } %t244, 1
  %t247 = mul i64 %t245, 1
  %t248 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t247)
  call void @llvm.memcpy.p0.p0.i64(ptr %t248, ptr %t246, i64 %t247, i1 false)
  %t249 = insertvalue { i64, ptr } undef, i64 %t245, 0
  %t250 = insertvalue { i64, ptr } %t249, ptr %t248, 1
  %t252 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnNeedsValue(ptr %s12, ptr %s12, { i64, ptr } %t250)
  store %"compiler/msgs:Msg" %t252, ptr %l131
  br label %bb68
bb68:
  %t253 = load ptr, ptr %l125, !tbaa !29
  %t254 = load %"compiler/source:Span", ptr %l126
  %t255 = load %"compiler/msgs:Msg", ptr %l131
  %t256 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s12, ptr %t253, %"compiler/source:Span" %t254, %"compiler/msgs:Msg" %t255)
  store i64 %t256, ptr %l132
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s12)
  br label %ret
bb70:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load %"compiler/source:Span", ptr %l1
  store { i64, [3 x i64] } zeroinitializer, ptr %t259
  %t260 = getelementptr { i64, [3 x i64] }, ptr %t259, i32 0, i32 0
  store i64 6, ptr %t260
  %t262 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t258, 0
  %t263 = insertvalue { %"compiler/source:Span", ptr } %t262, ptr null, 1
  %t264 = getelementptr { i64, [3 x i64] }, ptr %t259, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t263, ptr %t264
  %t265 = load { i64, [3 x i64] }, ptr %t259
  %t267 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t265, ptr %t267
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t257, ptr %t267)
  br label %bb71
bb71:
  br label %ret
bb72:
  %t270 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t272 = extractvalue { i64, ptr } %t270, 0
  %t274 = icmp eq i64 %t272, 1
  br i1 %t274, label %bb73, label %bb74
bb73:
  %t276 = load i32, ptr %l5, !tbaa !23
  %t277 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t280 = icmp eq i32 %t276, %t277
  br i1 %t280, label %bb75, label %bb76
bb74:
  br label %bb106
bb75:
  store %olang.scope zeroinitializer, ptr %s14
  %t282 = load ptr, ptr %l0, !tbaa !29
  store ptr %t282, ptr %l143, !tbaa !29
  %t283 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t283, ptr %l144
  %t284 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnValueInVoid(ptr %s14)
  store %"compiler/msgs:Msg" %t284, ptr %l145
  br label %bb77
bb76:
  br label %bb79
bb77:
  %t285 = load ptr, ptr %l143, !tbaa !29
  %t286 = load %"compiler/source:Span", ptr %l144
  %t287 = load %"compiler/msgs:Msg", ptr %l145
  %t288 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s14, ptr %t285, %"compiler/source:Span" %t286, %"compiler/msgs:Msg" %t287)
  store i64 %t288, ptr %l146
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s14)
  br label %ret
bb79:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t291 = getelementptr %"compiler/check:Checker", ptr %t289, i32 0, i32 13
  %t292 = load { i64, [3 x i64] }, ptr %t291
  store { i64, [3 x i64] } %t292, ptr %l6
  %t294 = load ptr, ptr %l0, !tbaa !29
  store ptr %t294, ptr %l149, !tbaa !29
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t297 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresultAt(ptr %v0, ptr %t295, i64 0)
  store { i64, [3 x i64] } %t297, ptr %l151
  br label %bb80
bb80:
  %t298 = load { i64, [3 x i64] }, ptr %l151
  %t299 = load ptr, ptr %l149, !tbaa !29
  %t300 = getelementptr %"compiler/check:Checker", ptr %t299, i32 0, i32 13
  store { i64, [3 x i64] } %t298, ptr %t300
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t302 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t302, ptr %l153, !tbaa !27
  %t303 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t304 = load ptr, ptr %t303, !tbaa !27
  %t305 = getelementptr ptr, ptr %t304, i64 0
  %t306 = load ptr, ptr %t305, !tbaa !39
  %t307 = load i32, ptr %l5, !tbaa !23
  %t311 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %v0, ptr %t301, ptr %t306, i32 %t307)
  store ptr %t311, ptr %l156
  br label %bb81
bb81:
  %t312 = load ptr, ptr %l156, !tbaa !29
  store ptr %t312, ptr %l7, !tbaa !29
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t314 = load { i64, [3 x i64] }, ptr %l6
  %t317 = getelementptr %"compiler/check:Checker", ptr %t313, i32 0, i32 13
  store { i64, [3 x i64] } %t314, ptr %t317
  %t318 = load i32, ptr %l5, !tbaa !23
  store i32 %t318, ptr %l159, !tbaa !23
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t321 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t319)
  store i32 %t321, ptr %l161
  br label %bb82
bb82:
  %t322 = load i32, ptr %l159, !tbaa !23
  %t323 = load i32, ptr %l161, !tbaa !23
  %t324 = icmp eq i32 %t322, %t323
  br i1 %t324, label %bb83, label %bb84
bb83:
  %t326 = load ptr, ptr %l0, !tbaa !29
  store ptr %t326, ptr %l164, !tbaa !29
  %t327 = load ptr, ptr %l7, !tbaa !29
  %t330 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t327)
  store i32 %t330, ptr %l167
  br label %bb85
bb84:
  store i1 false, ptr %l163, !tbaa !21
  br label %bb87
bb85:
  %t331 = load ptr, ptr %l164, !tbaa !29
  %t332 = load i32, ptr %l167, !tbaa !23
  %t333 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t331, i32 %t332)
  store i1 %t333, ptr %l168
  br label %bb86
bb86:
  %t334 = load i1, ptr %l168, !tbaa !21
  store i1 %t334, ptr %l163, !tbaa !21
  br label %bb87
bb87:
  %t335 = load i1, ptr %l163, !tbaa !21
  br i1 %t335, label %bb88, label %bb89
bb88:
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t337 = load %"compiler/source:Span", ptr %l1
  %t338 = load %"compiler/source:Span", ptr %l1
  %t339 = load i32, ptr %l5, !tbaa !23
  %t340 = load ptr, ptr %l7, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t341
  %t342 = getelementptr { i64, [4 x i64] }, ptr %t341, i32 0, i32 0
  store i64 2, ptr %t342
  %t344 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t338, 0
  %t346 = insertvalue { %"compiler/source:Span", i32, ptr } %t344, i32 %t339, 1
  %t348 = insertvalue { %"compiler/source:Span", i32, ptr } %t346, ptr %t340, 2
  %t349 = getelementptr { i64, [4 x i64] }, ptr %t341, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t348, ptr %t349
  %t350 = load { i64, [4 x i64] }, ptr %t341
  %t352 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t350, ptr %t352
  %t356 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t336, %"compiler/source:Span" %t337, ptr %t352)
  store ptr %t356, ptr %l176
  br label %bb90
bb89:
  br label %bb91
bb90:
  %t357 = load ptr, ptr %l176, !tbaa !29
  store ptr %t357, ptr %l7, !tbaa !29
  br label %bb91
bb91:
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t359 = load i32, ptr %l5, !tbaa !23
  %t362 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t358, i32 %t359)
  store i1 %t362, ptr %l179
  br label %bb92
bb92:
  %t363 = load i1, ptr %l179, !tbaa !21
  %t364 = xor i1 %t363, true
  br i1 %t364, label %bb93, label %bb94
bb93:
  %t366 = load ptr, ptr %l0, !tbaa !29
  store ptr %t366, ptr %l181, !tbaa !29
  %t367 = load ptr, ptr %l7, !tbaa !29
  store ptr %t367, ptr %l183, !tbaa !29
  %t369 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t369, ptr %l184, !tbaa !27
  %t370 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t371 = load ptr, ptr %t370, !tbaa !27
  %t372 = getelementptr ptr, ptr %t371, i64 0
  %t373 = load ptr, ptr %t372, !tbaa !39
  %t375 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t373)
  store %"compiler/source:Span" %t375, ptr %l186
  br label %bb95
bb94:
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t377 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRefResult(ptr %v0, ptr %v0, ptr %t376, ptr %t377)
  br label %bb97
bb95:
  %t381 = load i64, ptr @G_2ecompiler_2fcheck_2eRoReturned, !tbaa !24
  %t382 = load ptr, ptr %l181, !tbaa !29
  %t383 = load ptr, ptr %l183, !tbaa !29
  %t384 = load %"compiler/source:Span", ptr %l186
  %t386 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v0, ptr %t382, ptr %t383, %"compiler/source:Span" %t384, i64 %t381)
  store i1 %t386, ptr %l188
  br label %bb96
bb96:
  br label %bb98
bb97:
  br label %bb98
bb98:
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t388 = load i32, ptr %l5, !tbaa !23
  %t391 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t387, i32 %t388)
  store i1 %t391, ptr %l194
  br label %bb99
bb99:
  %t392 = load i1, ptr %l194, !tbaa !21
  %t393 = xor i1 %t392, true
  br i1 %t393, label %bb100, label %bb101
bb100:
  %t395 = load ptr, ptr %l0, !tbaa !29
  store ptr %t395, ptr %l196, !tbaa !29
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t397 = load ptr, ptr %l7, !tbaa !29
  %t400 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueLand(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t396, ptr %t397, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d27, i32 0, i32 1) }, i1 true)
  store ptr %t400, ptr %l199
  br label %bb102
bb101:
  br label %bb104
bb102:
  %t401 = load ptr, ptr %l196, !tbaa !29
  %t402 = load ptr, ptr %l199, !tbaa !29
  %t403 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eretLand(ptr %v0, ptr %v0, ptr %v0, ptr %t401, ptr %t402)
  store ptr %t403, ptr %l200
  br label %bb103
bb103:
  %t404 = load ptr, ptr %l200, !tbaa !29
  store ptr %t404, ptr %l7, !tbaa !29
  br label %bb104
bb104:
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t406 = load %"compiler/source:Span", ptr %l1
  %t407 = load ptr, ptr %l7, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t409
  %t410 = getelementptr { i64, [3 x i64] }, ptr %t409, i32 0, i32 0
  store i64 6, ptr %t410
  %t412 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t406, 0
  %t414 = insertvalue { %"compiler/source:Span", ptr } %t412, ptr %t407, 1
  %t415 = getelementptr { i64, [3 x i64] }, ptr %t409, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t414, ptr %t415
  %t416 = load { i64, [3 x i64] }, ptr %t409
  %t418 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t416, ptr %t418
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t405, ptr %t418)
  br label %bb105
bb105:
  br label %ret
bb106:
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t423 = getelementptr %"compiler/check:Checker", ptr %t421, i32 0, i32 1
  %t424 = load ptr, ptr %t423, !tbaa !29
  %t426 = getelementptr %"compiler/generic:Program", ptr %t424, i32 0, i32 2
  %t427 = load i32, ptr %l5, !tbaa !23
  %t430 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t426, i32 %t427)
  store i32 %t430, ptr %l211
  br label %bb107
bb107:
  %t431 = load i32, ptr %l211, !range !{i32 0, i32 33}
  %t433 = trunc i64 22 to i32
  %t434 = icmp eq i32 %t431, %t433
  %t436 = xor i1 %t434, true
  br i1 %t436, label %bb108, label %bb109
bb108:
  store %olang.scope zeroinitializer, ptr %s19
  %t438 = load ptr, ptr %l0, !tbaa !29
  %t439 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s19, ptr %t438, %"compiler/source:Span" %t439, { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d28, i32 0, i32 1) })
  br label %bb110
bb109:
  br label %bb111
bb110:
  call void @__olang_scope_close(ptr %s19)
  br label %ret
bb111:
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t444 = getelementptr %"compiler/check:Checker", ptr %t442, i32 0, i32 1
  %t445 = load ptr, ptr %t444, !tbaa !29
  %t447 = getelementptr %"compiler/generic:Program", ptr %t445, i32 0, i32 2
  store ptr %t447, ptr %l219, !tbaa !29
  %t448 = load ptr, ptr %l0, !tbaa !29
  %t450 = getelementptr %"compiler/check:Checker", ptr %t448, i32 0, i32 1
  %t451 = load ptr, ptr %t450, !tbaa !29
  %t453 = getelementptr %"compiler/generic:Program", ptr %t451, i32 0, i32 2
  %t454 = load i32, ptr %l5, !tbaa !23
  %t457 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t453, i32 %t454)
  store i32 %t457, ptr %l224
  br label %bb112
bb112:
  %t458 = load ptr, ptr %l219, !tbaa !29
  %t459 = load i32, ptr %l224, !tbaa !23
  %t460 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t458, i32 %t459)
  store { i64, ptr } %t460, ptr %l225
  br label %bb113
bb113:
  %t461 = load { i64, ptr }, ptr %l225, !tbaa !27
  store { i64, ptr } %t461, ptr %l8, !tbaa !27
  %t462 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t464 = extractvalue { i64, ptr } %t462, 0
  %t465 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t467 = extractvalue { i64, ptr } %t465, 0
  %t470 = icmp ne i64 %t464, %t467
  br i1 %t470, label %bb114, label %bb115
bb114:
  store %olang.scope zeroinitializer, ptr %s20
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t473 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s20, ptr %t472, %"compiler/source:Span" %t473, { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d29, i32 0, i32 1) })
  br label %bb116
bb115:
  br label %bb117
bb116:
  call void @__olang_scope_close(ptr %s20)
  br label %ret
bb117:
  %t476 = load ptr, ptr %l0, !tbaa !29
  %t478 = getelementptr %"compiler/check:Checker", ptr %t476, i32 0, i32 36
  %t480 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t478)
  store i64 %t480, ptr %l235
  br label %bb118
bb118:
  %t481 = load i64, ptr %l235, !tbaa !24
  store i64 %t481, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  %t482 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t484 = extractvalue { i64, ptr } %t482, 0
  store i64 %t484, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t486 = load i64, ptr %l11, !tbaa !24
  %t487 = load i64, ptr %l10, !tbaa !24
  %t490 = icmp sgt i64 %t486, %t487
  br i1 %t490, label %bb119, label %bb120
bb119:
  %t492 = load i64, ptr %l12, !tbaa !24
  %t494 = icmp sgt i64 %t492, 0
  br i1 %t494, label %bb121, label %bb122
bb120:
  store i64 0, ptr %l241, !tbaa !24
  br label %bb124
bb121:
  %t496 = load i64, ptr %l11, !tbaa !24
  %t497 = load i64, ptr %l10, !tbaa !24
  %t500 = sub i64 %t496, %t497
  %t501 = load i64, ptr %l12, !tbaa !24
  %t504 = add i64 %t500, %t501
  %t506 = sub i64 %t504, 1
  %t507 = load i64, ptr %l12, !tbaa !24
  %t510 = sdiv i64 %t506, %t507
  store i64 %t510, ptr %l244, !tbaa !24
  br label %bb123
bb122:
  store i64 0, ptr %l244, !tbaa !24
  br label %bb123
bb123:
  %t512 = load i64, ptr %l244, !tbaa !24
  store i64 %t512, ptr %l241, !tbaa !24
  br label %bb124
bb124:
  %t513 = load i64, ptr %l241, !tbaa !24
  store i64 %t513, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb125
bb125:
  %t514 = load i64, ptr %l14, !tbaa !24
  %t515 = load i64, ptr %l13, !tbaa !24
  %t518 = icmp slt i64 %t514, %t515
  %t520 = xor i1 %t518, true
  br i1 %t520, label %bb126, label %bb127
bb126:
  br label %bb139
bb127:
  br label %bb128
bb128:
  %t522 = load i64, ptr %l10, !tbaa !24
  %t523 = load i64, ptr %l14, !tbaa !24
  %t524 = load i64, ptr %l12, !tbaa !24
  %t527 = mul i64 %t523, %t524
  %t530 = add i64 %t522, %t527
  store i64 %t530, ptr %l15, !tbaa !24
  %t532 = load ptr, ptr %l0, !tbaa !29
  %t534 = getelementptr %"compiler/check:Checker", ptr %t532, i32 0, i32 13
  %t535 = load { i64, [3 x i64] }, ptr %t534
  store { i64, [3 x i64] } %t535, ptr %l16
  %t537 = load ptr, ptr %l0, !tbaa !29
  store ptr %t537, ptr %l264, !tbaa !29
  %t538 = load ptr, ptr %l0, !tbaa !29
  %t539 = load i64, ptr %l15, !tbaa !24
  %t542 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresultAt(ptr %v0, ptr %t538, i64 %t539)
  store { i64, [3 x i64] } %t542, ptr %l267
  br label %bb129
bb129:
  %t543 = load { i64, [3 x i64] }, ptr %l267
  %t544 = load ptr, ptr %l264, !tbaa !29
  %t545 = getelementptr %"compiler/check:Checker", ptr %t544, i32 0, i32 13
  store { i64, [3 x i64] } %t543, ptr %t545
  %t546 = load ptr, ptr %l0, !tbaa !29
  %t547 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t547, ptr %l269, !tbaa !27
  %t548 = load i64, ptr %l15, !tbaa !24
  %t550 = getelementptr { i64, ptr }, ptr %l269, i32 0, i32 1
  %t551 = load ptr, ptr %t550, !tbaa !27
  %t552 = getelementptr ptr, ptr %t551, i64 %t548
  %t553 = load ptr, ptr %t552, !tbaa !39
  %t554 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t554, ptr %l272, !tbaa !27
  %t555 = load i64, ptr %l15, !tbaa !24
  %t557 = getelementptr { i64, ptr }, ptr %l272, i32 0, i32 1
  %t558 = load ptr, ptr %t557, !tbaa !27
  %t559 = getelementptr i32, ptr %t558, i64 %t555
  %t560 = load i32, ptr %t559, !tbaa !33
  %t564 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %v0, ptr %t546, ptr %t553, i32 %t560)
  store ptr %t564, ptr %l275
  br label %bb130
bb130:
  %t565 = load ptr, ptr %l275, !tbaa !29
  store ptr %t565, ptr %l17, !tbaa !29
  %t566 = load ptr, ptr %l0, !tbaa !29
  %t567 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t567, ptr %l277, !tbaa !27
  %t568 = load i64, ptr %l15, !tbaa !24
  %t570 = getelementptr { i64, ptr }, ptr %l277, i32 0, i32 1
  %t571 = load ptr, ptr %t570, !tbaa !27
  %t572 = getelementptr i32, ptr %t571, i64 %t568
  %t573 = load i32, ptr %t572, !tbaa !33
  %t576 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t566, i32 %t573)
  store i1 %t576, ptr %l280
  br label %bb131
bb131:
  %t577 = load i1, ptr %l280, !tbaa !21
  %t578 = xor i1 %t577, true
  br i1 %t578, label %bb132, label %bb133
bb132:
  %t580 = load ptr, ptr %l0, !tbaa !29
  store ptr %t580, ptr %l282, !tbaa !29
  %t581 = load ptr, ptr %l0, !tbaa !29
  %t582 = load ptr, ptr %l17, !tbaa !29
  %t585 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueLand(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t581, ptr %t582, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d30, i32 0, i32 1) }, i1 true)
  store ptr %t585, ptr %l285
  br label %bb134
bb133:
  br label %bb136
bb134:
  %t586 = load ptr, ptr %l282, !tbaa !29
  %t587 = load ptr, ptr %l285, !tbaa !29
  %t588 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eretLand(ptr %v0, ptr %v0, ptr %v0, ptr %t586, ptr %t587)
  store ptr %t588, ptr %l286
  br label %bb135
bb135:
  %t589 = load ptr, ptr %l286, !tbaa !29
  store ptr %t589, ptr %l17, !tbaa !29
  br label %bb136
bb136:
  %t590 = load ptr, ptr %l0, !tbaa !29
  %t592 = getelementptr %"compiler/check:Checker", ptr %t590, i32 0, i32 36
  %t593 = load ptr, ptr %l17, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t592, ptr %t593)
  br label %bb137
bb137:
  %t596 = load ptr, ptr %l0, !tbaa !29
  %t597 = load { i64, [3 x i64] }, ptr %l16
  %t600 = getelementptr %"compiler/check:Checker", ptr %t596, i32 0, i32 13
  store { i64, [3 x i64] } %t597, ptr %t600
  br label %bb138
bb138:
  %t601 = load i64, ptr %l14, !tbaa !24
  %t603 = add i64 %t601, 1
  store i64 %t603, ptr %l14, !tbaa !24
  br label %bb125
bb139:
  %t605 = load ptr, ptr %l0, !tbaa !29
  %t607 = getelementptr %"compiler/check:Checker", ptr %t605, i32 0, i32 36
  %t608 = load i64, ptr %l9, !tbaa !24
  %t611 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t607, i64 %t608)
  store { i64, ptr } %t611, ptr %l297
  br label %bb140
bb140:
  %t612 = load { i64, ptr }, ptr %l297, !tbaa !27
  %t613 = load ptr, ptr %l0, !tbaa !29
  store ptr %t613, ptr %l298, !tbaa !29
  %t614 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t614, ptr %l299
  %t615 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t615, ptr %l300
  %t616 = load i32, ptr %l5, !tbaa !23
  store i32 %t616, ptr %l301, !tbaa !23
  %t621 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v0, ptr %v0, i32 0, i64 0, { i64, ptr } %t612, ptr null, i32 -1, i32 0, i1 false)
  store %"compiler/typed:Make" %t621, ptr %l305
  br label %bb141
bb141:
  %t622 = load %"compiler/typed:Make", ptr %l305
  %t623 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/typed:Make" %t622, ptr %t623
  store { i64, [5 x i64] } zeroinitializer, ptr %t624
  %t625 = getelementptr { i64, [5 x i64] }, ptr %t624, i32 0, i32 0
  store i64 7, ptr %t625
  %t626 = load %"compiler/source:Span", ptr %l300
  %t627 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t626, 0
  %t628 = load i32, ptr %l301, !tbaa !23
  %t629 = insertvalue { %"compiler/source:Span", i32, ptr } %t627, i32 %t628, 1
  %t631 = insertvalue { %"compiler/source:Span", i32, ptr } %t629, ptr %t623, 2
  %t632 = getelementptr { i64, [5 x i64] }, ptr %t624, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t631, ptr %t632
  %t633 = load { i64, [5 x i64] }, ptr %t624
  %t635 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t633, ptr %t635
  store { i64, [3 x i64] } zeroinitializer, ptr %t636
  %t637 = getelementptr { i64, [3 x i64] }, ptr %t636, i32 0, i32 0
  store i64 6, ptr %t637
  %t638 = load %"compiler/source:Span", ptr %l299
  %t639 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t638, 0
  %t641 = insertvalue { %"compiler/source:Span", ptr } %t639, ptr %t635, 1
  %t642 = getelementptr { i64, [3 x i64] }, ptr %t636, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t641, ptr %t642
  %t643 = load { i64, [3 x i64] }, ptr %t636
  %t645 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t643, ptr %t645
  %t646 = load ptr, ptr %l298, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t646, ptr %t645)
  br label %bb142
bb142:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCallRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i1
  %l14 = alloca i1
  %l17 = alloca { i64, ptr }
  %l21 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroBorrowedFrom(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l2, !tbaa !24
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Call", ptr %t12, i32 0, i32 1
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t20 = icmp slt i64 %t11, %t17
  store i1 %t20, ptr %l8, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t22 = load i1, ptr %l8, !tbaa !21
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Call", ptr %t24, i32 0, i32 1
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l17, !tbaa !27
  %t28 = load i64, ptr %l2, !tbaa !24
  %t30 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr ptr, ptr %t31, i64 %t28
  %t33 = load ptr, ptr %t32, !tbaa !39
  %t37 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %t23, ptr %t33)
  store i1 %t37, ptr %l21
  br label %bb7
bb6:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb8
bb7:
  %t38 = load i1, ptr %l21, !tbaa !21
  store i1 %t38, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t39 = load i1, ptr %l14, !tbaa !21
  store i1 %t39, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, ptr %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca %"compiler/typed:Local"
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l26 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l38 = alloca ptr
  %l40 = alloca %"compiler/typed:Local"
  %l46 = alloca ptr
  %l48 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l50 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l52 = alloca i64
  %l56 = alloca i64
  %l59 = alloca i64
  %l79 = alloca i32
  %l82 = alloca i1
  %l86 = alloca i1
  %l87 = alloca i1
  %l90 = alloca i1
  %l98 = alloca i1
  %l102 = alloca i1
  %l106 = alloca ptr
  %l108 = alloca ptr
  %l112 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l113 = alloca ptr
  %l114 = alloca i32
  %l116 = alloca i64
  %l118 = alloca i64
  %l123 = alloca ptr
  %l134 = alloca ptr
  %l135 = alloca i1
  %l148 = alloca ptr
  %l149 = alloca i1
  %l162 = alloca ptr
  %l163 = alloca i1
  %l177 = alloca ptr
  %l178 = alloca i1
  %l192 = alloca ptr
  %l193 = alloca i1
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l5, !tbaa !24
  %t7 = icmp sgt i64 %t5, 48
  store i1 %t7, ptr %l26, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l26, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t10 = load ptr, ptr %l2, !tbaa !29
  store ptr %t10, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t11 = load ptr, ptr %l29, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l29, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 0
  store i1 %t17, ptr %l30, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l30, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t21, i32 0, i32 2
  %t23 = load i32, ptr %t22
  store i32 %t23, ptr %l6, !tbaa !23
  br label %bb11
bb10:
  br label %bb67
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 14
  %t28 = load i64, ptr %l1, !tbaa !24
  %t31 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t27, i64 %t28)
  store ptr %t31, ptr %l38
  br label %bb12
bb12:
  %t32 = load i32, ptr %l6, !tbaa !23
  %t33 = load ptr, ptr %l38, !tbaa !29
  %t35 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t33, i32 %t32)
  store %"compiler/typed:Local" %t35, ptr %l40
  br label %bb13
bb13:
  %t36 = load %"compiler/typed:Local", ptr %l40
  store %"compiler/typed:Local" %t36, ptr %l7
  %t37 = getelementptr %"compiler/typed:Local", ptr %l7, i32 0, i32 4
  %t38 = load i32, ptr %t37, !range !{i32 0, i32 7}
  %t40 = trunc i64 0 to i32
  %t41 = icmp eq i32 %t38, %t40
  br i1 %t41, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 14
  %t46 = load i64, ptr %l1, !tbaa !24
  %t49 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t45, i64 %t46)
  store ptr %t49, ptr %l46
  br label %bb16
bb15:
  br label %bb44
bb16:
  %t50 = load ptr, ptr %l46, !tbaa !29
  %t52 = getelementptr %"compiler/typed:Body", ptr %t50, i32 0, i32 5
  %t53 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t52
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t53, ptr %l48
  %t55 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e(ptr %s3, ptr %l48)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t55, ptr %l50
  br label %bb17
bb17:
  %t56 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l50
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t56, ptr %l8
  store i64 0, ptr %l9, !tbaa !24
  %t58 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %s3, ptr %l8)
  store i64 %t58, ptr %l52
  br label %bb18
bb18:
  %t59 = load i64, ptr %l52, !tbaa !24
  store i64 %t59, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t60 = load i64, ptr %l10, !tbaa !24
  %t61 = load i64, ptr %l9, !tbaa !24
  %t64 = icmp sgt i64 %t60, %t61
  br i1 %t64, label %bb19, label %bb20
bb19:
  %t66 = load i64, ptr %l11, !tbaa !24
  %t68 = icmp sgt i64 %t66, 0
  br i1 %t68, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb24
bb21:
  %t70 = load i64, ptr %l10, !tbaa !24
  %t71 = load i64, ptr %l9, !tbaa !24
  %t74 = sub i64 %t70, %t71
  %t75 = load i64, ptr %l11, !tbaa !24
  %t78 = add i64 %t74, %t75
  %t80 = sub i64 %t78, 1
  %t81 = load i64, ptr %l11, !tbaa !24
  %t84 = sdiv i64 %t80, %t81
  store i64 %t84, ptr %l59, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb23
bb23:
  %t86 = load i64, ptr %l59, !tbaa !24
  store i64 %t86, ptr %l56, !tbaa !24
  br label %bb24
bb24:
  %t87 = load i64, ptr %l56, !tbaa !24
  store i64 %t87, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb25
bb25:
  %t88 = load i64, ptr %l13, !tbaa !24
  %t89 = load i64, ptr %l12, !tbaa !24
  %t92 = icmp slt i64 %t88, %t89
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb26, label %bb27
bb26:
  br label %bb43
bb27:
  br label %bb28
bb28:
  %t96 = load i64, ptr %l9, !tbaa !24
  %t97 = load i64, ptr %l13, !tbaa !24
  %t98 = load i64, ptr %l11, !tbaa !24
  %t101 = mul i64 %t97, %t98
  %t104 = add i64 %t96, %t101
  store i64 %t104, ptr %l14, !tbaa !24
  %t106 = load i64, ptr %l14, !tbaa !24
  %t109 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %s3, ptr %l8, i64 %t106)
  store i32 %t109, ptr %l79
  br label %bb29
bb29:
  %t110 = load i32, ptr %l6, !tbaa !23
  %t111 = load i32, ptr %l79, !tbaa !23
  %t113 = icmp eq i32 %t111, %t110
  br i1 %t113, label %bb30, label %bb31
bb30:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load i64, ptr %l1, !tbaa !24
  %t117 = load i64, ptr %l14, !tbaa !24
  %t121 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %t115, i64 %t116, i64 %t117)
  store i1 %t121, ptr %l86
  br label %bb32
bb31:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb33
bb32:
  %t122 = load i1, ptr %l86, !tbaa !21
  store i1 %t122, ptr %l82, !tbaa !21
  br label %bb33
bb33:
  %t123 = load i1, ptr %l82, !tbaa !21
  br i1 %t123, label %bb34, label %bb35
bb34:
  %t124 = load ptr, ptr %l3, !tbaa !29
  %t125 = load i64, ptr %l14, !tbaa !24
  %t128 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v2, ptr %t124, i64 %t125)
  store i1 %t128, ptr %l90
  br label %bb36
bb35:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb37
bb36:
  %t129 = load i1, ptr %l90, !tbaa !21
  %t130 = xor i1 %t129, true
  store i1 %t130, ptr %l87, !tbaa !21
  br label %bb37
bb37:
  %t132 = load i1, ptr %l87, !tbaa !21
  br i1 %t132, label %bb38, label %bb39
bb38:
  %t133 = load ptr, ptr %l3, !tbaa !29
  %t134 = load i64, ptr %l14, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t133, i64 %t134)
  br label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t137 = load i64, ptr %l13, !tbaa !24
  %t139 = add i64 %t137, 1
  store i64 %t139, ptr %l13, !tbaa !24
  br label %bb25
bb43:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb44:
  %t141 = getelementptr %"compiler/typed:Local", ptr %l7, i32 0, i32 4
  %t142 = load i32, ptr %t141, !range !{i32 0, i32 7}
  %t144 = trunc i64 5 to i32
  %t145 = icmp eq i32 %t142, %t144
  br i1 %t145, label %bb45, label %bb46
bb45:
  store i1 true, ptr %l98, !tbaa !21
  br label %bb48
bb46:
  %t147 = load ptr, ptr %l4, !tbaa !29
  %t148 = load i32, ptr %l6, !tbaa !23
  %t150 = sext i32 %t148 to i64
  %t153 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v3, ptr %t147, i64 %t150)
  store i1 %t153, ptr %l102
  br label %bb47
bb47:
  %t154 = load i1, ptr %l102, !tbaa !21
  store i1 %t154, ptr %l98, !tbaa !21
  br label %bb48
bb48:
  %t155 = load i1, ptr %l98, !tbaa !21
  br i1 %t155, label %bb49, label %bb50
bb49:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb50:
  br label %bb51
bb51:
  %t156 = load ptr, ptr %l4, !tbaa !29
  %t157 = load i32, ptr %l6, !tbaa !23
  %t159 = sext i32 %t157 to i64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v3, ptr %t156, i64 %t159, i1 true)
  br label %bb52
bb52:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/check:Checker", ptr %t162, i32 0, i32 80
  store ptr %t164, ptr %l108, !tbaa !29
  %t165 = load i64, ptr %l1, !tbaa !24
  %t166 = load i32, ptr %l6, !tbaa !23
  %t168 = sext i32 %t166 to i64
  %t171 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s2, i64 %t165, i64 %t168)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t171, ptr %l112
  br label %bb53
bb53:
  %t172 = load ptr, ptr %l108, !tbaa !29
  %t173 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l112
  %t174 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H9a57a0a969606bc6b56c6db08d26f577(ptr %v0, ptr %v0, ptr %t172, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t173)
  %t175 = extractvalue { i32, ptr } %t174, 1
  %t176 = extractvalue { i32, ptr } %t174, 0
  store i32 %t176, ptr %l114
  %t177 = icmp ne i32 %t176, 0
  br i1 %t177, label %bb55, label %ok.178, !prof !99
ok.178:
  store ptr %t175, ptr %l113
  br label %bb54
bb54:
  %t179 = load ptr, ptr %l113, !tbaa !29
  store ptr %t179, ptr %l106, !tbaa !29
  br label %bb57
bb55:
  br label %bb56
bb56:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb57:
  %t180 = load ptr, ptr %l106, !tbaa !29
  store ptr %t180, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb58
bb58:
  %t183 = load i64, ptr %l17, !tbaa !24
  store i64 %t183, ptr %l116, !tbaa !24
  %t184 = load ptr, ptr %l16, !tbaa !29
  %t186 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t184)
  store i64 %t186, ptr %l118
  br label %bb59
bb59:
  %t187 = load i64, ptr %l116, !tbaa !24
  %t188 = load i64, ptr %l118, !tbaa !24
  %t189 = icmp slt i64 %t187, %t188
  %t191 = xor i1 %t189, true
  br i1 %t191, label %bb60, label %bb61
bb60:
  br label %bb66
bb61:
  br label %bb62
bb62:
  %t193 = load ptr, ptr %l16, !tbaa !29
  %t194 = load i64, ptr %l17, !tbaa !24
  %t197 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t193, i64 %t194)
  store ptr %t197, ptr %l123
  br label %bb63
bb63:
  %t198 = load ptr, ptr %l123, !tbaa !29
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load i64, ptr %l1, !tbaa !24
  %t203 = load ptr, ptr %l3, !tbaa !29
  %t204 = load ptr, ptr %l4, !tbaa !29
  %t205 = load i64, ptr %l5, !tbaa !24
  %t207 = add i64 %t205, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepIn(ptr %v0, ptr %v0, ptr %v2, ptr %v3, ptr %t199, i64 %t200, ptr %t198, ptr %t203, ptr %t204, i64 %t207)
  br label %bb64
bb64:
  br label %bb65
bb65:
  %t214 = load i64, ptr %l17, !tbaa !24
  %t216 = add i64 %t214, 1
  store i64 %t216, ptr %l17, !tbaa !24
  br label %bb58
bb66:
  call void @__olang_scope_close(ptr %s2)
  br label %bb107
bb67:
  %t218 = load ptr, ptr %l2, !tbaa !29
  store ptr %t218, ptr %l134, !tbaa !29
  store i1 false, ptr %l135, !tbaa !21
  %t219 = load ptr, ptr %l134, !tbaa !29
  %t220 = icmp ne ptr %t219, null
  br i1 %t220, label %bb68, label %bb69
bb68:
  %t222 = load ptr, ptr %l134, !tbaa !29
  %t223 = load i64, ptr %t222, !range !{i64 0, i64 8}
  %t225 = icmp eq i64 %t223, 2
  store i1 %t225, ptr %l135, !tbaa !21
  br label %bb69
bb69:
  %t226 = load i1, ptr %l135, !tbaa !21
  br i1 %t226, label %bb70, label %bb71
bb70:
  %t227 = load ptr, ptr %l2, !tbaa !29
  %t229 = getelementptr { i64, [4 x i64] }, ptr %t227, i32 0, i32 1
  %t230 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t229, i32 0, i32 2
  %t231 = load ptr, ptr %t230
  store ptr %t231, ptr %l19, !tbaa !29
  br label %bb72
bb71:
  br label %bb74
bb72:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t234 = load i64, ptr %l1, !tbaa !24
  %t235 = load ptr, ptr %l19, !tbaa !29
  %t237 = load ptr, ptr %l3, !tbaa !29
  %t238 = load ptr, ptr %l4, !tbaa !29
  %t239 = load i64, ptr %l5, !tbaa !24
  %t241 = add i64 %t239, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t233, i64 %t234, ptr %t235, ptr %t237, ptr %t238, i64 %t241)
  br label %bb73
bb73:
  br label %bb107
bb74:
  %t248 = load ptr, ptr %l2, !tbaa !29
  store ptr %t248, ptr %l148, !tbaa !29
  store i1 false, ptr %l149, !tbaa !21
  %t249 = load ptr, ptr %l148, !tbaa !29
  %t250 = icmp ne ptr %t249, null
  br i1 %t250, label %bb75, label %bb76
bb75:
  %t252 = load ptr, ptr %l148, !tbaa !29
  %t253 = load i64, ptr %t252, !range !{i64 0, i64 8}
  %t255 = icmp eq i64 %t253, 3
  store i1 %t255, ptr %l149, !tbaa !21
  br label %bb76
bb76:
  %t256 = load i1, ptr %l149, !tbaa !21
  br i1 %t256, label %bb77, label %bb78
bb77:
  %t257 = load ptr, ptr %l2, !tbaa !29
  %t259 = getelementptr { i64, [4 x i64] }, ptr %t257, i32 0, i32 1
  %t260 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t259, i32 0, i32 2
  %t261 = load ptr, ptr %t260
  store ptr %t261, ptr %l20, !tbaa !29
  br label %bb79
bb78:
  br label %bb81
bb79:
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t264 = load i64, ptr %l1, !tbaa !24
  %t265 = load ptr, ptr %l20, !tbaa !29
  %t267 = load ptr, ptr %l3, !tbaa !29
  %t268 = load ptr, ptr %l4, !tbaa !29
  %t269 = load i64, ptr %l5, !tbaa !24
  %t271 = add i64 %t269, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t263, i64 %t264, ptr %t265, ptr %t267, ptr %t268, i64 %t271)
  br label %bb80
bb80:
  br label %bb107
bb81:
  %t278 = load ptr, ptr %l2, !tbaa !29
  store ptr %t278, ptr %l162, !tbaa !29
  store i1 false, ptr %l163, !tbaa !21
  %t279 = load ptr, ptr %l162, !tbaa !29
  %t280 = icmp ne ptr %t279, null
  br i1 %t280, label %bb82, label %bb83
bb82:
  %t282 = load ptr, ptr %l162, !tbaa !29
  %t283 = load i64, ptr %t282, !range !{i64 0, i64 8}
  %t285 = icmp eq i64 %t283, 4
  store i1 %t285, ptr %l163, !tbaa !21
  br label %bb83
bb83:
  %t286 = load i1, ptr %l163, !tbaa !21
  br i1 %t286, label %bb84, label %bb85
bb84:
  %t287 = load ptr, ptr %l2, !tbaa !29
  %t289 = getelementptr { i64, [4 x i64] }, ptr %t287, i32 0, i32 1
  %t290 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t289, i32 0, i32 2
  %t291 = load ptr, ptr %t290
  store ptr %t291, ptr %l21, !tbaa !29
  br label %bb86
bb85:
  br label %bb88
bb86:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t294 = load i64, ptr %l1, !tbaa !24
  %t295 = load ptr, ptr %l21, !tbaa !29
  %t297 = getelementptr %"compiler/typed:Elem", ptr %t295, i32 0, i32 0
  %t298 = load ptr, ptr %t297, !tbaa !29
  %t300 = load ptr, ptr %l3, !tbaa !29
  %t301 = load ptr, ptr %l4, !tbaa !29
  %t302 = load i64, ptr %l5, !tbaa !24
  %t304 = add i64 %t302, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t293, i64 %t294, ptr %t298, ptr %t300, ptr %t301, i64 %t304)
  br label %bb87
bb87:
  br label %bb107
bb88:
  %t311 = load ptr, ptr %l2, !tbaa !29
  store ptr %t311, ptr %l177, !tbaa !29
  store i1 false, ptr %l178, !tbaa !21
  %t312 = load ptr, ptr %l177, !tbaa !29
  %t313 = icmp ne ptr %t312, null
  br i1 %t313, label %bb89, label %bb90
bb89:
  %t315 = load ptr, ptr %l177, !tbaa !29
  %t316 = load i64, ptr %t315, !range !{i64 0, i64 8}
  %t318 = icmp eq i64 %t316, 5
  store i1 %t318, ptr %l178, !tbaa !21
  br label %bb90
bb90:
  %t319 = load i1, ptr %l178, !tbaa !21
  br i1 %t319, label %bb91, label %bb92
bb91:
  %t320 = load ptr, ptr %l2, !tbaa !29
  %t322 = getelementptr { i64, [4 x i64] }, ptr %t320, i32 0, i32 1
  %t323 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t322, i32 0, i32 2
  %t324 = load ptr, ptr %t323
  store ptr %t324, ptr %l22, !tbaa !29
  br label %bb93
bb92:
  br label %bb95
bb93:
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t327 = load i64, ptr %l1, !tbaa !24
  %t328 = load ptr, ptr %l22, !tbaa !29
  %t330 = getelementptr %"compiler/typed:Payload", ptr %t328, i32 0, i32 0
  %t331 = load ptr, ptr %t330, !tbaa !29
  %t333 = load ptr, ptr %l3, !tbaa !29
  %t334 = load ptr, ptr %l4, !tbaa !29
  %t335 = load i64, ptr %l5, !tbaa !24
  %t337 = add i64 %t335, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t326, i64 %t327, ptr %t331, ptr %t333, ptr %t334, i64 %t337)
  br label %bb94
bb94:
  br label %bb107
bb95:
  %t344 = load ptr, ptr %l2, !tbaa !29
  store ptr %t344, ptr %l192, !tbaa !29
  store i1 false, ptr %l193, !tbaa !21
  %t345 = load ptr, ptr %l192, !tbaa !29
  %t346 = icmp ne ptr %t345, null
  br i1 %t346, label %bb96, label %bb97
bb96:
  %t348 = load ptr, ptr %l192, !tbaa !29
  %t349 = load i64, ptr %t348, !range !{i64 0, i64 8}
  %t351 = icmp eq i64 %t349, 6
  store i1 %t351, ptr %l193, !tbaa !21
  br label %bb97
bb97:
  %t352 = load i1, ptr %l193, !tbaa !21
  br i1 %t352, label %bb98, label %bb99
bb98:
  %t353 = load ptr, ptr %l2, !tbaa !29
  %t355 = getelementptr { i64, [4 x i64] }, ptr %t353, i32 0, i32 1
  %t356 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t355, i32 0, i32 2
  %t357 = load ptr, ptr %t356
  store ptr %t357, ptr %l23, !tbaa !29
  br label %bb100
bb99:
  br label %bb102
bb100:
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t360 = load i64, ptr %l1, !tbaa !24
  %t361 = load ptr, ptr %l23, !tbaa !29
  %t363 = load ptr, ptr %l3, !tbaa !29
  %t364 = load ptr, ptr %l4, !tbaa !29
  %t365 = load i64, ptr %l5, !tbaa !24
  %t367 = add i64 %t365, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t359, i64 %t360, ptr %t361, ptr %t363, ptr %t364, i64 %t367)
  br label %bb101
bb101:
  br label %bb107
bb102:
  br i1 true, label %bb103, label %bb104
bb103:
  br label %bb105
bb104:
  br label %bb106
bb105:
  br label %bb107
bb106:
  call void @__olang_check_failed(ptr @olang_loc_8771b1e868207559_9b4adf6aba3e467d)
  unreachable
bb107:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i1
  %l20 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb5
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t9 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t6)
  store i32 %t9, ptr %l8
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l5, !tbaa !29
  %t11 = load i32, ptr %l8, !tbaa !23
  %t12 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t10, i32 %t11)
  store i1 %t12, ptr %l9
  br label %bb4
bb4:
  %t13 = load i1, ptr %l9, !tbaa !21
  store i1 %t13, ptr %l4, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l4, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb10
bb7:
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l11, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t19 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t16)
  store i32 %t19, ptr %l14
  br label %bb8
bb8:
  %t20 = load ptr, ptr %l11, !tbaa !29
  %t21 = load i32, ptr %l14, !tbaa !23
  %t22 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %t20, i32 %t21)
  store i1 %t22, ptr %l15
  br label %bb9
bb9:
  %t23 = load i1, ptr %l15, !tbaa !21
  %t24 = xor i1 %t23, true
  store i1 %t24, ptr %l10, !tbaa !21
  br label %bb10
bb10:
  %t26 = load i1, ptr %l10, !tbaa !21
  br i1 %t26, label %bb11, label %bb12
bb11:
  store i1 false, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t32 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCopied(ptr %v0, ptr %v1, ptr %t28, ptr %t29)
  store i1 %t32, ptr %l20
  br label %bb14
bb14:
  %t33 = load i1, ptr %l20, !tbaa !21
  store i1 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eseqElem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l9 = alloca %"compiler/source:Span"
  %l11 = alloca i32
  %l15 = alloca %"compiler/typed:Elem"
  %l19 = alloca ptr
  %l20 = alloca %"compiler/source:Span"
  %l21 = alloca %"compiler/source:Span"
  %l23 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l38 = alloca ptr
  %l39 = alloca %"compiler/source:Span"
  %l42 = alloca i32
  %l43 = alloca ptr
  %l47 = alloca i32
  %rv = alloca ptr
  %t21 = alloca { i64, [4 x i64] }, align 8
  %t90 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = getelementptr %"compiler/check:seqOf", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp slt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t8, ptr %l9
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t11 = getelementptr %"compiler/check:seqOf", ptr %t9, i32 0, i32 0
  %t12 = load i32, ptr %t11, !tbaa !23
  store i32 %t12, ptr %l11, !tbaa !23
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t14 = load ptr, ptr %l4, !tbaa !29
  %t18 = call %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v1, ptr %v3, ptr %v4, ptr %t13, ptr %t14, i32 0)
  store %"compiler/typed:Elem" %t18, ptr %l15
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t19 = load %"compiler/typed:Elem", ptr %l15
  %t20 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 24, i64 8)
  store %"compiler/typed:Elem" %t19, ptr %t20
  store { i64, [4 x i64] } zeroinitializer, ptr %t21
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t21, i32 0, i32 0
  store i64 4, ptr %t22
  %t23 = load %"compiler/source:Span", ptr %l9
  %t24 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t23, 0
  %t25 = load i32, ptr %l11, !tbaa !23
  %t26 = insertvalue { %"compiler/source:Span", i32, ptr } %t24, i32 %t25, 1
  %t28 = insertvalue { %"compiler/source:Span", i32, ptr } %t26, ptr %t20, 2
  %t29 = getelementptr { i64, [4 x i64] }, ptr %t21, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t28, ptr %t29
  %t30 = load { i64, [4 x i64] }, ptr %t21
  %t32 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 40, i64 8)
  store { i64, [4 x i64] } %t30, ptr %t32
  store ptr %t32, ptr %rv
  br label %ret
bb4:
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l19, !tbaa !29
  %t35 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t35, ptr %l20
  %t36 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t36, ptr %l21
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t39 = getelementptr %"compiler/check:seqOf", ptr %t37, i32 0, i32 1
  %t40 = load i64, ptr %t39, !tbaa !24
  store i64 %t40, ptr %l23, !tbaa !24
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load %"compiler/source:Span", ptr %l1
  %t43 = load ptr, ptr %l2, !tbaa !29
  %t47 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v0, ptr %t41, %"compiler/source:Span" %t42, ptr %t43)
  store ptr %t47, ptr %l27
  br label %bb5
bb5:
  %t48 = load ptr, ptr %l27, !tbaa !29
  store ptr %t48, ptr %l28, !tbaa !29
  %t49 = icmp sge i64 0, 0
  br i1 %t49, label %bb6, label %bb7
bb6:
  %t51 = icmp sle i64 0, 1152921504606846975
  br i1 %t51, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_5b70aeb4dcee2d2_fdbe62f0939a6ff6)
  unreachable
bb8:
  %t53 = mul i64 0, 8
  %t54 = insertvalue { i64, ptr } undef, i64 0, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t55, ptr %l31, !tbaa !27
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load ptr, ptr %l4, !tbaa !29
  %t60 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v3, ptr %v0, ptr %t56, ptr %t57)
  store { i64, ptr } %t60, ptr %l34
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_5b70aeb4dcee2d2_fdbe62f0939a6ff6)
  unreachable
bb10:
  %t61 = icmp sge i64 0, 0
  br i1 %t61, label %bb11, label %bb12
bb11:
  %t63 = icmp sle i64 0, 2305843009213693951
  br i1 %t63, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_51f82334067145c7_15912fbf1ec70a8b)
  unreachable
bb13:
  %t65 = mul i64 0, 4
  %t66 = insertvalue { i64, ptr } undef, i64 0, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t68 = load ptr, ptr %l19, !tbaa !29
  %t69 = load %"compiler/source:Span", ptr %l20
  %t70 = load %"compiler/source:Span", ptr %l21
  %t71 = load i64, ptr %l23, !tbaa !24
  %t72 = load ptr, ptr %l28, !tbaa !29
  %t73 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t74 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t76 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v4, ptr %v4, ptr %t68, %"compiler/source:Span" %t69, %"compiler/source:Span" %t70, i64 %t71, ptr %t72, { i64, ptr } %t73, { i64, ptr } %t74, { i64, ptr } %t67)
  store ptr %t76, ptr %l38
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_51f82334067145c7_15912fbf1ec70a8b)
  unreachable
bb15:
  %t77 = load ptr, ptr %l38, !tbaa !29
  store ptr %t77, ptr %l5, !tbaa !29
  %t78 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t78, ptr %l39
  %t79 = load ptr, ptr %l5, !tbaa !29
  %t82 = call i32 @compiler_2fcheck_2etypeOf(ptr %v4, ptr %t79)
  store i32 %t82, ptr %l42
  br label %bb16
bb16:
  %t83 = load ptr, ptr %l5, !tbaa !29
  store ptr %t83, ptr %l43, !tbaa !29
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load %"compiler/source:Span", ptr %l1
  %t89 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t84, i32 8, %"compiler/source:Span" %t85)
  store i32 %t89, ptr %l47
  br label %bb17
bb17:
  store { i64, [4 x i64] } zeroinitializer, ptr %t90
  %t91 = getelementptr { i64, [4 x i64] }, ptr %t90, i32 0, i32 0
  store i64 6, ptr %t91
  %t92 = load %"compiler/source:Span", ptr %l39
  %t93 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t92, 0
  %t94 = load i32, ptr %l42, !tbaa !23
  %t95 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t93, i32 %t94, 1
  %t96 = load ptr, ptr %l43, !tbaa !29
  %t97 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t95, ptr %t96, 2
  %t98 = load i32, ptr %l47, !tbaa !23
  %t99 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t97, i32 %t98, 3
  %t100 = getelementptr { i64, [4 x i64] }, ptr %t90, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t99, ptr %t100
  %t101 = load { i64, [4 x i64] }, ptr %t90
  %t103 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 40, i64 8)
  store { i64, [4 x i64] } %t101, ptr %t103
  store ptr %t103, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eseqOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l7 = alloca i64
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca i32
  %l16 = alloca { i64, ptr }
  %l19 = alloca %"compiler/typed:Seq"
  %rv = alloca ptr
  %t29 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 37
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i64, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l7, !tbaa !24
  %t9 = icmp eq i64 %t7, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l4, !tbaa !29
  store ptr %t11, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store %"compiler/source:Span" %a1, ptr %l11
  store i32 %a2, ptr %l12, !tbaa !23
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 37
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t17, i64 %t18)
  store { i64, ptr } %t21, ptr %l16
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l4, !tbaa !29
  %t24 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t26 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %t24, ptr %t22, i1 false)
  store %"compiler/typed:Seq" %t26, ptr %l19
  br label %bb6
bb6:
  %t27 = load %"compiler/typed:Seq", ptr %l19
  %t28 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"compiler/typed:Seq" %t27, ptr %t28
  store { i64, [5 x i64] } zeroinitializer, ptr %t29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 0
  store i64 12, ptr %t30
  %t31 = load %"compiler/source:Span", ptr %l11
  %t32 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t31, 0
  %t33 = load i32, ptr %l12, !tbaa !23
  %t34 = insertvalue { %"compiler/source:Span", i32, ptr } %t32, i32 %t33, 1
  %t36 = insertvalue { %"compiler/source:Span", i32, ptr } %t34, ptr %t28, 2
  %t37 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t36, ptr %t37
  %t38 = load { i64, [5 x i64] }, ptr %t29
  %t40 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t38, ptr %t40
  store ptr %t40, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleUnread(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/typed:Local"
  %l8 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca %"compiler/names:Unread"
  %l13 = alloca { i64, [3 x i64] }
  %l19 = alloca i64
  %l25 = alloca i64
  %l27 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l30 = alloca i64
  %l32 = alloca i64
  %l37 = alloca ptr
  %l43 = alloca i64
  %l45 = alloca i64
  %l50 = alloca %"compiler/typed:Local"
  %l54 = alloca i1
  %l65 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l69 = alloca i1
  %l72 = alloca i1
  %l76 = alloca i1
  %l77 = alloca i1
  %l78 = alloca i1
  %l81 = alloca i1
  %l82 = alloca i32
  %l95 = alloca i64
  %l97 = alloca i64
  %l102 = alloca %"compiler/names:Unread"
  %l113 = alloca ptr
  %l114 = alloca { i64, [3 x i64] }
  %l117 = alloca { i64, ptr }
  %l119 = alloca %"compiler/msgs:Msg"
  %l120 = alloca i64
  %l128 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l129 = alloca i1
  %l132 = alloca i1
  %l133 = alloca i32
  %l138 = alloca ptr
  %l139 = alloca { i64, [3 x i64] }
  %l142 = alloca { i64, ptr }
  %l144 = alloca %"compiler/msgs:Msg"
  %l145 = alloca i64
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %t202 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/names:Resolver", ptr %t7, i32 0, i32 18
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aUnread_3e_2eLen_3ccompiler_2fnames_3aUnread_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l19
  br label %bb1
bb1:
  %t12 = load i64, ptr %l19, !tbaa !24
  %t13 = icmp eq i64 %t12, 0
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/generic:Program", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/load:Loader", ptr %t21, i32 0, i32 4
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %t24)
  store i64 %t26, ptr %l25
  br label %bb5
bb5:
  %t27 = load i64, ptr %l25, !tbaa !24
  %t28 = icmp sgt i64 %t27, 0
  br i1 %t28, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  br label %bb8
bb8:
  %t30 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t30, ptr %l27
  br label %bb9
bb9:
  %t31 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l27
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t31, ptr %l1
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 14
  store ptr %t34, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb10
bb10:
  %t36 = load i64, ptr %l3, !tbaa !24
  store i64 %t36, ptr %l30, !tbaa !24
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t37)
  store i64 %t39, ptr %l32
  br label %bb11
bb11:
  %t40 = load i64, ptr %l30, !tbaa !24
  %t41 = load i64, ptr %l32, !tbaa !24
  %t42 = icmp slt i64 %t40, %t41
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb12, label %bb13
bb12:
  br label %bb51
bb13:
  br label %bb14
bb14:
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t47 = load i64, ptr %l3, !tbaa !24
  %t50 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t46, i64 %t47)
  store ptr %t50, ptr %l37
  br label %bb15
bb15:
  %t51 = load ptr, ptr %l37, !tbaa !29
  store ptr %t51, ptr %l4, !tbaa !29
  %t52 = load ptr, ptr %l4, !tbaa !29
  %t54 = getelementptr %"compiler/typed:Body", ptr %t52, i32 0, i32 11
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = icmp eq ptr %t55, null
  br i1 %t57, label %bb16, label %bb17
bb16:
  br label %bb50
bb17:
  br label %bb18
bb18:
  %t59 = load ptr, ptr %l4, !tbaa !29
  %t61 = getelementptr %"compiler/typed:Body", ptr %t59, i32 0, i32 7
  store ptr %t61, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s7
  %t63 = load i64, ptr %l6, !tbaa !24
  store i64 %t63, ptr %l43, !tbaa !24
  %t64 = load ptr, ptr %l5, !tbaa !29
  %t66 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t64)
  store i64 %t66, ptr %l45
  br label %bb20
bb20:
  %t67 = load i64, ptr %l43, !tbaa !24
  %t68 = load i64, ptr %l45, !tbaa !24
  %t69 = icmp slt i64 %t67, %t68
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s7)
  br label %bb49
bb22:
  br label %bb23
bb23:
  %t73 = load ptr, ptr %l5, !tbaa !29
  %t74 = load i64, ptr %l6, !tbaa !24
  %t77 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t73, i64 %t74)
  store %"compiler/typed:Local" %t77, ptr %l50
  br label %bb24
bb24:
  %t78 = load %"compiler/typed:Local", ptr %l50
  store %"compiler/typed:Local" %t78, ptr %l7
  %t79 = getelementptr %"compiler/typed:Local", ptr %l7, i32 0, i32 4
  %t80 = load i32, ptr %t79, !range !{i32 0, i32 7}
  %t82 = trunc i64 1 to i32
  %t83 = icmp eq i32 %t80, %t82
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb27
bb26:
  %t87 = getelementptr %"compiler/typed:Local", ptr %l7, i32 0, i32 0
  %t88 = load i32, ptr %t87, !tbaa !23
  %t90 = icmp eq i32 %t88, 0
  store i1 %t90, ptr %l54, !tbaa !21
  br label %bb27
bb27:
  %t92 = load i1, ptr %l54, !tbaa !21
  br i1 %t92, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s7)
  br label %bb48
bb29:
  br label %bb30
bb30:
  %t93 = load ptr, ptr %l4, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Body", ptr %t93, i32 0, i32 3
  %t96 = load i64, ptr %t95, !tbaa !24
  %t97 = getelementptr %"compiler/typed:Local", ptr %l7, i32 0, i32 1
  %t98 = getelementptr %"compiler/source:Span", ptr %t97, i32 0, i32 0
  %t99 = load i32, ptr %t98, !tbaa !23
  %t101 = sext i32 %t99 to i64
  %t103 = shl i64 %t101, 32
  %t104 = getelementptr %"compiler/typed:Local", ptr %l7, i32 0, i32 1
  %t105 = getelementptr %"compiler/source:Span", ptr %t104, i32 0, i32 1
  %t106 = load i32, ptr %t105, !tbaa !23
  %t108 = sext i32 %t106 to i64
  %t111 = or i64 %t103, %t108
  %t114 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s7, i64 %t96, i64 %t111)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t114, ptr %l65
  br label %bb31
bb31:
  %t115 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l65
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t115, ptr %l8
  %t116 = getelementptr %"compiler/typed:Local", ptr %l7, i32 0, i32 2
  %t117 = load i32, ptr %t116, !tbaa !23
  %t118 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t121 = icmp ne i32 %t117, %t118
  br i1 %t121, label %bb32, label %bb33
bb32:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/typed:Local", ptr %l7, i32 0, i32 2
  %t125 = load i32, ptr %t124, !tbaa !23
  %t128 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edestructs(ptr %v0, ptr %t123, i32 %t125)
  store i1 %t128, ptr %l72
  br label %bb34
bb33:
  store i1 false, ptr %l69, !tbaa !21
  br label %bb35
bb34:
  %t129 = load i1, ptr %l72, !tbaa !21
  %t130 = xor i1 %t129, true
  store i1 %t130, ptr %l69, !tbaa !21
  br label %bb35
bb35:
  %t132 = load i1, ptr %l69, !tbaa !21
  store i1 %t132, ptr %l9, !tbaa !21
  %t133 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l8
  %t136 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %s0, ptr %l1, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t133)
  store i1 %t136, ptr %l76
  br label %bb36
bb36:
  %t137 = load i1, ptr %l76, !tbaa !21
  br i1 %t137, label %bb37, label %bb38
bb37:
  %t138 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l8
  %t141 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H190b78e3c1eec037529224679e114a85(ptr %s0, ptr %l1, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t138)
  %t142 = extractvalue { i32, i1 } %t141, 1
  %t143 = extractvalue { i32, i1 } %t141, 0
  store i32 %t143, ptr %l82
  %t144 = icmp ne i32 %t143, 0
  br i1 %t144, label %bb40, label %ok.145, !prof !99
ok.145:
  store i1 %t142, ptr %l81
  br label %bb39
bb38:
  store i1 false, ptr %l77, !tbaa !21
  br label %bb43
bb39:
  %t146 = load i1, ptr %l81, !tbaa !21
  store i1 %t146, ptr %l78, !tbaa !21
  br label %bb42
bb40:
  br label %bb41
bb41:
  call void @__olang_ert_req_clear()
  store i1 true, ptr %l78, !tbaa !21
  br label %bb42
bb42:
  %t147 = load i1, ptr %l78, !tbaa !21
  %t148 = xor i1 %t147, true
  store i1 %t148, ptr %l77, !tbaa !21
  br label %bb43
bb43:
  %t150 = load i1, ptr %l77, !tbaa !21
  br i1 %t150, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s7)
  br label %bb48
bb45:
  br label %bb46
bb46:
  %t151 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l8
  %t152 = load i1, ptr %l9, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %s0, ptr %l1, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t151, i1 %t152)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s7)
  br label %bb48
bb48:
  %t156 = load i64, ptr %l6, !tbaa !24
  %t158 = add i64 %t156, 1
  store i64 %t158, ptr %l6, !tbaa !24
  br label %bb19
bb49:
  br label %bb50
bb50:
  %t160 = load i64, ptr %l3, !tbaa !24
  %t162 = add i64 %t160, 1
  store i64 %t162, ptr %l3, !tbaa !24
  br label %bb10
bb51:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/check:Checker", ptr %t164, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t169 = getelementptr %"compiler/generic:Program", ptr %t167, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t172 = getelementptr %"compiler/names:Resolver", ptr %t170, i32 0, i32 18
  store ptr %t172, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb52
bb52:
  store %olang.scope zeroinitializer, ptr %s13
  %t174 = load i64, ptr %l11, !tbaa !24
  store i64 %t174, ptr %l95, !tbaa !24
  %t175 = load ptr, ptr %l10, !tbaa !29
  %t177 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aUnread_3e_2eLen_3ccompiler_2fnames_3aUnread_3e(ptr %v0, ptr %t175)
  store i64 %t177, ptr %l97
  br label %bb53
bb53:
  %t178 = load i64, ptr %l95, !tbaa !24
  %t179 = load i64, ptr %l97, !tbaa !24
  %t180 = icmp slt i64 %t178, %t179
  %t182 = xor i1 %t180, true
  br i1 %t182, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s13)
  br label %bb76
bb55:
  br label %bb56
bb56:
  %t184 = load ptr, ptr %l10, !tbaa !29
  %t185 = load i64, ptr %l11, !tbaa !24
  %t188 = call %"compiler/names:Unread" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aUnread_3e_2eAt_3ccompiler_2fnames_3aUnread_3e(ptr %v0, ptr %t184, i64 %t185)
  store %"compiler/names:Unread" %t188, ptr %l102
  br label %bb57
bb57:
  %t189 = load %"compiler/names:Unread", ptr %l102
  store %"compiler/names:Unread" %t189, ptr %l12
  %t190 = getelementptr %"compiler/names:Unread", ptr %l12, i32 0, i32 0
  %t191 = load i64, ptr %t190, !tbaa !24
  %t192 = getelementptr %"compiler/names:Unread", ptr %l12, i32 0, i32 1
  %t193 = getelementptr %"compiler/source:Span", ptr %t192, i32 0, i32 0
  %t194 = load i32, ptr %t193, !tbaa !23
  %t196 = sext i32 %t194 to i64
  %t197 = getelementptr %"compiler/names:Unread", ptr %l12, i32 0, i32 1
  %t198 = getelementptr %"compiler/source:Span", ptr %t197, i32 0, i32 1
  %t199 = load i32, ptr %t198, !tbaa !23
  %t201 = sext i32 %t199 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t202
  %t203 = getelementptr { i64, [3 x i64] }, ptr %t202, i32 0, i32 0
  store i64 3, ptr %t203
  %t205 = insertvalue { i64, i64, i64 } undef, i64 %t191, 0
  %t207 = insertvalue { i64, i64, i64 } %t205, i64 %t196, 1
  %t209 = insertvalue { i64, i64, i64 } %t207, i64 %t201, 2
  %t210 = getelementptr { i64, [3 x i64] }, ptr %t202, i32 0, i32 1
  store { i64, i64, i64 } %t209, ptr %t210
  %t211 = load { i64, [3 x i64] }, ptr %t202
  store { i64, [3 x i64] } %t211, ptr %l13
  %t213 = getelementptr %"compiler/names:Unread", ptr %l12, i32 0, i32 3
  %t214 = load i1, ptr %t213, !tbaa !21
  br i1 %t214, label %bb58, label %bb59
bb58:
  store %olang.scope zeroinitializer, ptr %s14
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/check:Checker", ptr %t216, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !29
  %t221 = getelementptr %"compiler/generic:Program", ptr %t219, i32 0, i32 0
  %t222 = load ptr, ptr %t221, !tbaa !29
  %t224 = getelementptr %"compiler/load:Loader", ptr %t222, i32 0, i32 4
  %t225 = load ptr, ptr %t224, !tbaa !29
  store ptr %t225, ptr %l113, !tbaa !29
  %t226 = load { i64, [3 x i64] }, ptr %l13
  store { i64, [3 x i64] } %t226, ptr %l114
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/names:Unread", ptr %l12, i32 0, i32 2
  %t229 = load i32, ptr %t228, !tbaa !23
  %t232 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s14, ptr %t227, i32 %t229)
  store { i64, ptr } %t232, ptr %l117
  br label %bb60
bb59:
  br label %bb63
bb60:
  %t233 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t234 = extractvalue { i64, ptr } %t233, 0
  %t235 = extractvalue { i64, ptr } %t233, 1
  %t236 = mul i64 %t234, 1
  %t237 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t236)
  call void @llvm.memcpy.p0.p0.i64(ptr %t237, ptr %t235, i64 %t236, i1 false)
  %t238 = insertvalue { i64, ptr } undef, i64 %t234, 0
  %t239 = insertvalue { i64, ptr } %t238, ptr %t237, 1
  %t241 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLocalUnusedBare(ptr %s14, ptr %s14, { i64, ptr } %t239)
  store %"compiler/msgs:Msg" %t241, ptr %l119
  br label %bb61
bb61:
  %t242 = load ptr, ptr %l113, !tbaa !29
  %t243 = load { i64, [3 x i64] }, ptr %l114
  %t244 = load %"compiler/msgs:Msg", ptr %l119
  %t245 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorAlone(ptr %v0, ptr %s14, ptr %t242, { i64, [3 x i64] } %t243, %"compiler/msgs:Msg" %t244)
  store i64 %t245, ptr %l120
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s13)
  br label %bb75
bb63:
  %t246 = getelementptr %"compiler/names:Unread", ptr %l12, i32 0, i32 0
  %t247 = load i64, ptr %t246, !tbaa !24
  %t248 = getelementptr %"compiler/names:Unread", ptr %l12, i32 0, i32 1
  %t249 = getelementptr %"compiler/source:Span", ptr %t248, i32 0, i32 0
  %t250 = load i32, ptr %t249, !tbaa !23
  %t252 = sext i32 %t250 to i64
  %t254 = shl i64 %t252, 32
  %t255 = getelementptr %"compiler/names:Unread", ptr %l12, i32 0, i32 1
  %t256 = getelementptr %"compiler/source:Span", ptr %t255, i32 0, i32 1
  %t257 = load i32, ptr %t256, !tbaa !23
  %t259 = sext i32 %t257 to i64
  %t262 = or i64 %t254, %t259
  %t265 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s13, i64 %t247, i64 %t262)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t265, ptr %l128
  br label %bb64
bb64:
  %t266 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l128
  %t270 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H190b78e3c1eec037529224679e114a85(ptr %s0, ptr %l1, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t266)
  %t271 = extractvalue { i32, i1 } %t270, 1
  %t272 = extractvalue { i32, i1 } %t270, 0
  store i32 %t272, ptr %l133
  %t273 = icmp ne i32 %t272, 0
  br i1 %t273, label %bb66, label %ok.274, !prof !99
ok.274:
  store i1 %t271, ptr %l132
  br label %bb65
bb65:
  %t275 = load i1, ptr %l132, !tbaa !21
  store i1 %t275, ptr %l129, !tbaa !21
  br label %bb68
bb66:
  br label %bb67
bb67:
  call void @__olang_ert_req_clear()
  store i1 false, ptr %l129, !tbaa !21
  br label %bb68
bb68:
  %t276 = load i1, ptr %l129, !tbaa !21
  %t277 = xor i1 %t276, true
  br i1 %t277, label %bb69, label %bb70
bb69:
  call void @__olang_scope_close(ptr %s13)
  br label %bb75
bb70:
  br label %bb71
bb71:
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr %"compiler/check:Checker", ptr %t279, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !29
  %t284 = getelementptr %"compiler/generic:Program", ptr %t282, i32 0, i32 0
  %t285 = load ptr, ptr %t284, !tbaa !29
  %t287 = getelementptr %"compiler/load:Loader", ptr %t285, i32 0, i32 4
  %t288 = load ptr, ptr %t287, !tbaa !29
  store ptr %t288, ptr %l138, !tbaa !29
  %t289 = load { i64, [3 x i64] }, ptr %l13
  store { i64, [3 x i64] } %t289, ptr %l139
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t291 = getelementptr %"compiler/names:Unread", ptr %l12, i32 0, i32 2
  %t292 = load i32, ptr %t291, !tbaa !23
  %t295 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s13, ptr %t290, i32 %t292)
  store { i64, ptr } %t295, ptr %l142
  br label %bb72
bb72:
  %t296 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t297 = extractvalue { i64, ptr } %t296, 0
  %t298 = extractvalue { i64, ptr } %t296, 1
  %t299 = mul i64 %t297, 1
  %t300 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t299)
  call void @llvm.memcpy.p0.p0.i64(ptr %t300, ptr %t298, i64 %t299, i1 false)
  %t301 = insertvalue { i64, ptr } undef, i64 %t297, 0
  %t302 = insertvalue { i64, ptr } %t301, ptr %t300, 1
  %t304 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLocalUnused(ptr %s13, ptr %s13, { i64, ptr } %t302)
  store %"compiler/msgs:Msg" %t304, ptr %l144
  br label %bb73
bb73:
  %t305 = load ptr, ptr %l138, !tbaa !29
  %t306 = load { i64, [3 x i64] }, ptr %l139
  %t307 = load %"compiler/msgs:Msg", ptr %l144
  %t308 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorAlone(ptr %v0, ptr %s13, ptr %t305, { i64, [3 x i64] } %t306, %"compiler/msgs:Msg" %t307)
  store i64 %t308, ptr %l145
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s13)
  br label %bb75
bb75:
  %t309 = load i64, ptr %l11, !tbaa !24
  %t311 = add i64 %t309, 1
  store i64 %t311, ptr %l11, !tbaa !24
  br label %bb52
bb76:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i32
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i1
  %l25 = alloca i64
  %l26 = alloca i32
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l33 = alloca i1
  %l34 = alloca i1
  %l35 = alloca i1
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i32
  %l56 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca { i64, ptr }
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca { i64, ptr }
  %l74 = alloca i64
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca i64
  %l79 = alloca i64
  %l84 = alloca i1
  %l85 = alloca ptr
  %l88 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l101 = alloca i32
  %l126 = alloca i32
  %l127 = alloca ptr
  %l130 = alloca ptr
  %l135 = alloca i32
  %l136 = alloca i32
  %l137 = alloca { i64, ptr }
  %l140 = alloca ptr
  %l143 = alloca ptr
  %l148 = alloca i32
  %l149 = alloca i64
  %l150 = alloca { i64, ptr }
  %l155 = alloca ptr
  %l160 = alloca i32
  %l161 = alloca { i64, ptr }
  %l166 = alloca i64
  %l172 = alloca i64
  %l175 = alloca i64
  %l195 = alloca i1
  %l197 = alloca i64
  %l204 = alloca ptr
  %l206 = alloca ptr
  %l211 = alloca i32
  %l212 = alloca i1
  %l213 = alloca { i64, ptr }
  %l217 = alloca { i64, ptr }
  %l219 = alloca { i64, ptr }
  %l222 = alloca { i64, ptr }
  %l231 = alloca ptr
  %l232 = alloca ptr
  %l235 = alloca ptr
  %l240 = alloca i32
  %l241 = alloca i64
  %l242 = alloca { i64, ptr }
  %l244 = alloca ptr
  %l245 = alloca ptr
  %l248 = alloca ptr
  %l253 = alloca i32
  %l254 = alloca i32
  %l255 = alloca { i64, ptr }
  %l256 = alloca ptr
  %l257 = alloca ptr
  %l262 = alloca i32
  %l267 = alloca ptr
  %l272 = alloca i32
  %l273 = alloca { i64, ptr }
  %l278 = alloca i32
  %l283 = alloca ptr
  %l284 = alloca ptr
  %l289 = alloca i64
  %l290 = alloca { i64, ptr }
  %l292 = alloca ptr
  %l293 = alloca ptr
  %l298 = alloca i32
  %l299 = alloca { i64, ptr }
  %l305 = alloca { i64, ptr }
  %l313 = alloca i64
  %l316 = alloca i64
  %l339 = alloca { i64, ptr }
  %l348 = alloca ptr
  %l349 = alloca ptr
  %l354 = alloca i32
  %l361 = alloca ptr
  %l362 = alloca ptr
  %l367 = alloca i32
  %l377 = alloca i64
  %l383 = alloca ptr
  %l384 = alloca ptr
  %l387 = alloca ptr
  %l392 = alloca i32
  %l393 = alloca i32
  %l396 = alloca i1
  %l402 = alloca ptr
  %l403 = alloca ptr
  %l408 = alloca i32
  %l409 = alloca ptr
  %l414 = alloca { i64, ptr }
  %l421 = alloca i32
  %l424 = alloca ptr
  %l429 = alloca i32
  %l430 = alloca { i64, ptr }
  %l438 = alloca { i64, ptr }
  %l452 = alloca i32
  %l455 = alloca i1
  %l458 = alloca ptr
  %l463 = alloca i32
  %l464 = alloca { i64, ptr }
  %l467 = alloca i1
  %l472 = alloca i1
  %l475 = alloca i1
  %l485 = alloca i32
  %l488 = alloca ptr
  %l489 = alloca ptr
  %l494 = alloca i32
  %l495 = alloca ptr
  %l500 = alloca i1
  %l501 = alloca { i64, ptr }
  %l507 = alloca ptr
  %l512 = alloca i1
  %l513 = alloca { i64, ptr }
  %l516 = alloca ptr
  %l521 = alloca i32
  %l522 = alloca { i64, ptr }
  %l527 = alloca { i64, ptr }
  %l533 = alloca i64
  %l536 = alloca i64
  %l562 = alloca ptr
  %l564 = alloca { i64, ptr }
  %l569 = alloca { i64, ptr }
  %l573 = alloca { i64, ptr }
  %l583 = alloca i32
  %l588 = alloca ptr
  %l593 = alloca i32
  %l594 = alloca { i64, ptr }
  %l600 = alloca i64
  %l603 = alloca i64
  %l621 = alloca ptr
  %l624 = alloca { i64, ptr }
  %l627 = alloca { i64, ptr }
  %l636 = alloca ptr
  %l640 = alloca i1
  %l645 = alloca i32
  %l648 = alloca i1
  %l651 = alloca ptr
  %l656 = alloca i32
  %l657 = alloca { i64, ptr }
  %l677 = alloca { i64, ptr }
  %l683 = alloca ptr
  %l686 = alloca { i64, ptr }
  %l698 = alloca ptr
  %l699 = alloca ptr
  %l704 = alloca i32
  %l712 = alloca { i64, ptr }
  %l715 = alloca ptr
  %l720 = alloca i32
  %l721 = alloca { i64, ptr }
  %l726 = alloca { i64, ptr }
  %l732 = alloca i64
  %l735 = alloca i64
  %l754 = alloca ptr
  %l756 = alloca { i64, ptr }
  %l759 = alloca { i64, ptr }
  %l764 = alloca i1
  %l765 = alloca { i64, ptr }
  %l771 = alloca ptr
  %l775 = alloca { i64, ptr }
  %l778 = alloca i32
  %l779 = alloca { i64, ptr }
  %l790 = alloca ptr
  %l791 = alloca ptr
  %l795 = alloca { i64, ptr }
  %l798 = alloca i32
  %l805 = alloca i64
  %l808 = alloca i64
  %l829 = alloca ptr
  %l831 = alloca { i64, ptr }
  %l836 = alloca { i64, ptr }
  %l840 = alloca { i64, ptr }
  %l855 = alloca ptr
  %l860 = alloca i64
  %l865 = alloca ptr
  %l866 = alloca ptr
  %l868 = alloca ptr
  %l873 = alloca i64
  %l878 = alloca i64
  %l879 = alloca %"compiler/generic:varRow"
  %l881 = alloca { i64, ptr }
  %l886 = alloca ptr
  %l891 = alloca i32
  %l892 = alloca { i64, ptr }
  %l902 = alloca i64
  %l905 = alloca i64
  %l928 = alloca { i64, ptr }
  %l933 = alloca ptr
  %l938 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s44 = alloca %olang.scope
  %s49 = alloca %olang.scope
  %s52 = alloca %olang.scope
  %s53 = alloca %olang.scope
  %s55 = alloca %olang.scope
  %s59 = alloca %olang.scope
  %s60 = alloca %olang.scope
  %s65 = alloca %olang.scope
  %s68 = alloca %olang.scope
  %s71 = alloca %olang.scope
  %s75 = alloca %olang.scope
  %s78 = alloca %olang.scope
  %s80 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l84
  br label %bb1
bb1:
  %t11 = load i1, ptr %l84, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t12 = load ptr, ptr %l1, !tbaa !29
  store ptr %t12, ptr %l85, !tbaa !29
  %t13 = load i32, ptr %l2, !tbaa !23
  %t15 = icmp sle i32 %t13, 14
  br i1 %t15, label %bb4, label %bb5
bb3:
  br label %bb10
bb4:
  %t17 = load i32, ptr %l2, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2fcheck_2eprimName(ptr %s1, i32 %t17)
  store { i64, ptr } %t19, ptr %l90
  br label %bb6
bb5:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  %t26 = load i32, ptr %l2, !tbaa !23
  %t29 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s1, ptr %t25, i32 %t26)
  store { i64, ptr } %t29, ptr %l95
  br label %bb7
bb6:
  %t30 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t30, ptr %l88, !tbaa !27
  br label %bb8
bb7:
  %t31 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  %t33 = extractvalue { i64, ptr } %t31, 1
  %t34 = mul i64 %t32, 1
  %t35 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t34)
  call void @llvm.memcpy.p0.p0.i64(ptr %t35, ptr %t33, i64 %t34, i1 false)
  %t36 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  store { i64, ptr } %t37, ptr %l88, !tbaa !27
  br label %bb8
bb8:
  %t39 = load ptr, ptr %l85, !tbaa !29
  %t40 = load { i64, ptr }, ptr %l88, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s1, ptr %t39, { i64, ptr } %t40)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb10:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 2
  %t47 = load i32, ptr %l2, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t50, ptr %l101
  br label %bb11
bb11:
  %t51 = load i32, ptr %l101, !range !{i32 0, i32 33}
  store i32 %t51, ptr %l4
  %t52 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t54 = trunc i64 2 to i32
  %t55 = icmp eq i32 %t52, %t54
  br i1 %t55, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb16
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t57 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t57, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d31, i32 0, i32 1) })
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb441
bb16:
  %t59 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t61 = trunc i64 0 to i32
  %t62 = icmp eq i32 %t59, %t61
  br i1 %t62, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t64 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t64, i8 63)
  br label %bb20
bb20:
  br label %bb441
bb21:
  %t66 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t68 = trunc i64 1 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb26
bb24:
  store %olang.scope zeroinitializer, ptr %s4
  %t71 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s4, ptr %t71, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d32, i32 0, i32 1) })
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s4)
  br label %bb441
bb26:
  %t73 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t75 = trunc i64 15 to i32
  %t76 = icmp eq i32 %t73, %t75
  br i1 %t76, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb31
bb29:
  store %olang.scope zeroinitializer, ptr %s5
  %t78 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s5, ptr %t78, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d33, i32 0, i32 1) })
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb441
bb31:
  %t80 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t82 = trunc i64 16 to i32
  %t83 = icmp eq i32 %t80, %t82
  br i1 %t83, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb36
bb34:
  store %olang.scope zeroinitializer, ptr %s6
  %t85 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s6, ptr %t85, { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d34, i32 0, i32 1) })
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s6)
  br label %bb441
bb36:
  %t87 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t89 = trunc i64 17 to i32
  %t90 = icmp eq i32 %t87, %t89
  br i1 %t90, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb41
bb39:
  store %olang.scope zeroinitializer, ptr %s7
  %t92 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s7, ptr %t92, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d35, i32 0, i32 1) })
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s7)
  br label %bb441
bb41:
  %t94 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t96 = trunc i64 28 to i32
  %t97 = icmp eq i32 %t94, %t96
  br i1 %t97, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb87
bb44:
  store %olang.scope zeroinitializer, ptr %s8
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = getelementptr %"compiler/generic:Program", ptr %t102, i32 0, i32 2
  %t105 = load i32, ptr %l2, !tbaa !23
  %t108 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t104, i32 %t105)
  store i32 %t108, ptr %l126
  br label %bb45
bb45:
  %t109 = load i32, ptr %l126, !tbaa !23
  store i32 %t109, ptr %l5, !tbaa !23
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l127, !tbaa !29
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/check:Checker", ptr %t111, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = getelementptr %"compiler/generic:Program", ptr %t114, i32 0, i32 2
  store ptr %t116, ptr %l130, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = getelementptr %"compiler/generic:Program", ptr %t120, i32 0, i32 2
  %t123 = load i32, ptr %l5, !tbaa !23
  %t126 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t122, i32 %t123)
  store i32 %t126, ptr %l135
  br label %bb46
bb46:
  %t127 = load ptr, ptr %l130, !tbaa !29
  %t128 = load i32, ptr %l135, !tbaa !23
  %t129 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t127, i32 %t128)
  store i32 %t129, ptr %l136
  br label %bb47
bb47:
  %t130 = load ptr, ptr %l127, !tbaa !29
  %t131 = load i32, ptr %l136, !tbaa !23
  %t132 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t130, i32 %t131)
  store { i64, ptr } %t132, ptr %l137
  br label %bb48
bb48:
  %t133 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t133, ptr %l6, !tbaa !27
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t134, i32 0, i32 5
  %t137 = load i1, ptr %t136, !tbaa !21
  br i1 %t137, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s9
  %t139 = load ptr, ptr %l0, !tbaa !29
  store ptr %t139, ptr %l140, !tbaa !29
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/check:Checker", ptr %t140, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t145 = getelementptr %"compiler/generic:Program", ptr %t143, i32 0, i32 2
  store ptr %t145, ptr %l143, !tbaa !29
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/check:Checker", ptr %t146, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t151 = getelementptr %"compiler/generic:Program", ptr %t149, i32 0, i32 2
  %t152 = load i32, ptr %l5, !tbaa !23
  %t155 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t151, i32 %t152)
  store i32 %t155, ptr %l148
  br label %bb51
bb50:
  br label %bb54
bb51:
  %t156 = load ptr, ptr %l143, !tbaa !29
  %t157 = load i32, ptr %l148, !tbaa !23
  %t158 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t156, i32 %t157)
  store i64 %t158, ptr %l149
  br label %bb52
bb52:
  %t159 = load ptr, ptr %l140, !tbaa !29
  %t160 = load i64, ptr %l149, !tbaa !24
  %t161 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2equalifierFor(ptr %v0, ptr %s9, ptr %t159, i64 %t160)
  store { i64, ptr } %t161, ptr %l150
  br label %bb53
bb53:
  %t162 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t163 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t164 = extractvalue { i64, ptr } %t163, 1
  %t165 = extractvalue { i64, ptr } %t163, 0
  %t167 = extractvalue { i64, ptr } %t162, 1
  %t168 = extractvalue { i64, ptr } %t162, 0
  %t169 = add i64 %t165, %t168
  %t170 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t169)
  call void @olang_textcopy(ptr %t170, ptr %t164, i64 %t165)
  %t171 = getelementptr i8, ptr %t170, i64 %t165
  call void @olang_textcopy(ptr %t171, ptr %t167, i64 %t168)
  %t172 = insertvalue { i64, ptr } undef, i64 %t169, 0
  %t173 = insertvalue { i64, ptr } %t172, ptr %t170, 1
  %t175 = extractvalue { i64, ptr } %t173, 0
  %t176 = extractvalue { i64, ptr } %t173, 1
  %t177 = mul i64 %t175, 1
  %t178 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t177)
  call void @llvm.memcpy.p0.p0.i64(ptr %t178, ptr %t176, i64 %t177, i1 false)
  %t179 = insertvalue { i64, ptr } undef, i64 %t175, 0
  %t180 = insertvalue { i64, ptr } %t179, ptr %t178, 1
  store { i64, ptr } %t180, ptr %l6, !tbaa !27
  call void @__olang_scope_close(ptr %s9)
  br label %bb54
bb54:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/check:Checker", ptr %t182, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !29
  store ptr %t185, ptr %l155, !tbaa !29
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = getelementptr %"compiler/check:Checker", ptr %t186, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !29
  %t191 = getelementptr %"compiler/generic:Program", ptr %t189, i32 0, i32 2
  %t192 = load i32, ptr %l5, !tbaa !23
  %t195 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t191, i32 %t192)
  store i32 %t195, ptr %l160
  br label %bb55
bb55:
  %t196 = load ptr, ptr %l155, !tbaa !29
  %t197 = load i32, ptr %l160, !tbaa !23
  %t198 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %s8, ptr %t196, i32 %t197)
  store { i64, ptr } %t198, ptr %l161
  br label %bb56
bb56:
  %t199 = load { i64, ptr }, ptr %l161, !tbaa !27
  store { i64, ptr } %t199, ptr %l7, !tbaa !27
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/check:Checker", ptr %t200, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !29
  %t205 = getelementptr %"compiler/generic:Program", ptr %t203, i32 0, i32 2
  %t206 = load i32, ptr %l2, !tbaa !23
  %t209 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t205, i32 %t206)
  store i64 %t209, ptr %l166
  br label %bb57
bb57:
  %t210 = load i64, ptr %l166, !tbaa !65
  store i64 %t210, ptr %l8, !tbaa !65
  store i1 true, ptr %l9, !tbaa !21
  store i64 0, ptr %l10, !tbaa !24
  %t211 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t211, 0
  store i64 %t213, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t215 = load i64, ptr %l11, !tbaa !24
  %t216 = load i64, ptr %l10, !tbaa !24
  %t219 = icmp sgt i64 %t215, %t216
  br i1 %t219, label %bb58, label %bb59
bb58:
  %t221 = load i64, ptr %l12, !tbaa !24
  %t223 = icmp sgt i64 %t221, 0
  br i1 %t223, label %bb60, label %bb61
bb59:
  store i64 0, ptr %l172, !tbaa !24
  br label %bb63
bb60:
  %t225 = load i64, ptr %l11, !tbaa !24
  %t226 = load i64, ptr %l10, !tbaa !24
  %t229 = sub i64 %t225, %t226
  %t230 = load i64, ptr %l12, !tbaa !24
  %t233 = add i64 %t229, %t230
  %t235 = sub i64 %t233, 1
  %t236 = load i64, ptr %l12, !tbaa !24
  %t239 = sdiv i64 %t235, %t236
  store i64 %t239, ptr %l175, !tbaa !24
  br label %bb62
bb61:
  store i64 0, ptr %l175, !tbaa !24
  br label %bb62
bb62:
  %t241 = load i64, ptr %l175, !tbaa !24
  store i64 %t241, ptr %l172, !tbaa !24
  br label %bb63
bb63:
  %t242 = load i64, ptr %l172, !tbaa !24
  store i64 %t242, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb64
bb64:
  %t243 = load i64, ptr %l14, !tbaa !24
  %t244 = load i64, ptr %l13, !tbaa !24
  %t247 = icmp slt i64 %t243, %t244
  %t249 = xor i1 %t247, true
  br i1 %t249, label %bb65, label %bb66
bb65:
  br label %bb86
bb66:
  br label %bb67
bb67:
  %t251 = load i64, ptr %l10, !tbaa !24
  %t252 = load i64, ptr %l14, !tbaa !24
  %t253 = load i64, ptr %l12, !tbaa !24
  %t256 = mul i64 %t252, %t253
  %t259 = add i64 %t251, %t256
  store i64 %t259, ptr %l15, !tbaa !24
  %t261 = load i64, ptr %l15, !tbaa !24
  %t263 = icmp slt i64 %t261, 64
  br i1 %t263, label %bb68, label %bb69
bb68:
  %t265 = load i64, ptr %l8, !tbaa !65
  %t266 = load i64, ptr %l15, !tbaa !24
  store i64 %t266, ptr %l197, !tbaa !24
  %t267 = load i64, ptr %l197, !tbaa !24
  %t268 = load i64, ptr %l197, !tbaa !24
  %t269 = shl i64 1, %t268
  %t272 = and i64 %t265, %t269
  %t274 = icmp ne i64 %t272, 0
  store i1 %t274, ptr %l195, !tbaa !21
  br label %bb70
bb69:
  store i1 false, ptr %l195, !tbaa !21
  br label %bb70
bb70:
  %t276 = load i1, ptr %l195, !tbaa !21
  br i1 %t276, label %bb71, label %bb72
bb71:
  store %olang.scope zeroinitializer, ptr %s13
  %t277 = load i1, ptr %l9, !tbaa !21
  %t279 = xor i1 %t277, true
  br i1 %t279, label %bb73, label %bb74
bb72:
  br label %bb84
bb73:
  store %olang.scope zeroinitializer, ptr %s14
  %t281 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s14, ptr %t281, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d36, i32 0, i32 1) })
  br label %bb75
bb74:
  br label %bb76
bb75:
  call void @__olang_scope_close(ptr %s14)
  br label %bb76
bb76:
  %t283 = load ptr, ptr %l1, !tbaa !29
  store ptr %t283, ptr %l204, !tbaa !29
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t286 = getelementptr %"compiler/check:Checker", ptr %t284, i32 0, i32 1
  %t287 = load ptr, ptr %t286, !tbaa !29
  store ptr %t287, ptr %l206, !tbaa !29
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t290 = getelementptr %"compiler/check:Checker", ptr %t288, i32 0, i32 1
  %t291 = load ptr, ptr %t290, !tbaa !29
  %t293 = getelementptr %"compiler/generic:Program", ptr %t291, i32 0, i32 2
  %t294 = load i32, ptr %l5, !tbaa !23
  %t297 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t293, i32 %t294)
  store i32 %t297, ptr %l211
  br label %bb77
bb77:
  %t298 = load ptr, ptr %l206, !tbaa !29
  %t299 = load i32, ptr %l211, !tbaa !23
  %t300 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsRaisedError(ptr %v0, ptr %t298, i32 %t299)
  store i1 %t300, ptr %l212
  br label %bb78
bb78:
  %t301 = load i1, ptr %l212, !tbaa !21
  br i1 %t301, label %bb79, label %bb80
bb79:
  %t302 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t304 = extractvalue { i64, ptr } %t302, 1
  %t305 = extractvalue { i64, ptr } %t302, 0
  %t306 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t305)
  call void @olang_textcopy(ptr %t306, ptr %t304, i64 %t305)
  %t307 = insertvalue { i64, ptr } undef, i64 %t305, 0
  %t308 = insertvalue { i64, ptr } %t307, ptr %t306, 1
  %t310 = extractvalue { i64, ptr } %t308, 0
  %t311 = extractvalue { i64, ptr } %t308, 1
  %t312 = mul i64 %t310, 1
  %t313 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t312)
  call void @llvm.memcpy.p0.p0.i64(ptr %t313, ptr %t311, i64 %t312, i1 false)
  %t314 = insertvalue { i64, ptr } undef, i64 %t310, 0
  %t315 = insertvalue { i64, ptr } %t314, ptr %t313, 1
  store { i64, ptr } %t315, ptr %l213, !tbaa !27
  br label %bb82
bb80:
  %t317 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t317, ptr %l217, !tbaa !27
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t319 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t319, ptr %l219, !tbaa !27
  %t320 = load i64, ptr %l15, !tbaa !24
  %t322 = getelementptr { i64, ptr }, ptr %l219, i32 0, i32 1
  %t323 = load ptr, ptr %t322, !tbaa !27
  %t324 = getelementptr i32, ptr %t323, i64 %t320
  %t325 = load i32, ptr %t324, !tbaa !33
  %t328 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s13, ptr %t318, i32 %t325)
  store { i64, ptr } %t328, ptr %l222
  br label %bb81
bb81:
  %t329 = load { i64, ptr }, ptr %l217, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t329, 1
  %t331 = extractvalue { i64, ptr } %t329, 0
  %t332 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t333 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t334 = add i64 %t331, %t333
  %t335 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t336 = extractvalue { i64, ptr } %t335, 1
  %t337 = extractvalue { i64, ptr } %t335, 0
  %t338 = add i64 %t334, %t337
  %t339 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t338)
  call void @olang_textcopy(ptr %t339, ptr %t330, i64 %t331)
  %t340 = getelementptr i8, ptr %t339, i64 %t331
  call void @olang_textcopy(ptr %t340, ptr %t332, i64 %t333)
  %t341 = getelementptr i8, ptr %t340, i64 %t333
  call void @olang_textcopy(ptr %t341, ptr %t336, i64 %t337)
  %t342 = insertvalue { i64, ptr } undef, i64 %t338, 0
  %t343 = insertvalue { i64, ptr } %t342, ptr %t339, 1
  %t345 = extractvalue { i64, ptr } %t343, 0
  %t346 = extractvalue { i64, ptr } %t343, 1
  %t347 = mul i64 %t345, 1
  %t348 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t347)
  call void @llvm.memcpy.p0.p0.i64(ptr %t348, ptr %t346, i64 %t347, i1 false)
  %t349 = insertvalue { i64, ptr } undef, i64 %t345, 0
  %t350 = insertvalue { i64, ptr } %t349, ptr %t348, 1
  store { i64, ptr } %t350, ptr %l213, !tbaa !27
  br label %bb82
bb82:
  %t352 = load ptr, ptr %l204, !tbaa !29
  %t353 = load { i64, ptr }, ptr %l213, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s13, ptr %t352, { i64, ptr } %t353)
  br label %bb83
bb83:
  store i1 false, ptr %l9, !tbaa !21
  call void @__olang_scope_close(ptr %s13)
  br label %bb84
bb84:
  br label %bb85
bb85:
  %t354 = load i64, ptr %l14, !tbaa !24
  %t356 = add i64 %t354, 1
  store i64 %t356, ptr %l14, !tbaa !24
  br label %bb64
bb86:
  call void @__olang_scope_close(ptr %s8)
  br label %bb441
bb87:
  %t358 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t360 = trunc i64 18 to i32
  %t361 = icmp eq i32 %t358, %t360
  br i1 %t361, label %bb88, label %bb89
bb88:
  br label %bb90
bb89:
  br label %bb104
bb90:
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t365 = getelementptr %"compiler/check:Checker", ptr %t363, i32 0, i32 5
  %t366 = load i1, ptr %t365, !tbaa !21
  br i1 %t366, label %bb91, label %bb92
bb91:
  store %olang.scope zeroinitializer, ptr %s19
  %t368 = load ptr, ptr %l1, !tbaa !29
  store ptr %t368, ptr %l231, !tbaa !29
  %t369 = load ptr, ptr %l0, !tbaa !29
  store ptr %t369, ptr %l232, !tbaa !29
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t372 = getelementptr %"compiler/check:Checker", ptr %t370, i32 0, i32 1
  %t373 = load ptr, ptr %t372, !tbaa !29
  %t375 = getelementptr %"compiler/generic:Program", ptr %t373, i32 0, i32 2
  store ptr %t375, ptr %l235, !tbaa !29
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t378 = getelementptr %"compiler/check:Checker", ptr %t376, i32 0, i32 1
  %t379 = load ptr, ptr %t378, !tbaa !29
  %t381 = getelementptr %"compiler/generic:Program", ptr %t379, i32 0, i32 2
  %t382 = load i32, ptr %l2, !tbaa !23
  %t385 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t381, i32 %t382)
  store i32 %t385, ptr %l240
  br label %bb93
bb92:
  br label %bb97
bb93:
  %t386 = load ptr, ptr %l235, !tbaa !29
  %t387 = load i32, ptr %l240, !tbaa !23
  %t388 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t386, i32 %t387)
  store i64 %t388, ptr %l241
  br label %bb94
bb94:
  %t389 = load ptr, ptr %l232, !tbaa !29
  %t390 = load i64, ptr %l241, !tbaa !24
  %t391 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2equalifierFor(ptr %v0, ptr %s19, ptr %t389, i64 %t390)
  store { i64, ptr } %t391, ptr %l242
  br label %bb95
bb95:
  %t392 = load { i64, ptr }, ptr %l242, !tbaa !27
  %t393 = extractvalue { i64, ptr } %t392, 0
  %t394 = extractvalue { i64, ptr } %t392, 1
  %t395 = mul i64 %t393, 1
  %t396 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t395)
  call void @llvm.memcpy.p0.p0.i64(ptr %t396, ptr %t394, i64 %t395, i1 false)
  %t397 = insertvalue { i64, ptr } undef, i64 %t393, 0
  %t398 = insertvalue { i64, ptr } %t397, ptr %t396, 1
  %t399 = load ptr, ptr %l231, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s19, ptr %t399, { i64, ptr } %t398)
  br label %bb96
bb96:
  call void @__olang_scope_close(ptr %s19)
  br label %bb97
bb97:
  %t401 = load ptr, ptr %l1, !tbaa !29
  store ptr %t401, ptr %l244, !tbaa !29
  %t402 = load ptr, ptr %l0, !tbaa !29
  store ptr %t402, ptr %l245, !tbaa !29
  %t403 = load ptr, ptr %l0, !tbaa !29
  %t405 = getelementptr %"compiler/check:Checker", ptr %t403, i32 0, i32 1
  %t406 = load ptr, ptr %t405, !tbaa !29
  %t408 = getelementptr %"compiler/generic:Program", ptr %t406, i32 0, i32 2
  store ptr %t408, ptr %l248, !tbaa !29
  %t409 = load ptr, ptr %l0, !tbaa !29
  %t411 = getelementptr %"compiler/check:Checker", ptr %t409, i32 0, i32 1
  %t412 = load ptr, ptr %t411, !tbaa !29
  %t414 = getelementptr %"compiler/generic:Program", ptr %t412, i32 0, i32 2
  %t415 = load i32, ptr %l2, !tbaa !23
  %t418 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t414, i32 %t415)
  store i32 %t418, ptr %l253
  br label %bb98
bb98:
  %t419 = load ptr, ptr %l248, !tbaa !29
  %t420 = load i32, ptr %l253, !tbaa !23
  %t421 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t419, i32 %t420)
  store i32 %t421, ptr %l254
  br label %bb99
bb99:
  %t422 = load ptr, ptr %l245, !tbaa !29
  %t423 = load i32, ptr %l254, !tbaa !23
  %t424 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t422, i32 %t423)
  store { i64, ptr } %t424, ptr %l255
  br label %bb100
bb100:
  %t425 = load ptr, ptr %l244, !tbaa !29
  %t426 = load { i64, ptr }, ptr %l255, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %v0, ptr %t425, { i64, ptr } %t426)
  br label %bb101
bb101:
  %t427 = load ptr, ptr %l0, !tbaa !29
  store ptr %t427, ptr %l256, !tbaa !29
  %t428 = load ptr, ptr %l1, !tbaa !29
  store ptr %t428, ptr %l257, !tbaa !29
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t431 = getelementptr %"compiler/check:Checker", ptr %t429, i32 0, i32 1
  %t432 = load ptr, ptr %t431, !tbaa !29
  %t434 = getelementptr %"compiler/generic:Program", ptr %t432, i32 0, i32 2
  %t435 = load i32, ptr %l2, !tbaa !23
  %t438 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t434, i32 %t435)
  store i32 %t438, ptr %l262
  br label %bb102
bb102:
  %t439 = load ptr, ptr %l256, !tbaa !29
  %t440 = load ptr, ptr %l257, !tbaa !29
  %t441 = load i32, ptr %l262, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espellArgs(ptr %v0, ptr %v1, ptr %t439, ptr %t440, i32 %t441)
  br label %bb103
bb103:
  br label %bb441
bb104:
  %t442 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t444 = trunc i64 32 to i32
  %t445 = icmp eq i32 %t442, %t444
  br i1 %t445, label %bb105, label %bb106
bb105:
  br label %bb107
bb106:
  br label %bb146
bb107:
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t449 = getelementptr %"compiler/check:Checker", ptr %t447, i32 0, i32 1
  %t450 = load ptr, ptr %t449, !tbaa !29
  %t452 = getelementptr %"compiler/generic:Program", ptr %t450, i32 0, i32 2
  store ptr %t452, ptr %l267, !tbaa !29
  %t453 = load ptr, ptr %l0, !tbaa !29
  %t455 = getelementptr %"compiler/check:Checker", ptr %t453, i32 0, i32 1
  %t456 = load ptr, ptr %t455, !tbaa !29
  %t458 = getelementptr %"compiler/generic:Program", ptr %t456, i32 0, i32 2
  %t459 = load i32, ptr %l2, !tbaa !23
  %t462 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t458, i32 %t459)
  store i32 %t462, ptr %l272
  br label %bb108
bb108:
  %t463 = load ptr, ptr %l267, !tbaa !29
  %t464 = load i32, ptr %l272, !tbaa !23
  %t465 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t463, i32 %t464)
  store { i64, ptr } %t465, ptr %l273
  br label %bb109
bb109:
  %t466 = load { i64, ptr }, ptr %l273, !tbaa !27
  store { i64, ptr } %t466, ptr %l16, !tbaa !27
  %t467 = load ptr, ptr %l0, !tbaa !29
  %t469 = getelementptr %"compiler/check:Checker", ptr %t467, i32 0, i32 1
  %t470 = load ptr, ptr %t469, !tbaa !29
  %t472 = getelementptr %"compiler/generic:Program", ptr %t470, i32 0, i32 2
  %t473 = load i32, ptr %l2, !tbaa !23
  %t476 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValName(ptr %v0, ptr %t472, i32 %t473)
  store i32 %t476, ptr %l278
  br label %bb110
bb110:
  %t477 = load i32, ptr %l278, !tbaa !23
  store i32 %t477, ptr %l17, !tbaa !23
  %t478 = load i32, ptr %l17, !tbaa !23
  %t480 = icmp sge i32 %t478, 0
  br i1 %t480, label %bb111, label %bb112
bb111:
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t484 = getelementptr %"compiler/check:Checker", ptr %t482, i32 0, i32 5
  %t485 = load i1, ptr %t484, !tbaa !21
  br i1 %t485, label %bb113, label %bb114
bb112:
  %t487 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t489 = extractvalue { i64, ptr } %t487, 0
  %t491 = icmp eq i64 %t489, 1
  br i1 %t491, label %bb122, label %bb123
bb113:
  store %olang.scope zeroinitializer, ptr %s22
  %t493 = load ptr, ptr %l1, !tbaa !29
  store ptr %t493, ptr %l283, !tbaa !29
  %t494 = load ptr, ptr %l0, !tbaa !29
  store ptr %t494, ptr %l284, !tbaa !29
  %t495 = load ptr, ptr %l0, !tbaa !29
  %t497 = getelementptr %"compiler/check:Checker", ptr %t495, i32 0, i32 1
  %t498 = load ptr, ptr %t497, !tbaa !29
  %t500 = getelementptr %"compiler/generic:Program", ptr %t498, i32 0, i32 2
  %t501 = load i32, ptr %l17, !tbaa !23
  %t504 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t500, i32 %t501)
  store i64 %t504, ptr %l289
  br label %bb115
bb114:
  br label %bb118
bb115:
  %t505 = load ptr, ptr %l284, !tbaa !29
  %t506 = load i64, ptr %l289, !tbaa !24
  %t507 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2equalifierFor(ptr %v0, ptr %s22, ptr %t505, i64 %t506)
  store { i64, ptr } %t507, ptr %l290
  br label %bb116
bb116:
  %t508 = load { i64, ptr }, ptr %l290, !tbaa !27
  %t509 = extractvalue { i64, ptr } %t508, 0
  %t510 = extractvalue { i64, ptr } %t508, 1
  %t511 = mul i64 %t509, 1
  %t512 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t511)
  call void @llvm.memcpy.p0.p0.i64(ptr %t512, ptr %t510, i64 %t511, i1 false)
  %t513 = insertvalue { i64, ptr } undef, i64 %t509, 0
  %t514 = insertvalue { i64, ptr } %t513, ptr %t512, 1
  %t515 = load ptr, ptr %l283, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s22, ptr %t515, { i64, ptr } %t514)
  br label %bb117
bb117:
  call void @__olang_scope_close(ptr %s22)
  br label %bb118
bb118:
  %t517 = load ptr, ptr %l1, !tbaa !29
  store ptr %t517, ptr %l292, !tbaa !29
  %t518 = load ptr, ptr %l0, !tbaa !29
  store ptr %t518, ptr %l293, !tbaa !29
  %t519 = load ptr, ptr %l0, !tbaa !29
  %t521 = getelementptr %"compiler/check:Checker", ptr %t519, i32 0, i32 1
  %t522 = load ptr, ptr %t521, !tbaa !29
  %t524 = getelementptr %"compiler/generic:Program", ptr %t522, i32 0, i32 2
  %t525 = load i32, ptr %l17, !tbaa !23
  %t528 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t524, i32 %t525)
  store i32 %t528, ptr %l298
  br label %bb119
bb119:
  %t529 = load ptr, ptr %l293, !tbaa !29
  %t530 = load i32, ptr %l298, !tbaa !23
  %t531 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t529, i32 %t530)
  store { i64, ptr } %t531, ptr %l299
  br label %bb120
bb120:
  %t532 = load ptr, ptr %l292, !tbaa !29
  %t533 = load { i64, ptr }, ptr %l299, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %v0, ptr %t532, { i64, ptr } %t533)
  br label %bb121
bb121:
  br label %bb145
bb122:
  %t534 = load ptr, ptr %l0, !tbaa !29
  %t535 = load ptr, ptr %l1, !tbaa !29
  %t536 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t536, ptr %l305, !tbaa !27
  %t537 = getelementptr { i64, ptr }, ptr %l305, i32 0, i32 1
  %t538 = load ptr, ptr %t537, !tbaa !27
  %t539 = getelementptr i32, ptr %t538, i64 0
  %t540 = load i32, ptr %t539, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %v1, ptr %t534, ptr %t535, i32 %t540, i1 false)
  br label %bb124
bb123:
  %t544 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t544, i8 123)
  br label %bb125
bb124:
  br label %bb144
bb125:
  store i64 0, ptr %l18, !tbaa !24
  %t546 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t548 = extractvalue { i64, ptr } %t546, 0
  store i64 %t548, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t550 = load i64, ptr %l19, !tbaa !24
  %t551 = load i64, ptr %l18, !tbaa !24
  %t554 = icmp sgt i64 %t550, %t551
  br i1 %t554, label %bb126, label %bb127
bb126:
  %t556 = load i64, ptr %l20, !tbaa !24
  %t558 = icmp sgt i64 %t556, 0
  br i1 %t558, label %bb128, label %bb129
bb127:
  store i64 0, ptr %l313, !tbaa !24
  br label %bb131
bb128:
  %t560 = load i64, ptr %l19, !tbaa !24
  %t561 = load i64, ptr %l18, !tbaa !24
  %t564 = sub i64 %t560, %t561
  %t565 = load i64, ptr %l20, !tbaa !24
  %t568 = add i64 %t564, %t565
  %t570 = sub i64 %t568, 1
  %t571 = load i64, ptr %l20, !tbaa !24
  %t574 = sdiv i64 %t570, %t571
  store i64 %t574, ptr %l316, !tbaa !24
  br label %bb130
bb129:
  store i64 0, ptr %l316, !tbaa !24
  br label %bb130
bb130:
  %t576 = load i64, ptr %l316, !tbaa !24
  store i64 %t576, ptr %l313, !tbaa !24
  br label %bb131
bb131:
  %t577 = load i64, ptr %l313, !tbaa !24
  store i64 %t577, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb132
bb132:
  %t578 = load i64, ptr %l22, !tbaa !24
  %t579 = load i64, ptr %l21, !tbaa !24
  %t582 = icmp slt i64 %t578, %t579
  %t584 = xor i1 %t582, true
  br i1 %t584, label %bb133, label %bb134
bb133:
  br label %bb142
bb134:
  br label %bb135
bb135:
  %t586 = load i64, ptr %l18, !tbaa !24
  %t587 = load i64, ptr %l22, !tbaa !24
  %t588 = load i64, ptr %l20, !tbaa !24
  %t591 = mul i64 %t587, %t588
  %t594 = add i64 %t586, %t591
  store i64 %t594, ptr %l23, !tbaa !24
  %t596 = load i64, ptr %l23, !tbaa !24
  %t598 = icmp sgt i64 %t596, 0
  br i1 %t598, label %bb136, label %bb137
bb136:
  store %olang.scope zeroinitializer, ptr %s28
  %t600 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s28, ptr %t600, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d38, i32 0, i32 1) })
  br label %bb138
bb137:
  br label %bb139
bb138:
  call void @__olang_scope_close(ptr %s28)
  br label %bb139
bb139:
  %t602 = load ptr, ptr %l0, !tbaa !29
  %t603 = load ptr, ptr %l1, !tbaa !29
  %t604 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t604, ptr %l339, !tbaa !27
  %t605 = load i64, ptr %l23, !tbaa !24
  %t607 = getelementptr { i64, ptr }, ptr %l339, i32 0, i32 1
  %t608 = load ptr, ptr %t607, !tbaa !27
  %t609 = getelementptr i32, ptr %t608, i64 %t605
  %t610 = load i32, ptr %t609, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %v1, ptr %t602, ptr %t603, i32 %t610, i1 false)
  br label %bb140
bb140:
  br label %bb141
bb141:
  %t614 = load i64, ptr %l22, !tbaa !24
  %t616 = add i64 %t614, 1
  store i64 %t616, ptr %l22, !tbaa !24
  br label %bb132
bb142:
  %t618 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t618, i8 125)
  br label %bb143
bb143:
  br label %bb144
bb144:
  br label %bb145
bb145:
  br label %bb441
bb146:
  %t620 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t622 = trunc i64 29 to i32
  %t623 = icmp eq i32 %t620, %t622
  br i1 %t623, label %bb147, label %bb148
bb147:
  br label %bb149
bb148:
  br label %bb153
bb149:
  store %olang.scope zeroinitializer, ptr %s30
  %t625 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s30, ptr %t625, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d39, i32 0, i32 1) })
  br label %bb150
bb150:
  %t627 = load ptr, ptr %l0, !tbaa !29
  store ptr %t627, ptr %l348, !tbaa !29
  %t628 = load ptr, ptr %l1, !tbaa !29
  store ptr %t628, ptr %l349, !tbaa !29
  %t629 = load ptr, ptr %l0, !tbaa !29
  %t631 = getelementptr %"compiler/check:Checker", ptr %t629, i32 0, i32 1
  %t632 = load ptr, ptr %t631, !tbaa !29
  %t634 = getelementptr %"compiler/generic:Program", ptr %t632, i32 0, i32 2
  %t635 = load i32, ptr %l2, !tbaa !23
  %t638 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t634, i32 %t635)
  store i32 %t638, ptr %l354
  br label %bb151
bb151:
  %t639 = load ptr, ptr %l348, !tbaa !29
  %t640 = load ptr, ptr %l349, !tbaa !29
  %t641 = load i32, ptr %l354, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %v1, ptr %t639, ptr %t640, i32 %t641, i1 false)
  br label %bb152
bb152:
  call void @__olang_scope_close(ptr %s30)
  br label %bb441
bb153:
  %t642 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t644 = trunc i64 19 to i32
  %t645 = icmp eq i32 %t642, %t644
  br i1 %t645, label %bb154, label %bb155
bb154:
  br label %bb156
bb155:
  br label %bb161
bb156:
  store %olang.scope zeroinitializer, ptr %s31
  %t647 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s31, ptr %t647, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d40, i32 0, i32 1) })
  br label %bb157
bb157:
  %t649 = load ptr, ptr %l0, !tbaa !29
  %t651 = getelementptr %"compiler/check:Checker", ptr %t649, i32 0, i32 4
  %t652 = load i1, ptr %t651, !tbaa !21
  store i1 %t652, ptr %l24, !tbaa !21
  %t654 = load ptr, ptr %l0, !tbaa !29
  %t656 = getelementptr %"compiler/check:Checker", ptr %t654, i32 0, i32 4
  store i1 true, ptr %t656, !tbaa !21
  %t657 = load ptr, ptr %l0, !tbaa !29
  store ptr %t657, ptr %l361, !tbaa !29
  %t658 = load ptr, ptr %l1, !tbaa !29
  store ptr %t658, ptr %l362, !tbaa !29
  %t659 = load ptr, ptr %l0, !tbaa !29
  %t661 = getelementptr %"compiler/check:Checker", ptr %t659, i32 0, i32 1
  %t662 = load ptr, ptr %t661, !tbaa !29
  %t664 = getelementptr %"compiler/generic:Program", ptr %t662, i32 0, i32 2
  %t665 = load i32, ptr %l2, !tbaa !23
  %t668 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t664, i32 %t665)
  store i32 %t668, ptr %l367
  br label %bb158
bb158:
  %t669 = load ptr, ptr %l361, !tbaa !29
  %t670 = load ptr, ptr %l362, !tbaa !29
  %t671 = load i32, ptr %l367, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %v1, ptr %t669, ptr %t670, i32 %t671, i1 false)
  br label %bb159
bb159:
  %t672 = load ptr, ptr %l0, !tbaa !29
  %t673 = load i1, ptr %l24, !tbaa !21
  %t676 = getelementptr %"compiler/check:Checker", ptr %t672, i32 0, i32 4
  store i1 %t673, ptr %t676, !tbaa !21
  %t677 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t677, i8 62)
  br label %bb160
bb160:
  call void @__olang_scope_close(ptr %s31)
  br label %bb441
bb161:
  %t679 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t681 = trunc i64 20 to i32
  %t682 = icmp eq i32 %t679, %t681
  br i1 %t682, label %bb162, label %bb163
bb162:
  br label %bb164
bb163:
  br label %bb186
bb164:
  store %olang.scope zeroinitializer, ptr %s32
  %t684 = load ptr, ptr %l0, !tbaa !29
  %t686 = getelementptr %"compiler/check:Checker", ptr %t684, i32 0, i32 1
  %t687 = load ptr, ptr %t686, !tbaa !29
  %t689 = getelementptr %"compiler/generic:Program", ptr %t687, i32 0, i32 2
  %t690 = load i32, ptr %l2, !tbaa !23
  %t693 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t689, i32 %t690)
  store i64 %t693, ptr %l377
  br label %bb165
bb165:
  %t694 = load i64, ptr %l377, !tbaa !24
  store i64 %t694, ptr %l25, !tbaa !24
  %t695 = load i64, ptr %l25, !tbaa !24
  %t696 = load i64, ptr @G_2ecompiler_2ftypes_2eSpread, !tbaa !24
  %t699 = and i64 %t695, %t696
  %t701 = icmp ne i64 %t699, 0
  br i1 %t701, label %bb166, label %bb167
bb166:
  store %olang.scope zeroinitializer, ptr %s33
  %t703 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s33, ptr %t703, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d41, i32 0, i32 1) })
  br label %bb168
bb167:
  br label %bb172
bb168:
  %t705 = load ptr, ptr %l0, !tbaa !29
  store ptr %t705, ptr %l383, !tbaa !29
  %t706 = load ptr, ptr %l1, !tbaa !29
  store ptr %t706, ptr %l384, !tbaa !29
  %t707 = load ptr, ptr %l0, !tbaa !29
  %t709 = getelementptr %"compiler/check:Checker", ptr %t707, i32 0, i32 1
  %t710 = load ptr, ptr %t709, !tbaa !29
  %t712 = getelementptr %"compiler/generic:Program", ptr %t710, i32 0, i32 2
  store ptr %t712, ptr %l387, !tbaa !29
  %t713 = load ptr, ptr %l0, !tbaa !29
  %t715 = getelementptr %"compiler/check:Checker", ptr %t713, i32 0, i32 1
  %t716 = load ptr, ptr %t715, !tbaa !29
  %t718 = getelementptr %"compiler/generic:Program", ptr %t716, i32 0, i32 2
  %t719 = load i32, ptr %l2, !tbaa !23
  %t722 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t718, i32 %t719)
  store i32 %t722, ptr %l392
  br label %bb169
bb169:
  %t723 = load ptr, ptr %l387, !tbaa !29
  %t724 = load i32, ptr %l392, !tbaa !23
  %t725 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t723, i32 %t724)
  store i32 %t725, ptr %l393
  br label %bb170
bb170:
  %t726 = load ptr, ptr %l383, !tbaa !29
  %t727 = load ptr, ptr %l384, !tbaa !29
  %t728 = load i32, ptr %l393, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %v1, ptr %t726, ptr %t727, i32 %t728, i1 false)
  br label %bb171
bb171:
  call void @__olang_scope_close(ptr %s33)
  call void @__olang_scope_close(ptr %s32)
  br label %ret
bb172:
  %t731 = xor i1 %a3, true
  br i1 %t731, label %bb173, label %bb174
bb173:
  %t733 = load i64, ptr %l25, !tbaa !24
  %t734 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t737 = and i64 %t733, %t734
  %t739 = icmp ne i64 %t737, 0
  store i1 %t739, ptr %l396, !tbaa !21
  br label %bb175
bb174:
  store i1 false, ptr %l396, !tbaa !21
  br label %bb175
bb175:
  %t741 = load i1, ptr %l396, !tbaa !21
  br i1 %t741, label %bb176, label %bb177
bb176:
  store %olang.scope zeroinitializer, ptr %s34
  %t742 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s34, ptr %t742, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d42, i32 0, i32 1) })
  br label %bb178
bb177:
  br label %bb179
bb178:
  call void @__olang_scope_close(ptr %s34)
  br label %bb179
bb179:
  %t744 = load ptr, ptr %l0, !tbaa !29
  store ptr %t744, ptr %l402, !tbaa !29
  %t745 = load ptr, ptr %l1, !tbaa !29
  store ptr %t745, ptr %l403, !tbaa !29
  %t746 = load ptr, ptr %l0, !tbaa !29
  %t748 = getelementptr %"compiler/check:Checker", ptr %t746, i32 0, i32 1
  %t749 = load ptr, ptr %t748, !tbaa !29
  %t751 = getelementptr %"compiler/generic:Program", ptr %t749, i32 0, i32 2
  %t752 = load i32, ptr %l2, !tbaa !23
  %t755 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t751, i32 %t752)
  store i32 %t755, ptr %l408
  br label %bb180
bb180:
  %t756 = load ptr, ptr %l402, !tbaa !29
  %t757 = load ptr, ptr %l403, !tbaa !29
  %t758 = load i32, ptr %l408, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %v1, ptr %t756, ptr %t757, i32 %t758, i1 false)
  br label %bb181
bb181:
  %t759 = load ptr, ptr %l1, !tbaa !29
  store ptr %t759, ptr %l409, !tbaa !29
  %t760 = load i64, ptr %l25, !tbaa !24
  %t761 = load i64, ptr @G_2ecompiler_2ftypes_2eNullable, !tbaa !24
  %t764 = and i64 %t760, %t761
  %t766 = icmp ne i64 %t764, 0
  br i1 %t766, label %bb182, label %bb183
bb182:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d43, i32 0, i32 1) }, ptr %l414, !tbaa !27
  br label %bb184
bb183:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, ptr %l414, !tbaa !27
  br label %bb184
bb184:
  %t768 = load ptr, ptr %l409, !tbaa !29
  %t769 = load { i64, ptr }, ptr %l414, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s32, ptr %t768, { i64, ptr } %t769)
  br label %bb185
bb185:
  call void @__olang_scope_close(ptr %s32)
  br label %bb441
bb186:
  %t770 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t772 = trunc i64 21 to i32
  %t773 = icmp eq i32 %t770, %t772
  br i1 %t773, label %bb187, label %bb188
bb187:
  br label %bb189
bb188:
  br label %bb323
bb189:
  store %olang.scope zeroinitializer, ptr %s35
  %t775 = load ptr, ptr %l0, !tbaa !29
  %t777 = getelementptr %"compiler/check:Checker", ptr %t775, i32 0, i32 1
  %t778 = load ptr, ptr %t777, !tbaa !29
  %t780 = getelementptr %"compiler/generic:Program", ptr %t778, i32 0, i32 2
  %t781 = load i32, ptr %l2, !tbaa !23
  %t784 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t780, i32 %t781)
  store i32 %t784, ptr %l421
  br label %bb190
bb190:
  %t785 = load i32, ptr %l421, !tbaa !23
  store i32 %t785, ptr %l26, !tbaa !23
  %t786 = load ptr, ptr %l0, !tbaa !29
  %t788 = getelementptr %"compiler/check:Checker", ptr %t786, i32 0, i32 1
  %t789 = load ptr, ptr %t788, !tbaa !29
  %t791 = getelementptr %"compiler/generic:Program", ptr %t789, i32 0, i32 2
  store ptr %t791, ptr %l424, !tbaa !29
  %t792 = load ptr, ptr %l0, !tbaa !29
  %t794 = getelementptr %"compiler/check:Checker", ptr %t792, i32 0, i32 1
  %t795 = load ptr, ptr %t794, !tbaa !29
  %t797 = getelementptr %"compiler/generic:Program", ptr %t795, i32 0, i32 2
  %t798 = load i32, ptr %l2, !tbaa !23
  %t801 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t797, i32 %t798)
  store i32 %t801, ptr %l429
  br label %bb191
bb191:
  %t802 = load ptr, ptr %l424, !tbaa !29
  %t803 = load i32, ptr %l429, !tbaa !23
  %t804 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t802, i32 %t803)
  store { i64, ptr } %t804, ptr %l430
  br label %bb192
bb192:
  %t805 = load { i64, ptr }, ptr %l430, !tbaa !27
  store { i64, ptr } %t805, ptr %l27, !tbaa !27
  store i64 0, ptr %l28, !tbaa !24
  %t806 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t806, ptr %l29, !tbaa !27
  store i64 0, ptr %l30, !tbaa !24
  %t808 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t810 = extractvalue { i64, ptr } %t808, 0
  store i64 %t810, ptr %l31, !tbaa !24
  br label %bb193
bb193:
  %t812 = load i64, ptr %l30, !tbaa !24
  %t813 = load i64, ptr %l31, !tbaa !24
  %t816 = icmp slt i64 %t812, %t813
  %t818 = xor i1 %t816, true
  br i1 %t818, label %bb194, label %bb195
bb194:
  br label %bb201
bb195:
  br label %bb196
bb196:
  %t820 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t820, ptr %l438, !tbaa !27
  %t821 = load i64, ptr %l30, !tbaa !24
  %t823 = getelementptr { i64, ptr }, ptr %l438, i32 0, i32 1
  %t824 = load ptr, ptr %t823, !tbaa !27
  %t825 = getelementptr i32, ptr %t824, i64 %t821
  %t826 = load i32, ptr %t825, !tbaa !33
  %t829 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  %t832 = icmp ne i32 %t826, %t829
  br i1 %t832, label %bb197, label %bb198
bb197:
  %t834 = load i64, ptr %l28, !tbaa !24
  %t836 = add i64 %t834, 1
  store i64 %t836, ptr %l28, !tbaa !24
  br label %bb199
bb198:
  br label %bb199
bb199:
  br label %bb200
bb200:
  %t838 = load i64, ptr %l30, !tbaa !24
  %t840 = add i64 %t838, 1
  store i64 %t840, ptr %l30, !tbaa !24
  br label %bb193
bb201:
  %t842 = load ptr, ptr %l0, !tbaa !29
  %t844 = getelementptr %"compiler/check:Checker", ptr %t842, i32 0, i32 1
  %t845 = load ptr, ptr %t844, !tbaa !29
  %t847 = getelementptr %"compiler/generic:Program", ptr %t845, i32 0, i32 2
  %t848 = load i32, ptr %l26, !tbaa !23
  %t851 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t847, i32 %t848)
  store i32 %t851, ptr %l452
  br label %bb202
bb202:
  %t852 = load i32, ptr %l452, !range !{i32 0, i32 33}
  %t854 = trunc i64 22 to i32
  %t855 = icmp eq i32 %t852, %t854
  br i1 %t855, label %bb203, label %bb204
bb203:
  %t857 = load ptr, ptr %l0, !tbaa !29
  %t859 = getelementptr %"compiler/check:Checker", ptr %t857, i32 0, i32 1
  %t860 = load ptr, ptr %t859, !tbaa !29
  %t862 = getelementptr %"compiler/generic:Program", ptr %t860, i32 0, i32 2
  store ptr %t862, ptr %l458, !tbaa !29
  %t863 = load ptr, ptr %l0, !tbaa !29
  %t865 = getelementptr %"compiler/check:Checker", ptr %t863, i32 0, i32 1
  %t866 = load ptr, ptr %t865, !tbaa !29
  %t868 = getelementptr %"compiler/generic:Program", ptr %t866, i32 0, i32 2
  %t869 = load i32, ptr %l26, !tbaa !23
  %t872 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t868, i32 %t869)
  store i32 %t872, ptr %l463
  br label %bb205
bb204:
  store i1 false, ptr %l455, !tbaa !21
  br label %bb207
bb205:
  %t873 = load ptr, ptr %l458, !tbaa !29
  %t874 = load i32, ptr %l463, !tbaa !23
  %t875 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s35, ptr %t873, i32 %t874)
  store { i64, ptr } %t875, ptr %l464
  br label %bb206
bb206:
  %t876 = load { i64, ptr }, ptr %l464, !tbaa !27
  %t877 = extractvalue { i64, ptr } %t876, 0
  %t879 = icmp sgt i64 %t877, 1
  store i1 %t879, ptr %l455, !tbaa !21
  br label %bb207
bb207:
  %t881 = load i1, ptr %l455, !tbaa !21
  br i1 %t881, label %bb208, label %bb209
bb208:
  store i1 true, ptr %l467, !tbaa !21
  br label %bb210
bb209:
  %t882 = load i64, ptr %l28, !tbaa !24
  %t884 = icmp sgt i64 %t882, 1
  store i1 %t884, ptr %l467, !tbaa !21
  br label %bb210
bb210:
  %t886 = load i1, ptr %l467, !tbaa !21
  store i1 %t886, ptr %l33, !tbaa !21
  %t887 = load ptr, ptr %l0, !tbaa !29
  %t889 = getelementptr %"compiler/check:Checker", ptr %t887, i32 0, i32 8
  %t890 = load i1, ptr %t889, !tbaa !21
  br i1 %t890, label %bb211, label %bb212
bb211:
  store i1 true, ptr %l472, !tbaa !21
  br label %bb216
bb212:
  %t892 = load ptr, ptr %l0, !tbaa !29
  %t894 = getelementptr %"compiler/check:Checker", ptr %t892, i32 0, i32 4
  %t895 = load i1, ptr %t894, !tbaa !21
  br i1 %t895, label %bb213, label %bb214
bb213:
  %t897 = load i1, ptr %l33, !tbaa !21
  store i1 %t897, ptr %l475, !tbaa !21
  br label %bb215
bb214:
  store i1 false, ptr %l475, !tbaa !21
  br label %bb215
bb215:
  %t899 = load i1, ptr %l475, !tbaa !21
  store i1 %t899, ptr %l472, !tbaa !21
  br label %bb216
bb216:
  %t900 = load i1, ptr %l472, !tbaa !21
  store i1 %t900, ptr %l34, !tbaa !21
  %t901 = load ptr, ptr %l0, !tbaa !29
  %t903 = getelementptr %"compiler/check:Checker", ptr %t901, i32 0, i32 8
  store i1 false, ptr %t903, !tbaa !21
  %t904 = load ptr, ptr %l0, !tbaa !29
  %t906 = getelementptr %"compiler/check:Checker", ptr %t904, i32 0, i32 4
  %t907 = load i1, ptr %t906, !tbaa !21
  store i1 %t907, ptr %l35, !tbaa !21
  %t909 = load ptr, ptr %l0, !tbaa !29
  %t911 = getelementptr %"compiler/check:Checker", ptr %t909, i32 0, i32 4
  store i1 true, ptr %t911, !tbaa !21
  %t912 = load ptr, ptr %l0, !tbaa !29
  %t914 = getelementptr %"compiler/check:Checker", ptr %t912, i32 0, i32 1
  %t915 = load ptr, ptr %t914, !tbaa !29
  %t917 = getelementptr %"compiler/generic:Program", ptr %t915, i32 0, i32 2
  %t918 = load i32, ptr %l2, !tbaa !23
  %t921 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFuncTag(ptr %v0, ptr %t917, i32 %t918)
  store i32 %t921, ptr %l485
  br label %bb217
bb217:
  %t922 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t923 = load i32, ptr %l485, !tbaa !23
  %t925 = icmp ne i32 %t923, %t922
  br i1 %t925, label %bb218, label %bb219
bb218:
  store %olang.scope zeroinitializer, ptr %s40
  %t927 = load ptr, ptr %l0, !tbaa !29
  store ptr %t927, ptr %l488, !tbaa !29
  %t928 = load ptr, ptr %l1, !tbaa !29
  store ptr %t928, ptr %l489, !tbaa !29
  %t929 = load ptr, ptr %l0, !tbaa !29
  %t931 = getelementptr %"compiler/check:Checker", ptr %t929, i32 0, i32 1
  %t932 = load ptr, ptr %t931, !tbaa !29
  %t934 = getelementptr %"compiler/generic:Program", ptr %t932, i32 0, i32 2
  %t935 = load i32, ptr %l2, !tbaa !23
  %t938 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFuncTag(ptr %v0, ptr %t934, i32 %t935)
  store i32 %t938, ptr %l494
  br label %bb220
bb219:
  br label %bb227
bb220:
  %t939 = load ptr, ptr %l488, !tbaa !29
  %t940 = load ptr, ptr %l489, !tbaa !29
  %t941 = load i32, ptr %l494, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %v1, ptr %t939, ptr %t940, i32 %t941, i1 false)
  br label %bb221
bb221:
  %t942 = load ptr, ptr %l1, !tbaa !29
  store ptr %t942, ptr %l495, !tbaa !29
  %t943 = load ptr, ptr %l0, !tbaa !29
  %t945 = getelementptr %"compiler/check:Checker", ptr %t943, i32 0, i32 1
  %t946 = load ptr, ptr %t945, !tbaa !29
  %t948 = getelementptr %"compiler/generic:Program", ptr %t946, i32 0, i32 2
  %t949 = load i32, ptr %l2, !tbaa !23
  %t952 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFuncNullable(ptr %v0, ptr %t948, i32 %t949)
  store i1 %t952, ptr %l500
  br label %bb222
bb222:
  %t953 = load i1, ptr %l500, !tbaa !21
  br i1 %t953, label %bb223, label %bb224
bb223:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d45, i32 0, i32 1) }, ptr %l501, !tbaa !27
  br label %bb225
bb224:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, ptr %l501, !tbaa !27
  br label %bb225
bb225:
  %t954 = load ptr, ptr %l495, !tbaa !29
  %t955 = load { i64, ptr }, ptr %l501, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s40, ptr %t954, { i64, ptr } %t955)
  br label %bb226
bb226:
  %t956 = load ptr, ptr %l0, !tbaa !29
  %t958 = getelementptr %"compiler/check:Checker", ptr %t956, i32 0, i32 8
  store i1 false, ptr %t958, !tbaa !21
  %t959 = load ptr, ptr %l0, !tbaa !29
  %t960 = load i1, ptr %l35, !tbaa !21
  %t963 = getelementptr %"compiler/check:Checker", ptr %t959, i32 0, i32 4
  store i1 %t960, ptr %t963, !tbaa !21
  call void @__olang_scope_close(ptr %s40)
  call void @__olang_scope_close(ptr %s35)
  br label %ret
bb227:
  %t964 = load i1, ptr %l34, !tbaa !21
  br i1 %t964, label %bb228, label %bb229
bb228:
  %t966 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t966, i8 40)
  br label %bb230
bb229:
  br label %bb231
bb230:
  br label %bb231
bb231:
  %t968 = load ptr, ptr %l1, !tbaa !29
  store ptr %t968, ptr %l507, !tbaa !29
  %t969 = load ptr, ptr %l0, !tbaa !29
  %t971 = getelementptr %"compiler/check:Checker", ptr %t969, i32 0, i32 1
  %t972 = load ptr, ptr %t971, !tbaa !29
  %t974 = getelementptr %"compiler/generic:Program", ptr %t972, i32 0, i32 2
  %t975 = load i32, ptr %l2, !tbaa !23
  %t978 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFuncNullable(ptr %v0, ptr %t974, i32 %t975)
  store i1 %t978, ptr %l512
  br label %bb232
bb232:
  %t979 = load i1, ptr %l512, !tbaa !21
  br i1 %t979, label %bb233, label %bb234
bb233:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d47, i32 0, i32 1) }, ptr %l513, !tbaa !27
  br label %bb235
bb234:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %l513, !tbaa !27
  br label %bb235
bb235:
  %t980 = load ptr, ptr %l507, !tbaa !29
  %t981 = load { i64, ptr }, ptr %l513, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s35, ptr %t980, { i64, ptr } %t981)
  br label %bb236
bb236:
  %t982 = load ptr, ptr %l0, !tbaa !29
  %t984 = getelementptr %"compiler/check:Checker", ptr %t982, i32 0, i32 1
  %t985 = load ptr, ptr %t984, !tbaa !29
  %t987 = getelementptr %"compiler/generic:Program", ptr %t985, i32 0, i32 2
  store ptr %t987, ptr %l516, !tbaa !29
  %t988 = load ptr, ptr %l0, !tbaa !29
  %t990 = getelementptr %"compiler/check:Checker", ptr %t988, i32 0, i32 1
  %t991 = load ptr, ptr %t990, !tbaa !29
  %t993 = getelementptr %"compiler/generic:Program", ptr %t991, i32 0, i32 2
  %t994 = load i32, ptr %l2, !tbaa !23
  %t997 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t993, i32 %t994)
  store i32 %t997, ptr %l521
  br label %bb237
bb237:
  %t998 = load ptr, ptr %l516, !tbaa !29
  %t999 = load i32, ptr %l521, !tbaa !23
  %t1000 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t998, i32 %t999)
  store { i64, ptr } %t1000, ptr %l522
  br label %bb238
bb238:
  %t1001 = load { i64, ptr }, ptr %l522, !tbaa !27
  store { i64, ptr } %t1001, ptr %l36, !tbaa !27
  %t1002 = load ptr, ptr %l0, !tbaa !29
  %t1004 = getelementptr %"compiler/check:Checker", ptr %t1002, i32 0, i32 1
  %t1005 = load ptr, ptr %t1004, !tbaa !29
  %t1007 = getelementptr %"compiler/generic:Program", ptr %t1005, i32 0, i32 2
  %t1008 = load i32, ptr %l2, !tbaa !23
  %t1011 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesOf(ptr %v0, ptr %v0, ptr %t1007, i32 %t1008)
  store { i64, ptr } %t1011, ptr %l527
  br label %bb239
bb239:
  %t1012 = load { i64, ptr }, ptr %l527, !tbaa !27
  store { i64, ptr } %t1012, ptr %l37, !tbaa !27
  store i64 0, ptr %l38, !tbaa !24
  %t1013 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t1015 = extractvalue { i64, ptr } %t1013, 0
  store i64 %t1015, ptr %l39, !tbaa !24
  store i64 1, ptr %l40, !tbaa !24
  %t1017 = load i64, ptr %l39, !tbaa !24
  %t1018 = load i64, ptr %l38, !tbaa !24
  %t1021 = icmp sgt i64 %t1017, %t1018
  br i1 %t1021, label %bb240, label %bb241
bb240:
  %t1023 = load i64, ptr %l40, !tbaa !24
  %t1025 = icmp sgt i64 %t1023, 0
  br i1 %t1025, label %bb242, label %bb243
bb241:
  store i64 0, ptr %l533, !tbaa !24
  br label %bb245
bb242:
  %t1027 = load i64, ptr %l39, !tbaa !24
  %t1028 = load i64, ptr %l38, !tbaa !24
  %t1031 = sub i64 %t1027, %t1028
  %t1032 = load i64, ptr %l40, !tbaa !24
  %t1035 = add i64 %t1031, %t1032
  %t1037 = sub i64 %t1035, 1
  %t1038 = load i64, ptr %l40, !tbaa !24
  %t1041 = sdiv i64 %t1037, %t1038
  store i64 %t1041, ptr %l536, !tbaa !24
  br label %bb244
bb243:
  store i64 0, ptr %l536, !tbaa !24
  br label %bb244
bb244:
  %t1043 = load i64, ptr %l536, !tbaa !24
  store i64 %t1043, ptr %l533, !tbaa !24
  br label %bb245
bb245:
  %t1044 = load i64, ptr %l533, !tbaa !24
  store i64 %t1044, ptr %l41, !tbaa !24
  store i64 0, ptr %l42, !tbaa !24
  br label %bb246
bb246:
  %t1045 = load i64, ptr %l42, !tbaa !24
  %t1046 = load i64, ptr %l41, !tbaa !24
  %t1049 = icmp slt i64 %t1045, %t1046
  %t1051 = xor i1 %t1049, true
  br i1 %t1051, label %bb247, label %bb248
bb247:
  br label %bb262
bb248:
  br label %bb249
bb249:
  %t1053 = load i64, ptr %l38, !tbaa !24
  %t1054 = load i64, ptr %l42, !tbaa !24
  %t1055 = load i64, ptr %l40, !tbaa !24
  %t1058 = mul i64 %t1054, %t1055
  %t1061 = add i64 %t1053, %t1058
  store i64 %t1061, ptr %l43, !tbaa !24
  %t1063 = load i64, ptr %l43, !tbaa !24
  %t1065 = icmp sgt i64 %t1063, 0
  br i1 %t1065, label %bb250, label %bb251
bb250:
  store %olang.scope zeroinitializer, ptr %s44
  %t1067 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s44, ptr %t1067, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d49, i32 0, i32 1) })
  br label %bb252
bb251:
  br label %bb253
bb252:
  call void @__olang_scope_close(ptr %s44)
  br label %bb253
bb253:
  %t1069 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t1071 = extractvalue { i64, ptr } %t1069, 0
  %t1072 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t1074 = extractvalue { i64, ptr } %t1072, 0
  %t1077 = icmp eq i64 %t1071, %t1074
  br i1 %t1077, label %bb254, label %bb255
bb254:
  %t1079 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1079, ptr %l562, !tbaa !29
  %t1080 = load ptr, ptr %l0, !tbaa !29
  %t1081 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t1081, ptr %l564, !tbaa !27
  %t1082 = load i64, ptr %l43, !tbaa !24
  %t1084 = getelementptr { i64, ptr }, ptr %l564, i32 0, i32 1
  %t1085 = load ptr, ptr %t1084, !tbaa !27
  %t1086 = getelementptr i64, ptr %t1085, i64 %t1082
  %t1087 = load i64, ptr %t1086, !tbaa !34
  %t1089 = trunc i64 %t1087 to i32
  %t1093 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t1080, i32 %t1089)
  store { i64, ptr } %t1093, ptr %l569
  br label %bb256
bb255:
  br label %bb259
bb256:
  %t1094 = load ptr, ptr %l562, !tbaa !29
  %t1095 = load { i64, ptr }, ptr %l569, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %v0, ptr %t1094, { i64, ptr } %t1095)
  br label %bb257
bb257:
  %t1096 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t1096, i8 32)
  br label %bb258
bb258:
  br label %bb259
bb259:
  %t1098 = load ptr, ptr %l0, !tbaa !29
  %t1099 = load ptr, ptr %l1, !tbaa !29
  %t1100 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t1100, ptr %l573, !tbaa !27
  %t1101 = load i64, ptr %l43, !tbaa !24
  %t1103 = getelementptr { i64, ptr }, ptr %l573, i32 0, i32 1
  %t1104 = load ptr, ptr %t1103, !tbaa !27
  %t1105 = getelementptr i32, ptr %t1104, i64 %t1101
  %t1106 = load i32, ptr %t1105, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %v1, ptr %t1098, ptr %t1099, i32 %t1106, i1 false)
  br label %bb260
bb260:
  br label %bb261
bb261:
  %t1110 = load i64, ptr %l42, !tbaa !24
  %t1112 = add i64 %t1110, 1
  store i64 %t1112, ptr %l42, !tbaa !24
  br label %bb246
bb262:
  %t1114 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t1114, i8 41)
  br label %bb263
bb263:
  %t1116 = load ptr, ptr %l0, !tbaa !29
  %t1118 = getelementptr %"compiler/check:Checker", ptr %t1116, i32 0, i32 1
  %t1119 = load ptr, ptr %t1118, !tbaa !29
  %t1121 = getelementptr %"compiler/generic:Program", ptr %t1119, i32 0, i32 2
  %t1122 = load i32, ptr %l26, !tbaa !23
  %t1125 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1121, i32 %t1122)
  store i32 %t1125, ptr %l583
  br label %bb264
bb264:
  %t1126 = load i32, ptr %l583, !range !{i32 0, i32 33}
  %t1128 = trunc i64 22 to i32
  %t1129 = icmp eq i32 %t1126, %t1128
  br i1 %t1129, label %bb265, label %bb266
bb265:
  %t1131 = load ptr, ptr %l0, !tbaa !29
  %t1133 = getelementptr %"compiler/check:Checker", ptr %t1131, i32 0, i32 1
  %t1134 = load ptr, ptr %t1133, !tbaa !29
  %t1136 = getelementptr %"compiler/generic:Program", ptr %t1134, i32 0, i32 2
  store ptr %t1136, ptr %l588, !tbaa !29
  %t1137 = load ptr, ptr %l0, !tbaa !29
  %t1139 = getelementptr %"compiler/check:Checker", ptr %t1137, i32 0, i32 1
  %t1140 = load ptr, ptr %t1139, !tbaa !29
  %t1142 = getelementptr %"compiler/generic:Program", ptr %t1140, i32 0, i32 2
  %t1143 = load i32, ptr %l26, !tbaa !23
  %t1146 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t1142, i32 %t1143)
  store i32 %t1146, ptr %l593
  br label %bb267
bb266:
  %t1147 = load i32, ptr %l26, !tbaa !23
  %t1148 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t1151 = icmp ne i32 %t1147, %t1148
  br i1 %t1151, label %bb286, label %bb287
bb267:
  %t1153 = load ptr, ptr %l588, !tbaa !29
  %t1154 = load i32, ptr %l593, !tbaa !23
  %t1155 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t1153, i32 %t1154)
  store { i64, ptr } %t1155, ptr %l594
  br label %bb268
bb268:
  %t1156 = load { i64, ptr }, ptr %l594, !tbaa !27
  store { i64, ptr } %t1156, ptr %l44, !tbaa !27
  store i64 0, ptr %l45, !tbaa !24
  %t1157 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t1159 = extractvalue { i64, ptr } %t1157, 0
  store i64 %t1159, ptr %l46, !tbaa !24
  store i64 1, ptr %l47, !tbaa !24
  %t1161 = load i64, ptr %l46, !tbaa !24
  %t1162 = load i64, ptr %l45, !tbaa !24
  %t1165 = icmp sgt i64 %t1161, %t1162
  br i1 %t1165, label %bb269, label %bb270
bb269:
  %t1167 = load i64, ptr %l47, !tbaa !24
  %t1169 = icmp sgt i64 %t1167, 0
  br i1 %t1169, label %bb271, label %bb272
bb270:
  store i64 0, ptr %l600, !tbaa !24
  br label %bb274
bb271:
  %t1171 = load i64, ptr %l46, !tbaa !24
  %t1172 = load i64, ptr %l45, !tbaa !24
  %t1175 = sub i64 %t1171, %t1172
  %t1176 = load i64, ptr %l47, !tbaa !24
  %t1179 = add i64 %t1175, %t1176
  %t1181 = sub i64 %t1179, 1
  %t1182 = load i64, ptr %l47, !tbaa !24
  %t1185 = sdiv i64 %t1181, %t1182
  store i64 %t1185, ptr %l603, !tbaa !24
  br label %bb273
bb272:
  store i64 0, ptr %l603, !tbaa !24
  br label %bb273
bb273:
  %t1187 = load i64, ptr %l603, !tbaa !24
  store i64 %t1187, ptr %l600, !tbaa !24
  br label %bb274
bb274:
  %t1188 = load i64, ptr %l600, !tbaa !24
  store i64 %t1188, ptr %l48, !tbaa !24
  store i64 0, ptr %l49, !tbaa !24
  br label %bb275
bb275:
  store %olang.scope zeroinitializer, ptr %s49
  %t1189 = load i64, ptr %l49, !tbaa !24
  %t1190 = load i64, ptr %l48, !tbaa !24
  %t1193 = icmp slt i64 %t1189, %t1190
  %t1195 = xor i1 %t1193, true
  br i1 %t1195, label %bb276, label %bb277
bb276:
  call void @__olang_scope_close(ptr %s49)
  br label %bb285
bb277:
  br label %bb278
bb278:
  %t1197 = load i64, ptr %l45, !tbaa !24
  %t1198 = load i64, ptr %l49, !tbaa !24
  %t1199 = load i64, ptr %l47, !tbaa !24
  %t1202 = mul i64 %t1198, %t1199
  %t1205 = add i64 %t1197, %t1202
  store i64 %t1205, ptr %l50, !tbaa !24
  %t1207 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1207, ptr %l621, !tbaa !29
  %t1208 = load i64, ptr %l50, !tbaa !24
  %t1210 = icmp sgt i64 %t1208, 0
  br i1 %t1210, label %bb279, label %bb280
bb279:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d50, i32 0, i32 1) }, ptr %l624, !tbaa !27
  br label %bb281
bb280:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, ptr %l624, !tbaa !27
  br label %bb281
bb281:
  %t1212 = load ptr, ptr %l621, !tbaa !29
  %t1213 = load { i64, ptr }, ptr %l624, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s49, ptr %t1212, { i64, ptr } %t1213)
  br label %bb282
bb282:
  %t1214 = load ptr, ptr %l0, !tbaa !29
  %t1215 = load ptr, ptr %l1, !tbaa !29
  %t1216 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t1216, ptr %l627, !tbaa !27
  %t1217 = load i64, ptr %l50, !tbaa !24
  %t1219 = getelementptr { i64, ptr }, ptr %l627, i32 0, i32 1
  %t1220 = load ptr, ptr %t1219, !tbaa !27
  %t1221 = getelementptr i32, ptr %t1220, i64 %t1217
  %t1222 = load i32, ptr %t1221, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %v1, ptr %t1214, ptr %t1215, i32 %t1222, i1 false)
  br label %bb283
bb283:
  call void @__olang_scope_close(ptr %s49)
  br label %bb284
bb284:
  %t1226 = load i64, ptr %l49, !tbaa !24
  %t1228 = add i64 %t1226, 1
  store i64 %t1228, ptr %l49, !tbaa !24
  br label %bb275
bb285:
  br label %bb300
bb286:
  store %olang.scope zeroinitializer, ptr %s52
  %t1230 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t1230, i8 32)
  br label %bb288
bb287:
  br label %bb299
bb288:
  %t1232 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1232, ptr %l636, !tbaa !29
  %t1233 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t1235 = extractvalue { i64, ptr } %t1233, 0
  %t1237 = icmp sgt i64 %t1235, 0
  br i1 %t1237, label %bb289, label %bb290
bb289:
  %t1239 = load ptr, ptr %l0, !tbaa !29
  %t1241 = getelementptr %"compiler/check:Checker", ptr %t1239, i32 0, i32 1
  %t1242 = load ptr, ptr %t1241, !tbaa !29
  %t1244 = getelementptr %"compiler/generic:Program", ptr %t1242, i32 0, i32 2
  %t1245 = load i32, ptr %l26, !tbaa !23
  %t1248 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1244, i32 %t1245)
  store i32 %t1248, ptr %l645
  br label %bb291
bb290:
  store i1 false, ptr %l640, !tbaa !21
  br label %bb292
bb291:
  %t1249 = load i32, ptr %l645, !range !{i32 0, i32 33}
  %t1251 = trunc i64 21 to i32
  %t1252 = icmp eq i32 %t1249, %t1251
  store i1 %t1252, ptr %l640, !tbaa !21
  br label %bb292
bb292:
  %t1254 = load i1, ptr %l640, !tbaa !21
  br i1 %t1254, label %bb293, label %bb294
bb293:
  %t1255 = load ptr, ptr %l0, !tbaa !29
  %t1257 = getelementptr %"compiler/check:Checker", ptr %t1255, i32 0, i32 1
  %t1258 = load ptr, ptr %t1257, !tbaa !29
  %t1260 = getelementptr %"compiler/generic:Program", ptr %t1258, i32 0, i32 2
  store ptr %t1260, ptr %l651, !tbaa !29
  %t1261 = load ptr, ptr %l0, !tbaa !29
  %t1263 = getelementptr %"compiler/check:Checker", ptr %t1261, i32 0, i32 1
  %t1264 = load ptr, ptr %t1263, !tbaa !29
  %t1266 = getelementptr %"compiler/generic:Program", ptr %t1264, i32 0, i32 2
  %t1267 = load i32, ptr %l26, !tbaa !23
  %t1270 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t1266, i32 %t1267)
  store i32 %t1270, ptr %l656
  br label %bb295
bb294:
  store i1 false, ptr %l648, !tbaa !21
  br label %bb297
bb295:
  %t1271 = load ptr, ptr %l651, !tbaa !29
  %t1272 = load i32, ptr %l656, !tbaa !23
  %t1273 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s52, ptr %t1271, i32 %t1272)
  store { i64, ptr } %t1273, ptr %l657
  br label %bb296
bb296:
  %t1274 = load { i64, ptr }, ptr %l657, !tbaa !27
  %t1275 = extractvalue { i64, ptr } %t1274, 0
  %t1277 = icmp eq i64 %t1275, 0
  store i1 %t1277, ptr %l648, !tbaa !21
  br label %bb297
bb297:
  %t1279 = load i1, ptr %l648, !tbaa !21
  %t1280 = load ptr, ptr %l636, !tbaa !29
  %t1281 = getelementptr %"compiler/check:Checker", ptr %t1280, i32 0, i32 8
  store i1 %t1279, ptr %t1281, !tbaa !21
  %t1282 = load ptr, ptr %l0, !tbaa !29
  %t1283 = load ptr, ptr %l1, !tbaa !29
  %t1284 = load i32, ptr %l26, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %v1, ptr %t1282, ptr %t1283, i32 %t1284, i1 false)
  br label %bb298
bb298:
  %t1288 = load ptr, ptr %l0, !tbaa !29
  %t1290 = getelementptr %"compiler/check:Checker", ptr %t1288, i32 0, i32 8
  store i1 false, ptr %t1290, !tbaa !21
  call void @__olang_scope_close(ptr %s52)
  br label %bb299
bb299:
  br label %bb300
bb300:
  %t1291 = load ptr, ptr %l0, !tbaa !29
  %t1292 = load i1, ptr %l35, !tbaa !21
  %t1295 = getelementptr %"compiler/check:Checker", ptr %t1291, i32 0, i32 4
  store i1 %t1292, ptr %t1295, !tbaa !21
  %t1296 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t1298 = extractvalue { i64, ptr } %t1296, 0
  %t1300 = icmp sgt i64 %t1298, 0
  br i1 %t1300, label %bb301, label %bb302
bb301:
  store %olang.scope zeroinitializer, ptr %s53
  %t1302 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s53, ptr %t1302, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d52, i32 0, i32 1) })
  br label %bb303
bb302:
  br label %bb318
bb303:
  store i64 0, ptr %l51, !tbaa !24
  %t1304 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t1304, ptr %l52, !tbaa !27
  store i64 0, ptr %l53, !tbaa !24
  %t1306 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t1308 = extractvalue { i64, ptr } %t1306, 0
  store i64 %t1308, ptr %l54, !tbaa !24
  br label %bb304
bb304:
  store %olang.scope zeroinitializer, ptr %s55
  %t1310 = load i64, ptr %l53, !tbaa !24
  %t1311 = load i64, ptr %l54, !tbaa !24
  %t1314 = icmp slt i64 %t1310, %t1311
  %t1316 = xor i1 %t1314, true
  br i1 %t1316, label %bb305, label %bb306
bb305:
  call void @__olang_scope_close(ptr %s55)
  br label %bb317
bb306:
  br label %bb307
bb307:
  %t1318 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t1318, ptr %l677, !tbaa !27
  %t1319 = load i64, ptr %l53, !tbaa !24
  %t1321 = getelementptr { i64, ptr }, ptr %l677, i32 0, i32 1
  %t1322 = load ptr, ptr %t1321, !tbaa !27
  %t1323 = getelementptr i32, ptr %t1322, i64 %t1319
  %t1324 = load i32, ptr %t1323, !tbaa !33
  store i32 %t1324, ptr %l55, !tbaa !23
  %t1326 = load i32, ptr %l55, !tbaa !23
  %t1327 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  %t1330 = icmp eq i32 %t1326, %t1327
  br i1 %t1330, label %bb308, label %bb309
bb308:
  call void @__olang_scope_close(ptr %s55)
  br label %bb316
bb309:
  br label %bb310
bb310:
  %t1332 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1332, ptr %l683, !tbaa !29
  %t1333 = load i64, ptr %l51, !tbaa !24
  %t1335 = icmp eq i64 %t1333, 0
  br i1 %t1335, label %bb311, label %bb312
bb311:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d53, i32 0, i32 1) }, ptr %l686, !tbaa !27
  br label %bb313
bb312:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d54, i32 0, i32 1) }, ptr %l686, !tbaa !27
  br label %bb313
bb313:
  %t1337 = load ptr, ptr %l683, !tbaa !29
  %t1338 = load { i64, ptr }, ptr %l686, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s55, ptr %t1337, { i64, ptr } %t1338)
  br label %bb314
bb314:
  %t1339 = load ptr, ptr %l0, !tbaa !29
  %t1340 = load ptr, ptr %l1, !tbaa !29
  %t1341 = load i32, ptr %l55, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %v1, ptr %t1339, ptr %t1340, i32 %t1341, i1 false)
  br label %bb315
bb315:
  %t1345 = load i64, ptr %l51, !tbaa !24
  %t1347 = add i64 %t1345, 1
  store i64 %t1347, ptr %l51, !tbaa !24
  call void @__olang_scope_close(ptr %s55)
  br label %bb316
bb316:
  %t1349 = load i64, ptr %l53, !tbaa !24
  %t1351 = add i64 %t1349, 1
  store i64 %t1351, ptr %l53, !tbaa !24
  br label %bb304
bb317:
  call void @__olang_scope_close(ptr %s53)
  br label %bb318
bb318:
  %t1353 = load i1, ptr %l34, !tbaa !21
  br i1 %t1353, label %bb319, label %bb320
bb319:
  %t1355 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t1355, i8 41)
  br label %bb321
bb320:
  br label %bb322
bb321:
  br label %bb322
bb322:
  call void @__olang_scope_close(ptr %s35)
  br label %bb441
bb323:
  %t1357 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t1359 = trunc i64 22 to i32
  %t1360 = icmp eq i32 %t1357, %t1359
  br i1 %t1360, label %bb324, label %bb325
bb324:
  br label %bb326
bb325:
  br label %bb329
bb326:
  store %olang.scope zeroinitializer, ptr %s59
  %t1362 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1362, ptr %l698, !tbaa !29
  %t1363 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1363, ptr %l699, !tbaa !29
  %t1364 = load ptr, ptr %l0, !tbaa !29
  %t1366 = getelementptr %"compiler/check:Checker", ptr %t1364, i32 0, i32 1
  %t1367 = load ptr, ptr %t1366, !tbaa !29
  %t1369 = getelementptr %"compiler/generic:Program", ptr %t1367, i32 0, i32 2
  %t1370 = load i32, ptr %l2, !tbaa !23
  %t1373 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t1369, i32 %t1370)
  store i32 %t1373, ptr %l704
  br label %bb327
bb327:
  %t1374 = load ptr, ptr %l698, !tbaa !29
  %t1375 = load ptr, ptr %l699, !tbaa !29
  %t1376 = load i32, ptr %l704, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espellList(ptr %v0, ptr %v1, ptr %s59, ptr %s59, ptr %t1374, ptr %t1375, i32 %t1376, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d55, i32 0, i32 1) }, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) })
  br label %bb328
bb328:
  call void @__olang_scope_close(ptr %s59)
  br label %bb441
bb329:
  %t1377 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t1379 = trunc i64 24 to i32
  %t1380 = icmp eq i32 %t1377, %t1379
  br i1 %t1380, label %bb330, label %bb331
bb330:
  br label %bb332
bb331:
  br label %bb392
bb332:
  store %olang.scope zeroinitializer, ptr %s60
  %t1382 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s60, ptr %t1382, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d57, i32 0, i32 1) })
  br label %bb333
bb333:
  %t1384 = load ptr, ptr %l0, !tbaa !29
  %t1386 = getelementptr %"compiler/check:Checker", ptr %t1384, i32 0, i32 1
  %t1387 = load ptr, ptr %t1386, !tbaa !29
  %t1389 = getelementptr %"compiler/generic:Program", ptr %t1387, i32 0, i32 2
  %t1390 = load i32, ptr %l2, !tbaa !23
  %t1393 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeNames(ptr %v0, ptr %v0, ptr %t1389, i32 %t1390)
  store { i64, ptr } %t1393, ptr %l712
  br label %bb334
bb334:
  %t1394 = load { i64, ptr }, ptr %l712, !tbaa !27
  store { i64, ptr } %t1394, ptr %l56, !tbaa !27
  %t1395 = load ptr, ptr %l0, !tbaa !29
  %t1397 = getelementptr %"compiler/check:Checker", ptr %t1395, i32 0, i32 1
  %t1398 = load ptr, ptr %t1397, !tbaa !29
  %t1400 = getelementptr %"compiler/generic:Program", ptr %t1398, i32 0, i32 2
  store ptr %t1400, ptr %l715, !tbaa !29
  %t1401 = load ptr, ptr %l0, !tbaa !29
  %t1403 = getelementptr %"compiler/check:Checker", ptr %t1401, i32 0, i32 1
  %t1404 = load ptr, ptr %t1403, !tbaa !29
  %t1406 = getelementptr %"compiler/generic:Program", ptr %t1404, i32 0, i32 2
  %t1407 = load i32, ptr %l2, !tbaa !23
  %t1410 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t1406, i32 %t1407)
  store i32 %t1410, ptr %l720
  br label %bb335
bb335:
  %t1411 = load ptr, ptr %l715, !tbaa !29
  %t1412 = load i32, ptr %l720, !tbaa !23
  %t1413 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t1411, i32 %t1412)
  store { i64, ptr } %t1413, ptr %l721
  br label %bb336
bb336:
  %t1414 = load { i64, ptr }, ptr %l721, !tbaa !27
  store { i64, ptr } %t1414, ptr %l57, !tbaa !27
  %t1415 = load ptr, ptr %l0, !tbaa !29
  %t1417 = getelementptr %"compiler/check:Checker", ptr %t1415, i32 0, i32 1
  %t1418 = load ptr, ptr %t1417, !tbaa !29
  %t1420 = getelementptr %"compiler/generic:Program", ptr %t1418, i32 0, i32 2
  %t1421 = load i32, ptr %l2, !tbaa !23
  %t1424 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeFields(ptr %v0, ptr %v0, ptr %t1420, i32 %t1421)
  store { i64, ptr } %t1424, ptr %l726
  br label %bb337
bb337:
  %t1425 = load { i64, ptr }, ptr %l726, !tbaa !27
  store { i64, ptr } %t1425, ptr %l58, !tbaa !27
  store i64 0, ptr %l59, !tbaa !24
  store i64 0, ptr %l60, !tbaa !24
  %t1426 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t1428 = extractvalue { i64, ptr } %t1426, 0
  store i64 %t1428, ptr %l61, !tbaa !24
  store i64 1, ptr %l62, !tbaa !24
  %t1430 = load i64, ptr %l61, !tbaa !24
  %t1431 = load i64, ptr %l60, !tbaa !24
  %t1434 = icmp sgt i64 %t1430, %t1431
  br i1 %t1434, label %bb338, label %bb339
bb338:
  %t1436 = load i64, ptr %l62, !tbaa !24
  %t1438 = icmp sgt i64 %t1436, 0
  br i1 %t1438, label %bb340, label %bb341
bb339:
  store i64 0, ptr %l732, !tbaa !24
  br label %bb343
bb340:
  %t1440 = load i64, ptr %l61, !tbaa !24
  %t1441 = load i64, ptr %l60, !tbaa !24
  %t1444 = sub i64 %t1440, %t1441
  %t1445 = load i64, ptr %l62, !tbaa !24
  %t1448 = add i64 %t1444, %t1445
  %t1450 = sub i64 %t1448, 1
  %t1451 = load i64, ptr %l62, !tbaa !24
  %t1454 = sdiv i64 %t1450, %t1451
  store i64 %t1454, ptr %l735, !tbaa !24
  br label %bb342
bb341:
  store i64 0, ptr %l735, !tbaa !24
  br label %bb342
bb342:
  %t1456 = load i64, ptr %l735, !tbaa !24
  store i64 %t1456, ptr %l732, !tbaa !24
  br label %bb343
bb343:
  %t1457 = load i64, ptr %l732, !tbaa !24
  store i64 %t1457, ptr %l63, !tbaa !24
  store i64 0, ptr %l64, !tbaa !24
  br label %bb344
bb344:
  %t1458 = load i64, ptr %l64, !tbaa !24
  %t1459 = load i64, ptr %l63, !tbaa !24
  %t1462 = icmp slt i64 %t1458, %t1459
  %t1464 = xor i1 %t1462, true
  br i1 %t1464, label %bb345, label %bb346
bb345:
  br label %bb390
bb346:
  br label %bb347
bb347:
  %t1466 = load i64, ptr %l60, !tbaa !24
  %t1467 = load i64, ptr %l64, !tbaa !24
  %t1468 = load i64, ptr %l62, !tbaa !24
  %t1471 = mul i64 %t1467, %t1468
  %t1474 = add i64 %t1466, %t1471
  store i64 %t1474, ptr %l65, !tbaa !24
  %t1476 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t1476, i8 32)
  br label %bb348
bb348:
  %t1478 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1478, ptr %l754, !tbaa !29
  %t1479 = load ptr, ptr %l0, !tbaa !29
  %t1480 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t1480, ptr %l756, !tbaa !27
  %t1481 = load i64, ptr %l65, !tbaa !24
  %t1483 = getelementptr { i64, ptr }, ptr %l756, i32 0, i32 1
  %t1484 = load ptr, ptr %t1483, !tbaa !27
  %t1485 = getelementptr i32, ptr %t1484, i64 %t1481
  %t1486 = load i32, ptr %t1485, !tbaa !33
  %t1489 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t1479, i32 %t1486)
  store { i64, ptr } %t1489, ptr %l759
  br label %bb349
bb349:
  %t1490 = load ptr, ptr %l754, !tbaa !29
  %t1491 = load { i64, ptr }, ptr %l759, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %v0, ptr %t1490, { i64, ptr } %t1491)
  br label %bb350
bb350:
  %t1492 = load i64, ptr %l65, !tbaa !24
  %t1493 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t1495 = extractvalue { i64, ptr } %t1493, 0
  %t1498 = icmp sge i64 %t1492, %t1495
  br i1 %t1498, label %bb351, label %bb352
bb351:
  store i1 true, ptr %l764, !tbaa !21
  br label %bb353
bb352:
  %t1500 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t1500, ptr %l765, !tbaa !27
  %t1501 = load i64, ptr %l65, !tbaa !24
  %t1503 = getelementptr { i64, ptr }, ptr %l765, i32 0, i32 1
  %t1504 = load ptr, ptr %t1503, !tbaa !27
  %t1505 = getelementptr i32, ptr %t1504, i64 %t1501
  %t1506 = load i32, ptr %t1505, !tbaa !33
  %t1508 = icmp eq i32 %t1506, 0
  store i1 %t1508, ptr %l764, !tbaa !21
  br label %bb353
bb353:
  %t1510 = load i1, ptr %l764, !tbaa !21
  br i1 %t1510, label %bb354, label %bb355
bb354:
  br label %bb389
bb355:
  br label %bb356
bb356:
  %t1511 = load ptr, ptr %l0, !tbaa !29
  %t1513 = getelementptr %"compiler/check:Checker", ptr %t1511, i32 0, i32 1
  %t1514 = load ptr, ptr %t1513, !tbaa !29
  %t1516 = getelementptr %"compiler/generic:Program", ptr %t1514, i32 0, i32 2
  store ptr %t1516, ptr %l771, !tbaa !29
  %t1517 = load ptr, ptr %l0, !tbaa !29
  %t1519 = getelementptr %"compiler/check:Checker", ptr %t1517, i32 0, i32 1
  %t1520 = load ptr, ptr %t1519, !tbaa !29
  %t1522 = getelementptr %"compiler/generic:Program", ptr %t1520, i32 0, i32 2
  %t1523 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t1523, ptr %l775, !tbaa !27
  %t1524 = load i64, ptr %l65, !tbaa !24
  %t1526 = getelementptr { i64, ptr }, ptr %l775, i32 0, i32 1
  %t1527 = load ptr, ptr %t1526, !tbaa !27
  %t1528 = getelementptr i32, ptr %t1527, i64 %t1524
  %t1529 = load i32, ptr %t1528, !tbaa !33
  %t1532 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t1522, i32 %t1529)
  store i32 %t1532, ptr %l778
  br label %bb357
bb357:
  %t1533 = load ptr, ptr %l771, !tbaa !29
  %t1534 = load i32, ptr %l778, !tbaa !23
  %t1535 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t1533, i32 %t1534)
  store { i64, ptr } %t1535, ptr %l779
  br label %bb358
bb358:
  %t1536 = load { i64, ptr }, ptr %l779, !tbaa !27
  store { i64, ptr } %t1536, ptr %l66, !tbaa !27
  %t1537 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t1539 = extractvalue { i64, ptr } %t1537, 0
  %t1541 = icmp eq i64 %t1539, 0
  br i1 %t1541, label %bb359, label %bb360
bb359:
  br label %bb389
bb360:
  br label %bb361
bb361:
  %t1543 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t1545 = extractvalue { i64, ptr } %t1543, 0
  %t1546 = load i64, ptr %l59, !tbaa !24
  %t1547 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t1549 = extractvalue { i64, ptr } %t1547, 0
  %t1552 = add i64 %t1546, %t1549
  %t1555 = icmp slt i64 %t1545, %t1552
  br i1 %t1555, label %bb362, label %bb363
bb362:
  store %olang.scope zeroinitializer, ptr %s65
  %t1557 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1557, ptr %l790, !tbaa !29
  %t1558 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1558, ptr %l791, !tbaa !29
  %t1559 = load ptr, ptr %l0, !tbaa !29
  %t1561 = getelementptr %"compiler/check:Checker", ptr %t1559, i32 0, i32 1
  %t1562 = load ptr, ptr %t1561, !tbaa !29
  %t1564 = getelementptr %"compiler/generic:Program", ptr %t1562, i32 0, i32 2
  %t1565 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t1565, ptr %l795, !tbaa !27
  %t1566 = load i64, ptr %l65, !tbaa !24
  %t1568 = getelementptr { i64, ptr }, ptr %l795, i32 0, i32 1
  %t1569 = load ptr, ptr %t1568, !tbaa !27
  %t1570 = getelementptr i32, ptr %t1569, i64 %t1566
  %t1571 = load i32, ptr %t1570, !tbaa !33
  %t1574 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t1564, i32 %t1571)
  store i32 %t1574, ptr %l798
  br label %bb364
bb363:
  br label %bb366
bb364:
  %t1575 = load ptr, ptr %l790, !tbaa !29
  %t1576 = load ptr, ptr %l791, !tbaa !29
  %t1577 = load i32, ptr %l798, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espellList(ptr %v0, ptr %v1, ptr %s65, ptr %s65, ptr %t1575, ptr %t1576, i32 %t1577, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) })
  br label %bb365
bb365:
  call void @__olang_scope_close(ptr %s65)
  br label %bb389
bb366:
  %t1578 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t1578, i8 40)
  br label %bb367
bb367:
  store i64 0, ptr %l67, !tbaa !24
  %t1580 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t1582 = extractvalue { i64, ptr } %t1580, 0
  store i64 %t1582, ptr %l68, !tbaa !24
  store i64 1, ptr %l69, !tbaa !24
  %t1584 = load i64, ptr %l68, !tbaa !24
  %t1585 = load i64, ptr %l67, !tbaa !24
  %t1588 = icmp sgt i64 %t1584, %t1585
  br i1 %t1588, label %bb368, label %bb369
bb368:
  %t1590 = load i64, ptr %l69, !tbaa !24
  %t1592 = icmp sgt i64 %t1590, 0
  br i1 %t1592, label %bb370, label %bb371
bb369:
  store i64 0, ptr %l805, !tbaa !24
  br label %bb373
bb370:
  %t1594 = load i64, ptr %l68, !tbaa !24
  %t1595 = load i64, ptr %l67, !tbaa !24
  %t1598 = sub i64 %t1594, %t1595
  %t1599 = load i64, ptr %l69, !tbaa !24
  %t1602 = add i64 %t1598, %t1599
  %t1604 = sub i64 %t1602, 1
  %t1605 = load i64, ptr %l69, !tbaa !24
  %t1608 = sdiv i64 %t1604, %t1605
  store i64 %t1608, ptr %l808, !tbaa !24
  br label %bb372
bb371:
  store i64 0, ptr %l808, !tbaa !24
  br label %bb372
bb372:
  %t1610 = load i64, ptr %l808, !tbaa !24
  store i64 %t1610, ptr %l805, !tbaa !24
  br label %bb373
bb373:
  %t1611 = load i64, ptr %l805, !tbaa !24
  store i64 %t1611, ptr %l70, !tbaa !24
  store i64 0, ptr %l71, !tbaa !24
  br label %bb374
bb374:
  %t1612 = load i64, ptr %l71, !tbaa !24
  %t1613 = load i64, ptr %l70, !tbaa !24
  %t1616 = icmp slt i64 %t1612, %t1613
  %t1618 = xor i1 %t1616, true
  br i1 %t1618, label %bb375, label %bb376
bb375:
  br label %bb387
bb376:
  br label %bb377
bb377:
  %t1620 = load i64, ptr %l67, !tbaa !24
  %t1621 = load i64, ptr %l71, !tbaa !24
  %t1622 = load i64, ptr %l69, !tbaa !24
  %t1625 = mul i64 %t1621, %t1622
  %t1628 = add i64 %t1620, %t1625
  store i64 %t1628, ptr %l72, !tbaa !24
  %t1630 = load i64, ptr %l72, !tbaa !24
  %t1632 = icmp sgt i64 %t1630, 0
  br i1 %t1632, label %bb378, label %bb379
bb378:
  store %olang.scope zeroinitializer, ptr %s68
  %t1634 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s68, ptr %t1634, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d60, i32 0, i32 1) })
  br label %bb380
bb379:
  br label %bb381
bb380:
  call void @__olang_scope_close(ptr %s68)
  br label %bb381
bb381:
  %t1636 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1636, ptr %l829, !tbaa !29
  %t1637 = load ptr, ptr %l0, !tbaa !29
  %t1638 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t1638, ptr %l831, !tbaa !27
  %t1639 = load i64, ptr %l59, !tbaa !24
  %t1640 = load i64, ptr %l72, !tbaa !24
  %t1643 = add i64 %t1639, %t1640
  %t1645 = getelementptr { i64, ptr }, ptr %l831, i32 0, i32 1
  %t1646 = load ptr, ptr %t1645, !tbaa !27
  %t1647 = getelementptr i32, ptr %t1646, i64 %t1643
  %t1648 = load i32, ptr %t1647, !tbaa !33
  %t1651 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t1637, i32 %t1648)
  store { i64, ptr } %t1651, ptr %l836
  br label %bb382
bb382:
  %t1652 = load ptr, ptr %l829, !tbaa !29
  %t1653 = load { i64, ptr }, ptr %l836, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %v0, ptr %t1652, { i64, ptr } %t1653)
  br label %bb383
bb383:
  %t1654 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t1654, i8 32)
  br label %bb384
bb384:
  %t1656 = load ptr, ptr %l0, !tbaa !29
  %t1657 = load ptr, ptr %l1, !tbaa !29
  %t1658 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t1658, ptr %l840, !tbaa !27
  %t1659 = load i64, ptr %l72, !tbaa !24
  %t1661 = getelementptr { i64, ptr }, ptr %l840, i32 0, i32 1
  %t1662 = load ptr, ptr %t1661, !tbaa !27
  %t1663 = getelementptr i32, ptr %t1662, i64 %t1659
  %t1664 = load i32, ptr %t1663, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %v1, ptr %t1656, ptr %t1657, i32 %t1664, i1 false)
  br label %bb385
bb385:
  br label %bb386
bb386:
  %t1668 = load i64, ptr %l71, !tbaa !24
  %t1670 = add i64 %t1668, 1
  store i64 %t1670, ptr %l71, !tbaa !24
  br label %bb374
bb387:
  %t1672 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t1672, i8 41)
  br label %bb388
bb388:
  %t1674 = load i64, ptr %l59, !tbaa !24
  %t1675 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t1677 = extractvalue { i64, ptr } %t1675, 0
  %t1680 = add i64 %t1674, %t1677
  store i64 %t1680, ptr %l59, !tbaa !24
  br label %bb389
bb389:
  %t1682 = load i64, ptr %l64, !tbaa !24
  %t1684 = add i64 %t1682, 1
  store i64 %t1684, ptr %l64, !tbaa !24
  br label %bb344
bb390:
  %t1686 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s60, ptr %t1686, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d61, i32 0, i32 1) })
  br label %bb391
bb391:
  call void @__olang_scope_close(ptr %s60)
  br label %bb441
bb392:
  %t1688 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t1690 = trunc i64 26 to i32
  %t1691 = icmp eq i32 %t1688, %t1690
  br i1 %t1691, label %bb393, label %bb394
bb393:
  br label %bb395
bb394:
  br label %bb398
bb395:
  store %olang.scope zeroinitializer, ptr %s71
  %t1693 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1693, ptr %l855, !tbaa !29
  %t1694 = load ptr, ptr %l0, !tbaa !29
  %t1696 = getelementptr %"compiler/check:Checker", ptr %t1694, i32 0, i32 1
  %t1697 = load ptr, ptr %t1696, !tbaa !29
  %t1699 = getelementptr %"compiler/generic:Program", ptr %t1697, i32 0, i32 2
  %t1700 = load i32, ptr %l2, !tbaa !23
  %t1703 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t1699, i32 %t1700)
  store i64 %t1703, ptr %l860
  br label %bb396
bb396:
  %t1704 = load i64, ptr %l860, !tbaa !24
  %t1705 = call i64 @__olang_fmt_i64(ptr null, i64 %t1704)
  %t1706 = call ptr @__olang_scope_alloc(ptr %s71, i64 %t1705)
  %t1707 = call i64 @__olang_fmt_i64(ptr %t1706, i64 %t1704)
  %t1708 = insertvalue { i64, ptr } undef, i64 %t1705, 0
  %t1709 = insertvalue { i64, ptr } %t1708, ptr %t1706, 1
  %t1711 = extractvalue { i64, ptr } %t1709, 0
  %t1712 = extractvalue { i64, ptr } %t1709, 1
  %t1713 = mul i64 %t1711, 1
  %t1714 = call ptr @__olang_scope_alloc(ptr %s71, i64 %t1713)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1714, ptr %t1712, i64 %t1713, i1 false)
  %t1715 = insertvalue { i64, ptr } undef, i64 %t1711, 0
  %t1716 = insertvalue { i64, ptr } %t1715, ptr %t1714, 1
  %t1717 = load ptr, ptr %l855, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s71, ptr %t1717, { i64, ptr } %t1716)
  br label %bb397
bb397:
  call void @__olang_scope_close(ptr %s71)
  br label %bb441
bb398:
  %t1719 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t1721 = trunc i64 25 to i32
  %t1722 = icmp eq i32 %t1719, %t1721
  br i1 %t1722, label %bb399, label %bb400
bb399:
  br label %bb401
bb400:
  br label %bb407
bb401:
  %t1724 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1724, ptr %l865, !tbaa !29
  %t1725 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1725, ptr %l866, !tbaa !29
  %t1726 = load ptr, ptr %l0, !tbaa !29
  %t1728 = getelementptr %"compiler/check:Checker", ptr %t1726, i32 0, i32 1
  %t1729 = load ptr, ptr %t1728, !tbaa !29
  store ptr %t1729, ptr %l868, !tbaa !29
  %t1730 = load ptr, ptr %l0, !tbaa !29
  %t1732 = getelementptr %"compiler/check:Checker", ptr %t1730, i32 0, i32 1
  %t1733 = load ptr, ptr %t1732, !tbaa !29
  %t1735 = getelementptr %"compiler/generic:Program", ptr %t1733, i32 0, i32 2
  %t1736 = load i32, ptr %l2, !tbaa !23
  %t1739 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t1735, i32 %t1736)
  store i64 %t1739, ptr %l873
  br label %bb402
bb402:
  %t1740 = load ptr, ptr %l0, !tbaa !29
  %t1742 = getelementptr %"compiler/check:Checker", ptr %t1740, i32 0, i32 1
  %t1743 = load ptr, ptr %t1742, !tbaa !29
  %t1745 = getelementptr %"compiler/generic:Program", ptr %t1743, i32 0, i32 2
  %t1746 = load i32, ptr %l2, !tbaa !23
  %t1749 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t1745, i32 %t1746)
  store i64 %t1749, ptr %l878
  br label %bb403
bb403:
  %t1750 = load ptr, ptr %l868, !tbaa !29
  %t1751 = load i64, ptr %l873, !tbaa !24
  %t1752 = load i64, ptr %l878, !tbaa !24
  %t1753 = call %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %t1750, i64 %t1751, i64 %t1752)
  store %"compiler/generic:varRow" %t1753, ptr %l879
  br label %bb404
bb404:
  %t1754 = getelementptr %"compiler/generic:varRow", ptr %l879, i32 0, i32 1
  %t1755 = load i32, ptr %t1754, !tbaa !23
  %t1756 = load ptr, ptr %l866, !tbaa !29
  %t1758 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t1756, i32 %t1755)
  store { i64, ptr } %t1758, ptr %l881
  br label %bb405
bb405:
  %t1759 = load ptr, ptr %l865, !tbaa !29
  %t1760 = load { i64, ptr }, ptr %l881, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %v0, ptr %t1759, { i64, ptr } %t1760)
  br label %bb406
bb406:
  br label %bb441
bb407:
  %t1761 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t1763 = trunc i64 30 to i32
  %t1764 = icmp eq i32 %t1761, %t1763
  br i1 %t1764, label %bb408, label %bb409
bb408:
  br label %bb410
bb409:
  br label %bb434
bb410:
  %t1766 = load ptr, ptr %l0, !tbaa !29
  %t1768 = getelementptr %"compiler/check:Checker", ptr %t1766, i32 0, i32 1
  %t1769 = load ptr, ptr %t1768, !tbaa !29
  %t1771 = getelementptr %"compiler/generic:Program", ptr %t1769, i32 0, i32 2
  store ptr %t1771, ptr %l886, !tbaa !29
  %t1772 = load ptr, ptr %l0, !tbaa !29
  %t1774 = getelementptr %"compiler/check:Checker", ptr %t1772, i32 0, i32 1
  %t1775 = load ptr, ptr %t1774, !tbaa !29
  %t1777 = getelementptr %"compiler/generic:Program", ptr %t1775, i32 0, i32 2
  %t1778 = load i32, ptr %l2, !tbaa !23
  %t1781 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %t1777, i32 %t1778)
  store i32 %t1781, ptr %l891
  br label %bb411
bb411:
  %t1782 = load ptr, ptr %l886, !tbaa !29
  %t1783 = load i32, ptr %l891, !tbaa !23
  %t1784 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t1782, i32 %t1783)
  store { i64, ptr } %t1784, ptr %l892
  br label %bb412
bb412:
  %t1785 = load { i64, ptr }, ptr %l892, !tbaa !27
  store { i64, ptr } %t1785, ptr %l73, !tbaa !27
  %t1786 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t1788 = extractvalue { i64, ptr } %t1786, 0
  %t1790 = icmp eq i64 %t1788, 0
  br i1 %t1790, label %bb413, label %bb414
bb413:
  store %olang.scope zeroinitializer, ptr %s75
  %t1792 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s75, ptr %t1792, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d62, i32 0, i32 1) })
  br label %bb415
bb414:
  br label %bb416
bb415:
  call void @__olang_scope_close(ptr %s75)
  br label %bb416
bb416:
  store i64 0, ptr %l74, !tbaa !24
  %t1794 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t1796 = extractvalue { i64, ptr } %t1794, 0
  store i64 %t1796, ptr %l75, !tbaa !24
  store i64 1, ptr %l76, !tbaa !24
  %t1798 = load i64, ptr %l75, !tbaa !24
  %t1799 = load i64, ptr %l74, !tbaa !24
  %t1802 = icmp sgt i64 %t1798, %t1799
  br i1 %t1802, label %bb417, label %bb418
bb417:
  %t1804 = load i64, ptr %l76, !tbaa !24
  %t1806 = icmp sgt i64 %t1804, 0
  br i1 %t1806, label %bb419, label %bb420
bb418:
  store i64 0, ptr %l902, !tbaa !24
  br label %bb422
bb419:
  %t1808 = load i64, ptr %l75, !tbaa !24
  %t1809 = load i64, ptr %l74, !tbaa !24
  %t1812 = sub i64 %t1808, %t1809
  %t1813 = load i64, ptr %l76, !tbaa !24
  %t1816 = add i64 %t1812, %t1813
  %t1818 = sub i64 %t1816, 1
  %t1819 = load i64, ptr %l76, !tbaa !24
  %t1822 = sdiv i64 %t1818, %t1819
  store i64 %t1822, ptr %l905, !tbaa !24
  br label %bb421
bb420:
  store i64 0, ptr %l905, !tbaa !24
  br label %bb421
bb421:
  %t1824 = load i64, ptr %l905, !tbaa !24
  store i64 %t1824, ptr %l902, !tbaa !24
  br label %bb422
bb422:
  %t1825 = load i64, ptr %l902, !tbaa !24
  store i64 %t1825, ptr %l77, !tbaa !24
  store i64 0, ptr %l78, !tbaa !24
  br label %bb423
bb423:
  %t1826 = load i64, ptr %l78, !tbaa !24
  %t1827 = load i64, ptr %l77, !tbaa !24
  %t1830 = icmp slt i64 %t1826, %t1827
  %t1832 = xor i1 %t1830, true
  br i1 %t1832, label %bb424, label %bb425
bb424:
  br label %bb433
bb425:
  br label %bb426
bb426:
  %t1834 = load i64, ptr %l74, !tbaa !24
  %t1835 = load i64, ptr %l78, !tbaa !24
  %t1836 = load i64, ptr %l76, !tbaa !24
  %t1839 = mul i64 %t1835, %t1836
  %t1842 = add i64 %t1834, %t1839
  store i64 %t1842, ptr %l79, !tbaa !24
  %t1844 = load i64, ptr %l79, !tbaa !24
  %t1846 = icmp sgt i64 %t1844, 0
  br i1 %t1846, label %bb427, label %bb428
bb427:
  store %olang.scope zeroinitializer, ptr %s78
  %t1848 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s78, ptr %t1848, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d63, i32 0, i32 1) })
  br label %bb429
bb428:
  br label %bb430
bb429:
  call void @__olang_scope_close(ptr %s78)
  br label %bb430
bb430:
  %t1850 = load ptr, ptr %l0, !tbaa !29
  %t1851 = load ptr, ptr %l1, !tbaa !29
  %t1852 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t1852, ptr %l928, !tbaa !27
  %t1853 = load i64, ptr %l79, !tbaa !24
  %t1855 = getelementptr { i64, ptr }, ptr %l928, i32 0, i32 1
  %t1856 = load ptr, ptr %t1855, !tbaa !27
  %t1857 = getelementptr i32, ptr %t1856, i64 %t1853
  %t1858 = load i32, ptr %t1857, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %v1, ptr %t1850, ptr %t1851, i32 %t1858, i1 false)
  br label %bb431
bb431:
  br label %bb432
bb432:
  %t1862 = load i64, ptr %l78, !tbaa !24
  %t1864 = add i64 %t1862, 1
  store i64 %t1864, ptr %l78, !tbaa !24
  br label %bb423
bb433:
  br label %bb441
bb434:
  br i1 true, label %bb435, label %bb436
bb435:
  br label %bb437
bb436:
  br label %bb440
bb437:
  store %olang.scope zeroinitializer, ptr %s80
  %t1866 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1866, ptr %l933, !tbaa !29
  %t1867 = load ptr, ptr %l0, !tbaa !29
  %t1869 = getelementptr %"compiler/check:Checker", ptr %t1867, i32 0, i32 1
  %t1870 = load ptr, ptr %t1869, !tbaa !29
  %t1872 = getelementptr %"compiler/generic:Program", ptr %t1870, i32 0, i32 2
  %t1873 = load i32, ptr %l2, !tbaa !23
  %t1876 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s80, ptr %t1872, i32 %t1873)
  store { i64, ptr } %t1876, ptr %l938
  br label %bb438
bb438:
  %t1877 = load { i64, ptr }, ptr %l938, !tbaa !27
  %t1878 = extractvalue { i64, ptr } %t1877, 0
  %t1879 = extractvalue { i64, ptr } %t1877, 1
  %t1880 = mul i64 %t1878, 1
  %t1881 = call ptr @__olang_scope_alloc(ptr %s80, i64 %t1880)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1881, ptr %t1879, i64 %t1880, i1 false)
  %t1882 = insertvalue { i64, ptr } undef, i64 %t1878, 0
  %t1883 = insertvalue { i64, ptr } %t1882, ptr %t1881, 1
  %t1884 = load ptr, ptr %l933, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s80, ptr %t1884, { i64, ptr } %t1883)
  br label %bb439
bb439:
  call void @__olang_scope_close(ptr %s80)
  br label %bb441
bb440:
  call void @__olang_check_failed(ptr @olang_loc_150065cf715feb7f_967c08b33fa11dcb)
  unreachable
bb441:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc2(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l2 = alloca %"compiler/source:Span"
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %rv = alloca { i64, ptr }
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 4
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t14 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v0, ptr %v0, ptr %t10, i64 %a1)
  store { i64, ptr } %t14, ptr %l8
  br label %bb1
bb1:
  %t15 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t15, ptr %l9, !tbaa !27
  %t16 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t17 = load i32, ptr %t16, !tbaa !23
  %t19 = sext i32 %t17 to i64
  store i64 %t19, ptr %l11, !tbaa !24
  %t20 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t21 = load i32, ptr %t20, !tbaa !23
  %t23 = sext i32 %t21 to i64
  store i64 %t23, ptr %l13, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 0
  store i64 %t25, ptr %l14, !tbaa !24
  %t26 = load i64, ptr %l11, !tbaa !24
  %t27 = icmp sge i64 %t26, 0
  br i1 %t27, label %bb2, label %bb3
bb2:
  %t29 = load i64, ptr %l11, !tbaa !24
  %t30 = load i64, ptr %l13, !tbaa !24
  %t31 = icmp sle i64 %t29, %t30
  br i1 %t31, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_acadf2af31b93e38_18751a402ed16b84)
  unreachable
bb4:
  %t33 = load i64, ptr %l13, !tbaa !24
  %t34 = load i64, ptr %l14, !tbaa !24
  %t35 = icmp sle i64 %t33, %t34
  br i1 %t35, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_acadf2af31b93e38_18751a402ed16b84)
  unreachable
bb6:
  %t37 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = load i64, ptr %l11, !tbaa !24
  %t40 = load i64, ptr %l13, !tbaa !24
  %t41 = getelementptr i8, ptr %t38, i64 %t39
  %t42 = sub i64 %t40, %t39
  %t43 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t41, 1
  %t46 = extractvalue { i64, ptr } %t44, 1
  %t47 = extractvalue { i64, ptr } %t44, 0
  %t48 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t47)
  call void @olang_textcopy(ptr %t48, ptr %t46, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  store { i64, ptr } %t50, ptr %rv
  br label %ret
bb7:
  call void @__olang_check_failed(ptr @olang_loc_acadf2af31b93e38_18751a402ed16b84)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estep(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i64
  %l12 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca %"compiler/source:Span"
  %l18 = alloca i32
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l25 = alloca %"compiler/source:Span"
  %l29 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l35 = alloca i32
  %l38 = alloca i1
  %l40 = alloca i1
  %l43 = alloca i1
  %l44 = alloca i1
  %l48 = alloca i1
  %l53 = alloca i1
  %l59 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca ptr
  %l64 = alloca %"compiler/source:Span"
  %l65 = alloca %"compiler/source:Span"
  %l68 = alloca { i64, ptr }
  %l70 = alloca %"compiler/msgs:Msg"
  %l71 = alloca i64
  %l78 = alloca ptr
  %l79 = alloca ptr
  %l80 = alloca %"compiler/source:Span"
  %l81 = alloca i32
  %l84 = alloca ptr
  %l87 = alloca i32
  %l88 = alloca i1
  %l89 = alloca i64
  %l92 = alloca i32
  %l93 = alloca i64
  %l94 = alloca ptr
  %l96 = alloca i32
  %l101 = alloca i64
  %l108 = alloca ptr
  %l109 = alloca %"compiler/source:Span"
  %l110 = alloca ptr
  %l111 = alloca %"compiler/source:Span"
  %l112 = alloca i32
  %l113 = alloca i32
  %l114 = alloca i32
  %l118 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %t130 = alloca { i64, [4 x i64] }, align 8
  %t213 = alloca { i64, [5 x i64] }, align 8
  %t229 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t5 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %v0, ptr %t1, ptr %t2)
  store ptr %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l12, !tbaa !29
  store ptr %t6, ptr %l4, !tbaa !29
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l15, !tbaa !29
  %t12 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t12, ptr %l16
  %t13 = load i1, ptr %l3, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  store i32 65, ptr %l18
  br label %bb7
bb6:
  store i32 66, ptr %l18
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l4, !tbaa !29
  store ptr %t17, ptr %l21, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l22, !tbaa !29
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t19)
  store %"compiler/source:Span" %t21, ptr %l24
  br label %bb8
bb8:
  %t22 = load ptr, ptr %l22, !tbaa !29
  %t23 = load %"compiler/source:Span", ptr %l24
  %t24 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %t22, %"compiler/source:Span" %t23, i64 2)
  store %"compiler/source:Span" %t24, ptr %l25
  br label %bb9
bb9:
  %t25 = icmp sge i64 0, 0
  br i1 %t25, label %bb10, label %bb11
bb10:
  %t27 = icmp sle i64 0, 1152921504606846975
  br i1 %t27, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_ddf5999d75afc0ea_2c71428eb0b518ce)
  unreachable
bb12:
  %t29 = mul i64 0, 8
  %t30 = insertvalue { i64, ptr } undef, i64 0, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t32 = load ptr, ptr %l15, !tbaa !29
  %t33 = load %"compiler/source:Span", ptr %l16
  %t34 = load i32, ptr %l18, !range !{i32 0, i32 98}
  %t35 = load ptr, ptr %l21, !tbaa !29
  %t36 = load %"compiler/source:Span", ptr %l25
  %t38 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewriteBack(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t32, %"compiler/source:Span" %t33, i32 %t34, ptr %t35, ptr null, %"compiler/source:Span" %t36, i64 -1, { i64, ptr } %t31)
  store i1 %t38, ptr %l29
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_ddf5999d75afc0ea_2c71428eb0b518ce)
  unreachable
bb14:
  %t39 = load i1, ptr %l29, !tbaa !21
  br i1 %t39, label %bb15, label %bb16
bb15:
  br label %ret
bb16:
  br label %bb17
bb17:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l30, !tbaa !29
  %t41 = load ptr, ptr %l4, !tbaa !29
  store ptr %t41, ptr %l31, !tbaa !29
  %t42 = load ptr, ptr %l2, !tbaa !29
  %t44 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t42)
  store %"compiler/source:Span" %t44, ptr %l33
  br label %bb18
bb18:
  %t45 = load ptr, ptr %l30, !tbaa !29
  %t46 = load ptr, ptr %l31, !tbaa !29
  %t47 = load %"compiler/source:Span", ptr %l33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotCapture(ptr %v0, ptr %v0, ptr %t45, ptr %t46, %"compiler/source:Span" %t47)
  br label %bb19
bb19:
  %t48 = load ptr, ptr %l4, !tbaa !29
  %t50 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %t48)
  store i32 %t50, ptr %l35
  br label %bb20
bb20:
  %t51 = load i32, ptr %l35, !tbaa !23
  store i32 %t51, ptr %l5, !tbaa !23
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i32, ptr %l5, !tbaa !23
  %t56 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t52, i32 %t53)
  store i1 %t56, ptr %l38
  br label %bb21
bb21:
  %t57 = load i1, ptr %l38, !tbaa !21
  %t58 = xor i1 %t57, true
  br i1 %t58, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb29
bb23:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load i32, ptr %l5, !tbaa !23
  %t64 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t60, i32 %t61)
  store i1 %t64, ptr %l43
  br label %bb24
bb24:
  %t65 = load i1, ptr %l43, !tbaa !21
  br i1 %t65, label %bb25, label %bb26
bb25:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t70 = load i32, ptr %l5, !tbaa !23
  %t73 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t69, i32 %t70)
  store i1 %t73, ptr %l48
  br label %bb27
bb26:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb28
bb27:
  %t74 = load i1, ptr %l48, !tbaa !21
  %t75 = xor i1 %t74, true
  store i1 %t75, ptr %l44, !tbaa !21
  br label %bb28
bb28:
  %t77 = load i1, ptr %l44, !tbaa !21
  store i1 %t77, ptr %l40, !tbaa !21
  br label %bb29
bb29:
  %t78 = load i1, ptr %l40, !tbaa !21
  br i1 %t78, label %bb30, label %bb31
bb30:
  %t79 = load i32, ptr %l5, !tbaa !23
  %t80 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t83 = icmp ne i32 %t79, %t80
  br i1 %t83, label %bb32, label %bb33
bb31:
  br label %bb44
bb32:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load %"compiler/source:Span", ptr %l1
  %t87 = load ptr, ptr %l4, !tbaa !29
  %t88 = load i32, ptr %l5, !tbaa !23
  %t89 = load i1, ptr %l3, !tbaa !21
  %t95 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estepMethod(ptr %v0, ptr %v0, ptr %t85, %"compiler/source:Span" %t86, ptr %t87, i32 %t88, i1 %t89)
  store i1 %t95, ptr %l59
  br label %bb34
bb33:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb35
bb34:
  %t96 = load i1, ptr %l59, !tbaa !21
  %t97 = xor i1 %t96, true
  store i1 %t97, ptr %l53, !tbaa !21
  br label %bb35
bb35:
  %t99 = load i1, ptr %l53, !tbaa !21
  br i1 %t99, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s4
  %t100 = load ptr, ptr %l0, !tbaa !29
  store ptr %t100, ptr %l61, !tbaa !29
  %t101 = load ptr, ptr %l0, !tbaa !29
  store ptr %t101, ptr %l62, !tbaa !29
  %t102 = load ptr, ptr %l2, !tbaa !29
  %t104 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t102)
  store %"compiler/source:Span" %t104, ptr %l64
  br label %bb38
bb37:
  br label %bb43
bb38:
  %t105 = load ptr, ptr %l62, !tbaa !29
  %t106 = load %"compiler/source:Span", ptr %l64
  %t107 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %t105, %"compiler/source:Span" %t106, i64 2)
  store %"compiler/source:Span" %t107, ptr %l65
  br label %bb39
bb39:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load i32, ptr %l5, !tbaa !23
  %t112 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s4, ptr %t108, i32 %t109)
  store { i64, ptr } %t112, ptr %l68
  br label %bb40
bb40:
  %t113 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  %t115 = extractvalue { i64, ptr } %t113, 1
  %t116 = mul i64 %t114, 1
  %t117 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t116)
  call void @llvm.memcpy.p0.p0.i64(ptr %t117, ptr %t115, i64 %t116, i1 false)
  %t118 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t117, 1
  %t121 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eStepNotNumber(ptr %s4, ptr %s4, { i64, ptr } %t119)
  store %"compiler/msgs:Msg" %t121, ptr %l70
  br label %bb41
bb41:
  %t122 = load ptr, ptr %l61, !tbaa !29
  %t123 = load %"compiler/source:Span", ptr %l65
  %t124 = load %"compiler/msgs:Msg", ptr %l70
  %t125 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t122, %"compiler/source:Span" %t123, %"compiler/msgs:Msg" %t124)
  store i64 %t125, ptr %l71
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s4)
  br label %bb43
bb43:
  br label %ret
bb44:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load %"compiler/source:Span", ptr %l1
  %t128 = load %"compiler/source:Span", ptr %l1
  %t129 = load i32, ptr %l5, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t130
  %t131 = getelementptr { i64, [4 x i64] }, ptr %t130, i32 0, i32 0
  store i64 7, ptr %t131
  %t133 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t128, 0
  %t135 = insertvalue { %"compiler/source:Span", i32 } %t133, i32 %t129, 1
  %t136 = getelementptr { i64, [4 x i64] }, ptr %t130, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t135, ptr %t136
  %t137 = load { i64, [4 x i64] }, ptr %t130
  %t139 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t137, ptr %t139
  %t143 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t126, %"compiler/source:Span" %t127, ptr %t139)
  store ptr %t143, ptr %l78
  br label %bb45
bb45:
  %t144 = load ptr, ptr %l78, !tbaa !29
  store ptr %t144, ptr %l6, !tbaa !29
  %t145 = load ptr, ptr %l0, !tbaa !29
  store ptr %t145, ptr %l79, !tbaa !29
  %t146 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t146, ptr %l80
  %t147 = load i32, ptr %l5, !tbaa !23
  store i32 %t147, ptr %l81, !tbaa !23
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/check:Checker", ptr %t148, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = getelementptr %"compiler/generic:Program", ptr %t151, i32 0, i32 2
  store ptr %t153, ptr %l84, !tbaa !29
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load i32, ptr %l5, !tbaa !23
  %t158 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t154, i32 %t155)
  store i32 %t158, ptr %l87
  br label %bb46
bb46:
  %t159 = load ptr, ptr %l84, !tbaa !29
  %t160 = load i32, ptr %l87, !tbaa !23
  %t161 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t159, i32 %t160)
  store i1 %t161, ptr %l88
  br label %bb47
bb47:
  %t162 = load i1, ptr %l88, !tbaa !21
  br i1 %t162, label %bb48, label %bb49
bb48:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load i32, ptr %l5, !tbaa !23
  %t167 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t163, i32 %t164)
  store i32 %t167, ptr %l92
  br label %bb50
bb49:
  store i64 1, ptr %l89, !tbaa !24
  br label %bb52
bb50:
  %t168 = load i32, ptr %l92, !tbaa !23
  %t169 = call i64 @compiler_2fcheck_2efloatBits(i32 %t168, double 0x3ff0000000000000)
  store i64 %t169, ptr %l93
  br label %bb51
bb51:
  %t170 = load i64, ptr %l93, !tbaa !24
  store i64 %t170, ptr %l89, !tbaa !24
  br label %bb52
bb52:
  %t171 = load ptr, ptr %l79, !tbaa !29
  %t172 = load %"compiler/source:Span", ptr %l80
  %t173 = load i32, ptr %l81, !tbaa !23
  %t174 = load i64, ptr %l89, !tbaa !24
  %t175 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t171, %"compiler/source:Span" %t172, i32 %t173, i64 %t174)
  store ptr %t175, ptr %l94
  br label %bb53
bb53:
  %t176 = load ptr, ptr %l94, !tbaa !29
  store ptr %t176, ptr %l7, !tbaa !29
  %t177 = load i1, ptr %l3, !tbaa !21
  br i1 %t177, label %bb54, label %bb55
bb54:
  store i32 3, ptr %l96
  br label %bb56
bb55:
  store i32 4, ptr %l96
  br label %bb56
bb56:
  %t181 = load i32, ptr %l96, !range !{i32 0, i32 44}
  store i32 %t181, ptr %l8
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/check:Checker", ptr %t182, i32 0, i32 36
  %t186 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t184)
  store i64 %t186, ptr %l101
  br label %bb57
bb57:
  %t187 = load i64, ptr %l101, !tbaa !24
  store i64 %t187, ptr %l9, !tbaa !24
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/check:Checker", ptr %t188, i32 0, i32 36
  %t191 = load ptr, ptr %l6, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t190, ptr %t191)
  br label %bb58
bb58:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/check:Checker", ptr %t194, i32 0, i32 36
  %t197 = load ptr, ptr %l7, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t196, ptr %t197)
  br label %bb59
bb59:
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l108, !tbaa !29
  %t201 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t201, ptr %l109
  %t202 = load ptr, ptr %l4, !tbaa !29
  store ptr %t202, ptr %l110, !tbaa !29
  %t203 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t203, ptr %l111
  %t204 = load i32, ptr %l5, !tbaa !23
  store i32 %t204, ptr %l112, !tbaa !23
  %t205 = load i32, ptr %l8, !range !{i32 0, i32 44}
  store i32 %t205, ptr %l113
  store i32 0, ptr %l114
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/check:Checker", ptr %t206, i32 0, i32 36
  %t209 = load i64, ptr %l9, !tbaa !24
  %t212 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t208, i64 %t209)
  store { i64, ptr } %t212, ptr %l118
  br label %bb60
bb60:
  store { i64, [5 x i64] } zeroinitializer, ptr %t213
  %t214 = getelementptr { i64, [5 x i64] }, ptr %t213, i32 0, i32 0
  store i64 9, ptr %t214
  %t215 = load %"compiler/source:Span", ptr %l111
  %t216 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t215, 0
  %t217 = load i32, ptr %l112, !tbaa !23
  %t218 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t216, i32 %t217, 1
  %t219 = load i32, ptr %l113, !range !{i32 0, i32 44}
  %t220 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t218, i32 %t219, 2
  %t221 = load i32, ptr %l114, !range !{i32 0, i32 3}
  %t222 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t220, i32 %t221, 3
  %t223 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t224 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t222, { i64, ptr } %t223, 4
  %t225 = getelementptr { i64, [5 x i64] }, ptr %t213, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t224, ptr %t225
  %t226 = load { i64, [5 x i64] }, ptr %t213
  %t228 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t226, ptr %t228
  store { i64, [3 x i64] } zeroinitializer, ptr %t229
  %t230 = getelementptr { i64, [3 x i64] }, ptr %t229, i32 0, i32 0
  store i64 1, ptr %t230
  %t231 = load %"compiler/source:Span", ptr %l109
  %t232 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t231, 0
  %t233 = load ptr, ptr %l110, !tbaa !29
  %t234 = insertvalue { %"compiler/source:Span", ptr, ptr } %t232, ptr %t233, 1
  %t236 = insertvalue { %"compiler/source:Span", ptr, ptr } %t234, ptr %t228, 2
  %t237 = getelementptr { i64, [3 x i64] }, ptr %t229, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t236, ptr %t237
  %t238 = load { i64, [3 x i64] }, ptr %t229
  %t240 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t238, ptr %t240
  %t241 = load ptr, ptr %l108, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t241, ptr %t240)
  br label %bb61
bb61:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etestBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/source:Span"
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l10 = alloca { i64, [2 x i64] }
  %l15 = alloca i32
  %l18 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l29 = alloca %"compiler/generic:Context"
  %l32 = alloca ptr
  %l35 = alloca i32
  %l38 = alloca ptr
  %l40 = alloca ptr
  %t3 = alloca { i64, [2 x i64] }, align 8
  %t46 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t3
  %t4 = getelementptr { i64, [2 x i64] }, ptr %t3, i32 0, i32 0
  store i64 5, ptr %t4
  %t6 = insertvalue { i64 } undef, i64 %a4, 0
  %t7 = getelementptr { i64, [2 x i64] }, ptr %t3, i32 0, i32 1
  store { i64 } %t6, ptr %t7
  %t8 = load { i64, [2 x i64] }, ptr %t3
  store { i64, [2 x i64] } %t8, ptr %l10
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/generic:Program", ptr %t12, i32 0, i32 2
  %t15 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t14, i32 0, i32 %t15, i32 0, i32 0, i64 0, i1 false, i32 0)
  store i32 %t18, ptr %l15
  br label %bb1
bb1:
  %t19 = load i64, ptr %l1, !tbaa !24
  %t20 = load %"compiler/source:Span", ptr %l2
  %t21 = load ptr, ptr %l8, !tbaa !29
  %t22 = load { i64, [2 x i64] }, ptr %l10
  %t23 = load i32, ptr %l15, !tbaa !23
  %t26 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t21, { i64, [2 x i64] } %t22, i32 %t23, i64 %t19, %"compiler/source:Span" %t20)
  store i64 %t26, ptr %l18
  br label %bb2
bb2:
  %t27 = load i64, ptr %l18, !tbaa !24
  store i64 %t27, ptr %l5, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 19
  %t31 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t30, i64 %t31, i64 1)
  br label %bb3
bb3:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i64, ptr %l5, !tbaa !24
  %t36 = load i64, ptr %l1, !tbaa !24
  %t37 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t42 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t34, i64 %t35, i64 %t36, i32 %t37, i32 0)
  store ptr %t42, ptr %l26
  br label %bb4
bb4:
  %t43 = load ptr, ptr %l26, !tbaa !29
  store ptr %t43, ptr %l6, !tbaa !29
  %t44 = load ptr, ptr %l6, !tbaa !29
  store ptr %t44, ptr %l27, !tbaa !29
  %t45 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fgeneric_3aContext_2ector(ptr %t46, ptr %v0, i64 %t45, i64 -1)
  call void @llvm.memmove.p0.p0.i64(ptr %l29, ptr %t46, i64 160, i1 false)
  br label %bb5
bb5:
  %t48 = load ptr, ptr %l27, !tbaa !29
  %t49 = getelementptr %"compiler/check:frame", ptr %t48, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %t49, ptr %l29, i64 160, i1 false)
  %t50 = load ptr, ptr %l6, !tbaa !29
  %t52 = getelementptr %"compiler/check:frame", ptr %t50, i32 0, i32 12
  store i1 true, ptr %t52, !tbaa !21
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t53)
  store ptr %t55, ptr %l32
  br label %bb6
bb6:
  %t56 = load %"compiler/source:Span", ptr %l2
  %t57 = load ptr, ptr %l32, !tbaa !29
  %t60 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t57, i32 -1, i32 0, %"compiler/source:Span" %t56)
  store i32 %t60, ptr %l35
  br label %bb7
bb7:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t65 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootStmts(ptr %v0, ptr %v1, ptr %v0, ptr %t61, { i64, ptr } %a3)
  store ptr %t65, ptr %l38
  br label %bb8
bb8:
  %t66 = load ptr, ptr %l38, !tbaa !29
  store ptr %t66, ptr %l7, !tbaa !29
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t67)
  store ptr %t69, ptr %l40
  br label %bb9
bb9:
  %t70 = load ptr, ptr %l40, !tbaa !29
  %t71 = load ptr, ptr %l7, !tbaa !29
  %t75 = getelementptr %"compiler/typed:Body", ptr %t70, i32 0, i32 11
  store ptr %t71, ptr %t75, !tbaa !29
  %t76 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t76)
  br label %bb10
bb10:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/check:Checker", ptr %t78, i32 0, i32 19
  %t81 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t80, i64 %t81, i64 2)
  br label %bb11
bb11:
  br label %ret
ret:
  ret void
}

define dso_local { i32, %"compiler/source:Span" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l22 = alloca %"compiler/source:Span"
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca i32
  %rv = alloca { i32, %"compiler/source:Span" }
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19, !range !{i32 0, i32 98}
  store i32 %t20, ptr %l3
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t22 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t24 = trunc i64 5 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t27 = load %"compiler/source:Span", ptr %l2
  %t29 = insertvalue { i32, %"compiler/source:Span" } zeroinitializer, %"compiler/source:Span" %t27, 1
  store { i32, %"compiler/source:Span" } %t29, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb23
bb9:
  %t30 = load ptr, ptr %l1, !tbaa !29
  store ptr %t30, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t31 = load ptr, ptr %l16, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb10, label %bb11
bb10:
  %t34 = load ptr, ptr %l16, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 30}
  %t37 = icmp eq i64 %t35, 2
  store i1 %t37, ptr %l17, !tbaa !21
  br label %bb11
bb11:
  %t38 = load i1, ptr %l17, !tbaa !21
  br i1 %t38, label %bb12, label %bb13
bb12:
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr { i64, [4 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", ptr }, ptr %t41, i32 0, i32 1
  %t43 = load ptr, ptr %t42
  store ptr %t43, ptr %l4, !tbaa !29
  br label %bb14
bb13:
  br label %bb18
bb14:
  %t46 = load ptr, ptr %l4, !tbaa !29
  %t49 = call { i32, %"compiler/source:Span" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextValue(ptr %v0, ptr %v1, ptr %a0, ptr %t46)
  %t50 = extractvalue { i32, %"compiler/source:Span" } %t49, 1
  %t51 = extractvalue { i32, %"compiler/source:Span" } %t49, 0
  store i32 %t51, ptr %l26
  %t52 = icmp ne i32 %t51, 0
  br i1 %t52, label %bb16, label %ok.53, !prof !99
ok.53:
  store %"compiler/source:Span" %t50, ptr %l25
  br label %bb15
bb15:
  %t54 = load %"compiler/source:Span", ptr %l25
  store %"compiler/source:Span" %t54, ptr %l22
  br label %bb17
bb16:
  %t55 = load i32, ptr %l26, !tbaa !23
  %t56 = lshr i32 %t55, 16
  %t57 = and i32 %t55, 65535
  %t58 = icmp eq i32 %t56, 1
  %t59 = select i1 %t58, i32 1, i32 0
  %t60 = icmp eq i32 %t55, 0
  %t61 = shl i32 %t59, 16
  %t62 = or i32 %t61, %t57
  %t63 = select i1 %t60, i32 0, i32 %t62
  %t65 = insertvalue { i32, %"compiler/source:Span" } zeroinitializer, i32 %t63, 0
  store { i32, %"compiler/source:Span" } %t65, ptr %rv
  br label %ret
bb17:
  %t66 = load %"compiler/source:Span", ptr %l22
  %t67 = insertvalue { i32, %"compiler/source:Span" } zeroinitializer, %"compiler/source:Span" %t66, 1
  store { i32, %"compiler/source:Span" } %t67, ptr %rv
  br label %ret
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_ec59a5f60fda0dc9_336029f9ba6be385)
  unreachable
bb23:
  %t69 = insertvalue { i32, %"compiler/source:Span" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/source:Span" } %t69, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/source:Span" }, ptr %rv
  ret { i32, %"compiler/source:Span" } %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ethunkModule(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l12 = alloca ptr
  %l19 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l49 = alloca ptr
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 14
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l12, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 3
  %t11 = load i64, ptr %t10, !tbaa !24
  store i64 %t11, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/load:Loader", ptr %t19, i32 0, i32 10
  %t23 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t21)
  store i64 %t23, ptr %l19
  br label %bb2
bb2:
  %t24 = load i64, ptr %l19, !tbaa !24
  store i64 %t24, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t25 = load i64, ptr %l4, !tbaa !24
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = icmp sgt i64 %t25, %t26
  br i1 %t29, label %bb3, label %bb4
bb3:
  %t31 = load i64, ptr %l5, !tbaa !24
  %t33 = icmp sgt i64 %t31, 0
  br i1 %t33, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb8
bb5:
  %t35 = load i64, ptr %l4, !tbaa !24
  %t36 = load i64, ptr %l3, !tbaa !24
  %t39 = sub i64 %t35, %t36
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = add i64 %t39, %t40
  %t45 = sub i64 %t43, 1
  %t46 = load i64, ptr %l5, !tbaa !24
  %t49 = sdiv i64 %t45, %t46
  store i64 %t49, ptr %l26, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb7
bb7:
  %t51 = load i64, ptr %l26, !tbaa !24
  store i64 %t51, ptr %l23, !tbaa !24
  br label %bb8
bb8:
  %t52 = load i64, ptr %l23, !tbaa !24
  store i64 %t52, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  %t53 = load i64, ptr %l7, !tbaa !24
  %t54 = load i64, ptr %l6, !tbaa !24
  %t57 = icmp slt i64 %t53, %t54
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb10, label %bb11
bb10:
  br label %bb18
bb11:
  br label %bb12
bb12:
  %t61 = load i64, ptr %l3, !tbaa !24
  %t62 = load i64, ptr %l7, !tbaa !24
  %t63 = load i64, ptr %l5, !tbaa !24
  %t66 = mul i64 %t62, %t63
  %t69 = add i64 %t61, %t66
  store i64 %t69, ptr %l8, !tbaa !24
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 0
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/load:Loader", ptr %t77, i32 0, i32 10
  %t80 = load i64, ptr %l8, !tbaa !24
  %t83 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t79, i64 %t80)
  store ptr %t83, ptr %l49
  br label %bb13
bb13:
  %t84 = load ptr, ptr %l49, !tbaa !29
  %t86 = getelementptr %"compiler/load:Module", ptr %t84, i32 0, i32 4
  %t87 = load i64, ptr %t86, !tbaa !24
  %t88 = load i64, ptr %l2, !tbaa !24
  %t91 = icmp eq i64 %t87, %t88
  br i1 %t91, label %bb14, label %bb15
bb14:
  %t93 = load i64, ptr %l8, !tbaa !24
  store i64 %t93, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t95 = load i64, ptr %l7, !tbaa !24
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l7, !tbaa !24
  br label %bb9
bb18:
  store i64 0, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopSetIf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, i1 %a4, i1 %a5, i64 %a6, i64 %a7, ptr %a8) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca %"compiler/source:Span"
  %l18 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca i64
  %l31 = alloca { i64, ptr }
  %l33 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i64
  %l44 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca i64
  %l68 = alloca { i64, ptr }
  %l70 = alloca i1
  %l80 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l84 = alloca i64
  %l91 = alloca ptr
  %l99 = alloca i64
  %l101 = alloca i64
  %l106 = alloca i32
  %l112 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca i64
  %l120 = alloca %"compiler/source:Span"
  %l123 = alloca { i64, ptr }
  %l124 = alloca i1
  %l130 = alloca %"compiler/source:Span"
  %l131 = alloca ptr
  %l137 = alloca { i64, [3 x i64] }
  %l140 = alloca { i64, ptr }
  %l141 = alloca %"compiler/msgs:Msg"
  %l142 = alloca i64
  %l155 = alloca ptr
  %l158 = alloca i32
  %l160 = alloca ptr
  %l164 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l165 = alloca i32
  %l166 = alloca i32
  %l171 = alloca i1
  %l175 = alloca i1
  %s0 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %t248 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i1 %a5, ptr %l5
  store i64 %a6, ptr %l6
  store i64 %a7, ptr %l7
  store ptr %a8, ptr %l8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = getelementptr %"compiler/ast:TopIf", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  %t8 = xor i1 %t6, true
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l23, !tbaa !29
  %t11 = load i64, ptr %l1, !tbaa !24
  store i64 %t11, ptr %l24, !tbaa !24
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = getelementptr %"compiler/ast:TopIf", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = icmp eq ptr %t15, null
  br i1 %t17, label %bb3, label %bb4
bb2:
  br label %bb10
bb3:
  call void @__olang_check_failed(ptr @olang_loc_6b4c91049558e776_f5788538a01eee7a)
  unreachable
bb4:
  br label %bb5
bb5:
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t21 = getelementptr %"compiler/ast:TopIf", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t25 = getelementptr %"compiler/ast:TopBranch", ptr %t22, i32 0, i32 1
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  store { i64, ptr } %t26, ptr %l31, !tbaa !27
  %t27 = load i1, ptr %l5, !tbaa !21
  br i1 %t27, label %bb6, label %bb7
bb6:
  %t29 = load i64, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l7, !tbaa !24
  %t33 = icmp eq i64 %t29, %t30
  store i1 %t33, ptr %l33, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb8
bb8:
  %t35 = load ptr, ptr %l8, !tbaa !29
  %t36 = load ptr, ptr %l23, !tbaa !29
  %t37 = load i64, ptr %l24, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t39 = load i1, ptr %l33, !tbaa !21
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopSetDecls(ptr %v0, ptr %v2, ptr %v3, ptr %t36, i64 %t37, { i64, ptr } %t38, i1 true, i1 %t39, ptr %t35)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t41 = load ptr, ptr %l3, !tbaa !29
  %t43 = getelementptr %"compiler/ast:TopIf", ptr %t41, i32 0, i32 2
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = icmp eq ptr %t44, null
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb11, label %bb12
bb11:
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l42, !tbaa !29
  %t51 = load i64, ptr %l1, !tbaa !24
  store i64 %t51, ptr %l43, !tbaa !24
  %t52 = load ptr, ptr %l2, !tbaa !29
  store ptr %t52, ptr %l44, !tbaa !29
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t55 = getelementptr %"compiler/ast:TopIf", ptr %t53, i32 0, i32 2
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = icmp eq ptr %t56, null
  br i1 %t58, label %bb13, label %bb14
bb12:
  %t60 = load ptr, ptr %l3, !tbaa !29
  %t62 = getelementptr %"compiler/ast:TopIf", ptr %t60, i32 0, i32 3
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = icmp eq ptr %t63, null
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb17, label %bb18
bb13:
  call void @__olang_check_failed(ptr @olang_loc_812bc6763f016bdd_ce6f0e3f96c00d01)
  unreachable
bb14:
  br label %bb15
bb15:
  %t69 = load ptr, ptr %l3, !tbaa !29
  %t71 = getelementptr %"compiler/ast:TopIf", ptr %t69, i32 0, i32 2
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = load i1, ptr %l5, !tbaa !21
  %t75 = load i64, ptr %l6, !tbaa !24
  %t76 = load i64, ptr %l7, !tbaa !24
  %t78 = add i64 %t76, 1
  %t79 = load ptr, ptr %l8, !tbaa !29
  %t80 = load ptr, ptr %l42, !tbaa !29
  %t81 = load i64, ptr %l43, !tbaa !24
  %t82 = load ptr, ptr %l44, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopSetIf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t80, i64 %t81, ptr %t82, ptr %t72, i1 %a4, i1 %t74, i64 %t75, i64 %t78, ptr %t79)
  br label %bb16
bb16:
  br label %bb27
bb17:
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l60, !tbaa !29
  %t90 = load i64, ptr %l1, !tbaa !24
  store i64 %t90, ptr %l61, !tbaa !24
  %t91 = load ptr, ptr %l3, !tbaa !29
  %t93 = getelementptr %"compiler/ast:TopIf", ptr %t91, i32 0, i32 3
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = icmp eq ptr %t94, null
  br i1 %t96, label %bb19, label %bb20
bb18:
  br label %bb26
bb19:
  call void @__olang_check_failed(ptr @olang_loc_8d628e20c33cf608_43e2c14925cb83cc)
  unreachable
bb20:
  br label %bb21
bb21:
  %t98 = load ptr, ptr %l3, !tbaa !29
  %t100 = getelementptr %"compiler/ast:TopIf", ptr %t98, i32 0, i32 3
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t104 = getelementptr %"compiler/ast:TopBranch", ptr %t101, i32 0, i32 1
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !27
  store { i64, ptr } %t105, ptr %l68, !tbaa !27
  %t106 = load i1, ptr %l5, !tbaa !21
  br i1 %t106, label %bb22, label %bb23
bb22:
  %t108 = load i64, ptr %l6, !tbaa !24
  %t109 = load i64, ptr %l7, !tbaa !24
  %t111 = add i64 %t109, 1
  %t114 = icmp eq i64 %t108, %t111
  store i1 %t114, ptr %l70, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb24
bb24:
  %t116 = load ptr, ptr %l8, !tbaa !29
  %t117 = load ptr, ptr %l60, !tbaa !29
  %t118 = load i64, ptr %l61, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t120 = load i1, ptr %l70, !tbaa !21
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopSetDecls(ptr %v0, ptr %v2, ptr %v3, ptr %t117, i64 %t118, { i64, ptr } %t119, i1 true, i1 %t120, ptr %t116)
  br label %bb25
bb25:
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t122 = load ptr, ptr %l2, !tbaa !29
  %t123 = load ptr, ptr %l3, !tbaa !29
  %t126 = icmp eq ptr %t122, %t123
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb29:
  br label %bb30
bb30:
  %t130 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t130, ptr %l80
  br label %bb31
bb31:
  %t131 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l80
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t131, ptr %l9
  %t132 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2echainNames(ptr %v1, ptr %s0, ptr %t132, ptr %l9)
  br label %bb32
bb32:
  %t136 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l9)
  store i64 %t136, ptr %l84
  br label %bb33
bb33:
  %t137 = load i64, ptr %l84, !tbaa !24
  %t138 = icmp eq i64 %t137, 0
  br i1 %t138, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb35:
  br label %bb36
bb36:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/check:Checker", ptr %t140, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t145 = getelementptr %"compiler/generic:Program", ptr %t143, i32 0, i32 0
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t148 = getelementptr %"compiler/load:Loader", ptr %t146, i32 0, i32 10
  %t149 = load i64, ptr %l1, !tbaa !24
  %t152 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t148, i64 %t149)
  store ptr %t152, ptr %l91
  br label %bb37
bb37:
  %t153 = load ptr, ptr %l91, !tbaa !29
  %t155 = getelementptr %"compiler/load:Module", ptr %t153, i32 0, i32 4
  %t156 = load i64, ptr %t155, !tbaa !24
  store i64 %t156, ptr %l10, !tbaa !24
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/check:Checker", ptr %t158, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = getelementptr %"compiler/generic:Program", ptr %t161, i32 0, i32 0
  %t164 = load ptr, ptr %t163, !tbaa !29
  %t166 = getelementptr %"compiler/load:Loader", ptr %t164, i32 0, i32 4
  %t167 = load ptr, ptr %t166, !tbaa !29
  store ptr %t167, ptr %l11, !tbaa !29
  store ptr %l9, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s8
  %t170 = load i64, ptr %l13, !tbaa !24
  store i64 %t170, ptr %l99, !tbaa !24
  %t171 = load ptr, ptr %l12, !tbaa !29
  %t173 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %t171)
  store i64 %t173, ptr %l101
  br label %bb39
bb39:
  %t174 = load i64, ptr %l99, !tbaa !24
  %t175 = load i64, ptr %l101, !tbaa !24
  %t176 = icmp slt i64 %t174, %t175
  %t178 = xor i1 %t176, true
  br i1 %t178, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s8)
  br label %bb90
bb41:
  br label %bb42
bb42:
  %t180 = load ptr, ptr %l12, !tbaa !29
  %t181 = load i64, ptr %l13, !tbaa !24
  %t184 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %t180, i64 %t181)
  store i32 %t184, ptr %l106
  br label %bb43
bb43:
  %t185 = load i32, ptr %l106, !tbaa !23
  store i32 %t185, ptr %l14, !tbaa !23
  %t186 = load ptr, ptr %l2, !tbaa !29
  store ptr %t186, ptr %l15, !tbaa !29
  br label %bb44
bb44:
  %t188 = load ptr, ptr %l15, !tbaa !29
  %t190 = getelementptr %"compiler/ast:TopIf", ptr %t188, i32 0, i32 0
  %t191 = load ptr, ptr %t190, !tbaa !29
  %t193 = icmp eq ptr %t191, null
  %t195 = xor i1 %t193, true
  br i1 %t195, label %bb45, label %bb46
bb45:
  %t197 = load ptr, ptr %l0, !tbaa !29
  store ptr %t197, ptr %l113, !tbaa !29
  %t198 = load i64, ptr %l10, !tbaa !24
  store i64 %t198, ptr %l114, !tbaa !24
  %t199 = load ptr, ptr %l15, !tbaa !29
  %t201 = getelementptr %"compiler/ast:TopIf", ptr %t199, i32 0, i32 0
  %t202 = load ptr, ptr %t201, !tbaa !29
  %t204 = icmp eq ptr %t202, null
  br i1 %t204, label %bb47, label %bb48
bb46:
  store i1 false, ptr %l112, !tbaa !21
  br label %bb53
bb47:
  call void @__olang_check_failed(ptr @olang_loc_90c8334c62802427_4400025bac92e03b)
  unreachable
bb48:
  br label %bb49
bb49:
  %t206 = load ptr, ptr %l15, !tbaa !29
  %t208 = getelementptr %"compiler/ast:TopIf", ptr %t206, i32 0, i32 0
  %t209 = load ptr, ptr %t208, !tbaa !29
  %t211 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t209)
  store %"compiler/source:Span" %t211, ptr %l120
  br label %bb50
bb50:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load i32, ptr %l14, !tbaa !23
  %t216 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t212, i32 %t213)
  store { i64, ptr } %t216, ptr %l123
  br label %bb51
bb51:
  %t217 = load ptr, ptr %l113, !tbaa !29
  %t218 = load i64, ptr %l114, !tbaa !24
  %t219 = load %"compiler/source:Span", ptr %l120
  %t220 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t221 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econdReads(ptr %v0, ptr %v0, ptr %t217, i64 %t218, %"compiler/source:Span" %t219, { i64, ptr } %t220)
  store i1 %t221, ptr %l124
  br label %bb52
bb52:
  %t222 = load i1, ptr %l124, !tbaa !21
  store i1 %t222, ptr %l112, !tbaa !21
  br label %bb53
bb53:
  %t223 = load i1, ptr %l112, !tbaa !21
  br i1 %t223, label %bb54, label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s10
  %t224 = load ptr, ptr %l15, !tbaa !29
  %t226 = getelementptr %"compiler/ast:TopIf", ptr %t224, i32 0, i32 0
  %t227 = load ptr, ptr %t226, !tbaa !29
  %t229 = icmp eq ptr %t227, null
  br i1 %t229, label %bb56, label %bb57
bb55:
  br label %bb63
bb56:
  call void @__olang_check_failed(ptr @olang_loc_39ed54cf65861a3a_83e11e15934e9cb6)
  unreachable
bb57:
  br label %bb58
bb58:
  %t231 = load ptr, ptr %l15, !tbaa !29
  %t233 = getelementptr %"compiler/ast:TopIf", ptr %t231, i32 0, i32 0
  %t234 = load ptr, ptr %t233, !tbaa !29
  %t236 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t234)
  store %"compiler/source:Span" %t236, ptr %l130
  br label %bb59
bb59:
  %t237 = load %"compiler/source:Span", ptr %l130
  store %"compiler/source:Span" %t237, ptr %l16
  %t238 = load ptr, ptr %l11, !tbaa !29
  store ptr %t238, ptr %l131, !tbaa !29
  %t239 = load i64, ptr %l10, !tbaa !24
  %t240 = getelementptr %"compiler/source:Span", ptr %l16, i32 0, i32 0
  %t241 = load i32, ptr %t240, !tbaa !23
  %t243 = sext i32 %t241 to i64
  %t244 = getelementptr %"compiler/source:Span", ptr %l16, i32 0, i32 1
  %t245 = load i32, ptr %t244, !tbaa !23
  %t247 = sext i32 %t245 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t248
  %t249 = getelementptr { i64, [3 x i64] }, ptr %t248, i32 0, i32 0
  store i64 3, ptr %t249
  %t251 = insertvalue { i64, i64, i64 } undef, i64 %t239, 0
  %t253 = insertvalue { i64, i64, i64 } %t251, i64 %t243, 1
  %t255 = insertvalue { i64, i64, i64 } %t253, i64 %t247, 2
  %t256 = getelementptr { i64, [3 x i64] }, ptr %t248, i32 0, i32 1
  store { i64, i64, i64 } %t255, ptr %t256
  %t257 = load { i64, [3 x i64] }, ptr %t248
  store { i64, [3 x i64] } %t257, ptr %l137
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t259 = load i32, ptr %l14, !tbaa !23
  %t262 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t258, i32 %t259)
  store { i64, ptr } %t262, ptr %l140
  br label %bb60
bb60:
  %t263 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t264 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTopSetCondReads(ptr %v0, ptr %s10, { i64, ptr } %t263)
  store %"compiler/msgs:Msg" %t264, ptr %l141
  br label %bb61
bb61:
  %t265 = load ptr, ptr %l131, !tbaa !29
  %t266 = load { i64, [3 x i64] }, ptr %l137
  %t267 = load %"compiler/msgs:Msg", ptr %l141
  %t268 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s10, ptr %t265, { i64, [3 x i64] } %t266, %"compiler/msgs:Msg" %t267)
  store i64 %t268, ptr %l142
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s10)
  br label %bb63
bb63:
  %t269 = load ptr, ptr %l15, !tbaa !29
  %t271 = getelementptr %"compiler/ast:TopIf", ptr %t269, i32 0, i32 2
  %t272 = load ptr, ptr %t271, !tbaa !29
  %t274 = icmp eq ptr %t272, null
  br i1 %t274, label %bb64, label %bb65
bb64:
  br label %bb71
bb65:
  br label %bb66
bb66:
  %t276 = load ptr, ptr %l15, !tbaa !29
  %t278 = getelementptr %"compiler/ast:TopIf", ptr %t276, i32 0, i32 2
  %t279 = load ptr, ptr %t278, !tbaa !29
  %t281 = icmp eq ptr %t279, null
  br i1 %t281, label %bb67, label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_39e926dc5bd50dc1_491eed70903c4c1d)
  unreachable
bb68:
  br label %bb69
bb69:
  %t283 = load ptr, ptr %l15, !tbaa !29
  %t285 = getelementptr %"compiler/ast:TopIf", ptr %t283, i32 0, i32 2
  %t286 = load ptr, ptr %t285, !tbaa !29
  store ptr %t286, ptr %l15, !tbaa !29
  br label %bb70
bb70:
  br label %bb44
bb71:
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t290 = getelementptr %"compiler/check:Checker", ptr %t288, i32 0, i32 1
  %t291 = load ptr, ptr %t290, !tbaa !29
  %t292 = load i64, ptr %l1, !tbaa !24
  %t293 = load i32, ptr %l14, !tbaa !23
  %t297 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %v0, ptr %t291, i64 %t292, i32 %t293)
  store ptr %t297, ptr %l155
  br label %bb72
bb72:
  %t298 = load ptr, ptr %l155, !tbaa !29
  %t301 = icmp eq ptr %t298, null
  br i1 %t301, label %bb73, label %bb74
bb73:
  call void @__olang_scope_close(ptr %s8)
  br label %bb89
bb74:
  br label %bb75
bb75:
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"compiler/check:Checker", ptr %t303, i32 0, i32 28
  store ptr %t305, ptr %l160, !tbaa !29
  %t306 = load i64, ptr %l1, !tbaa !24
  %t307 = load i32, ptr %l14, !tbaa !23
  %t309 = sext i32 %t307 to i64
  %t312 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s8, i64 %t306, i64 %t309)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t312, ptr %l164
  br label %bb76
bb76:
  %t313 = load ptr, ptr %l160, !tbaa !29
  %t314 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l164
  %t315 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H3cc70d507a7fc767d013b59b12ee0a99(ptr %v0, ptr %t313, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t314)
  %t316 = extractvalue { i32, i32 } %t315, 1
  %t317 = extractvalue { i32, i32 } %t315, 0
  store i32 %t317, ptr %l166
  %t318 = icmp ne i32 %t317, 0
  br i1 %t318, label %bb78, label %ok.319, !prof !99
ok.319:
  store i32 %t316, ptr %l165
  br label %bb77
bb77:
  %t320 = load i32, ptr %l165, !tbaa !23
  store i32 %t320, ptr %l158, !tbaa !23
  br label %bb80
bb78:
  br label %bb79
bb79:
  call void @__olang_ert_req_clear()
  %t321 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t321, ptr %l158, !tbaa !23
  br label %bb80
bb80:
  %t323 = load i32, ptr %l158, !tbaa !23
  store i32 %t323, ptr %l18, !tbaa !23
  %t324 = load i32, ptr %l18, !tbaa !23
  %t325 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t328 = icmp eq i32 %t324, %t325
  br i1 %t328, label %bb81, label %bb82
bb81:
  store i1 true, ptr %l171, !tbaa !21
  br label %bb84
bb82:
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t331 = load i64, ptr %l1, !tbaa !24
  %t332 = load i32, ptr %l18, !tbaa !23
  %t336 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasZero(ptr %v0, ptr %t330, i64 %t331, i32 %t332)
  store i1 %t336, ptr %l175
  br label %bb83
bb83:
  %t337 = load i1, ptr %l175, !tbaa !21
  store i1 %t337, ptr %l171, !tbaa !21
  br label %bb84
bb84:
  %t338 = load i1, ptr %l171, !tbaa !21
  br i1 %t338, label %bb85, label %bb86
bb85:
  call void @__olang_scope_close(ptr %s8)
  br label %bb89
bb86:
  br label %bb87
bb87:
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t340 = load i64, ptr %l10, !tbaa !24
  %t341 = load ptr, ptr %l2, !tbaa !29
  %t342 = load i32, ptr %l14, !tbaa !23
  %t343 = load i32, ptr %l18, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebranchesAssign(ptr %v0, ptr %v1, ptr %t339, i64 %t340, ptr %t341, i32 %t342, i32 %t343)
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s8)
  br label %bb89
bb89:
  %t349 = load i64, ptr %l13, !tbaa !24
  %t351 = add i64 %t349, 1
  store i64 %t351, ptr %l13, !tbaa !24
  br label %bb38
bb90:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeArgMet(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i1
  %l9 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutOnValue(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t13 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenMet(ptr %v0, ptr %v1, ptr %t8, ptr %t9)
  store i1 %t13, ptr %l9
  br label %bb5
bb5:
  %t14 = load i1, ptr %l9, !tbaa !21
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeWrittenAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca ptr
  %l9 = alloca { i64, [3 x i64] }
  %rv = alloca { i64, [3 x i64] }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t2)
  store ptr %t4, ptr %l4
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 1
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t14 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkAt(ptr %v0, ptr %v1, ptr %t11, i64 %t8, ptr %a1)
  store { i64, [3 x i64] } %t14, ptr %l9
  br label %bb2
bb2:
  %t15 = load { i64, [3 x i64] }, ptr %l9
  store { i64, [3 x i64] } %t15, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [3 x i64] }, ptr %rv
  ret { i64, [3 x i64] } %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  %l36 = alloca i1
  %l43 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a1, ptr %l2, !tbaa !23
  store i64 0, ptr %l3, !tbaa !24
  store i64 32, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t3 = load i64, ptr %l4, !tbaa !24
  %t4 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l5, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l16, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l16, !tbaa !24
  store i64 %t29, ptr %l13, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l13, !tbaa !24
  store i64 %t30, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t31 = load i64, ptr %l7, !tbaa !24
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  br label %bb17
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load i64, ptr %l7, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = mul i64 %t40, %t41
  %t47 = add i64 %t39, %t44
  store i64 %t47, ptr %l8, !tbaa !24
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i32, ptr %l2, !tbaa !23
  %t53 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %t49, i32 %t50)
  store i1 %t53, ptr %l36
  br label %bb11
bb11:
  %t54 = load i1, ptr %l36, !tbaa !21
  %t55 = xor i1 %t54, true
  br i1 %t55, label %bb12, label %bb13
bb12:
  %t57 = load i32, ptr %l2, !tbaa !23
  store i32 %t57, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  %t65 = load i32, ptr %l2, !tbaa !23
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t64, i32 %t65)
  store i32 %t68, ptr %l43
  br label %bb15
bb15:
  %t69 = load i32, ptr %l43, !tbaa !23
  store i32 %t69, ptr %l2, !tbaa !23
  br label %bb16
bb16:
  %t70 = load i64, ptr %l7, !tbaa !24
  %t72 = add i64 %t70, 1
  store i64 %t72, ptr %l7, !tbaa !24
  br label %bb7
bb17:
  %t74 = load i32, ptr %l2, !tbaa !23
  store i32 %t74, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueLand(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i64
  %l7 = alloca i1
  %l13 = alloca i64
  %l17 = alloca ptr
  %l19 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca i64
  %l24 = alloca %"compiler/source:Span"
  %l27 = alloca i32
  %l28 = alloca ptr
  %l31 = alloca i32
  %l32 = alloca i64
  %l33 = alloca %"compiler/check:landing"
  %l37 = alloca ptr
  %l38 = alloca ptr
  %l40 = alloca %"compiler/source:Span"
  %l43 = alloca i32
  %s2 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueExisting(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i1 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i1, ptr %l7, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l1, !tbaa !29
  store ptr %t9, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t17 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehandedOn(ptr %v0, ptr %v1, ptr %t11, ptr %t12, i1 %a3)
  store i64 %t17, ptr %l13
  br label %bb5
bb5:
  %t18 = load i64, ptr %l13, !tbaa !24
  store i64 %t18, ptr %l4, !tbaa !24
  %t19 = load i64, ptr %l4, !tbaa !24
  %t21 = icmp sge i64 %t19, 0
  br i1 %t21, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 63
  store ptr %t25, ptr %l17, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t26)
  store ptr %t28, ptr %l19
  br label %bb8
bb7:
  br label %bb16
bb8:
  %t29 = load ptr, ptr %l19, !tbaa !29
  %t31 = getelementptr %"compiler/check:frame", ptr %t29, i32 0, i32 0
  %t32 = load i64, ptr %t31, !tbaa !24
  store i64 %t32, ptr %l21, !tbaa !24
  %t33 = load i64, ptr %l4, !tbaa !24
  store i64 %t33, ptr %l22, !tbaa !24
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t34)
  store %"compiler/source:Span" %t36, ptr %l24
  br label %bb9
bb9:
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t40 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t37)
  store i32 %t40, ptr %l27
  br label %bb10
bb10:
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l28, !tbaa !29
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t45 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t42)
  store i32 %t45, ptr %l31
  br label %bb11
bb11:
  %t46 = load ptr, ptr %l28, !tbaa !29
  %t47 = load i32, ptr %l31, !tbaa !23
  %t48 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eboundMention(ptr %v0, ptr %t46, i32 %t47)
  store i64 %t48, ptr %l32
  br label %bb12
bb12:
  %t49 = load i64, ptr %l21, !tbaa !24
  %t50 = load i64, ptr %l22, !tbaa !24
  %t51 = load %"compiler/source:Span", ptr %l24
  %t52 = load i32, ptr %l27, !tbaa !23
  %t53 = load i64, ptr %l32, !tbaa !24
  %t54 = call %"compiler/check:landing" @compiler_2fcheck_3alanding_2ector(ptr %s2, i64 %t49, i64 %t50, %"compiler/source:Span" %t51, i32 %t52, i64 %t53)
  store %"compiler/check:landing" %t54, ptr %l33
  br label %bb13
bb13:
  %t55 = load ptr, ptr %l17, !tbaa !29
  %t56 = load %"compiler/check:landing", ptr %l33
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alanding_3e_2ePush_3ccompiler_2fcheck_3alanding_3e(ptr %v0, ptr %t55, %"compiler/check:landing" %t56)
  br label %bb14
bb14:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t59 = load i64, ptr %l4, !tbaa !24
  %t63 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehandOn(ptr %v0, ptr %v1, ptr %v3, ptr %t57, ptr %t58, i64 %t59)
  store ptr %t63, ptr %l37
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  %t64 = load ptr, ptr %l37, !tbaa !29
  store ptr %t64, ptr %rv
  br label %ret
bb16:
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l38, !tbaa !29
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t66)
  store %"compiler/source:Span" %t68, ptr %l40
  br label %bb17
bb17:
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t72 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t69)
  store i32 %t72, ptr %l43
  br label %bb18
bb18:
  %t74 = load ptr, ptr %l38, !tbaa !29
  %t75 = load %"compiler/source:Span", ptr %l40
  %t76 = load i32, ptr %l43, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueErr(ptr %v0, ptr %v2, ptr %t74, %"compiler/source:Span" %t75, i32 %t76, { i64, ptr } %a2)
  br label %bb19
bb19:
  %t78 = load ptr, ptr %l1, !tbaa !29
  store ptr %t78, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenRefOrVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i1
  %l16 = alloca i32
  %l19 = alloca i1
  %l20 = alloca i1
  %l25 = alloca i32
  %l28 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 4
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb18
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = icmp eq ptr %t16, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t26 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %t21, ptr %t22)
  store i32 %t26, ptr %l16
  br label %bb9
bb9:
  %t27 = load i32, ptr %l16, !tbaa !23
  store i32 %t27, ptr %l3, !tbaa !23
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l3, !tbaa !23
  %t32 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t28, i32 %t29)
  store i1 %t32, ptr %l19
  br label %bb10
bb10:
  %t33 = load i1, ptr %l19, !tbaa !21
  br i1 %t33, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb14
bb12:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  %t40 = load i32, ptr %l3, !tbaa !23
  %t43 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t43, ptr %l25
  br label %bb13
bb13:
  %t44 = load i32, ptr %l25, !range !{i32 0, i32 33}
  %t46 = trunc i64 25 to i32
  %t47 = icmp eq i32 %t44, %t46
  store i1 %t47, ptr %l20, !tbaa !21
  br label %bb14
bb14:
  %t49 = load i1, ptr %l20, !tbaa !21
  br i1 %t49, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb17
bb16:
  %t50 = load i32, ptr %l3, !tbaa !23
  %t51 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t54 = icmp eq i32 %t50, %t51
  store i1 %t54, ptr %l28, !tbaa !21
  br label %bb17
bb17:
  %t56 = load i1, ptr %l28, !tbaa !21
  store i1 %t56, ptr %rv
  br label %ret
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store i1 false, ptr %rv
  br label %ret
bb22:
  call void @__olang_check_failed(ptr @olang_loc_712f9e4ca30bc6cb_a93275977373a857)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3acollWalk_2esomeHolds(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l14 = alloca { i64, ptr }
  %l19 = alloca i1
  %l23 = alloca i1
  %l25 = alloca i1
  %l30 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb17
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l14, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i32, ptr %t19, i64 %t16
  %t21 = load i32, ptr %t20, !tbaa !33
  store i32 %t21, ptr %l6, !tbaa !23
  %t23 = load i32, ptr %l6, !tbaa !23
  %t25 = icmp ne i32 %t23, 0
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:collWalk", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t31 = load i32, ptr %l6, !tbaa !23
  %t32 = load ptr, ptr @__olang_prog_scope
  %t35 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t32, ptr %t30, i32 %t31)
  store i1 %t35, ptr %l23
  br label %bb7
bb6:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb8
bb7:
  %t36 = load i1, ptr %l23, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %l19, !tbaa !21
  br label %bb8
bb8:
  %t39 = load i1, ptr %l19, !tbaa !21
  br i1 %t39, label %bb9, label %bb10
bb9:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l6, !tbaa !23
  %t44 = add i64 %a2, 1
  %t48 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3acollWalk_2eholds(ptr %v0, ptr %t40, i32 %t41, i64 %t44)
  store i1 %t48, ptr %l30
  br label %bb11
bb10:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb12
bb11:
  %t49 = load i1, ptr %l30, !tbaa !21
  store i1 %t49, ptr %l25, !tbaa !21
  br label %bb12
bb12:
  %t50 = load i1, ptr %l25, !tbaa !21
  br i1 %t50, label %bb13, label %bb14
bb13:
  store i1 true, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t52 = load i64, ptr %l4, !tbaa !24
  %t54 = add i64 %t52, 1
  store i64 %t54, ptr %l4, !tbaa !24
  br label %bb1
bb17:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eeffectOp(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 44}
  %t3 = trunc i64 25 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb9
bb2:
  %t6 = load i32, ptr %l0, !range !{i32 0, i32 44}
  %t8 = trunc i64 26 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t11 = load i32, ptr %l0, !range !{i32 0, i32 44}
  %t13 = trunc i64 27 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb5, label %bb6
bb5:
  br label %bb9
bb6:
  %t16 = load i32, ptr %l0, !range !{i32 0, i32 44}
  %t18 = trunc i64 28 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb21
bb10:
  %t21 = load i32, ptr %l0, !range !{i32 0, i32 44}
  %t23 = trunc i64 29 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  %t26 = load i32, ptr %l0, !range !{i32 0, i32 44}
  %t28 = trunc i64 30 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_d652d3791394a9d9_f08137453595c3ad)
  unreachable
bb21:
  %t31 = load i1, ptr %l1, !tbaa !21
  store i1 %t31, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/check:signMag" @compiler_2fcheck_2emagOf(%"compiler/check:litv" %a0) #0 {
entry:
  %l0 = alloca %"compiler/check:litv"
  %l4 = alloca %"compiler/check:signMag"
  %l9 = alloca %"compiler/check:signMag"
  %l16 = alloca %"compiler/check:signMag"
  %l20 = alloca %"compiler/check:signMag"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca %"compiler/check:signMag"
  store %"compiler/check:litv" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 6
  %t2 = load i1, ptr %t1, !tbaa !21
  br i1 %t2, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t4 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 7
  %t5 = load i1, ptr %t4, !tbaa !21
  %t6 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 8
  %t7 = load i128, ptr %t6
  %t10 = call %"compiler/check:signMag" @compiler_2fcheck_3asignMag_2ector(ptr %s1, i1 %t5, i128 %t7)
  store %"compiler/check:signMag" %t10, ptr %l4
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t11 = load %"compiler/check:signMag", ptr %l4
  store %"compiler/check:signMag" %t11, ptr %rv
  br label %ret
bb4:
  %t12 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 2
  %t13 = load i1, ptr %t12, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 3
  %t16 = load i64, ptr %t15, !tbaa !24
  %t19 = zext i64 %t16 to i128
  %t21 = call %"compiler/check:signMag" @compiler_2fcheck_3asignMag_2ector(ptr %s2, i1 false, i128 %t19)
  store %"compiler/check:signMag" %t21, ptr %l9
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t22 = load %"compiler/check:signMag", ptr %l9
  store %"compiler/check:signMag" %t22, ptr %rv
  br label %ret
bb8:
  %t23 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 3
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = icmp slt i64 %t24, 0
  br i1 %t26, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t28 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 3
  %t29 = load i64, ptr %t28, !tbaa !24
  %t32 = sub i64 0, %t29
  %t34 = zext i64 %t32 to i128
  %t36 = call %"compiler/check:signMag" @compiler_2fcheck_3asignMag_2ector(ptr %s3, i1 true, i128 %t34)
  store %"compiler/check:signMag" %t36, ptr %l16
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t37 = load %"compiler/check:signMag", ptr %l16
  store %"compiler/check:signMag" %t37, ptr %rv
  br label %ret
bb12:
  %t38 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 3
  %t39 = load i64, ptr %t38, !tbaa !24
  %t42 = zext i64 %t39 to i128
  %t44 = call %"compiler/check:signMag" @compiler_2fcheck_3asignMag_2ector(ptr %s0, i1 false, i128 %t42)
  store %"compiler/check:signMag" %t44, ptr %l20
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t45 = load %"compiler/check:signMag", ptr %l20
  store %"compiler/check:signMag" %t45, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:signMag", ptr %rv
  ret %"compiler/check:signMag" %rr
}

define dso_local i1 @compiler_2fcheck_2ematchExisting(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l21 = alloca i1
  %l27 = alloca i1
  %l35 = alloca i1
  %l45 = alloca i1
  %l56 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Match", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l2, !tbaa !24
  %t11 = load i64, ptr %l3, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb16
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t18, ptr %l14, !tbaa !27
  %t19 = load i64, ptr %l2, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l4, !tbaa !29
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t28 = getelementptr %"compiler/typed:Arm", ptr %t26, i32 0, i32 4
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = icmp eq ptr %t29, null
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb5, label %bb6
bb5:
  %t35 = load ptr, ptr %l4, !tbaa !29
  %t37 = getelementptr %"compiler/typed:Arm", ptr %t35, i32 0, i32 4
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = icmp eq ptr %t38, null
  br i1 %t40, label %bb7, label %bb8
bb6:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb11
bb7:
  call void @__olang_check_failed(ptr @olang_loc_3bef89c29375057e_93446d82378ce1ba)
  unreachable
bb8:
  br label %bb9
bb9:
  %t42 = load ptr, ptr %l4, !tbaa !29
  %t44 = getelementptr %"compiler/typed:Arm", ptr %t42, i32 0, i32 4
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = call i1 @compiler_2fcheck_2eexistingValue(ptr %v0, ptr %t45)
  store i1 %t47, ptr %l27
  br label %bb10
bb10:
  %t48 = load i1, ptr %l27, !tbaa !21
  store i1 %t48, ptr %l21, !tbaa !21
  br label %bb11
bb11:
  %t49 = load i1, ptr %l21, !tbaa !21
  br i1 %t49, label %bb12, label %bb13
bb12:
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t51 = load i64, ptr %l2, !tbaa !24
  %t53 = add i64 %t51, 1
  store i64 %t53, ptr %l2, !tbaa !24
  br label %bb1
bb16:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Match", ptr %t55, i32 0, i32 2
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = icmp eq ptr %t58, null
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb17, label %bb18
bb17:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/typed:Match", ptr %t64, i32 0, i32 2
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = icmp eq ptr %t67, null
  br i1 %t69, label %bb19, label %bb20
bb18:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb22
bb19:
  call void @__olang_check_failed(ptr @olang_loc_f9ce4d996cc4e225_93403f8f2ddbd541)
  unreachable
bb20:
  br label %bb21
bb21:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/typed:Match", ptr %t71, i32 0, i32 2
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t77 = getelementptr %"compiler/typed:Arm", ptr %t74, i32 0, i32 4
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = icmp eq ptr %t78, null
  %t82 = xor i1 %t80, true
  store i1 %t82, ptr %l35, !tbaa !21
  br label %bb22
bb22:
  %t84 = load i1, ptr %l35, !tbaa !21
  br i1 %t84, label %bb23, label %bb24
bb23:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Match", ptr %t85, i32 0, i32 2
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = icmp eq ptr %t88, null
  br i1 %t90, label %bb25, label %bb26
bb24:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb32
bb25:
  call void @__olang_check_failed(ptr @olang_loc_f9ce4d996cc4e225_93403f8f2ddbd541)
  unreachable
bb26:
  br label %bb27
bb27:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Match", ptr %t92, i32 0, i32 2
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t98 = getelementptr %"compiler/typed:Arm", ptr %t95, i32 0, i32 4
  %t99 = load ptr, ptr %t98, !tbaa !29
  store ptr %t99, ptr %l5, !tbaa !29
  %t101 = load ptr, ptr %l5, !tbaa !29
  %t103 = icmp eq ptr %t101, null
  br i1 %t103, label %bb28, label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_f9ce4d996cc4e225_93403f8f2ddbd541)
  unreachable
bb29:
  br label %bb30
bb30:
  %t105 = load ptr, ptr %l5, !tbaa !29
  %t107 = call i1 @compiler_2fcheck_2eexistingValue(ptr %v0, ptr %t105)
  store i1 %t107, ptr %l56
  br label %bb31
bb31:
  %t108 = load i1, ptr %l56, !tbaa !21
  store i1 %t108, ptr %l45, !tbaa !21
  br label %bb32
bb32:
  %t109 = load i1, ptr %l45, !tbaa !21
  store i1 %t109, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2esameRead(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l44 = alloca i1
  %l47 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i1
  %l57 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t17 = load ptr, ptr %l15, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l15, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 30}
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l16, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l16, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32 }, ptr %t27, i32 0, i32 1
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l3, !tbaa !23
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t31 = load i32, ptr %l2, !tbaa !23
  %t32 = load i32, ptr %l3, !tbaa !23
  %t35 = icmp eq i32 %t31, %t32
  store i1 %t35, ptr %rv
  br label %ret
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i1 false, ptr %rv
  br label %ret
bb15:
  call void @__olang_check_failed(ptr @olang_loc_66c871427796c5ad_be34307b05f1da91)
  unreachable
bb16:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t39 = load ptr, ptr %l25, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb17, label %bb18
bb17:
  %t42 = load ptr, ptr %l25, !tbaa !29
  %t43 = load i64, ptr %t42, !range !{i64 0, i64 30}
  %t45 = icmp eq i64 %t43, 14
  store i1 %t45, ptr %l26, !tbaa !21
  br label %bb18
bb18:
  %t46 = load i1, ptr %l26, !tbaa !21
  br i1 %t46, label %bb19, label %bb20
bb19:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr { i64, [4 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t49, i32 0, i32 1
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l4, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr { i64, [4 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t55, i32 0, i32 2
  %t57 = load i32, ptr %t56
  store i32 %t57, ptr %l5, !tbaa !23
  br label %bb21
bb20:
  br label %bb36
bb21:
  %t59 = load ptr, ptr %l1, !tbaa !29
  store ptr %t59, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t60 = load ptr, ptr %l33, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb22, label %bb23
bb22:
  %t63 = load ptr, ptr %l33, !tbaa !29
  %t64 = load i64, ptr %t63, !range !{i64 0, i64 30}
  %t66 = icmp eq i64 %t64, 14
  store i1 %t66, ptr %l34, !tbaa !21
  br label %bb23
bb23:
  %t67 = load i1, ptr %l34, !tbaa !21
  br i1 %t67, label %bb24, label %bb25
bb24:
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t70, i32 0, i32 1
  %t72 = load ptr, ptr %t71
  store ptr %t72, ptr %l6, !tbaa !29
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t76, i32 0, i32 2
  %t78 = load i32, ptr %t77
  store i32 %t78, ptr %l7, !tbaa !23
  br label %bb26
bb25:
  br label %bb31
bb26:
  %t80 = load i32, ptr %l5, !tbaa !23
  %t81 = load i32, ptr %l7, !tbaa !23
  %t84 = icmp eq i32 %t80, %t81
  br i1 %t84, label %bb27, label %bb28
bb27:
  %t86 = load ptr, ptr %l4, !tbaa !29
  %t87 = load ptr, ptr %l6, !tbaa !29
  %t90 = call i1 @compiler_2fcheck_2esameRead(ptr %v0, ptr %v1, ptr %t86, ptr %t87)
  store i1 %t90, ptr %l47
  br label %bb29
bb28:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb30
bb29:
  %t91 = load i1, ptr %l47, !tbaa !21
  store i1 %t91, ptr %l44, !tbaa !21
  br label %bb30
bb30:
  %t92 = load i1, ptr %l44, !tbaa !21
  store i1 %t92, ptr %rv
  br label %ret
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  store i1 false, ptr %rv
  br label %ret
bb35:
  call void @__olang_check_failed(ptr @olang_loc_d1a78098b058e5fc_3c3cd5596d56fa00)
  unreachable
bb36:
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t95 = load ptr, ptr %l49, !tbaa !29
  %t96 = icmp ne ptr %t95, null
  br i1 %t96, label %bb37, label %bb38
bb37:
  %t98 = load ptr, ptr %l49, !tbaa !29
  %t99 = load i64, ptr %t98, !range !{i64 0, i64 30}
  %t101 = icmp eq i64 %t99, 2
  store i1 %t101, ptr %l50, !tbaa !21
  br label %bb38
bb38:
  %t102 = load i1, ptr %l50, !tbaa !21
  br i1 %t102, label %bb39, label %bb40
bb39:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr { i64, [4 x i64] }, ptr %t103, i32 0, i32 1
  %t106 = getelementptr { %"compiler/source:Span", ptr }, ptr %t105, i32 0, i32 1
  %t107 = load ptr, ptr %t106
  store ptr %t107, ptr %l8, !tbaa !29
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t109 = load ptr, ptr %l8, !tbaa !29
  %t110 = load ptr, ptr %l1, !tbaa !29
  %t113 = call i1 @compiler_2fcheck_2esameRead(ptr %v0, ptr %v1, ptr %t109, ptr %t110)
  store i1 %t113, ptr %l57
  br label %bb42
bb42:
  %t114 = load i1, ptr %l57, !tbaa !21
  store i1 %t114, ptr %rv
  br label %ret
bb43:
  br i1 true, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb47
bb46:
  store i1 false, ptr %rv
  br label %ret
bb47:
  call void @__olang_check_failed(ptr @olang_loc_e46b3fa1946bcbb7_3b47270341ec1d7b)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2estoredTarget(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v1, ptr %t16, i32 %t17, i1 true)
  br label %bb6
bb6:
  br label %bb20
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t21 = load ptr, ptr %l12, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l12, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 30}
  %t27 = icmp eq i64 %t25, 2
  store i1 %t27, ptr %l13, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l13, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", ptr }, ptr %t31, i32 0, i32 1
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t35 = load ptr, ptr %l3, !tbaa !29
  %t36 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredTarget(ptr %v0, ptr %v1, ptr %t35, ptr %t36)
  br label %bb13
bb13:
  br label %bb20
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t39, ptr %t41)
  br label %bb18
bb18:
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_67e8dc6b8789e10d_d8389ade20250951)
  unreachable
bb20:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fcheck_2etextBytes(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %lp1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l8 = alloca i64
  %l19 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l8, !tbaa !24
  %t4 = load i64, ptr %l8, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l8, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  %t12 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t12, ptr %lp1
  %t14 = load ptr, ptr %lp1
  store { i64, ptr } %t11, ptr %t14, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t15, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  store i64 %t19, ptr %l4, !tbaa !24
  br label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_7873eed4a01e5678_b9c164dc568d47a4)
  unreachable
bb3:
  %t21 = load i64, ptr %l3, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = icmp slt i64 %t21, %t22
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb4, label %bb5
bb4:
  br label %bb8
bb5:
  br label %bb6
bb6:
  %t29 = load i64, ptr %l3, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t31, ptr %l19, !tbaa !27
  %t32 = load i64, ptr %l3, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr i8, ptr %t35, i64 %t32
  %t37 = load i8, ptr %t36, !tbaa !32
  %t43 = load ptr, ptr %lp1
  %t45 = getelementptr { i64, ptr }, ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr i8, ptr %t46, i64 %t29
  store i8 %t37, ptr %t47, !tbaa !32
  br label %bb7
bb7:
  %t48 = load i64, ptr %l3, !tbaa !24
  %t50 = add i64 %t48, 1
  store i64 %t50, ptr %l3, !tbaa !24
  br label %bb3
bb8:
  %t52 = load ptr, ptr %lp1
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  store { i64, ptr } %t53, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcheck_3ab5aWalk_2ector(ptr %out, ptr %v0, i64 %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l10 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l14 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l15 = alloca %"compiler/check:b5aWalk"
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a0, ptr %l1, !tbaa !24
  %t3 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l10
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t4, ptr %l2
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l11
  br label %bb2
bb2:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l3
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l12
  br label %bb3
bb3:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l4
  %t9 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t9, ptr %l13
  br label %bb4
bb4:
  %t10 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l13
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t10, ptr %l5
  %t11 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t11, ptr %l14
  br label %bb5
bb5:
  %t12 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l14
  %t13 = getelementptr %"compiler/check:b5aWalk", ptr %l15, i32 0, i32 0
  %t14 = load i64, ptr %l1, !tbaa !24
  store i64 %t14, ptr %t13, !tbaa !24
  %t15 = getelementptr %"compiler/check:b5aWalk", ptr %l15, i32 0, i32 1
  %t16 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l2
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t16, ptr %t15
  %t17 = getelementptr %"compiler/check:b5aWalk", ptr %l15, i32 0, i32 2
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %t17
  %t19 = getelementptr %"compiler/check:b5aWalk", ptr %l15, i32 0, i32 3
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %t19
  %t21 = getelementptr %"compiler/check:b5aWalk", ptr %l15, i32 0, i32 4
  %t22 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l5
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t22, ptr %t21
  %t23 = getelementptr %"compiler/check:b5aWalk", ptr %l15, i32 0, i32 5
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t12, ptr %t23
  %t25 = getelementptr %"compiler/check:b5aWalk", ptr %l15, i32 0, i32 6
  store i1 false, ptr %t25, !tbaa !21
  %t27 = getelementptr %"compiler/check:b5aWalk", ptr %l15, i32 0, i32 7
  store i1 false, ptr %t27, !tbaa !21
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l15, i64 296, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/check:elemsShape" @compiler_2fcheck_3aelemsShape_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %rv = alloca %"compiler/check:elemsShape"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/check:elemsShape" undef, { i64, ptr } %a0, 0
  %t8 = insertvalue %"compiler/check:elemsShape" %t6, i64 %a1, 1
  store %"compiler/check:elemsShape" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:elemsShape", ptr %rv
  ret %"compiler/check:elemsShape" %rr
}

define dso_local %"compiler/check:roFn" @compiler_2fcheck_3aroFn_2ector(ptr %v0, ptr %v1, i64 %a0, i64 %a1, { i64, [3 x i64] } %a2, { i64, ptr } %a3) #0 {
entry:
  %rv = alloca %"compiler/check:roFn"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/check:roFn" undef, i64 %a0, 0
  %t12 = insertvalue %"compiler/check:roFn" %t10, i64 %a1, 1
  %t14 = insertvalue %"compiler/check:roFn" %t12, { i64, [3 x i64] } %a2, 2
  %t16 = insertvalue %"compiler/check:roFn" %t14, { i64, ptr } %a3, 3
  store %"compiler/check:roFn" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:roFn", ptr %rv
  ret %"compiler/check:roFn" %rr
}

declare void @__olang_ert_req_clear()
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr void @olang_2eHelperKind_2eCopy_2ecompiler_2feffects_3aEffects(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/effects:Effects"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l17 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l33 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l35 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l37 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l39 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 1008, i1 false)
  %t2 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 1
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e(ptr %v0, ptr %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t6 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  %t7 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 2
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t11 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %t11
  %t12 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 3
  %t14 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e(ptr %v0, ptr %t12)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l7
  br label %bb3
bb3:
  %t15 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t16 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %t16
  %t17 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 4
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_3e(ptr %v0, ptr %t17)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l9
  br label %bb4
bb4:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  %t21 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %t21
  %t22 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 5
  %t24 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t22)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l11
  br label %bb5
bb5:
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  %t26 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %t26
  %t27 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 6
  %t29 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t27)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %l13
  br label %bb6
bb6:
  %t30 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  %t31 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %t31
  %t32 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 7
  %t34 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0, ptr %t32)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t34, ptr %l15
  br label %bb7
bb7:
  %t35 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l15
  %t36 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 7
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t35, ptr %t36
  %t37 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 8
  %t39 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feffects_3apair_2c_20Bool_3e(ptr %v0, ptr %t37)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t39, ptr %l17
  br label %bb8
bb8:
  %t40 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l17
  %t41 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 8
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t40, ptr %t41
  %t42 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 9
  %t44 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t42)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %l19
  br label %bb9
bb9:
  %t45 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  %t46 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %t46
  %t47 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 10
  %t49 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t47)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %l21
  br label %bb10
bb10:
  %t50 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  %t51 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t50, ptr %t51
  %t52 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 11
  %t54 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cBool_3e(ptr %v0, ptr %t52)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t54, ptr %l23
  br label %bb11
bb11:
  %t55 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  %t56 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t55, ptr %t56
  %t57 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 12
  %t59 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t57)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t59, ptr %l25
  br label %bb12
bb12:
  %t60 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  %t61 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t60, ptr %t61
  %t62 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 15
  %t64 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t62)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t64, ptr %l27
  br label %bb13
bb13:
  %t65 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  %t66 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t65, ptr %t66
  %t67 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 16
  %t69 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e(ptr %v0, ptr %t67)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t69, ptr %l29
  br label %bb14
bb14:
  %t70 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  %t71 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t70, ptr %t71
  %t72 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 17
  %t74 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0, ptr %t72)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t74, ptr %l31
  br label %bb15
bb15:
  %t75 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l31
  %t76 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 17
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t75, ptr %t76
  %t77 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 18
  %t79 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0, ptr %t77)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t79, ptr %l33
  br label %bb16
bb16:
  %t80 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l33
  %t81 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 18
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t80, ptr %t81
  %t82 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 19
  %t84 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0, ptr %t82)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t84, ptr %l35
  br label %bb17
bb17:
  %t85 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l35
  %t86 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 19
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t85, ptr %t86
  %t87 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 20
  %t89 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0, ptr %t87)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t89, ptr %l37
  br label %bb18
bb18:
  %t90 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l37
  %t91 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 20
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t90, ptr %t91
  %t92 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 24
  %t94 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %v0, ptr %t92)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t94, ptr %l39
  br label %bb19
bb19:
  %t95 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l39
  %t96 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 24
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t95, ptr %t96
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 1008, i1 false)
  br label %ret
ret:
  ret void
}

define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare void @__olang_check_failed(ptr) cold noreturn
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d0 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@__olang_empty_array = external constant [16 x i64]
@.d1 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"a binding in a call compared as a value (S13d)" }>, align 8
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d3 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
declare ptr @llvm.coro.promise(ptr, i32, i1)
@.d5 = private constant <{ i64, [63 x i8] }> <{ i64 0, [63 x i8] c"it reads a mutable global, whose value is the running program's" }>, align 8
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"?" }>, align 8
@.d7 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"?" }>, align 8
@.d8 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"At" }>, align 8
@.d9 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'['" }>, align 8
@.d10 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"fn" }>, align 8
@.d11 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"fn?&" }>, align 8
@.d12 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d13 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d14 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"module " }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d15 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d16 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c" - declare 'fn (x " }>, align 8
@.d17 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c") Pow(y E) " }>, align 8
@.d18 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d19 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"case" }>, align 8
@.d20 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"parameter" }>, align 8
@.d21 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"result" }>, align 8
@.d22 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"Of" }>, align 8
@.d23 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"its Name and Type" }>, align 8
@.d24 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'s " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d25 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"true" }>, align 8
@.d26 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"false" }>, align 8
@.d27 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"the result" }>, align 8
@.d28 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c"several values returned where one is the result" }>, align 8
@.d29 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c"a count of returned values other than the result's" }>, align 8
@.d30 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"a result" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 4
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d31 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d32 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"nothing" }>, align 8
@.d33 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d34 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"what its body can fail with" }>, align 8
@.d35 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"noreturn" }>, align 8
@.d36 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d37 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d38 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d39 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"any " }>, align 8
@.d40 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Array<" }>, align 8
@.d41 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"..." }>, align 8
@.d42 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"mut " }>, align 8
@.d43 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"?&" }>, align 8
@.d44 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"&" }>, align 8
@.d45 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"?&" }>, align 8
@.d46 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"&" }>, align 8
@.d47 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"fn?&(" }>, align 8
@.d48 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"fn&(" }>, align 8
@.d49 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d50 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d51 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d52 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" ?" }>, align 8
@.d53 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d54 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d55 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d56 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d57 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"enum {" }>, align 8
@.d58 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d59 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d60 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d61 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" }" }>, align 8
@.d62 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"nothing" }>, align 8
@.d63 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 80
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 80
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = mul i64 %t24, 8
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l7, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = mul i64 %t33, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t36 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = mul i64 %t41, 8
  %t43 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l10, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = mul i64 %t50, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t53 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feffects_3apair_2c_20Bool_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 24
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 24
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = mul i64 %t24, 8
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l7, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = mul i64 %t33, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t36 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = mul i64 %t41, 8
  %t43 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l10, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = mul i64 %t50, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t53 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cBool_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 24
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 24
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = mul i64 %t24, 8
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l7, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = mul i64 %t33, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t36 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = mul i64 %t41, 8
  %t43 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l10, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = mul i64 %t50, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t53 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = mul i64 %t24, 8
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l7, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = mul i64 %t33, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t36 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = mul i64 %t41, 8
  %t43 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l10, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = mul i64 %t50, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t53 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
define linkonce_odr { i64, ptr } @olang_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 32
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t14, i64 %t12
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t15)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t22, i64 %t20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define linkonce_odr { i64, ptr } @olang_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 32
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t14, i64 %t12
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e(ptr %v0, ptr %t15)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t22, i64 %t20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2feffects_3aEffects_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
@olang_loc_76d1a478b1ca441c_29a7b400711a77a8 = external constant [0 x i8]
declare %"compiler/generic:Unmet" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMissing(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i1 %a3, i64 %a4)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emembersWritten(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/text:StringBuilder" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ememberListing(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyNotMember(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/msgs:Msg" %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyUnmetMethod(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteOtherSignature(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, %"compiler/msgs:Msg" %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyUnmet(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunArrayEnds(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyAs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, ptr %a4)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_30630aa0385ef6ff_761547ceb2a660b3 = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_383f9ac3750cc0fe_a676b835dd8ab732 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsAsNotEnum(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAsNeedsCase(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrongCase(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailOp(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/source:Span" %a2, i1 %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAsNothing(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_d7812add9a78f336_89874a21e94d300a = external constant [0 x i8]
declare %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, i64 %a1, { i64, ptr } %a2, ptr %a3, i32 %a4, i32 %a5, i1 %a6)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_ca088269e212954c_d643913a2551dac8 = external constant [0 x i8]
declare %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2, i1 %a3, i1 %a4)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckedInst(ptr %v0, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceOrigin(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ementions(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnique(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoCase(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
@olang_loc_1ea07ba70e71bd73_64b4b6dffcea6d07 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
@olang_loc_be381b70f49fc8f2_3328b3c24d360da6 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eToArray_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTest(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4)
declare %"compiler/generic:Desc" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseDesc(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2fgeneric_2eDescCase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCase(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eand2(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3)
@olang_loc_82b73da87554a50f_4f07d83e7e807a5b = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCtorVarOfGeneric(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" @compiler_2fgeneric_2eFieldDecls.walk(ptr %v0, ptr %v1, ptr %a0)
declare { i32, ptr } @std_2fprelude_2fiterator_2estd_2fprelude_2fiterator_3aViewGenerator_3ccompiler_2fast_3aV_Hf179e857cb72c72900f4614cd5df5a25(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCtorGenericInferredField(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordIn(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCtorFieldNamesVar(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
@olang_loc_7351608f8313d577_54e294ea81fa84bb = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edataLength(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_3ca681ba130ec9b7_181dd48ce58d3c73 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eleaves(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrsChecked(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
@olang_loc_e375dcd56c8db7ae_8ebec7f18eafef7a = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyAttrs(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
@olang_loc_f43f80063d96068c_f8dacab5994fea88 = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamed(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_f558fce6a2b003e7_933c1b66dd113bdb = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2fgeneric_2eWrittenMut(ptr %v0, ptr %a0)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultNotComputable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
@olang_loc_5535019c26f71449_86439f2d3bbcfbb5 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrItemPath(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrWordPath(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtComparedToCaught(ptr %v0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrCompareItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eLen_H4b13e48b0a317e727dbe35330ad8712a(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLen_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eLen__H3cdfcddd9c493bd8bcefc7b766e0438b(ptr %v0, ptr %a0)
declare %"compiler/check:factsMark" @compiler_2fcheck_3afactsMark_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_a78beee7b0d01a06_c23e8f3cd3901b22 = external constant [0 x i8]
@olang_loc_a9ac84188a5d3ced_8a30b05829c2589 = external constant [0 x i8]
@olang_loc_d343f6dbe85f33a0_61dfe5c423c7544c = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrsCover(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_b9703f47e3d93663_9ebf3615d73f11ff = external constant [0 x i8]
@olang_loc_1d4c1b6caa485862_a69bc63913ecdbfe = external constant [0 x i8]
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_6c69e074d5382e65_c76aefb5b106fb41 = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_862846f5a5002b51_69e64f75e4a124a5 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eSetAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayLit(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3)
declare %"compiler/check:reflList" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflInt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"compiler/check:reflVal" @compiler_2fcheck_2enoRefl(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflIndexNotConst(ptr %v0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistItem(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/check:reflList" %a2, i64 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueElem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, { i64, ptr } %a4)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebracketIn(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5)
@olang_loc_23e55da1d35c3b26_9d147ecacbf30ffa = external constant [0 x i8]
@olang_loc_2136f99ca1795ebb_470e73d5134ce74f = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, ptr } %a7)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoIndex(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, i64 %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelemPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3, i32 %a4)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesIn(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i64 %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esameRepr(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritableAt(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_9eba0537152ec68c_48ed4257e6d07438 = external constant [0 x i8]
@olang_loc_cd7c953a3f1af3d1_dcd21a8e35cf56dd = external constant [0 x i8]
declare i1 @compiler_2fcheck_2erefWrittenTop(ptr %v0, ptr %a0)
declare i1 @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eIsFunc(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowOwner(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_cd94e6a5e488a5b1_e9066543c2d4a76d = external constant [0 x i8]
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eReopen(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushFacts(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2, i64 %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %a0)
declare %"compiler/check:narrowed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eAt_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecaseDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCNoForm(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %a0)
declare %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %a0)
declare void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eHint(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotInModule(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimplSig(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aModules(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eorderModule(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowMethod(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2ePowNone(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_40ba663ddc86f216_8a32628f26d9e82 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@olang_loc_e2e10646092ca22b_113878b4617d7337 = external constant [0 x i8]
declare void @compiler_2fcheck_3aframe_2ector(ptr %out, ptr %v0, i64 %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_Hc321aad2e90dd8996307445942f8d6e9(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %a0)
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:SiteInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aSiteInfo_3e_2eAt_3ccompiler_2ftyped_3aSiteInfo_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fgeneric_2eDescField = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eDescParam = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflDescNoMember(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflOfArgs(ptr %v0, i64 %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullRead(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflOfType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescType(ptr %v0, ptr %v1, ptr %a0, %"compiler/generic:Desc" %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescName(ptr %v0, ptr %v1, ptr %a0, %"compiler/generic:Desc" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eFieldOfEnum(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflFold(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@G_2ecompiler_2fcheck_2eRvText = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eRvInt = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eRvBool = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleadWord(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
@olang_loc_af27478d58ae9a15_461e52858b358fe1 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecurInst(ptr %v0, ptr %a0)
declare %"compiler/generic:Origin" @compiler_2fgeneric_3aOrigin_2ector(ptr %v0, i64 %a0, %"compiler/source:Span" %a1, i64 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenMet(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnInTest(ptr %v0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnInCtor(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnInNoreturn(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskClauseReturns(ptr %v0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emsgOwner(ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertMsgReturns(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeferReturns(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenReturnValue(ptr %v0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenEnd(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferReturn(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnNeedsValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnValueInVoid(ptr %v0)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresultAt(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRefResult(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2fcheck_2eRoReturned = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i64 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eretLand(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroBorrowedFrom(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H9a57a0a969606bc6b56c6db08d26f577(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, ptr %a4, i64 %a5)
@olang_loc_8771b1e868207559_9b4adf6aba3e467d = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCopied(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
@olang_loc_5b70aeb4dcee2d2_fdbe62f0939a6ff6 = external constant [0 x i8]
@olang_loc_51f82334067145c7_15912fbf1ec70a8b = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1, i1 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aUnread_3e_2eLen_3ccompiler_2fnames_3aUnread_3e(ptr %v0, ptr %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edestructs(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H190b78e3c1eec037529224679e114a85(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i1 %a2)
declare %"compiler/names:Unread" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aUnread_3e_2eAt_3ccompiler_2fnames_3aUnread_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLocalUnusedBare(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorAlone(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLocalUnused(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fcheck_2eprimName(ptr %v0, i32 %a0)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2equalifierFor(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsRaisedError(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espellArgs(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValName(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eSpread = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNullable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eDefaultErrT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFuncTag(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFuncNullable(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espellList(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i32 %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeFields(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_150065cf715feb7f_967c08b33fa11dcb = external constant [0 x i8]
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_acadf2af31b93e38_18751a402ed16b84 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
@olang_loc_ddf5999d75afc0ea_2c71428eb0b518ce = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewriteBack(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4, %"compiler/source:Span" %a5, i64 %a6, { i64, ptr } %a7)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotCapture(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estepMethod(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, i1 %a4)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eStepNotNumber(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2efloatBits(i32 %a0, double %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5, i1 %a6, i32 %a7)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2fgeneric_3aContext_2ector(ptr %out, ptr %v0, i64 %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootStmts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %a0)
@olang_loc_ec59a5f60fda0dc9_336029f9ba6be385 = external constant [0 x i8]
@olang_loc_6b4c91049558e776_f5788538a01eee7a = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopSetDecls(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, i1 %a3, i1 %a4, ptr %a5)
@olang_loc_812bc6763f016bdd_ce6f0e3f96c00d01 = external constant [0 x i8]
@olang_loc_8d628e20c33cf608_43e2c14925cb83cc = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2fcheck_2echainNames(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_90c8334c62802427_4400025bac92e03b = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econdReads(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3)
@olang_loc_39ed54cf65861a3a_83e11e15934e9cb6 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTopSetCondReads(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
@olang_loc_39e926dc5bd50dc1_491eed70903c4c1d = external constant [0 x i8]
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H3cc70d507a7fc767d013b59b12ee0a99(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasZero(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebranchesAssign(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i32 %a3, i32 %a4)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutOnValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueExisting(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehandedOn(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
declare %"compiler/check:landing" @compiler_2fcheck_3alanding_2ector(ptr %v0, i64 %a0, i64 %a1, %"compiler/source:Span" %a2, i32 %a3, i64 %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alanding_3e_2ePush_3ccompiler_2fcheck_3alanding_3e(ptr %v0, ptr %a0, %"compiler/check:landing" %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehandOn(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueErr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3)
@olang_loc_712f9e4ca30bc6cb_a93275977373a857 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3acollWalk_2eholds(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_d652d3791394a9d9_f08137453595c3ad = external constant [0 x i8]
declare %"compiler/check:signMag" @compiler_2fcheck_3asignMag_2ector(ptr %v0, i1 %a0, i128 %a1)
@olang_loc_3bef89c29375057e_93446d82378ce1ba = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eexistingValue(ptr %v0, ptr %a0)
@olang_loc_f9ce4d996cc4e225_93403f8f2ddbd541 = external constant [0 x i8]
@olang_loc_66c871427796c5ad_be34307b05f1da91 = external constant [0 x i8]
@olang_loc_d1a78098b058e5fc_3c3cd5596d56fa00 = external constant [0 x i8]
@olang_loc_e46b3fa1946bcbb7_3b47270341ec1d7b = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v0, ptr %a0, i32 %a1, i1 %a2)
declare void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_67e8dc6b8789e10d_d8389ade20250951 = external constant [0 x i8]
@olang_loc_7873eed4a01e5678_b9c164dc568d47a4 = external constant [0 x i8]
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
