; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i64, i1, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, i64, i64, i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/text:StringBuilder", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i32, i64, i64, i64, i1, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", i64, i1 }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1 }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/check:ownerAt" = type { i32, i1 }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr } }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/check:errBind" = type { i32, i64, i32, %"compiler/source:Span" }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i32, %"compiler/source:Span" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr }, ptr, i32 }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, ptr, i1, i1 }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, { i64, ptr }, i1 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/check:fieldSet" = type { { i64, ptr }, i32, { i64, ptr }, { i64, ptr } }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, { i64, ptr }, i32, i1 }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr, { i64, ptr } }
%"compiler/check:reflList" = type { i1, i32, i64, i64 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/check:laneNode" = type { i64, i32, %"compiler/source:Span", %"compiler/source:Span", i64, i64, i64, ptr, i32, i64, i32 }
%"compiler/generic:AnySlot" = type { i32, i32, i64, i64, i1, i32 }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/generic:Binding" = type { i64, i64, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1, i1, i1, i128 }
%"compiler/check:signMag" = type { i1, i128 }
%"compiler/check:rawTable" = type { i32, i1, { i64, ptr }, { i64, ptr } }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr, { i64, ptr } }
%"compiler/generic:Desc" = type { i64, i32, i64, i64 }
%"compiler/check:seqOf" = type { i32, i64, i64, i64 }
%"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" = type { ptr, i64 }
%"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" = type { i32, i64 }
%"compiler/load:Import" = type { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, { i64, ptr }, i64, i64, { i64, ptr }, %"compiler/source:Span" }
%"compiler/names:Entry" = type { i32, %"compiler/source:Span", i32, i1, ptr }
%"compiler/msgs:Nearest" = type { { i64, ptr }, { i64, ptr }, i64 }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/names:Table" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/generic:Unmet" = type { i64, i32, i32, i1, i1, i1 }
%"compiler/check:typeCase" = type { i1, i1, i32, i64, i64, i1 }
%"compiler/ast:Compr" = type { ptr, ptr, i32, i32, ptr, ptr, i1, i64 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/check:fixedInit" = type { ptr, i32 }
%"compiler/check:roFn" = type { i64, i64, { i64, [3 x i64] }, { i64, ptr } }
%"compiler/check:setAt" = type { ptr, i64, { i64, ptr }, { i64, ptr }, %"compiler/source:Span", i32 }
define dso_local i1 @compiler_2fcheck_2ebadSeparator(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l33 = alloca { i64, ptr }
  %l39 = alloca i1
  %l46 = alloca { i64, ptr }
  %l50 = alloca i1
  %l52 = alloca i1
  %l53 = alloca { i64, ptr }
  %l57 = alloca i1
  %l60 = alloca { i64, ptr }
  %l64 = alloca i1
  %l66 = alloca i1
  %l67 = alloca { i64, ptr }
  %l71 = alloca i1
  %l76 = alloca i1
  %l77 = alloca { i64, ptr }
  %l82 = alloca i1
  %l83 = alloca { i64, ptr }
  %l88 = alloca i1
  %l91 = alloca i1
  %l92 = alloca { i64, ptr }
  %l97 = alloca i1
  %l98 = alloca { i64, ptr }
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load i64, ptr %l1, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l12, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l2, !tbaa !24
  %t16 = load i64, ptr %l1, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l15, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l15, !tbaa !24
  store i64 %t31, ptr %l12, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l12, !tbaa !24
  store i64 %t32, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb7
bb7:
  %t33 = load i64, ptr %l5, !tbaa !24
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb55
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l1, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = load i64, ptr %l3, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l6, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t51, ptr %l33, !tbaa !27
  %t52 = load i64, ptr %l6, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i8, ptr %t55, i64 %t52
  %t57 = load i8, ptr %t56, !tbaa !32
  %t59 = icmp ne i8 %t57, 95
  br i1 %t59, label %bb11, label %bb12
bb11:
  br label %bb54
bb12:
  br label %bb13
bb13:
  %t61 = load i64, ptr %l6, !tbaa !24
  %t63 = icmp eq i64 %t61, 0
  br i1 %t63, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb16
bb15:
  %t65 = load i64, ptr %l6, !tbaa !24
  %t67 = add i64 %t65, 1
  %t68 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t73 = icmp sge i64 %t67, %t70
  store i1 %t73, ptr %l39, !tbaa !21
  br label %bb16
bb16:
  %t75 = load i1, ptr %l39, !tbaa !21
  br i1 %t75, label %bb17, label %bb18
bb17:
  store i1 true, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t77 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t77, ptr %l46, !tbaa !27
  %t78 = load i64, ptr %l6, !tbaa !24
  %t80 = sub i64 %t78, 1
  %t82 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr i8, ptr %t83, i64 %t80
  %t85 = load i8, ptr %t84, !tbaa !32
  %t87 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t85)
  store i1 %t87, ptr %l50
  br label %bb20
bb20:
  %t88 = load i1, ptr %l50, !tbaa !21
  %t89 = xor i1 %t88, true
  br i1 %t89, label %bb21, label %bb22
bb21:
  %t91 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t91, ptr %l53, !tbaa !27
  %t92 = load i64, ptr %l6, !tbaa !24
  %t94 = sub i64 %t92, 1
  %t96 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr i8, ptr %t97, i64 %t94
  %t99 = load i8, ptr %t98, !tbaa !32
  %t101 = call i1 @compiler_2fcheck_2eisHexDigit(i8 %t99)
  store i1 %t101, ptr %l57
  br label %bb23
bb22:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb24
bb23:
  %t102 = load i1, ptr %l57, !tbaa !21
  %t103 = xor i1 %t102, true
  store i1 %t103, ptr %l52, !tbaa !21
  br label %bb24
bb24:
  %t105 = load i1, ptr %l52, !tbaa !21
  br i1 %t105, label %bb25, label %bb26
bb25:
  store i1 true, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t107 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t107, ptr %l60, !tbaa !27
  %t108 = load i64, ptr %l6, !tbaa !24
  %t110 = add i64 %t108, 1
  %t112 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr i8, ptr %t113, i64 %t110
  %t115 = load i8, ptr %t114, !tbaa !32
  %t117 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t115)
  store i1 %t117, ptr %l64
  br label %bb28
bb28:
  %t118 = load i1, ptr %l64, !tbaa !21
  %t119 = xor i1 %t118, true
  br i1 %t119, label %bb29, label %bb30
bb29:
  %t121 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t121, ptr %l67, !tbaa !27
  %t122 = load i64, ptr %l6, !tbaa !24
  %t124 = add i64 %t122, 1
  %t126 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr i8, ptr %t127, i64 %t124
  %t129 = load i8, ptr %t128, !tbaa !32
  %t131 = call i1 @compiler_2fcheck_2eisHexDigit(i8 %t129)
  store i1 %t131, ptr %l71
  br label %bb31
bb30:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb32
bb31:
  %t132 = load i1, ptr %l71, !tbaa !21
  %t133 = xor i1 %t132, true
  store i1 %t133, ptr %l66, !tbaa !21
  br label %bb32
bb32:
  %t135 = load i1, ptr %l66, !tbaa !21
  br i1 %t135, label %bb33, label %bb34
bb33:
  store i1 true, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t137 = load i64, ptr %l6, !tbaa !24
  %t139 = icmp sge i64 %t137, 2
  br i1 %t139, label %bb36, label %bb37
bb36:
  %t141 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t141, ptr %l77, !tbaa !27
  %t142 = load i64, ptr %l6, !tbaa !24
  %t144 = sub i64 %t142, 1
  %t146 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr i8, ptr %t147, i64 %t144
  %t149 = load i8, ptr %t148, !tbaa !32
  %t151 = icmp eq i8 %t149, 120
  store i1 %t151, ptr %l76, !tbaa !21
  br label %bb38
bb37:
  store i1 false, ptr %l76, !tbaa !21
  br label %bb38
bb38:
  %t153 = load i1, ptr %l76, !tbaa !21
  br i1 %t153, label %bb39, label %bb40
bb39:
  %t154 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t154, ptr %l83, !tbaa !27
  %t155 = load i64, ptr %l6, !tbaa !24
  %t157 = sub i64 %t155, 2
  %t159 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr i8, ptr %t160, i64 %t157
  %t162 = load i8, ptr %t161, !tbaa !32
  %t164 = icmp eq i8 %t162, 48
  store i1 %t164, ptr %l82, !tbaa !21
  br label %bb41
bb40:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb41
bb41:
  %t166 = load i1, ptr %l82, !tbaa !21
  br i1 %t166, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l88, !tbaa !21
  br label %bb50
bb43:
  %t167 = load i64, ptr %l6, !tbaa !24
  %t169 = icmp sge i64 %t167, 2
  br i1 %t169, label %bb44, label %bb45
bb44:
  %t171 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t171, ptr %l92, !tbaa !27
  %t172 = load i64, ptr %l6, !tbaa !24
  %t174 = sub i64 %t172, 1
  %t176 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr i8, ptr %t177, i64 %t174
  %t179 = load i8, ptr %t178, !tbaa !32
  %t181 = icmp eq i8 %t179, 98
  store i1 %t181, ptr %l91, !tbaa !21
  br label %bb46
bb45:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb46
bb46:
  %t183 = load i1, ptr %l91, !tbaa !21
  br i1 %t183, label %bb47, label %bb48
bb47:
  %t184 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t184, ptr %l98, !tbaa !27
  %t185 = load i64, ptr %l6, !tbaa !24
  %t187 = sub i64 %t185, 2
  %t189 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !27
  %t191 = getelementptr i8, ptr %t190, i64 %t187
  %t192 = load i8, ptr %t191, !tbaa !32
  %t194 = icmp eq i8 %t192, 48
  store i1 %t194, ptr %l97, !tbaa !21
  br label %bb49
bb48:
  store i1 false, ptr %l97, !tbaa !21
  br label %bb49
bb49:
  %t196 = load i1, ptr %l97, !tbaa !21
  store i1 %t196, ptr %l88, !tbaa !21
  br label %bb50
bb50:
  %t197 = load i1, ptr %l88, !tbaa !21
  br i1 %t197, label %bb51, label %bb52
bb51:
  store i1 true, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t199 = load i64, ptr %l5, !tbaa !24
  %t201 = add i64 %t199, 1
  store i64 %t201, ptr %l5, !tbaa !24
  br label %bb7
bb55:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ebuiltAst(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l25 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %l36 = alloca i1
  %l38 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca i1
  %l52 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t11 = load ptr, ptr %l10, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l10, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 30}
  %t17 = icmp eq i64 %t15, 20
  store i1 %t17, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l11, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t20 = load ptr, ptr %l14, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l14, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 30}
  %t26 = icmp eq i64 %t24, 14
  store i1 %t26, ptr %l15, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l15, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb47
bb14:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t29 = load ptr, ptr %l18, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb15, label %bb16
bb15:
  %t32 = load ptr, ptr %l18, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 30}
  %t35 = icmp eq i64 %t33, 2
  store i1 %t35, ptr %l19, !tbaa !21
  br label %bb16
bb16:
  %t36 = load i1, ptr %l19, !tbaa !21
  br i1 %t36, label %bb17, label %bb18
bb17:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", ptr }, ptr %t39, i32 0, i32 1
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l1, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = call i1 @compiler_2fcheck_2ebuiltAst(ptr %v0, ptr %t43)
  store i1 %t45, ptr %l25
  br label %bb20
bb20:
  %t46 = load i1, ptr %l25, !tbaa !21
  store i1 %t46, ptr %l5, !tbaa !21
  br label %bb47
bb21:
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t48 = load ptr, ptr %l26, !tbaa !29
  %t49 = icmp ne ptr %t48, null
  br i1 %t49, label %bb22, label %bb23
bb22:
  %t51 = load ptr, ptr %l26, !tbaa !29
  %t52 = load i64, ptr %t51, !range !{i64 0, i64 30}
  %t54 = icmp eq i64 %t52, 3
  store i1 %t54, ptr %l27, !tbaa !21
  br label %bb23
bb23:
  %t55 = load i1, ptr %l27, !tbaa !21
  br i1 %t55, label %bb24, label %bb25
bb24:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr { i64, [4 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t58, i32 0, i32 1
  %t60 = load i32, ptr %t59, !range !{i32 0, i32 98}
  store i32 %t60, ptr %l2
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr { i64, [4 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t64, i32 0, i32 2
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l3, !tbaa !29
  br label %bb26
bb25:
  br label %bb31
bb26:
  %t68 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t70 = trunc i64 53 to i32
  %t71 = icmp eq i32 %t68, %t70
  br i1 %t71, label %bb27, label %bb28
bb27:
  %t73 = load ptr, ptr %l3, !tbaa !29
  %t75 = call i1 @compiler_2fcheck_2ebuiltAst(ptr %v0, ptr %t73)
  store i1 %t75, ptr %l38
  br label %bb29
bb28:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb30
bb29:
  %t76 = load i1, ptr %l38, !tbaa !21
  store i1 %t76, ptr %l36, !tbaa !21
  br label %bb30
bb30:
  %t77 = load i1, ptr %l36, !tbaa !21
  store i1 %t77, ptr %l5, !tbaa !21
  br label %bb47
bb31:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t79 = load ptr, ptr %l39, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb32, label %bb33
bb32:
  %t82 = load ptr, ptr %l39, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 30}
  %t85 = icmp eq i64 %t83, 12
  store i1 %t85, ptr %l40, !tbaa !21
  br label %bb33
bb33:
  %t86 = load i1, ptr %l40, !tbaa !21
  br i1 %t86, label %bb34, label %bb35
bb34:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t89, i32 0, i32 2
  %t91 = load { i64, ptr }, ptr %t90
  store { i64, ptr } %t91, ptr %l4, !tbaa !27
  br label %bb40
bb35:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t94 = load ptr, ptr %l45, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb36, label %bb37
bb36:
  %t97 = load ptr, ptr %l45, !tbaa !29
  %t98 = load i64, ptr %t97, !range !{i64 0, i64 30}
  %t100 = icmp eq i64 %t98, 17
  store i1 %t100, ptr %l46, !tbaa !21
  br label %bb37
bb37:
  %t101 = load i1, ptr %l46, !tbaa !21
  br i1 %t101, label %bb38, label %bb39
bb38:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr { i64, [4 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t104, i32 0, i32 2
  %t106 = load { i64, ptr }, ptr %t105
  store { i64, ptr } %t106, ptr %l4, !tbaa !27
  br label %bb40
bb39:
  br label %bb42
bb40:
  %t108 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t110 = call i1 @compiler_2fcheck_2eallBuilt(ptr %v0, { i64, ptr } %t108)
  store i1 %t110, ptr %l52
  br label %bb41
bb41:
  %t111 = load i1, ptr %l52, !tbaa !21
  store i1 %t111, ptr %l5, !tbaa !21
  br label %bb47
bb42:
  br i1 true, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_195b5efb383c41db_4fe01bc12efac86f)
  unreachable
bb47:
  %t112 = load i1, ptr %l5, !tbaa !21
  store i1 %t112, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eGlobalType(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l6 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t7 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalType(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
  store i32 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load i32, ptr %l6, !tbaa !23
  store i32 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eallWords(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordCount(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sge i64 %t7, 64
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = sub i64 0, 1
  store i64 %t11, ptr %l8, !tbaa !65
  br label %bb4
bb3:
  %t13 = load i64, ptr %l2, !tbaa !24
  store i64 %t13, ptr %l10, !tbaa !24
  %t14 = load i64, ptr %l10, !tbaa !24
  %t15 = load i64, ptr %l10, !tbaa !24
  %t16 = shl i64 1, %t15
  %t18 = sub i64 %t16, 1
  store i64 %t18, ptr %l8, !tbaa !65
  br label %bb4
bb4:
  %t20 = load i64, ptr %l8, !tbaa !65
  store i64 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayMake(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3, i32 %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i64
  %l13 = alloca { i64, [3 x i64] }
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i1
  %l17 = alloca { i64, [3 x i64] }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i32
  %l20 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca ptr
  %l30 = alloca i32
  %l33 = alloca i32
  %l38 = alloca i1
  %l41 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca i32
  %l48 = alloca i1
  %l51 = alloca ptr
  %l54 = alloca i32
  %l55 = alloca i32
  %l60 = alloca ptr
  %l62 = alloca ptr
  %l65 = alloca { i64, ptr }
  %l68 = alloca i32
  %l73 = alloca i32
  %l76 = alloca i1
  %l81 = alloca i64
  %l83 = alloca ptr
  %l84 = alloca { i64, ptr }
  %l86 = alloca %"compiler/source:Span"
  %l91 = alloca i64
  %l92 = alloca %"compiler/diagmsg:Msg"
  %l93 = alloca i64
  %l100 = alloca i32
  %l103 = alloca i64
  %l114 = alloca ptr
  %l117 = alloca { i64, ptr }
  %l120 = alloca ptr
  %l125 = alloca i1
  %l127 = alloca ptr
  %l129 = alloca ptr
  %l130 = alloca { i64, ptr }
  %l132 = alloca %"compiler/source:Span"
  %l134 = alloca i1
  %l135 = alloca ptr
  %l136 = alloca { i64, ptr }
  %l138 = alloca %"compiler/source:Span"
  %l147 = alloca ptr
  %l149 = alloca ptr
  %l151 = alloca ptr
  %l152 = alloca { i64, ptr }
  %l153 = alloca ptr
  %l155 = alloca i32
  %l156 = alloca i32
  %l161 = alloca i32
  %l164 = alloca i1
  %l169 = alloca i64
  %l177 = alloca i1
  %l180 = alloca i1
  %l182 = alloca ptr
  %l186 = alloca ptr
  %l193 = alloca i1
  %l196 = alloca i1
  %l198 = alloca ptr
  %l202 = alloca ptr
  %l208 = alloca ptr
  %l214 = alloca { i64, ptr }
  %l218 = alloca i1
  %l222 = alloca i1
  %l225 = alloca ptr
  %l230 = alloca i32
  %l231 = alloca i32
  %l236 = alloca %"compiler/source:Span"
  %l237 = alloca i32
  %l238 = alloca i32
  %l239 = alloca { i64, ptr }
  %l241 = alloca ptr
  %l245 = alloca i32
  %l248 = alloca %"compiler/typed:Make"
  %s2 = alloca %olang.scope
  %rv = alloca ptr
  %t185 = alloca { i64, [3 x i64] }, align 8
  %t324 = alloca { i64, [3 x i64] }, align 8
  %t472 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i32 %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l21, !tbaa !29
  %t2 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t2, ptr %l22, !tbaa !27
  %t3 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !27
  %t5 = getelementptr ptr, ptr %t4, i64 0
  %t6 = load ptr, ptr %t5, !tbaa !39
  store ptr %t6, ptr %l23, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t7)
  store i32 %t9, ptr %l25
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l21, !tbaa !29
  %t11 = load ptr, ptr %l23, !tbaa !29
  %t12 = load i32, ptr %l25, !tbaa !23
  %t13 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %v3, ptr %t10, ptr %t11, i32 %t12)
  store ptr %t13, ptr %l26
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l26, !tbaa !29
  store ptr %t14, ptr %l6, !tbaa !29
  store i32 0, ptr %l7, !tbaa !23
  %t15 = load i32, ptr %l4, !tbaa !23
  %t16 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t19 = icmp ne i32 %t15, %t16
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l4, !tbaa !23
  %t25 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l33
  br label %bb5
bb4:
  %t26 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t26, ptr %l30, !tbaa !23
  br label %bb6
bb5:
  %t28 = load i32, ptr %l33, !tbaa !23
  store i32 %t28, ptr %l30, !tbaa !23
  br label %bb6
bb6:
  %t29 = load i32, ptr %l30, !tbaa !23
  store i32 %t29, ptr %l8, !tbaa !23
  %t30 = load i32, ptr %l8, !tbaa !23
  %t31 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t34 = icmp ne i32 %t30, %t31
  br i1 %t34, label %bb7, label %bb8
bb7:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = getelementptr %"compiler/generic:Program", ptr %t39, i32 0, i32 2
  store ptr %t41, ptr %l41, !tbaa !29
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l8, !tbaa !23
  %t46 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t42, i32 %t43)
  store i32 %t46, ptr %l44
  br label %bb9
bb8:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb11
bb9:
  %t47 = load ptr, ptr %l41, !tbaa !29
  %t48 = load i32, ptr %l44, !tbaa !23
  %t49 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t49, ptr %l45
  br label %bb10
bb10:
  %t50 = load i32, ptr %l45, !range !{i32 0, i32 33}
  %t52 = trunc i64 19 to i32
  %t53 = icmp eq i32 %t50, %t52
  store i1 %t53, ptr %l38, !tbaa !21
  br label %bb11
bb11:
  %t55 = load i1, ptr %l38, !tbaa !21
  br i1 %t55, label %bb12, label %bb13
bb12:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  store ptr %t61, ptr %l51, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i32, ptr %l8, !tbaa !23
  %t66 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t62, i32 %t63)
  store i32 %t66, ptr %l54
  br label %bb14
bb13:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb16
bb14:
  %t67 = load ptr, ptr %l51, !tbaa !29
  %t68 = load i32, ptr %l54, !tbaa !23
  %t69 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t67, i32 %t68)
  store i32 %t69, ptr %l55
  br label %bb15
bb15:
  %t70 = load i32, ptr %l55, !tbaa !23
  %t71 = icmp eq i32 %t70, 0
  store i1 %t71, ptr %l48, !tbaa !21
  br label %bb16
bb16:
  %t73 = load i1, ptr %l48, !tbaa !21
  %t76 = xor i1 %t73, true
  br i1 %t76, label %bb17, label %bb18
bb17:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/check:Checker", ptr %t78, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !29
  store ptr %t81, ptr %l60, !tbaa !29
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t82)
  store ptr %t84, ptr %l62
  br label %bb19
bb18:
  br label %bb33
bb19:
  %t85 = load ptr, ptr %l62, !tbaa !29
  %t87 = getelementptr %"compiler/check:frame", ptr %t85, i32 0, i32 4
  %t88 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t88, ptr %l65, !tbaa !27
  %t89 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr ptr, ptr %t90, i64 0
  %t92 = load ptr, ptr %t91, !tbaa !39
  %t94 = load ptr, ptr %l60, !tbaa !29
  %t97 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFoldLength(ptr %v0, ptr %v0, ptr %v1, ptr %t94, ptr %t87, ptr %t92)
  store i32 %t97, ptr %l68
  br label %bb20
bb20:
  %t98 = load i32, ptr %l68, !tbaa !23
  store i32 %t98, ptr %l10, !tbaa !23
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = getelementptr %"compiler/generic:Program", ptr %t102, i32 0, i32 2
  %t105 = load i32, ptr %l10, !tbaa !23
  %t108 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t104, i32 %t105)
  store i32 %t108, ptr %l73
  br label %bb21
bb21:
  %t109 = load i32, ptr %l73, !range !{i32 0, i32 33}
  %t111 = trunc i64 26 to i32
  %t112 = icmp eq i32 %t109, %t111
  br i1 %t112, label %bb22, label %bb23
bb22:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/check:Checker", ptr %t114, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t119 = getelementptr %"compiler/generic:Program", ptr %t117, i32 0, i32 2
  %t120 = load i32, ptr %l10, !tbaa !23
  %t123 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t119, i32 %t120)
  store i64 %t123, ptr %l81
  br label %bb24
bb23:
  store i1 false, ptr %l76, !tbaa !21
  br label %bb25
bb24:
  %t124 = load i64, ptr %l81, !tbaa !24
  %t125 = icmp slt i64 %t124, 0
  store i1 %t125, ptr %l76, !tbaa !21
  br label %bb25
bb25:
  %t127 = load i1, ptr %l76, !tbaa !21
  br i1 %t127, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s2
  %t128 = load ptr, ptr %l0, !tbaa !29
  store ptr %t128, ptr %l83, !tbaa !29
  %t129 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t129, ptr %l84, !tbaa !27
  %t130 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr ptr, ptr %t131, i64 0
  %t133 = load ptr, ptr %t132, !tbaa !39
  %t135 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t133)
  store %"compiler/source:Span" %t135, ptr %l86
  br label %bb28
bb27:
  %t136 = load i32, ptr %l10, !tbaa !23
  store i32 %t136, ptr %l7, !tbaa !23
  br label %bb32
bb28:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/check:Checker", ptr %t138, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t143 = getelementptr %"compiler/generic:Program", ptr %t141, i32 0, i32 2
  %t144 = load i32, ptr %l10, !tbaa !23
  %t147 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t143, i32 %t144)
  store i64 %t147, ptr %l91
  br label %bb29
bb29:
  %t148 = load i64, ptr %l91, !tbaa !24
  %t149 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArrayLengthRange(ptr %s2, i64 %t148)
  store %"compiler/diagmsg:Msg" %t149, ptr %l92
  br label %bb30
bb30:
  %t150 = load ptr, ptr %l83, !tbaa !29
  %t151 = load %"compiler/source:Span", ptr %l86
  %t152 = load %"compiler/diagmsg:Msg", ptr %l92
  %t153 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t150, %"compiler/source:Span" %t151, %"compiler/diagmsg:Msg" %t152)
  store i64 %t153, ptr %l93
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/check:Checker", ptr %t154, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = getelementptr %"compiler/generic:Program", ptr %t157, i32 0, i32 2
  %t160 = load i32, ptr %l2, !tbaa !23
  %t161 = load i32, ptr %l7, !tbaa !23
  %t165 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t159, i32 %t160, i32 %t161)
  store i32 %t165, ptr %l100
  br label %bb34
bb34:
  %t166 = load i32, ptr %l100, !tbaa !23
  store i32 %t166, ptr %l11, !tbaa !23
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/check:Checker", ptr %t167, i32 0, i32 36
  %t171 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t169)
  store i64 %t171, ptr %l103
  br label %bb35
bb35:
  %t172 = load i64, ptr %l103, !tbaa !24
  store i64 %t172, ptr %l12, !tbaa !24
  %t173 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t175 = extractvalue { i64, ptr } %t173, 0
  %t177 = icmp eq i64 %t175, 2
  br i1 %t177, label %bb36, label %bb37
bb36:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t179, i32 0, i32 13
  %t182 = load { i64, [3 x i64] }, ptr %t181
  store { i64, [3 x i64] } %t182, ptr %l13
  %t184 = load ptr, ptr %l0, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t185
  %t186 = getelementptr { i64, [3 x i64] }, ptr %t185, i32 0, i32 0
  store i64 0, ptr %t186
  %t187 = load { i64, [3 x i64] }, ptr %t185
  %t190 = getelementptr %"compiler/check:Checker", ptr %t184, i32 0, i32 13
  store { i64, [3 x i64] } %t187, ptr %t190
  %t191 = load ptr, ptr %l5, !tbaa !29
  %t193 = icmp eq ptr %t191, null
  %t195 = xor i1 %t193, true
  br i1 %t195, label %bb38, label %bb39
bb37:
  br label %bb51
bb38:
  %t197 = load ptr, ptr %l5, !tbaa !29
  store ptr %t197, ptr %l114, !tbaa !29
  br label %bb41
bb39:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t200, ptr %l117, !tbaa !27
  %t201 = getelementptr { i64, ptr }, ptr %l117, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !27
  %t203 = getelementptr ptr, ptr %t202, i64 1
  %t204 = load ptr, ptr %t203, !tbaa !39
  %t205 = load i32, ptr %l2, !tbaa !23
  %t209 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %v2, ptr %t199, ptr %t204, i32 %t205)
  store ptr %t209, ptr %l120
  br label %bb40
bb40:
  %t210 = load ptr, ptr %l120, !tbaa !29
  store ptr %t210, ptr %l114, !tbaa !29
  br label %bb41
bb41:
  %t211 = load ptr, ptr %l114, !tbaa !29
  store ptr %t211, ptr %l14, !tbaa !29
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load { i64, [3 x i64] }, ptr %l13
  %t216 = getelementptr %"compiler/check:Checker", ptr %t212, i32 0, i32 13
  store { i64, [3 x i64] } %t213, ptr %t216
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load i32, ptr %l2, !tbaa !23
  %t221 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t217, i32 %t218)
  store i1 %t221, ptr %l125
  br label %bb42
bb42:
  %t222 = load i1, ptr %l125, !tbaa !21
  %t223 = xor i1 %t222, true
  br i1 %t223, label %bb43, label %bb44
bb43:
  %t225 = load ptr, ptr %l0, !tbaa !29
  store ptr %t225, ptr %l127, !tbaa !29
  %t226 = load ptr, ptr %l14, !tbaa !29
  store ptr %t226, ptr %l129, !tbaa !29
  %t228 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t228, ptr %l130, !tbaa !27
  %t229 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t230 = load ptr, ptr %t229, !tbaa !27
  %t231 = getelementptr ptr, ptr %t230, i64 1
  %t232 = load ptr, ptr %t231, !tbaa !39
  %t234 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t232)
  store %"compiler/source:Span" %t234, ptr %l132
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t235 = load i64, ptr @G_2ecompiler_2fcheck_2eRoStored, !tbaa !24
  %t236 = load ptr, ptr %l127, !tbaa !29
  %t237 = load ptr, ptr %l129, !tbaa !29
  %t238 = load %"compiler/source:Span", ptr %l132
  %t240 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v2, ptr %t236, ptr %t237, %"compiler/source:Span" %t238, i64 %t235)
  store i1 %t240, ptr %l134
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t241 = load ptr, ptr %l0, !tbaa !29
  store ptr %t241, ptr %l135, !tbaa !29
  %t242 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t242, ptr %l136, !tbaa !27
  %t243 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !27
  %t245 = getelementptr ptr, ptr %t244, i64 1
  %t246 = load ptr, ptr %t245, !tbaa !39
  %t248 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t246)
  store %"compiler/source:Span" %t248, ptr %l138
  br label %bb48
bb48:
  %t249 = load i32, ptr %l2, !tbaa !23
  %t250 = load ptr, ptr %l135, !tbaa !29
  %t251 = load %"compiler/source:Span", ptr %l138
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueFill(ptr %v0, ptr %t250, %"compiler/source:Span" %t251, i32 %t249)
  br label %bb49
bb49:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/check:Checker", ptr %t253, i32 0, i32 36
  %t256 = load ptr, ptr %l14, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v2, ptr %t255, ptr %t256)
  br label %bb50
bb50:
  br label %bb51
bb51:
  %t259 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t261 = extractvalue { i64, ptr } %t259, 0
  %t263 = icmp eq i64 %t261, 1
  br i1 %t263, label %bb52, label %bb53
bb52:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t267 = getelementptr %"compiler/check:Checker", ptr %t265, i32 0, i32 1
  %t268 = load ptr, ptr %t267, !tbaa !29
  store ptr %t268, ptr %l147, !tbaa !29
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t269)
  store ptr %t271, ptr %l149
  br label %bb54
bb53:
  br label %bb85
bb54:
  %t272 = load ptr, ptr %l149, !tbaa !29
  %t274 = getelementptr %"compiler/check:frame", ptr %t272, i32 0, i32 4
  store ptr %t274, ptr %l151, !tbaa !29
  %t275 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t275, ptr %l152, !tbaa !27
  %t276 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !27
  %t278 = getelementptr ptr, ptr %t277, i64 0
  %t279 = load ptr, ptr %t278, !tbaa !39
  store ptr %t279, ptr %l153, !tbaa !29
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t280)
  store i32 %t282, ptr %l155
  br label %bb55
bb55:
  %t283 = load ptr, ptr %l147, !tbaa !29
  %t284 = load ptr, ptr %l151, !tbaa !29
  %t285 = load ptr, ptr %l153, !tbaa !29
  %t286 = load i32, ptr %l155, !tbaa !23
  %t287 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFoldKnown(ptr %v0, ptr %v0, ptr %v1, ptr %t283, ptr %t284, ptr %t285, i32 %t286)
  store i32 %t287, ptr %l156
  br label %bb56
bb56:
  %t288 = load i32, ptr %l156, !tbaa !23
  store i32 %t288, ptr %l15, !tbaa !23
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t291 = getelementptr %"compiler/check:Checker", ptr %t289, i32 0, i32 1
  %t292 = load ptr, ptr %t291, !tbaa !29
  %t294 = getelementptr %"compiler/generic:Program", ptr %t292, i32 0, i32 2
  %t295 = load i32, ptr %l15, !tbaa !23
  %t298 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t294, i32 %t295)
  store i32 %t298, ptr %l161
  br label %bb57
bb57:
  %t299 = load i32, ptr %l161, !range !{i32 0, i32 33}
  %t301 = trunc i64 26 to i32
  %t302 = icmp eq i32 %t299, %t301
  br i1 %t302, label %bb58, label %bb59
bb58:
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t306 = getelementptr %"compiler/check:Checker", ptr %t304, i32 0, i32 1
  %t307 = load ptr, ptr %t306, !tbaa !29
  %t309 = getelementptr %"compiler/generic:Program", ptr %t307, i32 0, i32 2
  %t310 = load i32, ptr %l15, !tbaa !23
  %t313 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t309, i32 %t310)
  store i64 %t313, ptr %l169
  br label %bb60
bb59:
  store i1 false, ptr %l164, !tbaa !21
  br label %bb61
bb60:
  %t314 = load i64, ptr %l169, !tbaa !24
  %t315 = icmp eq i64 %t314, 0
  store i1 %t315, ptr %l164, !tbaa !21
  br label %bb61
bb61:
  %t317 = load i1, ptr %l164, !tbaa !21
  store i1 %t317, ptr %l16, !tbaa !21
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t320 = getelementptr %"compiler/check:Checker", ptr %t318, i32 0, i32 13
  %t321 = load { i64, [3 x i64] }, ptr %t320
  store { i64, [3 x i64] } %t321, ptr %l17
  %t323 = load ptr, ptr %l0, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t324
  %t325 = getelementptr { i64, [3 x i64] }, ptr %t324, i32 0, i32 0
  store i64 0, ptr %t325
  %t326 = load { i64, [3 x i64] }, ptr %t324
  %t329 = getelementptr %"compiler/check:Checker", ptr %t323, i32 0, i32 13
  store { i64, [3 x i64] } %t326, ptr %t329
  %t330 = load i1, ptr %l16, !tbaa !21
  %t332 = xor i1 %t330, true
  br i1 %t332, label %bb62, label %bb63
bb62:
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t335 = load i32, ptr %l2, !tbaa !23
  %t338 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezeroCalls(ptr %v0, ptr %t334, i32 %t335)
  store i1 %t338, ptr %l180
  br label %bb64
bb63:
  store i1 false, ptr %l177, !tbaa !21
  br label %bb65
bb64:
  %t339 = load i1, ptr %l180, !tbaa !21
  store i1 %t339, ptr %l177, !tbaa !21
  br label %bb65
bb65:
  %t340 = load i1, ptr %l177, !tbaa !21
  br i1 %t340, label %bb66, label %bb67
bb66:
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t343 = getelementptr %"compiler/check:Checker", ptr %t341, i32 0, i32 36
  store ptr %t343, ptr %l182, !tbaa !29
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t345 = load %"compiler/source:Span", ptr %l1
  %t346 = load i32, ptr %l2, !tbaa !23
  %t350 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %v0, ptr %t344, %"compiler/source:Span" %t345, i32 %t346)
  store ptr %t350, ptr %l186
  br label %bb68
bb67:
  %t351 = load i1, ptr %l16, !tbaa !21
  %t353 = xor i1 %t351, true
  br i1 %t353, label %bb71, label %bb72
bb68:
  %t355 = load ptr, ptr %l182, !tbaa !29
  %t356 = load ptr, ptr %l186, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t355, ptr %t356)
  br label %bb69
bb69:
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t358 = load %"compiler/source:Span", ptr %l1
  %t359 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2easkValue(ptr %v0, ptr %v0, ptr %t357, i32 2, %"compiler/source:Span" %t358, i32 %t359, ptr null)
  br label %bb70
bb70:
  br label %bb84
bb71:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t365 = load i32, ptr %l2, !tbaa !23
  %t368 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullableArray(ptr %v0, ptr %t364, i32 %t365)
  store i1 %t368, ptr %l196
  br label %bb73
bb72:
  store i1 false, ptr %l193, !tbaa !21
  br label %bb74
bb73:
  %t369 = load i1, ptr %l196, !tbaa !21
  store i1 %t369, ptr %l193, !tbaa !21
  br label %bb74
bb74:
  %t370 = load i1, ptr %l193, !tbaa !21
  br i1 %t370, label %bb75, label %bb76
bb75:
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t373 = getelementptr %"compiler/check:Checker", ptr %t371, i32 0, i32 36
  store ptr %t373, ptr %l198, !tbaa !29
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t375 = load %"compiler/source:Span", ptr %l1
  %t376 = load i32, ptr %l2, !tbaa !23
  %t380 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullOf(ptr %v0, ptr %v0, ptr %t374, %"compiler/source:Span" %t375, i32 %t376)
  store ptr %t380, ptr %l202
  br label %bb77
bb76:
  %t381 = load i1, ptr %l16, !tbaa !21
  %t383 = xor i1 %t381, true
  br i1 %t383, label %bb79, label %bb80
bb77:
  %t385 = load ptr, ptr %l198, !tbaa !29
  %t386 = load ptr, ptr %l202, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t385, ptr %t386)
  br label %bb78
bb78:
  br label %bb83
bb79:
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t388 = load %"compiler/source:Span", ptr %l1
  %t389 = load i32, ptr %l2, !tbaa !23
  %t393 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %v0, ptr %t387, %"compiler/source:Span" %t388, i32 %t389)
  store ptr %t393, ptr %l208
  br label %bb81
bb80:
  br label %bb82
bb81:
  br label %bb82
bb82:
  br label %bb83
bb83:
  br label %bb84
bb84:
  %t394 = load ptr, ptr %l0, !tbaa !29
  %t395 = load { i64, [3 x i64] }, ptr %l17
  %t398 = getelementptr %"compiler/check:Checker", ptr %t394, i32 0, i32 13
  store { i64, [3 x i64] } %t395, ptr %t398
  br label %bb85
bb85:
  %t399 = load ptr, ptr %l0, !tbaa !29
  %t401 = getelementptr %"compiler/check:Checker", ptr %t399, i32 0, i32 36
  %t402 = load i64, ptr %l12, !tbaa !24
  %t405 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v3, ptr %t401, i64 %t402)
  store { i64, ptr } %t405, ptr %l214
  br label %bb86
bb86:
  %t406 = load { i64, ptr }, ptr %l214, !tbaa !27
  store { i64, ptr } %t406, ptr %l18, !tbaa !27
  store i32 1, ptr %l19
  %t408 = load ptr, ptr %l0, !tbaa !29
  %t410 = getelementptr %"compiler/check:Checker", ptr %t408, i32 0, i32 117
  %t411 = load i1, ptr %t410, !tbaa !21
  br i1 %t411, label %bb87, label %bb88
bb87:
  %t413 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t415 = extractvalue { i64, ptr } %t413, 0
  %t417 = icmp eq i64 %t415, 1
  store i1 %t417, ptr %l218, !tbaa !21
  br label %bb89
bb88:
  store i1 false, ptr %l218, !tbaa !21
  br label %bb89
bb89:
  %t419 = load i1, ptr %l218, !tbaa !21
  br i1 %t419, label %bb90, label %bb91
bb90:
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t422 = getelementptr %"compiler/check:Checker", ptr %t420, i32 0, i32 1
  %t423 = load ptr, ptr %t422, !tbaa !29
  %t425 = getelementptr %"compiler/generic:Program", ptr %t423, i32 0, i32 2
  store ptr %t425, ptr %l225, !tbaa !29
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t428 = getelementptr %"compiler/check:Checker", ptr %t426, i32 0, i32 1
  %t429 = load ptr, ptr %t428, !tbaa !29
  %t431 = getelementptr %"compiler/generic:Program", ptr %t429, i32 0, i32 2
  %t432 = load i32, ptr %l2, !tbaa !23
  %t435 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t431, i32 %t432)
  store i32 %t435, ptr %l230
  br label %bb92
bb91:
  store i1 false, ptr %l222, !tbaa !21
  br label %bb94
bb92:
  %t436 = load ptr, ptr %l225, !tbaa !29
  %t437 = load i32, ptr %l230, !tbaa !23
  %t438 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t436, i32 %t437)
  store i32 %t438, ptr %l231
  br label %bb93
bb93:
  %t439 = load i32, ptr %l231, !range !{i32 0, i32 33}
  %t441 = trunc i64 19 to i32
  %t442 = icmp eq i32 %t439, %t441
  %t444 = xor i1 %t442, true
  store i1 %t444, ptr %l222, !tbaa !21
  br label %bb94
bb94:
  %t446 = load i1, ptr %l222, !tbaa !21
  store i1 %t446, ptr %l20, !tbaa !21
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t449 = getelementptr %"compiler/check:Checker", ptr %t447, i32 0, i32 117
  store i1 false, ptr %t449, !tbaa !21
  %t450 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t450, ptr %l236
  %t451 = load i32, ptr %l11, !tbaa !23
  store i32 %t451, ptr %l237, !tbaa !23
  store i32 3, ptr %l238
  %t452 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t452, ptr %l239, !tbaa !27
  %t453 = load ptr, ptr %l6, !tbaa !29
  store ptr %t453, ptr %l241, !tbaa !29
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t456 = load %"compiler/source:Span", ptr %l1
  %t460 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t455, i32 1, %"compiler/source:Span" %t456)
  store i32 %t460, ptr %l245
  br label %bb95
bb95:
  %t461 = load i32, ptr %l19, !range !{i32 0, i32 3}
  %t462 = load i1, ptr %l20, !tbaa !21
  %t463 = load i32, ptr %l238, !range !{i32 0, i32 5}
  %t464 = load { i64, ptr }, ptr %l239, !tbaa !27
  %t465 = load ptr, ptr %l241, !tbaa !29
  %t466 = load i32, ptr %l245, !tbaa !23
  %t469 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v3, ptr %v3, ptr %v3, i32 %t463, i64 0, { i64, ptr } %t464, ptr %t465, i32 %t466, i32 %t461, i1 %t462)
  store %"compiler/typed:Make" %t469, ptr %l248
  br label %bb96
bb96:
  %t470 = load %"compiler/typed:Make", ptr %l248
  %t471 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 56, i64 8)
  store %"compiler/typed:Make" %t470, ptr %t471
  store { i64, [5 x i64] } zeroinitializer, ptr %t472
  %t473 = getelementptr { i64, [5 x i64] }, ptr %t472, i32 0, i32 0
  store i64 7, ptr %t473
  %t474 = load %"compiler/source:Span", ptr %l236
  %t475 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t474, 0
  %t476 = load i32, ptr %l237, !tbaa !23
  %t477 = insertvalue { %"compiler/source:Span", i32, ptr } %t475, i32 %t476, 1
  %t479 = insertvalue { %"compiler/source:Span", i32, ptr } %t477, ptr %t471, 2
  %t480 = getelementptr { i64, [5 x i64] }, ptr %t472, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t479, ptr %t480
  %t481 = load { i64, [5 x i64] }, ptr %t472
  %t483 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store { i64, [5 x i64] } %t481, ptr %t483
  store ptr %t483, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t6 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t2, i32 %a1)
  store i32 %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t8 = load i32, ptr %l6, !tbaa !23
  %t9 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t9, ptr %l7
  br label %bb2
bb2:
  %t10 = load i32, ptr %l7, !tbaa !23
  store i32 %t10, ptr %l2, !tbaa !23
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 2
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t16, i32 %t17)
  store i32 %t20, ptr %l12
  br label %bb3
bb3:
  %t21 = load i32, ptr %l12, !range !{i32 0, i32 33}
  %t23 = trunc i64 19 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb4, label %bb5
bb4:
  %t26 = load i32, ptr %l2, !tbaa !23
  store i32 %t26, ptr %l15, !tbaa !23
  br label %bb6
bb5:
  %t28 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t28, ptr %l15, !tbaa !23
  br label %bb6
bb6:
  %t30 = load i32, ptr %l15, !tbaa !23
  store i32 %t30, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l8 = alloca ptr
  %l11 = alloca i64
  %l14 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l38 = alloca %"compiler/source:Span"
  %l41 = alloca i32
  %l43 = alloca ptr
  %l47 = alloca %"compiler/typed:Try"
  %rv = alloca ptr
  %t90 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l8
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l8, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 28
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l11
  br label %bb2
bb2:
  %t10 = load i64, ptr %l11, !tbaa !24
  store i64 %t10, ptr %l3, !tbaa !24
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = getelementptr %"compiler/check:frame", ptr %t11, i32 0, i32 16
  %t14 = load i64, ptr %t13, !tbaa !24
  store i64 %t14, ptr %l4, !tbaa !24
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %l14, !tbaa !29
  %t17 = load ptr, ptr %l14, !tbaa !29
  %t18 = getelementptr %"compiler/check:frame", ptr %t17, i32 0, i32 15
  %t19 = load i64, ptr %t18, !tbaa !24
  %t21 = add i64 %t19, 1
  %t23 = load ptr, ptr %l14, !tbaa !29
  %t24 = getelementptr %"compiler/check:frame", ptr %t23, i32 0, i32 15
  store i64 %t21, ptr %t24, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t32 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t25, ptr %t26, i32 %t28)
  store ptr %t32, ptr %l21
  br label %bb3
bb3:
  %t33 = load ptr, ptr %l21, !tbaa !29
  store ptr %t33, ptr %l5, !tbaa !29
  %t34 = load ptr, ptr %l2, !tbaa !29
  store ptr %t34, ptr %l22, !tbaa !29
  %t35 = load ptr, ptr %l22, !tbaa !29
  %t36 = getelementptr %"compiler/check:frame", ptr %t35, i32 0, i32 15
  %t37 = load i64, ptr %t36, !tbaa !24
  %t39 = sub i64 %t37, 1
  %t41 = load ptr, ptr %l22, !tbaa !29
  %t42 = getelementptr %"compiler/check:frame", ptr %t41, i32 0, i32 15
  store i64 %t39, ptr %t42, !tbaa !24
  %t43 = load ptr, ptr %l2, !tbaa !29
  %t45 = getelementptr %"compiler/check:frame", ptr %t43, i32 0, i32 16
  %t46 = load i64, ptr %t45, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = icmp ne i64 %t46, %t47
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t53 = load i64, ptr %l4, !tbaa !24
  %t56 = getelementptr %"compiler/check:frame", ptr %t52, i32 0, i32 16
  store i64 %t53, ptr %t56, !tbaa !24
  %t59 = xor i1 %t50, true
  br i1 %t59, label %bb4, label %bb5
bb4:
  %t61 = load ptr, ptr %l5, !tbaa !29
  store ptr %t61, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t63 = load ptr, ptr %l2, !tbaa !29
  %t65 = getelementptr %"compiler/check:frame", ptr %t63, i32 0, i32 28
  %t66 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t65, i64 %t66)
  br label %bb7
bb7:
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t71 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t69)
  store %"compiler/source:Span" %t71, ptr %l38
  br label %bb8
bb8:
  %t72 = load ptr, ptr %l5, !tbaa !29
  %t75 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t72)
  store i32 %t75, ptr %l41
  br label %bb9
bb9:
  %t76 = load ptr, ptr %l5, !tbaa !29
  store ptr %t76, ptr %l43, !tbaa !29
  %t78 = icmp sge i64 0, 0
  br i1 %t78, label %bb10, label %bb11
bb10:
  %t80 = icmp sle i64 0, 1152921504606846975
  br i1 %t80, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_ca088269e212954c_d643913a2551dac8)
  unreachable
bb12:
  %t82 = mul i64 0, 8
  %t83 = insertvalue { i64, ptr } undef, i64 0, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t85 = load ptr, ptr %l43, !tbaa !29
  %t87 = call %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %t85, { i64, ptr } %t84, i1 true, i1 false, i1 true)
  store %"compiler/typed:Try" %t87, ptr %l47
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_ca088269e212954c_d643913a2551dac8)
  unreachable
bb14:
  %t88 = load %"compiler/typed:Try", ptr %l47
  %t89 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"compiler/typed:Try" %t88, ptr %t89
  store { i64, [5 x i64] } zeroinitializer, ptr %t90
  %t91 = getelementptr { i64, [5 x i64] }, ptr %t90, i32 0, i32 0
  store i64 14, ptr %t91
  %t92 = load %"compiler/source:Span", ptr %l38
  %t93 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t92, 0
  %t94 = load i32, ptr %l41, !tbaa !23
  %t95 = insertvalue { %"compiler/source:Span", i32, ptr } %t93, i32 %t94, 1
  %t97 = insertvalue { %"compiler/source:Span", i32, ptr } %t95, ptr %t89, 2
  %t98 = getelementptr { i64, [5 x i64] }, ptr %t90, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t97, ptr %t98
  %t99 = load { i64, [5 x i64] }, ptr %t90
  %t101 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t99, ptr %t101
  store ptr %t101, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindPattern(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, i32 %a4, ptr %a5, i64 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca { i64, [3 x i64] }
  %l10 = alloca ptr
  %l14 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca i1
  %l22 = alloca i1
  %l25 = alloca i1
  %l29 = alloca i32
  %l32 = alloca i64
  %l35 = alloca i1
  %l37 = alloca ptr
  %l41 = alloca %"compiler/typed:Local"
  %l46 = alloca i1
  %l48 = alloca ptr
  %l52 = alloca %"compiler/typed:Local"
  %l62 = alloca i64
  %l65 = alloca { i64, [3 x i64] }
  %l70 = alloca ptr
  %l77 = alloca ptr
  %l79 = alloca ptr
  %l83 = alloca %"compiler/typed:Local"
  %l86 = alloca i1
  %l88 = alloca i1
  %l100 = alloca ptr
  %l105 = alloca %"compiler/typed:Bind"
  %l110 = alloca ptr
  %rv = alloca ptr
  %t91 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t3 = load %"compiler/source:Span", ptr %l1
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t8 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v1, ptr %t2, %"compiler/source:Span" %t3, ptr %t4)
  store ptr %t8, ptr %l14
  br label %bb1
bb1:
  %t9 = load %"compiler/source:Span", ptr %l1
  %t10 = load ptr, ptr %l10, !tbaa !29
  %t11 = load ptr, ptr %l14, !tbaa !29
  %t13 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueRef(ptr %v0, ptr %v1, ptr %v0, ptr %t10, ptr %t11, %"compiler/source:Span" %t9, i1 false)
  store ptr %t13, ptr %l16
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l16, !tbaa !29
  store ptr %t14, ptr %l7, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l17, !tbaa !29
  %t16 = load ptr, ptr %l7, !tbaa !29
  %t19 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t16)
  store i32 %t19, ptr %l20
  br label %bb3
bb3:
  %t20 = load ptr, ptr %l17, !tbaa !29
  %t21 = load i32, ptr %l20, !tbaa !23
  %t22 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t20, i32 %t21)
  store i1 %t22, ptr %l21
  br label %bb4
bb4:
  %t23 = load i1, ptr %l21, !tbaa !21
  br i1 %t23, label %bb5, label %bb6
bb5:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l4, !tbaa !23
  %t28 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t24, i32 %t25)
  store i1 %t28, ptr %l25
  br label %bb7
bb6:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb8
bb7:
  %t29 = load i1, ptr %l25, !tbaa !21
  %t30 = xor i1 %t29, true
  store i1 %t30, ptr %l22, !tbaa !21
  br label %bb8
bb8:
  %t32 = load i1, ptr %l22, !tbaa !21
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t33 = load ptr, ptr %l7, !tbaa !29
  %t36 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t33)
  store i32 %t36, ptr %l29
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t37 = load i32, ptr %l29, !tbaa !23
  store i32 %t37, ptr %l4, !tbaa !23
  br label %bb12
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i32, ptr %l2, !tbaa !23
  %t42 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t38, i32 %t39)
  store i64 %t42, ptr %l32
  br label %bb13
bb13:
  %t43 = load i64, ptr %l32, !tbaa !24
  store i64 %t43, ptr %l8, !tbaa !24
  %t44 = load i64, ptr %l8, !tbaa !24
  %t46 = icmp slt i64 %t44, 0
  br i1 %t46, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb18
bb15:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t48)
  store ptr %t50, ptr %l37
  br label %bb16
bb16:
  %t51 = load ptr, ptr %l37, !tbaa !29
  %t53 = getelementptr %"compiler/typed:Body", ptr %t51, i32 0, i32 7
  %t54 = load i64, ptr %l8, !tbaa !24
  %t57 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t53, i64 %t54)
  store %"compiler/typed:Local" %t57, ptr %l41
  br label %bb17
bb17:
  %t58 = getelementptr %"compiler/typed:Local", ptr %l41, i32 0, i32 3
  %t59 = load i32, ptr %t58, !tbaa !23
  %t61 = sext i32 %t59 to i64
  %t65 = icmp ne i64 %t61, %a6
  store i1 %t65, ptr %l35, !tbaa !21
  br label %bb18
bb18:
  %t67 = load i1, ptr %l35, !tbaa !21
  br i1 %t67, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb23
bb20:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t68)
  store ptr %t70, ptr %l48
  br label %bb21
bb21:
  %t71 = load ptr, ptr %l48, !tbaa !29
  %t73 = getelementptr %"compiler/typed:Body", ptr %t71, i32 0, i32 7
  %t74 = load i64, ptr %l8, !tbaa !24
  %t77 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t73, i64 %t74)
  store %"compiler/typed:Local" %t77, ptr %l52
  br label %bb22
bb22:
  %t78 = getelementptr %"compiler/typed:Local", ptr %l52, i32 0, i32 4
  %t79 = load i32, ptr %t78, !range !{i32 0, i32 7}
  %t81 = trunc i64 4 to i32
  %t82 = icmp eq i32 %t79, %t81
  %t84 = xor i1 %t82, true
  store i1 %t84, ptr %l46, !tbaa !21
  br label %bb23
bb23:
  %t86 = load i1, ptr %l46, !tbaa !21
  br i1 %t86, label %bb24, label %bb25
bb24:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load i32, ptr %l2, !tbaa !23
  %t89 = load %"compiler/source:Span", ptr %l1
  %t90 = load i32, ptr %l4, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t91
  %t92 = getelementptr { i64, [1 x i64] }, ptr %t91, i32 0, i32 0
  store i64 4, ptr %t92
  %t93 = load { i64, [1 x i64] }, ptr %t91
  %t100 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t87, i32 %t88, %"compiler/source:Span" %t89, i32 %t90, i32 4, { i64, [1 x i64] } %t93)
  store i64 %t100, ptr %l62
  br label %bb26
bb25:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/check:Checker", ptr %t101, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = getelementptr %"compiler/generic:Program", ptr %t104, i32 0, i32 2
  store ptr %t106, ptr %l77, !tbaa !29
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t107)
  store ptr %t109, ptr %l79
  br label %bb33
bb26:
  %t110 = load i64, ptr %l62, !tbaa !24
  store i64 %t110, ptr %l8, !tbaa !24
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load ptr, ptr %l3, !tbaa !29
  %t115 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceAt(ptr %v0, ptr %v1, ptr %t111, ptr %t112)
  store { i64, [3 x i64] } %t115, ptr %l65
  br label %bb27
bb27:
  %t116 = load { i64, [3 x i64] }, ptr %l65
  store { i64, [3 x i64] } %t116, ptr %l9
  %t117 = load { i64, [3 x i64] }, ptr %l9
  %t119 = extractvalue { i64, [3 x i64] } %t117, 0
  %t120 = icmp eq i64 %t119, 0
  %t122 = xor i1 %t120, true
  br i1 %t122, label %bb28, label %bb29
bb28:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t124)
  store ptr %t126, ptr %l70
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t127 = load ptr, ptr %l70, !tbaa !29
  %t129 = getelementptr %"compiler/check:frame", ptr %t127, i32 0, i32 3
  %t130 = load i64, ptr %l8, !tbaa !24
  %t131 = load { i64, [3 x i64] }, ptr %l9
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_Hc07a7e56a24d8f1225398db99ea19a4b(ptr %v0, ptr %t129, i64 %t130, { i64, [3 x i64] } %t131)
  br label %bb31
bb31:
  br label %bb32
bb32:
  br label %bb43
bb33:
  %t135 = load ptr, ptr %l79, !tbaa !29
  %t137 = getelementptr %"compiler/typed:Body", ptr %t135, i32 0, i32 7
  %t138 = load i64, ptr %l8, !tbaa !24
  %t141 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t137, i64 %t138)
  store %"compiler/typed:Local" %t141, ptr %l83
  br label %bb34
bb34:
  %t142 = getelementptr %"compiler/typed:Local", ptr %l83, i32 0, i32 2
  %t143 = load i32, ptr %t142, !tbaa !23
  %t144 = load i32, ptr %l4, !tbaa !23
  %t145 = load ptr, ptr %l77, !tbaa !29
  %t148 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t145, i32 %t143, i32 %t144)
  store i1 %t148, ptr %l86
  br label %bb35
bb35:
  %t149 = load i1, ptr %l86, !tbaa !21
  %t150 = xor i1 %t149, true
  br i1 %t150, label %bb36, label %bb37
bb36:
  %t152 = load i32, ptr %l4, !tbaa !23
  %t153 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t156 = icmp ne i32 %t152, %t153
  store i1 %t156, ptr %l88, !tbaa !21
  br label %bb38
bb37:
  store i1 false, ptr %l88, !tbaa !21
  br label %bb38
bb38:
  %t158 = load i1, ptr %l88, !tbaa !21
  br i1 %t158, label %bb39, label %bb40
bb39:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load %"compiler/source:Span", ptr %l1
  %t161 = load i32, ptr %l2, !tbaa !23
  %t162 = load i64, ptr %l8, !tbaa !24
  %t163 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ealtBinding(ptr %v0, ptr %t159, %"compiler/source:Span" %t160, i32 %t161, i64 %t162, i32 %t163)
  br label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load i64, ptr %l8, !tbaa !24
  %t171 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v0, ptr %t169, i64 %t170, ptr %t171)
  br label %bb44
bb44:
  store ptr %a5, ptr %l100, !tbaa !29
  %t176 = load i64, ptr %l8, !tbaa !24
  %t178 = trunc i64 %t176 to i32
  %t180 = load ptr, ptr %l7, !tbaa !29
  %t183 = call %"compiler/typed:Bind" @compiler_2ftyped_3aBind_2ector(ptr %v0, ptr %v2, i32 %t178, ptr %t180)
  store %"compiler/typed:Bind" %t183, ptr %l105
  br label %bb45
bb45:
  %t184 = load %"compiler/typed:Bind", ptr %l105
  %t185 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store %"compiler/typed:Bind" %t184, ptr %t185
  %t186 = load ptr, ptr %l100, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBind_26_3e_2ePush_3ccompiler_2ftyped_3aBind_26_3e(ptr %v2, ptr %v2, ptr %t186, ptr %t185)
  br label %bb46
bb46:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load %"compiler/source:Span", ptr %l1
  %t190 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t194 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t188, %"compiler/source:Span" %t189, i32 %t190, i64 1)
  store ptr %t194, ptr %l110
  br label %bb47
bb47:
  %t195 = load ptr, ptr %l110, !tbaa !29
  store ptr %t195, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyErrors(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l8 = alloca ptr
  %l11 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i32
  %l22 = alloca i32
  %l26 = alloca i64
  %l33 = alloca i64
  %l35 = alloca i32
  %l39 = alloca i32
  %l40 = alloca i32
  %l41 = alloca i1
  %l45 = alloca i1
  %l46 = alloca i32
  %l48 = alloca ptr
  %l49 = alloca i64
  %l54 = alloca { i64, ptr }
  %l56 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l59 = alloca i32
  %l61 = alloca ptr
  %l64 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l65 = alloca i32
  %l66 = alloca i32
  %l68 = alloca ptr
  %l69 = alloca i64
  %l74 = alloca { i64, ptr }
  %l76 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 14
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l8, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 2
  %t11 = load i32, ptr %t10, !tbaa !23
  store i32 %t11, ptr %l2, !tbaa !23
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 54
  %t16 = load i64, ptr %l1, !tbaa !24
  %t19 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %t15, i64 %t16)
  %t20 = extractvalue { i32, i1 } %t19, 1
  %t21 = extractvalue { i32, i1 } %t19, 0
  store i32 %t21, ptr %l16
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb3, label %ok.23, !prof !99
ok.23:
  store i1 %t20, ptr %l15
  br label %bb2
bb2:
  %t24 = load i1, ptr %l15, !tbaa !21
  store i1 %t24, ptr %l11, !tbaa !21
  br label %bb5
bb3:
  br label %bb4
bb4:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l11, !tbaa !21
  %t26 = xor i1 %t25, true
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  %t34 = load i32, ptr %l2, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l22
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t38 = load i32, ptr %l22, !tbaa !23
  store i32 %t38, ptr %rv
  br label %ret
bb9:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 19
  %t42 = load i64, ptr %l1, !tbaa !24
  %t45 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t41, i64 %t42)
  store i64 %t45, ptr %l26
  br label %bb10
bb10:
  %t46 = load i64, ptr %l26, !tbaa !24
  %t47 = icmp eq i64 %t46, 0
  br i1 %t47, label %bb11, label %bb12
bb11:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckNow(ptr %v0, ptr %t49, i64 %t50)
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 19
  %t56 = load i64, ptr %l1, !tbaa !24
  %t59 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t55, i64 %t56)
  store i64 %t59, ptr %l33
  br label %bb15
bb15:
  %t60 = load i64, ptr %l33, !tbaa !24
  %t61 = icmp eq i64 %t60, 2
  br i1 %t61, label %bb16, label %bb17
bb16:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 55
  %t66 = load i64, ptr %l1, !tbaa !24
  %t69 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e__H9cb5d99387f926677a92c13412f9a8b2(ptr %v0, ptr %t65, i64 %t66)
  %t70 = extractvalue { i32, i32 } %t69, 1
  %t71 = extractvalue { i32, i32 } %t69, 0
  store i32 %t71, ptr %l40
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb19, label %ok.73, !prof !99
ok.73:
  store i32 %t70, ptr %l39
  br label %bb18
bb17:
  br label %bb33
bb18:
  %t74 = load i32, ptr %l39, !tbaa !23
  store i32 %t74, ptr %l35, !tbaa !23
  br label %bb21
bb19:
  br label %bb20
bb20:
  store i32 0, ptr %l35, !tbaa !23
  br label %bb21
bb21:
  %t75 = load i32, ptr %l35, !tbaa !23
  store i32 %t75, ptr %l3, !tbaa !23
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 57
  %t79 = load i64, ptr %l1, !tbaa !24
  %t82 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %t78, i64 %t79)
  %t83 = extractvalue { i32, i1 } %t82, 1
  %t84 = extractvalue { i32, i1 } %t82, 0
  store i32 %t84, ptr %l46
  %t85 = icmp ne i32 %t84, 0
  br i1 %t85, label %bb23, label %ok.86, !prof !99
ok.86:
  store i1 %t83, ptr %l45
  br label %bb22
bb22:
  %t87 = load i1, ptr %l45, !tbaa !21
  store i1 %t87, ptr %l41, !tbaa !21
  br label %bb25
bb23:
  br label %bb24
bb24:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb25
bb25:
  %t88 = load i1, ptr %l41, !tbaa !21
  br i1 %t88, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/check:Checker", ptr %t89, i32 0, i32 56
  store ptr %t91, ptr %l48, !tbaa !29
  %t92 = load i64, ptr %l1, !tbaa !24
  store i64 %t92, ptr %l49, !tbaa !24
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 2
  %t99 = load i32, ptr %l3, !tbaa !23
  %t102 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s4, ptr %t98, i32 %t99)
  store { i64, ptr } %t102, ptr %l54
  br label %bb28
bb27:
  br label %bb32
bb28:
  %t103 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 0
  %t105 = load i64, ptr %l49, !tbaa !24
  %t107 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s4, i64 %t105, i64 %t104)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t107, ptr %l56
  br label %bb29
bb29:
  %t108 = load ptr, ptr %l48, !tbaa !29
  %t109 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l56
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H2474e1fc3c93452d7765e4ed18f29a03(ptr %v0, ptr %t108, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t109)
  br label %bb30
bb30:
  %t110 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunsettle(ptr %v0, ptr %t110)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s4)
  br label %bb32
bb32:
  %t112 = load i32, ptr %l3, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t112, ptr %rv
  br label %ret
bb33:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/check:Checker", ptr %t114, i32 0, i32 58
  store ptr %t116, ptr %l61, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i64, ptr %l1, !tbaa !24
  %t121 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyKey(ptr %v0, ptr %t117, i64 %t118)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t121, ptr %l64
  br label %bb34
bb34:
  %t122 = load ptr, ptr %l61, !tbaa !29
  %t123 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l64
  %t124 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hf3bb75ba9d3f922b4d327e9d3c1adfb0(ptr %v0, ptr %t122, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t123)
  %t125 = extractvalue { i32, i32 } %t124, 1
  %t126 = extractvalue { i32, i32 } %t124, 0
  store i32 %t126, ptr %l66
  %t127 = icmp ne i32 %t126, 0
  br i1 %t127, label %bb36, label %ok.128, !prof !99
ok.128:
  store i32 %t125, ptr %l65
  br label %bb35
bb35:
  %t129 = load i32, ptr %l65, !tbaa !23
  store i32 %t129, ptr %l59, !tbaa !23
  br label %bb38
bb36:
  br label %bb37
bb37:
  store i32 0, ptr %l59, !tbaa !23
  br label %bb38
bb38:
  %t130 = load i32, ptr %l59, !tbaa !23
  store i32 %t130, ptr %l4, !tbaa !23
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/check:Checker", ptr %t131, i32 0, i32 56
  store ptr %t133, ptr %l68, !tbaa !29
  %t134 = load i64, ptr %l1, !tbaa !24
  store i64 %t134, ptr %l69, !tbaa !24
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = getelementptr %"compiler/generic:Program", ptr %t138, i32 0, i32 2
  %t141 = load i32, ptr %l4, !tbaa !23
  %t144 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t140, i32 %t141)
  store { i64, ptr } %t144, ptr %l74
  br label %bb39
bb39:
  %t145 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t145, 0
  %t147 = load i64, ptr %l69, !tbaa !24
  %t149 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t147, i64 %t146)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t149, ptr %l76
  br label %bb40
bb40:
  %t150 = load ptr, ptr %l68, !tbaa !29
  %t151 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l76
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H2474e1fc3c93452d7765e4ed18f29a03(ptr %v0, ptr %t150, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t151)
  br label %bb41
bb41:
  %t152 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunsettle(ptr %v0, ptr %t152)
  br label %bb42
bb42:
  %t154 = load i32, ptr %l4, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t154, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuilderFactInst(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/check:ownerAt"
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca %"compiler/check:ownerAt"
  %l12 = alloca ptr
  %l13 = alloca i1
  %l20 = alloca %"compiler/check:ownerAt"
  %l25 = alloca i1
  %l32 = alloca { i64, ptr }
  %l34 = alloca i64
  %l36 = alloca ptr
  %l38 = alloca i64
  %l39 = alloca i64
  %l49 = alloca { i64, ptr }
  %l59 = alloca ptr
  %l60 = alloca i64
  %l65 = alloca i32
  %l66 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t3 = call %"compiler/check:ownerAt" @compiler_2fcheck_3aownerAt_2ector(ptr %s0, i32 %t1, i1 false)
  store %"compiler/check:ownerAt" %t3, ptr %l11
  br label %bb1
bb1:
  %t4 = load %"compiler/check:ownerAt", ptr %l11
  store %"compiler/check:ownerAt" %t4, ptr %l3
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t6 = load ptr, ptr %l12, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l12, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 30}
  %t12 = icmp eq i64 %t10, 14
  store i1 %t12, ptr %l13, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l13, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t16, i32 0, i32 1
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l4, !tbaa !29
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t24 = call %"compiler/check:ownerAt" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownerOf(ptr %v0, ptr %v1, ptr %t20, ptr %t21)
  store %"compiler/check:ownerAt" %t24, ptr %l20
  br label %bb7
bb7:
  %t25 = load %"compiler/check:ownerAt", ptr %l20
  store %"compiler/check:ownerAt" %t25, ptr %l3
  br label %bb13
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb12:
  call void @__olang_check_failed(ptr @olang_loc_9c3920f9822030fe_f04ee3e76f867a92)
  unreachable
bb13:
  %t27 = getelementptr %"compiler/check:ownerAt", ptr %l3, i32 0, i32 0
  %t28 = load i32, ptr %t27, !tbaa !23
  %t29 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t32 = icmp eq i32 %t28, %t29
  br i1 %t32, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb16
bb15:
  %t34 = getelementptr %"compiler/check:ownerAt", ptr %l3, i32 0, i32 1
  %t35 = load i1, ptr %t34, !tbaa !21
  store i1 %t35, ptr %l25, !tbaa !21
  br label %bb16
bb16:
  %t37 = load i1, ptr %l25, !tbaa !21
  br i1 %t37, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t43 = load i64, ptr %l2, !tbaa !24
  %t44 = getelementptr %"compiler/check:ownerAt", ptr %l3, i32 0, i32 0
  %t45 = load i32, ptr %t44, !tbaa !23
  %t49 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eOwnerBinding(ptr %v0, ptr %s0, ptr %t42, i64 %t43, i32 %t45)
  store { i64, ptr } %t49, ptr %l32
  br label %bb20
bb20:
  %t50 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t50, ptr %l5, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t51, 0
  store i64 %t53, ptr %l34, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  store ptr %t57, ptr %l36, !tbaa !29
  %t58 = load i64, ptr %l2, !tbaa !24
  %t60 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t58)
  store i64 %t60, ptr %l38
  br label %bb21
bb21:
  %t61 = load ptr, ptr %l36, !tbaa !29
  %t62 = load i64, ptr %l38, !tbaa !24
  %t63 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t61, i64 %t62)
  store i64 %t63, ptr %l39
  br label %bb22
bb22:
  %t64 = load i64, ptr %l34, !tbaa !24
  %t65 = load i64, ptr %l39, !tbaa !24
  %t66 = icmp ne i64 %t64, %t65
  br i1 %t66, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t69 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t69, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t71 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t71, 0
  store i64 %t73, ptr %l8, !tbaa !24
  br label %bb26
bb26:
  %t75 = load i64, ptr %l7, !tbaa !24
  %t76 = load i64, ptr %l8, !tbaa !24
  %t79 = icmp slt i64 %t75, %t76
  %t81 = xor i1 %t79, true
  br i1 %t81, label %bb27, label %bb28
bb27:
  br label %bb34
bb28:
  br label %bb29
bb29:
  %t83 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t83, ptr %l49, !tbaa !27
  %t84 = load i64, ptr %l7, !tbaa !24
  %t86 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr i32, ptr %t87, i64 %t84
  %t89 = load i32, ptr %t88, !tbaa !33
  %t92 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t95 = icmp eq i32 %t89, %t92
  br i1 %t95, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t98 = load i64, ptr %l7, !tbaa !24
  %t100 = add i64 %t98, 1
  store i64 %t100, ptr %l7, !tbaa !24
  br label %bb26
bb34:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/check:Checker", ptr %t102, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  store ptr %t105, ptr %l59, !tbaa !29
  %t106 = load i64, ptr %l2, !tbaa !24
  store i64 %t106, ptr %l60, !tbaa !24
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/check:Checker", ptr %t107, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/generic:Program", ptr %t110, i32 0, i32 2
  %t113 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t116 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t112, { i64, ptr } %t113)
  store i32 %t116, ptr %l65
  br label %bb35
bb35:
  %t117 = load ptr, ptr %l59, !tbaa !29
  %t118 = load i64, ptr %l60, !tbaa !24
  %t119 = load i32, ptr %l65, !tbaa !23
  %t120 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %t117, i64 %t118, i32 %t119)
  store i64 %t120, ptr %l66
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s0)
  %t121 = load i64, ptr %l66, !tbaa !24
  store i64 %t121, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i32
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca { i64, i32 }
  %l21 = alloca i64
  %l22 = alloca i32
  %l27 = alloca i1
  %l29 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l35 = alloca i1
  %l37 = alloca ptr
  %l39 = alloca ptr
  %l43 = alloca i32
  %l48 = alloca i32
  %l53 = alloca ptr
  %l58 = alloca i32
  %l59 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l77 = alloca i1
  %l79 = alloca ptr
  %l81 = alloca ptr
  %l85 = alloca i32
  %l92 = alloca i1
  %l94 = alloca ptr
  %l96 = alloca %"compiler/typed:Item"
  %l97 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l103 = alloca i64
  %l105 = alloca i64
  %l110 = alloca i32
  %l118 = alloca i32
  %l122 = alloca ptr
  %l124 = alloca %"compiler/typed:Item"
  %l129 = alloca i64
  %l133 = alloca i64
  %l136 = alloca i64
  %l155 = alloca i64
  %l159 = alloca ptr
  %l164 = alloca i32
  %l166 = alloca %"compiler/typed:Item"
  %l173 = alloca { i64, i32 }
  %l179 = alloca ptr
  %l181 = alloca ptr
  %l185 = alloca i1
  %l186 = alloca ptr
  %l189 = alloca %"compiler/typed:Item"
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s15 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Path", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 1
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t10)
  store ptr %t12, ptr %l29
  br label %bb3
bb2:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb5
bb3:
  %t13 = load ptr, ptr %l29, !tbaa !29
  %t15 = getelementptr %"compiler/check:frame", ptr %t13, i32 0, i32 4
  %t16 = getelementptr %"compiler/generic:Context", ptr %t15, i32 0, i32 2
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr %"compiler/ast:Path", ptr %t17, i32 0, i32 1
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l33, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr i32, ptr %t22, i64 0
  %t24 = load i32, ptr %t23, !tbaa !33
  %t27 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_He6be2b0836caba7ddc59483ff74db438(ptr %v0, ptr %t16, i32 %t24)
  store i1 %t27, ptr %l35
  br label %bb4
bb4:
  %t28 = load i1, ptr %l35, !tbaa !21
  store i1 %t28, ptr %l27, !tbaa !21
  br label %bb5
bb5:
  %t29 = load i1, ptr %l27, !tbaa !21
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  store ptr %t33, ptr %l37, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t34)
  store ptr %t36, ptr %l39
  br label %bb8
bb7:
  br label %bb27
bb8:
  %t37 = load ptr, ptr %l39, !tbaa !29
  %t39 = getelementptr %"compiler/check:frame", ptr %t37, i32 0, i32 4
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t41 = load ptr, ptr %l37, !tbaa !29
  %t44 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorSetItem(ptr %v0, ptr %v0, ptr %v1, ptr %t41, ptr %t39, ptr %t40)
  store i32 %t44, ptr %l43
  br label %bb9
bb9:
  %t45 = load i32, ptr %l43, !tbaa !23
  store i32 %t45, ptr %l3, !tbaa !23
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 2
  %t52 = load i32, ptr %l3, !tbaa !23
  %t55 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t51, i32 %t52)
  store i32 %t55, ptr %l48
  br label %bb10
bb10:
  %t56 = load i32, ptr %l48, !range !{i32 0, i32 33}
  %t58 = trunc i64 30 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb11, label %bb12
bb11:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/check:Checker", ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = getelementptr %"compiler/generic:Program", ptr %t64, i32 0, i32 2
  store ptr %t66, ptr %l53, !tbaa !29
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t70, i32 0, i32 2
  %t73 = load i32, ptr %l3, !tbaa !23
  %t76 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %t72, i32 %t73)
  store i32 %t76, ptr %l58
  br label %bb13
bb12:
  br label %bb22
bb13:
  %t77 = load ptr, ptr %l53, !tbaa !29
  %t78 = load i32, ptr %l58, !tbaa !23
  %t79 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t77, i32 %t78)
  store { i64, ptr } %t79, ptr %l59
  br label %bb14
bb14:
  %t80 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t80, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t81 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t81, 0
  store i64 %t83, ptr %l6, !tbaa !24
  br label %bb15
bb15:
  %t85 = load i64, ptr %l5, !tbaa !24
  %t86 = load i64, ptr %l6, !tbaa !24
  %t89 = icmp slt i64 %t85, %t86
  %t91 = xor i1 %t89, true
  br i1 %t91, label %bb16, label %bb17
bb16:
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t93 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t93, ptr %l66, !tbaa !27
  %t94 = load i64, ptr %l5, !tbaa !24
  %t96 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr i32, ptr %t97, i64 %t94
  %t99 = load i32, ptr %t98, !tbaa !33
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryItems(ptr %v0, ptr %v2, ptr %t101, i32 %t99, ptr %t103)
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t107 = load i64, ptr %l5, !tbaa !24
  %t109 = add i64 %t107, 1
  store i64 %t109, ptr %l5, !tbaa !24
  br label %bb15
bb21:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb22:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/check:Checker", ptr %t111, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t115 = load i32, ptr %l3, !tbaa !23
  %t118 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsErrVar(ptr %v0, ptr %t114, i32 %t115)
  store i1 %t118, ptr %l77
  br label %bb23
bb23:
  %t119 = load i1, ptr %l77, !tbaa !21
  br i1 %t119, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb25:
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/check:Checker", ptr %t120, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !29
  store ptr %t123, ptr %l79, !tbaa !29
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t124)
  store ptr %t126, ptr %l81
  br label %bb28
bb28:
  %t127 = load ptr, ptr %l81, !tbaa !29
  %t129 = getelementptr %"compiler/check:frame", ptr %t127, i32 0, i32 4
  %t130 = load ptr, ptr %l1, !tbaa !29
  %t131 = load ptr, ptr %l79, !tbaa !29
  %t134 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorType(ptr %v0, ptr %v0, ptr %v1, ptr %t131, ptr %t129, ptr %t130)
  store i32 %t134, ptr %l85
  br label %bb29
bb29:
  %t135 = load i32, ptr %l85, !tbaa !23
  store i32 %t135, ptr %l8, !tbaa !23
  %t136 = load i32, ptr %l8, !tbaa !23
  %t137 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t140 = icmp ne i32 %t136, %t137
  br i1 %t140, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s7
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/check:Checker", ptr %t142, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !29
  %t146 = load i32, ptr %l8, !tbaa !23
  %t149 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsErrorSet(ptr %v0, ptr %t145, i32 %t146)
  store i1 %t149, ptr %l92
  br label %bb32
bb31:
  br label %bb76
bb32:
  %t150 = load i1, ptr %l92, !tbaa !21
  %t151 = xor i1 %t150, true
  br i1 %t151, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s8
  %t153 = load ptr, ptr %l2, !tbaa !29
  store ptr %t153, ptr %l94, !tbaa !29
  %t154 = load i32, ptr %l8, !tbaa !23
  %t156 = call %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %s8, i32 %t154, i64 -1)
  store %"compiler/typed:Item" %t156, ptr %l96
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t157 = load ptr, ptr %l94, !tbaa !29
  %t158 = load %"compiler/typed:Item", ptr %l96
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v2, ptr %t157, %"compiler/typed:Item" %t158)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb37:
  %t159 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s7, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t159, ptr %l97
  br label %bb38
bb38:
  %t160 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l97
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t160, ptr %l9
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/check:Checker", ptr %t161, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !29
  %t165 = load i32, ptr %l8, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eEntriesOf(ptr %v0, ptr %s7, ptr %t164, i32 %t165, ptr %l9)
  br label %bb39
bb39:
  store ptr %l9, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb40
bb40:
  %t170 = load i64, ptr %l11, !tbaa !24
  store i64 %t170, ptr %l103, !tbaa !24
  %t171 = load ptr, ptr %l10, !tbaa !29
  %t173 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s7, ptr %t171)
  store i64 %t173, ptr %l105
  br label %bb41
bb41:
  %t174 = load i64, ptr %l103, !tbaa !24
  %t175 = load i64, ptr %l105, !tbaa !24
  %t176 = icmp slt i64 %t174, %t175
  %t178 = xor i1 %t176, true
  br i1 %t178, label %bb42, label %bb43
bb42:
  br label %bb75
bb43:
  br label %bb44
bb44:
  %t180 = load ptr, ptr %l10, !tbaa !29
  %t181 = load i64, ptr %l11, !tbaa !24
  %t184 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s7, ptr %t180, i64 %t181)
  store i32 %t184, ptr %l110
  br label %bb45
bb45:
  %t185 = load i32, ptr %l110, !tbaa !23
  store i32 %t185, ptr %l12, !tbaa !23
  %t186 = load i32, ptr %l12, !tbaa !23
  %t187 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t190 = icmp eq i32 %t186, %t187
  br i1 %t190, label %bb46, label %bb47
bb46:
  br label %bb74
bb47:
  br label %bb48
bb48:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/check:Checker", ptr %t192, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !29
  %t197 = getelementptr %"compiler/generic:Program", ptr %t195, i32 0, i32 2
  %t198 = load i32, ptr %l12, !tbaa !23
  %t201 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t197, i32 %t198)
  store i32 %t201, ptr %l118
  br label %bb49
bb49:
  %t202 = load i32, ptr %l118, !range !{i32 0, i32 33}
  %t204 = trunc i64 28 to i32
  %t205 = icmp eq i32 %t202, %t204
  %t207 = xor i1 %t205, true
  br i1 %t207, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s12
  %t209 = load ptr, ptr %l2, !tbaa !29
  store ptr %t209, ptr %l122, !tbaa !29
  %t210 = load i32, ptr %l12, !tbaa !23
  %t212 = call %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %s12, i32 %t210, i64 -1)
  store %"compiler/typed:Item" %t212, ptr %l124
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t213 = load ptr, ptr %l122, !tbaa !29
  %t214 = load %"compiler/typed:Item", ptr %l124
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v2, ptr %t213, %"compiler/typed:Item" %t214)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s12)
  br label %bb74
bb54:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = getelementptr %"compiler/check:Checker", ptr %t215, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !29
  %t220 = getelementptr %"compiler/generic:Program", ptr %t218, i32 0, i32 2
  %t221 = load i32, ptr %l12, !tbaa !23
  %t224 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t220, i32 %t221)
  store i64 %t224, ptr %l129
  br label %bb55
bb55:
  %t225 = load i64, ptr %l129, !tbaa !65
  store i64 %t225, ptr %l13, !tbaa !65
  store i64 0, ptr %l14, !tbaa !24
  store i64 64, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t226 = load i64, ptr %l15, !tbaa !24
  %t227 = load i64, ptr %l14, !tbaa !24
  %t230 = icmp sgt i64 %t226, %t227
  br i1 %t230, label %bb56, label %bb57
bb56:
  %t232 = load i64, ptr %l16, !tbaa !24
  %t234 = icmp sgt i64 %t232, 0
  br i1 %t234, label %bb58, label %bb59
bb57:
  store i64 0, ptr %l133, !tbaa !24
  br label %bb61
bb58:
  %t236 = load i64, ptr %l15, !tbaa !24
  %t237 = load i64, ptr %l14, !tbaa !24
  %t240 = sub i64 %t236, %t237
  %t241 = load i64, ptr %l16, !tbaa !24
  %t244 = add i64 %t240, %t241
  %t246 = sub i64 %t244, 1
  %t247 = load i64, ptr %l16, !tbaa !24
  %t250 = sdiv i64 %t246, %t247
  store i64 %t250, ptr %l136, !tbaa !24
  br label %bb60
bb59:
  store i64 0, ptr %l136, !tbaa !24
  br label %bb60
bb60:
  %t252 = load i64, ptr %l136, !tbaa !24
  store i64 %t252, ptr %l133, !tbaa !24
  br label %bb61
bb61:
  %t253 = load i64, ptr %l133, !tbaa !24
  store i64 %t253, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb62
bb62:
  %t254 = load i64, ptr %l18, !tbaa !24
  %t255 = load i64, ptr %l17, !tbaa !24
  %t258 = icmp slt i64 %t254, %t255
  %t260 = xor i1 %t258, true
  br i1 %t260, label %bb63, label %bb64
bb63:
  br label %bb73
bb64:
  br label %bb65
bb65:
  %t262 = load i64, ptr %l14, !tbaa !24
  %t263 = load i64, ptr %l18, !tbaa !24
  %t264 = load i64, ptr %l16, !tbaa !24
  %t267 = mul i64 %t263, %t264
  %t270 = add i64 %t262, %t267
  store i64 %t270, ptr %l19, !tbaa !24
  %t272 = load i64, ptr %l13, !tbaa !65
  %t273 = load i64, ptr %l19, !tbaa !24
  store i64 %t273, ptr %l155, !tbaa !24
  %t274 = load i64, ptr %l155, !tbaa !24
  %t275 = load i64, ptr %l155, !tbaa !24
  %t276 = shl i64 1, %t275
  %t279 = and i64 %t272, %t276
  %t281 = icmp ne i64 %t279, 0
  br i1 %t281, label %bb66, label %bb67
bb66:
  store %olang.scope zeroinitializer, ptr %s15
  %t283 = load ptr, ptr %l2, !tbaa !29
  store ptr %t283, ptr %l159, !tbaa !29
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t286 = getelementptr %"compiler/check:Checker", ptr %t284, i32 0, i32 1
  %t287 = load ptr, ptr %t286, !tbaa !29
  %t289 = getelementptr %"compiler/generic:Program", ptr %t287, i32 0, i32 2
  %t290 = load i32, ptr %l12, !tbaa !23
  %t293 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t289, i32 %t290)
  store i32 %t293, ptr %l164
  br label %bb68
bb67:
  br label %bb71
bb68:
  %t294 = load i64, ptr %l19, !tbaa !24
  %t295 = load i32, ptr %l164, !tbaa !23
  %t297 = call %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %s15, i32 %t295, i64 %t294)
  store %"compiler/typed:Item" %t297, ptr %l166
  br label %bb69
bb69:
  %t298 = load ptr, ptr %l159, !tbaa !29
  %t299 = load %"compiler/typed:Item", ptr %l166
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v2, ptr %t298, %"compiler/typed:Item" %t299)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s15)
  br label %bb71
bb71:
  br label %bb72
bb72:
  %t300 = load i64, ptr %l18, !tbaa !24
  %t302 = add i64 %t300, 1
  store i64 %t302, ptr %l18, !tbaa !24
  br label %bb62
bb73:
  br label %bb74
bb74:
  %t304 = load i64, ptr %l11, !tbaa !24
  %t306 = add i64 %t304, 1
  store i64 %t306, ptr %l11, !tbaa !24
  br label %bb40
bb75:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb76:
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t309 = load ptr, ptr %l1, !tbaa !29
  %t312 = call { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorWord(ptr %v0, ptr %v1, ptr %t308, ptr %t309)
  store { i64, i32 } %t312, ptr %l173
  br label %bb77
bb77:
  %t313 = load { i64, i32 }, ptr %l173
  store { i64, i32 } %t313, ptr %l20
  %t314 = getelementptr { i64, i32 }, ptr %l20, i32 0, i32 0
  %t315 = load i64, ptr %t314, !tbaa !24
  store i64 %t315, ptr %l21, !tbaa !24
  %t317 = getelementptr { i64, i32 }, ptr %l20, i32 0, i32 1
  %t318 = load i32, ptr %t317, !tbaa !23
  store i32 %t318, ptr %l22, !tbaa !23
  %t320 = load i64, ptr %l21, !tbaa !24
  %t322 = icmp slt i64 %t320, 0
  br i1 %t322, label %bb78, label %bb79
bb78:
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t326 = getelementptr %"compiler/check:Checker", ptr %t324, i32 0, i32 1
  %t327 = load ptr, ptr %t326, !tbaa !29
  store ptr %t327, ptr %l179, !tbaa !29
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t330 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t328)
  store ptr %t330, ptr %l181
  br label %bb80
bb79:
  br label %bb82
bb80:
  %t331 = load ptr, ptr %l181, !tbaa !29
  %t333 = getelementptr %"compiler/check:frame", ptr %t331, i32 0, i32 4
  %t334 = load ptr, ptr %l1, !tbaa !29
  %t335 = load ptr, ptr %l179, !tbaa !29
  %t338 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorItemKnown(ptr %v0, ptr %v0, ptr %v1, ptr %t335, ptr %t333, ptr %t334)
  store i1 %t338, ptr %l185
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb82:
  %t339 = load ptr, ptr %l2, !tbaa !29
  store ptr %t339, ptr %l186, !tbaa !29
  %t340 = load i32, ptr %l22, !tbaa !23
  %t341 = load i64, ptr %l21, !tbaa !24
  %t344 = call %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %s0, i32 %t340, i64 %t341)
  store %"compiler/typed:Item" %t344, ptr %l189
  br label %bb83
bb83:
  %t345 = load ptr, ptr %l186, !tbaa !29
  %t346 = load %"compiler/typed:Item", ptr %l189
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v2, ptr %t345, %"compiler/typed:Item" %t346)
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtLast(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l41 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l62 = alloca i1
  %l69 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Match", ptr %t1, i32 0, i32 3
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  store i64 %t6, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t12 = icmp sgt i64 %t8, %t9
  br i1 %t12, label %bb1, label %bb2
bb1:
  %t14 = load i64, ptr %l5, !tbaa !24
  %t16 = icmp sgt i64 %t14, 0
  br i1 %t16, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb6
bb3:
  %t18 = load i64, ptr %l4, !tbaa !24
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = sub i64 %t18, %t19
  %t23 = load i64, ptr %l5, !tbaa !24
  %t26 = add i64 %t22, %t23
  %t28 = sub i64 %t26, 1
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = sdiv i64 %t28, %t29
  store i64 %t32, ptr %l22, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb5
bb5:
  %t34 = load i64, ptr %l22, !tbaa !24
  store i64 %t34, ptr %l19, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l19, !tbaa !24
  store i64 %t35, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l7, !tbaa !24
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb8, label %bb9
bb8:
  br label %bb25
bb9:
  br label %bb10
bb10:
  %t44 = load i64, ptr %l3, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t46 = load i64, ptr %l5, !tbaa !24
  %t49 = mul i64 %t45, %t46
  %t52 = add i64 %t44, %t49
  store i64 %t52, ptr %l8, !tbaa !24
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr %"compiler/ast:Match", ptr %t54, i32 0, i32 3
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  store { i64, ptr } %t57, ptr %l41, !tbaa !27
  %t58 = load i64, ptr %l8, !tbaa !24
  %t60 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr ptr, ptr %t61, i64 %t58
  %t63 = load ptr, ptr %t62, !tbaa !39
  %t65 = getelementptr %"compiler/ast:Case", ptr %t63, i32 0, i32 3
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = icmp eq ptr %t66, null
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb11, label %bb12
bb11:
  br label %bb24
bb12:
  br label %bb13
bb13:
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = getelementptr %"compiler/ast:Match", ptr %t72, i32 0, i32 3
  %t75 = load { i64, ptr }, ptr %t74, !tbaa !27
  store { i64, ptr } %t75, ptr %l48, !tbaa !27
  %t76 = load i64, ptr %l8, !tbaa !24
  %t78 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr ptr, ptr %t79, i64 %t76
  %t81 = load ptr, ptr %t80, !tbaa !39
  %t83 = getelementptr %"compiler/ast:Case", ptr %t81, i32 0, i32 1
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  store { i64, ptr } %t84, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t86 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  store i64 %t88, ptr %l11, !tbaa !24
  br label %bb14
bb14:
  %t90 = load i64, ptr %l10, !tbaa !24
  %t91 = load i64, ptr %l11, !tbaa !24
  %t94 = icmp slt i64 %t90, %t91
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb15, label %bb16
bb15:
  br label %bb23
bb16:
  br label %bb17
bb17:
  %t98 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t98, ptr %l58, !tbaa !27
  %t99 = load i64, ptr %l10, !tbaa !24
  %t101 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr ptr, ptr %t102, i64 %t99
  %t104 = load ptr, ptr %t103, !tbaa !39
  %t108 = call i1 @compiler_2fcheck_2eisWild(ptr %v1, ptr %t104)
  store i1 %t108, ptr %l62
  br label %bb18
bb18:
  %t109 = load i1, ptr %l62, !tbaa !21
  br i1 %t109, label %bb19, label %bb20
bb19:
  %t110 = load i64, ptr %l8, !tbaa !24
  store i64 %t110, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t112 = load i64, ptr %l10, !tbaa !24
  %t114 = add i64 %t112, 1
  store i64 %t114, ptr %l10, !tbaa !24
  br label %bb14
bb23:
  br label %bb24
bb24:
  %t116 = load i64, ptr %l7, !tbaa !24
  %t118 = add i64 %t116, 1
  store i64 %t118, ptr %l7, !tbaa !24
  br label %bb7
bb25:
  br i1 %a2, label %bb26, label %bb27
bb26:
  %t122 = load ptr, ptr %l1, !tbaa !29
  %t124 = getelementptr %"compiler/ast:Match", ptr %t122, i32 0, i32 3
  %t125 = load { i64, ptr }, ptr %t124, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t125, 0
  %t129 = sub i64 %t127, 1
  store i64 %t129, ptr %l69, !tbaa !24
  br label %bb28
bb27:
  store i64 -1, ptr %l69, !tbaa !24
  br label %bb28
bb28:
  %t131 = load i64, ptr %l69, !tbaa !24
  store i64 %t131, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtUsed(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l7 = alloca i64
  %l15 = alloca ptr
  %l18 = alloca i64
  %l26 = alloca %"compiler/check:errBind"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 16
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i64, ptr %l7, !tbaa !24
  %t7 = sub i64 %t6, 1
  store i64 %t7, ptr %l2, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l2, !tbaa !24
  %t11 = icmp sge i64 %t9, 0
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb20
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 16
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_Hc8503b2b20cde402cc7bde6f68d96fc0(ptr %v0, ptr %v0, ptr %t17, i64 %t18)
  store ptr %t21, ptr %l15
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l15, !tbaa !29
  store ptr %t22, ptr %l3, !tbaa !29
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t25 = getelementptr %"compiler/check:frame", ptr %t23, i32 0, i32 57
  %t27 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrBind_3e_2eLen_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %t25)
  store i64 %t27, ptr %l18
  br label %bb7
bb7:
  %t28 = load i64, ptr %l18, !tbaa !24
  %t29 = sub i64 %t28, 1
  store i64 %t29, ptr %l4, !tbaa !24
  br label %bb8
bb8:
  %t31 = load i64, ptr %l4, !tbaa !24
  %t33 = icmp sge i64 %t31, 0
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb9, label %bb10
bb9:
  br label %bb18
bb10:
  br label %bb11
bb11:
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t39 = getelementptr %"compiler/check:frame", ptr %t37, i32 0, i32 57
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = call %"compiler/check:errBind" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrBind_3e_2eAt_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %t39, i64 %t40)
  store %"compiler/check:errBind" %t43, ptr %l26
  br label %bb12
bb12:
  %t44 = getelementptr %"compiler/check:errBind", ptr %l26, i32 0, i32 0
  %t45 = load i32, ptr %t44, !tbaa !23
  %t49 = icmp eq i32 %t45, %a1
  br i1 %t49, label %bb13, label %bb14
bb13:
  %t51 = load ptr, ptr %l3, !tbaa !29
  %t53 = getelementptr %"compiler/check:frame", ptr %t51, i32 0, i32 58
  %t54 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t53, i64 %t54, i1 true)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %ret
bb16:
  br label %bb17
bb17:
  %t57 = load i64, ptr %l4, !tbaa !24
  %t59 = sub i64 %t57, 1
  store i64 %t59, ptr %l4, !tbaa !24
  br label %bb8
bb18:
  %t61 = load ptr, ptr %l3, !tbaa !29
  %t63 = getelementptr %"compiler/check:frame", ptr %t61, i32 0, i32 19
  %t64 = load i64, ptr %t63, !tbaa !24
  store i64 %t64, ptr %l2, !tbaa !24
  br label %bb19
bb19:
  br label %bb2
bb20:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclauseHandler(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %lp26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l30 = alloca i1
  %l41 = alloca i1
  %l44 = alloca i1
  %l49 = alloca i1
  %l52 = alloca ptr
  %l55 = alloca %"compiler/source:Span"
  %l56 = alloca %"compiler/diagmsg:Msg"
  %l57 = alloca i64
  %l61 = alloca i32
  %l68 = alloca i32
  %l70 = alloca ptr
  %l73 = alloca i64
  %l86 = alloca i64
  %l95 = alloca ptr
  %l96 = alloca ptr
  %l98 = alloca %"compiler/generic:Context"
  %l100 = alloca %"compiler/generic:Context"
  %l105 = alloca ptr
  %l109 = alloca i32
  %l111 = alloca ptr
  %l115 = alloca { i64, ptr }
  %l119 = alloca i64
  %l129 = alloca { i64, ptr }
  %l140 = alloca i1
  %l145 = alloca ptr
  %l147 = alloca %"compiler/source:Span"
  %l150 = alloca { i64, ptr }
  %l153 = alloca ptr
  %l161 = alloca i32
  %l164 = alloca { i64, ptr }
  %l167 = alloca ptr
  %l172 = alloca i32
  %l173 = alloca { i64, ptr }
  %l183 = alloca ptr
  %l185 = alloca %"compiler/source:Span"
  %l191 = alloca %"compiler/diagmsg:Msg"
  %l192 = alloca i64
  %l195 = alloca i64
  %l201 = alloca i64
  %l204 = alloca i64
  %l223 = alloca ptr
  %l226 = alloca { i64, ptr }
  %l229 = alloca { i64, ptr }
  %l232 = alloca ptr
  %l238 = alloca { i64, ptr }
  %l239 = alloca ptr
  %l241 = alloca %"compiler/source:Span"
  %l243 = alloca %"compiler/source:Span"
  %l244 = alloca i32
  %l248 = alloca %"compiler/typed:Make"
  %l257 = alloca { i64, ptr }
  %l258 = alloca %"compiler/typed:Block"
  %l260 = alloca ptr
  %l265 = alloca i1
  %l268 = alloca i1
  %l270 = alloca ptr
  %l274 = alloca i1
  %l276 = alloca i1
  %l278 = alloca ptr
  %l280 = alloca %"compiler/source:Span"
  %l281 = alloca %"compiler/diagmsg:Msg"
  %l282 = alloca i64
  %l284 = alloca ptr
  %l287 = alloca { i64, ptr }
  %l293 = alloca %"compiler/source:Span"
  %l294 = alloca i32
  %l297 = alloca i32
  %l298 = alloca { i64, ptr }
  %l303 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca ptr
  %t99 = alloca { i64, [2 x i64] }, align 8
  %t144 = alloca %"compiler/generic:Context", align 8
  %t275 = alloca { i64, [3 x i64] }, align 8
  %t467 = alloca { i64, [5 x i64] }, align 8
  %t479 = alloca { i64, [3 x i64] }, align 8
  %t584 = alloca { i64, [4 x i64] }, align 8
  %t596 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Catch", ptr %t1, i32 0, i32 4
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/ast:Catch", ptr %t6, i32 0, i32 2
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t13 = icmp sgt i64 %t11, 0
  store i1 %t13, ptr %l30, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l30, !tbaa !21
  store i1 %t15, ptr %l4, !tbaa !21
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/ast:Catch", ptr %t16, i32 0, i32 3
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  %t23 = icmp sgt i64 %t21, 0
  store i1 %t23, ptr %l5, !tbaa !21
  %t25 = load i1, ptr %l4, !tbaa !21
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb4, label %bb5
bb4:
  %t29 = load i1, ptr %l5, !tbaa !21
  %t31 = xor i1 %t29, true
  store i1 %t31, ptr %l41, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb6
bb6:
  %t33 = load i1, ptr %l41, !tbaa !21
  br i1 %t33, label %bb7, label %bb8
bb7:
  %t34 = load i64, ptr %l3, !tbaa !24
  %t36 = icmp eq i64 %t34, 0
  store i1 %t36, ptr %l44, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l44, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t40 = load i1, ptr %l5, !tbaa !21
  br i1 %t40, label %bb13, label %bb14
bb13:
  %t42 = load i64, ptr %l3, !tbaa !24
  %t44 = icmp eq i64 %t42, 0
  store i1 %t44, ptr %l49, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb15
bb15:
  %t46 = load i1, ptr %l49, !tbaa !21
  br i1 %t46, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s2
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l52, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t52 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultSpan(ptr %v0, ptr %v1, ptr %t48, ptr %t49)
  store %"compiler/source:Span" %t52, ptr %l55
  br label %bb18
bb17:
  br label %bb21
bb18:
  %t53 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTaskDefaultInStatement(ptr %s2)
  store %"compiler/diagmsg:Msg" %t53, ptr %l56
  br label %bb19
bb19:
  %t54 = load ptr, ptr %l52, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l55
  %t56 = load %"compiler/diagmsg:Msg", ptr %l56
  %t57 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t54, %"compiler/source:Span" %t55, %"compiler/diagmsg:Msg" %t56)
  store i64 %t57, ptr %l57
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb21:
  %t59 = load i64, ptr %l3, !tbaa !24
  %t61 = icmp sgt i64 %t59, 0
  br i1 %t61, label %bb22, label %bb23
bb22:
  %t63 = load i32, ptr %l2, !tbaa !23
  store i32 %t63, ptr %l61, !tbaa !23
  br label %bb24
bb23:
  %t65 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t65, ptr %l61, !tbaa !23
  br label %bb24
bb24:
  %t67 = load i32, ptr %l61, !tbaa !23
  store i32 %t67, ptr %l6, !tbaa !23
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/check:Checker", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/generic:Program", ptr %t71, i32 0, i32 2
  %t74 = load i32, ptr %l6, !tbaa !23
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t73, i32 0, i32 %t74, i32 0, i32 0, i64 0, i1 false, i32 0)
  store i32 %t77, ptr %l68
  br label %bb25
bb25:
  %t78 = load i32, ptr %l68, !tbaa !23
  store i32 %t78, ptr %l7, !tbaa !23
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t79)
  store ptr %t81, ptr %l70
  br label %bb26
bb26:
  %t82 = load ptr, ptr %l70, !tbaa !29
  store ptr %t82, ptr %l8, !tbaa !29
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 16
  %t87 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t85)
  store i64 %t87, ptr %l73
  br label %bb27
bb27:
  %t88 = load i64, ptr %l73, !tbaa !24
  %t89 = sub i64 %t88, 1
  store i64 %t89, ptr %l9, !tbaa !24
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l8, !tbaa !29
  %t94 = getelementptr %"compiler/check:frame", ptr %t92, i32 0, i32 0
  %t95 = load i64, ptr %t94, !tbaa !24
  %t97 = trunc i64 %t95 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t99
  %t100 = getelementptr { i64, [2 x i64] }, ptr %t99, i32 0, i32 0
  store i64 4, ptr %t100
  %t102 = insertvalue { i32 } undef, i32 %t97, 0
  %t103 = getelementptr { i64, [2 x i64] }, ptr %t99, i32 0, i32 1
  store { i32 } %t102, ptr %t103
  %t104 = load { i64, [2 x i64] }, ptr %t99
  %t105 = load i32, ptr %l7, !tbaa !23
  %t106 = load ptr, ptr %l8, !tbaa !29
  %t108 = getelementptr %"compiler/check:frame", ptr %t106, i32 0, i32 1
  %t109 = load i64, ptr %t108, !tbaa !24
  %t110 = load ptr, ptr %l1, !tbaa !29
  %t112 = getelementptr %"compiler/ast:Catch", ptr %t110, i32 0, i32 0
  %t113 = load %"compiler/source:Span", ptr %t112
  %t119 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t91, { i64, [2 x i64] } %t104, i32 %t105, i64 %t109, %"compiler/source:Span" %t113)
  store i64 %t119, ptr %l86
  br label %bb28
bb28:
  %t120 = load i64, ptr %l86, !tbaa !24
  store i64 %t120, ptr %l10, !tbaa !24
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/check:Checker", ptr %t121, i32 0, i32 19
  %t124 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t123, i64 %t124, i64 1)
  br label %bb29
bb29:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load i64, ptr %l10, !tbaa !24
  %t129 = load ptr, ptr %l8, !tbaa !29
  %t131 = getelementptr %"compiler/check:frame", ptr %t129, i32 0, i32 1
  %t132 = load i64, ptr %t131, !tbaa !24
  %t133 = load i32, ptr %l6, !tbaa !23
  %t138 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t127, i64 %t128, i64 %t132, i32 %t133, i32 0)
  store ptr %t138, ptr %l95
  br label %bb30
bb30:
  %t139 = load ptr, ptr %l95, !tbaa !29
  store ptr %t139, ptr %l11, !tbaa !29
  %t140 = load ptr, ptr %l11, !tbaa !29
  store ptr %t140, ptr %l96, !tbaa !29
  %t141 = load ptr, ptr %l8, !tbaa !29
  %t143 = getelementptr %"compiler/check:frame", ptr %t141, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %l98, ptr %t143, i64 160, i1 false)
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fgeneric_3aContext(ptr %t144, ptr %v0, ptr %l98)
  call void @llvm.memmove.p0.p0.i64(ptr %l100, ptr %t144, i64 160, i1 false)
  br label %bb31
bb31:
  %t146 = load ptr, ptr %l96, !tbaa !29
  %t147 = getelementptr %"compiler/check:frame", ptr %t146, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %t147, ptr %l100, i64 160, i1 false)
  %t148 = load ptr, ptr %l11, !tbaa !29
  %t149 = load i64, ptr %l9, !tbaa !24
  %t152 = getelementptr %"compiler/check:frame", ptr %t148, i32 0, i32 19
  store i64 %t149, ptr %t152, !tbaa !24
  %t153 = load ptr, ptr %l11, !tbaa !29
  %t155 = getelementptr %"compiler/check:frame", ptr %t153, i32 0, i32 32
  store i1 true, ptr %t155, !tbaa !21
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t156)
  store ptr %t158, ptr %l105
  br label %bb32
bb32:
  %t159 = load ptr, ptr %l1, !tbaa !29
  %t161 = getelementptr %"compiler/ast:Catch", ptr %t159, i32 0, i32 0
  %t162 = load %"compiler/source:Span", ptr %t161
  %t163 = load ptr, ptr %l105, !tbaa !29
  %t166 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t163, i32 -1, i32 0, %"compiler/source:Span" %t162)
  store i32 %t166, ptr %l109
  br label %bb33
bb33:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t167)
  store ptr %t169, ptr %l111
  br label %bb34
bb34:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/check:Checker", ptr %t170, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !29
  %t174 = load i32, ptr %l7, !tbaa !23
  %t177 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t173, i32 %t174)
  store { i64, ptr } %t177, ptr %l115
  br label %bb35
bb35:
  %t178 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t178, 0
  %t180 = extractvalue { i64, ptr } %t178, 1
  %t181 = mul i64 %t179, 8
  %t182 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t181)
  call void @llvm.memcpy.p0.p0.i64(ptr %t182, ptr %t180, i64 %t181, i1 false)
  %t183 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t182, 1
  %t185 = load ptr, ptr %l111, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eSetVars(ptr %v0, ptr %s0, ptr %t185, { i64, ptr } %t184)
  br label %bb36
bb36:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/check:Checker", ptr %t187, i32 0, i32 37
  %t191 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t189)
  store i64 %t191, ptr %l119
  br label %bb37
bb37:
  %t192 = load i64, ptr %l119, !tbaa !24
  store i64 %t192, ptr %l12, !tbaa !24
  %t193 = load i1, ptr %l4, !tbaa !21
  br i1 %t193, label %bb38, label %bb39
bb38:
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = getelementptr %"compiler/ast:Catch", ptr %t195, i32 0, i32 2
  %t198 = load { i64, ptr }, ptr %t197, !tbaa !27
  store { i64, ptr } %t198, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t200 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t202 = extractvalue { i64, ptr } %t200, 0
  store i64 %t202, ptr %l15, !tbaa !24
  br label %bb40
bb39:
  br label %bb47
bb40:
  %t204 = load i64, ptr %l14, !tbaa !24
  %t205 = load i64, ptr %l15, !tbaa !24
  %t208 = icmp slt i64 %t204, %t205
  %t210 = xor i1 %t208, true
  br i1 %t210, label %bb41, label %bb42
bb41:
  br label %bb46
bb42:
  br label %bb43
bb43:
  %t212 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t212, ptr %l129, !tbaa !27
  %t213 = load i64, ptr %l14, !tbaa !24
  %t215 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !27
  %t217 = getelementptr ptr, ptr %t216, i64 %t213
  %t218 = load ptr, ptr %t217, !tbaa !39
  %t220 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %t220, ptr %t218)
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t225 = load i64, ptr %l14, !tbaa !24
  %t227 = add i64 %t225, 1
  store i64 %t227, ptr %l14, !tbaa !24
  br label %bb40
bb46:
  br label %bb47
bb47:
  %t229 = load i1, ptr %l5, !tbaa !21
  br i1 %t229, label %bb48, label %bb49
bb48:
  %t231 = load i64, ptr %l3, !tbaa !24
  %t233 = icmp eq i64 %t231, 1
  br i1 %t233, label %bb50, label %bb51
bb49:
  br label %bb91
bb50:
  store i1 true, ptr %l140, !tbaa !21
  br label %bb52
bb51:
  %t235 = load ptr, ptr %l1, !tbaa !29
  %t237 = getelementptr %"compiler/ast:Catch", ptr %t235, i32 0, i32 3
  %t238 = load { i64, ptr }, ptr %t237, !tbaa !27
  %t240 = extractvalue { i64, ptr } %t238, 0
  %t242 = icmp eq i64 %t240, 1
  store i1 %t242, ptr %l140, !tbaa !21
  br label %bb52
bb52:
  %t244 = load i1, ptr %l140, !tbaa !21
  br i1 %t244, label %bb53, label %bb54
bb53:
  %t245 = load ptr, ptr %l0, !tbaa !29
  store ptr %t245, ptr %l145, !tbaa !29
  %t246 = load ptr, ptr %l1, !tbaa !29
  %t248 = getelementptr %"compiler/ast:Catch", ptr %t246, i32 0, i32 0
  %t249 = load %"compiler/source:Span", ptr %t248
  store %"compiler/source:Span" %t249, ptr %l147
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load ptr, ptr %l1, !tbaa !29
  %t253 = getelementptr %"compiler/ast:Catch", ptr %t251, i32 0, i32 3
  %t254 = load { i64, ptr }, ptr %t253, !tbaa !27
  store { i64, ptr } %t254, ptr %l150, !tbaa !27
  %t255 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t256 = load ptr, ptr %t255, !tbaa !27
  %t257 = getelementptr ptr, ptr %t256, i64 0
  %t258 = load ptr, ptr %t257, !tbaa !39
  %t259 = load i32, ptr %l2, !tbaa !23
  %t263 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etaskDefault(ptr %v0, ptr %v1, ptr %v0, ptr %t250, ptr %t258, i32 %t259)
  store ptr %t263, ptr %l153
  br label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s9
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t266 = getelementptr %"compiler/check:Checker", ptr %t264, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !29
  %t269 = getelementptr %"compiler/generic:Program", ptr %t267, i32 0, i32 2
  %t270 = load i32, ptr %l2, !tbaa !23
  %t273 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t269, i32 %t270)
  store i32 %t273, ptr %l161
  br label %bb57
bb55:
  %t274 = load ptr, ptr %l153, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t275
  %t276 = getelementptr { i64, [3 x i64] }, ptr %t275, i32 0, i32 0
  store i64 6, ptr %t276
  %t277 = load %"compiler/source:Span", ptr %l147
  %t278 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t277, 0
  %t280 = insertvalue { %"compiler/source:Span", ptr } %t278, ptr %t274, 1
  %t281 = getelementptr { i64, [3 x i64] }, ptr %t275, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t280, ptr %t281
  %t282 = load { i64, [3 x i64] }, ptr %t275
  %t284 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t282, ptr %t284
  %t285 = load ptr, ptr %l145, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t285, ptr %t284)
  br label %bb56
bb56:
  br label %bb90
bb57:
  %t287 = load i32, ptr %l161, !range !{i32 0, i32 33}
  %t289 = trunc i64 22 to i32
  %t290 = icmp eq i32 %t287, %t289
  br i1 %t290, label %bb58, label %bb59
bb58:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"compiler/check:Checker", ptr %t292, i32 0, i32 1
  %t295 = load ptr, ptr %t294, !tbaa !29
  %t297 = getelementptr %"compiler/generic:Program", ptr %t295, i32 0, i32 2
  store ptr %t297, ptr %l167, !tbaa !29
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t300 = getelementptr %"compiler/check:Checker", ptr %t298, i32 0, i32 1
  %t301 = load ptr, ptr %t300, !tbaa !29
  %t303 = getelementptr %"compiler/generic:Program", ptr %t301, i32 0, i32 2
  %t304 = load i32, ptr %l2, !tbaa !23
  %t307 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t303, i32 %t304)
  store i32 %t307, ptr %l172
  br label %bb60
bb59:
  %t308 = icmp sge i64 0, 0
  br i1 %t308, label %bb62, label %bb63
bb60:
  %t310 = load ptr, ptr %l167, !tbaa !29
  %t311 = load i32, ptr %l172, !tbaa !23
  %t312 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s9, ptr %t310, i32 %t311)
  store { i64, ptr } %t312, ptr %l173
  br label %bb61
bb61:
  %t313 = load { i64, ptr }, ptr %l173, !tbaa !27
  store { i64, ptr } %t313, ptr %l164, !tbaa !27
  br label %bb66
bb62:
  %t314 = icmp sle i64 0, 2305843009213693951
  br i1 %t314, label %bb64, label %bb65
bb63:
  call void @__olang_check_failed(ptr @olang_loc_b7a62f2efaadd4af_1b278ceebf7ddf33)
  unreachable
bb64:
  %t316 = mul i64 0, 4
  %t317 = insertvalue { i64, ptr } undef, i64 0, 0
  %t318 = insertvalue { i64, ptr } %t317, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t318, ptr %l164, !tbaa !27
  br label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_b7a62f2efaadd4af_1b278ceebf7ddf33)
  unreachable
bb66:
  %t320 = load { i64, ptr }, ptr %l164, !tbaa !27
  store { i64, ptr } %t320, ptr %l17, !tbaa !27
  %t321 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t323 = extractvalue { i64, ptr } %t321, 0
  %t324 = load ptr, ptr %l1, !tbaa !29
  %t326 = getelementptr %"compiler/ast:Catch", ptr %t324, i32 0, i32 3
  %t327 = load { i64, ptr }, ptr %t326, !tbaa !27
  %t329 = extractvalue { i64, ptr } %t327, 0
  %t332 = icmp ne i64 %t323, %t329
  br i1 %t332, label %bb67, label %bb68
bb67:
  store %olang.scope zeroinitializer, ptr %s10
  %t334 = load ptr, ptr %l0, !tbaa !29
  store ptr %t334, ptr %l183, !tbaa !29
  %t335 = load ptr, ptr %l1, !tbaa !29
  %t337 = getelementptr %"compiler/ast:Catch", ptr %t335, i32 0, i32 0
  %t338 = load %"compiler/source:Span", ptr %t337
  store %"compiler/source:Span" %t338, ptr %l185
  %t339 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t341 = extractvalue { i64, ptr } %t339, 0
  %t342 = load ptr, ptr %l1, !tbaa !29
  %t344 = getelementptr %"compiler/ast:Catch", ptr %t342, i32 0, i32 3
  %t345 = load { i64, ptr }, ptr %t344, !tbaa !27
  %t347 = extractvalue { i64, ptr } %t345, 0
  %t350 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDestructCount(ptr %s10, i64 %t341, i64 %t347)
  store %"compiler/diagmsg:Msg" %t350, ptr %l191
  br label %bb69
bb68:
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t353 = getelementptr %"compiler/check:Checker", ptr %t351, i32 0, i32 36
  %t355 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t353)
  store i64 %t355, ptr %l195
  br label %bb71
bb69:
  %t356 = load ptr, ptr %l183, !tbaa !29
  %t357 = load %"compiler/source:Span", ptr %l185
  %t358 = load %"compiler/diagmsg:Msg", ptr %l191
  %t359 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s10, ptr %t356, %"compiler/source:Span" %t357, %"compiler/diagmsg:Msg" %t358)
  store i64 %t359, ptr %l192
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s10)
  br label %bb89
bb71:
  %t360 = load i64, ptr %l195, !tbaa !24
  store i64 %t360, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  %t361 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t363 = extractvalue { i64, ptr } %t361, 0
  store i64 %t363, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t365 = load i64, ptr %l20, !tbaa !24
  %t366 = load i64, ptr %l19, !tbaa !24
  %t369 = icmp sgt i64 %t365, %t366
  br i1 %t369, label %bb72, label %bb73
bb72:
  %t371 = load i64, ptr %l21, !tbaa !24
  %t373 = icmp sgt i64 %t371, 0
  br i1 %t373, label %bb74, label %bb75
bb73:
  store i64 0, ptr %l201, !tbaa !24
  br label %bb77
bb74:
  %t375 = load i64, ptr %l20, !tbaa !24
  %t376 = load i64, ptr %l19, !tbaa !24
  %t379 = sub i64 %t375, %t376
  %t380 = load i64, ptr %l21, !tbaa !24
  %t383 = add i64 %t379, %t380
  %t385 = sub i64 %t383, 1
  %t386 = load i64, ptr %l21, !tbaa !24
  %t389 = sdiv i64 %t385, %t386
  store i64 %t389, ptr %l204, !tbaa !24
  br label %bb76
bb75:
  store i64 0, ptr %l204, !tbaa !24
  br label %bb76
bb76:
  %t391 = load i64, ptr %l204, !tbaa !24
  store i64 %t391, ptr %l201, !tbaa !24
  br label %bb77
bb77:
  %t392 = load i64, ptr %l201, !tbaa !24
  store i64 %t392, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb78
bb78:
  %t393 = load i64, ptr %l23, !tbaa !24
  %t394 = load i64, ptr %l22, !tbaa !24
  %t397 = icmp slt i64 %t393, %t394
  %t399 = xor i1 %t397, true
  br i1 %t399, label %bb79, label %bb80
bb79:
  br label %bb85
bb80:
  br label %bb81
bb81:
  %t401 = load i64, ptr %l19, !tbaa !24
  %t402 = load i64, ptr %l23, !tbaa !24
  %t403 = load i64, ptr %l21, !tbaa !24
  %t406 = mul i64 %t402, %t403
  %t409 = add i64 %t401, %t406
  store i64 %t409, ptr %l24, !tbaa !24
  %t411 = load ptr, ptr %l0, !tbaa !29
  %t413 = getelementptr %"compiler/check:Checker", ptr %t411, i32 0, i32 36
  store ptr %t413, ptr %l223, !tbaa !29
  %t414 = load ptr, ptr %l0, !tbaa !29
  %t415 = load ptr, ptr %l1, !tbaa !29
  %t417 = getelementptr %"compiler/ast:Catch", ptr %t415, i32 0, i32 3
  %t418 = load { i64, ptr }, ptr %t417, !tbaa !27
  store { i64, ptr } %t418, ptr %l226, !tbaa !27
  %t419 = load i64, ptr %l24, !tbaa !24
  %t421 = getelementptr { i64, ptr }, ptr %l226, i32 0, i32 1
  %t422 = load ptr, ptr %t421, !tbaa !27
  %t423 = getelementptr ptr, ptr %t422, i64 %t419
  %t424 = load ptr, ptr %t423, !tbaa !39
  %t425 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t425, ptr %l229, !tbaa !27
  %t426 = load i64, ptr %l24, !tbaa !24
  %t428 = getelementptr { i64, ptr }, ptr %l229, i32 0, i32 1
  %t429 = load ptr, ptr %t428, !tbaa !27
  %t430 = getelementptr i32, ptr %t429, i64 %t426
  %t431 = load i32, ptr %t430, !tbaa !33
  %t435 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etaskDefault(ptr %v0, ptr %v1, ptr %v0, ptr %t414, ptr %t424, i32 %t431)
  store ptr %t435, ptr %l232
  br label %bb82
bb82:
  %t436 = load ptr, ptr %l223, !tbaa !29
  %t437 = load ptr, ptr %l232, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t436, ptr %t437)
  br label %bb83
bb83:
  br label %bb84
bb84:
  %t438 = load i64, ptr %l23, !tbaa !24
  %t440 = add i64 %t438, 1
  store i64 %t440, ptr %l23, !tbaa !24
  br label %bb78
bb85:
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t444 = getelementptr %"compiler/check:Checker", ptr %t442, i32 0, i32 36
  %t445 = load i64, ptr %l18, !tbaa !24
  %t448 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t444, i64 %t445)
  store { i64, ptr } %t448, ptr %l238
  br label %bb86
bb86:
  %t449 = load { i64, ptr }, ptr %l238, !tbaa !27
  %t450 = load ptr, ptr %l0, !tbaa !29
  store ptr %t450, ptr %l239, !tbaa !29
  %t451 = load ptr, ptr %l1, !tbaa !29
  %t453 = getelementptr %"compiler/ast:Catch", ptr %t451, i32 0, i32 0
  %t454 = load %"compiler/source:Span", ptr %t453
  store %"compiler/source:Span" %t454, ptr %l241
  %t455 = load ptr, ptr %l1, !tbaa !29
  %t457 = getelementptr %"compiler/ast:Catch", ptr %t455, i32 0, i32 0
  %t458 = load %"compiler/source:Span", ptr %t457
  store %"compiler/source:Span" %t458, ptr %l243
  %t459 = load i32, ptr %l2, !tbaa !23
  store i32 %t459, ptr %l244, !tbaa !23
  %t464 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v0, ptr %v0, i32 0, i64 0, { i64, ptr } %t449, ptr null, i32 -1, i32 0, i1 false)
  store %"compiler/typed:Make" %t464, ptr %l248
  br label %bb87
bb87:
  %t465 = load %"compiler/typed:Make", ptr %l248
  %t466 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/typed:Make" %t465, ptr %t466
  store { i64, [5 x i64] } zeroinitializer, ptr %t467
  %t468 = getelementptr { i64, [5 x i64] }, ptr %t467, i32 0, i32 0
  store i64 7, ptr %t468
  %t469 = load %"compiler/source:Span", ptr %l243
  %t470 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t469, 0
  %t471 = load i32, ptr %l244, !tbaa !23
  %t472 = insertvalue { %"compiler/source:Span", i32, ptr } %t470, i32 %t471, 1
  %t474 = insertvalue { %"compiler/source:Span", i32, ptr } %t472, ptr %t466, 2
  %t475 = getelementptr { i64, [5 x i64] }, ptr %t467, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t474, ptr %t475
  %t476 = load { i64, [5 x i64] }, ptr %t467
  %t478 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t476, ptr %t478
  store { i64, [3 x i64] } zeroinitializer, ptr %t479
  %t480 = getelementptr { i64, [3 x i64] }, ptr %t479, i32 0, i32 0
  store i64 6, ptr %t480
  %t481 = load %"compiler/source:Span", ptr %l241
  %t482 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t481, 0
  %t484 = insertvalue { %"compiler/source:Span", ptr } %t482, ptr %t478, 1
  %t485 = getelementptr { i64, [3 x i64] }, ptr %t479, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t484, ptr %t485
  %t486 = load { i64, [3 x i64] }, ptr %t479
  %t488 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t486, ptr %t488
  %t489 = load ptr, ptr %l239, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t489, ptr %t488)
  br label %bb88
bb88:
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s9)
  br label %bb90
bb90:
  br label %bb91
bb91:
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t493 = getelementptr %"compiler/check:Checker", ptr %t491, i32 0, i32 37
  %t494 = load i64, ptr %l12, !tbaa !24
  %t497 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t493, i64 %t494)
  store { i64, ptr } %t497, ptr %l257
  br label %bb92
bb92:
  %t498 = load { i64, ptr }, ptr %l257, !tbaa !27
  %t499 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 0, { i64, ptr } %t498)
  store %"compiler/typed:Block" %t499, ptr %l258
  br label %bb93
bb93:
  %t500 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store ptr %t500, ptr %lp26
  %t501 = load %"compiler/typed:Block", ptr %l258
  %t502 = load ptr, ptr %lp26
  store %"compiler/typed:Block" %t501, ptr %t502
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t505 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t503)
  store ptr %t505, ptr %l260
  br label %bb94
bb94:
  %t506 = load ptr, ptr %l260, !tbaa !29
  %t507 = load ptr, ptr %lp26
  %t510 = getelementptr %"compiler/typed:Body", ptr %t506, i32 0, i32 11
  store ptr %t507, ptr %t510, !tbaa !29
  %t511 = load i64, ptr %l3, !tbaa !24
  %t513 = icmp sgt i64 %t511, 0
  br i1 %t513, label %bb95, label %bb96
bb95:
  %t515 = load i1, ptr %l5, !tbaa !21
  %t517 = xor i1 %t515, true
  store i1 %t517, ptr %l265, !tbaa !21
  br label %bb97
bb96:
  store i1 false, ptr %l265, !tbaa !21
  br label %bb97
bb97:
  %t519 = load i1, ptr %l265, !tbaa !21
  br i1 %t519, label %bb98, label %bb99
bb98:
  %t520 = load ptr, ptr %l0, !tbaa !29
  %t522 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t520)
  store ptr %t522, ptr %l270
  br label %bb100
bb99:
  store i1 false, ptr %l268, !tbaa !21
  br label %bb101
bb100:
  %t523 = load ptr, ptr %l270, !tbaa !29
  %t525 = getelementptr %"compiler/check:frame", ptr %t523, i32 0, i32 18
  %t526 = load i1, ptr %t525, !tbaa !21
  %t528 = xor i1 %t526, true
  store i1 %t528, ptr %l268, !tbaa !21
  br label %bb101
bb101:
  %t530 = load i1, ptr %l268, !tbaa !21
  br i1 %t530, label %bb102, label %bb103
bb102:
  %t531 = load ptr, ptr %lp26
  %t533 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t531)
  store i1 %t533, ptr %l276
  br label %bb104
bb103:
  store i1 false, ptr %l274, !tbaa !21
  br label %bb105
bb104:
  %t534 = load i1, ptr %l276, !tbaa !21
  %t535 = xor i1 %t534, true
  store i1 %t535, ptr %l274, !tbaa !21
  br label %bb105
bb105:
  %t537 = load i1, ptr %l274, !tbaa !21
  br i1 %t537, label %bb106, label %bb107
bb106:
  store %olang.scope zeroinitializer, ptr %s15
  %t538 = load ptr, ptr %l0, !tbaa !29
  store ptr %t538, ptr %l278, !tbaa !29
  %t539 = load ptr, ptr %l1, !tbaa !29
  %t541 = getelementptr %"compiler/ast:Catch", ptr %t539, i32 0, i32 0
  %t542 = load %"compiler/source:Span", ptr %t541
  store %"compiler/source:Span" %t542, ptr %l280
  %t543 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTaskClauseNeedsDefault(ptr %s15)
  store %"compiler/diagmsg:Msg" %t543, ptr %l281
  br label %bb108
bb107:
  br label %bb110
bb108:
  %t544 = load ptr, ptr %l278, !tbaa !29
  %t545 = load %"compiler/source:Span", ptr %l280
  %t546 = load %"compiler/diagmsg:Msg", ptr %l281
  %t547 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s15, ptr %t544, %"compiler/source:Span" %t545, %"compiler/diagmsg:Msg" %t546)
  store i64 %t547, ptr %l282
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s15)
  br label %bb110
bb110:
  %t548 = load ptr, ptr %l0, !tbaa !29
  %t550 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t548)
  store ptr %t550, ptr %l284
  br label %bb111
bb111:
  %t551 = load ptr, ptr %l284, !tbaa !29
  %t553 = getelementptr %"compiler/check:frame", ptr %t551, i32 0, i32 30
  %t555 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aCapture_26_3e_2eToA_H65e94094dadf75016f6073f244c91f3b(ptr %v0, ptr %v2, ptr %t553)
  store { i64, ptr } %t555, ptr %l287
  br label %bb112
bb112:
  %t556 = load { i64, ptr }, ptr %l287, !tbaa !27
  store { i64, ptr } %t556, ptr %l27, !tbaa !27
  %t557 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t557)
  br label %bb113
bb113:
  %t559 = load ptr, ptr %l0, !tbaa !29
  %t561 = getelementptr %"compiler/check:Checker", ptr %t559, i32 0, i32 19
  %t562 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t561, i64 %t562, i64 2)
  br label %bb114
bb114:
  %t565 = load ptr, ptr %l1, !tbaa !29
  %t567 = getelementptr %"compiler/ast:Catch", ptr %t565, i32 0, i32 0
  %t568 = load %"compiler/source:Span", ptr %t567
  store %"compiler/source:Span" %t568, ptr %l293
  %t569 = load i32, ptr %l7, !tbaa !23
  store i32 %t569, ptr %l294, !tbaa !23
  %t570 = load i64, ptr %l10, !tbaa !24
  %t572 = trunc i64 %t570 to i32
  store i32 %t572, ptr %l297, !tbaa !23
  %t574 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t574, ptr %l298, !tbaa !27
  %t575 = load ptr, ptr %l0, !tbaa !29
  %t576 = load ptr, ptr %l1, !tbaa !29
  %t578 = getelementptr %"compiler/ast:Catch", ptr %t576, i32 0, i32 0
  %t579 = load %"compiler/source:Span", ptr %t578
  %t583 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t575, i32 5, %"compiler/source:Span" %t579)
  store i32 %t583, ptr %l303
  br label %bb115
bb115:
  store { i64, [4 x i64] } zeroinitializer, ptr %t584
  %t585 = getelementptr { i64, [4 x i64] }, ptr %t584, i32 0, i32 0
  store i64 1, ptr %t585
  %t586 = load i32, ptr %l297, !tbaa !23
  %t587 = insertvalue { i32, { i64, ptr }, i32 } undef, i32 %t586, 0
  %t588 = load { i64, ptr }, ptr %l298, !tbaa !27
  %t589 = insertvalue { i32, { i64, ptr }, i32 } %t587, { i64, ptr } %t588, 1
  %t590 = load i32, ptr %l303, !tbaa !23
  %t591 = insertvalue { i32, { i64, ptr }, i32 } %t589, i32 %t590, 2
  %t592 = getelementptr { i64, [4 x i64] }, ptr %t584, i32 0, i32 1
  store { i32, { i64, ptr }, i32 } %t591, ptr %t592
  %t593 = load { i64, [4 x i64] }, ptr %t584
  %t595 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t593, ptr %t595
  store { i64, [5 x i64] } zeroinitializer, ptr %t596
  %t597 = getelementptr { i64, [5 x i64] }, ptr %t596, i32 0, i32 0
  store i64 15, ptr %t597
  %t598 = load %"compiler/source:Span", ptr %l293
  %t599 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t598, 0
  %t600 = load i32, ptr %l294, !tbaa !23
  %t601 = insertvalue { %"compiler/source:Span", i32, ptr } %t599, i32 %t600, 1
  %t603 = insertvalue { %"compiler/source:Span", i32, ptr } %t601, ptr %t595, 2
  %t604 = getelementptr { i64, [5 x i64] }, ptr %t596, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t603, ptr %t604
  %t605 = load { i64, [5 x i64] }, ptr %t596
  %t607 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t605, ptr %t607
  call void @__olang_scope_close(ptr %s0)
  store ptr %t607, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecommuting(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i64
  %l5 = alloca i1
  %l7 = alloca i1
  %l10 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l20 = alloca i1
  %l24 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t3 = call i1 @compiler_2fcheck_2ecommutative(i32 %t1)
  store i1 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i1, ptr %l5, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb5
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t7, i32 %t8)
  store i1 %t11, ptr %l10
  br label %bb4
bb4:
  %t12 = load i1, ptr %l10, !tbaa !21
  %t13 = xor i1 %t12, true
  store i1 %t13, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t15 = load i1, ptr %l7, !tbaa !21
  br i1 %t15, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l13, !tbaa !29
  %t18 = load i32, ptr %l1, !tbaa !23
  store i32 %t18, ptr %l14, !tbaa !23
  %t19 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t21 = call { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %s0, i32 %t19)
  store { i64, ptr } %t21, ptr %l16
  br label %bb9
bb9:
  %t22 = load ptr, ptr %l13, !tbaa !29
  %t23 = load i32, ptr %l14, !tbaa !23
  %t24 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t25 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t22, i32 %t23, { i64, ptr } %t24, i64 1)
  store i64 %t25, ptr %l17
  br label %bb10
bb10:
  %t26 = load i64, ptr %l17, !tbaa !24
  store i64 %t26, ptr %l3, !tbaa !24
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = icmp slt i64 %t27, 0
  br i1 %t29, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb14
bb12:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t35 = load i64, ptr %l3, !tbaa !24
  %t38 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s0, ptr %t34, i64 %t35)
  store ptr %t38, ptr %l24
  br label %bb13
bb13:
  %t39 = load ptr, ptr %l24, !tbaa !29
  %t41 = getelementptr %"compiler/ast:Func", ptr %t39, i32 0, i32 3
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/ast:Sig", ptr %t42, i32 0, i32 6
  %t45 = load i1, ptr %t44, !tbaa !21
  %t47 = xor i1 %t45, true
  store i1 %t47, ptr %l20, !tbaa !21
  br label %bb14
bb14:
  %t49 = load i1, ptr %l20, !tbaa !21
  br i1 %t49, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t51 = load i64, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t51, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomptime(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca { i64, [2 x i64] }
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i32
  %l12 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca ptr
  %l17 = alloca ptr
  %l22 = alloca ptr
  %l33 = alloca ptr
  %l37 = alloca i1
  %l42 = alloca i1
  %l44 = alloca i1
  %l49 = alloca i1
  %l51 = alloca { i64, ptr }
  %l53 = alloca %"compiler/source:Span"
  %l55 = alloca %"compiler/source:Span"
  %l57 = alloca i1
  %l67 = alloca ptr
  %l69 = alloca { i64, ptr }
  %l71 = alloca i1
  %l72 = alloca i64
  %l82 = alloca ptr
  %l89 = alloca ptr
  %l96 = alloca i32
  %l100 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l101 = alloca i64
  %l105 = alloca i64
  %l106 = alloca i32
  %l115 = alloca i64
  %l116 = alloca i32
  %l120 = alloca i32
  %l121 = alloca i32
  %l128 = alloca ptr
  %l139 = alloca i32
  %l142 = alloca %"compiler/source:Span"
  %l148 = alloca i32
  %l155 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t274 = alloca { i64, [4 x i64] }, align 8
  %t318 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l17
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l17, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 14
  %t8 = load ptr, ptr %l4, !tbaa !29
  %t10 = getelementptr %"compiler/check:frame", ptr %t8, i32 0, i32 0
  %t11 = load i64, ptr %t10, !tbaa !24
  %t14 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t7, i64 %t11)
  store ptr %t14, ptr %l22
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l22, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Body", ptr %t15, i32 0, i32 1
  %t18 = load { i64, [2 x i64] }, ptr %t17
  store { i64, [2 x i64] } %t18, ptr %l5
  %t20 = load { i64, [2 x i64] }, ptr %l5
  %t22 = extractvalue { i64, [2 x i64] } %t20, 0
  %t23 = icmp eq i64 %t22, 6
  br i1 %t23, label %bb3, label %bb4
bb3:
  %t25 = getelementptr { i64, [2 x i64] }, ptr %l5, i32 0, i32 1
  %t26 = getelementptr { i64, i32 }, ptr %t25, i32 0, i32 0
  %t27 = load i64, ptr %t26
  store i64 %t27, ptr %l6, !tbaa !24
  %t29 = getelementptr { i64, [2 x i64] }, ptr %l5, i32 0, i32 1
  %t30 = getelementptr { i64, i32 }, ptr %t29, i32 0, i32 1
  %t31 = load i32, ptr %t30
  store i32 %t31, ptr %l7, !tbaa !23
  br label %bb5
bb4:
  br label %bb24
bb5:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i32, ptr %l7, !tbaa !23
  %t42 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %v0, ptr %t36, i64 %t37, i32 %t38)
  store ptr %t42, ptr %l33
  br label %bb6
bb6:
  %t43 = load ptr, ptr %l33, !tbaa !29
  store ptr %t43, ptr %l8, !tbaa !29
  %t44 = load ptr, ptr %l8, !tbaa !29
  %t46 = icmp eq ptr %t44, null
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb7, label %bb8
bb7:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t54 = load i64, ptr %l6, !tbaa !24
  %t55 = load i32, ptr %l7, !tbaa !23
  %t59 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsSynth(ptr %v0, ptr %t53, i64 %t54, i32 %t55)
  store i1 %t59, ptr %l42
  br label %bb9
bb8:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb10
bb9:
  %t60 = load i1, ptr %l42, !tbaa !21
  %t61 = xor i1 %t60, true
  store i1 %t61, ptr %l37, !tbaa !21
  br label %bb10
bb10:
  %t63 = load i1, ptr %l37, !tbaa !21
  br i1 %t63, label %bb11, label %bb12
bb11:
  %t64 = load ptr, ptr %l8, !tbaa !29
  %t66 = getelementptr %"compiler/ast:VarDecl", ptr %t64, i32 0, i32 3
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t71 = icmp sgt i64 %t69, 0
  store i1 %t71, ptr %l44, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb13
bb13:
  %t73 = load i1, ptr %l44, !tbaa !21
  br i1 %t73, label %bb14, label %bb15
bb14:
  %t74 = load ptr, ptr %l8, !tbaa !29
  %t76 = getelementptr %"compiler/ast:VarDecl", ptr %t74, i32 0, i32 3
  %t77 = load { i64, ptr }, ptr %t76, !tbaa !27
  store { i64, ptr } %t77, ptr %l51, !tbaa !27
  %t78 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr ptr, ptr %t79, i64 0
  %t81 = load ptr, ptr %t80, !tbaa !39
  %t83 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t81)
  store %"compiler/source:Span" %t83, ptr %l53
  br label %bb16
bb15:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb18
bb16:
  %t84 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t84, ptr %l55
  %t87 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %l53, ptr %l55)
  store i1 %t87, ptr %l57
  br label %bb17
bb17:
  %t88 = load i1, ptr %l57, !tbaa !21
  store i1 %t88, ptr %l49, !tbaa !21
  br label %bb18
bb18:
  %t89 = load i1, ptr %l49, !tbaa !21
  br i1 %t89, label %bb19, label %bb20
bb19:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t90, i32 0, i32 126
  %t93 = load ptr, ptr %l4, !tbaa !29
  %t95 = getelementptr %"compiler/check:frame", ptr %t93, i32 0, i32 0
  %t96 = load i64, ptr %t95, !tbaa !24
  %t97 = load %"compiler/source:Span", ptr %l1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fsource_3aSpan_3e_2_H19fded22be32a91ca4084130356a325d(ptr %v0, ptr %t92, i64 %t96, %"compiler/source:Span" %t97)
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load ptr, ptr %l2, !tbaa !29
  %t104 = load i32, ptr %l3, !tbaa !23
  %t108 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t101, ptr %t102, i32 %t104)
  store ptr %t108, ptr %l67
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t109 = load ptr, ptr %l67, !tbaa !29
  store ptr %t109, ptr %rv
  br label %ret
bb23:
  br label %bb29
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_fa3c94e3a612a0dd_4761343759351551)
  unreachable
bb29:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomptimeCtx(ptr %v0, ptr %s0, ptr %t110)
  store { i64, ptr } %t112, ptr %l69
  br label %bb30
bb30:
  %t113 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t113, ptr %l9, !tbaa !27
  %t114 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t116 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t114, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t116, ptr %l71
  br label %bb31
bb31:
  %t117 = load i1, ptr %l71, !tbaa !21
  br i1 %t117, label %bb32, label %bb33
bb32:
  %t118 = load ptr, ptr %l4, !tbaa !29
  %t120 = getelementptr %"compiler/check:frame", ptr %t118, i32 0, i32 1
  %t121 = load i64, ptr %t120, !tbaa !24
  store i64 %t121, ptr %l72, !tbaa !24
  br label %bb34
bb33:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/check:Checker", ptr %t123, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t128 = getelementptr %"compiler/generic:Program", ptr %t126, i32 0, i32 0
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/load:Loader", ptr %t129, i32 0, i32 12
  %t132 = load i64, ptr %t131, !tbaa !24
  store i64 %t132, ptr %l72, !tbaa !24
  br label %bb34
bb34:
  %t134 = load i64, ptr %l72, !tbaa !24
  store i64 %t134, ptr %l10, !tbaa !24
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = getelementptr %"compiler/generic:Program", ptr %t138, i32 0, i32 0
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t143 = getelementptr %"compiler/load:Loader", ptr %t141, i32 0, i32 3
  %t144 = load ptr, ptr %t143, !tbaa !29
  store ptr %t144, ptr %l82, !tbaa !29
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/check:Checker", ptr %t145, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !29
  %t150 = getelementptr %"compiler/generic:Program", ptr %t148, i32 0, i32 0
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = getelementptr %"compiler/load:Loader", ptr %t151, i32 0, i32 10
  %t154 = load ptr, ptr %l4, !tbaa !29
  %t156 = getelementptr %"compiler/check:frame", ptr %t154, i32 0, i32 1
  %t157 = load i64, ptr %t156, !tbaa !24
  %t160 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t153, i64 %t157)
  store ptr %t160, ptr %l89
  br label %bb35
bb35:
  %t161 = load ptr, ptr %l89, !tbaa !29
  %t163 = getelementptr %"compiler/load:Module", ptr %t161, i32 0, i32 2
  %t164 = load { i64, ptr }, ptr %t163, !tbaa !27
  %t165 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t166 = load i32, ptr %t165, !tbaa !23
  %t167 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t168 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t169 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t171 = extractvalue { i64, ptr } %t164, 1
  %t172 = extractvalue { i64, ptr } %t164, 0
  %t173 = add i64 %t169, %t172
  %t174 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t175 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t176 = add i64 %t173, %t175
  %t178 = sext i32 %t166 to i64
  %t179 = call i64 @__olang_fmt_i64(ptr null, i64 %t178)
  %t180 = add i64 %t176, %t179
  %t182 = extractvalue { i64, ptr } %t167, 1
  %t183 = extractvalue { i64, ptr } %t167, 0
  %t184 = add i64 %t180, %t183
  %t185 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t184)
  call void @olang_textcopy(ptr %t185, ptr %t168, i64 %t169)
  %t186 = getelementptr i8, ptr %t185, i64 %t169
  call void @olang_textcopy(ptr %t186, ptr %t171, i64 %t172)
  %t187 = getelementptr i8, ptr %t186, i64 %t172
  call void @olang_textcopy(ptr %t187, ptr %t174, i64 %t175)
  %t188 = getelementptr i8, ptr %t187, i64 %t175
  %t189 = call i64 @__olang_fmt_i64(ptr %t188, i64 %t178)
  %t190 = getelementptr i8, ptr %t188, i64 %t179
  call void @olang_textcopy(ptr %t190, ptr %t182, i64 %t183)
  %t191 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t185, 1
  %t194 = extractvalue { i64, ptr } %t192, 0
  %t195 = extractvalue { i64, ptr } %t192, 1
  %t196 = mul i64 %t194, 1
  %t197 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t196)
  call void @llvm.memcpy.p0.p0.i64(ptr %t197, ptr %t195, i64 %t196, i1 false)
  %t198 = insertvalue { i64, ptr } undef, i64 %t194, 0
  %t199 = insertvalue { i64, ptr } %t198, ptr %t197, 1
  %t200 = load ptr, ptr %l82, !tbaa !29
  %t202 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t200, { i64, ptr } %t199)
  store i32 %t202, ptr %l96
  br label %bb36
bb36:
  %t203 = load i32, ptr %l96, !tbaa !23
  store i32 %t203, ptr %l11, !tbaa !23
  %t204 = load i64, ptr %l10, !tbaa !24
  %t205 = load i32, ptr %l11, !tbaa !23
  %t207 = sext i32 %t205 to i64
  %t210 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t204, i64 %t207)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t210, ptr %l100
  br label %bb37
bb37:
  %t211 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l100
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t211, ptr %l12
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/check:Checker", ptr %t212, i32 0, i32 27
  %t215 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l12
  %t218 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t214, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t215)
  %t219 = extractvalue { i32, i64 } %t218, 1
  %t220 = extractvalue { i32, i64 } %t218, 0
  store i32 %t220, ptr %l106
  %t221 = icmp ne i32 %t220, 0
  br i1 %t221, label %bb39, label %ok.222, !prof !99
ok.222:
  store i64 %t219, ptr %l105
  br label %bb38
bb38:
  %t223 = load i64, ptr %l105, !tbaa !24
  store i64 %t223, ptr %l101, !tbaa !24
  br label %bb41
bb39:
  br label %bb40
bb40:
  store i64 -1, ptr %l101, !tbaa !24
  br label %bb41
bb41:
  %t224 = load i64, ptr %l101, !tbaa !24
  store i64 %t224, ptr %l13, !tbaa !24
  %t225 = load i64, ptr %l13, !tbaa !24
  %t227 = icmp slt i64 %t225, 0
  br i1 %t227, label %bb42, label %bb43
bb42:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t230 = load %"compiler/source:Span", ptr %l1
  %t231 = load ptr, ptr %l2, !tbaa !29
  %t232 = load i32, ptr %l3, !tbaa !23
  %t233 = load i64, ptr %l10, !tbaa !24
  %t234 = load i32, ptr %l11, !tbaa !23
  %t241 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomptimeBody(ptr %v0, ptr %v1, ptr %t229, %"compiler/source:Span" %t230, ptr %t231, i32 %t232, i64 %t233, i32 %t234)
  store i64 %t241, ptr %l115
  br label %bb44
bb43:
  br label %bb45
bb44:
  %t242 = load i64, ptr %l115, !tbaa !24
  store i64 %t242, ptr %l13, !tbaa !24
  br label %bb45
bb45:
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t245 = getelementptr %"compiler/check:Checker", ptr %t243, i32 0, i32 28
  %t246 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l12
  %t249 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H3cc70d507a7fc767d013b59b12ee0a99(ptr %v0, ptr %t245, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t246)
  %t250 = extractvalue { i32, i32 } %t249, 1
  %t251 = extractvalue { i32, i32 } %t249, 0
  store i32 %t251, ptr %l121
  %t252 = icmp ne i32 %t251, 0
  br i1 %t252, label %bb47, label %ok.253, !prof !99
ok.253:
  store i32 %t250, ptr %l120
  br label %bb46
bb46:
  %t254 = load i32, ptr %l120, !tbaa !23
  store i32 %t254, ptr %l116, !tbaa !23
  br label %bb49
bb47:
  br label %bb48
bb48:
  %t255 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t255, ptr %l116, !tbaa !23
  br label %bb49
bb49:
  %t257 = load i32, ptr %l116, !tbaa !23
  store i32 %t257, ptr %l14, !tbaa !23
  %t258 = load i32, ptr %l14, !tbaa !23
  %t259 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t262 = icmp eq i32 %t258, %t259
  br i1 %t262, label %bb50, label %bb51
bb50:
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t265 = load %"compiler/source:Span", ptr %l1
  %t268 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t264, %"compiler/source:Span" %t265)
  store ptr %t268, ptr %l128
  br label %bb52
bb51:
  br label %bb53
bb52:
  call void @__olang_scope_close(ptr %s0)
  %t269 = load ptr, ptr %l128, !tbaa !29
  store ptr %t269, ptr %rv
  br label %ret
bb53:
  %t270 = load %"compiler/source:Span", ptr %l1
  %t271 = load i32, ptr %l14, !tbaa !23
  %t272 = load i64, ptr %l10, !tbaa !24
  %t273 = load i32, ptr %l11, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t274
  %t275 = getelementptr { i64, [4 x i64] }, ptr %t274, i32 0, i32 0
  store i64 1, ptr %t275
  %t277 = insertvalue { %"compiler/source:Span", i32, i64, i32 } undef, %"compiler/source:Span" %t270, 0
  %t279 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t277, i32 %t271, 1
  %t281 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t279, i64 %t272, 2
  %t283 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t281, i32 %t273, 3
  %t284 = getelementptr { i64, [4 x i64] }, ptr %t274, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, i32 } %t283, ptr %t284
  %t285 = load { i64, [4 x i64] }, ptr %t274
  %t287 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t285, ptr %t287
  store ptr %t287, ptr %l15, !tbaa !29
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t291 = getelementptr %"compiler/check:Checker", ptr %t289, i32 0, i32 1
  %t292 = load ptr, ptr %t291, !tbaa !29
  %t294 = getelementptr %"compiler/generic:Program", ptr %t292, i32 0, i32 2
  %t295 = load i32, ptr %l14, !tbaa !23
  %t298 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t294, i32 %t295)
  store i32 %t298, ptr %l139
  br label %bb54
bb54:
  %t299 = load i32, ptr %l139, !range !{i32 0, i32 33}
  %t301 = trunc i64 19 to i32
  %t302 = icmp eq i32 %t299, %t301
  br i1 %t302, label %bb55, label %bb56
bb55:
  %t304 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t304, ptr %l142
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t307 = getelementptr %"compiler/check:Checker", ptr %t305, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !29
  %t310 = getelementptr %"compiler/generic:Program", ptr %t308, i32 0, i32 2
  %t311 = load i32, ptr %l14, !tbaa !23
  %t312 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t316 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t310, i32 %t311, i64 %t312)
  store i32 %t316, ptr %l148
  br label %bb57
bb56:
  br label %bb58
bb57:
  %t317 = load ptr, ptr %l15, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t318
  %t319 = getelementptr { i64, [5 x i64] }, ptr %t318, i32 0, i32 0
  store i64 3, ptr %t319
  %t320 = load %"compiler/source:Span", ptr %l142
  %t321 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t320, 0
  %t322 = load i32, ptr %l148, !tbaa !23
  %t323 = insertvalue { %"compiler/source:Span", i32, ptr } %t321, i32 %t322, 1
  %t325 = insertvalue { %"compiler/source:Span", i32, ptr } %t323, ptr %t317, 2
  %t326 = getelementptr { i64, [5 x i64] }, ptr %t318, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t325, ptr %t326
  %t327 = load { i64, [5 x i64] }, ptr %t318
  %t329 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t327, ptr %t329
  call void @__olang_scope_close(ptr %s0)
  store ptr %t329, ptr %rv
  br label %ret
bb58:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t332 = load %"compiler/source:Span", ptr %l1
  %t333 = load ptr, ptr %l15, !tbaa !29
  %t337 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v2, ptr %v2, ptr %t331, %"compiler/source:Span" %t332, ptr %t333)
  store ptr %t337, ptr %l155
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s0)
  %t338 = load ptr, ptr %l155, !tbaa !29
  store ptr %t338, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecountsTo(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i1
  %l14 = alloca i1
  %l16 = alloca { i64, ptr }
  %l19 = alloca i1
  %l20 = alloca i1
  %l24 = alloca i1
  %l26 = alloca { i64, ptr }
  %l28 = alloca i1
  %l29 = alloca i1
  %l31 = alloca { i64, ptr }
  %l34 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 24
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t12, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  br label %bb21
bb5:
  %t16 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  %t20 = icmp eq i64 %t18, 1
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t23, ptr %l16, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr ptr, ptr %t25, i64 0
  %t27 = load ptr, ptr %t26, !tbaa !39
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t32 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esameLen(ptr %v0, ptr %v1, ptr %v2, ptr %t22, ptr %t27, ptr %t28)
  store i1 %t32, ptr %l19
  br label %bb8
bb7:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb9
bb8:
  %t33 = load i1, ptr %l19, !tbaa !21
  store i1 %t33, ptr %l14, !tbaa !21
  br label %bb9
bb9:
  %t34 = load i1, ptr %l14, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb20
bb11:
  %t35 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t39 = icmp eq i64 %t37, 2
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t42, ptr %l26, !tbaa !27
  %t43 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr ptr, ptr %t44, i64 0
  %t46 = load ptr, ptr %t45, !tbaa !39
  %t49 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisZeroLit(ptr %v0, ptr %v1, ptr %t41, ptr %t46)
  store i1 %t49, ptr %l28
  br label %bb14
bb13:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb15
bb14:
  %t50 = load i1, ptr %l28, !tbaa !21
  store i1 %t50, ptr %l24, !tbaa !21
  br label %bb15
bb15:
  %t51 = load i1, ptr %l24, !tbaa !21
  br i1 %t51, label %bb16, label %bb17
bb16:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t53, ptr %l31, !tbaa !27
  %t54 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr ptr, ptr %t55, i64 1
  %t57 = load ptr, ptr %t56, !tbaa !39
  %t58 = load ptr, ptr %l2, !tbaa !29
  %t62 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esameLen(ptr %v0, ptr %v1, ptr %v2, ptr %t52, ptr %t57, ptr %t58)
  store i1 %t62, ptr %l34
  br label %bb18
bb17:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb19
bb18:
  %t63 = load i1, ptr %l34, !tbaa !21
  store i1 %t63, ptr %l29, !tbaa !21
  br label %bb19
bb19:
  %t64 = load i1, ptr %l29, !tbaa !21
  store i1 %t64, ptr %l20, !tbaa !21
  br label %bb20
bb20:
  %t65 = load i1, ptr %l20, !tbaa !21
  store i1 %t65, ptr %l4, !tbaa !21
  br label %bb26
bb21:
  br i1 true, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_d2b428b6a63c5a88_9cb41cac42ab9d54)
  unreachable
bb26:
  %t66 = load i1, ptr %l4, !tbaa !21
  store i1 %t66, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecoversStruct(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, { i64, ptr } %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l26 = alloca ptr
  %l29 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca { i64, ptr }
  %l47 = alloca i32
  %l48 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l51 = alloca i64
  %l53 = alloca i64
  %l58 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l62 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l73 = alloca ptr
  %l74 = alloca i1
  %l83 = alloca i32
  %l93 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l101 = alloca { i64, ptr }
  %l115 = alloca { i64, ptr }
  %l122 = alloca ptr
  %l123 = alloca ptr
  %l125 = alloca { i64, ptr }
  %l128 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estructFields(ptr %v0, ptr %s0, ptr %t1, i32 %t2)
  store ptr %t5, ptr %l26
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l26, !tbaa !29
  store ptr %t6, ptr %l5, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  store ptr %t12, ptr %l29, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l2, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l34
  br label %bb2
bb2:
  %t23 = load ptr, ptr %l29, !tbaa !29
  %t24 = load i32, ptr %l34, !tbaa !23
  %t25 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t23, i32 %t24)
  store { i64, ptr } %t25, ptr %l35
  br label %bb3
bb3:
  %t26 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t26, ptr %l6, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t30 = load ptr, ptr %l5, !tbaa !29
  %t32 = getelementptr %"compiler/check:fieldSet", ptr %t30, i32 0, i32 0
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t38 = icmp ne i64 %t29, %t35
  br i1 %t38, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 2
  %t47 = load i32, ptr %l2, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t50, ptr %l47
  br label %bb7
bb7:
  %t51 = load i32, ptr %l47, !tbaa !23
  store i32 %t51, ptr %l7, !tbaa !23
  %t52 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t52, ptr %l48
  br label %bb8
bb8:
  %t53 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l48
  %t54 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t53, ptr %t54
  store ptr %t54, ptr %l8, !tbaa !29
  store ptr %a1, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb9
bb9:
  %t58 = load i64, ptr %l10, !tbaa !24
  store i64 %t58, ptr %l51, !tbaa !24
  %t59 = load ptr, ptr %l9, !tbaa !29
  %t61 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H06f4ae43b564aa38800728c5b9a6edfe(ptr %v1, ptr %t59)
  store i64 %t61, ptr %l53
  br label %bb10
bb10:
  %t62 = load i64, ptr %l51, !tbaa !24
  %t63 = load i64, ptr %l53, !tbaa !24
  %t64 = icmp slt i64 %t62, %t63
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb11, label %bb12
bb11:
  br label %bb42
bb12:
  br label %bb13
bb13:
  %t68 = load ptr, ptr %l9, !tbaa !29
  %t69 = load i64, ptr %l10, !tbaa !24
  %t72 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_Hb04d670045d084ea2498d9030c4fbba9(ptr %v1, ptr %v1, ptr %t68, i64 %t69)
  store { i64, ptr } %t72, ptr %l58
  br label %bb14
bb14:
  %t73 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t73, ptr %l11, !tbaa !27
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t75, ptr %l60, !tbaa !27
  %t76 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr ptr, ptr %t77, i64 0
  %t79 = load ptr, ptr %t78, !tbaa !39
  %t82 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatWild(ptr %v0, ptr %v1, ptr %t74, ptr %t79)
  store i1 %t82, ptr %l62
  br label %bb15
bb15:
  %t83 = load i1, ptr %l62, !tbaa !21
  br i1 %t83, label %bb16, label %bb17
bb16:
  %t84 = load ptr, ptr %l8, !tbaa !29
  store ptr %t84, ptr %l63, !tbaa !29
  %t85 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t85, ptr %l64, !tbaa !27
  %t86 = icmp sge i64 0, 0
  br i1 %t86, label %bb18, label %bb19
bb17:
  br label %bb24
bb18:
  %t88 = icmp sle i64 0, 1152921504606846975
  br i1 %t88, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_26959ece93e3b5d7_ef6153c643f98adb)
  unreachable
bb20:
  %t90 = mul i64 0, 8
  %t91 = insertvalue { i64, ptr } undef, i64 0, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t93 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t96 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t99 = call { i64, ptr } @compiler_2fcheck_2epatTail(ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t96, { i64, ptr } %t92, i64 %t95)
  store { i64, ptr } %t99, ptr %l70
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_26959ece93e3b5d7_ef6153c643f98adb)
  unreachable
bb22:
  %t100 = load ptr, ptr %l63, !tbaa !29
  %t101 = load { i64, ptr }, ptr %l70, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H19842cc3f9f17801919cd111c108caa0(ptr %s0, ptr %v1, ptr %t100, { i64, ptr } %t101)
  br label %bb23
bb23:
  br label %bb41
bb24:
  %t102 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t102, ptr %l71, !tbaa !27
  %t103 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = getelementptr ptr, ptr %t104, i64 0
  %t106 = load ptr, ptr %t105, !tbaa !39
  store ptr %t106, ptr %l12, !tbaa !29
  %t108 = load ptr, ptr %l12, !tbaa !29
  store ptr %t108, ptr %l73, !tbaa !29
  store i1 false, ptr %l74, !tbaa !21
  %t109 = load ptr, ptr %l73, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb25, label %bb26
bb25:
  %t112 = load ptr, ptr %l73, !tbaa !29
  %t113 = load i64, ptr %t112, !range !{i64 0, i64 9}
  %t115 = icmp eq i64 %t113, 2
  store i1 %t115, ptr %l74, !tbaa !21
  br label %bb26
bb26:
  %t116 = load i1, ptr %l74, !tbaa !21
  br i1 %t116, label %bb27, label %bb28
bb27:
  %t117 = load ptr, ptr %l12, !tbaa !29
  %t119 = getelementptr { i64, [4 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t119, i32 0, i32 1
  %t121 = load ptr, ptr %t120
  store ptr %t121, ptr %l13, !tbaa !29
  %t123 = load ptr, ptr %l12, !tbaa !29
  %t125 = getelementptr { i64, [4 x i64] }, ptr %t123, i32 0, i32 1
  %t126 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t125, i32 0, i32 2
  %t127 = load { i64, ptr }, ptr %t126
  store { i64, ptr } %t127, ptr %l14, !tbaa !27
  br label %bb29
bb28:
  br label %bb35
bb29:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load ptr, ptr %l13, !tbaa !29
  %t133 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estructDecl(ptr %v0, ptr %v1, ptr %t129, ptr %t130)
  store i32 %t133, ptr %l83
  br label %bb30
bb30:
  %t134 = load i32, ptr %l7, !tbaa !23
  %t135 = load i32, ptr %l83, !tbaa !23
  %t137 = icmp eq i32 %t135, %t134
  br i1 %t137, label %bb31, label %bb32
bb31:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load ptr, ptr %l8, !tbaa !29
  %t141 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t142 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t143 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebyFieldRow(ptr %v0, ptr %s0, ptr %v1, ptr %v1, ptr %s0, ptr %t139, ptr %t140, { i64, ptr } %t141, { i64, ptr } %t142, ptr %t143)
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb34
bb34:
  br label %bb40
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_dcaa30bcf0ceb4b1_7307533feb398e7d)
  unreachable
bb40:
  br label %bb41
bb41:
  %t149 = load i64, ptr %l10, !tbaa !24
  %t151 = add i64 %t149, 1
  store i64 %t151, ptr %l10, !tbaa !24
  br label %bb9
bb42:
  %t153 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t153, ptr %l93
  br label %bb43
bb43:
  %t154 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l93
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t154, ptr %l15
  %t155 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t155, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t157 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t157, 0
  store i64 %t159, ptr %l18, !tbaa !24
  br label %bb44
bb44:
  %t161 = load i64, ptr %l17, !tbaa !24
  %t162 = load i64, ptr %l18, !tbaa !24
  %t165 = icmp slt i64 %t161, %t162
  %t167 = xor i1 %t165, true
  br i1 %t167, label %bb45, label %bb46
bb45:
  br label %bb50
bb46:
  br label %bb47
bb47:
  %t169 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t169, ptr %l101, !tbaa !27
  %t170 = load i64, ptr %l17, !tbaa !24
  %t172 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = getelementptr i32, ptr %t173, i64 %t170
  %t175 = load i32, ptr %t174, !tbaa !33
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l15, i32 %t175)
  br label %bb48
bb48:
  br label %bb49
bb49:
  %t180 = load i64, ptr %l17, !tbaa !24
  %t182 = add i64 %t180, 1
  store i64 %t182, ptr %l17, !tbaa !24
  br label %bb44
bb50:
  store { i64, ptr } %a3, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t186 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t186, 0
  store i64 %t188, ptr %l22, !tbaa !24
  br label %bb51
bb51:
  %t190 = load i64, ptr %l21, !tbaa !24
  %t191 = load i64, ptr %l22, !tbaa !24
  %t194 = icmp slt i64 %t190, %t191
  %t196 = xor i1 %t194, true
  br i1 %t196, label %bb52, label %bb53
bb52:
  br label %bb57
bb53:
  br label %bb54
bb54:
  %t198 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t198, ptr %l115, !tbaa !27
  %t199 = load i64, ptr %l21, !tbaa !24
  %t201 = getelementptr { i64, ptr }, ptr %l115, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !27
  %t203 = getelementptr i32, ptr %t202, i64 %t199
  %t204 = load i32, ptr %t203, !tbaa !33
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l15, i32 %t204)
  br label %bb55
bb55:
  br label %bb56
bb56:
  %t209 = load i64, ptr %l21, !tbaa !24
  %t211 = add i64 %t209, 1
  store i64 %t211, ptr %l21, !tbaa !24
  br label %bb51
bb57:
  %t213 = load ptr, ptr %l0, !tbaa !29
  store ptr %t213, ptr %l122, !tbaa !29
  %t214 = load ptr, ptr %l8, !tbaa !29
  store ptr %t214, ptr %l123, !tbaa !29
  %t216 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %s0, ptr %l15)
  store { i64, ptr } %t216, ptr %l125
  br label %bb58
bb58:
  %t219 = add i64 %a4, 1
  %t220 = load ptr, ptr %l122, !tbaa !29
  %t221 = load ptr, ptr %l123, !tbaa !29
  %t222 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t224 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecoversRows(ptr %v0, ptr %s0, ptr %s0, ptr %t220, ptr %t221, { i64, ptr } %t222, i64 %t219)
  store i1 %t224, ptr %l128
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s0)
  %t225 = load i1, ptr %l128, !tbaa !21
  store i1 %t225, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectErr(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, %"compiler/diagmsg:Msg" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l13 = alloca ptr
  %l22 = alloca i64
  %rv = alloca i64
  %t36 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 4
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l7, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/load:Loader", ptr %t17, i32 0, i32 10
  %t23 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t19, i64 %a1)
  store ptr %t23, ptr %l13
  br label %bb1
bb1:
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t26 = getelementptr %"compiler/load:Module", ptr %t24, i32 0, i32 4
  %t27 = load i64, ptr %t26, !tbaa !24
  %t28 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t29 = load i32, ptr %t28, !tbaa !23
  %t31 = sext i32 %t29 to i64
  %t32 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t33 = load i32, ptr %t32, !tbaa !23
  %t35 = sext i32 %t33 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t36
  %t37 = getelementptr { i64, [3 x i64] }, ptr %t36, i32 0, i32 0
  store i64 3, ptr %t37
  %t39 = insertvalue { i64, i64, i64 } undef, i64 %t27, 0
  %t41 = insertvalue { i64, i64, i64 } %t39, i64 %t31, 1
  %t43 = insertvalue { i64, i64, i64 } %t41, i64 %t35, 2
  %t44 = getelementptr { i64, [3 x i64] }, ptr %t36, i32 0, i32 1
  store { i64, i64, i64 } %t43, ptr %t44
  %t45 = load { i64, [3 x i64] }, ptr %t36
  %t47 = load ptr, ptr %l7, !tbaa !29
  %t50 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %t47, { i64, [3 x i64] } %t45, %"compiler/diagmsg:Msg" %a3)
  store i64 %t50, ptr %l22
  br label %bb2
bb2:
  %t51 = load i64, ptr %l22, !tbaa !24
  store i64 %t51, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclAttrs(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca i1
  %l49 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 11}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [8 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb14
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i64, ptr %l1, !tbaa !24
  %t18 = load ptr, ptr %l3, !tbaa !29
  %t20 = getelementptr %"compiler/ast:TypeDecl", ptr %t18, i32 0, i32 4
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrsChecked(ptr %v0, ptr %v1, ptr %t16, i64 %t17, { i64, ptr } %t21)
  br label %bb6
bb6:
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t27 = getelementptr %"compiler/ast:TypeDecl", ptr %t25, i32 0, i32 3
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = icmp eq ptr %t28, null
  %t32 = xor i1 %t30, true
  br i1 %t32, label %bb7, label %bb8
bb7:
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l23, !tbaa !29
  %t35 = load i64, ptr %l1, !tbaa !24
  store i64 %t35, ptr %l24, !tbaa !24
  %t36 = load ptr, ptr %l3, !tbaa !29
  %t38 = getelementptr %"compiler/ast:TypeDecl", ptr %t36, i32 0, i32 3
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = icmp eq ptr %t39, null
  br i1 %t41, label %bb9, label %bb10
bb8:
  br label %bb13
bb9:
  call void @__olang_check_failed(ptr @olang_loc_e375dcd56c8db7ae_8ebec7f18eafef7a)
  unreachable
bb10:
  br label %bb11
bb11:
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t45 = getelementptr %"compiler/ast:TypeDecl", ptr %t43, i32 0, i32 3
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t47 = load ptr, ptr %l23, !tbaa !29
  %t48 = load i64, ptr %l24, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyAttrs(ptr %v0, ptr %v1, ptr %t47, i64 %t48, ptr %t46)
  br label %bb12
bb12:
  br label %bb13
bb13:
  br label %bb33
bb14:
  %t50 = load ptr, ptr %l2, !tbaa !29
  store ptr %t50, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t51 = load ptr, ptr %l30, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb15, label %bb16
bb15:
  %t54 = load ptr, ptr %l30, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 11}
  %t57 = icmp eq i64 %t55, 0
  store i1 %t57, ptr %l31, !tbaa !21
  br label %bb16
bb16:
  %t58 = load i1, ptr %l31, !tbaa !21
  br i1 %t58, label %bb17, label %bb18
bb17:
  %t59 = load ptr, ptr %l2, !tbaa !29
  %t61 = getelementptr { i64, [8 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { ptr }, ptr %t61, i32 0, i32 0
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb28
bb19:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load i64, ptr %l1, !tbaa !24
  %t67 = load ptr, ptr %l4, !tbaa !29
  %t69 = getelementptr %"compiler/ast:Func", ptr %t67, i32 0, i32 8
  %t70 = load { i64, ptr }, ptr %t69, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrsChecked(ptr %v0, ptr %v1, ptr %t65, i64 %t66, { i64, ptr } %t70)
  br label %bb20
bb20:
  %t74 = load ptr, ptr %l4, !tbaa !29
  %t76 = getelementptr %"compiler/ast:Func", ptr %t74, i32 0, i32 3
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/ast:Sig", ptr %t77, i32 0, i32 0
  %t80 = load { i64, ptr }, ptr %t79, !tbaa !27
  store { i64, ptr } %t80, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t82 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t82, 0
  store i64 %t84, ptr %l7, !tbaa !24
  br label %bb21
bb21:
  %t86 = load i64, ptr %l6, !tbaa !24
  %t87 = load i64, ptr %l7, !tbaa !24
  %t90 = icmp slt i64 %t86, %t87
  %t92 = xor i1 %t90, true
  br i1 %t92, label %bb22, label %bb23
bb22:
  br label %bb27
bb23:
  br label %bb24
bb24:
  %t94 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t94, ptr %l49, !tbaa !27
  %t95 = load i64, ptr %l6, !tbaa !24
  %t97 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr ptr, ptr %t98, i64 %t95
  %t100 = load ptr, ptr %t99, !tbaa !39
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load i64, ptr %l1, !tbaa !24
  %t106 = getelementptr %"compiler/ast:Param", ptr %t100, i32 0, i32 4
  %t107 = load { i64, ptr }, ptr %t106, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrsChecked(ptr %v0, ptr %v1, ptr %t102, i64 %t103, { i64, ptr } %t107)
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t111 = load i64, ptr %l6, !tbaa !24
  %t113 = add i64 %t111, 1
  store i64 %t113, ptr %l6, !tbaa !24
  br label %bb21
bb27:
  br label %bb33
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_f43f80063d96068c_f8dacab5994fea88)
  unreachable
bb33:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l4, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t12, i32 %a1)
  store i32 %t16, ptr %l9
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t18 = load i32, ptr %l9, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t19, ptr %l10
  br label %bb2
bb2:
  %t20 = load i32, ptr %l10, !range !{i32 0, i32 6}
  store i32 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescriptor(ptr %v0, ptr %a0, %"compiler/check:reflList" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/check:reflList"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l13 = alloca i32
  %l22 = alloca i32
  %l31 = alloca i32
  %l33 = alloca i64
  %l51 = alloca ptr
  %l52 = alloca i64
  %l53 = alloca i32
  %l56 = alloca i64
  %l59 = alloca i32
  %l68 = alloca i32
  %l74 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store %"compiler/check:reflList" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/check:reflList", ptr %l1, i32 0, i32 2
  %t2 = load i64, ptr %t1, !tbaa !24
  %t3 = load i64, ptr @G_2ecompiler_2fgeneric_2eListFunctions, !tbaa !24
  %t6 = icmp eq i64 %t2, %t3
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t8, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t12 = load i64, ptr %l2, !tbaa !24
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t14 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t19 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFuncDescriptor(ptr %v0, ptr %t11, i64 %t12, i32 %t13, i32 %t14)
  store i32 %t19, ptr %l13
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t20 = load i32, ptr %l13, !tbaa !23
  store i32 %t20, ptr %rv
  br label %ret
bb4:
  %t21 = getelementptr %"compiler/check:reflList", ptr %l1, i32 0, i32 2
  %t22 = load i64, ptr %t21, !tbaa !24
  %t23 = load i64, ptr @G_2ecompiler_2fgeneric_2eListMethods, !tbaa !24
  %t26 = icmp eq i64 %t22, %t23
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t32 = load i64, ptr %l2, !tbaa !24
  %t33 = getelementptr %"compiler/check:reflList", ptr %l1, i32 0, i32 1
  %t34 = load i32, ptr %t33, !tbaa !23
  %t35 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t40 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFuncDescriptor(ptr %v0, ptr %t31, i64 %t32, i32 %t34, i32 %t35)
  store i32 %t40, ptr %l22
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t41 = load i32, ptr %l22, !tbaa !23
  store i32 %t41, ptr %rv
  br label %ret
bb8:
  %t42 = getelementptr %"compiler/check:reflList", ptr %l1, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t44 = load i64, ptr @G_2ecompiler_2fgeneric_2eListBuilders, !tbaa !24
  %t47 = icmp eq i64 %t43, %t44
  br i1 %t47, label %bb9, label %bb10
bb9:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t53 = load i64, ptr %l2, !tbaa !24
  %t54 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t55 = getelementptr %"compiler/check:reflList", ptr %l1, i32 0, i32 1
  %t56 = load i32, ptr %t55, !tbaa !23
  %t61 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFuncDescriptor(ptr %v0, ptr %t52, i64 %t53, i32 %t54, i32 %t56)
  store i32 %t61, ptr %l31
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t62 = load i32, ptr %l31, !tbaa !23
  store i32 %t62, ptr %rv
  br label %ret
bb12:
  %t63 = getelementptr %"compiler/check:reflList", ptr %l1, i32 0, i32 2
  %t64 = load i64, ptr %t63, !tbaa !24
  store i64 %t64, ptr %l3, !tbaa !24
  %t66 = load i64, ptr %l3, !tbaa !24
  %t67 = load i64, ptr @G_2ecompiler_2fgeneric_2eListFields, !tbaa !24
  %t70 = icmp eq i64 %t66, %t67
  br i1 %t70, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t72 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescField, !tbaa !24
  store i64 %t72, ptr %l33, !tbaa !24
  br label %bb29
bb16:
  %t74 = load i64, ptr %l3, !tbaa !24
  %t75 = load i64, ptr @G_2ecompiler_2fgeneric_2eListCases, !tbaa !24
  %t78 = icmp eq i64 %t74, %t75
  br i1 %t78, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t80 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescCase, !tbaa !24
  store i64 %t80, ptr %l33, !tbaa !24
  br label %bb29
bb20:
  %t82 = load i64, ptr %l3, !tbaa !24
  %t83 = load i64, ptr @G_2ecompiler_2fgeneric_2eListParams, !tbaa !24
  %t86 = icmp eq i64 %t82, %t83
  br i1 %t86, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  %t88 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescParam, !tbaa !24
  store i64 %t88, ptr %l33, !tbaa !24
  br label %bb29
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t90 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescResult, !tbaa !24
  store i64 %t90, ptr %l33, !tbaa !24
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_56167ce98e06ac0c_8ddb750e2bed0608)
  unreachable
bb29:
  %t92 = load i64, ptr %l33, !tbaa !24
  store i64 %t92, ptr %l4, !tbaa !24
  %t93 = load i64, ptr %l4, !tbaa !24
  %t94 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescField, !tbaa !24
  %t97 = icmp eq i64 %t93, %t94
  br i1 %t97, label %bb30, label %bb31
bb30:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !29
  store ptr %t102, ptr %l51, !tbaa !29
  %t103 = load i64, ptr %l4, !tbaa !24
  store i64 %t103, ptr %l52, !tbaa !24
  %t104 = getelementptr %"compiler/check:reflList", ptr %l1, i32 0, i32 1
  %t105 = load i32, ptr %t104, !tbaa !23
  store i32 %t105, ptr %l53, !tbaa !23
  %t106 = getelementptr %"compiler/check:reflList", ptr %l1, i32 0, i32 3
  %t107 = load i64, ptr %t106, !tbaa !24
  %t109 = icmp slt i64 %t107, 0
  br i1 %t109, label %bb32, label %bb33
bb31:
  br label %bb36
bb32:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb34
bb33:
  %t111 = getelementptr %"compiler/check:reflList", ptr %l1, i32 0, i32 3
  %t112 = load i64, ptr %t111, !tbaa !24
  store i64 %t112, ptr %l56, !tbaa !24
  br label %bb34
bb34:
  %t114 = load i64, ptr %l2, !tbaa !24
  %t115 = load ptr, ptr %l51, !tbaa !29
  %t116 = load i64, ptr %l52, !tbaa !24
  %t117 = load i32, ptr %l53, !tbaa !23
  %t118 = load i64, ptr %l56, !tbaa !24
  %t120 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescriptor(ptr %v0, ptr %t115, i64 %t116, i32 %t117, i64 %t118, i64 %t114)
  store i32 %t120, ptr %l59
  br label %bb35
bb35:
  %t121 = load i32, ptr %l59, !tbaa !23
  store i32 %t121, ptr %rv
  br label %ret
bb36:
  %t122 = load i64, ptr %l4, !tbaa !24
  %t123 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescCase, !tbaa !24
  %t126 = icmp eq i64 %t122, %t123
  br i1 %t126, label %bb37, label %bb38
bb37:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/check:Checker", ptr %t128, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !29
  %t132 = load i64, ptr %l4, !tbaa !24
  %t133 = getelementptr %"compiler/check:reflList", ptr %l1, i32 0, i32 1
  %t134 = load i32, ptr %t133, !tbaa !23
  %t135 = load i64, ptr %l2, !tbaa !24
  %t140 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescriptor(ptr %v0, ptr %t131, i64 %t132, i32 %t134, i64 %t135, i64 0)
  store i32 %t140, ptr %l68
  br label %bb39
bb38:
  br label %bb40
bb39:
  %t141 = load i32, ptr %l68, !tbaa !23
  store i32 %t141, ptr %rv
  br label %ret
bb40:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/check:Checker", ptr %t142, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !29
  %t146 = load i64, ptr %l4, !tbaa !24
  %t147 = getelementptr %"compiler/check:reflList", ptr %l1, i32 0, i32 1
  %t148 = load i32, ptr %t147, !tbaa !23
  %t149 = load i64, ptr %l2, !tbaa !24
  %t154 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescriptor(ptr %v0, ptr %t145, i64 %t146, i32 %t148, i64 0, i64 %t149)
  store i32 %t154, ptr %l74
  br label %bb41
bb41:
  %t155 = load i32, ptr %l74, !tbaa !23
  store i32 %t155, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropTaken(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca i64
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l46 = alloca i32
  %l50 = alloca i32
  %l61 = alloca i64
  %l63 = alloca i64
  %l68 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l16
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l4
  %t3 = load i64, ptr %l2, !tbaa !24
  store i64 %t3, ptr %l5, !tbaa !24
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t5)
  store i64 %t7, ptr %l19
  br label %bb2
bb2:
  %t8 = load i64, ptr %l19, !tbaa !24
  store i64 %t8, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load i64, ptr %l7, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb8
bb5:
  %t19 = load i64, ptr %l6, !tbaa !24
  %t20 = load i64, ptr %l5, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l7, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l7, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l26, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l26, !tbaa !24
  store i64 %t35, ptr %l23, !tbaa !24
  br label %bb8
bb8:
  %t36 = load i64, ptr %l23, !tbaa !24
  store i64 %t36, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  %t37 = load i64, ptr %l9, !tbaa !24
  %t38 = load i64, ptr %l8, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb10, label %bb11
bb10:
  br label %bb20
bb11:
  br label %bb12
bb12:
  %t45 = load i64, ptr %l5, !tbaa !24
  %t46 = load i64, ptr %l9, !tbaa !24
  %t47 = load i64, ptr %l7, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t59 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t55, i64 %t53)
  store i32 %t59, ptr %l46
  br label %bb13
bb13:
  %t60 = load i32, ptr %l46, !tbaa !23
  %t67 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleft(ptr %v0, ptr %v2, ptr %a0, i32 %t60, ptr %a3)
  store i32 %t67, ptr %l50
  br label %bb14
bb14:
  %t68 = load i32, ptr %l50, !tbaa !23
  store i32 %t68, ptr %l12, !tbaa !23
  %t69 = load i32, ptr %l12, !tbaa !23
  %t70 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t73 = icmp ne i32 %t69, %t70
  br i1 %t73, label %bb15, label %bb16
bb15:
  %t75 = load i32, ptr %l12, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l4, i32 %t75)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t78 = load i64, ptr %l9, !tbaa !24
  %t80 = add i64 %t78, 1
  store i64 %t80, ptr %l9, !tbaa !24
  br label %bb9
bb20:
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t83 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t82, i64 %t83)
  br label %bb21
bb21:
  store ptr %l4, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb22
bb22:
  %t87 = load i64, ptr %l14, !tbaa !24
  store i64 %t87, ptr %l61, !tbaa !24
  %t88 = load ptr, ptr %l13, !tbaa !29
  %t90 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t88)
  store i64 %t90, ptr %l63
  br label %bb23
bb23:
  %t91 = load i64, ptr %l61, !tbaa !24
  %t92 = load i64, ptr %l63, !tbaa !24
  %t93 = icmp slt i64 %t91, %t92
  %t95 = xor i1 %t93, true
  br i1 %t95, label %bb24, label %bb25
bb24:
  br label %bb30
bb25:
  br label %bb26
bb26:
  %t97 = load ptr, ptr %l13, !tbaa !29
  %t98 = load i64, ptr %l14, !tbaa !24
  %t101 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t97, i64 %t98)
  store i32 %t101, ptr %l68
  br label %bb27
bb27:
  %t102 = load i32, ptr %l68, !tbaa !23
  %t103 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t103, i32 %t102)
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t107 = load i64, ptr %l14, !tbaa !24
  %t109 = add i64 %t107, 1
  store i64 %t109, ptr %l14, !tbaa !24
  br label %bb22
bb30:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropsGone(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca %"compiler/source:Span"
  %l22 = alloca ptr
  %l26 = alloca ptr
  %t29 = alloca { i64, [4 x i64] }, align 8
  %t48 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l6, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 23
  %t10 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t6, i64 %a2)
  %t11 = extractvalue { i32, i64 } %t10, 1
  %t12 = extractvalue { i32, i64 } %t10, 0
  store i32 %t12, ptr %l11
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb3, label %ok.14, !prof !99
ok.14:
  store i64 %t11, ptr %l10
  br label %bb2
bb2:
  %t15 = load i64, ptr %l10, !tbaa !24
  store i64 %t15, ptr %l4, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  store i64 -1, ptr %l4, !tbaa !24
  br label %bb5
bb5:
  %t16 = load i64, ptr %l4, !tbaa !24
  store i64 %t16, ptr %l3, !tbaa !24
  %t17 = load i64, ptr %l3, !tbaa !24
  %t19 = icmp sge i64 %t17, 0
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l14, !tbaa !29
  %t22 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t22, ptr %l15
  %t23 = load %"compiler/source:Span", ptr %l1
  %t24 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t25 = load i64, ptr %l3, !tbaa !24
  %t27 = trunc i64 %t25 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t29
  %t30 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 0
  store i64 0, ptr %t30
  %t32 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t23, 0
  %t34 = insertvalue { %"compiler/source:Span", i32, i32 } %t32, i32 %t24, 1
  %t36 = insertvalue { %"compiler/source:Span", i32, i32 } %t34, i32 %t27, 2
  %t37 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t36, ptr %t37
  %t38 = load { i64, [4 x i64] }, ptr %t29
  %t40 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t38, ptr %t40
  store ptr %t40, ptr %l22, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load %"compiler/source:Span", ptr %l1
  %t43 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t47 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t41, %"compiler/source:Span" %t42, i32 %t43, i64 0)
  store ptr %t47, ptr %l26
  br label %bb8
bb7:
  br label %bb10
bb8:
  store { i64, [3 x i64] } zeroinitializer, ptr %t48
  %t49 = getelementptr { i64, [3 x i64] }, ptr %t48, i32 0, i32 0
  store i64 1, ptr %t49
  %t50 = load %"compiler/source:Span", ptr %l15
  %t51 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t50, 0
  %t52 = load ptr, ptr %l22, !tbaa !29
  %t53 = insertvalue { %"compiler/source:Span", ptr, ptr } %t51, ptr %t52, 1
  %t54 = load ptr, ptr %l26, !tbaa !29
  %t55 = insertvalue { %"compiler/source:Span", ptr, ptr } %t53, ptr %t54, 2
  %t56 = getelementptr { i64, [3 x i64] }, ptr %t48, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t55, ptr %t56
  %t57 = load { i64, [3 x i64] }, ptr %t48
  %t59 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t57, ptr %t59
  %t60 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t60, ptr %t59)
  br label %bb9
bb9:
  br label %bb10
bb10:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eenumsEqual(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca ptr
  %lp19 = alloca ptr
  %lp20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca ptr
  %l41 = alloca %"compiler/source:Span"
  %l46 = alloca ptr
  %l47 = alloca ptr
  %l50 = alloca ptr
  %l55 = alloca i32
  %l56 = alloca { i64, ptr }
  %l60 = alloca ptr
  %l66 = alloca i64
  %l69 = alloca i64
  %l94 = alloca ptr
  %l97 = alloca ptr
  %l102 = alloca i32
  %l103 = alloca i32
  %l104 = alloca { i64, ptr }
  %l105 = alloca ptr
  %l106 = alloca %"compiler/source:Span"
  %l107 = alloca i32
  %l108 = alloca i32
  %l112 = alloca ptr
  %l113 = alloca ptr
  %l114 = alloca %"compiler/source:Span"
  %l116 = alloca i32
  %l118 = alloca ptr
  %l120 = alloca ptr
  %l121 = alloca %"compiler/source:Span"
  %l122 = alloca { i64, ptr }
  %l124 = alloca i32
  %l128 = alloca %"compiler/typed:Payload"
  %l131 = alloca %"compiler/source:Span"
  %l132 = alloca { i64, ptr }
  %l134 = alloca i32
  %l138 = alloca %"compiler/typed:Payload"
  %l146 = alloca i64
  %l149 = alloca i64
  %l167 = alloca ptr
  %l168 = alloca %"compiler/source:Span"
  %l169 = alloca i32
  %l173 = alloca { i64, ptr }
  %l180 = alloca ptr
  %l184 = alloca { i64, ptr }
  %l191 = alloca ptr
  %l192 = alloca ptr
  %l197 = alloca ptr
  %l200 = alloca ptr
  %l201 = alloca %"compiler/source:Span"
  %l202 = alloca i32
  %l203 = alloca i32
  %l207 = alloca ptr
  %l208 = alloca ptr
  %l209 = alloca %"compiler/source:Span"
  %l211 = alloca i32
  %l213 = alloca ptr
  %l215 = alloca ptr
  %l216 = alloca %"compiler/source:Span"
  %l217 = alloca i32
  %l222 = alloca %"compiler/typed:Cond"
  %l230 = alloca i64
  %l233 = alloca %"compiler/source:Span"
  %l234 = alloca i32
  %l238 = alloca { i64, ptr }
  %l241 = alloca %"compiler/typed:Seq"
  %rv = alloca ptr
  %t202 = alloca { i64, [4 x i64] }, align 8
  %t231 = alloca { i64, [4 x i64] }, align 8
  %t308 = alloca { i64, [4 x i64] }, align 8
  %t338 = alloca { i64, [4 x i64] }, align 8
  %t419 = alloca { i64, [5 x i64] }, align 8
  %t462 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 37
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l31
  br label %bb1
bb1:
  %t6 = load i64, ptr %l31, !tbaa !24
  store i64 %t6, ptr %l5, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l32, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t8, ptr %l33
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l4, !tbaa !23
  %t12 = load %"compiler/source:Span", ptr %l1
  %t17 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v3, ptr %t9, ptr %a2, i32 %t11, %"compiler/source:Span" %t12)
  store ptr %t17, ptr %l38
  br label %bb2
bb2:
  %t18 = load ptr, ptr %l32, !tbaa !29
  %t19 = load %"compiler/source:Span", ptr %l33
  %t20 = load ptr, ptr %l38, !tbaa !29
  %t21 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldOf(ptr %v0, ptr %v3, ptr %v3, ptr %t18, %"compiler/source:Span" %t19, ptr %t20)
  store ptr %t21, ptr %l39
  br label %bb3
bb3:
  %t22 = load ptr, ptr %l39, !tbaa !29
  store ptr %t22, ptr %l6, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l40, !tbaa !29
  %t24 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t24, ptr %l41
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i32, ptr %l4, !tbaa !23
  %t28 = load %"compiler/source:Span", ptr %l1
  %t33 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v2, ptr %v3, ptr %t25, ptr %a3, i32 %t27, %"compiler/source:Span" %t28)
  store ptr %t33, ptr %l46
  br label %bb4
bb4:
  %t34 = load ptr, ptr %l40, !tbaa !29
  %t35 = load %"compiler/source:Span", ptr %l41
  %t36 = load ptr, ptr %l46, !tbaa !29
  %t37 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldOf(ptr %v0, ptr %v3, ptr %v3, ptr %t34, %"compiler/source:Span" %t35, ptr %t36)
  store ptr %t37, ptr %l47
  br label %bb5
bb5:
  %t38 = load ptr, ptr %l47, !tbaa !29
  store ptr %t38, ptr %l7, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/generic:Program", ptr %t42, i32 0, i32 2
  store ptr %t44, ptr %l50, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = getelementptr %"compiler/generic:Program", ptr %t48, i32 0, i32 2
  %t51 = load i32, ptr %l4, !tbaa !23
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t50, i32 %t51)
  store i32 %t54, ptr %l55
  br label %bb6
bb6:
  %t55 = load ptr, ptr %l50, !tbaa !29
  %t56 = load i32, ptr %l55, !tbaa !23
  %t57 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t55, i32 %t56)
  store { i64, ptr } %t57, ptr %l56
  br label %bb7
bb7:
  %t58 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t58, ptr %l8, !tbaa !27
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load %"compiler/source:Span", ptr %l1
  %t61 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t65 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t59, %"compiler/source:Span" %t60, i32 %t61, i64 0)
  store ptr %t65, ptr %l60
  br label %bb8
bb8:
  %t66 = load ptr, ptr %l60, !tbaa !29
  store ptr %t66, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  %t67 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 0
  store i64 %t69, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t71 = load i64, ptr %l11, !tbaa !24
  %t72 = load i64, ptr %l10, !tbaa !24
  %t75 = icmp sgt i64 %t71, %t72
  br i1 %t75, label %bb9, label %bb10
bb9:
  %t77 = load i64, ptr %l12, !tbaa !24
  %t79 = icmp sgt i64 %t77, 0
  br i1 %t79, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb14
bb11:
  %t81 = load i64, ptr %l11, !tbaa !24
  %t82 = load i64, ptr %l10, !tbaa !24
  %t85 = sub i64 %t81, %t82
  %t86 = load i64, ptr %l12, !tbaa !24
  %t89 = add i64 %t85, %t86
  %t91 = sub i64 %t89, 1
  %t92 = load i64, ptr %l12, !tbaa !24
  %t95 = sdiv i64 %t91, %t92
  store i64 %t95, ptr %l69, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb13
bb13:
  %t97 = load i64, ptr %l69, !tbaa !24
  store i64 %t97, ptr %l66, !tbaa !24
  br label %bb14
bb14:
  %t98 = load i64, ptr %l66, !tbaa !24
  store i64 %t98, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb15
bb15:
  %t99 = load i64, ptr %l14, !tbaa !24
  %t100 = load i64, ptr %l13, !tbaa !24
  %t103 = icmp slt i64 %t99, %t100
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb16, label %bb17
bb16:
  br label %bb50
bb17:
  br label %bb18
bb18:
  %t107 = load i64, ptr %l10, !tbaa !24
  %t108 = load i64, ptr %l14, !tbaa !24
  %t109 = load i64, ptr %l12, !tbaa !24
  %t112 = mul i64 %t108, %t109
  %t115 = add i64 %t107, %t112
  %t117 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t117, 0
  %t121 = sub i64 %t119, 1
  %t125 = sub i64 %t121, %t115
  store i64 %t125, ptr %l16, !tbaa !24
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/check:Checker", ptr %t127, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t132 = getelementptr %"compiler/generic:Program", ptr %t130, i32 0, i32 2
  store ptr %t132, ptr %l94, !tbaa !29
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/check:Checker", ptr %t133, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t138 = getelementptr %"compiler/generic:Program", ptr %t136, i32 0, i32 2
  store ptr %t138, ptr %l97, !tbaa !29
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/check:Checker", ptr %t139, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t143 = load i32, ptr %l4, !tbaa !23
  %t144 = load i64, ptr %l16, !tbaa !24
  %t148 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %t142, i32 %t143, i64 %t144)
  store i32 %t148, ptr %l102
  br label %bb19
bb19:
  %t149 = load ptr, ptr %l97, !tbaa !29
  %t150 = load i32, ptr %l102, !tbaa !23
  %t151 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t149, i32 %t150)
  store i32 %t151, ptr %l103
  br label %bb20
bb20:
  %t152 = load ptr, ptr %l94, !tbaa !29
  %t153 = load i32, ptr %l103, !tbaa !23
  %t154 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t152, i32 %t153)
  store { i64, ptr } %t154, ptr %l104
  br label %bb21
bb21:
  %t155 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t155, ptr %l17, !tbaa !27
  %t156 = load ptr, ptr %l0, !tbaa !29
  store ptr %t156, ptr %l105, !tbaa !29
  %t157 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t157, ptr %l106
  %t158 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t158, ptr %l107, !tbaa !23
  store i32 23, ptr %l108
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load %"compiler/source:Span", ptr %l1
  %t161 = load ptr, ptr %l7, !tbaa !29
  %t165 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v3, ptr %v3, ptr %t159, %"compiler/source:Span" %t160, ptr %t161)
  store ptr %t165, ptr %l112
  br label %bb22
bb22:
  %t166 = load ptr, ptr %l0, !tbaa !29
  store ptr %t166, ptr %l113, !tbaa !29
  %t167 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t167, ptr %l114
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t168)
  store i32 %t170, ptr %l116
  br label %bb23
bb23:
  %t171 = load i64, ptr %l16, !tbaa !24
  %t172 = load ptr, ptr %l113, !tbaa !29
  %t173 = load %"compiler/source:Span", ptr %l114
  %t174 = load i32, ptr %l116, !tbaa !23
  %t176 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t172, %"compiler/source:Span" %t173, i32 %t174, i64 %t171)
  store ptr %t176, ptr %l118
  br label %bb24
bb24:
  %t177 = load ptr, ptr %l118, !tbaa !29
  %t178 = load ptr, ptr %l105, !tbaa !29
  %t179 = load %"compiler/source:Span", ptr %l106
  %t180 = load i32, ptr %l107, !tbaa !23
  %t181 = load i32, ptr %l108, !range !{i32 0, i32 49}
  %t182 = load ptr, ptr %l112, !tbaa !29
  %t184 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v3, ptr %v0, ptr %v3, ptr %t178, %"compiler/source:Span" %t179, i32 %t180, i32 %t181, ptr %t182, ptr %t177)
  store ptr %t184, ptr %l120
  br label %bb25
bb25:
  %t185 = load ptr, ptr %l120, !tbaa !29
  store ptr %t185, ptr %l18, !tbaa !29
  %t186 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t186, ptr %l121
  %t187 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t187, ptr %l122, !tbaa !27
  %t188 = load i64, ptr %l16, !tbaa !24
  %t190 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr i32, ptr %t191, i64 %t188
  %t193 = load i32, ptr %t192, !tbaa !33
  store i32 %t193, ptr %l124, !tbaa !23
  %t194 = load ptr, ptr %l6, !tbaa !29
  %t195 = load i64, ptr %l16, !tbaa !24
  %t199 = call %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v3, ptr %v3, ptr %t194, i64 %t195, i32 0)
  store %"compiler/typed:Payload" %t199, ptr %l128
  br label %bb26
bb26:
  %t200 = load %"compiler/typed:Payload", ptr %l128
  %t201 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 24, i64 8)
  store %"compiler/typed:Payload" %t200, ptr %t201
  store { i64, [4 x i64] } zeroinitializer, ptr %t202
  %t203 = getelementptr { i64, [4 x i64] }, ptr %t202, i32 0, i32 0
  store i64 5, ptr %t203
  %t204 = load %"compiler/source:Span", ptr %l121
  %t205 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t204, 0
  %t206 = load i32, ptr %l124, !tbaa !23
  %t207 = insertvalue { %"compiler/source:Span", i32, ptr } %t205, i32 %t206, 1
  %t209 = insertvalue { %"compiler/source:Span", i32, ptr } %t207, ptr %t201, 2
  %t210 = getelementptr { i64, [4 x i64] }, ptr %t202, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t209, ptr %t210
  %t211 = load { i64, [4 x i64] }, ptr %t202
  %t212 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store ptr %t212, ptr %lp19
  %t214 = load ptr, ptr %lp19
  store { i64, [4 x i64] } %t211, ptr %t214
  %t215 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t215, ptr %l131
  %t216 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t216, ptr %l132, !tbaa !27
  %t217 = load i64, ptr %l16, !tbaa !24
  %t219 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t220 = load ptr, ptr %t219, !tbaa !27
  %t221 = getelementptr i32, ptr %t220, i64 %t217
  %t222 = load i32, ptr %t221, !tbaa !33
  store i32 %t222, ptr %l134, !tbaa !23
  %t223 = load ptr, ptr %l7, !tbaa !29
  %t224 = load i64, ptr %l16, !tbaa !24
  %t228 = call %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v3, ptr %v3, ptr %t223, i64 %t224, i32 0)
  store %"compiler/typed:Payload" %t228, ptr %l138
  br label %bb27
bb27:
  %t229 = load %"compiler/typed:Payload", ptr %l138
  %t230 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 24, i64 8)
  store %"compiler/typed:Payload" %t229, ptr %t230
  store { i64, [4 x i64] } zeroinitializer, ptr %t231
  %t232 = getelementptr { i64, [4 x i64] }, ptr %t231, i32 0, i32 0
  store i64 5, ptr %t232
  %t233 = load %"compiler/source:Span", ptr %l131
  %t234 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t233, 0
  %t235 = load i32, ptr %l134, !tbaa !23
  %t236 = insertvalue { %"compiler/source:Span", i32, ptr } %t234, i32 %t235, 1
  %t238 = insertvalue { %"compiler/source:Span", i32, ptr } %t236, ptr %t230, 2
  %t239 = getelementptr { i64, [4 x i64] }, ptr %t231, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t238, ptr %t239
  %t240 = load { i64, [4 x i64] }, ptr %t231
  %t241 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store ptr %t241, ptr %lp20
  %t243 = load ptr, ptr %lp20
  store { i64, [4 x i64] } %t240, ptr %t243
  store i64 0, ptr %l21, !tbaa !24
  %t244 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t246 = extractvalue { i64, ptr } %t244, 0
  store i64 %t246, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t248 = load i64, ptr %l22, !tbaa !24
  %t249 = load i64, ptr %l21, !tbaa !24
  %t252 = icmp sgt i64 %t248, %t249
  br i1 %t252, label %bb28, label %bb29
bb28:
  %t254 = load i64, ptr %l23, !tbaa !24
  %t256 = icmp sgt i64 %t254, 0
  br i1 %t256, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l146, !tbaa !24
  br label %bb33
bb30:
  %t258 = load i64, ptr %l22, !tbaa !24
  %t259 = load i64, ptr %l21, !tbaa !24
  %t262 = sub i64 %t258, %t259
  %t263 = load i64, ptr %l23, !tbaa !24
  %t266 = add i64 %t262, %t263
  %t268 = sub i64 %t266, 1
  %t269 = load i64, ptr %l23, !tbaa !24
  %t272 = sdiv i64 %t268, %t269
  store i64 %t272, ptr %l149, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l149, !tbaa !24
  br label %bb32
bb32:
  %t274 = load i64, ptr %l149, !tbaa !24
  store i64 %t274, ptr %l146, !tbaa !24
  br label %bb33
bb33:
  %t275 = load i64, ptr %l146, !tbaa !24
  store i64 %t275, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb34
bb34:
  %t276 = load i64, ptr %l25, !tbaa !24
  %t277 = load i64, ptr %l24, !tbaa !24
  %t280 = icmp slt i64 %t276, %t277
  %t282 = xor i1 %t280, true
  br i1 %t282, label %bb35, label %bb36
bb35:
  br label %bb43
bb36:
  br label %bb37
bb37:
  %t284 = load i64, ptr %l21, !tbaa !24
  %t285 = load i64, ptr %l25, !tbaa !24
  %t286 = load i64, ptr %l23, !tbaa !24
  %t289 = mul i64 %t285, %t286
  %t292 = add i64 %t284, %t289
  store i64 %t292, ptr %l26, !tbaa !24
  %t294 = load ptr, ptr %l0, !tbaa !29
  store ptr %t294, ptr %l167, !tbaa !29
  %t295 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t295, ptr %l168
  store i32 78, ptr %l169
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t297 = load %"compiler/source:Span", ptr %l1
  %t298 = load %"compiler/source:Span", ptr %l1
  %t299 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t299, ptr %l173, !tbaa !27
  %t300 = load i64, ptr %l26, !tbaa !24
  %t302 = getelementptr { i64, ptr }, ptr %l173, i32 0, i32 1
  %t303 = load ptr, ptr %t302, !tbaa !27
  %t304 = getelementptr i32, ptr %t303, i64 %t300
  %t305 = load i32, ptr %t304, !tbaa !33
  %t306 = load ptr, ptr %lp19
  %t307 = load i64, ptr %l26, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t308
  %t309 = getelementptr { i64, [4 x i64] }, ptr %t308, i32 0, i32 0
  store i64 3, ptr %t309
  %t311 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t298, 0
  %t313 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t311, i32 %t305, 1
  %t315 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t313, ptr %t306, 2
  %t317 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t315, i64 %t307, 3
  %t318 = getelementptr { i64, [4 x i64] }, ptr %t308, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t317, ptr %t318
  %t319 = load { i64, [4 x i64] }, ptr %t308
  %t321 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t319, ptr %t321
  %t325 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t296, %"compiler/source:Span" %t297, ptr %t321)
  store ptr %t325, ptr %l180
  br label %bb38
bb38:
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t327 = load %"compiler/source:Span", ptr %l1
  %t328 = load %"compiler/source:Span", ptr %l1
  %t329 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t329, ptr %l184, !tbaa !27
  %t330 = load i64, ptr %l26, !tbaa !24
  %t332 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t333 = load ptr, ptr %t332, !tbaa !27
  %t334 = getelementptr i32, ptr %t333, i64 %t330
  %t335 = load i32, ptr %t334, !tbaa !33
  %t336 = load ptr, ptr %lp20
  %t337 = load i64, ptr %l26, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t338
  %t339 = getelementptr { i64, [4 x i64] }, ptr %t338, i32 0, i32 0
  store i64 3, ptr %t339
  %t341 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t328, 0
  %t343 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t341, i32 %t335, 1
  %t345 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t343, ptr %t336, 2
  %t347 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t345, i64 %t337, 3
  %t348 = getelementptr { i64, [4 x i64] }, ptr %t338, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t347, ptr %t348
  %t349 = load { i64, [4 x i64] }, ptr %t338
  %t351 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t349, ptr %t351
  %t355 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t326, %"compiler/source:Span" %t327, ptr %t351)
  store ptr %t355, ptr %l191
  br label %bb39
bb39:
  %t356 = load ptr, ptr %l167, !tbaa !29
  %t357 = load %"compiler/source:Span", ptr %l168
  %t358 = load i32, ptr %l169, !range !{i32 0, i32 98}
  %t359 = load ptr, ptr %l180, !tbaa !29
  %t360 = load ptr, ptr %l191, !tbaa !29
  %t361 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eequality(ptr %v0, ptr %v0, ptr %v0, ptr %v3, ptr %t356, %"compiler/source:Span" %t357, i32 %t358, ptr %t359, ptr %t360)
  store ptr %t361, ptr %l192
  br label %bb40
bb40:
  %t362 = load ptr, ptr %l192, !tbaa !29
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t364 = load %"compiler/source:Span", ptr %l1
  %t365 = load ptr, ptr %l18, !tbaa !29
  %t371 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eand2(ptr %v0, ptr %v3, ptr %v3, ptr %v3, ptr %t363, %"compiler/source:Span" %t364, ptr %t365, ptr %t362)
  store ptr %t371, ptr %l197
  br label %bb41
bb41:
  %t372 = load ptr, ptr %l197, !tbaa !29
  store ptr %t372, ptr %l18, !tbaa !29
  br label %bb42
bb42:
  %t373 = load i64, ptr %l25, !tbaa !24
  %t375 = add i64 %t373, 1
  store i64 %t375, ptr %l25, !tbaa !24
  br label %bb34
bb43:
  %t377 = load ptr, ptr %l0, !tbaa !29
  store ptr %t377, ptr %l200, !tbaa !29
  %t378 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t378, ptr %l201
  %t379 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t379, ptr %l202, !tbaa !23
  store i32 23, ptr %l203
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t381 = load %"compiler/source:Span", ptr %l1
  %t382 = load ptr, ptr %l6, !tbaa !29
  %t386 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v3, ptr %v3, ptr %t380, %"compiler/source:Span" %t381, ptr %t382)
  store ptr %t386, ptr %l207
  br label %bb44
bb44:
  %t387 = load ptr, ptr %l0, !tbaa !29
  store ptr %t387, ptr %l208, !tbaa !29
  %t388 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t388, ptr %l209
  %t389 = load ptr, ptr %l0, !tbaa !29
  %t391 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t389)
  store i32 %t391, ptr %l211
  br label %bb45
bb45:
  %t392 = load i64, ptr %l16, !tbaa !24
  %t393 = load ptr, ptr %l208, !tbaa !29
  %t394 = load %"compiler/source:Span", ptr %l209
  %t395 = load i32, ptr %l211, !tbaa !23
  %t397 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t393, %"compiler/source:Span" %t394, i32 %t395, i64 %t392)
  store ptr %t397, ptr %l213
  br label %bb46
bb46:
  %t398 = load ptr, ptr %l213, !tbaa !29
  %t399 = load ptr, ptr %l200, !tbaa !29
  %t400 = load %"compiler/source:Span", ptr %l201
  %t401 = load i32, ptr %l202, !tbaa !23
  %t402 = load i32, ptr %l203, !range !{i32 0, i32 49}
  %t403 = load ptr, ptr %l207, !tbaa !29
  %t405 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v3, ptr %v0, ptr %v3, ptr %t399, %"compiler/source:Span" %t400, i32 %t401, i32 %t402, ptr %t403, ptr %t398)
  store ptr %t405, ptr %l215
  br label %bb47
bb47:
  %t406 = load ptr, ptr %l215, !tbaa !29
  %t407 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t407, ptr %l216
  %t408 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t408, ptr %l217, !tbaa !23
  %t410 = load ptr, ptr %l18, !tbaa !29
  %t412 = load ptr, ptr %l9, !tbaa !29
  %t416 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %t406, ptr %t410, ptr %t412)
  store %"compiler/typed:Cond" %t416, ptr %l222
  br label %bb48
bb48:
  %t417 = load %"compiler/typed:Cond", ptr %l222
  %t418 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 24, i64 8)
  store %"compiler/typed:Cond" %t417, ptr %t418
  store { i64, [5 x i64] } zeroinitializer, ptr %t419
  %t420 = getelementptr { i64, [5 x i64] }, ptr %t419, i32 0, i32 0
  store i64 11, ptr %t420
  %t421 = load %"compiler/source:Span", ptr %l216
  %t422 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t421, 0
  %t423 = load i32, ptr %l217, !tbaa !23
  %t424 = insertvalue { %"compiler/source:Span", i32, ptr } %t422, i32 %t423, 1
  %t426 = insertvalue { %"compiler/source:Span", i32, ptr } %t424, ptr %t418, 2
  %t427 = getelementptr { i64, [5 x i64] }, ptr %t419, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t426, ptr %t427
  %t428 = load { i64, [5 x i64] }, ptr %t419
  %t430 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store { i64, [5 x i64] } %t428, ptr %t430
  store ptr %t430, ptr %l9, !tbaa !29
  br label %bb49
bb49:
  %t432 = load i64, ptr %l14, !tbaa !24
  %t434 = add i64 %t432, 1
  store i64 %t434, ptr %l14, !tbaa !24
  br label %bb15
bb50:
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t438 = getelementptr %"compiler/check:Checker", ptr %t436, i32 0, i32 37
  %t440 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t438)
  store i64 %t440, ptr %l230
  br label %bb51
bb51:
  %t441 = load i64, ptr %l5, !tbaa !24
  %t442 = load i64, ptr %l230, !tbaa !24
  %t444 = icmp sgt i64 %t442, %t441
  br i1 %t444, label %bb52, label %bb53
bb52:
  %t446 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t446, ptr %l233
  %t447 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t447, ptr %l234, !tbaa !23
  %t448 = load ptr, ptr %l0, !tbaa !29
  %t450 = getelementptr %"compiler/check:Checker", ptr %t448, i32 0, i32 37
  %t451 = load i64, ptr %l5, !tbaa !24
  %t454 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t450, i64 %t451)
  store { i64, ptr } %t454, ptr %l238
  br label %bb54
bb53:
  br label %bb56
bb54:
  %t455 = load ptr, ptr %l9, !tbaa !29
  %t457 = load { i64, ptr }, ptr %l238, !tbaa !27
  %t459 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v3, ptr %v3, { i64, ptr } %t457, ptr %t455, i1 false)
  store %"compiler/typed:Seq" %t459, ptr %l241
  br label %bb55
bb55:
  %t460 = load %"compiler/typed:Seq", ptr %l241
  %t461 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store %"compiler/typed:Seq" %t460, ptr %t461
  store { i64, [5 x i64] } zeroinitializer, ptr %t462
  %t463 = getelementptr { i64, [5 x i64] }, ptr %t462, i32 0, i32 0
  store i64 12, ptr %t463
  %t464 = load %"compiler/source:Span", ptr %l233
  %t465 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t464, 0
  %t466 = load i32, ptr %l234, !tbaa !23
  %t467 = insertvalue { %"compiler/source:Span", i32, ptr } %t465, i32 %t466, 1
  %t469 = insertvalue { %"compiler/source:Span", i32, ptr } %t467, ptr %t461, 2
  %t470 = getelementptr { i64, [5 x i64] }, ptr %t462, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t469, ptr %t470
  %t471 = load { i64, [5 x i64] }, ptr %t462
  %t473 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store { i64, [5 x i64] } %t471, ptr %t473
  store ptr %t473, ptr %rv
  br label %ret
bb56:
  %t475 = load ptr, ptr %l9, !tbaa !29
  store ptr %t475, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrItemPath(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l6 = alloca ptr
  %l12 = alloca ptr
  %l14 = alloca ptr
  %l19 = alloca %"compiler/names:Ref"
  %l24 = alloca i1
  %l30 = alloca ptr
  %l32 = alloca ptr
  %l36 = alloca i32
  %l46 = alloca ptr
  %l48 = alloca ptr
  %l50 = alloca ptr
  %l52 = alloca %"compiler/source:Span"
  %l54 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i64
  %l64 = alloca %"compiler/ast:Path"
  %l66 = alloca i32
  %l71 = alloca ptr
  %l76 = alloca i32
  %l78 = alloca { i64, ptr }
  %l84 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call ptr @compiler_2fcheck_2eexprPath(ptr %v1, ptr %s0, ptr %a1)
  store ptr %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l6, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  store ptr %t16, ptr %l12, !tbaa !29
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t17)
  store ptr %t19, ptr %l14
  br label %bb5
bb5:
  %t20 = load ptr, ptr %l14, !tbaa !29
  %t22 = getelementptr %"compiler/check:frame", ptr %t20, i32 0, i32 2
  %t23 = load i64, ptr %t22, !tbaa !24
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = getelementptr %"compiler/ast:Path", ptr %t24, i32 0, i32 0
  %t27 = getelementptr %"compiler/source:Span", ptr %t26, i32 0, i32 0
  %t28 = load i32, ptr %t27, !tbaa !23
  %t29 = load ptr, ptr %l12, !tbaa !29
  %t32 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t29, i64 %t23, i32 %t28)
  store %"compiler/names:Ref" %t32, ptr %l19
  br label %bb6
bb6:
  %t33 = getelementptr %"compiler/names:Ref", ptr %l19, i32 0, i32 0
  %t34 = load i32, ptr %t33, !range !{i32 0, i32 9}
  store i32 %t34, ptr %l3
  %t36 = load i32, ptr %l3, !range !{i32 0, i32 9}
  %t38 = trunc i64 4 to i32
  %t39 = icmp eq i32 %t36, %t38
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb7, label %bb8
bb7:
  %t43 = load i32, ptr %l3, !range !{i32 0, i32 9}
  %t45 = trunc i64 5 to i32
  %t46 = icmp eq i32 %t43, %t45
  %t48 = xor i1 %t46, true
  store i1 %t48, ptr %l24, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb9
bb9:
  %t50 = load i1, ptr %l24, !tbaa !21
  br i1 %t50, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  store ptr %t55, ptr %l30, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t56)
  store ptr %t58, ptr %l32
  br label %bb13
bb13:
  %t59 = load ptr, ptr %l32, !tbaa !29
  %t61 = getelementptr %"compiler/check:frame", ptr %t59, i32 0, i32 4
  %t62 = load ptr, ptr %l2, !tbaa !29
  %t63 = load ptr, ptr %l30, !tbaa !29
  %t66 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorType(ptr %v0, ptr %v0, ptr %s0, ptr %t63, ptr %t61, ptr %t62)
  store i32 %t66, ptr %l36
  br label %bb14
bb14:
  %t67 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t68 = load i32, ptr %l36, !tbaa !23
  %t70 = icmp ne i32 %t68, %t67
  br i1 %t70, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t73 = load ptr, ptr %l2, !tbaa !29
  %t75 = getelementptr %"compiler/ast:Path", ptr %t73, i32 0, i32 1
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t76, 0
  %t80 = icmp slt i64 %t78, 2
  br i1 %t80, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  store ptr %t86, ptr %l46, !tbaa !29
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t87)
  store ptr %t89, ptr %l48
  br label %bb21
bb21:
  %t90 = load ptr, ptr %l48, !tbaa !29
  %t92 = getelementptr %"compiler/check:frame", ptr %t90, i32 0, i32 4
  store ptr %t92, ptr %l50, !tbaa !29
  %t93 = load ptr, ptr %l2, !tbaa !29
  %t95 = getelementptr %"compiler/ast:Path", ptr %t93, i32 0, i32 0
  %t96 = load %"compiler/source:Span", ptr %t95
  store %"compiler/source:Span" %t96, ptr %l52
  %t97 = load ptr, ptr %l2, !tbaa !29
  %t99 = getelementptr %"compiler/ast:Path", ptr %t97, i32 0, i32 1
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !27
  store { i64, ptr } %t100, ptr %l54, !tbaa !27
  %t101 = load ptr, ptr %l2, !tbaa !29
  %t103 = getelementptr %"compiler/ast:Path", ptr %t101, i32 0, i32 1
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t108 = sub i64 %t106, 1
  store i64 %t108, ptr %l58, !tbaa !24
  %t109 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  store i64 %t110, ptr %l59, !tbaa !24
  %t111 = icmp sge i64 0, 0
  br i1 %t111, label %bb22, label %bb23
bb22:
  %t113 = load i64, ptr %l58, !tbaa !24
  %t114 = icmp sle i64 0, %t113
  br i1 %t114, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_21bd7d1c01cb29ff_7bd6b7239395673b)
  unreachable
bb24:
  %t116 = load i64, ptr %l58, !tbaa !24
  %t117 = load i64, ptr %l59, !tbaa !24
  %t118 = icmp sle i64 %t116, %t117
  br i1 %t118, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_21bd7d1c01cb29ff_7bd6b7239395673b)
  unreachable
bb26:
  %t120 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = load i64, ptr %l58, !tbaa !24
  %t123 = getelementptr i32, ptr %t121, i64 0
  %t124 = sub i64 %t122, 0
  %t125 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t123, 1
  %t127 = load %"compiler/source:Span", ptr %l52
  %t129 = call %"compiler/ast:Path" @compiler_2fast_3aPath_2ector(ptr %s0, ptr %s0, %"compiler/source:Span" %t127, { i64, ptr } %t126)
  store %"compiler/ast:Path" %t129, ptr %l64
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_21bd7d1c01cb29ff_7bd6b7239395673b)
  unreachable
bb28:
  %t130 = load ptr, ptr %l46, !tbaa !29
  %t131 = load ptr, ptr %l50, !tbaa !29
  %t133 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorType(ptr %v0, ptr %v0, ptr %s0, ptr %t130, ptr %t131, ptr %l64)
  store i32 %t133, ptr %l66
  br label %bb29
bb29:
  %t134 = load i32, ptr %l66, !tbaa !23
  store i32 %t134, ptr %l4, !tbaa !23
  %t135 = load i32, ptr %l4, !tbaa !23
  %t136 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t139 = icmp eq i32 %t135, %t136
  br i1 %t139, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t142 = load ptr, ptr %l0, !tbaa !29
  store ptr %t142, ptr %l71, !tbaa !29
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/check:Checker", ptr %t143, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t148 = getelementptr %"compiler/generic:Program", ptr %t146, i32 0, i32 2
  %t149 = load i32, ptr %l4, !tbaa !23
  %t152 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t148, i32 %t149)
  store i32 %t152, ptr %l76
  br label %bb33
bb33:
  %t153 = load ptr, ptr %l2, !tbaa !29
  %t155 = getelementptr %"compiler/ast:Path", ptr %t153, i32 0, i32 1
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  store { i64, ptr } %t156, ptr %l78, !tbaa !27
  %t157 = load ptr, ptr %l2, !tbaa !29
  %t159 = getelementptr %"compiler/ast:Path", ptr %t157, i32 0, i32 1
  %t160 = load { i64, ptr }, ptr %t159, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t160, 0
  %t164 = sub i64 %t162, 1
  %t166 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr i32, ptr %t167, i64 %t164
  %t169 = load i32, ptr %t168, !tbaa !33
  %t170 = load ptr, ptr %l71, !tbaa !29
  %t171 = load i32, ptr %l76, !tbaa !23
  %t173 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordIndex(ptr %v0, ptr %t170, i32 %t171, i32 %t169)
  store i64 %t173, ptr %l84
  br label %bb34
bb34:
  %t174 = load i64, ptr %l84, !tbaa !24
  %t175 = icmp sge i64 %t174, 0
  call void @__olang_scope_close(ptr %s0)
  store i1 %t175, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternRules(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca %"compiler/diagmsg:Msg"
  %l17 = alloca i32
  %l18 = alloca %"compiler/diagmsg:Msg"
  %l22 = alloca ptr
  %l26 = alloca i64
  %l30 = alloca i32
  %l33 = alloca ptr
  %l38 = alloca i32
  %l39 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca i1
  %l50 = alloca ptr
  %l60 = alloca i64
  %l63 = alloca i64
  %l85 = alloca { i64, ptr }
  %l91 = alloca i1
  %l94 = alloca i1
  %l97 = alloca i1
  %l100 = alloca i1
  %l102 = alloca i1
  %l107 = alloca i32
  %l110 = alloca i1
  %l113 = alloca ptr
  %l118 = alloca i32
  %l119 = alloca { i64, ptr }
  %l122 = alloca i1
  %l127 = alloca i32
  %l130 = alloca i1
  %l133 = alloca ptr
  %l138 = alloca i32
  %l139 = alloca { i64, ptr }
  %l144 = alloca { i64, ptr }
  %l150 = alloca ptr
  %l153 = alloca i32
  %l154 = alloca i1
  %l155 = alloca %"compiler/diagmsg:Msg"
  %l158 = alloca { i64, ptr }
  %l160 = alloca %"compiler/diagmsg:Msg"
  %l163 = alloca { i64, ptr }
  %l165 = alloca %"compiler/diagmsg:Msg"
  %l169 = alloca ptr
  %l170 = alloca i64
  %l172 = alloca i64
  %l174 = alloca i64
  %l178 = alloca { i64, ptr }
  %l182 = alloca { i64, ptr }
  %l187 = alloca i64
  %l194 = alloca i32
  %l198 = alloca i1
  %l202 = alloca i1
  %l206 = alloca i1
  %l217 = alloca i1
  %l220 = alloca i1
  %l224 = alloca ptr
  %l227 = alloca i32
  %l228 = alloca i1
  %l229 = alloca i1
  %l235 = alloca %"compiler/diagmsg:Msg"
  %l238 = alloca { i64, ptr }
  %l240 = alloca %"compiler/diagmsg:Msg"
  %l243 = alloca { i64, ptr }
  %l245 = alloca %"compiler/diagmsg:Msg"
  %l249 = alloca ptr
  %l250 = alloca i64
  %l253 = alloca { i64, ptr }
  %l255 = alloca %"compiler/source:Span"
  %l257 = alloca i64
  %l260 = alloca { i64, ptr }
  %l267 = alloca %"compiler/source:Span"
  %l272 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %t364 = alloca { i64, [3 x i64] }, align 8
  %t564 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l22
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l22, !tbaa !29
  store ptr %t9, ptr %l2, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l26
  br label %bb2
bb2:
  %t18 = load i64, ptr %l26, !tbaa !24
  store i64 %t18, ptr %l3, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t23 = load i64, ptr %l1, !tbaa !24
  %t26 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t22, i64 %t23)
  store i32 %t26, ptr %l30
  br label %bb3
bb3:
  %t27 = load i32, ptr %l30, !tbaa !23
  store i32 %t27, ptr %l4, !tbaa !23
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  store ptr %t33, ptr %l33, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  %t40 = load i32, ptr %l4, !tbaa !23
  %t43 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t43, ptr %l38
  br label %bb4
bb4:
  %t44 = load ptr, ptr %l33, !tbaa !29
  %t45 = load i32, ptr %l38, !tbaa !23
  %t46 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t44, i32 %t45)
  store { i64, ptr } %t46, ptr %l39
  br label %bb5
bb5:
  %t47 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t47, ptr %l5, !tbaa !27
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load ptr, ptr %l2, !tbaa !29
  %t51 = getelementptr %"compiler/ast:Func", ptr %t49, i32 0, i32 2
  %t52 = load i32, ptr %t51, !tbaa !23
  %t55 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t48, i32 %t52)
  store { i64, ptr } %t55, ptr %l43
  br label %bb6
bb6:
  %t56 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t57 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t56, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i1 %t57, ptr %l44
  br label %bb7
bb7:
  %t58 = load i1, ptr %l44, !tbaa !21
  store i1 %t58, ptr %l6, !tbaa !21
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/load:Loader", ptr %t65, i32 0, i32 10
  %t68 = load i64, ptr %l3, !tbaa !24
  %t71 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t67, i64 %t68)
  store ptr %t71, ptr %l50
  br label %bb8
bb8:
  %t72 = load ptr, ptr %l50, !tbaa !29
  %t74 = getelementptr %"compiler/load:Module", ptr %t72, i32 0, i32 4
  %t75 = load i64, ptr %t74, !tbaa !24
  store i64 %t75, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t77 = load ptr, ptr %l2, !tbaa !29
  %t79 = getelementptr %"compiler/ast:Func", ptr %t77, i32 0, i32 3
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/ast:Sig", ptr %t80, i32 0, i32 0
  %t83 = load { i64, ptr }, ptr %t82, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t83, 0
  store i64 %t85, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t87 = load i64, ptr %l9, !tbaa !24
  %t88 = load i64, ptr %l8, !tbaa !24
  %t91 = icmp sgt i64 %t87, %t88
  br i1 %t91, label %bb9, label %bb10
bb9:
  %t93 = load i64, ptr %l10, !tbaa !24
  %t95 = icmp sgt i64 %t93, 0
  br i1 %t95, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l60, !tbaa !24
  br label %bb14
bb11:
  %t97 = load i64, ptr %l9, !tbaa !24
  %t98 = load i64, ptr %l8, !tbaa !24
  %t101 = sub i64 %t97, %t98
  %t102 = load i64, ptr %l10, !tbaa !24
  %t105 = add i64 %t101, %t102
  %t107 = sub i64 %t105, 1
  %t108 = load i64, ptr %l10, !tbaa !24
  %t111 = sdiv i64 %t107, %t108
  store i64 %t111, ptr %l63, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb13
bb13:
  %t113 = load i64, ptr %l63, !tbaa !24
  store i64 %t113, ptr %l60, !tbaa !24
  br label %bb14
bb14:
  %t114 = load i64, ptr %l60, !tbaa !24
  store i64 %t114, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t115 = load i64, ptr %l12, !tbaa !24
  %t116 = load i64, ptr %l11, !tbaa !24
  %t119 = icmp slt i64 %t115, %t116
  %t121 = xor i1 %t119, true
  br i1 %t121, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb69
bb17:
  br label %bb18
bb18:
  %t123 = load i64, ptr %l8, !tbaa !24
  %t124 = load i64, ptr %l12, !tbaa !24
  %t125 = load i64, ptr %l10, !tbaa !24
  %t128 = mul i64 %t124, %t125
  %t131 = add i64 %t123, %t128
  store i64 %t131, ptr %l13, !tbaa !24
  %t133 = load i64, ptr %l13, !tbaa !24
  %t134 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t134, 0
  %t139 = icmp sge i64 %t133, %t136
  br i1 %t139, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb69
bb20:
  br label %bb21
bb21:
  %t141 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t141, ptr %l85, !tbaa !27
  %t142 = load i64, ptr %l13, !tbaa !24
  %t144 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = getelementptr i32, ptr %t145, i64 %t142
  %t147 = load i32, ptr %t146, !tbaa !33
  store i32 %t147, ptr %l14, !tbaa !23
  %t149 = load i32, ptr %l14, !tbaa !23
  %t150 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t153 = icmp eq i32 %t149, %t150
  br i1 %t153, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l91, !tbaa !21
  br label %bb25
bb23:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load i32, ptr %l14, !tbaa !23
  %t159 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternParam(ptr %v0, ptr %t155, i32 %t156)
  store i1 %t159, ptr %l94
  br label %bb24
bb24:
  %t160 = load i1, ptr %l94, !tbaa !21
  store i1 %t160, ptr %l91, !tbaa !21
  br label %bb25
bb25:
  %t161 = load i1, ptr %l91, !tbaa !21
  br i1 %t161, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s2)
  br label %bb68
bb27:
  br label %bb28
bb28:
  %t162 = load i1, ptr %l6, !tbaa !21
  %t164 = xor i1 %t162, true
  br i1 %t164, label %bb29, label %bb30
bb29:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load i32, ptr %l14, !tbaa !23
  %t170 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallbackType(ptr %v0, ptr %t166, i32 %t167)
  store i1 %t170, ptr %l100
  br label %bb31
bb30:
  store i1 false, ptr %l97, !tbaa !21
  br label %bb32
bb31:
  %t171 = load i1, ptr %l100, !tbaa !21
  store i1 %t171, ptr %l97, !tbaa !21
  br label %bb32
bb32:
  %t172 = load i1, ptr %l97, !tbaa !21
  br i1 %t172, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s2)
  br label %bb68
bb34:
  br label %bb35
bb35:
  %t173 = load i1, ptr %l6, !tbaa !21
  br i1 %t173, label %bb36, label %bb37
bb36:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/check:Checker", ptr %t175, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !29
  %t180 = getelementptr %"compiler/generic:Program", ptr %t178, i32 0, i32 2
  %t181 = load i32, ptr %l14, !tbaa !23
  %t184 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t180, i32 %t181)
  store i32 %t184, ptr %l107
  br label %bb38
bb37:
  store i1 false, ptr %l102, !tbaa !21
  br label %bb39
bb38:
  %t185 = load i32, ptr %l107, !range !{i32 0, i32 33}
  %t187 = trunc i64 21 to i32
  %t188 = icmp eq i32 %t185, %t187
  store i1 %t188, ptr %l102, !tbaa !21
  br label %bb39
bb39:
  %t190 = load i1, ptr %l102, !tbaa !21
  br i1 %t190, label %bb40, label %bb41
bb40:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/check:Checker", ptr %t191, i32 0, i32 1
  %t194 = load ptr, ptr %t193, !tbaa !29
  %t196 = getelementptr %"compiler/generic:Program", ptr %t194, i32 0, i32 2
  store ptr %t196, ptr %l113, !tbaa !29
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/check:Checker", ptr %t197, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !29
  %t202 = getelementptr %"compiler/generic:Program", ptr %t200, i32 0, i32 2
  %t203 = load i32, ptr %l14, !tbaa !23
  %t206 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t202, i32 %t203)
  store i32 %t206, ptr %l118
  br label %bb42
bb41:
  store i1 false, ptr %l110, !tbaa !21
  br label %bb44
bb42:
  %t207 = load ptr, ptr %l113, !tbaa !29
  %t208 = load i32, ptr %l118, !tbaa !23
  %t209 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s2, ptr %t207, i32 %t208)
  store { i64, ptr } %t209, ptr %l119
  br label %bb43
bb43:
  %t210 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t210, 0
  %t213 = icmp eq i64 %t211, 0
  store i1 %t213, ptr %l110, !tbaa !21
  br label %bb44
bb44:
  %t215 = load i1, ptr %l110, !tbaa !21
  br i1 %t215, label %bb45, label %bb46
bb45:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/check:Checker", ptr %t216, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !29
  %t221 = getelementptr %"compiler/generic:Program", ptr %t219, i32 0, i32 2
  %t222 = load i32, ptr %l14, !tbaa !23
  %t225 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t221, i32 %t222)
  store i32 %t225, ptr %l127
  br label %bb47
bb46:
  store i1 false, ptr %l122, !tbaa !21
  br label %bb48
bb47:
  %t226 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t227 = load i32, ptr %l127, !tbaa !23
  %t229 = icmp eq i32 %t227, %t226
  store i1 %t229, ptr %l122, !tbaa !21
  br label %bb48
bb48:
  %t231 = load i1, ptr %l122, !tbaa !21
  br i1 %t231, label %bb49, label %bb50
bb49:
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr %"compiler/check:Checker", ptr %t232, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !29
  %t237 = getelementptr %"compiler/generic:Program", ptr %t235, i32 0, i32 2
  store ptr %t237, ptr %l133, !tbaa !29
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/check:Checker", ptr %t238, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !29
  %t243 = getelementptr %"compiler/generic:Program", ptr %t241, i32 0, i32 2
  %t244 = load i32, ptr %l14, !tbaa !23
  %t247 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t243, i32 %t244)
  store i32 %t247, ptr %l138
  br label %bb51
bb50:
  store i1 false, ptr %l130, !tbaa !21
  br label %bb53
bb51:
  %t248 = load ptr, ptr %l133, !tbaa !29
  %t249 = load i32, ptr %l138, !tbaa !23
  %t250 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s2, ptr %t248, i32 %t249)
  store { i64, ptr } %t250, ptr %l139
  br label %bb52
bb52:
  %t251 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t251, 0
  %t254 = icmp eq i64 %t252, 0
  store i1 %t254, ptr %l130, !tbaa !21
  br label %bb53
bb53:
  %t256 = load i1, ptr %l130, !tbaa !21
  br i1 %t256, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s2)
  br label %bb68
bb55:
  br label %bb56
bb56:
  %t257 = load ptr, ptr %l2, !tbaa !29
  %t259 = getelementptr %"compiler/ast:Func", ptr %t257, i32 0, i32 3
  %t260 = load ptr, ptr %t259, !tbaa !29
  %t262 = getelementptr %"compiler/ast:Sig", ptr %t260, i32 0, i32 0
  %t263 = load { i64, ptr }, ptr %t262, !tbaa !27
  store { i64, ptr } %t263, ptr %l144, !tbaa !27
  %t264 = load i64, ptr %l13, !tbaa !24
  %t266 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !27
  %t268 = getelementptr ptr, ptr %t267, i64 %t264
  %t269 = load ptr, ptr %t268, !tbaa !39
  %t271 = getelementptr %"compiler/ast:Param", ptr %t269, i32 0, i32 0
  %t272 = load %"compiler/source:Span", ptr %t271
  store %"compiler/source:Span" %t272, ptr %l15
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/check:Checker", ptr %t274, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !29
  %t279 = getelementptr %"compiler/generic:Program", ptr %t277, i32 0, i32 2
  store ptr %t279, ptr %l150, !tbaa !29
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load i32, ptr %l14, !tbaa !23
  %t284 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t280, i32 %t281)
  store i32 %t284, ptr %l153
  br label %bb57
bb57:
  %t285 = load ptr, ptr %l150, !tbaa !29
  %t286 = load i32, ptr %l153, !tbaa !23
  %t287 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePacked(ptr %v0, ptr %t285, i32 %t286)
  store i1 %t287, ptr %l154
  br label %bb58
bb58:
  %t288 = load i1, ptr %l154, !tbaa !21
  br i1 %t288, label %bb59, label %bb60
bb59:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t290 = load i32, ptr %l14, !tbaa !23
  %t293 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t289, i32 %t290)
  store { i64, ptr } %t293, ptr %l158
  br label %bb61
bb60:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load i32, ptr %l14, !tbaa !23
  %t298 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t294, i32 %t295)
  store { i64, ptr } %t298, ptr %l163
  br label %bb63
bb61:
  %t299 = load { i64, ptr }, ptr %l158, !tbaa !27
  %t300 = extractvalue { i64, ptr } %t299, 0
  %t301 = extractvalue { i64, ptr } %t299, 1
  %t302 = mul i64 %t300, 1
  %t303 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t302)
  call void @llvm.memcpy.p0.p0.i64(ptr %t303, ptr %t301, i64 %t302, i1 false)
  %t304 = insertvalue { i64, ptr } undef, i64 %t300, 0
  %t305 = insertvalue { i64, ptr } %t304, ptr %t303, 1
  %t307 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePackedByValueC(ptr %s2, ptr %s2, { i64, ptr } %t305)
  store %"compiler/diagmsg:Msg" %t307, ptr %l160
  br label %bb62
bb62:
  %t308 = load %"compiler/diagmsg:Msg", ptr %l160
  store %"compiler/diagmsg:Msg" %t308, ptr %l155
  br label %bb65
bb63:
  %t309 = load { i64, ptr }, ptr %l163, !tbaa !27
  %t310 = extractvalue { i64, ptr } %t309, 0
  %t311 = extractvalue { i64, ptr } %t309, 1
  %t312 = mul i64 %t310, 1
  %t313 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t312)
  call void @llvm.memcpy.p0.p0.i64(ptr %t313, ptr %t311, i64 %t312, i1 false)
  %t314 = insertvalue { i64, ptr } undef, i64 %t310, 0
  %t315 = insertvalue { i64, ptr } %t314, ptr %t313, 1
  %t317 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eExternType(ptr %s2, ptr %s2, { i64, ptr } %t315)
  store %"compiler/diagmsg:Msg" %t317, ptr %l165
  br label %bb64
bb64:
  %t318 = load %"compiler/diagmsg:Msg", ptr %l165
  store %"compiler/diagmsg:Msg" %t318, ptr %l155
  br label %bb65
bb65:
  %t319 = load %"compiler/diagmsg:Msg", ptr %l155
  store %"compiler/diagmsg:Msg" %t319, ptr %l16
  %t320 = load ptr, ptr %l0, !tbaa !29
  %t322 = getelementptr %"compiler/check:Checker", ptr %t320, i32 0, i32 1
  %t323 = load ptr, ptr %t322, !tbaa !29
  %t325 = getelementptr %"compiler/generic:Program", ptr %t323, i32 0, i32 0
  %t326 = load ptr, ptr %t325, !tbaa !29
  %t328 = getelementptr %"compiler/load:Loader", ptr %t326, i32 0, i32 4
  %t329 = load ptr, ptr %t328, !tbaa !29
  store ptr %t329, ptr %l169, !tbaa !29
  %t330 = load i64, ptr %l7, !tbaa !24
  store i64 %t330, ptr %l170, !tbaa !24
  %t331 = getelementptr %"compiler/source:Span", ptr %l15, i32 0, i32 0
  %t332 = load i32, ptr %t331, !tbaa !23
  %t334 = sext i32 %t332 to i64
  store i64 %t334, ptr %l172, !tbaa !24
  %t335 = getelementptr %"compiler/source:Span", ptr %l15, i32 0, i32 0
  %t336 = load i32, ptr %t335, !tbaa !23
  %t338 = sext i32 %t336 to i64
  store i64 %t338, ptr %l174, !tbaa !24
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t340 = load ptr, ptr %l2, !tbaa !29
  %t342 = getelementptr %"compiler/ast:Func", ptr %t340, i32 0, i32 3
  %t343 = load ptr, ptr %t342, !tbaa !29
  %t345 = getelementptr %"compiler/ast:Sig", ptr %t343, i32 0, i32 0
  %t346 = load { i64, ptr }, ptr %t345, !tbaa !27
  store { i64, ptr } %t346, ptr %l178, !tbaa !27
  %t347 = load i64, ptr %l13, !tbaa !24
  %t349 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t350 = load ptr, ptr %t349, !tbaa !27
  %t351 = getelementptr ptr, ptr %t350, i64 %t347
  %t352 = load ptr, ptr %t351, !tbaa !39
  %t354 = getelementptr %"compiler/ast:Param", ptr %t352, i32 0, i32 1
  %t355 = load i32, ptr %t354, !tbaa !23
  %t358 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s2, ptr %t339, i32 %t355)
  store { i64, ptr } %t358, ptr %l182
  br label %bb66
bb66:
  %t359 = load { i64, ptr }, ptr %l182, !tbaa !27
  %t360 = extractvalue { i64, ptr } %t359, 0
  %t361 = load i64, ptr %l174, !tbaa !24
  %t363 = add i64 %t361, %t360
  store { i64, [3 x i64] } zeroinitializer, ptr %t364
  %t365 = getelementptr { i64, [3 x i64] }, ptr %t364, i32 0, i32 0
  store i64 3, ptr %t365
  %t366 = load i64, ptr %l170, !tbaa !24
  %t367 = insertvalue { i64, i64, i64 } undef, i64 %t366, 0
  %t368 = load i64, ptr %l172, !tbaa !24
  %t369 = insertvalue { i64, i64, i64 } %t367, i64 %t368, 1
  %t371 = insertvalue { i64, i64, i64 } %t369, i64 %t363, 2
  %t372 = getelementptr { i64, [3 x i64] }, ptr %t364, i32 0, i32 1
  store { i64, i64, i64 } %t371, ptr %t372
  %t373 = load { i64, [3 x i64] }, ptr %t364
  %t374 = load %"compiler/diagmsg:Msg", ptr %l16
  %t375 = load ptr, ptr %l169, !tbaa !29
  %t378 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s2, ptr %t375, { i64, [3 x i64] } %t373, %"compiler/diagmsg:Msg" %t374)
  store i64 %t378, ptr %l187
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s2)
  br label %bb68
bb68:
  %t379 = load i64, ptr %l12, !tbaa !24
  %t381 = add i64 %t379, 1
  store i64 %t381, ptr %l12, !tbaa !24
  br label %bb15
bb69:
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t385 = getelementptr %"compiler/check:Checker", ptr %t383, i32 0, i32 1
  %t386 = load ptr, ptr %t385, !tbaa !29
  %t388 = getelementptr %"compiler/generic:Program", ptr %t386, i32 0, i32 2
  %t389 = load i32, ptr %l4, !tbaa !23
  %t392 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t388, i32 %t389)
  store i32 %t392, ptr %l194
  br label %bb70
bb70:
  %t393 = load i32, ptr %l194, !tbaa !23
  store i32 %t393, ptr %l17, !tbaa !23
  %t394 = load i32, ptr %l17, !tbaa !23
  %t395 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t398 = icmp eq i32 %t394, %t395
  br i1 %t398, label %bb71, label %bb72
bb71:
  store i1 true, ptr %l198, !tbaa !21
  br label %bb73
bb72:
  %t400 = load i32, ptr %l17, !tbaa !23
  %t401 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t404 = icmp eq i32 %t400, %t401
  store i1 %t404, ptr %l198, !tbaa !21
  br label %bb73
bb73:
  %t406 = load i1, ptr %l198, !tbaa !21
  br i1 %t406, label %bb74, label %bb75
bb74:
  store i1 true, ptr %l202, !tbaa !21
  br label %bb76
bb75:
  %t407 = load i32, ptr %l17, !tbaa !23
  %t408 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t411 = icmp eq i32 %t407, %t408
  store i1 %t411, ptr %l202, !tbaa !21
  br label %bb76
bb76:
  %t413 = load i1, ptr %l202, !tbaa !21
  br i1 %t413, label %bb77, label %bb78
bb77:
  store i1 true, ptr %l206, !tbaa !21
  br label %bb79
bb78:
  %t414 = load ptr, ptr %l2, !tbaa !29
  %t416 = getelementptr %"compiler/ast:Func", ptr %t414, i32 0, i32 3
  %t417 = load ptr, ptr %t416, !tbaa !29
  %t419 = getelementptr %"compiler/ast:Sig", ptr %t417, i32 0, i32 1
  %t420 = load { i64, ptr }, ptr %t419, !tbaa !27
  %t422 = extractvalue { i64, ptr } %t420, 0
  %t424 = icmp eq i64 %t422, 0
  store i1 %t424, ptr %l206, !tbaa !21
  br label %bb79
bb79:
  %t426 = load i1, ptr %l206, !tbaa !21
  br i1 %t426, label %bb80, label %bb81
bb80:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb81:
  br label %bb82
bb82:
  %t427 = load ptr, ptr %l2, !tbaa !29
  %t429 = getelementptr %"compiler/ast:Func", ptr %t427, i32 0, i32 3
  %t430 = load ptr, ptr %t429, !tbaa !29
  %t432 = getelementptr %"compiler/ast:Sig", ptr %t430, i32 0, i32 1
  %t433 = load { i64, ptr }, ptr %t432, !tbaa !27
  %t435 = extractvalue { i64, ptr } %t433, 0
  %t437 = icmp sgt i64 %t435, 1
  br i1 %t437, label %bb83, label %bb84
bb83:
  store i1 true, ptr %l217, !tbaa !21
  br label %bb86
bb84:
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t440 = load i32, ptr %l17, !tbaa !23
  %t443 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %t439, i32 %t440)
  store i1 %t443, ptr %l220
  br label %bb85
bb85:
  %t444 = load i1, ptr %l220, !tbaa !21
  %t445 = xor i1 %t444, true
  store i1 %t445, ptr %l217, !tbaa !21
  br label %bb86
bb86:
  %t447 = load i1, ptr %l217, !tbaa !21
  br i1 %t447, label %bb87, label %bb88
bb87:
  store %olang.scope zeroinitializer, ptr %s9
  %t448 = load ptr, ptr %l0, !tbaa !29
  %t450 = getelementptr %"compiler/check:Checker", ptr %t448, i32 0, i32 1
  %t451 = load ptr, ptr %t450, !tbaa !29
  %t453 = getelementptr %"compiler/generic:Program", ptr %t451, i32 0, i32 2
  store ptr %t453, ptr %l224, !tbaa !29
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t455 = load i32, ptr %l17, !tbaa !23
  %t458 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t454, i32 %t455)
  store i32 %t458, ptr %l227
  br label %bb89
bb88:
  br label %bb104
bb89:
  %t459 = load ptr, ptr %l224, !tbaa !29
  %t460 = load i32, ptr %l227, !tbaa !23
  %t461 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePacked(ptr %v0, ptr %t459, i32 %t460)
  store i1 %t461, ptr %l228
  br label %bb90
bb90:
  %t462 = load i1, ptr %l228, !tbaa !21
  br i1 %t462, label %bb91, label %bb92
bb91:
  %t463 = load ptr, ptr %l2, !tbaa !29
  %t465 = getelementptr %"compiler/ast:Func", ptr %t463, i32 0, i32 3
  %t466 = load ptr, ptr %t465, !tbaa !29
  %t468 = getelementptr %"compiler/ast:Sig", ptr %t466, i32 0, i32 1
  %t469 = load { i64, ptr }, ptr %t468, !tbaa !27
  %t471 = extractvalue { i64, ptr } %t469, 0
  %t473 = icmp eq i64 %t471, 1
  store i1 %t473, ptr %l229, !tbaa !21
  br label %bb93
bb92:
  store i1 false, ptr %l229, !tbaa !21
  br label %bb93
bb93:
  %t475 = load i1, ptr %l229, !tbaa !21
  br i1 %t475, label %bb94, label %bb95
bb94:
  %t476 = load ptr, ptr %l0, !tbaa !29
  %t477 = load i32, ptr %l17, !tbaa !23
  %t480 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t476, i32 %t477)
  store { i64, ptr } %t480, ptr %l238
  br label %bb96
bb95:
  %t481 = load ptr, ptr %l0, !tbaa !29
  %t482 = load i32, ptr %l17, !tbaa !23
  %t485 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t481, i32 %t482)
  store { i64, ptr } %t485, ptr %l243
  br label %bb98
bb96:
  %t486 = load { i64, ptr }, ptr %l238, !tbaa !27
  %t487 = extractvalue { i64, ptr } %t486, 0
  %t488 = extractvalue { i64, ptr } %t486, 1
  %t489 = mul i64 %t487, 1
  %t490 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t489)
  call void @llvm.memcpy.p0.p0.i64(ptr %t490, ptr %t488, i64 %t489, i1 false)
  %t491 = insertvalue { i64, ptr } undef, i64 %t487, 0
  %t492 = insertvalue { i64, ptr } %t491, ptr %t490, 1
  %t494 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePackedByValueC(ptr %s9, ptr %s9, { i64, ptr } %t492)
  store %"compiler/diagmsg:Msg" %t494, ptr %l240
  br label %bb97
bb97:
  %t495 = load %"compiler/diagmsg:Msg", ptr %l240
  store %"compiler/diagmsg:Msg" %t495, ptr %l235
  br label %bb100
bb98:
  %t496 = load { i64, ptr }, ptr %l243, !tbaa !27
  %t497 = extractvalue { i64, ptr } %t496, 0
  %t498 = extractvalue { i64, ptr } %t496, 1
  %t499 = mul i64 %t497, 1
  %t500 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t499)
  call void @llvm.memcpy.p0.p0.i64(ptr %t500, ptr %t498, i64 %t499, i1 false)
  %t501 = insertvalue { i64, ptr } undef, i64 %t497, 0
  %t502 = insertvalue { i64, ptr } %t501, ptr %t500, 1
  %t504 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eExternResult(ptr %s9, ptr %s9, { i64, ptr } %t502)
  store %"compiler/diagmsg:Msg" %t504, ptr %l245
  br label %bb99
bb99:
  %t505 = load %"compiler/diagmsg:Msg", ptr %l245
  store %"compiler/diagmsg:Msg" %t505, ptr %l235
  br label %bb100
bb100:
  %t506 = load %"compiler/diagmsg:Msg", ptr %l235
  store %"compiler/diagmsg:Msg" %t506, ptr %l18
  %t507 = load ptr, ptr %l0, !tbaa !29
  %t509 = getelementptr %"compiler/check:Checker", ptr %t507, i32 0, i32 1
  %t510 = load ptr, ptr %t509, !tbaa !29
  %t512 = getelementptr %"compiler/generic:Program", ptr %t510, i32 0, i32 0
  %t513 = load ptr, ptr %t512, !tbaa !29
  %t515 = getelementptr %"compiler/load:Loader", ptr %t513, i32 0, i32 4
  %t516 = load ptr, ptr %t515, !tbaa !29
  store ptr %t516, ptr %l249, !tbaa !29
  %t517 = load i64, ptr %l7, !tbaa !24
  store i64 %t517, ptr %l250, !tbaa !24
  %t518 = load ptr, ptr %l2, !tbaa !29
  %t520 = getelementptr %"compiler/ast:Func", ptr %t518, i32 0, i32 3
  %t521 = load ptr, ptr %t520, !tbaa !29
  %t523 = getelementptr %"compiler/ast:Sig", ptr %t521, i32 0, i32 1
  %t524 = load { i64, ptr }, ptr %t523, !tbaa !27
  store { i64, ptr } %t524, ptr %l253, !tbaa !27
  %t525 = getelementptr { i64, ptr }, ptr %l253, i32 0, i32 1
  %t526 = load ptr, ptr %t525, !tbaa !27
  %t527 = getelementptr ptr, ptr %t526, i64 0
  %t528 = load ptr, ptr %t527, !tbaa !39
  %t530 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %t528)
  store %"compiler/source:Span" %t530, ptr %l255
  br label %bb101
bb101:
  %t531 = getelementptr %"compiler/source:Span", ptr %l255, i32 0, i32 0
  %t532 = load i32, ptr %t531, !tbaa !23
  %t534 = sext i32 %t532 to i64
  store i64 %t534, ptr %l257, !tbaa !24
  %t535 = load ptr, ptr %l2, !tbaa !29
  %t537 = getelementptr %"compiler/ast:Func", ptr %t535, i32 0, i32 3
  %t538 = load ptr, ptr %t537, !tbaa !29
  %t540 = getelementptr %"compiler/ast:Sig", ptr %t538, i32 0, i32 1
  %t541 = load { i64, ptr }, ptr %t540, !tbaa !27
  store { i64, ptr } %t541, ptr %l260, !tbaa !27
  %t542 = load ptr, ptr %l2, !tbaa !29
  %t544 = getelementptr %"compiler/ast:Func", ptr %t542, i32 0, i32 3
  %t545 = load ptr, ptr %t544, !tbaa !29
  %t547 = getelementptr %"compiler/ast:Sig", ptr %t545, i32 0, i32 1
  %t548 = load { i64, ptr }, ptr %t547, !tbaa !27
  %t550 = extractvalue { i64, ptr } %t548, 0
  %t552 = sub i64 %t550, 1
  %t554 = getelementptr { i64, ptr }, ptr %l260, i32 0, i32 1
  %t555 = load ptr, ptr %t554, !tbaa !27
  %t556 = getelementptr ptr, ptr %t555, i64 %t552
  %t557 = load ptr, ptr %t556, !tbaa !39
  %t559 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %t557)
  store %"compiler/source:Span" %t559, ptr %l267
  br label %bb102
bb102:
  %t560 = getelementptr %"compiler/source:Span", ptr %l267, i32 0, i32 1
  %t561 = load i32, ptr %t560, !tbaa !23
  %t563 = sext i32 %t561 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t564
  %t565 = getelementptr { i64, [3 x i64] }, ptr %t564, i32 0, i32 0
  store i64 3, ptr %t565
  %t566 = load i64, ptr %l250, !tbaa !24
  %t567 = insertvalue { i64, i64, i64 } undef, i64 %t566, 0
  %t568 = load i64, ptr %l257, !tbaa !24
  %t569 = insertvalue { i64, i64, i64 } %t567, i64 %t568, 1
  %t571 = insertvalue { i64, i64, i64 } %t569, i64 %t563, 2
  %t572 = getelementptr { i64, [3 x i64] }, ptr %t564, i32 0, i32 1
  store { i64, i64, i64 } %t571, ptr %t572
  %t573 = load { i64, [3 x i64] }, ptr %t564
  %t574 = load %"compiler/diagmsg:Msg", ptr %l18
  %t575 = load ptr, ptr %l249, !tbaa !29
  %t578 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s9, ptr %t575, { i64, [3 x i64] } %t573, %"compiler/diagmsg:Msg" %t574)
  store i64 %t578, ptr %l272
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s9)
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efirstValueType(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i32
  %l7 = alloca i32
  %l10 = alloca i1
  %l11 = alloca i1
  %l16 = alloca i32
  %l19 = alloca i1
  %l21 = alloca i1
  %l26 = alloca i32
  %l31 = alloca i32
  %l34 = alloca i1
  %l39 = alloca i32
  %l41 = alloca i1
  %l44 = alloca i1
  %l47 = alloca ptr
  %l52 = alloca i32
  %l53 = alloca i32
  %l56 = alloca i1
  %l59 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %a2)
  store i32 %t4, ptr %l7
  br label %bb1
bb1:
  %t5 = load i32, ptr %l7, !tbaa !23
  store i32 %t5, ptr %l4, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l4, !tbaa !23
  %t10 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l10
  br label %bb2
bb2:
  %t11 = load i1, ptr %l10, !tbaa !21
  br i1 %t11, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb6
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %l4, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l16
  br label %bb5
bb5:
  %t22 = load i32, ptr %l16, !range !{i32 0, i32 33}
  %t24 = trunc i64 21 to i32
  %t25 = icmp eq i32 %t22, %t24
  store i1 %t25, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l11, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t30 = call i1 @compiler_2fcheck_2enullValue(ptr %v1, ptr %a1)
  store i1 %t30, ptr %l21
  br label %bb9
bb8:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb10
bb9:
  %t31 = load i1, ptr %l21, !tbaa !21
  store i1 %t31, ptr %l19, !tbaa !21
  br label %bb10
bb10:
  %t32 = load i1, ptr %l19, !tbaa !21
  br i1 %t32, label %bb11, label %bb12
bb11:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %l4, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l26
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t43 = load i32, ptr %l26, !tbaa !23
  store i32 %t43, ptr %l4, !tbaa !23
  br label %bb14
bb14:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  %t50 = load i32, ptr %l4, !tbaa !23
  %t53 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t53, ptr %l31
  br label %bb15
bb15:
  %t54 = load i32, ptr %l31, !range !{i32 0, i32 33}
  %t56 = trunc i64 19 to i32
  %t57 = icmp eq i32 %t54, %t56
  br i1 %t57, label %bb16, label %bb17
bb16:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  %t65 = load i32, ptr %l4, !tbaa !23
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t64, i32 %t65)
  store i32 %t68, ptr %l39
  br label %bb18
bb17:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb19
bb18:
  %t69 = load i32, ptr %l39, !tbaa !23
  %t70 = icmp ne i32 %t69, 0
  store i1 %t70, ptr %l34, !tbaa !21
  br label %bb19
bb19:
  %t72 = load i1, ptr %l34, !tbaa !21
  br i1 %t72, label %bb20, label %bb21
bb20:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t77 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitArray(ptr %v0, ptr %v3, ptr %t73, ptr %a3)
  store i1 %t77, ptr %l44
  br label %bb22
bb21:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb23
bb22:
  %t78 = load i1, ptr %l44, !tbaa !21
  store i1 %t78, ptr %l41, !tbaa !21
  br label %bb23
bb23:
  %t79 = load i1, ptr %l41, !tbaa !21
  br i1 %t79, label %bb24, label %bb25
bb24:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/check:Checker", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = getelementptr %"compiler/generic:Program", ptr %t83, i32 0, i32 2
  store ptr %t85, ptr %l47, !tbaa !29
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/generic:Program", ptr %t89, i32 0, i32 2
  %t92 = load i32, ptr %l4, !tbaa !23
  %t95 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t91, i32 %t92)
  store i32 %t95, ptr %l52
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t96 = load ptr, ptr %l47, !tbaa !29
  %t97 = load i32, ptr %l52, !tbaa !23
  %t98 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t96, i32 %t97, i32 0)
  store i32 %t98, ptr %l53
  br label %bb27
bb27:
  %t99 = load i32, ptr %l53, !tbaa !23
  store i32 %t99, ptr %l4, !tbaa !23
  br label %bb28
bb28:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load i32, ptr %l4, !tbaa !23
  %t104 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t100, i32 %t101)
  store i1 %t104, ptr %l56
  br label %bb29
bb29:
  %t105 = load i1, ptr %l56, !tbaa !21
  br i1 %t105, label %bb30, label %bb31
bb30:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i32, ptr %l4, !tbaa !23
  %t110 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %t106, i32 %t107)
  store i32 %t110, ptr %l59
  br label %bb32
bb31:
  br label %bb33
bb32:
  %t111 = load i32, ptr %l59, !tbaa !23
  store i32 %t111, ptr %l4, !tbaa !23
  br label %bb33
bb33:
  %t112 = load i32, ptr %l4, !tbaa !23
  store i32 %t112, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/names:Ref"
  %l4 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/names:Ref"
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca ptr
  %l18 = alloca ptr
  %l22 = alloca %"compiler/names:Ref"
  %l25 = alloca i1
  %l32 = alloca i32
  %l37 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca i1
  %l48 = alloca ptr
  %l50 = alloca ptr
  %l54 = alloca %"compiler/names:Ref"
  %l57 = alloca i1
  %l64 = alloca i32
  %l69 = alloca i64
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  br label %bb5
bb4:
  br label %bb19
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  store ptr %t22, ptr %l16, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t23)
  store ptr %t25, ptr %l18
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l18, !tbaa !29
  %t28 = getelementptr %"compiler/check:frame", ptr %t26, i32 0, i32 2
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t31 = load i32, ptr %t30, !tbaa !23
  %t32 = load ptr, ptr %l16, !tbaa !29
  %t35 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t32, i64 %t29, i32 %t31)
  store %"compiler/names:Ref" %t35, ptr %l22
  br label %bb7
bb7:
  %t36 = load %"compiler/names:Ref", ptr %l22
  store %"compiler/names:Ref" %t36, ptr %l3
  %t37 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 0
  %t38 = load i32, ptr %t37, !range !{i32 0, i32 9}
  %t40 = trunc i64 4 to i32
  %t41 = icmp eq i32 %t38, %t40
  br i1 %t41, label %bb8, label %bb9
bb8:
  %t43 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 2
  %t44 = load i64, ptr %t43, !tbaa !24
  %t46 = icmp sge i64 %t44, 0
  store i1 %t46, ptr %l25, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb10
bb10:
  %t48 = load i1, ptr %l25, !tbaa !21
  br i1 %t48, label %bb11, label %bb12
bb11:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t53 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 1
  %t54 = load i64, ptr %t53, !tbaa !24
  %t55 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 2
  %t56 = load i64, ptr %t55, !tbaa !24
  %t60 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t52, i64 %t54, i64 %t56)
  store i32 %t60, ptr %l32
  br label %bb13
bb12:
  br label %bb18
bb13:
  %t61 = load i32, ptr %l32, !tbaa !23
  store i32 %t61, ptr %l4, !tbaa !23
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l4, !tbaa !23
  %t71 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %t67, i32 %t68)
  store i64 %t71, ptr %l37
  br label %bb14
bb14:
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sgt i64 %t72, 0
  br i1 %t73, label %bb15, label %bb16
bb15:
  %t75 = load i32, ptr %l4, !tbaa !23
  store i32 %t75, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  br label %bb43
bb19:
  %t77 = load ptr, ptr %l1, !tbaa !29
  store ptr %t77, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t78 = load ptr, ptr %l40, !tbaa !29
  %t79 = icmp ne ptr %t78, null
  br i1 %t79, label %bb20, label %bb21
bb20:
  %t81 = load ptr, ptr %l40, !tbaa !29
  %t82 = load i64, ptr %t81, !range !{i64 0, i64 30}
  %t84 = icmp eq i64 %t82, 14
  store i1 %t84, ptr %l41, !tbaa !21
  br label %bb21
bb21:
  %t85 = load i1, ptr %l41, !tbaa !21
  br i1 %t85, label %bb22, label %bb23
bb22:
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr { i64, [4 x i64] }, ptr %t86, i32 0, i32 1
  %t89 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t88, i32 0, i32 0
  %t90 = load %"compiler/source:Span", ptr %t89
  store %"compiler/source:Span" %t90, ptr %l5
  br label %bb24
bb23:
  br label %bb38
bb24:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = getelementptr %"compiler/generic:Program", ptr %t95, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !29
  store ptr %t98, ptr %l48, !tbaa !29
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t99)
  store ptr %t101, ptr %l50
  br label %bb25
bb25:
  %t102 = load ptr, ptr %l50, !tbaa !29
  %t104 = getelementptr %"compiler/check:frame", ptr %t102, i32 0, i32 2
  %t105 = load i64, ptr %t104, !tbaa !24
  %t106 = getelementptr %"compiler/source:Span", ptr %l5, i32 0, i32 1
  %t107 = load i32, ptr %t106, !tbaa !23
  %t108 = load ptr, ptr %l48, !tbaa !29
  %t111 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %t108, i64 %t105, i32 %t107)
  store %"compiler/names:Ref" %t111, ptr %l54
  br label %bb26
bb26:
  %t112 = load %"compiler/names:Ref", ptr %l54
  store %"compiler/names:Ref" %t112, ptr %l6
  %t113 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 0
  %t114 = load i32, ptr %t113, !range !{i32 0, i32 9}
  %t116 = trunc i64 4 to i32
  %t117 = icmp eq i32 %t114, %t116
  br i1 %t117, label %bb27, label %bb28
bb27:
  %t119 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 2
  %t120 = load i64, ptr %t119, !tbaa !24
  %t122 = icmp sge i64 %t120, 0
  store i1 %t122, ptr %l57, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb29
bb29:
  %t124 = load i1, ptr %l57, !tbaa !21
  br i1 %t124, label %bb30, label %bb31
bb30:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/check:Checker", ptr %t125, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t129 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 1
  %t130 = load i64, ptr %t129, !tbaa !24
  %t131 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 2
  %t132 = load i64, ptr %t131, !tbaa !24
  %t136 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t128, i64 %t130, i64 %t132)
  store i32 %t136, ptr %l64
  br label %bb32
bb31:
  br label %bb37
bb32:
  %t137 = load i32, ptr %l64, !tbaa !23
  store i32 %t137, ptr %l7, !tbaa !23
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/check:Checker", ptr %t138, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t143 = getelementptr %"compiler/generic:Program", ptr %t141, i32 0, i32 2
  %t144 = load i32, ptr %l7, !tbaa !23
  %t147 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %t143, i32 %t144)
  store i64 %t147, ptr %l69
  br label %bb33
bb33:
  %t148 = load i64, ptr %l69, !tbaa !24
  %t149 = icmp sgt i64 %t148, 0
  br i1 %t149, label %bb34, label %bb35
bb34:
  %t151 = load i32, ptr %l7, !tbaa !23
  store i32 %t151, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  br label %bb37
bb37:
  br label %bb43
bb38:
  br i1 true, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_369dcc443ccea639_2a432d0faa4fb925)
  unreachable
bb43:
  store i32 -1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eidentity(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca { i64, [3 x i64] }
  %l14 = alloca ptr
  %l16 = alloca i1
  %l17 = alloca i1
  %l19 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l29 = alloca %"compiler/source:Span"
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca %"compiler/source:Span"
  %l34 = alloca i1
  %l37 = alloca { i64, ptr }
  %l40 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca %"compiler/source:Span"
  %l43 = alloca { i64, ptr }
  %l44 = alloca ptr
  %l46 = alloca %"compiler/source:Span"
  %l47 = alloca { i64, ptr }
  %l48 = alloca ptr
  %l50 = alloca %"compiler/source:Span"
  %l51 = alloca { i64, ptr }
  %l52 = alloca %"compiler/diagmsg:Msg"
  %l53 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca %"compiler/source:Span"
  %l57 = alloca %"compiler/diagmsg:Msg"
  %l58 = alloca i64
  %l62 = alloca ptr
  %l64 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca %"compiler/source:Span"
  %l67 = alloca %"compiler/diagmsg:Msg"
  %l68 = alloca i64
  %l72 = alloca ptr
  %l77 = alloca ptr
  %l80 = alloca i32
  %l86 = alloca ptr
  %l91 = alloca i1
  %l95 = alloca i1
  %l96 = alloca ptr
  %l97 = alloca %"compiler/source:Span"
  %l98 = alloca ptr
  %l100 = alloca %"compiler/source:Span"
  %l101 = alloca { i64, ptr }
  %l104 = alloca %"compiler/diagmsg:Msg"
  %l105 = alloca i64
  %l106 = alloca ptr
  %l107 = alloca %"compiler/source:Span"
  %l108 = alloca i32
  %l110 = alloca i64
  %l111 = alloca ptr
  %l112 = alloca ptr
  %l113 = alloca %"compiler/source:Span"
  %l114 = alloca i32
  %l115 = alloca i32
  %l116 = alloca ptr
  %l120 = alloca ptr
  %l122 = alloca ptr
  %l124 = alloca ptr
  %l128 = alloca ptr
  %l132 = alloca i1
  %l134 = alloca i1
  %l139 = alloca i32
  %l143 = alloca ptr
  %l144 = alloca %"compiler/source:Span"
  %l147 = alloca { i64, ptr }
  %l149 = alloca %"compiler/diagmsg:Msg"
  %l150 = alloca i64
  %l154 = alloca ptr
  %l159 = alloca i1
  %l160 = alloca i1
  %l165 = alloca i1
  %l167 = alloca ptr
  %l168 = alloca %"compiler/source:Span"
  %l169 = alloca ptr
  %l171 = alloca %"compiler/source:Span"
  %l172 = alloca { i64, ptr }
  %l174 = alloca { i64, ptr }
  %l175 = alloca %"compiler/diagmsg:Msg"
  %l176 = alloca i64
  %l177 = alloca ptr
  %l178 = alloca %"compiler/source:Span"
  %l179 = alloca i32
  %l181 = alloca i64
  %l182 = alloca ptr
  %l185 = alloca i1
  %l186 = alloca ptr
  %l187 = alloca %"compiler/source:Span"
  %l188 = alloca ptr
  %l190 = alloca %"compiler/source:Span"
  %l191 = alloca { i64, ptr }
  %l194 = alloca { i64, ptr }
  %l195 = alloca { i64, ptr }
  %l197 = alloca { i64, ptr }
  %l198 = alloca %"compiler/diagmsg:Msg"
  %l199 = alloca i64
  %l201 = alloca ptr
  %l205 = alloca { i64, [3 x i64] }
  %l208 = alloca { i64, [3 x i64] }
  %l211 = alloca { i64, [3 x i64] }
  %l218 = alloca ptr
  %l219 = alloca i64
  %l220 = alloca { i64, [3 x i64] }
  %l221 = alloca %"compiler/diagmsg:Msg"
  %l222 = alloca ptr
  %l223 = alloca %"compiler/source:Span"
  %l224 = alloca i32
  %l226 = alloca i64
  %l227 = alloca ptr
  %l228 = alloca ptr
  %l233 = alloca ptr
  %l234 = alloca i32
  %l236 = alloca %"compiler/source:Span"
  %l237 = alloca ptr
  %l245 = alloca ptr
  %l247 = alloca ptr
  %l251 = alloca ptr
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = call i1 @compiler_2fcheck_2eisNullLit(ptr %v1, ptr %t1)
  store i1 %t3, ptr %l16
  br label %bb1
bb1:
  %t4 = load i1, ptr %l16, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = call i1 @compiler_2fcheck_2eisNullLit(ptr %v2, ptr %t5)
  store i1 %t7, ptr %l19
  br label %bb4
bb3:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb5
bb4:
  %t8 = load i1, ptr %l19, !tbaa !21
  %t9 = xor i1 %t8, true
  store i1 %t9, ptr %l17, !tbaa !21
  br label %bb5
bb5:
  %t11 = load i1, ptr %l17, !tbaa !21
  br i1 %t11, label %bb6, label %bb7
bb6:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load %"compiler/source:Span", ptr %l1
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t16 = load i1, ptr %l4, !tbaa !21
  %t22 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eidentity(ptr %v0, ptr %v2, ptr %v1, ptr %v3, ptr %t12, %"compiler/source:Span" %t13, ptr %t14, ptr %t15, i1 %t16)
  store ptr %t22, ptr %l26
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t23 = load ptr, ptr %l26, !tbaa !29
  store ptr %t23, ptr %rv
  br label %ret
bb9:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l27, !tbaa !29
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t25)
  store %"compiler/source:Span" %t27, ptr %l29
  br label %bb10
bb10:
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t30 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t28)
  store %"compiler/source:Span" %t30, ptr %l31
  br label %bb11
bb11:
  %t31 = load ptr, ptr %l27, !tbaa !29
  %t32 = load %"compiler/source:Span", ptr %l29
  %t33 = load %"compiler/source:Span", ptr %l31
  %t34 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t31, %"compiler/source:Span" %t32, %"compiler/source:Span" %t33, i64 2)
  store %"compiler/source:Span" %t34, ptr %l32
  br label %bb12
bb12:
  %t35 = load %"compiler/source:Span", ptr %l32
  store %"compiler/source:Span" %t35, ptr %l5
  %t36 = load ptr, ptr %l3, !tbaa !29
  %t38 = call i1 @compiler_2fcheck_2eisNullLit(ptr %v2, ptr %t36)
  store i1 %t38, ptr %l34
  br label %bb13
bb13:
  %t39 = load i1, ptr %l34, !tbaa !21
  %t40 = xor i1 %t39, true
  br i1 %t40, label %bb14, label %bb15
bb14:
  %t42 = load i1, ptr %l4, !tbaa !21
  br i1 %t42, label %bb16, label %bb17
bb15:
  br label %bb32
bb16:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l37, !tbaa !27
  br label %bb18
bb17:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l37, !tbaa !27
  br label %bb18
bb18:
  %t44 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t44, ptr %l6, !tbaa !27
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t49 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseWritten(ptr %v0, ptr %v2, ptr %t45, ptr %t46)
  store i1 %t49, ptr %l40
  br label %bb19
bb19:
  %t50 = load i1, ptr %l40, !tbaa !21
  br i1 %t50, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s3
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l41, !tbaa !29
  %t52 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t52, ptr %l42
  %t53 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t53, ptr %l43, !tbaa !27
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l44, !tbaa !29
  %t55 = load ptr, ptr %l2, !tbaa !29
  %t57 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t55)
  store %"compiler/source:Span" %t57, ptr %l46
  br label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l54, !tbaa !29
  %t59 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t59, ptr %l55
  %t60 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t61 = load ptr, ptr @__olang_prog_scope
  %t63 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eIsOnlyNull(ptr %t61, ptr %s4, { i64, ptr } %t60)
  store %"compiler/diagmsg:Msg" %t63, ptr %l57
  br label %bb28
bb22:
  %t64 = load ptr, ptr %l44, !tbaa !29
  %t65 = load %"compiler/source:Span", ptr %l46
  %t66 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t64, %"compiler/source:Span" %t65)
  store { i64, ptr } %t66, ptr %l47
  br label %bb23
bb23:
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l48, !tbaa !29
  %t68 = load ptr, ptr %l3, !tbaa !29
  %t70 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t68)
  store %"compiler/source:Span" %t70, ptr %l50
  br label %bb24
bb24:
  %t71 = load ptr, ptr %l48, !tbaa !29
  %t72 = load %"compiler/source:Span", ptr %l50
  %t73 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t71, %"compiler/source:Span" %t72)
  store { i64, ptr } %t73, ptr %l51
  br label %bb25
bb25:
  %t74 = load ptr, ptr @__olang_prog_scope
  %t75 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t78 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eIsCaseWritten(ptr %t74, ptr %v0, ptr %v0, ptr %s3, { i64, ptr } %t75, { i64, ptr } %t76, { i64, ptr } %t77)
  store %"compiler/diagmsg:Msg" %t78, ptr %l52
  br label %bb26
bb26:
  %t79 = load ptr, ptr %l41, !tbaa !29
  %t80 = load %"compiler/source:Span", ptr %l42
  %t81 = load %"compiler/diagmsg:Msg", ptr %l52
  %t82 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t79, %"compiler/source:Span" %t80, %"compiler/diagmsg:Msg" %t81)
  store i64 %t82, ptr %l53
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb28:
  %t83 = load ptr, ptr %l54, !tbaa !29
  %t84 = load %"compiler/source:Span", ptr %l55
  %t85 = load %"compiler/diagmsg:Msg", ptr %l57
  %t86 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t83, %"compiler/source:Span" %t84, %"compiler/diagmsg:Msg" %t85)
  store i64 %t86, ptr %l58
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s4)
  br label %bb30
bb30:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load %"compiler/source:Span", ptr %l1
  %t89 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t93 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t87, %"compiler/source:Span" %t88, i32 %t89, i64 0)
  store ptr %t93, ptr %l62
  br label %bb31
bb31:
  %t94 = load ptr, ptr %l62, !tbaa !29
  store ptr %t94, ptr %rv
  br label %ret
bb32:
  %t95 = load ptr, ptr %l2, !tbaa !29
  %t97 = call i1 @compiler_2fcheck_2eisNullLit(ptr %v1, ptr %t95)
  store i1 %t97, ptr %l64
  br label %bb33
bb33:
  %t98 = load i1, ptr %l64, !tbaa !21
  br i1 %t98, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s5
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l65, !tbaa !29
  %t100 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t100, ptr %l66
  %t101 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eIsNullOfNull(ptr %s5)
  store %"compiler/diagmsg:Msg" %t101, ptr %l67
  br label %bb36
bb35:
  br label %bb39
bb36:
  %t102 = load ptr, ptr %l65, !tbaa !29
  %t103 = load %"compiler/source:Span", ptr %l66
  %t104 = load %"compiler/diagmsg:Msg", ptr %l67
  %t105 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t102, %"compiler/source:Span" %t103, %"compiler/diagmsg:Msg" %t104)
  store i64 %t105, ptr %l68
  br label %bb37
bb37:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load %"compiler/source:Span", ptr %l1
  %t108 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t112 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t106, %"compiler/source:Span" %t107, i32 %t108, i64 0)
  store ptr %t112, ptr %l72
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s5)
  %t113 = load ptr, ptr %l72, !tbaa !29
  store ptr %t113, ptr %rv
  br label %ret
bb39:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load ptr, ptr %l2, !tbaa !29
  %t117 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t121 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v3, ptr %t114, ptr %t115, i32 %t117)
  store ptr %t121, ptr %l77
  br label %bb40
bb40:
  %t122 = load ptr, ptr %l77, !tbaa !29
  store ptr %t122, ptr %l7, !tbaa !29
  %t123 = load ptr, ptr %l7, !tbaa !29
  %t126 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t123)
  store i32 %t126, ptr %l80
  br label %bb41
bb41:
  %t127 = load i32, ptr %l80, !tbaa !23
  store i32 %t127, ptr %l8, !tbaa !23
  %t128 = load i32, ptr %l8, !tbaa !23
  %t129 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t132 = icmp eq i32 %t128, %t129
  br i1 %t132, label %bb42, label %bb43
bb42:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load %"compiler/source:Span", ptr %l1
  %t138 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t134, %"compiler/source:Span" %t135)
  store ptr %t138, ptr %l86
  br label %bb44
bb43:
  br label %bb45
bb44:
  %t139 = load ptr, ptr %l86, !tbaa !29
  store ptr %t139, ptr %rv
  br label %ret
bb45:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/check:Checker", ptr %t140, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t145 = getelementptr %"compiler/generic:Program", ptr %t143, i32 0, i32 2
  %t146 = load i32, ptr %l8, !tbaa !23
  %t149 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %t145, i32 %t146)
  store i1 %t149, ptr %l91
  br label %bb46
bb46:
  %t150 = load i1, ptr %l91, !tbaa !21
  br i1 %t150, label %bb47, label %bb48
bb47:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load ptr, ptr %l2, !tbaa !29
  %t153 = load ptr, ptr %l7, !tbaa !29
  %t157 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrNonNull(ptr %v0, ptr %v1, ptr %v3, ptr %t151, ptr %t152, ptr %t153)
  store i1 %t157, ptr %l95
  br label %bb49
bb48:
  br label %bb67
bb49:
  %t158 = load i1, ptr %l95, !tbaa !21
  br i1 %t158, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s8
  %t159 = load ptr, ptr %l0, !tbaa !29
  store ptr %t159, ptr %l96, !tbaa !29
  %t160 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t160, ptr %l97
  %t161 = load ptr, ptr %l0, !tbaa !29
  store ptr %t161, ptr %l98, !tbaa !29
  %t162 = load ptr, ptr %l2, !tbaa !29
  %t164 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t162)
  store %"compiler/source:Span" %t164, ptr %l100
  br label %bb52
bb51:
  br label %bb60
bb52:
  %t165 = load ptr, ptr %l98, !tbaa !29
  %t166 = load %"compiler/source:Span", ptr %l100
  %t167 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %s8, ptr %t165, %"compiler/source:Span" %t166)
  store { i64, ptr } %t167, ptr %l101
  br label %bb53
bb53:
  %t168 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t169 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t170 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t170, 1
  %t172 = extractvalue { i64, ptr } %t170, 0
  %t173 = add i64 %t169, %t172
  %t174 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t175 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t176 = add i64 %t173, %t175
  %t177 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t176)
  call void @olang_textcopy(ptr %t177, ptr %t168, i64 %t169)
  %t178 = getelementptr i8, ptr %t177, i64 %t169
  call void @olang_textcopy(ptr %t178, ptr %t171, i64 %t172)
  %t179 = getelementptr i8, ptr %t178, i64 %t172
  call void @olang_textcopy(ptr %t179, ptr %t174, i64 %t175)
  %t180 = insertvalue { i64, ptr } undef, i64 %t176, 0
  %t181 = insertvalue { i64, ptr } %t180, ptr %t177, 1
  %t183 = extractvalue { i64, ptr } %t181, 0
  %t184 = extractvalue { i64, ptr } %t181, 1
  %t185 = mul i64 %t183, 1
  %t186 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t185)
  call void @llvm.memcpy.p0.p0.i64(ptr %t186, ptr %t184, i64 %t185, i1 false)
  %t187 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t186, 1
  %t190 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrNeverNull(ptr %s8, ptr %s8, { i64, ptr } %t188)
  store %"compiler/diagmsg:Msg" %t190, ptr %l104
  br label %bb54
bb54:
  %t191 = load ptr, ptr %l96, !tbaa !29
  %t192 = load %"compiler/source:Span", ptr %l97
  %t193 = load %"compiler/diagmsg:Msg", ptr %l104
  %t194 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t191, %"compiler/source:Span" %t192, %"compiler/diagmsg:Msg" %t193)
  store i64 %t194, ptr %l105
  br label %bb55
bb55:
  %t195 = load ptr, ptr %l0, !tbaa !29
  store ptr %t195, ptr %l106, !tbaa !29
  %t196 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t196, ptr %l107
  %t197 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t197, ptr %l108, !tbaa !23
  %t198 = load i1, ptr %l4, !tbaa !21
  br i1 %t198, label %bb56, label %bb57
bb56:
  store i64 1, ptr %l110, !tbaa !24
  br label %bb58
bb57:
  store i64 0, ptr %l110, !tbaa !24
  br label %bb58
bb58:
  %t200 = load ptr, ptr %l106, !tbaa !29
  %t201 = load %"compiler/source:Span", ptr %l107
  %t202 = load i32, ptr %l108, !tbaa !23
  %t203 = load i64, ptr %l110, !tbaa !24
  %t204 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t200, %"compiler/source:Span" %t201, i32 %t202, i64 %t203)
  store ptr %t204, ptr %l111
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s8)
  %t205 = load ptr, ptr %l111, !tbaa !29
  store ptr %t205, ptr %rv
  br label %ret
bb60:
  %t206 = load ptr, ptr %l0, !tbaa !29
  store ptr %t206, ptr %l112, !tbaa !29
  %t207 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t207, ptr %l113
  %t208 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t208, ptr %l114, !tbaa !23
  store i32 13, ptr %l115
  %t209 = load ptr, ptr %l7, !tbaa !29
  store ptr %t209, ptr %l116, !tbaa !29
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t211 = load %"compiler/source:Span", ptr %l1
  %t212 = load i32, ptr %l8, !tbaa !23
  %t216 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t210, %"compiler/source:Span" %t211, i32 %t212, i64 0)
  store ptr %t216, ptr %l120
  br label %bb61
bb61:
  %t217 = load ptr, ptr %l120, !tbaa !29
  %t218 = load ptr, ptr %l112, !tbaa !29
  %t219 = load %"compiler/source:Span", ptr %l113
  %t220 = load i32, ptr %l114, !tbaa !23
  %t221 = load i32, ptr %l115, !range !{i32 0, i32 49}
  %t222 = load ptr, ptr %l116, !tbaa !29
  %t224 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v3, ptr %v0, ptr %v3, ptr %t218, %"compiler/source:Span" %t219, i32 %t220, i32 %t221, ptr %t222, ptr %t217)
  store ptr %t224, ptr %l122
  br label %bb62
bb62:
  %t225 = load ptr, ptr %l122, !tbaa !29
  store ptr %t225, ptr %l9, !tbaa !29
  %t226 = load i1, ptr %l4, !tbaa !21
  br i1 %t226, label %bb63, label %bb64
bb63:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load %"compiler/source:Span", ptr %l1
  %t230 = load ptr, ptr %l9, !tbaa !29
  %t234 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v3, ptr %v3, ptr %t228, %"compiler/source:Span" %t229, ptr %t230)
  store ptr %t234, ptr %l128
  br label %bb65
bb64:
  %t235 = load ptr, ptr %l9, !tbaa !29
  store ptr %t235, ptr %l124, !tbaa !29
  br label %bb66
bb65:
  %t237 = load ptr, ptr %l128, !tbaa !29
  store ptr %t237, ptr %l124, !tbaa !29
  br label %bb66
bb66:
  %t238 = load ptr, ptr %l124, !tbaa !29
  store ptr %t238, ptr %rv
  br label %ret
bb67:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load i32, ptr %l8, !tbaa !23
  %t243 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t239, i32 %t240)
  store i1 %t243, ptr %l132
  br label %bb68
bb68:
  %t244 = load i1, ptr %l132, !tbaa !21
  %t245 = xor i1 %t244, true
  br i1 %t245, label %bb69, label %bb70
bb69:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t249 = getelementptr %"compiler/check:Checker", ptr %t247, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !29
  %t252 = getelementptr %"compiler/generic:Program", ptr %t250, i32 0, i32 2
  %t253 = load i32, ptr %l8, !tbaa !23
  %t256 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t252, i32 %t253)
  store i32 %t256, ptr %l139
  br label %bb71
bb70:
  store i1 false, ptr %l134, !tbaa !21
  br label %bb72
bb71:
  %t257 = load i32, ptr %l139, !range !{i32 0, i32 33}
  %t259 = trunc i64 21 to i32
  %t260 = icmp eq i32 %t257, %t259
  %t262 = xor i1 %t260, true
  store i1 %t262, ptr %l134, !tbaa !21
  br label %bb72
bb72:
  %t264 = load i1, ptr %l134, !tbaa !21
  br i1 %t264, label %bb73, label %bb74
bb73:
  store %olang.scope zeroinitializer, ptr %s10
  %t265 = load ptr, ptr %l0, !tbaa !29
  store ptr %t265, ptr %l143, !tbaa !29
  %t266 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t266, ptr %l144
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t268 = load i32, ptr %l8, !tbaa !23
  %t271 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s10, ptr %t267, i32 %t268)
  store { i64, ptr } %t271, ptr %l147
  br label %bb75
bb74:
  br label %bb79
bb75:
  %t272 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t273 = extractvalue { i64, ptr } %t272, 0
  %t274 = extractvalue { i64, ptr } %t272, 1
  %t275 = mul i64 %t273, 1
  %t276 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t275)
  call void @llvm.memcpy.p0.p0.i64(ptr %t276, ptr %t274, i64 %t275, i1 false)
  %t277 = insertvalue { i64, ptr } undef, i64 %t273, 0
  %t278 = insertvalue { i64, ptr } %t277, ptr %t276, 1
  %t280 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eIsNullOfValue(ptr %s10, ptr %s10, { i64, ptr } %t278)
  store %"compiler/diagmsg:Msg" %t280, ptr %l149
  br label %bb76
bb76:
  %t281 = load ptr, ptr %l143, !tbaa !29
  %t282 = load %"compiler/source:Span", ptr %l144
  %t283 = load %"compiler/diagmsg:Msg", ptr %l149
  %t284 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s10, ptr %t281, %"compiler/source:Span" %t282, %"compiler/diagmsg:Msg" %t283)
  store i64 %t284, ptr %l150
  br label %bb77
bb77:
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t286 = load %"compiler/source:Span", ptr %l1
  %t287 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t291 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t285, %"compiler/source:Span" %t286, i32 %t287, i64 0)
  store ptr %t291, ptr %l154
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s10)
  %t292 = load ptr, ptr %l154, !tbaa !29
  store ptr %t292, ptr %rv
  br label %ret
bb79:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = getelementptr %"compiler/check:Checker", ptr %t293, i32 0, i32 1
  %t296 = load ptr, ptr %t295, !tbaa !29
  %t298 = getelementptr %"compiler/generic:Program", ptr %t296, i32 0, i32 2
  %t299 = load i32, ptr %l8, !tbaa !23
  %t302 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArrayRef(ptr %v0, ptr %t298, i32 %t299)
  store i1 %t302, ptr %l159
  br label %bb80
bb80:
  %t303 = load i1, ptr %l159, !tbaa !21
  br i1 %t303, label %bb81, label %bb82
bb81:
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t306 = getelementptr %"compiler/check:Checker", ptr %t304, i32 0, i32 1
  %t307 = load ptr, ptr %t306, !tbaa !29
  %t309 = getelementptr %"compiler/generic:Program", ptr %t307, i32 0, i32 2
  %t310 = load i32, ptr %l8, !tbaa !23
  %t313 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t309, i32 %t310)
  store i1 %t313, ptr %l165
  br label %bb83
bb82:
  store i1 false, ptr %l160, !tbaa !21
  br label %bb84
bb83:
  %t314 = load i1, ptr %l165, !tbaa !21
  %t315 = xor i1 %t314, true
  store i1 %t315, ptr %l160, !tbaa !21
  br label %bb84
bb84:
  %t317 = load i1, ptr %l160, !tbaa !21
  br i1 %t317, label %bb85, label %bb86
bb85:
  store %olang.scope zeroinitializer, ptr %s11
  %t318 = load ptr, ptr %l0, !tbaa !29
  store ptr %t318, ptr %l167, !tbaa !29
  %t319 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t319, ptr %l168
  %t320 = load ptr, ptr %l0, !tbaa !29
  store ptr %t320, ptr %l169, !tbaa !29
  %t321 = load ptr, ptr %l2, !tbaa !29
  %t323 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t321)
  store %"compiler/source:Span" %t323, ptr %l171
  br label %bb87
bb86:
  br label %bb98
bb87:
  %t324 = load ptr, ptr %l169, !tbaa !29
  %t325 = load %"compiler/source:Span", ptr %l171
  %t326 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t324, %"compiler/source:Span" %t325)
  store { i64, ptr } %t326, ptr %l172
  br label %bb88
bb88:
  %t327 = load i1, ptr %l4, !tbaa !21
  br i1 %t327, label %bb89, label %bb90
bb89:
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l174, !tbaa !27
  br label %bb91
bb90:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l174, !tbaa !27
  br label %bb91
bb91:
  %t329 = load { i64, ptr }, ptr %l172, !tbaa !27
  %t330 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t331 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArrayIsNull(ptr %v0, ptr %s11, ptr %s11, { i64, ptr } %t329, { i64, ptr } %t330)
  store %"compiler/diagmsg:Msg" %t331, ptr %l175
  br label %bb92
bb92:
  %t332 = load ptr, ptr %l167, !tbaa !29
  %t333 = load %"compiler/source:Span", ptr %l168
  %t334 = load %"compiler/diagmsg:Msg", ptr %l175
  %t335 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s11, ptr %t332, %"compiler/source:Span" %t333, %"compiler/diagmsg:Msg" %t334)
  store i64 %t335, ptr %l176
  br label %bb93
bb93:
  %t336 = load ptr, ptr %l0, !tbaa !29
  store ptr %t336, ptr %l177, !tbaa !29
  %t337 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t337, ptr %l178
  %t338 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t338, ptr %l179, !tbaa !23
  %t339 = load i1, ptr %l4, !tbaa !21
  br i1 %t339, label %bb94, label %bb95
bb94:
  store i64 1, ptr %l181, !tbaa !24
  br label %bb96
bb95:
  store i64 0, ptr %l181, !tbaa !24
  br label %bb96
bb96:
  %t341 = load ptr, ptr %l177, !tbaa !29
  %t342 = load %"compiler/source:Span", ptr %l178
  %t343 = load i32, ptr %l179, !tbaa !23
  %t344 = load i64, ptr %l181, !tbaa !24
  %t345 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t341, %"compiler/source:Span" %t342, i32 %t343, i64 %t344)
  store ptr %t345, ptr %l182
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s11)
  %t346 = load ptr, ptr %l182, !tbaa !29
  store ptr %t346, ptr %rv
  br label %ret
bb98:
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t348 = load i32, ptr %l8, !tbaa !23
  %t351 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneverNull(ptr %v0, ptr %t347, i32 %t348)
  store i1 %t351, ptr %l185
  br label %bb99
bb99:
  %t352 = load i1, ptr %l185, !tbaa !21
  br i1 %t352, label %bb100, label %bb101
bb100:
  store %olang.scope zeroinitializer, ptr %s12
  %t353 = load ptr, ptr %l0, !tbaa !29
  store ptr %t353, ptr %l186, !tbaa !29
  %t354 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t354, ptr %l187
  %t355 = load ptr, ptr %l0, !tbaa !29
  store ptr %t355, ptr %l188, !tbaa !29
  %t356 = load ptr, ptr %l2, !tbaa !29
  %t358 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t356)
  store %"compiler/source:Span" %t358, ptr %l190
  br label %bb102
bb101:
  br label %bb125
bb102:
  %t359 = load ptr, ptr %l188, !tbaa !29
  %t360 = load %"compiler/source:Span", ptr %l190
  %t361 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t359, %"compiler/source:Span" %t360)
  store { i64, ptr } %t361, ptr %l191
  br label %bb103
bb103:
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t363 = load i32, ptr %l8, !tbaa !23
  %t366 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s12, ptr %t362, i32 %t363)
  store { i64, ptr } %t366, ptr %l194
  br label %bb104
bb104:
  %t367 = load { i64, ptr }, ptr %l194, !tbaa !27
  %t368 = extractvalue { i64, ptr } %t367, 0
  %t369 = extractvalue { i64, ptr } %t367, 1
  %t370 = mul i64 %t368, 1
  %t371 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t370)
  call void @llvm.memcpy.p0.p0.i64(ptr %t371, ptr %t369, i64 %t370, i1 false)
  %t372 = insertvalue { i64, ptr } undef, i64 %t368, 0
  %t373 = insertvalue { i64, ptr } %t372, ptr %t371, 1
  store { i64, ptr } %t373, ptr %l195, !tbaa !27
  %t374 = load i1, ptr %l4, !tbaa !21
  br i1 %t374, label %bb105, label %bb106
bb105:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l197, !tbaa !27
  br label %bb107
bb106:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d10, i32 0, i32 1) }, ptr %l197, !tbaa !27
  br label %bb107
bb107:
  %t376 = load { i64, ptr }, ptr %l191, !tbaa !27
  %t377 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t378 = load { i64, ptr }, ptr %l197, !tbaa !27
  %t379 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNeverNull(ptr %v0, ptr %s12, ptr %s12, ptr %s12, { i64, ptr } %t376, { i64, ptr } %t377, { i64, ptr } %t378)
  store %"compiler/diagmsg:Msg" %t379, ptr %l198
  br label %bb108
bb108:
  %t380 = load ptr, ptr %l186, !tbaa !29
  %t381 = load %"compiler/source:Span", ptr %l187
  %t382 = load %"compiler/diagmsg:Msg", ptr %l198
  %t383 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s12, ptr %t380, %"compiler/source:Span" %t381, %"compiler/diagmsg:Msg" %t382)
  store i64 %t383, ptr %l199
  br label %bb109
bb109:
  %t384 = load i64, ptr %l199, !tbaa !24
  store i64 %t384, ptr %l10, !tbaa !24
  %t385 = load ptr, ptr %l7, !tbaa !29
  %t387 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v3, ptr %v3, ptr %t385)
  store ptr %t387, ptr %l201
  br label %bb110
bb110:
  %t388 = load ptr, ptr %l201, !tbaa !29
  store ptr %t388, ptr %l11, !tbaa !29
  %t389 = load ptr, ptr %l11, !tbaa !29
  %t391 = icmp eq ptr %t389, null
  %t393 = xor i1 %t391, true
  br i1 %t393, label %bb111, label %bb112
bb111:
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t396 = load ptr, ptr %l11, !tbaa !29
  %t399 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceAt(ptr %v0, ptr %v3, ptr %t395, ptr %t396)
  store { i64, [3 x i64] } %t399, ptr %l208
  br label %bb113
bb112:
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t401 = load ptr, ptr %l7, !tbaa !29
  %t404 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalledAt(ptr %v0, ptr %v3, ptr %t400, ptr %t401)
  store { i64, [3 x i64] } %t404, ptr %l211
  br label %bb114
bb113:
  %t405 = load { i64, [3 x i64] }, ptr %l208
  store { i64, [3 x i64] } %t405, ptr %l205
  br label %bb115
bb114:
  %t406 = load { i64, [3 x i64] }, ptr %l211
  store { i64, [3 x i64] } %t406, ptr %l205
  br label %bb115
bb115:
  %t407 = load { i64, [3 x i64] }, ptr %l205
  store { i64, [3 x i64] } %t407, ptr %l12
  %t408 = load { i64, [3 x i64] }, ptr %l12
  %t410 = extractvalue { i64, [3 x i64] } %t408, 0
  %t411 = icmp eq i64 %t410, 0
  %t413 = xor i1 %t411, true
  br i1 %t413, label %bb116, label %bb117
bb116:
  store %olang.scope zeroinitializer, ptr %s13
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t417 = getelementptr %"compiler/check:Checker", ptr %t415, i32 0, i32 1
  %t418 = load ptr, ptr %t417, !tbaa !29
  %t420 = getelementptr %"compiler/generic:Program", ptr %t418, i32 0, i32 0
  %t421 = load ptr, ptr %t420, !tbaa !29
  %t423 = getelementptr %"compiler/load:Loader", ptr %t421, i32 0, i32 4
  %t424 = load ptr, ptr %t423, !tbaa !29
  store ptr %t424, ptr %l218, !tbaa !29
  %t425 = load i64, ptr %l10, !tbaa !24
  store i64 %t425, ptr %l219, !tbaa !24
  %t426 = load { i64, [3 x i64] }, ptr %l12
  store { i64, [3 x i64] } %t426, ptr %l220
  %t427 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteNullableDecl(ptr %s13)
  store %"compiler/diagmsg:Msg" %t427, ptr %l221
  br label %bb118
bb117:
  br label %bb120
bb118:
  %t428 = load ptr, ptr %l218, !tbaa !29
  %t429 = load i64, ptr %l219, !tbaa !24
  %t430 = load { i64, [3 x i64] }, ptr %l220
  %t431 = load %"compiler/diagmsg:Msg", ptr %l221
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s13, ptr %t428, i64 %t429, { i64, [3 x i64] } %t430, %"compiler/diagmsg:Msg" %t431)
  br label %bb119
bb119:
  call void @__olang_scope_close(ptr %s13)
  br label %bb120
bb120:
  %t432 = load ptr, ptr %l0, !tbaa !29
  store ptr %t432, ptr %l222, !tbaa !29
  %t433 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t433, ptr %l223
  %t434 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t434, ptr %l224, !tbaa !23
  %t435 = load i1, ptr %l4, !tbaa !21
  br i1 %t435, label %bb121, label %bb122
bb121:
  store i64 1, ptr %l226, !tbaa !24
  br label %bb123
bb122:
  store i64 0, ptr %l226, !tbaa !24
  br label %bb123
bb123:
  %t437 = load ptr, ptr %l222, !tbaa !29
  %t438 = load %"compiler/source:Span", ptr %l223
  %t439 = load i32, ptr %l224, !tbaa !23
  %t440 = load i64, ptr %l226, !tbaa !24
  %t441 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t437, %"compiler/source:Span" %t438, i32 %t439, i64 %t440)
  store ptr %t441, ptr %l227
  br label %bb124
bb124:
  call void @__olang_scope_close(ptr %s12)
  %t442 = load ptr, ptr %l227, !tbaa !29
  store ptr %t442, ptr %rv
  br label %ret
bb125:
  %t443 = load ptr, ptr %l0, !tbaa !29
  store ptr %t443, ptr %l228, !tbaa !29
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t445 = load ptr, ptr %l3, !tbaa !29
  %t447 = load i32, ptr %l8, !tbaa !23
  %t451 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %v0, ptr %t444, ptr %t445, i32 %t447)
  store ptr %t451, ptr %l233
  br label %bb126
bb126:
  %t452 = load i32, ptr %l8, !tbaa !23
  store i32 %t452, ptr %l234, !tbaa !23
  %t453 = load ptr, ptr %l3, !tbaa !29
  %t455 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t453)
  store %"compiler/source:Span" %t455, ptr %l236
  br label %bb127
bb127:
  %t456 = load ptr, ptr %l228, !tbaa !29
  %t457 = load ptr, ptr %l233, !tbaa !29
  %t458 = load i32, ptr %l234, !tbaa !23
  %t459 = load %"compiler/source:Span", ptr %l236
  %t460 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v0, ptr %v3, ptr %t456, ptr %t457, i32 %t458, %"compiler/source:Span" %t459)
  store ptr %t460, ptr %l237
  br label %bb128
bb128:
  %t461 = load ptr, ptr %l237, !tbaa !29
  %t462 = load ptr, ptr %l0, !tbaa !29
  %t463 = load %"compiler/source:Span", ptr %l1
  %t464 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t465 = load ptr, ptr %l7, !tbaa !29
  %t474 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v3, ptr %v3, ptr %v3, ptr %t462, %"compiler/source:Span" %t463, i32 %t464, i32 19, ptr %t465, ptr %t461)
  store ptr %t474, ptr %l245
  br label %bb129
bb129:
  %t475 = load ptr, ptr %l245, !tbaa !29
  store ptr %t475, ptr %l14, !tbaa !29
  %t476 = load i1, ptr %l4, !tbaa !21
  br i1 %t476, label %bb130, label %bb131
bb130:
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t479 = load %"compiler/source:Span", ptr %l1
  %t480 = load ptr, ptr %l14, !tbaa !29
  %t484 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v3, ptr %v3, ptr %t478, %"compiler/source:Span" %t479, ptr %t480)
  store ptr %t484, ptr %l251
  br label %bb132
bb131:
  %t485 = load ptr, ptr %l14, !tbaa !29
  store ptr %t485, ptr %l247, !tbaa !29
  br label %bb133
bb132:
  %t487 = load ptr, ptr %l251, !tbaa !29
  store ptr %t487, ptr %l247, !tbaa !29
  br label %bb133
bb133:
  %t488 = load ptr, ptr %l247, !tbaa !29
  store ptr %t488, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einPlaceBodies(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca ptr
  %l15 = alloca i1
  %l30 = alloca i64
  %l33 = alloca i64
  %l53 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Call", ptr %t5, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t10 = load ptr, ptr %l3, !tbaa !29
  store ptr %t10, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t11 = load ptr, ptr %l14, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = load ptr, ptr %l14, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 5}
  %t17 = icmp eq i64 %t15, 0
  store i1 %t17, ptr %l15, !tbaa !21
  br label %bb3
bb3:
  %t18 = load i1, ptr %l15, !tbaa !21
  br i1 %t18, label %bb4, label %bb5
bb4:
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t21 = getelementptr { i64, [3 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { i32 }, ptr %t21, i32 0, i32 0
  %t23 = load i32, ptr %t22
  store i32 %t23, ptr %l4, !tbaa !23
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t25 = load ptr, ptr %lp2
  %t26 = load i32, ptr %l4, !tbaa !23
  %t28 = sext i32 %t26 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t25, i64 %t28)
  br label %bb7
bb7:
  br label %bb13
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t31 = load ptr, ptr %lp2
  %t32 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t31
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %rv
  br label %ret
bb12:
  call void @__olang_check_failed(ptr @olang_loc_8803ccf5e870aa5b_cb8fe22003fe469f)
  unreachable
bb13:
  store i64 1, ptr %l5, !tbaa !24
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Call", ptr %t34, i32 0, i32 1
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  store i64 %t39, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t41 = load i64, ptr %l6, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = icmp sgt i64 %t41, %t42
  br i1 %t45, label %bb14, label %bb15
bb14:
  %t47 = load i64, ptr %l7, !tbaa !24
  %t49 = icmp sgt i64 %t47, 0
  br i1 %t49, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb19
bb16:
  %t51 = load i64, ptr %l6, !tbaa !24
  %t52 = load i64, ptr %l5, !tbaa !24
  %t55 = sub i64 %t51, %t52
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = add i64 %t55, %t56
  %t61 = sub i64 %t59, 1
  %t62 = load i64, ptr %l7, !tbaa !24
  %t65 = sdiv i64 %t61, %t62
  store i64 %t65, ptr %l33, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb18
bb18:
  %t67 = load i64, ptr %l33, !tbaa !24
  store i64 %t67, ptr %l30, !tbaa !24
  br label %bb19
bb19:
  %t68 = load i64, ptr %l30, !tbaa !24
  store i64 %t68, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb20
bb20:
  %t69 = load i64, ptr %l9, !tbaa !24
  %t70 = load i64, ptr %l8, !tbaa !24
  %t73 = icmp slt i64 %t69, %t70
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb21, label %bb22
bb21:
  br label %bb26
bb22:
  br label %bb23
bb23:
  %t77 = load i64, ptr %l5, !tbaa !24
  %t78 = load i64, ptr %l9, !tbaa !24
  %t79 = load i64, ptr %l7, !tbaa !24
  %t82 = mul i64 %t78, %t79
  %t85 = add i64 %t77, %t82
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Call", ptr %t88, i32 0, i32 1
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  store { i64, ptr } %t91, ptr %l53, !tbaa !27
  %t94 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr ptr, ptr %t95, i64 %t85
  %t97 = load ptr, ptr %t96, !tbaa !39
  %t98 = load ptr, ptr %lp2
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBodies(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %t97, ptr %t98)
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t102 = load i64, ptr %l9, !tbaa !24
  %t104 = add i64 %t102, 1
  store i64 %t104, ptr %l9, !tbaa !24
  br label %bb20
bb26:
  %t106 = load ptr, ptr %lp2
  %t107 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t106
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t107, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCase(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l15 = alloca i32
  %l17 = alloca ptr
  %l19 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t2, ptr %l5
  %t3 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t3, ptr %l6, !tbaa !23
  store i32 23, ptr %l7
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t5 = load %"compiler/source:Span", ptr %l1
  %t10 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v1, ptr %t4, %"compiler/source:Span" %t5, ptr %a2)
  store ptr %t10, ptr %l11
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l12, !tbaa !29
  %t12 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t12, ptr %l13
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t13)
  store i32 %t15, ptr %l15
  br label %bb2
bb2:
  %t17 = load ptr, ptr %l12, !tbaa !29
  %t18 = load %"compiler/source:Span", ptr %l13
  %t19 = load i32, ptr %l15, !tbaa !23
  %t21 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t17, %"compiler/source:Span" %t18, i32 %t19, i64 %a3)
  store ptr %t21, ptr %l17
  br label %bb3
bb3:
  %t22 = load ptr, ptr %l17, !tbaa !29
  %t23 = load ptr, ptr %l4, !tbaa !29
  %t24 = load %"compiler/source:Span", ptr %l5
  %t25 = load i32, ptr %l6, !tbaa !23
  %t26 = load i32, ptr %l7, !range !{i32 0, i32 49}
  %t27 = load ptr, ptr %l11, !tbaa !29
  %t29 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v1, ptr %v0, ptr %v2, ptr %t23, %"compiler/source:Span" %t24, i32 %t25, i32 %t26, ptr %t27, ptr %t22)
  store ptr %t29, ptr %l19
  br label %bb4
bb4:
  %t30 = load ptr, ptr %l19, !tbaa !29
  store ptr %t30, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisWildType(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i1
  %l15 = alloca i1
  %l19 = alloca i1
  %l21 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i1
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t12, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t18, i32 0, i32 2
  %t20 = load { i64, ptr }, ptr %t19
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  br label %bb14
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t26 = icmp eq i64 %t24, 1
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t28 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t32 = icmp eq i64 %t30, 0
  store i1 %t32, ptr %l15, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb8
bb8:
  %t34 = load i1, ptr %l15, !tbaa !21
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t36 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t36, ptr %l21, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr i32, ptr %t38, i64 0
  %t40 = load i32, ptr %t39, !tbaa !33
  %t43 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %a0, i32 %t40)
  store { i64, ptr } %t43, ptr %l23
  br label %bb11
bb10:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb13
bb11:
  %t44 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t45 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t44, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i1 %t45, ptr %l24
  br label %bb12
bb12:
  %t46 = load i1, ptr %l24, !tbaa !21
  store i1 %t46, ptr %l19, !tbaa !21
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s1)
  %t47 = load i1, ptr %l19, !tbaa !21
  store i1 %t47, ptr %rv
  br label %ret
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 false, ptr %rv
  br label %ret
bb18:
  call void @__olang_check_failed(ptr @olang_loc_dabacd8646f437fb_89d6d0c21504246f)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneAdd(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:laneNode" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l7 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 39
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2ePush_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v1, ptr %t3, %"compiler/check:laneNode" %a1)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 39
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eLen_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l7
  br label %bb2
bb2:
  %t12 = load i64, ptr %l7, !tbaa !24
  %t13 = sub i64 %t12, 1
  store i64 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, i64, i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLoopOpen(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, i64, i64 }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l13 = alloca i32
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca %"compiler/source:Span"
  %l19 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca %"compiler/source:Span"
  %l23 = alloca i32
  %l25 = alloca ptr
  %l30 = alloca i64
  %l34 = alloca { i64, i64, i64 }
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca %"compiler/source:Span"
  %l41 = alloca ptr
  %l42 = alloca %"compiler/source:Span"
  %l43 = alloca i32
  %l44 = alloca i32
  %l48 = alloca ptr
  %l51 = alloca ptr
  %l53 = alloca ptr
  %rv = alloca { i64, i64, i64, i64, i64 }
  %t28 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  %t2 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t2, ptr %l11
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t3)
  store i32 %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l10, !tbaa !29
  %t7 = load %"compiler/source:Span", ptr %l11
  %t8 = load i32, ptr %l13, !tbaa !23
  %t9 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t6, %"compiler/source:Span" %t7, i32 %t8)
  store i64 %t9, ptr %l14
  br label %bb2
bb2:
  %t10 = load i64, ptr %l14, !tbaa !24
  store i64 %t10, ptr %l4, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l15, !tbaa !29
  %t12 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t12, ptr %l16
  %t13 = load i64, ptr %l4, !tbaa !24
  %t15 = trunc i64 %t13 to i32
  store i32 %t15, ptr %l19, !tbaa !23
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l20, !tbaa !29
  %t18 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t18, ptr %l21
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t19)
  store i32 %t21, ptr %l23
  br label %bb3
bb3:
  %t23 = load ptr, ptr %l20, !tbaa !29
  %t24 = load %"compiler/source:Span", ptr %l21
  %t25 = load i32, ptr %l23, !tbaa !23
  %t27 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t23, %"compiler/source:Span" %t24, i32 %t25, i64 %a3)
  store ptr %t27, ptr %l25
  br label %bb4
bb4:
  store { i64, [3 x i64] } zeroinitializer, ptr %t28
  %t29 = getelementptr { i64, [3 x i64] }, ptr %t28, i32 0, i32 0
  store i64 0, ptr %t29
  %t30 = load %"compiler/source:Span", ptr %l16
  %t31 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t30, 0
  %t32 = load i32, ptr %l19, !tbaa !23
  %t33 = insertvalue { %"compiler/source:Span", i32, ptr } %t31, i32 %t32, 1
  %t34 = load ptr, ptr %l25, !tbaa !29
  %t35 = insertvalue { %"compiler/source:Span", i32, ptr } %t33, ptr %t34, 2
  %t36 = getelementptr { i64, [3 x i64] }, ptr %t28, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t35, ptr %t36
  %t37 = load { i64, [3 x i64] }, ptr %t28
  %t39 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t37, ptr %t39
  %t40 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t40, ptr %t39)
  br label %bb5
bb5:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t42, i32 0, i32 37
  %t46 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t44)
  store i64 %t46, ptr %l30
  br label %bb6
bb6:
  %t47 = load i64, ptr %l30, !tbaa !24
  store i64 %t47, ptr %l5, !tbaa !24
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load %"compiler/source:Span", ptr %l1
  %t53 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t48, i32 2, %"compiler/source:Span" %t49)
  store { i64, i64, i64 } %t53, ptr %l34
  br label %bb7
bb7:
  %t54 = load { i64, i64, i64 }, ptr %l34
  store { i64, i64, i64 } %t54, ptr %l6
  %t55 = getelementptr { i64, i64, i64 }, ptr %l6, i32 0, i32 0
  %t56 = load i64, ptr %t55, !tbaa !24
  store i64 %t56, ptr %l7, !tbaa !24
  %t58 = getelementptr { i64, i64, i64 }, ptr %l6, i32 0, i32 1
  %t59 = load i64, ptr %t58, !tbaa !24
  store i64 %t59, ptr %l8, !tbaa !24
  %t61 = getelementptr { i64, i64, i64 }, ptr %l6, i32 0, i32 2
  %t62 = load i64, ptr %t61, !tbaa !24
  store i64 %t62, ptr %l9, !tbaa !24
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l38, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l39, !tbaa !29
  %t66 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t66, ptr %l40
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l41, !tbaa !29
  %t68 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t68, ptr %l42
  %t69 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t69, ptr %l43, !tbaa !23
  store i32 15, ptr %l44
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load %"compiler/source:Span", ptr %l1
  %t72 = load i64, ptr %l4, !tbaa !24
  %t76 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t70, %"compiler/source:Span" %t71, i64 %t72)
  store ptr %t76, ptr %l48
  br label %bb8
bb8:
  %t79 = load ptr, ptr %l41, !tbaa !29
  %t80 = load %"compiler/source:Span", ptr %l42
  %t81 = load i32, ptr %l43, !tbaa !23
  %t82 = load i32, ptr %l44, !range !{i32 0, i32 49}
  %t83 = load ptr, ptr %l48, !tbaa !29
  %t85 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v1, ptr %v0, ptr %t79, %"compiler/source:Span" %t80, i32 %t81, i32 %t82, ptr %t83, ptr %a2)
  store ptr %t85, ptr %l51
  br label %bb9
bb9:
  %t86 = load i64, ptr %l7, !tbaa !24
  %t87 = load ptr, ptr %l39, !tbaa !29
  %t88 = load %"compiler/source:Span", ptr %l40
  %t89 = load ptr, ptr %l51, !tbaa !29
  %t91 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebreakUnless(ptr %v0, ptr %v0, ptr %v0, ptr %t87, %"compiler/source:Span" %t88, ptr %t89, i64 %t86)
  store ptr %t91, ptr %l53
  br label %bb10
bb10:
  %t92 = load ptr, ptr %l38, !tbaa !29
  %t93 = load ptr, ptr %l53, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t92, ptr %t93)
  br label %bb11
bb11:
  %t94 = load i64, ptr %l4, !tbaa !24
  %t95 = load i64, ptr %l7, !tbaa !24
  %t96 = load i64, ptr %l8, !tbaa !24
  %t97 = load i64, ptr %l9, !tbaa !24
  %t98 = load i64, ptr %l5, !tbaa !24
  %t100 = insertvalue { i64, i64, i64, i64, i64 } undef, i64 %t94, 0
  %t102 = insertvalue { i64, i64, i64, i64, i64 } %t100, i64 %t95, 1
  %t104 = insertvalue { i64, i64, i64, i64, i64 } %t102, i64 %t96, 2
  %t106 = insertvalue { i64, i64, i64, i64, i64 } %t104, i64 %t97, 3
  %t108 = insertvalue { i64, i64, i64, i64, i64 } %t106, i64 %t98, 4
  store { i64, i64, i64, i64, i64 } %t108, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64, i64, i64, i64 }, ptr %rv
  ret { i64, i64, i64, i64, i64 } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneUnary(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca [1 x i64]
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i32
  %l15 = alloca %"compiler/check:laneNode"
  %l17 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca %"compiler/source:Span"
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca i32
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca %"compiler/source:Span"
  %l27 = alloca i64
  %l28 = alloca i32
  %l32 = alloca %"compiler/check:laneNode"
  %l33 = alloca i64
  %l38 = alloca i32
  %l39 = alloca %"compiler/check:laneNode"
  %l40 = alloca i64
  %l41 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %v1, ptr %t1, ptr %a3)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l10, !tbaa !29
  %t8 = load i32, ptr %l2, !range !{i32 0, i32 98}
  store i32 %t8, ptr %l11
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 39
  %t12 = load i64, ptr %l4, !tbaa !24
  %t15 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s0, ptr %t11, i64 %t12)
  store %"compiler/check:laneNode" %t15, ptr %l15
  br label %bb2
bb2:
  %t16 = getelementptr %"compiler/check:laneNode", ptr %l15, i32 0, i32 8
  %t17 = load i32, ptr %t16, !tbaa !23
  %t18 = load ptr, ptr %l10, !tbaa !29
  %t19 = load i32, ptr %l11, !range !{i32 0, i32 98}
  %t21 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneUnType(ptr %v0, ptr %t18, i32 %t19, i32 %t17)
  store i32 %t21, ptr %l17
  br label %bb3
bb3:
  %t22 = load i32, ptr %l17, !tbaa !23
  store i32 %t22, ptr %l5, !tbaa !23
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = insertvalue [1 x i64] undef, i64 %t23, 0
  store [1 x i64] %t25, ptr %l6
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l20, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t28, ptr %l21
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l22, !tbaa !29
  %t30 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneUn, !tbaa !24
  store i64 %t30, ptr %l23, !tbaa !24
  %t31 = load i32, ptr %l2, !range !{i32 0, i32 98}
  store i32 %t31, ptr %l24
  %t32 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t32, ptr %l25
  %t33 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t33, ptr %l26
  %t34 = load i64, ptr %l4, !tbaa !24
  store i64 %t34, ptr %l27, !tbaa !24
  %t35 = load i32, ptr %l5, !tbaa !23
  store i32 %t35, ptr %l28, !tbaa !23
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 39
  %t39 = load i64, ptr %l4, !tbaa !24
  %t42 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s0, ptr %t38, i64 %t39)
  store %"compiler/check:laneNode" %t42, ptr %l32
  br label %bb4
bb4:
  %t43 = getelementptr %"compiler/check:laneNode", ptr %l32, i32 0, i32 9
  %t44 = load i64, ptr %t43, !tbaa !24
  store i64 %t44, ptr %l33, !tbaa !24
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = insertvalue { i64, ptr } undef, i64 1, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %l6, 1
  %t49 = load i32, ptr %l5, !tbaa !23
  %t53 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneDecl(ptr %v0, ptr %s0, ptr %t45, { i64, ptr } %t48, i32 %t49)
  store i32 %t53, ptr %l38
  br label %bb5
bb5:
  %t54 = load i64, ptr %l23, !tbaa !24
  %t55 = load i32, ptr %l24, !range !{i32 0, i32 98}
  %t56 = load %"compiler/source:Span", ptr %l25
  %t57 = load %"compiler/source:Span", ptr %l26
  %t58 = load i64, ptr %l27, !tbaa !24
  %t59 = load i32, ptr %l28, !tbaa !23
  %t60 = load i64, ptr %l33, !tbaa !24
  %t61 = load i32, ptr %l38, !tbaa !23
  %t62 = call %"compiler/check:laneNode" @compiler_2fcheck_3alaneNode_2ector(ptr %v0, ptr %v0, i64 %t54, i32 %t55, %"compiler/source:Span" %t56, %"compiler/source:Span" %t57, i64 %t58, i64 -1, i64 -1, ptr null, i32 %t59, i64 %t60, i32 %t61)
  store %"compiler/check:laneNode" %t62, ptr %l39
  br label %bb6
bb6:
  %t63 = load ptr, ptr %l22, !tbaa !29
  %t64 = load %"compiler/check:laneNode", ptr %l39
  %t65 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneAdd(ptr %v0, ptr %v0, ptr %t63, %"compiler/check:laneNode" %t64)
  store i64 %t65, ptr %l40
  br label %bb7
bb7:
  %t66 = load ptr, ptr %l20, !tbaa !29
  %t67 = load %"compiler/source:Span", ptr %l21
  %t68 = load i64, ptr %l40, !tbaa !24
  %t69 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneHold(ptr %v0, ptr %v2, ptr %t66, %"compiler/source:Span" %t67, i64 %t68)
  store ptr %t69, ptr %l41
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t70 = load ptr, ptr %l41, !tbaa !29
  store ptr %t70, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralLocalNote(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca %"compiler/typed:Local"
  %l5 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l6 = alloca %"compiler/source:Span"
  %l10 = alloca ptr
  %l14 = alloca %"compiler/typed:Local"
  %l16 = alloca ptr
  %l20 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l21 = alloca %"compiler/source:Span"
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca i32
  %l27 = alloca %"compiler/source:Span"
  %l33 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i64
  %l41 = alloca { i64, [3 x i64] }
  %l44 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l57 = alloca %"compiler/diagmsg:Msg"
  %l61 = alloca ptr
  %l62 = alloca i64
  %l65 = alloca { i64, [3 x i64] }
  %l68 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l84 = alloca %"compiler/diagmsg:Msg"
  %l88 = alloca ptr
  %l89 = alloca i64
  %l92 = alloca { i64, [3 x i64] }
  %l95 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l107 = alloca %"compiler/diagmsg:Msg"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t5)
  store ptr %t7, ptr %l10
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l10, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 7
  %t11 = load i64, ptr %l2, !tbaa !24
  %t14 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t10, i64 %t11)
  store %"compiler/typed:Local" %t14, ptr %l14
  br label %bb5
bb5:
  %t15 = load %"compiler/typed:Local", ptr %l14
  store %"compiler/typed:Local" %t15, ptr %l4
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t16)
  store ptr %t18, ptr %l16
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l16, !tbaa !29
  %t21 = getelementptr %"compiler/check:frame", ptr %t19, i32 0, i32 0
  %t22 = load i64, ptr %t21, !tbaa !24
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t22, i64 %t23)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t26, ptr %l20
  br label %bb7
bb7:
  %t27 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l20
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t27, ptr %l5
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 32
  %t31 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l5
  %t34 = call { i32, %"compiler/source:Span" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H7d5384a5030fc995e793b3fe1f57e776(ptr %v0, ptr %t30, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t31)
  %t35 = extractvalue { i32, %"compiler/source:Span" } %t34, 1
  %t36 = extractvalue { i32, %"compiler/source:Span" } %t34, 0
  store i32 %t36, ptr %l26
  %t37 = icmp ne i32 %t36, 0
  br i1 %t37, label %bb9, label %ok.38, !prof !99
ok.38:
  store %"compiler/source:Span" %t35, ptr %l25
  br label %bb8
bb8:
  %t39 = load %"compiler/source:Span", ptr %l25
  store %"compiler/source:Span" %t39, ptr %l21
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t40 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 -1, i32 -1)
  store %"compiler/source:Span" %t40, ptr %l27
  br label %bb11
bb11:
  %t41 = load %"compiler/source:Span", ptr %l27
  store %"compiler/source:Span" %t41, ptr %l21
  br label %bb12
bb12:
  %t42 = load %"compiler/source:Span", ptr %l21
  store %"compiler/source:Span" %t42, ptr %l6
  %t43 = getelementptr %"compiler/source:Span", ptr %l6, i32 0, i32 0
  %t44 = load i32, ptr %t43, !tbaa !23
  %t46 = icmp sge i32 %t44, 0
  br i1 %t46, label %bb13, label %bb14
bb13:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 33
  %t51 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l5
  %t54 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t50, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t51)
  store i1 %t54, ptr %l33
  br label %bb15
bb14:
  br label %bb34
bb15:
  %t55 = load i1, ptr %l33, !tbaa !21
  br i1 %t55, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/load:Loader", ptr %t62, i32 0, i32 4
  %t65 = load ptr, ptr %t64, !tbaa !29
  store ptr %t65, ptr %l37, !tbaa !29
  %t66 = load i64, ptr %l1, !tbaa !24
  store i64 %t66, ptr %l38, !tbaa !24
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load %"compiler/source:Span", ptr %l6
  %t71 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t67, %"compiler/source:Span" %t68)
  store { i64, [3 x i64] } %t71, ptr %l41
  br label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/check:Checker", ptr %t72, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = getelementptr %"compiler/generic:Program", ptr %t75, i32 0, i32 0
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = getelementptr %"compiler/load:Loader", ptr %t78, i32 0, i32 4
  %t81 = load ptr, ptr %t80, !tbaa !29
  store ptr %t81, ptr %l61, !tbaa !29
  %t82 = load i64, ptr %l1, !tbaa !24
  store i64 %t82, ptr %l62, !tbaa !24
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load %"compiler/source:Span", ptr %l6
  %t87 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t83, %"compiler/source:Span" %t84)
  store { i64, [3 x i64] } %t87, ptr %l65
  br label %bb25
bb18:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 0
  %t90 = load i32, ptr %t89, !tbaa !23
  %t93 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t88, i32 %t90)
  store { i64, ptr } %t93, ptr %l44
  br label %bb19
bb19:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 2
  %t96 = load i32, ptr %t95, !tbaa !23
  %t99 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t94, i32 %t96)
  store { i64, ptr } %t99, ptr %l47
  br label %bb20
bb20:
  %t100 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t102 = extractvalue { i64, ptr } %t100, 1
  %t103 = mul i64 %t101, 1
  %t104 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t103)
  call void @llvm.memcpy.p0.p0.i64(ptr %t104, ptr %t102, i64 %t103, i1 false)
  %t105 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  store { i64, ptr } %t106, ptr %l48, !tbaa !27
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i32, ptr %l3, !tbaa !23
  %t111 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t107, i32 %t108)
  store { i64, ptr } %t111, ptr %l51
  br label %bb21
bb21:
  %t112 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t112, 0
  %t114 = extractvalue { i64, ptr } %t112, 1
  %t115 = mul i64 %t113, 1
  %t116 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t115)
  call void @llvm.memcpy.p0.p0.i64(ptr %t116, ptr %t114, i64 %t115, i1 false)
  %t117 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t116, 1
  store { i64, ptr } %t118, ptr %l52, !tbaa !27
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load i32, ptr %l3, !tbaa !23
  %t123 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t119, i32 %t120)
  store { i64, ptr } %t123, ptr %l55
  br label %bb22
bb22:
  %t124 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t124, 0
  %t126 = extractvalue { i64, ptr } %t124, 1
  %t127 = mul i64 %t125, 1
  %t128 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t127)
  call void @llvm.memcpy.p0.p0.i64(ptr %t128, ptr %t126, i64 %t127, i1 false)
  %t129 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t128, 1
  %t131 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t132 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t135 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteLiteralRangeExpr(ptr %v0, ptr %s3, ptr %s3, ptr %s3, ptr %s3, { i64, ptr } %t131, { i64, ptr } %t132, { i64, ptr } %t133, { i64, ptr } %t130)
  store %"compiler/diagmsg:Msg" %t135, ptr %l57
  br label %bb23
bb23:
  %t136 = load ptr, ptr %l37, !tbaa !29
  %t137 = load i64, ptr %l38, !tbaa !24
  %t138 = load { i64, [3 x i64] }, ptr %l41
  %t139 = load %"compiler/diagmsg:Msg", ptr %l57
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s3, ptr %t136, i64 %t137, { i64, [3 x i64] } %t138, %"compiler/diagmsg:Msg" %t139)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s3)
  br label %bb33
bb25:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 0
  %t142 = load i32, ptr %t141, !tbaa !23
  %t145 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t140, i32 %t142)
  store { i64, ptr } %t145, ptr %l68
  br label %bb26
bb26:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 2
  %t148 = load i32, ptr %t147, !tbaa !23
  %t151 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s4, ptr %t146, i32 %t148)
  store { i64, ptr } %t151, ptr %l71
  br label %bb27
bb27:
  %t152 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t153 = extractvalue { i64, ptr } %t152, 0
  %t154 = extractvalue { i64, ptr } %t152, 1
  %t155 = mul i64 %t153, 1
  %t156 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t155)
  call void @llvm.memcpy.p0.p0.i64(ptr %t156, ptr %t154, i64 %t155, i1 false)
  %t157 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t156, 1
  store { i64, ptr } %t158, ptr %l72, !tbaa !27
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load i32, ptr %l3, !tbaa !23
  %t163 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s4, ptr %t159, i32 %t160)
  store { i64, ptr } %t163, ptr %l75
  br label %bb28
bb28:
  %t164 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t164, 0
  %t166 = extractvalue { i64, ptr } %t164, 1
  %t167 = mul i64 %t165, 1
  %t168 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t167)
  call void @llvm.memcpy.p0.p0.i64(ptr %t168, ptr %t166, i64 %t167, i1 false)
  %t169 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t168, 1
  store { i64, ptr } %t170, ptr %l76, !tbaa !27
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load %"compiler/source:Span", ptr %l6
  %t175 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t171, %"compiler/source:Span" %t172)
  store { i64, ptr } %t175, ptr %l79
  br label %bb29
bb29:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load i32, ptr %l3, !tbaa !23
  %t180 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s4, ptr %t176, i32 %t177)
  store { i64, ptr } %t180, ptr %l82
  br label %bb30
bb30:
  %t181 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t181, 0
  %t183 = extractvalue { i64, ptr } %t181, 1
  %t184 = mul i64 %t182, 1
  %t185 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t184)
  call void @llvm.memcpy.p0.p0.i64(ptr %t185, ptr %t183, i64 %t184, i1 false)
  %t186 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t185, 1
  %t188 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t189 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t190 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t191 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t193 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteLiteralRange(ptr %v0, ptr %s4, ptr %s4, ptr %v0, ptr %s4, ptr %s4, { i64, ptr } %t188, { i64, ptr } %t189, { i64, ptr } %t190, { i64, ptr } %t191, { i64, ptr } %t187)
  store %"compiler/diagmsg:Msg" %t193, ptr %l84
  br label %bb31
bb31:
  %t194 = load ptr, ptr %l61, !tbaa !29
  %t195 = load i64, ptr %l62, !tbaa !24
  %t196 = load { i64, [3 x i64] }, ptr %l65
  %t197 = load %"compiler/diagmsg:Msg", ptr %l84
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s4, ptr %t194, i64 %t195, { i64, [3 x i64] } %t196, %"compiler/diagmsg:Msg" %t197)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s4)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb34:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/check:Checker", ptr %t198, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !29
  %t203 = getelementptr %"compiler/generic:Program", ptr %t201, i32 0, i32 0
  %t204 = load ptr, ptr %t203, !tbaa !29
  %t206 = getelementptr %"compiler/load:Loader", ptr %t204, i32 0, i32 4
  %t207 = load ptr, ptr %t206, !tbaa !29
  store ptr %t207, ptr %l88, !tbaa !29
  %t208 = load i64, ptr %l1, !tbaa !24
  store i64 %t208, ptr %l89, !tbaa !24
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 1
  %t211 = load %"compiler/source:Span", ptr %t210
  %t214 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t209, %"compiler/source:Span" %t211)
  store { i64, [3 x i64] } %t214, ptr %l92
  br label %bb35
bb35:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 0
  %t217 = load i32, ptr %t216, !tbaa !23
  %t220 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t215, i32 %t217)
  store { i64, ptr } %t220, ptr %l95
  br label %bb36
bb36:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 2
  %t223 = load i32, ptr %t222, !tbaa !23
  %t226 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t221, i32 %t223)
  store { i64, ptr } %t226, ptr %l98
  br label %bb37
bb37:
  %t227 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t228 = extractvalue { i64, ptr } %t227, 0
  %t229 = extractvalue { i64, ptr } %t227, 1
  %t230 = mul i64 %t228, 1
  %t231 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t230)
  call void @llvm.memcpy.p0.p0.i64(ptr %t231, ptr %t229, i64 %t230, i1 false)
  %t232 = insertvalue { i64, ptr } undef, i64 %t228, 0
  %t233 = insertvalue { i64, ptr } %t232, ptr %t231, 1
  store { i64, ptr } %t233, ptr %l99, !tbaa !27
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 0
  %t236 = load i32, ptr %t235, !tbaa !23
  %t239 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t234, i32 %t236)
  store { i64, ptr } %t239, ptr %l102
  br label %bb38
bb38:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load i32, ptr %l3, !tbaa !23
  %t244 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t240, i32 %t241)
  store { i64, ptr } %t244, ptr %l105
  br label %bb39
bb39:
  %t245 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t246 = extractvalue { i64, ptr } %t245, 0
  %t247 = extractvalue { i64, ptr } %t245, 1
  %t248 = mul i64 %t246, 1
  %t249 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t248)
  call void @llvm.memcpy.p0.p0.i64(ptr %t249, ptr %t247, i64 %t248, i1 false)
  %t250 = insertvalue { i64, ptr } undef, i64 %t246, 0
  %t251 = insertvalue { i64, ptr } %t250, ptr %t249, 1
  %t252 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t253 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t254 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t256 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteLiteralLocal(ptr %v0, ptr %s0, ptr %v0, ptr %s0, ptr %s0, { i64, ptr } %t252, { i64, ptr } %t253, { i64, ptr } %t254, { i64, ptr } %t251)
  store %"compiler/diagmsg:Msg" %t256, ptr %l107
  br label %bb40
bb40:
  %t257 = load ptr, ptr %l88, !tbaa !29
  %t258 = load i64, ptr %l89, !tbaa !24
  %t259 = load { i64, [3 x i64] }, ptr %l92
  %t260 = load %"compiler/diagmsg:Msg", ptr %l107
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s0, ptr %t257, i64 %t258, { i64, [3 x i64] } %t259, %"compiler/diagmsg:Msg" %t260)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloopCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca %"compiler/generic:AnySlot"
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i64
  %l26 = alloca ptr
  %l29 = alloca i32
  %l32 = alloca i64
  %l33 = alloca ptr
  %l41 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca i32
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l59 = alloca ptr
  %l60 = alloca %"compiler/source:Span"
  %l61 = alloca %"compiler/source:Span"
  %l62 = alloca i32
  %l68 = alloca ptr
  %l70 = alloca ptr
  %l75 = alloca ptr
  %l77 = alloca ptr
  %l78 = alloca %"compiler/source:Span"
  %l79 = alloca %"compiler/source:Span"
  %l80 = alloca i64
  %l82 = alloca ptr
  %l85 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l90 = alloca ptr
  %l92 = alloca ptr
  %l100 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l114 = alloca i32
  %l117 = alloca ptr
  %l122 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l126 = alloca i64
  %l130 = alloca i64
  %l133 = alloca i64
  %l153 = alloca ptr
  %l157 = alloca i32
  %l158 = alloca i32
  %l161 = alloca ptr
  %l165 = alloca i32
  %l172 = alloca i64
  %l174 = alloca i64
  %l179 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t95 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l26
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l26, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s0, ptr %s0, ptr %t8, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d12, i32 0, i32 1) }, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i32 %t10, ptr %l29
  br label %bb2
bb2:
  %t11 = load i32, ptr %l29, !tbaa !23
  store i32 %t11, ptr %l6, !tbaa !23
  %t12 = load ptr, ptr %l5, !tbaa !29
  %t14 = getelementptr %"compiler/check:frame", ptr %t12, i32 0, i32 28
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l32
  br label %bb3
bb3:
  %t17 = load i64, ptr %l32, !tbaa !24
  store i64 %t17, ptr %l7, !tbaa !24
  %t18 = load ptr, ptr %l5, !tbaa !29
  store ptr %t18, ptr %l33, !tbaa !29
  %t19 = load ptr, ptr %l33, !tbaa !29
  %t20 = getelementptr %"compiler/check:frame", ptr %t19, i32 0, i32 15
  %t21 = load i64, ptr %t20, !tbaa !24
  %t23 = add i64 %t21, 1
  %t25 = load ptr, ptr %l33, !tbaa !29
  %t26 = getelementptr %"compiler/check:frame", ptr %t25, i32 0, i32 15
  store i64 %t23, ptr %t26, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 42
  store i32 0, ptr %t29, !tbaa !23
  store ptr null, ptr %l8, !tbaa !29
  %t30 = load i64, ptr %l2, !tbaa !24
  %t32 = icmp slt i64 %t30, -1
  br i1 %t32, label %bb4, label %bb5
bb4:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  store ptr %t39, ptr %l41, !tbaa !29
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t43 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t40)
  store i32 %t43, ptr %l44
  br label %bb6
bb5:
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l77, !tbaa !29
  %t45 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t45, ptr %l78
  %t46 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t46, ptr %l79
  %t47 = load i64, ptr %l2, !tbaa !24
  store i64 %t47, ptr %l80, !tbaa !24
  %t48 = load ptr, ptr %l3, !tbaa !29
  store ptr %t48, ptr %l82, !tbaa !29
  %t50 = icmp sge i64 0, 0
  br i1 %t50, label %bb15, label %bb16
bb6:
  %t52 = load ptr, ptr %l41, !tbaa !29
  %t53 = load i32, ptr %l44, !tbaa !23
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t52, i32 %t53)
  store i32 %t54, ptr %l45
  br label %bb7
bb7:
  %t55 = load i32, ptr %l45, !tbaa !23
  store i32 %t55, ptr %l9, !tbaa !23
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t60 = load i32, ptr %l9, !tbaa !23
  %t63 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v0, ptr %t59, i32 %t60)
  store { i64, ptr } %t63, ptr %l49
  br label %bb8
bb8:
  %t64 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t64, ptr %l50, !tbaa !27
  %t65 = load i64, ptr %l2, !tbaa !24
  %t67 = sub i64 -2, %t65
  %t69 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr %"compiler/generic:AnySlot", ptr %t70, i64 %t67
  %t72 = load %"compiler/generic:AnySlot", ptr %t71
  store %"compiler/generic:AnySlot" %t72, ptr %l10
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i32, ptr %l9, !tbaa !23
  %t76 = load i64, ptr %l2, !tbaa !24
  %t78 = sub i64 -2, %t76
  %t79 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eslotCall(ptr %v0, ptr %t74, i32 %t75, i64 %t78, %"compiler/source:Span" %t79)
  br label %bb9
bb9:
  %t84 = load ptr, ptr %l0, !tbaa !29
  store ptr %t84, ptr %l59, !tbaa !29
  %t85 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t85, ptr %l60
  %t86 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t86, ptr %l61
  %t87 = getelementptr %"compiler/generic:AnySlot", ptr %l10, i32 0, i32 5
  %t88 = load i32, ptr %t87, !tbaa !23
  store i32 %t88, ptr %l62, !tbaa !23
  %t89 = load i32, ptr %l9, !tbaa !23
  %t90 = load i64, ptr %l2, !tbaa !24
  %t92 = sub i64 -2, %t90
  %t93 = getelementptr %"compiler/generic:AnySlot", ptr %l10, i32 0, i32 5
  %t94 = load i32, ptr %t93, !tbaa !23
  store { i64, [3 x i64] } zeroinitializer, ptr %t95
  %t96 = getelementptr { i64, [3 x i64] }, ptr %t95, i32 0, i32 0
  store i64 3, ptr %t96
  %t98 = insertvalue { i32, i64, i32 } undef, i32 %t89, 0
  %t100 = insertvalue { i32, i64, i32 } %t98, i64 %t92, 1
  %t102 = insertvalue { i32, i64, i32 } %t100, i32 %t94, 2
  %t103 = getelementptr { i64, [3 x i64] }, ptr %t95, i32 0, i32 1
  store { i32, i64, i32 } %t102, ptr %t103
  %t104 = load { i64, [3 x i64] }, ptr %t95
  %t106 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store { i64, [3 x i64] } %t104, ptr %t106
  store ptr %t106, ptr %l68, !tbaa !29
  %t107 = load ptr, ptr %l3, !tbaa !29
  store ptr %t107, ptr %l70, !tbaa !29
  %t109 = icmp sge i64 0, 0
  br i1 %t109, label %bb10, label %bb11
bb10:
  %t111 = icmp sle i64 0, 1152921504606846975
  br i1 %t111, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_652199a1d15cfac6_f2a0b86627c88902)
  unreachable
bb12:
  %t113 = mul i64 0, 8
  %t114 = insertvalue { i64, ptr } undef, i64 0, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t116 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t117 = load ptr, ptr %l59, !tbaa !29
  %t118 = load %"compiler/source:Span", ptr %l60
  %t119 = load %"compiler/source:Span", ptr %l61
  %t120 = load i32, ptr %l62, !tbaa !23
  %t121 = load ptr, ptr %l68, !tbaa !29
  %t122 = load ptr, ptr %l70, !tbaa !29
  %t125 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v3, ptr %v1, ptr %v0, ptr %v2, ptr %v3, ptr %t117, %"compiler/source:Span" %t118, %"compiler/source:Span" %t119, i32 %t120, ptr %t121, i64 -1, ptr %t122, { i64, ptr } %t115, { i64, ptr } %t116)
  store ptr %t125, ptr %l75
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_652199a1d15cfac6_f2a0b86627c88902)
  unreachable
bb14:
  %t126 = load ptr, ptr %l75, !tbaa !29
  store ptr %t126, ptr %l8, !tbaa !29
  br label %bb24
bb15:
  %t128 = icmp sle i64 0, 1152921504606846975
  br i1 %t128, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_7509e56452997e5b_fb360af196d85db7)
  unreachable
bb17:
  %t130 = mul i64 0, 8
  %t131 = insertvalue { i64, ptr } undef, i64 0, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t132, ptr %l85, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t133, ptr %l86, !tbaa !27
  %t134 = icmp sge i64 0, 0
  br i1 %t134, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_7509e56452997e5b_fb360af196d85db7)
  unreachable
bb19:
  %t136 = icmp sle i64 0, 2305843009213693951
  br i1 %t136, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_ff81ff8210117a78_6f7a62fdc976c914)
  unreachable
bb21:
  %t138 = mul i64 0, 4
  %t139 = insertvalue { i64, ptr } undef, i64 0, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t141 = load ptr, ptr %l77, !tbaa !29
  %t142 = load %"compiler/source:Span", ptr %l78
  %t143 = load %"compiler/source:Span", ptr %l79
  %t144 = load i64, ptr %l80, !tbaa !24
  %t145 = load ptr, ptr %l82, !tbaa !29
  %t146 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t147 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t149 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v0, ptr %v2, ptr %v3, ptr %v3, ptr %t141, %"compiler/source:Span" %t142, %"compiler/source:Span" %t143, i64 %t144, ptr %t145, { i64, ptr } %t146, { i64, ptr } %t147, { i64, ptr } %t140)
  store ptr %t149, ptr %l90
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_ff81ff8210117a78_6f7a62fdc976c914)
  unreachable
bb23:
  %t150 = load ptr, ptr %l90, !tbaa !29
  store ptr %t150, ptr %l8, !tbaa !29
  br label %bb24
bb24:
  %t152 = load ptr, ptr %l5, !tbaa !29
  store ptr %t152, ptr %l92, !tbaa !29
  %t153 = load ptr, ptr %l92, !tbaa !29
  %t154 = getelementptr %"compiler/check:frame", ptr %t153, i32 0, i32 15
  %t155 = load i64, ptr %t154, !tbaa !24
  %t157 = sub i64 %t155, 1
  %t159 = load ptr, ptr %l92, !tbaa !29
  %t160 = getelementptr %"compiler/check:frame", ptr %t159, i32 0, i32 15
  store i64 %t157, ptr %t160, !tbaa !24
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/check:Checker", ptr %t161, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !29
  %t166 = getelementptr %"compiler/generic:Program", ptr %t164, i32 0, i32 2
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/check:Checker", ptr %t167, i32 0, i32 42
  %t170 = load i32, ptr %t169, !tbaa !23
  %t173 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t166, i32 %t170)
  store { i64, ptr } %t173, ptr %l100
  br label %bb25
bb25:
  %t174 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t174, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t175 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t175, 0
  store i64 %t177, ptr %l13, !tbaa !24
  br label %bb26
bb26:
  %t179 = load i64, ptr %l12, !tbaa !24
  %t180 = load i64, ptr %l13, !tbaa !24
  %t183 = icmp slt i64 %t179, %t180
  %t185 = xor i1 %t183, true
  br i1 %t185, label %bb27, label %bb28
bb27:
  br label %bb35
bb28:
  br label %bb29
bb29:
  %t187 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t187, ptr %l107, !tbaa !27
  %t188 = load i64, ptr %l12, !tbaa !24
  %t190 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr i32, ptr %t191, i64 %t188
  %t193 = load i32, ptr %t192, !tbaa !33
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/check:Checker", ptr %t195, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t200 = getelementptr %"compiler/generic:Program", ptr %t198, i32 0, i32 2
  %t204 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t200, i32 %t193)
  store i32 %t204, ptr %l114
  br label %bb30
bb30:
  %t205 = load i32, ptr %l6, !tbaa !23
  %t206 = load i32, ptr %l114, !tbaa !23
  %t208 = icmp ne i32 %t206, %t205
  br i1 %t208, label %bb31, label %bb32
bb31:
  %t210 = load ptr, ptr %l5, !tbaa !29
  store ptr %t210, ptr %l117, !tbaa !29
  %t211 = load ptr, ptr %l117, !tbaa !29
  %t212 = getelementptr %"compiler/check:frame", ptr %t211, i32 0, i32 17
  %t213 = load i64, ptr %t212, !tbaa !24
  %t215 = add i64 %t213, 1
  %t217 = load ptr, ptr %l117, !tbaa !29
  %t218 = getelementptr %"compiler/check:frame", ptr %t217, i32 0, i32 17
  store i64 %t215, ptr %t218, !tbaa !24
  br label %bb33
bb32:
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t219 = load i64, ptr %l12, !tbaa !24
  %t221 = add i64 %t219, 1
  store i64 %t221, ptr %l12, !tbaa !24
  br label %bb26
bb35:
  %t223 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t223, ptr %l122
  br label %bb36
bb36:
  %t224 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l122
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t224, ptr %l15
  %t225 = load i64, ptr %l7, !tbaa !24
  store i64 %t225, ptr %l16, !tbaa !24
  %t227 = load ptr, ptr %l5, !tbaa !29
  %t229 = getelementptr %"compiler/check:frame", ptr %t227, i32 0, i32 28
  %t231 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t229)
  store i64 %t231, ptr %l126
  br label %bb37
bb37:
  %t232 = load i64, ptr %l126, !tbaa !24
  store i64 %t232, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t233 = load i64, ptr %l17, !tbaa !24
  %t234 = load i64, ptr %l16, !tbaa !24
  %t237 = icmp sgt i64 %t233, %t234
  br i1 %t237, label %bb38, label %bb39
bb38:
  %t239 = load i64, ptr %l18, !tbaa !24
  %t241 = icmp sgt i64 %t239, 0
  br i1 %t241, label %bb40, label %bb41
bb39:
  store i64 0, ptr %l130, !tbaa !24
  br label %bb43
bb40:
  %t243 = load i64, ptr %l17, !tbaa !24
  %t244 = load i64, ptr %l16, !tbaa !24
  %t247 = sub i64 %t243, %t244
  %t248 = load i64, ptr %l18, !tbaa !24
  %t251 = add i64 %t247, %t248
  %t253 = sub i64 %t251, 1
  %t254 = load i64, ptr %l18, !tbaa !24
  %t257 = sdiv i64 %t253, %t254
  store i64 %t257, ptr %l133, !tbaa !24
  br label %bb42
bb41:
  store i64 0, ptr %l133, !tbaa !24
  br label %bb42
bb42:
  %t259 = load i64, ptr %l133, !tbaa !24
  store i64 %t259, ptr %l130, !tbaa !24
  br label %bb43
bb43:
  %t260 = load i64, ptr %l130, !tbaa !24
  store i64 %t260, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb44
bb44:
  %t261 = load i64, ptr %l20, !tbaa !24
  %t262 = load i64, ptr %l19, !tbaa !24
  %t265 = icmp slt i64 %t261, %t262
  %t267 = xor i1 %t265, true
  br i1 %t267, label %bb45, label %bb46
bb45:
  br label %bb56
bb46:
  br label %bb47
bb47:
  %t269 = load i64, ptr %l16, !tbaa !24
  %t270 = load i64, ptr %l20, !tbaa !24
  %t271 = load i64, ptr %l18, !tbaa !24
  %t274 = mul i64 %t270, %t271
  %t277 = add i64 %t269, %t274
  store i64 %t277, ptr %l21, !tbaa !24
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr %"compiler/check:Checker", ptr %t279, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !29
  %t284 = getelementptr %"compiler/generic:Program", ptr %t282, i32 0, i32 2
  store ptr %t284, ptr %l153, !tbaa !29
  %t285 = load ptr, ptr %l5, !tbaa !29
  %t287 = getelementptr %"compiler/check:frame", ptr %t285, i32 0, i32 28
  %t288 = load i64, ptr %l21, !tbaa !24
  %t291 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t287, i64 %t288)
  store i32 %t291, ptr %l157
  br label %bb48
bb48:
  %t292 = load ptr, ptr %l153, !tbaa !29
  %t293 = load i32, ptr %l157, !tbaa !23
  %t294 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t292, i32 %t293)
  store i32 %t294, ptr %l158
  br label %bb49
bb49:
  %t295 = load i32, ptr %l6, !tbaa !23
  %t296 = load i32, ptr %l158, !tbaa !23
  %t298 = icmp ne i32 %t296, %t295
  br i1 %t298, label %bb50, label %bb51
bb50:
  store ptr %l15, ptr %l161, !tbaa !29
  %t300 = load ptr, ptr %l5, !tbaa !29
  %t302 = getelementptr %"compiler/check:frame", ptr %t300, i32 0, i32 28
  %t303 = load i64, ptr %l21, !tbaa !24
  %t306 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t302, i64 %t303)
  store i32 %t306, ptr %l165
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t307 = load ptr, ptr %l161, !tbaa !29
  %t308 = load i32, ptr %l165, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t307, i32 %t308)
  br label %bb53
bb53:
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t309 = load i64, ptr %l20, !tbaa !24
  %t311 = add i64 %t309, 1
  store i64 %t311, ptr %l20, !tbaa !24
  br label %bb44
bb56:
  %t313 = load ptr, ptr %l5, !tbaa !29
  %t315 = getelementptr %"compiler/check:frame", ptr %t313, i32 0, i32 28
  %t316 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t315, i64 %t316)
  br label %bb57
bb57:
  store ptr %l15, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  br label %bb58
bb58:
  %t320 = load i64, ptr %l23, !tbaa !24
  store i64 %t320, ptr %l172, !tbaa !24
  %t321 = load ptr, ptr %l22, !tbaa !29
  %t323 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t321)
  store i64 %t323, ptr %l174
  br label %bb59
bb59:
  %t324 = load i64, ptr %l172, !tbaa !24
  %t325 = load i64, ptr %l174, !tbaa !24
  %t326 = icmp slt i64 %t324, %t325
  %t328 = xor i1 %t326, true
  br i1 %t328, label %bb60, label %bb61
bb60:
  br label %bb66
bb61:
  br label %bb62
bb62:
  %t330 = load ptr, ptr %l22, !tbaa !29
  %t331 = load i64, ptr %l23, !tbaa !24
  %t334 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t330, i64 %t331)
  store i32 %t334, ptr %l179
  br label %bb63
bb63:
  %t335 = load i32, ptr %l179, !tbaa !23
  %t336 = load ptr, ptr %l5, !tbaa !29
  %t338 = getelementptr %"compiler/check:frame", ptr %t336, i32 0, i32 28
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t338, i32 %t335)
  br label %bb64
bb64:
  br label %bb65
bb65:
  %t342 = load i64, ptr %l23, !tbaa !24
  %t344 = add i64 %t342, 1
  store i64 %t344, ptr %l23, !tbaa !24
  br label %bb58
bb66:
  %t346 = load ptr, ptr %l8, !tbaa !29
  %t348 = icmp eq ptr %t346, null
  br i1 %t348, label %bb67, label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_77a5603a1298311f_4bb819fe8c7bb9e3)
  unreachable
bb68:
  br label %bb69
bb69:
  %t350 = load ptr, ptr %l8, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t350, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotCapture(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emustWrite(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i1 true)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotRecord(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i1
  %l9 = alloca i1
  %l13 = alloca i1
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca ptr
  %l38 = alloca i1
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l50 = alloca i1
  %l56 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l59 = alloca i64
  %l60 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i1, ptr %l7, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb5
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t16, ptr %l13
  br label %bb4
bb4:
  %t17 = load i1, ptr %l13, !tbaa !21
  %t18 = xor i1 %t17, true
  store i1 %t18, ptr %l9, !tbaa !21
  br label %bb5
bb5:
  %t20 = load i1, ptr %l9, !tbaa !21
  br i1 %t20, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d14, i32 0, i32 1) }, ptr %l15, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t21, ptr %l16, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l17, !tbaa !24
  %t24 = load i64, ptr %l17, !tbaa !24
  %t25 = mul i64 %t24, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l18, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l17, !tbaa !24
  %t34 = mul i64 %t33, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t35, ptr %l16, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t36, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 2
  %t43 = load i32, ptr %l1, !tbaa !23
  %t46 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t42, i32 %t43)
  store i1 %t46, ptr %l23
  br label %bb9
bb9:
  %t47 = load i1, ptr %l23, !tbaa !21
  br i1 %t47, label %bb10, label %bb11
bb10:
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %l24, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t48, ptr %l25, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  store i64 %t50, ptr %l26, !tbaa !24
  %t51 = load i64, ptr %l26, !tbaa !24
  %t52 = mul i64 %t51, 1
  %t53 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t52)
  %t54 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  store { i64, ptr } %t55, ptr %l27, !tbaa !27
  %t56 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = load i64, ptr %l26, !tbaa !24
  %t61 = mul i64 %t60, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t57, ptr %t59, i64 %t61, i1 false)
  %t62 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t62, ptr %l25, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t63, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  store ptr %t67, ptr %l29, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/check:Checker", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/generic:Program", ptr %t71, i32 0, i32 2
  %t74 = load i32, ptr %l1, !tbaa !23
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t73, i32 %t74)
  store i32 %t77, ptr %l34
  br label %bb13
bb13:
  %t78 = load ptr, ptr %l29, !tbaa !29
  %t79 = load i32, ptr %l34, !tbaa !23
  %t80 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t78, i32 %t79)
  store ptr %t80, ptr %l35
  br label %bb14
bb14:
  %t81 = load ptr, ptr %l35, !tbaa !29
  store ptr %t81, ptr %l2, !tbaa !29
  %t82 = load ptr, ptr %l2, !tbaa !29
  %t84 = icmp eq ptr %t82, null
  br i1 %t84, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb17
bb16:
  %t86 = load ptr, ptr %l2, !tbaa !29
  %t88 = getelementptr %"compiler/ast:TypeDecl", ptr %t86, i32 0, i32 3
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = icmp eq ptr %t89, null
  store i1 %t91, ptr %l38, !tbaa !21
  br label %bb17
bb17:
  %t93 = load i1, ptr %l38, !tbaa !21
  br i1 %t93, label %bb18, label %bb19
bb18:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l42, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t94, ptr %l43, !tbaa !27
  %t95 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t95, 0
  store i64 %t96, ptr %l44, !tbaa !24
  %t97 = load i64, ptr %l44, !tbaa !24
  %t98 = mul i64 %t97, 1
  %t99 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t98)
  %t100 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %t99, 1
  store { i64, ptr } %t101, ptr %l45, !tbaa !27
  %t102 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = load i64, ptr %l44, !tbaa !24
  %t107 = mul i64 %t106, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t103, ptr %t105, i64 %t107, i1 false)
  %t108 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t108, ptr %l43, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t109, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t110 = load ptr, ptr %l2, !tbaa !29
  %t112 = getelementptr %"compiler/ast:TypeDecl", ptr %t110, i32 0, i32 3
  %t113 = load ptr, ptr %t112, !tbaa !29
  store ptr %t113, ptr %l3, !tbaa !29
  %t115 = load ptr, ptr %l3, !tbaa !29
  store ptr %t115, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t116 = load ptr, ptr %l49, !tbaa !29
  %t117 = icmp ne ptr %t116, null
  br i1 %t117, label %bb21, label %bb22
bb21:
  %t119 = load ptr, ptr %l49, !tbaa !29
  %t120 = load i64, ptr %t119, !range !{i64 0, i64 5}
  %t122 = icmp eq i64 %t120, 0
  store i1 %t122, ptr %l50, !tbaa !21
  br label %bb22
bb22:
  %t123 = load i1, ptr %l50, !tbaa !21
  br i1 %t123, label %bb23, label %bb24
bb23:
  %t124 = load ptr, ptr %l3, !tbaa !29
  %t126 = getelementptr { i64, [6 x i64] }, ptr %t124, i32 0, i32 1
  %t127 = getelementptr { ptr }, ptr %t126, i32 0, i32 0
  %t128 = load ptr, ptr %t127
  store ptr %t128, ptr %l4, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t130 = load ptr, ptr %l4, !tbaa !29
  %t132 = call { i64, ptr } @compiler_2fcheck_2erecordBody(ptr %v0, ptr %v1, ptr %t130)
  store { i64, ptr } %t132, ptr %l56
  br label %bb26
bb26:
  %t133 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t133, ptr %l48, !tbaa !27
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d17, i32 0, i32 1) }, ptr %l57, !tbaa !27
  %t134 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t134, ptr %l48, !tbaa !27
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_9d659989a3d8e899_e17dd41770304f7d)
  unreachable
bb32:
  %t136 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 0
  store i64 %t137, ptr %l59, !tbaa !24
  %t138 = load i64, ptr %l59, !tbaa !24
  %t139 = mul i64 %t138, 1
  %t140 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t139)
  %t141 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t140, 1
  store { i64, ptr } %t142, ptr %l60, !tbaa !27
  %t143 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = load i64, ptr %l59, !tbaa !24
  %t148 = mul i64 %t147, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t144, ptr %t146, i64 %t148, i1 false)
  %t149 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t149, ptr %l48, !tbaa !27
  %t150 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t150, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, %"compiler/diagmsg:Msg" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca ptr
  %l19 = alloca i64
  %l25 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l41 = alloca i64
  %l53 = alloca i64
  %l54 = alloca { i64, ptr }
  %l55 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i32
  %l69 = alloca i64
  %l79 = alloca ptr
  %l80 = alloca i64
  %l86 = alloca ptr
  %t188 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l2, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l15
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l15, !tbaa !29
  store ptr %t9, ptr %l4, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l19
  br label %bb2
bb2:
  %t18 = load i64, ptr %l19, !tbaa !24
  store i64 %t18, ptr %l5, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/load:Loader", ptr %t25, i32 0, i32 10
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t27, i64 %t28)
  store ptr %t31, ptr %l25
  br label %bb3
bb3:
  %t32 = load ptr, ptr %l25, !tbaa !29
  %t34 = getelementptr %"compiler/load:Module", ptr %t32, i32 0, i32 6
  %t35 = load ptr, ptr %t34, !tbaa !29
  store ptr %t35, ptr %l6, !tbaa !29
  %t37 = load ptr, ptr %l6, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  br i1 %t39, label %bb4, label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_f66b04275832bdf5_49261566e6ebbc09)
  unreachable
bb5:
  br label %bb6
bb6:
  %t41 = load ptr, ptr %l6, !tbaa !29
  %t44 = getelementptr %"compiler/source:Source", ptr %t41, i32 0, i32 1
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  store { i64, ptr } %t45, ptr %l7, !tbaa !27
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load ptr, ptr %l4, !tbaa !29
  %t50 = getelementptr %"compiler/ast:Func", ptr %t48, i32 0, i32 2
  %t51 = load i32, ptr %t50, !tbaa !23
  %t54 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t47, i32 %t51)
  store { i64, ptr } %t54, ptr %l36
  br label %bb7
bb7:
  %t55 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t55, ptr %l8, !tbaa !27
  %t56 = load ptr, ptr %l4, !tbaa !29
  %t58 = getelementptr %"compiler/ast:Func", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = icmp eq ptr %t59, null
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb8, label %bb9
bb8:
  %t65 = load ptr, ptr %l4, !tbaa !29
  %t67 = getelementptr %"compiler/ast:Func", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = icmp eq ptr %t68, null
  br i1 %t70, label %bb10, label %bb11
bb9:
  %t72 = load ptr, ptr %l4, !tbaa !29
  %t74 = getelementptr %"compiler/ast:Func", ptr %t72, i32 0, i32 0
  %t75 = getelementptr %"compiler/source:Span", ptr %t74, i32 0, i32 0
  %t76 = load i32, ptr %t75, !tbaa !23
  %t78 = sext i32 %t76 to i64
  store i64 %t78, ptr %l41, !tbaa !24
  br label %bb13
bb10:
  call void @__olang_check_failed(ptr @olang_loc_959932aa8b846e4e_2c1999e37dfb1a2)
  unreachable
bb11:
  br label %bb12
bb12:
  %t80 = load ptr, ptr %l4, !tbaa !29
  %t82 = getelementptr %"compiler/ast:Func", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t86 = getelementptr %"compiler/ast:Param", ptr %t83, i32 0, i32 0
  %t87 = getelementptr %"compiler/source:Span", ptr %t86, i32 0, i32 1
  %t88 = load i32, ptr %t87, !tbaa !23
  %t90 = sext i32 %t88 to i64
  store i64 %t90, ptr %l41, !tbaa !24
  br label %bb13
bb13:
  %t92 = load i64, ptr %l41, !tbaa !24
  store i64 %t92, ptr %l9, !tbaa !24
  %t93 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t93, ptr %l54, !tbaa !27
  %t94 = load i64, ptr %l9, !tbaa !24
  store i64 %t94, ptr %l55, !tbaa !24
  %t95 = load ptr, ptr %l4, !tbaa !29
  %t97 = getelementptr %"compiler/ast:Func", ptr %t95, i32 0, i32 0
  %t98 = getelementptr %"compiler/source:Span", ptr %t97, i32 0, i32 1
  %t99 = load i32, ptr %t98, !tbaa !23
  %t101 = sext i32 %t99 to i64
  store i64 %t101, ptr %l58, !tbaa !24
  %t102 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 0
  store i64 %t103, ptr %l59, !tbaa !24
  %t104 = load i64, ptr %l55, !tbaa !24
  %t105 = icmp sge i64 %t104, 0
  br i1 %t105, label %bb14, label %bb15
bb14:
  %t107 = load i64, ptr %l55, !tbaa !24
  %t108 = load i64, ptr %l58, !tbaa !24
  %t109 = icmp sle i64 %t107, %t108
  br i1 %t109, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_f94ac378888081c5_5f597351c4418bf9)
  unreachable
bb16:
  %t111 = load i64, ptr %l58, !tbaa !24
  %t112 = load i64, ptr %l59, !tbaa !24
  %t113 = icmp sle i64 %t111, %t112
  br i1 %t113, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_f94ac378888081c5_5f597351c4418bf9)
  unreachable
bb18:
  %t115 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = load i64, ptr %l55, !tbaa !24
  %t118 = load i64, ptr %l58, !tbaa !24
  %t119 = getelementptr i8, ptr %t116, i64 %t117
  %t120 = sub i64 %t118, %t117
  %t121 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t119, 1
  %t123 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t126 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v0, { i64, ptr } %t122, { i64, ptr } %t123)
  %t127 = extractvalue { i32, i64 } %t126, 1
  %t128 = extractvalue { i32, i64 } %t126, 0
  store i32 %t128, ptr %l66
  %t129 = icmp ne i32 %t128, 0
  br i1 %t129, label %bb21, label %ok.130, !prof !99
ok.130:
  store i64 %t127, ptr %l65
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_f94ac378888081c5_5f597351c4418bf9)
  unreachable
bb20:
  %t131 = load i64, ptr %l65, !tbaa !24
  store i64 %t131, ptr %l53, !tbaa !24
  br label %bb23
bb21:
  br label %bb22
bb22:
  store i64 -1, ptr %l53, !tbaa !24
  br label %bb23
bb23:
  %t132 = load i64, ptr %l53, !tbaa !24
  store i64 %t132, ptr %l10, !tbaa !24
  %t133 = load i64, ptr %l10, !tbaa !24
  %t135 = icmp slt i64 %t133, 0
  br i1 %t135, label %bb24, label %bb25
bb24:
  %t137 = load ptr, ptr %l4, !tbaa !29
  %t139 = getelementptr %"compiler/ast:Func", ptr %t137, i32 0, i32 0
  %t140 = getelementptr %"compiler/source:Span", ptr %t139, i32 0, i32 0
  %t141 = load i32, ptr %t140, !tbaa !23
  %t143 = sext i32 %t141 to i64
  store i64 %t143, ptr %l69, !tbaa !24
  br label %bb26
bb25:
  %t145 = load i64, ptr %l9, !tbaa !24
  %t146 = load i64, ptr %l10, !tbaa !24
  %t149 = add i64 %t145, %t146
  store i64 %t149, ptr %l69, !tbaa !24
  br label %bb26
bb26:
  %t151 = load i64, ptr %l69, !tbaa !24
  store i64 %t151, ptr %l11, !tbaa !24
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/check:Checker", ptr %t152, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t157 = getelementptr %"compiler/generic:Program", ptr %t155, i32 0, i32 0
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t160 = getelementptr %"compiler/load:Loader", ptr %t158, i32 0, i32 4
  %t161 = load ptr, ptr %t160, !tbaa !29
  store ptr %t161, ptr %l79, !tbaa !29
  store i64 %a1, ptr %l80, !tbaa !24
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/check:Checker", ptr %t163, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !29
  %t168 = getelementptr %"compiler/generic:Program", ptr %t166, i32 0, i32 0
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t171 = getelementptr %"compiler/load:Loader", ptr %t169, i32 0, i32 10
  %t172 = load i64, ptr %l5, !tbaa !24
  %t175 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t171, i64 %t172)
  store ptr %t175, ptr %l86
  br label %bb27
bb27:
  %t176 = load ptr, ptr %l86, !tbaa !29
  %t178 = getelementptr %"compiler/load:Module", ptr %t176, i32 0, i32 4
  %t179 = load i64, ptr %t178, !tbaa !24
  %t180 = load i64, ptr %l11, !tbaa !24
  %t181 = load i64, ptr %l11, !tbaa !24
  %t182 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t182, 0
  %t187 = add i64 %t181, %t184
  store { i64, [3 x i64] } zeroinitializer, ptr %t188
  %t189 = getelementptr { i64, [3 x i64] }, ptr %t188, i32 0, i32 0
  store i64 3, ptr %t189
  %t191 = insertvalue { i64, i64, i64 } undef, i64 %t179, 0
  %t193 = insertvalue { i64, i64, i64 } %t191, i64 %t180, 1
  %t195 = insertvalue { i64, i64, i64 } %t193, i64 %t187, 2
  %t196 = getelementptr { i64, [3 x i64] }, ptr %t188, i32 0, i32 1
  store { i64, i64, i64 } %t195, ptr %t196
  %t197 = load { i64, [3 x i64] }, ptr %t188
  %t199 = load ptr, ptr %l79, !tbaa !29
  %t200 = load i64, ptr %l80, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %t199, i64 %t200, { i64, [3 x i64] } %t197, %"compiler/diagmsg:Msg" %a3)
  br label %bb28
bb28:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullOf(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l10 = alloca i1
  %l11 = alloca i64
  %l12 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store %"compiler/source:Span" %a1, ptr %l4
  %t3 = load i32, ptr %l2, !tbaa !23
  store i32 %t3, ptr %l5, !tbaa !23
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/check:Checker", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 2
  %t10 = load i32, ptr %l2, !tbaa !23
  %t13 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArrayRef(ptr %v0, ptr %t9, i32 %t10)
  store i1 %t13, ptr %l10
  br label %bb1
bb1:
  %t14 = load i1, ptr %l10, !tbaa !21
  br i1 %t14, label %bb2, label %bb3
bb2:
  store i64 -1, ptr %l11, !tbaa !24
  br label %bb4
bb3:
  store i64 0, ptr %l11, !tbaa !24
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l3, !tbaa !29
  %t16 = load %"compiler/source:Span", ptr %l4
  %t17 = load i32, ptr %l5, !tbaa !23
  %t18 = load i64, ptr %l11, !tbaa !24
  %t19 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %t15, %"compiler/source:Span" %t16, i32 %t17, i64 %t18)
  store ptr %t19, ptr %l12
  br label %bb5
bb5:
  %t20 = load ptr, ptr %l12, !tbaa !29
  store ptr %t20, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eonce(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l36 = alloca i32
  %l37 = alloca i64
  %l49 = alloca ptr
  %rv = alloca ptr
  %t78 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %rv
  br label %ret
bb6:
  %t12 = load ptr, ptr %l1, !tbaa !29
  store ptr %t12, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t13 = load ptr, ptr %l13, !tbaa !29
  %t14 = icmp ne ptr %t13, null
  br i1 %t14, label %bb7, label %bb8
bb7:
  %t16 = load ptr, ptr %l13, !tbaa !29
  %t17 = load i64, ptr %t16, !range !{i64 0, i64 18}
  %t19 = icmp eq i64 %t17, 2
  store i1 %t19, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t20 = load i1, ptr %l14, !tbaa !21
  br i1 %t20, label %bb9, label %bb10
bb9:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [5 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t23, i32 0, i32 2
  %t25 = load ptr, ptr %t24
  store ptr %t25, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb17
bb11:
  %t27 = load ptr, ptr %l2, !tbaa !29
  store ptr %t27, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t28 = load ptr, ptr %l19, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb12, label %bb13
bb12:
  %t31 = load ptr, ptr %l19, !tbaa !29
  %t32 = load i64, ptr %t31, !range !{i64 0, i64 8}
  %t34 = icmp eq i64 %t32, 0
  store i1 %t34, ptr %l20, !tbaa !21
  br label %bb13
bb13:
  %t35 = load i1, ptr %l20, !tbaa !21
  br i1 %t35, label %bb14, label %bb15
bb14:
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = getelementptr { i64, [4 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t38, i32 0, i32 0
  %t40 = load %"compiler/source:Span", ptr %t39
  store %"compiler/source:Span" %t40, ptr %l3
  %t42 = load ptr, ptr %l2, !tbaa !29
  %t44 = getelementptr { i64, [4 x i64] }, ptr %t42, i32 0, i32 1
  %t45 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t44, i32 0, i32 1
  %t46 = load i32, ptr %t45
  store i32 %t46, ptr %l4, !tbaa !23
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t50 = getelementptr { i64, [4 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t50, i32 0, i32 2
  %t52 = load i32, ptr %t51
  store i32 %t52, ptr %l5, !tbaa !23
  %t54 = load ptr, ptr %l1, !tbaa !29
  store ptr %t54, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_9e3e60c51c241998_753bf57c496fa07c)
  unreachable
bb22:
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t58 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t56)
  store %"compiler/source:Span" %t58, ptr %l31
  br label %bb23
bb23:
  %t59 = load %"compiler/source:Span", ptr %l31
  store %"compiler/source:Span" %t59, ptr %l6
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l32, !tbaa !29
  %t61 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t61, ptr %l33
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t65 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t62)
  store i32 %t65, ptr %l36
  br label %bb24
bb24:
  %t66 = load ptr, ptr %l32, !tbaa !29
  %t67 = load %"compiler/source:Span", ptr %l33
  %t68 = load i32, ptr %l36, !tbaa !23
  %t69 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t66, %"compiler/source:Span" %t67, i32 %t68)
  store i64 %t69, ptr %l37
  br label %bb25
bb25:
  %t70 = load i64, ptr %l37, !tbaa !24
  store i64 %t70, ptr %l7, !tbaa !24
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load %"compiler/source:Span", ptr %l6
  %t73 = load i64, ptr %l7, !tbaa !24
  %t75 = trunc i64 %t73 to i32
  %t77 = load ptr, ptr %l1, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t78
  %t79 = getelementptr { i64, [3 x i64] }, ptr %t78, i32 0, i32 0
  store i64 0, ptr %t79
  %t81 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t72, 0
  %t83 = insertvalue { %"compiler/source:Span", i32, ptr } %t81, i32 %t75, 1
  %t85 = insertvalue { %"compiler/source:Span", i32, ptr } %t83, ptr %t77, 2
  %t86 = getelementptr { i64, [3 x i64] }, ptr %t78, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t85, ptr %t86
  %t87 = load { i64, [3 x i64] }, ptr %t78
  %t89 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t87, ptr %t89
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t71, ptr %t89)
  br label %bb26
bb26:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load %"compiler/source:Span", ptr %l6
  %t94 = load i64, ptr %l7, !tbaa !24
  %t98 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v2, ptr %t92, %"compiler/source:Span" %t93, i64 %t94)
  store ptr %t98, ptr %l49
  br label %bb27
bb27:
  %t99 = load ptr, ptr %l49, !tbaa !29
  store ptr %t99, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5, %"compiler/source:Span" %a6, %"compiler/source:Span" %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i32
  %l9 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i1
  %l15 = alloca %"compiler/source:Span"
  %l17 = alloca i32
  %l20 = alloca i32
  %l23 = alloca i32
  %l27 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca %"compiler/source:Span"
  %l34 = alloca i1
  %l35 = alloca i32
  %l38 = alloca ptr
  %l43 = alloca i1
  %l44 = alloca i1
  %l49 = alloca i1
  %l56 = alloca ptr
  %l58 = alloca i1
  %l59 = alloca i1
  %l62 = alloca i64
  %l64 = alloca i1
  %l67 = alloca i64
  %l69 = alloca i1
  %l72 = alloca i1
  %l73 = alloca i1
  %l76 = alloca i1
  %l79 = alloca i1
  %l81 = alloca i1
  %l84 = alloca i64
  %l86 = alloca i1
  %l87 = alloca ptr
  %l90 = alloca i32
  %l91 = alloca i1
  %l92 = alloca i1
  %l93 = alloca ptr
  %l96 = alloca i32
  %l98 = alloca { i64, ptr }
  %l99 = alloca i64
  %l109 = alloca ptr
  %l112 = alloca ptr
  %l115 = alloca ptr
  %l118 = alloca i32
  %l121 = alloca i32
  %l129 = alloca ptr
  %l131 = alloca i1
  %l132 = alloca i1
  %l136 = alloca i1
  %l140 = alloca i1
  %l143 = alloca i1
  %l144 = alloca i1
  %l147 = alloca i1
  %l150 = alloca { i64, ptr }
  %l153 = alloca { i64, ptr }
  %l156 = alloca { i64, ptr }
  %l157 = alloca ptr
  %l158 = alloca %"compiler/source:Span"
  %l160 = alloca { i64, ptr }
  %l161 = alloca { i64, ptr }
  %l164 = alloca %"compiler/diagmsg:Msg"
  %l165 = alloca i64
  %l169 = alloca ptr
  %l173 = alloca i1
  %l179 = alloca i1
  %l182 = alloca i1
  %l185 = alloca ptr
  %l186 = alloca %"compiler/source:Span"
  %l187 = alloca i32
  %l189 = alloca i32
  %l193 = alloca ptr
  %l194 = alloca ptr
  %l195 = alloca %"compiler/source:Span"
  %l197 = alloca { i64, ptr }
  %l198 = alloca { i64, ptr }
  %l200 = alloca %"compiler/diagmsg:Msg"
  %l201 = alloca i64
  %l204 = alloca ptr
  %l207 = alloca ptr
  %l208 = alloca %"compiler/source:Span"
  %l211 = alloca { i64, ptr }
  %l213 = alloca %"compiler/diagmsg:Msg"
  %l214 = alloca i64
  %l217 = alloca ptr
  %l221 = alloca i1
  %l231 = alloca ptr
  %l242 = alloca ptr
  %l249 = alloca ptr
  %l252 = alloca i32
  %l254 = alloca i1
  %l256 = alloca ptr
  %l257 = alloca %"compiler/source:Span"
  %l260 = alloca { i64, ptr }
  %l262 = alloca %"compiler/diagmsg:Msg"
  %l263 = alloca i64
  %l266 = alloca ptr
  %l269 = alloca i1
  %l272 = alloca i1
  %l275 = alloca i1
  %l276 = alloca i1
  %l282 = alloca i1
  %l283 = alloca i1
  %l286 = alloca i64
  %l290 = alloca i1
  %l292 = alloca i1
  %l295 = alloca i1
  %l297 = alloca i1
  %l301 = alloca i1
  %l313 = alloca ptr
  %l318 = alloca { i64, ptr }
  %l319 = alloca i1
  %l321 = alloca i1
  %l322 = alloca ptr
  %l325 = alloca i32
  %l327 = alloca { i64, ptr }
  %l328 = alloca %"compiler/source:Span"
  %l330 = alloca { i64, ptr }
  %l331 = alloca { i64, ptr }
  %l333 = alloca i1
  %l336 = alloca ptr
  %l339 = alloca i1
  %l340 = alloca i1
  %l343 = alloca i1
  %l344 = alloca ptr
  %l345 = alloca %"compiler/source:Span"
  %l347 = alloca { i64, ptr }
  %l348 = alloca { i64, ptr }
  %l349 = alloca { i64, ptr }
  %l352 = alloca { i64, ptr }
  %l353 = alloca { i64, ptr }
  %l356 = alloca { i64, ptr }
  %l358 = alloca %"compiler/diagmsg:Msg"
  %l359 = alloca i64
  %l360 = alloca ptr
  %l361 = alloca %"compiler/source:Span"
  %l362 = alloca i32
  %l364 = alloca { i64, ptr }
  %l365 = alloca { i64, ptr }
  %l367 = alloca { i64, ptr }
  %l368 = alloca { i64, ptr }
  %l369 = alloca { i64, ptr }
  %l372 = alloca { i64, ptr }
  %l374 = alloca %"compiler/diagmsg:Msg"
  %l375 = alloca i64
  %l378 = alloca ptr
  %l381 = alloca i1
  %l386 = alloca i1
  %l388 = alloca ptr
  %l389 = alloca %"compiler/source:Span"
  %l391 = alloca { i64, ptr }
  %l392 = alloca { i64, ptr }
  %l393 = alloca { i64, ptr }
  %l396 = alloca { i64, ptr }
  %l398 = alloca %"compiler/diagmsg:Msg"
  %l399 = alloca i64
  %l402 = alloca i1
  %l404 = alloca ptr
  %l405 = alloca %"compiler/source:Span"
  %l407 = alloca { i64, ptr }
  %l408 = alloca { i64, ptr }
  %l409 = alloca { i64, ptr }
  %l412 = alloca { i64, ptr }
  %l414 = alloca %"compiler/diagmsg:Msg"
  %l415 = alloca i64
  %l417 = alloca i1
  %l419 = alloca i1
  %l422 = alloca i1
  %l423 = alloca i1
  %l427 = alloca i1
  %l429 = alloca ptr
  %l430 = alloca %"compiler/source:Span"
  %l433 = alloca { i64, ptr }
  %l434 = alloca { i64, ptr }
  %l436 = alloca { i64, ptr }
  %l437 = alloca { i64, ptr }
  %l438 = alloca { i64, ptr }
  %l440 = alloca { i64, ptr }
  %l443 = alloca %"compiler/diagmsg:Msg"
  %l444 = alloca i64
  %l447 = alloca ptr
  %l452 = alloca i1
  %l456 = alloca ptr
  %l457 = alloca ptr
  %l458 = alloca %"compiler/source:Span"
  %l459 = alloca i32
  %l461 = alloca i32
  %l464 = alloca ptr
  %l473 = alloca i32
  %l476 = alloca ptr
  %l477 = alloca %"compiler/source:Span"
  %l480 = alloca { i64, ptr }
  %l481 = alloca { i64, ptr }
  %l484 = alloca { i64, ptr }
  %l486 = alloca %"compiler/diagmsg:Msg"
  %l487 = alloca i64
  %l490 = alloca ptr
  %l498 = alloca ptr
  %l506 = alloca ptr
  %l508 = alloca i1
  %l509 = alloca i1
  %l512 = alloca i1
  %l514 = alloca ptr
  %l515 = alloca %"compiler/source:Span"
  %l517 = alloca { i64, ptr }
  %l518 = alloca { i64, ptr }
  %l519 = alloca { i64, ptr }
  %l522 = alloca { i64, ptr }
  %l524 = alloca %"compiler/diagmsg:Msg"
  %l525 = alloca i64
  %l528 = alloca ptr
  %l530 = alloca i1
  %l532 = alloca i1
  %l535 = alloca i1
  %l536 = alloca i1
  %l540 = alloca i1
  %l542 = alloca ptr
  %l543 = alloca %"compiler/source:Span"
  %l546 = alloca { i64, ptr }
  %l547 = alloca { i64, ptr }
  %l549 = alloca { i64, ptr }
  %l550 = alloca { i64, ptr }
  %l551 = alloca { i64, ptr }
  %l553 = alloca { i64, ptr }
  %l556 = alloca %"compiler/diagmsg:Msg"
  %l557 = alloca i64
  %l560 = alloca ptr
  %l562 = alloca i1
  %l563 = alloca ptr
  %l564 = alloca %"compiler/source:Span"
  %l565 = alloca i32
  %l567 = alloca i32
  %l571 = alloca ptr
  %l572 = alloca ptr
  %l573 = alloca %"compiler/source:Span"
  %l574 = alloca i32
  %l576 = alloca i32
  %l579 = alloca ptr
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  store %"compiler/source:Span" %a7, ptr %l7
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l4, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t1)
  store i32 %t4, ptr %l20
  br label %bb1
bb1:
  %t5 = load i32, ptr %l20, !tbaa !23
  store i32 %t5, ptr %l8, !tbaa !23
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t9 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t6)
  store i32 %t9, ptr %l23
  br label %bb2
bb2:
  %t10 = load i32, ptr %l23, !tbaa !23
  store i32 %t10, ptr %l9, !tbaa !23
  %t11 = load i32, ptr %l8, !tbaa !23
  %t12 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t15 = icmp eq i32 %t11, %t12
  br i1 %t15, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb5
bb4:
  %t17 = load i32, ptr %l9, !tbaa !23
  %t18 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t21 = icmp eq i32 %t17, %t18
  store i1 %t21, ptr %l27, !tbaa !21
  br label %bb5
bb5:
  %t23 = load i1, ptr %l27, !tbaa !21
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l31, !tbaa !29
  %t25 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t25, ptr %l32
  %t26 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t28 = call i1 @compiler_2fcheck_2ecompares(i32 %t26)
  store i1 %t28, ptr %l34
  br label %bb8
bb7:
  br label %bb13
bb8:
  %t29 = load i1, ptr %l34, !tbaa !21
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t30 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t30, ptr %l35, !tbaa !23
  br label %bb11
bb10:
  %t32 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t32, ptr %l35, !tbaa !23
  br label %bb11
bb11:
  %t34 = load ptr, ptr %l31, !tbaa !29
  %t35 = load %"compiler/source:Span", ptr %l32
  %t36 = load i32, ptr %l35, !tbaa !23
  %t37 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t34, %"compiler/source:Span" %t35, i32 %t36, i64 0)
  store ptr %t37, ptr %l38
  br label %bb12
bb12:
  %t38 = load ptr, ptr %l38, !tbaa !29
  store ptr %t38, ptr %rv
  br label %ret
bb13:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/generic:Program", ptr %t42, i32 0, i32 2
  %t45 = load i32, ptr %l8, !tbaa !23
  %t48 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %t44, i32 %t45)
  store i1 %t48, ptr %l43
  br label %bb14
bb14:
  %t49 = load i1, ptr %l43, !tbaa !21
  br i1 %t49, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb18
bb16:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %l9, !tbaa !23
  %t59 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %t55, i32 %t56)
  store i1 %t59, ptr %l49
  br label %bb17
bb17:
  %t60 = load i1, ptr %l49, !tbaa !21
  store i1 %t60, ptr %l44, !tbaa !21
  br label %bb18
bb18:
  %t61 = load i1, ptr %l44, !tbaa !21
  br i1 %t61, label %bb19, label %bb20
bb19:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load %"compiler/source:Span", ptr %l1
  %t64 = load %"compiler/source:Span", ptr %l2
  %t65 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t66 = load ptr, ptr %l4, !tbaa !29
  %t67 = load ptr, ptr %l5, !tbaa !29
  %t74 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrValues(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t62, %"compiler/source:Span" %t63, %"compiler/source:Span" %t64, i32 %t65, ptr %t66, ptr %t67)
  store ptr %t74, ptr %l56
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t75 = load ptr, ptr %l56, !tbaa !29
  store ptr %t75, ptr %rv
  br label %ret
bb22:
  %t76 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t78 = call i1 @compiler_2fcheck_2elaneTok(i32 %t76)
  store i1 %t78, ptr %l58
  br label %bb23
bb23:
  %t79 = load i1, ptr %l58, !tbaa !21
  br i1 %t79, label %bb24, label %bb25
bb24:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load ptr, ptr %l4, !tbaa !29
  %t82 = load ptr, ptr @__olang_prog_scope
  %t85 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOf(ptr %v0, ptr %t82, ptr %t80, ptr %t81)
  store i64 %t85, ptr %l62
  br label %bb26
bb25:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb39
bb26:
  %t86 = load i64, ptr %l62, !tbaa !24
  %t87 = icmp sge i64 %t86, 0
  br i1 %t87, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l64, !tbaa !21
  br label %bb30
bb28:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load ptr, ptr %l5, !tbaa !29
  %t91 = load ptr, ptr @__olang_prog_scope
  %t94 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOf(ptr %v0, ptr %t91, ptr %t89, ptr %t90)
  store i64 %t94, ptr %l67
  br label %bb29
bb29:
  %t95 = load i64, ptr %l67, !tbaa !24
  %t96 = icmp sge i64 %t95, 0
  store i1 %t96, ptr %l64, !tbaa !21
  br label %bb30
bb30:
  %t98 = load i1, ptr %l64, !tbaa !21
  br i1 %t98, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l69, !tbaa !21
  br label %bb34
bb32:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load i32, ptr %l8, !tbaa !23
  %t103 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %t99, i32 %t100)
  store i1 %t103, ptr %l72
  br label %bb33
bb33:
  %t104 = load i1, ptr %l72, !tbaa !21
  store i1 %t104, ptr %l69, !tbaa !21
  br label %bb34
bb34:
  %t105 = load i1, ptr %l69, !tbaa !21
  br i1 %t105, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb38
bb36:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i32, ptr %l9, !tbaa !23
  %t110 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %t106, i32 %t107)
  store i1 %t110, ptr %l76
  br label %bb37
bb37:
  %t111 = load i1, ptr %l76, !tbaa !21
  store i1 %t111, ptr %l73, !tbaa !21
  br label %bb38
bb38:
  %t112 = load i1, ptr %l73, !tbaa !21
  store i1 %t112, ptr %l59, !tbaa !21
  br label %bb39
bb39:
  %t113 = load i1, ptr %l59, !tbaa !21
  br i1 %t113, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s3
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load i32, ptr %l8, !tbaa !23
  %t118 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %t114, i32 %t115)
  store i1 %t118, ptr %l79
  br label %bb42
bb41:
  br label %bb66
bb42:
  %t119 = load i1, ptr %l79, !tbaa !21
  %t120 = xor i1 %t119, true
  br i1 %t120, label %bb43, label %bb44
bb43:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load ptr, ptr %l4, !tbaa !29
  %t126 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOf(ptr %v0, ptr %v1, ptr %t122, ptr %t123)
  store i64 %t126, ptr %l84
  br label %bb45
bb44:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb46
bb45:
  %t127 = load i64, ptr %l84, !tbaa !24
  %t128 = icmp slt i64 %t127, 0
  store i1 %t128, ptr %l81, !tbaa !21
  br label %bb46
bb46:
  %t130 = load i1, ptr %l81, !tbaa !21
  br i1 %t130, label %bb47, label %bb48
bb47:
  %t131 = load ptr, ptr %l0, !tbaa !29
  store ptr %t131, ptr %l87, !tbaa !29
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load i32, ptr %l8, !tbaa !23
  %t136 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t132, i32 %t133)
  store i32 %t136, ptr %l90
  br label %bb49
bb48:
  store i1 false, ptr %l86, !tbaa !21
  br label %bb51
bb49:
  %t137 = load ptr, ptr %l87, !tbaa !29
  %t138 = load i32, ptr %l90, !tbaa !23
  %t139 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t137, i32 %t138)
  store i1 %t139, ptr %l91
  br label %bb50
bb50:
  %t140 = load i1, ptr %l91, !tbaa !21
  store i1 %t140, ptr %l86, !tbaa !21
  br label %bb51
bb51:
  %t141 = load i1, ptr %l86, !tbaa !21
  br i1 %t141, label %bb52, label %bb53
bb52:
  %t142 = load ptr, ptr %l0, !tbaa !29
  store ptr %t142, ptr %l93, !tbaa !29
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load i32, ptr %l8, !tbaa !23
  %t147 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t143, i32 %t144)
  store i32 %t147, ptr %l96
  br label %bb54
bb53:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb57
bb54:
  %t148 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t150 = call { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %s3, i32 %t148)
  store { i64, ptr } %t150, ptr %l98
  br label %bb55
bb55:
  %t151 = load ptr, ptr %l93, !tbaa !29
  %t152 = load i32, ptr %l96, !tbaa !23
  %t153 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t154 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s3, ptr %t151, i32 %t152, { i64, ptr } %t153, i64 1)
  store i64 %t154, ptr %l99
  br label %bb56
bb56:
  %t155 = load i64, ptr %l99, !tbaa !24
  %t156 = icmp sge i64 %t155, 0
  store i1 %t156, ptr %l92, !tbaa !21
  br label %bb57
bb57:
  %t158 = load i1, ptr %l92, !tbaa !21
  %t161 = xor i1 %t158, true
  br i1 %t161, label %bb58, label %bb59
bb58:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load %"compiler/source:Span", ptr %l1
  %t165 = load %"compiler/source:Span", ptr %l2
  %t166 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t167 = load ptr, ptr %l4, !tbaa !29
  %t168 = load ptr, ptr %l5, !tbaa !29
  %t175 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneBinary(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t163, %"compiler/source:Span" %t164, %"compiler/source:Span" %t165, i32 %t166, ptr %t167, ptr %t168)
  store ptr %t175, ptr %l109
  br label %bb60
bb59:
  br label %bb61
bb60:
  call void @__olang_scope_close(ptr %s3)
  %t176 = load ptr, ptr %l109, !tbaa !29
  store ptr %t176, ptr %rv
  br label %ret
bb61:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load ptr, ptr %l4, !tbaa !29
  %t181 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOut(ptr %v0, ptr %v1, ptr %v0, ptr %t177, ptr %t178)
  store ptr %t181, ptr %l112
  br label %bb62
bb62:
  %t182 = load ptr, ptr %l112, !tbaa !29
  store ptr %t182, ptr %l4, !tbaa !29
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load ptr, ptr %l5, !tbaa !29
  %t187 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOut(ptr %v0, ptr %v2, ptr %v0, ptr %t183, ptr %t184)
  store ptr %t187, ptr %l115
  br label %bb63
bb63:
  %t188 = load ptr, ptr %l115, !tbaa !29
  store ptr %t188, ptr %l5, !tbaa !29
  %t189 = load ptr, ptr %l4, !tbaa !29
  %t192 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t189)
  store i32 %t192, ptr %l118
  br label %bb64
bb64:
  %t193 = load i32, ptr %l118, !tbaa !23
  store i32 %t193, ptr %l8, !tbaa !23
  %t194 = load ptr, ptr %l5, !tbaa !29
  %t197 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t194)
  store i32 %t197, ptr %l121
  br label %bb65
bb65:
  %t198 = load i32, ptr %l121, !tbaa !23
  store i32 %t198, ptr %l9, !tbaa !23
  call void @__olang_scope_close(ptr %s3)
  br label %bb66
bb66:
  %t199 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t201 = trunc i64 55 to i32
  %t202 = icmp eq i32 %t199, %t201
  br i1 %t202, label %bb67, label %bb68
bb67:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load %"compiler/source:Span", ptr %l1
  %t206 = load %"compiler/source:Span", ptr %l2
  %t207 = load ptr, ptr %l4, !tbaa !29
  %t208 = load ptr, ptr %l5, !tbaa !29
  %t209 = load ptr, ptr @__olang_prog_scope
  %t210 = load ptr, ptr @__olang_prog_scope
  %t216 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowValues(ptr %v0, ptr %t209, ptr %t210, ptr %v3, ptr %t204, %"compiler/source:Span" %t205, %"compiler/source:Span" %t206, ptr %t207, ptr %t208)
  store ptr %t216, ptr %l129
  br label %bb69
bb68:
  br label %bb70
bb69:
  %t217 = load ptr, ptr %l129, !tbaa !29
  store ptr %t217, ptr %rv
  br label %ret
bb70:
  %t218 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t220 = call i1 @compiler_2fcheck_2ecompares(i32 %t218)
  store i1 %t220, ptr %l131
  br label %bb71
bb71:
  %t221 = load i1, ptr %l131, !tbaa !21
  br i1 %t221, label %bb72, label %bb73
bb72:
  %t222 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t224 = trunc i64 78 to i32
  %t225 = icmp eq i32 %t222, %t224
  %t227 = xor i1 %t225, true
  store i1 %t227, ptr %l132, !tbaa !21
  br label %bb74
bb73:
  store i1 false, ptr %l132, !tbaa !21
  br label %bb74
bb74:
  %t229 = load i1, ptr %l132, !tbaa !21
  br i1 %t229, label %bb75, label %bb76
bb75:
  %t230 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t232 = trunc i64 79 to i32
  %t233 = icmp eq i32 %t230, %t232
  %t235 = xor i1 %t233, true
  store i1 %t235, ptr %l136, !tbaa !21
  br label %bb77
bb76:
  store i1 false, ptr %l136, !tbaa !21
  br label %bb77
bb77:
  %t237 = load i1, ptr %l136, !tbaa !21
  br i1 %t237, label %bb78, label %bb79
bb78:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load i32, ptr %l8, !tbaa !23
  %t242 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %t238, i32 %t239)
  store i1 %t242, ptr %l143
  br label %bb80
bb79:
  store i1 false, ptr %l140, !tbaa !21
  br label %bb85
bb80:
  %t243 = load i1, ptr %l143, !tbaa !21
  br i1 %t243, label %bb81, label %bb82
bb81:
  store i1 true, ptr %l144, !tbaa !21
  br label %bb84
bb82:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load i32, ptr %l9, !tbaa !23
  %t248 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %t244, i32 %t245)
  store i1 %t248, ptr %l147
  br label %bb83
bb83:
  %t249 = load i1, ptr %l147, !tbaa !21
  store i1 %t249, ptr %l144, !tbaa !21
  br label %bb84
bb84:
  %t250 = load i1, ptr %l144, !tbaa !21
  store i1 %t250, ptr %l140, !tbaa !21
  br label %bb85
bb85:
  %t251 = load i1, ptr %l140, !tbaa !21
  br i1 %t251, label %bb86, label %bb87
bb86:
  store %olang.scope zeroinitializer, ptr %s6
  %t252 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t254 = trunc i64 81 to i32
  %t255 = icmp eq i32 %t252, %t254
  br i1 %t255, label %bb88, label %bb89
bb87:
  br label %bb102
bb88:
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l150, !tbaa !27
  br label %bb96
bb89:
  %t257 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t259 = trunc i64 83 to i32
  %t260 = icmp eq i32 %t257, %t259
  br i1 %t260, label %bb90, label %bb91
bb90:
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l153, !tbaa !27
  br label %bb95
bb91:
  %t262 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t264 = trunc i64 82 to i32
  %t265 = icmp eq i32 %t262, %t264
  br i1 %t265, label %bb92, label %bb93
bb92:
  store { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l156, !tbaa !27
  br label %bb94
bb93:
  store { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %l156, !tbaa !27
  br label %bb94
bb94:
  %t267 = load { i64, ptr }, ptr %l156, !tbaa !27
  store { i64, ptr } %t267, ptr %l153, !tbaa !27
  br label %bb95
bb95:
  %t268 = load { i64, ptr }, ptr %l153, !tbaa !27
  store { i64, ptr } %t268, ptr %l150, !tbaa !27
  br label %bb96
bb96:
  %t269 = load { i64, ptr }, ptr %l150, !tbaa !27
  store { i64, ptr } %t269, ptr %l11, !tbaa !27
  %t270 = load ptr, ptr %l0, !tbaa !29
  store ptr %t270, ptr %l157, !tbaa !29
  %t271 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t271, ptr %l158
  %t272 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t274 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s6, i32 %t272)
  store { i64, ptr } %t274, ptr %l160
  br label %bb97
bb97:
  %t275 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t276 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s6, ptr %s6, { i64, ptr } %t275)
  store { i64, ptr } %t276, ptr %l161
  br label %bb98
bb98:
  %t277 = load { i64, ptr }, ptr %l161, !tbaa !27
  %t278 = extractvalue { i64, ptr } %t277, 0
  %t279 = extractvalue { i64, ptr } %t277, 1
  %t280 = mul i64 %t278, 1
  %t281 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t280)
  call void @llvm.memcpy.p0.p0.i64(ptr %t281, ptr %t279, i64 %t280, i1 false)
  %t282 = insertvalue { i64, ptr } undef, i64 %t278, 0
  %t283 = insertvalue { i64, ptr } %t282, ptr %t281, 1
  %t284 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t285 = load ptr, ptr @__olang_prog_scope
  %t288 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLaneCompare(ptr %s6, ptr %t285, ptr %s6, { i64, ptr } %t283, { i64, ptr } %t284)
  store %"compiler/diagmsg:Msg" %t288, ptr %l164
  br label %bb99
bb99:
  %t289 = load ptr, ptr %l157, !tbaa !29
  %t290 = load %"compiler/source:Span", ptr %l158
  %t291 = load %"compiler/diagmsg:Msg", ptr %l164
  %t292 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t289, %"compiler/source:Span" %t290, %"compiler/diagmsg:Msg" %t291)
  store i64 %t292, ptr %l165
  br label %bb100
bb100:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t294 = load %"compiler/source:Span", ptr %l1
  %t295 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t299 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t293, %"compiler/source:Span" %t294, i32 %t295, i64 0)
  store ptr %t299, ptr %l169
  br label %bb101
bb101:
  call void @__olang_scope_close(ptr %s6)
  %t300 = load ptr, ptr %l169, !tbaa !29
  store ptr %t300, ptr %rv
  br label %ret
bb102:
  %t301 = load i32, ptr %l8, !tbaa !23
  %t302 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t305 = icmp eq i32 %t301, %t302
  br i1 %t305, label %bb103, label %bb104
bb103:
  %t307 = load i32, ptr %l9, !tbaa !23
  %t308 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t311 = icmp eq i32 %t307, %t308
  store i1 %t311, ptr %l173, !tbaa !21
  br label %bb105
bb104:
  store i1 false, ptr %l173, !tbaa !21
  br label %bb105
bb105:
  %t313 = load i1, ptr %l173, !tbaa !21
  br i1 %t313, label %bb106, label %bb107
bb106:
  store %olang.scope zeroinitializer, ptr %s7
  %t314 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t316 = trunc i64 78 to i32
  %t317 = icmp eq i32 %t314, %t316
  br i1 %t317, label %bb108, label %bb109
bb107:
  br label %bb124
bb108:
  store i1 true, ptr %l179, !tbaa !21
  br label %bb110
bb109:
  %t319 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t321 = trunc i64 79 to i32
  %t322 = icmp eq i32 %t319, %t321
  store i1 %t322, ptr %l179, !tbaa !21
  br label %bb110
bb110:
  %t324 = load i1, ptr %l179, !tbaa !21
  br i1 %t324, label %bb111, label %bb112
bb111:
  store i1 true, ptr %l182, !tbaa !21
  br label %bb113
bb112:
  %t325 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t327 = trunc i64 47 to i32
  %t328 = icmp eq i32 %t325, %t327
  store i1 %t328, ptr %l182, !tbaa !21
  br label %bb113
bb113:
  %t330 = load i1, ptr %l182, !tbaa !21
  br i1 %t330, label %bb114, label %bb115
bb114:
  %t331 = load ptr, ptr %l0, !tbaa !29
  store ptr %t331, ptr %l185, !tbaa !29
  %t332 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t332, ptr %l186
  %t333 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t333, ptr %l187, !tbaa !23
  %t334 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t336 = call i32 @compiler_2fcheck_2ebinaryOp(i32 %t334)
  store i32 %t336, ptr %l189
  br label %bb116
bb115:
  br label %bb118
bb116:
  %t337 = load ptr, ptr %l4, !tbaa !29
  %t338 = load ptr, ptr %l5, !tbaa !29
  %t340 = load ptr, ptr @__olang_prog_scope
  %t341 = load ptr, ptr @__olang_prog_scope
  %t342 = load ptr, ptr %l185, !tbaa !29
  %t343 = load %"compiler/source:Span", ptr %l186
  %t344 = load i32, ptr %l187, !tbaa !23
  %t345 = load i32, ptr %l189, !range !{i32 0, i32 49}
  %t348 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t340, ptr %t341, ptr %v3, ptr %t342, %"compiler/source:Span" %t343, i32 %t344, i32 %t345, ptr %t337, ptr %t338)
  store ptr %t348, ptr %l193
  br label %bb117
bb117:
  call void @__olang_scope_close(ptr %s7)
  %t349 = load ptr, ptr %l193, !tbaa !29
  store ptr %t349, ptr %rv
  br label %ret
bb118:
  %t350 = load ptr, ptr %l0, !tbaa !29
  store ptr %t350, ptr %l194, !tbaa !29
  %t351 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t351, ptr %l195
  %t352 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t354 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s7, i32 %t352)
  store { i64, ptr } %t354, ptr %l197
  br label %bb119
bb119:
  %t355 = load { i64, ptr }, ptr %l197, !tbaa !27
  %t356 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s7, ptr %s7, { i64, ptr } %t355)
  store { i64, ptr } %t356, ptr %l198
  br label %bb120
bb120:
  %t357 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t358 = extractvalue { i64, ptr } %t357, 0
  %t359 = extractvalue { i64, ptr } %t357, 1
  %t360 = mul i64 %t358, 1
  %t361 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t360)
  call void @llvm.memcpy.p0.p0.i64(ptr %t361, ptr %t359, i64 %t360, i1 false)
  %t362 = insertvalue { i64, ptr } undef, i64 %t358, 0
  %t363 = insertvalue { i64, ptr } %t362, ptr %t361, 1
  %t365 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOperandNotNumber(ptr %s7, ptr %s7, ptr %s7, { i64, ptr } %t363, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t365, ptr %l200
  br label %bb121
bb121:
  %t366 = load ptr, ptr %l194, !tbaa !29
  %t367 = load %"compiler/source:Span", ptr %l195
  %t368 = load %"compiler/diagmsg:Msg", ptr %l200
  %t369 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t366, %"compiler/source:Span" %t367, %"compiler/diagmsg:Msg" %t368)
  store i64 %t369, ptr %l201
  br label %bb122
bb122:
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t371 = load %"compiler/source:Span", ptr %l1
  %t374 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t370, %"compiler/source:Span" %t371)
  store ptr %t374, ptr %l204
  br label %bb123
bb123:
  call void @__olang_scope_close(ptr %s7)
  %t375 = load ptr, ptr %l204, !tbaa !29
  store ptr %t375, ptr %rv
  br label %ret
bb124:
  %t376 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t378 = trunc i64 47 to i32
  %t379 = icmp eq i32 %t376, %t378
  br i1 %t379, label %bb125, label %bb126
bb125:
  store %olang.scope zeroinitializer, ptr %s9
  %t381 = load ptr, ptr %l0, !tbaa !29
  store ptr %t381, ptr %l207, !tbaa !29
  %t382 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t382, ptr %l208
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t384 = load i32, ptr %l8, !tbaa !23
  %t387 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t383, i32 %t384)
  store { i64, ptr } %t387, ptr %l211
  br label %bb127
bb126:
  br label %bb131
bb127:
  %t388 = load { i64, ptr }, ptr %l211, !tbaa !27
  %t389 = extractvalue { i64, ptr } %t388, 0
  %t390 = extractvalue { i64, ptr } %t388, 1
  %t391 = mul i64 %t389, 1
  %t392 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t391)
  call void @llvm.memcpy.p0.p0.i64(ptr %t392, ptr %t390, i64 %t391, i1 false)
  %t393 = insertvalue { i64, ptr } undef, i64 %t389, 0
  %t394 = insertvalue { i64, ptr } %t393, ptr %t392, 1
  %t396 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOperandNotBool(ptr %s9, ptr %s9, ptr %s9, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d23, i32 0, i32 1) }, { i64, ptr } %t394)
  store %"compiler/diagmsg:Msg" %t396, ptr %l213
  br label %bb128
bb128:
  %t397 = load ptr, ptr %l207, !tbaa !29
  %t398 = load %"compiler/source:Span", ptr %l208
  %t399 = load %"compiler/diagmsg:Msg", ptr %l213
  %t400 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s9, ptr %t397, %"compiler/source:Span" %t398, %"compiler/diagmsg:Msg" %t399)
  store i64 %t400, ptr %l214
  br label %bb129
bb129:
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t402 = load %"compiler/source:Span", ptr %l1
  %t405 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t401, %"compiler/source:Span" %t402)
  store ptr %t405, ptr %l217
  br label %bb130
bb130:
  call void @__olang_scope_close(ptr %s9)
  %t406 = load ptr, ptr %l217, !tbaa !29
  store ptr %t406, ptr %rv
  br label %ret
bb131:
  %t407 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t409 = trunc i64 78 to i32
  %t410 = icmp eq i32 %t407, %t409
  %t412 = xor i1 %t410, true
  br i1 %t412, label %bb132, label %bb133
bb132:
  %t414 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t416 = trunc i64 79 to i32
  %t417 = icmp eq i32 %t414, %t416
  %t419 = xor i1 %t417, true
  store i1 %t419, ptr %l221, !tbaa !21
  br label %bb134
bb133:
  store i1 false, ptr %l221, !tbaa !21
  br label %bb134
bb134:
  %t421 = load i1, ptr %l221, !tbaa !21
  br i1 %t421, label %bb135, label %bb136
bb135:
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t423 = load %"compiler/source:Span", ptr %l1
  %t424 = load %"compiler/source:Span", ptr %l2
  %t425 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t426 = load ptr, ptr %l4, !tbaa !29
  %t427 = load ptr, ptr %l5, !tbaa !29
  %t428 = load ptr, ptr @__olang_prog_scope
  %t429 = load ptr, ptr @__olang_prog_scope
  %t436 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorCall(ptr %v0, ptr %t428, ptr %t429, ptr %v3, ptr %t422, %"compiler/source:Span" %t423, %"compiler/source:Span" %t424, i32 %t425, ptr %t426, ptr %t427)
  store ptr %t436, ptr %l231
  br label %bb137
bb136:
  br label %bb145
bb137:
  %t437 = load ptr, ptr %l231, !tbaa !29
  store ptr %t437, ptr %l12, !tbaa !29
  %t438 = load ptr, ptr %l12, !tbaa !29
  %t440 = icmp eq ptr %t438, null
  %t442 = xor i1 %t440, true
  br i1 %t442, label %bb138, label %bb139
bb138:
  %t444 = load ptr, ptr %l12, !tbaa !29
  store ptr %t444, ptr %rv
  br label %ret
bb139:
  br label %bb140
bb140:
  %t446 = load ptr, ptr %l0, !tbaa !29
  %t447 = load %"compiler/source:Span", ptr %l1
  %t448 = load %"compiler/source:Span", ptr %l2
  %t449 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t450 = load ptr, ptr %l4, !tbaa !29
  %t451 = load ptr, ptr %l5, !tbaa !29
  %t452 = load ptr, ptr @__olang_prog_scope
  %t453 = load ptr, ptr @__olang_prog_scope
  %t460 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecommutedCall(ptr %v0, ptr %t452, ptr %t453, ptr %v3, ptr %t446, %"compiler/source:Span" %t447, %"compiler/source:Span" %t448, i32 %t449, ptr %t450, ptr %t451)
  store ptr %t460, ptr %l242
  br label %bb141
bb141:
  %t461 = load ptr, ptr %l242, !tbaa !29
  store ptr %t461, ptr %l13, !tbaa !29
  %t462 = load ptr, ptr %l13, !tbaa !29
  %t464 = icmp eq ptr %t462, null
  %t466 = xor i1 %t464, true
  br i1 %t466, label %bb142, label %bb143
bb142:
  %t468 = load ptr, ptr %l13, !tbaa !29
  store ptr %t468, ptr %rv
  br label %ret
bb143:
  br label %bb144
bb144:
  br label %bb145
bb145:
  %t470 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t472 = trunc i64 58 to i32
  %t473 = icmp eq i32 %t470, %t472
  br i1 %t473, label %bb146, label %bb147
bb146:
  store %olang.scope zeroinitializer, ptr %s13
  %t475 = load ptr, ptr %l0, !tbaa !29
  store ptr %t475, ptr %l249, !tbaa !29
  %t476 = load ptr, ptr %l0, !tbaa !29
  %t477 = load i32, ptr %l8, !tbaa !23
  %t480 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t476, i32 %t477)
  store i32 %t480, ptr %l252
  br label %bb148
bb147:
  br label %bb157
bb148:
  %t481 = load %"compiler/source:Span", ptr %l2
  %t482 = load ptr, ptr %l249, !tbaa !29
  %t483 = load i32, ptr %l252, !tbaa !23
  %t485 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %s13, ptr %s13, ptr %t482, i32 %t483, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d24, i32 0, i32 1) }, %"compiler/source:Span" %t481, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d25, i32 0, i32 1) }, i64 1, i1 false)
  store i1 %t485, ptr %l254
  br label %bb149
bb149:
  %t486 = load i1, ptr %l254, !tbaa !21
  %t487 = xor i1 %t486, true
  br i1 %t487, label %bb150, label %bb151
bb150:
  store %olang.scope zeroinitializer, ptr %s14
  %t489 = load ptr, ptr %l0, !tbaa !29
  store ptr %t489, ptr %l256, !tbaa !29
  %t490 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t490, ptr %l257
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t492 = load i32, ptr %l8, !tbaa !23
  %t495 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s14, ptr %t491, i32 %t492)
  store { i64, ptr } %t495, ptr %l260
  br label %bb152
bb151:
  br label %bb155
bb152:
  %t496 = load { i64, ptr }, ptr %l260, !tbaa !27
  %t497 = extractvalue { i64, ptr } %t496, 0
  %t498 = extractvalue { i64, ptr } %t496, 1
  %t499 = mul i64 %t497, 1
  %t500 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t499)
  call void @llvm.memcpy.p0.p0.i64(ptr %t500, ptr %t498, i64 %t499, i1 false)
  %t501 = insertvalue { i64, ptr } undef, i64 %t497, 0
  %t502 = insertvalue { i64, ptr } %t501, ptr %t500, 1
  %t504 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMatmulUndeclared(ptr %s14, ptr %s14, { i64, ptr } %t502)
  store %"compiler/diagmsg:Msg" %t504, ptr %l262
  br label %bb153
bb153:
  %t505 = load ptr, ptr %l256, !tbaa !29
  %t506 = load %"compiler/source:Span", ptr %l257
  %t507 = load %"compiler/diagmsg:Msg", ptr %l262
  %t508 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s14, ptr %t505, %"compiler/source:Span" %t506, %"compiler/diagmsg:Msg" %t507)
  store i64 %t508, ptr %l263
  br label %bb154
bb154:
  call void @__olang_scope_close(ptr %s14)
  br label %bb155
bb155:
  %t509 = load ptr, ptr %l0, !tbaa !29
  %t510 = load %"compiler/source:Span", ptr %l1
  %t513 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t509, %"compiler/source:Span" %t510)
  store ptr %t513, ptr %l266
  br label %bb156
bb156:
  call void @__olang_scope_close(ptr %s13)
  %t514 = load ptr, ptr %l266, !tbaa !29
  store ptr %t514, ptr %rv
  br label %ret
bb157:
  %t515 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t517 = trunc i64 78 to i32
  %t518 = icmp eq i32 %t515, %t517
  br i1 %t518, label %bb158, label %bb159
bb158:
  store i1 true, ptr %l269, !tbaa !21
  br label %bb160
bb159:
  %t520 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t522 = trunc i64 79 to i32
  %t523 = icmp eq i32 %t520, %t522
  store i1 %t523, ptr %l269, !tbaa !21
  br label %bb160
bb160:
  %t525 = load i1, ptr %l269, !tbaa !21
  br i1 %t525, label %bb161, label %bb162
bb161:
  %t526 = load ptr, ptr %l0, !tbaa !29
  %t527 = load i32, ptr %l8, !tbaa !23
  %t530 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t526, i32 %t527)
  store i1 %t530, ptr %l275
  br label %bb163
bb162:
  store i1 false, ptr %l272, !tbaa !21
  br label %bb164
bb163:
  %t531 = load i1, ptr %l275, !tbaa !21
  store i1 %t531, ptr %l272, !tbaa !21
  br label %bb164
bb164:
  %t532 = load i1, ptr %l272, !tbaa !21
  br i1 %t532, label %bb165, label %bb166
bb165:
  %t533 = load ptr, ptr %l0, !tbaa !29
  %t535 = getelementptr %"compiler/check:Checker", ptr %t533, i32 0, i32 1
  %t536 = load ptr, ptr %t535, !tbaa !29
  %t538 = getelementptr %"compiler/generic:Program", ptr %t536, i32 0, i32 2
  %t539 = load i32, ptr %l8, !tbaa !23
  %t540 = load i32, ptr %l9, !tbaa !23
  %t544 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t538, i32 %t539, i32 %t540)
  store i1 %t544, ptr %l282
  br label %bb167
bb166:
  store i1 false, ptr %l276, !tbaa !21
  br label %bb168
bb167:
  %t545 = load i1, ptr %l282, !tbaa !21
  store i1 %t545, ptr %l276, !tbaa !21
  br label %bb168
bb168:
  %t546 = load i1, ptr %l276, !tbaa !21
  br i1 %t546, label %bb169, label %bb170
bb169:
  %t547 = load ptr, ptr %l0, !tbaa !29
  %t548 = load i32, ptr %l8, !tbaa !23
  %t551 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeqMethod(ptr %v0, ptr %t547, i32 %t548)
  store i64 %t551, ptr %l286
  br label %bb171
bb170:
  store i1 false, ptr %l283, !tbaa !21
  br label %bb172
bb171:
  %t552 = load i64, ptr %l286, !tbaa !24
  %t553 = icmp ne i64 %t552, -1
  store i1 %t553, ptr %l283, !tbaa !21
  br label %bb172
bb172:
  %t555 = load i1, ptr %l283, !tbaa !21
  store i1 %t555, ptr %l14, !tbaa !21
  %t556 = load ptr, ptr %l0, !tbaa !29
  %t557 = load i32, ptr %l8, !tbaa !23
  %t560 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t556, i32 %t557)
  store i1 %t560, ptr %l290
  br label %bb173
bb173:
  %t561 = load i1, ptr %l290, !tbaa !21
  %t562 = xor i1 %t561, true
  br i1 %t562, label %bb174, label %bb175
bb174:
  store i1 true, ptr %l292, !tbaa !21
  br label %bb177
bb175:
  %t564 = load ptr, ptr %l0, !tbaa !29
  %t565 = load i32, ptr %l9, !tbaa !23
  %t568 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t564, i32 %t565)
  store i1 %t568, ptr %l295
  br label %bb176
bb176:
  %t569 = load i1, ptr %l295, !tbaa !21
  %t570 = xor i1 %t569, true
  store i1 %t570, ptr %l292, !tbaa !21
  br label %bb177
bb177:
  %t572 = load i1, ptr %l292, !tbaa !21
  br i1 %t572, label %bb178, label %bb179
bb178:
  store i1 true, ptr %l297, !tbaa !21
  br label %bb180
bb179:
  %t573 = load i1, ptr %l14, !tbaa !21
  store i1 %t573, ptr %l297, !tbaa !21
  br label %bb180
bb180:
  %t575 = load i1, ptr %l297, !tbaa !21
  br i1 %t575, label %bb181, label %bb182
bb181:
  store %olang.scope zeroinitializer, ptr %s15
  %t576 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t578 = trunc i64 78 to i32
  %t579 = icmp eq i32 %t576, %t578
  br i1 %t579, label %bb183, label %bb184
bb182:
  br label %bb225
bb183:
  store i1 true, ptr %l301, !tbaa !21
  br label %bb185
bb184:
  %t581 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t583 = trunc i64 79 to i32
  %t584 = icmp eq i32 %t581, %t583
  store i1 %t584, ptr %l301, !tbaa !21
  br label %bb185
bb185:
  %t586 = load i1, ptr %l301, !tbaa !21
  br i1 %t586, label %bb186, label %bb187
bb186:
  %t587 = load ptr, ptr %l0, !tbaa !29
  %t589 = getelementptr %"compiler/check:Checker", ptr %t587, i32 0, i32 45
  %t590 = load %"compiler/source:Span", ptr %t589
  store %"compiler/source:Span" %t590, ptr %l15
  %t592 = load ptr, ptr %l0, !tbaa !29
  %t593 = load %"compiler/source:Span", ptr %l2
  %t596 = getelementptr %"compiler/check:Checker", ptr %t592, i32 0, i32 45
  store %"compiler/source:Span" %t593, ptr %t596
  %t597 = load ptr, ptr %l0, !tbaa !29
  %t598 = load %"compiler/source:Span", ptr %l1
  %t599 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t600 = load ptr, ptr %l4, !tbaa !29
  %t601 = load ptr, ptr %l5, !tbaa !29
  %t602 = load ptr, ptr @__olang_prog_scope
  %t603 = load ptr, ptr @__olang_prog_scope
  %t609 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eequality(ptr %v0, ptr %t602, ptr %t603, ptr %v3, ptr %t597, %"compiler/source:Span" %t598, i32 %t599, ptr %t600, ptr %t601)
  store ptr %t609, ptr %l313
  br label %bb188
bb187:
  br label %bb189
bb188:
  %t610 = load ptr, ptr %l313, !tbaa !29
  %t611 = load ptr, ptr %l0, !tbaa !29
  %t612 = load %"compiler/source:Span", ptr %l15
  %t615 = getelementptr %"compiler/check:Checker", ptr %t611, i32 0, i32 45
  store %"compiler/source:Span" %t612, ptr %t615
  call void @__olang_scope_close(ptr %s15)
  store ptr %t610, ptr %rv
  br label %ret
bb189:
  %t618 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t620 = call { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %s15, i32 %t618)
  store { i64, ptr } %t620, ptr %l318
  br label %bb190
bb190:
  %t621 = load { i64, ptr }, ptr %l318, !tbaa !27
  %t622 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s15, ptr %s15, { i64, ptr } %t621, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d26, i32 0, i32 1) })
  store i1 %t622, ptr %l319
  br label %bb191
bb191:
  %t623 = load i1, ptr %l319, !tbaa !21
  %t624 = xor i1 %t623, true
  br i1 %t624, label %bb192, label %bb193
bb192:
  %t626 = load ptr, ptr %l0, !tbaa !29
  store ptr %t626, ptr %l322, !tbaa !29
  %t627 = load ptr, ptr %l0, !tbaa !29
  %t628 = load i32, ptr %l8, !tbaa !23
  %t631 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t627, i32 %t628)
  store i32 %t631, ptr %l325
  br label %bb194
bb193:
  store i1 false, ptr %l321, !tbaa !21
  br label %bb199
bb194:
  %t632 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t634 = call { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %s15, i32 %t632)
  store { i64, ptr } %t634, ptr %l327
  br label %bb195
bb195:
  %t635 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t635, ptr %l328
  %t636 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t638 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s15, i32 %t636)
  store { i64, ptr } %t638, ptr %l330
  br label %bb196
bb196:
  %t639 = load { i64, ptr }, ptr %l330, !tbaa !27
  %t640 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s15, ptr %s15, { i64, ptr } %t639)
  store { i64, ptr } %t640, ptr %l331
  br label %bb197
bb197:
  %t641 = load { i64, ptr }, ptr %l331, !tbaa !27
  %t642 = extractvalue { i64, ptr } %t641, 0
  %t643 = extractvalue { i64, ptr } %t641, 1
  %t644 = mul i64 %t642, 1
  %t645 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t644)
  call void @llvm.memcpy.p0.p0.i64(ptr %t645, ptr %t643, i64 %t644, i1 false)
  %t646 = insertvalue { i64, ptr } undef, i64 %t642, 0
  %t647 = insertvalue { i64, ptr } %t646, ptr %t645, 1
  %t648 = load ptr, ptr %l322, !tbaa !29
  %t649 = load i32, ptr %l325, !tbaa !23
  %t650 = load { i64, ptr }, ptr %l327, !tbaa !27
  %t651 = load %"compiler/source:Span", ptr %l328
  %t653 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %s15, ptr %s15, ptr %t648, i32 %t649, { i64, ptr } %t650, %"compiler/source:Span" %t651, { i64, ptr } %t647, i64 1, i1 false)
  store i1 %t653, ptr %l333
  br label %bb198
bb198:
  %t654 = load i1, ptr %l333, !tbaa !21
  store i1 %t654, ptr %l321, !tbaa !21
  br label %bb199
bb199:
  %t655 = load i1, ptr %l321, !tbaa !21
  br i1 %t655, label %bb200, label %bb201
bb200:
  %t656 = load ptr, ptr %l0, !tbaa !29
  %t657 = load %"compiler/source:Span", ptr %l1
  %t660 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t656, %"compiler/source:Span" %t657)
  store ptr %t660, ptr %l336
  br label %bb202
bb201:
  br label %bb203
bb202:
  call void @__olang_scope_close(ptr %s15)
  %t661 = load ptr, ptr %l336, !tbaa !29
  store ptr %t661, ptr %rv
  br label %ret
bb203:
  %t662 = load ptr, ptr %l0, !tbaa !29
  %t663 = load i32, ptr %l8, !tbaa !23
  %t666 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t662, i32 %t663)
  store i1 %t666, ptr %l339
  br label %bb204
bb204:
  %t667 = load i1, ptr %l339, !tbaa !21
  br i1 %t667, label %bb205, label %bb206
bb205:
  store i1 true, ptr %l340, !tbaa !21
  br label %bb208
bb206:
  %t668 = load ptr, ptr %l0, !tbaa !29
  %t669 = load i32, ptr %l9, !tbaa !23
  %t672 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t668, i32 %t669)
  store i1 %t672, ptr %l343
  br label %bb207
bb207:
  %t673 = load i1, ptr %l343, !tbaa !21
  store i1 %t673, ptr %l340, !tbaa !21
  br label %bb208
bb208:
  %t674 = load i1, ptr %l340, !tbaa !21
  br i1 %t674, label %bb209, label %bb210
bb209:
  store %olang.scope zeroinitializer, ptr %s18
  %t675 = load ptr, ptr %l0, !tbaa !29
  store ptr %t675, ptr %l344, !tbaa !29
  %t676 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t676, ptr %l345
  %t677 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t679 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s18, i32 %t677)
  store { i64, ptr } %t679, ptr %l347
  br label %bb211
bb210:
  store %olang.scope zeroinitializer, ptr %s19
  %t680 = load ptr, ptr %l0, !tbaa !29
  store ptr %t680, ptr %l360, !tbaa !29
  %t681 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t681, ptr %l361
  %t682 = load i32, ptr %l8, !tbaa !23
  store i32 %t682, ptr %l362, !tbaa !23
  %t683 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t685 = call { i64, ptr } @compiler_2fcheck_2eopNeed(ptr %s19, i32 %t683)
  store { i64, ptr } %t685, ptr %l364
  br label %bb217
bb211:
  %t686 = load { i64, ptr }, ptr %l347, !tbaa !27
  %t687 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s18, ptr %s18, { i64, ptr } %t686)
  store { i64, ptr } %t687, ptr %l348
  br label %bb212
bb212:
  %t688 = load { i64, ptr }, ptr %l348, !tbaa !27
  %t689 = extractvalue { i64, ptr } %t688, 0
  %t690 = extractvalue { i64, ptr } %t688, 1
  %t691 = mul i64 %t689, 1
  %t692 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t691)
  call void @llvm.memcpy.p0.p0.i64(ptr %t692, ptr %t690, i64 %t691, i1 false)
  %t693 = insertvalue { i64, ptr } undef, i64 %t689, 0
  %t694 = insertvalue { i64, ptr } %t693, ptr %t692, 1
  store { i64, ptr } %t694, ptr %l349, !tbaa !27
  %t695 = load ptr, ptr %l0, !tbaa !29
  %t696 = load i32, ptr %l8, !tbaa !23
  %t699 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s18, ptr %t695, i32 %t696)
  store { i64, ptr } %t699, ptr %l352
  br label %bb213
bb213:
  %t700 = load { i64, ptr }, ptr %l352, !tbaa !27
  %t701 = extractvalue { i64, ptr } %t700, 0
  %t702 = extractvalue { i64, ptr } %t700, 1
  %t703 = mul i64 %t701, 1
  %t704 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t703)
  call void @llvm.memcpy.p0.p0.i64(ptr %t704, ptr %t702, i64 %t703, i1 false)
  %t705 = insertvalue { i64, ptr } undef, i64 %t701, 0
  %t706 = insertvalue { i64, ptr } %t705, ptr %t704, 1
  store { i64, ptr } %t706, ptr %l353, !tbaa !27
  %t707 = load ptr, ptr %l0, !tbaa !29
  %t708 = load i32, ptr %l9, !tbaa !23
  %t711 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s18, ptr %t707, i32 %t708)
  store { i64, ptr } %t711, ptr %l356
  br label %bb214
bb214:
  %t712 = load { i64, ptr }, ptr %l356, !tbaa !27
  %t713 = extractvalue { i64, ptr } %t712, 0
  %t714 = extractvalue { i64, ptr } %t712, 1
  %t715 = mul i64 %t713, 1
  %t716 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t715)
  call void @llvm.memcpy.p0.p0.i64(ptr %t716, ptr %t714, i64 %t715, i1 false)
  %t717 = insertvalue { i64, ptr } undef, i64 %t713, 0
  %t718 = insertvalue { i64, ptr } %t717, ptr %t716, 1
  %t719 = load { i64, ptr }, ptr %l349, !tbaa !27
  %t720 = load { i64, ptr }, ptr %l353, !tbaa !27
  %t722 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOperandsDiffer(ptr %s18, ptr %s18, ptr %s18, ptr %s18, { i64, ptr } %t719, { i64, ptr } %t720, { i64, ptr } %t718)
  store %"compiler/diagmsg:Msg" %t722, ptr %l358
  br label %bb215
bb215:
  %t723 = load ptr, ptr %l344, !tbaa !29
  %t724 = load %"compiler/source:Span", ptr %l345
  %t725 = load %"compiler/diagmsg:Msg", ptr %l358
  %t726 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s18, ptr %t723, %"compiler/source:Span" %t724, %"compiler/diagmsg:Msg" %t725)
  store i64 %t726, ptr %l359
  br label %bb216
bb216:
  call void @__olang_scope_close(ptr %s18)
  br label %bb223
bb217:
  %t727 = load { i64, ptr }, ptr %l364, !tbaa !27
  %t728 = extractvalue { i64, ptr } %t727, 0
  %t729 = extractvalue { i64, ptr } %t727, 1
  %t730 = mul i64 %t728, 1
  %t731 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t730)
  call void @llvm.memcpy.p0.p0.i64(ptr %t731, ptr %t729, i64 %t730, i1 false)
  %t732 = insertvalue { i64, ptr } undef, i64 %t728, 0
  %t733 = insertvalue { i64, ptr } %t732, ptr %t731, 1
  store { i64, ptr } %t733, ptr %l365, !tbaa !27
  %t734 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t736 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s19, i32 %t734)
  store { i64, ptr } %t736, ptr %l367
  br label %bb218
bb218:
  %t737 = load { i64, ptr }, ptr %l367, !tbaa !27
  %t738 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s19, ptr %s19, { i64, ptr } %t737)
  store { i64, ptr } %t738, ptr %l368
  br label %bb219
bb219:
  %t739 = load { i64, ptr }, ptr %l368, !tbaa !27
  %t740 = extractvalue { i64, ptr } %t739, 0
  %t741 = extractvalue { i64, ptr } %t739, 1
  %t742 = mul i64 %t740, 1
  %t743 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t742)
  call void @llvm.memcpy.p0.p0.i64(ptr %t743, ptr %t741, i64 %t742, i1 false)
  %t744 = insertvalue { i64, ptr } undef, i64 %t740, 0
  %t745 = insertvalue { i64, ptr } %t744, ptr %t743, 1
  store { i64, ptr } %t745, ptr %l369, !tbaa !27
  %t746 = load ptr, ptr %l0, !tbaa !29
  %t747 = load i32, ptr %l8, !tbaa !23
  %t750 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s19, ptr %t746, i32 %t747)
  store { i64, ptr } %t750, ptr %l372
  br label %bb220
bb220:
  %t751 = load { i64, ptr }, ptr %l372, !tbaa !27
  %t752 = extractvalue { i64, ptr } %t751, 0
  %t753 = extractvalue { i64, ptr } %t751, 1
  %t754 = mul i64 %t752, 1
  %t755 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t754)
  call void @llvm.memcpy.p0.p0.i64(ptr %t755, ptr %t753, i64 %t754, i1 false)
  %t756 = insertvalue { i64, ptr } undef, i64 %t752, 0
  %t757 = insertvalue { i64, ptr } %t756, ptr %t755, 1
  %t758 = load { i64, ptr }, ptr %l369, !tbaa !27
  %t760 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOperandNotNumber(ptr %s19, ptr %s19, ptr %s19, { i64, ptr } %t758, { i64, ptr } %t757)
  store %"compiler/diagmsg:Msg" %t760, ptr %l374
  br label %bb221
bb221:
  %t761 = load ptr, ptr %l360, !tbaa !29
  %t762 = load %"compiler/source:Span", ptr %l361
  %t763 = load i32, ptr %l362, !tbaa !23
  %t764 = load { i64, ptr }, ptr %l365, !tbaa !27
  %t765 = load %"compiler/diagmsg:Msg", ptr %l374
  %t766 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedErr(ptr %v0, ptr %s19, ptr %s19, ptr %t761, %"compiler/source:Span" %t762, i32 %t763, { i64, ptr } %t764, %"compiler/diagmsg:Msg" %t765)
  store i64 %t766, ptr %l375
  br label %bb222
bb222:
  call void @__olang_scope_close(ptr %s19)
  br label %bb223
bb223:
  %t767 = load ptr, ptr %l0, !tbaa !29
  %t768 = load %"compiler/source:Span", ptr %l1
  %t771 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t767, %"compiler/source:Span" %t768)
  store ptr %t771, ptr %l378
  br label %bb224
bb224:
  call void @__olang_scope_close(ptr %s15)
  %t772 = load ptr, ptr %l378, !tbaa !29
  store ptr %t772, ptr %rv
  br label %ret
bb225:
  %t773 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t775 = trunc i64 90 to i32
  %t776 = icmp eq i32 %t773, %t775
  br i1 %t776, label %bb226, label %bb227
bb226:
  store i1 true, ptr %l381, !tbaa !21
  br label %bb228
bb227:
  %t778 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t780 = trunc i64 91 to i32
  %t781 = icmp eq i32 %t778, %t780
  store i1 %t781, ptr %l381, !tbaa !21
  br label %bb228
bb228:
  %t783 = load i1, ptr %l381, !tbaa !21
  br i1 %t783, label %bb229, label %bb230
bb229:
  %t784 = load ptr, ptr %l0, !tbaa !29
  %t785 = load i32, ptr %l8, !tbaa !23
  %t788 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %t784, i32 %t785)
  store i1 %t788, ptr %l386
  br label %bb231
bb230:
  br label %bb275
bb231:
  %t789 = load i1, ptr %l386, !tbaa !21
  %t790 = xor i1 %t789, true
  br i1 %t790, label %bb232, label %bb233
bb232:
  store %olang.scope zeroinitializer, ptr %s21
  %t792 = load ptr, ptr %l0, !tbaa !29
  store ptr %t792, ptr %l388, !tbaa !29
  %t793 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t793, ptr %l389
  %t794 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t796 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s21, i32 %t794)
  store { i64, ptr } %t796, ptr %l391
  br label %bb234
bb233:
  br label %bb239
bb234:
  %t797 = load { i64, ptr }, ptr %l391, !tbaa !27
  %t798 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s21, ptr %s21, { i64, ptr } %t797)
  store { i64, ptr } %t798, ptr %l392
  br label %bb235
bb235:
  %t799 = load { i64, ptr }, ptr %l392, !tbaa !27
  %t800 = extractvalue { i64, ptr } %t799, 0
  %t801 = extractvalue { i64, ptr } %t799, 1
  %t802 = mul i64 %t800, 1
  %t803 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t802)
  call void @llvm.memcpy.p0.p0.i64(ptr %t803, ptr %t801, i64 %t802, i1 false)
  %t804 = insertvalue { i64, ptr } undef, i64 %t800, 0
  %t805 = insertvalue { i64, ptr } %t804, ptr %t803, 1
  store { i64, ptr } %t805, ptr %l393, !tbaa !27
  %t806 = load ptr, ptr %l0, !tbaa !29
  %t807 = load i32, ptr %l8, !tbaa !23
  %t810 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s21, ptr %t806, i32 %t807)
  store { i64, ptr } %t810, ptr %l396
  br label %bb236
bb236:
  %t811 = load { i64, ptr }, ptr %l396, !tbaa !27
  %t812 = extractvalue { i64, ptr } %t811, 0
  %t813 = extractvalue { i64, ptr } %t811, 1
  %t814 = mul i64 %t812, 1
  %t815 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t814)
  call void @llvm.memcpy.p0.p0.i64(ptr %t815, ptr %t813, i64 %t814, i1 false)
  %t816 = insertvalue { i64, ptr } undef, i64 %t812, 0
  %t817 = insertvalue { i64, ptr } %t816, ptr %t815, 1
  %t818 = load { i64, ptr }, ptr %l393, !tbaa !27
  %t820 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOperandNotInt(ptr %s21, ptr %s21, ptr %s21, { i64, ptr } %t818, { i64, ptr } %t817)
  store %"compiler/diagmsg:Msg" %t820, ptr %l398
  br label %bb237
bb237:
  %t821 = load ptr, ptr %l388, !tbaa !29
  %t822 = load %"compiler/source:Span", ptr %l389
  %t823 = load %"compiler/diagmsg:Msg", ptr %l398
  %t824 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s21, ptr %t821, %"compiler/source:Span" %t822, %"compiler/diagmsg:Msg" %t823)
  store i64 %t824, ptr %l399
  br label %bb238
bb238:
  call void @__olang_scope_close(ptr %s21)
  br label %bb239
bb239:
  %t825 = load ptr, ptr %l0, !tbaa !29
  %t826 = load i32, ptr %l9, !tbaa !23
  %t829 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %t825, i32 %t826)
  store i1 %t829, ptr %l402
  br label %bb240
bb240:
  %t830 = load i1, ptr %l402, !tbaa !21
  %t831 = xor i1 %t830, true
  br i1 %t831, label %bb241, label %bb242
bb241:
  store %olang.scope zeroinitializer, ptr %s22
  %t833 = load ptr, ptr %l0, !tbaa !29
  store ptr %t833, ptr %l404, !tbaa !29
  %t834 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t834, ptr %l405
  %t835 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t837 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s22, i32 %t835)
  store { i64, ptr } %t837, ptr %l407
  br label %bb243
bb242:
  br label %bb248
bb243:
  %t838 = load { i64, ptr }, ptr %l407, !tbaa !27
  %t839 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s22, ptr %s22, { i64, ptr } %t838)
  store { i64, ptr } %t839, ptr %l408
  br label %bb244
bb244:
  %t840 = load { i64, ptr }, ptr %l408, !tbaa !27
  %t841 = extractvalue { i64, ptr } %t840, 0
  %t842 = extractvalue { i64, ptr } %t840, 1
  %t843 = mul i64 %t841, 1
  %t844 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t843)
  call void @llvm.memcpy.p0.p0.i64(ptr %t844, ptr %t842, i64 %t843, i1 false)
  %t845 = insertvalue { i64, ptr } undef, i64 %t841, 0
  %t846 = insertvalue { i64, ptr } %t845, ptr %t844, 1
  store { i64, ptr } %t846, ptr %l409, !tbaa !27
  %t847 = load ptr, ptr %l0, !tbaa !29
  %t848 = load i32, ptr %l9, !tbaa !23
  %t851 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s22, ptr %t847, i32 %t848)
  store { i64, ptr } %t851, ptr %l412
  br label %bb245
bb245:
  %t852 = load { i64, ptr }, ptr %l412, !tbaa !27
  %t853 = extractvalue { i64, ptr } %t852, 0
  %t854 = extractvalue { i64, ptr } %t852, 1
  %t855 = mul i64 %t853, 1
  %t856 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t855)
  call void @llvm.memcpy.p0.p0.i64(ptr %t856, ptr %t854, i64 %t855, i1 false)
  %t857 = insertvalue { i64, ptr } undef, i64 %t853, 0
  %t858 = insertvalue { i64, ptr } %t857, ptr %t856, 1
  %t859 = load { i64, ptr }, ptr %l409, !tbaa !27
  %t861 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOperandNotInt(ptr %s22, ptr %s22, ptr %s22, { i64, ptr } %t859, { i64, ptr } %t858)
  store %"compiler/diagmsg:Msg" %t861, ptr %l414
  br label %bb246
bb246:
  %t862 = load ptr, ptr %l404, !tbaa !29
  %t863 = load %"compiler/source:Span", ptr %l405
  %t864 = load %"compiler/diagmsg:Msg", ptr %l414
  %t865 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s22, ptr %t862, %"compiler/source:Span" %t863, %"compiler/diagmsg:Msg" %t864)
  store i64 %t865, ptr %l415
  br label %bb247
bb247:
  call void @__olang_scope_close(ptr %s22)
  br label %bb248
bb248:
  %t866 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t868 = call i1 @compiler_2fcheck_2ecompares(i32 %t866)
  store i1 %t868, ptr %l417
  br label %bb249
bb249:
  %t869 = load i1, ptr %l417, !tbaa !21
  %t870 = xor i1 %t869, true
  br i1 %t870, label %bb250, label %bb251
bb250:
  %t872 = load ptr, ptr %l0, !tbaa !29
  %t873 = load i32, ptr %l8, !tbaa !23
  %t876 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t872, i32 %t873)
  store i1 %t876, ptr %l422
  br label %bb252
bb251:
  store i1 false, ptr %l419, !tbaa !21
  br label %bb253
bb252:
  %t877 = load i1, ptr %l422, !tbaa !21
  store i1 %t877, ptr %l419, !tbaa !21
  br label %bb253
bb253:
  %t878 = load i1, ptr %l419, !tbaa !21
  br i1 %t878, label %bb254, label %bb255
bb254:
  %t879 = load ptr, ptr %l0, !tbaa !29
  %t881 = getelementptr %"compiler/check:Checker", ptr %t879, i32 0, i32 1
  %t882 = load ptr, ptr %t881, !tbaa !29
  %t883 = load i32, ptr %l8, !tbaa !23
  %t886 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t882, i32 %t883)
  store i1 %t886, ptr %l427
  br label %bb256
bb255:
  store i1 false, ptr %l423, !tbaa !21
  br label %bb257
bb256:
  %t887 = load i1, ptr %l427, !tbaa !21
  %t888 = xor i1 %t887, true
  store i1 %t888, ptr %l423, !tbaa !21
  br label %bb257
bb257:
  %t890 = load i1, ptr %l423, !tbaa !21
  br i1 %t890, label %bb258, label %bb259
bb258:
  store %olang.scope zeroinitializer, ptr %s23
  %t891 = load ptr, ptr %l0, !tbaa !29
  store ptr %t891, ptr %l429, !tbaa !29
  %t892 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t892, ptr %l430
  %t893 = load ptr, ptr %l0, !tbaa !29
  %t894 = load i32, ptr %l8, !tbaa !23
  %t897 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s23, ptr %t893, i32 %t894)
  store { i64, ptr } %t897, ptr %l433
  br label %bb260
bb259:
  br label %bb267
bb260:
  %t898 = load { i64, ptr }, ptr %l433, !tbaa !27
  %t899 = extractvalue { i64, ptr } %t898, 0
  %t900 = extractvalue { i64, ptr } %t898, 1
  %t901 = mul i64 %t899, 1
  %t902 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t901)
  call void @llvm.memcpy.p0.p0.i64(ptr %t902, ptr %t900, i64 %t901, i1 false)
  %t903 = insertvalue { i64, ptr } undef, i64 %t899, 0
  %t904 = insertvalue { i64, ptr } %t903, ptr %t902, 1
  store { i64, ptr } %t904, ptr %l434, !tbaa !27
  %t905 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t907 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s23, i32 %t905)
  store { i64, ptr } %t907, ptr %l436
  br label %bb261
bb261:
  %t908 = load { i64, ptr }, ptr %l436, !tbaa !27
  %t909 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s23, ptr %s23, { i64, ptr } %t908)
  store { i64, ptr } %t909, ptr %l437
  br label %bb262
bb262:
  %t910 = load { i64, ptr }, ptr %l437, !tbaa !27
  %t911 = extractvalue { i64, ptr } %t910, 0
  %t912 = extractvalue { i64, ptr } %t910, 1
  %t913 = mul i64 %t911, 1
  %t914 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t913)
  call void @llvm.memcpy.p0.p0.i64(ptr %t914, ptr %t912, i64 %t913, i1 false)
  %t915 = insertvalue { i64, ptr } undef, i64 %t911, 0
  %t916 = insertvalue { i64, ptr } %t915, ptr %t914, 1
  store { i64, ptr } %t916, ptr %l438, !tbaa !27
  %t917 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t919 = call { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %s23, i32 %t917)
  store { i64, ptr } %t919, ptr %l440
  br label %bb263
bb263:
  %t920 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t921 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t922 = load { i64, ptr }, ptr %l440, !tbaa !27
  %t923 = extractvalue { i64, ptr } %t922, 1
  %t924 = extractvalue { i64, ptr } %t922, 0
  %t925 = add i64 %t921, %t924
  %t926 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t927 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t928 = add i64 %t925, %t927
  %t929 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t928)
  call void @olang_textcopy(ptr %t929, ptr %t920, i64 %t921)
  %t930 = getelementptr i8, ptr %t929, i64 %t921
  call void @olang_textcopy(ptr %t930, ptr %t923, i64 %t924)
  %t931 = getelementptr i8, ptr %t930, i64 %t924
  call void @olang_textcopy(ptr %t931, ptr %t926, i64 %t927)
  %t932 = insertvalue { i64, ptr } undef, i64 %t928, 0
  %t933 = insertvalue { i64, ptr } %t932, ptr %t929, 1
  %t935 = extractvalue { i64, ptr } %t933, 0
  %t936 = extractvalue { i64, ptr } %t933, 1
  %t937 = mul i64 %t935, 1
  %t938 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t937)
  call void @llvm.memcpy.p0.p0.i64(ptr %t938, ptr %t936, i64 %t937, i1 false)
  %t939 = insertvalue { i64, ptr } undef, i64 %t935, 0
  %t940 = insertvalue { i64, ptr } %t939, ptr %t938, 1
  %t941 = load { i64, ptr }, ptr %l434, !tbaa !27
  %t942 = load { i64, ptr }, ptr %l438, !tbaa !27
  %t944 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNotExtendedOp(ptr %s23, ptr %s23, ptr %s23, ptr %s23, { i64, ptr } %t941, { i64, ptr } %t942, { i64, ptr } %t940)
  store %"compiler/diagmsg:Msg" %t944, ptr %l443
  br label %bb264
bb264:
  %t945 = load ptr, ptr %l429, !tbaa !29
  %t946 = load %"compiler/source:Span", ptr %l430
  %t947 = load %"compiler/diagmsg:Msg", ptr %l443
  %t948 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s23, ptr %t945, %"compiler/source:Span" %t946, %"compiler/diagmsg:Msg" %t947)
  store i64 %t948, ptr %l444
  br label %bb265
bb265:
  %t949 = load ptr, ptr %l0, !tbaa !29
  %t950 = load %"compiler/source:Span", ptr %l1
  %t953 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t949, %"compiler/source:Span" %t950)
  store ptr %t953, ptr %l447
  br label %bb266
bb266:
  call void @__olang_scope_close(ptr %s23)
  %t954 = load ptr, ptr %l447, !tbaa !29
  store ptr %t954, ptr %rv
  br label %ret
bb267:
  %t955 = load ptr, ptr %l0, !tbaa !29
  %t956 = load i32, ptr %l8, !tbaa !23
  %t957 = load ptr, ptr %l5, !tbaa !29
  %t958 = load %"compiler/source:Span", ptr %l7
  %t959 = load ptr, ptr @__olang_prog_scope
  %t964 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftInRange(ptr %v0, ptr %t959, ptr %t955, i32 %t956, ptr %t957, %"compiler/source:Span" %t958)
  store i1 %t964, ptr %l452
  br label %bb268
bb268:
  %t965 = load i1, ptr %l452, !tbaa !21
  %t966 = xor i1 %t965, true
  br i1 %t966, label %bb269, label %bb270
bb269:
  %t968 = load ptr, ptr %l0, !tbaa !29
  %t969 = load %"compiler/source:Span", ptr %l1
  %t972 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t968, %"compiler/source:Span" %t969)
  store ptr %t972, ptr %l456
  br label %bb271
bb270:
  br label %bb272
bb271:
  %t973 = load ptr, ptr %l456, !tbaa !29
  store ptr %t973, ptr %rv
  br label %ret
bb272:
  %t974 = load ptr, ptr %l0, !tbaa !29
  store ptr %t974, ptr %l457, !tbaa !29
  %t975 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t975, ptr %l458
  %t976 = load i32, ptr %l8, !tbaa !23
  store i32 %t976, ptr %l459, !tbaa !23
  %t977 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t979 = call i32 @compiler_2fcheck_2ebinaryOp(i32 %t977)
  store i32 %t979, ptr %l461
  br label %bb273
bb273:
  %t980 = load ptr, ptr %l4, !tbaa !29
  %t981 = load ptr, ptr %l5, !tbaa !29
  %t982 = load ptr, ptr @__olang_prog_scope
  %t983 = load ptr, ptr @__olang_prog_scope
  %t984 = load ptr, ptr %l457, !tbaa !29
  %t985 = load %"compiler/source:Span", ptr %l458
  %t986 = load i32, ptr %l459, !tbaa !23
  %t987 = load i32, ptr %l461, !range !{i32 0, i32 49}
  %t990 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckedPrim(ptr %v0, ptr %t982, ptr %t983, ptr %v3, ptr %t984, %"compiler/source:Span" %t985, i32 %t986, i32 %t987, ptr %t980, ptr %t981)
  store ptr %t990, ptr %l464
  br label %bb274
bb274:
  %t991 = load ptr, ptr %l464, !tbaa !29
  store ptr %t991, ptr %rv
  br label %ret
bb275:
  %t992 = load i32, ptr %l8, !tbaa !23
  store i32 %t992, ptr %l17, !tbaa !23
  %t994 = load i32, ptr %l8, !tbaa !23
  %t995 = load i32, ptr %l9, !tbaa !23
  %t998 = icmp ne i32 %t994, %t995
  br i1 %t998, label %bb276, label %bb277
bb276:
  %t1000 = load ptr, ptr %l0, !tbaa !29
  %t1002 = getelementptr %"compiler/check:Checker", ptr %t1000, i32 0, i32 1
  %t1003 = load ptr, ptr %t1002, !tbaa !29
  %t1004 = load i32, ptr %l8, !tbaa !23
  %t1005 = load i32, ptr %l9, !tbaa !23
  %t1009 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %t1003, i32 %t1004, i32 %t1005)
  store i32 %t1009, ptr %l473
  br label %bb278
bb277:
  br label %bb295
bb278:
  %t1010 = load i32, ptr %l473, !tbaa !23
  store i32 %t1010, ptr %l17, !tbaa !23
  %t1011 = load i32, ptr %l17, !tbaa !23
  %t1013 = icmp slt i32 %t1011, 0
  br i1 %t1013, label %bb279, label %bb280
bb279:
  store %olang.scope zeroinitializer, ptr %s27
  %t1015 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1015, ptr %l476, !tbaa !29
  %t1016 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t1016, ptr %l477
  %t1017 = load ptr, ptr %l0, !tbaa !29
  %t1018 = load i32, ptr %l8, !tbaa !23
  %t1021 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s27, ptr %t1017, i32 %t1018)
  store { i64, ptr } %t1021, ptr %l480
  br label %bb281
bb280:
  br label %bb286
bb281:
  %t1022 = load { i64, ptr }, ptr %l480, !tbaa !27
  %t1023 = extractvalue { i64, ptr } %t1022, 0
  %t1024 = extractvalue { i64, ptr } %t1022, 1
  %t1025 = mul i64 %t1023, 1
  %t1026 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t1025)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1026, ptr %t1024, i64 %t1025, i1 false)
  %t1027 = insertvalue { i64, ptr } undef, i64 %t1023, 0
  %t1028 = insertvalue { i64, ptr } %t1027, ptr %t1026, 1
  store { i64, ptr } %t1028, ptr %l481, !tbaa !27
  %t1029 = load ptr, ptr %l0, !tbaa !29
  %t1030 = load i32, ptr %l9, !tbaa !23
  %t1033 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s27, ptr %t1029, i32 %t1030)
  store { i64, ptr } %t1033, ptr %l484
  br label %bb282
bb282:
  %t1034 = load { i64, ptr }, ptr %l484, !tbaa !27
  %t1035 = extractvalue { i64, ptr } %t1034, 0
  %t1036 = extractvalue { i64, ptr } %t1034, 1
  %t1037 = mul i64 %t1035, 1
  %t1038 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t1037)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1038, ptr %t1036, i64 %t1037, i1 false)
  %t1039 = insertvalue { i64, ptr } undef, i64 %t1035, 0
  %t1040 = insertvalue { i64, ptr } %t1039, ptr %t1038, 1
  %t1041 = load { i64, ptr }, ptr %l481, !tbaa !27
  %t1043 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNumbersDoNotMeet(ptr %s27, ptr %s27, ptr %s27, { i64, ptr } %t1041, { i64, ptr } %t1040)
  store %"compiler/diagmsg:Msg" %t1043, ptr %l486
  br label %bb283
bb283:
  %t1044 = load ptr, ptr %l476, !tbaa !29
  %t1045 = load %"compiler/source:Span", ptr %l477
  %t1046 = load %"compiler/diagmsg:Msg", ptr %l486
  %t1047 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s27, ptr %t1044, %"compiler/source:Span" %t1045, %"compiler/diagmsg:Msg" %t1046)
  store i64 %t1047, ptr %l487
  br label %bb284
bb284:
  %t1048 = load ptr, ptr %l0, !tbaa !29
  %t1049 = load %"compiler/source:Span", ptr %l1
  %t1052 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t1048, %"compiler/source:Span" %t1049)
  store ptr %t1052, ptr %l490
  br label %bb285
bb285:
  call void @__olang_scope_close(ptr %s27)
  %t1053 = load ptr, ptr %l490, !tbaa !29
  store ptr %t1053, ptr %rv
  br label %ret
bb286:
  %t1054 = load i32, ptr %l17, !tbaa !23
  %t1055 = load i32, ptr %l8, !tbaa !23
  %t1058 = icmp ne i32 %t1054, %t1055
  br i1 %t1058, label %bb287, label %bb288
bb287:
  %t1060 = load ptr, ptr %l0, !tbaa !29
  %t1062 = load ptr, ptr %l4, !tbaa !29
  %t1063 = load i32, ptr %l17, !tbaa !23
  %t1064 = load ptr, ptr @__olang_prog_scope
  %t1069 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t1064, ptr %v0, ptr %t1060, %"compiler/source:Span" %a6, ptr %t1062, i32 %t1063)
  store ptr %t1069, ptr %l498
  br label %bb289
bb288:
  br label %bb290
bb289:
  %t1070 = load ptr, ptr %l498, !tbaa !29
  store ptr %t1070, ptr %l4, !tbaa !29
  br label %bb290
bb290:
  %t1071 = load i32, ptr %l17, !tbaa !23
  %t1072 = load i32, ptr %l9, !tbaa !23
  %t1075 = icmp ne i32 %t1071, %t1072
  br i1 %t1075, label %bb291, label %bb292
bb291:
  %t1077 = load ptr, ptr %l0, !tbaa !29
  %t1078 = load %"compiler/source:Span", ptr %l7
  %t1079 = load ptr, ptr %l5, !tbaa !29
  %t1080 = load i32, ptr %l17, !tbaa !23
  %t1081 = load ptr, ptr @__olang_prog_scope
  %t1086 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t1081, ptr %v0, ptr %t1077, %"compiler/source:Span" %t1078, ptr %t1079, i32 %t1080)
  store ptr %t1086, ptr %l506
  br label %bb293
bb292:
  br label %bb294
bb293:
  %t1087 = load ptr, ptr %l506, !tbaa !29
  store ptr %t1087, ptr %l5, !tbaa !29
  br label %bb294
bb294:
  br label %bb295
bb295:
  %t1088 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t1090 = call i1 @compiler_2fcheck_2eintOnly(i32 %t1088)
  store i1 %t1090, ptr %l508
  br label %bb296
bb296:
  %t1091 = load i1, ptr %l508, !tbaa !21
  br i1 %t1091, label %bb297, label %bb298
bb297:
  %t1092 = load ptr, ptr %l0, !tbaa !29
  %t1093 = load i32, ptr %l17, !tbaa !23
  %t1096 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %t1092, i32 %t1093)
  store i1 %t1096, ptr %l512
  br label %bb299
bb298:
  store i1 false, ptr %l509, !tbaa !21
  br label %bb300
bb299:
  %t1097 = load i1, ptr %l512, !tbaa !21
  %t1098 = xor i1 %t1097, true
  store i1 %t1098, ptr %l509, !tbaa !21
  br label %bb300
bb300:
  %t1100 = load i1, ptr %l509, !tbaa !21
  br i1 %t1100, label %bb301, label %bb302
bb301:
  store %olang.scope zeroinitializer, ptr %s30
  %t1101 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1101, ptr %l514, !tbaa !29
  %t1102 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t1102, ptr %l515
  %t1103 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t1105 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s30, i32 %t1103)
  store { i64, ptr } %t1105, ptr %l517
  br label %bb303
bb302:
  br label %bb309
bb303:
  %t1106 = load { i64, ptr }, ptr %l517, !tbaa !27
  %t1107 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s30, ptr %s30, { i64, ptr } %t1106)
  store { i64, ptr } %t1107, ptr %l518
  br label %bb304
bb304:
  %t1108 = load { i64, ptr }, ptr %l518, !tbaa !27
  %t1109 = extractvalue { i64, ptr } %t1108, 0
  %t1110 = extractvalue { i64, ptr } %t1108, 1
  %t1111 = mul i64 %t1109, 1
  %t1112 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t1111)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1112, ptr %t1110, i64 %t1111, i1 false)
  %t1113 = insertvalue { i64, ptr } undef, i64 %t1109, 0
  %t1114 = insertvalue { i64, ptr } %t1113, ptr %t1112, 1
  store { i64, ptr } %t1114, ptr %l519, !tbaa !27
  %t1115 = load ptr, ptr %l0, !tbaa !29
  %t1116 = load i32, ptr %l17, !tbaa !23
  %t1119 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s30, ptr %t1115, i32 %t1116)
  store { i64, ptr } %t1119, ptr %l522
  br label %bb305
bb305:
  %t1120 = load { i64, ptr }, ptr %l522, !tbaa !27
  %t1121 = extractvalue { i64, ptr } %t1120, 0
  %t1122 = extractvalue { i64, ptr } %t1120, 1
  %t1123 = mul i64 %t1121, 1
  %t1124 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t1123)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1124, ptr %t1122, i64 %t1123, i1 false)
  %t1125 = insertvalue { i64, ptr } undef, i64 %t1121, 0
  %t1126 = insertvalue { i64, ptr } %t1125, ptr %t1124, 1
  %t1127 = load { i64, ptr }, ptr %l519, !tbaa !27
  %t1129 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOperandNotInt(ptr %s30, ptr %s30, ptr %s30, { i64, ptr } %t1127, { i64, ptr } %t1126)
  store %"compiler/diagmsg:Msg" %t1129, ptr %l524
  br label %bb306
bb306:
  %t1130 = load ptr, ptr %l514, !tbaa !29
  %t1131 = load %"compiler/source:Span", ptr %l515
  %t1132 = load %"compiler/diagmsg:Msg", ptr %l524
  %t1133 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s30, ptr %t1130, %"compiler/source:Span" %t1131, %"compiler/diagmsg:Msg" %t1132)
  store i64 %t1133, ptr %l525
  br label %bb307
bb307:
  %t1134 = load ptr, ptr %l0, !tbaa !29
  %t1135 = load %"compiler/source:Span", ptr %l1
  %t1138 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t1134, %"compiler/source:Span" %t1135)
  store ptr %t1138, ptr %l528
  br label %bb308
bb308:
  call void @__olang_scope_close(ptr %s30)
  %t1139 = load ptr, ptr %l528, !tbaa !29
  store ptr %t1139, ptr %rv
  br label %ret
bb309:
  %t1140 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t1142 = call i1 @compiler_2fcheck_2ecompares(i32 %t1140)
  store i1 %t1142, ptr %l530
  br label %bb310
bb310:
  %t1143 = load i1, ptr %l530, !tbaa !21
  %t1144 = xor i1 %t1143, true
  br i1 %t1144, label %bb311, label %bb312
bb311:
  %t1146 = load ptr, ptr %l0, !tbaa !29
  %t1147 = load i32, ptr %l17, !tbaa !23
  %t1150 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t1146, i32 %t1147)
  store i1 %t1150, ptr %l535
  br label %bb313
bb312:
  store i1 false, ptr %l532, !tbaa !21
  br label %bb314
bb313:
  %t1151 = load i1, ptr %l535, !tbaa !21
  store i1 %t1151, ptr %l532, !tbaa !21
  br label %bb314
bb314:
  %t1152 = load i1, ptr %l532, !tbaa !21
  br i1 %t1152, label %bb315, label %bb316
bb315:
  %t1153 = load ptr, ptr %l0, !tbaa !29
  %t1155 = getelementptr %"compiler/check:Checker", ptr %t1153, i32 0, i32 1
  %t1156 = load ptr, ptr %t1155, !tbaa !29
  %t1157 = load i32, ptr %l17, !tbaa !23
  %t1160 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t1156, i32 %t1157)
  store i1 %t1160, ptr %l540
  br label %bb317
bb316:
  store i1 false, ptr %l536, !tbaa !21
  br label %bb318
bb317:
  %t1161 = load i1, ptr %l540, !tbaa !21
  %t1162 = xor i1 %t1161, true
  store i1 %t1162, ptr %l536, !tbaa !21
  br label %bb318
bb318:
  %t1164 = load i1, ptr %l536, !tbaa !21
  br i1 %t1164, label %bb319, label %bb320
bb319:
  store %olang.scope zeroinitializer, ptr %s31
  %t1165 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1165, ptr %l542, !tbaa !29
  %t1166 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t1166, ptr %l543
  %t1167 = load ptr, ptr %l0, !tbaa !29
  %t1168 = load i32, ptr %l17, !tbaa !23
  %t1171 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s31, ptr %t1167, i32 %t1168)
  store { i64, ptr } %t1171, ptr %l546
  br label %bb321
bb320:
  br label %bb328
bb321:
  %t1172 = load { i64, ptr }, ptr %l546, !tbaa !27
  %t1173 = extractvalue { i64, ptr } %t1172, 0
  %t1174 = extractvalue { i64, ptr } %t1172, 1
  %t1175 = mul i64 %t1173, 1
  %t1176 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t1175)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1176, ptr %t1174, i64 %t1175, i1 false)
  %t1177 = insertvalue { i64, ptr } undef, i64 %t1173, 0
  %t1178 = insertvalue { i64, ptr } %t1177, ptr %t1176, 1
  store { i64, ptr } %t1178, ptr %l547, !tbaa !27
  %t1179 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t1181 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s31, i32 %t1179)
  store { i64, ptr } %t1181, ptr %l549
  br label %bb322
bb322:
  %t1182 = load { i64, ptr }, ptr %l549, !tbaa !27
  %t1183 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s31, ptr %s31, { i64, ptr } %t1182)
  store { i64, ptr } %t1183, ptr %l550
  br label %bb323
bb323:
  %t1184 = load { i64, ptr }, ptr %l550, !tbaa !27
  %t1185 = extractvalue { i64, ptr } %t1184, 0
  %t1186 = extractvalue { i64, ptr } %t1184, 1
  %t1187 = mul i64 %t1185, 1
  %t1188 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t1187)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1188, ptr %t1186, i64 %t1187, i1 false)
  %t1189 = insertvalue { i64, ptr } undef, i64 %t1185, 0
  %t1190 = insertvalue { i64, ptr } %t1189, ptr %t1188, 1
  store { i64, ptr } %t1190, ptr %l551, !tbaa !27
  %t1191 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t1193 = call { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %s31, i32 %t1191)
  store { i64, ptr } %t1193, ptr %l553
  br label %bb324
bb324:
  %t1194 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t1195 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t1196 = load { i64, ptr }, ptr %l553, !tbaa !27
  %t1197 = extractvalue { i64, ptr } %t1196, 1
  %t1198 = extractvalue { i64, ptr } %t1196, 0
  %t1199 = add i64 %t1195, %t1198
  %t1200 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t1201 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t1202 = add i64 %t1199, %t1201
  %t1203 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t1202)
  call void @olang_textcopy(ptr %t1203, ptr %t1194, i64 %t1195)
  %t1204 = getelementptr i8, ptr %t1203, i64 %t1195
  call void @olang_textcopy(ptr %t1204, ptr %t1197, i64 %t1198)
  %t1205 = getelementptr i8, ptr %t1204, i64 %t1198
  call void @olang_textcopy(ptr %t1205, ptr %t1200, i64 %t1201)
  %t1206 = insertvalue { i64, ptr } undef, i64 %t1202, 0
  %t1207 = insertvalue { i64, ptr } %t1206, ptr %t1203, 1
  %t1209 = extractvalue { i64, ptr } %t1207, 0
  %t1210 = extractvalue { i64, ptr } %t1207, 1
  %t1211 = mul i64 %t1209, 1
  %t1212 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t1211)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1212, ptr %t1210, i64 %t1211, i1 false)
  %t1213 = insertvalue { i64, ptr } undef, i64 %t1209, 0
  %t1214 = insertvalue { i64, ptr } %t1213, ptr %t1212, 1
  %t1215 = load { i64, ptr }, ptr %l547, !tbaa !27
  %t1216 = load { i64, ptr }, ptr %l551, !tbaa !27
  %t1218 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNotExtendedOp(ptr %s31, ptr %s31, ptr %s31, ptr %s31, { i64, ptr } %t1215, { i64, ptr } %t1216, { i64, ptr } %t1214)
  store %"compiler/diagmsg:Msg" %t1218, ptr %l556
  br label %bb325
bb325:
  %t1219 = load ptr, ptr %l542, !tbaa !29
  %t1220 = load %"compiler/source:Span", ptr %l543
  %t1221 = load %"compiler/diagmsg:Msg", ptr %l556
  %t1222 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s31, ptr %t1219, %"compiler/source:Span" %t1220, %"compiler/diagmsg:Msg" %t1221)
  store i64 %t1222, ptr %l557
  br label %bb326
bb326:
  %t1223 = load ptr, ptr %l0, !tbaa !29
  %t1224 = load %"compiler/source:Span", ptr %l1
  %t1227 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t1223, %"compiler/source:Span" %t1224)
  store ptr %t1227, ptr %l560
  br label %bb327
bb327:
  call void @__olang_scope_close(ptr %s31)
  %t1228 = load ptr, ptr %l560, !tbaa !29
  store ptr %t1228, ptr %rv
  br label %ret
bb328:
  %t1229 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t1231 = call i1 @compiler_2fcheck_2ecompares(i32 %t1229)
  store i1 %t1231, ptr %l562
  br label %bb329
bb329:
  %t1232 = load i1, ptr %l562, !tbaa !21
  br i1 %t1232, label %bb330, label %bb331
bb330:
  %t1233 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1233, ptr %l563, !tbaa !29
  %t1234 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1234, ptr %l564
  %t1235 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t1235, ptr %l565, !tbaa !23
  %t1236 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t1238 = call i32 @compiler_2fcheck_2ebinaryOp(i32 %t1236)
  store i32 %t1238, ptr %l567
  br label %bb332
bb331:
  br label %bb334
bb332:
  %t1239 = load ptr, ptr %l4, !tbaa !29
  %t1240 = load ptr, ptr %l5, !tbaa !29
  %t1242 = load ptr, ptr @__olang_prog_scope
  %t1243 = load ptr, ptr @__olang_prog_scope
  %t1244 = load ptr, ptr %l563, !tbaa !29
  %t1245 = load %"compiler/source:Span", ptr %l564
  %t1246 = load i32, ptr %l565, !tbaa !23
  %t1247 = load i32, ptr %l567, !range !{i32 0, i32 49}
  %t1250 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t1242, ptr %t1243, ptr %v3, ptr %t1244, %"compiler/source:Span" %t1245, i32 %t1246, i32 %t1247, ptr %t1239, ptr %t1240)
  store ptr %t1250, ptr %l571
  br label %bb333
bb333:
  %t1251 = load ptr, ptr %l571, !tbaa !29
  store ptr %t1251, ptr %rv
  br label %ret
bb334:
  %t1252 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1252, ptr %l572, !tbaa !29
  %t1253 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1253, ptr %l573
  %t1254 = load i32, ptr %l17, !tbaa !23
  store i32 %t1254, ptr %l574, !tbaa !23
  %t1255 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t1257 = call i32 @compiler_2fcheck_2ebinaryOp(i32 %t1255)
  store i32 %t1257, ptr %l576
  br label %bb335
bb335:
  %t1258 = load ptr, ptr %l4, !tbaa !29
  %t1259 = load ptr, ptr %l5, !tbaa !29
  %t1260 = load ptr, ptr @__olang_prog_scope
  %t1261 = load ptr, ptr @__olang_prog_scope
  %t1262 = load ptr, ptr %l572, !tbaa !29
  %t1263 = load %"compiler/source:Span", ptr %l573
  %t1264 = load i32, ptr %l574, !tbaa !23
  %t1265 = load i32, ptr %l576, !range !{i32 0, i32 49}
  %t1268 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckedPrim(ptr %v0, ptr %t1260, ptr %t1261, ptr %v3, ptr %t1262, %"compiler/source:Span" %t1263, i32 %t1264, i32 %t1265, ptr %t1258, ptr %t1259)
  store ptr %t1268, ptr %l579
  br label %bb336
bb336:
  %t1269 = load ptr, ptr %l579, !tbaa !29
  store ptr %t1269, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epackedStruct(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l25 = alloca %"compiler/diagmsg:Msg"
  %l26 = alloca i64
  %l30 = alloca i32
  %l34 = alloca i1
  %l39 = alloca i1
  %l42 = alloca ptr
  %l47 = alloca i32
  %l48 = alloca { i64, ptr }
  %l50 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l56 = alloca i64
  %l59 = alloca i64
  %l78 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l87 = alloca i1
  %l89 = alloca ptr
  %l90 = alloca i64
  %l92 = alloca i64
  %l94 = alloca %"compiler/source:Span"
  %l97 = alloca %"compiler/source:Span"
  %l100 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l106 = alloca %"compiler/diagmsg:Msg"
  %l107 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:StructBody", ptr %t1, i32 0, i32 4
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp sgt i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l18, !tbaa !29
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = getelementptr %"compiler/ast:StructBody", ptr %t11, i32 0, i32 3
  %t14 = getelementptr %"compiler/source:Span", ptr %t13, i32 0, i32 0
  %t15 = load i32, ptr %t14, !tbaa !23
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr %"compiler/ast:StructBody", ptr %t16, i32 0, i32 3
  %t19 = getelementptr %"compiler/source:Span", ptr %t18, i32 0, i32 0
  %t20 = load i32, ptr %t19, !tbaa !23
  %t22 = add i32 %t20, 8
  %t25 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 %t15, i32 %t22)
  store %"compiler/source:Span" %t25, ptr %l24
  br label %bb3
bb2:
  br label %bb6
bb3:
  %t26 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePackedDestruct(ptr %s1)
  store %"compiler/diagmsg:Msg" %t26, ptr %l25
  br label %bb4
bb4:
  %t27 = load ptr, ptr %l18, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l24
  %t29 = load %"compiler/diagmsg:Msg", ptr %l25
  %t30 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t27, %"compiler/source:Span" %t28, %"compiler/diagmsg:Msg" %t29)
  store i64 %t30, ptr %l26
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb6
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t38 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t34, i32 %a3)
  store i32 %t38, ptr %l30
  br label %bb7
bb7:
  %t39 = load i32, ptr %l30, !tbaa !23
  store i32 %t39, ptr %l4, !tbaa !23
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/check:Checker", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t44 = load i32, ptr %l4, !tbaa !23
  %t47 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t43, i32 %t44)
  store i1 %t47, ptr %l34
  br label %bb8
bb8:
  %t48 = load i1, ptr %l34, !tbaa !21
  %t49 = xor i1 %t48, true
  br i1 %t49, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb10:
  br label %bb11
bb11:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/check:Checker", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t55 = load i32, ptr %l4, !tbaa !23
  %t58 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t54, i32 %t55)
  store i1 %t58, ptr %l39
  br label %bb12
bb12:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  store ptr %t64, ptr %l42, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Program", ptr %t68, i32 0, i32 2
  %t71 = load i32, ptr %l4, !tbaa !23
  %t74 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t74, ptr %l47
  br label %bb13
bb13:
  %t75 = load ptr, ptr %l42, !tbaa !29
  %t76 = load i32, ptr %l47, !tbaa !23
  %t77 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t75, i32 %t76)
  store { i64, ptr } %t77, ptr %l48
  br label %bb14
bb14:
  %t78 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t78, ptr %l5, !tbaa !27
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t81 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2efieldSpans(ptr %v1, ptr %s0, ptr %t79)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t81, ptr %l50
  br label %bb15
bb15:
  %t82 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l50
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t82, ptr %l6
  store i64 0, ptr %l7, !tbaa !24
  %t83 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t83, 0
  store i64 %t85, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t87 = load i64, ptr %l8, !tbaa !24
  %t88 = load i64, ptr %l7, !tbaa !24
  %t91 = icmp sgt i64 %t87, %t88
  br i1 %t91, label %bb16, label %bb17
bb16:
  %t93 = load i64, ptr %l9, !tbaa !24
  %t95 = icmp sgt i64 %t93, 0
  br i1 %t95, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb21
bb18:
  %t97 = load i64, ptr %l8, !tbaa !24
  %t98 = load i64, ptr %l7, !tbaa !24
  %t101 = sub i64 %t97, %t98
  %t102 = load i64, ptr %l9, !tbaa !24
  %t105 = add i64 %t101, %t102
  %t107 = sub i64 %t105, 1
  %t108 = load i64, ptr %l9, !tbaa !24
  %t111 = sdiv i64 %t107, %t108
  store i64 %t111, ptr %l59, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb20
bb20:
  %t113 = load i64, ptr %l59, !tbaa !24
  store i64 %t113, ptr %l56, !tbaa !24
  br label %bb21
bb21:
  %t114 = load i64, ptr %l56, !tbaa !24
  store i64 %t114, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s4
  %t115 = load i64, ptr %l11, !tbaa !24
  %t116 = load i64, ptr %l10, !tbaa !24
  %t119 = icmp slt i64 %t115, %t116
  %t121 = xor i1 %t119, true
  br i1 %t121, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s4)
  br label %bb41
bb24:
  br label %bb25
bb25:
  %t123 = load i64, ptr %l7, !tbaa !24
  %t124 = load i64, ptr %l11, !tbaa !24
  %t125 = load i64, ptr %l9, !tbaa !24
  %t128 = mul i64 %t124, %t125
  %t131 = add i64 %t123, %t128
  store i64 %t131, ptr %l12, !tbaa !24
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t134, ptr %l78, !tbaa !27
  %t135 = load i64, ptr %l12, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr i32, ptr %t138, i64 %t135
  %t140 = load i32, ptr %t139, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteRawBits(ptr %v0, ptr %t133, i32 %t140)
  br label %bb26
bb26:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t144, ptr %l82, !tbaa !27
  %t145 = load i64, ptr %l12, !tbaa !24
  %t147 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = getelementptr i32, ptr %t148, i64 %t145
  %t150 = load i32, ptr %t149, !tbaa !33
  %t153 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epackedWhat(ptr %v0, ptr %s4, ptr %t143, i32 %t150)
  store { i64, ptr } %t153, ptr %l85
  br label %bb27
bb27:
  %t154 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t154, ptr %l13, !tbaa !27
  %t155 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t157 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s4, ptr %s4, { i64, ptr } %t155, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store i1 %t157, ptr %l87
  br label %bb28
bb28:
  %t158 = load i1, ptr %l87, !tbaa !21
  %t159 = xor i1 %t158, true
  br i1 %t159, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s5
  %t161 = load ptr, ptr %l0, !tbaa !29
  store ptr %t161, ptr %l89, !tbaa !29
  %t162 = load i64, ptr %l12, !tbaa !24
  store i64 %t162, ptr %l90, !tbaa !24
  %t164 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eLen_3ccompiler_2fsource_3aSpan_3e(ptr %s0, ptr %l6)
  store i64 %t164, ptr %l92
  br label %bb31
bb30:
  br label %bb39
bb31:
  %t165 = load i64, ptr %l90, !tbaa !24
  %t166 = load i64, ptr %l92, !tbaa !24
  %t167 = icmp slt i64 %t165, %t166
  br i1 %t167, label %bb32, label %bb33
bb32:
  %t169 = load i64, ptr %l12, !tbaa !24
  %t172 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %s0, ptr %l6, i64 %t169)
  store %"compiler/source:Span" %t172, ptr %l97
  br label %bb34
bb33:
  store %"compiler/source:Span" %a1, ptr %l94
  br label %bb35
bb34:
  %t175 = load %"compiler/source:Span", ptr %l97
  store %"compiler/source:Span" %t175, ptr %l94
  br label %bb35
bb35:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t177, ptr %l100, !tbaa !27
  %t178 = load i64, ptr %l12, !tbaa !24
  %t180 = getelementptr { i64, ptr }, ptr %l100, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !27
  %t182 = getelementptr i32, ptr %t181, i64 %t178
  %t183 = load i32, ptr %t182, !tbaa !33
  %t186 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t176, i32 %t183)
  store { i64, ptr } %t186, ptr %l103
  br label %bb36
bb36:
  %t187 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t187, 0
  %t189 = extractvalue { i64, ptr } %t187, 1
  %t190 = mul i64 %t188, 1
  %t191 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t190)
  call void @llvm.memcpy.p0.p0.i64(ptr %t191, ptr %t189, i64 %t190, i1 false)
  %t192 = insertvalue { i64, ptr } undef, i64 %t188, 0
  %t193 = insertvalue { i64, ptr } %t192, ptr %t191, 1
  %t194 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t197 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePackedField(ptr %s5, ptr %s4, ptr %s5, { i64, ptr } %t193, { i64, ptr } %t194)
  store %"compiler/diagmsg:Msg" %t197, ptr %l106
  br label %bb37
bb37:
  %t198 = load ptr, ptr %l89, !tbaa !29
  %t199 = load %"compiler/source:Span", ptr %l94
  %t200 = load %"compiler/diagmsg:Msg", ptr %l106
  %t201 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t198, %"compiler/source:Span" %t199, %"compiler/diagmsg:Msg" %t200)
  store i64 %t201, ptr %l107
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s5)
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s4)
  br label %bb40
bb40:
  %t202 = load i64, ptr %l11, !tbaa !24
  %t204 = add i64 %t202, 1
  store i64 %t204, ptr %l11, !tbaa !24
  br label %bb22
bb41:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamIndex(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/typed:Local"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l15 = alloca %"compiler/typed:Local"
  %l19 = alloca i1
  %l22 = alloca i1
  %l23 = alloca i1
  %l26 = alloca i1
  %l30 = alloca ptr
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l36 = alloca i64
  %l40 = alloca i64
  %l43 = alloca i64
  %l63 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l11
  br label %bb1
bb1:
  %t4 = load i64, ptr %l1, !tbaa !24
  %t6 = trunc i64 %t4 to i32
  %t8 = load ptr, ptr %l11, !tbaa !29
  %t10 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t8, i32 %t6)
  store %"compiler/typed:Local" %t10, ptr %l15
  br label %bb2
bb2:
  %t11 = load %"compiler/typed:Local", ptr %l15
  store %"compiler/typed:Local" %t11, ptr %l2
  %t12 = getelementptr %"compiler/typed:Local", ptr %l2, i32 0, i32 4
  %t13 = load i32, ptr %t12, !range !{i32 0, i32 7}
  %t15 = trunc i64 0 to i32
  %t16 = icmp eq i32 %t13, %t15
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb6
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/typed:Local", ptr %l2, i32 0, i32 2
  %t22 = load i32, ptr %t21, !tbaa !23
  %t25 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t20, i32 %t22)
  store i1 %t25, ptr %l22
  br label %bb5
bb5:
  %t26 = load i1, ptr %l22, !tbaa !21
  store i1 %t26, ptr %l19, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l19, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb10
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Local", ptr %l2, i32 0, i32 2
  %t30 = load i32, ptr %t29, !tbaa !23
  %t33 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %t28, i32 %t30)
  store i1 %t33, ptr %l26
  br label %bb9
bb9:
  %t34 = load i1, ptr %l26, !tbaa !21
  %t35 = xor i1 %t34, true
  store i1 %t35, ptr %l23, !tbaa !21
  br label %bb10
bb10:
  %t37 = load i1, ptr %l23, !tbaa !21
  br i1 %t37, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t39)
  store ptr %t41, ptr %l30
  br label %bb14
bb14:
  %t42 = load ptr, ptr %l30, !tbaa !29
  %t44 = getelementptr %"compiler/typed:Body", ptr %t42, i32 0, i32 5
  %t45 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t44
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %l32
  %t47 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l32)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t47, ptr %l34
  br label %bb15
bb15:
  %t48 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t48, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t50 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l3)
  store i64 %t50, ptr %l36
  br label %bb16
bb16:
  %t51 = load i64, ptr %l36, !tbaa !24
  store i64 %t51, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t52 = load i64, ptr %l5, !tbaa !24
  %t53 = load i64, ptr %l4, !tbaa !24
  %t56 = icmp sgt i64 %t52, %t53
  br i1 %t56, label %bb17, label %bb18
bb17:
  %t58 = load i64, ptr %l6, !tbaa !24
  %t60 = icmp sgt i64 %t58, 0
  br i1 %t60, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb22
bb19:
  %t62 = load i64, ptr %l5, !tbaa !24
  %t63 = load i64, ptr %l4, !tbaa !24
  %t66 = sub i64 %t62, %t63
  %t67 = load i64, ptr %l6, !tbaa !24
  %t70 = add i64 %t66, %t67
  %t72 = sub i64 %t70, 1
  %t73 = load i64, ptr %l6, !tbaa !24
  %t76 = sdiv i64 %t72, %t73
  store i64 %t76, ptr %l43, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb21
bb21:
  %t78 = load i64, ptr %l43, !tbaa !24
  store i64 %t78, ptr %l40, !tbaa !24
  br label %bb22
bb22:
  %t79 = load i64, ptr %l40, !tbaa !24
  store i64 %t79, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb23
bb23:
  %t80 = load i64, ptr %l8, !tbaa !24
  %t81 = load i64, ptr %l7, !tbaa !24
  %t84 = icmp slt i64 %t80, %t81
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb24, label %bb25
bb24:
  br label %bb32
bb25:
  br label %bb26
bb26:
  %t88 = load i64, ptr %l4, !tbaa !24
  %t89 = load i64, ptr %l8, !tbaa !24
  %t90 = load i64, ptr %l6, !tbaa !24
  %t93 = mul i64 %t89, %t90
  %t96 = add i64 %t88, %t93
  store i64 %t96, ptr %l9, !tbaa !24
  %t98 = load i64, ptr %l9, !tbaa !24
  %t101 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l3, i64 %t98)
  store i32 %t101, ptr %l63
  br label %bb27
bb27:
  %t102 = load i32, ptr %l63, !tbaa !23
  %t103 = sext i32 %t102 to i64
  %t104 = load i64, ptr %l1, !tbaa !24
  %t107 = icmp eq i64 %t103, %t104
  br i1 %t107, label %bb28, label %bb29
bb28:
  %t109 = load i64, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t109, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t111 = load i64, ptr %l8, !tbaa !24
  %t113 = add i64 %t111, 1
  store i64 %t113, ptr %l8, !tbaa !24
  br label %bb23
bb32:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamsOn(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %lp4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"compiler/generic:Binding"
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l16 = alloca ptr
  %l19 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca { i64, ptr }
  %l27 = alloca i64
  %l32 = alloca i64
  %l36 = alloca i64
  %l39 = alloca %"compiler/generic:Binding"
  %l42 = alloca i1
  %l47 = alloca { i64, ptr }
  %l56 = alloca i64
  %l59 = alloca i64
  %l77 = alloca i64
  %l80 = alloca i32
  %l82 = alloca { i64, ptr }
  %l85 = alloca i32
  %l90 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l16, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  store ptr %t12, ptr %l19, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t16, i64 %t17)
  store i32 %t20, ptr %l23
  br label %bb1
bb1:
  %t21 = load ptr, ptr %l19, !tbaa !29
  %t22 = load i32, ptr %l23, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t23, ptr %l24
  br label %bb2
bb2:
  %t24 = load ptr, ptr %l16, !tbaa !29
  %t25 = load i32, ptr %l24, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t24, i32 %t25)
  store { i64, ptr } %t26, ptr %l25
  br label %bb3
bb3:
  %t27 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t27, ptr %l3, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  store i64 %t30, ptr %l27, !tbaa !24
  %t31 = load i64, ptr %l27, !tbaa !24
  %t32 = icmp sge i64 %t31, 0
  br i1 %t32, label %bb4, label %bb5
bb4:
  %t34 = load i64, ptr %l27, !tbaa !24
  %t35 = icmp sle i64 %t34, 2305843009213693951
  br i1 %t35, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_aac959024b9d6f15_55461456e770b1d1)
  unreachable
bb6:
  %t37 = load i64, ptr %l27, !tbaa !24
  %t38 = mul i64 %t37, 4
  %t39 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t38)
  %t40 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  %t42 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t42, ptr %lp4
  %t44 = load ptr, ptr %lp4
  store { i64, ptr } %t41, ptr %t44, !tbaa !27
  %t45 = load i64, ptr %l1, !tbaa !24
  %t47 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t45)
  store i64 %t47, ptr %l32
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_aac959024b9d6f15_55461456e770b1d1)
  unreachable
bb8:
  %t48 = load i64, ptr %l32, !tbaa !24
  store i64 %t48, ptr %l5, !tbaa !24
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t53 = load i64, ptr %l5, !tbaa !24
  %t56 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t52, i64 %t53)
  store i64 %t56, ptr %l36
  br label %bb9
bb9:
  %t57 = load i64, ptr %l36, !tbaa !24
  store i64 %t57, ptr %l6, !tbaa !24
  %t58 = load i64, ptr %l5, !tbaa !24
  %t59 = load i64, ptr %l6, !tbaa !24
  %t62 = call %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %s0, i64 %t58, i64 %t59)
  store %"compiler/generic:Binding" %t62, ptr %l39
  br label %bb10
bb10:
  %t63 = load %"compiler/generic:Binding", ptr %l39
  store %"compiler/generic:Binding" %t63, ptr %l7
  %t64 = load i64, ptr %l6, !tbaa !24
  %t66 = icmp sgt i64 %t64, 0
  br i1 %t66, label %bb11, label %bb12
bb11:
  %t68 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t72 = icmp sgt i64 %t70, 0
  store i1 %t72, ptr %l42, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb13
bb13:
  %t74 = load i1, ptr %l42, !tbaa !21
  br i1 %t74, label %bb14, label %bb15
bb14:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t76, ptr %l47, !tbaa !27
  %t77 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr i32, ptr %t78, i64 0
  %t80 = load i32, ptr %t79, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %s0, ptr %t75, i32 %t80, i32 %a2, ptr %l7, i1 false, i1 true)
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  store i64 0, ptr %l8, !tbaa !24
  %t86 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  store i64 %t88, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t90 = load i64, ptr %l9, !tbaa !24
  %t91 = load i64, ptr %l8, !tbaa !24
  %t94 = icmp sgt i64 %t90, %t91
  br i1 %t94, label %bb18, label %bb19
bb18:
  %t96 = load i64, ptr %l10, !tbaa !24
  %t98 = icmp sgt i64 %t96, 0
  br i1 %t98, label %bb20, label %bb21
bb19:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb23
bb20:
  %t100 = load i64, ptr %l9, !tbaa !24
  %t101 = load i64, ptr %l8, !tbaa !24
  %t104 = sub i64 %t100, %t101
  %t105 = load i64, ptr %l10, !tbaa !24
  %t108 = add i64 %t104, %t105
  %t110 = sub i64 %t108, 1
  %t111 = load i64, ptr %l10, !tbaa !24
  %t114 = sdiv i64 %t110, %t111
  store i64 %t114, ptr %l59, !tbaa !24
  br label %bb22
bb21:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb22
bb22:
  %t116 = load i64, ptr %l59, !tbaa !24
  store i64 %t116, ptr %l56, !tbaa !24
  br label %bb23
bb23:
  %t117 = load i64, ptr %l56, !tbaa !24
  store i64 %t117, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb24
bb24:
  %t118 = load i64, ptr %l12, !tbaa !24
  %t119 = load i64, ptr %l11, !tbaa !24
  %t122 = icmp slt i64 %t118, %t119
  %t124 = xor i1 %t122, true
  br i1 %t124, label %bb25, label %bb26
bb25:
  br label %bb34
bb26:
  br label %bb27
bb27:
  %t126 = load i64, ptr %l8, !tbaa !24
  %t127 = load i64, ptr %l12, !tbaa !24
  %t128 = load i64, ptr %l10, !tbaa !24
  %t131 = mul i64 %t127, %t128
  %t134 = add i64 %t126, %t131
  store i64 %t134, ptr %l13, !tbaa !24
  %t136 = load i64, ptr %l13, !tbaa !24
  store i64 %t136, ptr %l77, !tbaa !24
  %t137 = load i64, ptr %l6, !tbaa !24
  %t139 = icmp eq i64 %t137, 0
  br i1 %t139, label %bb28, label %bb29
bb28:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t142, ptr %l82, !tbaa !27
  %t143 = load i64, ptr %l13, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr i32, ptr %t146, i64 %t143
  %t148 = load i32, ptr %t147, !tbaa !33
  %t151 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t141, i32 %t148)
  store i32 %t151, ptr %l85
  br label %bb30
bb29:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t154 = load i64, ptr %l13, !tbaa !24
  %t159 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eboundParam(ptr %v0, ptr %v0, ptr %s0, ptr %t152, { i64, ptr } %t153, i64 %t154, ptr %l7)
  store i32 %t159, ptr %l90
  br label %bb31
bb30:
  %t160 = load i32, ptr %l85, !tbaa !23
  store i32 %t160, ptr %l80, !tbaa !23
  br label %bb32
bb31:
  %t161 = load i32, ptr %l90, !tbaa !23
  store i32 %t161, ptr %l80, !tbaa !23
  br label %bb32
bb32:
  %t162 = load i32, ptr %l80, !tbaa !23
  %t163 = load ptr, ptr %lp4
  %t164 = load i64, ptr %l77, !tbaa !24
  %t165 = getelementptr { i64, ptr }, ptr %t163, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !27
  %t167 = getelementptr i32, ptr %t166, i64 %t164
  store i32 %t162, ptr %t167, !tbaa !33
  br label %bb33
bb33:
  %t168 = load i64, ptr %l12, !tbaa !24
  %t170 = add i64 %t168, 1
  store i64 %t170, ptr %l12, !tbaa !24
  br label %bb24
bb34:
  %t172 = load ptr, ptr %lp4
  %t173 = load { i64, ptr }, ptr %t172, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t173, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceHere(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %lp14 = alloca ptr
  %lp15 = alloca ptr
  %l17 = alloca i32
  %l21 = alloca { i64, ptr }
  %l22 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca %"compiler/source:Span"
  %l28 = alloca { i64, ptr }
  %l29 = alloca %"compiler/diagmsg:Msg"
  %l30 = alloca i64
  %l33 = alloca ptr
  %l35 = alloca i32
  %l39 = alloca i32
  %l45 = alloca ptr
  %l47 = alloca ptr
  %l66 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l72 = alloca i64
  %l77 = alloca { i64, ptr }
  %l84 = alloca %"compiler/source:Span"
  %l87 = alloca ptr
  %l89 = alloca i32
  %l91 = alloca i32
  %l93 = alloca ptr
  %l100 = alloca ptr
  %l101 = alloca ptr
  %l102 = alloca %"compiler/source:Span"
  %l104 = alloca i32
  %l108 = alloca i64
  %l109 = alloca ptr
  %l110 = alloca ptr
  %l111 = alloca %"compiler/source:Span"
  %l113 = alloca i32
  %l117 = alloca i64
  %l118 = alloca ptr
  %l122 = alloca i64
  %l127 = alloca ptr
  %l128 = alloca %"compiler/source:Span"
  %l129 = alloca %"compiler/source:Span"
  %l130 = alloca i32
  %l135 = alloca ptr
  %l141 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  %t173 = alloca { i64, [2 x i64] }, align 8
  %t181 = alloca { i64, [5 x i64] }, align 8
  %t262 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l3, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l21
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t6, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store i1 %t7, ptr %l22
  br label %bb2
bb2:
  %t8 = load i1, ptr %l22, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l24, !tbaa !29
  %t12 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t12, ptr %l25
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l3, !tbaa !23
  %t17 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t13, i32 %t14)
  store { i64, ptr } %t17, ptr %l28
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t18 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t19 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePlaceMember(ptr %v0, ptr %s1, { i64, ptr } %t18)
  store %"compiler/diagmsg:Msg" %t19, ptr %l29
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l24, !tbaa !29
  %t21 = load %"compiler/source:Span", ptr %l25
  %t22 = load %"compiler/diagmsg:Msg", ptr %l29
  %t23 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t20, %"compiler/source:Span" %t21, %"compiler/diagmsg:Msg" %t22)
  store i64 %t23, ptr %l30
  br label %bb7
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load %"compiler/source:Span", ptr %l1
  %t28 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t24, %"compiler/source:Span" %t25)
  store ptr %t28, ptr %l33
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t29 = load ptr, ptr %l33, !tbaa !29
  store ptr %t29, ptr %rv
  br label %ret
bb9:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceType(ptr %v0, ptr %t30)
  store i32 %t32, ptr %l35
  br label %bb10
bb10:
  %t33 = load i32, ptr %l35, !tbaa !23
  store i32 %t33, ptr %l4, !tbaa !23
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t38 = load i32, ptr %l4, !tbaa !23
  %t41 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l39
  br label %bb11
bb11:
  %t42 = load i32, ptr %l39, !tbaa !23
  store i32 %t42, ptr %l5, !tbaa !23
  %t43 = load i32, ptr %l5, !tbaa !23
  %t44 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t47 = icmp eq i32 %t43, %t44
  br i1 %t47, label %bb12, label %bb13
bb12:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load %"compiler/source:Span", ptr %l1
  %t53 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t49, %"compiler/source:Span" %t50)
  store ptr %t53, ptr %l45
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t54 = load ptr, ptr %l45, !tbaa !29
  store ptr %t54, ptr %rv
  br label %ret
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t55)
  store ptr %t57, ptr %l47
  br label %bb16
bb16:
  %t58 = load ptr, ptr %l47, !tbaa !29
  %t60 = getelementptr %"compiler/check:frame", ptr %t58, i32 0, i32 2
  %t61 = load i64, ptr %t60, !tbaa !24
  store i64 %t61, ptr %l6, !tbaa !24
  %t63 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t64 = load i32, ptr %t63, !tbaa !23
  %t66 = sext i32 %t64 to i64
  store i64 %t66, ptr %l7, !tbaa !24
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/check:Checker", ptr %t68, i32 0, i32 24
  %t71 = load i64, ptr %t70, !tbaa !24
  %t73 = icmp sge i64 %t71, 0
  br i1 %t73, label %bb17, label %bb18
bb17:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/check:Checker", ptr %t75, i32 0, i32 24
  %t78 = load i64, ptr %t77, !tbaa !24
  store i64 %t78, ptr %l6, !tbaa !24
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/check:Checker", ptr %t80, i32 0, i32 25
  %t83 = getelementptr %"compiler/source:Span", ptr %t82, i32 0, i32 0
  %t84 = load i32, ptr %t83, !tbaa !23
  %t86 = sext i32 %t84 to i64
  store i64 %t86, ptr %l7, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/check:Checker", ptr %t88, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = getelementptr %"compiler/generic:Program", ptr %t91, i32 0, i32 0
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = getelementptr %"compiler/load:Loader", ptr %t94, i32 0, i32 4
  %t97 = load ptr, ptr %t96, !tbaa !29
  store ptr %t97, ptr %l8, !tbaa !29
  %t99 = load ptr, ptr %l8, !tbaa !29
  %t100 = load i64, ptr %l6, !tbaa !24
  %t103 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePathOf(ptr %v0, ptr %s0, ptr %t99, i64 %t100)
  store { i64, ptr } %t103, ptr %l66
  br label %bb20
bb20:
  %t104 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t104, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t107 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t107, 0
  store i64 %t109, ptr %l12, !tbaa !24
  %t111 = load i64, ptr %l12, !tbaa !24
  %t113 = mul i64 %t111, 1
  %t114 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t113)
  %t115 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t114, 1
  store { i64, ptr } %t116, ptr %l71, !tbaa !27
  store i64 0, ptr %l72, !tbaa !24
  br label %bb21
bb21:
  %t117 = load i64, ptr %l11, !tbaa !24
  %t118 = load i64, ptr %l12, !tbaa !24
  %t121 = icmp slt i64 %t117, %t118
  %t123 = xor i1 %t121, true
  br i1 %t123, label %bb22, label %bb23
bb22:
  br label %bb26
bb23:
  br label %bb24
bb24:
  %t125 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t125, ptr %l77, !tbaa !27
  %t126 = load i64, ptr %l11, !tbaa !24
  %t128 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr i8, ptr %t129, i64 %t126
  %t131 = load i8, ptr %t130, !tbaa !32
  %t136 = load i64, ptr %l72, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr i8, ptr %t138, i64 %t136
  store i8 %t131, ptr %t139, !tbaa !32
  %t140 = load i64, ptr %l72, !tbaa !24
  %t141 = add i64 %t140, 1
  store i64 %t141, ptr %l72, !tbaa !24
  br label %bb25
bb25:
  %t142 = load i64, ptr %l11, !tbaa !24
  %t144 = add i64 %t142, 1
  store i64 %t144, ptr %l11, !tbaa !24
  br label %bb21
bb26:
  %t146 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t146, ptr %lp14
  %t147 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t148 = load ptr, ptr %lp14
  store { i64, ptr } %t147, ptr %t148, !tbaa !27
  %t149 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t149, ptr %l84
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/check:Checker", ptr %t150, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !29
  %t155 = getelementptr %"compiler/generic:Program", ptr %t153, i32 0, i32 2
  store ptr %t155, ptr %l87, !tbaa !29
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t156)
  store i32 %t158, ptr %l89
  br label %bb27
bb27:
  %t159 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t160 = load ptr, ptr %l87, !tbaa !29
  %t161 = load i32, ptr %l89, !tbaa !23
  %t163 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t160, i32 %t161, i64 %t159)
  store i32 %t163, ptr %l91
  br label %bb28
bb28:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t164)
  store ptr %t166, ptr %l93
  br label %bb29
bb29:
  %t167 = load ptr, ptr %l93, !tbaa !29
  %t169 = getelementptr %"compiler/check:frame", ptr %t167, i32 0, i32 2
  %t170 = load i64, ptr %t169, !tbaa !24
  %t171 = load ptr, ptr %lp14
  %t172 = load { i64, ptr }, ptr %t171, !tbaa !27
  store { i64, [2 x i64] } zeroinitializer, ptr %t173
  %t174 = getelementptr { i64, [2 x i64] }, ptr %t173, i32 0, i32 0
  store i64 1, ptr %t174
  %t176 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t172, 0
  %t177 = getelementptr { i64, [2 x i64] }, ptr %t173, i32 0, i32 1
  store { { i64, ptr } } %t176, ptr %t177
  %t178 = load { i64, [2 x i64] }, ptr %t173
  %t180 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store { i64, [2 x i64] } %t178, ptr %t180
  store { i64, [5 x i64] } zeroinitializer, ptr %t181
  %t182 = getelementptr { i64, [5 x i64] }, ptr %t181, i32 0, i32 0
  store i64 1, ptr %t182
  %t183 = load %"compiler/source:Span", ptr %l84
  %t184 = insertvalue { %"compiler/source:Span", i32, i64, ptr } undef, %"compiler/source:Span" %t183, 0
  %t185 = load i32, ptr %l91, !tbaa !23
  %t186 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t184, i32 %t185, 1
  %t188 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t186, i64 %t170, 2
  %t190 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t188, ptr %t180, 3
  %t191 = getelementptr { i64, [5 x i64] }, ptr %t181, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, ptr } %t190, ptr %t191
  %t192 = load { i64, [5 x i64] }, ptr %t181
  %t194 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t192, ptr %t194
  store ptr %t194, ptr %l100, !tbaa !29
  %t195 = load ptr, ptr %l0, !tbaa !29
  store ptr %t195, ptr %l101, !tbaa !29
  %t196 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t196, ptr %l102
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t197)
  store i32 %t199, ptr %l104
  br label %bb30
bb30:
  %t200 = load ptr, ptr %l8, !tbaa !29
  %t201 = load i64, ptr %l6, !tbaa !24
  %t202 = load i64, ptr %l7, !tbaa !24
  %t206 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %t200, i64 %t201, i64 %t202)
  store i64 %t206, ptr %l108
  br label %bb31
bb31:
  %t207 = load ptr, ptr %l101, !tbaa !29
  %t208 = load %"compiler/source:Span", ptr %l102
  %t209 = load i32, ptr %l104, !tbaa !23
  %t210 = load i64, ptr %l108, !tbaa !24
  %t211 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %t207, %"compiler/source:Span" %t208, i32 %t209, i64 %t210)
  store ptr %t211, ptr %l109
  br label %bb32
bb32:
  %t212 = load ptr, ptr %l0, !tbaa !29
  store ptr %t212, ptr %l110, !tbaa !29
  %t213 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t213, ptr %l111
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t214)
  store i32 %t216, ptr %l113
  br label %bb33
bb33:
  %t217 = load ptr, ptr %l8, !tbaa !29
  %t218 = load i64, ptr %l6, !tbaa !24
  %t219 = load i64, ptr %l7, !tbaa !24
  %t223 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eColumnAt(ptr %v0, ptr %t217, i64 %t218, i64 %t219)
  store i64 %t223, ptr %l117
  br label %bb34
bb34:
  %t224 = load ptr, ptr %l110, !tbaa !29
  %t225 = load %"compiler/source:Span", ptr %l111
  %t226 = load i32, ptr %l113, !tbaa !23
  %t227 = load i64, ptr %l117, !tbaa !24
  %t228 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %t224, %"compiler/source:Span" %t225, i32 %t226, i64 %t227)
  store ptr %t228, ptr %l118
  br label %bb35
bb35:
  %t229 = load ptr, ptr %l100, !tbaa !29
  %t230 = insertvalue [3 x ptr] undef, ptr %t229, 0
  %t231 = load ptr, ptr %l109, !tbaa !29
  %t232 = insertvalue [3 x ptr] %t230, ptr %t231, 1
  %t233 = load ptr, ptr %l118, !tbaa !29
  %t234 = insertvalue [3 x ptr] %t232, ptr %t233, 2
  %t235 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store ptr %t235, ptr %lp15
  %t237 = load ptr, ptr %lp15
  store [3 x ptr] %t234, ptr %t237
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load i32, ptr %l4, !tbaa !23
  %t242 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %t238, i32 %t239)
  store i64 %t242, ptr %l122
  br label %bb36
bb36:
  %t243 = load i64, ptr %l122, !tbaa !24
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr %"compiler/check:Checker", ptr %t244, i32 0, i32 23
  %t247 = load i32, ptr %t246, !tbaa !23
  store i32 %t247, ptr %l17, !tbaa !23
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t250 = load i32, ptr %l4, !tbaa !23
  %t253 = getelementptr %"compiler/check:Checker", ptr %t249, i32 0, i32 23
  store i32 %t250, ptr %t253, !tbaa !23
  %t254 = load ptr, ptr %l0, !tbaa !29
  store ptr %t254, ptr %l127, !tbaa !29
  %t255 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t255, ptr %l128
  %t256 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t256, ptr %l129
  %t257 = load i32, ptr %l5, !tbaa !23
  store i32 %t257, ptr %l130, !tbaa !23
  %t260 = trunc i64 %t243 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t262
  %t263 = getelementptr { i64, [3 x i64] }, ptr %t262, i32 0, i32 0
  store i64 0, ptr %t263
  %t265 = insertvalue { i32 } undef, i32 %t260, 0
  %t266 = getelementptr { i64, [3 x i64] }, ptr %t262, i32 0, i32 1
  store { i32 } %t265, ptr %t266
  %t267 = load { i64, [3 x i64] }, ptr %t262
  %t269 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store { i64, [3 x i64] } %t267, ptr %t269
  store ptr %t269, ptr %l135, !tbaa !29
  %t270 = icmp sge i64 0, 0
  br i1 %t270, label %bb37, label %bb38
bb37:
  %t272 = icmp sle i64 0, 1152921504606846975
  br i1 %t272, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_b23b0b3c83be0ad1_2f776aac88ec27cd)
  unreachable
bb39:
  %t274 = mul i64 0, 8
  %t275 = insertvalue { i64, ptr } undef, i64 0, 0
  %t276 = insertvalue { i64, ptr } %t275, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t277 = load ptr, ptr %lp15
  %t279 = insertvalue { i64, ptr } undef, i64 3, 0
  %t280 = insertvalue { i64, ptr } %t279, ptr %t277, 1
  %t281 = load ptr, ptr %l127, !tbaa !29
  %t282 = load %"compiler/source:Span", ptr %l128
  %t283 = load %"compiler/source:Span", ptr %l129
  %t284 = load i32, ptr %l130, !tbaa !23
  %t285 = load ptr, ptr %l135, !tbaa !29
  %t288 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v1, ptr %v0, ptr %v0, ptr %v1, ptr %v1, ptr %t281, %"compiler/source:Span" %t282, %"compiler/source:Span" %t283, i32 %t284, ptr %t285, i64 -1, ptr null, { i64, ptr } %t276, { i64, ptr } %t280)
  store ptr %t288, ptr %l141
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_b23b0b3c83be0ad1_2f776aac88ec27cd)
  unreachable
bb41:
  %t289 = load ptr, ptr %l141, !tbaa !29
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t291 = load i32, ptr %l17, !tbaa !23
  %t294 = getelementptr %"compiler/check:Checker", ptr %t290, i32 0, i32 23
  store i32 %t291, ptr %t294, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store ptr %t289, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceName(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i1
  %l12 = alloca ptr
  %l14 = alloca %"compiler/typed:Local"
  %l16 = alloca ptr
  %l17 = alloca i1
  %rv = alloca i32
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t18 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t18, ptr %l12
  br label %bb6
bb6:
  %t19 = load i32, ptr %l2, !tbaa !23
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t22 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t20, i32 %t19)
  store %"compiler/typed:Local" %t22, ptr %l14
  br label %bb7
bb7:
  %t23 = getelementptr %"compiler/typed:Local", ptr %l14, i32 0, i32 0
  %t24 = load i32, ptr %t23, !tbaa !23
  store i32 %t24, ptr %l4, !tbaa !23
  br label %bb19
bb8:
  %t26 = load ptr, ptr %l1, !tbaa !29
  store ptr %t26, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t27 = load ptr, ptr %l16, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb9, label %bb10
bb9:
  %t30 = load ptr, ptr %l16, !tbaa !29
  %t31 = load i64, ptr %t30, !range !{i64 0, i64 8}
  %t33 = icmp eq i64 %t31, 1
  store i1 %t33, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t34 = load i1, ptr %l17, !tbaa !21
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr { i64, [4 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t37, i32 0, i32 3
  %t39 = load i32, ptr %t38
  store i32 %t39, ptr %l3, !tbaa !23
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t41 = load i32, ptr %l3, !tbaa !23
  store i32 %t41, ptr %l4, !tbaa !23
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i32 0, ptr %l4, !tbaa !23
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_1f453287a90ee701_f75bf1e5be6f432d)
  unreachable
bb19:
  %t43 = load i32, ptr %l4, !tbaa !23
  store i32 %t43, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowMethod(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca i32
  %l11 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i1
  %l20 = alloca i1
  %l24 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca i32
  %l42 = alloca i32
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca i64
  %l47 = alloca i64
  %l49 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i32, ptr %l8, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l3, !tbaa !23
  %t11 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t7, i32 %t8)
  store i1 %t11, ptr %l11
  br label %bb2
bb2:
  %t12 = load i1, ptr %l11, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l3, !tbaa !23
  %t17 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t13, i32 %t14)
  store i1 %t17, ptr %l15
  br label %bb5
bb4:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb10
bb5:
  %t18 = load i1, ptr %l15, !tbaa !21
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t23 = load i32, ptr %l3, !tbaa !23
  %t26 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t22, i32 %t23)
  store i1 %t26, ptr %l20
  br label %bb8
bb7:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb9
bb8:
  %t27 = load i1, ptr %l20, !tbaa !21
  store i1 %t27, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l16, !tbaa !21
  %t29 = xor i1 %t28, true
  store i1 %t29, ptr %l12, !tbaa !21
  br label %bb10
bb10:
  %t31 = load i1, ptr %l12, !tbaa !21
  br i1 %t31, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s1
  %t32 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t33 = load i32, ptr %t32, !tbaa !23
  %t35 = icmp sge i32 %t33, 0
  br i1 %t35, label %bb13, label %bb14
bb12:
  br label %bb21
bb13:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i32, ptr %l3, !tbaa !23
  %t39 = load %"compiler/source:Span", ptr %l2
  %t43 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %s1, ptr %s1, ptr %t37, i32 %t38, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d31, i32 0, i32 1) }, i64 1, %"compiler/source:Span" %t39, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d32, i32 0, i32 1) })
  store i64 %t43, ptr %l28
  br label %bb15
bb14:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i32, ptr %l3, !tbaa !23
  %t48 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s1, ptr %t44, i32 %t45, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d33, i32 0, i32 1) }, i64 1)
  store i64 %t48, ptr %l31
  br label %bb16
bb15:
  %t49 = load i64, ptr %l28, !tbaa !24
  store i64 %t49, ptr %l24, !tbaa !24
  br label %bb17
bb16:
  %t50 = load i64, ptr %l31, !tbaa !24
  store i64 %t50, ptr %l24, !tbaa !24
  br label %bb17
bb17:
  %t51 = load i64, ptr %l24, !tbaa !24
  store i64 %t51, ptr %l4, !tbaa !24
  %t52 = load i64, ptr %l4, !tbaa !24
  %t54 = icmp sge i64 %t52, 0
  br i1 %t54, label %bb18, label %bb19
bb18:
  %t56 = load i64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i64 %t56, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s1)
  br label %bb21
bb21:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  store ptr %t61, ptr %l36, !tbaa !29
  %t62 = load i32, ptr %l3, !tbaa !23
  store i32 %t62, ptr %l37, !tbaa !23
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 0
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = getelementptr %"compiler/load:Loader", ptr %t69, i32 0, i32 3
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t72, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d34, i32 0, i32 1) })
  store i32 %t74, ptr %l42
  br label %bb22
bb22:
  %t75 = load ptr, ptr %l36, !tbaa !29
  %t76 = load i32, ptr %l37, !tbaa !23
  %t77 = load i32, ptr %l42, !tbaa !23
  %t78 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultMethods(ptr %v0, ptr %s0, ptr %t75, i32 %t76, i32 %t77)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t78, ptr %l43
  br label %bb23
bb23:
  %t79 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t79, ptr %l5
  %t81 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l5)
  store i64 %t81, ptr %l45
  br label %bb24
bb24:
  %t82 = load i64, ptr %l45, !tbaa !24
  %t83 = icmp eq i64 %t82, 1
  br i1 %t83, label %bb25, label %bb26
bb25:
  %t86 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l5, i64 0)
  store i64 %t86, ptr %l49
  br label %bb27
bb26:
  store i64 -1, ptr %l47, !tbaa !24
  br label %bb28
bb27:
  %t87 = load i64, ptr %l49, !tbaa !24
  store i64 %t87, ptr %l47, !tbaa !24
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s0)
  %t88 = load i64, ptr %l47, !tbaa !24
  store i64 %t88, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushPayload(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, i64 %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %lp12 = alloca ptr
  %l13 = alloca ptr
  %l18 = alloca i32
  %l23 = alloca { i64, ptr }
  %l26 = alloca %"compiler/source:Span"
  %l30 = alloca { i64, ptr }
  %l34 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca %"compiler/source:Span"
  %l39 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l44 = alloca %"compiler/diagmsg:Msg"
  %l45 = alloca i64
  %l49 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca %"compiler/source:Span"
  %l56 = alloca %"compiler/diagmsg:Msg"
  %l57 = alloca i64
  %l63 = alloca i32
  %l69 = alloca { i64, ptr }
  %l79 = alloca ptr
  %l80 = alloca %"compiler/source:Span"
  %l86 = alloca %"compiler/diagmsg:Msg"
  %l87 = alloca i64
  %l90 = alloca [0 x ptr]
  %l91 = alloca { i64, ptr }
  %l95 = alloca i1
  %l101 = alloca { i64, ptr }
  %l108 = alloca %"compiler/source:Span"
  %l109 = alloca ptr
  %l113 = alloca %"compiler/source:Span"
  %l115 = alloca i1
  %l123 = alloca i1
  %l129 = alloca { i64, ptr }
  %l130 = alloca { i64, ptr }
  %l132 = alloca i64
  %l134 = alloca i64
  %l135 = alloca { i64, ptr }
  %l136 = alloca ptr
  %l137 = alloca %"compiler/source:Span"
  %l138 = alloca %"compiler/source:Span"
  %l139 = alloca i32
  %l143 = alloca { i64, ptr }
  %l144 = alloca { i64, ptr }
  %l149 = alloca ptr
  %l152 = alloca i32
  %l155 = alloca ptr
  %l156 = alloca %"compiler/source:Span"
  %l162 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %t344 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i64 %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l3, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l18
  br label %bb1
bb1:
  %t11 = load i32, ptr %l18, !tbaa !23
  store i32 %t11, ptr %l6, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t16 = load i32, ptr %l6, !tbaa !23
  %t17 = load i64, ptr %l4, !tbaa !24
  %t21 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWordFields(ptr %v0, ptr %v0, ptr %t15, i32 %t16, i64 %t17)
  store { i64, ptr } %t21, ptr %l23
  br label %bb2
bb2:
  %t22 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t22, ptr %l7, !tbaa !27
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t27 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epathPart(ptr %v0, ptr %v1, ptr %t23, ptr %t24, i64 0)
  store %"compiler/source:Span" %t27, ptr %l26
  br label %bb3
bb3:
  %t28 = load %"compiler/source:Span", ptr %l26
  store %"compiler/source:Span" %t28, ptr %l8
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l3, !tbaa !23
  %t31 = load i64, ptr %l4, !tbaa !24
  %t35 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordText(ptr %v0, ptr %s0, ptr %t29, i32 %t30, i64 %t31)
  store { i64, ptr } %t35, ptr %l30
  br label %bb4
bb4:
  %t36 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t36, ptr %l9, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t41 = icmp sgt i64 %t39, 0
  br i1 %t41, label %bb5, label %bb6
bb5:
  %t43 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t46 = extractvalue { i64, ptr } { i64 -1, ptr null }, 0
  %t47 = icmp eq i64 %t45, %t46
  %t48 = extractvalue { i64, ptr } %t43, 1
  %t49 = extractvalue { i64, ptr } { i64 -1, ptr null }, 1
  %t50 = icmp eq ptr %t48, %t49
  %t51 = and i1 %t47, %t50
  store i1 %t51, ptr %l34, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb7
bb7:
  %t53 = load i1, ptr %l34, !tbaa !21
  br i1 %t53, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s1
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l37, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t55, ptr %l38
  %t56 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t56, ptr %l39, !tbaa !27
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t61 = call { i64, ptr } @compiler_2fcheck_2efieldNames(ptr %v0, ptr %v0, ptr %s1, ptr %t57, { i64, ptr } %t58)
  store { i64, ptr } %t61, ptr %l42
  br label %bb10
bb9:
  br label %bb13
bb10:
  %t62 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t62, 0
  %t64 = extractvalue { i64, ptr } %t62, 1
  %t65 = mul i64 %t63, 1
  %t66 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t65)
  call void @llvm.memcpy.p0.p0.i64(ptr %t66, ptr %t64, i64 %t65, i1 false)
  %t67 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  %t69 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t71 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePayloadWordBare(ptr %s0, ptr %s1, ptr %s1, { i64, ptr } %t69, { i64, ptr } %t68)
  store %"compiler/diagmsg:Msg" %t71, ptr %l44
  br label %bb11
bb11:
  %t72 = load ptr, ptr %l37, !tbaa !29
  %t73 = load %"compiler/source:Span", ptr %l38
  %t74 = load %"compiler/diagmsg:Msg", ptr %l44
  %t75 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t72, %"compiler/source:Span" %t73, %"compiler/diagmsg:Msg" %t74)
  store i64 %t75, ptr %l45
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb13:
  %t76 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t76, 0
  %t80 = icmp eq i64 %t78, 0
  br i1 %t80, label %bb14, label %bb15
bb14:
  %t82 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t85 = extractvalue { i64, ptr } { i64 -1, ptr null }, 0
  %t86 = icmp eq i64 %t84, %t85
  %t87 = extractvalue { i64, ptr } %t82, 1
  %t88 = extractvalue { i64, ptr } { i64 -1, ptr null }, 1
  %t89 = icmp eq ptr %t87, %t88
  %t90 = and i1 %t86, %t89
  %t92 = xor i1 %t90, true
  store i1 %t92, ptr %l49, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb16
bb16:
  %t94 = load i1, ptr %l49, !tbaa !21
  br i1 %t94, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s2
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l53, !tbaa !29
  %t96 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t96, ptr %l54
  %t97 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t99 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePlainWordCalled(ptr %s0, ptr %s2, { i64, ptr } %t97)
  store %"compiler/diagmsg:Msg" %t99, ptr %l56
  br label %bb19
bb18:
  br label %bb22
bb19:
  %t100 = load ptr, ptr %l53, !tbaa !29
  %t101 = load %"compiler/source:Span", ptr %l54
  %t102 = load %"compiler/diagmsg:Msg", ptr %l56
  %t103 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t100, %"compiler/source:Span" %t101, %"compiler/diagmsg:Msg" %t102)
  store i64 %t103, ptr %l57
  br label %bb20
bb20:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t104, { i64, ptr } %t105)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb22:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/check:Checker", ptr %t108, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t112 = load i32, ptr %l3, !tbaa !23
  %t115 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePayloadOf(ptr %v0, ptr %t111, i32 %t112)
  store i32 %t115, ptr %l63
  br label %bb23
bb23:
  %t116 = load i32, ptr %l63, !tbaa !23
  store i32 %t116, ptr %l10, !tbaa !23
  %t117 = load i32, ptr %l10, !tbaa !23
  %t118 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t121 = icmp eq i32 %t117, %t118
  br i1 %t121, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb25:
  br label %bb26
bb26:
  %t123 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t123, 0
  %t126 = extractvalue { i64, ptr } { i64 -1, ptr null }, 0
  %t127 = icmp eq i64 %t125, %t126
  %t128 = extractvalue { i64, ptr } %t123, 1
  %t129 = extractvalue { i64, ptr } { i64 -1, ptr null }, 1
  %t130 = icmp eq ptr %t128, %t129
  %t131 = and i1 %t127, %t130
  br i1 %t131, label %bb27, label %bb28
bb27:
  %t133 = icmp sge i64 0, 0
  br i1 %t133, label %bb29, label %bb30
bb28:
  %t135 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t135, ptr %l69, !tbaa !27
  br label %bb33
bb29:
  %t137 = icmp sle i64 0, 1152921504606846975
  br i1 %t137, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_97f728d69fa9714_fb4d660b7b54b10)
  unreachable
bb31:
  %t139 = mul i64 0, 8
  %t140 = insertvalue { i64, ptr } undef, i64 0, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t141, ptr %l69, !tbaa !27
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_97f728d69fa9714_fb4d660b7b54b10)
  unreachable
bb33:
  %t143 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t143, ptr %l11, !tbaa !27
  %t144 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t144, 0
  %t147 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t149 = extractvalue { i64, ptr } %t147, 0
  %t152 = icmp ne i64 %t146, %t149
  br i1 %t152, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s4
  %t154 = load ptr, ptr %l0, !tbaa !29
  store ptr %t154, ptr %l79, !tbaa !29
  %t155 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t155, ptr %l80
  %t156 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t157, 0
  %t160 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t160, 0
  %t166 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePayloadArgs(ptr %s0, ptr %s4, { i64, ptr } %t156, i64 %t159, i64 %t162)
  store %"compiler/diagmsg:Msg" %t166, ptr %l86
  br label %bb36
bb35:
  br label %bb39
bb36:
  %t167 = load ptr, ptr %l79, !tbaa !29
  %t168 = load %"compiler/source:Span", ptr %l80
  %t169 = load %"compiler/diagmsg:Msg", ptr %l86
  %t170 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t167, %"compiler/source:Span" %t168, %"compiler/diagmsg:Msg" %t169)
  store i64 %t170, ptr %l87
  br label %bb37
bb37:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load { i64, ptr }, ptr %l11, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t171, { i64, ptr } %t172)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb39:
  store [0 x ptr] zeroinitializer, ptr %l90
  %t175 = mul i64 0, 8
  %t176 = insertvalue { i64, ptr } undef, i64 0, 0
  %t177 = insertvalue { i64, ptr } %t176, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t177, ptr %l91, !tbaa !27
  %t178 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !27
  %t180 = mul i64 0, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t179, ptr %l90, i64 %t180, i1 false)
  %t181 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t181, ptr %lp12
  %t182 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t183 = load ptr, ptr %lp12
  store { i64, ptr } %t182, ptr %t183, !tbaa !27
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/check:Checker", ptr %t184, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !29
  %t188 = load i32, ptr %l6, !tbaa !23
  %t191 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsRaisedError(ptr %v0, ptr %t187, i32 %t188)
  store i1 %t191, ptr %l95
  br label %bb40
bb40:
  %t192 = load i1, ptr %l95, !tbaa !21
  br i1 %t192, label %bb41, label %bb42
bb41:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load %"compiler/source:Span", ptr %l8
  %t195 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t196 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t197 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t203 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eraisedArgs(ptr %v0, ptr %s0, ptr %v0, ptr %v2, ptr %v0, ptr %t193, %"compiler/source:Span" %t194, { i64, ptr } %t195, { i64, ptr } %t196, { i64, ptr } %t197)
  store { i64, ptr } %t203, ptr %l101
  br label %bb43
bb42:
  br label %bb61
bb43:
  %t204 = load { i64, ptr }, ptr %l101, !tbaa !27
  store { i64, ptr } %t204, ptr %l11, !tbaa !27
  %t205 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t207 = extractvalue { i64, ptr } %t205, 0
  %t208 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t210 = extractvalue { i64, ptr } %t208, 0
  %t213 = icmp ne i64 %t207, %t210
  br i1 %t213, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb45:
  br label %bb46
bb46:
  %t215 = load ptr, ptr %l2, !tbaa !29
  %t217 = getelementptr %"compiler/ast:Path", ptr %t215, i32 0, i32 0
  %t218 = load %"compiler/source:Span", ptr %t217
  store %"compiler/source:Span" %t218, ptr %l108
  store ptr %l108, ptr %l109, !tbaa !29
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t221 = getelementptr %"compiler/check:Checker", ptr %t219, i32 0, i32 1
  %t222 = load ptr, ptr %t221, !tbaa !29
  %t223 = load i32, ptr %l6, !tbaa !23
  %t226 = call %"compiler/source:Span" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eRaisedAt(ptr %v0, ptr %t222, i32 %t223)
  store %"compiler/source:Span" %t226, ptr %l113
  br label %bb47
bb47:
  %t227 = load ptr, ptr %l109, !tbaa !29
  %t229 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %t227, ptr %l113)
  store i1 %t229, ptr %l115
  br label %bb48
bb48:
  %t230 = load i1, ptr %l115, !tbaa !21
  %t231 = xor i1 %t230, true
  br i1 %t231, label %bb49, label %bb50
bb49:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t234 = load i32, ptr %l3, !tbaa !23
  %t235 = load i32, ptr %l10, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleRaised(ptr %v0, ptr %t233, i32 %t234, i32 %t235)
  br label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb52
bb52:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/check:Checker", ptr %t239, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !29
  %t243 = load i32, ptr %l10, !tbaa !23
  %t246 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eRaisedSettled(ptr %v0, ptr %t242, i32 %t243)
  store i1 %t246, ptr %l123
  br label %bb53
bb53:
  %t247 = load i1, ptr %l123, !tbaa !21
  %t248 = xor i1 %t247, true
  br i1 %t248, label %bb54, label %bb55
bb54:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load i32, ptr %l10, !tbaa !23
  %t252 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t253 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t258 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleBy(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t250, i32 %t251, { i64, ptr } %t252, { i64, ptr } %t253)
  store { i64, ptr } %t258, ptr %l129
  br label %bb56
bb55:
  br label %bb60
bb56:
  %t259 = load { i64, ptr }, ptr %l129, !tbaa !27
  store { i64, ptr } %t259, ptr %l130, !tbaa !27
  %t260 = load ptr, ptr %lp12
  %t261 = load { i64, ptr }, ptr %t260, !tbaa !27
  %t262 = extractvalue { i64, ptr } %t261, 0
  %t263 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t264 = extractvalue { i64, ptr } %t263, 0
  store i64 %t264, ptr %l132, !tbaa !24
  %t266 = load i64, ptr %l132, !tbaa !24
  %t267 = icmp eq i64 %t262, %t266
  br i1 %t267, label %bb57, label %bb58
bb57:
  %t269 = load ptr, ptr %lp12
  %t270 = getelementptr { i64, ptr }, ptr %t269, i32 0, i32 1
  %t271 = load ptr, ptr %t270, !tbaa !27
  %t272 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !27
  %t274 = load i64, ptr %l132, !tbaa !24
  %t275 = mul i64 %t274, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t271, ptr %t273, i64 %t275, i1 false)
  br label %bb59
bb58:
  %t276 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t277 = extractvalue { i64, ptr } %t276, 0
  store i64 %t277, ptr %l134, !tbaa !24
  %t278 = load i64, ptr %l134, !tbaa !24
  %t279 = mul i64 %t278, 8
  %t280 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t279)
  %t281 = insertvalue { i64, ptr } undef, i64 %t278, 0
  %t282 = insertvalue { i64, ptr } %t281, ptr %t280, 1
  store { i64, ptr } %t282, ptr %l135, !tbaa !27
  %t283 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !27
  %t285 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t286 = load ptr, ptr %t285, !tbaa !27
  %t287 = load i64, ptr %l134, !tbaa !24
  %t288 = mul i64 %t287, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t284, ptr %t286, i64 %t288, i1 false)
  %t289 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t290 = load ptr, ptr %lp12
  store { i64, ptr } %t289, ptr %t290, !tbaa !27
  br label %bb59
bb59:
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t291 = load ptr, ptr %l0, !tbaa !29
  store ptr %t291, ptr %l136, !tbaa !29
  %t292 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t292, ptr %l137
  %t293 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t293, ptr %l138
  %t294 = load i32, ptr %l10, !tbaa !23
  store i32 %t294, ptr %l139, !tbaa !23
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t297 = getelementptr %"compiler/check:Checker", ptr %t295, i32 0, i32 1
  %t298 = load ptr, ptr %t297, !tbaa !29
  %t299 = load i32, ptr %l6, !tbaa !23
  %t302 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %s0, ptr %t298, i32 %t299)
  store { i64, ptr } %t302, ptr %l143
  br label %bb62
bb62:
  %t303 = load { i64, ptr }, ptr %l143, !tbaa !27
  store { i64, ptr } %t303, ptr %l144, !tbaa !27
  %t304 = load i64, ptr %l4, !tbaa !24
  %t306 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t307 = load ptr, ptr %t306, !tbaa !27
  %t308 = getelementptr i32, ptr %t307, i64 %t304
  %t309 = load i32, ptr %t308, !tbaa !33
  %t310 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t311 = load ptr, ptr %lp12
  %t312 = load { i64, ptr }, ptr %t311, !tbaa !27
  %t313 = load ptr, ptr @__olang_prog_scope
  %t314 = load ptr, ptr %l136, !tbaa !29
  %t315 = load %"compiler/source:Span", ptr %l137
  %t316 = load %"compiler/source:Span", ptr %l138
  %t317 = load i32, ptr %l139, !tbaa !23
  %t321 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eenumCase(ptr %v0, ptr %t313, ptr %v0, ptr %v0, ptr %t314, %"compiler/source:Span" %t315, %"compiler/source:Span" %t316, i32 %t317, i32 %t309, { i64, ptr } %t310, { i64, ptr } %t312)
  store ptr %t321, ptr %l149
  br label %bb63
bb63:
  %t322 = load ptr, ptr %l149, !tbaa !29
  store ptr %t322, ptr %l13, !tbaa !29
  %t323 = load ptr, ptr %l13, !tbaa !29
  %t326 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t323)
  store i32 %t326, ptr %l152
  br label %bb64
bb64:
  %t327 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t328 = load i32, ptr %l152, !tbaa !23
  %t330 = icmp eq i32 %t328, %t327
  br i1 %t330, label %bb65, label %bb66
bb65:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb66:
  br label %bb67
bb67:
  %t332 = load ptr, ptr %l0, !tbaa !29
  store ptr %t332, ptr %l155, !tbaa !29
  %t333 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t333, ptr %l156
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t335 = load %"compiler/source:Span", ptr %l1
  %t336 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t337 = load ptr, ptr %l13, !tbaa !29
  %t343 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t334, %"compiler/source:Span" %t335, i32 %t336, i32 46, ptr %t337, ptr null)
  store ptr %t343, ptr %l162
  br label %bb68
bb68:
  store { i64, [3 x i64] } zeroinitializer, ptr %t344
  %t345 = getelementptr { i64, [3 x i64] }, ptr %t344, i32 0, i32 0
  store i64 2, ptr %t345
  %t346 = load %"compiler/source:Span", ptr %l156
  %t347 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t346, 0
  %t348 = load ptr, ptr %l162, !tbaa !29
  %t349 = insertvalue { %"compiler/source:Span", ptr } %t347, ptr %t348, 1
  %t350 = getelementptr { i64, [3 x i64] }, ptr %t344, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t349, ptr %t350
  %t351 = load { i64, [3 x i64] }, ptr %t344
  %t353 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t351, ptr %t353
  %t354 = load ptr, ptr %l155, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t354, ptr %t353)
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawEnum(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i32 %a1, { i64, ptr } %a2, ptr %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca i1
  %lp5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i1
  %l12 = alloca i64
  %lp13 = alloca ptr
  %lp14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca %"compiler/check:litv"
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca %"compiler/check:litv"
  %l33 = alloca %"compiler/check:signMag"
  %l34 = alloca i1
  %l35 = alloca i128
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i32
  %l45 = alloca { i64, ptr }
  %l49 = alloca %"compiler/check:rawTable"
  %l60 = alloca { i64, ptr }
  %l67 = alloca ptr
  %l73 = alloca %"compiler/source:Span"
  %l74 = alloca %"compiler/diagmsg:Msg"
  %l75 = alloca i64
  %l80 = alloca ptr
  %l84 = alloca %"compiler/generic:Context"
  %l88 = alloca i32
  %l95 = alloca ptr
  %l96 = alloca i32
  %l98 = alloca i32
  %l99 = alloca i1
  %l102 = alloca i1
  %l105 = alloca i1
  %l108 = alloca ptr
  %l110 = alloca %"compiler/source:Span"
  %l113 = alloca { i64, ptr }
  %l115 = alloca %"compiler/diagmsg:Msg"
  %l116 = alloca i64
  %l120 = alloca i64
  %l124 = alloca i64
  %l126 = alloca { i64, ptr }
  %l130 = alloca i64
  %l133 = alloca %"compiler/check:litv"
  %l138 = alloca i64
  %l141 = alloca i64
  %l159 = alloca { i64, ptr }
  %l163 = alloca i1
  %l167 = alloca { i64, ptr }
  %l168 = alloca i1
  %l169 = alloca ptr
  %l172 = alloca %"compiler/source:Span"
  %l173 = alloca %"compiler/diagmsg:Msg"
  %l174 = alloca i64
  %l178 = alloca %"compiler/source:Span"
  %l181 = alloca %"compiler/source:Span"
  %l187 = alloca %"compiler/source:Span"
  %l192 = alloca i64
  %l196 = alloca { i64, ptr }
  %l197 = alloca { i64, ptr }
  %l199 = alloca %"compiler/source:Span"
  %l200 = alloca ptr
  %l206 = alloca %"compiler/source:Span"
  %l207 = alloca i32
  %l209 = alloca i1
  %l211 = alloca ptr
  %l212 = alloca %"compiler/source:Span"
  %l215 = alloca { i64, ptr }
  %l217 = alloca %"compiler/diagmsg:Msg"
  %l218 = alloca i64
  %l219 = alloca i64
  %l222 = alloca { i64, ptr }
  %l228 = alloca i64
  %l231 = alloca i64
  %l251 = alloca i1
  %l253 = alloca { i64, ptr }
  %l256 = alloca { i64, ptr }
  %l258 = alloca i1
  %l260 = alloca ptr
  %l261 = alloca %"compiler/source:Span"
  %l265 = alloca { i64, ptr }
  %l268 = alloca { i64, ptr }
  %l269 = alloca i64
  %l270 = alloca { i64, ptr }
  %l273 = alloca { i64, ptr }
  %l275 = alloca { i64, ptr }
  %l279 = alloca { i64, ptr }
  %l280 = alloca %"compiler/diagmsg:Msg"
  %l281 = alloca i64
  %l284 = alloca %"compiler/check:litv"
  %l289 = alloca %"compiler/check:signMag"
  %l293 = alloca %"compiler/check:litv"
  %l296 = alloca %"compiler/check:litv"
  %l297 = alloca %"compiler/check:litv"
  %l304 = alloca i1
  %l305 = alloca i1
  %l311 = alloca i1
  %l312 = alloca ptr
  %l318 = alloca %"compiler/check:litv"
  %l321 = alloca i1
  %l324 = alloca ptr
  %l325 = alloca %"compiler/source:Span"
  %l330 = alloca %"compiler/diagmsg:Msg"
  %l333 = alloca { i64, ptr }
  %l335 = alloca %"compiler/diagmsg:Msg"
  %l338 = alloca { i64, ptr }
  %l340 = alloca %"compiler/diagmsg:Msg"
  %l341 = alloca i64
  %l342 = alloca %"compiler/check:litv"
  %l347 = alloca i1
  %l350 = alloca ptr
  %l351 = alloca %"compiler/source:Span"
  %l353 = alloca { i64, ptr }
  %l354 = alloca { i64, ptr }
  %l357 = alloca { i64, ptr }
  %l359 = alloca %"compiler/diagmsg:Msg"
  %l360 = alloca i64
  %l368 = alloca i64
  %l371 = alloca i64
  %l391 = alloca i1
  %l398 = alloca ptr
  %l399 = alloca %"compiler/source:Span"
  %l403 = alloca { i64, ptr }
  %l405 = alloca { i64, ptr }
  %l406 = alloca { i64, ptr }
  %l408 = alloca { i64, ptr }
  %l412 = alloca { i64, ptr }
  %l413 = alloca %"compiler/diagmsg:Msg"
  %l414 = alloca i64
  %l423 = alloca %"compiler/check:rawTable"
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %rv = alloca ptr
  %t94 = alloca %"compiler/generic:Context", align 8
  %t202 = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t1, ptr %l42, !tbaa !23
  %t2 = icmp sge i64 0, 0
  br i1 %t2, label %bb1, label %bb2
bb1:
  %t4 = icmp sle i64 0, 1152921504606846975
  br i1 %t4, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_ff4549fd04ada907_b78a4102fd7994db)
  unreachable
bb3:
  %t6 = mul i64 0, 8
  %t7 = insertvalue { i64, ptr } undef, i64 0, 0
  %t8 = insertvalue { i64, ptr } %t7, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t8, ptr %l45, !tbaa !27
  %t9 = icmp sge i64 0, 0
  br i1 %t9, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_ff4549fd04ada907_b78a4102fd7994db)
  unreachable
bb5:
  %t11 = icmp sle i64 0, 576460752303423487
  br i1 %t11, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_ff4549fd04ada907_b78a4102fd7994db)
  unreachable
bb7:
  %t13 = mul i64 0, 16
  %t14 = insertvalue { i64, ptr } undef, i64 0, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t16 = load i32, ptr %l42, !tbaa !23
  %t17 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t19 = call %"compiler/check:rawTable" @compiler_2fcheck_3arawTable_2ector(ptr %v3, ptr %v3, ptr %v3, i32 %t16, i1 false, { i64, ptr } %t17, { i64, ptr } %t15)
  store %"compiler/check:rawTable" %t19, ptr %l49
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_ff4549fd04ada907_b78a4102fd7994db)
  unreachable
bb9:
  %t20 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store ptr %t20, ptr %lp5
  %t21 = load %"compiler/check:rawTable", ptr %l49
  %t22 = load ptr, ptr %lp5
  store %"compiler/check:rawTable" %t21, ptr %t22
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  br i1 %t25, label %bb10, label %bb11
bb10:
  %t27 = load i1, ptr %l4, !tbaa !21
  br i1 %t27, label %bb12, label %bb13
bb11:
  br label %bb30
bb12:
  %t29 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t29, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  store i64 %t33, ptr %l8, !tbaa !24
  br label %bb14
bb13:
  br label %bb29
bb14:
  %t35 = load i64, ptr %l7, !tbaa !24
  %t36 = load i64, ptr %l8, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb15, label %bb16
bb15:
  br label %bb28
bb16:
  br label %bb17
bb17:
  %t43 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t43, ptr %l60, !tbaa !27
  %t44 = load i64, ptr %l7, !tbaa !24
  %t46 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr ptr, ptr %t47, i64 %t44
  %t49 = load ptr, ptr %t48, !tbaa !39
  store ptr %t49, ptr %l9, !tbaa !29
  %t51 = load ptr, ptr %l9, !tbaa !29
  %t53 = getelementptr %"compiler/ast:CaseDecl", ptr %t51, i32 0, i32 4
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = icmp eq ptr %t54, null
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s5
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l67, !tbaa !29
  %t61 = load ptr, ptr %l9, !tbaa !29
  %t63 = getelementptr %"compiler/ast:CaseDecl", ptr %t61, i32 0, i32 4
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = icmp eq ptr %t64, null
  br i1 %t66, label %bb20, label %bb21
bb19:
  br label %bb26
bb20:
  call void @__olang_check_failed(ptr @olang_loc_674ca34a4d5f8d72_a138681dd06a86e)
  unreachable
bb21:
  br label %bb22
bb22:
  %t68 = load ptr, ptr %l9, !tbaa !29
  %t70 = getelementptr %"compiler/ast:CaseDecl", ptr %t68, i32 0, i32 4
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t71)
  store %"compiler/source:Span" %t73, ptr %l73
  br label %bb23
bb23:
  %t74 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRawWithoutType(ptr %s5)
  store %"compiler/diagmsg:Msg" %t74, ptr %l74
  br label %bb24
bb24:
  %t75 = load ptr, ptr %l67, !tbaa !29
  %t76 = load %"compiler/source:Span", ptr %l73
  %t77 = load %"compiler/diagmsg:Msg", ptr %l74
  %t78 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t75, %"compiler/source:Span" %t76, %"compiler/diagmsg:Msg" %t77)
  store i64 %t78, ptr %l75
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s5)
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t79 = load i64, ptr %l7, !tbaa !24
  %t81 = add i64 %t79, 1
  store i64 %t81, ptr %l7, !tbaa !24
  br label %bb14
bb28:
  br label %bb29
bb29:
  %t83 = load ptr, ptr %lp5
  call void @__olang_scope_close(ptr %s0)
  store ptr %t83, ptr %rv
  br label %ret
bb30:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  store ptr %t88, ptr %l80, !tbaa !29
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/check:Checker", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclContext(ptr %t94, ptr %v0, ptr %s0, ptr %t92, i32 %a1)
  call void @llvm.memmove.p0.p0.i64(ptr %l84, ptr %t94, i64 160, i1 false)
  br label %bb31
bb31:
  %t97 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 160, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t97, ptr %l84, i64 160, i1 false)
  %t98 = load ptr, ptr %l3, !tbaa !29
  %t100 = load ptr, ptr %l80, !tbaa !29
  %t103 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %s0, ptr %v2, ptr %t100, ptr %t97, ptr %t98)
  store i32 %t103, ptr %l88
  br label %bb32
bb32:
  %t104 = load i32, ptr %l88, !tbaa !23
  store i32 %t104, ptr %l10, !tbaa !23
  %t105 = load i32, ptr %l10, !tbaa !23
  %t106 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t109 = icmp eq i32 %t105, %t106
  br i1 %t109, label %bb33, label %bb34
bb33:
  %t111 = load ptr, ptr %lp5
  call void @__olang_scope_close(ptr %s0)
  store ptr %t111, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/check:Checker", ptr %t113, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = getelementptr %"compiler/generic:Program", ptr %t116, i32 0, i32 2
  store ptr %t118, ptr %l95, !tbaa !29
  %t119 = load i32, ptr %l10, !tbaa !23
  store i32 %t119, ptr %l96, !tbaa !23
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t120)
  store i32 %t122, ptr %l98
  br label %bb36
bb36:
  %t123 = load ptr, ptr %l95, !tbaa !29
  %t124 = load i32, ptr %l96, !tbaa !23
  %t125 = load i32, ptr %l98, !tbaa !23
  %t126 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t123, i32 %t124, i32 %t125)
  store i1 %t126, ptr %l99
  br label %bb37
bb37:
  %t127 = load i1, ptr %l99, !tbaa !21
  store i1 %t127, ptr %l11, !tbaa !21
  %t128 = load i1, ptr %l11, !tbaa !21
  %t130 = xor i1 %t128, true
  br i1 %t130, label %bb38, label %bb39
bb38:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load i32, ptr %l10, !tbaa !23
  %t136 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %t132, i32 %t133)
  store i1 %t136, ptr %l105
  br label %bb40
bb39:
  store i1 false, ptr %l102, !tbaa !21
  br label %bb41
bb40:
  %t137 = load i1, ptr %l105, !tbaa !21
  %t138 = xor i1 %t137, true
  store i1 %t138, ptr %l102, !tbaa !21
  br label %bb41
bb41:
  %t140 = load i1, ptr %l102, !tbaa !21
  br i1 %t140, label %bb42, label %bb43
bb42:
  %t141 = load i1, ptr %l4, !tbaa !21
  br i1 %t141, label %bb44, label %bb45
bb43:
  br label %bb51
bb44:
  store %olang.scope zeroinitializer, ptr %s9
  %t143 = load ptr, ptr %l0, !tbaa !29
  store ptr %t143, ptr %l108, !tbaa !29
  %t144 = load ptr, ptr %l3, !tbaa !29
  %t146 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %t144)
  store %"compiler/source:Span" %t146, ptr %l110
  br label %bb46
bb45:
  br label %bb50
bb46:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load i32, ptr %l10, !tbaa !23
  %t151 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t147, i32 %t148)
  store { i64, ptr } %t151, ptr %l113
  br label %bb47
bb47:
  %t152 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t153 = extractvalue { i64, ptr } %t152, 0
  %t154 = extractvalue { i64, ptr } %t152, 1
  %t155 = mul i64 %t153, 1
  %t156 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t155)
  call void @llvm.memcpy.p0.p0.i64(ptr %t156, ptr %t154, i64 %t155, i1 false)
  %t157 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t156, 1
  %t160 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRawType(ptr %s9, ptr %s9, { i64, ptr } %t158)
  store %"compiler/diagmsg:Msg" %t160, ptr %l115
  br label %bb48
bb48:
  %t161 = load ptr, ptr %l108, !tbaa !29
  %t162 = load %"compiler/source:Span", ptr %l110
  %t163 = load %"compiler/diagmsg:Msg", ptr %l115
  %t164 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s9, ptr %t161, %"compiler/source:Span" %t162, %"compiler/diagmsg:Msg" %t163)
  store i64 %t164, ptr %l116
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s9)
  br label %bb50
bb50:
  %t165 = load ptr, ptr %lp5
  call void @__olang_scope_close(ptr %s0)
  store ptr %t165, ptr %rv
  br label %ret
bb51:
  %t167 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t167, 0
  store i64 %t169, ptr %l12, !tbaa !24
  %t171 = load i64, ptr %l12, !tbaa !24
  store i64 %t171, ptr %l120, !tbaa !24
  %t172 = load i64, ptr %l120, !tbaa !24
  %t173 = icmp sge i64 %t172, 0
  br i1 %t173, label %bb52, label %bb53
bb52:
  %t175 = load i64, ptr %l120, !tbaa !24
  %t176 = icmp sle i64 %t175, 1152921504606846975
  br i1 %t176, label %bb54, label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_5479af00bceefeb1_f5b0eb753f441165)
  unreachable
bb54:
  %t178 = load i64, ptr %l120, !tbaa !24
  %t179 = mul i64 %t178, 8
  %t180 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t179)
  %t181 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  %t183 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 16, i64 8)
  store ptr %t183, ptr %lp13
  %t185 = load ptr, ptr %lp13
  store { i64, ptr } %t182, ptr %t185, !tbaa !27
  %t186 = load i64, ptr %l12, !tbaa !24
  store i64 %t186, ptr %l124, !tbaa !24
  %t187 = icmp sge i64 0, 0
  br i1 %t187, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_5479af00bceefeb1_f5b0eb753f441165)
  unreachable
bb56:
  %t189 = mul i64 0, 1
  %t190 = insertvalue { i64, ptr } undef, i64 0, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t191, ptr %l126, !tbaa !27
  %t192 = load i64, ptr %l124, !tbaa !24
  %t193 = icmp sge i64 %t192, 0
  br i1 %t193, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_4e17f4aa3948dea4_42025b20baf190f8)
  unreachable
bb58:
  %t195 = load i64, ptr %l124, !tbaa !24
  %t196 = icmp sle i64 %t195, 576460752303423487
  br i1 %t196, label %bb60, label %bb61
bb59:
  call void @__olang_check_failed(ptr @olang_loc_4e17f4aa3948dea4_42025b20baf190f8)
  unreachable
bb60:
  %t198 = load i64, ptr %l124, !tbaa !24
  %t199 = mul i64 %t198, 16
  %t200 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t199)
  %t201 = load { i64, ptr }, ptr %l126, !tbaa !27
  store i64 0, ptr %t202
  br label %fill.203
fill.203:
  %t206 = load i64, ptr %t202
  %t207 = icmp slt i64 %t206, %t198
  br i1 %t207, label %fillb.204, label %filld.205
fillb.204:
  %t208 = getelementptr { i64, ptr }, ptr %t200, i64 %t206
  store { i64, ptr } %t201, ptr %t208
  %t209 = add i64 %t206, 1
  store i64 %t209, ptr %t202
  br label %fill.203
filld.205:
  %t210 = insertvalue { i64, ptr } undef, i64 %t198, 0
  %t211 = insertvalue { i64, ptr } %t210, ptr %t200, 1
  %t212 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 16, i64 8)
  store ptr %t212, ptr %lp14
  %t214 = load ptr, ptr %lp14
  store { i64, ptr } %t211, ptr %t214, !tbaa !27
  %t215 = load i64, ptr %l12, !tbaa !24
  store i64 %t215, ptr %l130, !tbaa !24
  %t216 = load i64, ptr %l130, !tbaa !24
  %t217 = icmp sge i64 %t216, 0
  br i1 %t217, label %bb62, label %bb63
bb61:
  call void @__olang_check_failed(ptr @olang_loc_4e17f4aa3948dea4_42025b20baf190f8)
  unreachable
bb62:
  %t219 = load i64, ptr %l130, !tbaa !24
  %t220 = mul i64 %t219, 1
  %t221 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t220)
  %t222 = insertvalue { i64, ptr } undef, i64 %t219, 0
  %t223 = insertvalue { i64, ptr } %t222, ptr %t221, 1
  store { i64, ptr } %t223, ptr %l15, !tbaa !27
  %t225 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2eintLit(i64 -1)
  store %"compiler/check:litv" %t225, ptr %l133
  br label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_15162faa0a6b8e7b_16d808b76471f267)
  unreachable
bb64:
  %t226 = load %"compiler/check:litv", ptr %l133
  store %"compiler/check:litv" %t226, ptr %l16
  store i64 0, ptr %l17, !tbaa !24
  %t227 = load i64, ptr %l12, !tbaa !24
  store i64 %t227, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t229 = load i64, ptr %l18, !tbaa !24
  %t230 = load i64, ptr %l17, !tbaa !24
  %t233 = icmp sgt i64 %t229, %t230
  br i1 %t233, label %bb65, label %bb66
bb65:
  %t235 = load i64, ptr %l19, !tbaa !24
  %t237 = icmp sgt i64 %t235, 0
  br i1 %t237, label %bb67, label %bb68
bb66:
  store i64 0, ptr %l138, !tbaa !24
  br label %bb70
bb67:
  %t239 = load i64, ptr %l18, !tbaa !24
  %t240 = load i64, ptr %l17, !tbaa !24
  %t243 = sub i64 %t239, %t240
  %t244 = load i64, ptr %l19, !tbaa !24
  %t247 = add i64 %t243, %t244
  %t249 = sub i64 %t247, 1
  %t250 = load i64, ptr %l19, !tbaa !24
  %t253 = sdiv i64 %t249, %t250
  store i64 %t253, ptr %l141, !tbaa !24
  br label %bb69
bb68:
  store i64 0, ptr %l141, !tbaa !24
  br label %bb69
bb69:
  %t255 = load i64, ptr %l141, !tbaa !24
  store i64 %t255, ptr %l138, !tbaa !24
  br label %bb70
bb70:
  %t256 = load i64, ptr %l138, !tbaa !24
  store i64 %t256, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb71
bb71:
  store %olang.scope zeroinitializer, ptr %s11
  %t257 = load i64, ptr %l21, !tbaa !24
  %t258 = load i64, ptr %l20, !tbaa !24
  %t261 = icmp slt i64 %t257, %t258
  %t263 = xor i1 %t261, true
  br i1 %t263, label %bb72, label %bb73
bb72:
  call void @__olang_scope_close(ptr %s11)
  br label %bb226
bb73:
  br label %bb74
bb74:
  %t265 = load i64, ptr %l17, !tbaa !24
  %t266 = load i64, ptr %l21, !tbaa !24
  %t267 = load i64, ptr %l19, !tbaa !24
  %t270 = mul i64 %t266, %t267
  %t273 = add i64 %t265, %t270
  store i64 %t273, ptr %l22, !tbaa !24
  %t275 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t275, ptr %l159, !tbaa !27
  %t276 = load i64, ptr %l22, !tbaa !24
  %t278 = getelementptr { i64, ptr }, ptr %l159, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = getelementptr ptr, ptr %t279, i64 %t276
  %t281 = load ptr, ptr %t280, !tbaa !39
  store ptr %t281, ptr %l23, !tbaa !29
  %t283 = load i1, ptr %l4, !tbaa !21
  br i1 %t283, label %bb75, label %bb76
bb75:
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t286 = load ptr, ptr %l23, !tbaa !29
  %t288 = getelementptr %"compiler/ast:CaseDecl", ptr %t286, i32 0, i32 1
  %t289 = load i32, ptr %t288, !tbaa !23
  %t292 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t285, i32 %t289)
  store { i64, ptr } %t292, ptr %l167
  br label %bb77
bb76:
  store i1 false, ptr %l163, !tbaa !21
  br label %bb79
bb77:
  %t293 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t294 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s11, { i64, ptr } %t293, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store i1 %t294, ptr %l168
  br label %bb78
bb78:
  %t295 = load i1, ptr %l168, !tbaa !21
  store i1 %t295, ptr %l163, !tbaa !21
  br label %bb79
bb79:
  %t296 = load i1, ptr %l163, !tbaa !21
  br i1 %t296, label %bb80, label %bb81
bb80:
  store %olang.scope zeroinitializer, ptr %s12
  %t297 = load ptr, ptr %l0, !tbaa !29
  store ptr %t297, ptr %l169, !tbaa !29
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t299 = load ptr, ptr %l23, !tbaa !29
  %t302 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseNameSpan(ptr %v0, ptr %v1, ptr %t298, ptr %t299)
  store %"compiler/source:Span" %t302, ptr %l172
  br label %bb82
bb81:
  br label %bb85
bb82:
  %t303 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFromCaseName(ptr %s12)
  store %"compiler/diagmsg:Msg" %t303, ptr %l173
  br label %bb83
bb83:
  %t304 = load ptr, ptr %l169, !tbaa !29
  %t305 = load %"compiler/source:Span", ptr %l172
  %t306 = load %"compiler/diagmsg:Msg", ptr %l173
  %t307 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s12, ptr %t304, %"compiler/source:Span" %t305, %"compiler/diagmsg:Msg" %t306)
  store i64 %t307, ptr %l174
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s12)
  br label %bb85
bb85:
  %t308 = load ptr, ptr %l23, !tbaa !29
  %t310 = getelementptr %"compiler/ast:CaseDecl", ptr %t308, i32 0, i32 4
  %t311 = load ptr, ptr %t310, !tbaa !29
  %t313 = icmp eq ptr %t311, null
  br i1 %t313, label %bb86, label %bb87
bb86:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t316 = load ptr, ptr %l23, !tbaa !29
  %t319 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseNameSpan(ptr %v0, ptr %v1, ptr %t315, ptr %t316)
  store %"compiler/source:Span" %t319, ptr %l181
  br label %bb88
bb87:
  %t320 = load ptr, ptr %l23, !tbaa !29
  %t322 = getelementptr %"compiler/ast:CaseDecl", ptr %t320, i32 0, i32 4
  %t323 = load ptr, ptr %t322, !tbaa !29
  %t325 = icmp eq ptr %t323, null
  br i1 %t325, label %bb89, label %bb90
bb88:
  %t327 = load %"compiler/source:Span", ptr %l181
  store %"compiler/source:Span" %t327, ptr %l178
  br label %bb93
bb89:
  call void @__olang_check_failed(ptr @olang_loc_c9b25feecc9d128e_1218ffeebcd03452)
  unreachable
bb90:
  br label %bb91
bb91:
  %t328 = load ptr, ptr %l23, !tbaa !29
  %t330 = getelementptr %"compiler/ast:CaseDecl", ptr %t328, i32 0, i32 4
  %t331 = load ptr, ptr %t330, !tbaa !29
  %t333 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t331)
  store %"compiler/source:Span" %t333, ptr %l187
  br label %bb92
bb92:
  %t334 = load %"compiler/source:Span", ptr %l187
  store %"compiler/source:Span" %t334, ptr %l178
  br label %bb93
bb93:
  %t335 = load %"compiler/source:Span", ptr %l178
  store %"compiler/source:Span" %t335, ptr %l24
  %t336 = load i1, ptr %l11, !tbaa !21
  br i1 %t336, label %bb94, label %bb95
bb94:
  %t338 = load ptr, ptr %l23, !tbaa !29
  %t340 = getelementptr %"compiler/ast:CaseDecl", ptr %t338, i32 0, i32 4
  %t341 = load ptr, ptr %t340, !tbaa !29
  %t343 = icmp eq ptr %t341, null
  br i1 %t343, label %bb96, label %bb97
bb95:
  br label %bb141
bb96:
  %t345 = load i64, ptr %l22, !tbaa !24
  store i64 %t345, ptr %l192, !tbaa !24
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t347 = load ptr, ptr %l23, !tbaa !29
  %t349 = getelementptr %"compiler/ast:CaseDecl", ptr %t347, i32 0, i32 1
  %t350 = load i32, ptr %t349, !tbaa !23
  %t353 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t346, i32 %t350)
  store { i64, ptr } %t353, ptr %l196
  br label %bb98
bb97:
  %t354 = load ptr, ptr %l0, !tbaa !29
  store ptr %t354, ptr %l200, !tbaa !29
  %t355 = load ptr, ptr %l23, !tbaa !29
  %t357 = getelementptr %"compiler/ast:CaseDecl", ptr %t355, i32 0, i32 4
  %t358 = load ptr, ptr %t357, !tbaa !29
  %t360 = icmp eq ptr %t358, null
  br i1 %t360, label %bb100, label %bb101
bb98:
  %t362 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t363 = call { i64, ptr } @compiler_2fcheck_2etextBytes(ptr %v0, ptr %v3, { i64, ptr } %t362)
  store { i64, ptr } %t363, ptr %l197
  br label %bb99
bb99:
  %t364 = load { i64, ptr }, ptr %l197, !tbaa !27
  %t365 = extractvalue { i64, ptr } %t364, 0
  %t366 = extractvalue { i64, ptr } %t364, 1
  %t367 = mul i64 %t365, 1
  %t368 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t367)
  call void @llvm.memcpy.p0.p0.i64(ptr %t368, ptr %t366, i64 %t367, i1 false)
  %t369 = insertvalue { i64, ptr } undef, i64 %t365, 0
  %t370 = insertvalue { i64, ptr } %t369, ptr %t368, 1
  %t372 = load ptr, ptr %lp14
  %t373 = load i64, ptr %l192, !tbaa !24
  %t374 = getelementptr { i64, ptr }, ptr %t372, i32 0, i32 1
  %t375 = load ptr, ptr %t374, !tbaa !27
  %t376 = getelementptr { i64, ptr }, ptr %t375, i64 %t373
  store { i64, ptr } %t370, ptr %t376, !tbaa !37
  br label %bb114
bb100:
  call void @__olang_check_failed(ptr @olang_loc_7a0bf9c228cd53f_3b674c8d006cd93)
  unreachable
bb101:
  br label %bb102
bb102:
  %t377 = load ptr, ptr %l23, !tbaa !29
  %t379 = getelementptr %"compiler/ast:CaseDecl", ptr %t377, i32 0, i32 4
  %t380 = load ptr, ptr %t379, !tbaa !29
  %t381 = load ptr, ptr %l200, !tbaa !29
  %t383 = call { i32, %"compiler/source:Span" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextValue(ptr %v0, ptr %v1, ptr %t381, ptr %t380)
  %t384 = extractvalue { i32, %"compiler/source:Span" } %t383, 1
  %t385 = extractvalue { i32, %"compiler/source:Span" } %t383, 0
  store i32 %t385, ptr %l207
  %t386 = icmp ne i32 %t385, 0
  br i1 %t386, label %bb104, label %ok.387, !prof !99
ok.387:
  store %"compiler/source:Span" %t384, ptr %l206
  br label %bb103
bb103:
  %t388 = load %"compiler/source:Span", ptr %l206
  store %"compiler/source:Span" %t388, ptr %l199
  br label %bb112
bb104:
  %t389 = load i32, ptr %l207, !tbaa !23
  %t390 = ashr i32 %t389, 16
  %t392 = icmp eq i32 %t390, 1
  store i1 %t392, ptr %l209, !tbaa !21
  br label %bb105
bb105:
  %t393 = load i1, ptr %l4, !tbaa !21
  br i1 %t393, label %bb106, label %bb107
bb106:
  store %olang.scope zeroinitializer, ptr %s17
  %t395 = load ptr, ptr %l0, !tbaa !29
  store ptr %t395, ptr %l211, !tbaa !29
  %t396 = load %"compiler/source:Span", ptr %l24
  store %"compiler/source:Span" %t396, ptr %l212
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t398 = load i32, ptr %l10, !tbaa !23
  %t401 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s17, ptr %t397, i32 %t398)
  store { i64, ptr } %t401, ptr %l215
  br label %bb108
bb107:
  br label %bb111
bb108:
  %t402 = load { i64, ptr }, ptr %l215, !tbaa !27
  %t403 = extractvalue { i64, ptr } %t402, 0
  %t404 = extractvalue { i64, ptr } %t402, 1
  %t405 = mul i64 %t403, 1
  %t406 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t405)
  call void @llvm.memcpy.p0.p0.i64(ptr %t406, ptr %t404, i64 %t405, i1 false)
  %t407 = insertvalue { i64, ptr } undef, i64 %t403, 0
  %t408 = insertvalue { i64, ptr } %t407, ptr %t406, 1
  %t410 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRawNotLiteral(ptr %s17, ptr %s17, { i64, ptr } %t408)
  store %"compiler/diagmsg:Msg" %t410, ptr %l217
  br label %bb109
bb109:
  %t411 = load ptr, ptr %l211, !tbaa !29
  %t412 = load %"compiler/source:Span", ptr %l212
  %t413 = load %"compiler/diagmsg:Msg", ptr %l217
  %t414 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s17, ptr %t411, %"compiler/source:Span" %t412, %"compiler/diagmsg:Msg" %t413)
  store i64 %t414, ptr %l218
  br label %bb110
bb110:
  call void @__olang_scope_close(ptr %s17)
  br label %bb111
bb111:
  call void @__olang_scope_close(ptr %s11)
  br label %bb225
bb112:
  %t415 = load %"compiler/source:Span", ptr %l199
  %t416 = load i64, ptr %l22, !tbaa !24
  store i64 %t416, ptr %l219, !tbaa !24
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t421 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estrBytes(ptr %v0, ptr %v3, ptr %t417, %"compiler/source:Span" %t415)
  store { i64, ptr } %t421, ptr %l222
  br label %bb113
bb113:
  %t422 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t423 = load ptr, ptr %lp14
  %t424 = load i64, ptr %l219, !tbaa !24
  %t425 = getelementptr { i64, ptr }, ptr %t423, i32 0, i32 1
  %t426 = load ptr, ptr %t425, !tbaa !27
  %t427 = getelementptr { i64, ptr }, ptr %t426, i64 %t424
  store { i64, ptr } %t422, ptr %t427, !tbaa !37
  br label %bb114
bb114:
  %t428 = load i64, ptr %l22, !tbaa !24
  %t430 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t431 = load ptr, ptr %t430, !tbaa !27
  %t432 = getelementptr i1, ptr %t431, i64 %t428
  store i1 true, ptr %t432, !tbaa !31
  store i64 0, ptr %l26, !tbaa !24
  %t433 = load i64, ptr %l22, !tbaa !24
  store i64 %t433, ptr %l27, !tbaa !24
  store i64 1, ptr %l28, !tbaa !24
  %t435 = load i64, ptr %l27, !tbaa !24
  %t436 = load i64, ptr %l26, !tbaa !24
  %t439 = icmp sgt i64 %t435, %t436
  br i1 %t439, label %bb115, label %bb116
bb115:
  %t441 = load i64, ptr %l28, !tbaa !24
  %t443 = icmp sgt i64 %t441, 0
  br i1 %t443, label %bb117, label %bb118
bb116:
  store i64 0, ptr %l228, !tbaa !24
  br label %bb120
bb117:
  %t445 = load i64, ptr %l27, !tbaa !24
  %t446 = load i64, ptr %l26, !tbaa !24
  %t449 = sub i64 %t445, %t446
  %t450 = load i64, ptr %l28, !tbaa !24
  %t453 = add i64 %t449, %t450
  %t455 = sub i64 %t453, 1
  %t456 = load i64, ptr %l28, !tbaa !24
  %t459 = sdiv i64 %t455, %t456
  store i64 %t459, ptr %l231, !tbaa !24
  br label %bb119
bb118:
  store i64 0, ptr %l231, !tbaa !24
  br label %bb119
bb119:
  %t461 = load i64, ptr %l231, !tbaa !24
  store i64 %t461, ptr %l228, !tbaa !24
  br label %bb120
bb120:
  %t462 = load i64, ptr %l228, !tbaa !24
  store i64 %t462, ptr %l29, !tbaa !24
  store i64 0, ptr %l30, !tbaa !24
  br label %bb121
bb121:
  %t463 = load i64, ptr %l30, !tbaa !24
  %t464 = load i64, ptr %l29, !tbaa !24
  %t467 = icmp slt i64 %t463, %t464
  %t469 = xor i1 %t467, true
  br i1 %t469, label %bb122, label %bb123
bb122:
  br label %bb140
bb123:
  br label %bb124
bb124:
  %t471 = load i64, ptr %l26, !tbaa !24
  %t472 = load i64, ptr %l30, !tbaa !24
  %t473 = load i64, ptr %l28, !tbaa !24
  %t476 = mul i64 %t472, %t473
  %t479 = add i64 %t471, %t476
  store i64 %t479, ptr %l31, !tbaa !24
  %t481 = load i64, ptr %l31, !tbaa !24
  %t483 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t484 = load ptr, ptr %t483, !tbaa !27
  %t485 = getelementptr i1, ptr %t484, i64 %t481
  %t486 = load i1, ptr %t485, !tbaa !31
  br i1 %t486, label %bb125, label %bb126
bb125:
  %t488 = load i64, ptr %l31, !tbaa !24
  %t489 = load ptr, ptr %lp14
  %t491 = getelementptr { i64, ptr }, ptr %t489, i32 0, i32 1
  %t492 = load ptr, ptr %t491, !tbaa !27
  %t493 = getelementptr { i64, ptr }, ptr %t492, i64 %t488
  %t494 = load { i64, ptr }, ptr %t493, !tbaa !37
  store { i64, ptr } %t494, ptr %l253, !tbaa !27
  %t495 = load i64, ptr %l22, !tbaa !24
  %t496 = load ptr, ptr %lp14
  %t498 = getelementptr { i64, ptr }, ptr %t496, i32 0, i32 1
  %t499 = load ptr, ptr %t498, !tbaa !27
  %t500 = getelementptr { i64, ptr }, ptr %t499, i64 %t495
  %t501 = load { i64, ptr }, ptr %t500, !tbaa !37
  store { i64, ptr } %t501, ptr %l256, !tbaa !27
  %t504 = call i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3cU8_3e_26(ptr %l253, ptr %l256)
  store i1 %t504, ptr %l258
  br label %bb127
bb126:
  store i1 false, ptr %l251, !tbaa !21
  br label %bb128
bb127:
  %t505 = load i1, ptr %l258, !tbaa !21
  store i1 %t505, ptr %l251, !tbaa !21
  br label %bb128
bb128:
  %t506 = load i1, ptr %l251, !tbaa !21
  br i1 %t506, label %bb129, label %bb130
bb129:
  %t507 = load i1, ptr %l4, !tbaa !21
  br i1 %t507, label %bb131, label %bb132
bb130:
  br label %bb138
bb131:
  store %olang.scope zeroinitializer, ptr %s21
  %t509 = load ptr, ptr %l0, !tbaa !29
  store ptr %t509, ptr %l260, !tbaa !29
  %t510 = load %"compiler/source:Span", ptr %l24
  store %"compiler/source:Span" %t510, ptr %l261
  %t511 = load ptr, ptr %l0, !tbaa !29
  %t512 = load ptr, ptr %l23, !tbaa !29
  %t514 = getelementptr %"compiler/ast:CaseDecl", ptr %t512, i32 0, i32 1
  %t515 = load i32, ptr %t514, !tbaa !23
  %t518 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t511, i32 %t515)
  store { i64, ptr } %t518, ptr %l265
  br label %bb133
bb132:
  br label %bb137
bb133:
  %t519 = load i64, ptr %l22, !tbaa !24
  %t520 = load ptr, ptr %lp14
  %t522 = getelementptr { i64, ptr }, ptr %t520, i32 0, i32 1
  %t523 = load ptr, ptr %t522, !tbaa !27
  %t524 = getelementptr { i64, ptr }, ptr %t523, i64 %t519
  %t525 = load { i64, ptr }, ptr %t524, !tbaa !37
  store { i64, ptr } %t525, ptr %l268, !tbaa !27
  %t527 = load { i64, ptr }, ptr %l268, !tbaa !27
  %t528 = extractvalue { i64, ptr } %t527, 0
  store i64 %t528, ptr %l269, !tbaa !24
  %t529 = load i64, ptr %l269, !tbaa !24
  %t530 = mul i64 %t529, 1
  %t531 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t530)
  %t532 = insertvalue { i64, ptr } undef, i64 %t529, 0
  %t533 = insertvalue { i64, ptr } %t532, ptr %t531, 1
  store { i64, ptr } %t533, ptr %l270, !tbaa !27
  %t534 = getelementptr { i64, ptr }, ptr %l270, i32 0, i32 1
  %t535 = load ptr, ptr %t534, !tbaa !27
  %t536 = getelementptr { i64, ptr }, ptr %l268, i32 0, i32 1
  %t537 = load ptr, ptr %t536, !tbaa !27
  %t538 = load i64, ptr %l269, !tbaa !24
  %t539 = mul i64 %t538, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t535, ptr %t537, i64 %t539, i1 false)
  %t540 = load { i64, ptr }, ptr %l270, !tbaa !27
  %t541 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t542 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t544 = extractvalue { i64, ptr } %t540, 1
  %t545 = extractvalue { i64, ptr } %t540, 0
  %t546 = add i64 %t542, %t545
  %t547 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t548 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t549 = add i64 %t546, %t548
  %t550 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t549)
  call void @olang_textcopy(ptr %t550, ptr %t541, i64 %t542)
  %t551 = getelementptr i8, ptr %t550, i64 %t542
  call void @olang_textcopy(ptr %t551, ptr %t544, i64 %t545)
  %t552 = getelementptr i8, ptr %t551, i64 %t545
  call void @olang_textcopy(ptr %t552, ptr %t547, i64 %t548)
  %t553 = insertvalue { i64, ptr } undef, i64 %t549, 0
  %t554 = insertvalue { i64, ptr } %t553, ptr %t550, 1
  %t556 = extractvalue { i64, ptr } %t554, 0
  %t557 = extractvalue { i64, ptr } %t554, 1
  %t558 = mul i64 %t556, 1
  %t559 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t558)
  call void @llvm.memcpy.p0.p0.i64(ptr %t559, ptr %t557, i64 %t558, i1 false)
  %t560 = insertvalue { i64, ptr } undef, i64 %t556, 0
  %t561 = insertvalue { i64, ptr } %t560, ptr %t559, 1
  store { i64, ptr } %t561, ptr %l273, !tbaa !27
  %t562 = load ptr, ptr %l0, !tbaa !29
  %t563 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t563, ptr %l275, !tbaa !27
  %t564 = load i64, ptr %l31, !tbaa !24
  %t566 = getelementptr { i64, ptr }, ptr %l275, i32 0, i32 1
  %t567 = load ptr, ptr %t566, !tbaa !27
  %t568 = getelementptr ptr, ptr %t567, i64 %t564
  %t569 = load ptr, ptr %t568, !tbaa !39
  %t571 = getelementptr %"compiler/ast:CaseDecl", ptr %t569, i32 0, i32 1
  %t572 = load i32, ptr %t571, !tbaa !23
  %t575 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t562, i32 %t572)
  store { i64, ptr } %t575, ptr %l279
  br label %bb134
bb134:
  %t576 = load { i64, ptr }, ptr %l265, !tbaa !27
  %t577 = load { i64, ptr }, ptr %l273, !tbaa !27
  %t578 = load { i64, ptr }, ptr %l279, !tbaa !27
  %t579 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRawRepeated(ptr %v0, ptr %s21, ptr %v0, ptr %s21, { i64, ptr } %t576, { i64, ptr } %t577, { i64, ptr } %t578)
  store %"compiler/diagmsg:Msg" %t579, ptr %l280
  br label %bb135
bb135:
  %t580 = load ptr, ptr %l260, !tbaa !29
  %t581 = load %"compiler/source:Span", ptr %l261
  %t582 = load %"compiler/diagmsg:Msg", ptr %l280
  %t583 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s21, ptr %t580, %"compiler/source:Span" %t581, %"compiler/diagmsg:Msg" %t582)
  store i64 %t583, ptr %l281
  br label %bb136
bb136:
  call void @__olang_scope_close(ptr %s21)
  br label %bb137
bb137:
  br label %bb140
bb138:
  br label %bb139
bb139:
  %t584 = load i64, ptr %l30, !tbaa !24
  %t586 = add i64 %t584, 1
  store i64 %t586, ptr %l30, !tbaa !24
  br label %bb121
bb140:
  call void @__olang_scope_close(ptr %s11)
  br label %bb225
bb141:
  %t588 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2enoLit()
  store %"compiler/check:litv" %t588, ptr %l284
  br label %bb142
bb142:
  %t589 = load %"compiler/check:litv", ptr %l284
  store %"compiler/check:litv" %t589, ptr %l32
  %t590 = load ptr, ptr %l23, !tbaa !29
  %t592 = getelementptr %"compiler/ast:CaseDecl", ptr %t590, i32 0, i32 4
  %t593 = load ptr, ptr %t592, !tbaa !29
  %t595 = icmp eq ptr %t593, null
  br i1 %t595, label %bb143, label %bb144
bb143:
  %t597 = load %"compiler/check:litv", ptr %l16
  %t599 = call %"compiler/check:signMag" @compiler_2fcheck_2esignMag_2emagOf(%"compiler/check:litv" %t597)
  store %"compiler/check:signMag" %t599, ptr %l289
  br label %bb145
bb144:
  %t600 = load ptr, ptr %l23, !tbaa !29
  %t602 = getelementptr %"compiler/ast:CaseDecl", ptr %t600, i32 0, i32 4
  %t603 = load ptr, ptr %t602, !tbaa !29
  %t605 = icmp eq ptr %t603, null
  br i1 %t605, label %bb151, label %bb152
bb145:
  %t607 = load %"compiler/check:signMag", ptr %l289
  store %"compiler/check:signMag" %t607, ptr %l33
  %t608 = getelementptr %"compiler/check:signMag", ptr %l33, i32 0, i32 0
  %t609 = load i1, ptr %t608, !tbaa !21
  store i1 %t609, ptr %l34, !tbaa !21
  %t611 = getelementptr %"compiler/check:signMag", ptr %l33, i32 0, i32 1
  %t612 = load i128, ptr %t611
  store i128 %t612, ptr %l35
  %t614 = getelementptr %"compiler/check:litv", ptr %l16, i32 0, i32 0
  %t615 = load i1, ptr %t614, !tbaa !21
  br i1 %t615, label %bb146, label %bb147
bb146:
  %t617 = load i1, ptr %l34, !tbaa !21
  %t618 = load i128, ptr %l35
  %t621 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2eaddMag(i1 %t617, i128 %t618, i1 false, i128 1)
  store %"compiler/check:litv" %t621, ptr %l296
  br label %bb148
bb147:
  %t622 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2enoLit()
  store %"compiler/check:litv" %t622, ptr %l297
  br label %bb149
bb148:
  %t623 = load %"compiler/check:litv", ptr %l296
  store %"compiler/check:litv" %t623, ptr %l293
  br label %bb150
bb149:
  %t624 = load %"compiler/check:litv", ptr %l297
  store %"compiler/check:litv" %t624, ptr %l293
  br label %bb150
bb150:
  %t625 = load %"compiler/check:litv", ptr %l293
  store %"compiler/check:litv" %t625, ptr %l32
  br label %bb169
bb151:
  call void @__olang_check_failed(ptr @olang_loc_bdfafd86356a320_3271504b736459c4)
  unreachable
bb152:
  br label %bb153
bb153:
  %t626 = load ptr, ptr %l23, !tbaa !29
  %t628 = getelementptr %"compiler/ast:CaseDecl", ptr %t626, i32 0, i32 4
  %t629 = load ptr, ptr %t628, !tbaa !29
  %t632 = call i1 @compiler_2fcheck_2enumberLitsOnly(ptr %v1, ptr %t629)
  store i1 %t632, ptr %l304
  br label %bb154
bb154:
  %t633 = load i1, ptr %l304, !tbaa !21
  br i1 %t633, label %bb155, label %bb156
bb155:
  store i1 true, ptr %l305, !tbaa !21
  br label %bb161
bb156:
  %t634 = load ptr, ptr %l23, !tbaa !29
  %t636 = getelementptr %"compiler/ast:CaseDecl", ptr %t634, i32 0, i32 4
  %t637 = load ptr, ptr %t636, !tbaa !29
  %t639 = icmp eq ptr %t637, null
  br i1 %t639, label %bb157, label %bb158
bb157:
  call void @__olang_check_failed(ptr @olang_loc_bdfafd86356a320_3271504b736459c4)
  unreachable
bb158:
  br label %bb159
bb159:
  %t641 = load ptr, ptr %l23, !tbaa !29
  %t643 = getelementptr %"compiler/ast:CaseDecl", ptr %t641, i32 0, i32 4
  %t644 = load ptr, ptr %t643, !tbaa !29
  %t646 = call i1 @compiler_2fcheck_2eisCharLit(ptr %v1, ptr %t644)
  store i1 %t646, ptr %l311
  br label %bb160
bb160:
  %t647 = load i1, ptr %l311, !tbaa !21
  store i1 %t647, ptr %l305, !tbaa !21
  br label %bb161
bb161:
  %t648 = load i1, ptr %l305, !tbaa !21
  br i1 %t648, label %bb162, label %bb163
bb162:
  %t649 = load ptr, ptr %l0, !tbaa !29
  store ptr %t649, ptr %l312, !tbaa !29
  %t650 = load ptr, ptr %l23, !tbaa !29
  %t652 = getelementptr %"compiler/ast:CaseDecl", ptr %t650, i32 0, i32 4
  %t653 = load ptr, ptr %t652, !tbaa !29
  %t655 = icmp eq ptr %t653, null
  br i1 %t655, label %bb164, label %bb165
bb163:
  br label %bb168
bb164:
  call void @__olang_check_failed(ptr @olang_loc_cf3f79d848e44ed1_488edda033e9ba8d)
  unreachable
bb165:
  br label %bb166
bb166:
  %t657 = load ptr, ptr %l23, !tbaa !29
  %t659 = getelementptr %"compiler/ast:CaseDecl", ptr %t657, i32 0, i32 4
  %t660 = load ptr, ptr %t659, !tbaa !29
  %t661 = load ptr, ptr %l312, !tbaa !29
  %t663 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efoldPart(ptr %v0, ptr %v1, ptr %t661, ptr %t660)
  store %"compiler/check:litv" %t663, ptr %l318
  br label %bb167
bb167:
  %t664 = load %"compiler/check:litv", ptr %l318
  store %"compiler/check:litv" %t664, ptr %l32
  br label %bb168
bb168:
  br label %bb169
bb169:
  %t665 = getelementptr %"compiler/check:litv", ptr %l32, i32 0, i32 0
  %t666 = load i1, ptr %t665, !tbaa !21
  %t668 = xor i1 %t666, true
  br i1 %t668, label %bb170, label %bb171
bb170:
  store i1 true, ptr %l321, !tbaa !21
  br label %bb172
bb171:
  %t670 = getelementptr %"compiler/check:litv", ptr %l32, i32 0, i32 1
  %t671 = load i1, ptr %t670, !tbaa !21
  store i1 %t671, ptr %l321, !tbaa !21
  br label %bb172
bb172:
  %t673 = load i1, ptr %l321, !tbaa !21
  br i1 %t673, label %bb173, label %bb174
bb173:
  %t674 = load i1, ptr %l4, !tbaa !21
  br i1 %t674, label %bb175, label %bb176
bb174:
  br label %bb187
bb175:
  store %olang.scope zeroinitializer, ptr %s28
  %t676 = load ptr, ptr %l0, !tbaa !29
  store ptr %t676, ptr %l324, !tbaa !29
  %t677 = load %"compiler/source:Span", ptr %l24
  store %"compiler/source:Span" %t677, ptr %l325
  %t678 = load ptr, ptr %l23, !tbaa !29
  %t680 = getelementptr %"compiler/ast:CaseDecl", ptr %t678, i32 0, i32 4
  %t681 = load ptr, ptr %t680, !tbaa !29
  %t683 = icmp eq ptr %t681, null
  %t685 = xor i1 %t683, true
  br i1 %t685, label %bb177, label %bb178
bb176:
  br label %bb185
bb177:
  %t687 = load ptr, ptr %l0, !tbaa !29
  %t688 = load i32, ptr %l10, !tbaa !23
  %t691 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s28, ptr %t687, i32 %t688)
  store { i64, ptr } %t691, ptr %l333
  br label %bb179
bb178:
  %t692 = load ptr, ptr %l0, !tbaa !29
  %t693 = load i32, ptr %l10, !tbaa !23
  %t696 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s28, ptr %t692, i32 %t693)
  store { i64, ptr } %t696, ptr %l338
  br label %bb181
bb179:
  %t697 = load { i64, ptr }, ptr %l333, !tbaa !27
  %t698 = extractvalue { i64, ptr } %t697, 0
  %t699 = extractvalue { i64, ptr } %t697, 1
  %t700 = mul i64 %t698, 1
  %t701 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t700)
  call void @llvm.memcpy.p0.p0.i64(ptr %t701, ptr %t699, i64 %t700, i1 false)
  %t702 = insertvalue { i64, ptr } undef, i64 %t698, 0
  %t703 = insertvalue { i64, ptr } %t702, ptr %t701, 1
  %t705 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRawNotLiteral(ptr %s28, ptr %s28, { i64, ptr } %t703)
  store %"compiler/diagmsg:Msg" %t705, ptr %l335
  br label %bb180
bb180:
  %t706 = load %"compiler/diagmsg:Msg", ptr %l335
  store %"compiler/diagmsg:Msg" %t706, ptr %l330
  br label %bb183
bb181:
  %t707 = load { i64, ptr }, ptr %l338, !tbaa !27
  %t708 = extractvalue { i64, ptr } %t707, 0
  %t709 = extractvalue { i64, ptr } %t707, 1
  %t710 = mul i64 %t708, 1
  %t711 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t710)
  call void @llvm.memcpy.p0.p0.i64(ptr %t711, ptr %t709, i64 %t710, i1 false)
  %t712 = insertvalue { i64, ptr } undef, i64 %t708, 0
  %t713 = insertvalue { i64, ptr } %t712, ptr %t711, 1
  %t715 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRawNoFit(ptr %s28, ptr %s28, ptr %s28, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d37, i32 0, i32 1) }, { i64, ptr } %t713)
  store %"compiler/diagmsg:Msg" %t715, ptr %l340
  br label %bb182
bb182:
  %t716 = load %"compiler/diagmsg:Msg", ptr %l340
  store %"compiler/diagmsg:Msg" %t716, ptr %l330
  br label %bb183
bb183:
  %t717 = load ptr, ptr %l324, !tbaa !29
  %t718 = load %"compiler/source:Span", ptr %l325
  %t719 = load %"compiler/diagmsg:Msg", ptr %l330
  %t720 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s28, ptr %t717, %"compiler/source:Span" %t718, %"compiler/diagmsg:Msg" %t719)
  store i64 %t720, ptr %l341
  br label %bb184
bb184:
  call void @__olang_scope_close(ptr %s28)
  br label %bb185
bb185:
  %t721 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2enoLit()
  store %"compiler/check:litv" %t721, ptr %l342
  br label %bb186
bb186:
  %t722 = load %"compiler/check:litv", ptr %l342
  store %"compiler/check:litv" %t722, ptr %l16
  call void @__olang_scope_close(ptr %s11)
  br label %bb225
bb187:
  %t723 = load %"compiler/check:litv", ptr %l32
  store %"compiler/check:litv" %t723, ptr %l16
  %t725 = load ptr, ptr %l0, !tbaa !29
  %t726 = load %"compiler/check:litv", ptr %l32
  %t727 = load i32, ptr %l10, !tbaa !23
  %t731 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawFits(ptr %v0, ptr %t725, %"compiler/check:litv" %t726, i32 %t727)
  store i1 %t731, ptr %l347
  br label %bb188
bb188:
  %t732 = load i1, ptr %l347, !tbaa !21
  %t733 = xor i1 %t732, true
  br i1 %t733, label %bb189, label %bb190
bb189:
  %t735 = load i1, ptr %l4, !tbaa !21
  br i1 %t735, label %bb191, label %bb192
bb190:
  br label %bb198
bb191:
  store %olang.scope zeroinitializer, ptr %s30
  %t737 = load ptr, ptr %l0, !tbaa !29
  store ptr %t737, ptr %l350, !tbaa !29
  %t738 = load %"compiler/source:Span", ptr %l24
  store %"compiler/source:Span" %t738, ptr %l351
  %t739 = load %"compiler/check:litv", ptr %l32
  %t741 = call { i64, ptr } @compiler_2fcheck_2elitText(ptr %s30, %"compiler/check:litv" %t739)
  store { i64, ptr } %t741, ptr %l353
  br label %bb193
bb192:
  br label %bb197
bb193:
  %t742 = load { i64, ptr }, ptr %l353, !tbaa !27
  %t743 = extractvalue { i64, ptr } %t742, 0
  %t744 = extractvalue { i64, ptr } %t742, 1
  %t745 = mul i64 %t743, 1
  %t746 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t745)
  call void @llvm.memcpy.p0.p0.i64(ptr %t746, ptr %t744, i64 %t745, i1 false)
  %t747 = insertvalue { i64, ptr } undef, i64 %t743, 0
  %t748 = insertvalue { i64, ptr } %t747, ptr %t746, 1
  store { i64, ptr } %t748, ptr %l354, !tbaa !27
  %t749 = load ptr, ptr %l0, !tbaa !29
  %t750 = load i32, ptr %l10, !tbaa !23
  %t753 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s30, ptr %t749, i32 %t750)
  store { i64, ptr } %t753, ptr %l357
  br label %bb194
bb194:
  %t754 = load { i64, ptr }, ptr %l357, !tbaa !27
  %t755 = extractvalue { i64, ptr } %t754, 0
  %t756 = extractvalue { i64, ptr } %t754, 1
  %t757 = mul i64 %t755, 1
  %t758 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t757)
  call void @llvm.memcpy.p0.p0.i64(ptr %t758, ptr %t756, i64 %t757, i1 false)
  %t759 = insertvalue { i64, ptr } undef, i64 %t755, 0
  %t760 = insertvalue { i64, ptr } %t759, ptr %t758, 1
  %t761 = load { i64, ptr }, ptr %l354, !tbaa !27
  %t763 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRawNoFit(ptr %s30, ptr %s30, ptr %s30, { i64, ptr } %t761, { i64, ptr } %t760)
  store %"compiler/diagmsg:Msg" %t763, ptr %l359
  br label %bb195
bb195:
  %t764 = load ptr, ptr %l350, !tbaa !29
  %t765 = load %"compiler/source:Span", ptr %l351
  %t766 = load %"compiler/diagmsg:Msg", ptr %l359
  %t767 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s30, ptr %t764, %"compiler/source:Span" %t765, %"compiler/diagmsg:Msg" %t766)
  store i64 %t767, ptr %l360
  br label %bb196
bb196:
  call void @__olang_scope_close(ptr %s30)
  br label %bb197
bb197:
  call void @__olang_scope_close(ptr %s11)
  br label %bb225
bb198:
  %t768 = load i64, ptr %l22, !tbaa !24
  %t769 = getelementptr %"compiler/check:litv", ptr %l32, i32 0, i32 3
  %t770 = load i64, ptr %t769, !tbaa !24
  %t772 = load ptr, ptr %lp13
  %t774 = getelementptr { i64, ptr }, ptr %t772, i32 0, i32 1
  %t775 = load ptr, ptr %t774, !tbaa !27
  %t776 = getelementptr i64, ptr %t775, i64 %t768
  store i64 %t770, ptr %t776, !tbaa !34
  %t777 = load i64, ptr %l22, !tbaa !24
  %t779 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t780 = load ptr, ptr %t779, !tbaa !27
  %t781 = getelementptr i1, ptr %t780, i64 %t777
  store i1 true, ptr %t781, !tbaa !31
  store i64 0, ptr %l36, !tbaa !24
  %t782 = load i64, ptr %l22, !tbaa !24
  store i64 %t782, ptr %l37, !tbaa !24
  store i64 1, ptr %l38, !tbaa !24
  %t784 = load i64, ptr %l37, !tbaa !24
  %t785 = load i64, ptr %l36, !tbaa !24
  %t788 = icmp sgt i64 %t784, %t785
  br i1 %t788, label %bb199, label %bb200
bb199:
  %t790 = load i64, ptr %l38, !tbaa !24
  %t792 = icmp sgt i64 %t790, 0
  br i1 %t792, label %bb201, label %bb202
bb200:
  store i64 0, ptr %l368, !tbaa !24
  br label %bb204
bb201:
  %t794 = load i64, ptr %l37, !tbaa !24
  %t795 = load i64, ptr %l36, !tbaa !24
  %t798 = sub i64 %t794, %t795
  %t799 = load i64, ptr %l38, !tbaa !24
  %t802 = add i64 %t798, %t799
  %t804 = sub i64 %t802, 1
  %t805 = load i64, ptr %l38, !tbaa !24
  %t808 = sdiv i64 %t804, %t805
  store i64 %t808, ptr %l371, !tbaa !24
  br label %bb203
bb202:
  store i64 0, ptr %l371, !tbaa !24
  br label %bb203
bb203:
  %t810 = load i64, ptr %l371, !tbaa !24
  store i64 %t810, ptr %l368, !tbaa !24
  br label %bb204
bb204:
  %t811 = load i64, ptr %l368, !tbaa !24
  store i64 %t811, ptr %l39, !tbaa !24
  store i64 0, ptr %l40, !tbaa !24
  br label %bb205
bb205:
  %t812 = load i64, ptr %l40, !tbaa !24
  %t813 = load i64, ptr %l39, !tbaa !24
  %t816 = icmp slt i64 %t812, %t813
  %t818 = xor i1 %t816, true
  br i1 %t818, label %bb206, label %bb207
bb206:
  br label %bb224
bb207:
  br label %bb208
bb208:
  %t820 = load i64, ptr %l36, !tbaa !24
  %t821 = load i64, ptr %l40, !tbaa !24
  %t822 = load i64, ptr %l38, !tbaa !24
  %t825 = mul i64 %t821, %t822
  %t828 = add i64 %t820, %t825
  store i64 %t828, ptr %l41, !tbaa !24
  %t830 = load i64, ptr %l41, !tbaa !24
  %t832 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t833 = load ptr, ptr %t832, !tbaa !27
  %t834 = getelementptr i1, ptr %t833, i64 %t830
  %t835 = load i1, ptr %t834, !tbaa !31
  br i1 %t835, label %bb209, label %bb210
bb209:
  %t837 = load i64, ptr %l41, !tbaa !24
  %t838 = load ptr, ptr %lp13
  %t840 = getelementptr { i64, ptr }, ptr %t838, i32 0, i32 1
  %t841 = load ptr, ptr %t840, !tbaa !27
  %t842 = getelementptr i64, ptr %t841, i64 %t837
  %t843 = load i64, ptr %t842, !tbaa !34
  %t844 = load i64, ptr %l22, !tbaa !24
  %t845 = load ptr, ptr %lp13
  %t847 = getelementptr { i64, ptr }, ptr %t845, i32 0, i32 1
  %t848 = load ptr, ptr %t847, !tbaa !27
  %t849 = getelementptr i64, ptr %t848, i64 %t844
  %t850 = load i64, ptr %t849, !tbaa !34
  %t853 = icmp eq i64 %t843, %t850
  store i1 %t853, ptr %l391, !tbaa !21
  br label %bb211
bb210:
  store i1 false, ptr %l391, !tbaa !21
  br label %bb211
bb211:
  %t855 = load i1, ptr %l391, !tbaa !21
  br i1 %t855, label %bb212, label %bb213
bb212:
  %t856 = load i1, ptr %l4, !tbaa !21
  br i1 %t856, label %bb214, label %bb215
bb213:
  br label %bb222
bb214:
  store %olang.scope zeroinitializer, ptr %s34
  %t858 = load ptr, ptr %l0, !tbaa !29
  store ptr %t858, ptr %l398, !tbaa !29
  %t859 = load %"compiler/source:Span", ptr %l24
  store %"compiler/source:Span" %t859, ptr %l399
  %t860 = load ptr, ptr %l0, !tbaa !29
  %t861 = load ptr, ptr %l23, !tbaa !29
  %t863 = getelementptr %"compiler/ast:CaseDecl", ptr %t861, i32 0, i32 1
  %t864 = load i32, ptr %t863, !tbaa !23
  %t867 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t860, i32 %t864)
  store { i64, ptr } %t867, ptr %l403
  br label %bb216
bb215:
  br label %bb221
bb216:
  %t868 = load %"compiler/check:litv", ptr %l32
  %t870 = call { i64, ptr } @compiler_2fcheck_2elitText(ptr %s34, %"compiler/check:litv" %t868)
  store { i64, ptr } %t870, ptr %l405
  br label %bb217
bb217:
  %t871 = load { i64, ptr }, ptr %l405, !tbaa !27
  %t872 = extractvalue { i64, ptr } %t871, 0
  %t873 = extractvalue { i64, ptr } %t871, 1
  %t874 = mul i64 %t872, 1
  %t875 = call ptr @__olang_scope_alloc(ptr %s34, i64 %t874)
  call void @llvm.memcpy.p0.p0.i64(ptr %t875, ptr %t873, i64 %t874, i1 false)
  %t876 = insertvalue { i64, ptr } undef, i64 %t872, 0
  %t877 = insertvalue { i64, ptr } %t876, ptr %t875, 1
  store { i64, ptr } %t877, ptr %l406, !tbaa !27
  %t878 = load ptr, ptr %l0, !tbaa !29
  %t879 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t879, ptr %l408, !tbaa !27
  %t880 = load i64, ptr %l41, !tbaa !24
  %t882 = getelementptr { i64, ptr }, ptr %l408, i32 0, i32 1
  %t883 = load ptr, ptr %t882, !tbaa !27
  %t884 = getelementptr ptr, ptr %t883, i64 %t880
  %t885 = load ptr, ptr %t884, !tbaa !39
  %t887 = getelementptr %"compiler/ast:CaseDecl", ptr %t885, i32 0, i32 1
  %t888 = load i32, ptr %t887, !tbaa !23
  %t891 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t878, i32 %t888)
  store { i64, ptr } %t891, ptr %l412
  br label %bb218
bb218:
  %t892 = load { i64, ptr }, ptr %l403, !tbaa !27
  %t893 = load { i64, ptr }, ptr %l406, !tbaa !27
  %t894 = load { i64, ptr }, ptr %l412, !tbaa !27
  %t895 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRawRepeated(ptr %v0, ptr %s34, ptr %v0, ptr %s34, { i64, ptr } %t892, { i64, ptr } %t893, { i64, ptr } %t894)
  store %"compiler/diagmsg:Msg" %t895, ptr %l413
  br label %bb219
bb219:
  %t896 = load ptr, ptr %l398, !tbaa !29
  %t897 = load %"compiler/source:Span", ptr %l399
  %t898 = load %"compiler/diagmsg:Msg", ptr %l413
  %t899 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s34, ptr %t896, %"compiler/source:Span" %t897, %"compiler/diagmsg:Msg" %t898)
  store i64 %t899, ptr %l414
  br label %bb220
bb220:
  call void @__olang_scope_close(ptr %s34)
  br label %bb221
bb221:
  br label %bb224
bb222:
  br label %bb223
bb223:
  %t900 = load i64, ptr %l40, !tbaa !24
  %t902 = add i64 %t900, 1
  store i64 %t902, ptr %l40, !tbaa !24
  br label %bb205
bb224:
  call void @__olang_scope_close(ptr %s11)
  br label %bb225
bb225:
  %t904 = load i64, ptr %l21, !tbaa !24
  %t906 = add i64 %t904, 1
  store i64 %t906, ptr %l21, !tbaa !24
  br label %bb71
bb226:
  %t908 = load i32, ptr %l10, !tbaa !23
  %t909 = load i1, ptr %l11, !tbaa !21
  %t910 = load ptr, ptr %lp13
  %t911 = load { i64, ptr }, ptr %t910, !tbaa !27
  %t912 = load ptr, ptr %lp14
  %t913 = load { i64, ptr }, ptr %t912, !tbaa !27
  %t918 = call %"compiler/check:rawTable" @compiler_2fcheck_3arawTable_2ector(ptr %v3, ptr %v3, ptr %v3, i32 %t908, i1 %t909, { i64, ptr } %t911, { i64, ptr } %t913)
  store %"compiler/check:rawTable" %t918, ptr %l423
  br label %bb227
bb227:
  %t919 = load %"compiler/check:rawTable", ptr %l423
  %t920 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store %"compiler/check:rawTable" %t919, ptr %t920
  call void @__olang_scope_close(ptr %s0)
  store ptr %t920, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erecvReplaced(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca { i64, ptr }
  %l21 = alloca i64
  %l30 = alloca i64
  %l33 = alloca i64
  %l52 = alloca { i64, ptr }
  %l60 = alloca ptr
  %l65 = alloca i32
  %l70 = alloca i32
  %l75 = alloca i32
  %l80 = alloca i32
  %l81 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l13, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l18
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = load i32, ptr %l18, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t17, i32 %t18)
  store { i64, ptr } %t19, ptr %l19
  br label %bb2
bb2:
  %t20 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l21, !tbaa !24
  %t24 = load i64, ptr %l21, !tbaa !24
  %t25 = icmp sge i64 %t24, 0
  br i1 %t25, label %bb3, label %bb4
bb3:
  %t27 = load i64, ptr %l21, !tbaa !24
  %t28 = icmp sle i64 %t27, 2305843009213693951
  br i1 %t28, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_e5e26ce82a519cb4_386557e0c1145fc8)
  unreachable
bb5:
  %t30 = load i64, ptr %l21, !tbaa !24
  %t31 = mul i64 %t30, 4
  %t32 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 0
  store i64 %t38, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = icmp sgt i64 %t40, %t41
  br i1 %t44, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_e5e26ce82a519cb4_386557e0c1145fc8)
  unreachable
bb7:
  %t46 = load i64, ptr %l7, !tbaa !24
  %t48 = icmp sgt i64 %t46, 0
  br i1 %t48, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb12
bb9:
  %t50 = load i64, ptr %l6, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = sub i64 %t50, %t51
  %t55 = load i64, ptr %l7, !tbaa !24
  %t58 = add i64 %t54, %t55
  %t60 = sub i64 %t58, 1
  %t61 = load i64, ptr %l7, !tbaa !24
  %t64 = sdiv i64 %t60, %t61
  store i64 %t64, ptr %l33, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb11
bb11:
  %t66 = load i64, ptr %l33, !tbaa !24
  store i64 %t66, ptr %l30, !tbaa !24
  br label %bb12
bb12:
  %t67 = load i64, ptr %l30, !tbaa !24
  store i64 %t67, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb13
bb13:
  %t68 = load i64, ptr %l9, !tbaa !24
  %t69 = load i64, ptr %l8, !tbaa !24
  %t72 = icmp slt i64 %t68, %t69
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t76 = load i64, ptr %l5, !tbaa !24
  %t77 = load i64, ptr %l9, !tbaa !24
  %t78 = load i64, ptr %l7, !tbaa !24
  %t81 = mul i64 %t77, %t78
  %t84 = add i64 %t76, %t81
  store i64 %t84, ptr %l10, !tbaa !24
  %t86 = load i64, ptr %l10, !tbaa !24
  %t87 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t87, ptr %l52, !tbaa !27
  %t88 = load i64, ptr %l10, !tbaa !24
  %t90 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr i32, ptr %t91, i64 %t88
  %t93 = load i32, ptr %t92, !tbaa !33
  %t96 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr i32, ptr %t97, i64 %t86
  store i32 %t93, ptr %t98, !tbaa !33
  br label %bb17
bb17:
  %t99 = load i64, ptr %l9, !tbaa !24
  %t101 = add i64 %t99, 1
  store i64 %t101, ptr %l9, !tbaa !24
  br label %bb13
bb18:
  %t105 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr i32, ptr %t106, i64 0
  store i32 %a2, ptr %t107, !tbaa !33
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/check:Checker", ptr %t108, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = getelementptr %"compiler/generic:Program", ptr %t111, i32 0, i32 2
  store ptr %t113, ptr %l60, !tbaa !29
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/check:Checker", ptr %t114, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t119 = getelementptr %"compiler/generic:Program", ptr %t117, i32 0, i32 2
  %t120 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t123 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t119, { i64, ptr } %t120)
  store i32 %t123, ptr %l65
  br label %bb19
bb19:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/check:Checker", ptr %t124, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t129 = getelementptr %"compiler/generic:Program", ptr %t127, i32 0, i32 2
  %t130 = load i32, ptr %l1, !tbaa !23
  %t133 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t129, i32 %t130)
  store i32 %t133, ptr %l70
  br label %bb20
bb20:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t134, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t139 = getelementptr %"compiler/generic:Program", ptr %t137, i32 0, i32 2
  %t140 = load i32, ptr %l1, !tbaa !23
  %t143 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t139, i32 %t140)
  store i32 %t143, ptr %l75
  br label %bb21
bb21:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/check:Checker", ptr %t144, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t149 = getelementptr %"compiler/generic:Program", ptr %t147, i32 0, i32 2
  %t150 = load i32, ptr %l1, !tbaa !23
  %t153 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t149, i32 %t150)
  store i32 %t153, ptr %l80
  br label %bb22
bb22:
  %t154 = load ptr, ptr %l60, !tbaa !29
  %t155 = load i32, ptr %l65, !tbaa !23
  %t156 = load i32, ptr %l70, !tbaa !23
  %t157 = load i32, ptr %l75, !tbaa !23
  %t158 = load i32, ptr %l80, !tbaa !23
  %t159 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t154, i32 %t155, i32 %t156, i32 %t157, i32 %t158, i64 0, i1 false, i32 0)
  store i32 %t159, ptr %l81
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  %t160 = load i32, ptr %l81, !tbaa !23
  store i32 %t160, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDefault(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/generic:Desc" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/generic:Desc"
  %l4 = alloca { i32, { i64, ptr } }
  %l5 = alloca i32
  %l6 = alloca %"compiler/generic:Desc"
  %l8 = alloca i32
  %l12 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca %"compiler/source:Span"
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l25 = alloca %"compiler/diagmsg:Msg"
  %l26 = alloca i64
  %l29 = alloca ptr
  %l33 = alloca { i32, { i64, ptr } }
  %l38 = alloca %"compiler/generic:Desc"
  %l45 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca %"compiler/source:Span"
  %l52 = alloca i64
  %l53 = alloca i64
  %l55 = alloca i64
  %l58 = alloca ptr
  %l67 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/generic:Desc" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load %"compiler/generic:Desc", ptr %l2
  %t5 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamDefault(ptr %v0, ptr %s0, ptr %t1, %"compiler/generic:Desc" %t2)
  store ptr %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l12, !tbaa !29
  %t9 = icmp eq ptr %t6, null
  br i1 %t9, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l15, !tbaa !29
  %t12 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t12, ptr %l16
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load %"compiler/generic:Desc", ptr %l2
  %t17 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescName(ptr %v0, ptr %s1, ptr %t13, %"compiler/generic:Desc" %t14)
  store { i64, ptr } %t17, ptr %l19
  br label %bb4
bb3:
  br label %bb9
bb4:
  %t18 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t18, 0
  %t20 = extractvalue { i64, ptr } %t18, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  store { i64, ptr } %t24, ptr %l20, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Desc", ptr %l2, i32 0, i32 1
  %t27 = load i32, ptr %t26, !tbaa !23
  %t30 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t25, i32 %t27)
  store { i64, ptr } %t30, ptr %l23
  br label %bb5
bb5:
  %t31 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  %t33 = extractvalue { i64, ptr } %t31, 1
  %t34 = mul i64 %t32, 1
  %t35 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t34)
  call void @llvm.memcpy.p0.p0.i64(ptr %t35, ptr %t33, i64 %t34, i1 false)
  %t36 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  %t38 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t40 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflNoDefault(ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t38, { i64, ptr } %t37)
  store %"compiler/diagmsg:Msg" %t40, ptr %l25
  br label %bb6
bb6:
  %t41 = load ptr, ptr %l15, !tbaa !29
  %t42 = load %"compiler/source:Span", ptr %l16
  %t43 = load %"compiler/diagmsg:Msg", ptr %l25
  %t44 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t41, %"compiler/source:Span" %t42, %"compiler/diagmsg:Msg" %t43)
  store i64 %t44, ptr %l26
  br label %bb7
bb7:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load %"compiler/source:Span", ptr %l1
  %t49 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t45, %"compiler/source:Span" %t46)
  store ptr %t49, ptr %l29
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t50 = load ptr, ptr %l29, !tbaa !29
  store ptr %t50, ptr %rv
  br label %ret
bb9:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/check:Checker", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t55 = load %"compiler/generic:Desc", ptr %l2
  %t58 = call { i32, { i64, ptr } } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescType(ptr %v0, ptr %s0, ptr %t54, %"compiler/generic:Desc" %t55)
  store { i32, { i64, ptr } } %t58, ptr %l33
  br label %bb10
bb10:
  %t59 = load { i32, { i64, ptr } }, ptr %l33
  store { i32, { i64, ptr } } %t59, ptr %l4
  %t60 = getelementptr { i32, { i64, ptr } }, ptr %l4, i32 0, i32 0
  %t61 = load i32, ptr %t60, !tbaa !23
  store i32 %t61, ptr %l5, !tbaa !23
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Desc", ptr %l2, i32 0, i32 1
  %t68 = load i32, ptr %t67, !tbaa !23
  %t71 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t66, i32 %t68)
  store %"compiler/generic:Desc" %t71, ptr %l38
  br label %bb11
bb11:
  %t72 = load %"compiler/generic:Desc", ptr %l38
  store %"compiler/generic:Desc" %t72, ptr %l6
  %t73 = getelementptr %"compiler/generic:Desc", ptr %l6, i32 0, i32 0
  %t74 = load i64, ptr %t73, !tbaa !24
  %t75 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescFunc, !tbaa !24
  %t78 = icmp eq i64 %t74, %t75
  br i1 %t78, label %bb12, label %bb13
bb12:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/check:Checker", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t84 = getelementptr %"compiler/generic:Desc", ptr %l6, i32 0, i32 2
  %t85 = load i64, ptr %t84, !tbaa !24
  %t88 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t83, i64 %t85)
  store ptr %t88, ptr %l45
  br label %bb14
bb13:
  br label %bb19
bb14:
  %t89 = load ptr, ptr %l45, !tbaa !29
  %t91 = getelementptr %"compiler/ast:Func", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = icmp eq ptr %t92, null
  %t96 = xor i1 %t94, true
  %t98 = load ptr, ptr %l0, !tbaa !29
  store ptr %t98, ptr %l50, !tbaa !29
  %t99 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t99, ptr %l51
  %t100 = getelementptr %"compiler/generic:Desc", ptr %l6, i32 0, i32 2
  %t101 = load i64, ptr %t100, !tbaa !24
  store i64 %t101, ptr %l52, !tbaa !24
  %t102 = getelementptr %"compiler/generic:Desc", ptr %l2, i32 0, i32 3
  %t103 = load i64, ptr %t102, !tbaa !24
  store i64 %t103, ptr %l53, !tbaa !24
  br i1 %t96, label %bb15, label %bb16
bb15:
  store i64 1, ptr %l55, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb17
bb17:
  %t106 = load i64, ptr %l53, !tbaa !24
  %t107 = load i64, ptr %l55, !tbaa !24
  %t108 = add i64 %t106, %t107
  %t109 = load i32, ptr %l5, !tbaa !23
  %t110 = load ptr, ptr %l50, !tbaa !29
  %t111 = load %"compiler/source:Span", ptr %l51
  %t112 = load i64, ptr %l52, !tbaa !24
  %t115 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultArg(ptr %v0, ptr %v1, ptr %t110, %"compiler/source:Span" %t111, i64 %t112, i64 %t108, i1 false, i32 %t109, i32 0)
  store ptr %t115, ptr %l58
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  %t116 = load ptr, ptr %l58, !tbaa !29
  store ptr %t116, ptr %rv
  br label %ret
bb19:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 23
  %t120 = load i32, ptr %t119, !tbaa !23
  store i32 %t120, ptr %l8, !tbaa !23
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/generic:Desc", ptr %l2, i32 0, i32 1
  %t124 = load i32, ptr %t123, !tbaa !23
  %t127 = getelementptr %"compiler/check:Checker", ptr %t122, i32 0, i32 23
  store i32 %t124, ptr %t127, !tbaa !23
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load %"compiler/source:Span", ptr %l1
  %t130 = getelementptr %"compiler/generic:Desc", ptr %l2, i32 0, i32 3
  %t131 = load i64, ptr %t130, !tbaa !24
  %t132 = load i32, ptr %l5, !tbaa !23
  %t137 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorDefault(ptr %v0, ptr %v1, ptr %t128, %"compiler/source:Span" %t129, i64 %t131, i32 %t132)
  store ptr %t137, ptr %l67
  br label %bb20
bb20:
  %t138 = load ptr, ptr %l67, !tbaa !29
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load i32, ptr %l8, !tbaa !23
  %t143 = getelementptr %"compiler/check:Checker", ptr %t139, i32 0, i32 23
  store i32 %t140, ptr %t143, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store ptr %t138, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i1
  %lp3 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i32
  %l13 = alloca i1
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 138
  %t4 = load i1, ptr %t3, !tbaa !21
  store i1 %t4, ptr %l2, !tbaa !21
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 138
  store i1 false, ptr %t8, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t13 = call { i32, { i64, ptr } } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflTextOf(ptr %v0, ptr %v1, ptr %v2, ptr %t9, ptr %a1)
  %t14 = extractvalue { i32, { i64, ptr } } %t13, 1
  %t15 = extractvalue { i32, { i64, ptr } } %t13, 0
  store i32 %t15, ptr %l11
  %t16 = icmp ne i32 %t15, 0
  br i1 %t16, label %bb2, label %ok.17, !prof !99
ok.17:
  store { i64, ptr } %t14, ptr %l10
  br label %bb1
bb1:
  %t18 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t18, ptr %l7, !tbaa !27
  br label %bb4
bb2:
  %t19 = load i32, ptr %l11, !tbaa !23
  %t20 = ashr i32 %t19, 16
  %t22 = icmp eq i32 %t20, 1
  store i1 %t22, ptr %l13, !tbaa !21
  br label %bb3
bb3:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 138
  %t27 = load i1, ptr %t26, !tbaa !21
  %t30 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 139
  store i1 %t27, ptr %t30, !tbaa !21
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i1, ptr %l2, !tbaa !21
  %t35 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 138
  store i1 %t32, ptr %t35, !tbaa !21
  %t37 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t37, ptr %rv
  br label %ret
bb4:
  %t38 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t38, ptr %lp3
  %t39 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t40 = load ptr, ptr %lp3
  store { i64, ptr } %t39, ptr %t40, !tbaa !27
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t42, i32 0, i32 138
  %t45 = load i1, ptr %t44, !tbaa !21
  %t48 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 139
  store i1 %t45, ptr %t48, !tbaa !21
  %t49 = load ptr, ptr %lp3
  %t50 = load { i64, ptr }, ptr %t49, !tbaa !27
  store { i64, ptr } %t50, ptr %l23, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t51, 0
  store i64 %t52, ptr %l24, !tbaa !24
  %t53 = load i64, ptr %l24, !tbaa !24
  %t54 = mul i64 %t53, 1
  %t55 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l25, !tbaa !27
  %t58 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = load i64, ptr %l24, !tbaa !24
  %t63 = mul i64 %t62, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t59, ptr %t61, i64 %t63, i1 false)
  %t64 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t64, ptr %l23, !tbaa !27
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load i1, ptr %l2, !tbaa !21
  %t69 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 138
  store i1 %t66, ptr %t69, !tbaa !21
  %t70 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t71 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t70, 1
  store { i32, { i64, ptr } } %t71, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erendered(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l9 = alloca ptr
  %l12 = alloca i32
  %l15 = alloca ptr
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca %"compiler/diagmsg:Msg"
  %l21 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l26 = alloca ptr
  %l30 = alloca %"compiler/source:Span"
  %l31 = alloca ptr
  %l34 = alloca i32
  %l36 = alloca ptr
  %l37 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t8 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t1, ptr %a2, i32 %t4)
  store ptr %t8, ptr %l9
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l9, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t13 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t10)
  store i32 %t13, ptr %l12
  br label %bb2
bb2:
  %t14 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t15 = load i32, ptr %l12, !tbaa !23
  %t17 = icmp eq i32 %t15, %t14
  br i1 %t17, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l15, !tbaa !29
  %t20 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t21 = load i32, ptr %t20, !tbaa !23
  %t22 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t23 = load i32, ptr %t22, !tbaa !23
  %t25 = add i32 %t23, 1
  %t28 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 %t21, i32 %t25)
  store %"compiler/source:Span" %t28, ptr %l19
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t29 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eStrOfNothing(ptr %s1)
  store %"compiler/diagmsg:Msg" %t29, ptr %l20
  br label %bb6
bb6:
  %t30 = load ptr, ptr %l15, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l19
  %t32 = load %"compiler/diagmsg:Msg", ptr %l20
  %t33 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t30, %"compiler/source:Span" %t31, %"compiler/diagmsg:Msg" %t32)
  store i64 %t33, ptr %l21
  br label %bb7
bb7:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load %"compiler/source:Span", ptr %l1
  %t38 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t34, %"compiler/source:Span" %t35)
  store ptr %t38, ptr %l24
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t39 = load ptr, ptr %l24, !tbaa !29
  store ptr %t39, ptr %rv
  br label %ret
bb9:
  %t40 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t40, ptr %l25
  br label %bb10
bb10:
  %t41 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l25
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t41, ptr %l4
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l26, !tbaa !29
  %t43 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t44 = load i32, ptr %t43, !tbaa !23
  %t45 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t46 = load i32, ptr %t45, !tbaa !23
  %t48 = add i32 %t46, 1
  %t51 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t44, i32 %t48)
  store %"compiler/source:Span" %t51, ptr %l30
  br label %bb11
bb11:
  %t52 = load %"compiler/source:Span", ptr %l30
  %t53 = load ptr, ptr %l26, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 46
  store %"compiler/source:Span" %t52, ptr %t54
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l31, !tbaa !29
  %t56 = load ptr, ptr %l3, !tbaa !29
  %t59 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t56)
  store i32 %t59, ptr %l34
  br label %bb12
bb12:
  %t60 = load ptr, ptr %l31, !tbaa !29
  %t61 = load i32, ptr %l34, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantStr(ptr %v0, ptr %s0, ptr %t60, i32 %t61, ptr %l4, i64 0)
  br label %bb13
bb13:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l36, !tbaa !29
  %t64 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 -1, i32 -1)
  store %"compiler/source:Span" %t64, ptr %l37
  br label %bb14
bb14:
  %t65 = load %"compiler/source:Span", ptr %l37
  %t66 = load ptr, ptr %l36, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 46
  store %"compiler/source:Span" %t65, ptr %t67
  %t68 = load ptr, ptr %l3, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t68, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erestBind(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3, i32 %a4, i64 %a5, i64 %a6, ptr %a7, i64 %a8) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca ptr
  %l14 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca ptr
  %l19 = alloca i1
  %l27 = alloca i1
  %l30 = alloca { i64, ptr }
  %l31 = alloca i1
  %l35 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca %"compiler/source:Span"
  %l41 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca { i64, ptr }
  %l47 = alloca %"compiler/diagmsg:Msg"
  %l48 = alloca i64
  %l49 = alloca ptr
  %l50 = alloca %"compiler/source:Span"
  %l52 = alloca i32
  %l54 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca %"compiler/source:Span"
  %l57 = alloca %"compiler/source:Span"
  %l58 = alloca i32
  %l63 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca %"compiler/source:Span"
  %l67 = alloca i32
  %l69 = alloca ptr
  %l72 = alloca ptr
  %l79 = alloca ptr
  %l80 = alloca i32
  %l83 = alloca { i64, ptr }
  %l88 = alloca %"compiler/source:Span"
  %l89 = alloca ptr
  %l93 = alloca ptr
  %l94 = alloca %"compiler/source:Span"
  %l97 = alloca i32
  %l98 = alloca ptr
  %l102 = alloca i32
  %l104 = alloca ptr
  %l107 = alloca i32
  %l110 = alloca ptr
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %t158 = alloca { i64, [4 x i64] }, align 8
  %t180 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t1)
  store %"compiler/source:Span" %t3, ptr %l17
  br label %bb1
bb1:
  %t4 = load %"compiler/source:Span", ptr %l17
  store %"compiler/source:Span" %t4, ptr %l9
  store i32 0, ptr %l10, !tbaa !23
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t6 = load ptr, ptr %l18, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l18, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 9}
  %t12 = icmp eq i64 %t10, 7
  store i1 %t12, ptr %l19, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l19, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32 }, ptr %t16, i32 0, i32 1
  %t18 = load i32, ptr %t17
  store i32 %t18, ptr %l11, !tbaa !23
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t20 = load i32, ptr %l11, !tbaa !23
  store i32 %t20, ptr %l10, !tbaa !23
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_e5b066603c2028fc_10f264a847d19698)
  unreachable
bb12:
  %t22 = load i32, ptr %l10, !tbaa !23
  %t24 = icmp eq i32 %t22, 0
  br i1 %t24, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb17
bb14:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i32, ptr %l10, !tbaa !23
  %t30 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t26, i32 %t27)
  store { i64, ptr } %t30, ptr %l30
  br label %bb15
bb15:
  %t31 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t32 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t31, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) })
  store i1 %t32, ptr %l31
  br label %bb16
bb16:
  %t33 = load i1, ptr %l31, !tbaa !21
  store i1 %t33, ptr %l27, !tbaa !21
  br label %bb17
bb17:
  %t34 = load i1, ptr %l27, !tbaa !21
  br i1 %t34, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb19:
  br label %bb20
bb20:
  %t35 = load ptr, ptr %l3, !tbaa !29
  %t37 = getelementptr %"compiler/check:seqOf", ptr %t35, i32 0, i32 1
  %t38 = load i64, ptr %t37, !tbaa !24
  %t40 = icmp sge i64 %t38, 0
  br i1 %t40, label %bb21, label %bb22
bb21:
  %t42 = load ptr, ptr %l3, !tbaa !29
  %t44 = getelementptr %"compiler/check:seqOf", ptr %t42, i32 0, i32 3
  %t45 = load i64, ptr %t44, !tbaa !24
  %t47 = icmp slt i64 %t45, 0
  store i1 %t47, ptr %l35, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb23
bb23:
  %t49 = load i1, ptr %l35, !tbaa !21
  br i1 %t49, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s4
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l39, !tbaa !29
  %t51 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t51, ptr %l40
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l41, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t57 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t53, i32 %a4)
  store i32 %t57, ptr %l44
  br label %bb26
bb25:
  br label %bb30
bb26:
  %t58 = load ptr, ptr %l41, !tbaa !29
  %t59 = load i32, ptr %l44, !tbaa !23
  %t60 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s4, ptr %t58, i32 %t59)
  store { i64, ptr } %t60, ptr %l45
  br label %bb27
bb27:
  %t61 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t61, 0
  %t63 = extractvalue { i64, ptr } %t61, 1
  %t64 = mul i64 %t62, 1
  %t65 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t64)
  call void @llvm.memcpy.p0.p0.i64(ptr %t65, ptr %t63, i64 %t64, i1 false)
  %t66 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t65, 1
  %t69 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRestNoSlice(ptr %s4, ptr %s4, { i64, ptr } %t67)
  store %"compiler/diagmsg:Msg" %t69, ptr %l47
  br label %bb28
bb28:
  %t70 = load ptr, ptr %l39, !tbaa !29
  %t71 = load %"compiler/source:Span", ptr %l40
  %t72 = load %"compiler/diagmsg:Msg", ptr %l47
  %t73 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t70, %"compiler/source:Span" %t71, %"compiler/diagmsg:Msg" %t72)
  store i64 %t73, ptr %l48
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb30:
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l49, !tbaa !29
  %t75 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t75, ptr %l50
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t76)
  store i32 %t78, ptr %l52
  br label %bb31
bb31:
  %t80 = load ptr, ptr %l49, !tbaa !29
  %t81 = load %"compiler/source:Span", ptr %l50
  %t82 = load i32, ptr %l52, !tbaa !23
  %t84 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t80, %"compiler/source:Span" %t81, i32 %t82, i64 %a5)
  store ptr %t84, ptr %l54
  br label %bb32
bb32:
  %t85 = load ptr, ptr %l54, !tbaa !29
  store ptr %t85, ptr %l12, !tbaa !29
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l55, !tbaa !29
  %t87 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t87, ptr %l56
  %t88 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t88, ptr %l57
  store i32 53, ptr %l58
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load %"compiler/source:Span", ptr %l9
  %t91 = load ptr, ptr %l2, !tbaa !29
  %t92 = load ptr, ptr %l3, !tbaa !29
  %t97 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eseqLen(ptr %v0, ptr %v2, ptr %v3, ptr %v0, ptr %t89, %"compiler/source:Span" %t90, ptr %t91, ptr %t92)
  store ptr %t97, ptr %l63
  br label %bb33
bb33:
  %t98 = load ptr, ptr %l0, !tbaa !29
  store ptr %t98, ptr %l64, !tbaa !29
  %t99 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t99, ptr %l65
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t100)
  store i32 %t102, ptr %l67
  br label %bb34
bb34:
  %t104 = load ptr, ptr %l64, !tbaa !29
  %t105 = load %"compiler/source:Span", ptr %l65
  %t106 = load i32, ptr %l67, !tbaa !23
  %t108 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t104, %"compiler/source:Span" %t105, i32 %t106, i64 %a6)
  store ptr %t108, ptr %l69
  br label %bb35
bb35:
  %t109 = load %"compiler/source:Span", ptr %l9
  %t110 = load %"compiler/source:Span", ptr %l9
  %t111 = load ptr, ptr %l55, !tbaa !29
  %t112 = load %"compiler/source:Span", ptr %l56
  %t113 = load %"compiler/source:Span", ptr %l57
  %t114 = load i32, ptr %l58, !range !{i32 0, i32 98}
  %t115 = load ptr, ptr %l63, !tbaa !29
  %t116 = load ptr, ptr %l69, !tbaa !29
  %t119 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t111, %"compiler/source:Span" %t112, %"compiler/source:Span" %t113, i32 %t114, ptr %t115, ptr %t116, %"compiler/source:Span" %t109, %"compiler/source:Span" %t110)
  store ptr %t119, ptr %l72
  br label %bb36
bb36:
  %t120 = load ptr, ptr %l72, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load %"compiler/source:Span", ptr %l9
  %t123 = load ptr, ptr %l2, !tbaa !29
  %t124 = load ptr, ptr %l3, !tbaa !29
  %t125 = load ptr, ptr %l12, !tbaa !29
  %t133 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eseqSlice(ptr %v0, ptr %v2, ptr %v3, ptr %v0, ptr %v0, ptr %v0, ptr %t121, %"compiler/source:Span" %t122, ptr %t123, ptr %t124, ptr %t125, ptr %t120)
  store ptr %t133, ptr %l79
  br label %bb37
bb37:
  %t134 = load ptr, ptr %l79, !tbaa !29
  store ptr %t134, ptr %l14, !tbaa !29
  %t135 = getelementptr %"compiler/source:Span", ptr %l9, i32 0, i32 1
  %t136 = load i32, ptr %t135, !tbaa !23
  store i32 %t136, ptr %l80, !tbaa !23
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load i32, ptr %l10, !tbaa !23
  %t141 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s0, ptr %t137, i32 %t138)
  store { i64, ptr } %t141, ptr %l83
  br label %bb38
bb38:
  %t142 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t142, 0
  %t145 = trunc i64 %t143 to i32
  %t146 = load i32, ptr %l80, !tbaa !23
  %t148 = sub i32 %t146, %t145
  %t149 = getelementptr %"compiler/source:Span", ptr %l9, i32 0, i32 1
  %t150 = load i32, ptr %t149, !tbaa !23
  %t153 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t148, i32 %t150)
  store %"compiler/source:Span" %t153, ptr %l88
  br label %bb39
bb39:
  %t154 = load %"compiler/source:Span", ptr %l88
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l89, !tbaa !29
  %t157 = load i32, ptr %l10, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t158
  %t159 = getelementptr { i64, [4 x i64] }, ptr %t158, i32 0, i32 0
  store i64 3, ptr %t159
  %t161 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t154, 0
  %t163 = insertvalue { %"compiler/source:Span", i32 } %t161, i32 %t157, 1
  %t164 = getelementptr { i64, [4 x i64] }, ptr %t158, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t163, ptr %t164
  %t165 = load { i64, [4 x i64] }, ptr %t158
  %t167 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t165, ptr %t167
  store ptr %t167, ptr %l93, !tbaa !29
  %t168 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t168, ptr %l94
  %t169 = load ptr, ptr %l14, !tbaa !29
  %t172 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t169)
  store i32 %t172, ptr %l97
  br label %bb40
bb40:
  %t173 = load ptr, ptr %l14, !tbaa !29
  store ptr %t173, ptr %l98, !tbaa !29
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load %"compiler/source:Span", ptr %l9
  %t179 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t174, i32 8, %"compiler/source:Span" %t175)
  store i32 %t179, ptr %l102
  br label %bb41
bb41:
  store { i64, [4 x i64] } zeroinitializer, ptr %t180
  %t181 = getelementptr { i64, [4 x i64] }, ptr %t180, i32 0, i32 0
  store i64 6, ptr %t181
  %t182 = load %"compiler/source:Span", ptr %l94
  %t183 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t182, 0
  %t184 = load i32, ptr %l97, !tbaa !23
  %t185 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t183, i32 %t184, 1
  %t186 = load ptr, ptr %l98, !tbaa !29
  %t187 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t185, ptr %t186, 2
  %t188 = load i32, ptr %l102, !tbaa !23
  %t189 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t187, i32 %t188, 3
  %t190 = getelementptr { i64, [4 x i64] }, ptr %t180, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t189, ptr %t190
  %t191 = load { i64, [4 x i64] }, ptr %t180
  %t193 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t191, ptr %t193
  store ptr %t193, ptr %l104, !tbaa !29
  %t194 = load ptr, ptr %l14, !tbaa !29
  %t197 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t194)
  store i32 %t197, ptr %l107
  br label %bb42
bb42:
  %t200 = load ptr, ptr %l89, !tbaa !29
  %t201 = load ptr, ptr %l93, !tbaa !29
  %t202 = load ptr, ptr %l104, !tbaa !29
  %t203 = load i32, ptr %l107, !tbaa !23
  %t206 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epattern(ptr %v0, ptr %v0, ptr %v0, ptr %v4, ptr %v0, ptr %t200, ptr %t201, ptr %t202, i32 %t203, ptr %a7, i64 %a8)
  store ptr %t206, ptr %l110
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l7 = alloca i32
  %l10 = alloca i1
  %l15 = alloca i32
  %l19 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca i32
  %l28 = alloca i1
  %l33 = alloca i32
  %l38 = alloca i32
  %l41 = alloca i1
  %l46 = alloca i32
  %l50 = alloca ptr
  %l53 = alloca ptr
  %l58 = alloca i32
  %l59 = alloca i32
  %l64 = alloca i64
  %l65 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t13 = trunc i64 19 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l1, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l15
  br label %bb4
bb3:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb5
bb4:
  %t26 = load i32, ptr %l15, !tbaa !23
  %t27 = icmp ne i32 %t26, 0
  store i1 %t27, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t29 = load i1, ptr %l10, !tbaa !21
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t33, i32 0, i32 2
  store ptr %t35, ptr %l19, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = getelementptr %"compiler/generic:Program", ptr %t39, i32 0, i32 2
  %t42 = load i32, ptr %l1, !tbaa !23
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l24
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t46 = load ptr, ptr %l19, !tbaa !29
  %t47 = load i32, ptr %l24, !tbaa !23
  %t48 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t46, i32 %t47, i32 0)
  store i32 %t48, ptr %l25
  br label %bb9
bb9:
  %t49 = load i32, ptr %l25, !tbaa !23
  store i32 %t49, ptr %rv
  br label %ret
bb10:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load i32, ptr %l1, !tbaa !23
  %t54 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t50, i32 %t51)
  store i1 %t54, ptr %l28
  br label %bb11
bb11:
  %t55 = load i1, ptr %l28, !tbaa !21
  br i1 %t55, label %bb12, label %bb13
bb12:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  %t62 = load i32, ptr %l1, !tbaa !23
  %t65 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t61, i32 %t62)
  store i32 %t65, ptr %l33
  br label %bb14
bb13:
  br label %bb27
bb14:
  %t66 = load i32, ptr %l33, !tbaa !23
  store i32 %t66, ptr %l2, !tbaa !23
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t70, i32 0, i32 2
  %t73 = load i32, ptr %l2, !tbaa !23
  %t76 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t72, i32 %t73)
  store i32 %t76, ptr %l38
  br label %bb15
bb15:
  %t77 = load i32, ptr %l38, !range !{i32 0, i32 33}
  %t79 = trunc i64 19 to i32
  %t80 = icmp eq i32 %t77, %t79
  br i1 %t80, label %bb16, label %bb17
bb16:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/generic:Program", ptr %t85, i32 0, i32 2
  %t88 = load i32, ptr %l2, !tbaa !23
  %t91 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t87, i32 %t88)
  store i32 %t91, ptr %l46
  br label %bb18
bb17:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb19
bb18:
  %t92 = load i32, ptr %l46, !tbaa !23
  %t93 = icmp ne i32 %t92, 0
  store i1 %t93, ptr %l41, !tbaa !21
  br label %bb19
bb19:
  %t95 = load i1, ptr %l41, !tbaa !21
  br i1 %t95, label %bb20, label %bb21
bb20:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/check:Checker", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/generic:Program", ptr %t99, i32 0, i32 2
  store ptr %t101, ptr %l50, !tbaa !29
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/check:Checker", ptr %t102, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = getelementptr %"compiler/generic:Program", ptr %t105, i32 0, i32 2
  store ptr %t107, ptr %l53, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/check:Checker", ptr %t108, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = getelementptr %"compiler/generic:Program", ptr %t111, i32 0, i32 2
  %t114 = load i32, ptr %l2, !tbaa !23
  %t117 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t113, i32 %t114)
  store i32 %t117, ptr %l58
  br label %bb22
bb21:
  br label %bb26
bb22:
  %t118 = load ptr, ptr %l53, !tbaa !29
  %t119 = load i32, ptr %l58, !tbaa !23
  %t120 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t118, i32 %t119, i32 0)
  store i32 %t120, ptr %l59
  br label %bb23
bb23:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/check:Checker", ptr %t121, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t126 = getelementptr %"compiler/generic:Program", ptr %t124, i32 0, i32 2
  %t127 = load i32, ptr %l1, !tbaa !23
  %t130 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t126, i32 %t127)
  store i64 %t130, ptr %l64
  br label %bb24
bb24:
  %t131 = load ptr, ptr %l50, !tbaa !29
  %t132 = load i32, ptr %l59, !tbaa !23
  %t133 = load i64, ptr %l64, !tbaa !24
  %t134 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t131, i32 %t132, i64 %t133)
  store i32 %t134, ptr %l65
  br label %bb25
bb25:
  %t135 = load i32, ptr %l65, !tbaa !23
  store i32 %t135, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t136 = load i32, ptr %l1, !tbaa !23
  store i32 %t136, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esuggest(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i64
  %lp4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l7 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca %"compiler/load:Import"
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca %"compiler/names:Entry"
  %l26 = alloca { i64, ptr }
  %l31 = alloca i1
  %l32 = alloca { i64, ptr }
  %l36 = alloca i1
  %l43 = alloca i1
  %l48 = alloca i1
  %l54 = alloca { i64, ptr }
  %l56 = alloca i8
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l72 = alloca i32
  %l77 = alloca i1
  %l78 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l80 = alloca i64
  %l81 = alloca { i64, ptr }
  %l83 = alloca %"compiler/msgs:Nearest"
  %l87 = alloca ptr
  %l90 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l91 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l93 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l94 = alloca i32
  %l96 = alloca i1
  %l97 = alloca ptr
  %l100 = alloca { i64, ptr }
  %l104 = alloca ptr
  %l106 = alloca ptr
  %l109 = alloca ptr
  %l112 = alloca i64
  %l114 = alloca i64
  %l119 = alloca %"compiler/load:Import"
  %l126 = alloca [14 x { i64, ptr }]
  %l145 = alloca i64
  %l149 = alloca i64
  %l152 = alloca i64
  %l170 = alloca i64
  %l172 = alloca ptr
  %l176 = alloca i1
  %l182 = alloca ptr
  %l186 = alloca i64
  %l188 = alloca ptr
  %l197 = alloca ptr
  %l200 = alloca i64
  %l202 = alloca i64
  %l207 = alloca %"compiler/names:Entry"
  %l210 = alloca i1
  %l212 = alloca i1
  %l215 = alloca i1
  %l217 = alloca i1
  %l224 = alloca { i64, ptr }
  %l227 = alloca i1
  %l229 = alloca i1
  %s0 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp sgt i64 %t5, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t9, ptr %l32, !tbaa !27
  %t10 = load i64, ptr %l3, !tbaa !24
  %t12 = sub i64 %t10, 1
  %t14 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i8, ptr %t15, i64 %t12
  %t17 = load i8, ptr %t16, !tbaa !32
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t17)
  store i1 %t19, ptr %l36
  br label %bb4
bb3:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb5
bb4:
  %t20 = load i1, ptr %l36, !tbaa !21
  store i1 %t20, ptr %l31, !tbaa !21
  br label %bb5
bb5:
  %t21 = load i1, ptr %l31, !tbaa !21
  %t22 = xor i1 %t21, true
  br i1 %t22, label %bb6, label %bb7
bb6:
  br label %bb10
bb7:
  br label %bb8
bb8:
  %t24 = load i64, ptr %l3, !tbaa !24
  %t26 = sub i64 %t24, 1
  store i64 %t26, ptr %l3, !tbaa !24
  br label %bb9
bb9:
  br label %bb1
bb10:
  %t28 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t32 = icmp sge i64 %t30, 2
  br i1 %t32, label %bb11, label %bb12
bb11:
  %t34 = load i64, ptr %l3, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t40 = icmp slt i64 %t34, %t37
  store i1 %t40, ptr %l43, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb13
bb13:
  %t42 = load i1, ptr %l43, !tbaa !21
  br i1 %t42, label %bb14, label %bb15
bb14:
  %t43 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t46 = load i64, ptr %l3, !tbaa !24
  %t49 = sub i64 %t45, %t46
  %t51 = icmp slt i64 %t49, 8
  store i1 %t51, ptr %l48, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb16
bb16:
  %t53 = load i1, ptr %l48, !tbaa !21
  br i1 %t53, label %bb17, label %bb18
bb17:
  %t54 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t54, ptr %l54, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr i8, ptr %t56, i64 0
  %t58 = load i8, ptr %t57, !tbaa !32
  %t60 = call i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToUpper(i8 %t58)
  store i8 %t60, ptr %l56
  br label %bb19
bb18:
  br label %bb30
bb19:
  %t61 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t61, ptr %l57, !tbaa !27
  %t62 = load i64, ptr %l3, !tbaa !24
  store i64 %t62, ptr %l58, !tbaa !24
  %t63 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t63, 0
  store i64 %t66, ptr %l61, !tbaa !24
  %t67 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 0
  store i64 %t68, ptr %l62, !tbaa !24
  %t69 = load i64, ptr %l58, !tbaa !24
  %t70 = icmp sge i64 %t69, 0
  br i1 %t70, label %bb20, label %bb21
bb20:
  %t72 = load i64, ptr %l58, !tbaa !24
  %t73 = load i64, ptr %l61, !tbaa !24
  %t74 = icmp sle i64 %t72, %t73
  br i1 %t74, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_fbd40b14c0771014_77084db5763620a0)
  unreachable
bb22:
  %t76 = load i64, ptr %l61, !tbaa !24
  %t77 = load i64, ptr %l62, !tbaa !24
  %t78 = icmp sle i64 %t76, %t77
  br i1 %t78, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_fbd40b14c0771014_77084db5763620a0)
  unreachable
bb24:
  %t80 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = load i64, ptr %l58, !tbaa !24
  %t83 = load i64, ptr %l61, !tbaa !24
  %t84 = getelementptr i8, ptr %t81, i64 %t82
  %t85 = sub i64 %t83, %t82
  %t86 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t84, 1
  %t88 = load i8, ptr %l56, !tbaa !22
  %t90 = extractvalue { i64, ptr } %t87, 1
  %t91 = extractvalue { i64, ptr } %t87, 0
  %t92 = add i64 1, %t91
  %t93 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t92)
  store i8 %t88, ptr %t93
  %t94 = getelementptr i8, ptr %t93, i64 1
  call void @olang_textcopy(ptr %t94, ptr %t90, i64 %t91)
  %t95 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t93, 1
  %t97 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t97, ptr %lp4
  %t99 = load ptr, ptr %lp4
  store { i64, ptr } %t96, ptr %t99, !tbaa !27
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/check:Checker", ptr %t100, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = getelementptr %"compiler/generic:Program", ptr %t103, i32 0, i32 2
  %t106 = load ptr, ptr %lp4
  %t107 = load { i64, ptr }, ptr %t106, !tbaa !27
  %t110 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v2, ptr %t105, { i64, ptr } %t107)
  store i32 %t110, ptr %l72
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_fbd40b14c0771014_77084db5763620a0)
  unreachable
bb26:
  %t111 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t112 = load i32, ptr %l72, !tbaa !23
  %t114 = icmp ne i32 %t112, %t111
  br i1 %t114, label %bb27, label %bb28
bb27:
  %t116 = load ptr, ptr %lp4
  %t117 = load { i64, ptr }, ptr %t116, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t117, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t119 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t121 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t119, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d39, i32 0, i32 1) })
  store i1 %t121, ptr %l77
  br label %bb31
bb31:
  %t122 = load i1, ptr %l77, !tbaa !21
  br i1 %t122, label %bb32, label %bb33
bb32:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %l78, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t123, ptr %l79, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t124, 0
  store i64 %t125, ptr %l80, !tbaa !24
  %t126 = load i64, ptr %l80, !tbaa !24
  %t127 = mul i64 %t126, 1
  %t128 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t127)
  %t129 = insertvalue { i64, ptr } undef, i64 %t126, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t128, 1
  store { i64, ptr } %t130, ptr %l81, !tbaa !27
  %t131 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = load i64, ptr %l80, !tbaa !24
  %t136 = mul i64 %t135, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t132, ptr %t134, i64 %t136, i1 false)
  %t137 = load { i64, ptr }, ptr %l81, !tbaa !27
  store { i64, ptr } %t137, ptr %l79, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t138 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t138, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  %t139 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t141 = call %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v1, ptr %s0, { i64, ptr } %t139)
  store %"compiler/msgs:Nearest" %t141, ptr %l83
  br label %bb35
bb35:
  %t142 = load %"compiler/msgs:Nearest", ptr %l83
  %t143 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 40, i64 8)
  store %"compiler/msgs:Nearest" %t142, ptr %t143
  store ptr %t143, ptr %l5, !tbaa !29
  %t145 = load i1, ptr %l2, !tbaa !21
  br i1 %t145, label %bb36, label %bb37
bb36:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t147)
  store ptr %t149, ptr %l87
  br label %bb38
bb37:
  br label %bb63
bb38:
  %t150 = load ptr, ptr %l87, !tbaa !29
  %t152 = getelementptr %"compiler/check:frame", ptr %t150, i32 0, i32 8
  %t154 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hda627d7755eecb5b938ca977110d67b2(ptr %v0, ptr %v0, ptr %t152)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t154, ptr %l90
  br label %bb39
bb39:
  %t155 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l90
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t155, ptr %l6
  br label %bb40
bb40:
  %t157 = call { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20I6_Hd1b8e91149b724287340e79c8c928444(ptr %v0, ptr %l6)
  %t158 = extractvalue { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } %t157, 1
  %t159 = extractvalue { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } %t157, 0
  store i32 %t159, ptr %l94
  %t160 = icmp ne i32 %t159, 0
  br i1 %t160, label %bb42, label %ok.161, !prof !99
ok.161:
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t158, ptr %l93
  br label %bb41
bb41:
  %t162 = load %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l93
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t162, ptr %l91
  br label %bb44
bb42:
  %t163 = load i32, ptr %l94, !tbaa !23
  %t164 = ashr i32 %t163, 16
  %t166 = icmp eq i32 %t164, 1
  store i1 %t166, ptr %l96, !tbaa !21
  br label %bb43
bb43:
  br label %bb48
bb44:
  %t167 = load %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l91
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t167, ptr %l7
  %t168 = load ptr, ptr %l5, !tbaa !29
  store ptr %t168, ptr %l97, !tbaa !29
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l7, i32 0, i32 0
  %t171 = load i32, ptr %t170, !tbaa !23
  %t174 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t169, i32 %t171)
  store { i64, ptr } %t174, ptr %l100
  br label %bb45
bb45:
  %t175 = load ptr, ptr %l97, !tbaa !29
  %t176 = load { i64, ptr }, ptr %l100, !tbaa !27
  call void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %s0, ptr %v0, ptr %t175, { i64, ptr } %t176)
  br label %bb46
bb46:
  br label %bb47
bb47:
  br label %bb40
bb48:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/check:Checker", ptr %t177, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !29
  %t182 = getelementptr %"compiler/generic:Program", ptr %t180, i32 0, i32 0
  %t183 = load ptr, ptr %t182, !tbaa !29
  %t185 = getelementptr %"compiler/load:Loader", ptr %t183, i32 0, i32 10
  store ptr %t185, ptr %l104, !tbaa !29
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t186)
  store ptr %t188, ptr %l106
  br label %bb49
bb49:
  %t189 = load ptr, ptr %l106, !tbaa !29
  %t191 = getelementptr %"compiler/check:frame", ptr %t189, i32 0, i32 1
  %t192 = load i64, ptr %t191, !tbaa !24
  %t193 = load ptr, ptr %l104, !tbaa !29
  %t195 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t193, i64 %t192)
  store ptr %t195, ptr %l109
  br label %bb50
bb50:
  %t196 = load ptr, ptr %l109, !tbaa !29
  %t198 = getelementptr %"compiler/load:Module", ptr %t196, i32 0, i32 11
  store ptr %t198, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb51
bb51:
  %t200 = load i64, ptr %l9, !tbaa !24
  store i64 %t200, ptr %l112, !tbaa !24
  %t201 = load ptr, ptr %l8, !tbaa !29
  %t203 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t201)
  store i64 %t203, ptr %l114
  br label %bb52
bb52:
  %t204 = load i64, ptr %l112, !tbaa !24
  %t205 = load i64, ptr %l114, !tbaa !24
  %t206 = icmp slt i64 %t204, %t205
  %t208 = xor i1 %t206, true
  br i1 %t208, label %bb53, label %bb54
bb53:
  br label %bb62
bb54:
  br label %bb55
bb55:
  %t210 = load ptr, ptr %l8, !tbaa !29
  %t211 = load i64, ptr %l9, !tbaa !24
  %t214 = call %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t210, i64 %t211)
  store %"compiler/load:Import" %t214, ptr %l119
  br label %bb56
bb56:
  %t215 = load %"compiler/load:Import", ptr %l119
  store %"compiler/load:Import" %t215, ptr %l10
  %t216 = getelementptr %"compiler/load:Import", ptr %l10, i32 0, i32 5
  %t217 = load i64, ptr %t216, !tbaa !24
  %t219 = icmp sge i64 %t217, 0
  br i1 %t219, label %bb57, label %bb58
bb57:
  %t221 = load ptr, ptr %l5, !tbaa !29
  %t222 = getelementptr %"compiler/load:Import", ptr %l10, i32 0, i32 2
  %t223 = load { i64, ptr }, ptr %t222, !tbaa !27
  call void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %s0, ptr %v0, ptr %t221, { i64, ptr } %t223)
  br label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t226 = load i64, ptr %l9, !tbaa !24
  %t228 = add i64 %t226, 1
  store i64 %t228, ptr %l9, !tbaa !24
  br label %bb51
bb62:
  br label %bb63
bb63:
  store %olang.scope zeroinitializer, ptr %s13
  %t230 = getelementptr [14 x { i64, ptr }], ptr %l126, i64 0, i64 0
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d41, i32 0, i32 1) }, ptr %t230, !tbaa !37
  %t231 = getelementptr [14 x { i64, ptr }], ptr %l126, i64 0, i64 1
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d42, i32 0, i32 1) }, ptr %t231, !tbaa !37
  %t232 = getelementptr [14 x { i64, ptr }], ptr %l126, i64 0, i64 2
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d43, i32 0, i32 1) }, ptr %t232, !tbaa !37
  %t233 = getelementptr [14 x { i64, ptr }], ptr %l126, i64 0, i64 3
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d44, i32 0, i32 1) }, ptr %t233, !tbaa !37
  %t234 = getelementptr [14 x { i64, ptr }], ptr %l126, i64 0, i64 4
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d45, i32 0, i32 1) }, ptr %t234, !tbaa !37
  %t235 = getelementptr [14 x { i64, ptr }], ptr %l126, i64 0, i64 5
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d46, i32 0, i32 1) }, ptr %t235, !tbaa !37
  %t236 = getelementptr [14 x { i64, ptr }], ptr %l126, i64 0, i64 6
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d47, i32 0, i32 1) }, ptr %t236, !tbaa !37
  %t237 = getelementptr [14 x { i64, ptr }], ptr %l126, i64 0, i64 7
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %t237, !tbaa !37
  %t238 = getelementptr [14 x { i64, ptr }], ptr %l126, i64 0, i64 8
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d49, i32 0, i32 1) }, ptr %t238, !tbaa !37
  %t239 = getelementptr [14 x { i64, ptr }], ptr %l126, i64 0, i64 9
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d50, i32 0, i32 1) }, ptr %t239, !tbaa !37
  %t240 = getelementptr [14 x { i64, ptr }], ptr %l126, i64 0, i64 10
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d51, i32 0, i32 1) }, ptr %t240, !tbaa !37
  %t241 = getelementptr [14 x { i64, ptr }], ptr %l126, i64 0, i64 11
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d52, i32 0, i32 1) }, ptr %t241, !tbaa !37
  %t242 = getelementptr [14 x { i64, ptr }], ptr %l126, i64 0, i64 12
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d53, i32 0, i32 1) }, ptr %t242, !tbaa !37
  %t243 = getelementptr [14 x { i64, ptr }], ptr %l126, i64 0, i64 13
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d54, i32 0, i32 1) }, ptr %t243, !tbaa !37
  %t244 = call ptr @__olang_scope_alloc_a(ptr %s13, i64 224, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t244, ptr %l126, i64 224, i1 false)
  store ptr %t244, ptr %l11
  store i64 0, ptr %l12, !tbaa !24
  %t246 = load ptr, ptr %l11
  store i64 14, ptr %l13, !tbaa !24
  br label %bb64
bb64:
  %t249 = load i64, ptr %l12, !tbaa !24
  %t250 = load i64, ptr %l13, !tbaa !24
  %t253 = icmp slt i64 %t249, %t250
  %t255 = xor i1 %t253, true
  br i1 %t255, label %bb65, label %bb66
bb65:
  br label %bb70
bb66:
  br label %bb67
bb67:
  %t257 = load ptr, ptr %l11
  %t258 = load i64, ptr %l12, !tbaa !24
  %t261 = getelementptr [14 x { i64, ptr }], ptr %t257, i64 0, i64 %t258
  %t262 = load { i64, ptr }, ptr %t261, !tbaa !37
  %t264 = load ptr, ptr %l5, !tbaa !29
  %t266 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %s0, ptr %t266, ptr %t264, { i64, ptr } %t262)
  br label %bb68
bb68:
  br label %bb69
bb69:
  %t269 = load i64, ptr %l12, !tbaa !24
  %t271 = add i64 %t269, 1
  store i64 %t271, ptr %l12, !tbaa !24
  br label %bb64
bb70:
  call void @__olang_scope_close(ptr %s13)
  store i64 0, ptr %l15, !tbaa !24
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/check:Checker", ptr %t273, i32 0, i32 1
  %t276 = load ptr, ptr %t275, !tbaa !29
  %t278 = getelementptr %"compiler/generic:Program", ptr %t276, i32 0, i32 0
  %t279 = load ptr, ptr %t278, !tbaa !29
  %t281 = getelementptr %"compiler/load:Loader", ptr %t279, i32 0, i32 10
  %t283 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t281)
  store i64 %t283, ptr %l145
  br label %bb71
bb71:
  %t284 = load i64, ptr %l145, !tbaa !24
  store i64 %t284, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t285 = load i64, ptr %l16, !tbaa !24
  %t286 = load i64, ptr %l15, !tbaa !24
  %t289 = icmp sgt i64 %t285, %t286
  br i1 %t289, label %bb72, label %bb73
bb72:
  %t291 = load i64, ptr %l17, !tbaa !24
  %t293 = icmp sgt i64 %t291, 0
  br i1 %t293, label %bb74, label %bb75
bb73:
  store i64 0, ptr %l149, !tbaa !24
  br label %bb77
bb74:
  %t295 = load i64, ptr %l16, !tbaa !24
  %t296 = load i64, ptr %l15, !tbaa !24
  %t299 = sub i64 %t295, %t296
  %t300 = load i64, ptr %l17, !tbaa !24
  %t303 = add i64 %t299, %t300
  %t305 = sub i64 %t303, 1
  %t306 = load i64, ptr %l17, !tbaa !24
  %t309 = sdiv i64 %t305, %t306
  store i64 %t309, ptr %l152, !tbaa !24
  br label %bb76
bb75:
  store i64 0, ptr %l152, !tbaa !24
  br label %bb76
bb76:
  %t311 = load i64, ptr %l152, !tbaa !24
  store i64 %t311, ptr %l149, !tbaa !24
  br label %bb77
bb77:
  %t312 = load i64, ptr %l149, !tbaa !24
  store i64 %t312, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb78
bb78:
  %t313 = load i64, ptr %l19, !tbaa !24
  %t314 = load i64, ptr %l18, !tbaa !24
  %t317 = icmp slt i64 %t313, %t314
  %t319 = xor i1 %t317, true
  br i1 %t319, label %bb79, label %bb80
bb79:
  br label %bb125
bb80:
  br label %bb81
bb81:
  %t321 = load i64, ptr %l15, !tbaa !24
  %t322 = load i64, ptr %l19, !tbaa !24
  %t323 = load i64, ptr %l17, !tbaa !24
  %t326 = mul i64 %t322, %t323
  %t329 = add i64 %t321, %t326
  store i64 %t329, ptr %l20, !tbaa !24
  %t331 = load i64, ptr %l20, !tbaa !24
  store i64 %t331, ptr %l170, !tbaa !24
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t334 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t332)
  store ptr %t334, ptr %l172
  br label %bb82
bb82:
  %t335 = load ptr, ptr %l172, !tbaa !29
  %t337 = getelementptr %"compiler/check:frame", ptr %t335, i32 0, i32 1
  %t338 = load i64, ptr %t337, !tbaa !24
  %t339 = load i64, ptr %l170, !tbaa !24
  %t341 = icmp ne i64 %t339, %t338
  br i1 %t341, label %bb83, label %bb84
bb83:
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t345 = getelementptr %"compiler/check:Checker", ptr %t343, i32 0, i32 1
  %t346 = load ptr, ptr %t345, !tbaa !29
  %t348 = getelementptr %"compiler/generic:Program", ptr %t346, i32 0, i32 0
  %t349 = load ptr, ptr %t348, !tbaa !29
  %t351 = getelementptr %"compiler/load:Loader", ptr %t349, i32 0, i32 10
  %t352 = load i64, ptr %l20, !tbaa !24
  %t355 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t351, i64 %t352)
  store ptr %t355, ptr %l182
  br label %bb85
bb84:
  store i1 false, ptr %l176, !tbaa !21
  br label %bb86
bb85:
  %t356 = load ptr, ptr %l182, !tbaa !29
  %t358 = getelementptr %"compiler/load:Module", ptr %t356, i32 0, i32 3
  %t359 = load i1, ptr %t358, !tbaa !21
  %t361 = xor i1 %t359, true
  store i1 %t361, ptr %l176, !tbaa !21
  br label %bb86
bb86:
  %t363 = load i1, ptr %l176, !tbaa !21
  br i1 %t363, label %bb87, label %bb88
bb87:
  br label %bb124
bb88:
  br label %bb89
bb89:
  %t364 = load i64, ptr %l20, !tbaa !24
  store i64 %t364, ptr %l186, !tbaa !24
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t367 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t365)
  store ptr %t367, ptr %l188
  br label %bb90
bb90:
  %t368 = load ptr, ptr %l188, !tbaa !29
  %t370 = getelementptr %"compiler/check:frame", ptr %t368, i32 0, i32 1
  %t371 = load i64, ptr %t370, !tbaa !24
  %t372 = load i64, ptr %l186, !tbaa !24
  %t374 = icmp eq i64 %t372, %t371
  store i1 %t374, ptr %l21, !tbaa !21
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t378 = getelementptr %"compiler/check:Checker", ptr %t376, i32 0, i32 1
  %t379 = load ptr, ptr %t378, !tbaa !29
  %t381 = getelementptr %"compiler/generic:Program", ptr %t379, i32 0, i32 1
  %t382 = load ptr, ptr %t381, !tbaa !29
  %t384 = getelementptr %"compiler/names:Resolver", ptr %t382, i32 0, i32 1
  %t385 = load i64, ptr %l20, !tbaa !24
  %t388 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t384, i64 %t385)
  store ptr %t388, ptr %l197
  br label %bb91
bb91:
  %t389 = load ptr, ptr %l197, !tbaa !29
  %t391 = getelementptr %"compiler/names:Table", ptr %t389, i32 0, i32 0
  store ptr %t391, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  br label %bb92
bb92:
  %t393 = load i64, ptr %l23, !tbaa !24
  store i64 %t393, ptr %l200, !tbaa !24
  %t394 = load ptr, ptr %l22, !tbaa !29
  %t396 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t394)
  store i64 %t396, ptr %l202
  br label %bb93
bb93:
  %t397 = load i64, ptr %l200, !tbaa !24
  %t398 = load i64, ptr %l202, !tbaa !24
  %t399 = icmp slt i64 %t397, %t398
  %t401 = xor i1 %t399, true
  br i1 %t401, label %bb94, label %bb95
bb94:
  br label %bb123
bb95:
  br label %bb96
bb96:
  %t403 = load ptr, ptr %l22, !tbaa !29
  %t404 = load i64, ptr %l23, !tbaa !24
  %t407 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t403, i64 %t404)
  store %"compiler/names:Entry" %t407, ptr %l207
  br label %bb97
bb97:
  %t408 = load %"compiler/names:Entry", ptr %l207
  store %"compiler/names:Entry" %t408, ptr %l24
  %t409 = getelementptr %"compiler/names:Entry", ptr %l24, i32 0, i32 2
  %t410 = load i32, ptr %t409, !range !{i32 0, i32 9}
  %t412 = trunc i64 4 to i32
  %t413 = icmp eq i32 %t410, %t412
  br i1 %t413, label %bb98, label %bb99
bb98:
  store i1 true, ptr %l210, !tbaa !21
  br label %bb109
bb99:
  %t415 = load i1, ptr %l2, !tbaa !21
  br i1 %t415, label %bb100, label %bb101
bb100:
  %t417 = getelementptr %"compiler/names:Entry", ptr %l24, i32 0, i32 2
  %t418 = load i32, ptr %t417, !range !{i32 0, i32 9}
  %t420 = trunc i64 2 to i32
  %t421 = icmp eq i32 %t418, %t420
  br i1 %t421, label %bb102, label %bb103
bb101:
  store i1 false, ptr %l212, !tbaa !21
  br label %bb108
bb102:
  store i1 true, ptr %l215, !tbaa !21
  br label %bb107
bb103:
  %t423 = load i1, ptr %l21, !tbaa !21
  br i1 %t423, label %bb104, label %bb105
bb104:
  %t425 = getelementptr %"compiler/names:Entry", ptr %l24, i32 0, i32 2
  %t426 = load i32, ptr %t425, !range !{i32 0, i32 9}
  %t428 = trunc i64 3 to i32
  %t429 = icmp eq i32 %t426, %t428
  store i1 %t429, ptr %l217, !tbaa !21
  br label %bb106
bb105:
  store i1 false, ptr %l217, !tbaa !21
  br label %bb106
bb106:
  %t431 = load i1, ptr %l217, !tbaa !21
  store i1 %t431, ptr %l215, !tbaa !21
  br label %bb107
bb107:
  %t432 = load i1, ptr %l215, !tbaa !21
  store i1 %t432, ptr %l212, !tbaa !21
  br label %bb108
bb108:
  %t433 = load i1, ptr %l212, !tbaa !21
  store i1 %t433, ptr %l210, !tbaa !21
  br label %bb109
bb109:
  %t434 = load i1, ptr %l210, !tbaa !21
  %t437 = xor i1 %t434, true
  br i1 %t437, label %bb110, label %bb111
bb110:
  br label %bb122
bb111:
  br label %bb112
bb112:
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t440 = getelementptr %"compiler/names:Entry", ptr %l24, i32 0, i32 0
  %t441 = load i32, ptr %t440, !tbaa !23
  %t444 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t439, i32 %t441)
  store { i64, ptr } %t444, ptr %l224
  br label %bb113
bb113:
  %t445 = load { i64, ptr }, ptr %l224, !tbaa !27
  store { i64, ptr } %t445, ptr %l26, !tbaa !27
  %t446 = load i1, ptr %l21, !tbaa !21
  %t448 = xor i1 %t446, true
  br i1 %t448, label %bb114, label %bb115
bb114:
  %t450 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t452 = call i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %t450)
  store i1 %t452, ptr %l229
  br label %bb116
bb115:
  store i1 false, ptr %l227, !tbaa !21
  br label %bb117
bb116:
  %t453 = load i1, ptr %l229, !tbaa !21
  %t454 = xor i1 %t453, true
  store i1 %t454, ptr %l227, !tbaa !21
  br label %bb117
bb117:
  %t456 = load i1, ptr %l227, !tbaa !21
  br i1 %t456, label %bb118, label %bb119
bb118:
  br label %bb122
bb119:
  br label %bb120
bb120:
  %t457 = load ptr, ptr %l5, !tbaa !29
  %t458 = load { i64, ptr }, ptr %l26, !tbaa !27
  call void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %s0, ptr %v0, ptr %t457, { i64, ptr } %t458)
  br label %bb121
bb121:
  br label %bb122
bb122:
  %t461 = load i64, ptr %l23, !tbaa !24
  %t463 = add i64 %t461, 1
  store i64 %t463, ptr %l23, !tbaa !24
  br label %bb92
bb123:
  br label %bb124
bb124:
  %t465 = load i64, ptr %l19, !tbaa !24
  %t467 = add i64 %t465, 1
  store i64 %t467, ptr %l19, !tbaa !24
  br label %bb78
bb125:
  %t469 = load ptr, ptr %l5, !tbaa !29
  %t471 = getelementptr %"compiler/msgs:Nearest", ptr %t469, i32 0, i32 1
  %t472 = load { i64, ptr }, ptr %t471, !tbaa !27
  %t474 = extractvalue { i64, ptr } %t472, 1
  %t475 = extractvalue { i64, ptr } %t472, 0
  %t476 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t475)
  call void @olang_textcopy(ptr %t476, ptr %t474, i64 %t475)
  %t477 = insertvalue { i64, ptr } undef, i64 %t475, 0
  %t478 = insertvalue { i64, ptr } %t477, ptr %t476, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t478, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etaskDefault(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l9 = alloca ptr
  %l12 = alloca i1
  %l13 = alloca i1
  %l18 = alloca i1
  %l22 = alloca %"compiler/source:Span"
  %l25 = alloca ptr
  %l26 = alloca %"compiler/source:Span"
  %l27 = alloca %"compiler/diagmsg:Msg"
  %l28 = alloca i64
  %l29 = alloca ptr
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca i32
  %l38 = alloca %"compiler/source:Span"
  %l39 = alloca ptr
  %s2 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i32, ptr %l2, !tbaa !23
  %t8 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t1, ptr %t2, i32 %t4)
  store ptr %t8, ptr %l9
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l9, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l2, !tbaa !23
  %t14 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t10, i32 %t11)
  store i1 %t14, ptr %l12
  br label %bb2
bb2:
  %t15 = load i1, ptr %l12, !tbaa !21
  br i1 %t15, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb6
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t21, i32 %t22)
  store i1 %t25, ptr %l18
  br label %bb5
bb5:
  %t26 = load i1, ptr %l18, !tbaa !21
  store i1 %t26, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l13, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t33 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexistingIn(ptr %v0, ptr %v2, ptr %t28, ptr %t29)
  store %"compiler/source:Span" %t33, ptr %l22
  br label %bb9
bb8:
  br label %bb17
bb9:
  %t34 = load %"compiler/source:Span", ptr %l22
  store %"compiler/source:Span" %t34, ptr %l4
  %t35 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 0
  %t36 = load i32, ptr %t35, !tbaa !23
  %t38 = icmp sge i32 %t36, 0
  br i1 %t38, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l25, !tbaa !29
  %t41 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t41, ptr %l26
  %t42 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTaskDefaultExisting(ptr %s2)
  store %"compiler/diagmsg:Msg" %t42, ptr %l27
  br label %bb12
bb11:
  br label %bb16
bb12:
  %t43 = load ptr, ptr %l25, !tbaa !29
  %t44 = load %"compiler/source:Span", ptr %l26
  %t45 = load %"compiler/diagmsg:Msg", ptr %l27
  %t46 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t43, %"compiler/source:Span" %t44, %"compiler/diagmsg:Msg" %t45)
  store i64 %t46, ptr %l28
  br label %bb13
bb13:
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l29, !tbaa !29
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t48)
  store %"compiler/source:Span" %t50, ptr %l31
  br label %bb14
bb14:
  %t51 = load ptr, ptr %l29, !tbaa !29
  %t52 = load %"compiler/source:Span", ptr %l31
  %t53 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t51, %"compiler/source:Span" %t52)
  store ptr %t53, ptr %l32
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  %t54 = load ptr, ptr %l32, !tbaa !29
  store ptr %t54, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l33, !tbaa !29
  %t56 = load ptr, ptr %l3, !tbaa !29
  store ptr %t56, ptr %l34, !tbaa !29
  %t57 = load i32, ptr %l2, !tbaa !23
  store i32 %t57, ptr %l35, !tbaa !23
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t62 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %t58, ptr %t59)
  store %"compiler/source:Span" %t62, ptr %l38
  br label %bb18
bb18:
  %t63 = load ptr, ptr %l33, !tbaa !29
  %t64 = load ptr, ptr %l34, !tbaa !29
  %t65 = load i32, ptr %l35, !tbaa !23
  %t66 = load %"compiler/source:Span", ptr %l38
  %t67 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v2, ptr %v2, ptr %t63, ptr %t64, i32 %t65, %"compiler/source:Span" %t66)
  store ptr %t67, ptr %l39
  br label %bb19
bb19:
  %t68 = load ptr, ptr %l39, !tbaa !29
  store ptr %t68, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopSetAnywhere(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l8 = alloca ptr
  %l12 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 10
  %t13 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t9, i64 %a1)
  store ptr %t13, ptr %l8
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t16 = getelementptr %"compiler/load:Module", ptr %t14, i32 0, i32 8
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  %t21 = call i1 @compiler_2fcheck_2esetsName(ptr %v0, { i64, ptr } %t17, i32 %a2)
  store i1 %t21, ptr %l12
  br label %bb2
bb2:
  %t22 = load i1, ptr %l12, !tbaa !21
  store i1 %t22, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitHeader(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca i1
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i32
  %l27 = alloca %"compiler/generic:Unmet"
  %l30 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i1
  %l47 = alloca i1
  %l56 = alloca i64
  %l63 = alloca i32
  %l67 = alloca ptr
  %l68 = alloca ptr
  %l72 = alloca %"compiler/generic:Context"
  %l76 = alloca i32
  %l84 = alloca { i64, ptr }
  %l90 = alloca i1
  %l92 = alloca ptr
  %l94 = alloca %"compiler/source:Span"
  %l95 = alloca ptr
  %l97 = alloca %"compiler/source:Span"
  %l98 = alloca { i64, ptr }
  %l99 = alloca %"compiler/diagmsg:Msg"
  %l100 = alloca i64
  %l105 = alloca i1
  %l109 = alloca i1
  %l113 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca { i64, ptr }
  %l117 = alloca %"compiler/source:Span"
  %l121 = alloca { i64, ptr }
  %l123 = alloca %"compiler/diagmsg:Msg"
  %l124 = alloca i64
  %l127 = alloca i1
  %l139 = alloca { i64, ptr }
  %l145 = alloca i1
  %l148 = alloca i1
  %l151 = alloca i1
  %l154 = alloca i32
  %l156 = alloca ptr
  %l158 = alloca ptr
  %l163 = alloca i32
  %l167 = alloca i32
  %l172 = alloca [1 x i32]
  %l173 = alloca { i64, ptr }
  %l175 = alloca i1
  %l179 = alloca i1
  %l181 = alloca ptr
  %l183 = alloca %"compiler/source:Span"
  %l184 = alloca ptr
  %l186 = alloca %"compiler/source:Span"
  %l187 = alloca { i64, ptr }
  %l188 = alloca %"compiler/diagmsg:Msg"
  %l189 = alloca i64
  %l194 = alloca { i64, ptr }
  %l195 = alloca { i64, ptr }
  %l197 = alloca i64
  %l199 = alloca i64
  %l200 = alloca { i64, ptr }
  %l210 = alloca { i64, ptr }
  %l217 = alloca %"compiler/generic:Unmet"
  %l220 = alloca i1
  %l222 = alloca ptr
  %l224 = alloca %"compiler/source:Span"
  %l227 = alloca { i64, ptr }
  %l228 = alloca { i64, ptr }
  %l232 = alloca { i64, ptr }
  %l233 = alloca { i64, ptr }
  %l236 = alloca { i64, ptr }
  %l238 = alloca %"compiler/diagmsg:Msg"
  %l239 = alloca i64
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %t95 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/ast:TypeDecl", ptr %t5, i32 0, i32 3
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = icmp eq ptr %t8, null
  store i1 %t10, ptr %l30, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l30, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t15 = getelementptr %"compiler/ast:TypeDecl", ptr %t13, i32 0, i32 3
  %t16 = load ptr, ptr %t15, !tbaa !29
  store ptr %t16, ptr %l3, !tbaa !29
  %t18 = load ptr, ptr %l3, !tbaa !29
  store ptr %t18, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t19 = load ptr, ptr %l36, !tbaa !29
  %t20 = icmp ne ptr %t19, null
  br i1 %t20, label %bb7, label %bb8
bb7:
  %t22 = load ptr, ptr %l36, !tbaa !29
  %t23 = load i64, ptr %t22, !range !{i64 0, i64 5}
  %t25 = icmp eq i64 %t23, 2
  store i1 %t25, ptr %l37, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l37, !tbaa !21
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t29 = getelementptr { i64, [6 x i64] }, ptr %t27, i32 0, i32 1
  %t30 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t29, i32 0, i32 1
  %t31 = load { i64, ptr }, ptr %t30
  store { i64, ptr } %t31, ptr %l4, !tbaa !27
  %t33 = load ptr, ptr %l3, !tbaa !29
  %t35 = getelementptr { i64, [6 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t35, i32 0, i32 2
  %t37 = load { i64, ptr }, ptr %t36
  store { i64, ptr } %t37, ptr %l5, !tbaa !27
  br label %bb11
bb10:
  br label %bb123
bb11:
  %t39 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t43 = icmp eq i64 %t41, 0
  br i1 %t43, label %bb12, label %bb13
bb12:
  %t45 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t49 = icmp eq i64 %t47, 0
  store i1 %t49, ptr %l47, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb14
bb14:
  %t51 = load i1, ptr %l47, !tbaa !21
  br i1 %t51, label %bb15, label %bb16
bb15:
  br label %ret
bb16:
  br label %bb17
bb17:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t56 = load i64, ptr %l1, !tbaa !24
  %t57 = load ptr, ptr %l2, !tbaa !29
  %t59 = getelementptr %"compiler/ast:TypeDecl", ptr %t57, i32 0, i32 0
  %t60 = load i32, ptr %t59, !tbaa !23
  %t64 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %t55, i64 %t56, i32 %t60)
  store i64 %t64, ptr %l56
  br label %bb18
bb18:
  %t65 = load i64, ptr %l56, !tbaa !24
  store i64 %t65, ptr %l6, !tbaa !24
  %t66 = load i64, ptr %l6, !tbaa !24
  %t68 = icmp slt i64 %t66, 0
  br i1 %t68, label %bb19, label %bb20
bb19:
  br label %ret
bb20:
  br label %bb21
bb21:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/check:Checker", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t74 = load i64, ptr %l1, !tbaa !24
  %t75 = load i64, ptr %l6, !tbaa !24
  %t79 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t73, i64 %t74, i64 %t75)
  store i32 %t79, ptr %l63
  br label %bb22
bb22:
  %t80 = load i32, ptr %l63, !tbaa !23
  store i32 %t80, ptr %l7, !tbaa !23
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load i64, ptr %l1, !tbaa !24
  %t83 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t87 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t81, i64 -1, i64 %t82, i32 %t83, i32 0)
  store ptr %t87, ptr %l67
  br label %bb23
bb23:
  %t88 = load ptr, ptr %l67, !tbaa !29
  store ptr %t88, ptr %l68, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t90, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t94 = load i32, ptr %l7, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclContext(ptr %t95, ptr %v0, ptr %v0, ptr %t93, i32 %t94)
  call void @llvm.memmove.p0.p0.i64(ptr %l72, ptr %t95, i64 160, i1 false)
  br label %bb24
bb24:
  %t98 = load ptr, ptr %l68, !tbaa !29
  %t99 = getelementptr %"compiler/check:frame", ptr %t98, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %t99, ptr %l72, i64 160, i1 false)
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/check:Checker", ptr %t100, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t104 = load i32, ptr %l7, !tbaa !23
  %t107 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t103, i32 %t104)
  store i32 %t107, ptr %l76
  br label %bb25
bb25:
  %t108 = load i32, ptr %l76, !tbaa !23
  store i32 %t108, ptr %l9, !tbaa !23
  store i1 false, ptr %l10, !tbaa !21
  %t109 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t109, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t111 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t111, 0
  store i64 %t113, ptr %l13, !tbaa !24
  br label %bb26
bb26:
  %t115 = load i64, ptr %l12, !tbaa !24
  %t116 = load i64, ptr %l13, !tbaa !24
  %t119 = icmp slt i64 %t115, %t116
  %t121 = xor i1 %t119, true
  br i1 %t121, label %bb27, label %bb28
bb27:
  br label %bb40
bb28:
  br label %bb29
bb29:
  %t123 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t123, ptr %l84, !tbaa !27
  %t124 = load i64, ptr %l12, !tbaa !24
  %t126 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr ptr, ptr %t127, i64 %t124
  %t129 = load ptr, ptr %t128, !tbaa !39
  store ptr %t129, ptr %l14, !tbaa !29
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i64, ptr %l1, !tbaa !24
  %t133 = load ptr, ptr %l14, !tbaa !29
  %t137 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitRef(ptr %v0, ptr %v1, ptr %t131, i64 %t132, ptr %t133)
  store i1 %t137, ptr %l90
  br label %bb30
bb30:
  %t138 = load i1, ptr %l90, !tbaa !21
  %t139 = xor i1 %t138, true
  br i1 %t139, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s7
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l92, !tbaa !29
  %t142 = load ptr, ptr %l14, !tbaa !29
  %t144 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t142)
  store %"compiler/source:Span" %t144, ptr %l94
  br label %bb33
bb32:
  br label %bb38
bb33:
  %t145 = load ptr, ptr %l0, !tbaa !29
  store ptr %t145, ptr %l95, !tbaa !29
  %t146 = load ptr, ptr %l14, !tbaa !29
  %t148 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t146)
  store %"compiler/source:Span" %t148, ptr %l97
  br label %bb34
bb34:
  %t149 = load ptr, ptr %l95, !tbaa !29
  %t150 = load %"compiler/source:Span", ptr %l97
  %t151 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t149, %"compiler/source:Span" %t150)
  store { i64, ptr } %t151, ptr %l98
  br label %bb35
bb35:
  %t152 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t153 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTraitExtendsNotTrait(ptr %v0, ptr %s7, { i64, ptr } %t152)
  store %"compiler/diagmsg:Msg" %t153, ptr %l99
  br label %bb36
bb36:
  %t154 = load ptr, ptr %l92, !tbaa !29
  %t155 = load %"compiler/source:Span", ptr %l94
  %t156 = load %"compiler/diagmsg:Msg", ptr %l99
  %t157 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t154, %"compiler/source:Span" %t155, %"compiler/diagmsg:Msg" %t156)
  store i64 %t157, ptr %l100
  br label %bb37
bb37:
  store i1 true, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s7)
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t158 = load i64, ptr %l12, !tbaa !24
  %t160 = add i64 %t158, 1
  store i64 %t160, ptr %l12, !tbaa !24
  br label %bb26
bb40:
  %t162 = load i1, ptr %l10, !tbaa !21
  %t164 = xor i1 %t162, true
  br i1 %t164, label %bb41, label %bb42
bb41:
  %t166 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t166, 0
  %t170 = icmp sgt i64 %t168, 0
  store i1 %t170, ptr %l105, !tbaa !21
  br label %bb43
bb42:
  store i1 false, ptr %l105, !tbaa !21
  br label %bb43
bb43:
  %t172 = load i1, ptr %l105, !tbaa !21
  br i1 %t172, label %bb44, label %bb45
bb44:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i32, ptr %l7, !tbaa !23
  %t175 = load i32, ptr %l9, !tbaa !23
  %t179 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereachesTrait(ptr %v0, ptr %t173, i32 %t174, i32 %t175, i64 0)
  store i1 %t179, ptr %l113
  br label %bb46
bb45:
  store i1 false, ptr %l109, !tbaa !21
  br label %bb47
bb46:
  %t180 = load i1, ptr %l113, !tbaa !21
  store i1 %t180, ptr %l109, !tbaa !21
  br label %bb47
bb47:
  %t181 = load i1, ptr %l109, !tbaa !21
  br i1 %t181, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s9
  %t182 = load ptr, ptr %l0, !tbaa !29
  store ptr %t182, ptr %l114, !tbaa !29
  %t183 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t183, ptr %l115, !tbaa !27
  %t184 = getelementptr { i64, ptr }, ptr %l115, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = getelementptr ptr, ptr %t185, i64 0
  %t187 = load ptr, ptr %t186, !tbaa !39
  %t189 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t187)
  store %"compiler/source:Span" %t189, ptr %l117
  br label %bb50
bb49:
  br label %bb54
bb50:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load ptr, ptr %l2, !tbaa !29
  %t193 = getelementptr %"compiler/ast:TypeDecl", ptr %t191, i32 0, i32 0
  %t194 = load i32, ptr %t193, !tbaa !23
  %t197 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s9, ptr %t190, i32 %t194)
  store { i64, ptr } %t197, ptr %l121
  br label %bb51
bb51:
  %t198 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t198, 0
  %t200 = extractvalue { i64, ptr } %t198, 1
  %t201 = mul i64 %t199, 1
  %t202 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t201)
  call void @llvm.memcpy.p0.p0.i64(ptr %t202, ptr %t200, i64 %t201, i1 false)
  %t203 = insertvalue { i64, ptr } undef, i64 %t199, 0
  %t204 = insertvalue { i64, ptr } %t203, ptr %t202, 1
  %t206 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTraitExtendsItself(ptr %s9, ptr %s9, { i64, ptr } %t204)
  store %"compiler/diagmsg:Msg" %t206, ptr %l123
  br label %bb52
bb52:
  %t207 = load ptr, ptr %l114, !tbaa !29
  %t208 = load %"compiler/source:Span", ptr %l117
  %t209 = load %"compiler/diagmsg:Msg", ptr %l123
  %t210 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s9, ptr %t207, %"compiler/source:Span" %t208, %"compiler/diagmsg:Msg" %t209)
  store i64 %t210, ptr %l124
  br label %bb53
bb53:
  store i1 true, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s9)
  br label %bb54
bb54:
  %t211 = load i1, ptr %l10, !tbaa !21
  %t213 = xor i1 %t211, true
  br i1 %t213, label %bb55, label %bb56
bb55:
  %t215 = load ptr, ptr %l2, !tbaa !29
  %t217 = getelementptr %"compiler/ast:TypeDecl", ptr %t215, i32 0, i32 1
  %t218 = load { i64, ptr }, ptr %t217, !tbaa !27
  %t220 = extractvalue { i64, ptr } %t218, 0
  %t222 = icmp eq i64 %t220, 0
  store i1 %t222, ptr %l127, !tbaa !21
  br label %bb57
bb56:
  store i1 false, ptr %l127, !tbaa !21
  br label %bb57
bb57:
  %t224 = load i1, ptr %l127, !tbaa !21
  store i1 %t224, ptr %l15, !tbaa !21
  %t225 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t225, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t227 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t229 = extractvalue { i64, ptr } %t227, 0
  store i64 %t229, ptr %l18, !tbaa !24
  br label %bb58
bb58:
  store %olang.scope zeroinitializer, ptr %s11
  %t231 = load i64, ptr %l17, !tbaa !24
  %t232 = load i64, ptr %l18, !tbaa !24
  %t235 = icmp slt i64 %t231, %t232
  %t237 = xor i1 %t235, true
  br i1 %t237, label %bb59, label %bb60
bb59:
  call void @__olang_scope_close(ptr %s11)
  br label %bb121
bb60:
  br label %bb61
bb61:
  %t239 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t239, ptr %l139, !tbaa !27
  %t240 = load i64, ptr %l17, !tbaa !24
  %t242 = getelementptr { i64, ptr }, ptr %l139, i32 0, i32 1
  %t243 = load ptr, ptr %t242, !tbaa !27
  %t244 = getelementptr ptr, ptr %t243, i64 %t240
  %t245 = load ptr, ptr %t244, !tbaa !39
  store ptr %t245, ptr %l19, !tbaa !29
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load i64, ptr %l1, !tbaa !24
  %t249 = load ptr, ptr %l19, !tbaa !29
  %t253 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitRef(ptr %v0, ptr %v1, ptr %t247, i64 %t248, ptr %t249)
  store i1 %t253, ptr %l145
  br label %bb62
bb62:
  %t254 = load i1, ptr %l145, !tbaa !21
  store i1 %t254, ptr %l20, !tbaa !21
  %t255 = load i1, ptr %l20, !tbaa !21
  %t257 = xor i1 %t255, true
  br i1 %t257, label %bb63, label %bb64
bb63:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load ptr, ptr %l19, !tbaa !29
  %t263 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTypeWritten(ptr %v0, ptr %v1, ptr %t259, ptr %t260, i1 true)
  store i1 %t263, ptr %l151
  br label %bb65
bb64:
  store i1 false, ptr %l148, !tbaa !21
  br label %bb66
bb65:
  %t264 = load i1, ptr %l151, !tbaa !21
  %t265 = xor i1 %t264, true
  store i1 %t265, ptr %l148, !tbaa !21
  br label %bb66
bb66:
  %t267 = load i1, ptr %l148, !tbaa !21
  br i1 %t267, label %bb67, label %bb68
bb67:
  call void @__olang_scope_close(ptr %s11)
  br label %bb120
bb68:
  br label %bb69
bb69:
  %t268 = load i1, ptr %l20, !tbaa !21
  br i1 %t268, label %bb70, label %bb71
bb70:
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t272 = getelementptr %"compiler/check:Checker", ptr %t270, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !29
  store ptr %t273, ptr %l156, !tbaa !29
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t274)
  store ptr %t276, ptr %l158
  br label %bb72
bb71:
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t278 = load ptr, ptr %l19, !tbaa !29
  %t282 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %t277, ptr %t278)
  store i32 %t282, ptr %l167
  br label %bb74
bb72:
  %t283 = load ptr, ptr %l158, !tbaa !29
  %t285 = getelementptr %"compiler/check:frame", ptr %t283, i32 0, i32 4
  %t286 = load ptr, ptr %l19, !tbaa !29
  %t288 = load ptr, ptr %l156, !tbaa !29
  %t291 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v0, ptr %v1, ptr %t288, ptr %t285, ptr %t286)
  store i32 %t291, ptr %l163
  br label %bb73
bb73:
  %t292 = load i32, ptr %l163, !tbaa !23
  store i32 %t292, ptr %l154, !tbaa !23
  br label %bb75
bb74:
  %t293 = load i32, ptr %l167, !tbaa !23
  store i32 %t293, ptr %l154, !tbaa !23
  br label %bb75
bb75:
  %t294 = load i32, ptr %l154, !tbaa !23
  store i32 %t294, ptr %l21, !tbaa !23
  %t295 = load i32, ptr %l21, !tbaa !23
  %t296 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t299 = icmp eq i32 %t295, %t296
  br i1 %t299, label %bb76, label %bb77
bb76:
  call void @__olang_scope_close(ptr %s11)
  br label %bb120
bb77:
  br label %bb78
bb78:
  %t301 = load i32, ptr %l21, !tbaa !23
  %t303 = insertvalue [1 x i32] undef, i32 %t301, 0
  store [1 x i32] %t303, ptr %l172
  %t304 = mul i64 1, 4
  %t305 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t304)
  %t306 = insertvalue { i64, ptr } undef, i64 1, 0
  %t307 = insertvalue { i64, ptr } %t306, ptr %t305, 1
  store { i64, ptr } %t307, ptr %l173, !tbaa !27
  %t308 = getelementptr { i64, ptr }, ptr %l173, i32 0, i32 1
  %t309 = load ptr, ptr %t308, !tbaa !27
  %t310 = mul i64 1, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t309, ptr %l172, i64 %t310, i1 false)
  %t311 = load { i64, ptr }, ptr %l173, !tbaa !27
  store { i64, ptr } %t311, ptr %l22, !tbaa !27
  %t312 = load i1, ptr %l20, !tbaa !21
  br i1 %t312, label %bb79, label %bb80
bb79:
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t316 = getelementptr %"compiler/check:Checker", ptr %t314, i32 0, i32 1
  %t317 = load ptr, ptr %t316, !tbaa !29
  %t318 = load i32, ptr %l21, !tbaa !23
  %t321 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsClosedTrait(ptr %v0, ptr %t317, i32 %t318)
  store i1 %t321, ptr %l179
  br label %bb81
bb80:
  store i1 false, ptr %l175, !tbaa !21
  br label %bb82
bb81:
  %t322 = load i1, ptr %l179, !tbaa !21
  %t323 = xor i1 %t322, true
  store i1 %t323, ptr %l175, !tbaa !21
  br label %bb82
bb82:
  %t325 = load i1, ptr %l175, !tbaa !21
  br i1 %t325, label %bb83, label %bb84
bb83:
  store %olang.scope zeroinitializer, ptr %s14
  %t326 = load ptr, ptr %l0, !tbaa !29
  store ptr %t326, ptr %l181, !tbaa !29
  %t327 = load ptr, ptr %l19, !tbaa !29
  %t329 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t327)
  store %"compiler/source:Span" %t329, ptr %l183
  br label %bb85
bb84:
  br label %bb90
bb85:
  %t330 = load ptr, ptr %l0, !tbaa !29
  store ptr %t330, ptr %l184, !tbaa !29
  %t331 = load ptr, ptr %l19, !tbaa !29
  %t333 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t331)
  store %"compiler/source:Span" %t333, ptr %l186
  br label %bb86
bb86:
  %t334 = load ptr, ptr %l184, !tbaa !29
  %t335 = load %"compiler/source:Span", ptr %l186
  %t336 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t334, %"compiler/source:Span" %t335)
  store { i64, ptr } %t336, ptr %l187
  br label %bb87
bb87:
  %t337 = load { i64, ptr }, ptr %l187, !tbaa !27
  %t338 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTraitMemberOpen(ptr %v0, ptr %s14, { i64, ptr } %t337)
  store %"compiler/diagmsg:Msg" %t338, ptr %l188
  br label %bb88
bb88:
  %t339 = load ptr, ptr %l181, !tbaa !29
  %t340 = load %"compiler/source:Span", ptr %l183
  %t341 = load %"compiler/diagmsg:Msg", ptr %l188
  %t342 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s14, ptr %t339, %"compiler/source:Span" %t340, %"compiler/diagmsg:Msg" %t341)
  store i64 %t342, ptr %l189
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s11)
  br label %bb120
bb90:
  %t343 = load i1, ptr %l20, !tbaa !21
  br i1 %t343, label %bb91, label %bb92
bb91:
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t347 = getelementptr %"compiler/check:Checker", ptr %t345, i32 0, i32 1
  %t348 = load ptr, ptr %t347, !tbaa !29
  %t349 = load i32, ptr %l21, !tbaa !23
  %t352 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMembers(ptr %v0, ptr %v0, ptr %t348, i32 %t349)
  store { i64, ptr } %t352, ptr %l194
  br label %bb93
bb92:
  br label %bb97
bb93:
  %t353 = load { i64, ptr }, ptr %l194, !tbaa !27
  store { i64, ptr } %t353, ptr %l195, !tbaa !27
  %t354 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t355 = extractvalue { i64, ptr } %t354, 0
  %t356 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t357 = extractvalue { i64, ptr } %t356, 0
  store i64 %t357, ptr %l197, !tbaa !24
  %t359 = load i64, ptr %l197, !tbaa !24
  %t360 = icmp eq i64 %t355, %t359
  br i1 %t360, label %bb94, label %bb95
bb94:
  %t362 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t363 = load ptr, ptr %t362, !tbaa !27
  %t364 = getelementptr { i64, ptr }, ptr %l195, i32 0, i32 1
  %t365 = load ptr, ptr %t364, !tbaa !27
  %t366 = load i64, ptr %l197, !tbaa !24
  %t367 = mul i64 %t366, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t363, ptr %t365, i64 %t367, i1 false)
  br label %bb96
bb95:
  %t368 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t369 = extractvalue { i64, ptr } %t368, 0
  store i64 %t369, ptr %l199, !tbaa !24
  %t370 = load i64, ptr %l199, !tbaa !24
  %t371 = mul i64 %t370, 4
  %t372 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t371)
  %t373 = insertvalue { i64, ptr } undef, i64 %t370, 0
  %t374 = insertvalue { i64, ptr } %t373, ptr %t372, 1
  store { i64, ptr } %t374, ptr %l200, !tbaa !27
  %t375 = getelementptr { i64, ptr }, ptr %l200, i32 0, i32 1
  %t376 = load ptr, ptr %t375, !tbaa !27
  %t377 = getelementptr { i64, ptr }, ptr %l195, i32 0, i32 1
  %t378 = load ptr, ptr %t377, !tbaa !27
  %t379 = load i64, ptr %l199, !tbaa !24
  %t380 = mul i64 %t379, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t376, ptr %t378, i64 %t380, i1 false)
  %t381 = load { i64, ptr }, ptr %l200, !tbaa !27
  store { i64, ptr } %t381, ptr %l22, !tbaa !27
  br label %bb96
bb96:
  br label %bb97
bb97:
  %t382 = load i1, ptr %l15, !tbaa !21
  %t384 = xor i1 %t382, true
  br i1 %t384, label %bb98, label %bb99
bb98:
  call void @__olang_scope_close(ptr %s11)
  br label %bb120
bb99:
  br label %bb100
bb100:
  %t386 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t386, ptr %l23, !tbaa !27
  store i64 0, ptr %l24, !tbaa !24
  %t388 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t390 = extractvalue { i64, ptr } %t388, 0
  store i64 %t390, ptr %l25, !tbaa !24
  br label %bb101
bb101:
  %t392 = load i64, ptr %l24, !tbaa !24
  %t393 = load i64, ptr %l25, !tbaa !24
  %t396 = icmp slt i64 %t392, %t393
  %t398 = xor i1 %t396, true
  br i1 %t398, label %bb102, label %bb103
bb102:
  br label %bb119
bb103:
  br label %bb104
bb104:
  %t400 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t400, ptr %l210, !tbaa !27
  %t401 = load i64, ptr %l24, !tbaa !24
  %t403 = getelementptr { i64, ptr }, ptr %l210, i32 0, i32 1
  %t404 = load ptr, ptr %t403, !tbaa !27
  %t405 = getelementptr i32, ptr %t404, i64 %t401
  %t406 = load i32, ptr %t405, !tbaa !33
  store i32 %t406, ptr %l26, !tbaa !23
  %t408 = load ptr, ptr %l0, !tbaa !29
  %t410 = getelementptr %"compiler/check:Checker", ptr %t408, i32 0, i32 1
  %t411 = load ptr, ptr %t410, !tbaa !29
  %t412 = load i32, ptr %l26, !tbaa !23
  %t413 = load i32, ptr %l9, !tbaa !23
  %t417 = call %"compiler/generic:Unmet" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMissing(ptr %v0, ptr %t411, i32 %t412, i32 %t413, i1 false, i64 0)
  store %"compiler/generic:Unmet" %t417, ptr %l217
  br label %bb105
bb105:
  %t418 = load %"compiler/generic:Unmet", ptr %l217
  store %"compiler/generic:Unmet" %t418, ptr %l27
  %t419 = getelementptr %"compiler/generic:Unmet", ptr %l27, i32 0, i32 0
  %t420 = load i64, ptr %t419, !tbaa !24
  %t422 = icmp sge i64 %t420, 0
  br i1 %t422, label %bb106, label %bb107
bb106:
  %t424 = getelementptr %"compiler/generic:Unmet", ptr %l27, i32 0, i32 3
  %t425 = load i1, ptr %t424, !tbaa !21
  store i1 %t425, ptr %l220, !tbaa !21
  br label %bb108
bb107:
  store i1 false, ptr %l220, !tbaa !21
  br label %bb108
bb108:
  %t427 = load i1, ptr %l220, !tbaa !21
  br i1 %t427, label %bb109, label %bb110
bb109:
  store %olang.scope zeroinitializer, ptr %s19
  %t428 = load ptr, ptr %l0, !tbaa !29
  store ptr %t428, ptr %l222, !tbaa !29
  %t429 = load ptr, ptr %l19, !tbaa !29
  %t431 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t429)
  store %"compiler/source:Span" %t431, ptr %l224
  br label %bb111
bb110:
  br label %bb117
bb111:
  %t432 = load ptr, ptr %l0, !tbaa !29
  %t433 = load i32, ptr %l26, !tbaa !23
  %t436 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s19, ptr %t432, i32 %t433)
  store { i64, ptr } %t436, ptr %l227
  br label %bb112
bb112:
  %t437 = load { i64, ptr }, ptr %l227, !tbaa !27
  %t438 = extractvalue { i64, ptr } %t437, 0
  %t439 = extractvalue { i64, ptr } %t437, 1
  %t440 = mul i64 %t438, 1
  %t441 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t440)
  call void @llvm.memcpy.p0.p0.i64(ptr %t441, ptr %t439, i64 %t440, i1 false)
  %t442 = insertvalue { i64, ptr } undef, i64 %t438, 0
  %t443 = insertvalue { i64, ptr } %t442, ptr %t441, 1
  store { i64, ptr } %t443, ptr %l228, !tbaa !27
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t445 = load ptr, ptr %l2, !tbaa !29
  %t447 = getelementptr %"compiler/ast:TypeDecl", ptr %t445, i32 0, i32 0
  %t448 = load i32, ptr %t447, !tbaa !23
  %t451 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s19, ptr %t444, i32 %t448)
  store { i64, ptr } %t451, ptr %l232
  br label %bb113
bb113:
  %t452 = load { i64, ptr }, ptr %l232, !tbaa !27
  %t453 = extractvalue { i64, ptr } %t452, 0
  %t454 = extractvalue { i64, ptr } %t452, 1
  %t455 = mul i64 %t453, 1
  %t456 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t455)
  call void @llvm.memcpy.p0.p0.i64(ptr %t456, ptr %t454, i64 %t455, i1 false)
  %t457 = insertvalue { i64, ptr } undef, i64 %t453, 0
  %t458 = insertvalue { i64, ptr } %t457, ptr %t456, 1
  store { i64, ptr } %t458, ptr %l233, !tbaa !27
  %t459 = load ptr, ptr %l0, !tbaa !29
  %t460 = getelementptr %"compiler/generic:Unmet", ptr %l27, i32 0, i32 2
  %t461 = load i32, ptr %t460, !tbaa !23
  %t464 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s19, ptr %t459, i32 %t461)
  store { i64, ptr } %t464, ptr %l236
  br label %bb114
bb114:
  %t465 = load { i64, ptr }, ptr %l236, !tbaa !27
  %t466 = extractvalue { i64, ptr } %t465, 0
  %t467 = extractvalue { i64, ptr } %t465, 1
  %t468 = mul i64 %t466, 1
  %t469 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t468)
  call void @llvm.memcpy.p0.p0.i64(ptr %t469, ptr %t467, i64 %t468, i1 false)
  %t470 = insertvalue { i64, ptr } undef, i64 %t466, 0
  %t471 = insertvalue { i64, ptr } %t470, ptr %t469, 1
  %t472 = load { i64, ptr }, ptr %l228, !tbaa !27
  %t473 = load { i64, ptr }, ptr %l233, !tbaa !27
  %t475 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTraitMemberMissing(ptr %s19, ptr %s19, ptr %s19, ptr %s19, { i64, ptr } %t472, { i64, ptr } %t473, { i64, ptr } %t471)
  store %"compiler/diagmsg:Msg" %t475, ptr %l238
  br label %bb115
bb115:
  %t476 = load ptr, ptr %l222, !tbaa !29
  %t477 = load %"compiler/source:Span", ptr %l224
  %t478 = load %"compiler/diagmsg:Msg", ptr %l238
  %t479 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s19, ptr %t476, %"compiler/source:Span" %t477, %"compiler/diagmsg:Msg" %t478)
  store i64 %t479, ptr %l239
  br label %bb116
bb116:
  call void @__olang_scope_close(ptr %s19)
  br label %bb117
bb117:
  br label %bb118
bb118:
  %t480 = load i64, ptr %l24, !tbaa !24
  %t482 = add i64 %t480, 1
  store i64 %t482, ptr %l24, !tbaa !24
  br label %bb101
bb119:
  call void @__olang_scope_close(ptr %s11)
  br label %bb120
bb120:
  %t484 = load i64, ptr %l17, !tbaa !24
  %t486 = add i64 %t484, 1
  store i64 %t486, ptr %l17, !tbaa !24
  br label %bb58
bb121:
  %t488 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t488)
  br label %bb122
bb122:
  br label %bb128
bb123:
  br i1 true, label %bb124, label %bb125
bb124:
  br label %bb126
bb125:
  br label %bb127
bb126:
  br label %bb128
bb127:
  call void @__olang_check_failed(ptr @olang_loc_21d2c8212e1ec20a_d97fbaae9e5bc606)
  unreachable
bb128:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etwinCall(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"compiler/generic:Binding"
  %lp12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca %"compiler/check:litv"
  %l21 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i64
  %l32 = alloca i32
  %l37 = alloca i32
  %l43 = alloca ptr
  %l48 = alloca i32
  %l52 = alloca { i64, ptr }
  %l60 = alloca ptr
  %l63 = alloca { i64, ptr }
  %l67 = alloca i64
  %l71 = alloca i64
  %l74 = alloca ptr
  %l79 = alloca i32
  %l80 = alloca { i64, ptr }
  %l83 = alloca %"compiler/generic:Binding"
  %l84 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l90 = alloca i64
  %l93 = alloca i64
  %l112 = alloca { i64, ptr }
  %l116 = alloca %"compiler/check:litv"
  %l118 = alloca i1
  %l120 = alloca { i64, ptr }
  %l123 = alloca i1
  %l125 = alloca i1
  %l128 = alloca { i64, ptr }
  %l131 = alloca i1
  %l136 = alloca ptr
  %l137 = alloca { i64, ptr }
  %l139 = alloca i32
  %l141 = alloca i32
  %l145 = alloca i32
  %l147 = alloca i32
  %l149 = alloca { i64, ptr }
  %l152 = alloca ptr
  %l153 = alloca i1
  %l156 = alloca ptr
  %l157 = alloca i1
  %l161 = alloca { i64, ptr }
  %l166 = alloca ptr
  %l171 = alloca i1
  %l176 = alloca i1
  %l179 = alloca i32
  %l182 = alloca i1
  %l185 = alloca i32
  %l188 = alloca ptr
  %l189 = alloca { i64, ptr }
  %l191 = alloca i32
  %l194 = alloca i32
  %l212 = alloca i64
  %l215 = alloca i64
  %l233 = alloca { i64, ptr }
  %l238 = alloca ptr
  %l239 = alloca %"compiler/source:Span"
  %l242 = alloca { i64, ptr }
  %l244 = alloca %"compiler/diagmsg:Msg"
  %l245 = alloca i64
  %l248 = alloca ptr
  %l255 = alloca i32
  %l260 = alloca i32
  %l266 = alloca ptr
  %l270 = alloca i64
  %l277 = alloca ptr
  %l278 = alloca %"compiler/source:Span"
  %l279 = alloca %"compiler/source:Span"
  %l280 = alloca i32
  %l285 = alloca ptr
  %l286 = alloca { i64, ptr }
  %l288 = alloca { i64, ptr }
  %l289 = alloca ptr
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca ptr
  %t520 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l3, !tbaa !23
  %t8 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t4, i32 %t5)
  store i32 %t8, ptr %l37
  br label %bb1
bb1:
  %t9 = load i32, ptr %l37, !tbaa !23
  store i32 %t9, ptr %l5, !tbaa !23
  %t10 = load i32, ptr %l5, !tbaa !23
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t14 = icmp eq i32 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load %"compiler/source:Span", ptr %l1
  %t20 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t16, %"compiler/source:Span" %t17)
  store ptr %t20, ptr %l43
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t21 = load ptr, ptr %l43, !tbaa !29
  store ptr %t21, ptr %rv
  br label %ret
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l3, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l48
  br label %bb6
bb6:
  %t32 = load i32, ptr %l48, !tbaa !23
  store i32 %t32, ptr %l6, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l6, !tbaa !23
  %t35 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t39 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorNamed(ptr %v0, ptr %v1, ptr %v0, ptr %t33, i32 %t34, { i64, ptr } %t35)
  store { i64, ptr } %t39, ptr %l52
  br label %bb7
bb7:
  %t40 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t40, ptr %l4, !tbaa !27
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 143
  %t44 = load i1, ptr %t43, !tbaa !21
  br i1 %t44, label %bb8, label %bb9
bb8:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 143
  store i1 false, ptr %t48, !tbaa !21
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v0, ptr %t49, { i64, ptr } %t50)
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load %"compiler/source:Span", ptr %l1
  %t57 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t53, %"compiler/source:Span" %t54)
  store ptr %t57, ptr %l60
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t58 = load ptr, ptr %l60, !tbaa !29
  store ptr %t58, ptr %rv
  br label %ret
bb12:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 144
  %t63 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %s0, ptr %t61)
  store { i64, ptr } %t63, ptr %l63
  br label %bb13
bb13:
  %t64 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t64, ptr %l7, !tbaa !27
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 144
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t67)
  br label %bb14
bb14:
  %t69 = load i32, ptr %l6, !tbaa !23
  %t71 = call i64 @compiler_2fgeneric_2eCtorOwner(i32 %t69)
  store i64 %t71, ptr %l67
  br label %bb15
bb15:
  %t72 = load i64, ptr %l67, !tbaa !24
  store i64 %t72, ptr %l8, !tbaa !24
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t77 = load i32, ptr %l6, !tbaa !23
  %t80 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorVars(ptr %v0, ptr %t76, i32 %t77)
  store i64 %t80, ptr %l71
  br label %bb16
bb16:
  %t81 = load i64, ptr %l71, !tbaa !24
  store i64 %t81, ptr %l9, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/generic:Program", ptr %t85, i32 0, i32 2
  store ptr %t87, ptr %l74, !tbaa !29
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/check:Checker", ptr %t88, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = getelementptr %"compiler/generic:Program", ptr %t91, i32 0, i32 2
  %t94 = load i32, ptr %l5, !tbaa !23
  %t97 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t93, i32 %t94)
  store i32 %t97, ptr %l79
  br label %bb17
bb17:
  %t98 = load ptr, ptr %l74, !tbaa !29
  %t99 = load i32, ptr %l79, !tbaa !23
  %t100 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t98, i32 %t99)
  store { i64, ptr } %t100, ptr %l80
  br label %bb18
bb18:
  %t101 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t101, ptr %l10, !tbaa !27
  %t102 = load i64, ptr %l8, !tbaa !24
  %t103 = load i64, ptr %l9, !tbaa !24
  %t106 = call %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %s0, i64 %t102, i64 %t103)
  store %"compiler/generic:Binding" %t106, ptr %l83
  br label %bb19
bb19:
  %t107 = load %"compiler/generic:Binding", ptr %l83
  store %"compiler/generic:Binding" %t107, ptr %l11
  %t108 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t108, ptr %l84
  br label %bb20
bb20:
  %t109 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t109, ptr %lp12
  %t110 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l84
  %t111 = load ptr, ptr %lp12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t110, ptr %t111
  store i64 0, ptr %l13, !tbaa !24
  %t112 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t112, 0
  store i64 %t114, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t116 = load i64, ptr %l14, !tbaa !24
  %t117 = load i64, ptr %l13, !tbaa !24
  %t120 = icmp sgt i64 %t116, %t117
  br i1 %t120, label %bb21, label %bb22
bb21:
  %t122 = load i64, ptr %l15, !tbaa !24
  %t124 = icmp sgt i64 %t122, 0
  br i1 %t124, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb26
bb23:
  %t126 = load i64, ptr %l14, !tbaa !24
  %t127 = load i64, ptr %l13, !tbaa !24
  %t130 = sub i64 %t126, %t127
  %t131 = load i64, ptr %l15, !tbaa !24
  %t134 = add i64 %t130, %t131
  %t136 = sub i64 %t134, 1
  %t137 = load i64, ptr %l15, !tbaa !24
  %t140 = sdiv i64 %t136, %t137
  store i64 %t140, ptr %l93, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l93, !tbaa !24
  br label %bb25
bb25:
  %t142 = load i64, ptr %l93, !tbaa !24
  store i64 %t142, ptr %l90, !tbaa !24
  br label %bb26
bb26:
  %t143 = load i64, ptr %l90, !tbaa !24
  store i64 %t143, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb27
bb27:
  %t144 = load i64, ptr %l17, !tbaa !24
  %t145 = load i64, ptr %l16, !tbaa !24
  %t148 = icmp slt i64 %t144, %t145
  %t150 = xor i1 %t148, true
  br i1 %t150, label %bb28, label %bb29
bb28:
  br label %bb90
bb29:
  br label %bb30
bb30:
  %t152 = load i64, ptr %l13, !tbaa !24
  %t153 = load i64, ptr %l17, !tbaa !24
  %t154 = load i64, ptr %l15, !tbaa !24
  %t157 = mul i64 %t153, %t154
  %t160 = add i64 %t152, %t157
  store i64 %t160, ptr %l18, !tbaa !24
  store ptr null, ptr %l19, !tbaa !29
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t163, ptr %l112, !tbaa !27
  %t164 = load i64, ptr %l18, !tbaa !24
  %t166 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr ptr, ptr %t167, i64 %t164
  %t169 = load ptr, ptr %t168, !tbaa !39
  %t173 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v0, ptr %t162, ptr %t169)
  store %"compiler/check:litv" %t173, ptr %l116
  br label %bb31
bb31:
  %t174 = load %"compiler/check:litv", ptr %l116
  store %"compiler/check:litv" %t174, ptr %l20
  %t175 = getelementptr %"compiler/check:litv", ptr %l20, i32 0, i32 0
  %t176 = load i1, ptr %t175, !tbaa !21
  br i1 %t176, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l118, !tbaa !21
  br label %bb35
bb33:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t179, ptr %l120, !tbaa !27
  %t180 = load i64, ptr %l18, !tbaa !24
  %t182 = getelementptr { i64, ptr }, ptr %l120, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !27
  %t184 = getelementptr ptr, ptr %t183, i64 %t180
  %t185 = load ptr, ptr %t184, !tbaa !39
  %t188 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v0, ptr %t178, ptr %t185)
  store i1 %t188, ptr %l123
  br label %bb34
bb34:
  %t189 = load i1, ptr %l123, !tbaa !21
  store i1 %t189, ptr %l118, !tbaa !21
  br label %bb35
bb35:
  %t190 = load i1, ptr %l118, !tbaa !21
  br i1 %t190, label %bb36, label %bb37
bb36:
  %t191 = getelementptr %"compiler/check:litv", ptr %l20, i32 0, i32 0
  %t192 = load i1, ptr %t191, !tbaa !21
  br i1 %t192, label %bb38, label %bb39
bb37:
  %t194 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t194, ptr %l149, !tbaa !27
  %t195 = load i64, ptr %l18, !tbaa !24
  %t197 = getelementptr { i64, ptr }, ptr %l149, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !27
  %t199 = getelementptr ptr, ptr %t198, i64 %t195
  %t200 = load ptr, ptr %t199, !tbaa !39
  store ptr %t200, ptr %l22, !tbaa !29
  %t202 = load ptr, ptr %l22, !tbaa !29
  store ptr %t202, ptr %l152, !tbaa !29
  store i1 false, ptr %l153, !tbaa !21
  %t203 = load ptr, ptr %l152, !tbaa !29
  %t204 = icmp ne ptr %t203, null
  br i1 %t204, label %bb51, label %bb52
bb38:
  %t206 = getelementptr %"compiler/check:litv", ptr %l20, i32 0, i32 1
  %t207 = load i1, ptr %t206, !tbaa !21
  store i1 %t207, ptr %l125, !tbaa !21
  br label %bb41
bb39:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t210, ptr %l128, !tbaa !27
  %t211 = load i64, ptr %l18, !tbaa !24
  %t213 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !27
  %t215 = getelementptr ptr, ptr %t214, i64 %t211
  %t216 = load ptr, ptr %t215, !tbaa !39
  %t219 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFloat(ptr %v0, ptr %v0, ptr %t209, ptr %t216)
  store i1 %t219, ptr %l131
  br label %bb40
bb40:
  %t220 = load i1, ptr %l131, !tbaa !21
  store i1 %t220, ptr %l125, !tbaa !21
  br label %bb41
bb41:
  %t221 = load i1, ptr %l125, !tbaa !21
  store i1 %t221, ptr %l21, !tbaa !21
  %t222 = load i64, ptr %l18, !tbaa !24
  %t223 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t225 = extractvalue { i64, ptr } %t223, 0
  %t228 = icmp slt i64 %t222, %t225
  br i1 %t228, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s6
  %t230 = load ptr, ptr %l0, !tbaa !29
  store ptr %t230, ptr %l136, !tbaa !29
  %t231 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t231, ptr %l137, !tbaa !27
  %t232 = load i64, ptr %l18, !tbaa !24
  %t234 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = getelementptr i32, ptr %t235, i64 %t232
  %t237 = load i32, ptr %t236, !tbaa !33
  store i32 %t237, ptr %l139, !tbaa !23
  %t238 = load i1, ptr %l21, !tbaa !21
  br i1 %t238, label %bb44, label %bb45
bb43:
  br label %bb50
bb44:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = getelementptr %"compiler/check:Checker", ptr %t240, i32 0, i32 1
  %t243 = load ptr, ptr %t242, !tbaa !29
  %t245 = getelementptr %"compiler/generic:Program", ptr %t243, i32 0, i32 2
  %t247 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s6, ptr %t245, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d55, i32 0, i32 1) })
  store i32 %t247, ptr %l145
  br label %bb46
bb45:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t250 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t248)
  store i32 %t250, ptr %l147
  br label %bb47
bb46:
  %t251 = load i32, ptr %l145, !tbaa !23
  store i32 %t251, ptr %l141, !tbaa !23
  br label %bb48
bb47:
  %t252 = load i32, ptr %l147, !tbaa !23
  store i32 %t252, ptr %l141, !tbaa !23
  br label %bb48
bb48:
  %t253 = load ptr, ptr %l136, !tbaa !29
  %t254 = load i32, ptr %l139, !tbaa !23
  %t255 = load i32, ptr %l141, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %s0, ptr %t253, i32 %t254, i32 %t255, ptr %l11, i1 true, i1 false)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s6)
  br label %bb50
bb50:
  br label %bb67
bb51:
  %t257 = load ptr, ptr %l152, !tbaa !29
  %t258 = load i64, ptr %t257, !range !{i64 0, i64 30}
  %t260 = icmp eq i64 %t258, 22
  store i1 %t260, ptr %l153, !tbaa !21
  br label %bb52
bb52:
  %t261 = load i1, ptr %l153, !tbaa !21
  br i1 %t261, label %bb53, label %bb54
bb53:
  br label %bb59
bb54:
  %t262 = load ptr, ptr %l22, !tbaa !29
  store ptr %t262, ptr %l156, !tbaa !29
  store i1 false, ptr %l157, !tbaa !21
  %t263 = load ptr, ptr %l156, !tbaa !29
  %t264 = icmp ne ptr %t263, null
  br i1 %t264, label %bb55, label %bb56
bb55:
  %t266 = load ptr, ptr %l156, !tbaa !29
  %t267 = load i64, ptr %t266, !range !{i64 0, i64 30}
  %t269 = icmp eq i64 %t267, 25
  store i1 %t269, ptr %l157, !tbaa !21
  br label %bb56
bb56:
  %t270 = load i1, ptr %l157, !tbaa !21
  br i1 %t270, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb66
bb60:
  br i1 true, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb65
bb63:
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t272 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t272, ptr %l161, !tbaa !27
  %t273 = load i64, ptr %l18, !tbaa !24
  %t275 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t276 = load ptr, ptr %t275, !tbaa !27
  %t277 = getelementptr ptr, ptr %t276, i64 %t273
  %t278 = load ptr, ptr %t277, !tbaa !39
  %t280 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t284 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v0, ptr %v2, ptr %t271, ptr %t278, i32 %t280)
  store ptr %t284, ptr %l166
  br label %bb64
bb64:
  %t285 = load ptr, ptr %l166, !tbaa !29
  store ptr %t285, ptr %l19, !tbaa !29
  br label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_86f2d648d7a819c5_fc1d6e84e063e4d9)
  unreachable
bb66:
  br label %bb67
bb67:
  %t287 = load ptr, ptr %l19, !tbaa !29
  %t289 = icmp eq ptr %t287, null
  %t291 = xor i1 %t289, true
  br i1 %t291, label %bb68, label %bb69
bb68:
  %t293 = load i64, ptr %l18, !tbaa !24
  %t294 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t296 = extractvalue { i64, ptr } %t294, 0
  %t299 = icmp slt i64 %t293, %t296
  store i1 %t299, ptr %l171, !tbaa !21
  br label %bb70
bb69:
  store i1 false, ptr %l171, !tbaa !21
  br label %bb70
bb70:
  %t301 = load i1, ptr %l171, !tbaa !21
  br i1 %t301, label %bb71, label %bb72
bb71:
  %t302 = load ptr, ptr %l19, !tbaa !29
  %t305 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t302)
  store i32 %t305, ptr %l179
  br label %bb73
bb72:
  store i1 false, ptr %l176, !tbaa !21
  br label %bb74
bb73:
  %t306 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t307 = load i32, ptr %l179, !tbaa !23
  %t309 = icmp ne i32 %t307, %t306
  store i1 %t309, ptr %l176, !tbaa !21
  br label %bb74
bb74:
  %t311 = load i1, ptr %l176, !tbaa !21
  br i1 %t311, label %bb75, label %bb76
bb75:
  %t312 = load ptr, ptr %l19, !tbaa !29
  %t315 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t312)
  store i32 %t315, ptr %l185
  br label %bb77
bb76:
  store i1 false, ptr %l182, !tbaa !21
  br label %bb78
bb77:
  %t316 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t317 = load i32, ptr %l185, !tbaa !23
  %t319 = icmp ne i32 %t317, %t316
  store i1 %t319, ptr %l182, !tbaa !21
  br label %bb78
bb78:
  %t321 = load i1, ptr %l182, !tbaa !21
  br i1 %t321, label %bb79, label %bb80
bb79:
  %t322 = load ptr, ptr %l0, !tbaa !29
  store ptr %t322, ptr %l188, !tbaa !29
  %t323 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t323, ptr %l189, !tbaa !27
  %t324 = load i64, ptr %l18, !tbaa !24
  %t326 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t327 = load ptr, ptr %t326, !tbaa !27
  %t328 = getelementptr i32, ptr %t327, i64 %t324
  %t329 = load i32, ptr %t328, !tbaa !33
  store i32 %t329, ptr %l191, !tbaa !23
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t331 = load ptr, ptr %l19, !tbaa !29
  %t334 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindType(ptr %v0, ptr %v2, ptr %t330, ptr %t331)
  store i32 %t334, ptr %l194
  br label %bb81
bb80:
  br label %bb83
bb81:
  %t335 = load ptr, ptr %l188, !tbaa !29
  %t336 = load i32, ptr %l191, !tbaa !23
  %t337 = load i32, ptr %l194, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %s0, ptr %t335, i32 %t336, i32 %t337, ptr %l11, i1 false, i1 false)
  br label %bb82
bb82:
  br label %bb83
bb83:
  %t339 = load ptr, ptr %l19, !tbaa !29
  %t341 = icmp eq ptr %t339, null
  br i1 %t341, label %bb84, label %bb85
bb84:
  %t343 = load ptr, ptr %lp12
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t346 = getelementptr %"compiler/check:Checker", ptr %t344, i32 0, i32 0
  %t347 = load ptr, ptr %t346, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v2, ptr %v0, ptr %t343, ptr %t347)
  br label %bb86
bb85:
  %t350 = load ptr, ptr %lp12
  %t351 = load ptr, ptr %l19, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v2, ptr %v2, ptr %t350, ptr %t351)
  br label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb88
bb88:
  br label %bb89
bb89:
  %t354 = load i64, ptr %l17, !tbaa !24
  %t356 = add i64 %t354, 1
  store i64 %t356, ptr %l17, !tbaa !24
  br label %bb27
bb90:
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t360 = getelementptr %"compiler/check:Checker", ptr %t358, i32 0, i32 1
  %t361 = load ptr, ptr %t360, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInferThroughBounds(ptr %v0, ptr %s0, ptr %t361, ptr %l11)
  br label %bb91
bb91:
  store i64 0, ptr %l23, !tbaa !24
  %t364 = load i64, ptr %l9, !tbaa !24
  store i64 %t364, ptr %l24, !tbaa !24
  store i64 1, ptr %l25, !tbaa !24
  %t366 = load i64, ptr %l24, !tbaa !24
  %t367 = load i64, ptr %l23, !tbaa !24
  %t370 = icmp sgt i64 %t366, %t367
  br i1 %t370, label %bb92, label %bb93
bb92:
  %t372 = load i64, ptr %l25, !tbaa !24
  %t374 = icmp sgt i64 %t372, 0
  br i1 %t374, label %bb94, label %bb95
bb93:
  store i64 0, ptr %l212, !tbaa !24
  br label %bb97
bb94:
  %t376 = load i64, ptr %l24, !tbaa !24
  %t377 = load i64, ptr %l23, !tbaa !24
  %t380 = sub i64 %t376, %t377
  %t381 = load i64, ptr %l25, !tbaa !24
  %t384 = add i64 %t380, %t381
  %t386 = sub i64 %t384, 1
  %t387 = load i64, ptr %l25, !tbaa !24
  %t390 = sdiv i64 %t386, %t387
  store i64 %t390, ptr %l215, !tbaa !24
  br label %bb96
bb95:
  store i64 0, ptr %l215, !tbaa !24
  br label %bb96
bb96:
  %t392 = load i64, ptr %l215, !tbaa !24
  store i64 %t392, ptr %l212, !tbaa !24
  br label %bb97
bb97:
  %t393 = load i64, ptr %l212, !tbaa !24
  store i64 %t393, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb98
bb98:
  %t394 = load i64, ptr %l27, !tbaa !24
  %t395 = load i64, ptr %l26, !tbaa !24
  %t398 = icmp slt i64 %t394, %t395
  %t400 = xor i1 %t398, true
  br i1 %t400, label %bb99, label %bb100
bb99:
  br label %bb110
bb100:
  br label %bb101
bb101:
  %t402 = load i64, ptr %l23, !tbaa !24
  %t403 = load i64, ptr %l27, !tbaa !24
  %t404 = load i64, ptr %l25, !tbaa !24
  %t407 = mul i64 %t403, %t404
  %t410 = add i64 %t402, %t407
  %t412 = getelementptr %"compiler/generic:Binding", ptr %l11, i32 0, i32 2
  %t413 = load { i64, ptr }, ptr %t412, !tbaa !27
  store { i64, ptr } %t413, ptr %l233, !tbaa !27
  %t416 = getelementptr { i64, ptr }, ptr %l233, i32 0, i32 1
  %t417 = load ptr, ptr %t416, !tbaa !27
  %t418 = getelementptr i32, ptr %t417, i64 %t410
  %t419 = load i32, ptr %t418, !tbaa !33
  %t420 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t423 = icmp eq i32 %t419, %t420
  br i1 %t423, label %bb102, label %bb103
bb102:
  store %olang.scope zeroinitializer, ptr %s16
  %t425 = load ptr, ptr %l0, !tbaa !29
  store ptr %t425, ptr %l238, !tbaa !29
  %t426 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t426, ptr %l239
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t428 = load i32, ptr %l3, !tbaa !23
  %t431 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s16, ptr %t427, i32 %t428)
  store { i64, ptr } %t431, ptr %l242
  br label %bb104
bb103:
  br label %bb108
bb104:
  %t432 = load { i64, ptr }, ptr %l242, !tbaa !27
  %t433 = extractvalue { i64, ptr } %t432, 0
  %t434 = extractvalue { i64, ptr } %t432, 1
  %t435 = mul i64 %t433, 1
  %t436 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t435)
  call void @llvm.memcpy.p0.p0.i64(ptr %t436, ptr %t434, i64 %t435, i1 false)
  %t437 = insertvalue { i64, ptr } undef, i64 %t433, 0
  %t438 = insertvalue { i64, ptr } %t437, ptr %t436, 1
  %t440 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCtorVarsNotInferable(ptr %s16, ptr %s16, { i64, ptr } %t438)
  store %"compiler/diagmsg:Msg" %t440, ptr %l244
  br label %bb105
bb105:
  %t441 = load ptr, ptr %l238, !tbaa !29
  %t442 = load %"compiler/source:Span", ptr %l239
  %t443 = load %"compiler/diagmsg:Msg", ptr %l244
  %t444 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s16, ptr %t441, %"compiler/source:Span" %t442, %"compiler/diagmsg:Msg" %t443)
  store i64 %t444, ptr %l245
  br label %bb106
bb106:
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t446 = load %"compiler/source:Span", ptr %l1
  %t449 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t445, %"compiler/source:Span" %t446)
  store ptr %t449, ptr %l248
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  %t450 = load ptr, ptr %l248, !tbaa !29
  store ptr %t450, ptr %rv
  br label %ret
bb108:
  br label %bb109
bb109:
  %t451 = load i64, ptr %l27, !tbaa !24
  %t453 = add i64 %t451, 1
  store i64 %t453, ptr %l27, !tbaa !24
  br label %bb98
bb110:
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t457 = getelementptr %"compiler/check:Checker", ptr %t455, i32 0, i32 1
  %t458 = load ptr, ptr %t457, !tbaa !29
  %t460 = getelementptr %"compiler/generic:Program", ptr %t458, i32 0, i32 2
  %t461 = getelementptr %"compiler/generic:Binding", ptr %l11, i32 0, i32 2
  %t462 = load { i64, ptr }, ptr %t461, !tbaa !27
  %t465 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t460, { i64, ptr } %t462)
  store i32 %t465, ptr %l255
  br label %bb111
bb111:
  %t466 = load i32, ptr %l255, !tbaa !23
  store i32 %t466, ptr %l29, !tbaa !23
  %t467 = load ptr, ptr %l0, !tbaa !29
  %t469 = getelementptr %"compiler/check:Checker", ptr %t467, i32 0, i32 1
  %t470 = load ptr, ptr %t469, !tbaa !29
  %t471 = load i32, ptr %l3, !tbaa !23
  %t472 = load i32, ptr %l29, !tbaa !23
  %t476 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSigAt(ptr %v0, ptr %t470, i32 %t471, i32 %t472)
  store i32 %t476, ptr %l260
  br label %bb112
bb112:
  %t477 = load i32, ptr %l260, !tbaa !23
  store i32 %t477, ptr %l30, !tbaa !23
  %t478 = load i32, ptr %l30, !tbaa !23
  %t479 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t482 = icmp eq i32 %t478, %t479
  br i1 %t482, label %bb113, label %bb114
bb113:
  %t484 = load ptr, ptr %l0, !tbaa !29
  %t485 = load %"compiler/source:Span", ptr %l1
  %t488 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t484, %"compiler/source:Span" %t485)
  store ptr %t488, ptr %l266
  br label %bb115
bb114:
  br label %bb116
bb115:
  call void @__olang_scope_close(ptr %s0)
  %t489 = load ptr, ptr %l266, !tbaa !29
  store ptr %t489, ptr %rv
  br label %ret
bb116:
  %t490 = load ptr, ptr %l0, !tbaa !29
  %t491 = load i32, ptr %l3, !tbaa !23
  %t492 = load i32, ptr %l29, !tbaa !23
  %t496 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etwinBody(ptr %v0, ptr %t490, i32 %t491, i32 %t492)
  store i64 %t496, ptr %l270
  br label %bb117
bb117:
  %t497 = load i64, ptr %l270, !tbaa !24
  store i64 %t497, ptr %l31, !tbaa !24
  %t498 = load ptr, ptr %l0, !tbaa !29
  %t500 = getelementptr %"compiler/check:Checker", ptr %t498, i32 0, i32 23
  %t501 = load i32, ptr %t500, !tbaa !23
  store i32 %t501, ptr %l32, !tbaa !23
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t504 = load i32, ptr %l3, !tbaa !23
  %t507 = getelementptr %"compiler/check:Checker", ptr %t503, i32 0, i32 23
  store i32 %t504, ptr %t507, !tbaa !23
  %t508 = load ptr, ptr %l0, !tbaa !29
  %t509 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetOrder(ptr %v0, ptr %s0, ptr %t508, { i64, ptr } %t509)
  br label %bb118
bb118:
  %t512 = load ptr, ptr %l0, !tbaa !29
  store ptr %t512, ptr %l277, !tbaa !29
  %t513 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t513, ptr %l278
  %t514 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t514, ptr %l279
  %t515 = load i32, ptr %l30, !tbaa !23
  store i32 %t515, ptr %l280, !tbaa !23
  %t516 = load i64, ptr %l31, !tbaa !24
  %t518 = trunc i64 %t516 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t520
  %t521 = getelementptr { i64, [3 x i64] }, ptr %t520, i32 0, i32 0
  store i64 0, ptr %t521
  %t523 = insertvalue { i32 } undef, i32 %t518, 0
  %t524 = getelementptr { i64, [3 x i64] }, ptr %t520, i32 0, i32 1
  store { i32 } %t523, ptr %t524
  %t525 = load { i64, [3 x i64] }, ptr %t520
  %t527 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store { i64, [3 x i64] } %t525, ptr %t527
  store ptr %t527, ptr %l285, !tbaa !29
  %t528 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t528, ptr %l286, !tbaa !27
  %t529 = load ptr, ptr %lp12
  %t531 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eToArra_H50cbff9caa8a2389caf3e92da7e24507(ptr %v2, ptr %v2, ptr %t529)
  store { i64, ptr } %t531, ptr %l288
  br label %bb119
bb119:
  %t532 = load ptr, ptr %l277, !tbaa !29
  %t533 = load %"compiler/source:Span", ptr %l278
  %t534 = load %"compiler/source:Span", ptr %l279
  %t535 = load i32, ptr %l280, !tbaa !23
  %t536 = load ptr, ptr %l285, !tbaa !29
  %t537 = load { i64, ptr }, ptr %l286, !tbaa !27
  %t538 = load { i64, ptr }, ptr %l288, !tbaa !27
  %t539 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v2, ptr %v0, ptr %v0, ptr %v2, ptr %v2, ptr %t532, %"compiler/source:Span" %t533, %"compiler/source:Span" %t534, i32 %t535, ptr %t536, i64 -1, ptr null, { i64, ptr } %t537, { i64, ptr } %t538)
  store ptr %t539, ptr %l289
  br label %bb120
bb120:
  %t540 = load ptr, ptr %l289, !tbaa !29
  %t541 = load ptr, ptr %l0, !tbaa !29
  %t542 = load i32, ptr %l32, !tbaa !23
  %t545 = getelementptr %"compiler/check:Checker", ptr %t541, i32 0, i32 23
  store i32 %t542, ptr %t545, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store ptr %t540, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeCase(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, %"compiler/source:Span" %a4, ptr %a5, i32 %a6, ptr %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l8 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l19 = alloca ptr
  %l24 = alloca i32
  %l31 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca %"compiler/source:Span"
  %l38 = alloca i32
  %l39 = alloca i32
  %l40 = alloca ptr
  %l44 = alloca ptr
  %l46 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l50 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca %"compiler/source:Span"
  %l57 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca ptr
  %l62 = alloca i32
  %l63 = alloca %"compiler/source:Span"
  %l66 = alloca i32
  %l69 = alloca i64
  %l73 = alloca ptr
  %l78 = alloca %"compiler/typed:Bind"
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t101 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a3, ptr %l3
  store ptr %a5, ptr %l5
  store i32 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l6, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  %t9 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t13 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v4, ptr %t7, %"compiler/source:Span" %t8, i32 %t9, i64 0)
  store ptr %t13, ptr %l19
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t14 = load ptr, ptr %l19, !tbaa !29
  store ptr %t14, ptr %rv
  br label %ret
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load %"compiler/source:Span", ptr %l1
  %t17 = load i32, ptr %l6, !tbaa !23
  %t23 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCaseType(ptr %v0, ptr %v1, ptr %t15, %"compiler/source:Span" %t16, i32 %t17, ptr %a2)
  store i32 %t23, ptr %l24
  br label %bb5
bb5:
  %t24 = load i32, ptr %l24, !tbaa !23
  store i32 %t24, ptr %l8, !tbaa !23
  %t25 = load i32, ptr %l8, !tbaa !23
  %t26 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t29 = icmp eq i32 %t25, %t26
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load %"compiler/source:Span", ptr %l1
  %t33 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t37 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v4, ptr %t31, %"compiler/source:Span" %t32, i32 %t33, i64 0)
  store ptr %t37, ptr %l31
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t38 = load ptr, ptr %l31, !tbaa !29
  store ptr %t38, ptr %rv
  br label %ret
bb9:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load %"compiler/source:Span", ptr %l1
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t45 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v2, ptr %v4, ptr %t39, %"compiler/source:Span" %t40, ptr %t41)
  store ptr %t45, ptr %l35
  br label %bb10
bb10:
  %t46 = load ptr, ptr %l35, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l36, !tbaa !29
  %t48 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t48, ptr %l37
  %t49 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t49, ptr %l38, !tbaa !23
  store i32 45, ptr %l39
  store ptr %t46, ptr %l40, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load %"compiler/source:Span", ptr %l1
  %t53 = load i32, ptr %l8, !tbaa !23
  %t57 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t51, %"compiler/source:Span" %t52, i32 %t53, i64 0)
  store ptr %t57, ptr %l44
  br label %bb11
bb11:
  %t58 = load ptr, ptr %l44, !tbaa !29
  %t59 = load ptr, ptr %l36, !tbaa !29
  %t60 = load %"compiler/source:Span", ptr %l37
  %t61 = load i32, ptr %l38, !tbaa !23
  %t62 = load i32, ptr %l39, !range !{i32 0, i32 49}
  %t63 = load ptr, ptr %l40, !tbaa !29
  %t65 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v4, ptr %v0, ptr %v4, ptr %t59, %"compiler/source:Span" %t60, i32 %t61, i32 %t62, ptr %t63, ptr %t58)
  store ptr %t65, ptr %l46
  br label %bb12
bb12:
  %t66 = load ptr, ptr %l46, !tbaa !29
  store ptr %t66, ptr %l10, !tbaa !29
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i32, ptr %l3, !tbaa !23
  %t71 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t67, i32 %t68)
  store { i64, ptr } %t71, ptr %l49
  br label %bb13
bb13:
  %t72 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t73 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t72, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) })
  store i1 %t73, ptr %l50
  br label %bb14
bb14:
  %t74 = load i1, ptr %l50, !tbaa !21
  %t75 = xor i1 %t74, true
  br i1 %t75, label %bb15, label %bb16
bb15:
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l52, !tbaa !29
  %t78 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t78, ptr %l53
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load %"compiler/source:Span", ptr %l1
  %t81 = load ptr, ptr %l5, !tbaa !29
  %t85 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v2, ptr %v2, ptr %t79, %"compiler/source:Span" %t80, ptr %t81)
  store ptr %t85, ptr %l57
  br label %bb17
bb16:
  br label %bb24
bb17:
  %t86 = load i32, ptr %l8, !tbaa !23
  %t87 = load ptr, ptr %l52, !tbaa !29
  %t88 = load %"compiler/source:Span", ptr %l53
  %t89 = load ptr, ptr %l57, !tbaa !29
  %t92 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyInstance(ptr %v0, ptr %v2, ptr %v0, ptr %t87, %"compiler/source:Span" %t88, ptr %t89, i32 %t86, i32 0)
  store ptr %t92, ptr %l60
  br label %bb18
bb18:
  %t93 = load ptr, ptr %l60, !tbaa !29
  store ptr %t93, ptr %l11, !tbaa !29
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l61, !tbaa !29
  %t95 = load i32, ptr %l3, !tbaa !23
  store i32 %t95, ptr %l62, !tbaa !23
  store %"compiler/source:Span" %a4, ptr %l63
  %t97 = load ptr, ptr %l11, !tbaa !29
  %t100 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t97)
  store i32 %t100, ptr %l66
  br label %bb19
bb19:
  store { i64, [1 x i64] } zeroinitializer, ptr %t101
  %t102 = getelementptr { i64, [1 x i64] }, ptr %t101, i32 0, i32 0
  store i64 4, ptr %t102
  %t103 = load { i64, [1 x i64] }, ptr %t101
  %t104 = load ptr, ptr %l61, !tbaa !29
  %t105 = load i32, ptr %l62, !tbaa !23
  %t106 = load %"compiler/source:Span", ptr %l63
  %t107 = load i32, ptr %l66, !tbaa !23
  %t110 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t104, i32 %t105, %"compiler/source:Span" %t106, i32 %t107, i32 4, { i64, [1 x i64] } %t103)
  store i64 %t110, ptr %l69
  br label %bb20
bb20:
  %t111 = load i64, ptr %l69, !tbaa !24
  store i64 %t111, ptr %l12, !tbaa !24
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load i64, ptr %l12, !tbaa !24
  %t114 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v0, ptr %t112, i64 %t113, ptr %t114)
  br label %bb21
bb21:
  store ptr %a7, ptr %l73, !tbaa !29
  %t119 = load i64, ptr %l12, !tbaa !24
  %t121 = trunc i64 %t119 to i32
  %t123 = load ptr, ptr %l11, !tbaa !29
  %t126 = call %"compiler/typed:Bind" @compiler_2ftyped_3aBind_2ector(ptr %v0, ptr %v3, i32 %t121, ptr %t123)
  store %"compiler/typed:Bind" %t126, ptr %l78
  br label %bb22
bb22:
  %t127 = load %"compiler/typed:Bind", ptr %l78
  %t128 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 16, i64 8)
  store %"compiler/typed:Bind" %t127, ptr %t128
  %t129 = load ptr, ptr %l73, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBind_26_3e_2ePush_3ccompiler_2ftyped_3aBind_26_3e(ptr %v3, ptr %v3, ptr %t129, ptr %t128)
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t131 = load ptr, ptr %l10, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t131, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeCaseCovers(ptr %v0, ptr %a0, %"compiler/check:typeCase" %a1, %"compiler/check:typeCase" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/check:typeCase"
  %l2 = alloca %"compiler/check:typeCase"
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l17 = alloca i1
  %l20 = alloca i1
  %l26 = alloca i1
  %l29 = alloca i1
  %l32 = alloca i1
  %l37 = alloca i1
  %l50 = alloca i1
  %l54 = alloca i1
  %l55 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca i32
  %l62 = alloca ptr
  %l67 = alloca i32
  %l72 = alloca i64
  %l76 = alloca i32
  %l77 = alloca i1
  %l82 = alloca i32
  %l86 = alloca i1
  %l91 = alloca i32
  %l100 = alloca i32
  %l105 = alloca i32
  %l110 = alloca ptr
  %l115 = alloca i32
  %l116 = alloca { i64, ptr }
  %l117 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l125 = alloca { i64, ptr }
  %l132 = alloca i32
  %l136 = alloca i1
  %l141 = alloca i64
  %l144 = alloca i1
  %l145 = alloca ptr
  %l150 = alloca i64
  %l151 = alloca i1
  %l153 = alloca ptr
  %l158 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/check:typeCase" %a1, ptr %l1
  store %"compiler/check:typeCase" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 0
  %t2 = load i1, ptr %t1, !tbaa !21
  br i1 %t2, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 0
  %t6 = load i1, ptr %t5, !tbaa !21
  br i1 %t6, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t9 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 1
  %t10 = load i1, ptr %t9, !tbaa !21
  br i1 %t10, label %bb7, label %bb8
bb7:
  %t12 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 1
  %t13 = load i1, ptr %t12, !tbaa !21
  br i1 %t13, label %bb9, label %bb10
bb8:
  br label %bb26
bb9:
  %t15 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 3
  %t16 = load i64, ptr %t15, !tbaa !24
  %t18 = icmp eq i64 %t16, 0
  br i1 %t18, label %bb11, label %bb12
bb10:
  br label %bb18
bb11:
  %t20 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 3
  %t21 = load i64, ptr %t20, !tbaa !24
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l17, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb13
bb13:
  %t25 = load i1, ptr %l17, !tbaa !21
  br i1 %t25, label %bb14, label %bb15
bb14:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 2
  %t32 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t33 = load i32, ptr %t32, !tbaa !23
  %t34 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 2
  %t35 = load i32, ptr %t34, !tbaa !23
  %t39 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t31, i32 %t33, i32 %t35)
  store i1 %t39, ptr %l26
  br label %bb16
bb15:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb17
bb16:
  %t40 = load i1, ptr %l26, !tbaa !21
  store i1 %t40, ptr %l20, !tbaa !21
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t41 = load i1, ptr %l20, !tbaa !21
  store i1 %t41, ptr %rv
  br label %ret
bb18:
  %t42 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 3
  %t43 = load i64, ptr %t42, !tbaa !24
  %t45 = icmp eq i64 %t43, 0
  br i1 %t45, label %bb19, label %bb20
bb19:
  %t47 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 3
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = icmp eq i64 %t48, 0
  store i1 %t50, ptr %l29, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb21
bb21:
  %t52 = load i1, ptr %l29, !tbaa !21
  br i1 %t52, label %bb22, label %bb23
bb22:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t57 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 2
  %t58 = load i32, ptr %t57, !tbaa !23
  %t59 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t60 = load i32, ptr %t59, !tbaa !23
  %t64 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSatisfies(ptr %v0, ptr %t56, i32 %t58, i32 %t60)
  store i1 %t64, ptr %l37
  br label %bb24
bb23:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb25
bb24:
  %t65 = load i1, ptr %l37, !tbaa !21
  store i1 %t65, ptr %l32, !tbaa !21
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t66 = load i1, ptr %l32, !tbaa !21
  store i1 %t66, ptr %rv
  br label %ret
bb26:
  %t67 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 1
  %t68 = load i1, ptr %t67, !tbaa !21
  br i1 %t68, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t71 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 3
  %t72 = load i64, ptr %t71, !tbaa !24
  %t74 = icmp eq i64 %t72, 0
  br i1 %t74, label %bb30, label %bb31
bb30:
  %t76 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 3
  %t77 = load i64, ptr %t76, !tbaa !24
  %t79 = icmp ne i64 %t77, 0
  br i1 %t79, label %bb32, label %bb33
bb31:
  br label %bb47
bb32:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/generic:Program", ptr %t85, i32 0, i32 2
  %t88 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t89 = load i32, ptr %t88, !tbaa !23
  %t90 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 2
  %t91 = load i32, ptr %t90, !tbaa !23
  %t95 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t87, i32 %t89, i32 %t91)
  store i1 %t95, ptr %l50
  br label %bb35
bb35:
  %t96 = load i1, ptr %l50, !tbaa !21
  br i1 %t96, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 2
  %t100 = load i32, ptr %t99, !tbaa !23
  %t103 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t98, i32 %t100)
  store i1 %t103, ptr %l54
  br label %bb39
bb39:
  %t104 = load i1, ptr %l54, !tbaa !21
  br i1 %t104, label %bb40, label %bb41
bb40:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/check:Checker", ptr %t105, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = getelementptr %"compiler/generic:Program", ptr %t108, i32 0, i32 2
  store ptr %t110, ptr %l58, !tbaa !29
  %t111 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t112 = load i32, ptr %t111, !tbaa !23
  store i32 %t112, ptr %l59, !tbaa !23
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/check:Checker", ptr %t113, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = getelementptr %"compiler/generic:Program", ptr %t116, i32 0, i32 2
  store ptr %t118, ptr %l62, !tbaa !29
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/check:Checker", ptr %t119, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t124 = getelementptr %"compiler/generic:Program", ptr %t122, i32 0, i32 2
  %t125 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 2
  %t126 = load i32, ptr %t125, !tbaa !23
  %t129 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t124, i32 %t126)
  store i32 %t129, ptr %l67
  br label %bb42
bb41:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb46
bb42:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/check:Checker", ptr %t130, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t135 = getelementptr %"compiler/generic:Program", ptr %t133, i32 0, i32 2
  %t136 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 2
  %t137 = load i32, ptr %t136, !tbaa !23
  %t140 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t135, i32 %t137)
  store i64 %t140, ptr %l72
  br label %bb43
bb43:
  %t141 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t143 = xor i64 %t141, -1
  %t144 = load i64, ptr %l72, !tbaa !24
  %t146 = and i64 %t144, %t143
  %t147 = load ptr, ptr %l62, !tbaa !29
  %t148 = load i32, ptr %l67, !tbaa !23
  %t150 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t147, i32 %t148, i64 %t146)
  store i32 %t150, ptr %l76
  br label %bb44
bb44:
  %t151 = load ptr, ptr %l58, !tbaa !29
  %t152 = load i32, ptr %l59, !tbaa !23
  %t153 = load i32, ptr %l76, !tbaa !23
  %t154 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t151, i32 %t152, i32 %t153)
  store i1 %t154, ptr %l77
  br label %bb45
bb45:
  %t155 = load i1, ptr %l77, !tbaa !21
  store i1 %t155, ptr %l55, !tbaa !21
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s0)
  %t156 = load i1, ptr %l55, !tbaa !21
  store i1 %t156, ptr %rv
  br label %ret
bb47:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/check:Checker", ptr %t157, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t162 = getelementptr %"compiler/generic:Program", ptr %t160, i32 0, i32 2
  %t163 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t164 = load i32, ptr %t163, !tbaa !23
  %t167 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t162, i32 %t164)
  store i32 %t167, ptr %l82
  br label %bb48
bb48:
  %t168 = load i32, ptr %l82, !range !{i32 0, i32 33}
  %t170 = trunc i64 18 to i32
  %t171 = icmp eq i32 %t168, %t170
  %t173 = xor i1 %t171, true
  br i1 %t173, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l86, !tbaa !21
  br label %bb52
bb50:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/check:Checker", ptr %t175, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !29
  %t180 = getelementptr %"compiler/generic:Program", ptr %t178, i32 0, i32 2
  %t181 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 2
  %t182 = load i32, ptr %t181, !tbaa !23
  %t185 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t180, i32 %t182)
  store i32 %t185, ptr %l91
  br label %bb51
bb51:
  %t186 = load i32, ptr %l91, !range !{i32 0, i32 33}
  %t188 = trunc i64 18 to i32
  %t189 = icmp eq i32 %t186, %t188
  %t191 = xor i1 %t189, true
  store i1 %t191, ptr %l86, !tbaa !21
  br label %bb52
bb52:
  %t193 = load i1, ptr %l86, !tbaa !21
  br i1 %t193, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb54:
  br label %bb55
bb55:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/check:Checker", ptr %t195, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t200 = getelementptr %"compiler/generic:Program", ptr %t198, i32 0, i32 2
  %t201 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t202 = load i32, ptr %t201, !tbaa !23
  %t205 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t200, i32 %t202)
  store i32 %t205, ptr %l100
  br label %bb56
bb56:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/check:Checker", ptr %t206, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !29
  %t211 = getelementptr %"compiler/generic:Program", ptr %t209, i32 0, i32 2
  %t212 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 2
  %t213 = load i32, ptr %t212, !tbaa !23
  %t216 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t211, i32 %t213)
  store i32 %t216, ptr %l105
  br label %bb57
bb57:
  %t217 = load i32, ptr %l100, !tbaa !23
  %t218 = load i32, ptr %l105, !tbaa !23
  %t219 = icmp ne i32 %t217, %t218
  br i1 %t219, label %bb58, label %bb59
bb58:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb59:
  br label %bb60
bb60:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/check:Checker", ptr %t222, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !29
  %t227 = getelementptr %"compiler/generic:Program", ptr %t225, i32 0, i32 2
  store ptr %t227, ptr %l110, !tbaa !29
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/check:Checker", ptr %t228, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !29
  %t233 = getelementptr %"compiler/generic:Program", ptr %t231, i32 0, i32 2
  %t234 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t235 = load i32, ptr %t234, !tbaa !23
  %t238 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t233, i32 %t235)
  store i32 %t238, ptr %l115
  br label %bb61
bb61:
  %t239 = load ptr, ptr %l110, !tbaa !29
  %t240 = load i32, ptr %l115, !tbaa !23
  %t241 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t239, i32 %t240)
  store { i64, ptr } %t241, ptr %l116
  br label %bb62
bb62:
  %t242 = load { i64, ptr }, ptr %l116, !tbaa !27
  store { i64, ptr } %t242, ptr %l3, !tbaa !27
  %t243 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t243, ptr %l117
  br label %bb63
bb63:
  %t244 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l117
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t244, ptr %l4
  %t245 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t245, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t247 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t249 = extractvalue { i64, ptr } %t247, 0
  store i64 %t249, ptr %l7, !tbaa !24
  br label %bb64
bb64:
  %t251 = load i64, ptr %l6, !tbaa !24
  %t252 = load i64, ptr %l7, !tbaa !24
  %t255 = icmp slt i64 %t251, %t252
  %t257 = xor i1 %t255, true
  br i1 %t257, label %bb65, label %bb66
bb65:
  br label %bb84
bb66:
  br label %bb67
bb67:
  %t259 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t259, ptr %l125, !tbaa !27
  %t260 = load i64, ptr %l6, !tbaa !24
  %t262 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t263 = load ptr, ptr %t262, !tbaa !27
  %t264 = getelementptr i32, ptr %t263, i64 %t260
  %t265 = load i32, ptr %t264, !tbaa !33
  store i32 %t265, ptr %l8, !tbaa !23
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/check:Checker", ptr %t267, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !29
  %t272 = getelementptr %"compiler/generic:Program", ptr %t270, i32 0, i32 2
  %t273 = load i32, ptr %l8, !tbaa !23
  %t276 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t272, i32 %t273)
  store i32 %t276, ptr %l132
  br label %bb68
bb68:
  %t277 = load i32, ptr %l132, !range !{i32 0, i32 33}
  %t279 = trunc i64 25 to i32
  %t280 = icmp eq i32 %t277, %t279
  %t282 = xor i1 %t280, true
  br i1 %t282, label %bb69, label %bb70
bb69:
  store i1 true, ptr %l136, !tbaa !21
  br label %bb72
bb70:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t286 = getelementptr %"compiler/check:Checker", ptr %t284, i32 0, i32 1
  %t287 = load ptr, ptr %t286, !tbaa !29
  %t289 = getelementptr %"compiler/generic:Program", ptr %t287, i32 0, i32 2
  %t290 = load i32, ptr %l8, !tbaa !23
  %t293 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t289, i32 %t290)
  store i64 %t293, ptr %l141
  br label %bb71
bb71:
  %t294 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 4
  %t295 = load i64, ptr %t294, !tbaa !24
  %t296 = load i64, ptr %l141, !tbaa !24
  %t298 = icmp ne i64 %t296, %t295
  store i1 %t298, ptr %l136, !tbaa !21
  br label %bb72
bb72:
  %t300 = load i1, ptr %l136, !tbaa !21
  br i1 %t300, label %bb73, label %bb74
bb73:
  store i1 true, ptr %l144, !tbaa !21
  br label %bb77
bb74:
  store ptr %l4, ptr %l145, !tbaa !29
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t303 = getelementptr %"compiler/check:Checker", ptr %t301, i32 0, i32 1
  %t304 = load ptr, ptr %t303, !tbaa !29
  %t306 = getelementptr %"compiler/generic:Program", ptr %t304, i32 0, i32 2
  %t307 = load i32, ptr %l8, !tbaa !23
  %t310 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t306, i32 %t307)
  store i64 %t310, ptr %l150
  br label %bb75
bb75:
  %t311 = load ptr, ptr %l145, !tbaa !29
  %t312 = load i64, ptr %l150, !tbaa !24
  %t313 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %s0, ptr %t311, i64 %t312)
  store i1 %t313, ptr %l151
  br label %bb76
bb76:
  %t314 = load i1, ptr %l151, !tbaa !21
  store i1 %t314, ptr %l144, !tbaa !21
  br label %bb77
bb77:
  %t315 = load i1, ptr %l144, !tbaa !21
  br i1 %t315, label %bb78, label %bb79
bb78:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb79:
  br label %bb80
bb80:
  store ptr %l4, ptr %l153, !tbaa !29
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t319 = getelementptr %"compiler/check:Checker", ptr %t317, i32 0, i32 1
  %t320 = load ptr, ptr %t319, !tbaa !29
  %t322 = getelementptr %"compiler/generic:Program", ptr %t320, i32 0, i32 2
  %t323 = load i32, ptr %l8, !tbaa !23
  %t326 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t322, i32 %t323)
  store i64 %t326, ptr %l158
  br label %bb81
bb81:
  %t327 = load ptr, ptr %l153, !tbaa !29
  %t328 = load i64, ptr %l158, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t327, i64 %t328)
  br label %bb82
bb82:
  br label %bb83
bb83:
  %t329 = load i64, ptr %l6, !tbaa !24
  %t331 = add i64 %t329, 1
  store i64 %t331, ptr %l6, !tbaa !24
  br label %bb64
bb84:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euncovered(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i64
  %l15 = alloca i32
  %l20 = alloca i64
  %l25 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l39 = alloca i32
  %l42 = alloca i64
  %l47 = alloca i64
  %l54 = alloca i64
  %l57 = alloca i64
  %l59 = alloca i64
  %l71 = alloca i32
  %l78 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l15
  br label %bb1
bb1:
  %t11 = load i32, ptr %l15, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %l2, !tbaa !23
  %t21 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t17, i32 %t18)
  store i64 %t21, ptr %l20
  br label %bb2
bb2:
  %t22 = load i64, ptr %l20, !tbaa !65
  store i64 %t22, ptr %l4, !tbaa !65
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  %t32 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t28, i32 %a1)
  store { i64, ptr } %t32, ptr %l25
  br label %bb3
bb3:
  %t33 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t33, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t34 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t34, 0
  store i64 %t36, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = load i64, ptr %l7, !tbaa !24
  %t42 = icmp slt i64 %t38, %t39
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb5, label %bb6
bb5:
  br label %bb14
bb6:
  br label %bb7
bb7:
  %t46 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t46, ptr %l32, !tbaa !27
  %t47 = load i64, ptr %l6, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr i32, ptr %t50, i64 %t47
  %t52 = load i32, ptr %t51, !tbaa !33
  store i32 %t52, ptr %l8, !tbaa !23
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/generic:Program", ptr %t57, i32 0, i32 2
  %t60 = load i32, ptr %l8, !tbaa !23
  %t63 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t59, i32 %t60)
  store i32 %t63, ptr %l39
  br label %bb8
bb8:
  %t64 = load i32, ptr %l3, !tbaa !23
  %t65 = load i32, ptr %l39, !tbaa !23
  %t67 = icmp eq i32 %t65, %t64
  br i1 %t67, label %bb9, label %bb10
bb9:
  %t69 = load i64, ptr %l4, !tbaa !65
  store i64 %t69, ptr %l42, !tbaa !65
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/check:Checker", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/generic:Program", ptr %t73, i32 0, i32 2
  %t76 = load i32, ptr %l8, !tbaa !23
  %t79 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t75, i32 %t76)
  store i64 %t79, ptr %l47
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t80 = load i64, ptr %l47, !tbaa !65
  %t81 = xor i64 %t80, -1
  %t82 = load i64, ptr %l42, !tbaa !65
  %t84 = and i64 %t82, %t81
  store i64 %t84, ptr %l4, !tbaa !65
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t86 = load i64, ptr %l6, !tbaa !24
  %t88 = add i64 %t86, 1
  store i64 %t88, ptr %l6, !tbaa !24
  br label %bb4
bb14:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i32, ptr %l3, !tbaa !23
  %t94 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordCount(ptr %v0, ptr %t90, i32 %t91)
  store i64 %t94, ptr %l54
  br label %bb15
bb15:
  %t95 = load i64, ptr %l54, !tbaa !24
  store i64 %t95, ptr %l9, !tbaa !24
  %t96 = load i64, ptr %l9, !tbaa !24
  %t98 = icmp sge i64 %t96, 64
  br i1 %t98, label %bb16, label %bb17
bb16:
  %t100 = sub i64 0, 1
  store i64 %t100, ptr %l57, !tbaa !65
  br label %bb18
bb17:
  %t102 = load i64, ptr %l9, !tbaa !24
  store i64 %t102, ptr %l59, !tbaa !24
  %t103 = load i64, ptr %l59, !tbaa !24
  %t104 = load i64, ptr %l59, !tbaa !24
  %t105 = shl i64 1, %t104
  %t107 = sub i64 %t105, 1
  store i64 %t107, ptr %l57, !tbaa !65
  br label %bb18
bb18:
  %t109 = load i64, ptr %l57, !tbaa !65
  store i64 %t109, ptr %l10, !tbaa !65
  %t110 = load i64, ptr %l4, !tbaa !65
  %t111 = load i64, ptr %l10, !tbaa !65
  %t114 = and i64 %t110, %t111
  store i64 %t114, ptr %l4, !tbaa !65
  %t116 = load i64, ptr %l4, !tbaa !65
  %t118 = icmp eq i64 %t116, 0
  br i1 %t118, label %bb19, label %bb20
bb19:
  %t120 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t120, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t122 = load i64, ptr %l4, !tbaa !65
  %t123 = load i64, ptr %l10, !tbaa !65
  %t126 = icmp eq i64 %t122, %t123
  br i1 %t126, label %bb22, label %bb23
bb22:
  %t128 = load i32, ptr %l3, !tbaa !23
  store i32 %t128, ptr %l71, !tbaa !23
  br label %bb25
bb23:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/check:Checker", ptr %t130, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t135 = getelementptr %"compiler/generic:Program", ptr %t133, i32 0, i32 2
  %t136 = load i32, ptr %l3, !tbaa !23
  %t137 = load i64, ptr %l4, !tbaa !65
  %t141 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %t135, i32 %t136, i64 %t137)
  store i32 %t141, ptr %l78
  br label %bb24
bb24:
  %t142 = load i32, ptr %l78, !tbaa !23
  store i32 %t142, ptr %l71, !tbaa !23
  br label %bb25
bb25:
  %t143 = load i32, ptr %l71, !tbaa !23
  store i32 %t143, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueElem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca ptr
  %l13 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l39 = alloca i32
  %l48 = alloca i32
  %l51 = alloca i1
  %l53 = alloca i1
  %l55 = alloca ptr
  %l58 = alloca i32
  %l59 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca %"compiler/source:Span"
  %l64 = alloca %"compiler/source:Span"
  %l65 = alloca i64
  %l69 = alloca ptr
  %l70 = alloca ptr
  %l71 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l78 = alloca ptr
  %l81 = alloca i32
  %l85 = alloca %"compiler/source:Span"
  %l86 = alloca ptr
  %l89 = alloca i32
  %l90 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca ptr
  %t160 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t8 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyUnique(ptr %v0, ptr %t6)
  store i1 %t8, ptr %l13
  br label %bb1
bb1:
  %t9 = load i1, ptr %l13, !tbaa !21
  %t10 = xor i1 %t9, true
  br i1 %t10, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l5, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t21 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceWritable(ptr %v0, ptr %v1, ptr %t17, ptr %t18)
  store i1 %t21, ptr %l20
  br label %bb5
bb5:
  %t22 = load i1, ptr %l20, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l3, !tbaa !23
  %t25 = load i64, ptr %l5, !tbaa !24
  %t29 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t23, i32 %t24, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d57, i32 0, i32 1) }, i64 %t25)
  store i64 %t29, ptr %l25
  br label %bb8
bb7:
  store i64 -1, ptr %l21, !tbaa !24
  br label %bb9
bb8:
  %t30 = load i64, ptr %l25, !tbaa !24
  store i64 %t30, ptr %l21, !tbaa !24
  br label %bb9
bb9:
  %t31 = load i64, ptr %l21, !tbaa !24
  store i64 %t31, ptr %l6, !tbaa !24
  %t32 = load i64, ptr %l6, !tbaa !24
  %t34 = icmp slt i64 %t32, 0
  br i1 %t34, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l3, !tbaa !23
  %t38 = load i64, ptr %l5, !tbaa !24
  %t42 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s2, ptr %t36, i32 %t37, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d58, i32 0, i32 1) }, i64 %t38)
  store i64 %t42, ptr %l31
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t43 = load i64, ptr %l31, !tbaa !24
  store i64 %t43, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  %t44 = load i64, ptr %l6, !tbaa !24
  %t46 = icmp slt i64 %t44, 0
  br i1 %t46, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t53 = load i64, ptr %l6, !tbaa !24
  %t54 = load i32, ptr %l3, !tbaa !23
  %t58 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodSig(ptr %v0, ptr %t52, i64 %t53, i32 %t54)
  store i32 %t58, ptr %l39
  br label %bb17
bb17:
  %t59 = load i32, ptr %l39, !tbaa !23
  store i32 %t59, ptr %l7, !tbaa !23
  %t60 = load i32, ptr %l7, !tbaa !23
  %t61 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t64 = icmp eq i32 %t60, %t61
  br i1 %t64, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t70, i32 0, i32 2
  %t73 = load i32, ptr %l7, !tbaa !23
  %t76 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t72, i32 %t73)
  store i32 %t76, ptr %l48
  br label %bb21
bb21:
  %t77 = load i32, ptr %l48, !tbaa !23
  store i32 %t77, ptr %l8, !tbaa !23
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i32, ptr %l8, !tbaa !23
  %t82 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t78, i32 %t79)
  store i1 %t82, ptr %l51
  br label %bb22
bb22:
  %t83 = load i1, ptr %l51, !tbaa !21
  %t84 = xor i1 %t83, true
  br i1 %t84, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb27
bb24:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  store ptr %t89, ptr %l55, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i32, ptr %l8, !tbaa !23
  %t94 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t90, i32 %t91)
  store i32 %t94, ptr %l58
  br label %bb25
bb25:
  %t95 = load ptr, ptr %l55, !tbaa !29
  %t96 = load i32, ptr %l58, !tbaa !23
  %t97 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnique(ptr %v0, ptr %t95, i32 %t96)
  store i1 %t97, ptr %l59
  br label %bb26
bb26:
  %t98 = load i1, ptr %l59, !tbaa !21
  %t99 = xor i1 %t98, true
  store i1 %t99, ptr %l53, !tbaa !21
  br label %bb27
bb27:
  %t101 = load i1, ptr %l53, !tbaa !21
  br i1 %t101, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l62, !tbaa !29
  %t104 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t104, ptr %l63
  %t105 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t105, ptr %l64
  %t106 = load i64, ptr %l6, !tbaa !24
  store i64 %t106, ptr %l65, !tbaa !24
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load %"compiler/source:Span", ptr %l1
  %t109 = load ptr, ptr %l2, !tbaa !29
  %t113 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v0, ptr %t107, %"compiler/source:Span" %t108, ptr %t109)
  store ptr %t113, ptr %l69
  br label %bb31
bb31:
  %t114 = load ptr, ptr %l69, !tbaa !29
  store ptr %t114, ptr %l70, !tbaa !29
  %t115 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t115, ptr %l71, !tbaa !27
  %t116 = icmp sge i64 0, 0
  br i1 %t116, label %bb32, label %bb33
bb32:
  %t118 = icmp sle i64 0, 1152921504606846975
  br i1 %t118, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_a50575fe0cbf16d0_d0ac681a5111f894)
  unreachable
bb34:
  %t120 = mul i64 0, 8
  %t121 = insertvalue { i64, ptr } undef, i64 0, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t122, ptr %l74, !tbaa !27
  %t123 = icmp sge i64 0, 0
  br i1 %t123, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_a50575fe0cbf16d0_d0ac681a5111f894)
  unreachable
bb36:
  %t125 = icmp sle i64 0, 2305843009213693951
  br i1 %t125, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_60e1b0f1da45c3fd_13c1ffbfc1f1b5a1)
  unreachable
bb38:
  %t127 = mul i64 0, 4
  %t128 = insertvalue { i64, ptr } undef, i64 0, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t130 = load ptr, ptr %l62, !tbaa !29
  %t131 = load %"compiler/source:Span", ptr %l63
  %t132 = load %"compiler/source:Span", ptr %l64
  %t133 = load i64, ptr %l65, !tbaa !24
  %t134 = load ptr, ptr %l70, !tbaa !29
  %t135 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t138 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %v2, ptr %v0, ptr %v3, ptr %v3, ptr %t130, %"compiler/source:Span" %t131, %"compiler/source:Span" %t132, i64 %t133, ptr %t134, { i64, ptr } %t135, { i64, ptr } %t136, { i64, ptr } %t129)
  store ptr %t138, ptr %l78
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_60e1b0f1da45c3fd_13c1ffbfc1f1b5a1)
  unreachable
bb40:
  %t139 = load ptr, ptr %l78, !tbaa !29
  store ptr %t139, ptr %l9, !tbaa !29
  %t140 = load ptr, ptr %l9, !tbaa !29
  %t143 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t140)
  store i32 %t143, ptr %l81
  br label %bb41
bb41:
  %t144 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t145 = load i32, ptr %l81, !tbaa !23
  %t147 = icmp eq i32 %t145, %t144
  br i1 %t147, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  %t150 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t150, ptr %l85
  %t151 = load ptr, ptr %l0, !tbaa !29
  store ptr %t151, ptr %l86, !tbaa !29
  %t152 = load ptr, ptr %l9, !tbaa !29
  %t155 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t152)
  store i32 %t155, ptr %l89
  br label %bb45
bb45:
  %t156 = load ptr, ptr %l86, !tbaa !29
  %t157 = load i32, ptr %l89, !tbaa !23
  %t158 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t156, i32 %t157)
  store i32 %t158, ptr %l90
  br label %bb46
bb46:
  %t159 = load ptr, ptr %l9, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t160
  %t161 = getelementptr { i64, [4 x i64] }, ptr %t160, i32 0, i32 0
  store i64 2, ptr %t161
  %t162 = load %"compiler/source:Span", ptr %l85
  %t163 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t162, 0
  %t164 = load i32, ptr %l90, !tbaa !23
  %t165 = insertvalue { %"compiler/source:Span", i32, ptr } %t163, i32 %t164, 1
  %t167 = insertvalue { %"compiler/source:Span", i32, ptr } %t165, ptr %t159, 2
  %t168 = getelementptr { i64, [4 x i64] }, ptr %t160, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t167, ptr %t168
  %t169 = load { i64, [4 x i64] }, ptr %t160
  %t171 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store { i64, [4 x i64] } %t169, ptr %t171
  call void @__olang_scope_close(ptr %s0)
  store ptr %t171, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrolledCompr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, %"compiler/check:reflList" %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca %"compiler/check:reflList"
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i1
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l26 = alloca { i64, ptr }
  %l29 = alloca i64
  %l35 = alloca i64
  %l38 = alloca i64
  %l56 = alloca ptr
  %l58 = alloca i32
  %l63 = alloca i32
  %l64 = alloca i32
  %l65 = alloca ptr
  %l67 = alloca i32
  %l70 = alloca ptr
  %l72 = alloca i32
  %l74 = alloca i32
  %l75 = alloca i32
  %l83 = alloca i64
  %l86 = alloca ptr
  %l92 = alloca %"compiler/source:Span"
  %l93 = alloca %"compiler/diagmsg:Msg"
  %l94 = alloca i64
  %l102 = alloca ptr
  %l105 = alloca i1
  %l107 = alloca ptr
  %l109 = alloca ptr
  %l112 = alloca %"compiler/source:Span"
  %l114 = alloca i1
  %l133 = alloca { i64, ptr }
  %l136 = alloca ptr
  %l137 = alloca i32
  %l140 = alloca ptr
  %l142 = alloca i32
  %l144 = alloca i32
  %l145 = alloca i32
  %l146 = alloca %"compiler/source:Span"
  %l147 = alloca i32
  %l148 = alloca i32
  %l149 = alloca { i64, ptr }
  %l153 = alloca i32
  %l155 = alloca %"compiler/typed:Make"
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca ptr
  %t279 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store %"compiler/check:reflList" %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l21, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t4 = getelementptr %"compiler/ast:Compr", ptr %t2, i32 0, i32 4
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t7 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t5)
  store %"compiler/source:Span" %t7, ptr %l24
  br label %bb1
bb1:
  %t8 = load %"compiler/check:reflList", ptr %l3
  %t9 = load ptr, ptr %l21, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l24
  %t12 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistItems(ptr %v0, ptr %s0, ptr %t9, %"compiler/source:Span" %t10, %"compiler/check:reflList" %t8)
  store { i64, ptr } %t12, ptr %l26
  br label %bb2
bb2:
  %t13 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t13, ptr %l5, !tbaa !27
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 36
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l29
  br label %bb3
bb3:
  %t19 = load i64, ptr %l29, !tbaa !24
  store i64 %t19, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  store i64 %t22, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t24 = load i64, ptr %l9, !tbaa !24
  %t25 = load i64, ptr %l8, !tbaa !24
  %t28 = icmp sgt i64 %t24, %t25
  br i1 %t28, label %bb4, label %bb5
bb4:
  %t30 = load i64, ptr %l10, !tbaa !24
  %t32 = icmp sgt i64 %t30, 0
  br i1 %t32, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb9
bb6:
  %t34 = load i64, ptr %l9, !tbaa !24
  %t35 = load i64, ptr %l8, !tbaa !24
  %t38 = sub i64 %t34, %t35
  %t39 = load i64, ptr %l10, !tbaa !24
  %t42 = add i64 %t38, %t39
  %t44 = sub i64 %t42, 1
  %t45 = load i64, ptr %l10, !tbaa !24
  %t48 = sdiv i64 %t44, %t45
  store i64 %t48, ptr %l38, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb8
bb8:
  %t50 = load i64, ptr %l38, !tbaa !24
  store i64 %t50, ptr %l35, !tbaa !24
  br label %bb9
bb9:
  %t51 = load i64, ptr %l35, !tbaa !24
  store i64 %t51, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb10
bb10:
  %t52 = load i64, ptr %l12, !tbaa !24
  %t53 = load i64, ptr %l11, !tbaa !24
  %t56 = icmp slt i64 %t52, %t53
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb11, label %bb12
bb11:
  br label %bb46
bb12:
  br label %bb13
bb13:
  %t60 = load i64, ptr %l8, !tbaa !24
  %t61 = load i64, ptr %l12, !tbaa !24
  %t62 = load i64, ptr %l10, !tbaa !24
  %t65 = mul i64 %t61, %t62
  %t68 = add i64 %t60, %t65
  store i64 %t68, ptr %l13, !tbaa !24
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l56, !tbaa !29
  %t71 = load ptr, ptr %l2, !tbaa !29
  %t73 = getelementptr %"compiler/ast:Compr", ptr %t71, i32 0, i32 3
  %t74 = load i32, ptr %t73, !tbaa !23
  store i32 %t74, ptr %l58, !tbaa !23
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load %"compiler/check:reflList", ptr %l3
  %t77 = load i64, ptr %l13, !tbaa !24
  %t79 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr i64, ptr %t80, i64 %t77
  %t82 = load i64, ptr %t81, !tbaa !34
  %t86 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescriptor(ptr %v0, ptr %t75, %"compiler/check:reflList" %t76, i64 %t82)
  store i32 %t86, ptr %l63
  br label %bb14
bb14:
  %t87 = load ptr, ptr %l56, !tbaa !29
  %t88 = load i32, ptr %l58, !tbaa !23
  %t89 = load i32, ptr %l63, !tbaa !23
  %t90 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflBind(ptr %v0, ptr %t87, i32 %t88, i32 %t89)
  store i32 %t90, ptr %l64
  br label %bb15
bb15:
  %t91 = load i32, ptr %l64, !tbaa !23
  store i32 %t91, ptr %l14, !tbaa !23
  %t92 = load ptr, ptr %l0, !tbaa !29
  store ptr %t92, ptr %l65, !tbaa !29
  %t93 = load ptr, ptr %l2, !tbaa !29
  %t95 = getelementptr %"compiler/ast:Compr", ptr %t93, i32 0, i32 2
  %t96 = load i32, ptr %t95, !tbaa !23
  store i32 %t96, ptr %l67, !tbaa !23
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  store ptr %t102, ptr %l70, !tbaa !29
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t103)
  store i32 %t105, ptr %l72
  br label %bb16
bb16:
  %t106 = load i64, ptr %l13, !tbaa !24
  %t107 = load ptr, ptr %l70, !tbaa !29
  %t108 = load i32, ptr %l72, !tbaa !23
  %t110 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t107, i32 %t108, i64 %t106)
  store i32 %t110, ptr %l74
  br label %bb17
bb17:
  %t111 = load ptr, ptr %l65, !tbaa !29
  %t112 = load i32, ptr %l67, !tbaa !23
  %t113 = load i32, ptr %l74, !tbaa !23
  %t114 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflBind(ptr %v0, ptr %t111, i32 %t112, i32 %t113)
  store i32 %t114, ptr %l75
  br label %bb18
bb18:
  %t115 = load i32, ptr %l75, !tbaa !23
  store i32 %t115, ptr %l15, !tbaa !23
  store i1 true, ptr %l16, !tbaa !21
  %t116 = load ptr, ptr %l2, !tbaa !29
  %t118 = getelementptr %"compiler/ast:Compr", ptr %t116, i32 0, i32 5
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t121 = icmp eq ptr %t119, null
  %t123 = xor i1 %t121, true
  br i1 %t123, label %bb19, label %bb20
bb19:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load ptr, ptr %l2, !tbaa !29
  %t128 = getelementptr %"compiler/ast:Compr", ptr %t126, i32 0, i32 5
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t132 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDecide(ptr %v0, ptr %v1, ptr %t125, ptr %t129)
  store i64 %t132, ptr %l83
  br label %bb21
bb20:
  br label %bb31
bb21:
  %t133 = load i64, ptr %l83, !tbaa !24
  store i64 %t133, ptr %l17, !tbaa !24
  %t134 = load i64, ptr %l17, !tbaa !24
  %t136 = icmp slt i64 %t134, 0
  br i1 %t136, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s4
  %t138 = load ptr, ptr %l0, !tbaa !29
  store ptr %t138, ptr %l86, !tbaa !29
  %t139 = load ptr, ptr %l2, !tbaa !29
  %t141 = getelementptr %"compiler/ast:Compr", ptr %t139, i32 0, i32 5
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t144 = icmp eq ptr %t142, null
  br i1 %t144, label %bb24, label %bb25
bb23:
  %t146 = load i64, ptr %l17, !tbaa !24
  %t148 = icmp eq i64 %t146, 1
  store i1 %t148, ptr %l16, !tbaa !21
  br label %bb30
bb24:
  call void @__olang_check_failed(ptr @olang_loc_ef99e54d7427d8e6_6c42201a9dddf792)
  unreachable
bb25:
  br label %bb26
bb26:
  %t150 = load ptr, ptr %l2, !tbaa !29
  %t152 = getelementptr %"compiler/ast:Compr", ptr %t150, i32 0, i32 5
  %t153 = load ptr, ptr %t152, !tbaa !29
  %t155 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t153)
  store %"compiler/source:Span" %t155, ptr %l92
  br label %bb27
bb27:
  %t156 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflFilterUndecided(ptr %s4)
  store %"compiler/diagmsg:Msg" %t156, ptr %l93
  br label %bb28
bb28:
  %t157 = load ptr, ptr %l86, !tbaa !29
  %t158 = load %"compiler/source:Span", ptr %l92
  %t159 = load %"compiler/diagmsg:Msg", ptr %l93
  %t160 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t157, %"compiler/source:Span" %t158, %"compiler/diagmsg:Msg" %t159)
  store i64 %t160, ptr %l94
  br label %bb29
bb29:
  store i1 false, ptr %l16, !tbaa !21
  call void @__olang_scope_close(ptr %s4)
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t161 = load i1, ptr %l16, !tbaa !21
  br i1 %t161, label %bb32, label %bb33
bb32:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load ptr, ptr %l2, !tbaa !29
  %t166 = getelementptr %"compiler/ast:Compr", ptr %t164, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t168 = load i32, ptr %l4, !tbaa !23
  %t172 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %v0, ptr %t163, ptr %t167, i32 %t168)
  store ptr %t172, ptr %l102
  br label %bb34
bb33:
  br label %bb42
bb34:
  %t173 = load ptr, ptr %l102, !tbaa !29
  store ptr %t173, ptr %l18, !tbaa !29
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load i32, ptr %l4, !tbaa !23
  %t178 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t174, i32 %t175)
  store i1 %t178, ptr %l105
  br label %bb35
bb35:
  %t179 = load i1, ptr %l105, !tbaa !21
  %t180 = xor i1 %t179, true
  br i1 %t180, label %bb36, label %bb37
bb36:
  %t182 = load ptr, ptr %l0, !tbaa !29
  store ptr %t182, ptr %l107, !tbaa !29
  %t183 = load ptr, ptr %l18, !tbaa !29
  store ptr %t183, ptr %l109, !tbaa !29
  %t185 = load ptr, ptr %l2, !tbaa !29
  %t187 = getelementptr %"compiler/ast:Compr", ptr %t185, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !29
  %t190 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t188)
  store %"compiler/source:Span" %t190, ptr %l112
  br label %bb38
bb37:
  br label %bb40
bb38:
  %t191 = load i64, ptr @G_2ecompiler_2fcheck_2eRoStored, !tbaa !24
  %t192 = load ptr, ptr %l107, !tbaa !29
  %t193 = load ptr, ptr %l109, !tbaa !29
  %t194 = load %"compiler/source:Span", ptr %l112
  %t196 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v0, ptr %t192, ptr %t193, %"compiler/source:Span" %t194, i64 %t191)
  store i1 %t196, ptr %l114
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/check:Checker", ptr %t197, i32 0, i32 36
  %t200 = load ptr, ptr %l18, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t199, ptr %t200)
  br label %bb41
bb41:
  %t203 = load i64, ptr %l7, !tbaa !24
  %t205 = add i64 %t203, 1
  store i64 %t205, ptr %l7, !tbaa !24
  br label %bb42
bb42:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load ptr, ptr %l2, !tbaa !29
  %t210 = getelementptr %"compiler/ast:Compr", ptr %t208, i32 0, i32 2
  %t211 = load i32, ptr %t210, !tbaa !23
  %t212 = load i32, ptr %l15, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflUnbind(ptr %v0, ptr %t207, i32 %t211, i32 %t212)
  br label %bb43
bb43:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load ptr, ptr %l2, !tbaa !29
  %t219 = getelementptr %"compiler/ast:Compr", ptr %t217, i32 0, i32 3
  %t220 = load i32, ptr %t219, !tbaa !23
  %t221 = load i32, ptr %l14, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflUnbind(ptr %v0, ptr %t216, i32 %t220, i32 %t221)
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t225 = load i64, ptr %l12, !tbaa !24
  %t227 = add i64 %t225, 1
  store i64 %t227, ptr %l12, !tbaa !24
  br label %bb10
bb46:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"compiler/check:Checker", ptr %t229, i32 0, i32 36
  %t232 = load i64, ptr %l6, !tbaa !24
  %t235 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v2, ptr %t231, i64 %t232)
  store { i64, ptr } %t235, ptr %l133
  br label %bb47
bb47:
  %t236 = load { i64, ptr }, ptr %l133, !tbaa !27
  store { i64, ptr } %t236, ptr %l19, !tbaa !27
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = getelementptr %"compiler/check:Checker", ptr %t237, i32 0, i32 1
  %t240 = load ptr, ptr %t239, !tbaa !29
  %t242 = getelementptr %"compiler/generic:Program", ptr %t240, i32 0, i32 2
  store ptr %t242, ptr %l136, !tbaa !29
  %t243 = load i32, ptr %l4, !tbaa !23
  store i32 %t243, ptr %l137, !tbaa !23
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr %"compiler/check:Checker", ptr %t244, i32 0, i32 1
  %t247 = load ptr, ptr %t246, !tbaa !29
  %t249 = getelementptr %"compiler/generic:Program", ptr %t247, i32 0, i32 2
  store ptr %t249, ptr %l140, !tbaa !29
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t252 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t250)
  store i32 %t252, ptr %l142
  br label %bb48
bb48:
  %t253 = load i64, ptr %l7, !tbaa !24
  %t254 = load ptr, ptr %l140, !tbaa !29
  %t255 = load i32, ptr %l142, !tbaa !23
  %t257 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t254, i32 %t255, i64 %t253)
  store i32 %t257, ptr %l144
  br label %bb49
bb49:
  %t258 = load ptr, ptr %l136, !tbaa !29
  %t259 = load i32, ptr %l137, !tbaa !23
  %t260 = load i32, ptr %l144, !tbaa !23
  %t261 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t258, i32 %t259, i32 %t260)
  store i32 %t261, ptr %l145
  br label %bb50
bb50:
  %t262 = load i32, ptr %l145, !tbaa !23
  %t263 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t263, ptr %l146
  store i32 %t262, ptr %l147, !tbaa !23
  store i32 2, ptr %l148
  %t265 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t265, ptr %l149, !tbaa !27
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t267 = load %"compiler/source:Span", ptr %l1
  %t271 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t266, i32 1, %"compiler/source:Span" %t267)
  store i32 %t271, ptr %l153
  br label %bb51
bb51:
  %t272 = load i32, ptr %l148, !range !{i32 0, i32 5}
  %t273 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t274 = load i32, ptr %l153, !tbaa !23
  %t276 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t272, i64 0, { i64, ptr } %t273, ptr null, i32 %t274, i32 0, i1 false)
  store %"compiler/typed:Make" %t276, ptr %l155
  br label %bb52
bb52:
  %t277 = load %"compiler/typed:Make", ptr %l155
  %t278 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 56, i64 8)
  store %"compiler/typed:Make" %t277, ptr %t278
  store { i64, [5 x i64] } zeroinitializer, ptr %t279
  %t280 = getelementptr { i64, [5 x i64] }, ptr %t279, i32 0, i32 0
  store i64 7, ptr %t280
  %t281 = load %"compiler/source:Span", ptr %l146
  %t282 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t281, 0
  %t283 = load i32, ptr %l147, !tbaa !23
  %t284 = insertvalue { %"compiler/source:Span", i32, ptr } %t282, i32 %t283, 1
  %t286 = insertvalue { %"compiler/source:Span", i32, ptr } %t284, ptr %t278, 2
  %t287 = getelementptr { i64, [5 x i64] }, ptr %t279, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t286, ptr %t287
  %t288 = load { i64, [5 x i64] }, ptr %t279
  %t290 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t288, ptr %t290
  call void @__olang_scope_close(ptr %s0)
  store ptr %t290, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eviewCallee(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %l15 = alloca i64
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Call", ptr %a1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t7 = load ptr, ptr %l7, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l7, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l8, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { i32 }, ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t22 = load i32, ptr %l3, !tbaa !23
  %t25 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eViewsOf(ptr %v0, ptr %a0, i32 %t22)
  store i64 %t25, ptr %l15
  br label %bb6
bb6:
  %t26 = load i64, ptr %l15, !tbaa !24
  %t27 = icmp ne i64 %t26, 0
  store i1 %t27, ptr %l6, !tbaa !21
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_a969f4d227859e_fa1675b60a8d81a2)
  unreachable
bb12:
  %t29 = load i1, ptr %l6, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eexistingValue(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l39 = alloca i1
  %l45 = alloca i1
  %l46 = alloca i1
  %l49 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l57 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca i1
  %l65 = alloca i1
  %l66 = alloca ptr
  %l67 = alloca i1
  %l76 = alloca i1
  %l82 = alloca i1
  %l83 = alloca ptr
  %l84 = alloca i1
  %l90 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca i1
  %l101 = alloca i1
  %l105 = alloca i1
  %l106 = alloca { i64, ptr }
  %l108 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l10, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t17 = load ptr, ptr %l16, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l16, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 6
  store i1 %t23, ptr %l17, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l17, !tbaa !21
  %t25 = xor i1 %t24, true
  store i1 %t25, ptr %l9, !tbaa !21
  br label %bb87
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t28 = load ptr, ptr %l21, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t31 = load ptr, ptr %l21, !tbaa !29
  %t32 = load i64, ptr %t31, !range !{i64 0, i64 18}
  %t34 = icmp eq i64 %t32, 10
  store i1 %t34, ptr %l22, !tbaa !21
  br label %bb10
bb10:
  %t35 = load i1, ptr %l22, !tbaa !21
  br i1 %t35, label %bb11, label %bb12
bb11:
  br label %bb17
bb12:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t37 = load ptr, ptr %l25, !tbaa !29
  %t38 = icmp ne ptr %t37, null
  br i1 %t38, label %bb13, label %bb14
bb13:
  %t40 = load ptr, ptr %l25, !tbaa !29
  %t41 = load i64, ptr %t40, !range !{i64 0, i64 18}
  %t43 = icmp eq i64 %t41, 1
  store i1 %t43, ptr %l26, !tbaa !21
  br label %bb14
bb14:
  %t44 = load i1, ptr %l26, !tbaa !21
  br i1 %t44, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb87
bb18:
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t46 = load ptr, ptr %l29, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb19, label %bb20
bb19:
  %t49 = load ptr, ptr %l29, !tbaa !29
  %t50 = load i64, ptr %t49, !range !{i64 0, i64 18}
  %t52 = icmp eq i64 %t50, 11
  store i1 %t52, ptr %l30, !tbaa !21
  br label %bb20
bb20:
  %t53 = load i1, ptr %l30, !tbaa !21
  br i1 %t53, label %bb21, label %bb22
bb21:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr { i64, [5 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t56, i32 0, i32 2
  %t58 = load ptr, ptr %t57
  store ptr %t58, ptr %l2, !tbaa !29
  br label %bb23
bb22:
  br label %bb35
bb23:
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Cond", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = icmp eq ptr %t63, null
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb24, label %bb25
bb24:
  %t69 = load ptr, ptr %l2, !tbaa !29
  %t71 = getelementptr %"compiler/typed:Cond", ptr %t69, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = icmp eq ptr %t72, null
  br i1 %t74, label %bb26, label %bb27
bb25:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb30
bb26:
  call void @__olang_check_failed(ptr @olang_loc_7bdd4e800dbf10f8_a5805e1380ae00f4)
  unreachable
bb27:
  br label %bb28
bb28:
  %t76 = load ptr, ptr %l2, !tbaa !29
  %t78 = getelementptr %"compiler/typed:Cond", ptr %t76, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = call i1 @compiler_2fcheck_2eexistingValue(ptr %v0, ptr %t79)
  store i1 %t81, ptr %l45
  br label %bb29
bb29:
  %t82 = load i1, ptr %l45, !tbaa !21
  store i1 %t82, ptr %l39, !tbaa !21
  br label %bb30
bb30:
  %t83 = load i1, ptr %l39, !tbaa !21
  br i1 %t83, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb34
bb32:
  %t84 = load ptr, ptr %l2, !tbaa !29
  %t86 = getelementptr %"compiler/typed:Cond", ptr %t84, i32 0, i32 2
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t89 = call i1 @compiler_2fcheck_2eexistingValue(ptr %v0, ptr %t87)
  store i1 %t89, ptr %l49
  br label %bb33
bb33:
  %t90 = load i1, ptr %l49, !tbaa !21
  store i1 %t90, ptr %l46, !tbaa !21
  br label %bb34
bb34:
  %t91 = load i1, ptr %l46, !tbaa !21
  store i1 %t91, ptr %l9, !tbaa !21
  br label %bb87
bb35:
  %t92 = load ptr, ptr %l0, !tbaa !29
  store ptr %t92, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t93 = load ptr, ptr %l50, !tbaa !29
  %t94 = icmp ne ptr %t93, null
  br i1 %t94, label %bb36, label %bb37
bb36:
  %t96 = load ptr, ptr %l50, !tbaa !29
  %t97 = load i64, ptr %t96, !range !{i64 0, i64 18}
  %t99 = icmp eq i64 %t97, 13
  store i1 %t99, ptr %l51, !tbaa !21
  br label %bb37
bb37:
  %t100 = load i1, ptr %l51, !tbaa !21
  br i1 %t100, label %bb38, label %bb39
bb38:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr { i64, [5 x i64] }, ptr %t101, i32 0, i32 1
  %t104 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t103, i32 0, i32 2
  %t105 = load ptr, ptr %t104
  store ptr %t105, ptr %l3, !tbaa !29
  br label %bb40
bb39:
  br label %bb42
bb40:
  %t107 = load ptr, ptr %l3, !tbaa !29
  %t109 = call i1 @compiler_2fcheck_2ematchExisting(ptr %v0, ptr %t107)
  store i1 %t109, ptr %l57
  br label %bb41
bb41:
  %t110 = load i1, ptr %l57, !tbaa !21
  store i1 %t110, ptr %l9, !tbaa !21
  br label %bb87
bb42:
  %t111 = load ptr, ptr %l0, !tbaa !29
  store ptr %t111, ptr %l58, !tbaa !29
  store i1 false, ptr %l59, !tbaa !21
  %t112 = load ptr, ptr %l58, !tbaa !29
  %t113 = icmp ne ptr %t112, null
  br i1 %t113, label %bb43, label %bb44
bb43:
  %t115 = load ptr, ptr %l58, !tbaa !29
  %t116 = load i64, ptr %t115, !range !{i64 0, i64 18}
  %t118 = icmp eq i64 %t116, 14
  store i1 %t118, ptr %l59, !tbaa !21
  br label %bb44
bb44:
  %t119 = load i1, ptr %l59, !tbaa !21
  br i1 %t119, label %bb45, label %bb46
bb45:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr { i64, [5 x i64] }, ptr %t120, i32 0, i32 1
  %t123 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t122, i32 0, i32 2
  %t124 = load ptr, ptr %t123
  store ptr %t124, ptr %l4, !tbaa !29
  br label %bb47
bb46:
  br label %bb49
bb47:
  %t126 = load ptr, ptr %l4, !tbaa !29
  %t128 = call i1 @compiler_2fcheck_2etryExisting(ptr %v0, ptr %t126)
  store i1 %t128, ptr %l65
  br label %bb48
bb48:
  %t129 = load i1, ptr %l65, !tbaa !21
  store i1 %t129, ptr %l9, !tbaa !21
  br label %bb87
bb49:
  %t130 = load ptr, ptr %l0, !tbaa !29
  store ptr %t130, ptr %l66, !tbaa !29
  store i1 false, ptr %l67, !tbaa !21
  %t131 = load ptr, ptr %l66, !tbaa !29
  %t132 = icmp ne ptr %t131, null
  br i1 %t132, label %bb50, label %bb51
bb50:
  %t134 = load ptr, ptr %l66, !tbaa !29
  %t135 = load i64, ptr %t134, !range !{i64 0, i64 18}
  %t137 = icmp eq i64 %t135, 12
  store i1 %t137, ptr %l67, !tbaa !21
  br label %bb51
bb51:
  %t138 = load i1, ptr %l67, !tbaa !21
  br i1 %t138, label %bb52, label %bb53
bb52:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr { i64, [5 x i64] }, ptr %t139, i32 0, i32 1
  %t142 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t141, i32 0, i32 2
  %t143 = load ptr, ptr %t142
  store ptr %t143, ptr %l5, !tbaa !29
  br label %bb54
bb53:
  br label %bb62
bb54:
  %t145 = load ptr, ptr %l5, !tbaa !29
  %t147 = getelementptr %"compiler/typed:Seq", ptr %t145, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !29
  %t150 = icmp eq ptr %t148, null
  %t152 = xor i1 %t150, true
  br i1 %t152, label %bb55, label %bb56
bb55:
  %t154 = load ptr, ptr %l5, !tbaa !29
  %t156 = getelementptr %"compiler/typed:Seq", ptr %t154, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = icmp eq ptr %t157, null
  br i1 %t159, label %bb57, label %bb58
bb56:
  store i1 false, ptr %l76, !tbaa !21
  br label %bb61
bb57:
  call void @__olang_check_failed(ptr @olang_loc_4533f85d93cedd17_b546fe5da9c85083)
  unreachable
bb58:
  br label %bb59
bb59:
  %t161 = load ptr, ptr %l5, !tbaa !29
  %t163 = getelementptr %"compiler/typed:Seq", ptr %t161, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !29
  %t166 = call i1 @compiler_2fcheck_2eexistingValue(ptr %v0, ptr %t164)
  store i1 %t166, ptr %l82
  br label %bb60
bb60:
  %t167 = load i1, ptr %l82, !tbaa !21
  store i1 %t167, ptr %l76, !tbaa !21
  br label %bb61
bb61:
  %t168 = load i1, ptr %l76, !tbaa !21
  store i1 %t168, ptr %l9, !tbaa !21
  br label %bb87
bb62:
  %t169 = load ptr, ptr %l0, !tbaa !29
  store ptr %t169, ptr %l83, !tbaa !29
  store i1 false, ptr %l84, !tbaa !21
  %t170 = load ptr, ptr %l83, !tbaa !29
  %t171 = icmp ne ptr %t170, null
  br i1 %t171, label %bb63, label %bb64
bb63:
  %t173 = load ptr, ptr %l83, !tbaa !29
  %t174 = load i64, ptr %t173, !range !{i64 0, i64 18}
  %t176 = icmp eq i64 %t174, 17
  store i1 %t176, ptr %l84, !tbaa !21
  br label %bb64
bb64:
  %t177 = load i1, ptr %l84, !tbaa !21
  br i1 %t177, label %bb65, label %bb66
bb65:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr { i64, [5 x i64] }, ptr %t178, i32 0, i32 1
  %t181 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t180, i32 0, i32 2
  %t182 = load ptr, ptr %t181
  store ptr %t182, ptr %l6, !tbaa !29
  br label %bb67
bb66:
  br label %bb69
bb67:
  %t184 = load ptr, ptr %l6, !tbaa !29
  %t186 = call i1 @compiler_2fcheck_2eexistingValue(ptr %v0, ptr %t184)
  store i1 %t186, ptr %l90
  br label %bb68
bb68:
  %t187 = load i1, ptr %l90, !tbaa !21
  store i1 %t187, ptr %l9, !tbaa !21
  br label %bb87
bb69:
  %t188 = load ptr, ptr %l0, !tbaa !29
  store ptr %t188, ptr %l91, !tbaa !29
  store i1 false, ptr %l92, !tbaa !21
  %t189 = load ptr, ptr %l91, !tbaa !29
  %t190 = icmp ne ptr %t189, null
  br i1 %t190, label %bb70, label %bb71
bb70:
  %t192 = load ptr, ptr %l91, !tbaa !29
  %t193 = load i64, ptr %t192, !range !{i64 0, i64 18}
  %t195 = icmp eq i64 %t193, 9
  store i1 %t195, ptr %l92, !tbaa !21
  br label %bb71
bb71:
  %t196 = load i1, ptr %l92, !tbaa !21
  br i1 %t196, label %bb72, label %bb73
bb72:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr { i64, [5 x i64] }, ptr %t197, i32 0, i32 1
  %t200 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t199, i32 0, i32 2
  %t201 = load i32, ptr %t200, !range !{i32 0, i32 49}
  store i32 %t201, ptr %l7
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr { i64, [5 x i64] }, ptr %t203, i32 0, i32 1
  %t206 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t205, i32 0, i32 4
  %t207 = load { i64, ptr }, ptr %t206
  store { i64, ptr } %t207, ptr %l8, !tbaa !27
  br label %bb74
bb73:
  br label %bb82
bb74:
  %t209 = load i32, ptr %l7, !range !{i32 0, i32 49}
  %t211 = trunc i64 20 to i32
  %t212 = icmp eq i32 %t209, %t211
  br i1 %t212, label %bb75, label %bb76
bb75:
  %t214 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t214, 0
  %t218 = icmp eq i64 %t216, 1
  store i1 %t218, ptr %l101, !tbaa !21
  br label %bb77
bb76:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb77
bb77:
  %t220 = load i1, ptr %l101, !tbaa !21
  br i1 %t220, label %bb78, label %bb79
bb78:
  %t221 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t221, ptr %l106, !tbaa !27
  %t222 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t223 = load ptr, ptr %t222, !tbaa !27
  %t224 = getelementptr ptr, ptr %t223, i64 0
  %t225 = load ptr, ptr %t224, !tbaa !39
  %t227 = call i1 @compiler_2fcheck_2eexistingValue(ptr %v0, ptr %t225)
  store i1 %t227, ptr %l108
  br label %bb80
bb79:
  store i1 false, ptr %l105, !tbaa !21
  br label %bb81
bb80:
  %t228 = load i1, ptr %l108, !tbaa !21
  store i1 %t228, ptr %l105, !tbaa !21
  br label %bb81
bb81:
  %t229 = load i1, ptr %l105, !tbaa !21
  store i1 %t229, ptr %l9, !tbaa !21
  br label %bb87
bb82:
  br i1 true, label %bb83, label %bb84
bb83:
  br label %bb85
bb84:
  br label %bb86
bb85:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb87
bb86:
  call void @__olang_check_failed(ptr @olang_loc_b94a36f209a3c5e5_113c4160723e4631)
  unreachable
bb87:
  %t230 = load i1, ptr %l9, !tbaa !21
  store i1 %t230, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2eheldValue(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l24 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Promote", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %l4, !tbaa !29
  br label %bb18
bb6:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t23 = load ptr, ptr %l14, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t26 = load ptr, ptr %l14, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 18}
  %t29 = icmp eq i64 %t27, 14
  store i1 %t29, ptr %l15, !tbaa !21
  br label %bb8
bb8:
  %t30 = load i1, ptr %l15, !tbaa !21
  br i1 %t30, label %bb9, label %bb10
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr { i64, [5 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 0
  %t35 = load %"compiler/source:Span", ptr %t34
  store %"compiler/source:Span" %t35, ptr %l2
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr { i64, [5 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l3, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t43 = load %"compiler/source:Span", ptr %l2
  %t44 = load ptr, ptr %l3, !tbaa !29
  %t47 = call ptr @compiler_2fcheck_2eheldTry(ptr %v0, ptr %v1, %"compiler/source:Span" %t43, ptr %t44)
  store ptr %t47, ptr %l24
  br label %bb12
bb12:
  %t48 = load ptr, ptr %l24, !tbaa !29
  store ptr %t48, ptr %l4, !tbaa !29
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store ptr null, ptr %l4, !tbaa !29
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_338177df999812ed_466eceed6b347ea1)
  unreachable
bb18:
  %t49 = load ptr, ptr %l4, !tbaa !29
  store ptr %t49, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2einvokedCallee(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l1, !tbaa !29
  store i1 false, ptr %l2, !tbaa !21
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 5}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l2, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l2, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t11 = load ptr, ptr %l5, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l5, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 5}
  %t17 = icmp eq i64 %t15, 1
  store i1 %t17, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l6, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br i1 true, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 false, ptr %rv
  br label %ret
bb14:
  call void @__olang_check_failed(ptr @olang_loc_db94e874d036c6ef_7db06dea6929eb03)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eisLimitName(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca i64
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i64 @compiler_2fcheck_2elimitIndex(ptr %v0, { i64, ptr } %a0)
  store i64 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i64, ptr %l2, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  store i1 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2elistName(ptr %v0, i64 %a0) #0 {
entry:
  %l1 = alloca [7 x { i64, ptr }]
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [7 x { i64, ptr }] undef, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t2 = insertvalue [7 x { i64, ptr }] %t1, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t3 = insertvalue [7 x { i64, ptr }] %t2, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d61, i32 0, i32 1) }, 2
  %t4 = insertvalue [7 x { i64, ptr }] %t3, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d62, i32 0, i32 1) }, 3
  %t5 = insertvalue [7 x { i64, ptr }] %t4, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d63, i32 0, i32 1) }, 4
  %t6 = insertvalue [7 x { i64, ptr }] %t5, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d64, i32 0, i32 1) }, 5
  %t7 = insertvalue [7 x { i64, ptr }] %t6, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d65, i32 0, i32 1) }, 6
  store [7 x { i64, ptr }] %t7, ptr %l1
  %t10 = getelementptr [7 x { i64, ptr }], ptr %l1, i64 0, i64 %a0
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !37
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t13, 0
  store i64 %t14, ptr %l5, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t16 = mul i64 %t15, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t16)
  %t18 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l6, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = load i64, ptr %l5, !tbaa !24
  %t25 = mul i64 %t24, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t21, ptr %t23, i64 %t25, i1 false)
  %t26 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t26, ptr %l4, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t27, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2elitv_2eintLit(i64 %a0) #0 {
entry:
  %l2 = alloca %"compiler/check:litv"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/check:litv"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %s0, i1 true, i1 false, i1 false, i64 %a0, double 0x0000000000000000)
  store %"compiler/check:litv" %t3, ptr %l2
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t4 = load %"compiler/check:litv", ptr %l2
  store %"compiler/check:litv" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %a0, i64 %a1) #0 {
entry:
  %l0 = alloca %"compiler/source:Span"
  %l7 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store %"compiler/source:Span" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/source:Span", ptr %l0, i32 0, i32 1
  %t2 = load i32, ptr %t1, !tbaa !23
  %t5 = trunc i64 %a1 to i32
  %t8 = sub i32 %t2, %t5
  %t9 = getelementptr %"compiler/source:Span", ptr %l0, i32 0, i32 1
  %t10 = load i32, ptr %t9, !tbaa !23
  %t13 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t8, i32 %t10)
  store %"compiler/source:Span" %t13, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t14 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t14, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2fcheck_2enullValue(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l20 = alloca i1
  %l26 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/ast:Match", ptr %a0, i32 0, i32 3
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l2, !tbaa !24
  %t11 = load i64, ptr %l3, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb16
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t18, ptr %l13, !tbaa !27
  %t19 = load i64, ptr %l2, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l4, !tbaa !29
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t28 = getelementptr %"compiler/ast:Case", ptr %t26, i32 0, i32 5
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = icmp eq ptr %t29, null
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb5, label %bb6
bb5:
  %t35 = load ptr, ptr %l4, !tbaa !29
  %t37 = getelementptr %"compiler/ast:Case", ptr %t35, i32 0, i32 5
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = icmp eq ptr %t38, null
  br i1 %t40, label %bb7, label %bb8
bb6:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb11
bb7:
  call void @__olang_check_failed(ptr @olang_loc_29f8057051902f50_e91b4d9ed5822c7c)
  unreachable
bb8:
  br label %bb9
bb9:
  %t42 = load ptr, ptr %l4, !tbaa !29
  %t44 = getelementptr %"compiler/ast:Case", ptr %t42, i32 0, i32 5
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = call i1 @compiler_2fcheck_2eisNullLit(ptr %v0, ptr %t45)
  store i1 %t47, ptr %l26
  br label %bb10
bb10:
  %t48 = load i1, ptr %l26, !tbaa !21
  store i1 %t48, ptr %l20, !tbaa !21
  br label %bb11
bb11:
  %t49 = load i1, ptr %l20, !tbaa !21
  br i1 %t49, label %bb12, label %bb13
bb12:
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t51 = load i64, ptr %l2, !tbaa !24
  %t53 = add i64 %t51, 1
  store i64 %t53, ptr %l2, !tbaa !24
  br label %bb1
bb16:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2estoredMatch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l18 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Match", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t4, ptr %t6)
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/ast:Match", ptr %t9, i32 0, i32 3
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  store { i64, ptr } %t12, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  store i64 %t16, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t18 = load i64, ptr %l3, !tbaa !24
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = icmp slt i64 %t18, %t19
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l18, !tbaa !27
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr ptr, ptr %t30, i64 %t27
  %t32 = load ptr, ptr %t31, !tbaa !39
  %t35 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredCase(ptr %v0, ptr %v1, ptr %t32, ptr %t35)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb2
bb8:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/check:fixedInit" @compiler_2fcheck_3afixedInit_2ector(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %rv = alloca %"compiler/check:fixedInit"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/check:fixedInit" undef, ptr %a0, 0
  %t8 = insertvalue %"compiler/check:fixedInit" %t6, i32 %a1, 1
  store %"compiler/check:fixedInit" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:fixedInit", ptr %rv
  ret %"compiler/check:fixedInit" %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %v0, i1 %a0, i1 %a1, i1 %a2, i64 %a3, double %a4) #0 {
entry:
  %rv = alloca %"compiler/check:litv"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/check:litv" undef, i1 %a0, 0
  %t14 = insertvalue %"compiler/check:litv" %t12, i1 %a1, 1
  %t16 = insertvalue %"compiler/check:litv" %t14, i1 %a2, 2
  %t18 = insertvalue %"compiler/check:litv" %t16, i64 %a3, 3
  %t20 = insertvalue %"compiler/check:litv" %t18, double %a4, 4
  %t22 = insertvalue %"compiler/check:litv" %t20, i1 false, 5
  %t24 = insertvalue %"compiler/check:litv" %t22, i1 false, 6
  %t26 = insertvalue %"compiler/check:litv" %t24, i1 false, 7
  %t28 = insertvalue %"compiler/check:litv" %t26, i128 0, 8
  store %"compiler/check:litv" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local %"compiler/check:roFn" @compiler_2fcheck_3aroFn_2ector(ptr %v0, ptr %v1, i64 %a0, i64 %a1, { i64, [3 x i64] } %a2, { i64, ptr } %a3) #0 {
entry:
  %rv = alloca %"compiler/check:roFn"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/check:roFn" undef, i64 %a0, 0
  %t12 = insertvalue %"compiler/check:roFn" %t10, i64 %a1, 1
  %t14 = insertvalue %"compiler/check:roFn" %t12, { i64, [3 x i64] } %a2, 2
  %t16 = insertvalue %"compiler/check:roFn" %t14, { i64, ptr } %a3, 3
  store %"compiler/check:roFn" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:roFn", ptr %rv
  ret %"compiler/check:roFn" %rr
}

define dso_local %"compiler/check:setAt" @compiler_2fcheck_3asetAt_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, { i64, ptr } %a3, %"compiler/source:Span" %a4, i32 %a5) #0 {
entry:
  %lp9 = alloca ptr
  %rv = alloca %"compiler/check:setAt"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t8, ptr %lp9
  %t10 = load ptr, ptr %lp9
  store { i64, ptr } %a3, ptr %t10, !tbaa !27
  %t16 = insertvalue %"compiler/check:setAt" undef, ptr %a0, 0
  %t18 = insertvalue %"compiler/check:setAt" %t16, i64 %a1, 1
  %t20 = insertvalue %"compiler/check:setAt" %t18, { i64, ptr } %a2, 2
  %t21 = load ptr, ptr %lp9
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  %t23 = insertvalue %"compiler/check:setAt" %t20, { i64, ptr } %t22, 3
  %t25 = insertvalue %"compiler/check:setAt" %t23, %"compiler/source:Span" %a4, 4
  %t27 = insertvalue %"compiler/check:setAt" %t25, i32 %a5, 5
  store %"compiler/check:setAt" %t27, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:setAt", ptr %rv
  ret %"compiler/check:setAt" %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@__olang_empty_array = external constant [16 x i64]
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fgeneric_3aContext(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/generic:Context"
  %l3 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l5 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 160, i1 false)
  %t2 = getelementptr %"compiler/generic:Context", ptr %l1, i32 0, i32 2
  %t4 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_Ha3611e7042201d9891a66cc0e2a71916(ptr %v0, ptr %t2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l3
  %t6 = getelementptr %"compiler/generic:Context", ptr %l1, i32 0, i32 2
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t5, ptr %t6
  %t7 = getelementptr %"compiler/generic:Context", ptr %l1, i32 0, i32 3
  %t9 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_Ha3611e7042201d9891a66cc0e2a71916(ptr %v0, ptr %t7)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l5
  %t11 = getelementptr %"compiler/generic:Context", ptr %l1, i32 0, i32 3
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t10, ptr %t11
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 160, i1 false)
  br label %ret
ret:
  ret void
}

define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/source:Span", ptr %t1, i32 0, i32 0
  %t3 = load i32, ptr %t2, !tbaa !23
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/source:Span", ptr %t4, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  %t9 = icmp eq i32 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb4
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/source:Span", ptr %t11, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/source:Span", ptr %t14, i32 0, i32 1
  %t16 = load i32, ptr %t15, !tbaa !23
  %t19 = icmp eq i32 %t13, %t16
  br i1 %t19, label %bb3, label %bb1
bb3:
  br label %bb4
bb4:
  %t21 = load i1, ptr %l2, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d1 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"comptime." }>, align 8
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d3 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"__olang_" }>, align 8
@.d4 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"!=" }>, align 8
@.d5 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"==" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d7 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c".Len() > 0" }>, align 8
@.d8 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c".Len() == 0" }>, align 8
@.d9 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"true" }>, align 8
@.d10 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"false" }>, align 8
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d12 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"std/prelude/iterator" }>, align 8
@.d13 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Exhausted" }>, align 8
@.d14 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"is no struct" }>, align 8
@.d15 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"has a destructor" }>, align 8
@.d16 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"is no struct" }>, align 8
@.d17 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"is no struct" }>, align 8
@.d18 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"a.LanesLess(b)" }>, align 8
@.d19 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"b.LanesLess(a)" }>, align 8
@.d20 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"not b.LanesLess(a)" }>, align 8
@.d21 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"not a.LanesLess(b)" }>, align 8
@.d22 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d23 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"'xor'" }>, align 8
@.d24 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"MatMul" }>, align 8
@.d25 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'@'" }>, align 8
@.d26 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d27 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d28 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d29 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 4
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d30 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Here" }>, align 8
@.d31 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Pow" }>, align 8
@.d32 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"'**'" }>, align 8
@.d33 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Pow" }>, align 8
@.d34 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Pow" }>, align 8
@.d35 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"From" }>, align 8
define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3cU8_3e_26(ptr %a0, ptr %a1) #0 {
entry:
  %l6 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %a0, !tbaa !27
  %t4 = load { i64, ptr }, ptr %a1, !tbaa !27
  %t9 = call i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3cU8_3e({ i64, ptr } %t2, { i64, ptr } %t4)
  store i1 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i1, ptr %l6, !tbaa !21
  store i1 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d36 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\22" }>, align 8
@.d37 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"18446744073709551616" }>, align 8
@.d38 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d39 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Byte" }>, align 8
@.d40 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d41 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"I8" }>, align 8
@.d42 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I16" }>, align 8
@.d43 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d44 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d45 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d46 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U16" }>, align 8
@.d47 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U32" }>, align 8
@.d48 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d49 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F16" }>, align 8
@.d50 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"BF16" }>, align 8
@.d51 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F32" }>, align 8
@.d52 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
@.d53 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d54 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Array" }>, align 8
@.d55 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
@.d56 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d57 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"RefMut" }>, align 8
@.d58 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Ref" }>, align 8
@.d59 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Fields" }>, align 8
@.d60 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Cases" }>, align 8
@.d61 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Params" }>, align 8
@.d62 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"Results" }>, align 8
@.d63 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Functions" }>, align 8
@.d64 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"Methods" }>, align 8
@.d65 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Functions" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_Ha3611e7042201d9891a66cc0e2a71916(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = mul i64 %t24, 8
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l7, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = mul i64 %t33, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t36 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = mul i64 %t41, 8
  %t43 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l10, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = mul i64 %t50, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t53 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3cU8_3e({ i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i64
  %l6 = alloca i64
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t3, 0
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb7
bb2:
  store i64 0, ptr %l6, !tbaa !24
  br label %bb3
bb3:
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i8, ptr %t15, i64 %t13
  %t17 = load i8, ptr %t16, !tbaa !32
  %t18 = load i64, ptr %l6, !tbaa !24
  %t19 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr i8, ptr %t20, i64 %t18
  %t22 = load i8, ptr %t21, !tbaa !32
  %t25 = icmp eq i8 %t17, %t22
  br i1 %t25, label %bb6, label %bb1
bb5:
  br label %bb7
bb6:
  %t27 = load i64, ptr %l6, !tbaa !24
  %t28 = add i64 %t27, 1
  store i64 %t28, ptr %l6, !tbaa !24
  br label %bb3
bb7:
  %t29 = load i1, ptr %l2, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare i1 @compiler_2fcheck_2eisHexDigit(i8 %a0)
declare i1 @compiler_2fcheck_2eallBuilt(ptr %v0, { i64, ptr } %a0)
@olang_loc_195b5efb383c41db_4fe01bc12efac86f = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalType(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordCount(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFoldLength(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArrayLengthRange(ptr %v0, i64 %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/diagmsg:Msg" %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fcheck_2eRoStored = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i64 %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueFill(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFoldKnown(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezeroCalls(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2easkValue(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullableArray(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, i64 %a1, { i64, ptr } %a2, ptr %a3, i32 %a4, i32 %a5, i1 %a6)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
@olang_loc_ca088269e212954c_d643913a2551dac8 = external constant [0 x i8]
declare %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2, i1 %a3, i1 %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueRef(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i1 %a3)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, [1 x i64] } %a5)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_Hc07a7e56a24d8f1225398db99ea19a4b(ptr %v0, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ealtBinding(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3, i32 %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare %"compiler/typed:Bind" @compiler_2ftyped_3aBind_2ector(ptr %v0, ptr %v1, i32 %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBind_26_3e_2ePush_3ccompiler_2ftyped_3aBind_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckNow(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e__H9cb5d99387f926677a92c13412f9a8b2(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H2474e1fc3c93452d7765e4ed18f29a03(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunsettle(ptr %v0, ptr %a0)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyKey(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hf3bb75ba9d3f922b4d327e9d3c1adfb0(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare %"compiler/check:ownerAt" @compiler_2fcheck_3aownerAt_2ector(ptr %v0, i32 %a0, i1 %a1)
declare %"compiler/check:ownerAt" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownerOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_9c3920f9822030fe_f04ee3e76f867a92 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eOwnerBinding(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_He6be2b0836caba7ddc59483ff74db438(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorSetItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsErrVar(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsErrorSet(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %v0, i32 %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %a0, %"compiler/typed:Item" %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eEntriesOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorWord(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorItemKnown(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i1 @compiler_2fcheck_2eisWild(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_Hc8503b2b20cde402cc7bde6f68d96fc0(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrBind_3e_2eLen_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %a0)
declare %"compiler/check:errBind" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrBind_3e_2eAt_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTaskDefaultInStatement(ptr %v0)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5, i1 %a6, i32 %a7)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eSetVars(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_b7a62f2efaadd4af_1b278ceebf7ddf33 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDestructCount(ptr %v0, i64 %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTaskClauseNeedsDefault(ptr %v0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aCapture_26_3e_2eToA_H65e94094dadf75016f6073f244c91f3b(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecommutative(i32 %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %v0, i32 %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsSynth(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fsource_3aSpan_3e_2_H19fded22be32a91ca4084130356a325d(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2)
@olang_loc_fa3c94e3a612a0dd_4761343759351551 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomptimeCtx(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomptimeBody(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, i64 %a4, i32 %a5)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H3cc70d507a7fc767d013b59b12ee0a99(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esameLen(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisZeroLit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_d2b428b6a63c5a88_9cb41cac42ab9d54 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estructFields(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_26_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H06f4ae43b564aa38800728c5b9a6edfe(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_Hb04d670045d084ea2498d9030c4fbba9(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatWild(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_26959ece93e3b5d7_ef6153c643f98adb = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2epatTail(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H19842cc3f9f17801919cd111c108caa0(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estructDecl(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebyFieldRow(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4)
@olang_loc_dcaa30bcf0ceb4b1_7307533feb398e7d = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecoversRows(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrsChecked(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
@olang_loc_e375dcd56c8db7ae_8ebec7f18eafef7a = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyAttrs(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
@olang_loc_f43f80063d96068c_f8dacab5994fea88 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fgeneric_2eListFunctions = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFuncDescriptor(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3)
@G_2ecompiler_2fgeneric_2eListMethods = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eListBuilders = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eListFields = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eDescField = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eListCases = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eDescCase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eListParams = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eDescParam = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eDescResult = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@olang_loc_56167ce98e06ac0c_8ddb750e2bed0608 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescriptor(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i64 %a3, i64 %a4)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleft(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
declare %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eequality(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eand2(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3)
declare %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1, i1 %a2)
declare ptr @compiler_2fcheck_2eexprPath(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_21bd7d1c01cb29ff_7bd6b7239395673b = external constant [0 x i8]
declare %"compiler/ast:Path" @compiler_2fast_3aPath_2ector(ptr %v0, ptr %v1, %"compiler/source:Span" %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordIndex(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternParam(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallbackType(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePacked(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePackedByValueC(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eExternType(ptr %v0, ptr %v1, { i64, ptr } %a0)
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eExternResult(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitArray(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_369dcc443ccea639_2a432d0faa4fb925 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eisNullLit(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eIsOnlyNull(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eIsCaseWritten(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eIsNullOfNull(ptr %v0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrNonNull(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrNeverNull(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eIsNullOfValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArrayRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArrayIsNull(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneverNull(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNeverNull(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %v1, ptr %a0)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalledAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteNullableDecl(ptr %v0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/diagmsg:Msg" %a3)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_8803ccf5e870aa5b_cb8fe22003fe469f = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBodies(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
@olang_loc_dabacd8646f437fb_89d6d0c21504246f = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2ePush_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:laneNode" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eLen_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebreakUnless(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneUnType(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@G_2ecompiler_2fcheck_2eLaneUn = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneDecl(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare %"compiler/check:laneNode" @compiler_2fcheck_3alaneNode_2ector(ptr %v0, ptr %v1, i64 %a0, i32 %a1, %"compiler/source:Span" %a2, %"compiler/source:Span" %a3, i64 %a4, i64 %a5, i64 %a6, ptr %a7, i32 %a8, i64 %a9, i32 %a10)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneHold(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare { i32, %"compiler/source:Span" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H7d5384a5030fc995e793b3fe1f57e776(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteLiteralRangeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteLiteralRange(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteLiteralLocal(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eslotCall(ptr %v0, ptr %a0, i32 %a1, i64 %a2, %"compiler/source:Span" %a3)
@olang_loc_652199a1d15cfac6_f2a0b86627c88902 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, i64 %a5, ptr %a6, { i64, ptr } %a7, { i64, ptr } %a8)
@olang_loc_7509e56452997e5b_fb360af196d85db7 = external constant [0 x i8]
@olang_loc_ff81ff8210117a78_6f7a62fdc976c914 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, ptr } %a7)
@olang_loc_77a5603a1298311f_4bb819fe8c7bb9e3 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emustWrite(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i1 %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2erecordBody(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_9d659989a3d8e899_e17dd41770304f7d = external constant [0 x i8]
@olang_loc_f66b04275832bdf5_49261566e6ebbc09 = external constant [0 x i8]
@olang_loc_959932aa8b846e4e_2c1999e37dfb1a2 = external constant [0 x i8]
@olang_loc_f94ac378888081c5_5f597351c4418bf9 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_9e3e60c51c241998_753bf57c496fa07c = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompares(i32 %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrValues(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5)
declare i1 @compiler_2fcheck_2elaneTok(i32 %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneBinary(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOut(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowValues(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, ptr %a4)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLaneCompare(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2fcheck_2ebinaryOp(i32 %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOperandNotNumber(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOperandNotBool(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecommutedCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4, i64 %a5, i1 %a6)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMatmulUndeclared(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeqMethod(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2eopNeed(ptr %v0, i32 %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOperandsDiffer(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedErr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3, %"compiler/diagmsg:Msg" %a4)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOperandNotInt(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNotExtendedOp(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftInRange(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, %"compiler/source:Span" %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckedPrim(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNumbersDoNotMeet(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
declare i1 @compiler_2fcheck_2eintOnly(i32 %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePackedDestruct(ptr %v0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2efieldSpans(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteRawBits(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epackedWhat(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eLen_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePackedField(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_aac959024b9d6f15_55461456e770b1d1 = external constant [0 x i8]
declare %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %v0, i64 %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i1 %a4, i1 %a5)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eboundParam(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i64 %a2, ptr %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePlaceMember(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceType(ptr %v0, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePathOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eColumnAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_b23b0b3c83be0ad1_2f776aac88ec27cd = external constant [0 x i8]
@olang_loc_1f453287a90ee701_f75bf1e5be6f432d = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultMethods(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWordFields(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epathPart(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordText(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare { i64, ptr } @compiler_2fcheck_2efieldNames(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePayloadWordBare(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePlainWordCalled(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePayloadOf(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_97f728d69fa9714_fb4d660b7b54b10 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePayloadArgs(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsRaisedError(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eraisedArgs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare %"compiler/source:Span" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eRaisedAt(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleRaised(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eRaisedSettled(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleBy(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i32 %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eenumCase(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, ptr } %a5, { i64, ptr } %a6)
@olang_loc_ff4549fd04ada907_b78a4102fd7994db = external constant [0 x i8]
declare %"compiler/check:rawTable" @compiler_2fcheck_3arawTable_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, i1 %a1, { i64, ptr } %a2, { i64, ptr } %a3)
@olang_loc_674ca34a4d5f8d72_a138681dd06a86e = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRawWithoutType(ptr %v0)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclContext(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRawType(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_5479af00bceefeb1_f5b0eb753f441165 = external constant [0 x i8]
@olang_loc_4e17f4aa3948dea4_42025b20baf190f8 = external constant [0 x i8]
@olang_loc_15162faa0a6b8e7b_16d808b76471f267 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseNameSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFromCaseName(ptr %v0)
@olang_loc_c9b25feecc9d128e_1218ffeebcd03452 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2etextBytes(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_7a0bf9c228cd53f_3b674c8d006cd93 = external constant [0 x i8]
declare { i32, %"compiler/source:Span" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRawNotLiteral(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estrBytes(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRawRepeated(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/check:litv" @compiler_2fcheck_2elitv_2enoLit()
declare %"compiler/check:signMag" @compiler_2fcheck_2esignMag_2emagOf(%"compiler/check:litv" %a0)
declare %"compiler/check:litv" @compiler_2fcheck_2elitv_2eaddMag(i1 %a0, i128 %a1, i1 %a2, i128 %a3)
@olang_loc_bdfafd86356a320_3271504b736459c4 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2enumberLitsOnly(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2eisCharLit(ptr %v0, ptr %a0)
@olang_loc_cf3f79d848e44ed1_488edda033e9ba8d = external constant [0 x i8]
declare %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efoldPart(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRawNoFit(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawFits(ptr %v0, ptr %a0, %"compiler/check:litv" %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2elitText(ptr %v0, %"compiler/check:litv" %a0)
@olang_loc_e5e26ce82a519cb4_386557e0c1145fc8 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamDefault(ptr %v0, ptr %v1, ptr %a0, %"compiler/generic:Desc" %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescName(ptr %v0, ptr %v1, ptr %a0, %"compiler/generic:Desc" %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflNoDefault(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescType(ptr %v0, ptr %v1, ptr %a0, %"compiler/generic:Desc" %a1)
declare %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fgeneric_2eDescFunc = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultArg(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3, i1 %a4, i32 %a5, i32 %a6)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorDefault(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i32 %a3)
declare { i32, { i64, ptr } } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflTextOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eStrOfNothing(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantStr(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, i64 %a3)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v0, ptr %a0)
@olang_loc_e5b066603c2028fc_10f264a847d19698 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRestNoSlice(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eseqLen(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eseqSlice(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epattern(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i32 %a3, ptr %a4, i64 %a5)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
declare i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToUpper(i8 %a0)
@olang_loc_fbd40b14c0771014_77084db5763620a0 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hda627d7755eecb5b938ca977110d67b2(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20I6_Hd1b8e91149b724287340e79c8c928444(ptr %v0, ptr %a0)
declare void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %a0)
declare %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %a0)
declare %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexistingIn(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTaskDefaultExisting(ptr %v0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2esetsName(ptr %v0, { i64, ptr } %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitRef(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTraitExtendsNotTrait(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereachesTrait(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTraitExtendsItself(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTypeWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsClosedTrait(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTraitMemberOpen(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMembers(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/generic:Unmet" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMissing(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i1 %a3, i64 %a4)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTraitMemberMissing(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@olang_loc_21d2c8212e1ec20a_d97fbaae9e5bc606 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorNamed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2eCtorOwner(i32 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorVars(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 %a0)
declare %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFloat(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_86f2d648d7a819c5_fc1d6e84e063e4d9 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInferThroughBounds(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCtorVarsNotInferable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSigAt(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etwinBody(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetOrder(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eToArra_H50cbff9caa8a2389caf3e92da7e24507(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCaseType(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyInstance(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, i32 %a4)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSatisfies(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyUnique(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceWritable(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodSig(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnique(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_a50575fe0cbf16d0_d0ac681a5111f894 = external constant [0 x i8]
@olang_loc_60e1b0f1da45c3fd_13c1ffbfc1f1b5a1 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistItems(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/check:reflList" %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflBind(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDecide(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_ef99e54d7427d8e6_6c42201a9dddf792 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflFilterUndecided(ptr %v0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflUnbind(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eViewsOf(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_a969f4d227859e_fa1675b60a8d81a2 = external constant [0 x i8]
@olang_loc_7bdd4e800dbf10f8_a5805e1380ae00f4 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ematchExisting(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2etryExisting(ptr %v0, ptr %a0)
@olang_loc_4533f85d93cedd17_b546fe5da9c85083 = external constant [0 x i8]
@olang_loc_b94a36f209a3c5e5_113c4160723e4631 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2eheldTry(ptr %v0, ptr %v1, %"compiler/source:Span" %a0, ptr %a1)
@olang_loc_338177df999812ed_466eceed6b347ea1 = external constant [0 x i8]
@olang_loc_db94e874d036c6ef_7db06dea6929eb03 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2elimitIndex(ptr %v0, { i64, ptr } %a0)
@olang_loc_29f8057051902f50_e91b4d9ed5822c7c = external constant [0 x i8]
declare void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2estoredCase(ptr %v0, ptr %v1, ptr %a0, ptr %a1)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
