; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/emit:Emitter" = type { ptr, ptr, ptr, ptr, i1, i1, i1, i1, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, i64, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i1, i1, { i64, ptr }, i1, i64, i64, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/lower:Lowerer" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i32 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
%"compiler/load:Import" = type { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, { i64, ptr }, i64, i64 }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/emit:fnEm" = type { ptr, ptr, { i64, [2 x i64] }, %"std/prelude/text:StringBuilder", %"std/prelude/text:StringBuilder", %"std/prelude/text:StringBuilder", i64, i64, i64, i32, i1, i1, i1, i1, { i64, ptr }, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/text:StringBuilder", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, ptr } }
%"compiler/mir:Fn" = type { { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64 }
%"compiler/mir:Place" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/mir:BasicBlock" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [8 x i64] } }
%"compiler/mir:Local" = type { i32, %"compiler/source:Span", i32, i32, { i64, [1 x i64] } }
%"compiler/mir:ScopeInfo" = type { i32, i32, i32, %"compiler/source:Span", i32 }
%"compiler/emit:Object" = type { { i64, ptr }, i32, { i64, ptr }, i64 }
define dso_local void @compiler_2femit_2eHomeInst_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 -3, ptr @G_2ecompiler_2femit_2eHomeInst, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2eHomeLoc_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 -4, ptr @G_2ecompiler_2femit_2eHomeLoc, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eadaptKey(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s0, ptr %t4, i32 %a1)
  store { i64, ptr } %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/emit:Emitter", ptr %t9, i32 0, i32 3
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t16 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s0, ptr %t12, i32 %a2)
  store { i64, ptr } %t16, ptr %l10
  br label %bb2
bb2:
  %t17 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t22 = add i64 %t19, %t21
  %t23 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 1
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t26 = add i64 %t22, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t18, i64 %t19)
  %t28 = getelementptr i8, ptr %t27, i64 %t19
  call void @olang_textcopy(ptr %t28, ptr %t20, i64 %t21)
  %t29 = getelementptr i8, ptr %t28, i64 %t21
  call void @olang_textcopy(ptr %t29, ptr %t24, i64 %t25)
  %t30 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t27, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t40 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t38)
  store { i64, ptr } %t40, ptr %l13
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t41 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t41, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ebodySym(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i32
  %l17 = alloca i64
  %l24 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l81 = alloca ptr
  %l83 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l107 = alloca i32
  %l108 = alloca i64
  %l110 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l119 = alloca { i64, ptr }
  %l123 = alloca { i64, ptr }
  %l130 = alloca { i64, ptr }
  %l134 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.builder
  %s18room = alloca [64 x i8], align 8
  %s19 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/emit:Emitter", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/lower:Lowerer", ptr %t9, i32 0, i32 1
  %t12 = load i64, ptr %l1, !tbaa !24
  %t15 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t11, i64 %t12)
  store ptr %t15, ptr %l24
  br label %bb1
bb1:
  %t16 = load ptr, ptr %l24, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Body", ptr %t16, i32 0, i32 1
  %t20 = load { i64, [2 x i64] }, ptr %t19
  store { i64, [2 x i64] } %t20, ptr %l4
  %t22 = load { i64, [2 x i64] }, ptr %l4
  %t24 = extractvalue { i64, [2 x i64] } %t22, 0
  %t25 = icmp eq i64 %t24, 0
  br i1 %t25, label %bb2, label %bb3
bb2:
  %t27 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  store i64 %t29, ptr %l5, !tbaa !24
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/emit:Emitter", ptr %t31, i32 0, i32 0
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceName(ptr %v0, ptr %t34, i64 %t35)
  store { i64, ptr } %t38, ptr %l34
  br label %bb5
bb5:
  %t39 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 1
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t42 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t41)
  call void @olang_textcopy(ptr %t42, ptr %t40, i64 %t41)
  %t43 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  store { i64, ptr } %t44, ptr %l27, !tbaa !27
  br label %bb66
bb6:
  %t46 = load { i64, [2 x i64] }, ptr %l4
  %t48 = extractvalue { i64, [2 x i64] } %t46, 0
  %t49 = icmp eq i64 %t48, 1
  br i1 %t49, label %bb7, label %bb8
bb7:
  %t51 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t52 = getelementptr { i32, i32 }, ptr %t51, i32 0, i32 0
  %t53 = load i32, ptr %t52
  store i32 %t53, ptr %l6, !tbaa !23
  %t55 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t56 = getelementptr { i32, i32 }, ptr %t55, i32 0, i32 1
  %t57 = load i32, ptr %t56
  store i32 %t57, ptr %l7, !tbaa !23
  br label %bb9
bb8:
  br label %bb16
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t59 = load ptr, ptr %l2, !tbaa !29
  %t60 = load i32, ptr %l6, !tbaa !23
  %t63 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s3, ptr %t59, i32 %t60)
  store { i64, ptr } %t63, ptr %l42
  br label %bb10
bb10:
  %t64 = load i32, ptr %l7, !tbaa !23
  %t66 = icmp eq i32 %t64, 0
  br i1 %t66, label %bb11, label %bb12
bb11:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l45, !tbaa !27
  br label %bb14
bb12:
  %t68 = load ptr, ptr %l2, !tbaa !29
  %t69 = load i32, ptr %l7, !tbaa !23
  %t72 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanonList(ptr %v0, ptr %s3, ptr %t68, i32 %t69)
  store { i64, ptr } %t72, ptr %l48
  br label %bb13
bb13:
  %t73 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t74 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t75 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 1
  %t77 = extractvalue { i64, ptr } %t75, 0
  %t78 = add i64 %t74, %t77
  %t79 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t81 = add i64 %t78, %t80
  %t82 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t81)
  call void @olang_textcopy(ptr %t82, ptr %t73, i64 %t74)
  %t83 = getelementptr i8, ptr %t82, i64 %t74
  call void @olang_textcopy(ptr %t83, ptr %t76, i64 %t77)
  %t84 = getelementptr i8, ptr %t83, i64 %t77
  call void @olang_textcopy(ptr %t84, ptr %t79, i64 %t80)
  %t85 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t82, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = extractvalue { i64, ptr } %t86, 1
  %t90 = mul i64 %t88, 1
  %t91 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t90)
  call void @llvm.memcpy.p0.p0.i64(ptr %t91, ptr %t89, i64 %t90, i1 false)
  %t92 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  store { i64, ptr } %t93, ptr %l45, !tbaa !27
  br label %bb14
bb14:
  %t95 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t95, 1
  %t97 = extractvalue { i64, ptr } %t95, 0
  %t98 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t99 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t100 = add i64 %t97, %t99
  %t101 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 1
  %t103 = extractvalue { i64, ptr } %t101, 0
  %t104 = add i64 %t100, %t103
  %t105 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t104)
  call void @olang_textcopy(ptr %t105, ptr %t96, i64 %t97)
  %t106 = getelementptr i8, ptr %t105, i64 %t97
  call void @olang_textcopy(ptr %t106, ptr %t98, i64 %t99)
  %t107 = getelementptr i8, ptr %t106, i64 %t99
  call void @olang_textcopy(ptr %t107, ptr %t102, i64 %t103)
  %t108 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t105, 1
  %t111 = extractvalue { i64, ptr } %t109, 0
  %t112 = extractvalue { i64, ptr } %t109, 1
  %t113 = mul i64 %t111, 1
  %t114 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t113)
  call void @llvm.memcpy.p0.p0.i64(ptr %t114, ptr %t112, i64 %t113, i1 false)
  %t115 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t114, 1
  %t118 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t116)
  store { i64, ptr } %t118, ptr %l53
  br label %bb15
bb15:
  %t119 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t119, ptr %l27, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  br label %bb66
bb16:
  %t120 = load { i64, [2 x i64] }, ptr %l4
  %t122 = extractvalue { i64, [2 x i64] } %t120, 0
  %t123 = icmp eq i64 %t122, 3
  br i1 %t123, label %bb17, label %bb18
bb17:
  %t125 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t126 = getelementptr { i32 }, ptr %t125, i32 0, i32 0
  %t127 = load i32, ptr %t126
  store i32 %t127, ptr %l8, !tbaa !23
  br label %bb19
bb18:
  br label %bb22
bb19:
  store %olang.scope zeroinitializer, ptr %s6
  %t129 = load ptr, ptr %l2, !tbaa !29
  %t130 = load i32, ptr %l8, !tbaa !23
  %t133 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s6, ptr %t129, i32 %t130)
  store { i64, ptr } %t133, ptr %l59
  br label %bb20
bb20:
  %t134 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t134, 1
  %t136 = extractvalue { i64, ptr } %t134, 0
  %t137 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t138 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t139 = add i64 %t136, %t138
  %t140 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t139)
  call void @olang_textcopy(ptr %t140, ptr %t135, i64 %t136)
  %t141 = getelementptr i8, ptr %t140, i64 %t136
  call void @olang_textcopy(ptr %t141, ptr %t137, i64 %t138)
  %t142 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t140, 1
  %t145 = extractvalue { i64, ptr } %t143, 0
  %t146 = extractvalue { i64, ptr } %t143, 1
  %t147 = mul i64 %t145, 1
  %t148 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t147)
  call void @llvm.memcpy.p0.p0.i64(ptr %t148, ptr %t146, i64 %t147, i1 false)
  %t149 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t148, 1
  %t152 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t150)
  store { i64, ptr } %t152, ptr %l62
  br label %bb21
bb21:
  %t153 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t153, ptr %l27, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb66
bb22:
  %t154 = load { i64, [2 x i64] }, ptr %l4
  %t156 = extractvalue { i64, [2 x i64] } %t154, 0
  %t157 = icmp eq i64 %t156, 4
  br i1 %t157, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  %t159 = load i64, ptr %l1, !tbaa !24
  %t160 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t161 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t163 = call i64 @__olang_fmt_i64(ptr null, i64 %t159)
  %t164 = add i64 %t161, %t163
  %t165 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t164)
  call void @olang_textcopy(ptr %t165, ptr %t160, i64 %t161)
  %t166 = getelementptr i8, ptr %t165, i64 %t161
  %t167 = call i64 @__olang_fmt_i64(ptr %t166, i64 %t159)
  %t168 = insertvalue { i64, ptr } undef, i64 %t164, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr %t165, 1
  store { i64, ptr } %t169, ptr %l27, !tbaa !27
  br label %bb66
bb26:
  %t171 = load { i64, [2 x i64] }, ptr %l4
  %t173 = extractvalue { i64, [2 x i64] } %t171, 0
  %t174 = icmp eq i64 %t173, 5
  br i1 %t174, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load i64, ptr %l1, !tbaa !24
  %t180 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etestSym(ptr %v0, ptr %v1, ptr %t176, i64 %t177)
  store { i64, ptr } %t180, ptr %l71
  br label %bb30
bb30:
  %t181 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t181, ptr %l27, !tbaa !27
  br label %bb66
bb31:
  %t182 = load { i64, [2 x i64] }, ptr %l4
  %t184 = extractvalue { i64, [2 x i64] } %t182, 0
  %t185 = icmp eq i64 %t184, 6
  br i1 %t185, label %bb32, label %bb33
bb32:
  %t187 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t188 = getelementptr { i64, i32 }, ptr %t187, i32 0, i32 0
  %t189 = load i64, ptr %t188
  store i64 %t189, ptr %l9, !tbaa !24
  %t191 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t192 = getelementptr { i64, i32 }, ptr %t191, i32 0, i32 1
  %t193 = load i32, ptr %t192
  store i32 %t193, ptr %l10, !tbaa !23
  br label %bb34
bb33:
  br label %bb38
bb34:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/emit:Emitter", ptr %t195, i32 0, i32 0
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t200 = getelementptr %"compiler/generic:Program", ptr %t198, i32 0, i32 0
  %t201 = load ptr, ptr %t200, !tbaa !29
  %t203 = getelementptr %"compiler/load:Loader", ptr %t201, i32 0, i32 5
  %t204 = load i64, ptr %l9, !tbaa !24
  %t207 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t203, i64 %t204)
  store ptr %t207, ptr %l81
  br label %bb35
bb35:
  %t208 = load ptr, ptr %l81, !tbaa !29
  %t210 = getelementptr %"compiler/load:Module", ptr %t208, i32 0, i32 2
  %t211 = load { i64, ptr }, ptr %t210, !tbaa !27
  store { i64, ptr } %t211, ptr %l83, !tbaa !27
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load i32, ptr %l10, !tbaa !23
  %t216 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %t212, i32 %t213)
  store { i64, ptr } %t216, ptr %l86
  br label %bb36
bb36:
  %t217 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t218 = extractvalue { i64, ptr } %t217, 1
  %t219 = extractvalue { i64, ptr } %t217, 0
  %t220 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t221 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t222 = add i64 %t219, %t221
  %t223 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t224 = extractvalue { i64, ptr } %t223, 1
  %t225 = extractvalue { i64, ptr } %t223, 0
  %t226 = add i64 %t222, %t225
  %t227 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t228 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t229 = add i64 %t226, %t228
  %t230 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t229)
  call void @olang_textcopy(ptr %t230, ptr %t218, i64 %t219)
  %t231 = getelementptr i8, ptr %t230, i64 %t219
  call void @olang_textcopy(ptr %t231, ptr %t220, i64 %t221)
  %t232 = getelementptr i8, ptr %t231, i64 %t221
  call void @olang_textcopy(ptr %t232, ptr %t224, i64 %t225)
  %t233 = getelementptr i8, ptr %t232, i64 %t225
  call void @olang_textcopy(ptr %t233, ptr %t227, i64 %t228)
  %t234 = insertvalue { i64, ptr } undef, i64 %t229, 0
  %t235 = insertvalue { i64, ptr } %t234, ptr %t230, 1
  %t237 = extractvalue { i64, ptr } %t235, 0
  %t238 = extractvalue { i64, ptr } %t235, 1
  %t239 = mul i64 %t237, 1
  %t240 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t239)
  call void @llvm.memcpy.p0.p0.i64(ptr %t240, ptr %t238, i64 %t239, i1 false)
  %t241 = insertvalue { i64, ptr } undef, i64 %t237, 0
  %t242 = insertvalue { i64, ptr } %t241, ptr %t240, 1
  %t244 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t242)
  store { i64, ptr } %t244, ptr %l89
  br label %bb37
bb37:
  %t245 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t245, ptr %l27, !tbaa !27
  br label %bb66
bb38:
  %t246 = load { i64, [2 x i64] }, ptr %l4
  %t248 = extractvalue { i64, [2 x i64] } %t246, 0
  %t249 = icmp eq i64 %t248, 2
  br i1 %t249, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  %t251 = load i64, ptr %l1, !tbaa !24
  %t252 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t253 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t255 = call i64 @__olang_fmt_i64(ptr null, i64 %t251)
  %t256 = add i64 %t253, %t255
  %t257 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t256)
  call void @olang_textcopy(ptr %t257, ptr %t252, i64 %t253)
  %t258 = getelementptr i8, ptr %t257, i64 %t253
  %t259 = call i64 @__olang_fmt_i64(ptr %t258, i64 %t251)
  %t260 = insertvalue { i64, ptr } undef, i64 %t256, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t257, 1
  store { i64, ptr } %t261, ptr %l27, !tbaa !27
  br label %bb66
bb42:
  %t263 = load { i64, [2 x i64] }, ptr %l4
  %t265 = extractvalue { i64, [2 x i64] } %t263, 0
  %t266 = icmp eq i64 %t265, 7
  br i1 %t266, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  %t268 = load i64, ptr %l1, !tbaa !24
  %t269 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t270 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t272 = call i64 @__olang_fmt_i64(ptr null, i64 %t268)
  %t273 = add i64 %t270, %t272
  %t274 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t273)
  call void @olang_textcopy(ptr %t274, ptr %t269, i64 %t270)
  %t275 = getelementptr i8, ptr %t274, i64 %t270
  %t276 = call i64 @__olang_fmt_i64(ptr %t275, i64 %t268)
  %t277 = insertvalue { i64, ptr } undef, i64 %t273, 0
  %t278 = insertvalue { i64, ptr } %t277, ptr %t274, 1
  store { i64, ptr } %t278, ptr %l27, !tbaa !27
  br label %bb66
bb46:
  %t280 = load { i64, [2 x i64] }, ptr %l4
  %t282 = extractvalue { i64, [2 x i64] } %t280, 0
  %t283 = icmp eq i64 %t282, 8
  br i1 %t283, label %bb47, label %bb48
bb47:
  %t285 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t286 = getelementptr { i32, i32, i64 }, ptr %t285, i32 0, i32 0
  %t287 = load i32, ptr %t286
  store i32 %t287, ptr %l11, !tbaa !23
  %t289 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t290 = getelementptr { i32, i32, i64 }, ptr %t289, i32 0, i32 1
  %t291 = load i32, ptr %t290
  store i32 %t291, ptr %l12
  %t293 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t294 = getelementptr { i32, i32, i64 }, ptr %t293, i32 0, i32 2
  %t295 = load i64, ptr %t294
  store i64 %t295, ptr %l13, !tbaa !24
  br label %bb49
bb48:
  br label %bb53
bb49:
  store %olang.scope zeroinitializer, ptr %s17
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load i32, ptr %l11, !tbaa !23
  %t300 = sext i32 %t298 to i64
  %t303 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ebodySym(ptr %v0, ptr %s17, ptr %t297, i64 %t300)
  store { i64, ptr } %t303, ptr %l106
  br label %bb50
bb50:
  %t304 = load i32, ptr %l12
  store i32 %t304, ptr %l107
  %t305 = load i64, ptr %l13, !tbaa !24
  store i64 %t305, ptr %l108, !tbaa !24
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s18
  store ptr %s18room, ptr %s18
  %t306 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t307 = extractvalue { i64, ptr } %t306, 1
  %t308 = extractvalue { i64, ptr } %t306, 0
  call void @__olang_sb_put(ptr %s18, ptr %t307, i64 %t308)
  %t309 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t310 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t309, i64 %t310)
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aContractKind(ptr %s18, ptr %l107, i64 0)
  br label %bb51
bb51:
  %t312 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t313 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t312, i64 %t313)
  %t314 = load i64, ptr %l108, !tbaa !24
  %t315 = call ptr @__olang_sb_room(ptr %s18, i64 24)
  %t316 = call i64 @__olang_fmt_i64(ptr %t315, i64 %t314)
  call void @__olang_sb_add(ptr %s18, i64 %t316)
  %t317 = load ptr, ptr %s18
  %t318 = getelementptr %olang.builder, ptr %s18, i32 0, i32 1
  %t319 = load i64, ptr %t318
  %t320 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t319)
  call void @olang_textcopy(ptr %t320, ptr %t317, i64 %t319)
  %t321 = insertvalue { i64, ptr } undef, i64 %t319, 0
  %t322 = insertvalue { i64, ptr } %t321, ptr %t320, 1
  store { i64, ptr } %t322, ptr %l110, !tbaa !27
  %t323 = getelementptr %olang.builder, ptr %s18, i32 0, i32 3
  %t324 = load ptr, ptr %t323
  %t325 = icmp ne ptr %t324, null
  br i1 %t325, label %sbgrew.326, label %sbdone.327
sbgrew.326:
  call void @__olang_sb_done(ptr %s18)
  br label %sbdone.327
sbdone.327:
  %t328 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t329 = extractvalue { i64, ptr } %t328, 0
  %t330 = extractvalue { i64, ptr } %t328, 1
  %t331 = mul i64 %t329, 1
  %t332 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t331)
  call void @llvm.memcpy.p0.p0.i64(ptr %t332, ptr %t330, i64 %t331, i1 false)
  %t333 = insertvalue { i64, ptr } undef, i64 %t329, 0
  %t334 = insertvalue { i64, ptr } %t333, ptr %t332, 1
  %t336 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t334)
  store { i64, ptr } %t336, ptr %l112
  br label %bb52
bb52:
  %t337 = load { i64, ptr }, ptr %l112, !tbaa !27
  store { i64, ptr } %t337, ptr %l27, !tbaa !27
  call void @__olang_scope_close(ptr %s17)
  br label %bb66
bb53:
  %t338 = load { i64, [2 x i64] }, ptr %l4
  %t340 = extractvalue { i64, [2 x i64] } %t338, 0
  %t341 = icmp eq i64 %t340, 9
  br i1 %t341, label %bb54, label %bb55
bb54:
  %t343 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t344 = getelementptr { i64, i64 }, ptr %t343, i32 0, i32 0
  %t345 = load i64, ptr %t344
  store i64 %t345, ptr %l14, !tbaa !24
  %t347 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t348 = getelementptr { i64, i64 }, ptr %t347, i32 0, i32 1
  %t349 = load i64, ptr %t348
  store i64 %t349, ptr %l15, !tbaa !24
  br label %bb56
bb55:
  br label %bb59
bb56:
  store %olang.scope zeroinitializer, ptr %s19
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t352 = load i64, ptr %l14, !tbaa !24
  %t355 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etableName(ptr %v0, ptr %s19, ptr %t351, i64 %t352)
  store { i64, ptr } %t355, ptr %l119
  br label %bb57
bb57:
  %t356 = load i64, ptr %l15, !tbaa !24
  %t357 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t358 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t359 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t360 = extractvalue { i64, ptr } %t359, 1
  %t361 = extractvalue { i64, ptr } %t359, 0
  %t362 = add i64 %t358, %t361
  %t363 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t364 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t365 = add i64 %t362, %t364
  %t367 = call i64 @__olang_fmt_i64(ptr null, i64 %t356)
  %t368 = add i64 %t365, %t367
  %t369 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t368)
  call void @olang_textcopy(ptr %t369, ptr %t357, i64 %t358)
  %t370 = getelementptr i8, ptr %t369, i64 %t358
  call void @olang_textcopy(ptr %t370, ptr %t360, i64 %t361)
  %t371 = getelementptr i8, ptr %t370, i64 %t361
  call void @olang_textcopy(ptr %t371, ptr %t363, i64 %t364)
  %t372 = getelementptr i8, ptr %t371, i64 %t364
  %t373 = call i64 @__olang_fmt_i64(ptr %t372, i64 %t356)
  %t374 = insertvalue { i64, ptr } undef, i64 %t368, 0
  %t375 = insertvalue { i64, ptr } %t374, ptr %t369, 1
  %t377 = extractvalue { i64, ptr } %t375, 0
  %t378 = extractvalue { i64, ptr } %t375, 1
  %t379 = mul i64 %t377, 1
  %t380 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t379)
  call void @llvm.memcpy.p0.p0.i64(ptr %t380, ptr %t378, i64 %t379, i1 false)
  %t381 = insertvalue { i64, ptr } undef, i64 %t377, 0
  %t382 = insertvalue { i64, ptr } %t381, ptr %t380, 1
  %t384 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t382)
  store { i64, ptr } %t384, ptr %l123
  br label %bb58
bb58:
  %t385 = load { i64, ptr }, ptr %l123, !tbaa !27
  store { i64, ptr } %t385, ptr %l27, !tbaa !27
  call void @__olang_scope_close(ptr %s19)
  br label %bb66
bb59:
  %t386 = load { i64, [2 x i64] }, ptr %l4
  %t388 = extractvalue { i64, [2 x i64] } %t386, 0
  %t389 = icmp eq i64 %t388, 10
  br i1 %t389, label %bb60, label %bb61
bb60:
  %t391 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t392 = getelementptr { i32, i64 }, ptr %t391, i32 0, i32 0
  %t393 = load i32, ptr %t392
  store i32 %t393, ptr %l16, !tbaa !23
  %t395 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t396 = getelementptr { i32, i64 }, ptr %t395, i32 0, i32 1
  %t397 = load i64, ptr %t396
  store i64 %t397, ptr %l17, !tbaa !24
  br label %bb62
bb61:
  br label %bb65
bb62:
  store %olang.scope zeroinitializer, ptr %s21
  %t399 = load ptr, ptr %l0, !tbaa !29
  %t400 = load i32, ptr %l16, !tbaa !23
  %t403 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecanonOf(ptr %v0, ptr %s21, ptr %t399, i32 %t400)
  store { i64, ptr } %t403, ptr %l130
  br label %bb63
bb63:
  %t404 = load i64, ptr %l17, !tbaa !24
  %t405 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t406 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t407 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t408 = extractvalue { i64, ptr } %t407, 1
  %t409 = extractvalue { i64, ptr } %t407, 0
  %t410 = add i64 %t406, %t409
  %t411 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t412 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t413 = add i64 %t410, %t412
  %t415 = call i64 @__olang_fmt_i64(ptr null, i64 %t404)
  %t416 = add i64 %t413, %t415
  %t417 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t416)
  call void @olang_textcopy(ptr %t417, ptr %t405, i64 %t406)
  %t418 = getelementptr i8, ptr %t417, i64 %t406
  call void @olang_textcopy(ptr %t418, ptr %t408, i64 %t409)
  %t419 = getelementptr i8, ptr %t418, i64 %t409
  call void @olang_textcopy(ptr %t419, ptr %t411, i64 %t412)
  %t420 = getelementptr i8, ptr %t419, i64 %t412
  %t421 = call i64 @__olang_fmt_i64(ptr %t420, i64 %t404)
  %t422 = insertvalue { i64, ptr } undef, i64 %t416, 0
  %t423 = insertvalue { i64, ptr } %t422, ptr %t417, 1
  %t425 = extractvalue { i64, ptr } %t423, 0
  %t426 = extractvalue { i64, ptr } %t423, 1
  %t427 = mul i64 %t425, 1
  %t428 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t427)
  call void @llvm.memcpy.p0.p0.i64(ptr %t428, ptr %t426, i64 %t427, i1 false)
  %t429 = insertvalue { i64, ptr } undef, i64 %t425, 0
  %t430 = insertvalue { i64, ptr } %t429, ptr %t428, 1
  %t432 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t430)
  store { i64, ptr } %t432, ptr %l134
  br label %bb64
bb64:
  %t433 = load { i64, ptr }, ptr %l134, !tbaa !27
  store { i64, ptr } %t433, ptr %l27, !tbaa !27
  call void @__olang_scope_close(ptr %s21)
  br label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_de1fe604fb5e87cf_ff4728625cff78d3)
  unreachable
bb66:
  %t434 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t434, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecoroDecls(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t1, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d17, i32 0, i32 1) }, { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d18, i32 0, i32 1) })
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t3, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d19, i32 0, i32 1) }, { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d20, i32 0, i32 1) })
  br label %bb2
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t5, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d21, i32 0, i32 1) }, { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d22, i32 0, i32 1) })
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t7, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d23, i32 0, i32 1) }, { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d24, i32 0, i32 1) })
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t9, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d25, i32 0, i32 1) }, { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d26, i32 0, i32 1) })
  br label %bb5
bb5:
  %t11 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t11, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d27, i32 0, i32 1) }, { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d28, i32 0, i32 1) })
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t13, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d29, i32 0, i32 1) }, { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d30, i32 0, i32 1) })
  br label %bb7
bb7:
  %t15 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t15, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d31, i32 0, i32 1) }, { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d32, i32 0, i32 1) })
  br label %bb8
bb8:
  %t17 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t17, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d33, i32 0, i32 1) }, { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d34, i32 0, i32 1) })
  br label %bb9
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t19, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d35, i32 0, i32 1) }, { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d36, i32 0, i32 1) })
  br label %bb10
bb10:
  %t21 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t21, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d37, i32 0, i32 1) }, { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d38, i32 0, i32 1) })
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l1 = alloca i64
  %s0 = alloca %olang.scope
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = load i64, ptr %l1, !tbaa !24
  %t3 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t6 = call i64 @__olang_fmt_i64(ptr null, i64 %t2)
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  %t10 = call i64 @__olang_fmt_i64(ptr %t9, i64 %t2)
  %t11 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t8, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t15 = extractvalue { i64, ptr } %t12, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  %t20 = load i64, ptr @G_2ecompiler_2femit_2eHomeShared, !tbaa !24
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  %t26 = call i64 @__olang_fmt_i64(ptr null, i64 %t21)
  %t27 = add i64 %t24, %t26
  %t28 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t29 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t30 = add i64 %t27, %t29
  %t32 = extractvalue { i64, ptr } %a2, 1
  %t33 = extractvalue { i64, ptr } %a2, 0
  %t34 = add i64 %t30, %t33
  %t35 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t37 = add i64 %t34, %t36
  %t38 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t37)
  call void @olang_textcopy(ptr %t38, ptr %t23, i64 %t24)
  %t39 = getelementptr i8, ptr %t38, i64 %t24
  %t40 = call i64 @__olang_fmt_i64(ptr %t39, i64 %t21)
  %t41 = getelementptr i8, ptr %t39, i64 %t26
  call void @olang_textcopy(ptr %t41, ptr %t28, i64 %t29)
  %t42 = getelementptr i8, ptr %t41, i64 %t29
  call void @olang_textcopy(ptr %t42, ptr %t32, i64 %t33)
  %t43 = getelementptr i8, ptr %t42, i64 %t33
  call void @olang_textcopy(ptr %t43, ptr %t35, i64 %t36)
  %t44 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t38, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = extractvalue { i64, ptr } %t45, 1
  %t49 = mul i64 %t47, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t48, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %a0, { i64, ptr } %t19, i64 %t20, { i64, ptr } %t52, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d43, i32 0, i32 1) })
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eexternRet(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l6 = alloca i32
  %l10 = alloca i1
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t4, i32 %a1)
  store i32 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load i32, ptr %l6, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load i32, ptr %l2, !tbaa !23
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t14 = icmp eq i32 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb4
bb3:
  %t16 = load i32, ptr %l2, !tbaa !23
  %t17 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t20 = icmp eq i32 %t16, %t17
  store i1 %t20, ptr %l10, !tbaa !21
  br label %bb4
bb4:
  %t22 = load i1, ptr %l10, !tbaa !21
  br i1 %t22, label %bb5, label %bb6
bb5:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d44, i32 0, i32 1) }, ptr %l14, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t23, ptr %l15, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 0
  store i64 %t25, ptr %l16, !tbaa !24
  %t26 = load i64, ptr %l16, !tbaa !24
  %t27 = mul i64 %t26, 1
  %t28 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t27)
  %t29 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  store { i64, ptr } %t30, ptr %l17, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = load i64, ptr %l16, !tbaa !24
  %t36 = mul i64 %t35, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t32, ptr %t34, i64 %t36, i1 false)
  %t37 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t37, ptr %l15, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t38, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i32, ptr %l2, !tbaa !23
  %t43 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %v1, ptr %t39, i32 %t40)
  store { i64, ptr } %t43, ptr %l20
  br label %bb8
bb8:
  %t44 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t44, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobalOrder(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca i64
  %l15 = alloca i64
  %l20 = alloca i64
  %l24 = alloca i64
  %l26 = alloca i64
  %l31 = alloca i64
  %l36 = alloca ptr
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  store ptr %l1, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t6 = load i64, ptr %l4, !tbaa !24
  store i64 %t6, ptr %l13, !tbaa !24
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t7)
  store i64 %t9, ptr %l15
  br label %bb3
bb3:
  %t10 = load i64, ptr %l13, !tbaa !24
  %t11 = load i64, ptr %l15, !tbaa !24
  %t12 = icmp slt i64 %t10, %t11
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb4, label %bb5
bb4:
  br label %bb31
bb5:
  br label %bb6
bb6:
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t17 = load i64, ptr %l4, !tbaa !24
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t16, i64 %t17)
  store i64 %t20, ptr %l20
  br label %bb7
bb7:
  %t21 = load i64, ptr %l20, !tbaa !24
  store i64 %t21, ptr %l5, !tbaa !24
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/emit:Emitter", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 41
  store ptr %t27, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  %t29 = load i64, ptr %l7, !tbaa !24
  store i64 %t29, ptr %l24, !tbaa !24
  %t30 = load ptr, ptr %l6, !tbaa !29
  %t32 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t30)
  store i64 %t32, ptr %l26
  br label %bb9
bb9:
  %t33 = load i64, ptr %l24, !tbaa !24
  %t34 = load i64, ptr %l26, !tbaa !24
  %t35 = icmp slt i64 %t33, %t34
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb10, label %bb11
bb10:
  br label %bb29
bb11:
  br label %bb12
bb12:
  %t39 = load ptr, ptr %l6, !tbaa !29
  %t40 = load i64, ptr %l7, !tbaa !24
  %t43 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t39, i64 %t40)
  store i64 %t43, ptr %l31
  br label %bb13
bb13:
  %t44 = load i64, ptr %l31, !tbaa !24
  store i64 %t44, ptr %l8, !tbaa !24
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/emit:Emitter", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = getelementptr %"compiler/lower:Lowerer", ptr %t48, i32 0, i32 1
  %t51 = load i64, ptr %l8, !tbaa !24
  %t54 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t50, i64 %t51)
  store ptr %t54, ptr %l36
  br label %bb14
bb14:
  %t55 = load ptr, ptr %l36, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Body", ptr %t55, i32 0, i32 1
  %t58 = load { i64, [2 x i64] }, ptr %t57
  store { i64, [2 x i64] } %t58, ptr %l9
  %t60 = load { i64, [2 x i64] }, ptr %l9
  %t62 = extractvalue { i64, [2 x i64] } %t60, 0
  %t63 = icmp eq i64 %t62, 6
  br i1 %t63, label %bb15, label %bb16
bb15:
  %t65 = getelementptr { i64, [2 x i64] }, ptr %l9, i32 0, i32 1
  %t66 = getelementptr { i64, i32 }, ptr %t65, i32 0, i32 0
  %t67 = load i64, ptr %t66
  store i64 %t67, ptr %l10, !tbaa !24
  br label %bb17
bb16:
  br label %bb22
bb17:
  %t69 = load i64, ptr %l10, !tbaa !24
  %t70 = load i64, ptr %l5, !tbaa !24
  %t73 = icmp eq i64 %t69, %t70
  br i1 %t73, label %bb18, label %bb19
bb18:
  %t75 = load ptr, ptr %lp2
  %t76 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t75, i64 %t76)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  br label %bb27
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_5ad0f5036011b2cd_7d6f5911e17dc851)
  unreachable
bb27:
  br label %bb28
bb28:
  %t79 = load i64, ptr %l7, !tbaa !24
  %t81 = add i64 %t79, 1
  store i64 %t81, ptr %l7, !tbaa !24
  br label %bb8
bb29:
  br label %bb30
bb30:
  %t83 = load i64, ptr %l4, !tbaa !24
  %t85 = add i64 %t83, 1
  store i64 %t85, ptr %l4, !tbaa !24
  br label %bb2
bb31:
  %t87 = load ptr, ptr %lp2
  %t88 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t87
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t88, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2egroupOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 15
  %t7 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store { i64, ptr } %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t11 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t9, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d45, i32 0, i32 1) })
  store i1 %t11, ptr %l8
  br label %bb2
bb2:
  %t12 = load i1, ptr %l8, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb6
bb4:
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t15 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t13, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d46, i32 0, i32 1) })
  store i1 %t15, ptr %l11
  br label %bb5
bb5:
  %t16 = load i1, ptr %l11, !tbaa !21
  store i1 %t16, ptr %l9, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l9, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i64 1, ptr %l12, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l12, !tbaa !24
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t18 = load i64, ptr %l12, !tbaa !24
  store i64 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisGlobalInit(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i32
  %l4 = alloca i1
  %l13 = alloca ptr
  %l16 = alloca i1
  %rv = alloca i1
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb14
bb3:
  %t12 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/lower:Lowerer", ptr %t13, i32 0, i32 1
  %t16 = load i32, ptr %l2, !tbaa !23
  %t18 = sext i32 %t16 to i64
  %t21 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t15, i64 %t18)
  store ptr %t21, ptr %l13
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l13, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Body", ptr %t22, i32 0, i32 1
  %t25 = load { i64, [2 x i64] }, ptr %t24
  %t29 = extractvalue { i64, [2 x i64] } %t25, 0
  %t30 = icmp eq i64 %t29, 6
  br i1 %t30, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb13
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_616c6f643d0ce9fd_dfe523617d4699c1)
  unreachable
bb13:
  %t32 = load i1, ptr %l16, !tbaa !21
  store i1 %t32, ptr %l4, !tbaa !21
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_b37ed008d0080fcc_cc9019489ebc5a30)
  unreachable
bb19:
  %t33 = load i1, ptr %l4, !tbaa !21
  store i1 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisLambda(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l7 = alloca ptr
  %l10 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/lower:Lowerer", ptr %t4, i32 0, i32 1
  %t10 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t6, i64 %a1)
  store ptr %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l7, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 1
  %t14 = load { i64, [2 x i64] }, ptr %t13
  %t18 = extractvalue { i64, [2 x i64] } %t14, 0
  %t19 = icmp eq i64 %t18, 4
  br i1 %t19, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb5
bb4:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_7f6c4a9881f0c77f_244fd8f3f85b2bab)
  unreachable
bb10:
  %t21 = load i1, ptr %l10, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2elocBase(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca i32
  %l22 = alloca i1
  %l25 = alloca i1
  %l29 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l41 = alloca i1
  %l47 = alloca ptr
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l63 = alloca ptr
  %l67 = alloca i64
  %l69 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 -1, ptr %l2, !tbaa !24
  store i1 false, ptr %l3, !tbaa !21
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l4, !tbaa !23
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t10 = load i32, ptr %l4, !tbaa !23
  %t12 = sext i32 %t10 to i64
  store i64 %t12, ptr %l2, !tbaa !24
  br label %bb13
bb4:
  %t14 = load { i64, [2 x i64] }, ptr %l1
  %t16 = extractvalue { i64, [2 x i64] } %t14, 0
  %t17 = icmp eq i64 %t16, 1
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t19 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t20 = getelementptr { i32 }, ptr %t19, i32 0, i32 0
  %t21 = load i32, ptr %t20
  store i32 %t21, ptr %l5, !tbaa !23
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t23 = load i32, ptr %l5, !tbaa !23
  %t25 = sext i32 %t23 to i64
  store i64 %t25, ptr %l2, !tbaa !24
  store i1 true, ptr %l3, !tbaa !21
  br label %bb13
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_1cb2b0b1c80ab6bb_ff3b7bcb0dec81bf)
  unreachable
bb13:
  %t27 = load i64, ptr %l2, !tbaa !24
  %t29 = icmp slt i64 %t27, 0
  br i1 %t29, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb17
bb15:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i64, ptr %l2, !tbaa !24
  %t35 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisLambda(ptr %v0, ptr %t31, i64 %t32)
  store i1 %t35, ptr %l25
  br label %bb16
bb16:
  %t36 = load i1, ptr %l25, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %l22, !tbaa !21
  br label %bb17
bb17:
  %t39 = load i1, ptr %l22, !tbaa !21
  br i1 %t39, label %bb18, label %bb19
bb18:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load { i64, [2 x i64] }, ptr %l1
  %t44 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %v1, ptr %t40, { i64, [2 x i64] } %t41)
  store { i64, ptr } %t44, ptr %l29
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t45 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t45, ptr %rv
  br label %ret
bb21:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/emit:Emitter", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/lower:Lowerer", ptr %t49, i32 0, i32 1
  %t52 = load i64, ptr %l2, !tbaa !24
  %t55 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t51, i64 %t52)
  store ptr %t55, ptr %l34
  br label %bb22
bb22:
  %t56 = load ptr, ptr %l34, !tbaa !29
  %t58 = getelementptr %"compiler/typed:Body", ptr %t56, i32 0, i32 4
  %t59 = getelementptr %"compiler/source:Span", ptr %t58, i32 0, i32 0
  %t60 = load i32, ptr %t59, !tbaa !23
  %t62 = sext i32 %t60 to i64
  store i64 %t62, ptr %l6, !tbaa !24
  %t64 = load i64, ptr %l2, !tbaa !24
  store i64 %t64, ptr %l7, !tbaa !24
  br label %bb23
bb23:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i64, ptr %l7, !tbaa !24
  %t70 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisLambda(ptr %v0, ptr %t66, i64 %t67)
  store i1 %t70, ptr %l41
  br label %bb24
bb24:
  %t71 = load i1, ptr %l41, !tbaa !21
  %t72 = xor i1 %t71, true
  br i1 %t72, label %bb25, label %bb26
bb25:
  br label %bb39
bb26:
  br label %bb27
bb27:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/emit:Emitter", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/lower:Lowerer", ptr %t77, i32 0, i32 1
  %t80 = load i64, ptr %l7, !tbaa !24
  %t83 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t79, i64 %t80)
  store ptr %t83, ptr %l47
  br label %bb28
bb28:
  %t84 = load ptr, ptr %l47, !tbaa !29
  %t86 = getelementptr %"compiler/typed:Body", ptr %t84, i32 0, i32 1
  %t87 = load { i64, [2 x i64] }, ptr %t86
  store { i64, [2 x i64] } %t87, ptr %l8
  %t89 = load { i64, [2 x i64] }, ptr %l8
  %t91 = extractvalue { i64, [2 x i64] } %t89, 0
  %t92 = icmp eq i64 %t91, 4
  br i1 %t92, label %bb29, label %bb30
bb29:
  %t94 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t95 = getelementptr { i32 }, ptr %t94, i32 0, i32 0
  %t96 = load i32, ptr %t95
  store i32 %t96, ptr %l9, !tbaa !23
  br label %bb31
bb30:
  br label %bb32
bb31:
  %t98 = load i32, ptr %l9, !tbaa !23
  %t100 = sext i32 %t98 to i64
  store i64 %t100, ptr %l7, !tbaa !24
  br label %bb37
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb39
bb36:
  call void @__olang_check_failed(ptr @olang_loc_dd4469a9ae312a3a_602f574df5758ebe)
  unreachable
bb37:
  br label %bb38
bb38:
  br label %bb23
bb39:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load i64, ptr %l7, !tbaa !24
  %t106 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ebodySym(ptr %v0, ptr %s0, ptr %t102, i64 %t103)
  store { i64, ptr } %t106, ptr %l57
  br label %bb40
bb40:
  %t107 = load i64, ptr %l6, !tbaa !24
  store i64 %t107, ptr %l58, !tbaa !24
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/emit:Emitter", ptr %t108, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = getelementptr %"compiler/lower:Lowerer", ptr %t111, i32 0, i32 1
  %t114 = load i64, ptr %l7, !tbaa !24
  %t117 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t113, i64 %t114)
  store ptr %t117, ptr %l63
  br label %bb41
bb41:
  %t118 = load ptr, ptr %l63, !tbaa !29
  %t120 = getelementptr %"compiler/typed:Body", ptr %t118, i32 0, i32 4
  %t121 = getelementptr %"compiler/source:Span", ptr %t120, i32 0, i32 0
  %t122 = load i32, ptr %t121, !tbaa !23
  %t124 = sext i32 %t122 to i64
  %t125 = load i64, ptr %l58, !tbaa !24
  %t127 = sub i64 %t125, %t124
  store i64 %t127, ptr %l67, !tbaa !24
  %t128 = load i1, ptr %l3, !tbaa !21
  br i1 %t128, label %bb42, label %bb43
bb42:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d47, i32 0, i32 1) }, ptr %l69, !tbaa !27
  br label %bb44
bb43:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %l69, !tbaa !27
  br label %bb44
bb44:
  %t130 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 1
  %t132 = extractvalue { i64, ptr } %t130, 0
  %t133 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t134 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t135 = add i64 %t132, %t134
  %t136 = load i64, ptr %l67, !tbaa !24
  %t137 = call i64 @__olang_fmt_i64(ptr null, i64 %t136)
  %t138 = add i64 %t135, %t137
  %t139 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 1
  %t141 = extractvalue { i64, ptr } %t139, 0
  %t142 = add i64 %t138, %t141
  %t143 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t142)
  call void @olang_textcopy(ptr %t143, ptr %t131, i64 %t132)
  %t144 = getelementptr i8, ptr %t143, i64 %t132
  call void @olang_textcopy(ptr %t144, ptr %t133, i64 %t134)
  %t145 = getelementptr i8, ptr %t144, i64 %t134
  %t146 = call i64 @__olang_fmt_i64(ptr %t145, i64 %t136)
  %t147 = getelementptr i8, ptr %t145, i64 %t137
  call void @olang_textcopy(ptr %t147, ptr %t140, i64 %t141)
  %t148 = insertvalue { i64, ptr } undef, i64 %t142, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t143, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t149, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2emathIntrinsic(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i1
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l26 = alloca i1
  %l28 = alloca i1
  %l30 = alloca i1
  %l31 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %l40 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i32
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l52 = alloca i32
  %l53 = alloca { i64, ptr }
  %l55 = alloca i32
  %l62 = alloca i1
  %l63 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca i32
  %l69 = alloca i32
  %l71 = alloca i1
  %l73 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l75 = alloca i64
  %l76 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l89 = alloca i32
  %l91 = alloca i32
  %l93 = alloca i1
  %l95 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l97 = alloca i64
  %l98 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t6, ptr %l15, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t7, 0
  store i64 %t10, ptr %l18, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  store i64 %t12, ptr %l19, !tbaa !24
  %t13 = icmp sge i64 0, 0
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i64, ptr %l18, !tbaa !24
  %t16 = icmp sle i64 0, %t15
  br i1 %t16, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_e68028fa4f0f457e_ac0c180900ac4e62)
  unreachable
bb3:
  %t18 = load i64, ptr %l18, !tbaa !24
  %t19 = load i64, ptr %l19, !tbaa !24
  %t20 = icmp sle i64 %t18, %t19
  br i1 %t20, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_e68028fa4f0f457e_ac0c180900ac4e62)
  unreachable
bb5:
  %t22 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = load i64, ptr %l18, !tbaa !24
  %t25 = getelementptr i8, ptr %t23, i64 0
  %t26 = sub i64 %t24, 0
  %t27 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t25, 1
  store { i64, ptr } %t28, ptr %l4, !tbaa !27
  store i1 false, ptr %l5, !tbaa !21
  %t30 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t31 = load ptr, ptr @__olang_prog_scope
  %t34 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %t31, ptr %v1, ptr @G_2ecompiler_2femit_2emathExact, { i64, ptr } %t30)
  store i1 %t34, ptr %l26
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_e68028fa4f0f457e_ac0c180900ac4e62)
  unreachable
bb7:
  %t35 = load i1, ptr %l26, !tbaa !21
  %t36 = xor i1 %t35, true
  br i1 %t36, label %bb8, label %bb9
bb8:
  %t38 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t40 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v1, ptr %s0, { i64, ptr } %t38, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) })
  store i1 %t40, ptr %l30
  br label %bb10
bb9:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb11
bb10:
  %t41 = load i1, ptr %l30, !tbaa !21
  store i1 %t41, ptr %l28, !tbaa !21
  br label %bb11
bb11:
  %t42 = load i1, ptr %l28, !tbaa !21
  br i1 %t42, label %bb12, label %bb13
bb12:
  %t43 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t43, ptr %l31, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t48 = sub i64 %t46, 1
  store i64 %t48, ptr %l34, !tbaa !24
  %t49 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  store i64 %t50, ptr %l35, !tbaa !24
  %t51 = icmp sge i64 0, 0
  br i1 %t51, label %bb14, label %bb15
bb13:
  br label %bb20
bb14:
  %t53 = load i64, ptr %l34, !tbaa !24
  %t54 = icmp sle i64 0, %t53
  br i1 %t54, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_8b9f7f38fd25c7fb_28bbaeaad75485df)
  unreachable
bb16:
  %t56 = load i64, ptr %l34, !tbaa !24
  %t57 = load i64, ptr %l35, !tbaa !24
  %t58 = icmp sle i64 %t56, %t57
  br i1 %t58, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_8b9f7f38fd25c7fb_28bbaeaad75485df)
  unreachable
bb18:
  %t60 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = load i64, ptr %l34, !tbaa !24
  %t63 = getelementptr i8, ptr %t61, i64 0
  %t64 = sub i64 %t62, 0
  %t65 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t63, 1
  store { i64, ptr } %t66, ptr %l4, !tbaa !27
  store i1 true, ptr %l5, !tbaa !21
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_8b9f7f38fd25c7fb_28bbaeaad75485df)
  unreachable
bb20:
  %t68 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t69 = load ptr, ptr @__olang_prog_scope
  %t72 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %t69, ptr %v1, ptr @G_2ecompiler_2femit_2emathExact, { i64, ptr } %t68)
  %t73 = extractvalue { i32, i64 } %t72, 1
  %t74 = extractvalue { i32, i64 } %t72, 0
  store i32 %t74, ptr %l44
  %t75 = icmp ne i32 %t74, 0
  br i1 %t75, label %bb22, label %ok.76
ok.76:
  store i64 %t73, ptr %l43
  br label %bb21
bb21:
  %t77 = load i64, ptr %l43, !tbaa !24
  store i64 %t77, ptr %l40, !tbaa !24
  br label %bb24
bb22:
  br label %bb23
bb23:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d51, i32 0, i32 1) }, ptr %l45, !tbaa !27
  %t78 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t78, ptr %l46, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 0
  store i64 %t80, ptr %l47, !tbaa !24
  %t81 = load i64, ptr %l47, !tbaa !24
  %t82 = mul i64 %t81, 1
  %t83 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t82)
  %t84 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t83, 1
  store { i64, ptr } %t85, ptr %l48, !tbaa !27
  %t86 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = load i64, ptr %l47, !tbaa !24
  %t91 = mul i64 %t90, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t87, ptr %t89, i64 %t91, i1 false)
  %t92 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t92, ptr %l46, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t93 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t93, ptr %rv
  br label %ret
bb24:
  %t94 = load i64, ptr %l40, !tbaa !24
  store i64 %t94, ptr %l6, !tbaa !24
  %t95 = load ptr, ptr %l3, !tbaa !29
  store ptr %t95, ptr %l49, !tbaa !29
  %t96 = load ptr, ptr %l3, !tbaa !29
  %t97 = load i32, ptr %l2, !tbaa !23
  %t100 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t96, i32 %t97)
  store i32 %t100, ptr %l52
  br label %bb25
bb25:
  %t101 = load ptr, ptr %l49, !tbaa !29
  %t102 = load i32, ptr %l52, !tbaa !23
  %t103 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t101, i32 %t102)
  store { i64, ptr } %t103, ptr %l53
  br label %bb26
bb26:
  %t104 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t104, ptr %l7, !tbaa !27
  %t105 = load i1, ptr %l5, !tbaa !21
  br i1 %t105, label %bb27, label %bb28
bb27:
  store i32 13, ptr %l55
  br label %bb29
bb28:
  store i32 14, ptr %l55
  br label %bb29
bb29:
  %t109 = load i32, ptr %l55
  store i32 %t109, ptr %l8
  %t110 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t110, 0
  %t113 = load i64, ptr %l6, !tbaa !24
  %t116 = icmp ne i64 %t112, %t113
  br i1 %t116, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb35
bb31:
  %t118 = load ptr, ptr %l3, !tbaa !29
  store ptr %t118, ptr %l63, !tbaa !29
  %t119 = load ptr, ptr %l3, !tbaa !29
  %t120 = load i32, ptr %l2, !tbaa !23
  %t123 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t119, i32 %t120)
  store i32 %t123, ptr %l66
  br label %bb32
bb32:
  %t124 = load ptr, ptr %l63, !tbaa !29
  %t125 = load i32, ptr %l66, !tbaa !23
  %t126 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t124, i32 %t125)
  store i32 %t126, ptr %l67
  br label %bb33
bb33:
  %t127 = load i32, ptr %l8
  store i32 %t127, ptr %l69
  %t130 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l67, ptr %l69)
  store i1 %t130, ptr %l71
  br label %bb34
bb34:
  %t131 = load i1, ptr %l71, !tbaa !21
  %t132 = xor i1 %t131, true
  store i1 %t132, ptr %l62, !tbaa !21
  br label %bb35
bb35:
  %t134 = load i1, ptr %l62, !tbaa !21
  br i1 %t134, label %bb36, label %bb37
bb36:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d52, i32 0, i32 1) }, ptr %l73, !tbaa !27
  %t135 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t135, ptr %l74, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 0
  store i64 %t137, ptr %l75, !tbaa !24
  %t138 = load i64, ptr %l75, !tbaa !24
  %t139 = mul i64 %t138, 1
  %t140 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t139)
  %t141 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t140, 1
  store { i64, ptr } %t142, ptr %l76, !tbaa !27
  %t143 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = load i64, ptr %l75, !tbaa !24
  %t148 = mul i64 %t147, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t144, ptr %t146, i64 %t148, i1 false)
  %t149 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t149, ptr %l74, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t150 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t150, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  %t151 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t151, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t153 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t153, 0
  store i64 %t155, ptr %l11, !tbaa !24
  br label %bb39
bb39:
  %t157 = load i64, ptr %l10, !tbaa !24
  %t158 = load i64, ptr %l11, !tbaa !24
  %t161 = icmp slt i64 %t157, %t158
  %t163 = xor i1 %t161, true
  br i1 %t163, label %bb40, label %bb41
bb40:
  br label %bb49
bb41:
  br label %bb42
bb42:
  %t165 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t165, ptr %l84, !tbaa !27
  %t166 = load i64, ptr %l10, !tbaa !24
  %t168 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = getelementptr i32, ptr %t169, i64 %t166
  %t171 = load i32, ptr %t170, !tbaa !33
  %t173 = load ptr, ptr %l3, !tbaa !29
  %t177 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t173, i32 %t171)
  store i32 %t177, ptr %l89
  br label %bb43
bb43:
  %t178 = load i32, ptr %l8
  store i32 %t178, ptr %l91
  %t181 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l89, ptr %l91)
  store i1 %t181, ptr %l93
  br label %bb44
bb44:
  %t182 = load i1, ptr %l93, !tbaa !21
  %t183 = xor i1 %t182, true
  br i1 %t183, label %bb45, label %bb46
bb45:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d53, i32 0, i32 1) }, ptr %l95, !tbaa !27
  %t185 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t185, ptr %l96, !tbaa !27
  %t186 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t186, 0
  store i64 %t187, ptr %l97, !tbaa !24
  %t188 = load i64, ptr %l97, !tbaa !24
  %t189 = mul i64 %t188, 1
  %t190 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t189)
  %t191 = insertvalue { i64, ptr } undef, i64 %t188, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t190, 1
  store { i64, ptr } %t192, ptr %l98, !tbaa !27
  %t193 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t194 = load ptr, ptr %t193, !tbaa !27
  %t195 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = load i64, ptr %l97, !tbaa !24
  %t198 = mul i64 %t197, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t194, ptr %t196, i64 %t198, i1 false)
  %t199 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t199, ptr %l96, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t200 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t200, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t201 = load i64, ptr %l10, !tbaa !24
  %t203 = add i64 %t201, 1
  store i64 %t203, ptr %l10, !tbaa !24
  br label %bb39
bb49:
  %t205 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t205, ptr %l101, !tbaa !27
  %t206 = load i1, ptr %l5, !tbaa !21
  br i1 %t206, label %bb50, label %bb51
bb50:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d54, i32 0, i32 1) }, ptr %l103, !tbaa !27
  br label %bb52
bb51:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %l103, !tbaa !27
  br label %bb52
bb52:
  %t208 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t209 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t210 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t210, 1
  %t212 = extractvalue { i64, ptr } %t210, 0
  %t213 = add i64 %t209, %t212
  %t214 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d57, i32 0, i32 1) }, 1
  %t215 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d57, i32 0, i32 1) }, 0
  %t216 = add i64 %t213, %t215
  %t217 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t218 = extractvalue { i64, ptr } %t217, 1
  %t219 = extractvalue { i64, ptr } %t217, 0
  %t220 = add i64 %t216, %t219
  %t221 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t220)
  call void @olang_textcopy(ptr %t221, ptr %t208, i64 %t209)
  %t222 = getelementptr i8, ptr %t221, i64 %t209
  call void @olang_textcopy(ptr %t222, ptr %t211, i64 %t212)
  %t223 = getelementptr i8, ptr %t222, i64 %t212
  call void @olang_textcopy(ptr %t223, ptr %t214, i64 %t215)
  %t224 = getelementptr i8, ptr %t223, i64 %t215
  call void @olang_textcopy(ptr %t224, ptr %t218, i64 %t219)
  %t225 = insertvalue { i64, ptr } undef, i64 %t220, 0
  %t226 = insertvalue { i64, ptr } %t225, ptr %t221, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t226, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2enoTable(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = load i64, ptr @G_2ecompiler_2femit_2eHomeShared, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %a0, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d58, i32 0, i32 1) }, i64 %t2, { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d59, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d43, i32 0, i32 1) })
  br label %bb1
bb1:
  store { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d60, i32 0, i32 1) }, ptr %l3, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t5, ptr %l4, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = mul i64 %t8, 1
  %t10 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l6, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = load i64, ptr %l5, !tbaa !24
  %t18 = mul i64 %t17, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %t16, i64 %t18, i1 false)
  %t19 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t19, ptr %l4, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t20 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t20, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2erecodeText(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, i32 %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l18 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l33 = alloca i64
  %l36 = alloca i64
  %l60 = alloca ptr
  %l61 = alloca i64
  %l62 = alloca i64
  %l65 = alloca { i64, ptr }
  %l68 = alloca i64
  %l73 = alloca { i64, ptr }
  %l75 = alloca i64
  %l83 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l85 = alloca i64
  %l86 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t4, i32 %a3)
  store { i64, ptr } %t10, ptr %l18
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t11, ptr %l6, !tbaa !27
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t15 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  %t18 = extractvalue { i64, ptr } %t13, 1
  %t19 = extractvalue { i64, ptr } %t13, 0
  %t20 = add i64 %t16, %t19
  %t21 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t23 = add i64 %t20, %t22
  %t25 = extractvalue { i64, ptr } %t14, 1
  %t26 = extractvalue { i64, ptr } %t14, 0
  %t27 = add i64 %t23, %t26
  %t28 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t29 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  %t30 = add i64 %t27, %t29
  %t31 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t30)
  call void @olang_textcopy(ptr %t31, ptr %t15, i64 %t16)
  %t32 = getelementptr i8, ptr %t31, i64 %t16
  call void @olang_textcopy(ptr %t32, ptr %t18, i64 %t19)
  %t33 = getelementptr i8, ptr %t32, i64 %t19
  call void @olang_textcopy(ptr %t33, ptr %t21, i64 %t22)
  %t34 = getelementptr i8, ptr %t33, i64 %t22
  call void @olang_textcopy(ptr %t34, ptr %t25, i64 %t26)
  %t35 = getelementptr i8, ptr %t34, i64 %t26
  call void @olang_textcopy(ptr %t35, ptr %t28, i64 %t29)
  %t36 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t31, 1
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t40 = extractvalue { i64, ptr } %t37, 1
  %t41 = mul i64 %t39, 1
  %t42 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t41)
  call void @llvm.memcpy.p0.p0.i64(ptr %t42, ptr %t40, i64 %t41, i1 false)
  %t43 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t12, { i64, ptr } %t44)
  br label %bb2
bb2:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, ptr %l24, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t47, ptr %l25, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 0
  store i64 %t49, ptr %l26, !tbaa !24
  %t50 = load i64, ptr %l26, !tbaa !24
  %t51 = mul i64 %t50, 1
  %t52 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t51)
  %t53 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  store { i64, ptr } %t54, ptr %l27, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = load i64, ptr %l26, !tbaa !24
  %t60 = mul i64 %t59, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t56, ptr %t58, i64 %t60, i1 false)
  %t61 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t61, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t62 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t62, 0
  store i64 %t64, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t66 = load i64, ptr %l9, !tbaa !24
  %t67 = load i64, ptr %l8, !tbaa !24
  %t70 = icmp sgt i64 %t66, %t67
  br i1 %t70, label %bb3, label %bb4
bb3:
  %t72 = load i64, ptr %l10, !tbaa !24
  %t74 = icmp sgt i64 %t72, 0
  br i1 %t74, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb8
bb5:
  %t76 = load i64, ptr %l9, !tbaa !24
  %t77 = load i64, ptr %l8, !tbaa !24
  %t80 = sub i64 %t76, %t77
  %t81 = load i64, ptr %l10, !tbaa !24
  %t84 = add i64 %t80, %t81
  %t86 = sub i64 %t84, 1
  %t87 = load i64, ptr %l10, !tbaa !24
  %t90 = sdiv i64 %t86, %t87
  store i64 %t90, ptr %l36, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb7
bb7:
  %t92 = load i64, ptr %l36, !tbaa !24
  store i64 %t92, ptr %l33, !tbaa !24
  br label %bb8
bb8:
  %t93 = load i64, ptr %l33, !tbaa !24
  store i64 %t93, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t94 = load i64, ptr %l12, !tbaa !24
  %t95 = load i64, ptr %l11, !tbaa !24
  %t98 = icmp slt i64 %t94, %t95
  %t100 = xor i1 %t98, true
  br i1 %t100, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb11:
  br label %bb12
bb12:
  %t102 = load i64, ptr %l8, !tbaa !24
  %t103 = load i64, ptr %l12, !tbaa !24
  %t104 = load i64, ptr %l10, !tbaa !24
  %t107 = mul i64 %t103, %t104
  %t110 = add i64 %t102, %t107
  store i64 %t110, ptr %l13, !tbaa !24
  %t112 = load ptr, ptr %l1, !tbaa !29
  %t113 = load i64, ptr %l13, !tbaa !24
  %t114 = load i64, ptr %l13, !tbaa !24
  %t116 = add i64 %t114, 1
  %t117 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t118 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  %t120 = call i64 @__olang_fmt_i64(ptr null, i64 %t113)
  %t121 = add i64 %t118, %t120
  %t122 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t123 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t124 = add i64 %t121, %t123
  %t126 = call i64 @__olang_fmt_i64(ptr null, i64 %t116)
  %t127 = add i64 %t124, %t126
  %t128 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t129 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t130 = add i64 %t127, %t129
  %t131 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t130)
  call void @olang_textcopy(ptr %t131, ptr %t117, i64 %t118)
  %t132 = getelementptr i8, ptr %t131, i64 %t118
  %t133 = call i64 @__olang_fmt_i64(ptr %t132, i64 %t113)
  %t134 = getelementptr i8, ptr %t132, i64 %t120
  call void @olang_textcopy(ptr %t134, ptr %t122, i64 %t123)
  %t135 = getelementptr i8, ptr %t134, i64 %t123
  %t136 = call i64 @__olang_fmt_i64(ptr %t135, i64 %t116)
  %t137 = getelementptr i8, ptr %t135, i64 %t126
  call void @olang_textcopy(ptr %t137, ptr %t128, i64 %t129)
  %t138 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t131, 1
  %t141 = extractvalue { i64, ptr } %t139, 0
  %t142 = extractvalue { i64, ptr } %t139, 1
  %t143 = mul i64 %t141, 1
  %t144 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t143)
  call void @llvm.memcpy.p0.p0.i64(ptr %t144, ptr %t142, i64 %t143, i1 false)
  %t145 = insertvalue { i64, ptr } undef, i64 %t141, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t144, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s3, ptr %t112, { i64, ptr } %t146)
  br label %bb13
bb13:
  %t149 = load ptr, ptr %l1, !tbaa !29
  store ptr %t149, ptr %l60, !tbaa !29
  %t150 = load i64, ptr %l13, !tbaa !24
  store i64 %t150, ptr %l61, !tbaa !24
  %t151 = load i64, ptr %l13, !tbaa !24
  store i64 %t151, ptr %l62, !tbaa !24
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t154, ptr %l65, !tbaa !27
  %t155 = load i64, ptr %l13, !tbaa !24
  %t157 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = getelementptr i32, ptr %t158, i64 %t155
  %t160 = load i32, ptr %t159, !tbaa !33
  %t164 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eposition(ptr %v0, ptr %t152, i32 %a4, i32 %t160)
  store i64 %t164, ptr %l68
  br label %bb14
bb14:
  %t165 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t166 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t167 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t168 = load i64, ptr %l61, !tbaa !24
  %t169 = call i64 @__olang_fmt_i64(ptr null, i64 %t168)
  %t170 = add i64 %t167, %t169
  %t171 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d69, i32 0, i32 1) }, 1
  %t172 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d69, i32 0, i32 1) }, 0
  %t173 = add i64 %t170, %t172
  %t174 = load i64, ptr %l62, !tbaa !24
  %t175 = call i64 @__olang_fmt_i64(ptr null, i64 %t174)
  %t176 = add i64 %t173, %t175
  %t177 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t178 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t179 = add i64 %t176, %t178
  %t180 = load i64, ptr %l68, !tbaa !24
  %t181 = call i64 @__olang_fmt_i64(ptr null, i64 %t180)
  %t182 = add i64 %t179, %t181
  %t183 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t184 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t185 = add i64 %t182, %t184
  %t187 = extractvalue { i64, ptr } %t165, 1
  %t188 = extractvalue { i64, ptr } %t165, 0
  %t189 = add i64 %t185, %t188
  %t190 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d71, i32 0, i32 1) }, 1
  %t191 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d71, i32 0, i32 1) }, 0
  %t192 = add i64 %t189, %t191
  %t193 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t192)
  call void @olang_textcopy(ptr %t193, ptr %t166, i64 %t167)
  %t194 = getelementptr i8, ptr %t193, i64 %t167
  %t195 = call i64 @__olang_fmt_i64(ptr %t194, i64 %t168)
  %t196 = getelementptr i8, ptr %t194, i64 %t169
  call void @olang_textcopy(ptr %t196, ptr %t171, i64 %t172)
  %t197 = getelementptr i8, ptr %t196, i64 %t172
  %t198 = call i64 @__olang_fmt_i64(ptr %t197, i64 %t174)
  %t199 = getelementptr i8, ptr %t197, i64 %t175
  call void @olang_textcopy(ptr %t199, ptr %t177, i64 %t178)
  %t200 = getelementptr i8, ptr %t199, i64 %t178
  %t201 = call i64 @__olang_fmt_i64(ptr %t200, i64 %t180)
  %t202 = getelementptr i8, ptr %t200, i64 %t181
  call void @olang_textcopy(ptr %t202, ptr %t183, i64 %t184)
  %t203 = getelementptr i8, ptr %t202, i64 %t184
  call void @olang_textcopy(ptr %t203, ptr %t187, i64 %t188)
  %t204 = getelementptr i8, ptr %t203, i64 %t188
  call void @olang_textcopy(ptr %t204, ptr %t190, i64 %t191)
  %t205 = insertvalue { i64, ptr } undef, i64 %t192, 0
  %t206 = insertvalue { i64, ptr } %t205, ptr %t193, 1
  %t208 = extractvalue { i64, ptr } %t206, 0
  %t209 = extractvalue { i64, ptr } %t206, 1
  %t210 = mul i64 %t208, 1
  %t211 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t210)
  call void @llvm.memcpy.p0.p0.i64(ptr %t211, ptr %t209, i64 %t210, i1 false)
  %t212 = insertvalue { i64, ptr } undef, i64 %t208, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %t211, 1
  %t214 = load ptr, ptr %l60, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s3, ptr %t214, { i64, ptr } %t213)
  br label %bb15
bb15:
  %t216 = load i64, ptr %l13, !tbaa !24
  %t217 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t218 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  %t220 = call i64 @__olang_fmt_i64(ptr null, i64 %t216)
  %t221 = add i64 %t218, %t220
  %t222 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t221)
  call void @olang_textcopy(ptr %t222, ptr %t217, i64 %t218)
  %t223 = getelementptr i8, ptr %t222, i64 %t218
  %t224 = call i64 @__olang_fmt_i64(ptr %t223, i64 %t216)
  %t225 = insertvalue { i64, ptr } undef, i64 %t221, 0
  %t226 = insertvalue { i64, ptr } %t225, ptr %t222, 1
  store { i64, ptr } %t226, ptr %l73, !tbaa !27
  %t227 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t228 = extractvalue { i64, ptr } %t227, 0
  %t229 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t229, 0
  store i64 %t230, ptr %l75, !tbaa !24
  %t232 = load i64, ptr %l75, !tbaa !24
  %t233 = icmp eq i64 %t228, %t232
  br i1 %t233, label %bb16, label %bb17
bb16:
  %t235 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t236 = load ptr, ptr %t235, !tbaa !27
  %t237 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t238 = load ptr, ptr %t237, !tbaa !27
  %t239 = load i64, ptr %l75, !tbaa !24
  %t240 = mul i64 %t239, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t236, ptr %t238, i64 %t240, i1 false)
  br label %bb18
bb17:
  %t241 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t241, ptr %l7, !tbaa !27
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  %t242 = load i64, ptr %l12, !tbaa !24
  %t244 = add i64 %t242, 1
  store i64 %t244, ptr %l12, !tbaa !24
  br label %bb9
bb20:
  %t246 = load ptr, ptr %l1, !tbaa !29
  %t247 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t248 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t249 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  %t251 = extractvalue { i64, ptr } %t247, 1
  %t252 = extractvalue { i64, ptr } %t247, 0
  %t253 = add i64 %t249, %t252
  %t254 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t255 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t256 = add i64 %t253, %t255
  %t257 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t256)
  call void @olang_textcopy(ptr %t257, ptr %t248, i64 %t249)
  %t258 = getelementptr i8, ptr %t257, i64 %t249
  call void @olang_textcopy(ptr %t258, ptr %t251, i64 %t252)
  %t259 = getelementptr i8, ptr %t258, i64 %t252
  call void @olang_textcopy(ptr %t259, ptr %t254, i64 %t255)
  %t260 = insertvalue { i64, ptr } undef, i64 %t256, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t257, 1
  %t263 = extractvalue { i64, ptr } %t261, 0
  %t264 = extractvalue { i64, ptr } %t261, 1
  %t265 = mul i64 %t263, 1
  %t266 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t265)
  call void @llvm.memcpy.p0.p0.i64(ptr %t266, ptr %t264, i64 %t265, i1 false)
  %t267 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t266, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t246, { i64, ptr } %t268)
  br label %bb21
bb21:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d75, i32 0, i32 1) }, ptr %l83, !tbaa !27
  %t271 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t271, ptr %l84, !tbaa !27
  %t272 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t273 = extractvalue { i64, ptr } %t272, 0
  store i64 %t273, ptr %l85, !tbaa !24
  %t274 = load i64, ptr %l85, !tbaa !24
  %t275 = mul i64 %t274, 1
  %t276 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t275)
  %t277 = insertvalue { i64, ptr } undef, i64 %t274, 0
  %t278 = insertvalue { i64, ptr } %t277, ptr %t276, 1
  store { i64, ptr } %t278, ptr %l86, !tbaa !27
  %t279 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t280 = load ptr, ptr %t279, !tbaa !27
  %t281 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !27
  %t283 = load i64, ptr %l85, !tbaa !24
  %t284 = mul i64 %t283, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t280, ptr %t282, i64 %t284, i1 false)
  %t285 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t285, ptr %l84, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t286 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t286, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eretires(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l9 = alloca i64
  %l11 = alloca i64
  %l16 = alloca ptr
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 5
  store ptr %t9, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t11 = load i64, ptr %l3, !tbaa !24
  store i64 %t11, ptr %l9, !tbaa !24
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l11
  br label %bb2
bb2:
  %t15 = load i64, ptr %l9, !tbaa !24
  %t16 = load i64, ptr %l11, !tbaa !24
  %t17 = icmp slt i64 %t15, %t16
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t21, i64 %t22)
  store ptr %t25, ptr %l16
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l16, !tbaa !29
  store ptr %t26, ptr %l4, !tbaa !29
  %t27 = load ptr, ptr %l4, !tbaa !29
  %t29 = getelementptr %"compiler/load:Module", ptr %t27, i32 0, i32 4
  %t30 = load i64, ptr %t29, !tbaa !24
  %t34 = icmp eq i64 %t30, %a1
  br i1 %t34, label %bb7, label %bb8
bb7:
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t38 = getelementptr %"compiler/load:Module", ptr %t36, i32 0, i32 5
  %t39 = load i1, ptr %t38, !tbaa !21
  store i1 %t39, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l3, !tbaa !24
  %t43 = add i64 %t41, 1
  store i64 %t43, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntimeItems(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/text:LineIter"
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i32
  %l21 = alloca %"std/prelude/text:StringBuilder"
  %l22 = alloca %"std/prelude/text:StringBuilder"
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l30 = alloca %"std/prelude/text:LineIter"
  %l31 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i32
  %l38 = alloca i1
  %l44 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l49 = alloca { i64, ptr }
  %l50 = alloca %"std/prelude/text:StringBuilder"
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l54 = alloca i64
  %l56 = alloca i64
  %l57 = alloca { i64, ptr }
  %l59 = alloca i1
  %l64 = alloca { i64, ptr }
  %l66 = alloca i1
  %l68 = alloca i1
  %l69 = alloca { i64, ptr }
  %l71 = alloca i64
  %l73 = alloca i64
  %l74 = alloca { i64, ptr }
  %l85 = alloca ptr
  %l87 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 49
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/emit:Emitter", ptr %t6, i32 0, i32 49
  store i1 true, ptr %t8, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/emit:Emitter", ptr %t9, i32 0, i32 45
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/emit:Emitter", ptr %t13, i32 0, i32 46
  %t16 = load i1, ptr %t15, !tbaa !21
  %t19 = call { i32, { i64, ptr } } @compiler_2fruntime_2eText(ptr %v0, ptr %s0, { i64, ptr } %t12, i1 %t16, i1 false)
  %t20 = extractvalue { i32, { i64, ptr } } %t19, 1
  %t21 = extractvalue { i32, { i64, ptr } } %t19, 0
  store i32 %t21, ptr %l17
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb5, label %ok.23
ok.23:
  store { i64, ptr } %t20, ptr %l16
  br label %bb4
bb4:
  %t24 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t24, ptr %l11, !tbaa !27
  br label %bb10
bb5:
  %t25 = load i32, ptr %l17, !tbaa !23
  %t26 = ashr i32 %t25, 16
  %t28 = icmp eq i32 %t26, 1
  br i1 %t28, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_49795d8549fab862_b41831e08981cb6)
  unreachable
bb8:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s2
  %t30 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2egap(ptr %v0, ptr %s2, ptr %t30, { i64, ptr } { i64 66, ptr getelementptr inbounds (<{ i64, [66 x i8] }>, ptr @.d76, i32 0, i32 1) })
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb10:
  %t32 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t32, ptr %l1, !tbaa !27
  %t33 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t33, ptr %l21
  br label %bb11
bb11:
  %t34 = load %"std/prelude/text:StringBuilder", ptr %l21
  store %"std/prelude/text:StringBuilder" %t34, ptr %l2
  %t35 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t35, ptr %l22
  br label %bb12
bb12:
  %t36 = load %"std/prelude/text:StringBuilder", ptr %l22
  store %"std/prelude/text:StringBuilder" %t36, ptr %l3
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d77, i32 0, i32 1) }, ptr %l23, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t37, ptr %l24, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l25, !tbaa !24
  %t40 = load i64, ptr %l25, !tbaa !24
  %t41 = mul i64 %t40, 1
  %t42 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t41)
  %t43 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  store { i64, ptr } %t44, ptr %l26, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = load i64, ptr %l25, !tbaa !24
  %t50 = mul i64 %t49, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t46, ptr %t48, i64 %t50, i1 false)
  %t51 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t51, ptr %l4, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s3
  %t52 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t54 = call { i64, ptr } @compiler_2fruntime_2eDecls(ptr %s0, ptr %s3, { i64, ptr } %t52)
  store { i64, ptr } %t54, ptr %l28
  br label %bb13
bb13:
  %t55 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  %t57 = extractvalue { i64, ptr } %t55, 1
  %t58 = mul i64 %t56, 1
  %t59 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t58)
  call void @llvm.memcpy.p0.p0.i64(ptr %t59, ptr %t57, i64 %t58, i1 false)
  %t60 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  %t63 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %s3, ptr %s3, { i64, ptr } %t61)
  store %"std/prelude/text:LineIter" %t63, ptr %l30
  br label %bb14
bb14:
  %t64 = load %"std/prelude/text:LineIter", ptr %l30
  store %"std/prelude/text:LineIter" %t64, ptr %l5
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t66 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %s3, ptr %l5)
  %t67 = extractvalue { i32, { i64, ptr } } %t66, 1
  %t68 = extractvalue { i32, { i64, ptr } } %t66, 0
  store i32 %t68, ptr %l34
  %t69 = icmp ne i32 %t68, 0
  br i1 %t69, label %bb17, label %ok.70
ok.70:
  store { i64, ptr } %t67, ptr %l33
  br label %bb16
bb16:
  %t71 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t71, ptr %l31, !tbaa !27
  br label %bb21
bb17:
  %t72 = load i32, ptr %l34, !tbaa !23
  %t73 = ashr i32 %t72, 16
  %t75 = icmp eq i32 %t73, 1
  br i1 %t75, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_e59d8160838b9663_ee3833e61d72b057)
  unreachable
bb20:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s4)
  br label %bb60
bb21:
  %t77 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t77, ptr %l6, !tbaa !27
  %t78 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t80 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s4, { i64, ptr } %t78, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d78, i32 0, i32 1) })
  store i1 %t80, ptr %l38
  br label %bb22
bb22:
  %t81 = load i1, ptr %l38, !tbaa !21
  %t82 = xor i1 %t81, true
  br i1 %t82, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s5
  %t84 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l3, { i64, ptr } %t84)
  br label %bb25
bb24:
  br label %bb37
bb25:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l3, i8 10)
  br label %bb26
bb26:
  %t88 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t90 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s3, ptr %s5, { i64, ptr } %t88, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d79, i32 0, i32 1) })
  store i1 %t90, ptr %l44
  br label %bb27
bb27:
  %t91 = load i1, ptr %l44, !tbaa !21
  br i1 %t91, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s6
  %t92 = load ptr, ptr %l0, !tbaa !29
  store ptr %t92, ptr %l45, !tbaa !29
  %t93 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t93, ptr %l46, !tbaa !27
  %t94 = load i64, ptr @G_2ecompiler_2femit_2eHomeShared, !tbaa !24
  store i64 %t94, ptr %l47, !tbaa !24
  %t96 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s6, ptr %l3)
  store { i64, ptr } %t96, ptr %l49
  br label %bb30
bb29:
  br label %bb36
bb30:
  %t97 = load ptr, ptr %l45, !tbaa !29
  %t98 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t99 = load i64, ptr %l47, !tbaa !24
  %t100 = load { i64, ptr }, ptr %l49, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s0, ptr %s6, ptr %s6, ptr %t97, { i64, ptr } %t98, i64 %t99, { i64, ptr } %t100, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d43, i32 0, i32 1) })
  br label %bb31
bb31:
  %t101 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t101, ptr %l50
  br label %bb32
bb32:
  %t102 = load %"std/prelude/text:StringBuilder", ptr %l50
  store %"std/prelude/text:StringBuilder" %t102, ptr %l3
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d80, i32 0, i32 1) }, ptr %l51, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t103, ptr %l52, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  %t106 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t106, 0
  store i64 %t107, ptr %l54, !tbaa !24
  %t109 = load i64, ptr %l54, !tbaa !24
  %t110 = icmp eq i64 %t105, %t109
  br i1 %t110, label %bb33, label %bb34
bb33:
  %t112 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = load i64, ptr %l54, !tbaa !24
  %t117 = mul i64 %t116, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t113, ptr %t115, i64 %t117, i1 false)
  br label %bb35
bb34:
  %t118 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t118, 0
  store i64 %t119, ptr %l56, !tbaa !24
  %t120 = load i64, ptr %l56, !tbaa !24
  %t121 = mul i64 %t120, 1
  %t122 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t121)
  %t123 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  store { i64, ptr } %t124, ptr %l57, !tbaa !27
  %t125 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = load i64, ptr %l56, !tbaa !24
  %t130 = mul i64 %t129, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t126, ptr %t128, i64 %t130, i1 false)
  %t131 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t131, ptr %l4, !tbaa !27
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s6)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  br label %bb59
bb37:
  %t132 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t134 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s3, ptr %s4, { i64, ptr } %t132, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d81, i32 0, i32 1) })
  store i1 %t134, ptr %l59
  br label %bb38
bb38:
  %t135 = load i1, ptr %l59, !tbaa !21
  br i1 %t135, label %bb39, label %bb40
bb39:
  %t136 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l2, { i64, ptr } %t136)
  br label %bb41
bb40:
  br label %bb43
bb41:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 10)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s4)
  br label %bb59
bb43:
  %t140 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t142 = call { i64, ptr } @compiler_2femit_2edeclaredSymbol(ptr %s3, ptr %s4, { i64, ptr } %t140)
  store { i64, ptr } %t142, ptr %l64
  br label %bb44
bb44:
  %t143 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t143, ptr %l7, !tbaa !27
  %t144 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t146 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s4, ptr %s4, { i64, ptr } %t144, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d82, i32 0, i32 1) })
  store i1 %t146, ptr %l66
  br label %bb45
bb45:
  %t147 = load i1, ptr %l66, !tbaa !21
  br i1 %t147, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s4)
  br label %bb59
bb47:
  br label %bb48
bb48:
  %t148 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t150 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s3, ptr %s4, { i64, ptr } %t148, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d83, i32 0, i32 1) })
  store i1 %t150, ptr %l68
  br label %bb49
bb49:
  %t151 = load i1, ptr %l68, !tbaa !21
  br i1 %t151, label %bb50, label %bb51
bb50:
  %t152 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t152, ptr %l69, !tbaa !27
  %t153 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t154 = extractvalue { i64, ptr } %t153, 0
  %t155 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t155, 0
  store i64 %t156, ptr %l71, !tbaa !24
  %t158 = load i64, ptr %l71, !tbaa !24
  %t159 = icmp eq i64 %t154, %t158
  br i1 %t159, label %bb52, label %bb53
bb51:
  store %olang.scope zeroinitializer, ptr %s10
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t163 = load i64, ptr @G_2ecompiler_2femit_2eHomeShared, !tbaa !24
  %t164 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t166 = extractvalue { i64, ptr } %t164, 1
  %t167 = extractvalue { i64, ptr } %t164, 0
  %t168 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d84, i32 0, i32 1) }, 1
  %t169 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d84, i32 0, i32 1) }, 0
  %t170 = add i64 %t167, %t169
  %t171 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t170)
  call void @olang_textcopy(ptr %t171, ptr %t166, i64 %t167)
  %t172 = getelementptr i8, ptr %t171, i64 %t167
  call void @olang_textcopy(ptr %t172, ptr %t168, i64 %t169)
  %t173 = insertvalue { i64, ptr } undef, i64 %t170, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t171, 1
  %t176 = extractvalue { i64, ptr } %t174, 0
  %t177 = extractvalue { i64, ptr } %t174, 1
  %t178 = mul i64 %t176, 1
  %t179 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t178)
  call void @llvm.memcpy.p0.p0.i64(ptr %t179, ptr %t177, i64 %t178, i1 false)
  %t180 = insertvalue { i64, ptr } undef, i64 %t176, 0
  %t181 = insertvalue { i64, ptr } %t180, ptr %t179, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s4, ptr %s10, ptr %s10, ptr %t161, { i64, ptr } %t162, i64 %t163, { i64, ptr } %t181, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d43, i32 0, i32 1) })
  br label %bb57
bb52:
  %t186 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !27
  %t188 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = load i64, ptr %l71, !tbaa !24
  %t191 = mul i64 %t190, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t187, ptr %t189, i64 %t191, i1 false)
  br label %bb54
bb53:
  %t192 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t192, 0
  store i64 %t193, ptr %l73, !tbaa !24
  %t194 = load i64, ptr %l73, !tbaa !24
  %t195 = mul i64 %t194, 1
  %t196 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t195)
  %t197 = insertvalue { i64, ptr } undef, i64 %t194, 0
  %t198 = insertvalue { i64, ptr } %t197, ptr %t196, 1
  store { i64, ptr } %t198, ptr %l74, !tbaa !27
  %t199 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !27
  %t201 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !27
  %t203 = load i64, ptr %l73, !tbaa !24
  %t204 = mul i64 %t203, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t200, ptr %t202, i64 %t204, i1 false)
  %t205 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t205, ptr %l4, !tbaa !27
  br label %bb54
bb54:
  %t206 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l3, { i64, ptr } %t206)
  br label %bb55
bb55:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l3, i8 10)
  br label %bb56
bb56:
  br label %bb58
bb57:
  call void @__olang_scope_close(ptr %s10)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s4)
  br label %bb59
bb59:
  br label %bb15
bb60:
  call void @__olang_scope_close(ptr %s3)
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d85, i32 0, i32 1) })
  br label %bb61
bb61:
  %t211 = load ptr, ptr %l0, !tbaa !29
  store ptr %t211, ptr %l85, !tbaa !29
  %t213 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v0, ptr %l2)
  store { i64, ptr } %t213, ptr %l87
  br label %bb62
bb62:
  %t214 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t215 = load ptr, ptr %l85, !tbaa !29
  %t216 = getelementptr %"compiler/emit:Emitter", ptr %t215, i32 0, i32 48
  store { i64, ptr } %t214, ptr %t216, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2etraced(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 4
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/emit:Emitter", ptr %t6, i32 0, i32 5
  %t9 = load i1, ptr %t8, !tbaa !21
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l20 = alloca i1
  %l23 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d86, i32 0, i32 1) }, ptr %l5, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t7, ptr %l6, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l7, !tbaa !24
  %t10 = load i64, ptr %l7, !tbaa !24
  %t11 = mul i64 %t10, 1
  %t12 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l8, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l7, !tbaa !24
  %t20 = mul i64 %t19, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %t18, i64 %t20, i1 false)
  %t21 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t21, ptr %l6, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t22, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t23 = load i32, ptr %l1, !tbaa !23
  %t24 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t27 = icmp eq i32 %t23, %t24
  br i1 %t27, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t29 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2egap(ptr %v0, ptr %s2, ptr %t29, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d87, i32 0, i32 1) })
  br label %bb6
bb5:
  br label %bb7
bb6:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d88, i32 0, i32 1) }, ptr %l13, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t31, ptr %l14, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 0
  store i64 %t33, ptr %l15, !tbaa !24
  %t34 = load i64, ptr %l15, !tbaa !24
  %t35 = mul i64 %t34, 1
  %t36 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t35)
  %t37 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  store { i64, ptr } %t38, ptr %l16, !tbaa !27
  %t39 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = load i64, ptr %l15, !tbaa !24
  %t44 = mul i64 %t43, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t40, ptr %t42, i64 %t44, i1 false)
  %t45 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t45, ptr %l14, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  %t46 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t46, ptr %rv
  br label %ret
bb7:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/emit:Emitter", ptr %t47, i32 0, i32 0
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t51 = load i32, ptr %l1, !tbaa !23
  %t54 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t50, i32 %t51)
  store i1 %t54, ptr %l20
  br label %bb8
bb8:
  %t55 = load i1, ptr %l20, !tbaa !21
  %t56 = xor i1 %t55, true
  br i1 %t56, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/emit:Emitter", ptr %t58, i32 0, i32 23
  store i1 true, ptr %t60, !tbaa !21
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l23, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/emit:Emitter", ptr %t62, i32 0, i32 3
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t66 = load i32, ptr %l1, !tbaa !23
  %t69 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s3, ptr %t65, i32 %t66)
  store { i64, ptr } %t69, ptr %l27
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t70 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d89, i32 0, i32 1) }, 1
  %t71 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d89, i32 0, i32 1) }, 0
  %t72 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 1
  %t74 = extractvalue { i64, ptr } %t72, 0
  %t75 = add i64 %t71, %t74
  %t76 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t75)
  call void @olang_textcopy(ptr %t76, ptr %t70, i64 %t71)
  %t77 = getelementptr i8, ptr %t76, i64 %t71
  call void @olang_textcopy(ptr %t77, ptr %t73, i64 %t74)
  %t78 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t76, 1
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t82 = extractvalue { i64, ptr } %t79, 1
  %t83 = mul i64 %t81, 1
  %t84 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t83)
  call void @llvm.memcpy.p0.p0.i64(ptr %t84, ptr %t82, i64 %t83, i1 false)
  %t85 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  %t87 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2egap(ptr %v0, ptr %s3, ptr %t87, { i64, ptr } %t86)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb13:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eneed(ptr %v0, ptr %t89, i32 %t90)
  br label %bb14
bb14:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/emit:Emitter", ptr %t93, i32 0, i32 3
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t97 = load i32, ptr %l1, !tbaa !23
  %t100 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %t96, i32 %t97)
  store { i64, ptr } %t100, ptr %l35
  br label %bb15
bb15:
  %t101 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 1
  %t103 = extractvalue { i64, ptr } %t101, 0
  %t104 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t103)
  call void @olang_textcopy(ptr %t104, ptr %t102, i64 %t103)
  %t105 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  store { i64, ptr } %t106, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2evisit(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/load:Import"
  %l9 = alloca i1
  %l17 = alloca ptr
  %l20 = alloca i64
  %l22 = alloca i64
  %l27 = alloca %"compiler/load:Import"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v1, ptr %t1, i64 %t2)
  store i1 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i1, ptr %l9, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t8 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v1, ptr %t7, i64 %t8, i1 true)
  br label %bb5
bb5:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/emit:Emitter", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/load:Loader", ptr %t17, i32 0, i32 5
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t19, i64 %t20)
  store ptr %t23, ptr %l17
  br label %bb6
bb6:
  %t24 = load ptr, ptr %l17, !tbaa !29
  %t26 = getelementptr %"compiler/load:Module", ptr %t24, i32 0, i32 11
  store ptr %t26, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb7
bb7:
  %t28 = load i64, ptr %l5, !tbaa !24
  store i64 %t28, ptr %l20, !tbaa !24
  %t29 = load ptr, ptr %l4, !tbaa !29
  %t31 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t29)
  store i64 %t31, ptr %l22
  br label %bb8
bb8:
  %t32 = load i64, ptr %l20, !tbaa !24
  %t33 = load i64, ptr %l22, !tbaa !24
  %t34 = icmp slt i64 %t32, %t33
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb9, label %bb10
bb9:
  br label %bb18
bb10:
  br label %bb11
bb11:
  %t38 = load ptr, ptr %l4, !tbaa !29
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = call %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t38, i64 %t39)
  store %"compiler/load:Import" %t42, ptr %l27
  br label %bb12
bb12:
  %t43 = load %"compiler/load:Import", ptr %l27
  store %"compiler/load:Import" %t43, ptr %l6
  %t44 = getelementptr %"compiler/load:Import", ptr %l6, i32 0, i32 5
  %t45 = load i64, ptr %t44, !tbaa !24
  %t47 = icmp sge i64 %t45, 0
  br i1 %t47, label %bb13, label %bb14
bb13:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/load:Import", ptr %l6, i32 0, i32 5
  %t51 = load i64, ptr %t50, !tbaa !24
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t53 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2evisit(ptr %v0, ptr %v1, ptr %v2, ptr %t49, i64 %t51, ptr %t52, ptr %t53)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t58 = load i64, ptr %l5, !tbaa !24
  %t60 = add i64 %t58, 1
  store i64 %t60, ptr %l5, !tbaa !24
  br label %bb7
bb18:
  %t62 = load ptr, ptr %l3, !tbaa !29
  %t63 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t62, i64 %t63)
  br label %bb19
bb19:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ebf16Bits(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %lp3 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d90, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d90, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a1, 1
  %t7 = extractvalue { i64, ptr } %a1, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d91, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d91, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t11)
  call void @olang_textcopy(ptr %t12, ptr %t3, i64 %t4)
  %t13 = getelementptr i8, ptr %t12, i64 %t4
  call void @olang_textcopy(ptr %t13, ptr %t6, i64 %t7)
  %t14 = getelementptr i8, ptr %t13, i64 %t7
  call void @olang_textcopy(ptr %t14, ptr %t9, i64 %t10)
  %t15 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t12, 1
  %t18 = extractvalue { i64, ptr } %t16, 0
  %t19 = extractvalue { i64, ptr } %t16, 1
  %t20 = mul i64 %t18, 1
  %t21 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t20)
  call void @llvm.memcpy.p0.p0.i64(ptr %t21, ptr %t19, i64 %t20, i1 false)
  %t22 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  %t26 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v2, ptr %v2, ptr %t1, { i64, ptr } %t23)
  store { i64, ptr } %t26, ptr %l8
  br label %bb1
bb1:
  %t27 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t27, ptr %lp3
  %t28 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t29 = load ptr, ptr %lp3
  store { i64, ptr } %t28, ptr %t29, !tbaa !27
  br i1 %a2, label %bb2, label %bb3
bb2:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load ptr, ptr %lp3
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  %t37 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eopaque16(ptr %v0, ptr %v2, ptr %v2, ptr %t32, { i64, ptr } %t34)
  store { i64, ptr } %t37, ptr %l13
  br label %bb4
bb3:
  %t38 = load ptr, ptr %lp3
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  store { i64, ptr } %t39, ptr %l10, !tbaa !27
  br label %bb5
bb4:
  %t41 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t41, ptr %l10, !tbaa !27
  br label %bb5
bb5:
  %t42 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t42, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2econstText(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca { i64, [1 x i64] }
  %l4 = alloca %"compiler/mir:Range"
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l11 = alloca %"std/prelude/text:StringBuilder"
  %l17 = alloca { i64, [1 x i64] }
  %l25 = alloca i32
  %l28 = alloca i32
  %l46 = alloca ptr
  %l55 = alloca i8
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca i64
  %l63 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l11
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/emit:fnEm", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = getelementptr %"compiler/mir:Fn", ptr %t6, i32 0, i32 19
  %t11 = sext i32 %a1 to i64
  %t14 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2eAt_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %t8, i64 %t11)
  store { i64, [1 x i64] } %t14, ptr %l17
  br label %bb2
bb2:
  %t15 = load { i64, [1 x i64] }, ptr %l17
  store { i64, [1 x i64] } %t15, ptr %l3
  %t16 = load { i64, [1 x i64] }, ptr %l3
  %t18 = extractvalue { i64, [1 x i64] } %t16, 0
  %t19 = icmp eq i64 %t18, 1
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = getelementptr { i64, [1 x i64] }, ptr %l3, i32 0, i32 1
  %t22 = getelementptr { %"compiler/mir:Range" }, ptr %t21, i32 0, i32 0
  %t23 = load %"compiler/mir:Range", ptr %t22
  store %"compiler/mir:Range" %t23, ptr %l4
  br label %bb5
bb4:
  br label %bb20
bb5:
  store i32 0, ptr %l5, !tbaa !23
  %t25 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 1
  %t26 = load i32, ptr %t25, !tbaa !23
  store i32 %t26, ptr %l6, !tbaa !23
  store i32 1, ptr %l7, !tbaa !23
  %t28 = load i32, ptr %l6, !tbaa !23
  %t29 = load i32, ptr %l5, !tbaa !23
  %t32 = icmp sgt i32 %t28, %t29
  br i1 %t32, label %bb6, label %bb7
bb6:
  %t34 = load i32, ptr %l7, !tbaa !23
  %t36 = icmp sgt i32 %t34, 0
  br i1 %t36, label %bb8, label %bb9
bb7:
  store i32 0, ptr %l25, !tbaa !23
  br label %bb11
bb8:
  %t38 = load i32, ptr %l6, !tbaa !23
  %t39 = load i32, ptr %l5, !tbaa !23
  %t42 = sub i32 %t38, %t39
  %t43 = load i32, ptr %l7, !tbaa !23
  %t46 = add i32 %t42, %t43
  %t48 = sub i32 %t46, 1
  %t49 = load i32, ptr %l7, !tbaa !23
  %t52 = sdiv i32 %t48, %t49
  store i32 %t52, ptr %l28, !tbaa !23
  br label %bb10
bb9:
  store i32 0, ptr %l28, !tbaa !23
  br label %bb10
bb10:
  %t54 = load i32, ptr %l28, !tbaa !23
  store i32 %t54, ptr %l25, !tbaa !23
  br label %bb11
bb11:
  %t55 = load i32, ptr %l25, !tbaa !23
  store i32 %t55, ptr %l8, !tbaa !23
  store i32 0, ptr %l9, !tbaa !23
  br label %bb12
bb12:
  %t56 = load i32, ptr %l9, !tbaa !23
  %t57 = load i32, ptr %l8, !tbaa !23
  %t60 = icmp slt i32 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb13, label %bb14
bb13:
  br label %bb19
bb14:
  br label %bb15
bb15:
  %t64 = load i32, ptr %l5, !tbaa !23
  %t65 = load i32, ptr %l9, !tbaa !23
  %t66 = load i32, ptr %l7, !tbaa !23
  %t69 = mul i32 %t65, %t66
  %t72 = add i32 %t64, %t69
  store ptr %l2, ptr %l46, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/emit:fnEm", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/mir:Fn", ptr %t77, i32 0, i32 21
  %t80 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 0
  %t81 = load i32, ptr %t80, !tbaa !23
  %t83 = sext i32 %t81 to i64
  %t86 = sext i32 %t72 to i64
  %t89 = add i64 %t83, %t86
  %t92 = call i8 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eAt_3cU8_3e(ptr %v0, ptr %t79, i64 %t89)
  store i8 %t92, ptr %l55
  br label %bb16
bb16:
  %t93 = load i8, ptr %l55, !tbaa !22
  %t94 = load ptr, ptr %l46, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t94, i8 %t93)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t96 = load i32, ptr %l9, !tbaa !23
  %t98 = add i32 %t96, 1
  store i32 %t98, ptr %l9, !tbaa !23
  br label %bb12
bb19:
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_a00373ca27d5619a_9315010cb9ead296)
  unreachable
bb25:
  %t101 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t101, ptr %l60
  br label %bb26
bb26:
  %t102 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t102, ptr %l61, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 0
  store i64 %t104, ptr %l62, !tbaa !24
  %t105 = load i64, ptr %l62, !tbaa !24
  %t106 = mul i64 %t105, 1
  %t107 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t106)
  %t108 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t107, 1
  store { i64, ptr } %t109, ptr %l63, !tbaa !27
  %t110 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = load i64, ptr %l62, !tbaa !24
  %t115 = mul i64 %t114, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t111, ptr %t113, i64 %t115, i1 false)
  %t116 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t116, ptr %l61, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t117 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t117, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edbgEntry(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 17
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp slt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d92, i32 0, i32 1) }, ptr %l4, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t8, ptr %l5, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l6, !tbaa !24
  %t11 = load i64, ptr %l6, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l7, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l6, !tbaa !24
  %t21 = mul i64 %t20, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  %t22 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t22, ptr %l5, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t23, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l8, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/emit:fnEm", ptr %t25, i32 0, i32 0
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/emit:Emitter", ptr %t28, i32 0, i32 2
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/emit:fnEm", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/mir:Fn", ptr %t35, i32 0, i32 2
  %t38 = load i64, ptr %t37, !tbaa !24
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/emit:fnEm", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/mir:Fn", ptr %t42, i32 0, i32 3
  %t45 = getelementptr %"compiler/source:Span", ptr %t44, i32 0, i32 0
  %t46 = load i32, ptr %t45, !tbaa !23
  %t48 = sext i32 %t46 to i64
  %t52 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %t31, i64 %t38, i64 %t48)
  store i64 %t52, ptr %l19
  br label %bb4
bb4:
  %t53 = load ptr, ptr %l8, !tbaa !29
  %t54 = load i64, ptr %l19, !tbaa !24
  %t55 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edbgLine(ptr %v0, ptr %v1, ptr %t53, i64 %t54)
  store { i64, ptr } %t55, ptr %l20
  br label %bb5
bb5:
  %t56 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t56, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2ederefs(ptr %v0, ptr %a0, %"compiler/mir:Place" %a1) #0 {
entry:
  %l1 = alloca %"compiler/mir:Place"
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l13 = alloca i32
  %l16 = alloca i32
  %l42 = alloca { i64, [1 x i64] }
  %rv = alloca i1
  store %"compiler/mir:Place" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr %l2, !tbaa !23
  %t1 = getelementptr %"compiler/mir:Place", ptr %l1, i32 0, i32 1
  %t2 = getelementptr %"compiler/mir:Range", ptr %t1, i32 0, i32 1
  %t3 = load i32, ptr %t2, !tbaa !23
  store i32 %t3, ptr %l3, !tbaa !23
  store i32 1, ptr %l4, !tbaa !23
  %t5 = load i32, ptr %l3, !tbaa !23
  %t6 = load i32, ptr %l2, !tbaa !23
  %t9 = icmp sgt i32 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i32, ptr %l4, !tbaa !23
  %t13 = icmp sgt i32 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i32 0, ptr %l13, !tbaa !23
  br label %bb6
bb3:
  %t15 = load i32, ptr %l3, !tbaa !23
  %t16 = load i32, ptr %l2, !tbaa !23
  %t19 = sub i32 %t15, %t16
  %t20 = load i32, ptr %l4, !tbaa !23
  %t23 = add i32 %t19, %t20
  %t25 = sub i32 %t23, 1
  %t26 = load i32, ptr %l4, !tbaa !23
  %t29 = sdiv i32 %t25, %t26
  store i32 %t29, ptr %l16, !tbaa !23
  br label %bb5
bb4:
  store i32 0, ptr %l16, !tbaa !23
  br label %bb5
bb5:
  %t31 = load i32, ptr %l16, !tbaa !23
  store i32 %t31, ptr %l13, !tbaa !23
  br label %bb6
bb6:
  %t32 = load i32, ptr %l13, !tbaa !23
  store i32 %t32, ptr %l5, !tbaa !23
  store i32 0, ptr %l6, !tbaa !23
  br label %bb7
bb7:
  %t33 = load i32, ptr %l6, !tbaa !23
  %t34 = load i32, ptr %l5, !tbaa !23
  %t37 = icmp slt i32 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb22
bb9:
  br label %bb10
bb10:
  %t41 = load i32, ptr %l2, !tbaa !23
  %t42 = load i32, ptr %l6, !tbaa !23
  %t43 = load i32, ptr %l4, !tbaa !23
  %t46 = mul i32 %t42, %t43
  %t49 = add i32 %t41, %t46
  %t53 = getelementptr %"compiler/emit:fnEm", ptr %a0, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/mir:Fn", ptr %t54, i32 0, i32 10
  %t57 = getelementptr %"compiler/mir:Place", ptr %l1, i32 0, i32 1
  %t58 = getelementptr %"compiler/mir:Range", ptr %t57, i32 0, i32 0
  %t59 = load i32, ptr %t58, !tbaa !23
  %t61 = sext i32 %t59 to i64
  %t64 = sext i32 %t49 to i64
  %t67 = add i64 %t61, %t64
  %t70 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %t56, i64 %t67)
  store { i64, [1 x i64] } %t70, ptr %l42
  br label %bb11
bb11:
  %t71 = load { i64, [1 x i64] }, ptr %l42
  %t74 = extractvalue { i64, [1 x i64] } %t71, 0
  %t75 = icmp eq i64 %t74, 3
  br i1 %t75, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i1 true, ptr %rv
  br label %ret
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_e9e71ccb75095175_3df52a9a91674c89)
  unreachable
bb20:
  br label %bb21
bb21:
  %t78 = load i32, ptr %l6, !tbaa !23
  %t80 = add i32 %t78, 1
  store i32 %t80, ptr %l6, !tbaa !23
  br label %bb7
bb22:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eexternArg(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i32
  %l6 = alloca { { i64, ptr }, { i64, ptr } }
  %l13 = alloca i32
  %l16 = alloca i32
  %l23 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l32 = alloca i1
  %l33 = alloca i32
  %l36 = alloca i32
  %l40 = alloca i32
  %l46 = alloca { { i64, ptr }, { i64, ptr } }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t10 = load i32, ptr %l2, !tbaa !23
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t9, i32 %t10)
  store i32 %t13, ptr %l13
  br label %bb1
bb1:
  %t14 = load i32, ptr %l13, !tbaa !23
  store i32 %t14, ptr %l4, !tbaa !23
  %t15 = load ptr, ptr %l3, !tbaa !29
  %t16 = load i32, ptr %l4, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t19, ptr %l16
  br label %bb2
bb2:
  %t20 = load i32, ptr %l16
  %t22 = trunc i64 21 to i32
  %t23 = icmp eq i32 %t20, %t22
  br i1 %t23, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t27 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d93, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d93, i32 0, i32 1) }, 0
  %t30 = extractvalue { i64, ptr } %t26, 1
  %t31 = extractvalue { i64, ptr } %t26, 0
  %t32 = add i64 %t28, %t31
  %t33 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  %t35 = add i64 %t32, %t34
  %t36 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t35)
  call void @olang_textcopy(ptr %t36, ptr %t27, i64 %t28)
  %t37 = getelementptr i8, ptr %t36, i64 %t28
  call void @olang_textcopy(ptr %t37, ptr %t30, i64 %t31)
  %t38 = getelementptr i8, ptr %t37, i64 %t31
  call void @olang_textcopy(ptr %t38, ptr %t33, i64 %t34)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t36, 1
  %t42 = extractvalue { i64, ptr } %t40, 0
  %t43 = extractvalue { i64, ptr } %t40, 1
  %t44 = mul i64 %t42, 1
  %t45 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t44)
  call void @llvm.memcpy.p0.p0.i64(ptr %t45, ptr %t43, i64 %t44, i1 false)
  %t46 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  %t50 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s1, ptr %s1, ptr %t25, { i64, ptr } %t47)
  store { i64, ptr } %t50, ptr %l23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t53 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t54 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  %t56 = extractvalue { i64, ptr } %t52, 1
  %t57 = extractvalue { i64, ptr } %t52, 0
  %t58 = add i64 %t54, %t57
  %t59 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d96, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d96, i32 0, i32 1) }, 0
  %t61 = add i64 %t58, %t60
  %t62 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t61)
  call void @olang_textcopy(ptr %t62, ptr %t53, i64 %t54)
  %t63 = getelementptr i8, ptr %t62, i64 %t54
  call void @olang_textcopy(ptr %t63, ptr %t56, i64 %t57)
  %t64 = getelementptr i8, ptr %t63, i64 %t57
  call void @olang_textcopy(ptr %t64, ptr %t59, i64 %t60)
  %t65 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t62, 1
  %t68 = extractvalue { i64, ptr } %t66, 0
  %t69 = extractvalue { i64, ptr } %t66, 1
  %t70 = mul i64 %t68, 1
  %t71 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t70)
  call void @llvm.memcpy.p0.p0.i64(ptr %t71, ptr %t69, i64 %t70, i1 false)
  %t72 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t71, 1
  %t76 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s1, ptr %s1, ptr %t51, { i64, ptr } %t73)
  store { i64, ptr } %t76, ptr %l28
  br label %bb6
bb6:
  %t77 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d97, i32 0, i32 1) }, 1
  %t78 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d97, i32 0, i32 1) }, 0
  %t79 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 1
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t82 = add i64 %t78, %t81
  %t83 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d98, i32 0, i32 1) }, 1
  %t84 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d98, i32 0, i32 1) }, 0
  %t85 = add i64 %t82, %t84
  %t86 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = add i64 %t85, %t88
  %t90 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t89)
  call void @olang_textcopy(ptr %t90, ptr %t77, i64 %t78)
  %t91 = getelementptr i8, ptr %t90, i64 %t78
  call void @olang_textcopy(ptr %t91, ptr %t80, i64 %t81)
  %t92 = getelementptr i8, ptr %t91, i64 %t81
  call void @olang_textcopy(ptr %t92, ptr %t83, i64 %t84)
  %t93 = getelementptr i8, ptr %t92, i64 %t84
  call void @olang_textcopy(ptr %t93, ptr %t87, i64 %t88)
  %t94 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t90, 1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t95, ptr %rv
  br label %ret
bb7:
  %t97 = load ptr, ptr %l3, !tbaa !29
  %t98 = load i32, ptr %l4, !tbaa !23
  %t101 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t97, i32 %t98)
  store i1 %t101, ptr %l32
  br label %bb8
bb8:
  %t102 = load i1, ptr %l32, !tbaa !21
  br i1 %t102, label %bb9, label %bb10
bb9:
  %t103 = load ptr, ptr %l3, !tbaa !29
  %t104 = load i32, ptr %l4, !tbaa !23
  %t107 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t103, i32 %t104)
  store i32 %t107, ptr %l36
  br label %bb11
bb10:
  %t108 = load i32, ptr %l4, !tbaa !23
  store i32 %t108, ptr %l33, !tbaa !23
  br label %bb12
bb11:
  %t110 = load i32, ptr %l36, !tbaa !23
  store i32 %t110, ptr %l33, !tbaa !23
  br label %bb12
bb12:
  %t111 = load i32, ptr %l33, !tbaa !23
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t116 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t112, i32 %t111)
  store i32 %t116, ptr %l40
  br label %bb13
bb13:
  %t117 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t118 = load i32, ptr %l40, !tbaa !23
  %t120 = icmp ne i32 %t118, %t117
  br i1 %t120, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s5
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t124 = load i32, ptr %l2, !tbaa !23
  %t128 = call { { i64, ptr }, { i64, ptr } } @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayParts(ptr %v0, ptr %v1, ptr %s5, ptr %t122, { i64, ptr } %t123, i32 %t124)
  store { { i64, ptr }, { i64, ptr } } %t128, ptr %l46
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t129 = load { { i64, ptr }, { i64, ptr } }, ptr %l46
  store { { i64, ptr }, { i64, ptr } } %t129, ptr %l6
  %t130 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l6, i32 0, i32 0
  %t131 = load { i64, ptr }, ptr %t130, !tbaa !27
  store { i64, ptr } %t131, ptr %l47, !tbaa !27
  %t132 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t132, 0
  store i64 %t133, ptr %l48, !tbaa !24
  %t134 = load i64, ptr %l48, !tbaa !24
  %t135 = mul i64 %t134, 1
  %t136 = call ptr @__olang_scope_alloc_zeroed(ptr %s5, i64 %t135)
  %t137 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t136, 1
  store { i64, ptr } %t138, ptr %l49, !tbaa !27
  %t139 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !27
  %t141 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = load i64, ptr %l48, !tbaa !24
  %t144 = mul i64 %t143, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t140, ptr %t142, i64 %t144, i1 false)
  %t145 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t147 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d99, i32 0, i32 1) }, 1
  %t148 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d99, i32 0, i32 1) }, 0
  %t150 = extractvalue { i64, ptr } %t145, 1
  %t151 = extractvalue { i64, ptr } %t145, 0
  %t152 = add i64 %t148, %t151
  %t153 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t152)
  call void @olang_textcopy(ptr %t153, ptr %t147, i64 %t148)
  %t154 = getelementptr i8, ptr %t153, i64 %t148
  call void @olang_textcopy(ptr %t154, ptr %t150, i64 %t151)
  %t155 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t153, 1
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t156, ptr %rv
  br label %ret
bb17:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load i32, ptr %l4, !tbaa !23
  %t162 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s0, ptr %t158, i32 %t159)
  store { i64, ptr } %t162, ptr %l54
  br label %bb18
bb18:
  %t163 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t164 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t164, 1
  %t166 = extractvalue { i64, ptr } %t164, 0
  %t167 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d100, i32 0, i32 1) }, 1
  %t168 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d100, i32 0, i32 1) }, 0
  %t169 = add i64 %t166, %t168
  %t171 = extractvalue { i64, ptr } %t163, 1
  %t172 = extractvalue { i64, ptr } %t163, 0
  %t173 = add i64 %t169, %t172
  %t174 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t173)
  call void @olang_textcopy(ptr %t174, ptr %t165, i64 %t166)
  %t175 = getelementptr i8, ptr %t174, i64 %t166
  call void @olang_textcopy(ptr %t175, ptr %t167, i64 %t168)
  %t176 = getelementptr i8, ptr %t175, i64 %t168
  call void @olang_textcopy(ptr %t176, ptr %t171, i64 %t172)
  %t177 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t174, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t178, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efillInPlace(ptr %v0, ptr %a0, %"compiler/mir:Place" %a1, i32 %a2, { i64, [15 x i64] } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Place"
  %l2 = alloca i32
  %l3 = alloca { i64, [15 x i64] }
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca %"compiler/mir:Range"
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i1
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca { { i64, ptr }, i32 }
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l30 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l37 = alloca { { i64, ptr }, i32 }
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, [4 x i64] }
  %l47 = alloca %"compiler/mir:Place"
  %l48 = alloca i32
  %l49 = alloca { { i64, ptr }, i32 }
  %l50 = alloca { i64, ptr }
  %l51 = alloca { { i64, ptr }, i32 }
  %l52 = alloca { i64, ptr }
  %l62 = alloca i32
  %l66 = alloca i1
  %l69 = alloca i1
  %l71 = alloca i1
  %l74 = alloca i32
  %l80 = alloca i64
  %l86 = alloca i32
  %l89 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l97 = alloca i64
  %l100 = alloca i64
  %l121 = alloca { i64, [4 x i64] }
  %l122 = alloca ptr
  %l125 = alloca { i64, [4 x i64] }
  %l127 = alloca i1
  %l132 = alloca ptr
  %l135 = alloca { i64, [4 x i64] }
  %l137 = alloca { i64, ptr }
  %l140 = alloca { { i64, ptr }, i32 }
  %l141 = alloca { i64, ptr }
  %l142 = alloca i64
  %l143 = alloca { i64, ptr }
  %l145 = alloca { i64, ptr }
  %l147 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l151 = alloca { i64, ptr }
  %l165 = alloca { i64, ptr }
  %l167 = alloca { i64, ptr }
  %l180 = alloca { i64, ptr }
  %l195 = alloca { i64, ptr }
  %l212 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l217 = alloca i64
  %l220 = alloca i64
  %l238 = alloca ptr
  %l239 = alloca ptr
  %l243 = alloca { i64, [4 x i64] }
  %l245 = alloca { i64, ptr }
  %l251 = alloca { { i64, ptr }, i32 }
  %l252 = alloca { i64, ptr }
  %l253 = alloca i64
  %l254 = alloca { i64, ptr }
  %l259 = alloca i64
  %l262 = alloca i64
  %l286 = alloca { i64, ptr }
  %l287 = alloca ptr
  %l288 = alloca { i64, ptr }
  %l291 = alloca { i64, ptr }
  %l302 = alloca ptr
  %l305 = alloca i32
  %l306 = alloca i32
  %l310 = alloca i1
  %l314 = alloca i1
  %l319 = alloca ptr
  %l322 = alloca i32
  %l323 = alloca i32
  %l326 = alloca i1
  %l327 = alloca ptr
  %l330 = alloca i32
  %l331 = alloca i1
  %l336 = alloca i64
  %l338 = alloca i1
  %l341 = alloca i32
  %l347 = alloca { { i64, ptr }, i32 }
  %l348 = alloca { i64, ptr }
  %l349 = alloca i64
  %l350 = alloca { i64, ptr }
  %l353 = alloca { { i64, ptr }, i32 }
  %l354 = alloca { i64, ptr }
  %l355 = alloca i64
  %l356 = alloca { i64, ptr }
  %l359 = alloca ptr
  %l360 = alloca { i64, ptr }
  %l361 = alloca { i64, ptr }
  %l364 = alloca i64
  %s1 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/mir:Place" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, [15 x i64] } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l4, !tbaa !29
  %t9 = load { i64, [15 x i64] }, ptr %l3
  %t11 = extractvalue { i64, [15 x i64] } %t9, 0
  %t12 = icmp eq i64 %t11, 6
  br i1 %t12, label %bb1, label %bb2
bb1:
  %t14 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t15 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t14, i32 0, i32 0
  %t16 = load i32, ptr %t15
  store i32 %t16, ptr %l5, !tbaa !23
  %t18 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t19 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t18, i32 0, i32 2
  %t20 = load %"compiler/mir:Range", ptr %t19
  store %"compiler/mir:Range" %t20, ptr %l6
  br label %bb3
bb2:
  br label %bb98
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l5, !tbaa !23
  %t26 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t26, ptr %l62
  br label %bb4
bb4:
  %t27 = load i32, ptr %l62, !tbaa !23
  store i32 %t27, ptr %l7, !tbaa !23
  %t28 = load i32, ptr %l7, !tbaa !23
  %t29 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t32 = icmp eq i32 %t28, %t29
  br i1 %t32, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb8
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i32, ptr %l7, !tbaa !23
  %t38 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixed(ptr %v0, ptr %t34, i32 %t35)
  store i1 %t38, ptr %l69
  br label %bb7
bb7:
  %t39 = load i1, ptr %l69, !tbaa !21
  %t40 = xor i1 %t39, true
  store i1 %t40, ptr %l66, !tbaa !21
  br label %bb8
bb8:
  %t42 = load i1, ptr %l66, !tbaa !21
  br i1 %t42, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l71, !tbaa !21
  br label %bb12
bb10:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i32, ptr %l2, !tbaa !23
  %t47 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t43, i32 %t44)
  store i32 %t47, ptr %l74
  br label %bb11
bb11:
  %t48 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t49 = load i32, ptr %l74, !tbaa !23
  %t51 = icmp eq i32 %t49, %t48
  store i1 %t51, ptr %l71, !tbaa !21
  br label %bb12
bb12:
  %t53 = load i1, ptr %l71, !tbaa !21
  br i1 %t53, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i32, ptr %l7, !tbaa !23
  %t59 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixedLen(ptr %v0, ptr %t55, i32 %t56)
  store i64 %t59, ptr %l80
  br label %bb16
bb16:
  %t60 = load i64, ptr %l80, !tbaa !24
  store i64 %t60, ptr %l8, !tbaa !24
  %t61 = load i64, ptr %l8, !tbaa !24
  %t63 = icmp sle i64 %t61, 16
  br i1 %t63, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t66 = load ptr, ptr %l4, !tbaa !29
  %t67 = load i32, ptr %l7, !tbaa !23
  %t70 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t66, i32 %t67)
  store i32 %t70, ptr %l86
  br label %bb20
bb20:
  %t71 = load i32, ptr %l86, !tbaa !23
  store i32 %t71, ptr %l9, !tbaa !23
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i32, ptr %l9, !tbaa !23
  %t76 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s1, ptr %t72, i32 %t73)
  store { i64, ptr } %t76, ptr %l89
  br label %bb21
bb21:
  %t77 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t77, ptr %l10, !tbaa !27
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i32, ptr %l7, !tbaa !23
  %t82 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s1, ptr %t78, i32 %t79)
  store { i64, ptr } %t82, ptr %l92
  br label %bb22
bb22:
  %t83 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t83, ptr %l11, !tbaa !27
  store i1 true, ptr %l12, !tbaa !21
  store i64 0, ptr %l13, !tbaa !24
  %t84 = load i64, ptr %l8, !tbaa !24
  store i64 %t84, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t86 = load i64, ptr %l14, !tbaa !24
  %t87 = load i64, ptr %l13, !tbaa !24
  %t90 = icmp sgt i64 %t86, %t87
  br i1 %t90, label %bb23, label %bb24
bb23:
  %t92 = load i64, ptr %l15, !tbaa !24
  %t94 = icmp sgt i64 %t92, 0
  br i1 %t94, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l97, !tbaa !24
  br label %bb28
bb25:
  %t96 = load i64, ptr %l14, !tbaa !24
  %t97 = load i64, ptr %l13, !tbaa !24
  %t100 = sub i64 %t96, %t97
  %t101 = load i64, ptr %l15, !tbaa !24
  %t104 = add i64 %t100, %t101
  %t106 = sub i64 %t104, 1
  %t107 = load i64, ptr %l15, !tbaa !24
  %t110 = sdiv i64 %t106, %t107
  store i64 %t110, ptr %l100, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l100, !tbaa !24
  br label %bb27
bb27:
  %t112 = load i64, ptr %l100, !tbaa !24
  store i64 %t112, ptr %l97, !tbaa !24
  br label %bb28
bb28:
  %t113 = load i64, ptr %l97, !tbaa !24
  store i64 %t113, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb29
bb29:
  %t114 = load i64, ptr %l17, !tbaa !24
  %t115 = load i64, ptr %l16, !tbaa !24
  %t118 = icmp slt i64 %t114, %t115
  %t120 = xor i1 %t118, true
  br i1 %t120, label %bb30, label %bb31
bb30:
  br label %bb40
bb31:
  br label %bb32
bb32:
  %t122 = load i64, ptr %l13, !tbaa !24
  %t123 = load i64, ptr %l17, !tbaa !24
  %t124 = load i64, ptr %l15, !tbaa !24
  %t127 = mul i64 %t123, %t124
  %t130 = add i64 %t122, %t127
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load %"compiler/mir:Range", ptr %l6
  %t138 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t132, %"compiler/mir:Range" %t133, i64 %t130)
  store { i64, [4 x i64] } %t138, ptr %l121
  br label %bb33
bb33:
  store ptr %l121, ptr %l122, !tbaa !29
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load %"compiler/mir:Range", ptr %l6
  %t143 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t139, %"compiler/mir:Range" %t140, i64 0)
  store { i64, [4 x i64] } %t143, ptr %l125
  br label %bb34
bb34:
  %t144 = load ptr, ptr %l122, !tbaa !29
  %t146 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aOperand(ptr %t144, ptr %l125)
  store i1 %t146, ptr %l127
  br label %bb35
bb35:
  %t147 = load i1, ptr %l127, !tbaa !21
  %t148 = xor i1 %t147, true
  br i1 %t148, label %bb36, label %bb37
bb36:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb38
bb37:
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t150 = load i64, ptr %l17, !tbaa !24
  %t152 = add i64 %t150, 1
  store i64 %t152, ptr %l17, !tbaa !24
  br label %bb29
bb40:
  %t154 = load i1, ptr %l12, !tbaa !21
  br i1 %t154, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s8
  %t156 = load ptr, ptr %l0, !tbaa !29
  store ptr %t156, ptr %l132, !tbaa !29
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load %"compiler/mir:Range", ptr %l6
  %t161 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t157, %"compiler/mir:Range" %t158, i64 0)
  store { i64, [4 x i64] } %t161, ptr %l135
  br label %bb43
bb42:
  br label %bb65
bb43:
  %t162 = load i32, ptr %l9, !tbaa !23
  %t163 = load ptr, ptr %l132, !tbaa !29
  %t164 = load { i64, [4 x i64] }, ptr %l135
  %t166 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s8, ptr %t163, { i64, [4 x i64] } %t164, i32 %t162)
  store { i64, ptr } %t166, ptr %l137
  br label %bb44
bb44:
  %t167 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t167, ptr %l19, !tbaa !27
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load %"compiler/mir:Place", ptr %l1
  %t172 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s8, ptr %t168, %"compiler/mir:Place" %t169)
  store { { i64, ptr }, i32 } %t172, ptr %l140
  br label %bb45
bb45:
  %t173 = load { { i64, ptr }, i32 }, ptr %l140
  store { { i64, ptr }, i32 } %t173, ptr %l20
  %t174 = getelementptr { { i64, ptr }, i32 }, ptr %l20, i32 0, i32 0
  %t175 = load { i64, ptr }, ptr %t174, !tbaa !27
  store { i64, ptr } %t175, ptr %l141, !tbaa !27
  %t176 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t176, 0
  store i64 %t177, ptr %l142, !tbaa !24
  %t178 = load i64, ptr %l142, !tbaa !24
  %t179 = mul i64 %t178, 1
  %t180 = call ptr @__olang_scope_alloc_zeroed(ptr %s8, i64 %t179)
  %t181 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  store { i64, ptr } %t182, ptr %l143, !tbaa !27
  %t183 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !27
  %t187 = load i64, ptr %l142, !tbaa !24
  %t188 = mul i64 %t187, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t184, ptr %t186, i64 %t188, i1 false)
  %t189 = load { i64, ptr }, ptr %l143, !tbaa !27
  store { i64, ptr } %t189, ptr %l21, !tbaa !27
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t192 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s8, ptr %s8, ptr %t190, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d101, i32 0, i32 1) })
  store { i64, ptr } %t192, ptr %l145
  br label %bb46
bb46:
  %t193 = load { i64, ptr }, ptr %l145, !tbaa !27
  store { i64, ptr } %t193, ptr %l22, !tbaa !27
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s8, ptr %s8, ptr %t194, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d102, i32 0, i32 1) })
  store { i64, ptr } %t196, ptr %l147
  br label %bb47
bb47:
  %t197 = load { i64, ptr }, ptr %l147, !tbaa !27
  store { i64, ptr } %t197, ptr %l23, !tbaa !27
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s8, ptr %s8, ptr %t198, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d103, i32 0, i32 1) })
  store { i64, ptr } %t200, ptr %l149
  br label %bb48
bb48:
  %t201 = load { i64, ptr }, ptr %l149, !tbaa !27
  store { i64, ptr } %t201, ptr %l24, !tbaa !27
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s8, ptr %s8, ptr %t202, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d104, i32 0, i32 1) })
  store { i64, ptr } %t204, ptr %l151
  br label %bb49
bb49:
  %t205 = load { i64, ptr }, ptr %l151, !tbaa !27
  store { i64, ptr } %t205, ptr %l25, !tbaa !27
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t207 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t208 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d105, i32 0, i32 1) }, 1
  %t209 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d105, i32 0, i32 1) }, 0
  %t211 = extractvalue { i64, ptr } %t207, 1
  %t212 = extractvalue { i64, ptr } %t207, 0
  %t213 = add i64 %t209, %t212
  %t214 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t213)
  call void @olang_textcopy(ptr %t214, ptr %t208, i64 %t209)
  %t215 = getelementptr i8, ptr %t214, i64 %t209
  call void @olang_textcopy(ptr %t215, ptr %t211, i64 %t212)
  %t216 = insertvalue { i64, ptr } undef, i64 %t213, 0
  %t217 = insertvalue { i64, ptr } %t216, ptr %t214, 1
  %t219 = extractvalue { i64, ptr } %t217, 0
  %t220 = extractvalue { i64, ptr } %t217, 1
  %t221 = mul i64 %t219, 1
  %t222 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t221)
  call void @llvm.memcpy.p0.p0.i64(ptr %t222, ptr %t220, i64 %t221, i1 false)
  %t223 = insertvalue { i64, ptr } undef, i64 %t219, 0
  %t224 = insertvalue { i64, ptr } %t223, ptr %t222, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s8, ptr %t206, { i64, ptr } %t224)
  br label %bb50
bb50:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load { i64, ptr }, ptr %l25, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s8, ptr %t227, { i64, ptr } %t228)
  br label %bb51
bb51:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t232 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t233 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d106, i32 0, i32 1) }, 1
  %t234 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d106, i32 0, i32 1) }, 0
  %t236 = extractvalue { i64, ptr } %t232, 1
  %t237 = extractvalue { i64, ptr } %t232, 0
  %t238 = add i64 %t234, %t237
  %t239 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t238)
  call void @olang_textcopy(ptr %t239, ptr %t233, i64 %t234)
  %t240 = getelementptr i8, ptr %t239, i64 %t234
  call void @olang_textcopy(ptr %t240, ptr %t236, i64 %t237)
  %t241 = insertvalue { i64, ptr } undef, i64 %t238, 0
  %t242 = insertvalue { i64, ptr } %t241, ptr %t239, 1
  %t244 = extractvalue { i64, ptr } %t242, 0
  %t245 = extractvalue { i64, ptr } %t242, 1
  %t246 = mul i64 %t244, 1
  %t247 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t246)
  call void @llvm.memcpy.p0.p0.i64(ptr %t247, ptr %t245, i64 %t246, i1 false)
  %t248 = insertvalue { i64, ptr } undef, i64 %t244, 0
  %t249 = insertvalue { i64, ptr } %t248, ptr %t247, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s8, ptr %t231, { i64, ptr } %t249)
  br label %bb52
bb52:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t253 = load { i64, ptr }, ptr %l22, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s8, ptr %t252, { i64, ptr } %t253)
  br label %bb53
bb53:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2etmp(ptr %v0, ptr %s8, ptr %t256)
  store { i64, ptr } %t258, ptr %l165
  br label %bb54
bb54:
  %t259 = load { i64, ptr }, ptr %l165, !tbaa !27
  store { i64, ptr } %t259, ptr %l26, !tbaa !27
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t262 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2etmp(ptr %v0, ptr %s8, ptr %t260)
  store { i64, ptr } %t262, ptr %l167
  br label %bb55
bb55:
  %t263 = load { i64, ptr }, ptr %l167, !tbaa !27
  store { i64, ptr } %t263, ptr %l27, !tbaa !27
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t265 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t266 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t267 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t268 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t270 = extractvalue { i64, ptr } %t265, 1
  %t271 = extractvalue { i64, ptr } %t265, 0
  %t272 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d107, i32 0, i32 1) }, 1
  %t273 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d107, i32 0, i32 1) }, 0
  %t274 = add i64 %t271, %t273
  %t276 = extractvalue { i64, ptr } %t266, 1
  %t277 = extractvalue { i64, ptr } %t266, 0
  %t278 = add i64 %t274, %t277
  %t279 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d108, i32 0, i32 1) }, 1
  %t280 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d108, i32 0, i32 1) }, 0
  %t281 = add i64 %t278, %t280
  %t283 = extractvalue { i64, ptr } %t267, 1
  %t284 = extractvalue { i64, ptr } %t267, 0
  %t285 = add i64 %t281, %t284
  %t286 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d109, i32 0, i32 1) }, 1
  %t287 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d109, i32 0, i32 1) }, 0
  %t288 = add i64 %t285, %t287
  %t290 = extractvalue { i64, ptr } %t268, 1
  %t291 = extractvalue { i64, ptr } %t268, 0
  %t292 = add i64 %t288, %t291
  %t293 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d110, i32 0, i32 1) }, 1
  %t294 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d110, i32 0, i32 1) }, 0
  %t295 = add i64 %t292, %t294
  %t296 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t295)
  call void @olang_textcopy(ptr %t296, ptr %t270, i64 %t271)
  %t297 = getelementptr i8, ptr %t296, i64 %t271
  call void @olang_textcopy(ptr %t297, ptr %t272, i64 %t273)
  %t298 = getelementptr i8, ptr %t297, i64 %t273
  call void @olang_textcopy(ptr %t298, ptr %t276, i64 %t277)
  %t299 = getelementptr i8, ptr %t298, i64 %t277
  call void @olang_textcopy(ptr %t299, ptr %t279, i64 %t280)
  %t300 = getelementptr i8, ptr %t299, i64 %t280
  call void @olang_textcopy(ptr %t300, ptr %t283, i64 %t284)
  %t301 = getelementptr i8, ptr %t300, i64 %t284
  call void @olang_textcopy(ptr %t301, ptr %t286, i64 %t287)
  %t302 = getelementptr i8, ptr %t301, i64 %t287
  call void @olang_textcopy(ptr %t302, ptr %t290, i64 %t291)
  %t303 = getelementptr i8, ptr %t302, i64 %t291
  call void @olang_textcopy(ptr %t303, ptr %t293, i64 %t294)
  %t304 = insertvalue { i64, ptr } undef, i64 %t295, 0
  %t305 = insertvalue { i64, ptr } %t304, ptr %t296, 1
  %t307 = extractvalue { i64, ptr } %t305, 0
  %t308 = extractvalue { i64, ptr } %t305, 1
  %t309 = mul i64 %t307, 1
  %t310 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t309)
  call void @llvm.memcpy.p0.p0.i64(ptr %t310, ptr %t308, i64 %t309, i1 false)
  %t311 = insertvalue { i64, ptr } undef, i64 %t307, 0
  %t312 = insertvalue { i64, ptr } %t311, ptr %t310, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s8, ptr %t264, { i64, ptr } %t312)
  br label %bb56
bb56:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t316 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t317 = load i64, ptr %l8, !tbaa !24
  %t318 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d111, i32 0, i32 1) }, 1
  %t319 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d111, i32 0, i32 1) }, 0
  %t321 = extractvalue { i64, ptr } %t316, 1
  %t322 = extractvalue { i64, ptr } %t316, 0
  %t323 = add i64 %t319, %t322
  %t324 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d112, i32 0, i32 1) }, 1
  %t325 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d112, i32 0, i32 1) }, 0
  %t326 = add i64 %t323, %t325
  %t328 = call i64 @__olang_fmt_i64(ptr null, i64 %t317)
  %t329 = add i64 %t326, %t328
  %t330 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t329)
  call void @olang_textcopy(ptr %t330, ptr %t318, i64 %t319)
  %t331 = getelementptr i8, ptr %t330, i64 %t319
  call void @olang_textcopy(ptr %t331, ptr %t321, i64 %t322)
  %t332 = getelementptr i8, ptr %t331, i64 %t322
  call void @olang_textcopy(ptr %t332, ptr %t324, i64 %t325)
  %t333 = getelementptr i8, ptr %t332, i64 %t325
  %t334 = call i64 @__olang_fmt_i64(ptr %t333, i64 %t317)
  %t335 = insertvalue { i64, ptr } undef, i64 %t329, 0
  %t336 = insertvalue { i64, ptr } %t335, ptr %t330, 1
  %t338 = extractvalue { i64, ptr } %t336, 0
  %t339 = extractvalue { i64, ptr } %t336, 1
  %t340 = mul i64 %t338, 1
  %t341 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t340)
  call void @llvm.memcpy.p0.p0.i64(ptr %t341, ptr %t339, i64 %t340, i1 false)
  %t342 = insertvalue { i64, ptr } undef, i64 %t338, 0
  %t343 = insertvalue { i64, ptr } %t342, ptr %t341, 1
  %t346 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s8, ptr %s8, ptr %t315, { i64, ptr } %t343)
  store { i64, ptr } %t346, ptr %l180
  br label %bb57
bb57:
  %t347 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t350 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t351 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t352 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d113, i32 0, i32 1) }, 1
  %t353 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d113, i32 0, i32 1) }, 0
  %t355 = extractvalue { i64, ptr } %t347, 1
  %t356 = extractvalue { i64, ptr } %t347, 0
  %t357 = add i64 %t353, %t356
  %t358 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d114, i32 0, i32 1) }, 1
  %t359 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d114, i32 0, i32 1) }, 0
  %t360 = add i64 %t357, %t359
  %t362 = extractvalue { i64, ptr } %t350, 1
  %t363 = extractvalue { i64, ptr } %t350, 0
  %t364 = add i64 %t360, %t363
  %t365 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d114, i32 0, i32 1) }, 1
  %t366 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d114, i32 0, i32 1) }, 0
  %t367 = add i64 %t364, %t366
  %t369 = extractvalue { i64, ptr } %t351, 1
  %t370 = extractvalue { i64, ptr } %t351, 0
  %t371 = add i64 %t367, %t370
  %t372 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t371)
  call void @olang_textcopy(ptr %t372, ptr %t352, i64 %t353)
  %t373 = getelementptr i8, ptr %t372, i64 %t353
  call void @olang_textcopy(ptr %t373, ptr %t355, i64 %t356)
  %t374 = getelementptr i8, ptr %t373, i64 %t356
  call void @olang_textcopy(ptr %t374, ptr %t358, i64 %t359)
  %t375 = getelementptr i8, ptr %t374, i64 %t359
  call void @olang_textcopy(ptr %t375, ptr %t362, i64 %t363)
  %t376 = getelementptr i8, ptr %t375, i64 %t363
  call void @olang_textcopy(ptr %t376, ptr %t365, i64 %t366)
  %t377 = getelementptr i8, ptr %t376, i64 %t366
  call void @olang_textcopy(ptr %t377, ptr %t369, i64 %t370)
  %t378 = insertvalue { i64, ptr } undef, i64 %t371, 0
  %t379 = insertvalue { i64, ptr } %t378, ptr %t372, 1
  %t381 = extractvalue { i64, ptr } %t379, 0
  %t382 = extractvalue { i64, ptr } %t379, 1
  %t383 = mul i64 %t381, 1
  %t384 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t383)
  call void @llvm.memcpy.p0.p0.i64(ptr %t384, ptr %t382, i64 %t383, i1 false)
  %t385 = insertvalue { i64, ptr } undef, i64 %t381, 0
  %t386 = insertvalue { i64, ptr } %t385, ptr %t384, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s8, ptr %t348, { i64, ptr } %t386)
  br label %bb58
bb58:
  %t389 = load ptr, ptr %l0, !tbaa !29
  %t390 = load { i64, ptr }, ptr %l23, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s8, ptr %t389, { i64, ptr } %t390)
  br label %bb59
bb59:
  %t393 = load ptr, ptr %l0, !tbaa !29
  %t394 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t395 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t396 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t397 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d115, i32 0, i32 1) }, 1
  %t398 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d115, i32 0, i32 1) }, 0
  %t400 = extractvalue { i64, ptr } %t394, 1
  %t401 = extractvalue { i64, ptr } %t394, 0
  %t402 = add i64 %t398, %t401
  %t403 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d116, i32 0, i32 1) }, 1
  %t404 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d116, i32 0, i32 1) }, 0
  %t405 = add i64 %t402, %t404
  %t407 = extractvalue { i64, ptr } %t395, 1
  %t408 = extractvalue { i64, ptr } %t395, 0
  %t409 = add i64 %t405, %t408
  %t410 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d117, i32 0, i32 1) }, 1
  %t411 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d117, i32 0, i32 1) }, 0
  %t412 = add i64 %t409, %t411
  %t414 = extractvalue { i64, ptr } %t396, 1
  %t415 = extractvalue { i64, ptr } %t396, 0
  %t416 = add i64 %t412, %t415
  %t417 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t416)
  call void @olang_textcopy(ptr %t417, ptr %t397, i64 %t398)
  %t418 = getelementptr i8, ptr %t417, i64 %t398
  call void @olang_textcopy(ptr %t418, ptr %t400, i64 %t401)
  %t419 = getelementptr i8, ptr %t418, i64 %t401
  call void @olang_textcopy(ptr %t419, ptr %t403, i64 %t404)
  %t420 = getelementptr i8, ptr %t419, i64 %t404
  call void @olang_textcopy(ptr %t420, ptr %t407, i64 %t408)
  %t421 = getelementptr i8, ptr %t420, i64 %t408
  call void @olang_textcopy(ptr %t421, ptr %t410, i64 %t411)
  %t422 = getelementptr i8, ptr %t421, i64 %t411
  call void @olang_textcopy(ptr %t422, ptr %t414, i64 %t415)
  %t423 = insertvalue { i64, ptr } undef, i64 %t416, 0
  %t424 = insertvalue { i64, ptr } %t423, ptr %t417, 1
  %t426 = extractvalue { i64, ptr } %t424, 0
  %t427 = extractvalue { i64, ptr } %t424, 1
  %t428 = mul i64 %t426, 1
  %t429 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t428)
  call void @llvm.memcpy.p0.p0.i64(ptr %t429, ptr %t427, i64 %t428, i1 false)
  %t430 = insertvalue { i64, ptr } undef, i64 %t426, 0
  %t431 = insertvalue { i64, ptr } %t430, ptr %t429, 1
  %t434 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s8, ptr %s8, ptr %t393, { i64, ptr } %t431)
  store { i64, ptr } %t434, ptr %l195
  br label %bb60
bb60:
  %t435 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t437 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t438 = load { i64, ptr }, ptr %l19, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s1, ptr %s8, ptr %s8, ptr %s8, ptr %t436, { i64, ptr } %t437, { i64, ptr } %t438, { i64, ptr } %t435, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d118, i32 0, i32 1) })
  br label %bb61
bb61:
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t445 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t446 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t448 = extractvalue { i64, ptr } %t445, 1
  %t449 = extractvalue { i64, ptr } %t445, 0
  %t450 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d119, i32 0, i32 1) }, 1
  %t451 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d119, i32 0, i32 1) }, 0
  %t452 = add i64 %t449, %t451
  %t454 = extractvalue { i64, ptr } %t446, 1
  %t455 = extractvalue { i64, ptr } %t446, 0
  %t456 = add i64 %t452, %t455
  %t457 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d120, i32 0, i32 1) }, 1
  %t458 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d120, i32 0, i32 1) }, 0
  %t459 = add i64 %t456, %t458
  %t460 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t459)
  call void @olang_textcopy(ptr %t460, ptr %t448, i64 %t449)
  %t461 = getelementptr i8, ptr %t460, i64 %t449
  call void @olang_textcopy(ptr %t461, ptr %t450, i64 %t451)
  %t462 = getelementptr i8, ptr %t461, i64 %t451
  call void @olang_textcopy(ptr %t462, ptr %t454, i64 %t455)
  %t463 = getelementptr i8, ptr %t462, i64 %t455
  call void @olang_textcopy(ptr %t463, ptr %t457, i64 %t458)
  %t464 = insertvalue { i64, ptr } undef, i64 %t459, 0
  %t465 = insertvalue { i64, ptr } %t464, ptr %t460, 1
  %t467 = extractvalue { i64, ptr } %t465, 0
  %t468 = extractvalue { i64, ptr } %t465, 1
  %t469 = mul i64 %t467, 1
  %t470 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t469)
  call void @llvm.memcpy.p0.p0.i64(ptr %t470, ptr %t468, i64 %t469, i1 false)
  %t471 = insertvalue { i64, ptr } undef, i64 %t467, 0
  %t472 = insertvalue { i64, ptr } %t471, ptr %t470, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s8, ptr %t444, { i64, ptr } %t472)
  br label %bb62
bb62:
  %t475 = load ptr, ptr %l0, !tbaa !29
  %t476 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t477 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d121, i32 0, i32 1) }, 1
  %t478 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d121, i32 0, i32 1) }, 0
  %t480 = extractvalue { i64, ptr } %t476, 1
  %t481 = extractvalue { i64, ptr } %t476, 0
  %t482 = add i64 %t478, %t481
  %t483 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t482)
  call void @olang_textcopy(ptr %t483, ptr %t477, i64 %t478)
  %t484 = getelementptr i8, ptr %t483, i64 %t478
  call void @olang_textcopy(ptr %t484, ptr %t480, i64 %t481)
  %t485 = insertvalue { i64, ptr } undef, i64 %t482, 0
  %t486 = insertvalue { i64, ptr } %t485, ptr %t483, 1
  %t488 = extractvalue { i64, ptr } %t486, 0
  %t489 = extractvalue { i64, ptr } %t486, 1
  %t490 = mul i64 %t488, 1
  %t491 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t490)
  call void @llvm.memcpy.p0.p0.i64(ptr %t491, ptr %t489, i64 %t490, i1 false)
  %t492 = insertvalue { i64, ptr } undef, i64 %t488, 0
  %t493 = insertvalue { i64, ptr } %t492, ptr %t491, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s8, ptr %t475, { i64, ptr } %t493)
  br label %bb63
bb63:
  %t496 = load ptr, ptr %l0, !tbaa !29
  %t497 = load { i64, ptr }, ptr %l24, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s8, ptr %t496, { i64, ptr } %t497)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb65:
  %t501 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t501, ptr %l212
  br label %bb66
bb66:
  %t502 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l212
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t502, ptr %l30
  store i64 0, ptr %l31, !tbaa !24
  %t503 = load i64, ptr %l8, !tbaa !24
  store i64 %t503, ptr %l32, !tbaa !24
  store i64 1, ptr %l33, !tbaa !24
  %t505 = load i64, ptr %l32, !tbaa !24
  %t506 = load i64, ptr %l31, !tbaa !24
  %t509 = icmp sgt i64 %t505, %t506
  br i1 %t509, label %bb67, label %bb68
bb67:
  %t511 = load i64, ptr %l33, !tbaa !24
  %t513 = icmp sgt i64 %t511, 0
  br i1 %t513, label %bb69, label %bb70
bb68:
  store i64 0, ptr %l217, !tbaa !24
  br label %bb72
bb69:
  %t515 = load i64, ptr %l32, !tbaa !24
  %t516 = load i64, ptr %l31, !tbaa !24
  %t519 = sub i64 %t515, %t516
  %t520 = load i64, ptr %l33, !tbaa !24
  %t523 = add i64 %t519, %t520
  %t525 = sub i64 %t523, 1
  %t526 = load i64, ptr %l33, !tbaa !24
  %t529 = sdiv i64 %t525, %t526
  store i64 %t529, ptr %l220, !tbaa !24
  br label %bb71
bb70:
  store i64 0, ptr %l220, !tbaa !24
  br label %bb71
bb71:
  %t531 = load i64, ptr %l220, !tbaa !24
  store i64 %t531, ptr %l217, !tbaa !24
  br label %bb72
bb72:
  %t532 = load i64, ptr %l217, !tbaa !24
  store i64 %t532, ptr %l34, !tbaa !24
  store i64 0, ptr %l35, !tbaa !24
  br label %bb73
bb73:
  %t533 = load i64, ptr %l35, !tbaa !24
  %t534 = load i64, ptr %l34, !tbaa !24
  %t537 = icmp slt i64 %t533, %t534
  %t539 = xor i1 %t537, true
  br i1 %t539, label %bb74, label %bb75
bb74:
  br label %bb81
bb75:
  br label %bb76
bb76:
  %t541 = load i64, ptr %l31, !tbaa !24
  %t542 = load i64, ptr %l35, !tbaa !24
  %t543 = load i64, ptr %l33, !tbaa !24
  %t546 = mul i64 %t542, %t543
  %t549 = add i64 %t541, %t546
  store ptr %l30, ptr %l238, !tbaa !29
  %t551 = load ptr, ptr %l0, !tbaa !29
  store ptr %t551, ptr %l239, !tbaa !29
  %t552 = load ptr, ptr %l0, !tbaa !29
  %t553 = load %"compiler/mir:Range", ptr %l6
  %t558 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t552, %"compiler/mir:Range" %t553, i64 %t549)
  store { i64, [4 x i64] } %t558, ptr %l243
  br label %bb77
bb77:
  %t559 = load i32, ptr %l9, !tbaa !23
  %t560 = load ptr, ptr %l239, !tbaa !29
  %t561 = load { i64, [4 x i64] }, ptr %l243
  %t563 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s1, ptr %t560, { i64, [4 x i64] } %t561, i32 %t559)
  store { i64, ptr } %t563, ptr %l245
  br label %bb78
bb78:
  %t564 = load { i64, ptr }, ptr %l245, !tbaa !27
  %t565 = extractvalue { i64, ptr } %t564, 0
  %t566 = extractvalue { i64, ptr } %t564, 1
  %t567 = mul i64 %t565, 1
  %t568 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t567)
  call void @llvm.memcpy.p0.p0.i64(ptr %t568, ptr %t566, i64 %t567, i1 false)
  %t569 = insertvalue { i64, ptr } undef, i64 %t565, 0
  %t570 = insertvalue { i64, ptr } %t569, ptr %t568, 1
  %t571 = load ptr, ptr %l238, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s1, ptr %s1, ptr %t571, { i64, ptr } %t570)
  br label %bb79
bb79:
  br label %bb80
bb80:
  %t573 = load i64, ptr %l35, !tbaa !24
  %t575 = add i64 %t573, 1
  store i64 %t575, ptr %l35, !tbaa !24
  br label %bb73
bb81:
  %t577 = load ptr, ptr %l0, !tbaa !29
  %t578 = load %"compiler/mir:Place", ptr %l1
  %t581 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s1, ptr %t577, %"compiler/mir:Place" %t578)
  store { { i64, ptr }, i32 } %t581, ptr %l251
  br label %bb82
bb82:
  %t582 = load { { i64, ptr }, i32 }, ptr %l251
  store { { i64, ptr }, i32 } %t582, ptr %l37
  %t583 = getelementptr { { i64, ptr }, i32 }, ptr %l37, i32 0, i32 0
  %t584 = load { i64, ptr }, ptr %t583, !tbaa !27
  store { i64, ptr } %t584, ptr %l252, !tbaa !27
  %t585 = load { i64, ptr }, ptr %l252, !tbaa !27
  %t586 = extractvalue { i64, ptr } %t585, 0
  store i64 %t586, ptr %l253, !tbaa !24
  %t587 = load i64, ptr %l253, !tbaa !24
  %t588 = mul i64 %t587, 1
  %t589 = call ptr @__olang_scope_alloc_zeroed(ptr %s1, i64 %t588)
  %t590 = insertvalue { i64, ptr } undef, i64 %t587, 0
  %t591 = insertvalue { i64, ptr } %t590, ptr %t589, 1
  store { i64, ptr } %t591, ptr %l254, !tbaa !27
  %t592 = getelementptr { i64, ptr }, ptr %l254, i32 0, i32 1
  %t593 = load ptr, ptr %t592, !tbaa !27
  %t594 = getelementptr { i64, ptr }, ptr %l252, i32 0, i32 1
  %t595 = load ptr, ptr %t594, !tbaa !27
  %t596 = load i64, ptr %l253, !tbaa !24
  %t597 = mul i64 %t596, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t593, ptr %t595, i64 %t597, i1 false)
  %t598 = load { i64, ptr }, ptr %l254, !tbaa !27
  store { i64, ptr } %t598, ptr %l38, !tbaa !27
  store i64 0, ptr %l39, !tbaa !24
  %t599 = load i64, ptr %l8, !tbaa !24
  store i64 %t599, ptr %l40, !tbaa !24
  store i64 1, ptr %l41, !tbaa !24
  %t601 = load i64, ptr %l40, !tbaa !24
  %t602 = load i64, ptr %l39, !tbaa !24
  %t605 = icmp sgt i64 %t601, %t602
  br i1 %t605, label %bb83, label %bb84
bb83:
  %t607 = load i64, ptr %l41, !tbaa !24
  %t609 = icmp sgt i64 %t607, 0
  br i1 %t609, label %bb85, label %bb86
bb84:
  store i64 0, ptr %l259, !tbaa !24
  br label %bb88
bb85:
  %t611 = load i64, ptr %l40, !tbaa !24
  %t612 = load i64, ptr %l39, !tbaa !24
  %t615 = sub i64 %t611, %t612
  %t616 = load i64, ptr %l41, !tbaa !24
  %t619 = add i64 %t615, %t616
  %t621 = sub i64 %t619, 1
  %t622 = load i64, ptr %l41, !tbaa !24
  %t625 = sdiv i64 %t621, %t622
  store i64 %t625, ptr %l262, !tbaa !24
  br label %bb87
bb86:
  store i64 0, ptr %l262, !tbaa !24
  br label %bb87
bb87:
  %t627 = load i64, ptr %l262, !tbaa !24
  store i64 %t627, ptr %l259, !tbaa !24
  br label %bb88
bb88:
  %t628 = load i64, ptr %l259, !tbaa !24
  store i64 %t628, ptr %l42, !tbaa !24
  store i64 0, ptr %l43, !tbaa !24
  br label %bb89
bb89:
  store %olang.scope zeroinitializer, ptr %s21
  %t629 = load i64, ptr %l43, !tbaa !24
  %t630 = load i64, ptr %l42, !tbaa !24
  %t633 = icmp slt i64 %t629, %t630
  %t635 = xor i1 %t633, true
  br i1 %t635, label %bb90, label %bb91
bb90:
  call void @__olang_scope_close(ptr %s21)
  br label %bb97
bb91:
  br label %bb92
bb92:
  %t637 = load i64, ptr %l39, !tbaa !24
  %t638 = load i64, ptr %l43, !tbaa !24
  %t639 = load i64, ptr %l41, !tbaa !24
  %t642 = mul i64 %t638, %t639
  %t645 = add i64 %t637, %t642
  store i64 %t645, ptr %l44, !tbaa !24
  %t647 = load ptr, ptr %l0, !tbaa !29
  %t648 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t649 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t650 = load i64, ptr %l44, !tbaa !24
  %t651 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d122, i32 0, i32 1) }, 1
  %t652 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d122, i32 0, i32 1) }, 0
  %t654 = extractvalue { i64, ptr } %t648, 1
  %t655 = extractvalue { i64, ptr } %t648, 0
  %t656 = add i64 %t652, %t655
  %t657 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d123, i32 0, i32 1) }, 1
  %t658 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d123, i32 0, i32 1) }, 0
  %t659 = add i64 %t656, %t658
  %t661 = extractvalue { i64, ptr } %t649, 1
  %t662 = extractvalue { i64, ptr } %t649, 0
  %t663 = add i64 %t659, %t662
  %t664 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d124, i32 0, i32 1) }, 1
  %t665 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d124, i32 0, i32 1) }, 0
  %t666 = add i64 %t663, %t665
  %t668 = call i64 @__olang_fmt_i64(ptr null, i64 %t650)
  %t669 = add i64 %t666, %t668
  %t670 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t669)
  call void @olang_textcopy(ptr %t670, ptr %t651, i64 %t652)
  %t671 = getelementptr i8, ptr %t670, i64 %t652
  call void @olang_textcopy(ptr %t671, ptr %t654, i64 %t655)
  %t672 = getelementptr i8, ptr %t671, i64 %t655
  call void @olang_textcopy(ptr %t672, ptr %t657, i64 %t658)
  %t673 = getelementptr i8, ptr %t672, i64 %t658
  call void @olang_textcopy(ptr %t673, ptr %t661, i64 %t662)
  %t674 = getelementptr i8, ptr %t673, i64 %t662
  call void @olang_textcopy(ptr %t674, ptr %t664, i64 %t665)
  %t675 = getelementptr i8, ptr %t674, i64 %t665
  %t676 = call i64 @__olang_fmt_i64(ptr %t675, i64 %t650)
  %t677 = insertvalue { i64, ptr } undef, i64 %t669, 0
  %t678 = insertvalue { i64, ptr } %t677, ptr %t670, 1
  %t680 = extractvalue { i64, ptr } %t678, 0
  %t681 = extractvalue { i64, ptr } %t678, 1
  %t682 = mul i64 %t680, 1
  %t683 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t682)
  call void @llvm.memcpy.p0.p0.i64(ptr %t683, ptr %t681, i64 %t682, i1 false)
  %t684 = insertvalue { i64, ptr } undef, i64 %t680, 0
  %t685 = insertvalue { i64, ptr } %t684, ptr %t683, 1
  %t688 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s21, ptr %s21, ptr %t647, { i64, ptr } %t685)
  store { i64, ptr } %t688, ptr %l286
  br label %bb93
bb93:
  %t689 = load { i64, ptr }, ptr %l286, !tbaa !27
  store { i64, ptr } %t689, ptr %l45, !tbaa !27
  %t690 = load ptr, ptr %l0, !tbaa !29
  store ptr %t690, ptr %l287, !tbaa !29
  %t691 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t691, ptr %l288, !tbaa !27
  %t692 = load i64, ptr %l44, !tbaa !24
  %t695 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s1, ptr %s1, ptr %l30, i64 %t692)
  store { i64, ptr } %t695, ptr %l291
  br label %bb94
bb94:
  %t696 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t697 = load ptr, ptr %l287, !tbaa !29
  %t698 = load { i64, ptr }, ptr %l288, !tbaa !27
  %t699 = load { i64, ptr }, ptr %l291, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s1, ptr %s1, ptr %s21, ptr %s21, ptr %t697, { i64, ptr } %t698, { i64, ptr } %t699, { i64, ptr } %t696, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d118, i32 0, i32 1) })
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s21)
  br label %bb96
bb96:
  %t701 = load i64, ptr %l43, !tbaa !24
  %t703 = add i64 %t701, 1
  store i64 %t703, ptr %l43, !tbaa !24
  br label %bb89
bb97:
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb98:
  %t706 = load { i64, [15 x i64] }, ptr %l3
  %t708 = extractvalue { i64, [15 x i64] } %t706, 0
  %t709 = icmp eq i64 %t708, 0
  br i1 %t709, label %bb99, label %bb100
bb99:
  %t711 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t712 = getelementptr { { i64, [4 x i64] } }, ptr %t711, i32 0, i32 0
  %t713 = load { i64, [4 x i64] }, ptr %t712
  store { i64, [4 x i64] } %t713, ptr %l46
  br label %bb101
bb100:
  br label %bb144
bb101:
  %t715 = load { i64, [4 x i64] }, ptr %l46
  %t717 = extractvalue { i64, [4 x i64] } %t715, 0
  %t718 = icmp eq i64 %t717, 1
  br i1 %t718, label %bb102, label %bb103
bb102:
  %t720 = getelementptr { i64, [4 x i64] }, ptr %l46, i32 0, i32 1
  %t721 = getelementptr { %"compiler/mir:Place" }, ptr %t720, i32 0, i32 0
  %t722 = load %"compiler/mir:Place", ptr %t721
  store %"compiler/mir:Place" %t722, ptr %l47
  br label %bb104
bb103:
  br label %bb139
bb104:
  store %olang.scope zeroinitializer, ptr %s25
  %t724 = load ptr, ptr %l4, !tbaa !29
  store ptr %t724, ptr %l302, !tbaa !29
  %t725 = load ptr, ptr %l4, !tbaa !29
  %t726 = load i32, ptr %l2, !tbaa !23
  %t729 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t725, i32 %t726)
  store i32 %t729, ptr %l305
  br label %bb105
bb105:
  %t730 = load ptr, ptr %l302, !tbaa !29
  %t731 = load i32, ptr %l305, !tbaa !23
  %t732 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t730, i32 %t731)
  store i32 %t732, ptr %l306
  br label %bb106
bb106:
  %t733 = load i32, ptr %l306
  store i32 %t733, ptr %l48
  %t734 = load i32, ptr %l48
  %t736 = trunc i64 19 to i32
  %t737 = icmp eq i32 %t734, %t736
  %t739 = xor i1 %t737, true
  br i1 %t739, label %bb107, label %bb108
bb107:
  %t741 = load i32, ptr %l48
  %t743 = trunc i64 18 to i32
  %t744 = icmp eq i32 %t741, %t743
  %t746 = xor i1 %t744, true
  store i1 %t746, ptr %l310, !tbaa !21
  br label %bb109
bb108:
  store i1 false, ptr %l310, !tbaa !21
  br label %bb109
bb109:
  %t748 = load i1, ptr %l310, !tbaa !21
  br i1 %t748, label %bb110, label %bb111
bb110:
  %t749 = load i32, ptr %l48
  %t751 = trunc i64 24 to i32
  %t752 = icmp eq i32 %t749, %t751
  %t754 = xor i1 %t752, true
  store i1 %t754, ptr %l314, !tbaa !21
  br label %bb112
bb111:
  store i1 false, ptr %l314, !tbaa !21
  br label %bb112
bb112:
  %t756 = load i1, ptr %l314, !tbaa !21
  br i1 %t756, label %bb113, label %bb114
bb113:
  call void @__olang_scope_close(ptr %s25)
  store i1 false, ptr %rv
  br label %ret
bb114:
  br label %bb115
bb115:
  %t758 = load ptr, ptr %l4, !tbaa !29
  store ptr %t758, ptr %l319, !tbaa !29
  %t759 = load ptr, ptr %l4, !tbaa !29
  %t760 = load i32, ptr %l2, !tbaa !23
  %t763 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t759, i32 %t760)
  store i32 %t763, ptr %l322
  br label %bb116
bb116:
  %t764 = load ptr, ptr %l319, !tbaa !29
  %t765 = load i32, ptr %l322, !tbaa !23
  %t766 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t764, i32 %t765)
  store i32 %t766, ptr %l323
  br label %bb117
bb117:
  %t767 = load i32, ptr %l323
  %t769 = trunc i64 19 to i32
  %t770 = icmp eq i32 %t767, %t769
  br i1 %t770, label %bb118, label %bb119
bb118:
  %t772 = load ptr, ptr %l0, !tbaa !29
  store ptr %t772, ptr %l327, !tbaa !29
  %t773 = load ptr, ptr %l4, !tbaa !29
  %t774 = load i32, ptr %l2, !tbaa !23
  %t777 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t773, i32 %t774)
  store i32 %t777, ptr %l330
  br label %bb120
bb119:
  store i1 false, ptr %l326, !tbaa !21
  br label %bb122
bb120:
  %t778 = load ptr, ptr %l327, !tbaa !29
  %t779 = load i32, ptr %l330, !tbaa !23
  %t780 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixed(ptr %v0, ptr %t778, i32 %t779)
  store i1 %t780, ptr %l331
  br label %bb121
bb121:
  %t781 = load i1, ptr %l331, !tbaa !21
  %t782 = xor i1 %t781, true
  store i1 %t782, ptr %l326, !tbaa !21
  br label %bb122
bb122:
  %t784 = load i1, ptr %l326, !tbaa !21
  br i1 %t784, label %bb123, label %bb124
bb123:
  call void @__olang_scope_close(ptr %s25)
  store i1 false, ptr %rv
  br label %ret
bb124:
  br label %bb125
bb125:
  %t786 = load ptr, ptr %l0, !tbaa !29
  %t787 = load i32, ptr %l2, !tbaa !23
  %t790 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t786, i32 %t787)
  store i64 %t790, ptr %l336
  br label %bb126
bb126:
  %t791 = load i64, ptr %l336, !tbaa !24
  %t792 = icmp sle i64 %t791, 128
  br i1 %t792, label %bb127, label %bb128
bb127:
  store i1 true, ptr %l338, !tbaa !21
  br label %bb130
bb128:
  %t794 = load ptr, ptr %l0, !tbaa !29
  %t795 = load %"compiler/mir:Place", ptr %l47
  %t798 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eplaceType(ptr %v0, ptr %t794, %"compiler/mir:Place" %t795)
  store i32 %t798, ptr %l341
  br label %bb129
bb129:
  %t799 = load i32, ptr %l2, !tbaa !23
  %t800 = load i32, ptr %l341, !tbaa !23
  %t802 = icmp ne i32 %t800, %t799
  store i1 %t802, ptr %l338, !tbaa !21
  br label %bb130
bb130:
  %t804 = load i1, ptr %l338, !tbaa !21
  br i1 %t804, label %bb131, label %bb132
bb131:
  call void @__olang_scope_close(ptr %s25)
  store i1 false, ptr %rv
  br label %ret
bb132:
  br label %bb133
bb133:
  %t806 = load ptr, ptr %l0, !tbaa !29
  %t807 = load %"compiler/mir:Place", ptr %l47
  %t810 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s25, ptr %t806, %"compiler/mir:Place" %t807)
  store { { i64, ptr }, i32 } %t810, ptr %l347
  br label %bb134
bb134:
  %t811 = load { { i64, ptr }, i32 }, ptr %l347
  store { { i64, ptr }, i32 } %t811, ptr %l49
  %t812 = getelementptr { { i64, ptr }, i32 }, ptr %l49, i32 0, i32 0
  %t813 = load { i64, ptr }, ptr %t812, !tbaa !27
  store { i64, ptr } %t813, ptr %l348, !tbaa !27
  %t814 = load { i64, ptr }, ptr %l348, !tbaa !27
  %t815 = extractvalue { i64, ptr } %t814, 0
  store i64 %t815, ptr %l349, !tbaa !24
  %t816 = load i64, ptr %l349, !tbaa !24
  %t817 = mul i64 %t816, 1
  %t818 = call ptr @__olang_scope_alloc_zeroed(ptr %s25, i64 %t817)
  %t819 = insertvalue { i64, ptr } undef, i64 %t816, 0
  %t820 = insertvalue { i64, ptr } %t819, ptr %t818, 1
  store { i64, ptr } %t820, ptr %l350, !tbaa !27
  %t821 = getelementptr { i64, ptr }, ptr %l350, i32 0, i32 1
  %t822 = load ptr, ptr %t821, !tbaa !27
  %t823 = getelementptr { i64, ptr }, ptr %l348, i32 0, i32 1
  %t824 = load ptr, ptr %t823, !tbaa !27
  %t825 = load i64, ptr %l349, !tbaa !24
  %t826 = mul i64 %t825, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t822, ptr %t824, i64 %t826, i1 false)
  %t827 = load { i64, ptr }, ptr %l350, !tbaa !27
  store { i64, ptr } %t827, ptr %l50, !tbaa !27
  %t828 = load ptr, ptr %l0, !tbaa !29
  %t829 = load %"compiler/mir:Place", ptr %l1
  %t832 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s25, ptr %t828, %"compiler/mir:Place" %t829)
  store { { i64, ptr }, i32 } %t832, ptr %l353
  br label %bb135
bb135:
  %t833 = load { { i64, ptr }, i32 }, ptr %l353
  store { { i64, ptr }, i32 } %t833, ptr %l51
  %t834 = getelementptr { { i64, ptr }, i32 }, ptr %l51, i32 0, i32 0
  %t835 = load { i64, ptr }, ptr %t834, !tbaa !27
  store { i64, ptr } %t835, ptr %l354, !tbaa !27
  %t836 = load { i64, ptr }, ptr %l354, !tbaa !27
  %t837 = extractvalue { i64, ptr } %t836, 0
  store i64 %t837, ptr %l355, !tbaa !24
  %t838 = load i64, ptr %l355, !tbaa !24
  %t839 = mul i64 %t838, 1
  %t840 = call ptr @__olang_scope_alloc_zeroed(ptr %s25, i64 %t839)
  %t841 = insertvalue { i64, ptr } undef, i64 %t838, 0
  %t842 = insertvalue { i64, ptr } %t841, ptr %t840, 1
  store { i64, ptr } %t842, ptr %l356, !tbaa !27
  %t843 = getelementptr { i64, ptr }, ptr %l356, i32 0, i32 1
  %t844 = load ptr, ptr %t843, !tbaa !27
  %t845 = getelementptr { i64, ptr }, ptr %l354, i32 0, i32 1
  %t846 = load ptr, ptr %t845, !tbaa !27
  %t847 = load i64, ptr %l355, !tbaa !24
  %t848 = mul i64 %t847, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t844, ptr %t846, i64 %t848, i1 false)
  %t849 = load { i64, ptr }, ptr %l356, !tbaa !27
  store { i64, ptr } %t849, ptr %l52, !tbaa !27
  %t850 = load ptr, ptr %l0, !tbaa !29
  %t852 = getelementptr %"compiler/emit:fnEm", ptr %t850, i32 0, i32 0
  %t853 = load ptr, ptr %t852, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s25, ptr %s25, ptr %t853, { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d125, i32 0, i32 1) }, { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d126, i32 0, i32 1) })
  br label %bb136
bb136:
  %t855 = load ptr, ptr %l0, !tbaa !29
  store ptr %t855, ptr %l359, !tbaa !29
  %t856 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t856, ptr %l360, !tbaa !27
  %t857 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t857, ptr %l361, !tbaa !27
  %t858 = load ptr, ptr %l0, !tbaa !29
  %t859 = load i32, ptr %l2, !tbaa !23
  %t862 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t858, i32 %t859)
  store i64 %t862, ptr %l364
  br label %bb137
bb137:
  %t863 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d127, i32 0, i32 1) }, 1
  %t864 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d127, i32 0, i32 1) }, 0
  %t865 = load { i64, ptr }, ptr %l360, !tbaa !27
  %t866 = extractvalue { i64, ptr } %t865, 1
  %t867 = extractvalue { i64, ptr } %t865, 0
  %t868 = add i64 %t864, %t867
  %t869 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d128, i32 0, i32 1) }, 1
  %t870 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d128, i32 0, i32 1) }, 0
  %t871 = add i64 %t868, %t870
  %t872 = load { i64, ptr }, ptr %l361, !tbaa !27
  %t873 = extractvalue { i64, ptr } %t872, 1
  %t874 = extractvalue { i64, ptr } %t872, 0
  %t875 = add i64 %t871, %t874
  %t876 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d129, i32 0, i32 1) }, 1
  %t877 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d129, i32 0, i32 1) }, 0
  %t878 = add i64 %t875, %t877
  %t879 = load i64, ptr %l364, !tbaa !24
  %t880 = call i64 @__olang_fmt_i64(ptr null, i64 %t879)
  %t881 = add i64 %t878, %t880
  %t882 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d130, i32 0, i32 1) }, 1
  %t883 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d130, i32 0, i32 1) }, 0
  %t884 = add i64 %t881, %t883
  %t885 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t884)
  call void @olang_textcopy(ptr %t885, ptr %t863, i64 %t864)
  %t886 = getelementptr i8, ptr %t885, i64 %t864
  call void @olang_textcopy(ptr %t886, ptr %t866, i64 %t867)
  %t887 = getelementptr i8, ptr %t886, i64 %t867
  call void @olang_textcopy(ptr %t887, ptr %t869, i64 %t870)
  %t888 = getelementptr i8, ptr %t887, i64 %t870
  call void @olang_textcopy(ptr %t888, ptr %t873, i64 %t874)
  %t889 = getelementptr i8, ptr %t888, i64 %t874
  call void @olang_textcopy(ptr %t889, ptr %t876, i64 %t877)
  %t890 = getelementptr i8, ptr %t889, i64 %t877
  %t891 = call i64 @__olang_fmt_i64(ptr %t890, i64 %t879)
  %t892 = getelementptr i8, ptr %t890, i64 %t880
  call void @olang_textcopy(ptr %t892, ptr %t882, i64 %t883)
  %t893 = insertvalue { i64, ptr } undef, i64 %t884, 0
  %t894 = insertvalue { i64, ptr } %t893, ptr %t885, 1
  %t896 = extractvalue { i64, ptr } %t894, 0
  %t897 = extractvalue { i64, ptr } %t894, 1
  %t898 = mul i64 %t896, 1
  %t899 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t898)
  call void @llvm.memcpy.p0.p0.i64(ptr %t899, ptr %t897, i64 %t898, i1 false)
  %t900 = insertvalue { i64, ptr } undef, i64 %t896, 0
  %t901 = insertvalue { i64, ptr } %t900, ptr %t899, 1
  %t902 = load ptr, ptr %l359, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s25, ptr %t902, { i64, ptr } %t901)
  br label %bb138
bb138:
  call void @__olang_scope_close(ptr %s25)
  store i1 true, ptr %rv
  br label %ret
bb139:
  br i1 true, label %bb140, label %bb141
bb140:
  br label %bb142
bb141:
  br label %bb143
bb142:
  store i1 false, ptr %rv
  br label %ret
bb143:
  call void @__olang_check_failed(ptr @olang_loc_9357034ceffa49e9_ad514f9345461395)
  unreachable
bb144:
  br i1 true, label %bb145, label %bb146
bb145:
  br label %bb147
bb146:
  br label %bb148
bb147:
  store i1 false, ptr %rv
  br label %ret
bb148:
  call void @__olang_check_failed(ptr @olang_loc_1dffb4089bad5318_6447f84abd9ba4a4)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2efindIdle(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/mir:BasicBlock"
  %l8 = alloca { i64, [8 x i64] }
  %l9 = alloca %"compiler/mir:Range"
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca %"compiler/mir:BasicBlock"
  %l25 = alloca ptr
  %l26 = alloca i64
  %l27 = alloca { i64, [21 x i64] }
  %l28 = alloca { i64, [1 x i64] }
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca { i64, [15 x i64] }
  %l32 = alloca { i64, [1 x i64] }
  %l33 = alloca { i64, [1 x i64] }
  %l34 = alloca { i64, [1 x i64] }
  %l35 = alloca { i64, [1 x i64] }
  %l36 = alloca { i64, [8 x i64] }
  %l37 = alloca i32
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca %"compiler/mir:Local"
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i32
  %l52 = alloca i64
  %l57 = alloca i64
  %l62 = alloca i64
  %l64 = alloca i64
  %l69 = alloca %"compiler/mir:BasicBlock"
  %l78 = alloca i32
  %l81 = alloca i32
  %l110 = alloca i64
  %l114 = alloca i64
  %l117 = alloca i64
  %l138 = alloca ptr
  %l142 = alloca { i64, [1 x i64] }
  %l144 = alloca i1
  %l145 = alloca i1
  %l151 = alloca i64
  %l153 = alloca i64
  %l158 = alloca %"compiler/mir:BasicBlock"
  %l160 = alloca i64
  %l162 = alloca i64
  %l167 = alloca { i64, [21 x i64] }
  %l168 = alloca { i64, [21 x i64] }
  %l171 = alloca { i64, [21 x i64] }
  %l174 = alloca { i64, [21 x i64] }
  %l180 = alloca i1
  %l181 = alloca i1
  %l183 = alloca { i64, [21 x i64] }
  %l188 = alloca { i64, [21 x i64] }
  %l193 = alloca { i64, [21 x i64] }
  %l208 = alloca i1
  %l209 = alloca i1
  %l218 = alloca i1
  %l219 = alloca i1
  %l224 = alloca i1
  %l225 = alloca i1
  %l236 = alloca i1
  %l237 = alloca i1
  %l251 = alloca i64
  %l253 = alloca i64
  %l258 = alloca %"compiler/mir:Local"
  %l261 = alloca i1
  %l266 = alloca i1
  %l267 = alloca i1
  %l273 = alloca i64
  %l277 = alloca i64
  %l280 = alloca i64
  %l301 = alloca %"compiler/mir:ScopeInfo"
  %l306 = alloca i1
  %l310 = alloca i1
  %l316 = alloca i1
  %l318 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/mir:Fn", ptr %t6, i32 0, i32 8
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l52
  br label %bb1
bb1:
  %t11 = load i64, ptr %l52, !tbaa !24
  %t12 = icmp sge i64 %t11, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = load i64, ptr %l52, !tbaa !24
  %t15 = mul i64 %t14, 1
  %t16 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l2, !tbaa !27
  store i1 false, ptr %l3, !tbaa !21
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr %"compiler/mir:Fn", ptr %t20, i32 0, i32 12
  %t24 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eLen_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t22)
  store i64 %t24, ptr %l57
  br label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_3b6348629663638e_4d98396f767ecbfa)
  unreachable
bb4:
  %t25 = load i64, ptr %l57, !tbaa !24
  %t26 = icmp sge i64 %t25, 0
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t28 = load i64, ptr %l57, !tbaa !24
  %t29 = mul i64 %t28, 1
  %t30 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t29)
  %t31 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  store { i64, ptr } %t32, ptr %l4, !tbaa !27
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr %"compiler/mir:Fn", ptr %t34, i32 0, i32 9
  store ptr %t36, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_e68eff5da6298283_f7922e79bdd8a34f)
  unreachable
bb7:
  %t38 = load i64, ptr %l6, !tbaa !24
  store i64 %t38, ptr %l62, !tbaa !24
  %t39 = load ptr, ptr %l5, !tbaa !29
  %t41 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %t39)
  store i64 %t41, ptr %l64
  br label %bb8
bb8:
  %t42 = load i64, ptr %l62, !tbaa !24
  %t43 = load i64, ptr %l64, !tbaa !24
  %t44 = icmp slt i64 %t42, %t43
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb9, label %bb10
bb9:
  br label %bb35
bb10:
  br label %bb11
bb11:
  %t48 = load ptr, ptr %l5, !tbaa !29
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = call %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v0, ptr %t48, i64 %t49)
  store %"compiler/mir:BasicBlock" %t52, ptr %l69
  br label %bb12
bb12:
  %t53 = load %"compiler/mir:BasicBlock", ptr %l69
  store %"compiler/mir:BasicBlock" %t53, ptr %l7
  %t54 = getelementptr %"compiler/mir:BasicBlock", ptr %l7, i32 0, i32 1
  %t55 = load { i64, [8 x i64] }, ptr %t54
  store { i64, [8 x i64] } %t55, ptr %l8
  %t57 = load { i64, [8 x i64] }, ptr %l8
  %t59 = extractvalue { i64, [8 x i64] } %t57, 0
  %t60 = icmp eq i64 %t59, 10
  br i1 %t60, label %bb13, label %bb14
bb13:
  %t62 = getelementptr { i64, [8 x i64] }, ptr %l8, i32 0, i32 1
  %t63 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t62, i32 0, i32 3
  %t64 = load %"compiler/mir:Range", ptr %t63
  store %"compiler/mir:Range" %t64, ptr %l9
  br label %bb15
bb14:
  br label %bb28
bb15:
  store i32 0, ptr %l10, !tbaa !23
  %t66 = getelementptr %"compiler/mir:Range", ptr %l9, i32 0, i32 1
  %t67 = load i32, ptr %t66, !tbaa !23
  store i32 %t67, ptr %l11, !tbaa !23
  store i32 1, ptr %l12, !tbaa !23
  %t69 = load i32, ptr %l11, !tbaa !23
  %t70 = load i32, ptr %l10, !tbaa !23
  %t73 = icmp sgt i32 %t69, %t70
  br i1 %t73, label %bb16, label %bb17
bb16:
  %t75 = load i32, ptr %l12, !tbaa !23
  %t77 = icmp sgt i32 %t75, 0
  br i1 %t77, label %bb18, label %bb19
bb17:
  store i32 0, ptr %l78, !tbaa !23
  br label %bb21
bb18:
  %t79 = load i32, ptr %l11, !tbaa !23
  %t80 = load i32, ptr %l10, !tbaa !23
  %t83 = sub i32 %t79, %t80
  %t84 = load i32, ptr %l12, !tbaa !23
  %t87 = add i32 %t83, %t84
  %t89 = sub i32 %t87, 1
  %t90 = load i32, ptr %l12, !tbaa !23
  %t93 = sdiv i32 %t89, %t90
  store i32 %t93, ptr %l81, !tbaa !23
  br label %bb20
bb19:
  store i32 0, ptr %l81, !tbaa !23
  br label %bb20
bb20:
  %t95 = load i32, ptr %l81, !tbaa !23
  store i32 %t95, ptr %l78, !tbaa !23
  br label %bb21
bb21:
  %t96 = load i32, ptr %l78, !tbaa !23
  store i32 %t96, ptr %l13, !tbaa !23
  store i32 0, ptr %l14, !tbaa !23
  br label %bb22
bb22:
  %t97 = load i32, ptr %l14, !tbaa !23
  %t98 = load i32, ptr %l13, !tbaa !23
  %t101 = icmp slt i32 %t97, %t98
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t105 = load i32, ptr %l10, !tbaa !23
  %t106 = load i32, ptr %l14, !tbaa !23
  %t107 = load i32, ptr %l12, !tbaa !23
  %t110 = mul i32 %t106, %t107
  %t113 = add i32 %t105, %t110
  %t115 = getelementptr %"compiler/mir:Range", ptr %l9, i32 0, i32 0
  %t116 = load i32, ptr %t115, !tbaa !23
  %t118 = sext i32 %t116 to i64
  %t121 = sext i32 %t113 to i64
  %t124 = add i64 %t118, %t121
  %t126 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr i1, ptr %t127, i64 %t124
  store i1 true, ptr %t128, !tbaa !31
  br label %bb26
bb26:
  %t129 = load i32, ptr %l14, !tbaa !23
  %t131 = add i32 %t129, 1
  store i32 %t131, ptr %l14, !tbaa !23
  br label %bb22
bb27:
  br label %bb33
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_7398c824c6ccd25f_37644bbf4fe2ca83)
  unreachable
bb33:
  br label %bb34
bb34:
  %t133 = load i64, ptr %l6, !tbaa !24
  %t135 = add i64 %t133, 1
  store i64 %t135, ptr %l6, !tbaa !24
  br label %bb7
bb35:
  store i64 0, ptr %l16, !tbaa !24
  %t137 = load ptr, ptr %l1, !tbaa !29
  %t139 = getelementptr %"compiler/mir:Fn", ptr %t137, i32 0, i32 12
  %t141 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eLen_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t139)
  store i64 %t141, ptr %l110
  br label %bb36
bb36:
  %t142 = load i64, ptr %l110, !tbaa !24
  store i64 %t142, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t143 = load i64, ptr %l17, !tbaa !24
  %t144 = load i64, ptr %l16, !tbaa !24
  %t147 = icmp sgt i64 %t143, %t144
  br i1 %t147, label %bb37, label %bb38
bb37:
  %t149 = load i64, ptr %l18, !tbaa !24
  %t151 = icmp sgt i64 %t149, 0
  br i1 %t151, label %bb39, label %bb40
bb38:
  store i64 0, ptr %l114, !tbaa !24
  br label %bb42
bb39:
  %t153 = load i64, ptr %l17, !tbaa !24
  %t154 = load i64, ptr %l16, !tbaa !24
  %t157 = sub i64 %t153, %t154
  %t158 = load i64, ptr %l18, !tbaa !24
  %t161 = add i64 %t157, %t158
  %t163 = sub i64 %t161, 1
  %t164 = load i64, ptr %l18, !tbaa !24
  %t167 = sdiv i64 %t163, %t164
  store i64 %t167, ptr %l117, !tbaa !24
  br label %bb41
bb40:
  store i64 0, ptr %l117, !tbaa !24
  br label %bb41
bb41:
  %t169 = load i64, ptr %l117, !tbaa !24
  store i64 %t169, ptr %l114, !tbaa !24
  br label %bb42
bb42:
  %t170 = load i64, ptr %l114, !tbaa !24
  store i64 %t170, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb43
bb43:
  %t171 = load i64, ptr %l20, !tbaa !24
  %t172 = load i64, ptr %l19, !tbaa !24
  %t175 = icmp slt i64 %t171, %t172
  %t177 = xor i1 %t175, true
  br i1 %t177, label %bb44, label %bb45
bb44:
  br label %bb56
bb45:
  br label %bb46
bb46:
  %t179 = load i64, ptr %l16, !tbaa !24
  %t180 = load i64, ptr %l20, !tbaa !24
  %t181 = load i64, ptr %l18, !tbaa !24
  %t184 = mul i64 %t180, %t181
  %t187 = add i64 %t179, %t184
  store i64 %t187, ptr %l21, !tbaa !24
  %t189 = load i64, ptr %l21, !tbaa !24
  %t191 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !27
  %t193 = getelementptr i1, ptr %t192, i64 %t189
  %t194 = load i1, ptr %t193, !tbaa !31
  %t196 = xor i1 %t194, true
  br i1 %t196, label %bb47, label %bb48
bb47:
  %t198 = load ptr, ptr %l0, !tbaa !29
  store ptr %t198, ptr %l138, !tbaa !29
  %t199 = load ptr, ptr %l1, !tbaa !29
  %t201 = getelementptr %"compiler/mir:Fn", ptr %t199, i32 0, i32 12
  %t202 = load i64, ptr %l21, !tbaa !24
  %t205 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t201, i64 %t202)
  store { i64, [1 x i64] } %t205, ptr %l142
  br label %bb49
bb48:
  br label %bb54
bb49:
  %t206 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t207 = load ptr, ptr %l138, !tbaa !29
  %t208 = load { i64, [1 x i64] }, ptr %l142
  %t210 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2euseRef(ptr %v0, ptr %s0, ptr %t207, { i64, [1 x i64] } %t208, { i64, ptr } %t206)
  store i1 %t210, ptr %l144
  br label %bb50
bb50:
  %t211 = load i1, ptr %l144, !tbaa !21
  br i1 %t211, label %bb51, label %bb52
bb51:
  store i1 true, ptr %l145, !tbaa !21
  br label %bb53
bb52:
  %t212 = load i1, ptr %l3, !tbaa !21
  store i1 %t212, ptr %l145, !tbaa !21
  br label %bb53
bb53:
  %t214 = load i1, ptr %l145, !tbaa !21
  store i1 %t214, ptr %l3, !tbaa !21
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t215 = load i64, ptr %l20, !tbaa !24
  %t217 = add i64 %t215, 1
  store i64 %t217, ptr %l20, !tbaa !24
  br label %bb43
bb56:
  %t219 = load ptr, ptr %l1, !tbaa !29
  %t221 = getelementptr %"compiler/mir:Fn", ptr %t219, i32 0, i32 9
  store ptr %t221, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  br label %bb57
bb57:
  %t223 = load i64, ptr %l23, !tbaa !24
  store i64 %t223, ptr %l151, !tbaa !24
  %t224 = load ptr, ptr %l22, !tbaa !29
  %t226 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %t224)
  store i64 %t226, ptr %l153
  br label %bb58
bb58:
  %t227 = load i64, ptr %l151, !tbaa !24
  %t228 = load i64, ptr %l153, !tbaa !24
  %t229 = icmp slt i64 %t227, %t228
  %t231 = xor i1 %t229, true
  br i1 %t231, label %bb59, label %bb60
bb59:
  br label %bb149
bb60:
  br label %bb61
bb61:
  %t233 = load ptr, ptr %l22, !tbaa !29
  %t234 = load i64, ptr %l23, !tbaa !24
  %t237 = call %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v0, ptr %t233, i64 %t234)
  store %"compiler/mir:BasicBlock" %t237, ptr %l158
  br label %bb62
bb62:
  %t238 = load %"compiler/mir:BasicBlock", ptr %l158
  store %"compiler/mir:BasicBlock" %t238, ptr %l24
  %t239 = getelementptr %"compiler/mir:BasicBlock", ptr %l24, i32 0, i32 0
  store ptr %t239, ptr %l25, !tbaa !29
  store i64 0, ptr %l26, !tbaa !24
  br label %bb63
bb63:
  %t241 = load i64, ptr %l26, !tbaa !24
  store i64 %t241, ptr %l160, !tbaa !24
  %t242 = load ptr, ptr %l25, !tbaa !29
  %t244 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t242)
  store i64 %t244, ptr %l162
  br label %bb64
bb64:
  %t245 = load i64, ptr %l160, !tbaa !24
  %t246 = load i64, ptr %l162, !tbaa !24
  %t247 = icmp slt i64 %t245, %t246
  %t249 = xor i1 %t247, true
  br i1 %t249, label %bb65, label %bb66
bb65:
  br label %bb138
bb66:
  br label %bb67
bb67:
  %t251 = load ptr, ptr %l25, !tbaa !29
  %t252 = load i64, ptr %l26, !tbaa !24
  %t255 = call { i64, [21 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t251, i64 %t252)
  store { i64, [21 x i64] } %t255, ptr %l167
  br label %bb68
bb68:
  call void @llvm.memmove.p0.p0.i64(ptr %l27, ptr %l167, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l168, ptr %l27, i64 176, i1 false)
  %t256 = load { i64, [21 x i64] }, ptr %l168
  %t257 = extractvalue { i64, [21 x i64] } %t256, 0
  %t258 = icmp eq i64 %t257, 6
  br i1 %t258, label %bb69, label %bb70
bb69:
  %t260 = getelementptr { i64, [21 x i64] }, ptr %l27, i32 0, i32 1
  %t261 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t260, i32 0, i32 1
  %t262 = load { i64, [1 x i64] }, ptr %t261
  store { i64, [1 x i64] } %t262, ptr %l28
  br label %bb75
bb70:
  call void @llvm.memmove.p0.p0.i64(ptr %l171, ptr %l27, i64 176, i1 false)
  %t264 = load { i64, [21 x i64] }, ptr %l171
  %t265 = extractvalue { i64, [21 x i64] } %t264, 0
  %t266 = icmp eq i64 %t265, 7
  br i1 %t266, label %bb71, label %bb72
bb71:
  %t268 = getelementptr { i64, [21 x i64] }, ptr %l27, i32 0, i32 1
  %t269 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, %"compiler/mir:Place" }, ptr %t268, i32 0, i32 1
  %t270 = load { i64, [1 x i64] }, ptr %t269
  store { i64, [1 x i64] } %t270, ptr %l28
  br label %bb75
bb72:
  call void @llvm.memmove.p0.p0.i64(ptr %l174, ptr %l27, i64 176, i1 false)
  %t272 = load { i64, [21 x i64] }, ptr %l174
  %t273 = extractvalue { i64, [21 x i64] } %t272, 0
  %t274 = icmp eq i64 %t273, 9
  br i1 %t274, label %bb73, label %bb74
bb73:
  %t276 = getelementptr { i64, [21 x i64] }, ptr %l27, i32 0, i32 1
  %t277 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t276, i32 0, i32 1
  %t278 = load { i64, [1 x i64] }, ptr %t277
  store { i64, [1 x i64] } %t278, ptr %l28
  br label %bb75
bb74:
  br label %bb80
bb75:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load { i64, [1 x i64] }, ptr %l28
  %t282 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t286 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2euseRef(ptr %v0, ptr %s0, ptr %t280, { i64, [1 x i64] } %t281, { i64, ptr } %t282)
  store i1 %t286, ptr %l180
  br label %bb76
bb76:
  %t287 = load i1, ptr %l180, !tbaa !21
  br i1 %t287, label %bb77, label %bb78
bb77:
  store i1 true, ptr %l181, !tbaa !21
  br label %bb79
bb78:
  %t288 = load i1, ptr %l3, !tbaa !21
  store i1 %t288, ptr %l181, !tbaa !21
  br label %bb79
bb79:
  %t290 = load i1, ptr %l181, !tbaa !21
  store i1 %t290, ptr %l3, !tbaa !21
  br label %bb136
bb80:
  call void @llvm.memmove.p0.p0.i64(ptr %l183, ptr %l27, i64 176, i1 false)
  %t291 = load { i64, [21 x i64] }, ptr %l183
  %t292 = extractvalue { i64, [21 x i64] } %t291, 0
  %t293 = icmp eq i64 %t292, 11
  br i1 %t293, label %bb81, label %bb82
bb81:
  %t295 = getelementptr { i64, [21 x i64] }, ptr %l27, i32 0, i32 1
  %t296 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t295, i32 0, i32 1
  %t297 = load i32, ptr %t296
  store i32 %t297, ptr %l29, !tbaa !23
  br label %bb83
bb82:
  br label %bb84
bb83:
  %t299 = load i32, ptr %l29, !tbaa !23
  %t301 = sext i32 %t299 to i64
  %t303 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t304 = load ptr, ptr %t303, !tbaa !27
  %t305 = getelementptr i1, ptr %t304, i64 %t301
  store i1 true, ptr %t305, !tbaa !31
  br label %bb136
bb84:
  call void @llvm.memmove.p0.p0.i64(ptr %l188, ptr %l27, i64 176, i1 false)
  %t306 = load { i64, [21 x i64] }, ptr %l188
  %t307 = extractvalue { i64, [21 x i64] } %t306, 0
  %t308 = icmp eq i64 %t307, 5
  br i1 %t308, label %bb85, label %bb86
bb85:
  %t310 = getelementptr { i64, [21 x i64] }, ptr %l27, i32 0, i32 1
  %t311 = getelementptr { %"compiler/source:Span", i32 }, ptr %t310, i32 0, i32 1
  %t312 = load i32, ptr %t311
  store i32 %t312, ptr %l30, !tbaa !23
  br label %bb87
bb86:
  br label %bb88
bb87:
  %t314 = load i32, ptr %l30, !tbaa !23
  %t316 = sext i32 %t314 to i64
  %t318 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t319 = load ptr, ptr %t318, !tbaa !27
  %t320 = getelementptr i1, ptr %t319, i64 %t316
  store i1 true, ptr %t320, !tbaa !31
  br label %bb136
bb88:
  call void @llvm.memmove.p0.p0.i64(ptr %l193, ptr %l27, i64 176, i1 false)
  %t321 = load { i64, [21 x i64] }, ptr %l193
  %t322 = extractvalue { i64, [21 x i64] } %t321, 0
  %t323 = icmp eq i64 %t322, 0
  br i1 %t323, label %bb89, label %bb90
bb89:
  %t325 = getelementptr { i64, [21 x i64] }, ptr %l27, i32 0, i32 1
  %t326 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } }, ptr %t325, i32 0, i32 2
  %t327 = load { i64, [15 x i64] }, ptr %t326
  store { i64, [15 x i64] } %t327, ptr %l31
  br label %bb91
bb90:
  br label %bb131
bb91:
  %t329 = load { i64, [15 x i64] }, ptr %l31
  %t331 = extractvalue { i64, [15 x i64] } %t329, 0
  %t332 = icmp eq i64 %t331, 7
  br i1 %t332, label %bb92, label %bb93
bb92:
  %t334 = getelementptr { i64, [15 x i64] }, ptr %l31, i32 0, i32 1
  %t335 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t334, i32 0, i32 0
  %t336 = load { i64, [1 x i64] }, ptr %t335
  store { i64, [1 x i64] } %t336, ptr %l32
  br label %bb98
bb93:
  %t338 = load { i64, [15 x i64] }, ptr %l31
  %t340 = extractvalue { i64, [15 x i64] } %t338, 0
  %t341 = icmp eq i64 %t340, 8
  br i1 %t341, label %bb94, label %bb95
bb94:
  %t343 = getelementptr { i64, [15 x i64] }, ptr %l31, i32 0, i32 1
  %t344 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t343, i32 0, i32 0
  %t345 = load { i64, [1 x i64] }, ptr %t344
  store { i64, [1 x i64] } %t345, ptr %l32
  br label %bb98
bb95:
  %t347 = load { i64, [15 x i64] }, ptr %l31
  %t349 = extractvalue { i64, [15 x i64] } %t347, 0
  %t350 = icmp eq i64 %t349, 10
  br i1 %t350, label %bb96, label %bb97
bb96:
  %t352 = getelementptr { i64, [15 x i64] }, ptr %l31, i32 0, i32 1
  %t353 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t352, i32 0, i32 2
  %t354 = load { i64, [1 x i64] }, ptr %t353
  store { i64, [1 x i64] } %t354, ptr %l32
  br label %bb98
bb97:
  br label %bb103
bb98:
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t357 = load { i64, [1 x i64] }, ptr %l32
  %t358 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t362 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2euseRef(ptr %v0, ptr %s0, ptr %t356, { i64, [1 x i64] } %t357, { i64, ptr } %t358)
  store i1 %t362, ptr %l208
  br label %bb99
bb99:
  %t363 = load i1, ptr %l208, !tbaa !21
  br i1 %t363, label %bb100, label %bb101
bb100:
  store i1 true, ptr %l209, !tbaa !21
  br label %bb102
bb101:
  %t364 = load i1, ptr %l3, !tbaa !21
  store i1 %t364, ptr %l209, !tbaa !21
  br label %bb102
bb102:
  %t366 = load i1, ptr %l209, !tbaa !21
  store i1 %t366, ptr %l3, !tbaa !21
  br label %bb130
bb103:
  %t367 = load { i64, [15 x i64] }, ptr %l31
  %t369 = extractvalue { i64, [15 x i64] } %t367, 0
  %t370 = icmp eq i64 %t369, 12
  br i1 %t370, label %bb104, label %bb105
bb104:
  %t372 = getelementptr { i64, [15 x i64] }, ptr %l31, i32 0, i32 1
  %t373 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t372, i32 0, i32 0
  %t374 = load { i64, [1 x i64] }, ptr %t373
  store { i64, [1 x i64] } %t374, ptr %l33
  %t376 = getelementptr { i64, [15 x i64] }, ptr %l31, i32 0, i32 1
  %t377 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t376, i32 0, i32 1
  %t378 = load { i64, [1 x i64] }, ptr %t377
  store { i64, [1 x i64] } %t378, ptr %l34
  br label %bb106
bb105:
  br label %bb115
bb106:
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t381 = load { i64, [1 x i64] }, ptr %l33
  %t382 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t386 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2euseRef(ptr %v0, ptr %s0, ptr %t380, { i64, [1 x i64] } %t381, { i64, ptr } %t382)
  store i1 %t386, ptr %l218
  br label %bb107
bb107:
  %t387 = load i1, ptr %l218, !tbaa !21
  br i1 %t387, label %bb108, label %bb109
bb108:
  store i1 true, ptr %l219, !tbaa !21
  br label %bb110
bb109:
  %t388 = load i1, ptr %l3, !tbaa !21
  store i1 %t388, ptr %l219, !tbaa !21
  br label %bb110
bb110:
  %t390 = load i1, ptr %l219, !tbaa !21
  store i1 %t390, ptr %l3, !tbaa !21
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t392 = load { i64, [1 x i64] }, ptr %l34
  %t393 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t397 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2euseRef(ptr %v0, ptr %s0, ptr %t391, { i64, [1 x i64] } %t392, { i64, ptr } %t393)
  store i1 %t397, ptr %l224
  br label %bb111
bb111:
  %t398 = load i1, ptr %l224, !tbaa !21
  br i1 %t398, label %bb112, label %bb113
bb112:
  store i1 true, ptr %l225, !tbaa !21
  br label %bb114
bb113:
  %t399 = load i1, ptr %l3, !tbaa !21
  store i1 %t399, ptr %l225, !tbaa !21
  br label %bb114
bb114:
  %t401 = load i1, ptr %l225, !tbaa !21
  store i1 %t401, ptr %l3, !tbaa !21
  br label %bb130
bb115:
  %t402 = load { i64, [15 x i64] }, ptr %l31
  %t404 = extractvalue { i64, [15 x i64] } %t402, 0
  %t405 = icmp eq i64 %t404, 13
  br i1 %t405, label %bb116, label %bb117
bb116:
  %t407 = getelementptr { i64, [15 x i64] }, ptr %l31, i32 0, i32 1
  %t408 = getelementptr { { i64, [1 x i64] } }, ptr %t407, i32 0, i32 0
  %t409 = load { i64, [1 x i64] }, ptr %t408
  store { i64, [1 x i64] } %t409, ptr %l35
  br label %bb120
bb117:
  %t411 = load { i64, [15 x i64] }, ptr %l31
  %t413 = extractvalue { i64, [15 x i64] } %t411, 0
  %t414 = icmp eq i64 %t413, 14
  br i1 %t414, label %bb118, label %bb119
bb118:
  %t416 = getelementptr { i64, [15 x i64] }, ptr %l31, i32 0, i32 1
  %t417 = getelementptr { { i64, [4 x i64] }, { i64, [1 x i64] } }, ptr %t416, i32 0, i32 1
  %t418 = load { i64, [1 x i64] }, ptr %t417
  store { i64, [1 x i64] } %t418, ptr %l35
  br label %bb120
bb119:
  br label %bb125
bb120:
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t421 = load { i64, [1 x i64] }, ptr %l35
  %t422 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t426 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2euseRef(ptr %v0, ptr %s0, ptr %t420, { i64, [1 x i64] } %t421, { i64, ptr } %t422)
  store i1 %t426, ptr %l236
  br label %bb121
bb121:
  %t427 = load i1, ptr %l236, !tbaa !21
  br i1 %t427, label %bb122, label %bb123
bb122:
  store i1 true, ptr %l237, !tbaa !21
  br label %bb124
bb123:
  %t428 = load i1, ptr %l3, !tbaa !21
  store i1 %t428, ptr %l237, !tbaa !21
  br label %bb124
bb124:
  %t430 = load i1, ptr %l237, !tbaa !21
  store i1 %t430, ptr %l3, !tbaa !21
  br label %bb130
bb125:
  br i1 true, label %bb126, label %bb127
bb126:
  br label %bb128
bb127:
  br label %bb129
bb128:
  br label %bb130
bb129:
  call void @__olang_check_failed(ptr @olang_loc_5718aedbda8f05de_73125ecff2351902)
  unreachable
bb130:
  br label %bb136
bb131:
  br i1 true, label %bb132, label %bb133
bb132:
  br label %bb134
bb133:
  br label %bb135
bb134:
  br label %bb136
bb135:
  call void @__olang_check_failed(ptr @olang_loc_c174e5a3b34e67b9_6250aa572b15a6d5)
  unreachable
bb136:
  br label %bb137
bb137:
  %t431 = load i64, ptr %l26, !tbaa !24
  %t433 = add i64 %t431, 1
  store i64 %t433, ptr %l26, !tbaa !24
  br label %bb63
bb138:
  %t435 = getelementptr %"compiler/mir:BasicBlock", ptr %l24, i32 0, i32 1
  %t436 = load { i64, [8 x i64] }, ptr %t435
  store { i64, [8 x i64] } %t436, ptr %l36
  %t438 = load { i64, [8 x i64] }, ptr %l36
  %t440 = extractvalue { i64, [8 x i64] } %t438, 0
  %t441 = icmp eq i64 %t440, 7
  br i1 %t441, label %bb139, label %bb140
bb139:
  %t443 = getelementptr { i64, [8 x i64] }, ptr %l36, i32 0, i32 1
  %t444 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t443, i32 0, i32 1
  %t445 = load i32, ptr %t444
  store i32 %t445, ptr %l37, !tbaa !23
  br label %bb141
bb140:
  br label %bb142
bb141:
  %t447 = load i32, ptr %l37, !tbaa !23
  %t449 = sext i32 %t447 to i64
  %t451 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t452 = load ptr, ptr %t451, !tbaa !27
  %t453 = getelementptr i1, ptr %t452, i64 %t449
  store i1 true, ptr %t453, !tbaa !31
  br label %bb147
bb142:
  br i1 true, label %bb143, label %bb144
bb143:
  br label %bb145
bb144:
  br label %bb146
bb145:
  br label %bb147
bb146:
  call void @__olang_check_failed(ptr @olang_loc_9206c849bcce77e8_1d8ffc9eff2b8ce4)
  unreachable
bb147:
  br label %bb148
bb148:
  %t454 = load i64, ptr %l23, !tbaa !24
  %t456 = add i64 %t454, 1
  store i64 %t456, ptr %l23, !tbaa !24
  br label %bb57
bb149:
  %t458 = load ptr, ptr %l1, !tbaa !29
  %t460 = getelementptr %"compiler/mir:Fn", ptr %t458, i32 0, i32 7
  store ptr %t460, ptr %l38, !tbaa !29
  store i64 0, ptr %l39, !tbaa !24
  br label %bb150
bb150:
  %t462 = load i64, ptr %l39, !tbaa !24
  store i64 %t462, ptr %l251, !tbaa !24
  %t463 = load ptr, ptr %l38, !tbaa !29
  %t465 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t463)
  store i64 %t465, ptr %l253
  br label %bb151
bb151:
  %t466 = load i64, ptr %l251, !tbaa !24
  %t467 = load i64, ptr %l253, !tbaa !24
  %t468 = icmp slt i64 %t466, %t467
  %t470 = xor i1 %t468, true
  br i1 %t470, label %bb152, label %bb153
bb152:
  br label %bb165
bb153:
  br label %bb154
bb154:
  %t472 = load ptr, ptr %l38, !tbaa !29
  %t473 = load i64, ptr %l39, !tbaa !24
  %t476 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t472, i64 %t473)
  store %"compiler/mir:Local" %t476, ptr %l258
  br label %bb155
bb155:
  %t477 = load %"compiler/mir:Local", ptr %l258
  store %"compiler/mir:Local" %t477, ptr %l40
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t479 = getelementptr %"compiler/mir:Local", ptr %l40, i32 0, i32 4
  %t480 = load { i64, [1 x i64] }, ptr %t479
  %t483 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eisFrame(ptr %v0, ptr %t478, { i64, [1 x i64] } %t480)
  store i1 %t483, ptr %l261
  br label %bb156
bb156:
  %t484 = load i1, ptr %l261, !tbaa !21
  %t485 = xor i1 %t484, true
  br i1 %t485, label %bb157, label %bb158
bb157:
  %t487 = load ptr, ptr %l0, !tbaa !29
  %t488 = getelementptr %"compiler/mir:Local", ptr %l40, i32 0, i32 4
  %t489 = load { i64, [1 x i64] }, ptr %t488
  %t490 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t494 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2euseRef(ptr %v0, ptr %s0, ptr %t487, { i64, [1 x i64] } %t489, { i64, ptr } %t490)
  store i1 %t494, ptr %l266
  br label %bb159
bb158:
  br label %bb163
bb159:
  %t495 = load i1, ptr %l266, !tbaa !21
  br i1 %t495, label %bb160, label %bb161
bb160:
  store i1 true, ptr %l267, !tbaa !21
  br label %bb162
bb161:
  %t496 = load i1, ptr %l3, !tbaa !21
  store i1 %t496, ptr %l267, !tbaa !21
  br label %bb162
bb162:
  %t498 = load i1, ptr %l267, !tbaa !21
  store i1 %t498, ptr %l3, !tbaa !21
  br label %bb163
bb163:
  br label %bb164
bb164:
  %t499 = load i64, ptr %l39, !tbaa !24
  %t501 = add i64 %t499, 1
  store i64 %t501, ptr %l39, !tbaa !24
  br label %bb150
bb165:
  store i64 0, ptr %l41, !tbaa !24
  %t503 = load ptr, ptr %l1, !tbaa !29
  %t505 = getelementptr %"compiler/mir:Fn", ptr %t503, i32 0, i32 8
  %t507 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t505)
  store i64 %t507, ptr %l273
  br label %bb166
bb166:
  %t508 = load i64, ptr %l273, !tbaa !24
  store i64 %t508, ptr %l42, !tbaa !24
  store i64 1, ptr %l43, !tbaa !24
  %t509 = load i64, ptr %l42, !tbaa !24
  %t510 = load i64, ptr %l41, !tbaa !24
  %t513 = icmp sgt i64 %t509, %t510
  br i1 %t513, label %bb167, label %bb168
bb167:
  %t515 = load i64, ptr %l43, !tbaa !24
  %t517 = icmp sgt i64 %t515, 0
  br i1 %t517, label %bb169, label %bb170
bb168:
  store i64 0, ptr %l277, !tbaa !24
  br label %bb172
bb169:
  %t519 = load i64, ptr %l42, !tbaa !24
  %t520 = load i64, ptr %l41, !tbaa !24
  %t523 = sub i64 %t519, %t520
  %t524 = load i64, ptr %l43, !tbaa !24
  %t527 = add i64 %t523, %t524
  %t529 = sub i64 %t527, 1
  %t530 = load i64, ptr %l43, !tbaa !24
  %t533 = sdiv i64 %t529, %t530
  store i64 %t533, ptr %l280, !tbaa !24
  br label %bb171
bb170:
  store i64 0, ptr %l280, !tbaa !24
  br label %bb171
bb171:
  %t535 = load i64, ptr %l280, !tbaa !24
  store i64 %t535, ptr %l277, !tbaa !24
  br label %bb172
bb172:
  %t536 = load i64, ptr %l277, !tbaa !24
  store i64 %t536, ptr %l44, !tbaa !24
  store i64 0, ptr %l45, !tbaa !24
  br label %bb173
bb173:
  %t537 = load i64, ptr %l45, !tbaa !24
  %t538 = load i64, ptr %l44, !tbaa !24
  %t541 = icmp slt i64 %t537, %t538
  %t543 = xor i1 %t541, true
  br i1 %t543, label %bb174, label %bb175
bb174:
  br label %bb198
bb175:
  br label %bb176
bb176:
  %t545 = load i64, ptr %l41, !tbaa !24
  %t546 = load i64, ptr %l45, !tbaa !24
  %t547 = load i64, ptr %l43, !tbaa !24
  %t550 = mul i64 %t546, %t547
  %t553 = add i64 %t545, %t550
  store i64 %t553, ptr %l46, !tbaa !24
  %t555 = load ptr, ptr %l1, !tbaa !29
  %t557 = getelementptr %"compiler/mir:Fn", ptr %t555, i32 0, i32 8
  %t558 = load i64, ptr %l46, !tbaa !24
  %t561 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t557, i64 %t558)
  store %"compiler/mir:ScopeInfo" %t561, ptr %l301
  br label %bb177
bb177:
  %t562 = getelementptr %"compiler/mir:ScopeInfo", ptr %l301, i32 0, i32 0
  %t563 = load i32, ptr %t562
  store i32 %t563, ptr %l47
  %t565 = load i32, ptr %l47
  %t567 = trunc i64 0 to i32
  %t568 = icmp eq i32 %t565, %t567
  %t570 = xor i1 %t568, true
  br i1 %t570, label %bb178, label %bb179
bb178:
  %t572 = load i32, ptr %l47
  %t574 = trunc i64 1 to i32
  %t575 = icmp eq i32 %t572, %t574
  %t577 = xor i1 %t575, true
  store i1 %t577, ptr %l306, !tbaa !21
  br label %bb180
bb179:
  store i1 false, ptr %l306, !tbaa !21
  br label %bb180
bb180:
  %t579 = load i1, ptr %l306, !tbaa !21
  br i1 %t579, label %bb181, label %bb182
bb181:
  %t580 = load i32, ptr %l47
  %t582 = trunc i64 2 to i32
  %t583 = icmp eq i32 %t580, %t582
  %t585 = xor i1 %t583, true
  store i1 %t585, ptr %l310, !tbaa !21
  br label %bb183
bb182:
  store i1 false, ptr %l310, !tbaa !21
  br label %bb183
bb183:
  %t587 = load i1, ptr %l310, !tbaa !21
  br i1 %t587, label %bb184, label %bb185
bb184:
  br label %bb197
bb185:
  br label %bb186
bb186:
  %t588 = load i64, ptr %l46, !tbaa !24
  %t590 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t591 = load ptr, ptr %t590, !tbaa !27
  %t592 = getelementptr i1, ptr %t591, i64 %t588
  %t593 = load i1, ptr %t592, !tbaa !31
  br i1 %t593, label %bb187, label %bb188
bb187:
  store i1 true, ptr %l316, !tbaa !21
  br label %bb192
bb188:
  %t595 = load i1, ptr %l3, !tbaa !21
  br i1 %t595, label %bb189, label %bb190
bb189:
  %t597 = load i64, ptr %l46, !tbaa !24
  %t598 = load ptr, ptr %l0, !tbaa !29
  %t600 = getelementptr %"compiler/emit:fnEm", ptr %t598, i32 0, i32 8
  %t601 = load i64, ptr %t600, !tbaa !24
  %t604 = icmp eq i64 %t597, %t601
  store i1 %t604, ptr %l318, !tbaa !21
  br label %bb191
bb190:
  store i1 false, ptr %l318, !tbaa !21
  br label %bb191
bb191:
  %t606 = load i1, ptr %l318, !tbaa !21
  store i1 %t606, ptr %l316, !tbaa !21
  br label %bb192
bb192:
  %t607 = load i1, ptr %l316, !tbaa !21
  br i1 %t607, label %bb193, label %bb194
bb193:
  br label %bb197
bb194:
  br label %bb195
bb195:
  %t608 = load ptr, ptr %l0, !tbaa !29
  %t610 = getelementptr %"compiler/emit:fnEm", ptr %t608, i32 0, i32 24
  %t611 = load i64, ptr %l46, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t610, i64 %t611, i1 true)
  br label %bb196
bb196:
  br label %bb197
bb197:
  %t614 = load i64, ptr %l45, !tbaa !24
  %t616 = add i64 %t614, 1
  store i64 %t616, ptr %l45, !tbaa !24
  br label %bb173
bb198:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l10 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d131, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d131, i32 0, i32 1) }, 0
  %t8 = extractvalue { i64, ptr } %a1, 1
  %t9 = extractvalue { i64, ptr } %a1, 0
  %t10 = add i64 %t6, %t9
  %t11 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d132, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d132, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t15 = extractvalue { i64, ptr } %a2, 1
  %t16 = extractvalue { i64, ptr } %a2, 0
  %t17 = add i64 %t13, %t16
  %t19 = extractvalue { i64, ptr } %a3, 1
  %t20 = extractvalue { i64, ptr } %a3, 0
  %t21 = add i64 %t17, %t20
  %t22 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t21)
  call void @olang_textcopy(ptr %t22, ptr %t5, i64 %t6)
  %t23 = getelementptr i8, ptr %t22, i64 %t6
  call void @olang_textcopy(ptr %t23, ptr %t8, i64 %t9)
  %t24 = getelementptr i8, ptr %t23, i64 %t9
  call void @olang_textcopy(ptr %t24, ptr %t11, i64 %t12)
  %t25 = getelementptr i8, ptr %t24, i64 %t12
  call void @olang_textcopy(ptr %t25, ptr %t15, i64 %t16)
  %t26 = getelementptr i8, ptr %t25, i64 %t16
  call void @olang_textcopy(ptr %t26, ptr %t19, i64 %t20)
  %t27 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t22, 1
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t31 = extractvalue { i64, ptr } %t28, 1
  %t32 = mul i64 %t30, 1
  %t33 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t32)
  call void @llvm.memcpy.p0.p0.i64(ptr %t33, ptr %t31, i64 %t32, i1 false)
  %t34 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  %t38 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v4, ptr %v4, ptr %a0, { i64, ptr } %t35)
  store { i64, ptr } %t38, ptr %l10
  br label %bb1
bb1:
  %t39 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t39, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2enarrowBF16(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d133, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d133, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a1, 1
  %t7 = extractvalue { i64, ptr } %a1, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d134, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d134, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @olang_textcopy(ptr %t12, ptr %t3, i64 %t4)
  %t13 = getelementptr i8, ptr %t12, i64 %t4
  call void @olang_textcopy(ptr %t13, ptr %t6, i64 %t7)
  %t14 = getelementptr i8, ptr %t13, i64 %t7
  call void @olang_textcopy(ptr %t14, ptr %t9, i64 %t10)
  %t15 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t12, 1
  %t18 = extractvalue { i64, ptr } %t16, 0
  %t19 = extractvalue { i64, ptr } %t16, 1
  %t20 = mul i64 %t18, 1
  %t21 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t20)
  call void @llvm.memcpy.p0.p0.i64(ptr %t21, ptr %t19, i64 %t20, i1 false)
  %t22 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  %t26 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t1, { i64, ptr } %t23)
  store { i64, ptr } %t26, ptr %l17
  br label %bb1
bb1:
  %t27 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t27, ptr %l2, !tbaa !27
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t30 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d135, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d135, i32 0, i32 1) }, 0
  %t33 = extractvalue { i64, ptr } %t29, 1
  %t34 = extractvalue { i64, ptr } %t29, 0
  %t35 = add i64 %t31, %t34
  %t36 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d136, i32 0, i32 1) }, 1
  %t37 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d136, i32 0, i32 1) }, 0
  %t38 = add i64 %t35, %t37
  %t39 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t38)
  call void @olang_textcopy(ptr %t39, ptr %t30, i64 %t31)
  %t40 = getelementptr i8, ptr %t39, i64 %t31
  call void @olang_textcopy(ptr %t40, ptr %t33, i64 %t34)
  %t41 = getelementptr i8, ptr %t40, i64 %t34
  call void @olang_textcopy(ptr %t41, ptr %t36, i64 %t37)
  %t42 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t39, 1
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t46 = extractvalue { i64, ptr } %t43, 1
  %t47 = mul i64 %t45, 1
  %t48 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t47)
  call void @llvm.memcpy.p0.p0.i64(ptr %t48, ptr %t46, i64 %t47, i1 false)
  %t49 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  %t53 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t28, { i64, ptr } %t50)
  store { i64, ptr } %t53, ptr %l22
  br label %bb2
bb2:
  %t54 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t54, ptr %l3, !tbaa !27
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t57 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d137, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d137, i32 0, i32 1) }, 0
  %t60 = extractvalue { i64, ptr } %t56, 1
  %t61 = extractvalue { i64, ptr } %t56, 0
  %t62 = add i64 %t58, %t61
  %t63 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d138, i32 0, i32 1) }, 1
  %t64 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d138, i32 0, i32 1) }, 0
  %t65 = add i64 %t62, %t64
  %t66 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t65)
  call void @olang_textcopy(ptr %t66, ptr %t57, i64 %t58)
  %t67 = getelementptr i8, ptr %t66, i64 %t58
  call void @olang_textcopy(ptr %t67, ptr %t60, i64 %t61)
  %t68 = getelementptr i8, ptr %t67, i64 %t61
  call void @olang_textcopy(ptr %t68, ptr %t63, i64 %t64)
  %t69 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t66, 1
  %t72 = extractvalue { i64, ptr } %t70, 0
  %t73 = extractvalue { i64, ptr } %t70, 1
  %t74 = mul i64 %t72, 1
  %t75 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t74)
  call void @llvm.memcpy.p0.p0.i64(ptr %t75, ptr %t73, i64 %t74, i1 false)
  %t76 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  %t80 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t55, { i64, ptr } %t77)
  store { i64, ptr } %t80, ptr %l27
  br label %bb3
bb3:
  %t81 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d139, i32 0, i32 1) }, 1
  %t85 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d139, i32 0, i32 1) }, 0
  %t87 = extractvalue { i64, ptr } %t81, 1
  %t88 = extractvalue { i64, ptr } %t81, 0
  %t89 = add i64 %t85, %t88
  %t90 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d140, i32 0, i32 1) }, 1
  %t91 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d140, i32 0, i32 1) }, 0
  %t92 = add i64 %t89, %t91
  %t93 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t92)
  call void @olang_textcopy(ptr %t93, ptr %t84, i64 %t85)
  %t94 = getelementptr i8, ptr %t93, i64 %t85
  call void @olang_textcopy(ptr %t94, ptr %t87, i64 %t88)
  %t95 = getelementptr i8, ptr %t94, i64 %t88
  call void @olang_textcopy(ptr %t95, ptr %t90, i64 %t91)
  %t96 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t93, 1
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t100 = extractvalue { i64, ptr } %t97, 1
  %t101 = mul i64 %t99, 1
  %t102 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t101)
  call void @llvm.memcpy.p0.p0.i64(ptr %t102, ptr %t100, i64 %t101, i1 false)
  %t103 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  %t107 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t82, { i64, ptr } %t104)
  store { i64, ptr } %t107, ptr %l32
  br label %bb4
bb4:
  %t108 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t112 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d141, i32 0, i32 1) }, 1
  %t113 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d141, i32 0, i32 1) }, 0
  %t115 = extractvalue { i64, ptr } %t110, 1
  %t116 = extractvalue { i64, ptr } %t110, 0
  %t117 = add i64 %t113, %t116
  %t118 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d142, i32 0, i32 1) }, 1
  %t119 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d142, i32 0, i32 1) }, 0
  %t120 = add i64 %t117, %t119
  %t122 = extractvalue { i64, ptr } %t108, 1
  %t123 = extractvalue { i64, ptr } %t108, 0
  %t124 = add i64 %t120, %t123
  %t125 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t124)
  call void @olang_textcopy(ptr %t125, ptr %t112, i64 %t113)
  %t126 = getelementptr i8, ptr %t125, i64 %t113
  call void @olang_textcopy(ptr %t126, ptr %t115, i64 %t116)
  %t127 = getelementptr i8, ptr %t126, i64 %t116
  call void @olang_textcopy(ptr %t127, ptr %t118, i64 %t119)
  %t128 = getelementptr i8, ptr %t127, i64 %t119
  call void @olang_textcopy(ptr %t128, ptr %t122, i64 %t123)
  %t129 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t125, 1
  %t132 = extractvalue { i64, ptr } %t130, 0
  %t133 = extractvalue { i64, ptr } %t130, 1
  %t134 = mul i64 %t132, 1
  %t135 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t134)
  call void @llvm.memcpy.p0.p0.i64(ptr %t135, ptr %t133, i64 %t134, i1 false)
  %t136 = insertvalue { i64, ptr } undef, i64 %t132, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t135, 1
  %t140 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t109, { i64, ptr } %t137)
  store { i64, ptr } %t140, ptr %l38
  br label %bb5
bb5:
  %t141 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d143, i32 0, i32 1) }, 1
  %t145 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d143, i32 0, i32 1) }, 0
  %t147 = extractvalue { i64, ptr } %t141, 1
  %t148 = extractvalue { i64, ptr } %t141, 0
  %t149 = add i64 %t145, %t148
  %t150 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d144, i32 0, i32 1) }, 1
  %t151 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d144, i32 0, i32 1) }, 0
  %t152 = add i64 %t149, %t151
  %t153 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t152)
  call void @olang_textcopy(ptr %t153, ptr %t144, i64 %t145)
  %t154 = getelementptr i8, ptr %t153, i64 %t145
  call void @olang_textcopy(ptr %t154, ptr %t147, i64 %t148)
  %t155 = getelementptr i8, ptr %t154, i64 %t148
  call void @olang_textcopy(ptr %t155, ptr %t150, i64 %t151)
  %t156 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t153, 1
  %t159 = extractvalue { i64, ptr } %t157, 0
  %t160 = extractvalue { i64, ptr } %t157, 1
  %t161 = mul i64 %t159, 1
  %t162 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t161)
  call void @llvm.memcpy.p0.p0.i64(ptr %t162, ptr %t160, i64 %t161, i1 false)
  %t163 = insertvalue { i64, ptr } undef, i64 %t159, 0
  %t164 = insertvalue { i64, ptr } %t163, ptr %t162, 1
  %t167 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t142, { i64, ptr } %t164)
  store { i64, ptr } %t167, ptr %l43
  br label %bb6
bb6:
  %t168 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t168, ptr %l7, !tbaa !27
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t171 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d145, i32 0, i32 1) }, 1
  %t172 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d145, i32 0, i32 1) }, 0
  %t174 = extractvalue { i64, ptr } %t170, 1
  %t175 = extractvalue { i64, ptr } %t170, 0
  %t176 = add i64 %t172, %t175
  %t177 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d146, i32 0, i32 1) }, 1
  %t178 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d146, i32 0, i32 1) }, 0
  %t179 = add i64 %t176, %t178
  %t180 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t179)
  call void @olang_textcopy(ptr %t180, ptr %t171, i64 %t172)
  %t181 = getelementptr i8, ptr %t180, i64 %t172
  call void @olang_textcopy(ptr %t181, ptr %t174, i64 %t175)
  %t182 = getelementptr i8, ptr %t181, i64 %t175
  call void @olang_textcopy(ptr %t182, ptr %t177, i64 %t178)
  %t183 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t180, 1
  %t186 = extractvalue { i64, ptr } %t184, 0
  %t187 = extractvalue { i64, ptr } %t184, 1
  %t188 = mul i64 %t186, 1
  %t189 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t188)
  call void @llvm.memcpy.p0.p0.i64(ptr %t189, ptr %t187, i64 %t188, i1 false)
  %t190 = insertvalue { i64, ptr } undef, i64 %t186, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr %t189, 1
  %t194 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t169, { i64, ptr } %t191)
  store { i64, ptr } %t194, ptr %l48
  br label %bb7
bb7:
  %t195 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t195, ptr %l8, !tbaa !27
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t198 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d147, i32 0, i32 1) }, 1
  %t199 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d147, i32 0, i32 1) }, 0
  %t201 = extractvalue { i64, ptr } %t197, 1
  %t202 = extractvalue { i64, ptr } %t197, 0
  %t203 = add i64 %t199, %t202
  %t204 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d148, i32 0, i32 1) }, 1
  %t205 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d148, i32 0, i32 1) }, 0
  %t206 = add i64 %t203, %t205
  %t207 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t206)
  call void @olang_textcopy(ptr %t207, ptr %t198, i64 %t199)
  %t208 = getelementptr i8, ptr %t207, i64 %t199
  call void @olang_textcopy(ptr %t208, ptr %t201, i64 %t202)
  %t209 = getelementptr i8, ptr %t208, i64 %t202
  call void @olang_textcopy(ptr %t209, ptr %t204, i64 %t205)
  %t210 = insertvalue { i64, ptr } undef, i64 %t206, 0
  %t211 = insertvalue { i64, ptr } %t210, ptr %t207, 1
  %t213 = extractvalue { i64, ptr } %t211, 0
  %t214 = extractvalue { i64, ptr } %t211, 1
  %t215 = mul i64 %t213, 1
  %t216 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t215)
  call void @llvm.memcpy.p0.p0.i64(ptr %t216, ptr %t214, i64 %t215, i1 false)
  %t217 = insertvalue { i64, ptr } undef, i64 %t213, 0
  %t218 = insertvalue { i64, ptr } %t217, ptr %t216, 1
  %t221 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t196, { i64, ptr } %t218)
  store { i64, ptr } %t221, ptr %l53
  br label %bb8
bb8:
  %t222 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d149, i32 0, i32 1) }, 1
  %t226 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d149, i32 0, i32 1) }, 0
  %t228 = extractvalue { i64, ptr } %t222, 1
  %t229 = extractvalue { i64, ptr } %t222, 0
  %t230 = add i64 %t226, %t229
  %t231 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d150, i32 0, i32 1) }, 1
  %t232 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d150, i32 0, i32 1) }, 0
  %t233 = add i64 %t230, %t232
  %t234 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t233)
  call void @olang_textcopy(ptr %t234, ptr %t225, i64 %t226)
  %t235 = getelementptr i8, ptr %t234, i64 %t226
  call void @olang_textcopy(ptr %t235, ptr %t228, i64 %t229)
  %t236 = getelementptr i8, ptr %t235, i64 %t229
  call void @olang_textcopy(ptr %t236, ptr %t231, i64 %t232)
  %t237 = insertvalue { i64, ptr } undef, i64 %t233, 0
  %t238 = insertvalue { i64, ptr } %t237, ptr %t234, 1
  %t240 = extractvalue { i64, ptr } %t238, 0
  %t241 = extractvalue { i64, ptr } %t238, 1
  %t242 = mul i64 %t240, 1
  %t243 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t242)
  call void @llvm.memcpy.p0.p0.i64(ptr %t243, ptr %t241, i64 %t242, i1 false)
  %t244 = insertvalue { i64, ptr } undef, i64 %t240, 0
  %t245 = insertvalue { i64, ptr } %t244, ptr %t243, 1
  %t248 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t223, { i64, ptr } %t245)
  store { i64, ptr } %t248, ptr %l58
  br label %bb9
bb9:
  %t249 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t252 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t253 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t254 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d151, i32 0, i32 1) }, 1
  %t255 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d151, i32 0, i32 1) }, 0
  %t257 = extractvalue { i64, ptr } %t249, 1
  %t258 = extractvalue { i64, ptr } %t249, 0
  %t259 = add i64 %t255, %t258
  %t260 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d152, i32 0, i32 1) }, 1
  %t261 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d152, i32 0, i32 1) }, 0
  %t262 = add i64 %t259, %t261
  %t264 = extractvalue { i64, ptr } %t252, 1
  %t265 = extractvalue { i64, ptr } %t252, 0
  %t266 = add i64 %t262, %t265
  %t267 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d152, i32 0, i32 1) }, 1
  %t268 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d152, i32 0, i32 1) }, 0
  %t269 = add i64 %t266, %t268
  %t271 = extractvalue { i64, ptr } %t253, 1
  %t272 = extractvalue { i64, ptr } %t253, 0
  %t273 = add i64 %t269, %t272
  %t274 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t273)
  call void @olang_textcopy(ptr %t274, ptr %t254, i64 %t255)
  %t275 = getelementptr i8, ptr %t274, i64 %t255
  call void @olang_textcopy(ptr %t275, ptr %t257, i64 %t258)
  %t276 = getelementptr i8, ptr %t275, i64 %t258
  call void @olang_textcopy(ptr %t276, ptr %t260, i64 %t261)
  %t277 = getelementptr i8, ptr %t276, i64 %t261
  call void @olang_textcopy(ptr %t277, ptr %t264, i64 %t265)
  %t278 = getelementptr i8, ptr %t277, i64 %t265
  call void @olang_textcopy(ptr %t278, ptr %t267, i64 %t268)
  %t279 = getelementptr i8, ptr %t278, i64 %t268
  call void @olang_textcopy(ptr %t279, ptr %t271, i64 %t272)
  %t280 = insertvalue { i64, ptr } undef, i64 %t273, 0
  %t281 = insertvalue { i64, ptr } %t280, ptr %t274, 1
  %t283 = extractvalue { i64, ptr } %t281, 0
  %t284 = extractvalue { i64, ptr } %t281, 1
  %t285 = mul i64 %t283, 1
  %t286 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t285)
  call void @llvm.memcpy.p0.p0.i64(ptr %t286, ptr %t284, i64 %t285, i1 false)
  %t287 = insertvalue { i64, ptr } undef, i64 %t283, 0
  %t288 = insertvalue { i64, ptr } %t287, ptr %t286, 1
  %t291 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t250, { i64, ptr } %t288)
  store { i64, ptr } %t291, ptr %l65
  br label %bb10
bb10:
  %t292 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d153, i32 0, i32 1) }, 1
  %t296 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d153, i32 0, i32 1) }, 0
  %t298 = extractvalue { i64, ptr } %t292, 1
  %t299 = extractvalue { i64, ptr } %t292, 0
  %t300 = add i64 %t296, %t299
  %t301 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d154, i32 0, i32 1) }, 1
  %t302 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d154, i32 0, i32 1) }, 0
  %t303 = add i64 %t300, %t302
  %t304 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t303)
  call void @olang_textcopy(ptr %t304, ptr %t295, i64 %t296)
  %t305 = getelementptr i8, ptr %t304, i64 %t296
  call void @olang_textcopy(ptr %t305, ptr %t298, i64 %t299)
  %t306 = getelementptr i8, ptr %t305, i64 %t299
  call void @olang_textcopy(ptr %t306, ptr %t301, i64 %t302)
  %t307 = insertvalue { i64, ptr } undef, i64 %t303, 0
  %t308 = insertvalue { i64, ptr } %t307, ptr %t304, 1
  %t310 = extractvalue { i64, ptr } %t308, 0
  %t311 = extractvalue { i64, ptr } %t308, 1
  %t312 = mul i64 %t310, 1
  %t313 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t312)
  call void @llvm.memcpy.p0.p0.i64(ptr %t313, ptr %t311, i64 %t312, i1 false)
  %t314 = insertvalue { i64, ptr } undef, i64 %t310, 0
  %t315 = insertvalue { i64, ptr } %t314, ptr %t313, 1
  %t318 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t293, { i64, ptr } %t315)
  store { i64, ptr } %t318, ptr %l70
  br label %bb11
bb11:
  %t319 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t320 = load ptr, ptr %l0, !tbaa !29
  %t322 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d155, i32 0, i32 1) }, 1
  %t323 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d155, i32 0, i32 1) }, 0
  %t325 = extractvalue { i64, ptr } %t319, 1
  %t326 = extractvalue { i64, ptr } %t319, 0
  %t327 = add i64 %t323, %t326
  %t328 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d156, i32 0, i32 1) }, 1
  %t329 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d156, i32 0, i32 1) }, 0
  %t330 = add i64 %t327, %t329
  %t331 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t330)
  call void @olang_textcopy(ptr %t331, ptr %t322, i64 %t323)
  %t332 = getelementptr i8, ptr %t331, i64 %t323
  call void @olang_textcopy(ptr %t332, ptr %t325, i64 %t326)
  %t333 = getelementptr i8, ptr %t332, i64 %t326
  call void @olang_textcopy(ptr %t333, ptr %t328, i64 %t329)
  %t334 = insertvalue { i64, ptr } undef, i64 %t330, 0
  %t335 = insertvalue { i64, ptr } %t334, ptr %t331, 1
  %t337 = extractvalue { i64, ptr } %t335, 0
  %t338 = extractvalue { i64, ptr } %t335, 1
  %t339 = mul i64 %t337, 1
  %t340 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t339)
  call void @llvm.memcpy.p0.p0.i64(ptr %t340, ptr %t338, i64 %t339, i1 false)
  %t341 = insertvalue { i64, ptr } undef, i64 %t337, 0
  %t342 = insertvalue { i64, ptr } %t341, ptr %t340, 1
  %t345 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v2, ptr %v2, ptr %t320, { i64, ptr } %t342)
  store { i64, ptr } %t345, ptr %l75
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  %t346 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t346, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2enewArray(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1, i32 %a2, { i64, [4 x i64] } %a3, { i64, [4 x i64] } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, [4 x i64] }
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca ptr
  %l6 = alloca i32
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i1
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l30 = alloca i32
  %l33 = alloca i1
  %l34 = alloca i32
  %l37 = alloca i32
  %l39 = alloca ptr
  %l42 = alloca i32
  %l43 = alloca i32
  %l44 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l52 = alloca i32
  %l53 = alloca { i64, ptr }
  %l54 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l58 = alloca i64
  %l61 = alloca { i64, ptr }
  %l62 = alloca i1
  %l70 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l73 = alloca i64
  %l74 = alloca { i64, ptr }
  %l77 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l96 = alloca i1
  %l102 = alloca i1
  %l110 = alloca { i64, ptr }
  %l112 = alloca i64
  %l118 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l126 = alloca i64
  %l131 = alloca i1
  %l136 = alloca { i64, ptr }
  %l138 = alloca i64
  %l142 = alloca i1
  %l144 = alloca { i64, ptr }
  %l148 = alloca { i64, ptr }
  %l152 = alloca { i64, ptr }
  %l154 = alloca { i64, ptr }
  %l158 = alloca { i64, ptr }
  %l160 = alloca { i64, ptr }
  %l162 = alloca { i64, ptr }
  %l171 = alloca { i64, ptr }
  %l177 = alloca { i64, ptr }
  %l192 = alloca { i64, ptr }
  %l202 = alloca ptr
  %l207 = alloca { i64, ptr }
  %l219 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [4 x i64] } %a3, ptr %l3
  store { i64, [4 x i64] } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l5, !tbaa !29
  %t9 = load ptr, ptr %l5, !tbaa !29
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t9, i32 %a2)
  store i32 %t13, ptr %l30
  br label %bb1
bb1:
  %t14 = load i32, ptr %l30, !tbaa !23
  store i32 %t14, ptr %l6, !tbaa !23
  %t15 = load ptr, ptr %l5, !tbaa !29
  %t16 = load i32, ptr %l6, !tbaa !23
  %t19 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l33
  br label %bb2
bb2:
  %t20 = load i1, ptr %l33, !tbaa !21
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t21 = load ptr, ptr %l5, !tbaa !29
  %t22 = load i32, ptr %l6, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l37
  br label %bb5
bb4:
  %t26 = load i32, ptr %l6, !tbaa !23
  store i32 %t26, ptr %l34, !tbaa !23
  br label %bb6
bb5:
  %t28 = load i32, ptr %l37, !tbaa !23
  store i32 %t28, ptr %l34, !tbaa !23
  br label %bb6
bb6:
  %t29 = load i32, ptr %l34, !tbaa !23
  %t30 = load ptr, ptr %l5, !tbaa !29
  store ptr %t30, ptr %l39, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t35 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t31, i32 %t29)
  store i32 %t35, ptr %l42
  br label %bb7
bb7:
  %t36 = load ptr, ptr %l39, !tbaa !29
  %t37 = load i32, ptr %l42, !tbaa !23
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t38, ptr %l43
  br label %bb8
bb8:
  %t39 = load i32, ptr %l43, !tbaa !23
  store i32 %t39, ptr %l8, !tbaa !23
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l44, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load { i64, [4 x i64] }, ptr %l3
  %t43 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t47 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s0, ptr %t41, { i64, [4 x i64] } %t42, i32 %t43)
  store { i64, ptr } %t47, ptr %l48
  br label %bb9
bb9:
  %t48 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 0
  %t50 = extractvalue { i64, ptr } %t48, 1
  %t51 = mul i64 %t49, 1
  %t52 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t51)
  call void @llvm.memcpy.p0.p0.i64(ptr %t52, ptr %t50, i64 %t51, i1 false)
  %t53 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  store { i64, ptr } %t54, ptr %l49, !tbaa !27
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load { i64, [4 x i64] }, ptr %l3
  %t59 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t55, { i64, [4 x i64] } %t56)
  store i32 %t59, ptr %l52
  br label %bb10
bb10:
  %t60 = load ptr, ptr %l44, !tbaa !29
  %t61 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t62 = load i32, ptr %l52, !tbaa !23
  %t63 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eindex(ptr %v0, ptr %s0, ptr %s0, ptr %t60, { i64, ptr } %t61, i32 %t62)
  store { i64, ptr } %t63, ptr %l53
  br label %bb11
bb11:
  %t64 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t64, ptr %l9, !tbaa !27
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l54, !tbaa !29
  %t66 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t66, ptr %l55, !tbaa !27
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i32, ptr %l8, !tbaa !23
  %t71 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t67, i32 %t68)
  store i64 %t71, ptr %l58
  br label %bb12
bb12:
  %t72 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d157, i32 0, i32 1) }, 1
  %t73 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d157, i32 0, i32 1) }, 0
  %t74 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t74, 1
  %t76 = extractvalue { i64, ptr } %t74, 0
  %t77 = add i64 %t73, %t76
  %t78 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d158, i32 0, i32 1) }, 1
  %t79 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d158, i32 0, i32 1) }, 0
  %t80 = add i64 %t77, %t79
  %t81 = load i64, ptr %l58, !tbaa !24
  %t82 = call i64 @__olang_fmt_i64(ptr null, i64 %t81)
  %t83 = add i64 %t80, %t82
  %t84 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t83)
  call void @olang_textcopy(ptr %t84, ptr %t72, i64 %t73)
  %t85 = getelementptr i8, ptr %t84, i64 %t73
  call void @olang_textcopy(ptr %t85, ptr %t75, i64 %t76)
  %t86 = getelementptr i8, ptr %t85, i64 %t76
  call void @olang_textcopy(ptr %t86, ptr %t78, i64 %t79)
  %t87 = getelementptr i8, ptr %t86, i64 %t79
  %t88 = call i64 @__olang_fmt_i64(ptr %t87, i64 %t81)
  %t89 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t84, 1
  %t92 = extractvalue { i64, ptr } %t90, 0
  %t93 = extractvalue { i64, ptr } %t90, 1
  %t94 = mul i64 %t92, 1
  %t95 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t94)
  call void @llvm.memcpy.p0.p0.i64(ptr %t95, ptr %t93, i64 %t94, i1 false)
  %t96 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  %t98 = load ptr, ptr %l54, !tbaa !29
  %t100 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t98, { i64, ptr } %t97)
  store { i64, ptr } %t100, ptr %l61
  br label %bb13
bb13:
  %t101 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t101, ptr %l10, !tbaa !27
  %t102 = load { i64, [4 x i64] }, ptr %l4
  %t104 = extractvalue { i64, [4 x i64] } %t102, 0
  %t105 = icmp eq i64 %t104, 2
  br i1 %t105, label %bb14, label %bb15
bb14:
  %t107 = getelementptr { i64, [4 x i64] }, ptr %l4, i32 0, i32 1
  %t108 = getelementptr { i32, i64 }, ptr %t107, i32 0, i32 1
  %t109 = load i64, ptr %t108
  store i64 %t109, ptr %l11, !tbaa !24
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t111 = load i64, ptr %l11, !tbaa !24
  %t113 = icmp eq i64 %t111, 0
  store i1 %t113, ptr %l62, !tbaa !21
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_7367d2b2f6aa7e57_e9ab633458e0a533)
  unreachable
bb22:
  %t115 = load i1, ptr %l62, !tbaa !21
  store i1 %t115, ptr %l12, !tbaa !21
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t120 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %s0, ptr %t116, { i64, [1 x i64] } %a1)
  store { i64, ptr } %t120, ptr %l70
  br label %bb23
bb23:
  %t121 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t121, ptr %l13, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d159, i32 0, i32 1) }, ptr %l71, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t122, ptr %l72, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  store i64 %t124, ptr %l73, !tbaa !24
  %t125 = load i64, ptr %l73, !tbaa !24
  %t126 = mul i64 %t125, 1
  %t127 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t126)
  %t128 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  store { i64, ptr } %t129, ptr %l74, !tbaa !27
  %t130 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = load i64, ptr %l73, !tbaa !24
  %t135 = mul i64 %t134, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t131, ptr %t133, i64 %t135, i1 false)
  %t136 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t136, ptr %l14, !tbaa !27
  %t137 = load { i64, [4 x i64] }, ptr %l4
  %t139 = extractvalue { i64, [4 x i64] } %t137, 0
  %t140 = icmp eq i64 %t139, 0
  br i1 %t140, label %bb24, label %bb25
bb24:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/emit:fnEm", ptr %t142, i32 0, i32 0
  %t145 = load ptr, ptr %t144, !tbaa !29
  %t147 = getelementptr %"compiler/emit:Emitter", ptr %t145, i32 0, i32 46
  %t148 = load i1, ptr %t147, !tbaa !21
  %t150 = xor i1 %t148, true
  store i1 %t150, ptr %l77, !tbaa !21
  br label %bb26
bb25:
  store i1 false, ptr %l77, !tbaa !21
  br label %bb26
bb26:
  %t152 = load i1, ptr %l77, !tbaa !21
  br i1 %t152, label %bb27, label %bb28
bb27:
  %t153 = load ptr, ptr %l0, !tbaa !29
  store ptr %t153, ptr %l82, !tbaa !29
  %t154 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t154, ptr %l83, !tbaa !27
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t158 = load i32, ptr %l8, !tbaa !23
  %t163 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayStorage(ptr %v0, ptr %s0, ptr %s0, ptr %v1, ptr %t155, { i64, ptr } %t156, { i64, ptr } %t157, i32 %t158, i1 false)
  store { i64, ptr } %t163, ptr %l88
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t164 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t164, 0
  %t166 = extractvalue { i64, ptr } %t164, 1
  %t167 = mul i64 %t165, 1
  %t168 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t167)
  call void @llvm.memcpy.p0.p0.i64(ptr %t168, ptr %t166, i64 %t167, i1 false)
  %t169 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t168, 1
  %t171 = load ptr, ptr %l82, !tbaa !29
  %t172 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t174 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epair(ptr %v0, ptr %s0, ptr %v1, ptr %v1, ptr %t171, { i64, ptr } %t172, { i64, ptr } %t170)
  store { i64, ptr } %t174, ptr %l90
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  %t175 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t175, ptr %rv
  br label %ret
bb31:
  %t176 = load { i64, [4 x i64] }, ptr %l4
  %t178 = extractvalue { i64, [4 x i64] } %t176, 0
  %t179 = icmp eq i64 %t178, 0
  br i1 %t179, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb34
bb33:
  br label %bb34
bb34:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/emit:fnEm", ptr %t181, i32 0, i32 0
  %t184 = load ptr, ptr %t183, !tbaa !29
  %t186 = getelementptr %"compiler/emit:Emitter", ptr %t184, i32 0, i32 46
  %t187 = load i1, ptr %t186, !tbaa !21
  br i1 %t187, label %bb35, label %bb36
bb35:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/emit:fnEm", ptr %t189, i32 0, i32 0
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/emit:fnEm", ptr %t193, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !29
  %t198 = getelementptr %"compiler/mir:Fn", ptr %t196, i32 0, i32 2
  %t199 = load i64, ptr %t198, !tbaa !24
  %t202 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eretires(ptr %v0, ptr %t192, i64 %t199)
  store i1 %t202, ptr %l102
  br label %bb37
bb36:
  store i1 false, ptr %l96, !tbaa !21
  br label %bb38
bb37:
  %t203 = load i1, ptr %l102, !tbaa !21
  store i1 %t203, ptr %l96, !tbaa !21
  br label %bb38
bb38:
  %t204 = load i1, ptr %l96, !tbaa !21
  br i1 %t204, label %bb39, label %bb40
bb39:
  store %olang.scope zeroinitializer, ptr %s6
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/emit:fnEm", ptr %t205, i32 0, i32 0
  %t208 = load ptr, ptr %t207, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s6, ptr %t208, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d160, i32 0, i32 1) })
  br label %bb41
bb40:
  %t210 = load i1, ptr %l12, !tbaa !21
  br i1 %t210, label %bb50, label %bb51
bb41:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t214 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t215 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d161, i32 0, i32 1) }, 1
  %t216 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d161, i32 0, i32 1) }, 0
  %t218 = extractvalue { i64, ptr } %t213, 1
  %t219 = extractvalue { i64, ptr } %t213, 0
  %t220 = add i64 %t216, %t219
  %t221 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d162, i32 0, i32 1) }, 1
  %t222 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d162, i32 0, i32 1) }, 0
  %t223 = add i64 %t220, %t222
  %t225 = extractvalue { i64, ptr } %t214, 1
  %t226 = extractvalue { i64, ptr } %t214, 0
  %t227 = add i64 %t223, %t226
  %t228 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d163, i32 0, i32 1) }, 1
  %t229 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d163, i32 0, i32 1) }, 0
  %t230 = add i64 %t227, %t229
  %t231 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t230)
  call void @olang_textcopy(ptr %t231, ptr %t215, i64 %t216)
  %t232 = getelementptr i8, ptr %t231, i64 %t216
  call void @olang_textcopy(ptr %t232, ptr %t218, i64 %t219)
  %t233 = getelementptr i8, ptr %t232, i64 %t219
  call void @olang_textcopy(ptr %t233, ptr %t221, i64 %t222)
  %t234 = getelementptr i8, ptr %t233, i64 %t222
  call void @olang_textcopy(ptr %t234, ptr %t225, i64 %t226)
  %t235 = getelementptr i8, ptr %t234, i64 %t226
  call void @olang_textcopy(ptr %t235, ptr %t228, i64 %t229)
  %t236 = insertvalue { i64, ptr } undef, i64 %t230, 0
  %t237 = insertvalue { i64, ptr } %t236, ptr %t231, 1
  %t239 = extractvalue { i64, ptr } %t237, 0
  %t240 = extractvalue { i64, ptr } %t237, 1
  %t241 = mul i64 %t239, 1
  %t242 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t241)
  call void @llvm.memcpy.p0.p0.i64(ptr %t242, ptr %t240, i64 %t241, i1 false)
  %t243 = insertvalue { i64, ptr } undef, i64 %t239, 0
  %t244 = insertvalue { i64, ptr } %t243, ptr %t242, 1
  %t247 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t212, { i64, ptr } %t244)
  store { i64, ptr } %t247, ptr %l110
  br label %bb42
bb42:
  %t248 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t249 = extractvalue { i64, ptr } %t248, 0
  %t250 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t251 = extractvalue { i64, ptr } %t250, 0
  store i64 %t251, ptr %l112, !tbaa !24
  %t253 = load i64, ptr %l112, !tbaa !24
  %t254 = icmp eq i64 %t249, %t253
  br i1 %t254, label %bb43, label %bb44
bb43:
  %t256 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t257 = load ptr, ptr %t256, !tbaa !27
  %t258 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t259 = load ptr, ptr %t258, !tbaa !27
  %t260 = load i64, ptr %l112, !tbaa !24
  %t261 = mul i64 %t260, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t257, ptr %t259, i64 %t261, i1 false)
  br label %bb45
bb44:
  %t262 = load { i64, ptr }, ptr %l110, !tbaa !27
  store { i64, ptr } %t262, ptr %l14, !tbaa !27
  br label %bb45
bb45:
  %t263 = load i1, ptr %l12, !tbaa !21
  br i1 %t263, label %bb46, label %bb47
bb46:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t266 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t267 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t271 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epair(ptr %v0, ptr %s0, ptr %s0, ptr %v1, ptr %t265, { i64, ptr } %t266, { i64, ptr } %t267)
  store { i64, ptr } %t271, ptr %l118
  br label %bb48
bb47:
  br label %bb49
bb48:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t272 = load { i64, ptr }, ptr %l118, !tbaa !27
  store { i64, ptr } %t272, ptr %rv
  br label %ret
bb49:
  call void @__olang_scope_close(ptr %s6)
  br label %bb57
bb50:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t275 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t276 = load i32, ptr %l8, !tbaa !23
  %t281 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayStorage(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t273, { i64, ptr } %t274, { i64, ptr } %t275, i32 %t276, i1 true)
  store { i64, ptr } %t281, ptr %l124
  br label %bb52
bb51:
  br label %bb56
bb52:
  %t282 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t283 = extractvalue { i64, ptr } %t282, 0
  %t284 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t285 = extractvalue { i64, ptr } %t284, 0
  store i64 %t285, ptr %l126, !tbaa !24
  %t287 = load i64, ptr %l126, !tbaa !24
  %t288 = icmp eq i64 %t283, %t287
  br i1 %t288, label %bb53, label %bb54
bb53:
  %t290 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t291 = load ptr, ptr %t290, !tbaa !27
  %t292 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t293 = load ptr, ptr %t292, !tbaa !27
  %t294 = load i64, ptr %l126, !tbaa !24
  %t295 = mul i64 %t294, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t291, ptr %t293, i64 %t295, i1 false)
  br label %bb55
bb54:
  %t296 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t296, ptr %l14, !tbaa !27
  br label %bb55
bb55:
  br label %bb56
bb56:
  br label %bb57
bb57:
  %t297 = load i1, ptr %l12, !tbaa !21
  %t299 = xor i1 %t297, true
  br i1 %t299, label %bb58, label %bb59
bb58:
  store %olang.scope zeroinitializer, ptr %s11
  %t301 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t303 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s11, { i64, ptr } %t301, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d164, i32 0, i32 1) })
  store i1 %t303, ptr %l131
  br label %bb60
bb59:
  br label %bb95
bb60:
  %t304 = load i1, ptr %l131, !tbaa !21
  br i1 %t304, label %bb61, label %bb62
bb61:
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t306 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t307 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t308 = load i32, ptr %l8, !tbaa !23
  %t313 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayStorage(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t305, { i64, ptr } %t306, { i64, ptr } %t307, i32 %t308, i1 false)
  store { i64, ptr } %t313, ptr %l136
  br label %bb63
bb62:
  br label %bb67
bb63:
  %t314 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t315 = extractvalue { i64, ptr } %t314, 0
  %t316 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t317 = extractvalue { i64, ptr } %t316, 0
  store i64 %t317, ptr %l138, !tbaa !24
  %t319 = load i64, ptr %l138, !tbaa !24
  %t320 = icmp eq i64 %t315, %t319
  br i1 %t320, label %bb64, label %bb65
bb64:
  %t322 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t323 = load ptr, ptr %t322, !tbaa !27
  %t324 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t325 = load ptr, ptr %t324, !tbaa !27
  %t326 = load i64, ptr %l138, !tbaa !24
  %t327 = mul i64 %t326, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t323, ptr %t325, i64 %t327, i1 false)
  br label %bb66
bb65:
  %t328 = load { i64, ptr }, ptr %l136, !tbaa !27
  store { i64, ptr } %t328, ptr %l14, !tbaa !27
  br label %bb66
bb66:
  br label %bb67
bb67:
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t330 = load i32, ptr %l8, !tbaa !23
  %t333 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eviaMem(ptr %v0, ptr %t329, i32 %t330)
  store i1 %t333, ptr %l142
  br label %bb68
bb68:
  %t334 = load i1, ptr %l142, !tbaa !21
  store i1 %t334, ptr %l15, !tbaa !21
  %t335 = load i1, ptr %l15, !tbaa !21
  br i1 %t335, label %bb69, label %bb70
bb69:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d165, i32 0, i32 1) }, ptr %l144, !tbaa !27
  br label %bb72
bb70:
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t338 = load { i64, [4 x i64] }, ptr %l4
  %t339 = load i32, ptr %l8, !tbaa !23
  %t343 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s11, ptr %t337, { i64, [4 x i64] } %t338, i32 %t339)
  store { i64, ptr } %t343, ptr %l148
  br label %bb71
bb71:
  %t344 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t345 = extractvalue { i64, ptr } %t344, 0
  %t346 = extractvalue { i64, ptr } %t344, 1
  %t347 = mul i64 %t345, 1
  %t348 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t347)
  call void @llvm.memcpy.p0.p0.i64(ptr %t348, ptr %t346, i64 %t347, i1 false)
  %t349 = insertvalue { i64, ptr } undef, i64 %t345, 0
  %t350 = insertvalue { i64, ptr } %t349, ptr %t348, 1
  store { i64, ptr } %t350, ptr %l144, !tbaa !27
  br label %bb72
bb72:
  %t352 = load { i64, ptr }, ptr %l144, !tbaa !27
  store { i64, ptr } %t352, ptr %l16, !tbaa !27
  %t353 = load ptr, ptr %l0, !tbaa !29
  %t354 = load i32, ptr %l8, !tbaa !23
  %t357 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s11, ptr %t353, i32 %t354)
  store { i64, ptr } %t357, ptr %l152
  br label %bb73
bb73:
  %t358 = load { i64, ptr }, ptr %l152, !tbaa !27
  store { i64, ptr } %t358, ptr %l17, !tbaa !27
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t361 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %s11, ptr %s11, ptr %t359, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d166, i32 0, i32 1) }, i64 0)
  store { i64, ptr } %t361, ptr %l154
  br label %bb74
bb74:
  %t362 = load { i64, ptr }, ptr %l154, !tbaa !27
  store { i64, ptr } %t362, ptr %l18, !tbaa !27
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t364 = load { i64, ptr }, ptr %l18, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s11, ptr %s11, ptr %s11, ptr %s11, ptr %t363, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d167, i32 0, i32 1) }, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d168, i32 0, i32 1) }, { i64, ptr } %t364, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d118, i32 0, i32 1) })
  br label %bb75
bb75:
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t369 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s11, ptr %s11, ptr %t367, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d169, i32 0, i32 1) })
  store { i64, ptr } %t369, ptr %l158
  br label %bb76
bb76:
  %t370 = load { i64, ptr }, ptr %l158, !tbaa !27
  store { i64, ptr } %t370, ptr %l19, !tbaa !27
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t373 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s11, ptr %s11, ptr %t371, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d170, i32 0, i32 1) })
  store { i64, ptr } %t373, ptr %l160
  br label %bb77
bb77:
  %t374 = load { i64, ptr }, ptr %l160, !tbaa !27
  store { i64, ptr } %t374, ptr %l20, !tbaa !27
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t377 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s11, ptr %s11, ptr %t375, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d171, i32 0, i32 1) })
  store { i64, ptr } %t377, ptr %l162
  br label %bb78
bb78:
  %t378 = load { i64, ptr }, ptr %l162, !tbaa !27
  store { i64, ptr } %t378, ptr %l21, !tbaa !27
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t380 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t381 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d172, i32 0, i32 1) }, 1
  %t382 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d172, i32 0, i32 1) }, 0
  %t384 = extractvalue { i64, ptr } %t380, 1
  %t385 = extractvalue { i64, ptr } %t380, 0
  %t386 = add i64 %t382, %t385
  %t387 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t386)
  call void @olang_textcopy(ptr %t387, ptr %t381, i64 %t382)
  %t388 = getelementptr i8, ptr %t387, i64 %t382
  call void @olang_textcopy(ptr %t388, ptr %t384, i64 %t385)
  %t389 = insertvalue { i64, ptr } undef, i64 %t386, 0
  %t390 = insertvalue { i64, ptr } %t389, ptr %t387, 1
  %t392 = extractvalue { i64, ptr } %t390, 0
  %t393 = extractvalue { i64, ptr } %t390, 1
  %t394 = mul i64 %t392, 1
  %t395 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t394)
  call void @llvm.memcpy.p0.p0.i64(ptr %t395, ptr %t393, i64 %t394, i1 false)
  %t396 = insertvalue { i64, ptr } undef, i64 %t392, 0
  %t397 = insertvalue { i64, ptr } %t396, ptr %t395, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s11, ptr %t379, { i64, ptr } %t397)
  br label %bb79
bb79:
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t401 = load { i64, ptr }, ptr %l19, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s11, ptr %t400, { i64, ptr } %t401)
  br label %bb80
bb80:
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t405 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t408 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s11, ptr %s11, ptr %s11, ptr %s11, ptr %t404, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d173, i32 0, i32 1) }, { i64, ptr } %t405, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d174, i32 0, i32 1) })
  store { i64, ptr } %t408, ptr %l171
  br label %bb81
bb81:
  %t409 = load { i64, ptr }, ptr %l171, !tbaa !27
  store { i64, ptr } %t409, ptr %l22, !tbaa !27
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t411 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t412 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t413 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d175, i32 0, i32 1) }, 1
  %t414 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d175, i32 0, i32 1) }, 0
  %t416 = extractvalue { i64, ptr } %t411, 1
  %t417 = extractvalue { i64, ptr } %t411, 0
  %t418 = add i64 %t414, %t417
  %t419 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d176, i32 0, i32 1) }, 1
  %t420 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d176, i32 0, i32 1) }, 0
  %t421 = add i64 %t418, %t420
  %t423 = extractvalue { i64, ptr } %t412, 1
  %t424 = extractvalue { i64, ptr } %t412, 0
  %t425 = add i64 %t421, %t424
  %t426 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t425)
  call void @olang_textcopy(ptr %t426, ptr %t413, i64 %t414)
  %t427 = getelementptr i8, ptr %t426, i64 %t414
  call void @olang_textcopy(ptr %t427, ptr %t416, i64 %t417)
  %t428 = getelementptr i8, ptr %t427, i64 %t417
  call void @olang_textcopy(ptr %t428, ptr %t419, i64 %t420)
  %t429 = getelementptr i8, ptr %t428, i64 %t420
  call void @olang_textcopy(ptr %t429, ptr %t423, i64 %t424)
  %t430 = insertvalue { i64, ptr } undef, i64 %t425, 0
  %t431 = insertvalue { i64, ptr } %t430, ptr %t426, 1
  %t433 = extractvalue { i64, ptr } %t431, 0
  %t434 = extractvalue { i64, ptr } %t431, 1
  %t435 = mul i64 %t433, 1
  %t436 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t435)
  call void @llvm.memcpy.p0.p0.i64(ptr %t436, ptr %t434, i64 %t435, i1 false)
  %t437 = insertvalue { i64, ptr } undef, i64 %t433, 0
  %t438 = insertvalue { i64, ptr } %t437, ptr %t436, 1
  %t441 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s11, ptr %s11, ptr %t410, { i64, ptr } %t438)
  store { i64, ptr } %t441, ptr %l177
  br label %bb82
bb82:
  %t442 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t445 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t446 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t447 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d177, i32 0, i32 1) }, 1
  %t448 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d177, i32 0, i32 1) }, 0
  %t450 = extractvalue { i64, ptr } %t442, 1
  %t451 = extractvalue { i64, ptr } %t442, 0
  %t452 = add i64 %t448, %t451
  %t453 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d178, i32 0, i32 1) }, 1
  %t454 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d178, i32 0, i32 1) }, 0
  %t455 = add i64 %t452, %t454
  %t457 = extractvalue { i64, ptr } %t445, 1
  %t458 = extractvalue { i64, ptr } %t445, 0
  %t459 = add i64 %t455, %t458
  %t460 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d178, i32 0, i32 1) }, 1
  %t461 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d178, i32 0, i32 1) }, 0
  %t462 = add i64 %t459, %t461
  %t464 = extractvalue { i64, ptr } %t446, 1
  %t465 = extractvalue { i64, ptr } %t446, 0
  %t466 = add i64 %t462, %t465
  %t467 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t466)
  call void @olang_textcopy(ptr %t467, ptr %t447, i64 %t448)
  %t468 = getelementptr i8, ptr %t467, i64 %t448
  call void @olang_textcopy(ptr %t468, ptr %t450, i64 %t451)
  %t469 = getelementptr i8, ptr %t468, i64 %t451
  call void @olang_textcopy(ptr %t469, ptr %t453, i64 %t454)
  %t470 = getelementptr i8, ptr %t469, i64 %t454
  call void @olang_textcopy(ptr %t470, ptr %t457, i64 %t458)
  %t471 = getelementptr i8, ptr %t470, i64 %t458
  call void @olang_textcopy(ptr %t471, ptr %t460, i64 %t461)
  %t472 = getelementptr i8, ptr %t471, i64 %t461
  call void @olang_textcopy(ptr %t472, ptr %t464, i64 %t465)
  %t473 = insertvalue { i64, ptr } undef, i64 %t466, 0
  %t474 = insertvalue { i64, ptr } %t473, ptr %t467, 1
  %t476 = extractvalue { i64, ptr } %t474, 0
  %t477 = extractvalue { i64, ptr } %t474, 1
  %t478 = mul i64 %t476, 1
  %t479 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t478)
  call void @llvm.memcpy.p0.p0.i64(ptr %t479, ptr %t477, i64 %t478, i1 false)
  %t480 = insertvalue { i64, ptr } undef, i64 %t476, 0
  %t481 = insertvalue { i64, ptr } %t480, ptr %t479, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s11, ptr %t443, { i64, ptr } %t481)
  br label %bb83
bb83:
  %t484 = load ptr, ptr %l0, !tbaa !29
  %t485 = load { i64, ptr }, ptr %l20, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s11, ptr %t484, { i64, ptr } %t485)
  br label %bb84
bb84:
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t489 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t490 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t491 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t492 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d179, i32 0, i32 1) }, 1
  %t493 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d179, i32 0, i32 1) }, 0
  %t495 = extractvalue { i64, ptr } %t489, 1
  %t496 = extractvalue { i64, ptr } %t489, 0
  %t497 = add i64 %t493, %t496
  %t498 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d180, i32 0, i32 1) }, 1
  %t499 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d180, i32 0, i32 1) }, 0
  %t500 = add i64 %t497, %t499
  %t502 = extractvalue { i64, ptr } %t490, 1
  %t503 = extractvalue { i64, ptr } %t490, 0
  %t504 = add i64 %t500, %t503
  %t505 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d181, i32 0, i32 1) }, 1
  %t506 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d181, i32 0, i32 1) }, 0
  %t507 = add i64 %t504, %t506
  %t509 = extractvalue { i64, ptr } %t491, 1
  %t510 = extractvalue { i64, ptr } %t491, 0
  %t511 = add i64 %t507, %t510
  %t512 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t511)
  call void @olang_textcopy(ptr %t512, ptr %t492, i64 %t493)
  %t513 = getelementptr i8, ptr %t512, i64 %t493
  call void @olang_textcopy(ptr %t513, ptr %t495, i64 %t496)
  %t514 = getelementptr i8, ptr %t513, i64 %t496
  call void @olang_textcopy(ptr %t514, ptr %t498, i64 %t499)
  %t515 = getelementptr i8, ptr %t514, i64 %t499
  call void @olang_textcopy(ptr %t515, ptr %t502, i64 %t503)
  %t516 = getelementptr i8, ptr %t515, i64 %t503
  call void @olang_textcopy(ptr %t516, ptr %t505, i64 %t506)
  %t517 = getelementptr i8, ptr %t516, i64 %t506
  call void @olang_textcopy(ptr %t517, ptr %t509, i64 %t510)
  %t518 = insertvalue { i64, ptr } undef, i64 %t511, 0
  %t519 = insertvalue { i64, ptr } %t518, ptr %t512, 1
  %t521 = extractvalue { i64, ptr } %t519, 0
  %t522 = extractvalue { i64, ptr } %t519, 1
  %t523 = mul i64 %t521, 1
  %t524 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t523)
  call void @llvm.memcpy.p0.p0.i64(ptr %t524, ptr %t522, i64 %t523, i1 false)
  %t525 = insertvalue { i64, ptr } undef, i64 %t521, 0
  %t526 = insertvalue { i64, ptr } %t525, ptr %t524, 1
  %t529 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s11, ptr %s11, ptr %t488, { i64, ptr } %t526)
  store { i64, ptr } %t529, ptr %l192
  br label %bb85
bb85:
  %t530 = load { i64, ptr }, ptr %l192, !tbaa !27
  store { i64, ptr } %t530, ptr %l24, !tbaa !27
  %t531 = load i1, ptr %l15, !tbaa !21
  br i1 %t531, label %bb86, label %bb87
bb86:
  store %olang.scope zeroinitializer, ptr %s17
  %t533 = load ptr, ptr %l0, !tbaa !29
  %t534 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t535 = load i32, ptr %l8, !tbaa !23
  %t536 = load { i64, [4 x i64] }, ptr %l4
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eput(ptr %v0, ptr %s11, ptr %s17, ptr %t533, { i64, ptr } %t534, i32 %t535, { i64, [4 x i64] } %t536, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d182, i32 0, i32 1) })
  br label %bb88
bb87:
  store %olang.scope zeroinitializer, ptr %s18
  %t541 = load ptr, ptr %l0, !tbaa !29
  %t542 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t543 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t544 = load { i64, ptr }, ptr %l24, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s11, ptr %s11, ptr %s11, ptr %s18, ptr %t541, { i64, ptr } %t542, { i64, ptr } %t543, { i64, ptr } %t544, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d118, i32 0, i32 1) })
  br label %bb89
bb88:
  call void @__olang_scope_close(ptr %s17)
  br label %bb90
bb89:
  call void @__olang_scope_close(ptr %s18)
  br label %bb90
bb90:
  %t549 = load ptr, ptr %l0, !tbaa !29
  store ptr %t549, ptr %l202, !tbaa !29
  %t550 = load ptr, ptr %l0, !tbaa !29
  %t551 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t552 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d183, i32 0, i32 1) }, 1
  %t553 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d183, i32 0, i32 1) }, 0
  %t555 = extractvalue { i64, ptr } %t551, 1
  %t556 = extractvalue { i64, ptr } %t551, 0
  %t557 = add i64 %t553, %t556
  %t558 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d184, i32 0, i32 1) }, 1
  %t559 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d184, i32 0, i32 1) }, 0
  %t560 = add i64 %t557, %t559
  %t561 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t560)
  call void @olang_textcopy(ptr %t561, ptr %t552, i64 %t553)
  %t562 = getelementptr i8, ptr %t561, i64 %t553
  call void @olang_textcopy(ptr %t562, ptr %t555, i64 %t556)
  %t563 = getelementptr i8, ptr %t562, i64 %t556
  call void @olang_textcopy(ptr %t563, ptr %t558, i64 %t559)
  %t564 = insertvalue { i64, ptr } undef, i64 %t560, 0
  %t565 = insertvalue { i64, ptr } %t564, ptr %t561, 1
  %t567 = extractvalue { i64, ptr } %t565, 0
  %t568 = extractvalue { i64, ptr } %t565, 1
  %t569 = mul i64 %t567, 1
  %t570 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t569)
  call void @llvm.memcpy.p0.p0.i64(ptr %t570, ptr %t568, i64 %t569, i1 false)
  %t571 = insertvalue { i64, ptr } undef, i64 %t567, 0
  %t572 = insertvalue { i64, ptr } %t571, ptr %t570, 1
  %t575 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s11, ptr %s11, ptr %t550, { i64, ptr } %t572)
  store { i64, ptr } %t575, ptr %l207
  br label %bb91
bb91:
  %t576 = load { i64, ptr }, ptr %l207, !tbaa !27
  %t577 = extractvalue { i64, ptr } %t576, 0
  %t578 = extractvalue { i64, ptr } %t576, 1
  %t579 = mul i64 %t577, 1
  %t580 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t579)
  call void @llvm.memcpy.p0.p0.i64(ptr %t580, ptr %t578, i64 %t579, i1 false)
  %t581 = insertvalue { i64, ptr } undef, i64 %t577, 0
  %t582 = insertvalue { i64, ptr } %t581, ptr %t580, 1
  %t583 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t584 = load ptr, ptr %l202, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s11, ptr %s11, ptr %s11, ptr %s11, ptr %t584, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d185, i32 0, i32 1) }, { i64, ptr } %t582, { i64, ptr } %t583, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d118, i32 0, i32 1) })
  br label %bb92
bb92:
  %t587 = load ptr, ptr %l0, !tbaa !29
  %t588 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t589 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d186, i32 0, i32 1) }, 1
  %t590 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d186, i32 0, i32 1) }, 0
  %t592 = extractvalue { i64, ptr } %t588, 1
  %t593 = extractvalue { i64, ptr } %t588, 0
  %t594 = add i64 %t590, %t593
  %t595 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t594)
  call void @olang_textcopy(ptr %t595, ptr %t589, i64 %t590)
  %t596 = getelementptr i8, ptr %t595, i64 %t590
  call void @olang_textcopy(ptr %t596, ptr %t592, i64 %t593)
  %t597 = insertvalue { i64, ptr } undef, i64 %t594, 0
  %t598 = insertvalue { i64, ptr } %t597, ptr %t595, 1
  %t600 = extractvalue { i64, ptr } %t598, 0
  %t601 = extractvalue { i64, ptr } %t598, 1
  %t602 = mul i64 %t600, 1
  %t603 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t602)
  call void @llvm.memcpy.p0.p0.i64(ptr %t603, ptr %t601, i64 %t602, i1 false)
  %t604 = insertvalue { i64, ptr } undef, i64 %t600, 0
  %t605 = insertvalue { i64, ptr } %t604, ptr %t603, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s11, ptr %t587, { i64, ptr } %t605)
  br label %bb93
bb93:
  %t608 = load ptr, ptr %l0, !tbaa !29
  %t609 = load { i64, ptr }, ptr %l21, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s11, ptr %t608, { i64, ptr } %t609)
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s11)
  br label %bb95
bb95:
  %t612 = load ptr, ptr %l0, !tbaa !29
  %t613 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t614 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t618 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epair(ptr %v0, ptr %s0, ptr %s0, ptr %v1, ptr %t612, { i64, ptr } %t613, { i64, ptr } %t614)
  store { i64, ptr } %t618, ptr %l219
  br label %bb96
bb96:
  call void @__olang_scope_close(ptr %s0)
  %t619 = load { i64, ptr }, ptr %l219, !tbaa !27
  store { i64, ptr } %t619, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eprim(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, %"compiler/mir:Range" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca %"compiler/mir:Range"
  %l4 = alloca ptr
  %l5 = alloca { i64, [4 x i64] }
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca i1
  %l10 = alloca i1
  %lp11 = alloca ptr
  %l12 = alloca { i64, [4 x i64] }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l24 = alloca i32
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca i32
  %l50 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l55 = alloca i32
  %l56 = alloca i32
  %l58 = alloca i32
  %l59 = alloca { i64, ptr }
  %l66 = alloca { i64, [4 x i64] }
  %l69 = alloca i32
  %l72 = alloca i1
  %l76 = alloca i1
  %l80 = alloca ptr
  %l83 = alloca { i64, [4 x i64] }
  %l84 = alloca i32
  %l87 = alloca i32
  %l90 = alloca { i64, ptr }
  %l93 = alloca i1
  %l96 = alloca i1
  %l100 = alloca { i64, ptr }
  %l104 = alloca i1
  %l105 = alloca ptr
  %l106 = alloca ptr
  %l111 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l117 = alloca { i64, ptr }
  %l119 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l131 = alloca { i64, ptr }
  %l134 = alloca ptr
  %l135 = alloca { i64, ptr }
  %l136 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l157 = alloca { i64, ptr }
  %l160 = alloca ptr
  %l161 = alloca { i64, ptr }
  %l162 = alloca { i64, ptr }
  %l165 = alloca { i64, ptr }
  %l167 = alloca { i64, ptr }
  %l172 = alloca { i64, [4 x i64] }
  %l173 = alloca i64
  %l181 = alloca { i64, ptr }
  %l182 = alloca { i64, ptr }
  %l183 = alloca i64
  %l184 = alloca { i64, ptr }
  %l188 = alloca { i64, ptr }
  %l193 = alloca { i64, ptr }
  %l198 = alloca { i64, ptr }
  %l204 = alloca { i64, ptr }
  %l210 = alloca { i64, ptr }
  %l217 = alloca { i64, ptr }
  %l224 = alloca { i64, ptr }
  %l229 = alloca { i64, ptr }
  %l230 = alloca ptr
  %l231 = alloca { i64, ptr }
  %l232 = alloca { i64, ptr }
  %l235 = alloca { i64, ptr }
  %l238 = alloca { i64, ptr }
  %l243 = alloca { i64, ptr }
  %l244 = alloca ptr
  %l245 = alloca { i64, ptr }
  %l247 = alloca ptr
  %l248 = alloca ptr
  %l251 = alloca { i64, [4 x i64] }
  %l252 = alloca i32
  %l253 = alloca { i64, ptr }
  %l256 = alloca { i64, ptr }
  %l261 = alloca i1
  %l262 = alloca i32
  %l265 = alloca i32
  %l269 = alloca i32
  %l273 = alloca i1
  %l277 = alloca i1
  %l280 = alloca i1
  %l286 = alloca { i64, ptr }
  %l291 = alloca { i64, ptr }
  %l292 = alloca ptr
  %l293 = alloca { i64, ptr }
  %l294 = alloca ptr
  %l297 = alloca i32
  %l298 = alloca i64
  %l301 = alloca { i64, ptr }
  %l309 = alloca { i64, ptr }
  %l310 = alloca { i64, ptr }
  %l311 = alloca i64
  %l312 = alloca { i64, ptr }
  %l317 = alloca i1
  %l318 = alloca i32
  %l321 = alloca i32
  %l325 = alloca i32
  %l329 = alloca i1
  %l332 = alloca i1
  %l335 = alloca i64
  %l341 = alloca { i64, ptr }
  %l346 = alloca i32
  %l347 = alloca ptr
  %l350 = alloca { i64, ptr }
  %l351 = alloca { i64, ptr }
  %l354 = alloca i64
  %l357 = alloca { i64, ptr }
  %l366 = alloca { i64, ptr }
  %l369 = alloca { i64, ptr }
  %l374 = alloca ptr
  %l375 = alloca { i64, ptr }
  %l376 = alloca { i64, ptr }
  %l377 = alloca { i64, ptr }
  %l378 = alloca { i64, ptr }
  %l380 = alloca i1
  %l382 = alloca { i64, ptr }
  %l385 = alloca ptr
  %l386 = alloca { i64, ptr }
  %l387 = alloca { i64, ptr }
  %l388 = alloca { i64, ptr }
  %l389 = alloca { i64, ptr }
  %l391 = alloca i1
  %l393 = alloca { i64, ptr }
  %l396 = alloca { i64, ptr }
  %l401 = alloca { i64, ptr }
  %l406 = alloca i64
  %l411 = alloca i64
  %l416 = alloca i64
  %l435 = alloca { i64, ptr }
  %l443 = alloca { i64, ptr }
  %l444 = alloca ptr
  %l445 = alloca { i64, ptr }
  %l451 = alloca { i64, ptr }
  %l455 = alloca { i64, ptr }
  %l473 = alloca { i64, ptr }
  %l478 = alloca ptr
  %l479 = alloca ptr
  %l482 = alloca { i64, [4 x i64] }
  %l484 = alloca { i64, ptr }
  %l488 = alloca { i64, ptr }
  %l491 = alloca i64
  %l497 = alloca ptr
  %l498 = alloca ptr
  %l501 = alloca { i64, [4 x i64] }
  %l503 = alloca { i64, ptr }
  %l507 = alloca { i64, ptr }
  %l512 = alloca { i64, ptr }
  %l518 = alloca { i64, ptr }
  %l519 = alloca ptr
  %l526 = alloca { i64, ptr }
  %l530 = alloca { i64, ptr }
  %l532 = alloca i64
  %l536 = alloca { i64, ptr }
  %l560 = alloca { i64, ptr }
  %l561 = alloca ptr
  %l564 = alloca { i64, [4 x i64] }
  %l566 = alloca { i64, ptr }
  %l568 = alloca i1
  %l571 = alloca { i64, ptr }
  %l574 = alloca { i64, ptr }
  %l575 = alloca { i64, ptr }
  %l587 = alloca i1
  %l589 = alloca ptr
  %l596 = alloca { i64, ptr }
  %l598 = alloca { i64, ptr }
  %l615 = alloca { i64, ptr }
  %l618 = alloca ptr
  %l620 = alloca { i64, ptr }
  %l626 = alloca { i64, ptr }
  %l629 = alloca ptr
  %l631 = alloca { i64, ptr }
  %l637 = alloca { i64, ptr }
  %l640 = alloca ptr
  %l642 = alloca { i64, ptr }
  %l648 = alloca { i64, ptr }
  %l651 = alloca ptr
  %l653 = alloca { i64, ptr }
  %l655 = alloca { i64, ptr }
  %l661 = alloca { i64, ptr }
  %l664 = alloca ptr
  %l666 = alloca { i64, ptr }
  %l668 = alloca { i64, ptr }
  %l674 = alloca { i64, ptr }
  %l679 = alloca ptr
  %l682 = alloca { i64, [4 x i64] }
  %l683 = alloca i32
  %l684 = alloca ptr
  %l685 = alloca ptr
  %l688 = alloca { i64, [4 x i64] }
  %l690 = alloca { i64, ptr }
  %l694 = alloca { i64, ptr }
  %l697 = alloca { i64, ptr }
  %l699 = alloca { i64, ptr }
  %l707 = alloca { i64, ptr }
  %l716 = alloca { i64, ptr }
  %l725 = alloca { i64, ptr }
  %l734 = alloca { i64, ptr }
  %l752 = alloca { i64, ptr }
  %l756 = alloca i1
  %l757 = alloca i1
  %l759 = alloca i1
  %l761 = alloca i1
  %l762 = alloca { i64, ptr }
  %l763 = alloca ptr
  %l764 = alloca { i64, ptr }
  %l770 = alloca { i64, ptr }
  %l776 = alloca { i64, ptr }
  %l779 = alloca { i64, ptr }
  %l780 = alloca ptr
  %l786 = alloca { i64, ptr }
  %l792 = alloca { i64, ptr }
  %l795 = alloca { i64, ptr }
  %l801 = alloca { i64, ptr }
  %l808 = alloca { i64, ptr }
  %l814 = alloca i1
  %l815 = alloca ptr
  %l821 = alloca { i64, ptr }
  %l825 = alloca { i64, ptr }
  %l826 = alloca ptr
  %l827 = alloca { i64, ptr }
  %l832 = alloca { i64, ptr }
  %l835 = alloca { i64, ptr }
  %l840 = alloca i32
  %l841 = alloca ptr
  %l844 = alloca { i64, ptr }
  %l845 = alloca ptr
  %l848 = alloca { i64, [4 x i64] }
  %l850 = alloca { i64, ptr }
  %l851 = alloca { i64, ptr }
  %l854 = alloca i64
  %l857 = alloca { i64, ptr }
  %l858 = alloca { i64, ptr }
  %l859 = alloca i64
  %l860 = alloca { i64, ptr }
  %l867 = alloca i32
  %l870 = alloca { i64, ptr }
  %l871 = alloca ptr
  %l872 = alloca { i64, ptr }
  %l873 = alloca { i64, ptr }
  %l876 = alloca { i64, ptr }
  %l877 = alloca ptr
  %l880 = alloca { i64, [4 x i64] }
  %l882 = alloca { i64, ptr }
  %l885 = alloca { i64, ptr }
  %l890 = alloca i32
  %l893 = alloca { i64, ptr }
  %l894 = alloca ptr
  %l895 = alloca { i64, ptr }
  %l896 = alloca { i64, ptr }
  %l897 = alloca ptr
  %l900 = alloca { i64, [4 x i64] }
  %l902 = alloca { i64, ptr }
  %l903 = alloca { i64, ptr }
  %l904 = alloca ptr
  %l907 = alloca { i64, [4 x i64] }
  %l909 = alloca { i64, ptr }
  %l912 = alloca { i64, ptr }
  %l918 = alloca { i64, ptr }
  %l919 = alloca ptr
  %l920 = alloca i32
  %l922 = alloca { i64, ptr }
  %l924 = alloca { i64, ptr }
  %l925 = alloca { i64, ptr }
  %l926 = alloca i64
  %l927 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s43 = alloca %olang.scope
  %s47 = alloca %olang.scope
  %s49 = alloca %olang.scope
  %s60 = alloca %olang.scope
  %s61 = alloca %olang.scope
  %s70 = alloca %olang.scope
  %s91 = alloca %olang.scope
  %s100 = alloca %olang.scope
  %s101 = alloca %olang.scope
  %s110 = alloca %olang.scope
  %s111 = alloca %olang.scope
  %s116 = alloca %olang.scope
  %s118 = alloca %olang.scope
  %s120 = alloca %olang.scope
  %s123 = alloca %olang.scope
  %s124 = alloca %olang.builder
  %s124room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/mir:Range" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load %"compiler/mir:Range", ptr %l3
  %t13 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t9, %"compiler/mir:Range" %t10, i64 0)
  store { i64, [4 x i64] } %t13, ptr %l66
  br label %bb1
bb1:
  %t14 = load { i64, [4 x i64] }, ptr %l66
  store { i64, [4 x i64] } %t14, ptr %l5
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load { i64, [4 x i64] }, ptr %l5
  %t19 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t15, { i64, [4 x i64] } %t16)
  store i32 %t19, ptr %l69
  br label %bb2
bb2:
  %t20 = load i32, ptr %l69, !tbaa !23
  store i32 %t20, ptr %l6, !tbaa !23
  %t21 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t22 = load i32, ptr %t21, !tbaa !23
  %t24 = icmp sgt i32 %t22, 1
  br i1 %t24, label %bb3, label %bb4
bb3:
  %t26 = load i32, ptr %l6, !tbaa !23
  %t27 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t30 = icmp eq i32 %t26, %t27
  br i1 %t30, label %bb5, label %bb6
bb4:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb8
bb5:
  store i1 true, ptr %l76, !tbaa !21
  br label %bb7
bb6:
  %t32 = load i32, ptr %l6, !tbaa !23
  %t33 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t36 = icmp eq i32 %t32, %t33
  store i1 %t36, ptr %l76, !tbaa !21
  br label %bb7
bb7:
  %t38 = load i1, ptr %l76, !tbaa !21
  store i1 %t38, ptr %l72, !tbaa !21
  br label %bb8
bb8:
  %t39 = load i1, ptr %l72, !tbaa !21
  br i1 %t39, label %bb9, label %bb10
bb9:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l80, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load %"compiler/mir:Range", ptr %l3
  %t45 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t41, %"compiler/mir:Range" %t42, i64 1)
  store { i64, [4 x i64] } %t45, ptr %l83
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t46 = load ptr, ptr %l80, !tbaa !29
  %t47 = load { i64, [4 x i64] }, ptr %l83
  %t48 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t46, { i64, [4 x i64] } %t47)
  store i32 %t48, ptr %l84
  br label %bb12
bb12:
  %t49 = load i32, ptr %l84, !tbaa !23
  store i32 %t49, ptr %l6, !tbaa !23
  br label %bb13
bb13:
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t51 = load i32, ptr %l6, !tbaa !23
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t50, i32 %t51)
  store i32 %t54, ptr %l87
  br label %bb14
bb14:
  %t55 = load i32, ptr %l87, !tbaa !23
  store i32 %t55, ptr %l7, !tbaa !23
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i32, ptr %l7, !tbaa !23
  %t60 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s0, ptr %t56, i32 %t57)
  store { i64, ptr } %t60, ptr %l90
  br label %bb15
bb15:
  %t61 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t61, ptr %l8, !tbaa !27
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t63 = load i32, ptr %l7, !tbaa !23
  %t66 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t62, i32 %t63)
  store i1 %t66, ptr %l93
  br label %bb16
bb16:
  %t67 = load i1, ptr %l93, !tbaa !21
  store i1 %t67, ptr %l9, !tbaa !21
  %t68 = load ptr, ptr %l4, !tbaa !29
  %t69 = load i32, ptr %l7, !tbaa !23
  %t72 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t68, i32 %t69)
  store i1 %t72, ptr %l96
  br label %bb17
bb17:
  %t73 = load i1, ptr %l96, !tbaa !21
  store i1 %t73, ptr %l10, !tbaa !21
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load { i64, [4 x i64] }, ptr %l5
  %t76 = load i32, ptr %l6, !tbaa !23
  %t80 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %v1, ptr %t74, { i64, [4 x i64] } %t75, i32 %t76)
  store { i64, ptr } %t80, ptr %l100
  br label %bb18
bb18:
  %t81 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t81, ptr %lp11
  %t82 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t83 = load ptr, ptr %lp11
  store { i64, ptr } %t82, ptr %t83, !tbaa !27
  %t84 = load i32, ptr %l1
  %t86 = trunc i64 0 to i32
  %t87 = icmp eq i32 %t84, %t86
  br i1 %t87, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb34
bb21:
  store %olang.scope zeroinitializer, ptr %s2
  %t89 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t91 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s2, { i64, ptr } %t89, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d187, i32 0, i32 1) })
  store i1 %t91, ptr %l104
  br label %bb22
bb22:
  %t92 = load i1, ptr %l104, !tbaa !21
  br i1 %t92, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s3
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l105, !tbaa !29
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l106, !tbaa !29
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load ptr, ptr %lp11
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !27
  %t98 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d188, i32 0, i32 1) }, 1
  %t99 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d188, i32 0, i32 1) }, 0
  %t101 = extractvalue { i64, ptr } %t97, 1
  %t102 = extractvalue { i64, ptr } %t97, 0
  %t103 = add i64 %t99, %t102
  %t104 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d189, i32 0, i32 1) }, 1
  %t105 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d189, i32 0, i32 1) }, 0
  %t106 = add i64 %t103, %t105
  %t107 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t106)
  call void @olang_textcopy(ptr %t107, ptr %t98, i64 %t99)
  %t108 = getelementptr i8, ptr %t107, i64 %t99
  call void @olang_textcopy(ptr %t108, ptr %t101, i64 %t102)
  %t109 = getelementptr i8, ptr %t108, i64 %t102
  call void @olang_textcopy(ptr %t109, ptr %t104, i64 %t105)
  %t110 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t107, 1
  %t113 = extractvalue { i64, ptr } %t111, 0
  %t114 = extractvalue { i64, ptr } %t111, 1
  %t115 = mul i64 %t113, 1
  %t116 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t115)
  call void @llvm.memcpy.p0.p0.i64(ptr %t116, ptr %t114, i64 %t115, i1 false)
  %t117 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t116, 1
  %t121 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s3, ptr %s3, ptr %t95, { i64, ptr } %t118)
  store { i64, ptr } %t121, ptr %l111
  br label %bb25
bb24:
  br label %bb28
bb25:
  %t122 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d190, i32 0, i32 1) }, 1
  %t123 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d190, i32 0, i32 1) }, 0
  %t124 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t124, 1
  %t126 = extractvalue { i64, ptr } %t124, 0
  %t127 = add i64 %t123, %t126
  %t128 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d191, i32 0, i32 1) }, 1
  %t129 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d191, i32 0, i32 1) }, 0
  %t130 = add i64 %t127, %t129
  %t131 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t130)
  call void @olang_textcopy(ptr %t131, ptr %t122, i64 %t123)
  %t132 = getelementptr i8, ptr %t131, i64 %t123
  call void @olang_textcopy(ptr %t132, ptr %t125, i64 %t126)
  %t133 = getelementptr i8, ptr %t132, i64 %t126
  call void @olang_textcopy(ptr %t133, ptr %t128, i64 %t129)
  %t134 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t131, 1
  %t137 = extractvalue { i64, ptr } %t135, 0
  %t138 = extractvalue { i64, ptr } %t135, 1
  %t139 = mul i64 %t137, 1
  %t140 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t139)
  call void @llvm.memcpy.p0.p0.i64(ptr %t140, ptr %t138, i64 %t139, i1 false)
  %t141 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t140, 1
  %t143 = load ptr, ptr %l106, !tbaa !29
  %t145 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s3, ptr %s3, ptr %t143, { i64, ptr } %t142)
  store { i64, ptr } %t145, ptr %l114
  br label %bb26
bb26:
  %t146 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d192, i32 0, i32 1) }, 1
  %t147 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d192, i32 0, i32 1) }, 0
  %t148 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t149 = extractvalue { i64, ptr } %t148, 1
  %t150 = extractvalue { i64, ptr } %t148, 0
  %t151 = add i64 %t147, %t150
  %t152 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d193, i32 0, i32 1) }, 1
  %t153 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d193, i32 0, i32 1) }, 0
  %t154 = add i64 %t151, %t153
  %t155 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t154)
  call void @olang_textcopy(ptr %t155, ptr %t146, i64 %t147)
  %t156 = getelementptr i8, ptr %t155, i64 %t147
  call void @olang_textcopy(ptr %t156, ptr %t149, i64 %t150)
  %t157 = getelementptr i8, ptr %t156, i64 %t150
  call void @olang_textcopy(ptr %t157, ptr %t152, i64 %t153)
  %t158 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t155, 1
  %t161 = extractvalue { i64, ptr } %t159, 0
  %t162 = extractvalue { i64, ptr } %t159, 1
  %t163 = mul i64 %t161, 1
  %t164 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t163)
  call void @llvm.memcpy.p0.p0.i64(ptr %t164, ptr %t162, i64 %t163, i1 false)
  %t165 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t164, 1
  %t167 = load ptr, ptr %l105, !tbaa !29
  %t169 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t167, { i64, ptr } %t166)
  store { i64, ptr } %t169, ptr %l117
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t170 = load { i64, ptr }, ptr %l117, !tbaa !27
  store { i64, ptr } %t170, ptr %rv
  br label %ret
bb28:
  %t171 = load i1, ptr %l9, !tbaa !21
  br i1 %t171, label %bb29, label %bb30
bb29:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t175 = load ptr, ptr %lp11
  %t176 = load { i64, ptr }, ptr %t175, !tbaa !27
  %t177 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d194, i32 0, i32 1) }, 1
  %t178 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d194, i32 0, i32 1) }, 0
  %t180 = extractvalue { i64, ptr } %t174, 1
  %t181 = extractvalue { i64, ptr } %t174, 0
  %t182 = add i64 %t178, %t181
  %t183 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d195, i32 0, i32 1) }, 1
  %t184 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d195, i32 0, i32 1) }, 0
  %t185 = add i64 %t182, %t184
  %t187 = extractvalue { i64, ptr } %t176, 1
  %t188 = extractvalue { i64, ptr } %t176, 0
  %t189 = add i64 %t185, %t188
  %t190 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t189)
  call void @olang_textcopy(ptr %t190, ptr %t177, i64 %t178)
  %t191 = getelementptr i8, ptr %t190, i64 %t178
  call void @olang_textcopy(ptr %t191, ptr %t180, i64 %t181)
  %t192 = getelementptr i8, ptr %t191, i64 %t181
  call void @olang_textcopy(ptr %t192, ptr %t183, i64 %t184)
  %t193 = getelementptr i8, ptr %t192, i64 %t184
  call void @olang_textcopy(ptr %t193, ptr %t187, i64 %t188)
  %t194 = insertvalue { i64, ptr } undef, i64 %t189, 0
  %t195 = insertvalue { i64, ptr } %t194, ptr %t190, 1
  %t197 = extractvalue { i64, ptr } %t195, 0
  %t198 = extractvalue { i64, ptr } %t195, 1
  %t199 = mul i64 %t197, 1
  %t200 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t199)
  call void @llvm.memcpy.p0.p0.i64(ptr %t200, ptr %t198, i64 %t199, i1 false)
  %t201 = insertvalue { i64, ptr } undef, i64 %t197, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t200, 1
  %t205 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t173, { i64, ptr } %t202)
  store { i64, ptr } %t205, ptr %l125
  br label %bb31
bb30:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t207 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t208 = load ptr, ptr %lp11
  %t209 = load { i64, ptr }, ptr %t208, !tbaa !27
  %t210 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d196, i32 0, i32 1) }, 1
  %t211 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d196, i32 0, i32 1) }, 0
  %t213 = extractvalue { i64, ptr } %t207, 1
  %t214 = extractvalue { i64, ptr } %t207, 0
  %t215 = add i64 %t211, %t214
  %t216 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d197, i32 0, i32 1) }, 1
  %t217 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d197, i32 0, i32 1) }, 0
  %t218 = add i64 %t215, %t217
  %t220 = extractvalue { i64, ptr } %t209, 1
  %t221 = extractvalue { i64, ptr } %t209, 0
  %t222 = add i64 %t218, %t221
  %t223 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t222)
  call void @olang_textcopy(ptr %t223, ptr %t210, i64 %t211)
  %t224 = getelementptr i8, ptr %t223, i64 %t211
  call void @olang_textcopy(ptr %t224, ptr %t213, i64 %t214)
  %t225 = getelementptr i8, ptr %t224, i64 %t214
  call void @olang_textcopy(ptr %t225, ptr %t216, i64 %t217)
  %t226 = getelementptr i8, ptr %t225, i64 %t217
  call void @olang_textcopy(ptr %t226, ptr %t220, i64 %t221)
  %t227 = insertvalue { i64, ptr } undef, i64 %t222, 0
  %t228 = insertvalue { i64, ptr } %t227, ptr %t223, 1
  %t230 = extractvalue { i64, ptr } %t228, 0
  %t231 = extractvalue { i64, ptr } %t228, 1
  %t232 = mul i64 %t230, 1
  %t233 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t232)
  call void @llvm.memcpy.p0.p0.i64(ptr %t233, ptr %t231, i64 %t232, i1 false)
  %t234 = insertvalue { i64, ptr } undef, i64 %t230, 0
  %t235 = insertvalue { i64, ptr } %t234, ptr %t233, 1
  %t238 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t206, { i64, ptr } %t235)
  store { i64, ptr } %t238, ptr %l131
  br label %bb32
bb31:
  %t239 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t239, ptr %l119, !tbaa !27
  br label %bb33
bb32:
  %t240 = load { i64, ptr }, ptr %l131, !tbaa !27
  store { i64, ptr } %t240, ptr %l119, !tbaa !27
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t241 = load { i64, ptr }, ptr %l119, !tbaa !27
  store { i64, ptr } %t241, ptr %rv
  br label %ret
bb34:
  %t242 = load i32, ptr %l1
  %t244 = trunc i64 1 to i32
  %t245 = icmp eq i32 %t242, %t244
  br i1 %t245, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb42
bb37:
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l134, !tbaa !29
  %t248 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t248, ptr %l135, !tbaa !27
  %t249 = load ptr, ptr %lp11
  %t250 = load { i64, ptr }, ptr %t249, !tbaa !27
  store { i64, ptr } %t250, ptr %l136, !tbaa !27
  %t251 = load i32, ptr %l7, !tbaa !23
  %t252 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t255 = icmp eq i32 %t251, %t252
  br i1 %t255, label %bb38, label %bb39
bb38:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d198, i32 0, i32 1) }, ptr %l140, !tbaa !27
  br label %bb40
bb39:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d199, i32 0, i32 1) }, ptr %l140, !tbaa !27
  br label %bb40
bb40:
  %t257 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d200, i32 0, i32 1) }, 1
  %t258 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d200, i32 0, i32 1) }, 0
  %t259 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t260 = extractvalue { i64, ptr } %t259, 1
  %t261 = extractvalue { i64, ptr } %t259, 0
  %t262 = add i64 %t258, %t261
  %t263 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d201, i32 0, i32 1) }, 1
  %t264 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d201, i32 0, i32 1) }, 0
  %t265 = add i64 %t262, %t264
  %t266 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t267 = extractvalue { i64, ptr } %t266, 1
  %t268 = extractvalue { i64, ptr } %t266, 0
  %t269 = add i64 %t265, %t268
  %t270 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d202, i32 0, i32 1) }, 1
  %t271 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d202, i32 0, i32 1) }, 0
  %t272 = add i64 %t269, %t271
  %t273 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t274 = extractvalue { i64, ptr } %t273, 1
  %t275 = extractvalue { i64, ptr } %t273, 0
  %t276 = add i64 %t272, %t275
  %t277 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t276)
  call void @olang_textcopy(ptr %t277, ptr %t257, i64 %t258)
  %t278 = getelementptr i8, ptr %t277, i64 %t258
  call void @olang_textcopy(ptr %t278, ptr %t260, i64 %t261)
  %t279 = getelementptr i8, ptr %t278, i64 %t261
  call void @olang_textcopy(ptr %t279, ptr %t263, i64 %t264)
  %t280 = getelementptr i8, ptr %t279, i64 %t264
  call void @olang_textcopy(ptr %t280, ptr %t267, i64 %t268)
  %t281 = getelementptr i8, ptr %t280, i64 %t268
  call void @olang_textcopy(ptr %t281, ptr %t270, i64 %t271)
  %t282 = getelementptr i8, ptr %t281, i64 %t271
  call void @olang_textcopy(ptr %t282, ptr %t274, i64 %t275)
  %t283 = insertvalue { i64, ptr } undef, i64 %t276, 0
  %t284 = insertvalue { i64, ptr } %t283, ptr %t277, 1
  %t286 = extractvalue { i64, ptr } %t284, 0
  %t287 = extractvalue { i64, ptr } %t284, 1
  %t288 = mul i64 %t286, 1
  %t289 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t288)
  call void @llvm.memcpy.p0.p0.i64(ptr %t289, ptr %t287, i64 %t288, i1 false)
  %t290 = insertvalue { i64, ptr } undef, i64 %t286, 0
  %t291 = insertvalue { i64, ptr } %t290, ptr %t289, 1
  %t292 = load ptr, ptr %l134, !tbaa !29
  %t294 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t292, { i64, ptr } %t291)
  store { i64, ptr } %t294, ptr %l143
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s0)
  %t295 = load { i64, ptr }, ptr %l143, !tbaa !27
  store { i64, ptr } %t295, ptr %rv
  br label %ret
bb42:
  %t296 = load i32, ptr %l1
  %t298 = trunc i64 2 to i32
  %t299 = icmp eq i32 %t296, %t298
  br i1 %t299, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t302 = load ptr, ptr %lp11
  %t303 = load { i64, ptr }, ptr %t302, !tbaa !27
  %t304 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d203, i32 0, i32 1) }, 1
  %t305 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d203, i32 0, i32 1) }, 0
  %t307 = extractvalue { i64, ptr } %t303, 1
  %t308 = extractvalue { i64, ptr } %t303, 0
  %t309 = add i64 %t305, %t308
  %t310 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d204, i32 0, i32 1) }, 1
  %t311 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d204, i32 0, i32 1) }, 0
  %t312 = add i64 %t309, %t311
  %t313 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t312)
  call void @olang_textcopy(ptr %t313, ptr %t304, i64 %t305)
  %t314 = getelementptr i8, ptr %t313, i64 %t305
  call void @olang_textcopy(ptr %t314, ptr %t307, i64 %t308)
  %t315 = getelementptr i8, ptr %t314, i64 %t308
  call void @olang_textcopy(ptr %t315, ptr %t310, i64 %t311)
  %t316 = insertvalue { i64, ptr } undef, i64 %t312, 0
  %t317 = insertvalue { i64, ptr } %t316, ptr %t313, 1
  %t319 = extractvalue { i64, ptr } %t317, 0
  %t320 = extractvalue { i64, ptr } %t317, 1
  %t321 = mul i64 %t319, 1
  %t322 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t321)
  call void @llvm.memcpy.p0.p0.i64(ptr %t322, ptr %t320, i64 %t321, i1 false)
  %t323 = insertvalue { i64, ptr } undef, i64 %t319, 0
  %t324 = insertvalue { i64, ptr } %t323, ptr %t322, 1
  %t327 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t301, { i64, ptr } %t324)
  store { i64, ptr } %t327, ptr %l150
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s0)
  %t328 = load { i64, ptr }, ptr %l150, !tbaa !27
  store { i64, ptr } %t328, ptr %rv
  br label %ret
bb47:
  %t329 = load i32, ptr %l1
  %t331 = trunc i64 20 to i32
  %t332 = icmp eq i32 %t329, %t331
  br i1 %t332, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t335 = load ptr, ptr %lp11
  %t336 = load { i64, ptr }, ptr %t335, !tbaa !27
  %t337 = load i32, ptr %l6, !tbaa !23
  %t338 = load i32, ptr %l2, !tbaa !23
  %t343 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2econvert(ptr %v0, ptr %v1, ptr %v1, ptr %t334, { i64, ptr } %t336, i32 %t337, i32 %t338)
  store { i64, ptr } %t343, ptr %l157
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s0)
  %t344 = load { i64, ptr }, ptr %l157, !tbaa !27
  store { i64, ptr } %t344, ptr %rv
  br label %ret
bb52:
  %t345 = load i32, ptr %l1
  %t347 = trunc i64 21 to i32
  %t348 = icmp eq i32 %t345, %t347
  br i1 %t348, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb58
bb55:
  %t350 = load ptr, ptr %l0, !tbaa !29
  store ptr %t350, ptr %l160, !tbaa !29
  %t351 = load ptr, ptr %lp11
  %t352 = load { i64, ptr }, ptr %t351, !tbaa !27
  store { i64, ptr } %t352, ptr %l161, !tbaa !27
  %t353 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t353, ptr %l162, !tbaa !27
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t355 = load i32, ptr %l2, !tbaa !23
  %t358 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %v1, ptr %t354, i32 %t355)
  store { i64, ptr } %t358, ptr %l165
  br label %bb56
bb56:
  %t359 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t360 = extractvalue { i64, ptr } %t359, 0
  %t361 = extractvalue { i64, ptr } %t359, 1
  %t362 = mul i64 %t360, 1
  %t363 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t362)
  call void @llvm.memcpy.p0.p0.i64(ptr %t363, ptr %t361, i64 %t362, i1 false)
  %t364 = insertvalue { i64, ptr } undef, i64 %t360, 0
  %t365 = insertvalue { i64, ptr } %t364, ptr %t363, 1
  %t366 = load ptr, ptr %l160, !tbaa !29
  %t367 = load { i64, ptr }, ptr %l161, !tbaa !27
  %t368 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t370 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ebitcast(ptr %v0, ptr %v1, ptr %s0, ptr %v1, ptr %v1, ptr %t366, { i64, ptr } %t367, { i64, ptr } %t368, { i64, ptr } %t365)
  store { i64, ptr } %t370, ptr %l167
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s0)
  %t371 = load { i64, ptr }, ptr %l167, !tbaa !27
  store { i64, ptr } %t371, ptr %rv
  br label %ret
bb58:
  %t372 = load i32, ptr %l1
  %t374 = trunc i64 40 to i32
  %t375 = icmp eq i32 %t372, %t374
  br i1 %t375, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb81
bb61:
  store %olang.scope zeroinitializer, ptr %s15
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t378 = load %"compiler/mir:Range", ptr %l3
  %t381 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t377, %"compiler/mir:Range" %t378, i64 1)
  store { i64, [4 x i64] } %t381, ptr %l172
  br label %bb62
bb62:
  %t382 = load { i64, [4 x i64] }, ptr %l172
  store { i64, [4 x i64] } %t382, ptr %l12
  %t383 = load { i64, [4 x i64] }, ptr %l12
  %t385 = extractvalue { i64, [4 x i64] } %t383, 0
  %t386 = icmp eq i64 %t385, 2
  br i1 %t386, label %bb63, label %bb64
bb63:
  %t388 = getelementptr { i64, [4 x i64] }, ptr %l12, i32 0, i32 1
  %t389 = getelementptr { i32, i64 }, ptr %t388, i32 0, i32 1
  %t390 = load i64, ptr %t389
  store i64 %t390, ptr %l13, !tbaa !24
  br label %bb65
bb64:
  br label %bb66
bb65:
  %t392 = load i64, ptr %l13, !tbaa !24
  store i64 %t392, ptr %l173, !tbaa !24
  br label %bb71
bb66:
  br i1 true, label %bb67, label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb70
bb69:
  store i64 -1, ptr %l173, !tbaa !24
  br label %bb71
bb70:
  call void @__olang_check_failed(ptr @olang_loc_69dfe582bfe1941e_f4b5889a4307147a)
  unreachable
bb71:
  %t394 = load i64, ptr %l173, !tbaa !24
  store i64 %t394, ptr %l14, !tbaa !24
  %t395 = load i64, ptr %l14, !tbaa !24
  %t397 = icmp slt i64 %t395, 0
  br i1 %t397, label %bb72, label %bb73
bb72:
  store %olang.scope zeroinitializer, ptr %s18
  %t399 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s18, ptr %t399, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d205, i32 0, i32 1) })
  br label %bb74
bb73:
  br label %bb75
bb74:
  store { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d206, i32 0, i32 1) }, ptr %l181, !tbaa !27
  %t401 = load { i64, ptr }, ptr %l181, !tbaa !27
  store { i64, ptr } %t401, ptr %l182, !tbaa !27
  %t402 = load { i64, ptr }, ptr %l182, !tbaa !27
  %t403 = extractvalue { i64, ptr } %t402, 0
  store i64 %t403, ptr %l183, !tbaa !24
  %t404 = load i64, ptr %l183, !tbaa !24
  %t405 = mul i64 %t404, 1
  %t406 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t405)
  %t407 = insertvalue { i64, ptr } undef, i64 %t404, 0
  %t408 = insertvalue { i64, ptr } %t407, ptr %t406, 1
  store { i64, ptr } %t408, ptr %l184, !tbaa !27
  %t409 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t410 = load ptr, ptr %t409, !tbaa !27
  %t411 = getelementptr { i64, ptr }, ptr %l182, i32 0, i32 1
  %t412 = load ptr, ptr %t411, !tbaa !27
  %t413 = load i64, ptr %l183, !tbaa !24
  %t414 = mul i64 %t413, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t410, ptr %t412, i64 %t414, i1 false)
  %t415 = load { i64, ptr }, ptr %l184, !tbaa !27
  store { i64, ptr } %t415, ptr %l182, !tbaa !27
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t416 = load { i64, ptr }, ptr %l182, !tbaa !27
  store { i64, ptr } %t416, ptr %rv
  br label %ret
bb75:
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t419 = getelementptr %"compiler/emit:fnEm", ptr %t417, i32 0, i32 0
  %t420 = load ptr, ptr %t419, !tbaa !29
  %t421 = load i64, ptr %l14, !tbaa !24
  %t424 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eanyTable(ptr %v0, ptr %s15, ptr %t420, i64 %t421)
  store { i64, ptr } %t424, ptr %l188
  br label %bb76
bb76:
  %t425 = load { i64, ptr }, ptr %l188, !tbaa !27
  store { i64, ptr } %t425, ptr %l15, !tbaa !27
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t427 = load ptr, ptr %lp11
  %t428 = load { i64, ptr }, ptr %t427, !tbaa !27
  %t429 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d207, i32 0, i32 1) }, 1
  %t430 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d207, i32 0, i32 1) }, 0
  %t432 = extractvalue { i64, ptr } %t428, 1
  %t433 = extractvalue { i64, ptr } %t428, 0
  %t434 = add i64 %t430, %t433
  %t435 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d208, i32 0, i32 1) }, 1
  %t436 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d208, i32 0, i32 1) }, 0
  %t437 = add i64 %t434, %t436
  %t438 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t437)
  call void @olang_textcopy(ptr %t438, ptr %t429, i64 %t430)
  %t439 = getelementptr i8, ptr %t438, i64 %t430
  call void @olang_textcopy(ptr %t439, ptr %t432, i64 %t433)
  %t440 = getelementptr i8, ptr %t439, i64 %t433
  call void @olang_textcopy(ptr %t440, ptr %t435, i64 %t436)
  %t441 = insertvalue { i64, ptr } undef, i64 %t437, 0
  %t442 = insertvalue { i64, ptr } %t441, ptr %t438, 1
  %t444 = extractvalue { i64, ptr } %t442, 0
  %t445 = extractvalue { i64, ptr } %t442, 1
  %t446 = mul i64 %t444, 1
  %t447 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t446)
  call void @llvm.memcpy.p0.p0.i64(ptr %t447, ptr %t445, i64 %t446, i1 false)
  %t448 = insertvalue { i64, ptr } undef, i64 %t444, 0
  %t449 = insertvalue { i64, ptr } %t448, ptr %t447, 1
  %t452 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s15, ptr %s15, ptr %t426, { i64, ptr } %t449)
  store { i64, ptr } %t452, ptr %l193
  br label %bb77
bb77:
  %t453 = load { i64, ptr }, ptr %l193, !tbaa !27
  store { i64, ptr } %t453, ptr %l16, !tbaa !27
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t455 = load ptr, ptr %lp11
  %t456 = load { i64, ptr }, ptr %t455, !tbaa !27
  %t457 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d209, i32 0, i32 1) }, 1
  %t458 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d209, i32 0, i32 1) }, 0
  %t460 = extractvalue { i64, ptr } %t456, 1
  %t461 = extractvalue { i64, ptr } %t456, 0
  %t462 = add i64 %t458, %t461
  %t463 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d210, i32 0, i32 1) }, 1
  %t464 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d210, i32 0, i32 1) }, 0
  %t465 = add i64 %t462, %t464
  %t466 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t465)
  call void @olang_textcopy(ptr %t466, ptr %t457, i64 %t458)
  %t467 = getelementptr i8, ptr %t466, i64 %t458
  call void @olang_textcopy(ptr %t467, ptr %t460, i64 %t461)
  %t468 = getelementptr i8, ptr %t467, i64 %t461
  call void @olang_textcopy(ptr %t468, ptr %t463, i64 %t464)
  %t469 = insertvalue { i64, ptr } undef, i64 %t465, 0
  %t470 = insertvalue { i64, ptr } %t469, ptr %t466, 1
  %t472 = extractvalue { i64, ptr } %t470, 0
  %t473 = extractvalue { i64, ptr } %t470, 1
  %t474 = mul i64 %t472, 1
  %t475 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t474)
  call void @llvm.memcpy.p0.p0.i64(ptr %t475, ptr %t473, i64 %t474, i1 false)
  %t476 = insertvalue { i64, ptr } undef, i64 %t472, 0
  %t477 = insertvalue { i64, ptr } %t476, ptr %t475, 1
  %t480 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s15, ptr %s15, ptr %t454, { i64, ptr } %t477)
  store { i64, ptr } %t480, ptr %l198
  br label %bb78
bb78:
  %t481 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t484 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t485 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d211, i32 0, i32 1) }, 1
  %t486 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d211, i32 0, i32 1) }, 0
  %t488 = extractvalue { i64, ptr } %t481, 1
  %t489 = extractvalue { i64, ptr } %t481, 0
  %t490 = add i64 %t486, %t489
  %t491 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d212, i32 0, i32 1) }, 1
  %t492 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d212, i32 0, i32 1) }, 0
  %t493 = add i64 %t490, %t492
  %t495 = extractvalue { i64, ptr } %t484, 1
  %t496 = extractvalue { i64, ptr } %t484, 0
  %t497 = add i64 %t493, %t496
  %t498 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d213, i32 0, i32 1) }, 1
  %t499 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d213, i32 0, i32 1) }, 0
  %t500 = add i64 %t497, %t499
  %t501 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t500)
  call void @olang_textcopy(ptr %t501, ptr %t485, i64 %t486)
  %t502 = getelementptr i8, ptr %t501, i64 %t486
  call void @olang_textcopy(ptr %t502, ptr %t488, i64 %t489)
  %t503 = getelementptr i8, ptr %t502, i64 %t489
  call void @olang_textcopy(ptr %t503, ptr %t491, i64 %t492)
  %t504 = getelementptr i8, ptr %t503, i64 %t492
  call void @olang_textcopy(ptr %t504, ptr %t495, i64 %t496)
  %t505 = getelementptr i8, ptr %t504, i64 %t496
  call void @olang_textcopy(ptr %t505, ptr %t498, i64 %t499)
  %t506 = insertvalue { i64, ptr } undef, i64 %t500, 0
  %t507 = insertvalue { i64, ptr } %t506, ptr %t501, 1
  %t509 = extractvalue { i64, ptr } %t507, 0
  %t510 = extractvalue { i64, ptr } %t507, 1
  %t511 = mul i64 %t509, 1
  %t512 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t511)
  call void @llvm.memcpy.p0.p0.i64(ptr %t512, ptr %t510, i64 %t511, i1 false)
  %t513 = insertvalue { i64, ptr } undef, i64 %t509, 0
  %t514 = insertvalue { i64, ptr } %t513, ptr %t512, 1
  %t517 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s15, ptr %s15, ptr %t482, { i64, ptr } %t514)
  store { i64, ptr } %t517, ptr %l204
  br label %bb79
bb79:
  %t518 = load { i64, ptr }, ptr %l204, !tbaa !27
  %t519 = load ptr, ptr %l0, !tbaa !29
  %t520 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t522 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d214, i32 0, i32 1) }, 1
  %t523 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d214, i32 0, i32 1) }, 0
  %t525 = extractvalue { i64, ptr } %t520, 1
  %t526 = extractvalue { i64, ptr } %t520, 0
  %t527 = add i64 %t523, %t526
  %t528 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d215, i32 0, i32 1) }, 1
  %t529 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d215, i32 0, i32 1) }, 0
  %t530 = add i64 %t527, %t529
  %t532 = extractvalue { i64, ptr } %t518, 1
  %t533 = extractvalue { i64, ptr } %t518, 0
  %t534 = add i64 %t530, %t533
  %t535 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d216, i32 0, i32 1) }, 1
  %t536 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d216, i32 0, i32 1) }, 0
  %t537 = add i64 %t534, %t536
  %t538 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t537)
  call void @olang_textcopy(ptr %t538, ptr %t522, i64 %t523)
  %t539 = getelementptr i8, ptr %t538, i64 %t523
  call void @olang_textcopy(ptr %t539, ptr %t525, i64 %t526)
  %t540 = getelementptr i8, ptr %t539, i64 %t526
  call void @olang_textcopy(ptr %t540, ptr %t528, i64 %t529)
  %t541 = getelementptr i8, ptr %t540, i64 %t529
  call void @olang_textcopy(ptr %t541, ptr %t532, i64 %t533)
  %t542 = getelementptr i8, ptr %t541, i64 %t533
  call void @olang_textcopy(ptr %t542, ptr %t535, i64 %t536)
  %t543 = insertvalue { i64, ptr } undef, i64 %t537, 0
  %t544 = insertvalue { i64, ptr } %t543, ptr %t538, 1
  %t546 = extractvalue { i64, ptr } %t544, 0
  %t547 = extractvalue { i64, ptr } %t544, 1
  %t548 = mul i64 %t546, 1
  %t549 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t548)
  call void @llvm.memcpy.p0.p0.i64(ptr %t549, ptr %t547, i64 %t548, i1 false)
  %t550 = insertvalue { i64, ptr } undef, i64 %t546, 0
  %t551 = insertvalue { i64, ptr } %t550, ptr %t549, 1
  %t554 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t519, { i64, ptr } %t551)
  store { i64, ptr } %t554, ptr %l210
  br label %bb80
bb80:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t555 = load { i64, ptr }, ptr %l210, !tbaa !27
  store { i64, ptr } %t555, ptr %rv
  br label %ret
bb81:
  %t556 = load i32, ptr %l1
  %t558 = trunc i64 41 to i32
  %t559 = icmp eq i32 %t556, %t558
  br i1 %t559, label %bb82, label %bb83
bb82:
  br label %bb84
bb83:
  br label %bb86
bb84:
  %t561 = load ptr, ptr %l0, !tbaa !29
  %t562 = load ptr, ptr %lp11
  %t563 = load { i64, ptr }, ptr %t562, !tbaa !27
  %t564 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d217, i32 0, i32 1) }, 1
  %t565 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d217, i32 0, i32 1) }, 0
  %t567 = extractvalue { i64, ptr } %t563, 1
  %t568 = extractvalue { i64, ptr } %t563, 0
  %t569 = add i64 %t565, %t568
  %t570 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d218, i32 0, i32 1) }, 1
  %t571 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d218, i32 0, i32 1) }, 0
  %t572 = add i64 %t569, %t571
  %t573 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t572)
  call void @olang_textcopy(ptr %t573, ptr %t564, i64 %t565)
  %t574 = getelementptr i8, ptr %t573, i64 %t565
  call void @olang_textcopy(ptr %t574, ptr %t567, i64 %t568)
  %t575 = getelementptr i8, ptr %t574, i64 %t568
  call void @olang_textcopy(ptr %t575, ptr %t570, i64 %t571)
  %t576 = insertvalue { i64, ptr } undef, i64 %t572, 0
  %t577 = insertvalue { i64, ptr } %t576, ptr %t573, 1
  %t579 = extractvalue { i64, ptr } %t577, 0
  %t580 = extractvalue { i64, ptr } %t577, 1
  %t581 = mul i64 %t579, 1
  %t582 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t581)
  call void @llvm.memcpy.p0.p0.i64(ptr %t582, ptr %t580, i64 %t581, i1 false)
  %t583 = insertvalue { i64, ptr } undef, i64 %t579, 0
  %t584 = insertvalue { i64, ptr } %t583, ptr %t582, 1
  %t587 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t561, { i64, ptr } %t584)
  store { i64, ptr } %t587, ptr %l217
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s0)
  %t588 = load { i64, ptr }, ptr %l217, !tbaa !27
  store { i64, ptr } %t588, ptr %rv
  br label %ret
bb86:
  %t589 = load i32, ptr %l1
  %t591 = trunc i64 42 to i32
  %t592 = icmp eq i32 %t589, %t591
  br i1 %t592, label %bb87, label %bb88
bb87:
  br label %bb89
bb88:
  br label %bb99
bb89:
  store %olang.scope zeroinitializer, ptr %s25
  %t594 = load ptr, ptr %l0, !tbaa !29
  %t595 = load ptr, ptr %lp11
  %t596 = load { i64, ptr }, ptr %t595, !tbaa !27
  %t597 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d219, i32 0, i32 1) }, 1
  %t598 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d219, i32 0, i32 1) }, 0
  %t600 = extractvalue { i64, ptr } %t596, 1
  %t601 = extractvalue { i64, ptr } %t596, 0
  %t602 = add i64 %t598, %t601
  %t603 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d220, i32 0, i32 1) }, 1
  %t604 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d220, i32 0, i32 1) }, 0
  %t605 = add i64 %t602, %t604
  %t606 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t605)
  call void @olang_textcopy(ptr %t606, ptr %t597, i64 %t598)
  %t607 = getelementptr i8, ptr %t606, i64 %t598
  call void @olang_textcopy(ptr %t607, ptr %t600, i64 %t601)
  %t608 = getelementptr i8, ptr %t607, i64 %t601
  call void @olang_textcopy(ptr %t608, ptr %t603, i64 %t604)
  %t609 = insertvalue { i64, ptr } undef, i64 %t605, 0
  %t610 = insertvalue { i64, ptr } %t609, ptr %t606, 1
  %t612 = extractvalue { i64, ptr } %t610, 0
  %t613 = extractvalue { i64, ptr } %t610, 1
  %t614 = mul i64 %t612, 1
  %t615 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t614)
  call void @llvm.memcpy.p0.p0.i64(ptr %t615, ptr %t613, i64 %t614, i1 false)
  %t616 = insertvalue { i64, ptr } undef, i64 %t612, 0
  %t617 = insertvalue { i64, ptr } %t616, ptr %t615, 1
  %t620 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s25, ptr %s25, ptr %t594, { i64, ptr } %t617)
  store { i64, ptr } %t620, ptr %l224
  br label %bb90
bb90:
  %t621 = load { i64, ptr }, ptr %l224, !tbaa !27
  store { i64, ptr } %t621, ptr %l19, !tbaa !27
  %t622 = load ptr, ptr %l0, !tbaa !29
  %t623 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t624 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d221, i32 0, i32 1) }, 1
  %t625 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d221, i32 0, i32 1) }, 0
  %t627 = extractvalue { i64, ptr } %t623, 1
  %t628 = extractvalue { i64, ptr } %t623, 0
  %t629 = add i64 %t625, %t628
  %t630 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d222, i32 0, i32 1) }, 1
  %t631 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d222, i32 0, i32 1) }, 0
  %t632 = add i64 %t629, %t631
  %t633 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t632)
  call void @olang_textcopy(ptr %t633, ptr %t624, i64 %t625)
  %t634 = getelementptr i8, ptr %t633, i64 %t625
  call void @olang_textcopy(ptr %t634, ptr %t627, i64 %t628)
  %t635 = getelementptr i8, ptr %t634, i64 %t628
  call void @olang_textcopy(ptr %t635, ptr %t630, i64 %t631)
  %t636 = insertvalue { i64, ptr } undef, i64 %t632, 0
  %t637 = insertvalue { i64, ptr } %t636, ptr %t633, 1
  %t639 = extractvalue { i64, ptr } %t637, 0
  %t640 = extractvalue { i64, ptr } %t637, 1
  %t641 = mul i64 %t639, 1
  %t642 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t641)
  call void @llvm.memcpy.p0.p0.i64(ptr %t642, ptr %t640, i64 %t641, i1 false)
  %t643 = insertvalue { i64, ptr } undef, i64 %t639, 0
  %t644 = insertvalue { i64, ptr } %t643, ptr %t642, 1
  %t647 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s25, ptr %s25, ptr %t622, { i64, ptr } %t644)
  store { i64, ptr } %t647, ptr %l229
  br label %bb91
bb91:
  %t648 = load { i64, ptr }, ptr %l229, !tbaa !27
  %t649 = load ptr, ptr %l0, !tbaa !29
  store ptr %t649, ptr %l230, !tbaa !29
  store { i64, ptr } %t648, ptr %l231, !tbaa !27
  %t651 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t651, ptr %l232, !tbaa !27
  %t652 = load ptr, ptr %l0, !tbaa !29
  %t654 = getelementptr %"compiler/emit:fnEm", ptr %t652, i32 0, i32 0
  %t655 = load ptr, ptr %t654, !tbaa !29
  %t657 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2enoTable(ptr %v0, ptr %s25, ptr %t655)
  store { i64, ptr } %t657, ptr %l235
  br label %bb92
bb92:
  %t658 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d223, i32 0, i32 1) }, 1
  %t659 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d223, i32 0, i32 1) }, 0
  %t660 = load { i64, ptr }, ptr %l231, !tbaa !27
  %t661 = extractvalue { i64, ptr } %t660, 1
  %t662 = extractvalue { i64, ptr } %t660, 0
  %t663 = add i64 %t659, %t662
  %t664 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d224, i32 0, i32 1) }, 1
  %t665 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d224, i32 0, i32 1) }, 0
  %t666 = add i64 %t663, %t665
  %t667 = load { i64, ptr }, ptr %l232, !tbaa !27
  %t668 = extractvalue { i64, ptr } %t667, 1
  %t669 = extractvalue { i64, ptr } %t667, 0
  %t670 = add i64 %t666, %t669
  %t671 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d225, i32 0, i32 1) }, 1
  %t672 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d225, i32 0, i32 1) }, 0
  %t673 = add i64 %t670, %t672
  %t674 = load { i64, ptr }, ptr %l235, !tbaa !27
  %t675 = extractvalue { i64, ptr } %t674, 1
  %t676 = extractvalue { i64, ptr } %t674, 0
  %t677 = add i64 %t673, %t676
  %t678 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t677)
  call void @olang_textcopy(ptr %t678, ptr %t658, i64 %t659)
  %t679 = getelementptr i8, ptr %t678, i64 %t659
  call void @olang_textcopy(ptr %t679, ptr %t661, i64 %t662)
  %t680 = getelementptr i8, ptr %t679, i64 %t662
  call void @olang_textcopy(ptr %t680, ptr %t664, i64 %t665)
  %t681 = getelementptr i8, ptr %t680, i64 %t665
  call void @olang_textcopy(ptr %t681, ptr %t668, i64 %t669)
  %t682 = getelementptr i8, ptr %t681, i64 %t669
  call void @olang_textcopy(ptr %t682, ptr %t671, i64 %t672)
  %t683 = getelementptr i8, ptr %t682, i64 %t672
  call void @olang_textcopy(ptr %t683, ptr %t675, i64 %t676)
  %t684 = insertvalue { i64, ptr } undef, i64 %t677, 0
  %t685 = insertvalue { i64, ptr } %t684, ptr %t678, 1
  %t687 = extractvalue { i64, ptr } %t685, 0
  %t688 = extractvalue { i64, ptr } %t685, 1
  %t689 = mul i64 %t687, 1
  %t690 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t689)
  call void @llvm.memcpy.p0.p0.i64(ptr %t690, ptr %t688, i64 %t689, i1 false)
  %t691 = insertvalue { i64, ptr } undef, i64 %t687, 0
  %t692 = insertvalue { i64, ptr } %t691, ptr %t690, 1
  %t693 = load ptr, ptr %l230, !tbaa !29
  %t695 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s25, ptr %s25, ptr %t693, { i64, ptr } %t692)
  store { i64, ptr } %t695, ptr %l238
  br label %bb93
bb93:
  %t696 = load { i64, ptr }, ptr %l238, !tbaa !27
  %t697 = load ptr, ptr %l0, !tbaa !29
  %t699 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d226, i32 0, i32 1) }, 1
  %t700 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d226, i32 0, i32 1) }, 0
  %t702 = extractvalue { i64, ptr } %t696, 1
  %t703 = extractvalue { i64, ptr } %t696, 0
  %t704 = add i64 %t700, %t703
  %t705 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t704)
  call void @olang_textcopy(ptr %t705, ptr %t699, i64 %t700)
  %t706 = getelementptr i8, ptr %t705, i64 %t700
  call void @olang_textcopy(ptr %t706, ptr %t702, i64 %t703)
  %t707 = insertvalue { i64, ptr } undef, i64 %t704, 0
  %t708 = insertvalue { i64, ptr } %t707, ptr %t705, 1
  %t710 = extractvalue { i64, ptr } %t708, 0
  %t711 = extractvalue { i64, ptr } %t708, 1
  %t712 = mul i64 %t710, 1
  %t713 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t712)
  call void @llvm.memcpy.p0.p0.i64(ptr %t713, ptr %t711, i64 %t712, i1 false)
  %t714 = insertvalue { i64, ptr } undef, i64 %t710, 0
  %t715 = insertvalue { i64, ptr } %t714, ptr %t713, 1
  %t718 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s25, ptr %s25, ptr %t697, { i64, ptr } %t715)
  store { i64, ptr } %t718, ptr %l243
  br label %bb94
bb94:
  %t719 = load { i64, ptr }, ptr %l243, !tbaa !27
  %t720 = load ptr, ptr %l0, !tbaa !29
  store ptr %t720, ptr %l244, !tbaa !29
  store { i64, ptr } %t719, ptr %l245, !tbaa !27
  %t722 = load ptr, ptr %l0, !tbaa !29
  %t724 = getelementptr %"compiler/emit:fnEm", ptr %t722, i32 0, i32 0
  %t725 = load ptr, ptr %t724, !tbaa !29
  store ptr %t725, ptr %l247, !tbaa !29
  %t726 = load ptr, ptr %l0, !tbaa !29
  store ptr %t726, ptr %l248, !tbaa !29
  %t727 = load ptr, ptr %l0, !tbaa !29
  %t728 = load %"compiler/mir:Range", ptr %l3
  %t731 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t727, %"compiler/mir:Range" %t728, i64 1)
  store { i64, [4 x i64] } %t731, ptr %l251
  br label %bb95
bb95:
  %t732 = load ptr, ptr %l248, !tbaa !29
  %t733 = load { i64, [4 x i64] }, ptr %l251
  %t734 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t732, { i64, [4 x i64] } %t733)
  store i32 %t734, ptr %l252
  br label %bb96
bb96:
  %t735 = load ptr, ptr %l247, !tbaa !29
  %t736 = load i32, ptr %l252, !tbaa !23
  %t737 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etypeid(ptr %v0, ptr %s25, ptr %t735, i32 %t736)
  store { i64, ptr } %t737, ptr %l253
  br label %bb97
bb97:
  %t738 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d227, i32 0, i32 1) }, 1
  %t739 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d227, i32 0, i32 1) }, 0
  %t740 = load { i64, ptr }, ptr %l245, !tbaa !27
  %t741 = extractvalue { i64, ptr } %t740, 1
  %t742 = extractvalue { i64, ptr } %t740, 0
  %t743 = add i64 %t739, %t742
  %t744 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d228, i32 0, i32 1) }, 1
  %t745 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d228, i32 0, i32 1) }, 0
  %t746 = add i64 %t743, %t745
  %t747 = load { i64, ptr }, ptr %l253, !tbaa !27
  %t748 = extractvalue { i64, ptr } %t747, 1
  %t749 = extractvalue { i64, ptr } %t747, 0
  %t750 = add i64 %t746, %t749
  %t751 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t750)
  call void @olang_textcopy(ptr %t751, ptr %t738, i64 %t739)
  %t752 = getelementptr i8, ptr %t751, i64 %t739
  call void @olang_textcopy(ptr %t752, ptr %t741, i64 %t742)
  %t753 = getelementptr i8, ptr %t752, i64 %t742
  call void @olang_textcopy(ptr %t753, ptr %t744, i64 %t745)
  %t754 = getelementptr i8, ptr %t753, i64 %t745
  call void @olang_textcopy(ptr %t754, ptr %t748, i64 %t749)
  %t755 = insertvalue { i64, ptr } undef, i64 %t750, 0
  %t756 = insertvalue { i64, ptr } %t755, ptr %t751, 1
  %t758 = extractvalue { i64, ptr } %t756, 0
  %t759 = extractvalue { i64, ptr } %t756, 1
  %t760 = mul i64 %t758, 1
  %t761 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t760)
  call void @llvm.memcpy.p0.p0.i64(ptr %t761, ptr %t759, i64 %t760, i1 false)
  %t762 = insertvalue { i64, ptr } undef, i64 %t758, 0
  %t763 = insertvalue { i64, ptr } %t762, ptr %t761, 1
  %t764 = load ptr, ptr %l244, !tbaa !29
  %t766 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t764, { i64, ptr } %t763)
  store { i64, ptr } %t766, ptr %l256
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s25)
  call void @__olang_scope_close(ptr %s0)
  %t767 = load { i64, ptr }, ptr %l256, !tbaa !27
  store { i64, ptr } %t767, ptr %rv
  br label %ret
bb99:
  %t768 = load i32, ptr %l1
  %t770 = trunc i64 29 to i32
  %t771 = icmp eq i32 %t768, %t770
  br i1 %t771, label %bb100, label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb126
bb102:
  %t773 = load ptr, ptr %l4, !tbaa !29
  %t774 = load i32, ptr %l7, !tbaa !23
  %t777 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t773, i32 %t774)
  store i1 %t777, ptr %l261
  br label %bb103
bb103:
  %t778 = load i1, ptr %l261, !tbaa !21
  br i1 %t778, label %bb104, label %bb105
bb104:
  %t779 = load ptr, ptr %l4, !tbaa !29
  %t780 = load i32, ptr %l7, !tbaa !23
  %t783 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t779, i32 %t780)
  store i32 %t783, ptr %l265
  br label %bb106
bb105:
  %t784 = load i32, ptr %l7, !tbaa !23
  store i32 %t784, ptr %l262, !tbaa !23
  br label %bb107
bb106:
  %t786 = load i32, ptr %l265, !tbaa !23
  store i32 %t786, ptr %l262, !tbaa !23
  br label %bb107
bb107:
  %t787 = load i32, ptr %l262, !tbaa !23
  %t788 = load ptr, ptr %l0, !tbaa !29
  %t792 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t788, i32 %t787)
  store i32 %t792, ptr %l269
  br label %bb108
bb108:
  %t793 = load i32, ptr %l269, !tbaa !23
  store i32 %t793, ptr %l24, !tbaa !23
  %t794 = load ptr, ptr %l0, !tbaa !29
  %t796 = getelementptr %"compiler/emit:fnEm", ptr %t794, i32 0, i32 0
  %t797 = load ptr, ptr %t796, !tbaa !29
  %t799 = getelementptr %"compiler/emit:Emitter", ptr %t797, i32 0, i32 46
  %t800 = load i1, ptr %t799, !tbaa !21
  br i1 %t800, label %bb109, label %bb110
bb109:
  %t802 = load i32, ptr %l24, !tbaa !23
  %t803 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t806 = icmp ne i32 %t802, %t803
  store i1 %t806, ptr %l273, !tbaa !21
  br label %bb111
bb110:
  store i1 false, ptr %l273, !tbaa !21
  br label %bb111
bb111:
  %t808 = load i1, ptr %l273, !tbaa !21
  br i1 %t808, label %bb112, label %bb113
bb112:
  %t809 = load ptr, ptr %l0, !tbaa !29
  %t810 = load i32, ptr %l24, !tbaa !23
  %t813 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixed(ptr %v0, ptr %t809, i32 %t810)
  store i1 %t813, ptr %l280
  br label %bb114
bb113:
  store i1 false, ptr %l277, !tbaa !21
  br label %bb115
bb114:
  %t814 = load i1, ptr %l280, !tbaa !21
  %t815 = xor i1 %t814, true
  store i1 %t815, ptr %l277, !tbaa !21
  br label %bb115
bb115:
  %t817 = load i1, ptr %l277, !tbaa !21
  br i1 %t817, label %bb116, label %bb117
bb116:
  store %olang.scope zeroinitializer, ptr %s32
  %t818 = load ptr, ptr %l0, !tbaa !29
  %t819 = load ptr, ptr %lp11
  %t820 = load { i64, ptr }, ptr %t819, !tbaa !27
  %t821 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d229, i32 0, i32 1) }, 1
  %t822 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d229, i32 0, i32 1) }, 0
  %t824 = extractvalue { i64, ptr } %t820, 1
  %t825 = extractvalue { i64, ptr } %t820, 0
  %t826 = add i64 %t822, %t825
  %t827 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d230, i32 0, i32 1) }, 1
  %t828 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d230, i32 0, i32 1) }, 0
  %t829 = add i64 %t826, %t828
  %t830 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t829)
  call void @olang_textcopy(ptr %t830, ptr %t821, i64 %t822)
  %t831 = getelementptr i8, ptr %t830, i64 %t822
  call void @olang_textcopy(ptr %t831, ptr %t824, i64 %t825)
  %t832 = getelementptr i8, ptr %t831, i64 %t825
  call void @olang_textcopy(ptr %t832, ptr %t827, i64 %t828)
  %t833 = insertvalue { i64, ptr } undef, i64 %t829, 0
  %t834 = insertvalue { i64, ptr } %t833, ptr %t830, 1
  %t836 = extractvalue { i64, ptr } %t834, 0
  %t837 = extractvalue { i64, ptr } %t834, 1
  %t838 = mul i64 %t836, 1
  %t839 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t838)
  call void @llvm.memcpy.p0.p0.i64(ptr %t839, ptr %t837, i64 %t838, i1 false)
  %t840 = insertvalue { i64, ptr } undef, i64 %t836, 0
  %t841 = insertvalue { i64, ptr } %t840, ptr %t839, 1
  %t844 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s32, ptr %s32, ptr %t818, { i64, ptr } %t841)
  store { i64, ptr } %t844, ptr %l286
  br label %bb118
bb117:
  br label %bb125
bb118:
  %t845 = load { i64, ptr }, ptr %l286, !tbaa !27
  store { i64, ptr } %t845, ptr %l25, !tbaa !27
  %t846 = load ptr, ptr %l0, !tbaa !29
  %t847 = load ptr, ptr %lp11
  %t848 = load { i64, ptr }, ptr %t847, !tbaa !27
  %t849 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d231, i32 0, i32 1) }, 1
  %t850 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d231, i32 0, i32 1) }, 0
  %t852 = extractvalue { i64, ptr } %t848, 1
  %t853 = extractvalue { i64, ptr } %t848, 0
  %t854 = add i64 %t850, %t853
  %t855 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d232, i32 0, i32 1) }, 1
  %t856 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d232, i32 0, i32 1) }, 0
  %t857 = add i64 %t854, %t856
  %t858 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t857)
  call void @olang_textcopy(ptr %t858, ptr %t849, i64 %t850)
  %t859 = getelementptr i8, ptr %t858, i64 %t850
  call void @olang_textcopy(ptr %t859, ptr %t852, i64 %t853)
  %t860 = getelementptr i8, ptr %t859, i64 %t853
  call void @olang_textcopy(ptr %t860, ptr %t855, i64 %t856)
  %t861 = insertvalue { i64, ptr } undef, i64 %t857, 0
  %t862 = insertvalue { i64, ptr } %t861, ptr %t858, 1
  %t864 = extractvalue { i64, ptr } %t862, 0
  %t865 = extractvalue { i64, ptr } %t862, 1
  %t866 = mul i64 %t864, 1
  %t867 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t866)
  call void @llvm.memcpy.p0.p0.i64(ptr %t867, ptr %t865, i64 %t866, i1 false)
  %t868 = insertvalue { i64, ptr } undef, i64 %t864, 0
  %t869 = insertvalue { i64, ptr } %t868, ptr %t867, 1
  %t872 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s32, ptr %s32, ptr %t846, { i64, ptr } %t869)
  store { i64, ptr } %t872, ptr %l291
  br label %bb119
bb119:
  %t873 = load { i64, ptr }, ptr %l291, !tbaa !27
  store { i64, ptr } %t873, ptr %l26, !tbaa !27
  %t874 = load ptr, ptr %l0, !tbaa !29
  store ptr %t874, ptr %l292, !tbaa !29
  %t875 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t875, ptr %l293, !tbaa !27
  %t876 = load ptr, ptr %l0, !tbaa !29
  store ptr %t876, ptr %l294, !tbaa !29
  %t877 = load ptr, ptr %l4, !tbaa !29
  %t878 = load i32, ptr %l24, !tbaa !23
  %t881 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t877, i32 %t878)
  store i32 %t881, ptr %l297
  br label %bb120
bb120:
  %t882 = load ptr, ptr %l294, !tbaa !29
  %t883 = load i32, ptr %l297, !tbaa !23
  %t884 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t882, i32 %t883)
  store i64 %t884, ptr %l298
  br label %bb121
bb121:
  %t885 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d233, i32 0, i32 1) }, 1
  %t886 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d233, i32 0, i32 1) }, 0
  %t887 = load { i64, ptr }, ptr %l293, !tbaa !27
  %t888 = extractvalue { i64, ptr } %t887, 1
  %t889 = extractvalue { i64, ptr } %t887, 0
  %t890 = add i64 %t886, %t889
  %t891 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d234, i32 0, i32 1) }, 1
  %t892 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d234, i32 0, i32 1) }, 0
  %t893 = add i64 %t890, %t892
  %t894 = load i64, ptr %l298, !tbaa !24
  %t895 = call i64 @__olang_fmt_i64(ptr null, i64 %t894)
  %t896 = add i64 %t893, %t895
  %t897 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t896)
  call void @olang_textcopy(ptr %t897, ptr %t885, i64 %t886)
  %t898 = getelementptr i8, ptr %t897, i64 %t886
  call void @olang_textcopy(ptr %t898, ptr %t888, i64 %t889)
  %t899 = getelementptr i8, ptr %t898, i64 %t889
  call void @olang_textcopy(ptr %t899, ptr %t891, i64 %t892)
  %t900 = getelementptr i8, ptr %t899, i64 %t892
  %t901 = call i64 @__olang_fmt_i64(ptr %t900, i64 %t894)
  %t902 = insertvalue { i64, ptr } undef, i64 %t896, 0
  %t903 = insertvalue { i64, ptr } %t902, ptr %t897, 1
  %t905 = extractvalue { i64, ptr } %t903, 0
  %t906 = extractvalue { i64, ptr } %t903, 1
  %t907 = mul i64 %t905, 1
  %t908 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t907)
  call void @llvm.memcpy.p0.p0.i64(ptr %t908, ptr %t906, i64 %t907, i1 false)
  %t909 = insertvalue { i64, ptr } undef, i64 %t905, 0
  %t910 = insertvalue { i64, ptr } %t909, ptr %t908, 1
  %t911 = load ptr, ptr %l292, !tbaa !29
  %t913 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s32, ptr %s32, ptr %t911, { i64, ptr } %t910)
  store { i64, ptr } %t913, ptr %l301
  br label %bb122
bb122:
  %t914 = load { i64, ptr }, ptr %l301, !tbaa !27
  store { i64, ptr } %t914, ptr %l27, !tbaa !27
  %t915 = load ptr, ptr %l0, !tbaa !29
  %t917 = getelementptr %"compiler/emit:fnEm", ptr %t915, i32 0, i32 0
  %t918 = load ptr, ptr %t917, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s32, ptr %t918, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d235, i32 0, i32 1) })
  br label %bb123
bb123:
  %t920 = load ptr, ptr %l0, !tbaa !29
  %t921 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t922 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t923 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d236, i32 0, i32 1) }, 1
  %t924 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d236, i32 0, i32 1) }, 0
  %t926 = extractvalue { i64, ptr } %t921, 1
  %t927 = extractvalue { i64, ptr } %t921, 0
  %t928 = add i64 %t924, %t927
  %t929 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d237, i32 0, i32 1) }, 1
  %t930 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d237, i32 0, i32 1) }, 0
  %t931 = add i64 %t928, %t930
  %t933 = extractvalue { i64, ptr } %t922, 1
  %t934 = extractvalue { i64, ptr } %t922, 0
  %t935 = add i64 %t931, %t934
  %t936 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d238, i32 0, i32 1) }, 1
  %t937 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d238, i32 0, i32 1) }, 0
  %t938 = add i64 %t935, %t937
  %t939 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t938)
  call void @olang_textcopy(ptr %t939, ptr %t923, i64 %t924)
  %t940 = getelementptr i8, ptr %t939, i64 %t924
  call void @olang_textcopy(ptr %t940, ptr %t926, i64 %t927)
  %t941 = getelementptr i8, ptr %t940, i64 %t927
  call void @olang_textcopy(ptr %t941, ptr %t929, i64 %t930)
  %t942 = getelementptr i8, ptr %t941, i64 %t930
  call void @olang_textcopy(ptr %t942, ptr %t933, i64 %t934)
  %t943 = getelementptr i8, ptr %t942, i64 %t934
  call void @olang_textcopy(ptr %t943, ptr %t936, i64 %t937)
  %t944 = insertvalue { i64, ptr } undef, i64 %t938, 0
  %t945 = insertvalue { i64, ptr } %t944, ptr %t939, 1
  %t947 = extractvalue { i64, ptr } %t945, 0
  %t948 = extractvalue { i64, ptr } %t945, 1
  %t949 = mul i64 %t947, 1
  %t950 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t949)
  call void @llvm.memcpy.p0.p0.i64(ptr %t950, ptr %t948, i64 %t949, i1 false)
  %t951 = insertvalue { i64, ptr } undef, i64 %t947, 0
  %t952 = insertvalue { i64, ptr } %t951, ptr %t950, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s32, ptr %t920, { i64, ptr } %t952)
  br label %bb124
bb124:
  call void @__olang_scope_close(ptr %s32)
  br label %bb125
bb125:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d239, i32 0, i32 1) }, ptr %l309, !tbaa !27
  %t955 = load { i64, ptr }, ptr %l309, !tbaa !27
  store { i64, ptr } %t955, ptr %l310, !tbaa !27
  %t956 = load { i64, ptr }, ptr %l310, !tbaa !27
  %t957 = extractvalue { i64, ptr } %t956, 0
  store i64 %t957, ptr %l311, !tbaa !24
  %t958 = load i64, ptr %l311, !tbaa !24
  %t959 = mul i64 %t958, 1
  %t960 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t959)
  %t961 = insertvalue { i64, ptr } undef, i64 %t958, 0
  %t962 = insertvalue { i64, ptr } %t961, ptr %t960, 1
  store { i64, ptr } %t962, ptr %l312, !tbaa !27
  %t963 = getelementptr { i64, ptr }, ptr %l312, i32 0, i32 1
  %t964 = load ptr, ptr %t963, !tbaa !27
  %t965 = getelementptr { i64, ptr }, ptr %l310, i32 0, i32 1
  %t966 = load ptr, ptr %t965, !tbaa !27
  %t967 = load i64, ptr %l311, !tbaa !24
  %t968 = mul i64 %t967, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t964, ptr %t966, i64 %t968, i1 false)
  %t969 = load { i64, ptr }, ptr %l312, !tbaa !27
  store { i64, ptr } %t969, ptr %l310, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t970 = load { i64, ptr }, ptr %l310, !tbaa !27
  store { i64, ptr } %t970, ptr %rv
  br label %ret
bb126:
  %t971 = load i32, ptr %l1
  %t973 = trunc i64 22 to i32
  %t974 = icmp eq i32 %t971, %t973
  br i1 %t974, label %bb127, label %bb128
bb127:
  br label %bb129
bb128:
  br label %bb145
bb129:
  %t976 = load ptr, ptr %l4, !tbaa !29
  %t977 = load i32, ptr %l7, !tbaa !23
  %t980 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t976, i32 %t977)
  store i1 %t980, ptr %l317
  br label %bb130
bb130:
  %t981 = load i1, ptr %l317, !tbaa !21
  br i1 %t981, label %bb131, label %bb132
bb131:
  %t982 = load ptr, ptr %l4, !tbaa !29
  %t983 = load i32, ptr %l7, !tbaa !23
  %t986 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t982, i32 %t983)
  store i32 %t986, ptr %l321
  br label %bb133
bb132:
  %t987 = load i32, ptr %l7, !tbaa !23
  store i32 %t987, ptr %l318, !tbaa !23
  br label %bb134
bb133:
  %t989 = load i32, ptr %l321, !tbaa !23
  store i32 %t989, ptr %l318, !tbaa !23
  br label %bb134
bb134:
  %t990 = load i32, ptr %l318, !tbaa !23
  %t991 = load ptr, ptr %l0, !tbaa !29
  %t995 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t991, i32 %t990)
  store i32 %t995, ptr %l325
  br label %bb135
bb135:
  %t996 = load i32, ptr %l325, !tbaa !23
  store i32 %t996, ptr %l29, !tbaa !23
  %t997 = load i32, ptr %l29, !tbaa !23
  %t998 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t1001 = icmp ne i32 %t997, %t998
  br i1 %t1001, label %bb136, label %bb137
bb136:
  %t1003 = load ptr, ptr %l0, !tbaa !29
  %t1004 = load i32, ptr %l29, !tbaa !23
  %t1007 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixed(ptr %v0, ptr %t1003, i32 %t1004)
  store i1 %t1007, ptr %l332
  br label %bb138
bb137:
  store i1 false, ptr %l329, !tbaa !21
  br label %bb139
bb138:
  %t1008 = load i1, ptr %l332, !tbaa !21
  store i1 %t1008, ptr %l329, !tbaa !21
  br label %bb139
bb139:
  %t1009 = load i1, ptr %l329, !tbaa !21
  br i1 %t1009, label %bb140, label %bb141
bb140:
  %t1010 = load ptr, ptr %l0, !tbaa !29
  %t1011 = load i32, ptr %l29, !tbaa !23
  %t1014 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixedLen(ptr %v0, ptr %t1010, i32 %t1011)
  store i64 %t1014, ptr %l335
  br label %bb142
bb141:
  br label %bb143
bb142:
  %t1015 = load i64, ptr %l335, !tbaa !24
  %t1016 = call i64 @__olang_fmt_i64(ptr null, i64 %t1015)
  %t1017 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1016)
  %t1018 = call i64 @__olang_fmt_i64(ptr %t1017, i64 %t1015)
  %t1019 = insertvalue { i64, ptr } undef, i64 %t1016, 0
  %t1020 = insertvalue { i64, ptr } %t1019, ptr %t1017, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t1020, ptr %rv
  br label %ret
bb143:
  %t1022 = load ptr, ptr %l0, !tbaa !29
  %t1023 = load ptr, ptr %lp11
  %t1024 = load { i64, ptr }, ptr %t1023, !tbaa !27
  %t1025 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d240, i32 0, i32 1) }, 1
  %t1026 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d240, i32 0, i32 1) }, 0
  %t1028 = extractvalue { i64, ptr } %t1024, 1
  %t1029 = extractvalue { i64, ptr } %t1024, 0
  %t1030 = add i64 %t1026, %t1029
  %t1031 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d241, i32 0, i32 1) }, 1
  %t1032 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d241, i32 0, i32 1) }, 0
  %t1033 = add i64 %t1030, %t1032
  %t1034 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1033)
  call void @olang_textcopy(ptr %t1034, ptr %t1025, i64 %t1026)
  %t1035 = getelementptr i8, ptr %t1034, i64 %t1026
  call void @olang_textcopy(ptr %t1035, ptr %t1028, i64 %t1029)
  %t1036 = getelementptr i8, ptr %t1035, i64 %t1029
  call void @olang_textcopy(ptr %t1036, ptr %t1031, i64 %t1032)
  %t1037 = insertvalue { i64, ptr } undef, i64 %t1033, 0
  %t1038 = insertvalue { i64, ptr } %t1037, ptr %t1034, 1
  %t1040 = extractvalue { i64, ptr } %t1038, 0
  %t1041 = extractvalue { i64, ptr } %t1038, 1
  %t1042 = mul i64 %t1040, 1
  %t1043 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1042)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1043, ptr %t1041, i64 %t1042, i1 false)
  %t1044 = insertvalue { i64, ptr } undef, i64 %t1040, 0
  %t1045 = insertvalue { i64, ptr } %t1044, ptr %t1043, 1
  %t1048 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t1022, { i64, ptr } %t1045)
  store { i64, ptr } %t1048, ptr %l341
  br label %bb144
bb144:
  call void @__olang_scope_close(ptr %s0)
  %t1049 = load { i64, ptr }, ptr %l341, !tbaa !27
  store { i64, ptr } %t1049, ptr %rv
  br label %ret
bb145:
  %t1050 = load i32, ptr %l1
  %t1052 = trunc i64 24 to i32
  %t1053 = icmp eq i32 %t1050, %t1052
  br i1 %t1053, label %bb146, label %bb147
bb146:
  br label %bb148
bb147:
  br label %bb153
bb148:
  store %olang.scope zeroinitializer, ptr %s41
  %t1055 = load ptr, ptr %l4, !tbaa !29
  %t1056 = load i32, ptr %l7, !tbaa !23
  %t1059 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t1055, i32 %t1056)
  store i32 %t1059, ptr %l346
  br label %bb149
bb149:
  %t1060 = load i32, ptr %l346, !tbaa !23
  store i32 %t1060, ptr %l30, !tbaa !23
  %t1061 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1061, ptr %l347, !tbaa !29
  %t1062 = load ptr, ptr %l0, !tbaa !29
  %t1063 = load i32, ptr %l30, !tbaa !23
  %t1066 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s41, ptr %t1062, i32 %t1063)
  store { i64, ptr } %t1066, ptr %l350
  br label %bb150
bb150:
  %t1067 = load ptr, ptr %lp11
  %t1068 = load { i64, ptr }, ptr %t1067, !tbaa !27
  store { i64, ptr } %t1068, ptr %l351, !tbaa !27
  %t1069 = load ptr, ptr %l0, !tbaa !29
  %t1070 = load i32, ptr %l30, !tbaa !23
  %t1073 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t1069, i32 %t1070)
  store i64 %t1073, ptr %l354
  br label %bb151
bb151:
  %t1074 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d242, i32 0, i32 1) }, 1
  %t1075 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d242, i32 0, i32 1) }, 0
  %t1076 = load { i64, ptr }, ptr %l350, !tbaa !27
  %t1077 = extractvalue { i64, ptr } %t1076, 1
  %t1078 = extractvalue { i64, ptr } %t1076, 0
  %t1079 = add i64 %t1075, %t1078
  %t1080 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d243, i32 0, i32 1) }, 1
  %t1081 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d243, i32 0, i32 1) }, 0
  %t1082 = add i64 %t1079, %t1081
  %t1083 = load { i64, ptr }, ptr %l351, !tbaa !27
  %t1084 = extractvalue { i64, ptr } %t1083, 1
  %t1085 = extractvalue { i64, ptr } %t1083, 0
  %t1086 = add i64 %t1082, %t1085
  %t1087 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d244, i32 0, i32 1) }, 1
  %t1088 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d244, i32 0, i32 1) }, 0
  %t1089 = add i64 %t1086, %t1088
  %t1090 = load i64, ptr %l354, !tbaa !24
  %t1091 = call i64 @__olang_fmt_i64(ptr null, i64 %t1090)
  %t1092 = add i64 %t1089, %t1091
  %t1093 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1092)
  call void @olang_textcopy(ptr %t1093, ptr %t1074, i64 %t1075)
  %t1094 = getelementptr i8, ptr %t1093, i64 %t1075
  call void @olang_textcopy(ptr %t1094, ptr %t1077, i64 %t1078)
  %t1095 = getelementptr i8, ptr %t1094, i64 %t1078
  call void @olang_textcopy(ptr %t1095, ptr %t1080, i64 %t1081)
  %t1096 = getelementptr i8, ptr %t1095, i64 %t1081
  call void @olang_textcopy(ptr %t1096, ptr %t1084, i64 %t1085)
  %t1097 = getelementptr i8, ptr %t1096, i64 %t1085
  call void @olang_textcopy(ptr %t1097, ptr %t1087, i64 %t1088)
  %t1098 = getelementptr i8, ptr %t1097, i64 %t1088
  %t1099 = call i64 @__olang_fmt_i64(ptr %t1098, i64 %t1090)
  %t1100 = insertvalue { i64, ptr } undef, i64 %t1092, 0
  %t1101 = insertvalue { i64, ptr } %t1100, ptr %t1093, 1
  %t1103 = extractvalue { i64, ptr } %t1101, 0
  %t1104 = extractvalue { i64, ptr } %t1101, 1
  %t1105 = mul i64 %t1103, 1
  %t1106 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1105)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1106, ptr %t1104, i64 %t1105, i1 false)
  %t1107 = insertvalue { i64, ptr } undef, i64 %t1103, 0
  %t1108 = insertvalue { i64, ptr } %t1107, ptr %t1106, 1
  %t1109 = load ptr, ptr %l347, !tbaa !29
  %t1111 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t1109, { i64, ptr } %t1108)
  store { i64, ptr } %t1111, ptr %l357
  br label %bb152
bb152:
  call void @__olang_scope_close(ptr %s41)
  call void @__olang_scope_close(ptr %s0)
  %t1112 = load { i64, ptr }, ptr %l357, !tbaa !27
  store { i64, ptr } %t1112, ptr %rv
  br label %ret
bb153:
  %t1113 = load i32, ptr %l1
  %t1115 = trunc i64 31 to i32
  %t1116 = icmp eq i32 %t1113, %t1115
  br i1 %t1116, label %bb154, label %bb155
bb154:
  br label %bb160
bb155:
  %t1118 = load i32, ptr %l1
  %t1120 = trunc i64 32 to i32
  %t1121 = icmp eq i32 %t1118, %t1120
  br i1 %t1121, label %bb156, label %bb157
bb156:
  br label %bb160
bb157:
  %t1123 = load i32, ptr %l1
  %t1125 = trunc i64 33 to i32
  %t1126 = icmp eq i32 %t1123, %t1125
  br i1 %t1126, label %bb158, label %bb159
bb158:
  br label %bb160
bb159:
  br label %bb178
bb160:
  store %olang.scope zeroinitializer, ptr %s43
  %t1128 = load i32, ptr %l1
  %t1130 = trunc i64 33 to i32
  %t1131 = icmp eq i32 %t1128, %t1130
  br i1 %t1131, label %bb161, label %bb162
bb161:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d245, i32 0, i32 1) }, ptr %l366, !tbaa !27
  br label %bb166
bb162:
  %t1133 = load i32, ptr %l1
  %t1135 = trunc i64 31 to i32
  %t1136 = icmp eq i32 %t1133, %t1135
  br i1 %t1136, label %bb163, label %bb164
bb163:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d246, i32 0, i32 1) }, ptr %l369, !tbaa !27
  br label %bb165
bb164:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d247, i32 0, i32 1) }, ptr %l369, !tbaa !27
  br label %bb165
bb165:
  %t1138 = load { i64, ptr }, ptr %l369, !tbaa !27
  store { i64, ptr } %t1138, ptr %l366, !tbaa !27
  br label %bb166
bb166:
  %t1139 = load { i64, ptr }, ptr %l366, !tbaa !27
  store { i64, ptr } %t1139, ptr %l31, !tbaa !27
  %t1140 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t1141 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1142 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d248, i32 0, i32 1) }, 1
  %t1143 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d248, i32 0, i32 1) }, 0
  %t1145 = extractvalue { i64, ptr } %t1140, 1
  %t1146 = extractvalue { i64, ptr } %t1140, 0
  %t1147 = add i64 %t1143, %t1146
  %t1148 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d249, i32 0, i32 1) }, 1
  %t1149 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d249, i32 0, i32 1) }, 0
  %t1150 = add i64 %t1147, %t1149
  %t1152 = extractvalue { i64, ptr } %t1141, 1
  %t1153 = extractvalue { i64, ptr } %t1141, 0
  %t1154 = add i64 %t1150, %t1153
  %t1155 = call ptr @__olang_scope_alloc(ptr %s43, i64 %t1154)
  call void @olang_textcopy(ptr %t1155, ptr %t1142, i64 %t1143)
  %t1156 = getelementptr i8, ptr %t1155, i64 %t1143
  call void @olang_textcopy(ptr %t1156, ptr %t1145, i64 %t1146)
  %t1157 = getelementptr i8, ptr %t1156, i64 %t1146
  call void @olang_textcopy(ptr %t1157, ptr %t1148, i64 %t1149)
  %t1158 = getelementptr i8, ptr %t1157, i64 %t1149
  call void @olang_textcopy(ptr %t1158, ptr %t1152, i64 %t1153)
  %t1159 = insertvalue { i64, ptr } undef, i64 %t1154, 0
  %t1160 = insertvalue { i64, ptr } %t1159, ptr %t1155, 1
  store { i64, ptr } %t1160, ptr %l32, !tbaa !27
  %t1162 = load ptr, ptr %l0, !tbaa !29
  %t1164 = getelementptr %"compiler/emit:fnEm", ptr %t1162, i32 0, i32 0
  %t1165 = load ptr, ptr %t1164, !tbaa !29
  store ptr %t1165, ptr %l374, !tbaa !29
  %t1166 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t1166, ptr %l375, !tbaa !27
  %t1167 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t1167, ptr %l376, !tbaa !27
  %t1168 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t1168, ptr %l377, !tbaa !27
  %t1169 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t1169, ptr %l378, !tbaa !27
  %t1170 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t1171 = load ptr, ptr @__olang_prog_scope
  %t1173 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t1171, ptr %s43, { i64, ptr } %t1170, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d250, i32 0, i32 1) })
  store i1 %t1173, ptr %l380
  br label %bb167
bb167:
  %t1174 = load i1, ptr %l380, !tbaa !21
  %t1175 = xor i1 %t1174, true
  br i1 %t1175, label %bb168, label %bb169
bb168:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d251, i32 0, i32 1) }, ptr %l382, !tbaa !27
  br label %bb170
bb169:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d252, i32 0, i32 1) }, ptr %l382, !tbaa !27
  br label %bb170
bb170:
  %t1177 = load { i64, ptr }, ptr %l376, !tbaa !27
  %t1178 = extractvalue { i64, ptr } %t1177, 1
  %t1179 = extractvalue { i64, ptr } %t1177, 0
  %t1180 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d253, i32 0, i32 1) }, 1
  %t1181 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d253, i32 0, i32 1) }, 0
  %t1182 = add i64 %t1179, %t1181
  %t1183 = load { i64, ptr }, ptr %l377, !tbaa !27
  %t1184 = extractvalue { i64, ptr } %t1183, 1
  %t1185 = extractvalue { i64, ptr } %t1183, 0
  %t1186 = add i64 %t1182, %t1185
  %t1187 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d254, i32 0, i32 1) }, 1
  %t1188 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d254, i32 0, i32 1) }, 0
  %t1189 = add i64 %t1186, %t1188
  %t1190 = load { i64, ptr }, ptr %l378, !tbaa !27
  %t1191 = extractvalue { i64, ptr } %t1190, 1
  %t1192 = extractvalue { i64, ptr } %t1190, 0
  %t1193 = add i64 %t1189, %t1192
  %t1194 = load { i64, ptr }, ptr %l382, !tbaa !27
  %t1195 = extractvalue { i64, ptr } %t1194, 1
  %t1196 = extractvalue { i64, ptr } %t1194, 0
  %t1197 = add i64 %t1193, %t1196
  %t1198 = call ptr @__olang_scope_alloc(ptr %s43, i64 %t1197)
  call void @olang_textcopy(ptr %t1198, ptr %t1178, i64 %t1179)
  %t1199 = getelementptr i8, ptr %t1198, i64 %t1179
  call void @olang_textcopy(ptr %t1199, ptr %t1180, i64 %t1181)
  %t1200 = getelementptr i8, ptr %t1199, i64 %t1181
  call void @olang_textcopy(ptr %t1200, ptr %t1184, i64 %t1185)
  %t1201 = getelementptr i8, ptr %t1200, i64 %t1185
  call void @olang_textcopy(ptr %t1201, ptr %t1187, i64 %t1188)
  %t1202 = getelementptr i8, ptr %t1201, i64 %t1188
  call void @olang_textcopy(ptr %t1202, ptr %t1191, i64 %t1192)
  %t1203 = getelementptr i8, ptr %t1202, i64 %t1192
  call void @olang_textcopy(ptr %t1203, ptr %t1195, i64 %t1196)
  %t1204 = insertvalue { i64, ptr } undef, i64 %t1197, 0
  %t1205 = insertvalue { i64, ptr } %t1204, ptr %t1198, 1
  %t1207 = extractvalue { i64, ptr } %t1205, 0
  %t1208 = extractvalue { i64, ptr } %t1205, 1
  %t1209 = mul i64 %t1207, 1
  %t1210 = call ptr @__olang_scope_alloc(ptr %s43, i64 %t1209)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1210, ptr %t1208, i64 %t1209, i1 false)
  %t1211 = insertvalue { i64, ptr } undef, i64 %t1207, 0
  %t1212 = insertvalue { i64, ptr } %t1211, ptr %t1210, 1
  %t1213 = load ptr, ptr %l374, !tbaa !29
  %t1214 = load { i64, ptr }, ptr %l375, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s43, ptr %s43, ptr %t1213, { i64, ptr } %t1214, { i64, ptr } %t1212)
  br label %bb171
bb171:
  %t1216 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1216, ptr %l385, !tbaa !29
  %t1217 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t1217, ptr %l386, !tbaa !27
  %t1218 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t1218, ptr %l387, !tbaa !27
  %t1219 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t1219, ptr %l388, !tbaa !27
  %t1220 = load ptr, ptr %lp11
  %t1221 = load { i64, ptr }, ptr %t1220, !tbaa !27
  store { i64, ptr } %t1221, ptr %l389, !tbaa !27
  %t1222 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t1223 = load ptr, ptr @__olang_prog_scope
  %t1225 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t1223, ptr %s43, { i64, ptr } %t1222, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d255, i32 0, i32 1) })
  store i1 %t1225, ptr %l391
  br label %bb172
bb172:
  %t1226 = load i1, ptr %l391, !tbaa !21
  %t1227 = xor i1 %t1226, true
  br i1 %t1227, label %bb173, label %bb174
bb173:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d256, i32 0, i32 1) }, ptr %l393, !tbaa !27
  br label %bb175
bb174:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d257, i32 0, i32 1) }, ptr %l393, !tbaa !27
  br label %bb175
bb175:
  %t1229 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d258, i32 0, i32 1) }, 1
  %t1230 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d258, i32 0, i32 1) }, 0
  %t1231 = load { i64, ptr }, ptr %l386, !tbaa !27
  %t1232 = extractvalue { i64, ptr } %t1231, 1
  %t1233 = extractvalue { i64, ptr } %t1231, 0
  %t1234 = add i64 %t1230, %t1233
  %t1235 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d259, i32 0, i32 1) }, 1
  %t1236 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d259, i32 0, i32 1) }, 0
  %t1237 = add i64 %t1234, %t1236
  %t1238 = load { i64, ptr }, ptr %l387, !tbaa !27
  %t1239 = extractvalue { i64, ptr } %t1238, 1
  %t1240 = extractvalue { i64, ptr } %t1238, 0
  %t1241 = add i64 %t1237, %t1240
  %t1242 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d260, i32 0, i32 1) }, 1
  %t1243 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d260, i32 0, i32 1) }, 0
  %t1244 = add i64 %t1241, %t1243
  %t1245 = load { i64, ptr }, ptr %l388, !tbaa !27
  %t1246 = extractvalue { i64, ptr } %t1245, 1
  %t1247 = extractvalue { i64, ptr } %t1245, 0
  %t1248 = add i64 %t1244, %t1247
  %t1249 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d261, i32 0, i32 1) }, 1
  %t1250 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d261, i32 0, i32 1) }, 0
  %t1251 = add i64 %t1248, %t1250
  %t1252 = load { i64, ptr }, ptr %l389, !tbaa !27
  %t1253 = extractvalue { i64, ptr } %t1252, 1
  %t1254 = extractvalue { i64, ptr } %t1252, 0
  %t1255 = add i64 %t1251, %t1254
  %t1256 = load { i64, ptr }, ptr %l393, !tbaa !27
  %t1257 = extractvalue { i64, ptr } %t1256, 1
  %t1258 = extractvalue { i64, ptr } %t1256, 0
  %t1259 = add i64 %t1255, %t1258
  %t1260 = call ptr @__olang_scope_alloc(ptr %s43, i64 %t1259)
  call void @olang_textcopy(ptr %t1260, ptr %t1229, i64 %t1230)
  %t1261 = getelementptr i8, ptr %t1260, i64 %t1230
  call void @olang_textcopy(ptr %t1261, ptr %t1232, i64 %t1233)
  %t1262 = getelementptr i8, ptr %t1261, i64 %t1233
  call void @olang_textcopy(ptr %t1262, ptr %t1235, i64 %t1236)
  %t1263 = getelementptr i8, ptr %t1262, i64 %t1236
  call void @olang_textcopy(ptr %t1263, ptr %t1239, i64 %t1240)
  %t1264 = getelementptr i8, ptr %t1263, i64 %t1240
  call void @olang_textcopy(ptr %t1264, ptr %t1242, i64 %t1243)
  %t1265 = getelementptr i8, ptr %t1264, i64 %t1243
  call void @olang_textcopy(ptr %t1265, ptr %t1246, i64 %t1247)
  %t1266 = getelementptr i8, ptr %t1265, i64 %t1247
  call void @olang_textcopy(ptr %t1266, ptr %t1249, i64 %t1250)
  %t1267 = getelementptr i8, ptr %t1266, i64 %t1250
  call void @olang_textcopy(ptr %t1267, ptr %t1253, i64 %t1254)
  %t1268 = getelementptr i8, ptr %t1267, i64 %t1254
  call void @olang_textcopy(ptr %t1268, ptr %t1257, i64 %t1258)
  %t1269 = insertvalue { i64, ptr } undef, i64 %t1259, 0
  %t1270 = insertvalue { i64, ptr } %t1269, ptr %t1260, 1
  %t1272 = extractvalue { i64, ptr } %t1270, 0
  %t1273 = extractvalue { i64, ptr } %t1270, 1
  %t1274 = mul i64 %t1272, 1
  %t1275 = call ptr @__olang_scope_alloc(ptr %s43, i64 %t1274)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1275, ptr %t1273, i64 %t1274, i1 false)
  %t1276 = insertvalue { i64, ptr } undef, i64 %t1272, 0
  %t1277 = insertvalue { i64, ptr } %t1276, ptr %t1275, 1
  %t1278 = load ptr, ptr %l385, !tbaa !29
  %t1280 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s43, ptr %s43, ptr %t1278, { i64, ptr } %t1277)
  store { i64, ptr } %t1280, ptr %l396
  br label %bb176
bb176:
  %t1281 = load { i64, ptr }, ptr %l396, !tbaa !27
  %t1282 = load ptr, ptr %l0, !tbaa !29
  %t1284 = load i32, ptr %l7, !tbaa !23
  %t1285 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t1290 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ewidth(ptr %v0, ptr %s43, ptr %v1, ptr %t1282, { i64, ptr } %t1281, i32 %t1284, i32 %t1285)
  store { i64, ptr } %t1290, ptr %l401
  br label %bb177
bb177:
  call void @__olang_scope_close(ptr %s43)
  call void @__olang_scope_close(ptr %s0)
  %t1291 = load { i64, ptr }, ptr %l401, !tbaa !27
  store { i64, ptr } %t1291, ptr %rv
  br label %ret
bb178:
  %t1292 = load i32, ptr %l1
  %t1294 = trunc i64 36 to i32
  %t1295 = icmp eq i32 %t1292, %t1294
  br i1 %t1295, label %bb179, label %bb180
bb179:
  br label %bb181
bb180:
  br label %bb198
bb181:
  store %olang.scope zeroinitializer, ptr %s47
  %t1297 = load ptr, ptr %l4, !tbaa !29
  %t1298 = load i32, ptr %l7, !tbaa !23
  %t1301 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t1297, i32 %t1298)
  store i64 %t1301, ptr %l406
  br label %bb182
bb182:
  %t1302 = load i64, ptr %l406, !tbaa !24
  %t1303 = icmp eq i64 %t1302, 8
  br i1 %t1303, label %bb183, label %bb184
bb183:
  %t1305 = load ptr, ptr %lp11
  %t1306 = load { i64, ptr }, ptr %t1305, !tbaa !27
  call void @__olang_scope_close(ptr %s47)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t1306, ptr %rv
  br label %ret
bb184:
  br label %bb185
bb185:
  %t1308 = load ptr, ptr %l4, !tbaa !29
  %t1309 = load i32, ptr %l7, !tbaa !23
  %t1312 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t1308, i32 %t1309)
  store i64 %t1312, ptr %l411
  br label %bb186
bb186:
  %t1313 = load i64, ptr %l411, !tbaa !24
  %t1314 = srem i64 %t1313, 16
  %t1316 = icmp ne i64 %t1314, 0
  br i1 %t1316, label %bb187, label %bb188
bb187:
  store %olang.scope zeroinitializer, ptr %s49
  %t1318 = load ptr, ptr %l4, !tbaa !29
  %t1319 = load i32, ptr %l7, !tbaa !23
  %t1322 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t1318, i32 %t1319)
  store i64 %t1322, ptr %l416
  br label %bb189
bb188:
  br label %bb195
bb189:
  %t1323 = load i64, ptr %l416, !tbaa !24
  %t1324 = add i64 %t1323, 8
  %t1325 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d262, i32 0, i32 1) }, 1
  %t1326 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d262, i32 0, i32 1) }, 0
  %t1328 = call i64 @__olang_fmt_i64(ptr null, i64 %t1324)
  %t1329 = add i64 %t1326, %t1328
  %t1330 = call ptr @__olang_scope_alloc(ptr %s49, i64 %t1329)
  call void @olang_textcopy(ptr %t1330, ptr %t1325, i64 %t1326)
  %t1331 = getelementptr i8, ptr %t1330, i64 %t1326
  %t1332 = call i64 @__olang_fmt_i64(ptr %t1331, i64 %t1324)
  %t1333 = insertvalue { i64, ptr } undef, i64 %t1329, 0
  %t1334 = insertvalue { i64, ptr } %t1333, ptr %t1330, 1
  store { i64, ptr } %t1334, ptr %l34, !tbaa !27
  %t1336 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t1337 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d263, i32 0, i32 1) }, 1
  %t1338 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d263, i32 0, i32 1) }, 0
  %t1340 = extractvalue { i64, ptr } %t1336, 1
  %t1341 = extractvalue { i64, ptr } %t1336, 0
  %t1342 = add i64 %t1338, %t1341
  %t1343 = call ptr @__olang_scope_alloc(ptr %s49, i64 %t1342)
  call void @olang_textcopy(ptr %t1343, ptr %t1337, i64 %t1338)
  %t1344 = getelementptr i8, ptr %t1343, i64 %t1338
  call void @olang_textcopy(ptr %t1344, ptr %t1340, i64 %t1341)
  %t1345 = insertvalue { i64, ptr } undef, i64 %t1342, 0
  %t1346 = insertvalue { i64, ptr } %t1345, ptr %t1343, 1
  store { i64, ptr } %t1346, ptr %l35, !tbaa !27
  %t1348 = load ptr, ptr %l0, !tbaa !29
  %t1350 = getelementptr %"compiler/emit:fnEm", ptr %t1348, i32 0, i32 0
  %t1351 = load ptr, ptr %t1350, !tbaa !29
  %t1352 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t1353 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t1354 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t1355 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t1357 = extractvalue { i64, ptr } %t1353, 1
  %t1358 = extractvalue { i64, ptr } %t1353, 0
  %t1359 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d264, i32 0, i32 1) }, 1
  %t1360 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d264, i32 0, i32 1) }, 0
  %t1361 = add i64 %t1358, %t1360
  %t1363 = extractvalue { i64, ptr } %t1354, 1
  %t1364 = extractvalue { i64, ptr } %t1354, 0
  %t1365 = add i64 %t1361, %t1364
  %t1366 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d265, i32 0, i32 1) }, 1
  %t1367 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d265, i32 0, i32 1) }, 0
  %t1368 = add i64 %t1365, %t1367
  %t1370 = extractvalue { i64, ptr } %t1355, 1
  %t1371 = extractvalue { i64, ptr } %t1355, 0
  %t1372 = add i64 %t1368, %t1371
  %t1373 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d266, i32 0, i32 1) }, 1
  %t1374 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d266, i32 0, i32 1) }, 0
  %t1375 = add i64 %t1372, %t1374
  %t1376 = call ptr @__olang_scope_alloc(ptr %s49, i64 %t1375)
  call void @olang_textcopy(ptr %t1376, ptr %t1357, i64 %t1358)
  %t1377 = getelementptr i8, ptr %t1376, i64 %t1358
  call void @olang_textcopy(ptr %t1377, ptr %t1359, i64 %t1360)
  %t1378 = getelementptr i8, ptr %t1377, i64 %t1360
  call void @olang_textcopy(ptr %t1378, ptr %t1363, i64 %t1364)
  %t1379 = getelementptr i8, ptr %t1378, i64 %t1364
  call void @olang_textcopy(ptr %t1379, ptr %t1366, i64 %t1367)
  %t1380 = getelementptr i8, ptr %t1379, i64 %t1367
  call void @olang_textcopy(ptr %t1380, ptr %t1370, i64 %t1371)
  %t1381 = getelementptr i8, ptr %t1380, i64 %t1371
  call void @olang_textcopy(ptr %t1381, ptr %t1373, i64 %t1374)
  %t1382 = insertvalue { i64, ptr } undef, i64 %t1375, 0
  %t1383 = insertvalue { i64, ptr } %t1382, ptr %t1376, 1
  %t1385 = extractvalue { i64, ptr } %t1383, 0
  %t1386 = extractvalue { i64, ptr } %t1383, 1
  %t1387 = mul i64 %t1385, 1
  %t1388 = call ptr @__olang_scope_alloc(ptr %s49, i64 %t1387)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1388, ptr %t1386, i64 %t1387, i1 false)
  %t1389 = insertvalue { i64, ptr } undef, i64 %t1385, 0
  %t1390 = insertvalue { i64, ptr } %t1389, ptr %t1388, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s49, ptr %s49, ptr %t1351, { i64, ptr } %t1352, { i64, ptr } %t1390)
  br label %bb190
bb190:
  %t1394 = load ptr, ptr %l0, !tbaa !29
  %t1395 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1396 = load ptr, ptr %lp11
  %t1397 = load { i64, ptr }, ptr %t1396, !tbaa !27
  %t1398 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t1399 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d267, i32 0, i32 1) }, 1
  %t1400 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d267, i32 0, i32 1) }, 0
  %t1402 = extractvalue { i64, ptr } %t1395, 1
  %t1403 = extractvalue { i64, ptr } %t1395, 0
  %t1404 = add i64 %t1400, %t1403
  %t1405 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d268, i32 0, i32 1) }, 1
  %t1406 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d268, i32 0, i32 1) }, 0
  %t1407 = add i64 %t1404, %t1406
  %t1409 = extractvalue { i64, ptr } %t1397, 1
  %t1410 = extractvalue { i64, ptr } %t1397, 0
  %t1411 = add i64 %t1407, %t1410
  %t1412 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d269, i32 0, i32 1) }, 1
  %t1413 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d269, i32 0, i32 1) }, 0
  %t1414 = add i64 %t1411, %t1413
  %t1416 = extractvalue { i64, ptr } %t1398, 1
  %t1417 = extractvalue { i64, ptr } %t1398, 0
  %t1418 = add i64 %t1414, %t1417
  %t1419 = call ptr @__olang_scope_alloc(ptr %s49, i64 %t1418)
  call void @olang_textcopy(ptr %t1419, ptr %t1399, i64 %t1400)
  %t1420 = getelementptr i8, ptr %t1419, i64 %t1400
  call void @olang_textcopy(ptr %t1420, ptr %t1402, i64 %t1403)
  %t1421 = getelementptr i8, ptr %t1420, i64 %t1403
  call void @olang_textcopy(ptr %t1421, ptr %t1405, i64 %t1406)
  %t1422 = getelementptr i8, ptr %t1421, i64 %t1406
  call void @olang_textcopy(ptr %t1422, ptr %t1409, i64 %t1410)
  %t1423 = getelementptr i8, ptr %t1422, i64 %t1410
  call void @olang_textcopy(ptr %t1423, ptr %t1412, i64 %t1413)
  %t1424 = getelementptr i8, ptr %t1423, i64 %t1413
  call void @olang_textcopy(ptr %t1424, ptr %t1416, i64 %t1417)
  %t1425 = insertvalue { i64, ptr } undef, i64 %t1418, 0
  %t1426 = insertvalue { i64, ptr } %t1425, ptr %t1419, 1
  %t1428 = extractvalue { i64, ptr } %t1426, 0
  %t1429 = extractvalue { i64, ptr } %t1426, 1
  %t1430 = mul i64 %t1428, 1
  %t1431 = call ptr @__olang_scope_alloc(ptr %s49, i64 %t1430)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1431, ptr %t1429, i64 %t1430, i1 false)
  %t1432 = insertvalue { i64, ptr } undef, i64 %t1428, 0
  %t1433 = insertvalue { i64, ptr } %t1432, ptr %t1431, 1
  %t1436 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s49, ptr %s49, ptr %t1394, { i64, ptr } %t1433)
  store { i64, ptr } %t1436, ptr %l435
  br label %bb191
bb191:
  %t1437 = load { i64, ptr }, ptr %l435, !tbaa !27
  %t1438 = load ptr, ptr %l0, !tbaa !29
  %t1439 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t1440 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t1441 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t1443 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d270, i32 0, i32 1) }, 1
  %t1444 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d270, i32 0, i32 1) }, 0
  %t1446 = extractvalue { i64, ptr } %t1439, 1
  %t1447 = extractvalue { i64, ptr } %t1439, 0
  %t1448 = add i64 %t1444, %t1447
  %t1449 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d271, i32 0, i32 1) }, 1
  %t1450 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d271, i32 0, i32 1) }, 0
  %t1451 = add i64 %t1448, %t1450
  %t1453 = extractvalue { i64, ptr } %t1440, 1
  %t1454 = extractvalue { i64, ptr } %t1440, 0
  %t1455 = add i64 %t1451, %t1454
  %t1456 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d272, i32 0, i32 1) }, 1
  %t1457 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d272, i32 0, i32 1) }, 0
  %t1458 = add i64 %t1455, %t1457
  %t1460 = extractvalue { i64, ptr } %t1441, 1
  %t1461 = extractvalue { i64, ptr } %t1441, 0
  %t1462 = add i64 %t1458, %t1461
  %t1463 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d273, i32 0, i32 1) }, 1
  %t1464 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d273, i32 0, i32 1) }, 0
  %t1465 = add i64 %t1462, %t1464
  %t1467 = extractvalue { i64, ptr } %t1437, 1
  %t1468 = extractvalue { i64, ptr } %t1437, 0
  %t1469 = add i64 %t1465, %t1468
  %t1470 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d274, i32 0, i32 1) }, 1
  %t1471 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d274, i32 0, i32 1) }, 0
  %t1472 = add i64 %t1469, %t1471
  %t1473 = call ptr @__olang_scope_alloc(ptr %s49, i64 %t1472)
  call void @olang_textcopy(ptr %t1473, ptr %t1443, i64 %t1444)
  %t1474 = getelementptr i8, ptr %t1473, i64 %t1444
  call void @olang_textcopy(ptr %t1474, ptr %t1446, i64 %t1447)
  %t1475 = getelementptr i8, ptr %t1474, i64 %t1447
  call void @olang_textcopy(ptr %t1475, ptr %t1449, i64 %t1450)
  %t1476 = getelementptr i8, ptr %t1475, i64 %t1450
  call void @olang_textcopy(ptr %t1476, ptr %t1453, i64 %t1454)
  %t1477 = getelementptr i8, ptr %t1476, i64 %t1454
  call void @olang_textcopy(ptr %t1477, ptr %t1456, i64 %t1457)
  %t1478 = getelementptr i8, ptr %t1477, i64 %t1457
  call void @olang_textcopy(ptr %t1478, ptr %t1460, i64 %t1461)
  %t1479 = getelementptr i8, ptr %t1478, i64 %t1461
  call void @olang_textcopy(ptr %t1479, ptr %t1463, i64 %t1464)
  %t1480 = getelementptr i8, ptr %t1479, i64 %t1464
  call void @olang_textcopy(ptr %t1480, ptr %t1467, i64 %t1468)
  %t1481 = getelementptr i8, ptr %t1480, i64 %t1468
  call void @olang_textcopy(ptr %t1481, ptr %t1470, i64 %t1471)
  %t1482 = insertvalue { i64, ptr } undef, i64 %t1472, 0
  %t1483 = insertvalue { i64, ptr } %t1482, ptr %t1473, 1
  %t1485 = extractvalue { i64, ptr } %t1483, 0
  %t1486 = extractvalue { i64, ptr } %t1483, 1
  %t1487 = mul i64 %t1485, 1
  %t1488 = call ptr @__olang_scope_alloc(ptr %s49, i64 %t1487)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1488, ptr %t1486, i64 %t1487, i1 false)
  %t1489 = insertvalue { i64, ptr } undef, i64 %t1485, 0
  %t1490 = insertvalue { i64, ptr } %t1489, ptr %t1488, 1
  %t1493 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s49, ptr %s49, ptr %t1438, { i64, ptr } %t1490)
  store { i64, ptr } %t1493, ptr %l443
  br label %bb192
bb192:
  %t1494 = load { i64, ptr }, ptr %l443, !tbaa !27
  %t1495 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1495, ptr %l444, !tbaa !29
  %t1496 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t1496, ptr %l445, !tbaa !27
  %t1497 = load ptr, ptr %l0, !tbaa !29
  %t1498 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t1500 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d275, i32 0, i32 1) }, 1
  %t1501 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d275, i32 0, i32 1) }, 0
  %t1503 = extractvalue { i64, ptr } %t1498, 1
  %t1504 = extractvalue { i64, ptr } %t1498, 0
  %t1505 = add i64 %t1501, %t1504
  %t1506 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d276, i32 0, i32 1) }, 1
  %t1507 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d276, i32 0, i32 1) }, 0
  %t1508 = add i64 %t1505, %t1507
  %t1510 = extractvalue { i64, ptr } %t1494, 1
  %t1511 = extractvalue { i64, ptr } %t1494, 0
  %t1512 = add i64 %t1508, %t1511
  %t1513 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d277, i32 0, i32 1) }, 1
  %t1514 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d277, i32 0, i32 1) }, 0
  %t1515 = add i64 %t1512, %t1514
  %t1516 = call ptr @__olang_scope_alloc(ptr %s49, i64 %t1515)
  call void @olang_textcopy(ptr %t1516, ptr %t1500, i64 %t1501)
  %t1517 = getelementptr i8, ptr %t1516, i64 %t1501
  call void @olang_textcopy(ptr %t1517, ptr %t1503, i64 %t1504)
  %t1518 = getelementptr i8, ptr %t1517, i64 %t1504
  call void @olang_textcopy(ptr %t1518, ptr %t1506, i64 %t1507)
  %t1519 = getelementptr i8, ptr %t1518, i64 %t1507
  call void @olang_textcopy(ptr %t1519, ptr %t1510, i64 %t1511)
  %t1520 = getelementptr i8, ptr %t1519, i64 %t1511
  call void @olang_textcopy(ptr %t1520, ptr %t1513, i64 %t1514)
  %t1521 = insertvalue { i64, ptr } undef, i64 %t1515, 0
  %t1522 = insertvalue { i64, ptr } %t1521, ptr %t1516, 1
  %t1524 = extractvalue { i64, ptr } %t1522, 0
  %t1525 = extractvalue { i64, ptr } %t1522, 1
  %t1526 = mul i64 %t1524, 1
  %t1527 = call ptr @__olang_scope_alloc(ptr %s49, i64 %t1526)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1527, ptr %t1525, i64 %t1526, i1 false)
  %t1528 = insertvalue { i64, ptr } undef, i64 %t1524, 0
  %t1529 = insertvalue { i64, ptr } %t1528, ptr %t1527, 1
  %t1532 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s49, ptr %s49, ptr %t1497, { i64, ptr } %t1529)
  store { i64, ptr } %t1532, ptr %l451
  br label %bb193
bb193:
  %t1533 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1534 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d278, i32 0, i32 1) }, 1
  %t1535 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d278, i32 0, i32 1) }, 0
  %t1536 = load { i64, ptr }, ptr %l445, !tbaa !27
  %t1537 = extractvalue { i64, ptr } %t1536, 1
  %t1538 = extractvalue { i64, ptr } %t1536, 0
  %t1539 = add i64 %t1535, %t1538
  %t1540 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d279, i32 0, i32 1) }, 1
  %t1541 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d279, i32 0, i32 1) }, 0
  %t1542 = add i64 %t1539, %t1541
  %t1543 = load { i64, ptr }, ptr %l451, !tbaa !27
  %t1544 = extractvalue { i64, ptr } %t1543, 1
  %t1545 = extractvalue { i64, ptr } %t1543, 0
  %t1546 = add i64 %t1542, %t1545
  %t1547 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d280, i32 0, i32 1) }, 1
  %t1548 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d280, i32 0, i32 1) }, 0
  %t1549 = add i64 %t1546, %t1548
  %t1551 = extractvalue { i64, ptr } %t1533, 1
  %t1552 = extractvalue { i64, ptr } %t1533, 0
  %t1553 = add i64 %t1549, %t1552
  %t1554 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1553)
  call void @olang_textcopy(ptr %t1554, ptr %t1534, i64 %t1535)
  %t1555 = getelementptr i8, ptr %t1554, i64 %t1535
  call void @olang_textcopy(ptr %t1555, ptr %t1537, i64 %t1538)
  %t1556 = getelementptr i8, ptr %t1555, i64 %t1538
  call void @olang_textcopy(ptr %t1556, ptr %t1540, i64 %t1541)
  %t1557 = getelementptr i8, ptr %t1556, i64 %t1541
  call void @olang_textcopy(ptr %t1557, ptr %t1544, i64 %t1545)
  %t1558 = getelementptr i8, ptr %t1557, i64 %t1545
  call void @olang_textcopy(ptr %t1558, ptr %t1547, i64 %t1548)
  %t1559 = getelementptr i8, ptr %t1558, i64 %t1548
  call void @olang_textcopy(ptr %t1559, ptr %t1551, i64 %t1552)
  %t1560 = insertvalue { i64, ptr } undef, i64 %t1553, 0
  %t1561 = insertvalue { i64, ptr } %t1560, ptr %t1554, 1
  %t1563 = extractvalue { i64, ptr } %t1561, 0
  %t1564 = extractvalue { i64, ptr } %t1561, 1
  %t1565 = mul i64 %t1563, 1
  %t1566 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1565)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1566, ptr %t1564, i64 %t1565, i1 false)
  %t1567 = insertvalue { i64, ptr } undef, i64 %t1563, 0
  %t1568 = insertvalue { i64, ptr } %t1567, ptr %t1566, 1
  %t1569 = load ptr, ptr %l444, !tbaa !29
  %t1571 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t1569, { i64, ptr } %t1568)
  store { i64, ptr } %t1571, ptr %l455
  br label %bb194
bb194:
  call void @__olang_scope_close(ptr %s49)
  call void @__olang_scope_close(ptr %s47)
  call void @__olang_scope_close(ptr %s0)
  %t1572 = load { i64, ptr }, ptr %l455, !tbaa !27
  store { i64, ptr } %t1572, ptr %rv
  br label %ret
bb195:
  %t1573 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1574 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d281, i32 0, i32 1) }, 1
  %t1575 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d281, i32 0, i32 1) }, 0
  %t1577 = extractvalue { i64, ptr } %t1573, 1
  %t1578 = extractvalue { i64, ptr } %t1573, 0
  %t1579 = add i64 %t1575, %t1578
  %t1580 = call ptr @__olang_scope_alloc(ptr %s47, i64 %t1579)
  call void @olang_textcopy(ptr %t1580, ptr %t1574, i64 %t1575)
  %t1581 = getelementptr i8, ptr %t1580, i64 %t1575
  call void @olang_textcopy(ptr %t1581, ptr %t1577, i64 %t1578)
  %t1582 = insertvalue { i64, ptr } undef, i64 %t1579, 0
  %t1583 = insertvalue { i64, ptr } %t1582, ptr %t1580, 1
  store { i64, ptr } %t1583, ptr %l38, !tbaa !27
  %t1585 = load ptr, ptr %l0, !tbaa !29
  %t1587 = getelementptr %"compiler/emit:fnEm", ptr %t1585, i32 0, i32 0
  %t1588 = load ptr, ptr %t1587, !tbaa !29
  %t1589 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t1590 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1591 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t1592 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1594 = extractvalue { i64, ptr } %t1590, 1
  %t1595 = extractvalue { i64, ptr } %t1590, 0
  %t1596 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d282, i32 0, i32 1) }, 1
  %t1597 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d282, i32 0, i32 1) }, 0
  %t1598 = add i64 %t1595, %t1597
  %t1600 = extractvalue { i64, ptr } %t1591, 1
  %t1601 = extractvalue { i64, ptr } %t1591, 0
  %t1602 = add i64 %t1598, %t1601
  %t1603 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d283, i32 0, i32 1) }, 1
  %t1604 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d283, i32 0, i32 1) }, 0
  %t1605 = add i64 %t1602, %t1604
  %t1607 = extractvalue { i64, ptr } %t1592, 1
  %t1608 = extractvalue { i64, ptr } %t1592, 0
  %t1609 = add i64 %t1605, %t1608
  %t1610 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d284, i32 0, i32 1) }, 1
  %t1611 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d284, i32 0, i32 1) }, 0
  %t1612 = add i64 %t1609, %t1611
  %t1613 = call ptr @__olang_scope_alloc(ptr %s47, i64 %t1612)
  call void @olang_textcopy(ptr %t1613, ptr %t1594, i64 %t1595)
  %t1614 = getelementptr i8, ptr %t1613, i64 %t1595
  call void @olang_textcopy(ptr %t1614, ptr %t1596, i64 %t1597)
  %t1615 = getelementptr i8, ptr %t1614, i64 %t1597
  call void @olang_textcopy(ptr %t1615, ptr %t1600, i64 %t1601)
  %t1616 = getelementptr i8, ptr %t1615, i64 %t1601
  call void @olang_textcopy(ptr %t1616, ptr %t1603, i64 %t1604)
  %t1617 = getelementptr i8, ptr %t1616, i64 %t1604
  call void @olang_textcopy(ptr %t1617, ptr %t1607, i64 %t1608)
  %t1618 = getelementptr i8, ptr %t1617, i64 %t1608
  call void @olang_textcopy(ptr %t1618, ptr %t1610, i64 %t1611)
  %t1619 = insertvalue { i64, ptr } undef, i64 %t1612, 0
  %t1620 = insertvalue { i64, ptr } %t1619, ptr %t1613, 1
  %t1622 = extractvalue { i64, ptr } %t1620, 0
  %t1623 = extractvalue { i64, ptr } %t1620, 1
  %t1624 = mul i64 %t1622, 1
  %t1625 = call ptr @__olang_scope_alloc(ptr %s47, i64 %t1624)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1625, ptr %t1623, i64 %t1624, i1 false)
  %t1626 = insertvalue { i64, ptr } undef, i64 %t1622, 0
  %t1627 = insertvalue { i64, ptr } %t1626, ptr %t1625, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s47, ptr %s47, ptr %t1588, { i64, ptr } %t1589, { i64, ptr } %t1627)
  br label %bb196
bb196:
  %t1631 = load ptr, ptr %l0, !tbaa !29
  %t1632 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1633 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t1634 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1635 = load ptr, ptr %lp11
  %t1636 = load { i64, ptr }, ptr %t1635, !tbaa !27
  %t1637 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d285, i32 0, i32 1) }, 1
  %t1638 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d285, i32 0, i32 1) }, 0
  %t1640 = extractvalue { i64, ptr } %t1632, 1
  %t1641 = extractvalue { i64, ptr } %t1632, 0
  %t1642 = add i64 %t1638, %t1641
  %t1643 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d286, i32 0, i32 1) }, 1
  %t1644 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d286, i32 0, i32 1) }, 0
  %t1645 = add i64 %t1642, %t1644
  %t1647 = extractvalue { i64, ptr } %t1633, 1
  %t1648 = extractvalue { i64, ptr } %t1633, 0
  %t1649 = add i64 %t1645, %t1648
  %t1650 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d287, i32 0, i32 1) }, 1
  %t1651 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d287, i32 0, i32 1) }, 0
  %t1652 = add i64 %t1649, %t1651
  %t1654 = extractvalue { i64, ptr } %t1634, 1
  %t1655 = extractvalue { i64, ptr } %t1634, 0
  %t1656 = add i64 %t1652, %t1655
  %t1657 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d288, i32 0, i32 1) }, 1
  %t1658 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d288, i32 0, i32 1) }, 0
  %t1659 = add i64 %t1656, %t1658
  %t1661 = extractvalue { i64, ptr } %t1636, 1
  %t1662 = extractvalue { i64, ptr } %t1636, 0
  %t1663 = add i64 %t1659, %t1662
  %t1664 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d289, i32 0, i32 1) }, 1
  %t1665 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d289, i32 0, i32 1) }, 0
  %t1666 = add i64 %t1663, %t1665
  %t1667 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1666)
  call void @olang_textcopy(ptr %t1667, ptr %t1637, i64 %t1638)
  %t1668 = getelementptr i8, ptr %t1667, i64 %t1638
  call void @olang_textcopy(ptr %t1668, ptr %t1640, i64 %t1641)
  %t1669 = getelementptr i8, ptr %t1668, i64 %t1641
  call void @olang_textcopy(ptr %t1669, ptr %t1643, i64 %t1644)
  %t1670 = getelementptr i8, ptr %t1669, i64 %t1644
  call void @olang_textcopy(ptr %t1670, ptr %t1647, i64 %t1648)
  %t1671 = getelementptr i8, ptr %t1670, i64 %t1648
  call void @olang_textcopy(ptr %t1671, ptr %t1650, i64 %t1651)
  %t1672 = getelementptr i8, ptr %t1671, i64 %t1651
  call void @olang_textcopy(ptr %t1672, ptr %t1654, i64 %t1655)
  %t1673 = getelementptr i8, ptr %t1672, i64 %t1655
  call void @olang_textcopy(ptr %t1673, ptr %t1657, i64 %t1658)
  %t1674 = getelementptr i8, ptr %t1673, i64 %t1658
  call void @olang_textcopy(ptr %t1674, ptr %t1661, i64 %t1662)
  %t1675 = getelementptr i8, ptr %t1674, i64 %t1662
  call void @olang_textcopy(ptr %t1675, ptr %t1664, i64 %t1665)
  %t1676 = insertvalue { i64, ptr } undef, i64 %t1666, 0
  %t1677 = insertvalue { i64, ptr } %t1676, ptr %t1667, 1
  %t1679 = extractvalue { i64, ptr } %t1677, 0
  %t1680 = extractvalue { i64, ptr } %t1677, 1
  %t1681 = mul i64 %t1679, 1
  %t1682 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1681)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1682, ptr %t1680, i64 %t1681, i1 false)
  %t1683 = insertvalue { i64, ptr } undef, i64 %t1679, 0
  %t1684 = insertvalue { i64, ptr } %t1683, ptr %t1682, 1
  %t1687 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t1631, { i64, ptr } %t1684)
  store { i64, ptr } %t1687, ptr %l473
  br label %bb197
bb197:
  call void @__olang_scope_close(ptr %s47)
  call void @__olang_scope_close(ptr %s0)
  %t1688 = load { i64, ptr }, ptr %l473, !tbaa !27
  store { i64, ptr } %t1688, ptr %rv
  br label %ret
bb198:
  %t1689 = load i32, ptr %l1
  %t1691 = trunc i64 34 to i32
  %t1692 = icmp eq i32 %t1689, %t1691
  br i1 %t1692, label %bb199, label %bb200
bb199:
  br label %bb203
bb200:
  %t1694 = load i32, ptr %l1
  %t1696 = trunc i64 35 to i32
  %t1697 = icmp eq i32 %t1694, %t1696
  br i1 %t1697, label %bb201, label %bb202
bb201:
  br label %bb203
bb202:
  br label %bb226
bb203:
  store %olang.scope zeroinitializer, ptr %s60
  %t1699 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1699, ptr %l478, !tbaa !29
  %t1700 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1700, ptr %l479, !tbaa !29
  %t1701 = load ptr, ptr %l0, !tbaa !29
  %t1702 = load %"compiler/mir:Range", ptr %l3
  %t1705 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t1701, %"compiler/mir:Range" %t1702, i64 1)
  store { i64, [4 x i64] } %t1705, ptr %l482
  br label %bb204
bb204:
  %t1706 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t1707 = load ptr, ptr %l479, !tbaa !29
  %t1708 = load { i64, [4 x i64] }, ptr %l482
  %t1710 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s60, ptr %t1707, { i64, [4 x i64] } %t1708, i32 %t1706)
  store { i64, ptr } %t1710, ptr %l484
  br label %bb205
bb205:
  %t1711 = load { i64, ptr }, ptr %l484, !tbaa !27
  %t1712 = extractvalue { i64, ptr } %t1711, 0
  %t1713 = extractvalue { i64, ptr } %t1711, 1
  %t1714 = mul i64 %t1712, 1
  %t1715 = call ptr @__olang_scope_alloc(ptr %s60, i64 %t1714)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1715, ptr %t1713, i64 %t1714, i1 false)
  %t1716 = insertvalue { i64, ptr } undef, i64 %t1712, 0
  %t1717 = insertvalue { i64, ptr } %t1716, ptr %t1715, 1
  %t1718 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t1719 = load i32, ptr %l7, !tbaa !23
  %t1720 = load ptr, ptr %l478, !tbaa !29
  %t1724 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ewidth(ptr %v0, ptr %s60, ptr %s60, ptr %t1720, { i64, ptr } %t1717, i32 %t1718, i32 %t1719)
  store { i64, ptr } %t1724, ptr %l488
  br label %bb206
bb206:
  %t1725 = load { i64, ptr }, ptr %l488, !tbaa !27
  store { i64, ptr } %t1725, ptr %l39, !tbaa !27
  %t1726 = load ptr, ptr %l4, !tbaa !29
  %t1727 = load i32, ptr %l7, !tbaa !23
  %t1730 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t1726, i32 %t1727)
  store i64 %t1730, ptr %l491
  br label %bb207
bb207:
  %t1731 = load i64, ptr %l491, !tbaa !24
  store i64 %t1731, ptr %l40, !tbaa !24
  %t1732 = load i64, ptr %l40, !tbaa !24
  %t1733 = load i64, ptr %l40, !tbaa !24
  %t1735 = sub i64 %t1733, 1
  %t1738 = and i64 %t1732, %t1735
  %t1740 = icmp ne i64 %t1738, 0
  br i1 %t1740, label %bb208, label %bb209
bb208:
  store %olang.scope zeroinitializer, ptr %s61
  %t1742 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1742, ptr %l497, !tbaa !29
  %t1743 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1743, ptr %l498, !tbaa !29
  %t1744 = load ptr, ptr %l0, !tbaa !29
  %t1745 = load %"compiler/mir:Range", ptr %l3
  %t1748 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t1744, %"compiler/mir:Range" %t1745, i64 1)
  store { i64, [4 x i64] } %t1748, ptr %l501
  br label %bb210
bb209:
  br label %bb220
bb210:
  %t1749 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t1750 = load ptr, ptr %l498, !tbaa !29
  %t1751 = load { i64, [4 x i64] }, ptr %l501
  %t1753 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s61, ptr %t1750, { i64, [4 x i64] } %t1751, i32 %t1749)
  store { i64, ptr } %t1753, ptr %l503
  br label %bb211
bb211:
  %t1754 = load i64, ptr %l40, !tbaa !24
  %t1755 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d290, i32 0, i32 1) }, 1
  %t1756 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d290, i32 0, i32 1) }, 0
  %t1757 = load { i64, ptr }, ptr %l503, !tbaa !27
  %t1758 = extractvalue { i64, ptr } %t1757, 1
  %t1759 = extractvalue { i64, ptr } %t1757, 0
  %t1760 = add i64 %t1756, %t1759
  %t1761 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d291, i32 0, i32 1) }, 1
  %t1762 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d291, i32 0, i32 1) }, 0
  %t1763 = add i64 %t1760, %t1762
  %t1765 = call i64 @__olang_fmt_i64(ptr null, i64 %t1754)
  %t1766 = add i64 %t1763, %t1765
  %t1767 = call ptr @__olang_scope_alloc(ptr %s61, i64 %t1766)
  call void @olang_textcopy(ptr %t1767, ptr %t1755, i64 %t1756)
  %t1768 = getelementptr i8, ptr %t1767, i64 %t1756
  call void @olang_textcopy(ptr %t1768, ptr %t1758, i64 %t1759)
  %t1769 = getelementptr i8, ptr %t1768, i64 %t1759
  call void @olang_textcopy(ptr %t1769, ptr %t1761, i64 %t1762)
  %t1770 = getelementptr i8, ptr %t1769, i64 %t1762
  %t1771 = call i64 @__olang_fmt_i64(ptr %t1770, i64 %t1754)
  %t1772 = insertvalue { i64, ptr } undef, i64 %t1766, 0
  %t1773 = insertvalue { i64, ptr } %t1772, ptr %t1767, 1
  %t1775 = extractvalue { i64, ptr } %t1773, 0
  %t1776 = extractvalue { i64, ptr } %t1773, 1
  %t1777 = mul i64 %t1775, 1
  %t1778 = call ptr @__olang_scope_alloc(ptr %s61, i64 %t1777)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1778, ptr %t1776, i64 %t1777, i1 false)
  %t1779 = insertvalue { i64, ptr } undef, i64 %t1775, 0
  %t1780 = insertvalue { i64, ptr } %t1779, ptr %t1778, 1
  %t1781 = load ptr, ptr %l497, !tbaa !29
  %t1783 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s61, ptr %s61, ptr %t1781, { i64, ptr } %t1780)
  store { i64, ptr } %t1783, ptr %l507
  br label %bb212
bb212:
  %t1784 = load { i64, ptr }, ptr %l507, !tbaa !27
  store { i64, ptr } %t1784, ptr %l41, !tbaa !27
  %t1785 = load ptr, ptr %l0, !tbaa !29
  %t1786 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t1787 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d292, i32 0, i32 1) }, 1
  %t1788 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d292, i32 0, i32 1) }, 0
  %t1790 = extractvalue { i64, ptr } %t1786, 1
  %t1791 = extractvalue { i64, ptr } %t1786, 0
  %t1792 = add i64 %t1788, %t1791
  %t1793 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d293, i32 0, i32 1) }, 1
  %t1794 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d293, i32 0, i32 1) }, 0
  %t1795 = add i64 %t1792, %t1794
  %t1796 = call ptr @__olang_scope_alloc(ptr %s61, i64 %t1795)
  call void @olang_textcopy(ptr %t1796, ptr %t1787, i64 %t1788)
  %t1797 = getelementptr i8, ptr %t1796, i64 %t1788
  call void @olang_textcopy(ptr %t1797, ptr %t1790, i64 %t1791)
  %t1798 = getelementptr i8, ptr %t1797, i64 %t1791
  call void @olang_textcopy(ptr %t1798, ptr %t1793, i64 %t1794)
  %t1799 = insertvalue { i64, ptr } undef, i64 %t1795, 0
  %t1800 = insertvalue { i64, ptr } %t1799, ptr %t1796, 1
  %t1802 = extractvalue { i64, ptr } %t1800, 0
  %t1803 = extractvalue { i64, ptr } %t1800, 1
  %t1804 = mul i64 %t1802, 1
  %t1805 = call ptr @__olang_scope_alloc(ptr %s61, i64 %t1804)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1805, ptr %t1803, i64 %t1804, i1 false)
  %t1806 = insertvalue { i64, ptr } undef, i64 %t1802, 0
  %t1807 = insertvalue { i64, ptr } %t1806, ptr %t1805, 1
  %t1810 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s61, ptr %s61, ptr %t1785, { i64, ptr } %t1807)
  store { i64, ptr } %t1810, ptr %l512
  br label %bb213
bb213:
  %t1811 = load { i64, ptr }, ptr %l512, !tbaa !27
  store { i64, ptr } %t1811, ptr %l42, !tbaa !27
  %t1812 = load ptr, ptr %l0, !tbaa !29
  %t1813 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t1814 = load i64, ptr %l40, !tbaa !24
  %t1815 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d294, i32 0, i32 1) }, 1
  %t1816 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d294, i32 0, i32 1) }, 0
  %t1818 = extractvalue { i64, ptr } %t1813, 1
  %t1819 = extractvalue { i64, ptr } %t1813, 0
  %t1820 = add i64 %t1816, %t1819
  %t1821 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d295, i32 0, i32 1) }, 1
  %t1822 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d295, i32 0, i32 1) }, 0
  %t1823 = add i64 %t1820, %t1822
  %t1825 = call i64 @__olang_fmt_i64(ptr null, i64 %t1814)
  %t1826 = add i64 %t1823, %t1825
  %t1827 = call ptr @__olang_scope_alloc(ptr %s61, i64 %t1826)
  call void @olang_textcopy(ptr %t1827, ptr %t1815, i64 %t1816)
  %t1828 = getelementptr i8, ptr %t1827, i64 %t1816
  call void @olang_textcopy(ptr %t1828, ptr %t1818, i64 %t1819)
  %t1829 = getelementptr i8, ptr %t1828, i64 %t1819
  call void @olang_textcopy(ptr %t1829, ptr %t1821, i64 %t1822)
  %t1830 = getelementptr i8, ptr %t1829, i64 %t1822
  %t1831 = call i64 @__olang_fmt_i64(ptr %t1830, i64 %t1814)
  %t1832 = insertvalue { i64, ptr } undef, i64 %t1826, 0
  %t1833 = insertvalue { i64, ptr } %t1832, ptr %t1827, 1
  %t1835 = extractvalue { i64, ptr } %t1833, 0
  %t1836 = extractvalue { i64, ptr } %t1833, 1
  %t1837 = mul i64 %t1835, 1
  %t1838 = call ptr @__olang_scope_alloc(ptr %s61, i64 %t1837)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1838, ptr %t1836, i64 %t1837, i1 false)
  %t1839 = insertvalue { i64, ptr } undef, i64 %t1835, 0
  %t1840 = insertvalue { i64, ptr } %t1839, ptr %t1838, 1
  %t1843 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s61, ptr %s61, ptr %t1812, { i64, ptr } %t1840)
  store { i64, ptr } %t1843, ptr %l518
  br label %bb214
bb214:
  %t1844 = load { i64, ptr }, ptr %l518, !tbaa !27
  %t1845 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1845, ptr %l519, !tbaa !29
  %t1846 = load ptr, ptr %l0, !tbaa !29
  %t1847 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t1849 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t1850 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d296, i32 0, i32 1) }, 1
  %t1851 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d296, i32 0, i32 1) }, 0
  %t1853 = extractvalue { i64, ptr } %t1847, 1
  %t1854 = extractvalue { i64, ptr } %t1847, 0
  %t1855 = add i64 %t1851, %t1854
  %t1856 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d297, i32 0, i32 1) }, 1
  %t1857 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d297, i32 0, i32 1) }, 0
  %t1858 = add i64 %t1855, %t1857
  %t1860 = extractvalue { i64, ptr } %t1844, 1
  %t1861 = extractvalue { i64, ptr } %t1844, 0
  %t1862 = add i64 %t1858, %t1861
  %t1863 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d297, i32 0, i32 1) }, 1
  %t1864 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d297, i32 0, i32 1) }, 0
  %t1865 = add i64 %t1862, %t1864
  %t1867 = extractvalue { i64, ptr } %t1849, 1
  %t1868 = extractvalue { i64, ptr } %t1849, 0
  %t1869 = add i64 %t1865, %t1868
  %t1870 = call ptr @__olang_scope_alloc(ptr %s60, i64 %t1869)
  call void @olang_textcopy(ptr %t1870, ptr %t1850, i64 %t1851)
  %t1871 = getelementptr i8, ptr %t1870, i64 %t1851
  call void @olang_textcopy(ptr %t1871, ptr %t1853, i64 %t1854)
  %t1872 = getelementptr i8, ptr %t1871, i64 %t1854
  call void @olang_textcopy(ptr %t1872, ptr %t1856, i64 %t1857)
  %t1873 = getelementptr i8, ptr %t1872, i64 %t1857
  call void @olang_textcopy(ptr %t1873, ptr %t1860, i64 %t1861)
  %t1874 = getelementptr i8, ptr %t1873, i64 %t1861
  call void @olang_textcopy(ptr %t1874, ptr %t1863, i64 %t1864)
  %t1875 = getelementptr i8, ptr %t1874, i64 %t1864
  call void @olang_textcopy(ptr %t1875, ptr %t1867, i64 %t1868)
  %t1876 = insertvalue { i64, ptr } undef, i64 %t1869, 0
  %t1877 = insertvalue { i64, ptr } %t1876, ptr %t1870, 1
  %t1879 = extractvalue { i64, ptr } %t1877, 0
  %t1880 = extractvalue { i64, ptr } %t1877, 1
  %t1881 = mul i64 %t1879, 1
  %t1882 = call ptr @__olang_scope_alloc(ptr %s60, i64 %t1881)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1882, ptr %t1880, i64 %t1881, i1 false)
  %t1883 = insertvalue { i64, ptr } undef, i64 %t1879, 0
  %t1884 = insertvalue { i64, ptr } %t1883, ptr %t1882, 1
  %t1887 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s60, ptr %s60, ptr %t1846, { i64, ptr } %t1884)
  store { i64, ptr } %t1887, ptr %l526
  br label %bb215
bb215:
  %t1888 = load { i64, ptr }, ptr %l526, !tbaa !27
  %t1889 = extractvalue { i64, ptr } %t1888, 0
  %t1890 = extractvalue { i64, ptr } %t1888, 1
  %t1891 = mul i64 %t1889, 1
  %t1892 = call ptr @__olang_scope_alloc(ptr %s60, i64 %t1891)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1892, ptr %t1890, i64 %t1891, i1 false)
  %t1893 = insertvalue { i64, ptr } undef, i64 %t1889, 0
  %t1894 = insertvalue { i64, ptr } %t1893, ptr %t1892, 1
  %t1895 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t1896 = load i32, ptr %l7, !tbaa !23
  %t1897 = load ptr, ptr %l519, !tbaa !29
  %t1901 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ewidth(ptr %v0, ptr %s60, ptr %s60, ptr %t1897, { i64, ptr } %t1894, i32 %t1895, i32 %t1896)
  store { i64, ptr } %t1901, ptr %l530
  br label %bb216
bb216:
  %t1902 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t1903 = extractvalue { i64, ptr } %t1902, 0
  %t1904 = load { i64, ptr }, ptr %l530, !tbaa !27
  %t1905 = extractvalue { i64, ptr } %t1904, 0
  store i64 %t1905, ptr %l532, !tbaa !24
  %t1907 = load i64, ptr %l532, !tbaa !24
  %t1908 = icmp eq i64 %t1903, %t1907
  br i1 %t1908, label %bb217, label %bb218
bb217:
  %t1910 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t1911 = load ptr, ptr %t1910, !tbaa !27
  %t1912 = getelementptr { i64, ptr }, ptr %l530, i32 0, i32 1
  %t1913 = load ptr, ptr %t1912, !tbaa !27
  %t1914 = load i64, ptr %l532, !tbaa !24
  %t1915 = mul i64 %t1914, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1911, ptr %t1913, i64 %t1915, i1 false)
  br label %bb219
bb218:
  %t1916 = load { i64, ptr }, ptr %l530, !tbaa !27
  store { i64, ptr } %t1916, ptr %l39, !tbaa !27
  br label %bb219
bb219:
  call void @__olang_scope_close(ptr %s61)
  br label %bb220
bb220:
  %t1917 = load i32, ptr %l1
  %t1919 = trunc i64 34 to i32
  %t1920 = icmp eq i32 %t1917, %t1919
  br i1 %t1920, label %bb221, label %bb222
bb221:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d298, i32 0, i32 1) }, ptr %l536, !tbaa !27
  br label %bb223
bb222:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d299, i32 0, i32 1) }, ptr %l536, !tbaa !27
  br label %bb223
bb223:
  %t1922 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1923 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d300, i32 0, i32 1) }, 1
  %t1924 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d300, i32 0, i32 1) }, 0
  %t1925 = load { i64, ptr }, ptr %l536, !tbaa !27
  %t1926 = extractvalue { i64, ptr } %t1925, 1
  %t1927 = extractvalue { i64, ptr } %t1925, 0
  %t1928 = add i64 %t1924, %t1927
  %t1929 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d301, i32 0, i32 1) }, 1
  %t1930 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d301, i32 0, i32 1) }, 0
  %t1931 = add i64 %t1928, %t1930
  %t1933 = extractvalue { i64, ptr } %t1922, 1
  %t1934 = extractvalue { i64, ptr } %t1922, 0
  %t1935 = add i64 %t1931, %t1934
  %t1936 = call ptr @__olang_scope_alloc(ptr %s60, i64 %t1935)
  call void @olang_textcopy(ptr %t1936, ptr %t1923, i64 %t1924)
  %t1937 = getelementptr i8, ptr %t1936, i64 %t1924
  call void @olang_textcopy(ptr %t1937, ptr %t1926, i64 %t1927)
  %t1938 = getelementptr i8, ptr %t1937, i64 %t1927
  call void @olang_textcopy(ptr %t1938, ptr %t1929, i64 %t1930)
  %t1939 = getelementptr i8, ptr %t1938, i64 %t1930
  call void @olang_textcopy(ptr %t1939, ptr %t1933, i64 %t1934)
  %t1940 = insertvalue { i64, ptr } undef, i64 %t1935, 0
  %t1941 = insertvalue { i64, ptr } %t1940, ptr %t1936, 1
  store { i64, ptr } %t1941, ptr %l44, !tbaa !27
  %t1943 = load ptr, ptr %l0, !tbaa !29
  %t1945 = getelementptr %"compiler/emit:fnEm", ptr %t1943, i32 0, i32 0
  %t1946 = load ptr, ptr %t1945, !tbaa !29
  %t1947 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t1948 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1949 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t1950 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1951 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1952 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1954 = extractvalue { i64, ptr } %t1948, 1
  %t1955 = extractvalue { i64, ptr } %t1948, 0
  %t1956 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d302, i32 0, i32 1) }, 1
  %t1957 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d302, i32 0, i32 1) }, 0
  %t1958 = add i64 %t1955, %t1957
  %t1960 = extractvalue { i64, ptr } %t1949, 1
  %t1961 = extractvalue { i64, ptr } %t1949, 0
  %t1962 = add i64 %t1958, %t1961
  %t1963 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d303, i32 0, i32 1) }, 1
  %t1964 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d303, i32 0, i32 1) }, 0
  %t1965 = add i64 %t1962, %t1964
  %t1967 = extractvalue { i64, ptr } %t1950, 1
  %t1968 = extractvalue { i64, ptr } %t1950, 0
  %t1969 = add i64 %t1965, %t1968
  %t1970 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d304, i32 0, i32 1) }, 1
  %t1971 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d304, i32 0, i32 1) }, 0
  %t1972 = add i64 %t1969, %t1971
  %t1974 = extractvalue { i64, ptr } %t1951, 1
  %t1975 = extractvalue { i64, ptr } %t1951, 0
  %t1976 = add i64 %t1972, %t1975
  %t1977 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d304, i32 0, i32 1) }, 1
  %t1978 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d304, i32 0, i32 1) }, 0
  %t1979 = add i64 %t1976, %t1978
  %t1981 = extractvalue { i64, ptr } %t1952, 1
  %t1982 = extractvalue { i64, ptr } %t1952, 0
  %t1983 = add i64 %t1979, %t1982
  %t1984 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d305, i32 0, i32 1) }, 1
  %t1985 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d305, i32 0, i32 1) }, 0
  %t1986 = add i64 %t1983, %t1985
  %t1987 = call ptr @__olang_scope_alloc(ptr %s60, i64 %t1986)
  call void @olang_textcopy(ptr %t1987, ptr %t1954, i64 %t1955)
  %t1988 = getelementptr i8, ptr %t1987, i64 %t1955
  call void @olang_textcopy(ptr %t1988, ptr %t1956, i64 %t1957)
  %t1989 = getelementptr i8, ptr %t1988, i64 %t1957
  call void @olang_textcopy(ptr %t1989, ptr %t1960, i64 %t1961)
  %t1990 = getelementptr i8, ptr %t1989, i64 %t1961
  call void @olang_textcopy(ptr %t1990, ptr %t1963, i64 %t1964)
  %t1991 = getelementptr i8, ptr %t1990, i64 %t1964
  call void @olang_textcopy(ptr %t1991, ptr %t1967, i64 %t1968)
  %t1992 = getelementptr i8, ptr %t1991, i64 %t1968
  call void @olang_textcopy(ptr %t1992, ptr %t1970, i64 %t1971)
  %t1993 = getelementptr i8, ptr %t1992, i64 %t1971
  call void @olang_textcopy(ptr %t1993, ptr %t1974, i64 %t1975)
  %t1994 = getelementptr i8, ptr %t1993, i64 %t1975
  call void @olang_textcopy(ptr %t1994, ptr %t1977, i64 %t1978)
  %t1995 = getelementptr i8, ptr %t1994, i64 %t1978
  call void @olang_textcopy(ptr %t1995, ptr %t1981, i64 %t1982)
  %t1996 = getelementptr i8, ptr %t1995, i64 %t1982
  call void @olang_textcopy(ptr %t1996, ptr %t1984, i64 %t1985)
  %t1997 = insertvalue { i64, ptr } undef, i64 %t1986, 0
  %t1998 = insertvalue { i64, ptr } %t1997, ptr %t1987, 1
  %t2000 = extractvalue { i64, ptr } %t1998, 0
  %t2001 = extractvalue { i64, ptr } %t1998, 1
  %t2002 = mul i64 %t2000, 1
  %t2003 = call ptr @__olang_scope_alloc(ptr %s60, i64 %t2002)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2003, ptr %t2001, i64 %t2002, i1 false)
  %t2004 = insertvalue { i64, ptr } undef, i64 %t2000, 0
  %t2005 = insertvalue { i64, ptr } %t2004, ptr %t2003, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s60, ptr %s60, ptr %t1946, { i64, ptr } %t1947, { i64, ptr } %t2005)
  br label %bb224
bb224:
  %t2009 = load ptr, ptr %l0, !tbaa !29
  %t2010 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t2011 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t2012 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t2013 = load ptr, ptr %lp11
  %t2014 = load { i64, ptr }, ptr %t2013, !tbaa !27
  %t2015 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t2016 = load ptr, ptr %lp11
  %t2017 = load { i64, ptr }, ptr %t2016, !tbaa !27
  %t2018 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t2019 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t2020 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d306, i32 0, i32 1) }, 1
  %t2021 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d306, i32 0, i32 1) }, 0
  %t2023 = extractvalue { i64, ptr } %t2010, 1
  %t2024 = extractvalue { i64, ptr } %t2010, 0
  %t2025 = add i64 %t2021, %t2024
  %t2026 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d307, i32 0, i32 1) }, 1
  %t2027 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d307, i32 0, i32 1) }, 0
  %t2028 = add i64 %t2025, %t2027
  %t2030 = extractvalue { i64, ptr } %t2011, 1
  %t2031 = extractvalue { i64, ptr } %t2011, 0
  %t2032 = add i64 %t2028, %t2031
  %t2033 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d308, i32 0, i32 1) }, 1
  %t2034 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d308, i32 0, i32 1) }, 0
  %t2035 = add i64 %t2032, %t2034
  %t2037 = extractvalue { i64, ptr } %t2012, 1
  %t2038 = extractvalue { i64, ptr } %t2012, 0
  %t2039 = add i64 %t2035, %t2038
  %t2040 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d309, i32 0, i32 1) }, 1
  %t2041 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d309, i32 0, i32 1) }, 0
  %t2042 = add i64 %t2039, %t2041
  %t2044 = extractvalue { i64, ptr } %t2014, 1
  %t2045 = extractvalue { i64, ptr } %t2014, 0
  %t2046 = add i64 %t2042, %t2045
  %t2047 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d310, i32 0, i32 1) }, 1
  %t2048 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d310, i32 0, i32 1) }, 0
  %t2049 = add i64 %t2046, %t2048
  %t2051 = extractvalue { i64, ptr } %t2015, 1
  %t2052 = extractvalue { i64, ptr } %t2015, 0
  %t2053 = add i64 %t2049, %t2052
  %t2054 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d309, i32 0, i32 1) }, 1
  %t2055 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d309, i32 0, i32 1) }, 0
  %t2056 = add i64 %t2053, %t2055
  %t2058 = extractvalue { i64, ptr } %t2017, 1
  %t2059 = extractvalue { i64, ptr } %t2017, 0
  %t2060 = add i64 %t2056, %t2059
  %t2061 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d310, i32 0, i32 1) }, 1
  %t2062 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d310, i32 0, i32 1) }, 0
  %t2063 = add i64 %t2060, %t2062
  %t2065 = extractvalue { i64, ptr } %t2018, 1
  %t2066 = extractvalue { i64, ptr } %t2018, 0
  %t2067 = add i64 %t2063, %t2066
  %t2068 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d309, i32 0, i32 1) }, 1
  %t2069 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d309, i32 0, i32 1) }, 0
  %t2070 = add i64 %t2067, %t2069
  %t2072 = extractvalue { i64, ptr } %t2019, 1
  %t2073 = extractvalue { i64, ptr } %t2019, 0
  %t2074 = add i64 %t2070, %t2073
  %t2075 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d311, i32 0, i32 1) }, 1
  %t2076 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d311, i32 0, i32 1) }, 0
  %t2077 = add i64 %t2074, %t2076
  %t2078 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2077)
  call void @olang_textcopy(ptr %t2078, ptr %t2020, i64 %t2021)
  %t2079 = getelementptr i8, ptr %t2078, i64 %t2021
  call void @olang_textcopy(ptr %t2079, ptr %t2023, i64 %t2024)
  %t2080 = getelementptr i8, ptr %t2079, i64 %t2024
  call void @olang_textcopy(ptr %t2080, ptr %t2026, i64 %t2027)
  %t2081 = getelementptr i8, ptr %t2080, i64 %t2027
  call void @olang_textcopy(ptr %t2081, ptr %t2030, i64 %t2031)
  %t2082 = getelementptr i8, ptr %t2081, i64 %t2031
  call void @olang_textcopy(ptr %t2082, ptr %t2033, i64 %t2034)
  %t2083 = getelementptr i8, ptr %t2082, i64 %t2034
  call void @olang_textcopy(ptr %t2083, ptr %t2037, i64 %t2038)
  %t2084 = getelementptr i8, ptr %t2083, i64 %t2038
  call void @olang_textcopy(ptr %t2084, ptr %t2040, i64 %t2041)
  %t2085 = getelementptr i8, ptr %t2084, i64 %t2041
  call void @olang_textcopy(ptr %t2085, ptr %t2044, i64 %t2045)
  %t2086 = getelementptr i8, ptr %t2085, i64 %t2045
  call void @olang_textcopy(ptr %t2086, ptr %t2047, i64 %t2048)
  %t2087 = getelementptr i8, ptr %t2086, i64 %t2048
  call void @olang_textcopy(ptr %t2087, ptr %t2051, i64 %t2052)
  %t2088 = getelementptr i8, ptr %t2087, i64 %t2052
  call void @olang_textcopy(ptr %t2088, ptr %t2054, i64 %t2055)
  %t2089 = getelementptr i8, ptr %t2088, i64 %t2055
  call void @olang_textcopy(ptr %t2089, ptr %t2058, i64 %t2059)
  %t2090 = getelementptr i8, ptr %t2089, i64 %t2059
  call void @olang_textcopy(ptr %t2090, ptr %t2061, i64 %t2062)
  %t2091 = getelementptr i8, ptr %t2090, i64 %t2062
  call void @olang_textcopy(ptr %t2091, ptr %t2065, i64 %t2066)
  %t2092 = getelementptr i8, ptr %t2091, i64 %t2066
  call void @olang_textcopy(ptr %t2092, ptr %t2068, i64 %t2069)
  %t2093 = getelementptr i8, ptr %t2092, i64 %t2069
  call void @olang_textcopy(ptr %t2093, ptr %t2072, i64 %t2073)
  %t2094 = getelementptr i8, ptr %t2093, i64 %t2073
  call void @olang_textcopy(ptr %t2094, ptr %t2075, i64 %t2076)
  %t2095 = insertvalue { i64, ptr } undef, i64 %t2077, 0
  %t2096 = insertvalue { i64, ptr } %t2095, ptr %t2078, 1
  %t2098 = extractvalue { i64, ptr } %t2096, 0
  %t2099 = extractvalue { i64, ptr } %t2096, 1
  %t2100 = mul i64 %t2098, 1
  %t2101 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2100)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2101, ptr %t2099, i64 %t2100, i1 false)
  %t2102 = insertvalue { i64, ptr } undef, i64 %t2098, 0
  %t2103 = insertvalue { i64, ptr } %t2102, ptr %t2101, 1
  %t2106 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t2009, { i64, ptr } %t2103)
  store { i64, ptr } %t2106, ptr %l560
  br label %bb225
bb225:
  call void @__olang_scope_close(ptr %s60)
  call void @__olang_scope_close(ptr %s0)
  %t2107 = load { i64, ptr }, ptr %l560, !tbaa !27
  store { i64, ptr } %t2107, ptr %rv
  br label %ret
bb226:
  br i1 true, label %bb227, label %bb228
bb227:
  br label %bb229
bb228:
  br label %bb230
bb229:
  br label %bb231
bb230:
  call void @__olang_check_failed(ptr @olang_loc_d23ee61a0d8dfe9f_a353f177579d38fb)
  unreachable
bb231:
  %t2108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2108, ptr %l561, !tbaa !29
  %t2109 = load ptr, ptr %l0, !tbaa !29
  %t2110 = load %"compiler/mir:Range", ptr %l3
  %t2113 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t2109, %"compiler/mir:Range" %t2110, i64 1)
  store { i64, [4 x i64] } %t2113, ptr %l564
  br label %bb232
bb232:
  %t2114 = load i32, ptr %l6, !tbaa !23
  %t2115 = load ptr, ptr %l561, !tbaa !29
  %t2116 = load { i64, [4 x i64] }, ptr %l564
  %t2118 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s0, ptr %t2115, { i64, [4 x i64] } %t2116, i32 %t2114)
  store { i64, ptr } %t2118, ptr %l566
  br label %bb233
bb233:
  %t2119 = load { i64, ptr }, ptr %l566, !tbaa !27
  store { i64, ptr } %t2119, ptr %l45, !tbaa !27
  %t2120 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t2122 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t2120, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d312, i32 0, i32 1) })
  store i1 %t2122, ptr %l568
  br label %bb234
bb234:
  %t2123 = load i1, ptr %l568, !tbaa !21
  br i1 %t2123, label %bb235, label %bb236
bb235:
  store %olang.scope zeroinitializer, ptr %s70
  %t2124 = load ptr, ptr %l0, !tbaa !29
  %t2125 = load ptr, ptr %lp11
  %t2126 = load { i64, ptr }, ptr %t2125, !tbaa !27
  %t2129 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ewidenBF16(ptr %v0, ptr %v1, ptr %s70, ptr %s70, ptr %t2124, { i64, ptr } %t2126, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d313, i32 0, i32 1) })
  store { i64, ptr } %t2129, ptr %l571
  br label %bb237
bb236:
  br label %bb290
bb237:
  %t2130 = load { i64, ptr }, ptr %l571, !tbaa !27
  store { i64, ptr } %t2130, ptr %l46, !tbaa !27
  %t2131 = load ptr, ptr %l0, !tbaa !29
  %t2132 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t2135 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ewidenBF16(ptr %v0, ptr %s0, ptr %s70, ptr %s70, ptr %t2131, { i64, ptr } %t2132, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d314, i32 0, i32 1) })
  store { i64, ptr } %t2135, ptr %l574
  br label %bb238
bb238:
  %t2136 = load { i64, ptr }, ptr %l574, !tbaa !27
  store { i64, ptr } %t2136, ptr %l47, !tbaa !27
  %t2137 = load i32, ptr %l1
  %t2139 = trunc i64 3 to i32
  %t2140 = icmp eq i32 %t2137, %t2139
  br i1 %t2140, label %bb239, label %bb240
bb239:
  br label %bb241
bb240:
  br label %bb242
bb241:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d315, i32 0, i32 1) }, ptr %l575, !tbaa !27
  br label %bb263
bb242:
  %t2142 = load i32, ptr %l1
  %t2144 = trunc i64 4 to i32
  %t2145 = icmp eq i32 %t2142, %t2144
  br i1 %t2145, label %bb243, label %bb244
bb243:
  br label %bb245
bb244:
  br label %bb246
bb245:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d316, i32 0, i32 1) }, ptr %l575, !tbaa !27
  br label %bb263
bb246:
  %t2147 = load i32, ptr %l1
  %t2149 = trunc i64 5 to i32
  %t2150 = icmp eq i32 %t2147, %t2149
  br i1 %t2150, label %bb247, label %bb248
bb247:
  br label %bb249
bb248:
  br label %bb250
bb249:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d317, i32 0, i32 1) }, ptr %l575, !tbaa !27
  br label %bb263
bb250:
  %t2152 = load i32, ptr %l1
  %t2154 = trunc i64 6 to i32
  %t2155 = icmp eq i32 %t2152, %t2154
  br i1 %t2155, label %bb251, label %bb252
bb251:
  br label %bb253
bb252:
  br label %bb254
bb253:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d318, i32 0, i32 1) }, ptr %l575, !tbaa !27
  br label %bb263
bb254:
  %t2157 = load i32, ptr %l1
  %t2159 = trunc i64 7 to i32
  %t2160 = icmp eq i32 %t2157, %t2159
  br i1 %t2160, label %bb255, label %bb256
bb255:
  br label %bb257
bb256:
  br label %bb258
bb257:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d319, i32 0, i32 1) }, ptr %l575, !tbaa !27
  br label %bb263
bb258:
  br i1 true, label %bb259, label %bb260
bb259:
  br label %bb261
bb260:
  br label %bb262
bb261:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d320, i32 0, i32 1) }, ptr %l575, !tbaa !27
  br label %bb263
bb262:
  call void @__olang_check_failed(ptr @olang_loc_f37913274faf0c64_a4499fcd83081580)
  unreachable
bb263:
  %t2162 = load { i64, ptr }, ptr %l575, !tbaa !27
  store { i64, ptr } %t2162, ptr %l48, !tbaa !27
  %t2163 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t2164 = load ptr, ptr @__olang_prog_scope
  %t2166 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t2164, ptr %s70, { i64, ptr } %t2163, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d321, i32 0, i32 1) })
  store i1 %t2166, ptr %l587
  br label %bb264
bb264:
  %t2167 = load i1, ptr %l587, !tbaa !21
  %t2168 = xor i1 %t2167, true
  br i1 %t2168, label %bb265, label %bb266
bb265:
  %t2170 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2170, ptr %l589, !tbaa !29
  %t2171 = load ptr, ptr %l0, !tbaa !29
  %t2172 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t2173 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t2174 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t2176 = extractvalue { i64, ptr } %t2172, 1
  %t2177 = extractvalue { i64, ptr } %t2172, 0
  %t2178 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d322, i32 0, i32 1) }, 1
  %t2179 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d322, i32 0, i32 1) }, 0
  %t2180 = add i64 %t2177, %t2179
  %t2182 = extractvalue { i64, ptr } %t2173, 1
  %t2183 = extractvalue { i64, ptr } %t2173, 0
  %t2184 = add i64 %t2180, %t2183
  %t2185 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d323, i32 0, i32 1) }, 1
  %t2186 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d323, i32 0, i32 1) }, 0
  %t2187 = add i64 %t2184, %t2186
  %t2189 = extractvalue { i64, ptr } %t2174, 1
  %t2190 = extractvalue { i64, ptr } %t2174, 0
  %t2191 = add i64 %t2187, %t2190
  %t2192 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2191)
  call void @olang_textcopy(ptr %t2192, ptr %t2176, i64 %t2177)
  %t2193 = getelementptr i8, ptr %t2192, i64 %t2177
  call void @olang_textcopy(ptr %t2193, ptr %t2178, i64 %t2179)
  %t2194 = getelementptr i8, ptr %t2193, i64 %t2179
  call void @olang_textcopy(ptr %t2194, ptr %t2182, i64 %t2183)
  %t2195 = getelementptr i8, ptr %t2194, i64 %t2183
  call void @olang_textcopy(ptr %t2195, ptr %t2185, i64 %t2186)
  %t2196 = getelementptr i8, ptr %t2195, i64 %t2186
  call void @olang_textcopy(ptr %t2196, ptr %t2189, i64 %t2190)
  %t2197 = insertvalue { i64, ptr } undef, i64 %t2191, 0
  %t2198 = insertvalue { i64, ptr } %t2197, ptr %t2192, 1
  %t2200 = extractvalue { i64, ptr } %t2198, 0
  %t2201 = extractvalue { i64, ptr } %t2198, 1
  %t2202 = mul i64 %t2200, 1
  %t2203 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2202)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2203, ptr %t2201, i64 %t2202, i1 false)
  %t2204 = insertvalue { i64, ptr } undef, i64 %t2200, 0
  %t2205 = insertvalue { i64, ptr } %t2204, ptr %t2203, 1
  %t2208 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t2171, { i64, ptr } %t2205)
  store { i64, ptr } %t2208, ptr %l596
  br label %bb267
bb266:
  br label %bb269
bb267:
  %t2209 = load { i64, ptr }, ptr %l596, !tbaa !27
  %t2210 = extractvalue { i64, ptr } %t2209, 0
  %t2211 = extractvalue { i64, ptr } %t2209, 1
  %t2212 = mul i64 %t2210, 1
  %t2213 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2212)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2213, ptr %t2211, i64 %t2212, i1 false)
  %t2214 = insertvalue { i64, ptr } undef, i64 %t2210, 0
  %t2215 = insertvalue { i64, ptr } %t2214, ptr %t2213, 1
  %t2216 = load ptr, ptr %l589, !tbaa !29
  %t2218 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2enarrowBF16(ptr %v0, ptr %v1, ptr %v1, ptr %t2216, { i64, ptr } %t2215)
  store { i64, ptr } %t2218, ptr %l598
  br label %bb268
bb268:
  call void @__olang_scope_close(ptr %s70)
  call void @__olang_scope_close(ptr %s0)
  %t2219 = load { i64, ptr }, ptr %l598, !tbaa !27
  store { i64, ptr } %t2219, ptr %rv
  br label %ret
bb269:
  %t2220 = load i32, ptr %l1
  %t2222 = trunc i64 13 to i32
  %t2223 = icmp eq i32 %t2220, %t2222
  br i1 %t2223, label %bb270, label %bb271
bb270:
  br label %bb282
bb271:
  %t2225 = load i32, ptr %l1
  %t2227 = trunc i64 14 to i32
  %t2228 = icmp eq i32 %t2225, %t2227
  br i1 %t2228, label %bb272, label %bb273
bb272:
  br label %bb282
bb273:
  %t2230 = load i32, ptr %l1
  %t2232 = trunc i64 15 to i32
  %t2233 = icmp eq i32 %t2230, %t2232
  br i1 %t2233, label %bb274, label %bb275
bb274:
  br label %bb282
bb275:
  %t2235 = load i32, ptr %l1
  %t2237 = trunc i64 16 to i32
  %t2238 = icmp eq i32 %t2235, %t2237
  br i1 %t2238, label %bb276, label %bb277
bb276:
  br label %bb282
bb277:
  %t2240 = load i32, ptr %l1
  %t2242 = trunc i64 17 to i32
  %t2243 = icmp eq i32 %t2240, %t2242
  br i1 %t2243, label %bb278, label %bb279
bb278:
  br label %bb282
bb279:
  %t2245 = load i32, ptr %l1
  %t2247 = trunc i64 18 to i32
  %t2248 = icmp eq i32 %t2245, %t2247
  br i1 %t2248, label %bb280, label %bb281
bb280:
  br label %bb282
bb281:
  br label %bb284
bb282:
  %t2250 = load ptr, ptr %l0, !tbaa !29
  %t2251 = load i32, ptr %l1
  %t2252 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t2253 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t2258 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ecompare(ptr %v0, ptr %s70, ptr %s70, ptr %v1, ptr %t2250, i32 %t2251, i32 13, { i64, ptr } %t2252, { i64, ptr } %t2253)
  store { i64, ptr } %t2258, ptr %l615
  br label %bb283
bb283:
  call void @__olang_scope_close(ptr %s70)
  call void @__olang_scope_close(ptr %s0)
  %t2259 = load { i64, ptr }, ptr %l615, !tbaa !27
  store { i64, ptr } %t2259, ptr %rv
  br label %ret
bb284:
  br i1 true, label %bb285, label %bb286
bb285:
  br label %bb287
bb286:
  br label %bb288
bb287:
  br label %bb289
bb288:
  call void @__olang_check_failed(ptr @olang_loc_3839c0df7b992655_2640faef1ba2f611)
  unreachable
bb289:
  call void @__olang_scope_close(ptr %s70)
  br label %bb290
bb290:
  %t2260 = load i32, ptr %l1
  %t2262 = trunc i64 3 to i32
  %t2263 = icmp eq i32 %t2260, %t2262
  br i1 %t2263, label %bb291, label %bb292
bb291:
  br label %bb293
bb292:
  br label %bb298
bb293:
  %t2265 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2265, ptr %l618, !tbaa !29
  %t2266 = load i1, ptr %l9, !tbaa !21
  br i1 %t2266, label %bb294, label %bb295
bb294:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d324, i32 0, i32 1) }, ptr %l620, !tbaa !27
  br label %bb296
bb295:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d325, i32 0, i32 1) }, ptr %l620, !tbaa !27
  br label %bb296
bb296:
  %t2268 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t2269 = load ptr, ptr %lp11
  %t2270 = load { i64, ptr }, ptr %t2269, !tbaa !27
  %t2271 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t2272 = load { i64, ptr }, ptr %l620, !tbaa !27
  %t2273 = extractvalue { i64, ptr } %t2272, 1
  %t2274 = extractvalue { i64, ptr } %t2272, 0
  %t2276 = extractvalue { i64, ptr } %t2268, 1
  %t2277 = extractvalue { i64, ptr } %t2268, 0
  %t2278 = add i64 %t2274, %t2277
  %t2279 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d326, i32 0, i32 1) }, 1
  %t2280 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d326, i32 0, i32 1) }, 0
  %t2281 = add i64 %t2278, %t2280
  %t2283 = extractvalue { i64, ptr } %t2270, 1
  %t2284 = extractvalue { i64, ptr } %t2270, 0
  %t2285 = add i64 %t2281, %t2284
  %t2286 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d327, i32 0, i32 1) }, 1
  %t2287 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d327, i32 0, i32 1) }, 0
  %t2288 = add i64 %t2285, %t2287
  %t2290 = extractvalue { i64, ptr } %t2271, 1
  %t2291 = extractvalue { i64, ptr } %t2271, 0
  %t2292 = add i64 %t2288, %t2291
  %t2293 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2292)
  call void @olang_textcopy(ptr %t2293, ptr %t2273, i64 %t2274)
  %t2294 = getelementptr i8, ptr %t2293, i64 %t2274
  call void @olang_textcopy(ptr %t2294, ptr %t2276, i64 %t2277)
  %t2295 = getelementptr i8, ptr %t2294, i64 %t2277
  call void @olang_textcopy(ptr %t2295, ptr %t2279, i64 %t2280)
  %t2296 = getelementptr i8, ptr %t2295, i64 %t2280
  call void @olang_textcopy(ptr %t2296, ptr %t2283, i64 %t2284)
  %t2297 = getelementptr i8, ptr %t2296, i64 %t2284
  call void @olang_textcopy(ptr %t2297, ptr %t2286, i64 %t2287)
  %t2298 = getelementptr i8, ptr %t2297, i64 %t2287
  call void @olang_textcopy(ptr %t2298, ptr %t2290, i64 %t2291)
  %t2299 = insertvalue { i64, ptr } undef, i64 %t2292, 0
  %t2300 = insertvalue { i64, ptr } %t2299, ptr %t2293, 1
  %t2302 = extractvalue { i64, ptr } %t2300, 0
  %t2303 = extractvalue { i64, ptr } %t2300, 1
  %t2304 = mul i64 %t2302, 1
  %t2305 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2304)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2305, ptr %t2303, i64 %t2304, i1 false)
  %t2306 = insertvalue { i64, ptr } undef, i64 %t2302, 0
  %t2307 = insertvalue { i64, ptr } %t2306, ptr %t2305, 1
  %t2308 = load ptr, ptr %l618, !tbaa !29
  %t2310 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t2308, { i64, ptr } %t2307)
  store { i64, ptr } %t2310, ptr %l626
  br label %bb297
bb297:
  call void @__olang_scope_close(ptr %s0)
  %t2311 = load { i64, ptr }, ptr %l626, !tbaa !27
  store { i64, ptr } %t2311, ptr %rv
  br label %ret
bb298:
  %t2312 = load i32, ptr %l1
  %t2314 = trunc i64 4 to i32
  %t2315 = icmp eq i32 %t2312, %t2314
  br i1 %t2315, label %bb299, label %bb300
bb299:
  br label %bb301
bb300:
  br label %bb306
bb301:
  %t2317 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2317, ptr %l629, !tbaa !29
  %t2318 = load i1, ptr %l9, !tbaa !21
  br i1 %t2318, label %bb302, label %bb303
bb302:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d328, i32 0, i32 1) }, ptr %l631, !tbaa !27
  br label %bb304
bb303:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d329, i32 0, i32 1) }, ptr %l631, !tbaa !27
  br label %bb304
bb304:
  %t2320 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t2321 = load ptr, ptr %lp11
  %t2322 = load { i64, ptr }, ptr %t2321, !tbaa !27
  %t2323 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t2324 = load { i64, ptr }, ptr %l631, !tbaa !27
  %t2325 = extractvalue { i64, ptr } %t2324, 1
  %t2326 = extractvalue { i64, ptr } %t2324, 0
  %t2328 = extractvalue { i64, ptr } %t2320, 1
  %t2329 = extractvalue { i64, ptr } %t2320, 0
  %t2330 = add i64 %t2326, %t2329
  %t2331 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d330, i32 0, i32 1) }, 1
  %t2332 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d330, i32 0, i32 1) }, 0
  %t2333 = add i64 %t2330, %t2332
  %t2335 = extractvalue { i64, ptr } %t2322, 1
  %t2336 = extractvalue { i64, ptr } %t2322, 0
  %t2337 = add i64 %t2333, %t2336
  %t2338 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d331, i32 0, i32 1) }, 1
  %t2339 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d331, i32 0, i32 1) }, 0
  %t2340 = add i64 %t2337, %t2339
  %t2342 = extractvalue { i64, ptr } %t2323, 1
  %t2343 = extractvalue { i64, ptr } %t2323, 0
  %t2344 = add i64 %t2340, %t2343
  %t2345 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2344)
  call void @olang_textcopy(ptr %t2345, ptr %t2325, i64 %t2326)
  %t2346 = getelementptr i8, ptr %t2345, i64 %t2326
  call void @olang_textcopy(ptr %t2346, ptr %t2328, i64 %t2329)
  %t2347 = getelementptr i8, ptr %t2346, i64 %t2329
  call void @olang_textcopy(ptr %t2347, ptr %t2331, i64 %t2332)
  %t2348 = getelementptr i8, ptr %t2347, i64 %t2332
  call void @olang_textcopy(ptr %t2348, ptr %t2335, i64 %t2336)
  %t2349 = getelementptr i8, ptr %t2348, i64 %t2336
  call void @olang_textcopy(ptr %t2349, ptr %t2338, i64 %t2339)
  %t2350 = getelementptr i8, ptr %t2349, i64 %t2339
  call void @olang_textcopy(ptr %t2350, ptr %t2342, i64 %t2343)
  %t2351 = insertvalue { i64, ptr } undef, i64 %t2344, 0
  %t2352 = insertvalue { i64, ptr } %t2351, ptr %t2345, 1
  %t2354 = extractvalue { i64, ptr } %t2352, 0
  %t2355 = extractvalue { i64, ptr } %t2352, 1
  %t2356 = mul i64 %t2354, 1
  %t2357 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2356)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2357, ptr %t2355, i64 %t2356, i1 false)
  %t2358 = insertvalue { i64, ptr } undef, i64 %t2354, 0
  %t2359 = insertvalue { i64, ptr } %t2358, ptr %t2357, 1
  %t2360 = load ptr, ptr %l629, !tbaa !29
  %t2362 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t2360, { i64, ptr } %t2359)
  store { i64, ptr } %t2362, ptr %l637
  br label %bb305
bb305:
  call void @__olang_scope_close(ptr %s0)
  %t2363 = load { i64, ptr }, ptr %l637, !tbaa !27
  store { i64, ptr } %t2363, ptr %rv
  br label %ret
bb306:
  %t2364 = load i32, ptr %l1
  %t2366 = trunc i64 5 to i32
  %t2367 = icmp eq i32 %t2364, %t2366
  br i1 %t2367, label %bb307, label %bb308
bb307:
  br label %bb309
bb308:
  br label %bb314
bb309:
  %t2369 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2369, ptr %l640, !tbaa !29
  %t2370 = load i1, ptr %l9, !tbaa !21
  br i1 %t2370, label %bb310, label %bb311
bb310:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d332, i32 0, i32 1) }, ptr %l642, !tbaa !27
  br label %bb312
bb311:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d333, i32 0, i32 1) }, ptr %l642, !tbaa !27
  br label %bb312
bb312:
  %t2372 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t2373 = load ptr, ptr %lp11
  %t2374 = load { i64, ptr }, ptr %t2373, !tbaa !27
  %t2375 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t2376 = load { i64, ptr }, ptr %l642, !tbaa !27
  %t2377 = extractvalue { i64, ptr } %t2376, 1
  %t2378 = extractvalue { i64, ptr } %t2376, 0
  %t2380 = extractvalue { i64, ptr } %t2372, 1
  %t2381 = extractvalue { i64, ptr } %t2372, 0
  %t2382 = add i64 %t2378, %t2381
  %t2383 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d334, i32 0, i32 1) }, 1
  %t2384 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d334, i32 0, i32 1) }, 0
  %t2385 = add i64 %t2382, %t2384
  %t2387 = extractvalue { i64, ptr } %t2374, 1
  %t2388 = extractvalue { i64, ptr } %t2374, 0
  %t2389 = add i64 %t2385, %t2388
  %t2390 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d335, i32 0, i32 1) }, 1
  %t2391 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d335, i32 0, i32 1) }, 0
  %t2392 = add i64 %t2389, %t2391
  %t2394 = extractvalue { i64, ptr } %t2375, 1
  %t2395 = extractvalue { i64, ptr } %t2375, 0
  %t2396 = add i64 %t2392, %t2395
  %t2397 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2396)
  call void @olang_textcopy(ptr %t2397, ptr %t2377, i64 %t2378)
  %t2398 = getelementptr i8, ptr %t2397, i64 %t2378
  call void @olang_textcopy(ptr %t2398, ptr %t2380, i64 %t2381)
  %t2399 = getelementptr i8, ptr %t2398, i64 %t2381
  call void @olang_textcopy(ptr %t2399, ptr %t2383, i64 %t2384)
  %t2400 = getelementptr i8, ptr %t2399, i64 %t2384
  call void @olang_textcopy(ptr %t2400, ptr %t2387, i64 %t2388)
  %t2401 = getelementptr i8, ptr %t2400, i64 %t2388
  call void @olang_textcopy(ptr %t2401, ptr %t2390, i64 %t2391)
  %t2402 = getelementptr i8, ptr %t2401, i64 %t2391
  call void @olang_textcopy(ptr %t2402, ptr %t2394, i64 %t2395)
  %t2403 = insertvalue { i64, ptr } undef, i64 %t2396, 0
  %t2404 = insertvalue { i64, ptr } %t2403, ptr %t2397, 1
  %t2406 = extractvalue { i64, ptr } %t2404, 0
  %t2407 = extractvalue { i64, ptr } %t2404, 1
  %t2408 = mul i64 %t2406, 1
  %t2409 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2408)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2409, ptr %t2407, i64 %t2408, i1 false)
  %t2410 = insertvalue { i64, ptr } undef, i64 %t2406, 0
  %t2411 = insertvalue { i64, ptr } %t2410, ptr %t2409, 1
  %t2412 = load ptr, ptr %l640, !tbaa !29
  %t2414 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t2412, { i64, ptr } %t2411)
  store { i64, ptr } %t2414, ptr %l648
  br label %bb313
bb313:
  call void @__olang_scope_close(ptr %s0)
  %t2415 = load { i64, ptr }, ptr %l648, !tbaa !27
  store { i64, ptr } %t2415, ptr %rv
  br label %ret
bb314:
  %t2416 = load i32, ptr %l1
  %t2418 = trunc i64 6 to i32
  %t2419 = icmp eq i32 %t2416, %t2418
  br i1 %t2419, label %bb315, label %bb316
bb315:
  br label %bb317
bb316:
  br label %bb325
bb317:
  %t2421 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2421, ptr %l651, !tbaa !29
  %t2422 = load i1, ptr %l9, !tbaa !21
  br i1 %t2422, label %bb318, label %bb319
bb318:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d336, i32 0, i32 1) }, ptr %l653, !tbaa !27
  br label %bb323
bb319:
  %t2424 = load i1, ptr %l10, !tbaa !21
  br i1 %t2424, label %bb320, label %bb321
bb320:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d337, i32 0, i32 1) }, ptr %l655, !tbaa !27
  br label %bb322
bb321:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d338, i32 0, i32 1) }, ptr %l655, !tbaa !27
  br label %bb322
bb322:
  %t2426 = load { i64, ptr }, ptr %l655, !tbaa !27
  store { i64, ptr } %t2426, ptr %l653, !tbaa !27
  br label %bb323
bb323:
  %t2427 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t2428 = load ptr, ptr %lp11
  %t2429 = load { i64, ptr }, ptr %t2428, !tbaa !27
  %t2430 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t2431 = load { i64, ptr }, ptr %l653, !tbaa !27
  %t2432 = extractvalue { i64, ptr } %t2431, 1
  %t2433 = extractvalue { i64, ptr } %t2431, 0
  %t2435 = extractvalue { i64, ptr } %t2427, 1
  %t2436 = extractvalue { i64, ptr } %t2427, 0
  %t2437 = add i64 %t2433, %t2436
  %t2438 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d339, i32 0, i32 1) }, 1
  %t2439 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d339, i32 0, i32 1) }, 0
  %t2440 = add i64 %t2437, %t2439
  %t2442 = extractvalue { i64, ptr } %t2429, 1
  %t2443 = extractvalue { i64, ptr } %t2429, 0
  %t2444 = add i64 %t2440, %t2443
  %t2445 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d340, i32 0, i32 1) }, 1
  %t2446 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d340, i32 0, i32 1) }, 0
  %t2447 = add i64 %t2444, %t2446
  %t2449 = extractvalue { i64, ptr } %t2430, 1
  %t2450 = extractvalue { i64, ptr } %t2430, 0
  %t2451 = add i64 %t2447, %t2450
  %t2452 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2451)
  call void @olang_textcopy(ptr %t2452, ptr %t2432, i64 %t2433)
  %t2453 = getelementptr i8, ptr %t2452, i64 %t2433
  call void @olang_textcopy(ptr %t2453, ptr %t2435, i64 %t2436)
  %t2454 = getelementptr i8, ptr %t2453, i64 %t2436
  call void @olang_textcopy(ptr %t2454, ptr %t2438, i64 %t2439)
  %t2455 = getelementptr i8, ptr %t2454, i64 %t2439
  call void @olang_textcopy(ptr %t2455, ptr %t2442, i64 %t2443)
  %t2456 = getelementptr i8, ptr %t2455, i64 %t2443
  call void @olang_textcopy(ptr %t2456, ptr %t2445, i64 %t2446)
  %t2457 = getelementptr i8, ptr %t2456, i64 %t2446
  call void @olang_textcopy(ptr %t2457, ptr %t2449, i64 %t2450)
  %t2458 = insertvalue { i64, ptr } undef, i64 %t2451, 0
  %t2459 = insertvalue { i64, ptr } %t2458, ptr %t2452, 1
  %t2461 = extractvalue { i64, ptr } %t2459, 0
  %t2462 = extractvalue { i64, ptr } %t2459, 1
  %t2463 = mul i64 %t2461, 1
  %t2464 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2463)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2464, ptr %t2462, i64 %t2463, i1 false)
  %t2465 = insertvalue { i64, ptr } undef, i64 %t2461, 0
  %t2466 = insertvalue { i64, ptr } %t2465, ptr %t2464, 1
  %t2467 = load ptr, ptr %l651, !tbaa !29
  %t2469 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t2467, { i64, ptr } %t2466)
  store { i64, ptr } %t2469, ptr %l661
  br label %bb324
bb324:
  call void @__olang_scope_close(ptr %s0)
  %t2470 = load { i64, ptr }, ptr %l661, !tbaa !27
  store { i64, ptr } %t2470, ptr %rv
  br label %ret
bb325:
  %t2471 = load i32, ptr %l1
  %t2473 = trunc i64 7 to i32
  %t2474 = icmp eq i32 %t2471, %t2473
  br i1 %t2474, label %bb326, label %bb327
bb326:
  br label %bb328
bb327:
  br label %bb336
bb328:
  %t2476 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2476, ptr %l664, !tbaa !29
  %t2477 = load i1, ptr %l9, !tbaa !21
  br i1 %t2477, label %bb329, label %bb330
bb329:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d341, i32 0, i32 1) }, ptr %l666, !tbaa !27
  br label %bb334
bb330:
  %t2479 = load i1, ptr %l10, !tbaa !21
  br i1 %t2479, label %bb331, label %bb332
bb331:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d342, i32 0, i32 1) }, ptr %l668, !tbaa !27
  br label %bb333
bb332:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d343, i32 0, i32 1) }, ptr %l668, !tbaa !27
  br label %bb333
bb333:
  %t2481 = load { i64, ptr }, ptr %l668, !tbaa !27
  store { i64, ptr } %t2481, ptr %l666, !tbaa !27
  br label %bb334
bb334:
  %t2482 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t2483 = load ptr, ptr %lp11
  %t2484 = load { i64, ptr }, ptr %t2483, !tbaa !27
  %t2485 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t2486 = load { i64, ptr }, ptr %l666, !tbaa !27
  %t2487 = extractvalue { i64, ptr } %t2486, 1
  %t2488 = extractvalue { i64, ptr } %t2486, 0
  %t2490 = extractvalue { i64, ptr } %t2482, 1
  %t2491 = extractvalue { i64, ptr } %t2482, 0
  %t2492 = add i64 %t2488, %t2491
  %t2493 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d344, i32 0, i32 1) }, 1
  %t2494 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d344, i32 0, i32 1) }, 0
  %t2495 = add i64 %t2492, %t2494
  %t2497 = extractvalue { i64, ptr } %t2484, 1
  %t2498 = extractvalue { i64, ptr } %t2484, 0
  %t2499 = add i64 %t2495, %t2498
  %t2500 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d345, i32 0, i32 1) }, 1
  %t2501 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d345, i32 0, i32 1) }, 0
  %t2502 = add i64 %t2499, %t2501
  %t2504 = extractvalue { i64, ptr } %t2485, 1
  %t2505 = extractvalue { i64, ptr } %t2485, 0
  %t2506 = add i64 %t2502, %t2505
  %t2507 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2506)
  call void @olang_textcopy(ptr %t2507, ptr %t2487, i64 %t2488)
  %t2508 = getelementptr i8, ptr %t2507, i64 %t2488
  call void @olang_textcopy(ptr %t2508, ptr %t2490, i64 %t2491)
  %t2509 = getelementptr i8, ptr %t2508, i64 %t2491
  call void @olang_textcopy(ptr %t2509, ptr %t2493, i64 %t2494)
  %t2510 = getelementptr i8, ptr %t2509, i64 %t2494
  call void @olang_textcopy(ptr %t2510, ptr %t2497, i64 %t2498)
  %t2511 = getelementptr i8, ptr %t2510, i64 %t2498
  call void @olang_textcopy(ptr %t2511, ptr %t2500, i64 %t2501)
  %t2512 = getelementptr i8, ptr %t2511, i64 %t2501
  call void @olang_textcopy(ptr %t2512, ptr %t2504, i64 %t2505)
  %t2513 = insertvalue { i64, ptr } undef, i64 %t2506, 0
  %t2514 = insertvalue { i64, ptr } %t2513, ptr %t2507, 1
  %t2516 = extractvalue { i64, ptr } %t2514, 0
  %t2517 = extractvalue { i64, ptr } %t2514, 1
  %t2518 = mul i64 %t2516, 1
  %t2519 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2518)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2519, ptr %t2517, i64 %t2518, i1 false)
  %t2520 = insertvalue { i64, ptr } undef, i64 %t2516, 0
  %t2521 = insertvalue { i64, ptr } %t2520, ptr %t2519, 1
  %t2522 = load ptr, ptr %l664, !tbaa !29
  %t2524 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t2522, { i64, ptr } %t2521)
  store { i64, ptr } %t2524, ptr %l674
  br label %bb335
bb335:
  call void @__olang_scope_close(ptr %s0)
  %t2525 = load { i64, ptr }, ptr %l674, !tbaa !27
  store { i64, ptr } %t2525, ptr %rv
  br label %ret
bb336:
  %t2526 = load i32, ptr %l1
  %t2528 = trunc i64 8 to i32
  %t2529 = icmp eq i32 %t2526, %t2528
  br i1 %t2529, label %bb337, label %bb338
bb337:
  br label %bb341
bb338:
  %t2531 = load i32, ptr %l1
  %t2533 = trunc i64 9 to i32
  %t2534 = icmp eq i32 %t2531, %t2533
  br i1 %t2534, label %bb339, label %bb340
bb339:
  br label %bb341
bb340:
  br label %bb354
bb341:
  store %olang.scope zeroinitializer, ptr %s91
  %t2536 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2536, ptr %l679, !tbaa !29
  %t2537 = load ptr, ptr %l0, !tbaa !29
  %t2538 = load %"compiler/mir:Range", ptr %l3
  %t2541 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t2537, %"compiler/mir:Range" %t2538, i64 1)
  store { i64, [4 x i64] } %t2541, ptr %l682
  br label %bb342
bb342:
  %t2542 = load ptr, ptr %l679, !tbaa !29
  %t2543 = load { i64, [4 x i64] }, ptr %l682
  %t2544 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t2542, { i64, [4 x i64] } %t2543)
  store i32 %t2544, ptr %l683
  br label %bb343
bb343:
  %t2545 = load i32, ptr %l683, !tbaa !23
  store i32 %t2545, ptr %l49, !tbaa !23
  %t2546 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2546, ptr %l684, !tbaa !29
  %t2547 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2547, ptr %l685, !tbaa !29
  %t2548 = load ptr, ptr %l0, !tbaa !29
  %t2549 = load %"compiler/mir:Range", ptr %l3
  %t2552 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t2548, %"compiler/mir:Range" %t2549, i64 1)
  store { i64, [4 x i64] } %t2552, ptr %l688
  br label %bb344
bb344:
  %t2553 = load i32, ptr %l49, !tbaa !23
  %t2554 = load ptr, ptr %l685, !tbaa !29
  %t2555 = load { i64, [4 x i64] }, ptr %l688
  %t2557 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s91, ptr %t2554, { i64, [4 x i64] } %t2555, i32 %t2553)
  store { i64, ptr } %t2557, ptr %l690
  br label %bb345
bb345:
  %t2558 = load { i64, ptr }, ptr %l690, !tbaa !27
  %t2559 = extractvalue { i64, ptr } %t2558, 0
  %t2560 = extractvalue { i64, ptr } %t2558, 1
  %t2561 = mul i64 %t2559, 1
  %t2562 = call ptr @__olang_scope_alloc(ptr %s91, i64 %t2561)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2562, ptr %t2560, i64 %t2561, i1 false)
  %t2563 = insertvalue { i64, ptr } undef, i64 %t2559, 0
  %t2564 = insertvalue { i64, ptr } %t2563, ptr %t2562, 1
  %t2565 = load i32, ptr %l49, !tbaa !23
  %t2566 = load i32, ptr %l7, !tbaa !23
  %t2567 = load ptr, ptr %l684, !tbaa !29
  %t2571 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ewidth(ptr %v0, ptr %s91, ptr %s91, ptr %t2567, { i64, ptr } %t2564, i32 %t2565, i32 %t2566)
  store { i64, ptr } %t2571, ptr %l694
  br label %bb346
bb346:
  %t2572 = load { i64, ptr }, ptr %l694, !tbaa !27
  store { i64, ptr } %t2572, ptr %l50, !tbaa !27
  %t2573 = load i32, ptr %l1
  %t2575 = trunc i64 8 to i32
  %t2576 = icmp eq i32 %t2573, %t2575
  br i1 %t2576, label %bb347, label %bb348
bb347:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d346, i32 0, i32 1) }, ptr %l697, !tbaa !27
  br label %bb352
bb348:
  %t2578 = load i1, ptr %l10, !tbaa !21
  br i1 %t2578, label %bb349, label %bb350
bb349:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d347, i32 0, i32 1) }, ptr %l699, !tbaa !27
  br label %bb351
bb350:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d348, i32 0, i32 1) }, ptr %l699, !tbaa !27
  br label %bb351
bb351:
  %t2580 = load { i64, ptr }, ptr %l699, !tbaa !27
  store { i64, ptr } %t2580, ptr %l697, !tbaa !27
  br label %bb352
bb352:
  %t2581 = load { i64, ptr }, ptr %l697, !tbaa !27
  %t2582 = load ptr, ptr %l0, !tbaa !29
  %t2584 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t2585 = load ptr, ptr %lp11
  %t2586 = load { i64, ptr }, ptr %t2585, !tbaa !27
  %t2587 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t2589 = extractvalue { i64, ptr } %t2581, 1
  %t2590 = extractvalue { i64, ptr } %t2581, 0
  %t2592 = extractvalue { i64, ptr } %t2584, 1
  %t2593 = extractvalue { i64, ptr } %t2584, 0
  %t2594 = add i64 %t2590, %t2593
  %t2595 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d349, i32 0, i32 1) }, 1
  %t2596 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d349, i32 0, i32 1) }, 0
  %t2597 = add i64 %t2594, %t2596
  %t2599 = extractvalue { i64, ptr } %t2586, 1
  %t2600 = extractvalue { i64, ptr } %t2586, 0
  %t2601 = add i64 %t2597, %t2600
  %t2602 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d350, i32 0, i32 1) }, 1
  %t2603 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d350, i32 0, i32 1) }, 0
  %t2604 = add i64 %t2601, %t2603
  %t2606 = extractvalue { i64, ptr } %t2587, 1
  %t2607 = extractvalue { i64, ptr } %t2587, 0
  %t2608 = add i64 %t2604, %t2607
  %t2609 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2608)
  call void @olang_textcopy(ptr %t2609, ptr %t2589, i64 %t2590)
  %t2610 = getelementptr i8, ptr %t2609, i64 %t2590
  call void @olang_textcopy(ptr %t2610, ptr %t2592, i64 %t2593)
  %t2611 = getelementptr i8, ptr %t2610, i64 %t2593
  call void @olang_textcopy(ptr %t2611, ptr %t2595, i64 %t2596)
  %t2612 = getelementptr i8, ptr %t2611, i64 %t2596
  call void @olang_textcopy(ptr %t2612, ptr %t2599, i64 %t2600)
  %t2613 = getelementptr i8, ptr %t2612, i64 %t2600
  call void @olang_textcopy(ptr %t2613, ptr %t2602, i64 %t2603)
  %t2614 = getelementptr i8, ptr %t2613, i64 %t2603
  call void @olang_textcopy(ptr %t2614, ptr %t2606, i64 %t2607)
  %t2615 = insertvalue { i64, ptr } undef, i64 %t2608, 0
  %t2616 = insertvalue { i64, ptr } %t2615, ptr %t2609, 1
  %t2618 = extractvalue { i64, ptr } %t2616, 0
  %t2619 = extractvalue { i64, ptr } %t2616, 1
  %t2620 = mul i64 %t2618, 1
  %t2621 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2620)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2621, ptr %t2619, i64 %t2620, i1 false)
  %t2622 = insertvalue { i64, ptr } undef, i64 %t2618, 0
  %t2623 = insertvalue { i64, ptr } %t2622, ptr %t2621, 1
  %t2626 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t2582, { i64, ptr } %t2623)
  store { i64, ptr } %t2626, ptr %l707
  br label %bb353
bb353:
  call void @__olang_scope_close(ptr %s91)
  call void @__olang_scope_close(ptr %s0)
  %t2627 = load { i64, ptr }, ptr %l707, !tbaa !27
  store { i64, ptr } %t2627, ptr %rv
  br label %ret
bb354:
  %t2628 = load i32, ptr %l1
  %t2630 = trunc i64 10 to i32
  %t2631 = icmp eq i32 %t2628, %t2630
  br i1 %t2631, label %bb355, label %bb356
bb355:
  br label %bb357
bb356:
  br label %bb359
bb357:
  %t2633 = load ptr, ptr %l0, !tbaa !29
  %t2634 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t2635 = load ptr, ptr %lp11
  %t2636 = load { i64, ptr }, ptr %t2635, !tbaa !27
  %t2637 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t2638 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d351, i32 0, i32 1) }, 1
  %t2639 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d351, i32 0, i32 1) }, 0
  %t2641 = extractvalue { i64, ptr } %t2634, 1
  %t2642 = extractvalue { i64, ptr } %t2634, 0
  %t2643 = add i64 %t2639, %t2642
  %t2644 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d352, i32 0, i32 1) }, 1
  %t2645 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d352, i32 0, i32 1) }, 0
  %t2646 = add i64 %t2643, %t2645
  %t2648 = extractvalue { i64, ptr } %t2636, 1
  %t2649 = extractvalue { i64, ptr } %t2636, 0
  %t2650 = add i64 %t2646, %t2649
  %t2651 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d353, i32 0, i32 1) }, 1
  %t2652 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d353, i32 0, i32 1) }, 0
  %t2653 = add i64 %t2650, %t2652
  %t2655 = extractvalue { i64, ptr } %t2637, 1
  %t2656 = extractvalue { i64, ptr } %t2637, 0
  %t2657 = add i64 %t2653, %t2656
  %t2658 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2657)
  call void @olang_textcopy(ptr %t2658, ptr %t2638, i64 %t2639)
  %t2659 = getelementptr i8, ptr %t2658, i64 %t2639
  call void @olang_textcopy(ptr %t2659, ptr %t2641, i64 %t2642)
  %t2660 = getelementptr i8, ptr %t2659, i64 %t2642
  call void @olang_textcopy(ptr %t2660, ptr %t2644, i64 %t2645)
  %t2661 = getelementptr i8, ptr %t2660, i64 %t2645
  call void @olang_textcopy(ptr %t2661, ptr %t2648, i64 %t2649)
  %t2662 = getelementptr i8, ptr %t2661, i64 %t2649
  call void @olang_textcopy(ptr %t2662, ptr %t2651, i64 %t2652)
  %t2663 = getelementptr i8, ptr %t2662, i64 %t2652
  call void @olang_textcopy(ptr %t2663, ptr %t2655, i64 %t2656)
  %t2664 = insertvalue { i64, ptr } undef, i64 %t2657, 0
  %t2665 = insertvalue { i64, ptr } %t2664, ptr %t2658, 1
  %t2667 = extractvalue { i64, ptr } %t2665, 0
  %t2668 = extractvalue { i64, ptr } %t2665, 1
  %t2669 = mul i64 %t2667, 1
  %t2670 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2669)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2670, ptr %t2668, i64 %t2669, i1 false)
  %t2671 = insertvalue { i64, ptr } undef, i64 %t2667, 0
  %t2672 = insertvalue { i64, ptr } %t2671, ptr %t2670, 1
  %t2675 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t2633, { i64, ptr } %t2672)
  store { i64, ptr } %t2675, ptr %l716
  br label %bb358
bb358:
  call void @__olang_scope_close(ptr %s0)
  %t2676 = load { i64, ptr }, ptr %l716, !tbaa !27
  store { i64, ptr } %t2676, ptr %rv
  br label %ret
bb359:
  %t2677 = load i32, ptr %l1
  %t2679 = trunc i64 11 to i32
  %t2680 = icmp eq i32 %t2677, %t2679
  br i1 %t2680, label %bb360, label %bb361
bb360:
  br label %bb362
bb361:
  br label %bb364
bb362:
  %t2682 = load ptr, ptr %l0, !tbaa !29
  %t2683 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t2684 = load ptr, ptr %lp11
  %t2685 = load { i64, ptr }, ptr %t2684, !tbaa !27
  %t2686 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t2687 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d354, i32 0, i32 1) }, 1
  %t2688 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d354, i32 0, i32 1) }, 0
  %t2690 = extractvalue { i64, ptr } %t2683, 1
  %t2691 = extractvalue { i64, ptr } %t2683, 0
  %t2692 = add i64 %t2688, %t2691
  %t2693 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d355, i32 0, i32 1) }, 1
  %t2694 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d355, i32 0, i32 1) }, 0
  %t2695 = add i64 %t2692, %t2694
  %t2697 = extractvalue { i64, ptr } %t2685, 1
  %t2698 = extractvalue { i64, ptr } %t2685, 0
  %t2699 = add i64 %t2695, %t2698
  %t2700 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d356, i32 0, i32 1) }, 1
  %t2701 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d356, i32 0, i32 1) }, 0
  %t2702 = add i64 %t2699, %t2701
  %t2704 = extractvalue { i64, ptr } %t2686, 1
  %t2705 = extractvalue { i64, ptr } %t2686, 0
  %t2706 = add i64 %t2702, %t2705
  %t2707 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2706)
  call void @olang_textcopy(ptr %t2707, ptr %t2687, i64 %t2688)
  %t2708 = getelementptr i8, ptr %t2707, i64 %t2688
  call void @olang_textcopy(ptr %t2708, ptr %t2690, i64 %t2691)
  %t2709 = getelementptr i8, ptr %t2708, i64 %t2691
  call void @olang_textcopy(ptr %t2709, ptr %t2693, i64 %t2694)
  %t2710 = getelementptr i8, ptr %t2709, i64 %t2694
  call void @olang_textcopy(ptr %t2710, ptr %t2697, i64 %t2698)
  %t2711 = getelementptr i8, ptr %t2710, i64 %t2698
  call void @olang_textcopy(ptr %t2711, ptr %t2700, i64 %t2701)
  %t2712 = getelementptr i8, ptr %t2711, i64 %t2701
  call void @olang_textcopy(ptr %t2712, ptr %t2704, i64 %t2705)
  %t2713 = insertvalue { i64, ptr } undef, i64 %t2706, 0
  %t2714 = insertvalue { i64, ptr } %t2713, ptr %t2707, 1
  %t2716 = extractvalue { i64, ptr } %t2714, 0
  %t2717 = extractvalue { i64, ptr } %t2714, 1
  %t2718 = mul i64 %t2716, 1
  %t2719 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2718)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2719, ptr %t2717, i64 %t2718, i1 false)
  %t2720 = insertvalue { i64, ptr } undef, i64 %t2716, 0
  %t2721 = insertvalue { i64, ptr } %t2720, ptr %t2719, 1
  %t2724 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t2682, { i64, ptr } %t2721)
  store { i64, ptr } %t2724, ptr %l725
  br label %bb363
bb363:
  call void @__olang_scope_close(ptr %s0)
  %t2725 = load { i64, ptr }, ptr %l725, !tbaa !27
  store { i64, ptr } %t2725, ptr %rv
  br label %ret
bb364:
  %t2726 = load i32, ptr %l1
  %t2728 = trunc i64 12 to i32
  %t2729 = icmp eq i32 %t2726, %t2728
  br i1 %t2729, label %bb365, label %bb366
bb365:
  br label %bb367
bb366:
  br label %bb369
bb367:
  %t2731 = load ptr, ptr %l0, !tbaa !29
  %t2732 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t2733 = load ptr, ptr %lp11
  %t2734 = load { i64, ptr }, ptr %t2733, !tbaa !27
  %t2735 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t2736 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d357, i32 0, i32 1) }, 1
  %t2737 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d357, i32 0, i32 1) }, 0
  %t2739 = extractvalue { i64, ptr } %t2732, 1
  %t2740 = extractvalue { i64, ptr } %t2732, 0
  %t2741 = add i64 %t2737, %t2740
  %t2742 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d358, i32 0, i32 1) }, 1
  %t2743 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d358, i32 0, i32 1) }, 0
  %t2744 = add i64 %t2741, %t2743
  %t2746 = extractvalue { i64, ptr } %t2734, 1
  %t2747 = extractvalue { i64, ptr } %t2734, 0
  %t2748 = add i64 %t2744, %t2747
  %t2749 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d359, i32 0, i32 1) }, 1
  %t2750 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d359, i32 0, i32 1) }, 0
  %t2751 = add i64 %t2748, %t2750
  %t2753 = extractvalue { i64, ptr } %t2735, 1
  %t2754 = extractvalue { i64, ptr } %t2735, 0
  %t2755 = add i64 %t2751, %t2754
  %t2756 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2755)
  call void @olang_textcopy(ptr %t2756, ptr %t2736, i64 %t2737)
  %t2757 = getelementptr i8, ptr %t2756, i64 %t2737
  call void @olang_textcopy(ptr %t2757, ptr %t2739, i64 %t2740)
  %t2758 = getelementptr i8, ptr %t2757, i64 %t2740
  call void @olang_textcopy(ptr %t2758, ptr %t2742, i64 %t2743)
  %t2759 = getelementptr i8, ptr %t2758, i64 %t2743
  call void @olang_textcopy(ptr %t2759, ptr %t2746, i64 %t2747)
  %t2760 = getelementptr i8, ptr %t2759, i64 %t2747
  call void @olang_textcopy(ptr %t2760, ptr %t2749, i64 %t2750)
  %t2761 = getelementptr i8, ptr %t2760, i64 %t2750
  call void @olang_textcopy(ptr %t2761, ptr %t2753, i64 %t2754)
  %t2762 = insertvalue { i64, ptr } undef, i64 %t2755, 0
  %t2763 = insertvalue { i64, ptr } %t2762, ptr %t2756, 1
  %t2765 = extractvalue { i64, ptr } %t2763, 0
  %t2766 = extractvalue { i64, ptr } %t2763, 1
  %t2767 = mul i64 %t2765, 1
  %t2768 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2767)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2768, ptr %t2766, i64 %t2767, i1 false)
  %t2769 = insertvalue { i64, ptr } undef, i64 %t2765, 0
  %t2770 = insertvalue { i64, ptr } %t2769, ptr %t2768, 1
  %t2773 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t2731, { i64, ptr } %t2770)
  store { i64, ptr } %t2773, ptr %l734
  br label %bb368
bb368:
  call void @__olang_scope_close(ptr %s0)
  %t2774 = load { i64, ptr }, ptr %l734, !tbaa !27
  store { i64, ptr } %t2774, ptr %rv
  br label %ret
bb369:
  %t2775 = load i32, ptr %l1
  %t2777 = trunc i64 13 to i32
  %t2778 = icmp eq i32 %t2775, %t2777
  br i1 %t2778, label %bb370, label %bb371
bb370:
  br label %bb382
bb371:
  %t2780 = load i32, ptr %l1
  %t2782 = trunc i64 14 to i32
  %t2783 = icmp eq i32 %t2780, %t2782
  br i1 %t2783, label %bb372, label %bb373
bb372:
  br label %bb382
bb373:
  %t2785 = load i32, ptr %l1
  %t2787 = trunc i64 15 to i32
  %t2788 = icmp eq i32 %t2785, %t2787
  br i1 %t2788, label %bb374, label %bb375
bb374:
  br label %bb382
bb375:
  %t2790 = load i32, ptr %l1
  %t2792 = trunc i64 16 to i32
  %t2793 = icmp eq i32 %t2790, %t2792
  br i1 %t2793, label %bb376, label %bb377
bb376:
  br label %bb382
bb377:
  %t2795 = load i32, ptr %l1
  %t2797 = trunc i64 17 to i32
  %t2798 = icmp eq i32 %t2795, %t2797
  br i1 %t2798, label %bb378, label %bb379
bb378:
  br label %bb382
bb379:
  %t2800 = load i32, ptr %l1
  %t2802 = trunc i64 18 to i32
  %t2803 = icmp eq i32 %t2800, %t2802
  br i1 %t2803, label %bb380, label %bb381
bb380:
  br label %bb382
bb381:
  br label %bb384
bb382:
  %t2805 = load ptr, ptr %l0, !tbaa !29
  %t2806 = load i32, ptr %l1
  %t2807 = load i32, ptr %l7, !tbaa !23
  %t2808 = load ptr, ptr %lp11
  %t2809 = load { i64, ptr }, ptr %t2808, !tbaa !27
  %t2810 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t2816 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ecompare(ptr %v0, ptr %v1, ptr %s0, ptr %v1, ptr %t2805, i32 %t2806, i32 %t2807, { i64, ptr } %t2809, { i64, ptr } %t2810)
  store { i64, ptr } %t2816, ptr %l752
  br label %bb383
bb383:
  call void @__olang_scope_close(ptr %s0)
  %t2817 = load { i64, ptr }, ptr %l752, !tbaa !27
  store { i64, ptr } %t2817, ptr %rv
  br label %ret
bb384:
  %t2818 = load i32, ptr %l1
  %t2820 = trunc i64 19 to i32
  %t2821 = icmp eq i32 %t2818, %t2820
  br i1 %t2821, label %bb385, label %bb386
bb385:
  br label %bb387
bb386:
  br label %bb408
bb387:
  store %olang.scope zeroinitializer, ptr %s100
  %t2823 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t2825 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s100, { i64, ptr } %t2823, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d360, i32 0, i32 1) })
  store i1 %t2825, ptr %l756
  br label %bb388
bb388:
  %t2826 = load i1, ptr %l756, !tbaa !21
  br i1 %t2826, label %bb389, label %bb390
bb389:
  store i1 true, ptr %l757, !tbaa !21
  br label %bb392
bb390:
  %t2827 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t2829 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s100, { i64, ptr } %t2827, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d361, i32 0, i32 1) })
  store i1 %t2829, ptr %l759
  br label %bb391
bb391:
  %t2830 = load i1, ptr %l759, !tbaa !21
  store i1 %t2830, ptr %l757, !tbaa !21
  br label %bb392
bb392:
  %t2831 = load i1, ptr %l757, !tbaa !21
  br i1 %t2831, label %bb393, label %bb394
bb393:
  store %olang.scope zeroinitializer, ptr %s101
  %t2832 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t2834 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s101, { i64, ptr } %t2832, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d362, i32 0, i32 1) })
  store i1 %t2834, ptr %l761
  br label %bb395
bb394:
  br label %bb406
bb395:
  %t2835 = load i1, ptr %l761, !tbaa !21
  br i1 %t2835, label %bb396, label %bb397
bb396:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d363, i32 0, i32 1) }, ptr %l762, !tbaa !27
  br label %bb398
bb397:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d364, i32 0, i32 1) }, ptr %l762, !tbaa !27
  br label %bb398
bb398:
  %t2836 = load { i64, ptr }, ptr %l762, !tbaa !27
  %t2837 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2837, ptr %l763, !tbaa !29
  store { i64, ptr } %t2836, ptr %l764, !tbaa !27
  %t2839 = load ptr, ptr %l0, !tbaa !29
  %t2840 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t2841 = load ptr, ptr %lp11
  %t2842 = load { i64, ptr }, ptr %t2841, !tbaa !27
  %t2843 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d365, i32 0, i32 1) }, 1
  %t2844 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d365, i32 0, i32 1) }, 0
  %t2846 = extractvalue { i64, ptr } %t2840, 1
  %t2847 = extractvalue { i64, ptr } %t2840, 0
  %t2848 = add i64 %t2844, %t2847
  %t2849 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d366, i32 0, i32 1) }, 1
  %t2850 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d366, i32 0, i32 1) }, 0
  %t2851 = add i64 %t2848, %t2850
  %t2853 = extractvalue { i64, ptr } %t2842, 1
  %t2854 = extractvalue { i64, ptr } %t2842, 0
  %t2855 = add i64 %t2851, %t2854
  %t2856 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d367, i32 0, i32 1) }, 1
  %t2857 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d367, i32 0, i32 1) }, 0
  %t2858 = add i64 %t2855, %t2857
  %t2859 = call ptr @__olang_scope_alloc(ptr %s101, i64 %t2858)
  call void @olang_textcopy(ptr %t2859, ptr %t2843, i64 %t2844)
  %t2860 = getelementptr i8, ptr %t2859, i64 %t2844
  call void @olang_textcopy(ptr %t2860, ptr %t2846, i64 %t2847)
  %t2861 = getelementptr i8, ptr %t2860, i64 %t2847
  call void @olang_textcopy(ptr %t2861, ptr %t2849, i64 %t2850)
  %t2862 = getelementptr i8, ptr %t2861, i64 %t2850
  call void @olang_textcopy(ptr %t2862, ptr %t2853, i64 %t2854)
  %t2863 = getelementptr i8, ptr %t2862, i64 %t2854
  call void @olang_textcopy(ptr %t2863, ptr %t2856, i64 %t2857)
  %t2864 = insertvalue { i64, ptr } undef, i64 %t2858, 0
  %t2865 = insertvalue { i64, ptr } %t2864, ptr %t2859, 1
  %t2867 = extractvalue { i64, ptr } %t2865, 0
  %t2868 = extractvalue { i64, ptr } %t2865, 1
  %t2869 = mul i64 %t2867, 1
  %t2870 = call ptr @__olang_scope_alloc(ptr %s101, i64 %t2869)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2870, ptr %t2868, i64 %t2869, i1 false)
  %t2871 = insertvalue { i64, ptr } undef, i64 %t2867, 0
  %t2872 = insertvalue { i64, ptr } %t2871, ptr %t2870, 1
  %t2875 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s101, ptr %s101, ptr %t2839, { i64, ptr } %t2872)
  store { i64, ptr } %t2875, ptr %l770
  br label %bb399
bb399:
  %t2876 = load ptr, ptr %l0, !tbaa !29
  %t2877 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t2878 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t2879 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d368, i32 0, i32 1) }, 1
  %t2880 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d368, i32 0, i32 1) }, 0
  %t2882 = extractvalue { i64, ptr } %t2877, 1
  %t2883 = extractvalue { i64, ptr } %t2877, 0
  %t2884 = add i64 %t2880, %t2883
  %t2885 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d369, i32 0, i32 1) }, 1
  %t2886 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d369, i32 0, i32 1) }, 0
  %t2887 = add i64 %t2884, %t2886
  %t2889 = extractvalue { i64, ptr } %t2878, 1
  %t2890 = extractvalue { i64, ptr } %t2878, 0
  %t2891 = add i64 %t2887, %t2890
  %t2892 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d370, i32 0, i32 1) }, 1
  %t2893 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d370, i32 0, i32 1) }, 0
  %t2894 = add i64 %t2891, %t2893
  %t2895 = call ptr @__olang_scope_alloc(ptr %s101, i64 %t2894)
  call void @olang_textcopy(ptr %t2895, ptr %t2879, i64 %t2880)
  %t2896 = getelementptr i8, ptr %t2895, i64 %t2880
  call void @olang_textcopy(ptr %t2896, ptr %t2882, i64 %t2883)
  %t2897 = getelementptr i8, ptr %t2896, i64 %t2883
  call void @olang_textcopy(ptr %t2897, ptr %t2885, i64 %t2886)
  %t2898 = getelementptr i8, ptr %t2897, i64 %t2886
  call void @olang_textcopy(ptr %t2898, ptr %t2889, i64 %t2890)
  %t2899 = getelementptr i8, ptr %t2898, i64 %t2890
  call void @olang_textcopy(ptr %t2899, ptr %t2892, i64 %t2893)
  %t2900 = insertvalue { i64, ptr } undef, i64 %t2894, 0
  %t2901 = insertvalue { i64, ptr } %t2900, ptr %t2895, 1
  %t2903 = extractvalue { i64, ptr } %t2901, 0
  %t2904 = extractvalue { i64, ptr } %t2901, 1
  %t2905 = mul i64 %t2903, 1
  %t2906 = call ptr @__olang_scope_alloc(ptr %s101, i64 %t2905)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2906, ptr %t2904, i64 %t2905, i1 false)
  %t2907 = insertvalue { i64, ptr } undef, i64 %t2903, 0
  %t2908 = insertvalue { i64, ptr } %t2907, ptr %t2906, 1
  %t2911 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s101, ptr %s101, ptr %t2876, { i64, ptr } %t2908)
  store { i64, ptr } %t2911, ptr %l776
  br label %bb400
bb400:
  %t2912 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d371, i32 0, i32 1) }, 1
  %t2913 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d371, i32 0, i32 1) }, 0
  %t2914 = load { i64, ptr }, ptr %l764, !tbaa !27
  %t2915 = extractvalue { i64, ptr } %t2914, 1
  %t2916 = extractvalue { i64, ptr } %t2914, 0
  %t2917 = add i64 %t2913, %t2916
  %t2918 = load { i64, ptr }, ptr %l770, !tbaa !27
  %t2919 = extractvalue { i64, ptr } %t2918, 1
  %t2920 = extractvalue { i64, ptr } %t2918, 0
  %t2921 = add i64 %t2917, %t2920
  %t2922 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d372, i32 0, i32 1) }, 1
  %t2923 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d372, i32 0, i32 1) }, 0
  %t2924 = add i64 %t2921, %t2923
  %t2925 = load { i64, ptr }, ptr %l776, !tbaa !27
  %t2926 = extractvalue { i64, ptr } %t2925, 1
  %t2927 = extractvalue { i64, ptr } %t2925, 0
  %t2928 = add i64 %t2924, %t2927
  %t2929 = call ptr @__olang_scope_alloc(ptr %s101, i64 %t2928)
  call void @olang_textcopy(ptr %t2929, ptr %t2912, i64 %t2913)
  %t2930 = getelementptr i8, ptr %t2929, i64 %t2913
  call void @olang_textcopy(ptr %t2930, ptr %t2915, i64 %t2916)
  %t2931 = getelementptr i8, ptr %t2930, i64 %t2916
  call void @olang_textcopy(ptr %t2931, ptr %t2919, i64 %t2920)
  %t2932 = getelementptr i8, ptr %t2931, i64 %t2920
  call void @olang_textcopy(ptr %t2932, ptr %t2922, i64 %t2923)
  %t2933 = getelementptr i8, ptr %t2932, i64 %t2923
  call void @olang_textcopy(ptr %t2933, ptr %t2926, i64 %t2927)
  %t2934 = insertvalue { i64, ptr } undef, i64 %t2928, 0
  %t2935 = insertvalue { i64, ptr } %t2934, ptr %t2929, 1
  %t2937 = extractvalue { i64, ptr } %t2935, 0
  %t2938 = extractvalue { i64, ptr } %t2935, 1
  %t2939 = mul i64 %t2937, 1
  %t2940 = call ptr @__olang_scope_alloc(ptr %s101, i64 %t2939)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2940, ptr %t2938, i64 %t2939, i1 false)
  %t2941 = insertvalue { i64, ptr } undef, i64 %t2937, 0
  %t2942 = insertvalue { i64, ptr } %t2941, ptr %t2940, 1
  %t2943 = load ptr, ptr %l763, !tbaa !29
  %t2945 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s101, ptr %s101, ptr %t2943, { i64, ptr } %t2942)
  store { i64, ptr } %t2945, ptr %l779
  br label %bb401
bb401:
  %t2946 = load { i64, ptr }, ptr %l779, !tbaa !27
  store { i64, ptr } %t2946, ptr %l53, !tbaa !27
  %t2947 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2947, ptr %l780, !tbaa !29
  %t2948 = load ptr, ptr %l0, !tbaa !29
  %t2949 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t2950 = load ptr, ptr %lp11
  %t2951 = load { i64, ptr }, ptr %t2950, !tbaa !27
  %t2952 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d373, i32 0, i32 1) }, 1
  %t2953 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d373, i32 0, i32 1) }, 0
  %t2955 = extractvalue { i64, ptr } %t2949, 1
  %t2956 = extractvalue { i64, ptr } %t2949, 0
  %t2957 = add i64 %t2953, %t2956
  %t2958 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d374, i32 0, i32 1) }, 1
  %t2959 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d374, i32 0, i32 1) }, 0
  %t2960 = add i64 %t2957, %t2959
  %t2962 = extractvalue { i64, ptr } %t2951, 1
  %t2963 = extractvalue { i64, ptr } %t2951, 0
  %t2964 = add i64 %t2960, %t2963
  %t2965 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d375, i32 0, i32 1) }, 1
  %t2966 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d375, i32 0, i32 1) }, 0
  %t2967 = add i64 %t2964, %t2966
  %t2968 = call ptr @__olang_scope_alloc(ptr %s101, i64 %t2967)
  call void @olang_textcopy(ptr %t2968, ptr %t2952, i64 %t2953)
  %t2969 = getelementptr i8, ptr %t2968, i64 %t2953
  call void @olang_textcopy(ptr %t2969, ptr %t2955, i64 %t2956)
  %t2970 = getelementptr i8, ptr %t2969, i64 %t2956
  call void @olang_textcopy(ptr %t2970, ptr %t2958, i64 %t2959)
  %t2971 = getelementptr i8, ptr %t2970, i64 %t2959
  call void @olang_textcopy(ptr %t2971, ptr %t2962, i64 %t2963)
  %t2972 = getelementptr i8, ptr %t2971, i64 %t2963
  call void @olang_textcopy(ptr %t2972, ptr %t2965, i64 %t2966)
  %t2973 = insertvalue { i64, ptr } undef, i64 %t2967, 0
  %t2974 = insertvalue { i64, ptr } %t2973, ptr %t2968, 1
  %t2976 = extractvalue { i64, ptr } %t2974, 0
  %t2977 = extractvalue { i64, ptr } %t2974, 1
  %t2978 = mul i64 %t2976, 1
  %t2979 = call ptr @__olang_scope_alloc(ptr %s101, i64 %t2978)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2979, ptr %t2977, i64 %t2978, i1 false)
  %t2980 = insertvalue { i64, ptr } undef, i64 %t2976, 0
  %t2981 = insertvalue { i64, ptr } %t2980, ptr %t2979, 1
  %t2984 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s101, ptr %s101, ptr %t2948, { i64, ptr } %t2981)
  store { i64, ptr } %t2984, ptr %l786
  br label %bb402
bb402:
  %t2985 = load ptr, ptr %l0, !tbaa !29
  %t2986 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t2987 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t2988 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d376, i32 0, i32 1) }, 1
  %t2989 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d376, i32 0, i32 1) }, 0
  %t2991 = extractvalue { i64, ptr } %t2986, 1
  %t2992 = extractvalue { i64, ptr } %t2986, 0
  %t2993 = add i64 %t2989, %t2992
  %t2994 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d377, i32 0, i32 1) }, 1
  %t2995 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d377, i32 0, i32 1) }, 0
  %t2996 = add i64 %t2993, %t2995
  %t2998 = extractvalue { i64, ptr } %t2987, 1
  %t2999 = extractvalue { i64, ptr } %t2987, 0
  %t3000 = add i64 %t2996, %t2999
  %t3001 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d378, i32 0, i32 1) }, 1
  %t3002 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d378, i32 0, i32 1) }, 0
  %t3003 = add i64 %t3000, %t3002
  %t3004 = call ptr @__olang_scope_alloc(ptr %s101, i64 %t3003)
  call void @olang_textcopy(ptr %t3004, ptr %t2988, i64 %t2989)
  %t3005 = getelementptr i8, ptr %t3004, i64 %t2989
  call void @olang_textcopy(ptr %t3005, ptr %t2991, i64 %t2992)
  %t3006 = getelementptr i8, ptr %t3005, i64 %t2992
  call void @olang_textcopy(ptr %t3006, ptr %t2994, i64 %t2995)
  %t3007 = getelementptr i8, ptr %t3006, i64 %t2995
  call void @olang_textcopy(ptr %t3007, ptr %t2998, i64 %t2999)
  %t3008 = getelementptr i8, ptr %t3007, i64 %t2999
  call void @olang_textcopy(ptr %t3008, ptr %t3001, i64 %t3002)
  %t3009 = insertvalue { i64, ptr } undef, i64 %t3003, 0
  %t3010 = insertvalue { i64, ptr } %t3009, ptr %t3004, 1
  %t3012 = extractvalue { i64, ptr } %t3010, 0
  %t3013 = extractvalue { i64, ptr } %t3010, 1
  %t3014 = mul i64 %t3012, 1
  %t3015 = call ptr @__olang_scope_alloc(ptr %s101, i64 %t3014)
  call void @llvm.memcpy.p0.p0.i64(ptr %t3015, ptr %t3013, i64 %t3014, i1 false)
  %t3016 = insertvalue { i64, ptr } undef, i64 %t3012, 0
  %t3017 = insertvalue { i64, ptr } %t3016, ptr %t3015, 1
  %t3020 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s101, ptr %s101, ptr %t2985, { i64, ptr } %t3017)
  store { i64, ptr } %t3020, ptr %l792
  br label %bb403
bb403:
  %t3021 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d379, i32 0, i32 1) }, 1
  %t3022 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d379, i32 0, i32 1) }, 0
  %t3023 = load { i64, ptr }, ptr %l786, !tbaa !27
  %t3024 = extractvalue { i64, ptr } %t3023, 1
  %t3025 = extractvalue { i64, ptr } %t3023, 0
  %t3026 = add i64 %t3022, %t3025
  %t3027 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d380, i32 0, i32 1) }, 1
  %t3028 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d380, i32 0, i32 1) }, 0
  %t3029 = add i64 %t3026, %t3028
  %t3030 = load { i64, ptr }, ptr %l792, !tbaa !27
  %t3031 = extractvalue { i64, ptr } %t3030, 1
  %t3032 = extractvalue { i64, ptr } %t3030, 0
  %t3033 = add i64 %t3029, %t3032
  %t3034 = call ptr @__olang_scope_alloc(ptr %s101, i64 %t3033)
  call void @olang_textcopy(ptr %t3034, ptr %t3021, i64 %t3022)
  %t3035 = getelementptr i8, ptr %t3034, i64 %t3022
  call void @olang_textcopy(ptr %t3035, ptr %t3024, i64 %t3025)
  %t3036 = getelementptr i8, ptr %t3035, i64 %t3025
  call void @olang_textcopy(ptr %t3036, ptr %t3027, i64 %t3028)
  %t3037 = getelementptr i8, ptr %t3036, i64 %t3028
  call void @olang_textcopy(ptr %t3037, ptr %t3031, i64 %t3032)
  %t3038 = insertvalue { i64, ptr } undef, i64 %t3033, 0
  %t3039 = insertvalue { i64, ptr } %t3038, ptr %t3034, 1
  %t3041 = extractvalue { i64, ptr } %t3039, 0
  %t3042 = extractvalue { i64, ptr } %t3039, 1
  %t3043 = mul i64 %t3041, 1
  %t3044 = call ptr @__olang_scope_alloc(ptr %s101, i64 %t3043)
  call void @llvm.memcpy.p0.p0.i64(ptr %t3044, ptr %t3042, i64 %t3043, i1 false)
  %t3045 = insertvalue { i64, ptr } undef, i64 %t3041, 0
  %t3046 = insertvalue { i64, ptr } %t3045, ptr %t3044, 1
  %t3047 = load ptr, ptr %l780, !tbaa !29
  %t3049 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s101, ptr %s101, ptr %t3047, { i64, ptr } %t3046)
  store { i64, ptr } %t3049, ptr %l795
  br label %bb404
bb404:
  %t3050 = load { i64, ptr }, ptr %l795, !tbaa !27
  %t3051 = load ptr, ptr %l0, !tbaa !29
  %t3052 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t3054 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d381, i32 0, i32 1) }, 1
  %t3055 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d381, i32 0, i32 1) }, 0
  %t3057 = extractvalue { i64, ptr } %t3052, 1
  %t3058 = extractvalue { i64, ptr } %t3052, 0
  %t3059 = add i64 %t3055, %t3058
  %t3060 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d382, i32 0, i32 1) }, 1
  %t3061 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d382, i32 0, i32 1) }, 0
  %t3062 = add i64 %t3059, %t3061
  %t3064 = extractvalue { i64, ptr } %t3050, 1
  %t3065 = extractvalue { i64, ptr } %t3050, 0
  %t3066 = add i64 %t3062, %t3065
  %t3067 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t3066)
  call void @olang_textcopy(ptr %t3067, ptr %t3054, i64 %t3055)
  %t3068 = getelementptr i8, ptr %t3067, i64 %t3055
  call void @olang_textcopy(ptr %t3068, ptr %t3057, i64 %t3058)
  %t3069 = getelementptr i8, ptr %t3068, i64 %t3058
  call void @olang_textcopy(ptr %t3069, ptr %t3060, i64 %t3061)
  %t3070 = getelementptr i8, ptr %t3069, i64 %t3061
  call void @olang_textcopy(ptr %t3070, ptr %t3064, i64 %t3065)
  %t3071 = insertvalue { i64, ptr } undef, i64 %t3066, 0
  %t3072 = insertvalue { i64, ptr } %t3071, ptr %t3067, 1
  %t3074 = extractvalue { i64, ptr } %t3072, 0
  %t3075 = extractvalue { i64, ptr } %t3072, 1
  %t3076 = mul i64 %t3074, 1
  %t3077 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t3076)
  call void @llvm.memcpy.p0.p0.i64(ptr %t3077, ptr %t3075, i64 %t3076, i1 false)
  %t3078 = insertvalue { i64, ptr } undef, i64 %t3074, 0
  %t3079 = insertvalue { i64, ptr } %t3078, ptr %t3077, 1
  %t3082 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t3051, { i64, ptr } %t3079)
  store { i64, ptr } %t3082, ptr %l801
  br label %bb405
bb405:
  call void @__olang_scope_close(ptr %s101)
  call void @__olang_scope_close(ptr %s100)
  call void @__olang_scope_close(ptr %s0)
  %t3083 = load { i64, ptr }, ptr %l801, !tbaa !27
  store { i64, ptr } %t3083, ptr %rv
  br label %ret
bb406:
  %t3084 = load ptr, ptr %l0, !tbaa !29
  %t3085 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t3086 = load ptr, ptr %lp11
  %t3087 = load { i64, ptr }, ptr %t3086, !tbaa !27
  %t3088 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t3089 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d383, i32 0, i32 1) }, 1
  %t3090 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d383, i32 0, i32 1) }, 0
  %t3092 = extractvalue { i64, ptr } %t3085, 1
  %t3093 = extractvalue { i64, ptr } %t3085, 0
  %t3094 = add i64 %t3090, %t3093
  %t3095 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d384, i32 0, i32 1) }, 1
  %t3096 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d384, i32 0, i32 1) }, 0
  %t3097 = add i64 %t3094, %t3096
  %t3099 = extractvalue { i64, ptr } %t3087, 1
  %t3100 = extractvalue { i64, ptr } %t3087, 0
  %t3101 = add i64 %t3097, %t3100
  %t3102 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d385, i32 0, i32 1) }, 1
  %t3103 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d385, i32 0, i32 1) }, 0
  %t3104 = add i64 %t3101, %t3103
  %t3106 = extractvalue { i64, ptr } %t3088, 1
  %t3107 = extractvalue { i64, ptr } %t3088, 0
  %t3108 = add i64 %t3104, %t3107
  %t3109 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t3108)
  call void @olang_textcopy(ptr %t3109, ptr %t3089, i64 %t3090)
  %t3110 = getelementptr i8, ptr %t3109, i64 %t3090
  call void @olang_textcopy(ptr %t3110, ptr %t3092, i64 %t3093)
  %t3111 = getelementptr i8, ptr %t3110, i64 %t3093
  call void @olang_textcopy(ptr %t3111, ptr %t3095, i64 %t3096)
  %t3112 = getelementptr i8, ptr %t3111, i64 %t3096
  call void @olang_textcopy(ptr %t3112, ptr %t3099, i64 %t3100)
  %t3113 = getelementptr i8, ptr %t3112, i64 %t3100
  call void @olang_textcopy(ptr %t3113, ptr %t3102, i64 %t3103)
  %t3114 = getelementptr i8, ptr %t3113, i64 %t3103
  call void @olang_textcopy(ptr %t3114, ptr %t3106, i64 %t3107)
  %t3115 = insertvalue { i64, ptr } undef, i64 %t3108, 0
  %t3116 = insertvalue { i64, ptr } %t3115, ptr %t3109, 1
  %t3118 = extractvalue { i64, ptr } %t3116, 0
  %t3119 = extractvalue { i64, ptr } %t3116, 1
  %t3120 = mul i64 %t3118, 1
  %t3121 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t3120)
  call void @llvm.memcpy.p0.p0.i64(ptr %t3121, ptr %t3119, i64 %t3120, i1 false)
  %t3122 = insertvalue { i64, ptr } undef, i64 %t3118, 0
  %t3123 = insertvalue { i64, ptr } %t3122, ptr %t3121, 1
  %t3126 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t3084, { i64, ptr } %t3123)
  store { i64, ptr } %t3126, ptr %l808
  br label %bb407
bb407:
  call void @__olang_scope_close(ptr %s100)
  call void @__olang_scope_close(ptr %s0)
  %t3127 = load { i64, ptr }, ptr %l808, !tbaa !27
  store { i64, ptr } %t3127, ptr %rv
  br label %ret
bb408:
  %t3128 = load i32, ptr %l1
  %t3130 = trunc i64 23 to i32
  %t3131 = icmp eq i32 %t3128, %t3130
  br i1 %t3131, label %bb409, label %bb410
bb409:
  br label %bb411
bb410:
  br label %bb420
bb411:
  store %olang.scope zeroinitializer, ptr %s110
  %t3133 = load ptr, ptr %l0, !tbaa !29
  %t3135 = getelementptr %"compiler/emit:fnEm", ptr %t3133, i32 0, i32 0
  %t3136 = load ptr, ptr %t3135, !tbaa !29
  %t3137 = load i32, ptr %l7, !tbaa !23
  %t3140 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eenumWords(ptr %v0, ptr %t3136, i32 %t3137)
  store i1 %t3140, ptr %l814
  br label %bb412
bb412:
  %t3141 = load i1, ptr %l814, !tbaa !21
  br i1 %t3141, label %bb413, label %bb414
bb413:
  store %olang.scope zeroinitializer, ptr %s111
  %t3142 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3142, ptr %l815, !tbaa !29
  %t3143 = load ptr, ptr %l0, !tbaa !29
  %t3144 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t3145 = load ptr, ptr %lp11
  %t3146 = load { i64, ptr }, ptr %t3145, !tbaa !27
  %t3147 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d386, i32 0, i32 1) }, 1
  %t3148 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d386, i32 0, i32 1) }, 0
  %t3150 = extractvalue { i64, ptr } %t3144, 1
  %t3151 = extractvalue { i64, ptr } %t3144, 0
  %t3152 = add i64 %t3148, %t3151
  %t3153 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d387, i32 0, i32 1) }, 1
  %t3154 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d387, i32 0, i32 1) }, 0
  %t3155 = add i64 %t3152, %t3154
  %t3157 = extractvalue { i64, ptr } %t3146, 1
  %t3158 = extractvalue { i64, ptr } %t3146, 0
  %t3159 = add i64 %t3155, %t3158
  %t3160 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d388, i32 0, i32 1) }, 1
  %t3161 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d388, i32 0, i32 1) }, 0
  %t3162 = add i64 %t3159, %t3161
  %t3163 = call ptr @__olang_scope_alloc(ptr %s111, i64 %t3162)
  call void @olang_textcopy(ptr %t3163, ptr %t3147, i64 %t3148)
  %t3164 = getelementptr i8, ptr %t3163, i64 %t3148
  call void @olang_textcopy(ptr %t3164, ptr %t3150, i64 %t3151)
  %t3165 = getelementptr i8, ptr %t3164, i64 %t3151
  call void @olang_textcopy(ptr %t3165, ptr %t3153, i64 %t3154)
  %t3166 = getelementptr i8, ptr %t3165, i64 %t3154
  call void @olang_textcopy(ptr %t3166, ptr %t3157, i64 %t3158)
  %t3167 = getelementptr i8, ptr %t3166, i64 %t3158
  call void @olang_textcopy(ptr %t3167, ptr %t3160, i64 %t3161)
  %t3168 = insertvalue { i64, ptr } undef, i64 %t3162, 0
  %t3169 = insertvalue { i64, ptr } %t3168, ptr %t3163, 1
  %t3171 = extractvalue { i64, ptr } %t3169, 0
  %t3172 = extractvalue { i64, ptr } %t3169, 1
  %t3173 = mul i64 %t3171, 1
  %t3174 = call ptr @__olang_scope_alloc(ptr %s111, i64 %t3173)
  call void @llvm.memcpy.p0.p0.i64(ptr %t3174, ptr %t3172, i64 %t3173, i1 false)
  %t3175 = insertvalue { i64, ptr } undef, i64 %t3171, 0
  %t3176 = insertvalue { i64, ptr } %t3175, ptr %t3174, 1
  %t3179 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s111, ptr %s111, ptr %t3143, { i64, ptr } %t3176)
  store { i64, ptr } %t3179, ptr %l821
  br label %bb415
bb414:
  br label %bb417
bb415:
  %t3180 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t3181 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d389, i32 0, i32 1) }, 1
  %t3182 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d389, i32 0, i32 1) }, 0
  %t3183 = load { i64, ptr }, ptr %l821, !tbaa !27
  %t3184 = extractvalue { i64, ptr } %t3183, 1
  %t3185 = extractvalue { i64, ptr } %t3183, 0
  %t3186 = add i64 %t3182, %t3185
  %t3187 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d390, i32 0, i32 1) }, 1
  %t3188 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d390, i32 0, i32 1) }, 0
  %t3189 = add i64 %t3186, %t3188
  %t3191 = extractvalue { i64, ptr } %t3180, 1
  %t3192 = extractvalue { i64, ptr } %t3180, 0
  %t3193 = add i64 %t3189, %t3192
  %t3194 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t3193)
  call void @olang_textcopy(ptr %t3194, ptr %t3181, i64 %t3182)
  %t3195 = getelementptr i8, ptr %t3194, i64 %t3182
  call void @olang_textcopy(ptr %t3195, ptr %t3184, i64 %t3185)
  %t3196 = getelementptr i8, ptr %t3195, i64 %t3185
  call void @olang_textcopy(ptr %t3196, ptr %t3187, i64 %t3188)
  %t3197 = getelementptr i8, ptr %t3196, i64 %t3188
  call void @olang_textcopy(ptr %t3197, ptr %t3191, i64 %t3192)
  %t3198 = insertvalue { i64, ptr } undef, i64 %t3193, 0
  %t3199 = insertvalue { i64, ptr } %t3198, ptr %t3194, 1
  %t3201 = extractvalue { i64, ptr } %t3199, 0
  %t3202 = extractvalue { i64, ptr } %t3199, 1
  %t3203 = mul i64 %t3201, 1
  %t3204 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t3203)
  call void @llvm.memcpy.p0.p0.i64(ptr %t3204, ptr %t3202, i64 %t3203, i1 false)
  %t3205 = insertvalue { i64, ptr } undef, i64 %t3201, 0
  %t3206 = insertvalue { i64, ptr } %t3205, ptr %t3204, 1
  %t3207 = load ptr, ptr %l815, !tbaa !29
  %t3209 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t3207, { i64, ptr } %t3206)
  store { i64, ptr } %t3209, ptr %l825
  br label %bb416
bb416:
  call void @__olang_scope_close(ptr %s111)
  call void @__olang_scope_close(ptr %s110)
  call void @__olang_scope_close(ptr %s0)
  %t3210 = load { i64, ptr }, ptr %l825, !tbaa !27
  store { i64, ptr } %t3210, ptr %rv
  br label %ret
bb417:
  %t3211 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3211, ptr %l826, !tbaa !29
  %t3212 = load ptr, ptr %lp11
  %t3213 = load { i64, ptr }, ptr %t3212, !tbaa !27
  store { i64, ptr } %t3213, ptr %l827, !tbaa !27
  %t3214 = load ptr, ptr %l0, !tbaa !29
  %t3215 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t3216 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d391, i32 0, i32 1) }, 1
  %t3217 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d391, i32 0, i32 1) }, 0
  %t3219 = extractvalue { i64, ptr } %t3215, 1
  %t3220 = extractvalue { i64, ptr } %t3215, 0
  %t3221 = add i64 %t3217, %t3220
  %t3222 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d392, i32 0, i32 1) }, 1
  %t3223 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d392, i32 0, i32 1) }, 0
  %t3224 = add i64 %t3221, %t3223
  %t3225 = call ptr @__olang_scope_alloc(ptr %s110, i64 %t3224)
  call void @olang_textcopy(ptr %t3225, ptr %t3216, i64 %t3217)
  %t3226 = getelementptr i8, ptr %t3225, i64 %t3217
  call void @olang_textcopy(ptr %t3226, ptr %t3219, i64 %t3220)
  %t3227 = getelementptr i8, ptr %t3226, i64 %t3220
  call void @olang_textcopy(ptr %t3227, ptr %t3222, i64 %t3223)
  %t3228 = insertvalue { i64, ptr } undef, i64 %t3224, 0
  %t3229 = insertvalue { i64, ptr } %t3228, ptr %t3225, 1
  %t3231 = extractvalue { i64, ptr } %t3229, 0
  %t3232 = extractvalue { i64, ptr } %t3229, 1
  %t3233 = mul i64 %t3231, 1
  %t3234 = call ptr @__olang_scope_alloc(ptr %s110, i64 %t3233)
  call void @llvm.memcpy.p0.p0.i64(ptr %t3234, ptr %t3232, i64 %t3233, i1 false)
  %t3235 = insertvalue { i64, ptr } undef, i64 %t3231, 0
  %t3236 = insertvalue { i64, ptr } %t3235, ptr %t3234, 1
  %t3239 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s110, ptr %s110, ptr %t3214, { i64, ptr } %t3236)
  store { i64, ptr } %t3239, ptr %l832
  br label %bb418
bb418:
  %t3240 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d393, i32 0, i32 1) }, 1
  %t3241 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d393, i32 0, i32 1) }, 0
  %t3242 = load { i64, ptr }, ptr %l827, !tbaa !27
  %t3243 = extractvalue { i64, ptr } %t3242, 1
  %t3244 = extractvalue { i64, ptr } %t3242, 0
  %t3245 = add i64 %t3241, %t3244
  %t3246 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d394, i32 0, i32 1) }, 1
  %t3247 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d394, i32 0, i32 1) }, 0
  %t3248 = add i64 %t3245, %t3247
  %t3249 = load { i64, ptr }, ptr %l832, !tbaa !27
  %t3250 = extractvalue { i64, ptr } %t3249, 1
  %t3251 = extractvalue { i64, ptr } %t3249, 0
  %t3252 = add i64 %t3248, %t3251
  %t3253 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t3252)
  call void @olang_textcopy(ptr %t3253, ptr %t3240, i64 %t3241)
  %t3254 = getelementptr i8, ptr %t3253, i64 %t3241
  call void @olang_textcopy(ptr %t3254, ptr %t3243, i64 %t3244)
  %t3255 = getelementptr i8, ptr %t3254, i64 %t3244
  call void @olang_textcopy(ptr %t3255, ptr %t3246, i64 %t3247)
  %t3256 = getelementptr i8, ptr %t3255, i64 %t3247
  call void @olang_textcopy(ptr %t3256, ptr %t3250, i64 %t3251)
  %t3257 = insertvalue { i64, ptr } undef, i64 %t3252, 0
  %t3258 = insertvalue { i64, ptr } %t3257, ptr %t3253, 1
  %t3260 = extractvalue { i64, ptr } %t3258, 0
  %t3261 = extractvalue { i64, ptr } %t3258, 1
  %t3262 = mul i64 %t3260, 1
  %t3263 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t3262)
  call void @llvm.memcpy.p0.p0.i64(ptr %t3263, ptr %t3261, i64 %t3262, i1 false)
  %t3264 = insertvalue { i64, ptr } undef, i64 %t3260, 0
  %t3265 = insertvalue { i64, ptr } %t3264, ptr %t3263, 1
  %t3266 = load ptr, ptr %l826, !tbaa !29
  %t3268 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t3266, { i64, ptr } %t3265)
  store { i64, ptr } %t3268, ptr %l835
  br label %bb419
bb419:
  call void @__olang_scope_close(ptr %s110)
  call void @__olang_scope_close(ptr %s0)
  %t3269 = load { i64, ptr }, ptr %l835, !tbaa !27
  store { i64, ptr } %t3269, ptr %rv
  br label %ret
bb420:
  %t3270 = load i32, ptr %l1
  %t3272 = trunc i64 25 to i32
  %t3273 = icmp eq i32 %t3270, %t3272
  br i1 %t3273, label %bb421, label %bb422
bb421:
  br label %bb423
bb422:
  br label %bb430
bb423:
  store %olang.scope zeroinitializer, ptr %s116
  %t3275 = load ptr, ptr %l4, !tbaa !29
  %t3276 = load i32, ptr %l7, !tbaa !23
  %t3279 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t3275, i32 %t3276)
  store i32 %t3279, ptr %l840
  br label %bb424
bb424:
  %t3280 = load i32, ptr %l840, !tbaa !23
  store i32 %t3280, ptr %l55, !tbaa !23
  %t3281 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3281, ptr %l841, !tbaa !29
  %t3282 = load ptr, ptr %l0, !tbaa !29
  %t3283 = load i32, ptr %l55, !tbaa !23
  %t3286 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s116, ptr %t3282, i32 %t3283)
  store { i64, ptr } %t3286, ptr %l844
  br label %bb425
bb425:
  %t3287 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3287, ptr %l845, !tbaa !29
  %t3288 = load ptr, ptr %l0, !tbaa !29
  %t3289 = load %"compiler/mir:Range", ptr %l3
  %t3292 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t3288, %"compiler/mir:Range" %t3289, i64 1)
  store { i64, [4 x i64] } %t3292, ptr %l848
  br label %bb426
bb426:
  %t3293 = load i32, ptr %l55, !tbaa !23
  %t3294 = load ptr, ptr %l845, !tbaa !29
  %t3295 = load { i64, [4 x i64] }, ptr %l848
  %t3297 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s116, ptr %t3294, { i64, [4 x i64] } %t3295, i32 %t3293)
  store { i64, ptr } %t3297, ptr %l850
  br label %bb427
bb427:
  %t3298 = load ptr, ptr %lp11
  %t3299 = load { i64, ptr }, ptr %t3298, !tbaa !27
  store { i64, ptr } %t3299, ptr %l851, !tbaa !27
  %t3300 = load ptr, ptr %l0, !tbaa !29
  %t3301 = load i32, ptr %l55, !tbaa !23
  %t3304 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t3300, i32 %t3301)
  store i64 %t3304, ptr %l854
  br label %bb428
bb428:
  %t3305 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d395, i32 0, i32 1) }, 1
  %t3306 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d395, i32 0, i32 1) }, 0
  %t3307 = load { i64, ptr }, ptr %l844, !tbaa !27
  %t3308 = extractvalue { i64, ptr } %t3307, 1
  %t3309 = extractvalue { i64, ptr } %t3307, 0
  %t3310 = add i64 %t3306, %t3309
  %t3311 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d396, i32 0, i32 1) }, 1
  %t3312 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d396, i32 0, i32 1) }, 0
  %t3313 = add i64 %t3310, %t3312
  %t3314 = load { i64, ptr }, ptr %l850, !tbaa !27
  %t3315 = extractvalue { i64, ptr } %t3314, 1
  %t3316 = extractvalue { i64, ptr } %t3314, 0
  %t3317 = add i64 %t3313, %t3316
  %t3318 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d397, i32 0, i32 1) }, 1
  %t3319 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d397, i32 0, i32 1) }, 0
  %t3320 = add i64 %t3317, %t3319
  %t3321 = load { i64, ptr }, ptr %l851, !tbaa !27
  %t3322 = extractvalue { i64, ptr } %t3321, 1
  %t3323 = extractvalue { i64, ptr } %t3321, 0
  %t3324 = add i64 %t3320, %t3323
  %t3325 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d398, i32 0, i32 1) }, 1
  %t3326 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d398, i32 0, i32 1) }, 0
  %t3327 = add i64 %t3324, %t3326
  %t3328 = load i64, ptr %l854, !tbaa !24
  %t3329 = call i64 @__olang_fmt_i64(ptr null, i64 %t3328)
  %t3330 = add i64 %t3327, %t3329
  %t3331 = call ptr @__olang_scope_alloc(ptr %s116, i64 %t3330)
  call void @olang_textcopy(ptr %t3331, ptr %t3305, i64 %t3306)
  %t3332 = getelementptr i8, ptr %t3331, i64 %t3306
  call void @olang_textcopy(ptr %t3332, ptr %t3308, i64 %t3309)
  %t3333 = getelementptr i8, ptr %t3332, i64 %t3309
  call void @olang_textcopy(ptr %t3333, ptr %t3311, i64 %t3312)
  %t3334 = getelementptr i8, ptr %t3333, i64 %t3312
  call void @olang_textcopy(ptr %t3334, ptr %t3315, i64 %t3316)
  %t3335 = getelementptr i8, ptr %t3334, i64 %t3316
  call void @olang_textcopy(ptr %t3335, ptr %t3318, i64 %t3319)
  %t3336 = getelementptr i8, ptr %t3335, i64 %t3319
  call void @olang_textcopy(ptr %t3336, ptr %t3322, i64 %t3323)
  %t3337 = getelementptr i8, ptr %t3336, i64 %t3323
  call void @olang_textcopy(ptr %t3337, ptr %t3325, i64 %t3326)
  %t3338 = getelementptr i8, ptr %t3337, i64 %t3326
  %t3339 = call i64 @__olang_fmt_i64(ptr %t3338, i64 %t3328)
  %t3340 = insertvalue { i64, ptr } undef, i64 %t3330, 0
  %t3341 = insertvalue { i64, ptr } %t3340, ptr %t3331, 1
  %t3343 = extractvalue { i64, ptr } %t3341, 0
  %t3344 = extractvalue { i64, ptr } %t3341, 1
  %t3345 = mul i64 %t3343, 1
  %t3346 = call ptr @__olang_scope_alloc(ptr %s116, i64 %t3345)
  call void @llvm.memcpy.p0.p0.i64(ptr %t3346, ptr %t3344, i64 %t3345, i1 false)
  %t3347 = insertvalue { i64, ptr } undef, i64 %t3343, 0
  %t3348 = insertvalue { i64, ptr } %t3347, ptr %t3346, 1
  %t3349 = load ptr, ptr %l841, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s116, ptr %t3349, { i64, ptr } %t3348)
  br label %bb429
bb429:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d399, i32 0, i32 1) }, ptr %l857, !tbaa !27
  %t3351 = load { i64, ptr }, ptr %l857, !tbaa !27
  store { i64, ptr } %t3351, ptr %l858, !tbaa !27
  %t3352 = load { i64, ptr }, ptr %l858, !tbaa !27
  %t3353 = extractvalue { i64, ptr } %t3352, 0
  store i64 %t3353, ptr %l859, !tbaa !24
  %t3354 = load i64, ptr %l859, !tbaa !24
  %t3355 = mul i64 %t3354, 1
  %t3356 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t3355)
  %t3357 = insertvalue { i64, ptr } undef, i64 %t3354, 0
  %t3358 = insertvalue { i64, ptr } %t3357, ptr %t3356, 1
  store { i64, ptr } %t3358, ptr %l860, !tbaa !27
  %t3359 = getelementptr { i64, ptr }, ptr %l860, i32 0, i32 1
  %t3360 = load ptr, ptr %t3359, !tbaa !27
  %t3361 = getelementptr { i64, ptr }, ptr %l858, i32 0, i32 1
  %t3362 = load ptr, ptr %t3361, !tbaa !27
  %t3363 = load i64, ptr %l859, !tbaa !24
  %t3364 = mul i64 %t3363, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t3360, ptr %t3362, i64 %t3364, i1 false)
  %t3365 = load { i64, ptr }, ptr %l860, !tbaa !27
  store { i64, ptr } %t3365, ptr %l858, !tbaa !27
  call void @__olang_scope_close(ptr %s116)
  call void @__olang_scope_close(ptr %s0)
  %t3366 = load { i64, ptr }, ptr %l858, !tbaa !27
  store { i64, ptr } %t3366, ptr %rv
  br label %ret
bb430:
  %t3367 = load i32, ptr %l1
  %t3369 = trunc i64 26 to i32
  %t3370 = icmp eq i32 %t3367, %t3369
  br i1 %t3370, label %bb431, label %bb432
bb431:
  br label %bb435
bb432:
  %t3372 = load i32, ptr %l1
  %t3374 = trunc i64 27 to i32
  %t3375 = icmp eq i32 %t3372, %t3374
  br i1 %t3375, label %bb433, label %bb434
bb433:
  br label %bb435
bb434:
  br label %bb444
bb435:
  store %olang.scope zeroinitializer, ptr %s118
  %t3377 = load ptr, ptr %l4, !tbaa !29
  %t3378 = load i32, ptr %l7, !tbaa !23
  %t3381 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t3377, i32 %t3378)
  store i32 %t3381, ptr %l867
  br label %bb436
bb436:
  %t3382 = load i32, ptr %l867, !tbaa !23
  store i32 %t3382, ptr %l56, !tbaa !23
  %t3383 = load i32, ptr %l1
  %t3385 = trunc i64 26 to i32
  %t3386 = icmp eq i32 %t3383, %t3385
  br i1 %t3386, label %bb437, label %bb438
bb437:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d400, i32 0, i32 1) }, ptr %l870, !tbaa !27
  br label %bb439
bb438:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d401, i32 0, i32 1) }, ptr %l870, !tbaa !27
  br label %bb439
bb439:
  %t3388 = load { i64, ptr }, ptr %l870, !tbaa !27
  %t3389 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3389, ptr %l871, !tbaa !29
  store { i64, ptr } %t3388, ptr %l872, !tbaa !27
  %t3391 = load ptr, ptr %lp11
  %t3392 = load { i64, ptr }, ptr %t3391, !tbaa !27
  store { i64, ptr } %t3392, ptr %l873, !tbaa !27
  %t3393 = load ptr, ptr %l0, !tbaa !29
  %t3394 = load i32, ptr %l56, !tbaa !23
  %t3397 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s118, ptr %t3393, i32 %t3394)
  store { i64, ptr } %t3397, ptr %l876
  br label %bb440
bb440:
  %t3398 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3398, ptr %l877, !tbaa !29
  %t3399 = load ptr, ptr %l0, !tbaa !29
  %t3400 = load %"compiler/mir:Range", ptr %l3
  %t3403 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t3399, %"compiler/mir:Range" %t3400, i64 1)
  store { i64, [4 x i64] } %t3403, ptr %l880
  br label %bb441
bb441:
  %t3404 = load i32, ptr %l56, !tbaa !23
  %t3405 = load ptr, ptr %l877, !tbaa !29
  %t3406 = load { i64, [4 x i64] }, ptr %l880
  %t3408 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s118, ptr %t3405, { i64, [4 x i64] } %t3406, i32 %t3404)
  store { i64, ptr } %t3408, ptr %l882
  br label %bb442
bb442:
  %t3409 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d402, i32 0, i32 1) }, 1
  %t3410 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d402, i32 0, i32 1) }, 0
  %t3411 = load { i64, ptr }, ptr %l872, !tbaa !27
  %t3412 = extractvalue { i64, ptr } %t3411, 1
  %t3413 = extractvalue { i64, ptr } %t3411, 0
  %t3414 = add i64 %t3410, %t3413
  %t3415 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d403, i32 0, i32 1) }, 1
  %t3416 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d403, i32 0, i32 1) }, 0
  %t3417 = add i64 %t3414, %t3416
  %t3418 = load { i64, ptr }, ptr %l873, !tbaa !27
  %t3419 = extractvalue { i64, ptr } %t3418, 1
  %t3420 = extractvalue { i64, ptr } %t3418, 0
  %t3421 = add i64 %t3417, %t3420
  %t3422 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d404, i32 0, i32 1) }, 1
  %t3423 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d404, i32 0, i32 1) }, 0
  %t3424 = add i64 %t3421, %t3423
  %t3425 = load { i64, ptr }, ptr %l876, !tbaa !27
  %t3426 = extractvalue { i64, ptr } %t3425, 1
  %t3427 = extractvalue { i64, ptr } %t3425, 0
  %t3428 = add i64 %t3424, %t3427
  %t3429 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d405, i32 0, i32 1) }, 1
  %t3430 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d405, i32 0, i32 1) }, 0
  %t3431 = add i64 %t3428, %t3430
  %t3432 = load { i64, ptr }, ptr %l882, !tbaa !27
  %t3433 = extractvalue { i64, ptr } %t3432, 1
  %t3434 = extractvalue { i64, ptr } %t3432, 0
  %t3435 = add i64 %t3431, %t3434
  %t3436 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d406, i32 0, i32 1) }, 1
  %t3437 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d406, i32 0, i32 1) }, 0
  %t3438 = add i64 %t3435, %t3437
  %t3439 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t3438)
  call void @olang_textcopy(ptr %t3439, ptr %t3409, i64 %t3410)
  %t3440 = getelementptr i8, ptr %t3439, i64 %t3410
  call void @olang_textcopy(ptr %t3440, ptr %t3412, i64 %t3413)
  %t3441 = getelementptr i8, ptr %t3440, i64 %t3413
  call void @olang_textcopy(ptr %t3441, ptr %t3415, i64 %t3416)
  %t3442 = getelementptr i8, ptr %t3441, i64 %t3416
  call void @olang_textcopy(ptr %t3442, ptr %t3419, i64 %t3420)
  %t3443 = getelementptr i8, ptr %t3442, i64 %t3420
  call void @olang_textcopy(ptr %t3443, ptr %t3422, i64 %t3423)
  %t3444 = getelementptr i8, ptr %t3443, i64 %t3423
  call void @olang_textcopy(ptr %t3444, ptr %t3426, i64 %t3427)
  %t3445 = getelementptr i8, ptr %t3444, i64 %t3427
  call void @olang_textcopy(ptr %t3445, ptr %t3429, i64 %t3430)
  %t3446 = getelementptr i8, ptr %t3445, i64 %t3430
  call void @olang_textcopy(ptr %t3446, ptr %t3433, i64 %t3434)
  %t3447 = getelementptr i8, ptr %t3446, i64 %t3434
  call void @olang_textcopy(ptr %t3447, ptr %t3436, i64 %t3437)
  %t3448 = insertvalue { i64, ptr } undef, i64 %t3438, 0
  %t3449 = insertvalue { i64, ptr } %t3448, ptr %t3439, 1
  %t3451 = extractvalue { i64, ptr } %t3449, 0
  %t3452 = extractvalue { i64, ptr } %t3449, 1
  %t3453 = mul i64 %t3451, 1
  %t3454 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t3453)
  call void @llvm.memcpy.p0.p0.i64(ptr %t3454, ptr %t3452, i64 %t3453, i1 false)
  %t3455 = insertvalue { i64, ptr } undef, i64 %t3451, 0
  %t3456 = insertvalue { i64, ptr } %t3455, ptr %t3454, 1
  %t3457 = load ptr, ptr %l871, !tbaa !29
  %t3459 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t3457, { i64, ptr } %t3456)
  store { i64, ptr } %t3459, ptr %l885
  br label %bb443
bb443:
  call void @__olang_scope_close(ptr %s118)
  call void @__olang_scope_close(ptr %s0)
  %t3460 = load { i64, ptr }, ptr %l885, !tbaa !27
  store { i64, ptr } %t3460, ptr %rv
  br label %ret
bb444:
  %t3461 = load i32, ptr %l1
  %t3463 = trunc i64 28 to i32
  %t3464 = icmp eq i32 %t3461, %t3463
  br i1 %t3464, label %bb445, label %bb446
bb445:
  br label %bb447
bb446:
  br label %bb456
bb447:
  store %olang.scope zeroinitializer, ptr %s120
  %t3466 = load ptr, ptr %l4, !tbaa !29
  %t3467 = load i32, ptr %l7, !tbaa !23
  %t3470 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t3466, i32 %t3467)
  store i32 %t3470, ptr %l890
  br label %bb448
bb448:
  %t3471 = load i32, ptr %l890, !tbaa !23
  store i32 %t3471, ptr %l58, !tbaa !23
  %t3472 = load ptr, ptr %l0, !tbaa !29
  %t3473 = load i32, ptr %l58, !tbaa !23
  %t3476 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s120, ptr %t3472, i32 %t3473)
  store { i64, ptr } %t3476, ptr %l893
  br label %bb449
bb449:
  %t3477 = load { i64, ptr }, ptr %l893, !tbaa !27
  store { i64, ptr } %t3477, ptr %l59, !tbaa !27
  %t3478 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3478, ptr %l894, !tbaa !29
  %t3479 = load ptr, ptr %lp11
  %t3480 = load { i64, ptr }, ptr %t3479, !tbaa !27
  store { i64, ptr } %t3480, ptr %l895, !tbaa !27
  %t3481 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t3481, ptr %l896, !tbaa !27
  %t3482 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3482, ptr %l897, !tbaa !29
  %t3483 = load ptr, ptr %l0, !tbaa !29
  %t3484 = load %"compiler/mir:Range", ptr %l3
  %t3487 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t3483, %"compiler/mir:Range" %t3484, i64 1)
  store { i64, [4 x i64] } %t3487, ptr %l900
  br label %bb450
bb450:
  %t3488 = load i32, ptr %l58, !tbaa !23
  %t3489 = load ptr, ptr %l897, !tbaa !29
  %t3490 = load { i64, [4 x i64] }, ptr %l900
  %t3492 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s120, ptr %t3489, { i64, [4 x i64] } %t3490, i32 %t3488)
  store { i64, ptr } %t3492, ptr %l902
  br label %bb451
bb451:
  %t3493 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t3493, ptr %l903, !tbaa !27
  %t3494 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3494, ptr %l904, !tbaa !29
  %t3495 = load ptr, ptr %l0, !tbaa !29
  %t3496 = load %"compiler/mir:Range", ptr %l3
  %t3499 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t3495, %"compiler/mir:Range" %t3496, i64 2)
  store { i64, [4 x i64] } %t3499, ptr %l907
  br label %bb452
bb452:
  %t3500 = load i32, ptr %l58, !tbaa !23
  %t3501 = load ptr, ptr %l904, !tbaa !29
  %t3502 = load { i64, [4 x i64] }, ptr %l907
  %t3504 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s120, ptr %t3501, { i64, [4 x i64] } %t3502, i32 %t3500)
  store { i64, ptr } %t3504, ptr %l909
  br label %bb453
bb453:
  %t3505 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d407, i32 0, i32 1) }, 1
  %t3506 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d407, i32 0, i32 1) }, 0
  %t3507 = load { i64, ptr }, ptr %l895, !tbaa !27
  %t3508 = extractvalue { i64, ptr } %t3507, 1
  %t3509 = extractvalue { i64, ptr } %t3507, 0
  %t3510 = add i64 %t3506, %t3509
  %t3511 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d408, i32 0, i32 1) }, 1
  %t3512 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d408, i32 0, i32 1) }, 0
  %t3513 = add i64 %t3510, %t3512
  %t3514 = load { i64, ptr }, ptr %l896, !tbaa !27
  %t3515 = extractvalue { i64, ptr } %t3514, 1
  %t3516 = extractvalue { i64, ptr } %t3514, 0
  %t3517 = add i64 %t3513, %t3516
  %t3518 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d409, i32 0, i32 1) }, 1
  %t3519 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d409, i32 0, i32 1) }, 0
  %t3520 = add i64 %t3517, %t3519
  %t3521 = load { i64, ptr }, ptr %l902, !tbaa !27
  %t3522 = extractvalue { i64, ptr } %t3521, 1
  %t3523 = extractvalue { i64, ptr } %t3521, 0
  %t3524 = add i64 %t3520, %t3523
  %t3525 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d408, i32 0, i32 1) }, 1
  %t3526 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d408, i32 0, i32 1) }, 0
  %t3527 = add i64 %t3524, %t3526
  %t3528 = load { i64, ptr }, ptr %l903, !tbaa !27
  %t3529 = extractvalue { i64, ptr } %t3528, 1
  %t3530 = extractvalue { i64, ptr } %t3528, 0
  %t3531 = add i64 %t3527, %t3530
  %t3532 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d409, i32 0, i32 1) }, 1
  %t3533 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d409, i32 0, i32 1) }, 0
  %t3534 = add i64 %t3531, %t3533
  %t3535 = load { i64, ptr }, ptr %l909, !tbaa !27
  %t3536 = extractvalue { i64, ptr } %t3535, 1
  %t3537 = extractvalue { i64, ptr } %t3535, 0
  %t3538 = add i64 %t3534, %t3537
  %t3539 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d410, i32 0, i32 1) }, 1
  %t3540 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d410, i32 0, i32 1) }, 0
  %t3541 = add i64 %t3538, %t3540
  %t3542 = call ptr @__olang_scope_alloc(ptr %s120, i64 %t3541)
  call void @olang_textcopy(ptr %t3542, ptr %t3505, i64 %t3506)
  %t3543 = getelementptr i8, ptr %t3542, i64 %t3506
  call void @olang_textcopy(ptr %t3543, ptr %t3508, i64 %t3509)
  %t3544 = getelementptr i8, ptr %t3543, i64 %t3509
  call void @olang_textcopy(ptr %t3544, ptr %t3511, i64 %t3512)
  %t3545 = getelementptr i8, ptr %t3544, i64 %t3512
  call void @olang_textcopy(ptr %t3545, ptr %t3515, i64 %t3516)
  %t3546 = getelementptr i8, ptr %t3545, i64 %t3516
  call void @olang_textcopy(ptr %t3546, ptr %t3518, i64 %t3519)
  %t3547 = getelementptr i8, ptr %t3546, i64 %t3519
  call void @olang_textcopy(ptr %t3547, ptr %t3522, i64 %t3523)
  %t3548 = getelementptr i8, ptr %t3547, i64 %t3523
  call void @olang_textcopy(ptr %t3548, ptr %t3525, i64 %t3526)
  %t3549 = getelementptr i8, ptr %t3548, i64 %t3526
  call void @olang_textcopy(ptr %t3549, ptr %t3529, i64 %t3530)
  %t3550 = getelementptr i8, ptr %t3549, i64 %t3530
  call void @olang_textcopy(ptr %t3550, ptr %t3532, i64 %t3533)
  %t3551 = getelementptr i8, ptr %t3550, i64 %t3533
  call void @olang_textcopy(ptr %t3551, ptr %t3536, i64 %t3537)
  %t3552 = getelementptr i8, ptr %t3551, i64 %t3537
  call void @olang_textcopy(ptr %t3552, ptr %t3539, i64 %t3540)
  %t3553 = insertvalue { i64, ptr } undef, i64 %t3541, 0
  %t3554 = insertvalue { i64, ptr } %t3553, ptr %t3542, 1
  %t3556 = extractvalue { i64, ptr } %t3554, 0
  %t3557 = extractvalue { i64, ptr } %t3554, 1
  %t3558 = mul i64 %t3556, 1
  %t3559 = call ptr @__olang_scope_alloc(ptr %s120, i64 %t3558)
  call void @llvm.memcpy.p0.p0.i64(ptr %t3559, ptr %t3557, i64 %t3558, i1 false)
  %t3560 = insertvalue { i64, ptr } undef, i64 %t3556, 0
  %t3561 = insertvalue { i64, ptr } %t3560, ptr %t3559, 1
  %t3562 = load ptr, ptr %l894, !tbaa !29
  %t3564 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s120, ptr %s120, ptr %t3562, { i64, ptr } %t3561)
  store { i64, ptr } %t3564, ptr %l912
  br label %bb454
bb454:
  %t3565 = load { i64, ptr }, ptr %l912, !tbaa !27
  %t3566 = load ptr, ptr %l0, !tbaa !29
  %t3567 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t3569 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d411, i32 0, i32 1) }, 1
  %t3570 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d411, i32 0, i32 1) }, 0
  %t3572 = extractvalue { i64, ptr } %t3567, 1
  %t3573 = extractvalue { i64, ptr } %t3567, 0
  %t3574 = add i64 %t3570, %t3573
  %t3575 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d412, i32 0, i32 1) }, 1
  %t3576 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d412, i32 0, i32 1) }, 0
  %t3577 = add i64 %t3574, %t3576
  %t3579 = extractvalue { i64, ptr } %t3565, 1
  %t3580 = extractvalue { i64, ptr } %t3565, 0
  %t3581 = add i64 %t3577, %t3580
  %t3582 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d413, i32 0, i32 1) }, 1
  %t3583 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d413, i32 0, i32 1) }, 0
  %t3584 = add i64 %t3581, %t3583
  %t3585 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t3584)
  call void @olang_textcopy(ptr %t3585, ptr %t3569, i64 %t3570)
  %t3586 = getelementptr i8, ptr %t3585, i64 %t3570
  call void @olang_textcopy(ptr %t3586, ptr %t3572, i64 %t3573)
  %t3587 = getelementptr i8, ptr %t3586, i64 %t3573
  call void @olang_textcopy(ptr %t3587, ptr %t3575, i64 %t3576)
  %t3588 = getelementptr i8, ptr %t3587, i64 %t3576
  call void @olang_textcopy(ptr %t3588, ptr %t3579, i64 %t3580)
  %t3589 = getelementptr i8, ptr %t3588, i64 %t3580
  call void @olang_textcopy(ptr %t3589, ptr %t3582, i64 %t3583)
  %t3590 = insertvalue { i64, ptr } undef, i64 %t3584, 0
  %t3591 = insertvalue { i64, ptr } %t3590, ptr %t3585, 1
  %t3593 = extractvalue { i64, ptr } %t3591, 0
  %t3594 = extractvalue { i64, ptr } %t3591, 1
  %t3595 = mul i64 %t3593, 1
  %t3596 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t3595)
  call void @llvm.memcpy.p0.p0.i64(ptr %t3596, ptr %t3594, i64 %t3595, i1 false)
  %t3597 = insertvalue { i64, ptr } undef, i64 %t3593, 0
  %t3598 = insertvalue { i64, ptr } %t3597, ptr %t3596, 1
  %t3601 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t3566, { i64, ptr } %t3598)
  store { i64, ptr } %t3601, ptr %l918
  br label %bb455
bb455:
  call void @__olang_scope_close(ptr %s120)
  call void @__olang_scope_close(ptr %s0)
  %t3602 = load { i64, ptr }, ptr %l918, !tbaa !27
  store { i64, ptr } %t3602, ptr %rv
  br label %ret
bb456:
  br i1 true, label %bb457, label %bb458
bb457:
  br label %bb459
bb458:
  br label %bb462
bb459:
  store %olang.scope zeroinitializer, ptr %s123
  %t3603 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3603, ptr %l919, !tbaa !29
  %t3604 = load i32, ptr %l1
  store i32 %t3604, ptr %l920
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s124
  store ptr %s124room, ptr %s124
  %t3605 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d414, i32 0, i32 1) }, 1
  %t3606 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d414, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s124, ptr %t3605, i64 %t3606)
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s124, ptr %l920, i64 0)
  br label %bb460
bb460:
  %t3608 = load ptr, ptr %s124
  %t3609 = getelementptr %olang.builder, ptr %s124, i32 0, i32 1
  %t3610 = load i64, ptr %t3609
  %t3611 = call ptr @__olang_scope_alloc(ptr %s123, i64 %t3610)
  call void @olang_textcopy(ptr %t3611, ptr %t3608, i64 %t3610)
  %t3612 = insertvalue { i64, ptr } undef, i64 %t3610, 0
  %t3613 = insertvalue { i64, ptr } %t3612, ptr %t3611, 1
  store { i64, ptr } %t3613, ptr %l922, !tbaa !27
  %t3614 = getelementptr %olang.builder, ptr %s124, i32 0, i32 3
  %t3615 = load ptr, ptr %t3614
  %t3616 = icmp ne ptr %t3615, null
  br i1 %t3616, label %sbgrew.3617, label %sbdone.3618
sbgrew.3617:
  call void @__olang_sb_done(ptr %s124)
  br label %sbdone.3618
sbdone.3618:
  %t3619 = load { i64, ptr }, ptr %l922, !tbaa !27
  %t3620 = extractvalue { i64, ptr } %t3619, 0
  %t3621 = extractvalue { i64, ptr } %t3619, 1
  %t3622 = mul i64 %t3620, 1
  %t3623 = call ptr @__olang_scope_alloc(ptr %s123, i64 %t3622)
  call void @llvm.memcpy.p0.p0.i64(ptr %t3623, ptr %t3621, i64 %t3622, i1 false)
  %t3624 = insertvalue { i64, ptr } undef, i64 %t3620, 0
  %t3625 = insertvalue { i64, ptr } %t3624, ptr %t3623, 1
  %t3626 = load ptr, ptr %l919, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s123, ptr %t3626, { i64, ptr } %t3625)
  br label %bb461
bb461:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d415, i32 0, i32 1) }, ptr %l924, !tbaa !27
  %t3628 = load { i64, ptr }, ptr %l924, !tbaa !27
  store { i64, ptr } %t3628, ptr %l925, !tbaa !27
  %t3629 = load { i64, ptr }, ptr %l925, !tbaa !27
  %t3630 = extractvalue { i64, ptr } %t3629, 0
  store i64 %t3630, ptr %l926, !tbaa !24
  %t3631 = load i64, ptr %l926, !tbaa !24
  %t3632 = mul i64 %t3631, 1
  %t3633 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t3632)
  %t3634 = insertvalue { i64, ptr } undef, i64 %t3631, 0
  %t3635 = insertvalue { i64, ptr } %t3634, ptr %t3633, 1
  store { i64, ptr } %t3635, ptr %l927, !tbaa !27
  %t3636 = getelementptr { i64, ptr }, ptr %l927, i32 0, i32 1
  %t3637 = load ptr, ptr %t3636, !tbaa !27
  %t3638 = getelementptr { i64, ptr }, ptr %l925, i32 0, i32 1
  %t3639 = load ptr, ptr %t3638, !tbaa !27
  %t3640 = load i64, ptr %l926, !tbaa !24
  %t3641 = mul i64 %t3640, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t3637, ptr %t3639, i64 %t3641, i1 false)
  %t3642 = load { i64, ptr }, ptr %l927, !tbaa !27
  store { i64, ptr } %t3642, ptr %l925, !tbaa !27
  call void @__olang_scope_close(ptr %s123)
  call void @__olang_scope_close(ptr %s0)
  %t3643 = load { i64, ptr }, ptr %l925, !tbaa !27
  store { i64, ptr } %t3643, ptr %rv
  br label %ret
bb462:
  call void @__olang_check_failed(ptr @olang_loc_48fb755842b89882_1da88e591314daf6)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2equoted(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s0, ptr %t4, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d416, i32 0, i32 1) })
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/emit:fnEm", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s0, ptr %t9, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d417, i32 0, i32 1) })
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/emit:fnEm", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s0, ptr %t14, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d418, i32 0, i32 1) })
  br label %bb3
bb3:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t19 = load i64, ptr %l4, !tbaa !24
  %t20 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d419, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d419, i32 0, i32 1) }, 0
  %t23 = extractvalue { i64, ptr } %t17, 1
  %t24 = extractvalue { i64, ptr } %t17, 0
  %t25 = add i64 %t21, %t24
  %t26 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d420, i32 0, i32 1) }, 1
  %t27 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d420, i32 0, i32 1) }, 0
  %t28 = add i64 %t25, %t27
  %t30 = extractvalue { i64, ptr } %t18, 1
  %t31 = extractvalue { i64, ptr } %t18, 0
  %t32 = add i64 %t28, %t31
  %t33 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d421, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d421, i32 0, i32 1) }, 0
  %t35 = add i64 %t32, %t34
  %t37 = call i64 @__olang_fmt_i64(ptr null, i64 %t19)
  %t38 = add i64 %t35, %t37
  %t39 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d422, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d422, i32 0, i32 1) }, 0
  %t41 = add i64 %t38, %t40
  %t42 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t41)
  call void @olang_textcopy(ptr %t42, ptr %t20, i64 %t21)
  %t43 = getelementptr i8, ptr %t42, i64 %t21
  call void @olang_textcopy(ptr %t43, ptr %t23, i64 %t24)
  %t44 = getelementptr i8, ptr %t43, i64 %t24
  call void @olang_textcopy(ptr %t44, ptr %t26, i64 %t27)
  %t45 = getelementptr i8, ptr %t44, i64 %t27
  call void @olang_textcopy(ptr %t45, ptr %t30, i64 %t31)
  %t46 = getelementptr i8, ptr %t45, i64 %t31
  call void @olang_textcopy(ptr %t46, ptr %t33, i64 %t34)
  %t47 = getelementptr i8, ptr %t46, i64 %t34
  %t48 = call i64 @__olang_fmt_i64(ptr %t47, i64 %t19)
  %t49 = getelementptr i8, ptr %t47, i64 %t37
  call void @olang_textcopy(ptr %t49, ptr %t39, i64 %t40)
  %t50 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t42, 1
  %t53 = extractvalue { i64, ptr } %t51, 0
  %t54 = extractvalue { i64, ptr } %t51, 1
  %t55 = mul i64 %t53, 1
  %t56 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t55)
  call void @llvm.memcpy.p0.p0.i64(ptr %t56, ptr %t54, i64 %t55, i1 false)
  %t57 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  %t61 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t16, { i64, ptr } %t58)
  store { i64, ptr } %t61, ptr %l19
  br label %bb4
bb4:
  %t62 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t62, ptr %l5, !tbaa !27
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t66 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d423, i32 0, i32 1) }, 1
  %t67 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d423, i32 0, i32 1) }, 0
  %t69 = extractvalue { i64, ptr } %t64, 1
  %t70 = extractvalue { i64, ptr } %t64, 0
  %t71 = add i64 %t67, %t70
  %t72 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d424, i32 0, i32 1) }, 1
  %t73 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d424, i32 0, i32 1) }, 0
  %t74 = add i64 %t71, %t73
  %t76 = extractvalue { i64, ptr } %t65, 1
  %t77 = extractvalue { i64, ptr } %t65, 0
  %t78 = add i64 %t74, %t77
  %t79 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d425, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d425, i32 0, i32 1) }, 0
  %t81 = add i64 %t78, %t80
  %t82 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t81)
  call void @olang_textcopy(ptr %t82, ptr %t66, i64 %t67)
  %t83 = getelementptr i8, ptr %t82, i64 %t67
  call void @olang_textcopy(ptr %t83, ptr %t69, i64 %t70)
  %t84 = getelementptr i8, ptr %t83, i64 %t70
  call void @olang_textcopy(ptr %t84, ptr %t72, i64 %t73)
  %t85 = getelementptr i8, ptr %t84, i64 %t73
  call void @olang_textcopy(ptr %t85, ptr %t76, i64 %t77)
  %t86 = getelementptr i8, ptr %t85, i64 %t77
  call void @olang_textcopy(ptr %t86, ptr %t79, i64 %t80)
  %t87 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t82, 1
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t91 = extractvalue { i64, ptr } %t88, 1
  %t92 = mul i64 %t90, 1
  %t93 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t92)
  call void @llvm.memcpy.p0.p0.i64(ptr %t93, ptr %t91, i64 %t92, i1 false)
  %t94 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t93, 1
  %t98 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t63, { i64, ptr } %t95)
  store { i64, ptr } %t98, ptr %l25
  br label %bb5
bb5:
  %t99 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t104 = load i64, ptr %l4, !tbaa !24
  %t105 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d426, i32 0, i32 1) }, 1
  %t106 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d426, i32 0, i32 1) }, 0
  %t108 = extractvalue { i64, ptr } %t99, 1
  %t109 = extractvalue { i64, ptr } %t99, 0
  %t110 = add i64 %t106, %t109
  %t111 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d427, i32 0, i32 1) }, 1
  %t112 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d427, i32 0, i32 1) }, 0
  %t113 = add i64 %t110, %t112
  %t115 = extractvalue { i64, ptr } %t102, 1
  %t116 = extractvalue { i64, ptr } %t102, 0
  %t117 = add i64 %t113, %t116
  %t118 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d428, i32 0, i32 1) }, 1
  %t119 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d428, i32 0, i32 1) }, 0
  %t120 = add i64 %t117, %t119
  %t122 = extractvalue { i64, ptr } %t103, 1
  %t123 = extractvalue { i64, ptr } %t103, 0
  %t124 = add i64 %t120, %t123
  %t125 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d429, i32 0, i32 1) }, 1
  %t126 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d429, i32 0, i32 1) }, 0
  %t127 = add i64 %t124, %t126
  %t129 = call i64 @__olang_fmt_i64(ptr null, i64 %t104)
  %t130 = add i64 %t127, %t129
  %t131 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d430, i32 0, i32 1) }, 1
  %t132 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d430, i32 0, i32 1) }, 0
  %t133 = add i64 %t130, %t132
  %t134 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t133)
  call void @olang_textcopy(ptr %t134, ptr %t105, i64 %t106)
  %t135 = getelementptr i8, ptr %t134, i64 %t106
  call void @olang_textcopy(ptr %t135, ptr %t108, i64 %t109)
  %t136 = getelementptr i8, ptr %t135, i64 %t109
  call void @olang_textcopy(ptr %t136, ptr %t111, i64 %t112)
  %t137 = getelementptr i8, ptr %t136, i64 %t112
  call void @olang_textcopy(ptr %t137, ptr %t115, i64 %t116)
  %t138 = getelementptr i8, ptr %t137, i64 %t116
  call void @olang_textcopy(ptr %t138, ptr %t118, i64 %t119)
  %t139 = getelementptr i8, ptr %t138, i64 %t119
  call void @olang_textcopy(ptr %t139, ptr %t122, i64 %t123)
  %t140 = getelementptr i8, ptr %t139, i64 %t123
  call void @olang_textcopy(ptr %t140, ptr %t125, i64 %t126)
  %t141 = getelementptr i8, ptr %t140, i64 %t126
  %t142 = call i64 @__olang_fmt_i64(ptr %t141, i64 %t104)
  %t143 = getelementptr i8, ptr %t141, i64 %t129
  call void @olang_textcopy(ptr %t143, ptr %t131, i64 %t132)
  %t144 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t134, 1
  %t147 = extractvalue { i64, ptr } %t145, 0
  %t148 = extractvalue { i64, ptr } %t145, 1
  %t149 = mul i64 %t147, 1
  %t150 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t149)
  call void @llvm.memcpy.p0.p0.i64(ptr %t150, ptr %t148, i64 %t149, i1 false)
  %t151 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t150, 1
  %t155 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t100, { i64, ptr } %t152)
  store { i64, ptr } %t155, ptr %l33
  br label %bb6
bb6:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t158 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t159 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d431, i32 0, i32 1) }, 1
  %t160 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d431, i32 0, i32 1) }, 0
  %t162 = extractvalue { i64, ptr } %t157, 1
  %t163 = extractvalue { i64, ptr } %t157, 0
  %t164 = add i64 %t160, %t163
  %t165 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d432, i32 0, i32 1) }, 1
  %t166 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d432, i32 0, i32 1) }, 0
  %t167 = add i64 %t164, %t166
  %t169 = extractvalue { i64, ptr } %t158, 1
  %t170 = extractvalue { i64, ptr } %t158, 0
  %t171 = add i64 %t167, %t170
  %t172 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d433, i32 0, i32 1) }, 1
  %t173 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d433, i32 0, i32 1) }, 0
  %t174 = add i64 %t171, %t173
  %t175 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t174)
  call void @olang_textcopy(ptr %t175, ptr %t159, i64 %t160)
  %t176 = getelementptr i8, ptr %t175, i64 %t160
  call void @olang_textcopy(ptr %t176, ptr %t162, i64 %t163)
  %t177 = getelementptr i8, ptr %t176, i64 %t163
  call void @olang_textcopy(ptr %t177, ptr %t165, i64 %t166)
  %t178 = getelementptr i8, ptr %t177, i64 %t166
  call void @olang_textcopy(ptr %t178, ptr %t169, i64 %t170)
  %t179 = getelementptr i8, ptr %t178, i64 %t170
  call void @olang_textcopy(ptr %t179, ptr %t172, i64 %t173)
  %t180 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t181 = insertvalue { i64, ptr } %t180, ptr %t175, 1
  %t183 = extractvalue { i64, ptr } %t181, 0
  %t184 = extractvalue { i64, ptr } %t181, 1
  %t185 = mul i64 %t183, 1
  %t186 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t185)
  call void @llvm.memcpy.p0.p0.i64(ptr %t186, ptr %t184, i64 %t185, i1 false)
  %t187 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t186, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t156, { i64, ptr } %t188)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ervalue(ptr %v0, ptr %v1, ptr %a0, { i64, [15 x i64] } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [15 x i64] }
  %l3 = alloca ptr
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca %"compiler/mir:Place"
  %l6 = alloca i32
  %l7 = alloca %"compiler/mir:Place"
  %l8 = alloca { { i64, ptr }, i32 }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %lp11 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca %"compiler/mir:Range"
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca %"compiler/mir:Range"
  %l18 = alloca %"compiler/mir:Place"
  %l19 = alloca { { i64, ptr }, i32 }
  %l20 = alloca { i64, ptr }
  %l22 = alloca i32
  %l23 = alloca i64
  %l24 = alloca %"compiler/mir:Range"
  %l25 = alloca { i64, [1 x i64] }
  %l26 = alloca { i64, [4 x i64] }
  %l27 = alloca i32
  %l28 = alloca i32
  %lp29 = alloca ptr
  %l30 = alloca { i64, ptr }
  %lp31 = alloca ptr
  %l32 = alloca { i64, [1 x i64] }
  %l33 = alloca i32
  %l34 = alloca { i64, [4 x i64] }
  %l35 = alloca { i64, [4 x i64] }
  %l36 = alloca %"compiler/mir:Place"
  %l37 = alloca { i64, [4 x i64] }
  %l38 = alloca { i64, [4 x i64] }
  %l39 = alloca i32
  %l40 = alloca { i64, [2 x i64] }
  %l41 = alloca i32
  %l42 = alloca { i64, [1 x i64] }
  %l43 = alloca %"compiler/mir:Range"
  %l44 = alloca %"compiler/mir:Range"
  %l45 = alloca { i64, [4 x i64] }
  %l46 = alloca i32
  %l47 = alloca i32
  %l48 = alloca { i64, [1 x i64] }
  %l49 = alloca { i64, [1 x i64] }
  %l50 = alloca i32
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca { i64, [1 x i64] }
  %l57 = alloca { i64, [4 x i64] }
  %l58 = alloca { i64, [1 x i64] }
  %l70 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l84 = alloca { { i64, ptr }, i32 }
  %l85 = alloca { i64, ptr }
  %l86 = alloca i64
  %l87 = alloca { i64, ptr }
  %l89 = alloca ptr
  %l92 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l96 = alloca ptr
  %l99 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l117 = alloca { i64, ptr }
  %l127 = alloca { i64, ptr }
  %l133 = alloca { { i64, ptr }, i32 }
  %l134 = alloca { i64, ptr }
  %l135 = alloca i64
  %l136 = alloca { i64, ptr }
  %l141 = alloca i1
  %l144 = alloca { i64, ptr }
  %l145 = alloca ptr
  %l148 = alloca { i64, ptr }
  %l151 = alloca { i64, ptr }
  %l161 = alloca { i64, ptr }
  %l167 = alloca ptr
  %l170 = alloca i32
  %l171 = alloca i32
  %l174 = alloca i1
  %l175 = alloca ptr
  %l176 = alloca { i64, [1 x i64] }
  %l179 = alloca i64
  %l181 = alloca { i64, ptr }
  %l184 = alloca i64
  %l187 = alloca { i64, ptr }
  %l189 = alloca { i64, ptr }
  %l198 = alloca { i64, ptr }
  %l201 = alloca i1
  %l206 = alloca { i64, ptr }
  %l207 = alloca ptr
  %l208 = alloca { i64, [1 x i64] }
  %l211 = alloca i64
  %l213 = alloca { i64, ptr }
  %l216 = alloca i64
  %l219 = alloca { i64, ptr }
  %l221 = alloca { i64, ptr }
  %l222 = alloca ptr
  %l225 = alloca { i64, ptr }
  %l241 = alloca { i64, ptr }
  %l253 = alloca { i64, ptr }
  %l267 = alloca { i64, ptr }
  %l273 = alloca ptr
  %l277 = alloca { i64, ptr }
  %l281 = alloca { i64, ptr }
  %l289 = alloca i1
  %l292 = alloca { i64, ptr }
  %l295 = alloca { i64, ptr }
  %l298 = alloca { i64, ptr }
  %l299 = alloca ptr
  %l304 = alloca { i64, ptr }
  %l306 = alloca { i64, ptr }
  %l309 = alloca ptr
  %l312 = alloca { i64, ptr }
  %l316 = alloca { i64, ptr }
  %l328 = alloca { i64, ptr }
  %l334 = alloca ptr
  %l337 = alloca { i64, ptr }
  %l340 = alloca { i64, ptr }
  %l345 = alloca { i64, ptr }
  %l352 = alloca ptr
  %l356 = alloca { i64, ptr }
  %l357 = alloca { i64, ptr }
  %l360 = alloca i32
  %l361 = alloca { i64, ptr }
  %l362 = alloca ptr
  %l363 = alloca { i64, ptr }
  %l366 = alloca { i64, ptr }
  %l369 = alloca { i64, ptr }
  %l374 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [15 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l3, !tbaa !29
  %t9 = load { i64, [15 x i64] }, ptr %l1
  %t11 = extractvalue { i64, [15 x i64] } %t9, 0
  %t12 = icmp eq i64 %t11, 0
  br i1 %t12, label %bb1, label %bb2
bb1:
  %t14 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t15 = getelementptr { { i64, [4 x i64] } }, ptr %t14, i32 0, i32 0
  %t16 = load { i64, [4 x i64] }, ptr %t15
  store { i64, [4 x i64] } %t16, ptr %l4
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load { i64, [4 x i64] }, ptr %l4
  %t24 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %v1, ptr %t18, { i64, [4 x i64] } %t19, i32 %a2)
  store { i64, ptr } %t24, ptr %l70
  br label %bb4
bb4:
  %t25 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t25, ptr %rv
  br label %ret
bb5:
  %t26 = load { i64, [15 x i64] }, ptr %l1
  %t28 = extractvalue { i64, [15 x i64] } %t26, 0
  %t29 = icmp eq i64 %t28, 1
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t31 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t32 = getelementptr { %"compiler/mir:Place", i32 }, ptr %t31, i32 0, i32 0
  %t33 = load %"compiler/mir:Place", ptr %t32
  store %"compiler/mir:Place" %t33, ptr %l5
  %t35 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t36 = getelementptr { %"compiler/mir:Place", i32 }, ptr %t35, i32 0, i32 1
  %t37 = load i32, ptr %t36
  store i32 %t37, ptr %l6, !tbaa !23
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load %"compiler/mir:Place", ptr %l5
  %t41 = load i32, ptr %l6, !tbaa !23
  %t45 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eref(ptr %v0, ptr %v1, ptr %t39, %"compiler/mir:Place" %t40, i32 %t41)
  store { i64, ptr } %t45, ptr %l78
  br label %bb9
bb9:
  %t46 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t46, ptr %rv
  br label %ret
bb10:
  %t47 = load { i64, [15 x i64] }, ptr %l1
  %t49 = extractvalue { i64, [15 x i64] } %t47, 0
  %t50 = icmp eq i64 %t49, 2
  br i1 %t50, label %bb11, label %bb12
bb11:
  %t52 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t53 = getelementptr { %"compiler/mir:Place" }, ptr %t52, i32 0, i32 0
  %t54 = load %"compiler/mir:Place", ptr %t53
  store %"compiler/mir:Place" %t54, ptr %l7
  br label %bb13
bb12:
  br label %bb20
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load %"compiler/mir:Place", ptr %l7
  %t60 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s3, ptr %t56, %"compiler/mir:Place" %t57)
  store { { i64, ptr }, i32 } %t60, ptr %l84
  br label %bb14
bb14:
  %t61 = load { { i64, ptr }, i32 }, ptr %l84
  store { { i64, ptr }, i32 } %t61, ptr %l8
  %t62 = getelementptr { { i64, ptr }, i32 }, ptr %l8, i32 0, i32 0
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  store { i64, ptr } %t63, ptr %l85, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l86, !tbaa !24
  %t66 = load i64, ptr %l86, !tbaa !24
  %t67 = mul i64 %t66, 1
  %t68 = call ptr @__olang_scope_alloc_zeroed(ptr %s3, i64 %t67)
  %t69 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t68, 1
  store { i64, ptr } %t70, ptr %l87, !tbaa !27
  %t71 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = load i64, ptr %l86, !tbaa !24
  %t76 = mul i64 %t75, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t72, ptr %t74, i64 %t76, i1 false)
  %t77 = load { i64, ptr }, ptr %l87, !tbaa !27
  store { i64, ptr } %t77, ptr %l9, !tbaa !27
  %t78 = getelementptr { { i64, ptr }, i32 }, ptr %l8, i32 0, i32 1
  %t79 = load i32, ptr %t78, !tbaa !23
  store i32 %t79, ptr %l10, !tbaa !23
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l89, !tbaa !29
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i32, ptr %l10, !tbaa !23
  %t86 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %v1, ptr %t82, i32 %t83)
  store { i64, ptr } %t86, ptr %l92
  br label %bb15
bb15:
  %t87 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  %t89 = extractvalue { i64, ptr } %t87, 1
  %t90 = mul i64 %t88, 1
  %t91 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t90)
  call void @llvm.memcpy.p0.p0.i64(ptr %t91, ptr %t89, i64 %t90, i1 false)
  %t92 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  %t94 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t95 = load ptr, ptr %l89, !tbaa !29
  %t98 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %v1, ptr %s3, ptr %v1, ptr %v1, ptr %t95, { i64, ptr } %t93, { i64, ptr } %t94, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d174, i32 0, i32 1) })
  store { i64, ptr } %t98, ptr %l95
  br label %bb16
bb16:
  %t99 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t99, ptr %lp11
  %t100 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t101 = load ptr, ptr %lp11
  store { i64, ptr } %t100, ptr %t101, !tbaa !27
  %t102 = load ptr, ptr %l0, !tbaa !29
  store ptr %t102, ptr %l96, !tbaa !29
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load i32, ptr %l10, !tbaa !23
  %t107 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s3, ptr %t103, i32 %t104)
  store { i64, ptr } %t107, ptr %l99
  br label %bb17
bb17:
  %t108 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t108, 0
  %t110 = extractvalue { i64, ptr } %t108, 1
  %t111 = mul i64 %t109, 1
  %t112 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t111)
  call void @llvm.memcpy.p0.p0.i64(ptr %t112, ptr %t110, i64 %t111, i1 false)
  %t113 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t112, 1
  store { i64, ptr } %t114, ptr %l100, !tbaa !27
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/emit:fnEm", ptr %t115, i32 0, i32 0
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t119 = load i32, ptr %l10, !tbaa !23
  %t122 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %v0, ptr %s3, ptr %t118, i32 %t119, i64 0)
  store { i64, ptr } %t122, ptr %l104
  br label %bb18
bb18:
  %t123 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  %t125 = extractvalue { i64, ptr } %t123, 1
  %t126 = mul i64 %t124, 1
  %t127 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t126)
  call void @llvm.memcpy.p0.p0.i64(ptr %t127, ptr %t125, i64 %t126, i1 false)
  %t128 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  %t130 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t131 = load ptr, ptr %l96, !tbaa !29
  %t132 = load { i64, ptr }, ptr %l100, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s3, ptr %s3, ptr %s3, ptr %s3, ptr %t131, { i64, ptr } %t132, { i64, ptr } %t129, { i64, ptr } %t130, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d118, i32 0, i32 1) })
  br label %bb19
bb19:
  %t135 = load ptr, ptr %lp11
  %t136 = load { i64, ptr }, ptr %t135, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  store { i64, ptr } %t136, ptr %rv
  br label %ret
bb20:
  %t138 = load { i64, [15 x i64] }, ptr %l1
  %t140 = extractvalue { i64, [15 x i64] } %t138, 0
  %t141 = icmp eq i64 %t140, 3
  br i1 %t141, label %bb21, label %bb22
bb21:
  %t143 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t144 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t143, i32 0, i32 0
  %t145 = load i32, ptr %t144
  store i32 %t145, ptr %l12
  %t147 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t148 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t147, i32 0, i32 1
  %t149 = load i32, ptr %t148
  store i32 %t149, ptr %l13, !tbaa !23
  %t151 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t152 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t151, i32 0, i32 2
  %t153 = load %"compiler/mir:Range", ptr %t152
  store %"compiler/mir:Range" %t153, ptr %l14
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load i32, ptr %l12
  %t157 = load i32, ptr %l13, !tbaa !23
  %t158 = load %"compiler/mir:Range", ptr %l14
  %t163 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eprim(ptr %v0, ptr %v1, ptr %t155, i32 %t156, i32 %t157, %"compiler/mir:Range" %t158)
  store { i64, ptr } %t163, ptr %l117
  br label %bb24
bb24:
  %t164 = load { i64, ptr }, ptr %l117, !tbaa !27
  store { i64, ptr } %t164, ptr %rv
  br label %ret
bb25:
  %t165 = load { i64, [15 x i64] }, ptr %l1
  %t167 = extractvalue { i64, [15 x i64] } %t165, 0
  %t168 = icmp eq i64 %t167, 4
  br i1 %t168, label %bb26, label %bb27
bb26:
  %t170 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t171 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t170, i32 0, i32 0
  %t172 = load i32, ptr %t171
  store i32 %t172, ptr %l15
  %t174 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t175 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t174, i32 0, i32 1
  %t176 = load i32, ptr %t175
  store i32 %t176, ptr %l16, !tbaa !23
  %t178 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t179 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t178, i32 0, i32 2
  %t180 = load %"compiler/mir:Range", ptr %t179
  store %"compiler/mir:Range" %t180, ptr %l17
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load i32, ptr %l15
  %t184 = load i32, ptr %l16, !tbaa !23
  %t185 = load %"compiler/mir:Range", ptr %l17
  %t190 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eoverflows(ptr %v0, ptr %v1, ptr %t182, i32 %t183, i32 %t184, %"compiler/mir:Range" %t185)
  store { i64, ptr } %t190, ptr %l127
  br label %bb29
bb29:
  %t191 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t191, ptr %rv
  br label %ret
bb30:
  %t192 = load { i64, [15 x i64] }, ptr %l1
  %t194 = extractvalue { i64, [15 x i64] } %t192, 0
  %t195 = icmp eq i64 %t194, 5
  br i1 %t195, label %bb31, label %bb32
bb31:
  %t197 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t198 = getelementptr { %"compiler/mir:Place" }, ptr %t197, i32 0, i32 0
  %t199 = load %"compiler/mir:Place", ptr %t198
  store %"compiler/mir:Place" %t199, ptr %l18
  br label %bb33
bb32:
  br label %bb42
bb33:
  store %olang.scope zeroinitializer, ptr %s6
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load %"compiler/mir:Place", ptr %l18
  %t205 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s6, ptr %t201, %"compiler/mir:Place" %t202)
  store { { i64, ptr }, i32 } %t205, ptr %l133
  br label %bb34
bb34:
  %t206 = load { { i64, ptr }, i32 }, ptr %l133
  store { { i64, ptr }, i32 } %t206, ptr %l19
  %t207 = getelementptr { { i64, ptr }, i32 }, ptr %l19, i32 0, i32 0
  %t208 = load { i64, ptr }, ptr %t207, !tbaa !27
  store { i64, ptr } %t208, ptr %l134, !tbaa !27
  %t209 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t210 = extractvalue { i64, ptr } %t209, 0
  store i64 %t210, ptr %l135, !tbaa !24
  %t211 = load i64, ptr %l135, !tbaa !24
  %t212 = mul i64 %t211, 1
  %t213 = call ptr @__olang_scope_alloc_zeroed(ptr %s6, i64 %t212)
  %t214 = insertvalue { i64, ptr } undef, i64 %t211, 0
  %t215 = insertvalue { i64, ptr } %t214, ptr %t213, 1
  store { i64, ptr } %t215, ptr %l136, !tbaa !27
  %t216 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !27
  %t220 = load i64, ptr %l135, !tbaa !24
  %t221 = mul i64 %t220, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t217, ptr %t219, i64 %t221, i1 false)
  %t222 = load { i64, ptr }, ptr %l136, !tbaa !27
  store { i64, ptr } %t222, ptr %l20, !tbaa !27
  %t223 = getelementptr { { i64, ptr }, i32 }, ptr %l19, i32 0, i32 1
  %t224 = load i32, ptr %t223, !tbaa !23
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/emit:fnEm", ptr %t226, i32 0, i32 0
  %t229 = load ptr, ptr %t228, !tbaa !29
  %t233 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eenumWords(ptr %v0, ptr %t229, i32 %t224)
  store i1 %t233, ptr %l141
  br label %bb35
bb35:
  %t234 = load i1, ptr %l141, !tbaa !21
  br i1 %t234, label %bb36, label %bb37
bb36:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t239 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %v1, ptr %s6, ptr %v1, ptr %v1, ptr %t235, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d434, i32 0, i32 1) }, { i64, ptr } %t236, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d174, i32 0, i32 1) })
  store { i64, ptr } %t239, ptr %l144
  br label %bb38
bb37:
  br label %bb39
bb38:
  call void @__olang_scope_close(ptr %s6)
  %t240 = load { i64, ptr }, ptr %l144, !tbaa !27
  store { i64, ptr } %t240, ptr %rv
  br label %ret
bb39:
  %t241 = load ptr, ptr %l0, !tbaa !29
  store ptr %t241, ptr %l145, !tbaa !29
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t246 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s6, ptr %s6, ptr %s6, ptr %s6, ptr %t242, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d435, i32 0, i32 1) }, { i64, ptr } %t243, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d174, i32 0, i32 1) })
  store { i64, ptr } %t246, ptr %l148
  br label %bb40
bb40:
  %t247 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d436, i32 0, i32 1) }, 1
  %t248 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d436, i32 0, i32 1) }, 0
  %t249 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t250 = extractvalue { i64, ptr } %t249, 1
  %t251 = extractvalue { i64, ptr } %t249, 0
  %t252 = add i64 %t248, %t251
  %t253 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d437, i32 0, i32 1) }, 1
  %t254 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d437, i32 0, i32 1) }, 0
  %t255 = add i64 %t252, %t254
  %t256 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t255)
  call void @olang_textcopy(ptr %t256, ptr %t247, i64 %t248)
  %t257 = getelementptr i8, ptr %t256, i64 %t248
  call void @olang_textcopy(ptr %t257, ptr %t250, i64 %t251)
  %t258 = getelementptr i8, ptr %t257, i64 %t251
  call void @olang_textcopy(ptr %t258, ptr %t253, i64 %t254)
  %t259 = insertvalue { i64, ptr } undef, i64 %t255, 0
  %t260 = insertvalue { i64, ptr } %t259, ptr %t256, 1
  %t262 = extractvalue { i64, ptr } %t260, 0
  %t263 = extractvalue { i64, ptr } %t260, 1
  %t264 = mul i64 %t262, 1
  %t265 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t264)
  call void @llvm.memcpy.p0.p0.i64(ptr %t265, ptr %t263, i64 %t264, i1 false)
  %t266 = insertvalue { i64, ptr } undef, i64 %t262, 0
  %t267 = insertvalue { i64, ptr } %t266, ptr %t265, 1
  %t268 = load ptr, ptr %l145, !tbaa !29
  %t270 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t268, { i64, ptr } %t267)
  store { i64, ptr } %t270, ptr %l151
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s6)
  %t271 = load { i64, ptr }, ptr %l151, !tbaa !27
  store { i64, ptr } %t271, ptr %rv
  br label %ret
bb42:
  %t272 = load { i64, [15 x i64] }, ptr %l1
  %t274 = extractvalue { i64, [15 x i64] } %t272, 0
  %t275 = icmp eq i64 %t274, 6
  br i1 %t275, label %bb43, label %bb44
bb43:
  %t277 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t278 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t277, i32 0, i32 0
  %t279 = load i32, ptr %t278
  store i32 %t279, ptr %l22, !tbaa !23
  %t281 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t282 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t281, i32 0, i32 1
  %t283 = load i64, ptr %t282
  store i64 %t283, ptr %l23, !tbaa !24
  %t285 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t286 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t285, i32 0, i32 2
  %t287 = load %"compiler/mir:Range", ptr %t286
  store %"compiler/mir:Range" %t287, ptr %l24
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t290 = load i32, ptr %l22, !tbaa !23
  %t291 = load i64, ptr %l23, !tbaa !24
  %t292 = load %"compiler/mir:Range", ptr %l24
  %t297 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaggregate(ptr %v0, ptr %v1, ptr %t289, i32 %t290, i64 %t291, %"compiler/mir:Range" %t292)
  store { i64, ptr } %t297, ptr %l161
  br label %bb46
bb46:
  %t298 = load { i64, ptr }, ptr %l161, !tbaa !27
  store { i64, ptr } %t298, ptr %rv
  br label %ret
bb47:
  %t299 = load { i64, [15 x i64] }, ptr %l1
  %t301 = extractvalue { i64, [15 x i64] } %t299, 0
  %t302 = icmp eq i64 %t301, 7
  br i1 %t302, label %bb48, label %bb49
bb48:
  %t304 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t305 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t304, i32 0, i32 0
  %t306 = load { i64, [1 x i64] }, ptr %t305
  store { i64, [1 x i64] } %t306, ptr %l25
  %t308 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t309 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t308, i32 0, i32 1
  %t310 = load { i64, [4 x i64] }, ptr %t309
  store { i64, [4 x i64] } %t310, ptr %l26
  %t312 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t313 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t312, i32 0, i32 2
  %t314 = load i32, ptr %t313
  store i32 %t314, ptr %l27, !tbaa !23
  br label %bb50
bb49:
  br label %bb74
bb50:
  store %olang.scope zeroinitializer, ptr %s10
  %t316 = load ptr, ptr %l3, !tbaa !29
  store ptr %t316, ptr %l167, !tbaa !29
  %t317 = load ptr, ptr %l3, !tbaa !29
  %t318 = load i32, ptr %l27, !tbaa !23
  %t321 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t317, i32 %t318)
  store i32 %t321, ptr %l170
  br label %bb51
bb51:
  %t322 = load ptr, ptr %l167, !tbaa !29
  %t323 = load i32, ptr %l170, !tbaa !23
  %t324 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t322, i32 %t323)
  store i32 %t324, ptr %l171
  br label %bb52
bb52:
  %t325 = load i32, ptr %l171, !tbaa !23
  store i32 %t325, ptr %l28, !tbaa !23
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t327 = load i32, ptr %l28, !tbaa !23
  %t330 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eviaMem(ptr %v0, ptr %t326, i32 %t327)
  store i1 %t330, ptr %l174
  br label %bb53
bb53:
  %t331 = load i1, ptr %l174, !tbaa !21
  br i1 %t331, label %bb54, label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s11
  %t332 = load ptr, ptr %l0, !tbaa !29
  store ptr %t332, ptr %l175, !tbaa !29
  %t333 = load { i64, [1 x i64] }, ptr %l25
  store { i64, [1 x i64] } %t333, ptr %l176
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t335 = load i32, ptr %l28, !tbaa !23
  %t338 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t334, i32 %t335)
  store i64 %t338, ptr %l179
  br label %bb56
bb55:
  br label %bb61
bb56:
  %t339 = load i64, ptr %l179, !tbaa !24
  %t340 = call i64 @__olang_fmt_i64(ptr null, i64 %t339)
  %t341 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t340)
  %t342 = call i64 @__olang_fmt_i64(ptr %t341, i64 %t339)
  %t343 = insertvalue { i64, ptr } undef, i64 %t340, 0
  %t344 = insertvalue { i64, ptr } %t343, ptr %t341, 1
  %t346 = extractvalue { i64, ptr } %t344, 0
  %t347 = extractvalue { i64, ptr } %t344, 1
  %t348 = mul i64 %t346, 1
  %t349 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t348)
  call void @llvm.memcpy.p0.p0.i64(ptr %t349, ptr %t347, i64 %t348, i1 false)
  %t350 = insertvalue { i64, ptr } undef, i64 %t346, 0
  %t351 = insertvalue { i64, ptr } %t350, ptr %t349, 1
  store { i64, ptr } %t351, ptr %l181, !tbaa !27
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t353 = load i32, ptr %l28, !tbaa !23
  %t356 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ealign(ptr %v0, ptr %t352, i32 %t353)
  store i64 %t356, ptr %l184
  br label %bb57
bb57:
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t358 = load i32, ptr %l28, !tbaa !23
  %t361 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %v1, ptr %t357, i32 %t358)
  store { i64, ptr } %t361, ptr %l187
  br label %bb58
bb58:
  %t362 = load { i64, ptr }, ptr %l187, !tbaa !27
  %t363 = extractvalue { i64, ptr } %t362, 0
  %t364 = extractvalue { i64, ptr } %t362, 1
  %t365 = mul i64 %t363, 1
  %t366 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t365)
  call void @llvm.memcpy.p0.p0.i64(ptr %t366, ptr %t364, i64 %t365, i1 false)
  %t367 = insertvalue { i64, ptr } undef, i64 %t363, 0
  %t368 = insertvalue { i64, ptr } %t367, ptr %t366, 1
  %t369 = load ptr, ptr %l175, !tbaa !29
  %t370 = load { i64, [1 x i64] }, ptr %l176
  %t371 = load { i64, ptr }, ptr %l181, !tbaa !27
  %t372 = load i64, ptr %l184, !tbaa !24
  %t374 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloc(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %t369, { i64, [1 x i64] } %t370, { i64, ptr } %t371, i64 %t372, { i64, ptr } %t368)
  store { i64, ptr } %t374, ptr %l189
  br label %bb59
bb59:
  %t375 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t375, ptr %lp29
  %t376 = load { i64, ptr }, ptr %l189, !tbaa !27
  %t377 = load ptr, ptr %lp29
  store { i64, ptr } %t376, ptr %t377, !tbaa !27
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t379 = load ptr, ptr %lp29
  %t380 = load { i64, ptr }, ptr %t379, !tbaa !27
  %t381 = load i32, ptr %l28, !tbaa !23
  %t382 = load { i64, [4 x i64] }, ptr %l26
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eput(ptr %v0, ptr %v1, ptr %s11, ptr %t378, { i64, ptr } %t380, i32 %t381, { i64, [4 x i64] } %t382, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d182, i32 0, i32 1) })
  br label %bb60
bb60:
  %t387 = load ptr, ptr %lp29
  %t388 = load { i64, ptr }, ptr %t387, !tbaa !27
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s10)
  store { i64, ptr } %t388, ptr %rv
  br label %ret
bb61:
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t391 = load { i64, [4 x i64] }, ptr %l26
  %t392 = load i32, ptr %l28, !tbaa !23
  %t396 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s10, ptr %t390, { i64, [4 x i64] } %t391, i32 %t392)
  store { i64, ptr } %t396, ptr %l198
  br label %bb62
bb62:
  %t397 = load { i64, ptr }, ptr %l198, !tbaa !27
  store { i64, ptr } %t397, ptr %l30, !tbaa !27
  %t398 = load ptr, ptr %l0, !tbaa !29
  %t399 = load i32, ptr %l28, !tbaa !23
  %t402 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erunTime(ptr %v0, ptr %t398, i32 %t399)
  store i1 %t402, ptr %l201
  br label %bb63
bb63:
  %t403 = load i1, ptr %l201, !tbaa !21
  br i1 %t403, label %bb64, label %bb65
bb64:
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t405 = load { i64, [1 x i64] }, ptr %l25
  %t406 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t407 = load i32, ptr %l28, !tbaa !23
  %t412 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ecopyArray(ptr %v0, ptr %s10, ptr %v1, ptr %t404, { i64, [1 x i64] } %t405, { i64, ptr } %t406, i32 %t407)
  store { i64, ptr } %t412, ptr %l206
  br label %bb66
bb65:
  br label %bb67
bb66:
  call void @__olang_scope_close(ptr %s10)
  %t413 = load { i64, ptr }, ptr %l206, !tbaa !27
  store { i64, ptr } %t413, ptr %rv
  br label %ret
bb67:
  %t414 = load ptr, ptr %l0, !tbaa !29
  store ptr %t414, ptr %l207, !tbaa !29
  %t415 = load { i64, [1 x i64] }, ptr %l25
  store { i64, [1 x i64] } %t415, ptr %l208
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t417 = load i32, ptr %l28, !tbaa !23
  %t420 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t416, i32 %t417)
  store i64 %t420, ptr %l211
  br label %bb68
bb68:
  %t421 = load i64, ptr %l211, !tbaa !24
  %t422 = call i64 @__olang_fmt_i64(ptr null, i64 %t421)
  %t423 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t422)
  %t424 = call i64 @__olang_fmt_i64(ptr %t423, i64 %t421)
  %t425 = insertvalue { i64, ptr } undef, i64 %t422, 0
  %t426 = insertvalue { i64, ptr } %t425, ptr %t423, 1
  %t428 = extractvalue { i64, ptr } %t426, 0
  %t429 = extractvalue { i64, ptr } %t426, 1
  %t430 = mul i64 %t428, 1
  %t431 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t430)
  call void @llvm.memcpy.p0.p0.i64(ptr %t431, ptr %t429, i64 %t430, i1 false)
  %t432 = insertvalue { i64, ptr } undef, i64 %t428, 0
  %t433 = insertvalue { i64, ptr } %t432, ptr %t431, 1
  store { i64, ptr } %t433, ptr %l213, !tbaa !27
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t435 = load i32, ptr %l28, !tbaa !23
  %t438 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ealign(ptr %v0, ptr %t434, i32 %t435)
  store i64 %t438, ptr %l216
  br label %bb69
bb69:
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t440 = load i32, ptr %l28, !tbaa !23
  %t443 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %v1, ptr %t439, i32 %t440)
  store { i64, ptr } %t443, ptr %l219
  br label %bb70
bb70:
  %t444 = load { i64, ptr }, ptr %l219, !tbaa !27
  %t445 = extractvalue { i64, ptr } %t444, 0
  %t446 = extractvalue { i64, ptr } %t444, 1
  %t447 = mul i64 %t445, 1
  %t448 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t447)
  call void @llvm.memcpy.p0.p0.i64(ptr %t448, ptr %t446, i64 %t447, i1 false)
  %t449 = insertvalue { i64, ptr } undef, i64 %t445, 0
  %t450 = insertvalue { i64, ptr } %t449, ptr %t448, 1
  %t451 = load ptr, ptr %l207, !tbaa !29
  %t452 = load { i64, [1 x i64] }, ptr %l208
  %t453 = load { i64, ptr }, ptr %l213, !tbaa !27
  %t454 = load i64, ptr %l216, !tbaa !24
  %t456 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloc(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %t451, { i64, [1 x i64] } %t452, { i64, ptr } %t453, i64 %t454, { i64, ptr } %t450)
  store { i64, ptr } %t456, ptr %l221
  br label %bb71
bb71:
  %t457 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t457, ptr %lp31
  %t458 = load { i64, ptr }, ptr %l221, !tbaa !27
  %t459 = load ptr, ptr %lp31
  store { i64, ptr } %t458, ptr %t459, !tbaa !27
  %t460 = load ptr, ptr %l0, !tbaa !29
  store ptr %t460, ptr %l222, !tbaa !29
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t462 = load i32, ptr %l28, !tbaa !23
  %t465 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s10, ptr %t461, i32 %t462)
  store { i64, ptr } %t465, ptr %l225
  br label %bb72
bb72:
  %t466 = load { i64, ptr }, ptr %l225, !tbaa !27
  %t467 = extractvalue { i64, ptr } %t466, 0
  %t468 = extractvalue { i64, ptr } %t466, 1
  %t469 = mul i64 %t467, 1
  %t470 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t469)
  call void @llvm.memcpy.p0.p0.i64(ptr %t470, ptr %t468, i64 %t469, i1 false)
  %t471 = insertvalue { i64, ptr } undef, i64 %t467, 0
  %t472 = insertvalue { i64, ptr } %t471, ptr %t470, 1
  %t473 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t474 = load ptr, ptr %lp31
  %t475 = load { i64, ptr }, ptr %t474, !tbaa !27
  %t476 = load ptr, ptr %l222, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s10, ptr %s10, ptr %v1, ptr %s10, ptr %t476, { i64, ptr } %t472, { i64, ptr } %t473, { i64, ptr } %t475, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d118, i32 0, i32 1) })
  br label %bb73
bb73:
  %t480 = load ptr, ptr %lp31
  %t481 = load { i64, ptr }, ptr %t480, !tbaa !27
  call void @__olang_scope_close(ptr %s10)
  store { i64, ptr } %t481, ptr %rv
  br label %ret
bb74:
  %t483 = load { i64, [15 x i64] }, ptr %l1
  %t485 = extractvalue { i64, [15 x i64] } %t483, 0
  %t486 = icmp eq i64 %t485, 8
  br i1 %t486, label %bb75, label %bb76
bb75:
  %t488 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t489 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t488, i32 0, i32 0
  %t490 = load { i64, [1 x i64] }, ptr %t489
  store { i64, [1 x i64] } %t490, ptr %l32
  %t492 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t493 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t492, i32 0, i32 1
  %t494 = load i32, ptr %t493
  store i32 %t494, ptr %l33, !tbaa !23
  %t496 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t497 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t496, i32 0, i32 2
  %t498 = load { i64, [4 x i64] }, ptr %t497
  store { i64, [4 x i64] } %t498, ptr %l34
  %t500 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t501 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t500, i32 0, i32 3
  %t502 = load { i64, [4 x i64] }, ptr %t501
  store { i64, [4 x i64] } %t502, ptr %l35
  br label %bb77
bb76:
  br label %bb79
bb77:
  %t504 = load ptr, ptr %l0, !tbaa !29
  %t505 = load { i64, [1 x i64] }, ptr %l32
  %t506 = load i32, ptr %l33, !tbaa !23
  %t507 = load { i64, [4 x i64] }, ptr %l34
  %t508 = load { i64, [4 x i64] }, ptr %l35
  %t514 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2enewArray(ptr %v0, ptr %v1, ptr %t504, { i64, [1 x i64] } %t505, i32 %t506, { i64, [4 x i64] } %t507, { i64, [4 x i64] } %t508)
  store { i64, ptr } %t514, ptr %l241
  br label %bb78
bb78:
  %t515 = load { i64, ptr }, ptr %l241, !tbaa !27
  store { i64, ptr } %t515, ptr %rv
  br label %ret
bb79:
  %t516 = load { i64, [15 x i64] }, ptr %l1
  %t518 = extractvalue { i64, [15 x i64] } %t516, 0
  %t519 = icmp eq i64 %t518, 9
  br i1 %t519, label %bb80, label %bb81
bb80:
  %t521 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t522 = getelementptr { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t521, i32 0, i32 0
  %t523 = load %"compiler/mir:Place", ptr %t522
  store %"compiler/mir:Place" %t523, ptr %l36
  %t525 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t526 = getelementptr { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t525, i32 0, i32 1
  %t527 = load { i64, [4 x i64] }, ptr %t526
  store { i64, [4 x i64] } %t527, ptr %l37
  %t529 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t530 = getelementptr { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t529, i32 0, i32 2
  %t531 = load { i64, [4 x i64] }, ptr %t530
  store { i64, [4 x i64] } %t531, ptr %l38
  %t533 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t534 = getelementptr { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t533, i32 0, i32 3
  %t535 = load i32, ptr %t534
  store i32 %t535, ptr %l39, !tbaa !23
  br label %bb82
bb81:
  br label %bb84
bb82:
  %t537 = load ptr, ptr %l0, !tbaa !29
  %t538 = load %"compiler/mir:Place", ptr %l36
  %t539 = load { i64, [4 x i64] }, ptr %l37
  %t540 = load { i64, [4 x i64] }, ptr %l38
  %t541 = load i32, ptr %l39, !tbaa !23
  %t547 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eslice(ptr %v0, ptr %v1, ptr %t537, %"compiler/mir:Place" %t538, { i64, [4 x i64] } %t539, { i64, [4 x i64] } %t540, i32 %t541)
  store { i64, ptr } %t547, ptr %l253
  br label %bb83
bb83:
  %t548 = load { i64, ptr }, ptr %l253, !tbaa !27
  store { i64, ptr } %t548, ptr %rv
  br label %ret
bb84:
  %t549 = load { i64, [15 x i64] }, ptr %l1
  %t551 = extractvalue { i64, [15 x i64] } %t549, 0
  %t552 = icmp eq i64 %t551, 10
  br i1 %t552, label %bb85, label %bb86
bb85:
  %t554 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t555 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t554, i32 0, i32 0
  %t556 = load { i64, [2 x i64] }, ptr %t555
  store { i64, [2 x i64] } %t556, ptr %l40
  %t558 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t559 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t558, i32 0, i32 1
  %t560 = load i32, ptr %t559
  store i32 %t560, ptr %l41, !tbaa !23
  %t562 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t563 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t562, i32 0, i32 2
  %t564 = load { i64, [1 x i64] }, ptr %t563
  store { i64, [1 x i64] } %t564, ptr %l42
  %t566 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t567 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t566, i32 0, i32 3
  %t568 = load %"compiler/mir:Range", ptr %t567
  store %"compiler/mir:Range" %t568, ptr %l43
  %t570 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t571 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t570, i32 0, i32 4
  %t572 = load %"compiler/mir:Range", ptr %t571
  store %"compiler/mir:Range" %t572, ptr %l44
  br label %bb87
bb86:
  br label %bb89
bb87:
  %t574 = load ptr, ptr %l0, !tbaa !29
  %t575 = load { i64, [2 x i64] }, ptr %l40
  %t576 = load i32, ptr %l41, !tbaa !23
  %t577 = load { i64, [1 x i64] }, ptr %l42
  %t578 = load %"compiler/mir:Range", ptr %l43
  %t579 = load %"compiler/mir:Range", ptr %l44
  %t586 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eclosure(ptr %v0, ptr %v1, ptr %t574, { i64, [2 x i64] } %t575, i32 %t576, { i64, [1 x i64] } %t577, %"compiler/mir:Range" %t578, %"compiler/mir:Range" %t579)
  store { i64, ptr } %t586, ptr %l267
  br label %bb88
bb88:
  %t587 = load { i64, ptr }, ptr %l267, !tbaa !27
  store { i64, ptr } %t587, ptr %rv
  br label %ret
bb89:
  %t588 = load { i64, [15 x i64] }, ptr %l1
  %t590 = extractvalue { i64, [15 x i64] } %t588, 0
  %t591 = icmp eq i64 %t590, 11
  br i1 %t591, label %bb90, label %bb91
bb90:
  %t593 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t594 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t593, i32 0, i32 0
  %t595 = load { i64, [4 x i64] }, ptr %t594
  store { i64, [4 x i64] } %t595, ptr %l45
  %t597 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t598 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t597, i32 0, i32 1
  %t599 = load i32, ptr %t598
  store i32 %t599, ptr %l46, !tbaa !23
  %t601 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t602 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t601, i32 0, i32 2
  %t603 = load i32, ptr %t602
  store i32 %t603, ptr %l47, !tbaa !23
  br label %bb92
bb91:
  br label %bb95
bb92:
  %t605 = load ptr, ptr %l0, !tbaa !29
  store ptr %t605, ptr %l273, !tbaa !29
  %t606 = load ptr, ptr %l0, !tbaa !29
  %t607 = load { i64, [4 x i64] }, ptr %l45
  %t608 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t612 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %v1, ptr %t606, { i64, [4 x i64] } %t607, i32 %t608)
  store { i64, ptr } %t612, ptr %l277
  br label %bb93
bb93:
  %t613 = load { i64, ptr }, ptr %l277, !tbaa !27
  %t614 = extractvalue { i64, ptr } %t613, 0
  %t615 = extractvalue { i64, ptr } %t613, 1
  %t616 = mul i64 %t614, 1
  %t617 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t616)
  call void @llvm.memcpy.p0.p0.i64(ptr %t617, ptr %t615, i64 %t616, i1 false)
  %t618 = insertvalue { i64, ptr } undef, i64 %t614, 0
  %t619 = insertvalue { i64, ptr } %t618, ptr %t617, 1
  %t620 = load i32, ptr %l46, !tbaa !23
  %t621 = load i32, ptr %l47, !tbaa !23
  %t622 = load ptr, ptr %l273, !tbaa !29
  %t626 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2erecode(ptr %v0, ptr %v1, ptr %v1, ptr %t622, { i64, ptr } %t619, i32 %t620, i32 %t621)
  store { i64, ptr } %t626, ptr %l281
  br label %bb94
bb94:
  %t627 = load { i64, ptr }, ptr %l281, !tbaa !27
  store { i64, ptr } %t627, ptr %rv
  br label %ret
bb95:
  %t628 = load { i64, [15 x i64] }, ptr %l1
  %t630 = extractvalue { i64, [15 x i64] } %t628, 0
  %t631 = icmp eq i64 %t630, 12
  br i1 %t631, label %bb96, label %bb97
bb96:
  %t633 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t634 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t633, i32 0, i32 0
  %t635 = load { i64, [1 x i64] }, ptr %t634
  store { i64, [1 x i64] } %t635, ptr %l48
  %t637 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t638 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t637, i32 0, i32 1
  %t639 = load { i64, [1 x i64] }, ptr %t638
  store { i64, [1 x i64] } %t639, ptr %l49
  %t641 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t642 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t641, i32 0, i32 2
  %t643 = load i32, ptr %t642
  store i32 %t643, ptr %l50, !tbaa !23
  br label %bb98
bb97:
  br label %bb114
bb98:
  store %olang.scope zeroinitializer, ptr %s19
  %t645 = load ptr, ptr %l0, !tbaa !29
  %t646 = load { i64, [1 x i64] }, ptr %l48
  %t649 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2edirectRef(ptr %v0, ptr %t645, { i64, [1 x i64] } %t646)
  store i1 %t649, ptr %l289
  br label %bb99
bb99:
  %t650 = load i1, ptr %l289, !tbaa !21
  br i1 %t650, label %bb100, label %bb101
bb100:
  %t651 = load ptr, ptr %l0, !tbaa !29
  %t652 = load { i64, [1 x i64] }, ptr %l49
  %t655 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edirectText(ptr %v0, ptr %v1, ptr %t651, { i64, [1 x i64] } %t652)
  store { i64, ptr } %t655, ptr %l292
  br label %bb102
bb101:
  br label %bb103
bb102:
  call void @__olang_scope_close(ptr %s19)
  %t656 = load { i64, ptr }, ptr %l292, !tbaa !27
  store { i64, ptr } %t656, ptr %rv
  br label %ret
bb103:
  %t657 = load ptr, ptr %l0, !tbaa !29
  %t658 = load { i64, [1 x i64] }, ptr %l48
  %t661 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %s19, ptr %t657, { i64, [1 x i64] } %t658)
  store { i64, ptr } %t661, ptr %l295
  br label %bb104
bb104:
  %t662 = load { i64, ptr }, ptr %l295, !tbaa !27
  store { i64, ptr } %t662, ptr %l51, !tbaa !27
  %t663 = load ptr, ptr %l0, !tbaa !29
  %t664 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t667 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s19, ptr %s19, ptr %s19, ptr %s19, ptr %t663, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d438, i32 0, i32 1) }, { i64, ptr } %t664, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d174, i32 0, i32 1) })
  store { i64, ptr } %t667, ptr %l298
  br label %bb105
bb105:
  %t668 = load { i64, ptr }, ptr %l298, !tbaa !27
  store { i64, ptr } %t668, ptr %l52, !tbaa !27
  %t669 = load ptr, ptr %l0, !tbaa !29
  store ptr %t669, ptr %l299, !tbaa !29
  %t670 = load ptr, ptr %l0, !tbaa !29
  %t671 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t672 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d439, i32 0, i32 1) }, 1
  %t673 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d439, i32 0, i32 1) }, 0
  %t675 = extractvalue { i64, ptr } %t671, 1
  %t676 = extractvalue { i64, ptr } %t671, 0
  %t677 = add i64 %t673, %t676
  %t678 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d440, i32 0, i32 1) }, 1
  %t679 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d440, i32 0, i32 1) }, 0
  %t680 = add i64 %t677, %t679
  %t681 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t680)
  call void @olang_textcopy(ptr %t681, ptr %t672, i64 %t673)
  %t682 = getelementptr i8, ptr %t681, i64 %t673
  call void @olang_textcopy(ptr %t682, ptr %t675, i64 %t676)
  %t683 = getelementptr i8, ptr %t682, i64 %t676
  call void @olang_textcopy(ptr %t683, ptr %t678, i64 %t679)
  %t684 = insertvalue { i64, ptr } undef, i64 %t680, 0
  %t685 = insertvalue { i64, ptr } %t684, ptr %t681, 1
  %t687 = extractvalue { i64, ptr } %t685, 0
  %t688 = extractvalue { i64, ptr } %t685, 1
  %t689 = mul i64 %t687, 1
  %t690 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t689)
  call void @llvm.memcpy.p0.p0.i64(ptr %t690, ptr %t688, i64 %t689, i1 false)
  %t691 = insertvalue { i64, ptr } undef, i64 %t687, 0
  %t692 = insertvalue { i64, ptr } %t691, ptr %t690, 1
  %t695 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s19, ptr %s19, ptr %t670, { i64, ptr } %t692)
  store { i64, ptr } %t695, ptr %l304
  br label %bb106
bb106:
  %t696 = load { i64, ptr }, ptr %l304, !tbaa !27
  %t697 = extractvalue { i64, ptr } %t696, 0
  %t698 = extractvalue { i64, ptr } %t696, 1
  %t699 = mul i64 %t697, 1
  %t700 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t699)
  call void @llvm.memcpy.p0.p0.i64(ptr %t700, ptr %t698, i64 %t699, i1 false)
  %t701 = insertvalue { i64, ptr } undef, i64 %t697, 0
  %t702 = insertvalue { i64, ptr } %t701, ptr %t700, 1
  %t703 = load ptr, ptr %l299, !tbaa !29
  %t705 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s19, ptr %s19, ptr %s19, ptr %s19, ptr %t703, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d441, i32 0, i32 1) }, { i64, ptr } %t702, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d174, i32 0, i32 1) })
  store { i64, ptr } %t705, ptr %l306
  br label %bb107
bb107:
  %t706 = load { i64, ptr }, ptr %l306, !tbaa !27
  store { i64, ptr } %t706, ptr %l53, !tbaa !27
  %t707 = load ptr, ptr %l0, !tbaa !29
  %t709 = getelementptr %"compiler/emit:fnEm", ptr %t707, i32 0, i32 0
  %t710 = load ptr, ptr %t709, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s19, ptr %t710, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d442, i32 0, i32 1) })
  br label %bb108
bb108:
  %t712 = load ptr, ptr %l0, !tbaa !29
  store ptr %t712, ptr %l309, !tbaa !29
  %t713 = load ptr, ptr %l0, !tbaa !29
  %t714 = load { i64, [1 x i64] }, ptr %l49
  %t717 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %s19, ptr %t713, { i64, [1 x i64] } %t714)
  store { i64, ptr } %t717, ptr %l312
  br label %bb109
bb109:
  %t718 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t719 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d443, i32 0, i32 1) }, 1
  %t720 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d443, i32 0, i32 1) }, 0
  %t721 = load { i64, ptr }, ptr %l312, !tbaa !27
  %t722 = extractvalue { i64, ptr } %t721, 1
  %t723 = extractvalue { i64, ptr } %t721, 0
  %t724 = add i64 %t720, %t723
  %t725 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d444, i32 0, i32 1) }, 1
  %t726 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d444, i32 0, i32 1) }, 0
  %t727 = add i64 %t724, %t726
  %t729 = extractvalue { i64, ptr } %t718, 1
  %t730 = extractvalue { i64, ptr } %t718, 0
  %t731 = add i64 %t727, %t730
  %t732 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d445, i32 0, i32 1) }, 1
  %t733 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d445, i32 0, i32 1) }, 0
  %t734 = add i64 %t731, %t733
  %t735 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t734)
  call void @olang_textcopy(ptr %t735, ptr %t719, i64 %t720)
  %t736 = getelementptr i8, ptr %t735, i64 %t720
  call void @olang_textcopy(ptr %t736, ptr %t722, i64 %t723)
  %t737 = getelementptr i8, ptr %t736, i64 %t723
  call void @olang_textcopy(ptr %t737, ptr %t725, i64 %t726)
  %t738 = getelementptr i8, ptr %t737, i64 %t726
  call void @olang_textcopy(ptr %t738, ptr %t729, i64 %t730)
  %t739 = getelementptr i8, ptr %t738, i64 %t730
  call void @olang_textcopy(ptr %t739, ptr %t732, i64 %t733)
  %t740 = insertvalue { i64, ptr } undef, i64 %t734, 0
  %t741 = insertvalue { i64, ptr } %t740, ptr %t735, 1
  %t743 = extractvalue { i64, ptr } %t741, 0
  %t744 = extractvalue { i64, ptr } %t741, 1
  %t745 = mul i64 %t743, 1
  %t746 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t745)
  call void @llvm.memcpy.p0.p0.i64(ptr %t746, ptr %t744, i64 %t745, i1 false)
  %t747 = insertvalue { i64, ptr } undef, i64 %t743, 0
  %t748 = insertvalue { i64, ptr } %t747, ptr %t746, 1
  %t749 = load ptr, ptr %l309, !tbaa !29
  %t751 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s19, ptr %s19, ptr %t749, { i64, ptr } %t748)
  store { i64, ptr } %t751, ptr %l316
  br label %bb110
bb110:
  %t752 = load { i64, ptr }, ptr %l316, !tbaa !27
  store { i64, ptr } %t752, ptr %l54, !tbaa !27
  %t753 = load ptr, ptr %l0, !tbaa !29
  %t755 = getelementptr %"compiler/emit:fnEm", ptr %t753, i32 0, i32 0
  %t756 = load ptr, ptr %t755, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2etextCopy(ptr %v0, ptr %t756)
  br label %bb111
bb111:
  %t758 = load ptr, ptr %l0, !tbaa !29
  %t759 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t760 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t761 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t762 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d446, i32 0, i32 1) }, 1
  %t763 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d446, i32 0, i32 1) }, 0
  %t765 = extractvalue { i64, ptr } %t759, 1
  %t766 = extractvalue { i64, ptr } %t759, 0
  %t767 = add i64 %t763, %t766
  %t768 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d447, i32 0, i32 1) }, 1
  %t769 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d447, i32 0, i32 1) }, 0
  %t770 = add i64 %t767, %t769
  %t772 = extractvalue { i64, ptr } %t760, 1
  %t773 = extractvalue { i64, ptr } %t760, 0
  %t774 = add i64 %t770, %t773
  %t775 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d448, i32 0, i32 1) }, 1
  %t776 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d448, i32 0, i32 1) }, 0
  %t777 = add i64 %t774, %t776
  %t779 = extractvalue { i64, ptr } %t761, 1
  %t780 = extractvalue { i64, ptr } %t761, 0
  %t781 = add i64 %t777, %t780
  %t782 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d449, i32 0, i32 1) }, 1
  %t783 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d449, i32 0, i32 1) }, 0
  %t784 = add i64 %t781, %t783
  %t785 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t784)
  call void @olang_textcopy(ptr %t785, ptr %t762, i64 %t763)
  %t786 = getelementptr i8, ptr %t785, i64 %t763
  call void @olang_textcopy(ptr %t786, ptr %t765, i64 %t766)
  %t787 = getelementptr i8, ptr %t786, i64 %t766
  call void @olang_textcopy(ptr %t787, ptr %t768, i64 %t769)
  %t788 = getelementptr i8, ptr %t787, i64 %t769
  call void @olang_textcopy(ptr %t788, ptr %t772, i64 %t773)
  %t789 = getelementptr i8, ptr %t788, i64 %t773
  call void @olang_textcopy(ptr %t789, ptr %t775, i64 %t776)
  %t790 = getelementptr i8, ptr %t789, i64 %t776
  call void @olang_textcopy(ptr %t790, ptr %t779, i64 %t780)
  %t791 = getelementptr i8, ptr %t790, i64 %t780
  call void @olang_textcopy(ptr %t791, ptr %t782, i64 %t783)
  %t792 = insertvalue { i64, ptr } undef, i64 %t784, 0
  %t793 = insertvalue { i64, ptr } %t792, ptr %t785, 1
  %t795 = extractvalue { i64, ptr } %t793, 0
  %t796 = extractvalue { i64, ptr } %t793, 1
  %t797 = mul i64 %t795, 1
  %t798 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t797)
  call void @llvm.memcpy.p0.p0.i64(ptr %t798, ptr %t796, i64 %t797, i1 false)
  %t799 = insertvalue { i64, ptr } undef, i64 %t795, 0
  %t800 = insertvalue { i64, ptr } %t799, ptr %t798, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s19, ptr %t758, { i64, ptr } %t800)
  br label %bb112
bb112:
  %t803 = load ptr, ptr %l0, !tbaa !29
  %t804 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t805 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t809 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epair(ptr %v0, ptr %s19, ptr %s19, ptr %v1, ptr %t803, { i64, ptr } %t804, { i64, ptr } %t805)
  store { i64, ptr } %t809, ptr %l328
  br label %bb113
bb113:
  call void @__olang_scope_close(ptr %s19)
  %t810 = load { i64, ptr }, ptr %l328, !tbaa !27
  store { i64, ptr } %t810, ptr %rv
  br label %ret
bb114:
  %t811 = load { i64, [15 x i64] }, ptr %l1
  %t813 = extractvalue { i64, [15 x i64] } %t811, 0
  %t814 = icmp eq i64 %t813, 13
  br i1 %t814, label %bb115, label %bb116
bb115:
  %t816 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t817 = getelementptr { { i64, [1 x i64] } }, ptr %t816, i32 0, i32 0
  %t818 = load { i64, [1 x i64] }, ptr %t817
  store { i64, [1 x i64] } %t818, ptr %l55
  br label %bb117
bb116:
  br label %bb122
bb117:
  store %olang.scope zeroinitializer, ptr %s24
  %t820 = load ptr, ptr %l0, !tbaa !29
  %t822 = getelementptr %"compiler/emit:fnEm", ptr %t820, i32 0, i32 0
  %t823 = load ptr, ptr %t822, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s24, ptr %t823, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d450, i32 0, i32 1) })
  br label %bb118
bb118:
  %t825 = load ptr, ptr %l0, !tbaa !29
  store ptr %t825, ptr %l334, !tbaa !29
  %t826 = load ptr, ptr %l0, !tbaa !29
  %t827 = load { i64, [1 x i64] }, ptr %l55
  %t830 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %s24, ptr %t826, { i64, [1 x i64] } %t827)
  store { i64, ptr } %t830, ptr %l337
  br label %bb119
bb119:
  %t831 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d451, i32 0, i32 1) }, 1
  %t832 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d451, i32 0, i32 1) }, 0
  %t833 = load { i64, ptr }, ptr %l337, !tbaa !27
  %t834 = extractvalue { i64, ptr } %t833, 1
  %t835 = extractvalue { i64, ptr } %t833, 0
  %t836 = add i64 %t832, %t835
  %t837 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d452, i32 0, i32 1) }, 1
  %t838 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d452, i32 0, i32 1) }, 0
  %t839 = add i64 %t836, %t838
  %t840 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t839)
  call void @olang_textcopy(ptr %t840, ptr %t831, i64 %t832)
  %t841 = getelementptr i8, ptr %t840, i64 %t832
  call void @olang_textcopy(ptr %t841, ptr %t834, i64 %t835)
  %t842 = getelementptr i8, ptr %t841, i64 %t835
  call void @olang_textcopy(ptr %t842, ptr %t837, i64 %t838)
  %t843 = insertvalue { i64, ptr } undef, i64 %t839, 0
  %t844 = insertvalue { i64, ptr } %t843, ptr %t840, 1
  %t846 = extractvalue { i64, ptr } %t844, 0
  %t847 = extractvalue { i64, ptr } %t844, 1
  %t848 = mul i64 %t846, 1
  %t849 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t848)
  call void @llvm.memcpy.p0.p0.i64(ptr %t849, ptr %t847, i64 %t848, i1 false)
  %t850 = insertvalue { i64, ptr } undef, i64 %t846, 0
  %t851 = insertvalue { i64, ptr } %t850, ptr %t849, 1
  %t852 = load ptr, ptr %l334, !tbaa !29
  %t854 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s24, ptr %s24, ptr %t852, { i64, ptr } %t851)
  store { i64, ptr } %t854, ptr %l340
  br label %bb120
bb120:
  %t855 = load { i64, ptr }, ptr %l340, !tbaa !27
  %t856 = load ptr, ptr %l0, !tbaa !29
  %t858 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d453, i32 0, i32 1) }, 1
  %t859 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d453, i32 0, i32 1) }, 0
  %t861 = extractvalue { i64, ptr } %t855, 1
  %t862 = extractvalue { i64, ptr } %t855, 0
  %t863 = add i64 %t859, %t862
  %t864 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d454, i32 0, i32 1) }, 1
  %t865 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d454, i32 0, i32 1) }, 0
  %t866 = add i64 %t863, %t865
  %t867 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t866)
  call void @olang_textcopy(ptr %t867, ptr %t858, i64 %t859)
  %t868 = getelementptr i8, ptr %t867, i64 %t859
  call void @olang_textcopy(ptr %t868, ptr %t861, i64 %t862)
  %t869 = getelementptr i8, ptr %t868, i64 %t862
  call void @olang_textcopy(ptr %t869, ptr %t864, i64 %t865)
  %t870 = insertvalue { i64, ptr } undef, i64 %t866, 0
  %t871 = insertvalue { i64, ptr } %t870, ptr %t867, 1
  %t873 = extractvalue { i64, ptr } %t871, 0
  %t874 = extractvalue { i64, ptr } %t871, 1
  %t875 = mul i64 %t873, 1
  %t876 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t875)
  call void @llvm.memcpy.p0.p0.i64(ptr %t876, ptr %t874, i64 %t875, i1 false)
  %t877 = insertvalue { i64, ptr } undef, i64 %t873, 0
  %t878 = insertvalue { i64, ptr } %t877, ptr %t876, 1
  %t881 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t856, { i64, ptr } %t878)
  store { i64, ptr } %t881, ptr %l345
  br label %bb121
bb121:
  call void @__olang_scope_close(ptr %s24)
  %t882 = load { i64, ptr }, ptr %l345, !tbaa !27
  store { i64, ptr } %t882, ptr %rv
  br label %ret
bb122:
  %t883 = load { i64, [15 x i64] }, ptr %l1
  %t885 = extractvalue { i64, [15 x i64] } %t883, 0
  %t886 = icmp eq i64 %t885, 14
  br i1 %t886, label %bb123, label %bb124
bb123:
  %t888 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t889 = getelementptr { { i64, [4 x i64] }, { i64, [1 x i64] } }, ptr %t888, i32 0, i32 0
  %t890 = load { i64, [4 x i64] }, ptr %t889
  store { i64, [4 x i64] } %t890, ptr %l57
  %t892 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t893 = getelementptr { { i64, [4 x i64] }, { i64, [1 x i64] } }, ptr %t892, i32 0, i32 1
  %t894 = load { i64, [1 x i64] }, ptr %t893
  store { i64, [1 x i64] } %t894, ptr %l58
  br label %bb125
bb124:
  br label %bb133
bb125:
  store %olang.scope zeroinitializer, ptr %s27
  %t896 = load ptr, ptr %l0, !tbaa !29
  %t898 = getelementptr %"compiler/emit:fnEm", ptr %t896, i32 0, i32 0
  %t899 = load ptr, ptr %t898, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s27, ptr %t899, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d455, i32 0, i32 1) })
  br label %bb126
bb126:
  %t901 = load ptr, ptr %l0, !tbaa !29
  store ptr %t901, ptr %l352, !tbaa !29
  %t902 = load ptr, ptr %l0, !tbaa !29
  %t903 = load { i64, [4 x i64] }, ptr %l57
  %t904 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t908 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s27, ptr %t902, { i64, [4 x i64] } %t903, i32 %t904)
  store { i64, ptr } %t908, ptr %l356
  br label %bb127
bb127:
  %t909 = load { i64, ptr }, ptr %l356, !tbaa !27
  %t910 = extractvalue { i64, ptr } %t909, 0
  %t911 = extractvalue { i64, ptr } %t909, 1
  %t912 = mul i64 %t910, 1
  %t913 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t912)
  call void @llvm.memcpy.p0.p0.i64(ptr %t913, ptr %t911, i64 %t912, i1 false)
  %t914 = insertvalue { i64, ptr } undef, i64 %t910, 0
  %t915 = insertvalue { i64, ptr } %t914, ptr %t913, 1
  store { i64, ptr } %t915, ptr %l357, !tbaa !27
  %t916 = load ptr, ptr %l0, !tbaa !29
  %t917 = load { i64, [4 x i64] }, ptr %l57
  %t920 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t916, { i64, [4 x i64] } %t917)
  store i32 %t920, ptr %l360
  br label %bb128
bb128:
  %t921 = load ptr, ptr %l352, !tbaa !29
  %t922 = load { i64, ptr }, ptr %l357, !tbaa !27
  %t923 = load i32, ptr %l360, !tbaa !23
  %t924 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eobjectPtr(ptr %v0, ptr %s27, ptr %s27, ptr %t921, { i64, ptr } %t922, i32 %t923)
  store { i64, ptr } %t924, ptr %l361
  br label %bb129
bb129:
  %t925 = load { i64, ptr }, ptr %l361, !tbaa !27
  %t926 = load ptr, ptr %l0, !tbaa !29
  store ptr %t926, ptr %l362, !tbaa !29
  store { i64, ptr } %t925, ptr %l363, !tbaa !27
  %t928 = load ptr, ptr %l0, !tbaa !29
  %t929 = load { i64, [1 x i64] }, ptr %l58
  %t932 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %s27, ptr %t928, { i64, [1 x i64] } %t929)
  store { i64, ptr } %t932, ptr %l366
  br label %bb130
bb130:
  %t933 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d456, i32 0, i32 1) }, 1
  %t934 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d456, i32 0, i32 1) }, 0
  %t935 = load { i64, ptr }, ptr %l363, !tbaa !27
  %t936 = extractvalue { i64, ptr } %t935, 1
  %t937 = extractvalue { i64, ptr } %t935, 0
  %t938 = add i64 %t934, %t937
  %t939 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d457, i32 0, i32 1) }, 1
  %t940 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d457, i32 0, i32 1) }, 0
  %t941 = add i64 %t938, %t940
  %t942 = load { i64, ptr }, ptr %l366, !tbaa !27
  %t943 = extractvalue { i64, ptr } %t942, 1
  %t944 = extractvalue { i64, ptr } %t942, 0
  %t945 = add i64 %t941, %t944
  %t946 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d458, i32 0, i32 1) }, 1
  %t947 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d458, i32 0, i32 1) }, 0
  %t948 = add i64 %t945, %t947
  %t949 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t948)
  call void @olang_textcopy(ptr %t949, ptr %t933, i64 %t934)
  %t950 = getelementptr i8, ptr %t949, i64 %t934
  call void @olang_textcopy(ptr %t950, ptr %t936, i64 %t937)
  %t951 = getelementptr i8, ptr %t950, i64 %t937
  call void @olang_textcopy(ptr %t951, ptr %t939, i64 %t940)
  %t952 = getelementptr i8, ptr %t951, i64 %t940
  call void @olang_textcopy(ptr %t952, ptr %t943, i64 %t944)
  %t953 = getelementptr i8, ptr %t952, i64 %t944
  call void @olang_textcopy(ptr %t953, ptr %t946, i64 %t947)
  %t954 = insertvalue { i64, ptr } undef, i64 %t948, 0
  %t955 = insertvalue { i64, ptr } %t954, ptr %t949, 1
  %t957 = extractvalue { i64, ptr } %t955, 0
  %t958 = extractvalue { i64, ptr } %t955, 1
  %t959 = mul i64 %t957, 1
  %t960 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t959)
  call void @llvm.memcpy.p0.p0.i64(ptr %t960, ptr %t958, i64 %t959, i1 false)
  %t961 = insertvalue { i64, ptr } undef, i64 %t957, 0
  %t962 = insertvalue { i64, ptr } %t961, ptr %t960, 1
  %t963 = load ptr, ptr %l362, !tbaa !29
  %t965 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s27, ptr %s27, ptr %t963, { i64, ptr } %t962)
  store { i64, ptr } %t965, ptr %l369
  br label %bb131
bb131:
  %t966 = load { i64, ptr }, ptr %l369, !tbaa !27
  %t967 = load ptr, ptr %l0, !tbaa !29
  %t969 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d459, i32 0, i32 1) }, 1
  %t970 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d459, i32 0, i32 1) }, 0
  %t972 = extractvalue { i64, ptr } %t966, 1
  %t973 = extractvalue { i64, ptr } %t966, 0
  %t974 = add i64 %t970, %t973
  %t975 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d460, i32 0, i32 1) }, 1
  %t976 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d460, i32 0, i32 1) }, 0
  %t977 = add i64 %t974, %t976
  %t978 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t977)
  call void @olang_textcopy(ptr %t978, ptr %t969, i64 %t970)
  %t979 = getelementptr i8, ptr %t978, i64 %t970
  call void @olang_textcopy(ptr %t979, ptr %t972, i64 %t973)
  %t980 = getelementptr i8, ptr %t979, i64 %t973
  call void @olang_textcopy(ptr %t980, ptr %t975, i64 %t976)
  %t981 = insertvalue { i64, ptr } undef, i64 %t977, 0
  %t982 = insertvalue { i64, ptr } %t981, ptr %t978, 1
  %t984 = extractvalue { i64, ptr } %t982, 0
  %t985 = extractvalue { i64, ptr } %t982, 1
  %t986 = mul i64 %t984, 1
  %t987 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t986)
  call void @llvm.memcpy.p0.p0.i64(ptr %t987, ptr %t985, i64 %t986, i1 false)
  %t988 = insertvalue { i64, ptr } undef, i64 %t984, 0
  %t989 = insertvalue { i64, ptr } %t988, ptr %t987, 1
  %t992 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t967, { i64, ptr } %t989)
  store { i64, ptr } %t992, ptr %l374
  br label %bb132
bb132:
  call void @__olang_scope_close(ptr %s27)
  %t993 = load { i64, ptr }, ptr %l374, !tbaa !27
  store { i64, ptr } %t993, ptr %rv
  br label %ret
bb133:
  call void @__olang_check_failed(ptr @olang_loc_b25f444594da9527_de5411018827488b)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2eunwindPush(ptr %v0, ptr %a0, i32 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %s0, ptr %s0, ptr %t4, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d461, i32 0, i32 1) }, { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d462, i32 0, i32 1) })
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t6, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d463, i32 0, i32 1) }, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d464, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d174, i32 0, i32 1) })
  store { i64, ptr } %t8, ptr %l7
  br label %bb2
bb2:
  %t9 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l8, !tbaa !29
  store { i64, ptr } %t9, ptr %l9, !tbaa !27
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l1, !tbaa !23
  %t14 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d465, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d465, i32 0, i32 1) }, 0
  %t17 = sext i32 %t13 to i64
  %t18 = call i64 @__olang_fmt_i64(ptr null, i64 %t17)
  %t19 = add i64 %t15, %t18
  %t20 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d466, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d466, i32 0, i32 1) }, 0
  %t22 = add i64 %t19, %t21
  %t23 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t14, i64 %t15)
  %t24 = getelementptr i8, ptr %t23, i64 %t15
  %t25 = call i64 @__olang_fmt_i64(ptr %t24, i64 %t17)
  %t26 = getelementptr i8, ptr %t24, i64 %t18
  call void @olang_textcopy(ptr %t26, ptr %t20, i64 %t21)
  %t27 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t23, 1
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t31 = extractvalue { i64, ptr } %t28, 1
  %t32 = mul i64 %t30, 1
  %t33 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t32)
  call void @llvm.memcpy.p0.p0.i64(ptr %t33, ptr %t31, i64 %t32, i1 false)
  %t34 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  %t38 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t12, { i64, ptr } %t35)
  store { i64, ptr } %t38, ptr %l14
  br label %bb3
bb3:
  %t39 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  %t41 = extractvalue { i64, ptr } %t39, 1
  %t42 = mul i64 %t40, 1
  %t43 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t42)
  call void @llvm.memcpy.p0.p0.i64(ptr %t43, ptr %t41, i64 %t42, i1 false)
  %t44 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  %t46 = load ptr, ptr %l8, !tbaa !29
  %t47 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t46, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d467, i32 0, i32 1) }, { i64, ptr } %t47, { i64, ptr } %t45, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d118, i32 0, i32 1) })
  br label %bb4
bb4:
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l16, !tbaa !29
  %t50 = load i32, ptr %l1, !tbaa !23
  %t51 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d468, i32 0, i32 1) }, 1
  %t52 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d468, i32 0, i32 1) }, 0
  %t54 = sext i32 %t50 to i64
  %t55 = call i64 @__olang_fmt_i64(ptr null, i64 %t54)
  %t56 = add i64 %t52, %t55
  %t57 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t51, i64 %t52)
  %t58 = getelementptr i8, ptr %t57, i64 %t52
  %t59 = call i64 @__olang_fmt_i64(ptr %t58, i64 %t54)
  %t60 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t57, 1
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t64 = extractvalue { i64, ptr } %t61, 1
  %t65 = mul i64 %t63, 1
  %t66 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t65)
  call void @llvm.memcpy.p0.p0.i64(ptr %t66, ptr %t64, i64 %t65, i1 false)
  %t67 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  store { i64, ptr } %t68, ptr %l19, !tbaa !27
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i32, ptr %l1, !tbaa !23
  %t71 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d469, i32 0, i32 1) }, 1
  %t72 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d469, i32 0, i32 1) }, 0
  %t74 = sext i32 %t70 to i64
  %t75 = call i64 @__olang_fmt_i64(ptr null, i64 %t74)
  %t76 = add i64 %t72, %t75
  %t77 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d470, i32 0, i32 1) }, 1
  %t78 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d470, i32 0, i32 1) }, 0
  %t79 = add i64 %t76, %t78
  %t80 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t79)
  call void @olang_textcopy(ptr %t80, ptr %t71, i64 %t72)
  %t81 = getelementptr i8, ptr %t80, i64 %t72
  %t82 = call i64 @__olang_fmt_i64(ptr %t81, i64 %t74)
  %t83 = getelementptr i8, ptr %t81, i64 %t75
  call void @olang_textcopy(ptr %t83, ptr %t77, i64 %t78)
  %t84 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t80, 1
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t88 = extractvalue { i64, ptr } %t85, 1
  %t89 = mul i64 %t87, 1
  %t90 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t89)
  call void @llvm.memcpy.p0.p0.i64(ptr %t90, ptr %t88, i64 %t89, i1 false)
  %t91 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t90, 1
  %t95 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t69, { i64, ptr } %t92)
  store { i64, ptr } %t95, ptr %l24
  br label %bb5
bb5:
  %t96 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 0
  %t98 = extractvalue { i64, ptr } %t96, 1
  %t99 = mul i64 %t97, 1
  %t100 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t99)
  call void @llvm.memcpy.p0.p0.i64(ptr %t100, ptr %t98, i64 %t99, i1 false)
  %t101 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t100, 1
  %t103 = load ptr, ptr %l16, !tbaa !29
  %t104 = load { i64, ptr }, ptr %l19, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t103, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d471, i32 0, i32 1) }, { i64, ptr } %t104, { i64, ptr } %t102, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d118, i32 0, i32 1) })
  br label %bb6
bb6:
  %t106 = load ptr, ptr %l0, !tbaa !29
  store ptr %t106, ptr %l26, !tbaa !29
  br i1 %a2, label %bb7, label %bb8
bb7:
  %t109 = load i32, ptr %l1, !tbaa !23
  %t110 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d472, i32 0, i32 1) }, 1
  %t111 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d472, i32 0, i32 1) }, 0
  %t113 = sext i32 %t109 to i64
  %t114 = call i64 @__olang_fmt_i64(ptr null, i64 %t113)
  %t115 = add i64 %t111, %t114
  %t116 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t115)
  call void @olang_textcopy(ptr %t116, ptr %t110, i64 %t111)
  %t117 = getelementptr i8, ptr %t116, i64 %t111
  %t118 = call i64 @__olang_fmt_i64(ptr %t117, i64 %t113)
  %t119 = insertvalue { i64, ptr } undef, i64 %t115, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t116, 1
  %t122 = extractvalue { i64, ptr } %t120, 0
  %t123 = extractvalue { i64, ptr } %t120, 1
  %t124 = mul i64 %t122, 1
  %t125 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t124)
  call void @llvm.memcpy.p0.p0.i64(ptr %t125, ptr %t123, i64 %t124, i1 false)
  %t126 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t125, 1
  store { i64, ptr } %t127, ptr %l28, !tbaa !27
  br label %bb9
bb8:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d473, i32 0, i32 1) }, ptr %l28, !tbaa !27
  br label %bb9
bb9:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load i32, ptr %l1, !tbaa !23
  %t131 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d474, i32 0, i32 1) }, 1
  %t132 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d474, i32 0, i32 1) }, 0
  %t134 = sext i32 %t130 to i64
  %t135 = call i64 @__olang_fmt_i64(ptr null, i64 %t134)
  %t136 = add i64 %t132, %t135
  %t137 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d475, i32 0, i32 1) }, 1
  %t138 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d475, i32 0, i32 1) }, 0
  %t139 = add i64 %t136, %t138
  %t140 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t139)
  call void @olang_textcopy(ptr %t140, ptr %t131, i64 %t132)
  %t141 = getelementptr i8, ptr %t140, i64 %t132
  %t142 = call i64 @__olang_fmt_i64(ptr %t141, i64 %t134)
  %t143 = getelementptr i8, ptr %t141, i64 %t135
  call void @olang_textcopy(ptr %t143, ptr %t137, i64 %t138)
  %t144 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t140, 1
  %t147 = extractvalue { i64, ptr } %t145, 0
  %t148 = extractvalue { i64, ptr } %t145, 1
  %t149 = mul i64 %t147, 1
  %t150 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t149)
  call void @llvm.memcpy.p0.p0.i64(ptr %t150, ptr %t148, i64 %t149, i1 false)
  %t151 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t150, 1
  %t155 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t129, { i64, ptr } %t152)
  store { i64, ptr } %t155, ptr %l36
  br label %bb10
bb10:
  %t156 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t156, 0
  %t158 = extractvalue { i64, ptr } %t156, 1
  %t159 = mul i64 %t157, 1
  %t160 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t159)
  call void @llvm.memcpy.p0.p0.i64(ptr %t160, ptr %t158, i64 %t159, i1 false)
  %t161 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t160, 1
  %t163 = load ptr, ptr %l26, !tbaa !29
  %t164 = load { i64, ptr }, ptr %l28, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t163, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d476, i32 0, i32 1) }, { i64, ptr } %t164, { i64, ptr } %t162, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d118, i32 0, i32 1) })
  br label %bb11
bb11:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load i32, ptr %l1, !tbaa !23
  %t168 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d477, i32 0, i32 1) }, 1
  %t169 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d477, i32 0, i32 1) }, 0
  %t171 = sext i32 %t167 to i64
  %t172 = call i64 @__olang_fmt_i64(ptr null, i64 %t171)
  %t173 = add i64 %t169, %t172
  %t174 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t173)
  call void @olang_textcopy(ptr %t174, ptr %t168, i64 %t169)
  %t175 = getelementptr i8, ptr %t174, i64 %t169
  %t176 = call i64 @__olang_fmt_i64(ptr %t175, i64 %t171)
  %t177 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t174, 1
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t181 = extractvalue { i64, ptr } %t178, 1
  %t182 = mul i64 %t180, 1
  %t183 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t182)
  call void @llvm.memcpy.p0.p0.i64(ptr %t183, ptr %t181, i64 %t182, i1 false)
  %t184 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t183, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t166, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d478, i32 0, i32 1) }, { i64, ptr } %t185, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d479, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d118, i32 0, i32 1) })
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2emathExact_2einit() #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2emathExactTable(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr @G_2ecompiler_2femit_2emathExact
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_3aEmitter_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca i64
  %l17 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l21 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l23 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i1
  %l28 = alloca i64
  %l29 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l30 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l31 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l32 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l33 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l34 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l35 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l36 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l37 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l38 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l39 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l40 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l41 = alloca i1
  %l42 = alloca i1
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i1
  %l46 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l47 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l48 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l49 = alloca { i64, ptr }
  %l50 = alloca i1
  %l51 = alloca i1
  %l52 = alloca { i64, ptr }
  %l53 = alloca i1
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l59 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l60 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l61 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l62 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l63 = alloca i1
  %l64 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l65 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l66 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l67 = alloca i1
  %l68 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l69 = alloca i1
  %l70 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l71 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l77 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l78 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l79 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l80 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l81 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l82 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l83 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l84 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l85 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l86 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l87 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l88 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l89 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l90 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l91 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l92 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l93 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l94 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l95 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l96 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l97 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l98 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l99 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l101 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l102 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l103 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l104 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l105 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l106 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l107 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l108 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l109 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l110 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l111 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l112 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l113 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l114 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l115 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l116 = alloca %"compiler/emit:Emitter"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l4, !tbaa !29
  store ptr %a1, ptr %l5, !tbaa !29
  store ptr %a2, ptr %l6, !tbaa !29
  store ptr %a3, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  store i1 false, ptr %l9, !tbaa !21
  store i1 false, ptr %l10, !tbaa !21
  store i1 true, ptr %l11, !tbaa !21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d480, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t9 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l77
  br label %bb1
bb1:
  %t10 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l77
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l13
  %t11 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l78
  br label %bb2
bb2:
  %t12 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l78
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l14
  %t13 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e(ptr %v4)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l79
  br label %bb3
bb3:
  %t14 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l79
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, ptr %l15
  store i64 -1, ptr %l16, !tbaa !24
  %t15 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %l80
  br label %bb4
bb4:
  %t16 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l80
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l17
  %t17 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e(ptr %v4)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, ptr %l81
  br label %bb5
bb5:
  %t18 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l81
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t18, ptr %l18
  %t19 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, ptr %l82
  br label %bb6
bb6:
  %t20 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l82
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t20, ptr %l19
  %t21 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, ptr %l83
  br label %bb7
bb7:
  %t22 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l83
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l20
  %t23 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %l84
  br label %bb8
bb8:
  %t24 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l84
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l21
  %t25 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l85
  br label %bb9
bb9:
  %t26 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l85
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t26, ptr %l22
  %t27 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %v4)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t27, ptr %l86
  br label %bb10
bb10:
  %t28 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l86
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, ptr %l23
  %t29 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t29, ptr %l87
  br label %bb11
bb11:
  %t30 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l87
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t30, ptr %l24
  store { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d481, i32 0, i32 1) }, ptr %l25, !tbaa !27
  store i64 0, ptr %l26, !tbaa !24
  store i1 false, ptr %l27, !tbaa !21
  store i64 0, ptr %l28, !tbaa !24
  %t31 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_Hf48d6d4096e547b8075d5a903caa3d54(ptr %v4)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t31, ptr %l88
  br label %bb12
bb12:
  %t32 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l88
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %l29
  %t33 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t33, ptr %l89
  br label %bb13
bb13:
  %t34 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l89
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t34, ptr %l30
  %t35 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %v4)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t35, ptr %l90
  br label %bb14
bb14:
  %t36 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l90
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t36, ptr %l31
  %t37 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t37, ptr %l91
  br label %bb15
bb15:
  %t38 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l91
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t38, ptr %l32
  %t39 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t39, ptr %l92
  br label %bb16
bb16:
  %t40 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l92
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, ptr %l33
  %t41 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t41, ptr %l93
  br label %bb17
bb17:
  %t42 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l93
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t42, ptr %l34
  %t43 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t43, ptr %l94
  br label %bb18
bb18:
  %t44 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l94
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t44, ptr %l35
  %t45 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %v4)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t45, ptr %l95
  br label %bb19
bb19:
  %t46 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l95
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t46, ptr %l36
  %t47 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t47, ptr %l96
  br label %bb20
bb20:
  %t48 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l96
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t48, ptr %l37
  %t49 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e(ptr %v4)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t49, ptr %l97
  br label %bb21
bb21:
  %t50 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l97
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t50, ptr %l38
  %t51 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %v4)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t51, ptr %l98
  br label %bb22
bb22:
  %t52 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l98
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t52, ptr %l39
  %t53 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %v4)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t53, ptr %l99
  br label %bb23
bb23:
  %t54 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l99
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t54, ptr %l40
  store i1 false, ptr %l41, !tbaa !21
  store i1 false, ptr %l42, !tbaa !21
  store i64 4611686018427387904, ptr %l43, !tbaa !24
  %t55 = load i64, ptr @G_2ecompiler_2femit_2ePartSize, !tbaa !24
  store i64 %t55, ptr %l44, !tbaa !24
  store i1 false, ptr %l45, !tbaa !21
  %t57 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t57, ptr %l101
  br label %bb24
bb24:
  %t58 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l101
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t58, ptr %l46
  %t59 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %v4)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t59, ptr %l102
  br label %bb25
bb25:
  %t60 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l102
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t60, ptr %l47
  %t61 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e(ptr %v4)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t61, ptr %l103
  br label %bb26
bb26:
  %t62 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l103
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t62, ptr %l48
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d482, i32 0, i32 1) }, ptr %l49, !tbaa !27
  store i1 false, ptr %l50, !tbaa !21
  store i1 false, ptr %l51, !tbaa !21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d483, i32 0, i32 1) }, ptr %l52, !tbaa !27
  store i1 false, ptr %l53, !tbaa !21
  store i64 1000, ptr %l54, !tbaa !24
  store i64 -1, ptr %l55, !tbaa !24
  store i64 -1, ptr %l56, !tbaa !24
  store i64 -1, ptr %l57, !tbaa !24
  %t63 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v4)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t63, ptr %l104
  br label %bb27
bb27:
  %t64 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l104
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t64, ptr %l58
  %t65 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v4)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t65, ptr %l105
  br label %bb28
bb28:
  %t66 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l105
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t66, ptr %l59
  %t67 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v4)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t67, ptr %l106
  br label %bb29
bb29:
  %t68 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l106
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t68, ptr %l60
  %t69 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v4)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t69, ptr %l107
  br label %bb30
bb30:
  %t70 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l107
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t70, ptr %l61
  %t71 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e(ptr %v4)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t71, ptr %l108
  br label %bb31
bb31:
  %t72 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l108
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t72, ptr %l62
  store i1 false, ptr %l63, !tbaa !21
  %t73 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aReused_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t73, ptr %l109
  br label %bb32
bb32:
  %t74 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l109
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t74, ptr %l64
  %t75 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v4)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t75, ptr %l110
  br label %bb33
bb33:
  %t76 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l110
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t76, ptr %l65
  %t77 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aReused_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t77, ptr %l111
  br label %bb34
bb34:
  %t78 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l111
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t78, ptr %l66
  store i1 false, ptr %l67, !tbaa !21
  %t79 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e(ptr %v4)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t79, ptr %l112
  br label %bb35
bb35:
  %t80 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l112
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t80, ptr %l68
  store i1 false, ptr %l69, !tbaa !21
  %t81 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v4)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t81, ptr %l113
  br label %bb36
bb36:
  %t82 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l113
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t82, ptr %l70
  %t83 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t83, ptr %l114
  br label %bb37
bb37:
  %t84 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l114
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t84, ptr %l71
  %t85 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v4)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t85, ptr %l115
  br label %bb38
bb38:
  %t86 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l115
  %t87 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 0
  %t88 = load ptr, ptr %l4, !tbaa !29
  store ptr %t88, ptr %t87, !tbaa !29
  %t89 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 1
  %t90 = load ptr, ptr %l5, !tbaa !29
  store ptr %t90, ptr %t89, !tbaa !29
  %t91 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 2
  %t92 = load ptr, ptr %l6, !tbaa !29
  store ptr %t92, ptr %t91, !tbaa !29
  %t93 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 3
  %t94 = load ptr, ptr %l7, !tbaa !29
  store ptr %t94, ptr %t93, !tbaa !29
  %t95 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 4
  %t96 = load i1, ptr %l8, !tbaa !21
  store i1 %t96, ptr %t95, !tbaa !21
  %t97 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 5
  %t98 = load i1, ptr %l9, !tbaa !21
  store i1 %t98, ptr %t97, !tbaa !21
  %t99 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 6
  %t100 = load i1, ptr %l10, !tbaa !21
  store i1 %t100, ptr %t99, !tbaa !21
  %t101 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 7
  %t102 = load i1, ptr %l11, !tbaa !21
  store i1 %t102, ptr %t101, !tbaa !21
  %t103 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 8
  %t104 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t104, ptr %t103, !tbaa !27
  %t105 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 9
  %t106 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t106, ptr %t105
  %t107 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 10
  %t108 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l14
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t108, ptr %t107
  %t109 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 11
  %t110 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l15
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t110, ptr %t109
  %t111 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 12
  %t112 = load i64, ptr %l16, !tbaa !24
  store i64 %t112, ptr %t111, !tbaa !24
  %t113 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 13
  %t114 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l17
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t114, ptr %t113
  %t115 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 14
  %t116 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l18
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t116, ptr %t115
  %t117 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 15
  %t118 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t118, ptr %t117
  %t119 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 16
  %t120 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t120, ptr %t119
  %t121 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 17
  %t122 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l21
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t122, ptr %t121
  %t123 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 18
  %t124 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l22
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t124, ptr %t123
  %t125 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 19
  %t126 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l23
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t126, ptr %t125
  %t127 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 20
  %t128 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l24
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t128, ptr %t127
  %t129 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 21
  %t130 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t130, ptr %t129, !tbaa !27
  %t131 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 22
  %t132 = load i64, ptr %l26, !tbaa !24
  store i64 %t132, ptr %t131, !tbaa !24
  %t133 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 23
  %t134 = load i1, ptr %l27, !tbaa !21
  store i1 %t134, ptr %t133, !tbaa !21
  %t135 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 24
  %t136 = load i64, ptr %l28, !tbaa !24
  store i64 %t136, ptr %t135, !tbaa !24
  %t137 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 25
  %t138 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l29
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t138, ptr %t137
  %t139 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 26
  %t140 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l30
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t140, ptr %t139
  %t141 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 27
  %t142 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l31
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t142, ptr %t141
  %t143 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 28
  %t144 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l32
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t144, ptr %t143
  %t145 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 29
  %t146 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l33
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t146, ptr %t145
  %t147 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 30
  %t148 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l34
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t148, ptr %t147
  %t149 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 31
  %t150 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l35
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t150, ptr %t149
  %t151 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 32
  %t152 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l36
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t152, ptr %t151
  %t153 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 33
  %t154 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l37
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t154, ptr %t153
  %t155 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 34
  %t156 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l38
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t156, ptr %t155
  %t157 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 35
  %t158 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l39
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t158, ptr %t157
  %t159 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 36
  %t160 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l40
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t160, ptr %t159
  %t161 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 37
  %t162 = load i1, ptr %l41, !tbaa !21
  store i1 %t162, ptr %t161, !tbaa !21
  %t163 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 38
  %t164 = load i1, ptr %l42, !tbaa !21
  store i1 %t164, ptr %t163, !tbaa !21
  %t165 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 39
  %t166 = load i64, ptr %l43, !tbaa !24
  store i64 %t166, ptr %t165, !tbaa !24
  %t167 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 40
  %t168 = load i64, ptr %l44, !tbaa !24
  store i64 %t168, ptr %t167, !tbaa !24
  %t169 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 41
  %t170 = load i1, ptr %l45, !tbaa !21
  store i1 %t170, ptr %t169, !tbaa !21
  %t171 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 42
  %t172 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l46
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t172, ptr %t171
  %t173 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 43
  %t174 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l47
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t174, ptr %t173
  %t175 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 44
  %t176 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l48
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t176, ptr %t175
  %t177 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 45
  %t178 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t178, ptr %t177, !tbaa !27
  %t179 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 46
  %t180 = load i1, ptr %l50, !tbaa !21
  store i1 %t180, ptr %t179, !tbaa !21
  %t181 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 47
  %t182 = load i1, ptr %l51, !tbaa !21
  store i1 %t182, ptr %t181, !tbaa !21
  %t183 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 48
  %t184 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t184, ptr %t183, !tbaa !27
  %t185 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 49
  %t186 = load i1, ptr %l53, !tbaa !21
  store i1 %t186, ptr %t185, !tbaa !21
  %t187 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 50
  %t188 = load i64, ptr %l54, !tbaa !24
  store i64 %t188, ptr %t187, !tbaa !24
  %t189 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 51
  %t190 = load i64, ptr %l55, !tbaa !24
  store i64 %t190, ptr %t189, !tbaa !24
  %t191 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 52
  %t192 = load i64, ptr %l56, !tbaa !24
  store i64 %t192, ptr %t191, !tbaa !24
  %t193 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 53
  %t194 = load i64, ptr %l57, !tbaa !24
  store i64 %t194, ptr %t193, !tbaa !24
  %t195 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 54
  %t196 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l58
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t196, ptr %t195
  %t197 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 55
  %t198 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l59
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t198, ptr %t197
  %t199 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 56
  %t200 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l60
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t200, ptr %t199
  %t201 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 57
  %t202 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l61
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t202, ptr %t201
  %t203 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 58
  %t204 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l62
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t204, ptr %t203
  %t205 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 59
  %t206 = load i1, ptr %l63, !tbaa !21
  store i1 %t206, ptr %t205, !tbaa !21
  %t207 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 60
  %t208 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l64
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t208, ptr %t207
  %t209 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 61
  %t210 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l65
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t210, ptr %t209
  %t211 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 62
  %t212 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l66
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t212, ptr %t211
  %t213 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 63
  %t214 = load i1, ptr %l67, !tbaa !21
  store i1 %t214, ptr %t213, !tbaa !21
  %t215 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 64
  %t216 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l68
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t216, ptr %t215
  %t217 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 65
  %t218 = load i1, ptr %l69, !tbaa !21
  store i1 %t218, ptr %t217, !tbaa !21
  %t219 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 66
  %t220 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l70
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t220, ptr %t219
  %t221 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 67
  %t222 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l71
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t222, ptr %t221
  %t223 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 68
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t86, ptr %t223
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l116, i64 544, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/emit:Object" @compiler_2femit_3aObject_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %rv = alloca %"compiler/emit:Object"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/emit:Object" undef, { i64, ptr } %a0, 0
  %t10 = insertvalue %"compiler/emit:Object" %t8, i32 %a1, 1
  %t12 = insertvalue %"compiler/emit:Object" %t10, { i64, ptr } %a2, 2
  %t14 = insertvalue %"compiler/emit:Object" %t12, i64 -1, 3
  store %"compiler/emit:Object" %t14, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/emit:Object", ptr %rv
  ret %"compiler/emit:Object" %rr
}

@.d0 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"|" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d3 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d4 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".ctor" }>, align 8
@.d5 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".dtor" }>, align 8
@.d6 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"olang_lambda_" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d7 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d8 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".init" }>, align 8
@.d9 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"olang_case_" }>, align 8
@.d10 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"olang_cond_" }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
@.d11 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c".contract." }>, align 8
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aContractKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d484, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d484, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
ret:
  ret void
}

@.d12 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare void @__olang_sb_add(ptr, i64)
declare void @__olang_sb_done(ptr)
@.d13 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"olang.slot." }>, align 8
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d15 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"olang.traitslot." }>, align 8
@.d16 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
declare void @__olang_check_failed(ptr)
@.d17 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"llvm.coro.id" }>, align 8
@.d18 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"token @llvm.coro.id(i32, ptr, ptr, ptr)" }>, align 8
@.d19 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"llvm.coro.size.i64" }>, align 8
@.d20 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"i64 @llvm.coro.size.i64()" }>, align 8
@.d21 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"llvm.coro.align.i64" }>, align 8
@.d22 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"i64 @llvm.coro.align.i64()" }>, align 8
@.d23 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"llvm.coro.begin" }>, align 8
@.d24 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"ptr @llvm.coro.begin(token, ptr)" }>, align 8
@.d25 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"llvm.coro.suspend" }>, align 8
@.d26 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"i8 @llvm.coro.suspend(token, i1)" }>, align 8
@.d27 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"llvm.coro.end" }>, align 8
@.d28 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"i1 @llvm.coro.end(ptr, i1, token)" }>, align 8
@.d29 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"llvm.coro.free" }>, align 8
@.d30 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"ptr @llvm.coro.free(token, ptr)" }>, align 8
@.d31 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"llvm.coro.resume" }>, align 8
@.d32 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"void @llvm.coro.resume(ptr)" }>, align 8
@.d33 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"llvm.coro.destroy" }>, align 8
@.d34 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"void @llvm.coro.destroy(ptr)" }>, align 8
@.d35 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"llvm.coro.done" }>, align 8
@.d36 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"i1 @llvm.coro.done(ptr)" }>, align 8
@.d37 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"llvm.coro.promise" }>, align 8
@.d38 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"ptr @llvm.coro.promise(ptr, i32, i1)" }>, align 8
@.d39 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"!" }>, align 8
@.d40 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"!" }>, align 8
@.d41 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d42 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d43 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d44 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.d45 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"olang_test_" }>, align 8
@.d46 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"main" }>, align 8
@.d47 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"|adapter" }>, align 8
@.d48 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d49 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"|" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d50 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"f" }>, align 8
declare void @__olang_ert_req_clear()
@.d51 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d52 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d53 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d54 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"32" }>, align 8
@.d55 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"64" }>, align 8
@.d56 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"llvm." }>, align 8
@.d57 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".f" }>, align 8
@.d58 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"olang.notable" }>, align 8
@.d59 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c"@olang.notable = linkonce_odr constant ptr null\0A" }>, align 8
@.d60 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"olang.notable" }>, align 8
@.d61 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"  %rhi = lshr i32 " }>, align 8
@.d62 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c", 16\0A  %rw = and i32 " }>, align 8
@.d63 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", 65535\0A" }>, align 8
@.d64 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
@.d65 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"  %rh" }>, align 8
@.d66 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c" = icmp eq i32 %rhi, " }>, align 8
@.d67 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d68 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"  %rp" }>, align 8
@.d69 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c" = select i1 %rh" }>, align 8
@.d70 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i32 " }>, align 8
@.d71 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d72 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%rp" }>, align 8
@.d73 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"  %rs = shl i32 " }>, align 8
@.d74 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c", 16\0A  %rv2 = or i32 %rs, %rw\0A" }>, align 8
@.d75 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"%rv2" }>, align 8
@.d76 = private constant <{ i64, [66 x i8] }> <{ i64 0, [66 x i8] c"the runtime's text (std/runtime/runtime.ll could not be filled in)" }>, align 8
@.d77 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d78 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d79 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d80 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d81 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"%" }>, align 8
@.d82 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d83 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"define " }>, align 8
@.d84 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d85 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c"%olang.builder = type { ptr, i64, i64, ptr, ptr }\0A" }>, align 8
@.d86 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d87 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"an unknown type" }>, align 8
@.d88 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"i8" }>, align 8
@.d89 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"a type with no layout: " }>, align 8
@.d90 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"bitcast bfloat " }>, align 8
@.d91 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" to i16" }>, align 8
@.d92 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d93 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"extractvalue { ptr, ptr } " }>, align 8
@.d94 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d95 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"extractvalue { ptr, ptr } " }>, align 8
@.d96 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d97 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ptr " }>, align 8
@.d98 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d99 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ptr " }>, align 8
@.d100 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aOperand(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %l8 = alloca i1
  %l26 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb16
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 i64 3, label %bb6 ]
bb3:
  br label %bb16
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { %"compiler/mir:Place" }, ptr %t11, i32 0, i32 0
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr { i64, [4 x i64] }, ptr %t13, i32 0, i32 1
  %t15 = getelementptr { %"compiler/mir:Place" }, ptr %t14, i32 0, i32 0
  %t18 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aPlace(ptr %t12, ptr %t15)
  store i1 %t18, ptr %l8
  br label %bb7
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t21 = getelementptr { i32, i64 }, ptr %t20, i32 0, i32 0
  %t22 = load i32, ptr %t21
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t23, i32 0, i32 1
  %t25 = getelementptr { i32, i64 }, ptr %t24, i32 0, i32 0
  %t26 = load i32, ptr %t25
  %t29 = icmp eq i32 %t22, %t26
  br i1 %t29, label %bb9, label %bb1
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t33 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t32, i32 0, i32 0
  %t34 = load i32, ptr %t33
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr { i64, [4 x i64] }, ptr %t35, i32 0, i32 1
  %t37 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t36, i32 0, i32 0
  %t38 = load i32, ptr %t37
  %t41 = icmp eq i32 %t34, %t38
  br i1 %t41, label %bb11, label %bb1
bb7:
  %t43 = load i1, ptr %l8, !tbaa !21
  br i1 %t43, label %bb8, label %bb1
bb8:
  br label %bb3
bb9:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 1
  %t46 = getelementptr { i32, i64 }, ptr %t45, i32 0, i32 1
  %t47 = load i64, ptr %t46
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr { i64, [4 x i64] }, ptr %t48, i32 0, i32 1
  %t50 = getelementptr { i32, i64 }, ptr %t49, i32 0, i32 1
  %t51 = load i64, ptr %t50
  %t54 = icmp eq i64 %t47, %t51
  br i1 %t54, label %bb10, label %bb1
bb10:
  br label %bb3
bb11:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t56, i32 0, i32 1
  %t58 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t57, i32 0, i32 1
  %t59 = load i32, ptr %t58
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t60, i32 0, i32 1
  %t62 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t61, i32 0, i32 1
  %t63 = load i32, ptr %t62
  %t66 = icmp eq i32 %t59, %t63
  br i1 %t66, label %bb12, label %bb1
bb12:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 1
  %t70 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t69, i32 0, i32 2
  %t71 = load i64, ptr %t70
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr { i64, [4 x i64] }, ptr %t72, i32 0, i32 1
  %t74 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t73, i32 0, i32 2
  %t75 = load i64, ptr %t74
  %t78 = icmp eq i64 %t71, %t75
  br i1 %t78, label %bb13, label %bb1
bb13:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr { i64, [4 x i64] }, ptr %t80, i32 0, i32 1
  %t82 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t81, i32 0, i32 3
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr { i64, [4 x i64] }, ptr %t83, i32 0, i32 1
  %t85 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t84, i32 0, i32 3
  %t88 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %t82, ptr %t85)
  store i1 %t88, ptr %l26
  br label %bb14
bb14:
  %t89 = load i1, ptr %l26, !tbaa !21
  br i1 %t89, label %bb15, label %bb1
bb15:
  br label %bb3
bb16:
  %t90 = load i1, ptr %l2, !tbaa !21
  store i1 %t90, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d101 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"fill" }>, align 8
@.d102 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"fill" }>, align 8
@.d103 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"fill" }>, align 8
@.d104 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"fill" }>, align 8
@.d105 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"br label %" }>, align 8
@.d106 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"br label %" }>, align 8
@.d107 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c" = phi i64 [ 0, %" }>, align 8
@.d108 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" ], [ " }>, align 8
@.d109 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", %" }>, align 8
@.d110 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" ]" }>, align 8
@.d111 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"icmp slt i64 " }>, align 8
@.d112 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d113 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"br i1 " }>, align 8
@.d114 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", label %" }>, align 8
@.d115 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"getelementptr " }>, align 8
@.d116 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d117 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", i64 0, i64 " }>, align 8
@.d118 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d119 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c" = add i64 " }>, align 8
@.d120 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d121 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"br label %" }>, align 8
@.d122 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"getelementptr " }>, align 8
@.d123 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d124 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", i64 0, i64 " }>, align 8
@.d125 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"llvm.memmove.p0.p0.i64" }>, align 8
@.d126 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c"void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)" }>, align 8
@.d127 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c"call void @llvm.memmove.p0.p0.i64(ptr " }>, align 8
@.d128 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d129 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d130 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c", i1 false)" }>, align 8
@.d131 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"load " }>, align 8
@.d132 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d133 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"bitcast float " }>, align 8
@.d134 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" to i32" }>, align 8
@.d135 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"lshr i32 " }>, align 8
@.d136 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c", 16" }>, align 8
@.d137 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"and i32 " }>, align 8
@.d138 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d139 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"add i32 " }>, align 8
@.d140 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c", 32767" }>, align 8
@.d141 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"add i32 " }>, align 8
@.d142 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d143 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"lshr i32 " }>, align 8
@.d144 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c", 16" }>, align 8
@.d145 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"or i32 " }>, align 8
@.d146 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c", 64" }>, align 8
@.d147 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"and i32 " }>, align 8
@.d148 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c", 2147483647" }>, align 8
@.d149 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"icmp ugt i32 " }>, align 8
@.d150 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c", 2139095040" }>, align 8
@.d151 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"select i1 " }>, align 8
@.d152 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i32 " }>, align 8
@.d153 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"trunc i32 " }>, align 8
@.d154 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" to i16" }>, align 8
@.d155 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"bitcast i16 " }>, align 8
@.d156 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" to bfloat" }>, align 8
@.d157 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"mul i64 " }>, align 8
@.d158 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d159 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d160 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"__olang_san_alloc_own" }>, align 8
@.d161 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"call ptr @__olang_san_alloc_own(ptr " }>, align 8
@.d162 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d163 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d164 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d165 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d166 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i64" }>, align 8
@.d167 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i64" }>, align 8
@.d168 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
@.d169 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"fill" }>, align 8
@.d170 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"fillb" }>, align 8
@.d171 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"filld" }>, align 8
@.d172 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"br label %" }>, align 8
@.d173 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i64" }>, align 8
@.d174 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d175 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"icmp slt i64 " }>, align 8
@.d176 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d177 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"br i1 " }>, align 8
@.d178 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", label %" }>, align 8
@.d179 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"getelementptr " }>, align 8
@.d180 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d181 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d182 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d183 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"add i64 " }>, align 8
@.d184 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d185 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i64" }>, align 8
@.d186 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"br label %" }>, align 8
@.d187 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"bfloat" }>, align 8
@.d188 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"bitcast bfloat " }>, align 8
@.d189 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" to i16" }>, align 8
@.d190 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"xor i16 " }>, align 8
@.d191 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", -32768" }>, align 8
@.d192 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"bitcast i16 " }>, align 8
@.d193 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" to bfloat" }>, align 8
@.d194 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"fneg " }>, align 8
@.d195 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d196 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"sub " }>, align 8
@.d197 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" 0, " }>, align 8
@.d198 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"true" }>, align 8
@.d199 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-1" }>, align 8
@.d200 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"xor " }>, align 8
@.d201 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d202 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d203 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"xor i1 " }>, align 8
@.d204 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", true" }>, align 8
@.d205 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"an any with no table" }>, align 8
@.d206 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"zeroinitializer" }>, align 8
@.d207 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"insertvalue { ptr, ptr } undef, ptr " }>, align 8
@.d208 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d209 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"icmp ne ptr " }>, align 8
@.d210 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", null" }>, align 8
@.d211 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"select i1 " }>, align 8
@.d212 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c", ptr @" }>, align 8
@.d213 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c", ptr null" }>, align 8
@.d214 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"insertvalue { ptr, ptr } " }>, align 8
@.d215 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d216 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d217 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"extractvalue { ptr, ptr } " }>, align 8
@.d218 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d219 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"extractvalue { ptr, ptr } " }>, align 8
@.d220 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d221 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"icmp ne ptr " }>, align 8
@.d222 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", null" }>, align 8
@.d223 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"select i1 " }>, align 8
@.d224 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d225 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c", ptr @" }>, align 8
@.d226 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"load ptr, ptr " }>, align 8
@.d227 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"icmp eq ptr " }>, align 8
@.d228 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", @" }>, align 8
@.d229 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"extractvalue { i64, ptr } " }>, align 8
@.d230 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d231 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"extractvalue { i64, ptr } " }>, align 8
@.d232 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d233 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"mul i64 " }>, align 8
@.d234 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d235 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"__olang_san_retire" }>, align 8
@.d236 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"call void @__olang_san_retire(ptr " }>, align 8
@.d237 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d238 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d239 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"undef" }>, align 8
@.d240 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"extractvalue { i64, ptr } " }>, align 8
@.d241 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d242 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"load atomic " }>, align 8
@.d243 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d244 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c" seq_cst, align " }>, align 8
@.d245 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"ctpop" }>, align 8
@.d246 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ctlz" }>, align 8
@.d247 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"cttz" }>, align 8
@.d248 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"llvm." }>, align 8
@.d249 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d250 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"ctpop" }>, align 8
@.d251 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c", i1)" }>, align 8
@.d252 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d253 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" @" }>, align 8
@.d254 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d255 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"ctpop" }>, align 8
@.d256 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c", i1 false)" }>, align 8
@.d257 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d258 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"call " }>, align 8
@.d259 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" @" }>, align 8
@.d260 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d261 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d262 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"i" }>, align 8
@.d263 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"llvm.bswap." }>, align 8
@.d264 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" @" }>, align 8
@.d265 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d266 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d267 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"zext " }>, align 8
@.d268 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d269 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" to " }>, align 8
@.d270 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"call " }>, align 8
@.d271 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" @" }>, align 8
@.d272 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d273 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d274 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d275 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"lshr " }>, align 8
@.d276 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d277 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 8" }>, align 8
@.d278 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"trunc " }>, align 8
@.d279 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d280 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" to " }>, align 8
@.d281 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"llvm.bswap." }>, align 8
@.d282 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" @" }>, align 8
@.d283 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d284 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d285 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"call " }>, align 8
@.d286 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" @" }>, align 8
@.d287 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d288 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d289 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d290 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"srem i64 " }>, align 8
@.d291 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d292 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"icmp slt i64 " }>, align 8
@.d293 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d294 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"add i64 " }>, align 8
@.d295 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d296 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"select i1 " }>, align 8
@.d297 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d298 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"l" }>, align 8
@.d299 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"r" }>, align 8
@.d300 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"llvm.fsh" }>, align 8
@.d301 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d302 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" @" }>, align 8
@.d303 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d304 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d305 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d306 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"call " }>, align 8
@.d307 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" @" }>, align 8
@.d308 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d309 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d310 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d311 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d312 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"bfloat" }>, align 8
@.d313 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"float" }>, align 8
@.d314 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"float" }>, align 8
@.d315 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"fadd" }>, align 8
@.d316 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"fsub" }>, align 8
@.d317 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"fmul" }>, align 8
@.d318 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"fdiv" }>, align 8
@.d319 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"frem" }>, align 8
@.d320 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d321 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d322 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" float " }>, align 8
@.d323 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d324 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"fadd " }>, align 8
@.d325 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"add " }>, align 8
@.d326 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d327 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d328 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"fsub " }>, align 8
@.d329 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"sub " }>, align 8
@.d330 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d331 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d332 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"fmul " }>, align 8
@.d333 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"mul " }>, align 8
@.d334 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d335 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d336 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"fdiv " }>, align 8
@.d337 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"udiv " }>, align 8
@.d338 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"sdiv " }>, align 8
@.d339 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d340 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d341 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"frem " }>, align 8
@.d342 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"urem " }>, align 8
@.d343 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"srem " }>, align 8
@.d344 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d345 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d346 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"shl " }>, align 8
@.d347 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"lshr " }>, align 8
@.d348 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"ashr " }>, align 8
@.d349 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d350 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d351 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"and " }>, align 8
@.d352 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d353 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d354 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"or " }>, align 8
@.d355 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d356 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d357 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"xor " }>, align 8
@.d358 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d359 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d360 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"{ i64, ptr }" }>, align 8
@.d361 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"{ ptr, ptr }" }>, align 8
@.d362 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"{ i64, ptr }" }>, align 8
@.d363 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"i64 " }>, align 8
@.d364 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ptr " }>, align 8
@.d365 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"extractvalue " }>, align 8
@.d366 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d367 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d368 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"extractvalue " }>, align 8
@.d369 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d370 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d371 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"icmp eq " }>, align 8
@.d372 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d373 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"extractvalue " }>, align 8
@.d374 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d375 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d376 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"extractvalue " }>, align 8
@.d377 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d378 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d379 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"icmp eq ptr " }>, align 8
@.d380 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d381 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"and i1 " }>, align 8
@.d382 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d383 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"icmp eq " }>, align 8
@.d384 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d385 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d386 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"extractvalue " }>, align 8
@.d387 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d388 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d389 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"icmp eq i64 " }>, align 8
@.d390 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d391 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"trunc i64 " }>, align 8
@.d392 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" to i32" }>, align 8
@.d393 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"icmp eq i32 " }>, align 8
@.d394 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d395 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"store atomic " }>, align 8
@.d396 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d397 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d398 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c" seq_cst, align " }>, align 8
@.d399 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"undef" }>, align 8
@.d400 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"add" }>, align 8
@.d401 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"xchg" }>, align 8
@.d402 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"atomicrmw " }>, align 8
@.d403 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" ptr " }>, align 8
@.d404 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d405 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d406 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" seq_cst" }>, align 8
@.d407 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"cmpxchg ptr " }>, align 8
@.d408 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d409 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d410 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c" seq_cst seq_cst" }>, align 8
@.d411 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"extractvalue { " }>, align 8
@.d412 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c", i1 } " }>, align 8
@.d413 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d414 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"the operation " }>, align 8
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 i64 7, label %bb9 i64 8, label %bb10 i64 9, label %bb11 i64 10, label %bb12 i64 11, label %bb13 i64 12, label %bb14 i64 13, label %bb15 i64 14, label %bb16 i64 15, label %bb17 i64 16, label %bb18 i64 17, label %bb19 i64 18, label %bb20 i64 19, label %bb21 i64 20, label %bb22 i64 21, label %bb23 i64 22, label %bb24 i64 23, label %bb25 i64 24, label %bb26 i64 25, label %bb27 i64 26, label %bb28 i64 27, label %bb29 i64 28, label %bb30 i64 29, label %bb31 i64 30, label %bb32 i64 31, label %bb33 i64 32, label %bb34 i64 33, label %bb35 i64 34, label %bb36 i64 35, label %bb37 i64 36, label %bb38 i64 37, label %bb39 i64 38, label %bb40 i64 39, label %bb41 i64 40, label %bb42 i64 41, label %bb43 i64 42, label %bb44 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d485, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d485, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d486, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d486, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d487, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d487, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d488, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d488, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
bb6:
  %t13 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d489, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d489, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t13, i64 %t14)
  br label %bb1
bb7:
  %t15 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d490, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d490, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t15, i64 %t16)
  br label %bb1
bb8:
  %t17 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d491, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d491, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t17, i64 %t18)
  br label %bb1
bb9:
  %t19 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d492, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d492, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t19, i64 %t20)
  br label %bb1
bb10:
  %t21 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d493, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d493, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t21, i64 %t22)
  br label %bb1
bb11:
  %t23 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d494, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d494, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t23, i64 %t24)
  br label %bb1
bb12:
  %t25 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d495, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d495, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t25, i64 %t26)
  br label %bb1
bb13:
  %t27 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d496, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d496, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t27, i64 %t28)
  br label %bb1
bb14:
  %t29 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d497, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d497, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t29, i64 %t30)
  br label %bb1
bb15:
  %t31 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d498, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d498, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t31, i64 %t32)
  br label %bb1
bb16:
  %t33 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d499, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d499, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t33, i64 %t34)
  br label %bb1
bb17:
  %t35 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d500, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d500, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t35, i64 %t36)
  br label %bb1
bb18:
  %t37 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d501, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d501, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t37, i64 %t38)
  br label %bb1
bb19:
  %t39 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d502, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d502, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t39, i64 %t40)
  br label %bb1
bb20:
  %t41 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d503, i32 0, i32 1) }, 1
  %t42 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d503, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t41, i64 %t42)
  br label %bb1
bb21:
  %t43 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d504, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d504, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t43, i64 %t44)
  br label %bb1
bb22:
  %t45 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d505, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d505, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t45, i64 %t46)
  br label %bb1
bb23:
  %t47 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d506, i32 0, i32 1) }, 1
  %t48 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d506, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t47, i64 %t48)
  br label %bb1
bb24:
  %t49 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d507, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d507, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t49, i64 %t50)
  br label %bb1
bb25:
  %t51 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d508, i32 0, i32 1) }, 1
  %t52 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d508, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t51, i64 %t52)
  br label %bb1
bb26:
  %t53 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d509, i32 0, i32 1) }, 1
  %t54 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d509, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t53, i64 %t54)
  br label %bb1
bb27:
  %t55 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d510, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d510, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t55, i64 %t56)
  br label %bb1
bb28:
  %t57 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d511, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d511, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t57, i64 %t58)
  br label %bb1
bb29:
  %t59 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d512, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d512, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t59, i64 %t60)
  br label %bb1
bb30:
  %t61 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d513, i32 0, i32 1) }, 1
  %t62 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d513, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t61, i64 %t62)
  br label %bb1
bb31:
  %t63 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d514, i32 0, i32 1) }, 1
  %t64 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d514, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t63, i64 %t64)
  br label %bb1
bb32:
  %t65 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d515, i32 0, i32 1) }, 1
  %t66 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d515, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t65, i64 %t66)
  br label %bb1
bb33:
  %t67 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d516, i32 0, i32 1) }, 1
  %t68 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d516, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t67, i64 %t68)
  br label %bb1
bb34:
  %t69 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d517, i32 0, i32 1) }, 1
  %t70 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d517, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t69, i64 %t70)
  br label %bb1
bb35:
  %t71 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d518, i32 0, i32 1) }, 1
  %t72 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d518, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t71, i64 %t72)
  br label %bb1
bb36:
  %t73 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d519, i32 0, i32 1) }, 1
  %t74 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d519, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t73, i64 %t74)
  br label %bb1
bb37:
  %t75 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d520, i32 0, i32 1) }, 1
  %t76 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d520, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t75, i64 %t76)
  br label %bb1
bb38:
  %t77 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d521, i32 0, i32 1) }, 1
  %t78 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d521, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t77, i64 %t78)
  br label %bb1
bb39:
  %t79 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d522, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d522, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t79, i64 %t80)
  br label %bb1
bb40:
  %t81 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d523, i32 0, i32 1) }, 1
  %t82 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d523, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t81, i64 %t82)
  br label %bb1
bb41:
  %t83 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d524, i32 0, i32 1) }, 1
  %t84 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d524, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t83, i64 %t84)
  br label %bb1
bb42:
  %t85 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d525, i32 0, i32 1) }, 1
  %t86 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d525, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t85, i64 %t86)
  br label %bb1
bb43:
  %t87 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d526, i32 0, i32 1) }, 1
  %t88 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d526, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t87, i64 %t88)
  br label %bb1
bb44:
  %t89 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d527, i32 0, i32 1) }, 1
  %t90 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d527, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t89, i64 %t90)
  br label %bb1
ret:
  ret void
}

@.d415 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"undef" }>, align 8
@.d416 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"__olang_rd_quote" }>, align 8
@.d417 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"__olang_sb_room" }>, align 8
@.d418 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"__olang_sb_add" }>, align 8
@.d419 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c"call i64 @__olang_rd_quote(ptr null, i64 0, ptr " }>, align 8
@.d420 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d421 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c", i8 " }>, align 8
@.d422 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d423 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"call ptr @__olang_sb_room(ptr " }>, align 8
@.d424 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d425 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d426 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"call i64 @__olang_rd_quote(ptr " }>, align 8
@.d427 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", i64 0, ptr " }>, align 8
@.d428 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d429 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c", i8 " }>, align 8
@.d430 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d431 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"call void @__olang_sb_add(ptr " }>, align 8
@.d432 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d433 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d434 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i64" }>, align 8
@.d435 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i32" }>, align 8
@.d436 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"sext i32 " }>, align 8
@.d437 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" to i64" }>, align 8
@.d438 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d439 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"getelementptr %olang.builder, ptr " }>, align 8
@.d440 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", i32 0, i32 1" }>, align 8
@.d441 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i64" }>, align 8
@.d442 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_scope_alloc" }>, align 8
@.d443 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"call ptr @__olang_scope_alloc(ptr " }>, align 8
@.d444 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d445 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d446 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"call void @olang_textcopy(ptr " }>, align 8
@.d447 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d448 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d449 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d450 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_region_make" }>, align 8
@.d451 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"call ptr @__olang_region_make(ptr " }>, align 8
@.d452 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d453 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"ptrtoint ptr " }>, align 8
@.d454 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" to i64" }>, align 8
@.d455 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"__olang_region_or" }>, align 8
@.d456 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"call ptr @__olang_region_or(ptr " }>, align 8
@.d457 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d458 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d459 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"ptrtoint ptr " }>, align 8
@.d460 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" to i64" }>, align 8
@.d461 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"__olang_unwind_top" }>, align 8
@.d462 = private constant <{ i64, [67 x i8] }> <{ i64 0, [67 x i8] c"@__olang_unwind_top = external thread_local(initialexec) global ptr" }>, align 8
@.d463 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d464 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"@__olang_unwind_top" }>, align 8
@.d465 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"getelementptr %olang.unwind, ptr %u" }>, align 8
@.d466 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", i32 0, i32 0" }>, align 8
@.d467 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d468 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"%s" }>, align 8
@.d469 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"getelementptr %olang.unwind, ptr %u" }>, align 8
@.d470 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", i32 0, i32 1" }>, align 8
@.d471 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d472 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%jh" }>, align 8
@.d473 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d474 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"getelementptr %olang.unwind, ptr %u" }>, align 8
@.d475 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", i32 0, i32 2" }>, align 8
@.d476 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d477 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"%u" }>, align 8
@.d478 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d479 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"@__olang_unwind_top" }>, align 8
@.d480 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d481 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"x86_64-pc-linux-gnu" }>, align 8
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_Hf48d6d4096e547b8075d5a903caa3d54(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d482 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"x86_64" }>, align 8
@.d483 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@.d484 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"ContractKind.Req" }>, align 8
declare ptr @__olang_sb_grow(ptr, i64) noinline
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aPlace(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l5 = alloca i1
  %l8 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/mir:Place", ptr %t1, i32 0, i32 0
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/mir:Place", ptr %t3, i32 0, i32 0
  %t7 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aBase(ptr %t2, ptr %t4)
  store i1 %t7, ptr %l5
  br label %bb2
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb6
bb2:
  %t8 = load i1, ptr %l5, !tbaa !21
  br i1 %t8, label %bb3, label %bb1
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/mir:Place", ptr %t9, i32 0, i32 1
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/mir:Place", ptr %t11, i32 0, i32 1
  %t15 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aRange(ptr %t10, ptr %t12)
  store i1 %t15, ptr %l8
  br label %bb4
bb4:
  %t16 = load i1, ptr %l8, !tbaa !21
  br i1 %t16, label %bb5, label %bb1
bb5:
  br label %bb6
bb6:
  %t17 = load i1, ptr %l2, !tbaa !21
  store i1 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/source:Span", ptr %t1, i32 0, i32 0
  %t3 = load i32, ptr %t2, !tbaa !23
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/source:Span", ptr %t4, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  %t9 = icmp eq i32 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb4
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/source:Span", ptr %t11, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/source:Span", ptr %t14, i32 0, i32 1
  %t16 = load i32, ptr %t15, !tbaa !23
  %t19 = icmp eq i32 %t13, %t16
  br i1 %t19, label %bb3, label %bb1
bb3:
  br label %bb4
bb4:
  %t21 = load i1, ptr %l2, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d485 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Neg" }>, align 8
@.d486 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"PrimOp.BitNot" }>, align 8
@.d487 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Not" }>, align 8
@.d488 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Add" }>, align 8
@.d489 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Sub" }>, align 8
@.d490 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Mul" }>, align 8
@.d491 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Div" }>, align 8
@.d492 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Rem" }>, align 8
@.d493 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Shl" }>, align 8
@.d494 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Shr" }>, align 8
@.d495 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"PrimOp.BitAnd" }>, align 8
@.d496 = private unnamed_addr constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"PrimOp.BitOr" }>, align 8
@.d497 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"PrimOp.BitXor" }>, align 8
@.d498 = private unnamed_addr constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"PrimOp.Eq" }>, align 8
@.d499 = private unnamed_addr constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"PrimOp.Ne" }>, align 8
@.d500 = private unnamed_addr constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"PrimOp.Lt" }>, align 8
@.d501 = private unnamed_addr constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"PrimOp.Le" }>, align 8
@.d502 = private unnamed_addr constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"PrimOp.Gt" }>, align 8
@.d503 = private unnamed_addr constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"PrimOp.Ge" }>, align 8
@.d504 = private unnamed_addr constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"PrimOp.Same" }>, align 8
@.d505 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"PrimOp.Convert" }>, align 8
@.d506 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"PrimOp.Bitcast" }>, align 8
@.d507 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Len" }>, align 8
@.d508 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"PrimOp.IsCase" }>, align 8
@.d509 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"PrimOp.AtomicLoad" }>, align 8
@.d510 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"PrimOp.AtomicStore" }>, align 8
@.d511 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"PrimOp.AtomicAdd" }>, align 8
@.d512 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"PrimOp.AtomicSwap" }>, align 8
@.d513 = private unnamed_addr constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"PrimOp.AtomicCompareSwap" }>, align 8
@.d514 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"PrimOp.Retire" }>, align 8
@.d515 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"PrimOp.Destroy" }>, align 8
@.d516 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"PrimOp.LeadingZeros" }>, align 8
@.d517 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"PrimOp.TrailingZeros" }>, align 8
@.d518 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"PrimOp.PopCount" }>, align 8
@.d519 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"PrimOp.RotateLeft" }>, align 8
@.d520 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"PrimOp.RotateRight" }>, align 8
@.d521 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"PrimOp.ByteSwap" }>, align 8
@.d522 = private unnamed_addr constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"PrimOp.Holds" }>, align 8
@.d523 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"PrimOp.LaneLen" }>, align 8
@.d524 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"PrimOp.NonEmpty" }>, align 8
@.d525 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"PrimOp.AnyMake" }>, align 8
@.d526 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"PrimOp.AnyInstance" }>, align 8
@.d527 = private unnamed_addr constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"PrimOp.AnyIs" }>, align 8
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aBase(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb10
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 ]
bb3:
  br label %bb10
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [2 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  %t20 = icmp eq i32 %t13, %t17
  br i1 %t20, label %bb6, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64, i32, i32 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64, i32, i32 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb7, label %bb1
bb6:
  br label %bb3
bb7:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [2 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i64, i32, i32 }, ptr %t35, i32 0, i32 1
  %t37 = load i32, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [2 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i64, i32, i32 }, ptr %t39, i32 0, i32 1
  %t41 = load i32, ptr %t40
  %t44 = icmp eq i32 %t37, %t41
  br i1 %t44, label %bb8, label %bb1
bb8:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [2 x i64] }, ptr %t46, i32 0, i32 1
  %t48 = getelementptr { i64, i32, i32 }, ptr %t47, i32 0, i32 2
  %t49 = load i32, ptr %t48
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [2 x i64] }, ptr %t50, i32 0, i32 1
  %t52 = getelementptr { i64, i32, i32 }, ptr %t51, i32 0, i32 2
  %t53 = load i32, ptr %t52
  %t56 = icmp eq i32 %t49, %t53
  br i1 %t56, label %bb9, label %bb1
bb9:
  br label %bb3
bb10:
  %t58 = load i1, ptr %l2, !tbaa !21
  store i1 %t58, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aRange(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/mir:Range", ptr %t1, i32 0, i32 0
  %t3 = load i32, ptr %t2, !tbaa !23
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/mir:Range", ptr %t4, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  %t9 = icmp eq i32 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb4
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/mir:Range", ptr %t11, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/mir:Range", ptr %t14, i32 0, i32 1
  %t16 = load i32, ptr %t15, !tbaa !23
  %t19 = icmp eq i32 %t13, %t16
  br i1 %t19, label %bb3, label %bb1
bb3:
  br label %bb4
bb4:
  %t21 = load i1, ptr %l2, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@G_2ecompiler_2femit_2eHomeInst = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FD\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2femit_2eHomeLoc = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FC\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceName(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanonList(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etestSym(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etableName(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecanonOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_de1fe604fb5e87cf_ff4728625cff78d3 = external constant [0 x i8]
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@G_2ecompiler_2femit_2eHomeShared = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i64 %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_5ad0f5036011b2cd_7d6f5911e17dc851 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_616c6f643d0ce9fd_dfe523617d4699c1 = external constant [0 x i8]
@olang_loc_b37ed008d0080fcc_cc9019489ebc5a30 = external constant [0 x i8]
@olang_loc_7f6c4a9881f0c77f_244fd8f3f85b2bab = external constant [0 x i8]
@olang_loc_1cb2b0b1c80ab6bb_ff3b7bcb0dec81bf = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1)
@olang_loc_dd4469a9ae312a3a_602f574df5758ebe = external constant [0 x i8]
@olang_loc_e68028fa4f0f457e_ac0c180900ac4e62 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2femit_2emathExact = external constant <{ ptr }>
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_8b9f7f38fd25c7fb_28bbaeaad75485df = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eposition(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @compiler_2fruntime_2eText(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1, i1 %a2)
@olang_loc_49795d8549fab862_b41831e08981cb6 = external constant [0 x i8]
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2egap(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare { i64, ptr } @compiler_2fruntime_2eDecls(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %a0)
@olang_loc_e59d8160838b9663_ee3833e61d72b057 = external constant [0 x i8]
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2femit_2edeclaredSymbol(ptr %v0, ptr %v1, { i64, ptr } %a0)
@G_2ecompiler_2ftypes_2eNullT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\0F\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eneed(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %a0)
declare %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eopaque16(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2eAt_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %a0, i64 %a1)
declare i8 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eAt_3cU8_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_a00373ca27d5619a_9315010cb9ead296 = external constant [0 x i8]
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edbgLine(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_e9e71ccb75095175_3df52a9a91674c89 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
declare { { i64, ptr }, { i64, ptr } } @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayParts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixed(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixedLen(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1, i64 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %v1, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2)
declare { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Place" %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2etmp(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eplaceType(ptr %v0, ptr %a0, %"compiler/mir:Place" %a1)
@olang_loc_9357034ceffa49e9_ad514f9345461395 = external constant [0 x i8]
@olang_loc_1dffb4089bad5318_6447f84abd9ba4a4 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eLen_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %a0)
@olang_loc_3b6348629663638e_4d98396f767ecbfa = external constant [0 x i8]
@olang_loc_e68eff5da6298283_f7922e79bdd8a34f = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %a0)
declare %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_7398c824c6ccd25f_37644bbf4fe2ca83 = external constant [0 x i8]
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2euseRef(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1, { i64, ptr } %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0)
declare { i64, [21 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_5718aedbda8f05de_73125ecff2351902 = external constant [0 x i8]
@olang_loc_c174e5a3b34e67b9_6250aa572b15a6d5 = external constant [0 x i8]
@olang_loc_9206c849bcce77e8_1d8ffc9eff2b8ce4 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0)
declare %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eisFrame(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eindex(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2)
@olang_loc_7367d2b2f6aa7e57_e9ab633458e0a533 = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayStorage(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i32 %a3, i1 %a4)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epair(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eviaMem(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2eput(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, [4 x i64] } %a3, { i64, ptr } %a4)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2econvert(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, i32 %a3)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ebitcast(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
@olang_loc_69dfe582bfe1941e_f4b5889a4307147a = external constant [0 x i8]
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eanyTable(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etypeid(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@G_2ecompiler_2fmir_2eI64T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\06\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ewidth(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, i32 %a3)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_d23ee61a0d8dfe9f_a353f177579d38fb = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ewidenBF16(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@olang_loc_f37913274faf0c64_a4499fcd83081580 = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ecompare(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3, { i64, ptr } %a4)
@olang_loc_3839c0df7b992655_2640faef1ba2f611 = external constant [0 x i8]
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eenumWords(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_48fb755842b89882_1da88e591314daf6 = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eref(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Place" %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eoverflows(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, %"compiler/mir:Range" %a3)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaggregate(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2, %"compiler/mir:Range" %a3)
declare i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ealign(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloc(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [1 x i64] } %a1, { i64, ptr } %a2, i64 %a3, { i64, ptr } %a4)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erunTime(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ecopyArray(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [1 x i64] } %a1, { i64, ptr } %a2, i32 %a3)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eslice(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Place" %a1, { i64, [4 x i64] } %a2, { i64, [4 x i64] } %a3, i32 %a4)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eclosure(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, { i64, [1 x i64] } %a3, %"compiler/mir:Range" %a4, %"compiler/mir:Range" %a5)
@G_2ecompiler_2fmir_2eI32T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\05\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2erecode(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, i32 %a3)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2edirectRef(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edirectText(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2etextCopy(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eobjectPtr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2)
@olang_loc_b25f444594da9527_de5411018827488b = external constant [0 x i8]
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2emathExactTable(ptr %v0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ector(ptr %v0, i64 %a0)
@G_2ecompiler_2femit_2ePartSize = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\10\00\00\00\00\00" }>, align 8
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aReused_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
