; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/emit:Emitter" = type { ptr, ptr, ptr, ptr, i1, i1, i1, i1, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, i64, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i1, i1, { i64, ptr }, i1, i64, i64, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/lower:Lowerer" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i32 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr } }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
%"compiler/load:Import" = type { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, { i64, ptr }, i64, i64 }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/emit:fnEm" = type { ptr, ptr, { i64, [2 x i64] }, %"std/prelude/text:StringBuilder", %"std/prelude/text:StringBuilder", %"std/prelude/text:StringBuilder", i64, i64, i64, i32, i1, i1, i1, i1, { i64, ptr }, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/text:StringBuilder", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/mir:Fn" = type { { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/mir:Place" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/mir:BasicBlock" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [7 x i64] } }
%"compiler/mir:Local" = type { i32, %"compiler/source:Span", i32, i32, { i64, [1 x i64] } }
%"compiler/mir:ScopeInfo" = type { i32, i32, i32, %"compiler/source:Span", i32 }
%"compiler/emit:Object" = type { { i64, ptr }, i32, { i64, ptr }, i64 }
define dso_local void @compiler_2femit_2eHomeInst_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 -3, ptr @G_2ecompiler_2femit_2eHomeInst, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2eHomeLoc_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 -4, ptr @G_2ecompiler_2femit_2eHomeLoc, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eadaptKey(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s0, ptr %t4, i32 %a1)
  store { i64, ptr } %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/emit:Emitter", ptr %t9, i32 0, i32 3
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t16 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s0, ptr %t12, i32 %a2)
  store { i64, ptr } %t16, ptr %l10
  br label %bb2
bb2:
  %t17 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } { i64 1, ptr @.d0 }, 1
  %t21 = extractvalue { i64, ptr } { i64 1, ptr @.d0 }, 0
  %t22 = add i64 %t19, %t21
  %t23 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 1
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t26 = add i64 %t22, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t18, i64 %t19)
  %t28 = getelementptr i8, ptr %t27, i64 %t19
  call void @olang_textcopy(ptr %t28, ptr %t20, i64 %t21)
  %t29 = getelementptr i8, ptr %t28, i64 %t21
  call void @olang_textcopy(ptr %t29, ptr %t24, i64 %t25)
  %t30 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t27, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t40 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t38)
  store { i64, ptr } %t40, ptr %l13
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t41 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t41, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ebodySym(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i32
  %l17 = alloca i64
  %l24 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l81 = alloca ptr
  %l83 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l107 = alloca i32
  %l108 = alloca i64
  %l110 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l119 = alloca { i64, ptr }
  %l123 = alloca { i64, ptr }
  %l130 = alloca { i64, ptr }
  %l134 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.builder
  %s18room = alloca [64 x i8], align 8
  %s19 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/emit:Emitter", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/lower:Lowerer", ptr %t9, i32 0, i32 1
  %t12 = load i64, ptr %l1, !tbaa !24
  %t15 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t11, i64 %t12)
  store ptr %t15, ptr %l24
  br label %bb1
bb1:
  %t16 = load ptr, ptr %l24, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Body", ptr %t16, i32 0, i32 1
  %t20 = load { i64, [2 x i64] }, ptr %t19
  store { i64, [2 x i64] } %t20, ptr %l4
  %t22 = load { i64, [2 x i64] }, ptr %l4
  %t24 = extractvalue { i64, [2 x i64] } %t22, 0
  %t25 = icmp eq i64 %t24, 0
  br i1 %t25, label %bb2, label %bb3
bb2:
  %t27 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  store i64 %t29, ptr %l5, !tbaa !24
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/emit:Emitter", ptr %t31, i32 0, i32 0
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceName(ptr %v0, ptr %t34, i64 %t35)
  store { i64, ptr } %t38, ptr %l34
  br label %bb5
bb5:
  %t39 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 1
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t42 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t41)
  call void @olang_textcopy(ptr %t42, ptr %t40, i64 %t41)
  %t43 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  store { i64, ptr } %t44, ptr %l27, !tbaa !27
  br label %bb66
bb6:
  %t46 = load { i64, [2 x i64] }, ptr %l4
  %t48 = extractvalue { i64, [2 x i64] } %t46, 0
  %t49 = icmp eq i64 %t48, 1
  br i1 %t49, label %bb7, label %bb8
bb7:
  %t51 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t52 = getelementptr { i32, i32 }, ptr %t51, i32 0, i32 0
  %t53 = load i32, ptr %t52
  store i32 %t53, ptr %l6, !tbaa !23
  %t55 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t56 = getelementptr { i32, i32 }, ptr %t55, i32 0, i32 1
  %t57 = load i32, ptr %t56
  store i32 %t57, ptr %l7, !tbaa !23
  br label %bb9
bb8:
  br label %bb16
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t59 = load ptr, ptr %l2, !tbaa !29
  %t60 = load i32, ptr %l6, !tbaa !23
  %t63 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s3, ptr %t59, i32 %t60)
  store { i64, ptr } %t63, ptr %l42
  br label %bb10
bb10:
  %t64 = load i32, ptr %l7, !tbaa !23
  %t66 = icmp eq i32 %t64, 0
  br i1 %t66, label %bb11, label %bb12
bb11:
  store { i64, ptr } { i64 0, ptr @.d1 }, ptr %l45, !tbaa !27
  br label %bb14
bb12:
  %t68 = load ptr, ptr %l2, !tbaa !29
  %t69 = load i32, ptr %l7, !tbaa !23
  %t72 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanonList(ptr %v0, ptr %s3, ptr %t68, i32 %t69)
  store { i64, ptr } %t72, ptr %l48
  br label %bb13
bb13:
  %t73 = extractvalue { i64, ptr } { i64 1, ptr @.d2 }, 1
  %t74 = extractvalue { i64, ptr } { i64 1, ptr @.d2 }, 0
  %t75 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 1
  %t77 = extractvalue { i64, ptr } %t75, 0
  %t78 = add i64 %t74, %t77
  %t79 = extractvalue { i64, ptr } { i64 1, ptr @.d3 }, 1
  %t80 = extractvalue { i64, ptr } { i64 1, ptr @.d3 }, 0
  %t81 = add i64 %t78, %t80
  %t82 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t81)
  call void @olang_textcopy(ptr %t82, ptr %t73, i64 %t74)
  %t83 = getelementptr i8, ptr %t82, i64 %t74
  call void @olang_textcopy(ptr %t83, ptr %t76, i64 %t77)
  %t84 = getelementptr i8, ptr %t83, i64 %t77
  call void @olang_textcopy(ptr %t84, ptr %t79, i64 %t80)
  %t85 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t82, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = extractvalue { i64, ptr } %t86, 1
  %t90 = mul i64 %t88, 1
  %t91 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t90)
  call void @llvm.memcpy.p0.p0.i64(ptr %t91, ptr %t89, i64 %t90, i1 false)
  %t92 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  store { i64, ptr } %t93, ptr %l45, !tbaa !27
  br label %bb14
bb14:
  %t95 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t95, 1
  %t97 = extractvalue { i64, ptr } %t95, 0
  %t98 = extractvalue { i64, ptr } { i64 5, ptr @.d4 }, 1
  %t99 = extractvalue { i64, ptr } { i64 5, ptr @.d4 }, 0
  %t100 = add i64 %t97, %t99
  %t101 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 1
  %t103 = extractvalue { i64, ptr } %t101, 0
  %t104 = add i64 %t100, %t103
  %t105 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t104)
  call void @olang_textcopy(ptr %t105, ptr %t96, i64 %t97)
  %t106 = getelementptr i8, ptr %t105, i64 %t97
  call void @olang_textcopy(ptr %t106, ptr %t98, i64 %t99)
  %t107 = getelementptr i8, ptr %t106, i64 %t99
  call void @olang_textcopy(ptr %t107, ptr %t102, i64 %t103)
  %t108 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t105, 1
  %t111 = extractvalue { i64, ptr } %t109, 0
  %t112 = extractvalue { i64, ptr } %t109, 1
  %t113 = mul i64 %t111, 1
  %t114 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t113)
  call void @llvm.memcpy.p0.p0.i64(ptr %t114, ptr %t112, i64 %t113, i1 false)
  %t115 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t114, 1
  %t118 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t116)
  store { i64, ptr } %t118, ptr %l53
  br label %bb15
bb15:
  %t119 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t119, ptr %l27, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  br label %bb66
bb16:
  %t120 = load { i64, [2 x i64] }, ptr %l4
  %t122 = extractvalue { i64, [2 x i64] } %t120, 0
  %t123 = icmp eq i64 %t122, 3
  br i1 %t123, label %bb17, label %bb18
bb17:
  %t125 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t126 = getelementptr { i32 }, ptr %t125, i32 0, i32 0
  %t127 = load i32, ptr %t126
  store i32 %t127, ptr %l8, !tbaa !23
  br label %bb19
bb18:
  br label %bb22
bb19:
  store %olang.scope zeroinitializer, ptr %s6
  %t129 = load ptr, ptr %l2, !tbaa !29
  %t130 = load i32, ptr %l8, !tbaa !23
  %t133 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s6, ptr %t129, i32 %t130)
  store { i64, ptr } %t133, ptr %l59
  br label %bb20
bb20:
  %t134 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t134, 1
  %t136 = extractvalue { i64, ptr } %t134, 0
  %t137 = extractvalue { i64, ptr } { i64 5, ptr @.d5 }, 1
  %t138 = extractvalue { i64, ptr } { i64 5, ptr @.d5 }, 0
  %t139 = add i64 %t136, %t138
  %t140 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t139)
  call void @olang_textcopy(ptr %t140, ptr %t135, i64 %t136)
  %t141 = getelementptr i8, ptr %t140, i64 %t136
  call void @olang_textcopy(ptr %t141, ptr %t137, i64 %t138)
  %t142 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t140, 1
  %t145 = extractvalue { i64, ptr } %t143, 0
  %t146 = extractvalue { i64, ptr } %t143, 1
  %t147 = mul i64 %t145, 1
  %t148 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t147)
  call void @llvm.memcpy.p0.p0.i64(ptr %t148, ptr %t146, i64 %t147, i1 false)
  %t149 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t148, 1
  %t152 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t150)
  store { i64, ptr } %t152, ptr %l62
  br label %bb21
bb21:
  %t153 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t153, ptr %l27, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb66
bb22:
  %t154 = load { i64, [2 x i64] }, ptr %l4
  %t156 = extractvalue { i64, [2 x i64] } %t154, 0
  %t157 = icmp eq i64 %t156, 4
  br i1 %t157, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  %t159 = load i64, ptr %l1, !tbaa !24
  %t160 = extractvalue { i64, ptr } { i64 13, ptr @.d6 }, 1
  %t161 = extractvalue { i64, ptr } { i64 13, ptr @.d6 }, 0
  %t163 = call i64 @__olang_fmt_i64(ptr null, i64 %t159)
  %t164 = add i64 %t161, %t163
  %t165 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t164)
  call void @olang_textcopy(ptr %t165, ptr %t160, i64 %t161)
  %t166 = getelementptr i8, ptr %t165, i64 %t161
  %t167 = call i64 @__olang_fmt_i64(ptr %t166, i64 %t159)
  %t168 = insertvalue { i64, ptr } undef, i64 %t164, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr %t165, 1
  store { i64, ptr } %t169, ptr %l27, !tbaa !27
  br label %bb66
bb26:
  %t171 = load { i64, [2 x i64] }, ptr %l4
  %t173 = extractvalue { i64, [2 x i64] } %t171, 0
  %t174 = icmp eq i64 %t173, 5
  br i1 %t174, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load i64, ptr %l1, !tbaa !24
  %t180 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etestSym(ptr %v0, ptr %v1, ptr %t176, i64 %t177)
  store { i64, ptr } %t180, ptr %l71
  br label %bb30
bb30:
  %t181 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t181, ptr %l27, !tbaa !27
  br label %bb66
bb31:
  %t182 = load { i64, [2 x i64] }, ptr %l4
  %t184 = extractvalue { i64, [2 x i64] } %t182, 0
  %t185 = icmp eq i64 %t184, 6
  br i1 %t185, label %bb32, label %bb33
bb32:
  %t187 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t188 = getelementptr { i64, i32 }, ptr %t187, i32 0, i32 0
  %t189 = load i64, ptr %t188
  store i64 %t189, ptr %l9, !tbaa !24
  %t191 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t192 = getelementptr { i64, i32 }, ptr %t191, i32 0, i32 1
  %t193 = load i32, ptr %t192
  store i32 %t193, ptr %l10, !tbaa !23
  br label %bb34
bb33:
  br label %bb38
bb34:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/emit:Emitter", ptr %t195, i32 0, i32 0
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t200 = getelementptr %"compiler/generic:Program", ptr %t198, i32 0, i32 0
  %t201 = load ptr, ptr %t200, !tbaa !29
  %t203 = getelementptr %"compiler/load:Loader", ptr %t201, i32 0, i32 5
  %t204 = load i64, ptr %l9, !tbaa !24
  %t207 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t203, i64 %t204)
  store ptr %t207, ptr %l81
  br label %bb35
bb35:
  %t208 = load ptr, ptr %l81, !tbaa !29
  %t210 = getelementptr %"compiler/load:Module", ptr %t208, i32 0, i32 2
  %t211 = load { i64, ptr }, ptr %t210, !tbaa !27
  store { i64, ptr } %t211, ptr %l83, !tbaa !27
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load i32, ptr %l10, !tbaa !23
  %t216 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %t212, i32 %t213)
  store { i64, ptr } %t216, ptr %l86
  br label %bb36
bb36:
  %t217 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t218 = extractvalue { i64, ptr } %t217, 1
  %t219 = extractvalue { i64, ptr } %t217, 0
  %t220 = extractvalue { i64, ptr } { i64 1, ptr @.d7 }, 1
  %t221 = extractvalue { i64, ptr } { i64 1, ptr @.d7 }, 0
  %t222 = add i64 %t219, %t221
  %t223 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t224 = extractvalue { i64, ptr } %t223, 1
  %t225 = extractvalue { i64, ptr } %t223, 0
  %t226 = add i64 %t222, %t225
  %t227 = extractvalue { i64, ptr } { i64 5, ptr @.d8 }, 1
  %t228 = extractvalue { i64, ptr } { i64 5, ptr @.d8 }, 0
  %t229 = add i64 %t226, %t228
  %t230 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t229)
  call void @olang_textcopy(ptr %t230, ptr %t218, i64 %t219)
  %t231 = getelementptr i8, ptr %t230, i64 %t219
  call void @olang_textcopy(ptr %t231, ptr %t220, i64 %t221)
  %t232 = getelementptr i8, ptr %t231, i64 %t221
  call void @olang_textcopy(ptr %t232, ptr %t224, i64 %t225)
  %t233 = getelementptr i8, ptr %t232, i64 %t225
  call void @olang_textcopy(ptr %t233, ptr %t227, i64 %t228)
  %t234 = insertvalue { i64, ptr } undef, i64 %t229, 0
  %t235 = insertvalue { i64, ptr } %t234, ptr %t230, 1
  %t237 = extractvalue { i64, ptr } %t235, 0
  %t238 = extractvalue { i64, ptr } %t235, 1
  %t239 = mul i64 %t237, 1
  %t240 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t239)
  call void @llvm.memcpy.p0.p0.i64(ptr %t240, ptr %t238, i64 %t239, i1 false)
  %t241 = insertvalue { i64, ptr } undef, i64 %t237, 0
  %t242 = insertvalue { i64, ptr } %t241, ptr %t240, 1
  %t244 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t242)
  store { i64, ptr } %t244, ptr %l89
  br label %bb37
bb37:
  %t245 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t245, ptr %l27, !tbaa !27
  br label %bb66
bb38:
  %t246 = load { i64, [2 x i64] }, ptr %l4
  %t248 = extractvalue { i64, [2 x i64] } %t246, 0
  %t249 = icmp eq i64 %t248, 2
  br i1 %t249, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  %t251 = load i64, ptr %l1, !tbaa !24
  %t252 = extractvalue { i64, ptr } { i64 11, ptr @.d9 }, 1
  %t253 = extractvalue { i64, ptr } { i64 11, ptr @.d9 }, 0
  %t255 = call i64 @__olang_fmt_i64(ptr null, i64 %t251)
  %t256 = add i64 %t253, %t255
  %t257 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t256)
  call void @olang_textcopy(ptr %t257, ptr %t252, i64 %t253)
  %t258 = getelementptr i8, ptr %t257, i64 %t253
  %t259 = call i64 @__olang_fmt_i64(ptr %t258, i64 %t251)
  %t260 = insertvalue { i64, ptr } undef, i64 %t256, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t257, 1
  store { i64, ptr } %t261, ptr %l27, !tbaa !27
  br label %bb66
bb42:
  %t263 = load { i64, [2 x i64] }, ptr %l4
  %t265 = extractvalue { i64, [2 x i64] } %t263, 0
  %t266 = icmp eq i64 %t265, 7
  br i1 %t266, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  %t268 = load i64, ptr %l1, !tbaa !24
  %t269 = extractvalue { i64, ptr } { i64 11, ptr @.d10 }, 1
  %t270 = extractvalue { i64, ptr } { i64 11, ptr @.d10 }, 0
  %t272 = call i64 @__olang_fmt_i64(ptr null, i64 %t268)
  %t273 = add i64 %t270, %t272
  %t274 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t273)
  call void @olang_textcopy(ptr %t274, ptr %t269, i64 %t270)
  %t275 = getelementptr i8, ptr %t274, i64 %t270
  %t276 = call i64 @__olang_fmt_i64(ptr %t275, i64 %t268)
  %t277 = insertvalue { i64, ptr } undef, i64 %t273, 0
  %t278 = insertvalue { i64, ptr } %t277, ptr %t274, 1
  store { i64, ptr } %t278, ptr %l27, !tbaa !27
  br label %bb66
bb46:
  %t280 = load { i64, [2 x i64] }, ptr %l4
  %t282 = extractvalue { i64, [2 x i64] } %t280, 0
  %t283 = icmp eq i64 %t282, 8
  br i1 %t283, label %bb47, label %bb48
bb47:
  %t285 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t286 = getelementptr { i32, i32, i64 }, ptr %t285, i32 0, i32 0
  %t287 = load i32, ptr %t286
  store i32 %t287, ptr %l11, !tbaa !23
  %t289 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t290 = getelementptr { i32, i32, i64 }, ptr %t289, i32 0, i32 1
  %t291 = load i32, ptr %t290
  store i32 %t291, ptr %l12
  %t293 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t294 = getelementptr { i32, i32, i64 }, ptr %t293, i32 0, i32 2
  %t295 = load i64, ptr %t294
  store i64 %t295, ptr %l13, !tbaa !24
  br label %bb49
bb48:
  br label %bb53
bb49:
  store %olang.scope zeroinitializer, ptr %s17
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load i32, ptr %l11, !tbaa !23
  %t300 = sext i32 %t298 to i64
  %t303 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ebodySym(ptr %v0, ptr %s17, ptr %t297, i64 %t300)
  store { i64, ptr } %t303, ptr %l106
  br label %bb50
bb50:
  %t304 = load i32, ptr %l12
  store i32 %t304, ptr %l107
  %t305 = load i64, ptr %l13, !tbaa !24
  store i64 %t305, ptr %l108, !tbaa !24
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s18
  store ptr %s18room, ptr %s18
  %t306 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t307 = extractvalue { i64, ptr } %t306, 1
  %t308 = extractvalue { i64, ptr } %t306, 0
  call void @__olang_sb_put(ptr %s18, ptr %t307, i64 %t308)
  %t309 = extractvalue { i64, ptr } { i64 10, ptr @.d11 }, 1
  %t310 = extractvalue { i64, ptr } { i64 10, ptr @.d11 }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t309, i64 %t310)
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aContractKind(ptr %s18, ptr %l107, i64 0)
  br label %bb51
bb51:
  %t312 = extractvalue { i64, ptr } { i64 1, ptr @.d12 }, 1
  %t313 = extractvalue { i64, ptr } { i64 1, ptr @.d12 }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t312, i64 %t313)
  %t314 = load i64, ptr %l108, !tbaa !24
  %t315 = call ptr @__olang_sb_room(ptr %s18, i64 24)
  %t316 = call i64 @__olang_fmt_i64(ptr %t315, i64 %t314)
  call void @__olang_sb_add(ptr %s18, i64 %t316)
  %t317 = load ptr, ptr %s18
  %t318 = getelementptr %olang.builder, ptr %s18, i32 0, i32 1
  %t319 = load i64, ptr %t318
  %t320 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t319)
  call void @olang_textcopy(ptr %t320, ptr %t317, i64 %t319)
  %t321 = insertvalue { i64, ptr } undef, i64 %t319, 0
  %t322 = insertvalue { i64, ptr } %t321, ptr %t320, 1
  store { i64, ptr } %t322, ptr %l110, !tbaa !27
  %t323 = getelementptr %olang.builder, ptr %s18, i32 0, i32 3
  %t324 = load ptr, ptr %t323
  %t325 = icmp ne ptr %t324, null
  br i1 %t325, label %sbgrew.326, label %sbdone.327
sbgrew.326:
  call void @__olang_sb_done(ptr %s18)
  br label %sbdone.327
sbdone.327:
  %t328 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t329 = extractvalue { i64, ptr } %t328, 0
  %t330 = extractvalue { i64, ptr } %t328, 1
  %t331 = mul i64 %t329, 1
  %t332 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t331)
  call void @llvm.memcpy.p0.p0.i64(ptr %t332, ptr %t330, i64 %t331, i1 false)
  %t333 = insertvalue { i64, ptr } undef, i64 %t329, 0
  %t334 = insertvalue { i64, ptr } %t333, ptr %t332, 1
  %t336 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t334)
  store { i64, ptr } %t336, ptr %l112
  br label %bb52
bb52:
  %t337 = load { i64, ptr }, ptr %l112, !tbaa !27
  store { i64, ptr } %t337, ptr %l27, !tbaa !27
  call void @__olang_scope_close(ptr %s17)
  br label %bb66
bb53:
  %t338 = load { i64, [2 x i64] }, ptr %l4
  %t340 = extractvalue { i64, [2 x i64] } %t338, 0
  %t341 = icmp eq i64 %t340, 9
  br i1 %t341, label %bb54, label %bb55
bb54:
  %t343 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t344 = getelementptr { i64, i64 }, ptr %t343, i32 0, i32 0
  %t345 = load i64, ptr %t344
  store i64 %t345, ptr %l14, !tbaa !24
  %t347 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t348 = getelementptr { i64, i64 }, ptr %t347, i32 0, i32 1
  %t349 = load i64, ptr %t348
  store i64 %t349, ptr %l15, !tbaa !24
  br label %bb56
bb55:
  br label %bb59
bb56:
  store %olang.scope zeroinitializer, ptr %s19
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t352 = load i64, ptr %l14, !tbaa !24
  %t355 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etableName(ptr %v0, ptr %s19, ptr %t351, i64 %t352)
  store { i64, ptr } %t355, ptr %l119
  br label %bb57
bb57:
  %t356 = load i64, ptr %l15, !tbaa !24
  %t357 = extractvalue { i64, ptr } { i64 11, ptr @.d13 }, 1
  %t358 = extractvalue { i64, ptr } { i64 11, ptr @.d13 }, 0
  %t359 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t360 = extractvalue { i64, ptr } %t359, 1
  %t361 = extractvalue { i64, ptr } %t359, 0
  %t362 = add i64 %t358, %t361
  %t363 = extractvalue { i64, ptr } { i64 1, ptr @.d14 }, 1
  %t364 = extractvalue { i64, ptr } { i64 1, ptr @.d14 }, 0
  %t365 = add i64 %t362, %t364
  %t367 = call i64 @__olang_fmt_i64(ptr null, i64 %t356)
  %t368 = add i64 %t365, %t367
  %t369 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t368)
  call void @olang_textcopy(ptr %t369, ptr %t357, i64 %t358)
  %t370 = getelementptr i8, ptr %t369, i64 %t358
  call void @olang_textcopy(ptr %t370, ptr %t360, i64 %t361)
  %t371 = getelementptr i8, ptr %t370, i64 %t361
  call void @olang_textcopy(ptr %t371, ptr %t363, i64 %t364)
  %t372 = getelementptr i8, ptr %t371, i64 %t364
  %t373 = call i64 @__olang_fmt_i64(ptr %t372, i64 %t356)
  %t374 = insertvalue { i64, ptr } undef, i64 %t368, 0
  %t375 = insertvalue { i64, ptr } %t374, ptr %t369, 1
  %t377 = extractvalue { i64, ptr } %t375, 0
  %t378 = extractvalue { i64, ptr } %t375, 1
  %t379 = mul i64 %t377, 1
  %t380 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t379)
  call void @llvm.memcpy.p0.p0.i64(ptr %t380, ptr %t378, i64 %t379, i1 false)
  %t381 = insertvalue { i64, ptr } undef, i64 %t377, 0
  %t382 = insertvalue { i64, ptr } %t381, ptr %t380, 1
  %t384 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t382)
  store { i64, ptr } %t384, ptr %l123
  br label %bb58
bb58:
  %t385 = load { i64, ptr }, ptr %l123, !tbaa !27
  store { i64, ptr } %t385, ptr %l27, !tbaa !27
  call void @__olang_scope_close(ptr %s19)
  br label %bb66
bb59:
  %t386 = load { i64, [2 x i64] }, ptr %l4
  %t388 = extractvalue { i64, [2 x i64] } %t386, 0
  %t389 = icmp eq i64 %t388, 10
  br i1 %t389, label %bb60, label %bb61
bb60:
  %t391 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t392 = getelementptr { i32, i64 }, ptr %t391, i32 0, i32 0
  %t393 = load i32, ptr %t392
  store i32 %t393, ptr %l16, !tbaa !23
  %t395 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t396 = getelementptr { i32, i64 }, ptr %t395, i32 0, i32 1
  %t397 = load i64, ptr %t396
  store i64 %t397, ptr %l17, !tbaa !24
  br label %bb62
bb61:
  br label %bb65
bb62:
  store %olang.scope zeroinitializer, ptr %s21
  %t399 = load ptr, ptr %l0, !tbaa !29
  %t400 = load i32, ptr %l16, !tbaa !23
  %t403 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecanonOf(ptr %v0, ptr %s21, ptr %t399, i32 %t400)
  store { i64, ptr } %t403, ptr %l130
  br label %bb63
bb63:
  %t404 = load i64, ptr %l17, !tbaa !24
  %t405 = extractvalue { i64, ptr } { i64 16, ptr @.d15 }, 1
  %t406 = extractvalue { i64, ptr } { i64 16, ptr @.d15 }, 0
  %t407 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t408 = extractvalue { i64, ptr } %t407, 1
  %t409 = extractvalue { i64, ptr } %t407, 0
  %t410 = add i64 %t406, %t409
  %t411 = extractvalue { i64, ptr } { i64 1, ptr @.d16 }, 1
  %t412 = extractvalue { i64, ptr } { i64 1, ptr @.d16 }, 0
  %t413 = add i64 %t410, %t412
  %t415 = call i64 @__olang_fmt_i64(ptr null, i64 %t404)
  %t416 = add i64 %t413, %t415
  %t417 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t416)
  call void @olang_textcopy(ptr %t417, ptr %t405, i64 %t406)
  %t418 = getelementptr i8, ptr %t417, i64 %t406
  call void @olang_textcopy(ptr %t418, ptr %t408, i64 %t409)
  %t419 = getelementptr i8, ptr %t418, i64 %t409
  call void @olang_textcopy(ptr %t419, ptr %t411, i64 %t412)
  %t420 = getelementptr i8, ptr %t419, i64 %t412
  %t421 = call i64 @__olang_fmt_i64(ptr %t420, i64 %t404)
  %t422 = insertvalue { i64, ptr } undef, i64 %t416, 0
  %t423 = insertvalue { i64, ptr } %t422, ptr %t417, 1
  %t425 = extractvalue { i64, ptr } %t423, 0
  %t426 = extractvalue { i64, ptr } %t423, 1
  %t427 = mul i64 %t425, 1
  %t428 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t427)
  call void @llvm.memcpy.p0.p0.i64(ptr %t428, ptr %t426, i64 %t427, i1 false)
  %t429 = insertvalue { i64, ptr } undef, i64 %t425, 0
  %t430 = insertvalue { i64, ptr } %t429, ptr %t428, 1
  %t432 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t430)
  store { i64, ptr } %t432, ptr %l134
  br label %bb64
bb64:
  %t433 = load { i64, ptr }, ptr %l134, !tbaa !27
  store { i64, ptr } %t433, ptr %l27, !tbaa !27
  call void @__olang_scope_close(ptr %s21)
  br label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_de1fe604fb5e87cf_ff4728625cff78d3)
  unreachable
bb66:
  %t434 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t434, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l1 = alloca i64
  %s0 = alloca %olang.scope
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = load i64, ptr %l1, !tbaa !24
  %t3 = extractvalue { i64, ptr } { i64 1, ptr @.d17 }, 1
  %t4 = extractvalue { i64, ptr } { i64 1, ptr @.d17 }, 0
  %t6 = call i64 @__olang_fmt_i64(ptr null, i64 %t2)
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  %t10 = call i64 @__olang_fmt_i64(ptr %t9, i64 %t2)
  %t11 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t8, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t15 = extractvalue { i64, ptr } %t12, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  %t20 = load i64, ptr @G_2ecompiler_2femit_2eHomeShared, !tbaa !24
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = extractvalue { i64, ptr } { i64 1, ptr @.d18 }, 1
  %t24 = extractvalue { i64, ptr } { i64 1, ptr @.d18 }, 0
  %t26 = call i64 @__olang_fmt_i64(ptr null, i64 %t21)
  %t27 = add i64 %t24, %t26
  %t28 = extractvalue { i64, ptr } { i64 3, ptr @.d19 }, 1
  %t29 = extractvalue { i64, ptr } { i64 3, ptr @.d19 }, 0
  %t30 = add i64 %t27, %t29
  %t32 = extractvalue { i64, ptr } %a2, 1
  %t33 = extractvalue { i64, ptr } %a2, 0
  %t34 = add i64 %t30, %t33
  %t35 = extractvalue { i64, ptr } { i64 1, ptr @.d20 }, 1
  %t36 = extractvalue { i64, ptr } { i64 1, ptr @.d20 }, 0
  %t37 = add i64 %t34, %t36
  %t38 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t37)
  call void @olang_textcopy(ptr %t38, ptr %t23, i64 %t24)
  %t39 = getelementptr i8, ptr %t38, i64 %t24
  %t40 = call i64 @__olang_fmt_i64(ptr %t39, i64 %t21)
  %t41 = getelementptr i8, ptr %t39, i64 %t26
  call void @olang_textcopy(ptr %t41, ptr %t28, i64 %t29)
  %t42 = getelementptr i8, ptr %t41, i64 %t29
  call void @olang_textcopy(ptr %t42, ptr %t32, i64 %t33)
  %t43 = getelementptr i8, ptr %t42, i64 %t33
  call void @olang_textcopy(ptr %t43, ptr %t35, i64 %t36)
  %t44 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t38, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = extractvalue { i64, ptr } %t45, 1
  %t49 = mul i64 %t47, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t48, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %a0, { i64, ptr } %t19, i64 %t20, { i64, ptr } %t52, { i64, ptr } { i64 0, ptr @.d21 })
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eexternRet(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l6 = alloca i32
  %l10 = alloca i1
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t4, i32 %a1)
  store i32 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load i32, ptr %l6, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load i32, ptr %l2, !tbaa !23
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t14 = icmp eq i32 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb4
bb3:
  %t16 = load i32, ptr %l2, !tbaa !23
  %t17 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t20 = icmp eq i32 %t16, %t17
  store i1 %t20, ptr %l10, !tbaa !21
  br label %bb4
bb4:
  %t22 = load i1, ptr %l10, !tbaa !21
  br i1 %t22, label %bb5, label %bb6
bb5:
  store { i64, ptr } { i64 4, ptr @.d22 }, ptr %l14, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t23, ptr %l15, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 0
  store i64 %t25, ptr %l16, !tbaa !24
  %t26 = load i64, ptr %l16, !tbaa !24
  %t27 = mul i64 %t26, 1
  %t28 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t27)
  %t29 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  store { i64, ptr } %t30, ptr %l17, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = load i64, ptr %l16, !tbaa !24
  %t36 = mul i64 %t35, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t32, ptr %t34, i64 %t36, i1 false)
  %t37 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t37, ptr %l15, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t38, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i32, ptr %l2, !tbaa !23
  %t43 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %v1, ptr %t39, i32 %t40)
  store { i64, ptr } %t43, ptr %l20
  br label %bb8
bb8:
  %t44 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t44, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobalOrder(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, [2 x i64] }
  %l16 = alloca i64
  %l17 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i32
  %l32 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i32
  %l51 = alloca { i64, ptr }
  %l58 = alloca ptr
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l17
  br label %bb1
bb1:
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t3, ptr %lp2
  %t4 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l17
  %t5 = load ptr, ptr %lp2
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %t5
  store ptr %l1, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v1, ptr %t7, i64 %t8)
  %t12 = extractvalue { i32, { i64, ptr } } %t11, 1
  %t13 = extractvalue { i32, { i64, ptr } } %t11, 0
  store i32 %t13, ptr %l23
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb4, label %ok.15
ok.15:
  store { i64, ptr } %t12, ptr %l22
  br label %bb3
bb3:
  %t16 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t16, ptr %l19, !tbaa !27
  br label %bb8
bb4:
  %t17 = load i32, ptr %l23, !tbaa !23
  %t18 = ashr i32 %t17, 16
  %t20 = icmp eq i32 %t18, 1
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_5ad0f5036011b2cd_7d6f5911e17dc851)
  unreachable
bb7:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb45
bb8:
  %t22 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t22, ptr %l5, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 0
  store i64 %t25, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t27 = load i64, ptr %l7, !tbaa !24
  %t28 = load i64, ptr %l6, !tbaa !24
  %t31 = icmp slt i64 %t27, %t28
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb43
bb11:
  br label %bb12
bb12:
  %t35 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t35, ptr %l32, !tbaa !27
  %t36 = load i64, ptr %l7, !tbaa !24
  %t38 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr i64, ptr %t39, i64 %t36
  %t41 = load i64, ptr %t40, !tbaa !34
  store i64 %t41, ptr %l8, !tbaa !24
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/emit:Emitter", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 37
  store ptr %t48, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s5
  %t50 = load ptr, ptr %l9, !tbaa !29
  %t51 = load i64, ptr %l10, !tbaa !24
  %t54 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %t50, i64 %t51)
  %t55 = extractvalue { i32, { i64, ptr } } %t54, 1
  %t56 = extractvalue { i32, { i64, ptr } } %t54, 0
  store i32 %t56, ptr %l42
  %t57 = icmp ne i32 %t56, 0
  br i1 %t57, label %bb15, label %ok.58
ok.58:
  store { i64, ptr } %t55, ptr %l41
  br label %bb14
bb14:
  %t59 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t59, ptr %l38, !tbaa !27
  br label %bb19
bb15:
  %t60 = load i32, ptr %l42, !tbaa !23
  %t61 = ashr i32 %t60, 16
  %t63 = icmp eq i32 %t61, 1
  br i1 %t63, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_aa3eb0efeafaca9c_7799b263c8155fc0)
  unreachable
bb18:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s5)
  br label %bb41
bb19:
  %t65 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t65, ptr %l11, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t66, 0
  store i64 %t68, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s6
  %t70 = load i64, ptr %l13, !tbaa !24
  %t71 = load i64, ptr %l12, !tbaa !24
  %t74 = icmp slt i64 %t70, %t71
  %t76 = xor i1 %t74, true
  br i1 %t76, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s6)
  br label %bb39
bb22:
  br label %bb23
bb23:
  %t78 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t78, ptr %l51, !tbaa !27
  %t79 = load i64, ptr %l13, !tbaa !24
  %t81 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr i64, ptr %t82, i64 %t79
  %t84 = load i64, ptr %t83, !tbaa !34
  store i64 %t84, ptr %l14, !tbaa !24
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/emit:Emitter", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/lower:Lowerer", ptr %t89, i32 0, i32 1
  %t92 = load i64, ptr %l14, !tbaa !24
  %t95 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t91, i64 %t92)
  store ptr %t95, ptr %l58
  br label %bb24
bb24:
  %t96 = load ptr, ptr %l58, !tbaa !29
  %t98 = getelementptr %"compiler/typed:Body", ptr %t96, i32 0, i32 1
  %t99 = load { i64, [2 x i64] }, ptr %t98
  store { i64, [2 x i64] } %t99, ptr %l15
  %t101 = load { i64, [2 x i64] }, ptr %l15
  %t103 = extractvalue { i64, [2 x i64] } %t101, 0
  %t104 = icmp eq i64 %t103, 6
  br i1 %t104, label %bb25, label %bb26
bb25:
  %t106 = getelementptr { i64, [2 x i64] }, ptr %l15, i32 0, i32 1
  %t107 = getelementptr { i64, i32 }, ptr %t106, i32 0, i32 0
  %t108 = load i64, ptr %t107
  store i64 %t108, ptr %l16, !tbaa !24
  br label %bb27
bb26:
  br label %bb32
bb27:
  %t110 = load i64, ptr %l16, !tbaa !24
  %t111 = load i64, ptr %l8, !tbaa !24
  %t114 = icmp eq i64 %t110, %t111
  br i1 %t114, label %bb28, label %bb29
bb28:
  %t116 = load ptr, ptr %lp2
  %t117 = load i64, ptr %l14, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t116, i64 %t117)
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb31
bb31:
  br label %bb37
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_eb6d9c3809493fd7_39d95642e792ba3b)
  unreachable
bb37:
  call void @__olang_scope_close(ptr %s6)
  br label %bb38
bb38:
  %t120 = load i64, ptr %l13, !tbaa !24
  %t122 = add i64 %t120, 1
  store i64 %t122, ptr %l13, !tbaa !24
  br label %bb20
bb39:
  %t124 = load i64, ptr %l10, !tbaa !24
  %t125 = load i64, ptr %l12, !tbaa !24
  %t128 = add i64 %t124, %t125
  store i64 %t128, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb40
bb40:
  br label %bb13
bb41:
  call void @__olang_scope_close(ptr %s3)
  br label %bb42
bb42:
  %t130 = load i64, ptr %l7, !tbaa !24
  %t132 = add i64 %t130, 1
  store i64 %t132, ptr %l7, !tbaa !24
  br label %bb9
bb43:
  %t134 = load i64, ptr %l4, !tbaa !24
  %t135 = load i64, ptr %l6, !tbaa !24
  %t138 = add i64 %t134, %t135
  store i64 %t138, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb44
bb44:
  br label %bb2
bb45:
  %t140 = load ptr, ptr %lp2
  %t141 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t140
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t141, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2egroupOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 15
  %t7 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store { i64, ptr } %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t11 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t9, { i64, ptr } { i64 11, ptr @.d23 })
  store i1 %t11, ptr %l8
  br label %bb2
bb2:
  %t12 = load i1, ptr %l8, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb6
bb4:
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t15 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t13, { i64, ptr } { i64 4, ptr @.d24 })
  store i1 %t15, ptr %l11
  br label %bb5
bb5:
  %t16 = load i1, ptr %l11, !tbaa !21
  store i1 %t16, ptr %l9, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l9, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i64 1, ptr %l12, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l12, !tbaa !24
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t18 = load i64, ptr %l12, !tbaa !24
  store i64 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisGlobalInit(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i32
  %l4 = alloca i1
  %l13 = alloca ptr
  %l16 = alloca i1
  %rv = alloca i1
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb14
bb3:
  %t12 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/lower:Lowerer", ptr %t13, i32 0, i32 1
  %t16 = load i32, ptr %l2, !tbaa !23
  %t18 = sext i32 %t16 to i64
  %t21 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t15, i64 %t18)
  store ptr %t21, ptr %l13
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l13, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Body", ptr %t22, i32 0, i32 1
  %t25 = load { i64, [2 x i64] }, ptr %t24
  %t29 = extractvalue { i64, [2 x i64] } %t25, 0
  %t30 = icmp eq i64 %t29, 6
  br i1 %t30, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb13
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_616c6f643d0ce9fd_dfe523617d4699c1)
  unreachable
bb13:
  %t32 = load i1, ptr %l16, !tbaa !21
  store i1 %t32, ptr %l4, !tbaa !21
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_b37ed008d0080fcc_cc9019489ebc5a30)
  unreachable
bb19:
  %t33 = load i1, ptr %l4, !tbaa !21
  store i1 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisLambda(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l7 = alloca ptr
  %l10 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/lower:Lowerer", ptr %t4, i32 0, i32 1
  %t10 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t6, i64 %a1)
  store ptr %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l7, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 1
  %t14 = load { i64, [2 x i64] }, ptr %t13
  %t18 = extractvalue { i64, [2 x i64] } %t14, 0
  %t19 = icmp eq i64 %t18, 4
  br i1 %t19, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb5
bb4:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_7f6c4a9881f0c77f_244fd8f3f85b2bab)
  unreachable
bb10:
  %t21 = load i1, ptr %l10, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2elocBase(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca i32
  %l22 = alloca i1
  %l25 = alloca i1
  %l29 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l41 = alloca i1
  %l47 = alloca ptr
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l63 = alloca ptr
  %l67 = alloca i64
  %l69 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 -1, ptr %l2, !tbaa !24
  store i1 false, ptr %l3, !tbaa !21
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l4, !tbaa !23
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t10 = load i32, ptr %l4, !tbaa !23
  %t12 = sext i32 %t10 to i64
  store i64 %t12, ptr %l2, !tbaa !24
  br label %bb13
bb4:
  %t14 = load { i64, [2 x i64] }, ptr %l1
  %t16 = extractvalue { i64, [2 x i64] } %t14, 0
  %t17 = icmp eq i64 %t16, 1
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t19 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t20 = getelementptr { i32 }, ptr %t19, i32 0, i32 0
  %t21 = load i32, ptr %t20
  store i32 %t21, ptr %l5, !tbaa !23
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t23 = load i32, ptr %l5, !tbaa !23
  %t25 = sext i32 %t23 to i64
  store i64 %t25, ptr %l2, !tbaa !24
  store i1 true, ptr %l3, !tbaa !21
  br label %bb13
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_1cb2b0b1c80ab6bb_ff3b7bcb0dec81bf)
  unreachable
bb13:
  %t27 = load i64, ptr %l2, !tbaa !24
  %t29 = icmp slt i64 %t27, 0
  br i1 %t29, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb17
bb15:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i64, ptr %l2, !tbaa !24
  %t35 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisLambda(ptr %v0, ptr %t31, i64 %t32)
  store i1 %t35, ptr %l25
  br label %bb16
bb16:
  %t36 = load i1, ptr %l25, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %l22, !tbaa !21
  br label %bb17
bb17:
  %t39 = load i1, ptr %l22, !tbaa !21
  br i1 %t39, label %bb18, label %bb19
bb18:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load { i64, [2 x i64] }, ptr %l1
  %t44 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %v1, ptr %t40, { i64, [2 x i64] } %t41)
  store { i64, ptr } %t44, ptr %l29
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t45 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t45, ptr %rv
  br label %ret
bb21:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/emit:Emitter", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/lower:Lowerer", ptr %t49, i32 0, i32 1
  %t52 = load i64, ptr %l2, !tbaa !24
  %t55 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t51, i64 %t52)
  store ptr %t55, ptr %l34
  br label %bb22
bb22:
  %t56 = load ptr, ptr %l34, !tbaa !29
  %t58 = getelementptr %"compiler/typed:Body", ptr %t56, i32 0, i32 4
  %t59 = getelementptr %"compiler/source:Span", ptr %t58, i32 0, i32 0
  %t60 = load i32, ptr %t59, !tbaa !23
  %t62 = sext i32 %t60 to i64
  store i64 %t62, ptr %l6, !tbaa !24
  %t64 = load i64, ptr %l2, !tbaa !24
  store i64 %t64, ptr %l7, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s5
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i64, ptr %l7, !tbaa !24
  %t70 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisLambda(ptr %v0, ptr %t66, i64 %t67)
  store i1 %t70, ptr %l41
  br label %bb24
bb24:
  %t71 = load i1, ptr %l41, !tbaa !21
  %t72 = xor i1 %t71, true
  br i1 %t72, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s5)
  br label %bb39
bb26:
  br label %bb27
bb27:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/emit:Emitter", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/lower:Lowerer", ptr %t77, i32 0, i32 1
  %t80 = load i64, ptr %l7, !tbaa !24
  %t83 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t79, i64 %t80)
  store ptr %t83, ptr %l47
  br label %bb28
bb28:
  %t84 = load ptr, ptr %l47, !tbaa !29
  %t86 = getelementptr %"compiler/typed:Body", ptr %t84, i32 0, i32 1
  %t87 = load { i64, [2 x i64] }, ptr %t86
  store { i64, [2 x i64] } %t87, ptr %l8
  %t89 = load { i64, [2 x i64] }, ptr %l8
  %t91 = extractvalue { i64, [2 x i64] } %t89, 0
  %t92 = icmp eq i64 %t91, 4
  br i1 %t92, label %bb29, label %bb30
bb29:
  %t94 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t95 = getelementptr { i32 }, ptr %t94, i32 0, i32 0
  %t96 = load i32, ptr %t95
  store i32 %t96, ptr %l9, !tbaa !23
  br label %bb31
bb30:
  br label %bb32
bb31:
  %t98 = load i32, ptr %l9, !tbaa !23
  %t100 = sext i32 %t98 to i64
  store i64 %t100, ptr %l7, !tbaa !24
  br label %bb37
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  call void @__olang_scope_close(ptr %s5)
  br label %bb39
bb36:
  call void @__olang_check_failed(ptr @olang_loc_dd4469a9ae312a3a_602f574df5758ebe)
  unreachable
bb37:
  call void @__olang_scope_close(ptr %s5)
  br label %bb38
bb38:
  br label %bb23
bb39:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load i64, ptr %l7, !tbaa !24
  %t106 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ebodySym(ptr %v0, ptr %s0, ptr %t102, i64 %t103)
  store { i64, ptr } %t106, ptr %l57
  br label %bb40
bb40:
  %t107 = load i64, ptr %l6, !tbaa !24
  store i64 %t107, ptr %l58, !tbaa !24
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/emit:Emitter", ptr %t108, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = getelementptr %"compiler/lower:Lowerer", ptr %t111, i32 0, i32 1
  %t114 = load i64, ptr %l7, !tbaa !24
  %t117 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t113, i64 %t114)
  store ptr %t117, ptr %l63
  br label %bb41
bb41:
  %t118 = load ptr, ptr %l63, !tbaa !29
  %t120 = getelementptr %"compiler/typed:Body", ptr %t118, i32 0, i32 4
  %t121 = getelementptr %"compiler/source:Span", ptr %t120, i32 0, i32 0
  %t122 = load i32, ptr %t121, !tbaa !23
  %t124 = sext i32 %t122 to i64
  %t125 = load i64, ptr %l58, !tbaa !24
  %t127 = sub i64 %t125, %t124
  store i64 %t127, ptr %l67, !tbaa !24
  %t128 = load i1, ptr %l3, !tbaa !21
  br i1 %t128, label %bb42, label %bb43
bb42:
  store { i64, ptr } { i64 8, ptr @.d25 }, ptr %l69, !tbaa !27
  br label %bb44
bb43:
  store { i64, ptr } { i64 0, ptr @.d26 }, ptr %l69, !tbaa !27
  br label %bb44
bb44:
  %t130 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 1
  %t132 = extractvalue { i64, ptr } %t130, 0
  %t133 = extractvalue { i64, ptr } { i64 1, ptr @.d27 }, 1
  %t134 = extractvalue { i64, ptr } { i64 1, ptr @.d27 }, 0
  %t135 = add i64 %t132, %t134
  %t136 = load i64, ptr %l67, !tbaa !24
  %t137 = call i64 @__olang_fmt_i64(ptr null, i64 %t136)
  %t138 = add i64 %t135, %t137
  %t139 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 1
  %t141 = extractvalue { i64, ptr } %t139, 0
  %t142 = add i64 %t138, %t141
  %t143 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t142)
  call void @olang_textcopy(ptr %t143, ptr %t131, i64 %t132)
  %t144 = getelementptr i8, ptr %t143, i64 %t132
  call void @olang_textcopy(ptr %t144, ptr %t133, i64 %t134)
  %t145 = getelementptr i8, ptr %t144, i64 %t134
  %t146 = call i64 @__olang_fmt_i64(ptr %t145, i64 %t136)
  %t147 = getelementptr i8, ptr %t145, i64 %t137
  call void @olang_textcopy(ptr %t147, ptr %t140, i64 %t141)
  %t148 = insertvalue { i64, ptr } undef, i64 %t142, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t143, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t149, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2emathIntrinsic(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i1
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l26 = alloca i1
  %l28 = alloca i1
  %l30 = alloca i1
  %l31 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %l40 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i32
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l52 = alloca i32
  %l53 = alloca { i64, ptr }
  %l55 = alloca i32
  %l62 = alloca i1
  %l63 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca i32
  %l69 = alloca i32
  %l71 = alloca i1
  %l73 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l75 = alloca i64
  %l76 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l89 = alloca i32
  %l91 = alloca i32
  %l93 = alloca i1
  %l95 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l97 = alloca i64
  %l98 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t6, ptr %l15, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t7, 0
  store i64 %t10, ptr %l18, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  store i64 %t12, ptr %l19, !tbaa !24
  %t13 = icmp sge i64 0, 0
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i64, ptr %l18, !tbaa !24
  %t16 = icmp sle i64 0, %t15
  br i1 %t16, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_e68028fa4f0f457e_ac0c180900ac4e62)
  unreachable
bb3:
  %t18 = load i64, ptr %l18, !tbaa !24
  %t19 = load i64, ptr %l19, !tbaa !24
  %t20 = icmp sle i64 %t18, %t19
  br i1 %t20, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_e68028fa4f0f457e_ac0c180900ac4e62)
  unreachable
bb5:
  %t22 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = load i64, ptr %l18, !tbaa !24
  %t25 = getelementptr i8, ptr %t23, i64 0
  %t26 = sub i64 %t24, 0
  %t27 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t25, 1
  store { i64, ptr } %t28, ptr %l4, !tbaa !27
  store i1 false, ptr %l5, !tbaa !21
  %t30 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t31 = load ptr, ptr @__olang_prog_scope
  %t34 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %t31, ptr %v1, ptr @G_2ecompiler_2femit_2emathExact, { i64, ptr } %t30)
  store i1 %t34, ptr %l26
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_e68028fa4f0f457e_ac0c180900ac4e62)
  unreachable
bb7:
  %t35 = load i1, ptr %l26, !tbaa !21
  %t36 = xor i1 %t35, true
  br i1 %t36, label %bb8, label %bb9
bb8:
  %t38 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t40 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v1, ptr %s0, { i64, ptr } %t38, { i64, ptr } { i64 1, ptr @.d28 })
  store i1 %t40, ptr %l30
  br label %bb10
bb9:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb11
bb10:
  %t41 = load i1, ptr %l30, !tbaa !21
  store i1 %t41, ptr %l28, !tbaa !21
  br label %bb11
bb11:
  %t42 = load i1, ptr %l28, !tbaa !21
  br i1 %t42, label %bb12, label %bb13
bb12:
  %t43 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t43, ptr %l31, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t48 = sub i64 %t46, 1
  store i64 %t48, ptr %l34, !tbaa !24
  %t49 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  store i64 %t50, ptr %l35, !tbaa !24
  %t51 = icmp sge i64 0, 0
  br i1 %t51, label %bb14, label %bb15
bb13:
  br label %bb20
bb14:
  %t53 = load i64, ptr %l34, !tbaa !24
  %t54 = icmp sle i64 0, %t53
  br i1 %t54, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_8b9f7f38fd25c7fb_28bbaeaad75485df)
  unreachable
bb16:
  %t56 = load i64, ptr %l34, !tbaa !24
  %t57 = load i64, ptr %l35, !tbaa !24
  %t58 = icmp sle i64 %t56, %t57
  br i1 %t58, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_8b9f7f38fd25c7fb_28bbaeaad75485df)
  unreachable
bb18:
  %t60 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = load i64, ptr %l34, !tbaa !24
  %t63 = getelementptr i8, ptr %t61, i64 0
  %t64 = sub i64 %t62, 0
  %t65 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t63, 1
  store { i64, ptr } %t66, ptr %l4, !tbaa !27
  store i1 true, ptr %l5, !tbaa !21
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_8b9f7f38fd25c7fb_28bbaeaad75485df)
  unreachable
bb20:
  %t68 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t69 = load ptr, ptr @__olang_prog_scope
  %t72 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %t69, ptr %v1, ptr @G_2ecompiler_2femit_2emathExact, { i64, ptr } %t68)
  %t73 = extractvalue { i32, i64 } %t72, 1
  %t74 = extractvalue { i32, i64 } %t72, 0
  store i32 %t74, ptr %l44
  %t75 = icmp ne i32 %t74, 0
  br i1 %t75, label %bb22, label %ok.76
ok.76:
  store i64 %t73, ptr %l43
  br label %bb21
bb21:
  %t77 = load i64, ptr %l43, !tbaa !24
  store i64 %t77, ptr %l40, !tbaa !24
  br label %bb24
bb22:
  br label %bb23
bb23:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr @.d29 }, ptr %l45, !tbaa !27
  %t78 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t78, ptr %l46, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 0
  store i64 %t80, ptr %l47, !tbaa !24
  %t81 = load i64, ptr %l47, !tbaa !24
  %t82 = mul i64 %t81, 1
  %t83 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t82)
  %t84 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t83, 1
  store { i64, ptr } %t85, ptr %l48, !tbaa !27
  %t86 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = load i64, ptr %l47, !tbaa !24
  %t91 = mul i64 %t90, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t87, ptr %t89, i64 %t91, i1 false)
  %t92 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t92, ptr %l46, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t93 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t93, ptr %rv
  br label %ret
bb24:
  %t94 = load i64, ptr %l40, !tbaa !24
  store i64 %t94, ptr %l6, !tbaa !24
  %t95 = load ptr, ptr %l3, !tbaa !29
  store ptr %t95, ptr %l49, !tbaa !29
  %t96 = load ptr, ptr %l3, !tbaa !29
  %t97 = load i32, ptr %l2, !tbaa !23
  %t100 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t96, i32 %t97)
  store i32 %t100, ptr %l52
  br label %bb25
bb25:
  %t101 = load ptr, ptr %l49, !tbaa !29
  %t102 = load i32, ptr %l52, !tbaa !23
  %t103 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t101, i32 %t102)
  store { i64, ptr } %t103, ptr %l53
  br label %bb26
bb26:
  %t104 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t104, ptr %l7, !tbaa !27
  %t105 = load i1, ptr %l5, !tbaa !21
  br i1 %t105, label %bb27, label %bb28
bb27:
  store i32 13, ptr %l55
  br label %bb29
bb28:
  store i32 14, ptr %l55
  br label %bb29
bb29:
  %t109 = load i32, ptr %l55
  store i32 %t109, ptr %l8
  %t110 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t110, 0
  %t113 = load i64, ptr %l6, !tbaa !24
  %t116 = icmp ne i64 %t112, %t113
  br i1 %t116, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb35
bb31:
  %t118 = load ptr, ptr %l3, !tbaa !29
  store ptr %t118, ptr %l63, !tbaa !29
  %t119 = load ptr, ptr %l3, !tbaa !29
  %t120 = load i32, ptr %l2, !tbaa !23
  %t123 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t119, i32 %t120)
  store i32 %t123, ptr %l66
  br label %bb32
bb32:
  %t124 = load ptr, ptr %l63, !tbaa !29
  %t125 = load i32, ptr %l66, !tbaa !23
  %t126 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t124, i32 %t125)
  store i32 %t126, ptr %l67
  br label %bb33
bb33:
  %t127 = load i32, ptr %l8
  store i32 %t127, ptr %l69
  %t130 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l67, ptr %l69)
  store i1 %t130, ptr %l71
  br label %bb34
bb34:
  %t131 = load i1, ptr %l71, !tbaa !21
  %t132 = xor i1 %t131, true
  store i1 %t132, ptr %l62, !tbaa !21
  br label %bb35
bb35:
  %t134 = load i1, ptr %l62, !tbaa !21
  br i1 %t134, label %bb36, label %bb37
bb36:
  store { i64, ptr } { i64 0, ptr @.d30 }, ptr %l73, !tbaa !27
  %t135 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t135, ptr %l74, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 0
  store i64 %t137, ptr %l75, !tbaa !24
  %t138 = load i64, ptr %l75, !tbaa !24
  %t139 = mul i64 %t138, 1
  %t140 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t139)
  %t141 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t140, 1
  store { i64, ptr } %t142, ptr %l76, !tbaa !27
  %t143 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = load i64, ptr %l75, !tbaa !24
  %t148 = mul i64 %t147, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t144, ptr %t146, i64 %t148, i1 false)
  %t149 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t149, ptr %l74, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t150 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t150, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  %t151 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t151, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t153 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t153, 0
  store i64 %t155, ptr %l11, !tbaa !24
  br label %bb39
bb39:
  store %olang.scope zeroinitializer, ptr %s5
  %t157 = load i64, ptr %l10, !tbaa !24
  %t158 = load i64, ptr %l11, !tbaa !24
  %t161 = icmp slt i64 %t157, %t158
  %t163 = xor i1 %t161, true
  br i1 %t163, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s5)
  br label %bb49
bb41:
  br label %bb42
bb42:
  %t165 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t165, ptr %l84, !tbaa !27
  %t166 = load i64, ptr %l10, !tbaa !24
  %t168 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = getelementptr i32, ptr %t169, i64 %t166
  %t171 = load i32, ptr %t170, !tbaa !33
  %t173 = load ptr, ptr %l3, !tbaa !29
  %t177 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t173, i32 %t171)
  store i32 %t177, ptr %l89
  br label %bb43
bb43:
  %t178 = load i32, ptr %l8
  store i32 %t178, ptr %l91
  %t181 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l89, ptr %l91)
  store i1 %t181, ptr %l93
  br label %bb44
bb44:
  %t182 = load i1, ptr %l93, !tbaa !21
  %t183 = xor i1 %t182, true
  br i1 %t183, label %bb45, label %bb46
bb45:
  store { i64, ptr } { i64 0, ptr @.d31 }, ptr %l95, !tbaa !27
  %t185 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t185, ptr %l96, !tbaa !27
  %t186 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t186, 0
  store i64 %t187, ptr %l97, !tbaa !24
  %t188 = load i64, ptr %l97, !tbaa !24
  %t189 = mul i64 %t188, 1
  %t190 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t189)
  %t191 = insertvalue { i64, ptr } undef, i64 %t188, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t190, 1
  store { i64, ptr } %t192, ptr %l98, !tbaa !27
  %t193 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t194 = load ptr, ptr %t193, !tbaa !27
  %t195 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = load i64, ptr %l97, !tbaa !24
  %t198 = mul i64 %t197, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t194, ptr %t196, i64 %t198, i1 false)
  %t199 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t199, ptr %l96, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t200 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t200, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s5)
  br label %bb48
bb48:
  %t201 = load i64, ptr %l10, !tbaa !24
  %t203 = add i64 %t201, 1
  store i64 %t203, ptr %l10, !tbaa !24
  br label %bb39
bb49:
  %t205 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t205, ptr %l101, !tbaa !27
  %t206 = load i1, ptr %l5, !tbaa !21
  br i1 %t206, label %bb50, label %bb51
bb50:
  store { i64, ptr } { i64 2, ptr @.d32 }, ptr %l103, !tbaa !27
  br label %bb52
bb51:
  store { i64, ptr } { i64 2, ptr @.d33 }, ptr %l103, !tbaa !27
  br label %bb52
bb52:
  %t208 = extractvalue { i64, ptr } { i64 5, ptr @.d34 }, 1
  %t209 = extractvalue { i64, ptr } { i64 5, ptr @.d34 }, 0
  %t210 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t210, 1
  %t212 = extractvalue { i64, ptr } %t210, 0
  %t213 = add i64 %t209, %t212
  %t214 = extractvalue { i64, ptr } { i64 2, ptr @.d35 }, 1
  %t215 = extractvalue { i64, ptr } { i64 2, ptr @.d35 }, 0
  %t216 = add i64 %t213, %t215
  %t217 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t218 = extractvalue { i64, ptr } %t217, 1
  %t219 = extractvalue { i64, ptr } %t217, 0
  %t220 = add i64 %t216, %t219
  %t221 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t220)
  call void @olang_textcopy(ptr %t221, ptr %t208, i64 %t209)
  %t222 = getelementptr i8, ptr %t221, i64 %t209
  call void @olang_textcopy(ptr %t222, ptr %t211, i64 %t212)
  %t223 = getelementptr i8, ptr %t222, i64 %t212
  call void @olang_textcopy(ptr %t223, ptr %t214, i64 %t215)
  %t224 = getelementptr i8, ptr %t223, i64 %t215
  call void @olang_textcopy(ptr %t224, ptr %t218, i64 %t219)
  %t225 = insertvalue { i64, ptr } undef, i64 %t220, 0
  %t226 = insertvalue { i64, ptr } %t225, ptr %t221, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t226, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2enoTable(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = load i64, ptr @G_2ecompiler_2femit_2eHomeShared, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %a0, { i64, ptr } { i64 13, ptr @.d36 }, i64 %t2, { i64, ptr } { i64 48, ptr @.d37 }, { i64, ptr } { i64 0, ptr @.d38 })
  br label %bb1
bb1:
  store { i64, ptr } { i64 13, ptr @.d39 }, ptr %l3, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t5, ptr %l4, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = mul i64 %t8, 1
  %t10 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l6, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = load i64, ptr %l5, !tbaa !24
  %t18 = mul i64 %t17, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %t16, i64 %t18, i1 false)
  %t19 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t19, ptr %l4, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t20 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t20, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2erecodeText(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, i32 %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l18 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l33 = alloca i64
  %l36 = alloca i64
  %l60 = alloca ptr
  %l61 = alloca i64
  %l62 = alloca i64
  %l65 = alloca { i64, ptr }
  %l68 = alloca i64
  %l73 = alloca { i64, ptr }
  %l75 = alloca i64
  %l83 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l85 = alloca i64
  %l86 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t4, i32 %a3)
  store { i64, ptr } %t10, ptr %l18
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t11, ptr %l6, !tbaa !27
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t15 = extractvalue { i64, ptr } { i64 18, ptr @.d40 }, 1
  %t16 = extractvalue { i64, ptr } { i64 18, ptr @.d40 }, 0
  %t18 = extractvalue { i64, ptr } %t13, 1
  %t19 = extractvalue { i64, ptr } %t13, 0
  %t20 = add i64 %t16, %t19
  %t21 = extractvalue { i64, ptr } { i64 21, ptr @.d41 }, 1
  %t22 = extractvalue { i64, ptr } { i64 21, ptr @.d41 }, 0
  %t23 = add i64 %t20, %t22
  %t25 = extractvalue { i64, ptr } %t14, 1
  %t26 = extractvalue { i64, ptr } %t14, 0
  %t27 = add i64 %t23, %t26
  %t28 = extractvalue { i64, ptr } { i64 8, ptr @.d42 }, 1
  %t29 = extractvalue { i64, ptr } { i64 8, ptr @.d42 }, 0
  %t30 = add i64 %t27, %t29
  %t31 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t30)
  call void @olang_textcopy(ptr %t31, ptr %t15, i64 %t16)
  %t32 = getelementptr i8, ptr %t31, i64 %t16
  call void @olang_textcopy(ptr %t32, ptr %t18, i64 %t19)
  %t33 = getelementptr i8, ptr %t32, i64 %t19
  call void @olang_textcopy(ptr %t33, ptr %t21, i64 %t22)
  %t34 = getelementptr i8, ptr %t33, i64 %t22
  call void @olang_textcopy(ptr %t34, ptr %t25, i64 %t26)
  %t35 = getelementptr i8, ptr %t34, i64 %t26
  call void @olang_textcopy(ptr %t35, ptr %t28, i64 %t29)
  %t36 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t31, 1
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t40 = extractvalue { i64, ptr } %t37, 1
  %t41 = mul i64 %t39, 1
  %t42 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t41)
  call void @llvm.memcpy.p0.p0.i64(ptr %t42, ptr %t40, i64 %t41, i1 false)
  %t43 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t12, { i64, ptr } %t44)
  br label %bb2
bb2:
  store { i64, ptr } { i64 1, ptr @.d43 }, ptr %l24, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t47, ptr %l25, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 0
  store i64 %t49, ptr %l26, !tbaa !24
  %t50 = load i64, ptr %l26, !tbaa !24
  %t51 = mul i64 %t50, 1
  %t52 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t51)
  %t53 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  store { i64, ptr } %t54, ptr %l27, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = load i64, ptr %l26, !tbaa !24
  %t60 = mul i64 %t59, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t56, ptr %t58, i64 %t60, i1 false)
  %t61 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t61, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t62 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t62, 0
  store i64 %t64, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t66 = load i64, ptr %l9, !tbaa !24
  %t67 = load i64, ptr %l8, !tbaa !24
  %t70 = icmp sgt i64 %t66, %t67
  br i1 %t70, label %bb3, label %bb4
bb3:
  %t72 = load i64, ptr %l10, !tbaa !24
  %t74 = icmp sgt i64 %t72, 0
  br i1 %t74, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb8
bb5:
  %t76 = load i64, ptr %l9, !tbaa !24
  %t77 = load i64, ptr %l8, !tbaa !24
  %t80 = sub i64 %t76, %t77
  %t81 = load i64, ptr %l10, !tbaa !24
  %t84 = add i64 %t80, %t81
  %t86 = sub i64 %t84, 1
  %t87 = load i64, ptr %l10, !tbaa !24
  %t90 = sdiv i64 %t86, %t87
  store i64 %t90, ptr %l36, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb7
bb7:
  %t92 = load i64, ptr %l36, !tbaa !24
  store i64 %t92, ptr %l33, !tbaa !24
  br label %bb8
bb8:
  %t93 = load i64, ptr %l33, !tbaa !24
  store i64 %t93, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t94 = load i64, ptr %l12, !tbaa !24
  %t95 = load i64, ptr %l11, !tbaa !24
  %t98 = icmp slt i64 %t94, %t95
  %t100 = xor i1 %t98, true
  br i1 %t100, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb11:
  br label %bb12
bb12:
  %t102 = load i64, ptr %l8, !tbaa !24
  %t103 = load i64, ptr %l12, !tbaa !24
  %t104 = load i64, ptr %l10, !tbaa !24
  %t107 = mul i64 %t103, %t104
  %t110 = add i64 %t102, %t107
  store i64 %t110, ptr %l13, !tbaa !24
  %t112 = load ptr, ptr %l1, !tbaa !29
  %t113 = load i64, ptr %l13, !tbaa !24
  %t114 = load i64, ptr %l13, !tbaa !24
  %t116 = add i64 %t114, 1
  %t117 = extractvalue { i64, ptr } { i64 5, ptr @.d44 }, 1
  %t118 = extractvalue { i64, ptr } { i64 5, ptr @.d44 }, 0
  %t120 = call i64 @__olang_fmt_i64(ptr null, i64 %t113)
  %t121 = add i64 %t118, %t120
  %t122 = extractvalue { i64, ptr } { i64 21, ptr @.d45 }, 1
  %t123 = extractvalue { i64, ptr } { i64 21, ptr @.d45 }, 0
  %t124 = add i64 %t121, %t123
  %t126 = call i64 @__olang_fmt_i64(ptr null, i64 %t116)
  %t127 = add i64 %t124, %t126
  %t128 = extractvalue { i64, ptr } { i64 1, ptr @.d46 }, 1
  %t129 = extractvalue { i64, ptr } { i64 1, ptr @.d46 }, 0
  %t130 = add i64 %t127, %t129
  %t131 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t130)
  call void @olang_textcopy(ptr %t131, ptr %t117, i64 %t118)
  %t132 = getelementptr i8, ptr %t131, i64 %t118
  %t133 = call i64 @__olang_fmt_i64(ptr %t132, i64 %t113)
  %t134 = getelementptr i8, ptr %t132, i64 %t120
  call void @olang_textcopy(ptr %t134, ptr %t122, i64 %t123)
  %t135 = getelementptr i8, ptr %t134, i64 %t123
  %t136 = call i64 @__olang_fmt_i64(ptr %t135, i64 %t116)
  %t137 = getelementptr i8, ptr %t135, i64 %t126
  call void @olang_textcopy(ptr %t137, ptr %t128, i64 %t129)
  %t138 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t131, 1
  %t141 = extractvalue { i64, ptr } %t139, 0
  %t142 = extractvalue { i64, ptr } %t139, 1
  %t143 = mul i64 %t141, 1
  %t144 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t143)
  call void @llvm.memcpy.p0.p0.i64(ptr %t144, ptr %t142, i64 %t143, i1 false)
  %t145 = insertvalue { i64, ptr } undef, i64 %t141, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t144, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s3, ptr %t112, { i64, ptr } %t146)
  br label %bb13
bb13:
  %t149 = load ptr, ptr %l1, !tbaa !29
  store ptr %t149, ptr %l60, !tbaa !29
  %t150 = load i64, ptr %l13, !tbaa !24
  store i64 %t150, ptr %l61, !tbaa !24
  %t151 = load i64, ptr %l13, !tbaa !24
  store i64 %t151, ptr %l62, !tbaa !24
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t154, ptr %l65, !tbaa !27
  %t155 = load i64, ptr %l13, !tbaa !24
  %t157 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = getelementptr i32, ptr %t158, i64 %t155
  %t160 = load i32, ptr %t159, !tbaa !33
  %t164 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eposition(ptr %v0, ptr %t152, i32 %a4, i32 %t160)
  store i64 %t164, ptr %l68
  br label %bb14
bb14:
  %t165 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t166 = extractvalue { i64, ptr } { i64 5, ptr @.d47 }, 1
  %t167 = extractvalue { i64, ptr } { i64 5, ptr @.d47 }, 0
  %t168 = load i64, ptr %l61, !tbaa !24
  %t169 = call i64 @__olang_fmt_i64(ptr null, i64 %t168)
  %t170 = add i64 %t167, %t169
  %t171 = extractvalue { i64, ptr } { i64 16, ptr @.d48 }, 1
  %t172 = extractvalue { i64, ptr } { i64 16, ptr @.d48 }, 0
  %t173 = add i64 %t170, %t172
  %t174 = load i64, ptr %l62, !tbaa !24
  %t175 = call i64 @__olang_fmt_i64(ptr null, i64 %t174)
  %t176 = add i64 %t173, %t175
  %t177 = extractvalue { i64, ptr } { i64 6, ptr @.d49 }, 1
  %t178 = extractvalue { i64, ptr } { i64 6, ptr @.d49 }, 0
  %t179 = add i64 %t176, %t178
  %t180 = load i64, ptr %l68, !tbaa !24
  %t181 = call i64 @__olang_fmt_i64(ptr null, i64 %t180)
  %t182 = add i64 %t179, %t181
  %t183 = extractvalue { i64, ptr } { i64 6, ptr @.d50 }, 1
  %t184 = extractvalue { i64, ptr } { i64 6, ptr @.d50 }, 0
  %t185 = add i64 %t182, %t184
  %t187 = extractvalue { i64, ptr } %t165, 1
  %t188 = extractvalue { i64, ptr } %t165, 0
  %t189 = add i64 %t185, %t188
  %t190 = extractvalue { i64, ptr } { i64 1, ptr @.d51 }, 1
  %t191 = extractvalue { i64, ptr } { i64 1, ptr @.d51 }, 0
  %t192 = add i64 %t189, %t191
  %t193 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t192)
  call void @olang_textcopy(ptr %t193, ptr %t166, i64 %t167)
  %t194 = getelementptr i8, ptr %t193, i64 %t167
  %t195 = call i64 @__olang_fmt_i64(ptr %t194, i64 %t168)
  %t196 = getelementptr i8, ptr %t194, i64 %t169
  call void @olang_textcopy(ptr %t196, ptr %t171, i64 %t172)
  %t197 = getelementptr i8, ptr %t196, i64 %t172
  %t198 = call i64 @__olang_fmt_i64(ptr %t197, i64 %t174)
  %t199 = getelementptr i8, ptr %t197, i64 %t175
  call void @olang_textcopy(ptr %t199, ptr %t177, i64 %t178)
  %t200 = getelementptr i8, ptr %t199, i64 %t178
  %t201 = call i64 @__olang_fmt_i64(ptr %t200, i64 %t180)
  %t202 = getelementptr i8, ptr %t200, i64 %t181
  call void @olang_textcopy(ptr %t202, ptr %t183, i64 %t184)
  %t203 = getelementptr i8, ptr %t202, i64 %t184
  call void @olang_textcopy(ptr %t203, ptr %t187, i64 %t188)
  %t204 = getelementptr i8, ptr %t203, i64 %t188
  call void @olang_textcopy(ptr %t204, ptr %t190, i64 %t191)
  %t205 = insertvalue { i64, ptr } undef, i64 %t192, 0
  %t206 = insertvalue { i64, ptr } %t205, ptr %t193, 1
  %t208 = extractvalue { i64, ptr } %t206, 0
  %t209 = extractvalue { i64, ptr } %t206, 1
  %t210 = mul i64 %t208, 1
  %t211 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t210)
  call void @llvm.memcpy.p0.p0.i64(ptr %t211, ptr %t209, i64 %t210, i1 false)
  %t212 = insertvalue { i64, ptr } undef, i64 %t208, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %t211, 1
  %t214 = load ptr, ptr %l60, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s3, ptr %t214, { i64, ptr } %t213)
  br label %bb15
bb15:
  %t216 = load i64, ptr %l13, !tbaa !24
  %t217 = extractvalue { i64, ptr } { i64 3, ptr @.d52 }, 1
  %t218 = extractvalue { i64, ptr } { i64 3, ptr @.d52 }, 0
  %t220 = call i64 @__olang_fmt_i64(ptr null, i64 %t216)
  %t221 = add i64 %t218, %t220
  %t222 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t221)
  call void @olang_textcopy(ptr %t222, ptr %t217, i64 %t218)
  %t223 = getelementptr i8, ptr %t222, i64 %t218
  %t224 = call i64 @__olang_fmt_i64(ptr %t223, i64 %t216)
  %t225 = insertvalue { i64, ptr } undef, i64 %t221, 0
  %t226 = insertvalue { i64, ptr } %t225, ptr %t222, 1
  store { i64, ptr } %t226, ptr %l73, !tbaa !27
  %t227 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t228 = extractvalue { i64, ptr } %t227, 0
  %t229 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t229, 0
  store i64 %t230, ptr %l75, !tbaa !24
  %t232 = load i64, ptr %l75, !tbaa !24
  %t233 = icmp eq i64 %t228, %t232
  br i1 %t233, label %bb16, label %bb17
bb16:
  %t235 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t236 = load ptr, ptr %t235, !tbaa !27
  %t237 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t238 = load ptr, ptr %t237, !tbaa !27
  %t239 = load i64, ptr %l75, !tbaa !24
  %t240 = mul i64 %t239, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t236, ptr %t238, i64 %t240, i1 false)
  br label %bb18
bb17:
  %t241 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t241, ptr %l7, !tbaa !27
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  %t242 = load i64, ptr %l12, !tbaa !24
  %t244 = add i64 %t242, 1
  store i64 %t244, ptr %l12, !tbaa !24
  br label %bb9
bb20:
  %t246 = load ptr, ptr %l1, !tbaa !29
  %t247 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t248 = extractvalue { i64, ptr } { i64 16, ptr @.d53 }, 1
  %t249 = extractvalue { i64, ptr } { i64 16, ptr @.d53 }, 0
  %t251 = extractvalue { i64, ptr } %t247, 1
  %t252 = extractvalue { i64, ptr } %t247, 0
  %t253 = add i64 %t249, %t252
  %t254 = extractvalue { i64, ptr } { i64 30, ptr @.d54 }, 1
  %t255 = extractvalue { i64, ptr } { i64 30, ptr @.d54 }, 0
  %t256 = add i64 %t253, %t255
  %t257 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t256)
  call void @olang_textcopy(ptr %t257, ptr %t248, i64 %t249)
  %t258 = getelementptr i8, ptr %t257, i64 %t249
  call void @olang_textcopy(ptr %t258, ptr %t251, i64 %t252)
  %t259 = getelementptr i8, ptr %t258, i64 %t252
  call void @olang_textcopy(ptr %t259, ptr %t254, i64 %t255)
  %t260 = insertvalue { i64, ptr } undef, i64 %t256, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t257, 1
  %t263 = extractvalue { i64, ptr } %t261, 0
  %t264 = extractvalue { i64, ptr } %t261, 1
  %t265 = mul i64 %t263, 1
  %t266 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t265)
  call void @llvm.memcpy.p0.p0.i64(ptr %t266, ptr %t264, i64 %t265, i1 false)
  %t267 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t266, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t246, { i64, ptr } %t268)
  br label %bb21
bb21:
  store { i64, ptr } { i64 4, ptr @.d55 }, ptr %l83, !tbaa !27
  %t271 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t271, ptr %l84, !tbaa !27
  %t272 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t273 = extractvalue { i64, ptr } %t272, 0
  store i64 %t273, ptr %l85, !tbaa !24
  %t274 = load i64, ptr %l85, !tbaa !24
  %t275 = mul i64 %t274, 1
  %t276 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t275)
  %t277 = insertvalue { i64, ptr } undef, i64 %t274, 0
  %t278 = insertvalue { i64, ptr } %t277, ptr %t276, 1
  store { i64, ptr } %t278, ptr %l86, !tbaa !27
  %t279 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t280 = load ptr, ptr %t279, !tbaa !27
  %t281 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !27
  %t283 = load i64, ptr %l85, !tbaa !24
  %t284 = mul i64 %t283, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t280, ptr %t282, i64 %t284, i1 false)
  %t285 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t285, ptr %l84, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t286 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t286, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eretires(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i32
  %l25 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 5
  store ptr %t9, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t12 = load i64, ptr %l3, !tbaa !24
  %t15 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H8fdab0f9e4aba8682af3c4e1d27c3999(ptr %v0, ptr %t11, i64 %t12)
  %t16 = extractvalue { i32, { i64, ptr } } %t15, 1
  %t17 = extractvalue { i32, { i64, ptr } } %t15, 0
  store i32 %t17, ptr %l16
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb3, label %ok.19
ok.19:
  store { i64, ptr } %t16, ptr %l15
  br label %bb2
bb2:
  %t20 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t20, ptr %l12, !tbaa !27
  br label %bb7
bb3:
  %t21 = load i32, ptr %l16, !tbaa !23
  %t22 = ashr i32 %t21, 16
  %t24 = icmp eq i32 %t22, 1
  br i1 %t24, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_6092aa485d103db2_ba7372f362365566)
  unreachable
bb6:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb7:
  %t26 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t26, ptr %l4, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  store i64 %t29, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t31 = load i64, ptr %l6, !tbaa !24
  %t32 = load i64, ptr %l5, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb10:
  br label %bb11
bb11:
  %t39 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t39, ptr %l25, !tbaa !27
  %t40 = load i64, ptr %l6, !tbaa !24
  %t42 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr ptr, ptr %t43, i64 %t40
  %t45 = load ptr, ptr %t44, !tbaa !39
  store ptr %t45, ptr %l7, !tbaa !29
  %t47 = load ptr, ptr %l7, !tbaa !29
  %t49 = getelementptr %"compiler/load:Module", ptr %t47, i32 0, i32 4
  %t50 = load i64, ptr %t49, !tbaa !24
  %t54 = icmp eq i64 %t50, %a1
  br i1 %t54, label %bb12, label %bb13
bb12:
  %t56 = load ptr, ptr %l7, !tbaa !29
  %t58 = getelementptr %"compiler/load:Module", ptr %t56, i32 0, i32 5
  %t59 = load i1, ptr %t58, !tbaa !21
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  store i1 %t59, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  %t61 = load i64, ptr %l6, !tbaa !24
  %t63 = add i64 %t61, 1
  store i64 %t63, ptr %l6, !tbaa !24
  br label %bb8
bb16:
  %t65 = load i64, ptr %l3, !tbaa !24
  %t66 = load i64, ptr %l5, !tbaa !24
  %t69 = add i64 %t65, %t66
  store i64 %t69, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  br label %bb1
bb18:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntimeItems(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/text:LineIter"
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i32
  %l21 = alloca %"std/prelude/text:StringBuilder"
  %l22 = alloca %"std/prelude/text:StringBuilder"
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l30 = alloca %"std/prelude/text:LineIter"
  %l31 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i32
  %l38 = alloca i1
  %l44 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l49 = alloca { i64, ptr }
  %l50 = alloca %"std/prelude/text:StringBuilder"
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l54 = alloca i64
  %l56 = alloca i64
  %l57 = alloca { i64, ptr }
  %l59 = alloca i1
  %l64 = alloca { i64, ptr }
  %l66 = alloca i1
  %l68 = alloca i1
  %l69 = alloca { i64, ptr }
  %l71 = alloca i64
  %l73 = alloca i64
  %l74 = alloca { i64, ptr }
  %l85 = alloca ptr
  %l87 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 49
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/emit:Emitter", ptr %t6, i32 0, i32 49
  store i1 true, ptr %t8, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/emit:Emitter", ptr %t9, i32 0, i32 45
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/emit:Emitter", ptr %t13, i32 0, i32 46
  %t16 = load i1, ptr %t15, !tbaa !21
  %t19 = call { i32, { i64, ptr } } @compiler_2fruntime_2eText(ptr %v0, ptr %s0, { i64, ptr } %t12, i1 %t16, i1 false)
  %t20 = extractvalue { i32, { i64, ptr } } %t19, 1
  %t21 = extractvalue { i32, { i64, ptr } } %t19, 0
  store i32 %t21, ptr %l17
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb5, label %ok.23
ok.23:
  store { i64, ptr } %t20, ptr %l16
  br label %bb4
bb4:
  %t24 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t24, ptr %l11, !tbaa !27
  br label %bb10
bb5:
  %t25 = load i32, ptr %l17, !tbaa !23
  %t26 = ashr i32 %t25, 16
  %t28 = icmp eq i32 %t26, 1
  br i1 %t28, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_49795d8549fab862_b41831e08981cb6)
  unreachable
bb8:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s2
  %t30 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2egap(ptr %v0, ptr %s2, ptr %t30, { i64, ptr } { i64 66, ptr @.d56 })
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb10:
  %t32 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t32, ptr %l1, !tbaa !27
  %t33 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t33, ptr %l21
  br label %bb11
bb11:
  %t34 = load %"std/prelude/text:StringBuilder", ptr %l21
  store %"std/prelude/text:StringBuilder" %t34, ptr %l2
  %t35 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t35, ptr %l22
  br label %bb12
bb12:
  %t36 = load %"std/prelude/text:StringBuilder", ptr %l22
  store %"std/prelude/text:StringBuilder" %t36, ptr %l3
  store { i64, ptr } { i64 0, ptr @.d57 }, ptr %l23, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t37, ptr %l24, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l25, !tbaa !24
  %t40 = load i64, ptr %l25, !tbaa !24
  %t41 = mul i64 %t40, 1
  %t42 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t41)
  %t43 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  store { i64, ptr } %t44, ptr %l26, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = load i64, ptr %l25, !tbaa !24
  %t50 = mul i64 %t49, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t46, ptr %t48, i64 %t50, i1 false)
  %t51 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t51, ptr %l4, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s3
  %t52 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t54 = call { i64, ptr } @compiler_2fruntime_2eDecls(ptr %s0, ptr %s3, { i64, ptr } %t52)
  store { i64, ptr } %t54, ptr %l28
  br label %bb13
bb13:
  %t55 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  %t57 = extractvalue { i64, ptr } %t55, 1
  %t58 = mul i64 %t56, 1
  %t59 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t58)
  call void @llvm.memcpy.p0.p0.i64(ptr %t59, ptr %t57, i64 %t58, i1 false)
  %t60 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  %t63 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %s3, ptr %s3, { i64, ptr } %t61)
  store %"std/prelude/text:LineIter" %t63, ptr %l30
  br label %bb14
bb14:
  %t64 = load %"std/prelude/text:LineIter", ptr %l30
  store %"std/prelude/text:LineIter" %t64, ptr %l5
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t66 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %s3, ptr %l5)
  %t67 = extractvalue { i32, { i64, ptr } } %t66, 1
  %t68 = extractvalue { i32, { i64, ptr } } %t66, 0
  store i32 %t68, ptr %l34
  %t69 = icmp ne i32 %t68, 0
  br i1 %t69, label %bb17, label %ok.70
ok.70:
  store { i64, ptr } %t67, ptr %l33
  br label %bb16
bb16:
  %t71 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t71, ptr %l31, !tbaa !27
  br label %bb21
bb17:
  %t72 = load i32, ptr %l34, !tbaa !23
  %t73 = ashr i32 %t72, 16
  %t75 = icmp eq i32 %t73, 1
  br i1 %t75, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_e59d8160838b9663_ee3833e61d72b057)
  unreachable
bb20:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s4)
  br label %bb60
bb21:
  %t77 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t77, ptr %l6, !tbaa !27
  %t78 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t80 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s4, { i64, ptr } %t78, { i64, ptr } { i64 0, ptr @.d58 })
  store i1 %t80, ptr %l38
  br label %bb22
bb22:
  %t81 = load i1, ptr %l38, !tbaa !21
  %t82 = xor i1 %t81, true
  br i1 %t82, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s5
  %t84 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l3, { i64, ptr } %t84)
  br label %bb25
bb24:
  br label %bb37
bb25:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l3, i8 10)
  br label %bb26
bb26:
  %t88 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t90 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s3, ptr %s5, { i64, ptr } %t88, { i64, ptr } { i64 1, ptr @.d59 })
  store i1 %t90, ptr %l44
  br label %bb27
bb27:
  %t91 = load i1, ptr %l44, !tbaa !21
  br i1 %t91, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s6
  %t92 = load ptr, ptr %l0, !tbaa !29
  store ptr %t92, ptr %l45, !tbaa !29
  %t93 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t93, ptr %l46, !tbaa !27
  %t94 = load i64, ptr @G_2ecompiler_2femit_2eHomeShared, !tbaa !24
  store i64 %t94, ptr %l47, !tbaa !24
  %t96 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s6, ptr %l3)
  store { i64, ptr } %t96, ptr %l49
  br label %bb30
bb29:
  br label %bb36
bb30:
  %t97 = load ptr, ptr %l45, !tbaa !29
  %t98 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t99 = load i64, ptr %l47, !tbaa !24
  %t100 = load { i64, ptr }, ptr %l49, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s0, ptr %s6, ptr %s6, ptr %t97, { i64, ptr } %t98, i64 %t99, { i64, ptr } %t100, { i64, ptr } { i64 0, ptr @.d21 })
  br label %bb31
bb31:
  %t101 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t101, ptr %l50
  br label %bb32
bb32:
  %t102 = load %"std/prelude/text:StringBuilder", ptr %l50
  store %"std/prelude/text:StringBuilder" %t102, ptr %l3
  store { i64, ptr } { i64 0, ptr @.d60 }, ptr %l51, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t103, ptr %l52, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  %t106 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t106, 0
  store i64 %t107, ptr %l54, !tbaa !24
  %t109 = load i64, ptr %l54, !tbaa !24
  %t110 = icmp eq i64 %t105, %t109
  br i1 %t110, label %bb33, label %bb34
bb33:
  %t112 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = load i64, ptr %l54, !tbaa !24
  %t117 = mul i64 %t116, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t113, ptr %t115, i64 %t117, i1 false)
  br label %bb35
bb34:
  %t118 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t118, 0
  store i64 %t119, ptr %l56, !tbaa !24
  %t120 = load i64, ptr %l56, !tbaa !24
  %t121 = mul i64 %t120, 1
  %t122 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t121)
  %t123 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  store { i64, ptr } %t124, ptr %l57, !tbaa !27
  %t125 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = load i64, ptr %l56, !tbaa !24
  %t130 = mul i64 %t129, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t126, ptr %t128, i64 %t130, i1 false)
  %t131 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t131, ptr %l4, !tbaa !27
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s6)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  br label %bb59
bb37:
  %t132 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t134 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s3, ptr %s4, { i64, ptr } %t132, { i64, ptr } { i64 1, ptr @.d61 })
  store i1 %t134, ptr %l59
  br label %bb38
bb38:
  %t135 = load i1, ptr %l59, !tbaa !21
  br i1 %t135, label %bb39, label %bb40
bb39:
  %t136 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l2, { i64, ptr } %t136)
  br label %bb41
bb40:
  br label %bb43
bb41:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 10)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s4)
  br label %bb59
bb43:
  %t140 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t142 = call { i64, ptr } @compiler_2femit_2edeclaredSymbol(ptr %s3, ptr %s4, { i64, ptr } %t140)
  store { i64, ptr } %t142, ptr %l64
  br label %bb44
bb44:
  %t143 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t143, ptr %l7, !tbaa !27
  %t144 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t146 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s4, ptr %s4, { i64, ptr } %t144, { i64, ptr } { i64 0, ptr @.d62 })
  store i1 %t146, ptr %l66
  br label %bb45
bb45:
  %t147 = load i1, ptr %l66, !tbaa !21
  br i1 %t147, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s4)
  br label %bb59
bb47:
  br label %bb48
bb48:
  %t148 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t150 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s3, ptr %s4, { i64, ptr } %t148, { i64, ptr } { i64 7, ptr @.d63 })
  store i1 %t150, ptr %l68
  br label %bb49
bb49:
  %t151 = load i1, ptr %l68, !tbaa !21
  br i1 %t151, label %bb50, label %bb51
bb50:
  %t152 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t152, ptr %l69, !tbaa !27
  %t153 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t154 = extractvalue { i64, ptr } %t153, 0
  %t155 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t155, 0
  store i64 %t156, ptr %l71, !tbaa !24
  %t158 = load i64, ptr %l71, !tbaa !24
  %t159 = icmp eq i64 %t154, %t158
  br i1 %t159, label %bb52, label %bb53
bb51:
  store %olang.scope zeroinitializer, ptr %s10
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t163 = load i64, ptr @G_2ecompiler_2femit_2eHomeShared, !tbaa !24
  %t164 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t166 = extractvalue { i64, ptr } %t164, 1
  %t167 = extractvalue { i64, ptr } %t164, 0
  %t168 = extractvalue { i64, ptr } { i64 1, ptr @.d64 }, 1
  %t169 = extractvalue { i64, ptr } { i64 1, ptr @.d64 }, 0
  %t170 = add i64 %t167, %t169
  %t171 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t170)
  call void @olang_textcopy(ptr %t171, ptr %t166, i64 %t167)
  %t172 = getelementptr i8, ptr %t171, i64 %t167
  call void @olang_textcopy(ptr %t172, ptr %t168, i64 %t169)
  %t173 = insertvalue { i64, ptr } undef, i64 %t170, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t171, 1
  %t176 = extractvalue { i64, ptr } %t174, 0
  %t177 = extractvalue { i64, ptr } %t174, 1
  %t178 = mul i64 %t176, 1
  %t179 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t178)
  call void @llvm.memcpy.p0.p0.i64(ptr %t179, ptr %t177, i64 %t178, i1 false)
  %t180 = insertvalue { i64, ptr } undef, i64 %t176, 0
  %t181 = insertvalue { i64, ptr } %t180, ptr %t179, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s4, ptr %s10, ptr %s10, ptr %t161, { i64, ptr } %t162, i64 %t163, { i64, ptr } %t181, { i64, ptr } { i64 0, ptr @.d65 })
  br label %bb57
bb52:
  %t186 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !27
  %t188 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = load i64, ptr %l71, !tbaa !24
  %t191 = mul i64 %t190, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t187, ptr %t189, i64 %t191, i1 false)
  br label %bb54
bb53:
  %t192 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t192, 0
  store i64 %t193, ptr %l73, !tbaa !24
  %t194 = load i64, ptr %l73, !tbaa !24
  %t195 = mul i64 %t194, 1
  %t196 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t195)
  %t197 = insertvalue { i64, ptr } undef, i64 %t194, 0
  %t198 = insertvalue { i64, ptr } %t197, ptr %t196, 1
  store { i64, ptr } %t198, ptr %l74, !tbaa !27
  %t199 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !27
  %t201 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !27
  %t203 = load i64, ptr %l73, !tbaa !24
  %t204 = mul i64 %t203, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t200, ptr %t202, i64 %t204, i1 false)
  %t205 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t205, ptr %l4, !tbaa !27
  br label %bb54
bb54:
  %t206 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l3, { i64, ptr } %t206)
  br label %bb55
bb55:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l3, i8 10)
  br label %bb56
bb56:
  br label %bb58
bb57:
  call void @__olang_scope_close(ptr %s10)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s4)
  br label %bb59
bb59:
  br label %bb15
bb60:
  call void @__olang_scope_close(ptr %s3)
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 50, ptr @.d66 })
  br label %bb61
bb61:
  %t211 = load ptr, ptr %l0, !tbaa !29
  store ptr %t211, ptr %l85, !tbaa !29
  %t213 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v0, ptr %l2)
  store { i64, ptr } %t213, ptr %l87
  br label %bb62
bb62:
  %t214 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t215 = load ptr, ptr %l85, !tbaa !29
  %t216 = getelementptr %"compiler/emit:Emitter", ptr %t215, i32 0, i32 48
  store { i64, ptr } %t214, ptr %t216, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2etraced(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 4
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/emit:Emitter", ptr %t6, i32 0, i32 5
  %t9 = load i1, ptr %t8, !tbaa !21
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l20 = alloca i1
  %l23 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 3, ptr @.d67 }, ptr %l5, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t7, ptr %l6, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l7, !tbaa !24
  %t10 = load i64, ptr %l7, !tbaa !24
  %t11 = mul i64 %t10, 1
  %t12 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l8, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l7, !tbaa !24
  %t20 = mul i64 %t19, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %t18, i64 %t20, i1 false)
  %t21 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t21, ptr %l6, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t22, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t23 = load i32, ptr %l1, !tbaa !23
  %t24 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t27 = icmp eq i32 %t23, %t24
  br i1 %t27, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t29 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2egap(ptr %v0, ptr %s2, ptr %t29, { i64, ptr } { i64 15, ptr @.d68 })
  br label %bb6
bb5:
  br label %bb7
bb6:
  store { i64, ptr } { i64 2, ptr @.d69 }, ptr %l13, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t31, ptr %l14, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 0
  store i64 %t33, ptr %l15, !tbaa !24
  %t34 = load i64, ptr %l15, !tbaa !24
  %t35 = mul i64 %t34, 1
  %t36 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t35)
  %t37 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  store { i64, ptr } %t38, ptr %l16, !tbaa !27
  %t39 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = load i64, ptr %l15, !tbaa !24
  %t44 = mul i64 %t43, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t40, ptr %t42, i64 %t44, i1 false)
  %t45 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t45, ptr %l14, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  %t46 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t46, ptr %rv
  br label %ret
bb7:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/emit:Emitter", ptr %t47, i32 0, i32 0
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t51 = load i32, ptr %l1, !tbaa !23
  %t54 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t50, i32 %t51)
  store i1 %t54, ptr %l20
  br label %bb8
bb8:
  %t55 = load i1, ptr %l20, !tbaa !21
  %t56 = xor i1 %t55, true
  br i1 %t56, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/emit:Emitter", ptr %t58, i32 0, i32 23
  store i1 true, ptr %t60, !tbaa !21
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l23, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/emit:Emitter", ptr %t62, i32 0, i32 3
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t66 = load i32, ptr %l1, !tbaa !23
  %t69 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s3, ptr %t65, i32 %t66)
  store { i64, ptr } %t69, ptr %l27
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t70 = extractvalue { i64, ptr } { i64 23, ptr @.d70 }, 1
  %t71 = extractvalue { i64, ptr } { i64 23, ptr @.d70 }, 0
  %t72 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 1
  %t74 = extractvalue { i64, ptr } %t72, 0
  %t75 = add i64 %t71, %t74
  %t76 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t75)
  call void @olang_textcopy(ptr %t76, ptr %t70, i64 %t71)
  %t77 = getelementptr i8, ptr %t76, i64 %t71
  call void @olang_textcopy(ptr %t77, ptr %t73, i64 %t74)
  %t78 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t76, 1
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t82 = extractvalue { i64, ptr } %t79, 1
  %t83 = mul i64 %t81, 1
  %t84 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t83)
  call void @llvm.memcpy.p0.p0.i64(ptr %t84, ptr %t82, i64 %t83, i1 false)
  %t85 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  %t87 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2egap(ptr %v0, ptr %s3, ptr %t87, { i64, ptr } %t86)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb13:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eneed(ptr %v0, ptr %t89, i32 %t90)
  br label %bb14
bb14:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/emit:Emitter", ptr %t93, i32 0, i32 3
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t97 = load i32, ptr %l1, !tbaa !23
  %t100 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %t96, i32 %t97)
  store { i64, ptr } %t100, ptr %l35
  br label %bb15
bb15:
  %t101 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 1
  %t103 = extractvalue { i64, ptr } %t101, 0
  %t104 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t103)
  call void @olang_textcopy(ptr %t104, ptr %t102, i64 %t103)
  %t105 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  store { i64, ptr } %t106, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2evisit(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/load:Import"
  %l12 = alloca i1
  %l20 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i32
  %l36 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v1, ptr %t1, i64 %t2)
  store i1 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i1, ptr %l12, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t8 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v1, ptr %t7, i64 %t8, i1 true)
  br label %bb5
bb5:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/emit:Emitter", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/load:Loader", ptr %t17, i32 0, i32 5
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t19, i64 %t20)
  store ptr %t23, ptr %l20
  br label %bb6
bb6:
  %t24 = load ptr, ptr %l20, !tbaa !29
  %t26 = getelementptr %"compiler/load:Module", ptr %t24, i32 0, i32 11
  store ptr %t26, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t28 = load ptr, ptr %l4, !tbaa !29
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eRunFrom_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t28, i64 %t29)
  %t33 = extractvalue { i32, { i64, ptr } } %t32, 1
  %t34 = extractvalue { i32, { i64, ptr } } %t32, 0
  store i32 %t34, ptr %l27
  %t35 = icmp ne i32 %t34, 0
  br i1 %t35, label %bb9, label %ok.36
ok.36:
  store { i64, ptr } %t33, ptr %l26
  br label %bb8
bb8:
  %t37 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t37, ptr %l23, !tbaa !27
  br label %bb13
bb9:
  %t38 = load i32, ptr %l27, !tbaa !23
  %t39 = ashr i32 %t38, 16
  %t41 = icmp eq i32 %t39, 1
  br i1 %t41, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_cd6d5a2ace167e0b_158f6ef781c59597)
  unreachable
bb12:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb13:
  %t43 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t43, ptr %l6, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  store i64 %t46, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t48 = load i64, ptr %l8, !tbaa !24
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb16:
  br label %bb17
bb17:
  %t56 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t56, ptr %l36, !tbaa !27
  %t57 = load i64, ptr %l8, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr %"compiler/load:Import", ptr %t60, i64 %t57
  %t62 = load %"compiler/load:Import", ptr %t61
  store %"compiler/load:Import" %t62, ptr %l9
  %t64 = getelementptr %"compiler/load:Import", ptr %l9, i32 0, i32 5
  %t65 = load i64, ptr %t64, !tbaa !24
  %t67 = icmp sge i64 %t65, 0
  br i1 %t67, label %bb18, label %bb19
bb18:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/load:Import", ptr %l9, i32 0, i32 5
  %t71 = load i64, ptr %t70, !tbaa !24
  %t72 = load ptr, ptr %l2, !tbaa !29
  %t73 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2evisit(ptr %v0, ptr %v1, ptr %v2, ptr %t69, i64 %t71, ptr %t72, ptr %t73)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb22:
  %t78 = load i64, ptr %l8, !tbaa !24
  %t80 = add i64 %t78, 1
  store i64 %t80, ptr %l8, !tbaa !24
  br label %bb14
bb23:
  %t82 = load i64, ptr %l5, !tbaa !24
  %t83 = load i64, ptr %l7, !tbaa !24
  %t86 = add i64 %t82, %t83
  store i64 %t86, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb24:
  br label %bb7
bb25:
  %t88 = load ptr, ptr %l3, !tbaa !29
  %t89 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t88, i64 %t89)
  br label %bb26
bb26:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ebf16Bits(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %lp3 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = extractvalue { i64, ptr } { i64 15, ptr @.d71 }, 1
  %t4 = extractvalue { i64, ptr } { i64 15, ptr @.d71 }, 0
  %t6 = extractvalue { i64, ptr } %a1, 1
  %t7 = extractvalue { i64, ptr } %a1, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 7, ptr @.d72 }, 1
  %t10 = extractvalue { i64, ptr } { i64 7, ptr @.d72 }, 0
  %t11 = add i64 %t8, %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t11)
  call void @olang_textcopy(ptr %t12, ptr %t3, i64 %t4)
  %t13 = getelementptr i8, ptr %t12, i64 %t4
  call void @olang_textcopy(ptr %t13, ptr %t6, i64 %t7)
  %t14 = getelementptr i8, ptr %t13, i64 %t7
  call void @olang_textcopy(ptr %t14, ptr %t9, i64 %t10)
  %t15 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t12, 1
  %t18 = extractvalue { i64, ptr } %t16, 0
  %t19 = extractvalue { i64, ptr } %t16, 1
  %t20 = mul i64 %t18, 1
  %t21 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t20)
  call void @llvm.memcpy.p0.p0.i64(ptr %t21, ptr %t19, i64 %t20, i1 false)
  %t22 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  %t26 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v2, ptr %v2, ptr %t1, { i64, ptr } %t23)
  store { i64, ptr } %t26, ptr %l8
  br label %bb1
bb1:
  %t27 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t27, ptr %lp3
  %t28 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t29 = load ptr, ptr %lp3
  store { i64, ptr } %t28, ptr %t29, !tbaa !27
  br i1 %a2, label %bb2, label %bb3
bb2:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load ptr, ptr %lp3
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  %t37 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eopaque16(ptr %v0, ptr %v2, ptr %v2, ptr %t32, { i64, ptr } %t34)
  store { i64, ptr } %t37, ptr %l13
  br label %bb4
bb3:
  %t38 = load ptr, ptr %lp3
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  store { i64, ptr } %t39, ptr %l10, !tbaa !27
  br label %bb5
bb4:
  %t41 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t41, ptr %l10, !tbaa !27
  br label %bb5
bb5:
  %t42 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t42, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2econstText(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca { i64, [1 x i64] }
  %l4 = alloca %"compiler/mir:Range"
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l11 = alloca %"std/prelude/text:StringBuilder"
  %l17 = alloca { i64, [1 x i64] }
  %l25 = alloca i32
  %l28 = alloca i32
  %l46 = alloca ptr
  %l55 = alloca i8
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca i64
  %l63 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l11
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/emit:fnEm", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = getelementptr %"compiler/mir:Fn", ptr %t6, i32 0, i32 19
  %t11 = sext i32 %a1 to i64
  %t14 = call { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aConstNode_3e_2eAt_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %t8, i64 %t11)
  store { i64, [1 x i64] } %t14, ptr %l17
  br label %bb2
bb2:
  %t15 = load { i64, [1 x i64] }, ptr %l17
  store { i64, [1 x i64] } %t15, ptr %l3
  %t16 = load { i64, [1 x i64] }, ptr %l3
  %t18 = extractvalue { i64, [1 x i64] } %t16, 0
  %t19 = icmp eq i64 %t18, 1
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = getelementptr { i64, [1 x i64] }, ptr %l3, i32 0, i32 1
  %t22 = getelementptr { %"compiler/mir:Range" }, ptr %t21, i32 0, i32 0
  %t23 = load %"compiler/mir:Range", ptr %t22
  store %"compiler/mir:Range" %t23, ptr %l4
  br label %bb5
bb4:
  br label %bb20
bb5:
  store i32 0, ptr %l5, !tbaa !23
  %t25 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 1
  %t26 = load i32, ptr %t25, !tbaa !23
  store i32 %t26, ptr %l6, !tbaa !23
  store i32 1, ptr %l7, !tbaa !23
  %t28 = load i32, ptr %l6, !tbaa !23
  %t29 = load i32, ptr %l5, !tbaa !23
  %t32 = icmp sgt i32 %t28, %t29
  br i1 %t32, label %bb6, label %bb7
bb6:
  %t34 = load i32, ptr %l7, !tbaa !23
  %t36 = icmp sgt i32 %t34, 0
  br i1 %t36, label %bb8, label %bb9
bb7:
  store i32 0, ptr %l25, !tbaa !23
  br label %bb11
bb8:
  %t38 = load i32, ptr %l6, !tbaa !23
  %t39 = load i32, ptr %l5, !tbaa !23
  %t42 = sub i32 %t38, %t39
  %t43 = load i32, ptr %l7, !tbaa !23
  %t46 = add i32 %t42, %t43
  %t48 = sub i32 %t46, 1
  %t49 = load i32, ptr %l7, !tbaa !23
  %t52 = sdiv i32 %t48, %t49
  store i32 %t52, ptr %l28, !tbaa !23
  br label %bb10
bb9:
  store i32 0, ptr %l28, !tbaa !23
  br label %bb10
bb10:
  %t54 = load i32, ptr %l28, !tbaa !23
  store i32 %t54, ptr %l25, !tbaa !23
  br label %bb11
bb11:
  %t55 = load i32, ptr %l25, !tbaa !23
  store i32 %t55, ptr %l8, !tbaa !23
  store i32 0, ptr %l9, !tbaa !23
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t56 = load i32, ptr %l9, !tbaa !23
  %t57 = load i32, ptr %l8, !tbaa !23
  %t60 = icmp slt i32 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb14:
  br label %bb15
bb15:
  %t64 = load i32, ptr %l5, !tbaa !23
  %t65 = load i32, ptr %l9, !tbaa !23
  %t66 = load i32, ptr %l7, !tbaa !23
  %t69 = mul i32 %t65, %t66
  %t72 = add i32 %t64, %t69
  store ptr %l2, ptr %l46, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/emit:fnEm", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/mir:Fn", ptr %t77, i32 0, i32 21
  %t80 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 0
  %t81 = load i32, ptr %t80, !tbaa !23
  %t83 = sext i32 %t81 to i64
  %t86 = sext i32 %t72 to i64
  %t89 = add i64 %t83, %t86
  %t92 = call i8 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cU8_3e_2eAt_3cU8_3e(ptr %v0, ptr %t79, i64 %t89)
  store i8 %t92, ptr %l55
  br label %bb16
bb16:
  %t93 = load i8, ptr %l55, !tbaa !22
  %t94 = load ptr, ptr %l46, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t94, i8 %t93)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb18:
  %t96 = load i32, ptr %l9, !tbaa !23
  %t98 = add i32 %t96, 1
  store i32 %t98, ptr %l9, !tbaa !23
  br label %bb12
bb19:
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_a00373ca27d5619a_9315010cb9ead296)
  unreachable
bb25:
  %t101 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t101, ptr %l60
  br label %bb26
bb26:
  %t102 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t102, ptr %l61, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 0
  store i64 %t104, ptr %l62, !tbaa !24
  %t105 = load i64, ptr %l62, !tbaa !24
  %t106 = mul i64 %t105, 1
  %t107 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t106)
  %t108 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t107, 1
  store { i64, ptr } %t109, ptr %l63, !tbaa !27
  %t110 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = load i64, ptr %l62, !tbaa !24
  %t115 = mul i64 %t114, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t111, ptr %t113, i64 %t115, i1 false)
  %t116 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t116, ptr %l61, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t117 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t117, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edbgEntry(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 17
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp slt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 0, ptr @.d73 }, ptr %l4, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t8, ptr %l5, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l6, !tbaa !24
  %t11 = load i64, ptr %l6, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l7, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l6, !tbaa !24
  %t21 = mul i64 %t20, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  %t22 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t22, ptr %l5, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t23, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l8, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/emit:fnEm", ptr %t25, i32 0, i32 0
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/emit:Emitter", ptr %t28, i32 0, i32 2
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/emit:fnEm", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/mir:Fn", ptr %t35, i32 0, i32 2
  %t38 = load i64, ptr %t37, !tbaa !24
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/emit:fnEm", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/mir:Fn", ptr %t42, i32 0, i32 3
  %t45 = getelementptr %"compiler/source:Span", ptr %t44, i32 0, i32 0
  %t46 = load i32, ptr %t45, !tbaa !23
  %t48 = sext i32 %t46 to i64
  %t52 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %t31, i64 %t38, i64 %t48)
  store i64 %t52, ptr %l19
  br label %bb4
bb4:
  %t53 = load ptr, ptr %l8, !tbaa !29
  %t54 = load i64, ptr %l19, !tbaa !24
  %t55 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edbgLine(ptr %v0, ptr %v1, ptr %t53, i64 %t54)
  store { i64, ptr } %t55, ptr %l20
  br label %bb5
bb5:
  %t56 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t56, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2ederefs(ptr %v0, ptr %a0, %"compiler/mir:Place" %a1) #0 {
entry:
  %l1 = alloca %"compiler/mir:Place"
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l13 = alloca i32
  %l16 = alloca i32
  %l42 = alloca { i64, [1 x i64] }
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store %"compiler/mir:Place" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr %l2, !tbaa !23
  %t1 = getelementptr %"compiler/mir:Place", ptr %l1, i32 0, i32 1
  %t2 = getelementptr %"compiler/mir:Range", ptr %t1, i32 0, i32 1
  %t3 = load i32, ptr %t2, !tbaa !23
  store i32 %t3, ptr %l3, !tbaa !23
  store i32 1, ptr %l4, !tbaa !23
  %t5 = load i32, ptr %l3, !tbaa !23
  %t6 = load i32, ptr %l2, !tbaa !23
  %t9 = icmp sgt i32 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i32, ptr %l4, !tbaa !23
  %t13 = icmp sgt i32 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i32 0, ptr %l13, !tbaa !23
  br label %bb6
bb3:
  %t15 = load i32, ptr %l3, !tbaa !23
  %t16 = load i32, ptr %l2, !tbaa !23
  %t19 = sub i32 %t15, %t16
  %t20 = load i32, ptr %l4, !tbaa !23
  %t23 = add i32 %t19, %t20
  %t25 = sub i32 %t23, 1
  %t26 = load i32, ptr %l4, !tbaa !23
  %t29 = sdiv i32 %t25, %t26
  store i32 %t29, ptr %l16, !tbaa !23
  br label %bb5
bb4:
  store i32 0, ptr %l16, !tbaa !23
  br label %bb5
bb5:
  %t31 = load i32, ptr %l16, !tbaa !23
  store i32 %t31, ptr %l13, !tbaa !23
  br label %bb6
bb6:
  %t32 = load i32, ptr %l13, !tbaa !23
  store i32 %t32, ptr %l5, !tbaa !23
  store i32 0, ptr %l6, !tbaa !23
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i32, ptr %l6, !tbaa !23
  %t34 = load i32, ptr %l5, !tbaa !23
  %t37 = icmp slt i32 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb9:
  br label %bb10
bb10:
  %t41 = load i32, ptr %l2, !tbaa !23
  %t42 = load i32, ptr %l6, !tbaa !23
  %t43 = load i32, ptr %l4, !tbaa !23
  %t46 = mul i32 %t42, %t43
  %t49 = add i32 %t41, %t46
  %t53 = getelementptr %"compiler/emit:fnEm", ptr %a0, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/mir:Fn", ptr %t54, i32 0, i32 10
  %t57 = getelementptr %"compiler/mir:Place", ptr %l1, i32 0, i32 1
  %t58 = getelementptr %"compiler/mir:Range", ptr %t57, i32 0, i32 0
  %t59 = load i32, ptr %t58, !tbaa !23
  %t61 = sext i32 %t59 to i64
  %t64 = sext i32 %t49 to i64
  %t67 = add i64 %t61, %t64
  %t70 = call { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %t56, i64 %t67)
  store { i64, [1 x i64] } %t70, ptr %l42
  br label %bb11
bb11:
  %t71 = load { i64, [1 x i64] }, ptr %l42
  %t74 = extractvalue { i64, [1 x i64] } %t71, 0
  %t75 = icmp eq i64 %t74, 3
  br i1 %t75, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_e9e71ccb75095175_3df52a9a91674c89)
  unreachable
bb20:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb21:
  %t78 = load i32, ptr %l6, !tbaa !23
  %t80 = add i32 %t78, 1
  store i32 %t80, ptr %l6, !tbaa !23
  br label %bb7
bb22:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eexternArg(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i32
  %l6 = alloca { { i64, ptr }, { i64, ptr } }
  %l13 = alloca i32
  %l16 = alloca i32
  %l23 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l32 = alloca i1
  %l33 = alloca i32
  %l36 = alloca i32
  %l40 = alloca i32
  %l46 = alloca { { i64, ptr }, { i64, ptr } }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t10 = load i32, ptr %l2, !tbaa !23
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t9, i32 %t10)
  store i32 %t13, ptr %l13
  br label %bb1
bb1:
  %t14 = load i32, ptr %l13, !tbaa !23
  store i32 %t14, ptr %l4, !tbaa !23
  %t15 = load ptr, ptr %l3, !tbaa !29
  %t16 = load i32, ptr %l4, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t19, ptr %l16
  br label %bb2
bb2:
  %t20 = load i32, ptr %l16
  %t22 = trunc i64 21 to i32
  %t23 = icmp eq i32 %t20, %t22
  br i1 %t23, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t27 = extractvalue { i64, ptr } { i64 26, ptr @.d74 }, 1
  %t28 = extractvalue { i64, ptr } { i64 26, ptr @.d74 }, 0
  %t30 = extractvalue { i64, ptr } %t26, 1
  %t31 = extractvalue { i64, ptr } %t26, 0
  %t32 = add i64 %t28, %t31
  %t33 = extractvalue { i64, ptr } { i64 3, ptr @.d75 }, 1
  %t34 = extractvalue { i64, ptr } { i64 3, ptr @.d75 }, 0
  %t35 = add i64 %t32, %t34
  %t36 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t35)
  call void @olang_textcopy(ptr %t36, ptr %t27, i64 %t28)
  %t37 = getelementptr i8, ptr %t36, i64 %t28
  call void @olang_textcopy(ptr %t37, ptr %t30, i64 %t31)
  %t38 = getelementptr i8, ptr %t37, i64 %t31
  call void @olang_textcopy(ptr %t38, ptr %t33, i64 %t34)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t36, 1
  %t42 = extractvalue { i64, ptr } %t40, 0
  %t43 = extractvalue { i64, ptr } %t40, 1
  %t44 = mul i64 %t42, 1
  %t45 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t44)
  call void @llvm.memcpy.p0.p0.i64(ptr %t45, ptr %t43, i64 %t44, i1 false)
  %t46 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  %t50 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s1, ptr %s1, ptr %t25, { i64, ptr } %t47)
  store { i64, ptr } %t50, ptr %l23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t53 = extractvalue { i64, ptr } { i64 26, ptr @.d76 }, 1
  %t54 = extractvalue { i64, ptr } { i64 26, ptr @.d76 }, 0
  %t56 = extractvalue { i64, ptr } %t52, 1
  %t57 = extractvalue { i64, ptr } %t52, 0
  %t58 = add i64 %t54, %t57
  %t59 = extractvalue { i64, ptr } { i64 3, ptr @.d77 }, 1
  %t60 = extractvalue { i64, ptr } { i64 3, ptr @.d77 }, 0
  %t61 = add i64 %t58, %t60
  %t62 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t61)
  call void @olang_textcopy(ptr %t62, ptr %t53, i64 %t54)
  %t63 = getelementptr i8, ptr %t62, i64 %t54
  call void @olang_textcopy(ptr %t63, ptr %t56, i64 %t57)
  %t64 = getelementptr i8, ptr %t63, i64 %t57
  call void @olang_textcopy(ptr %t64, ptr %t59, i64 %t60)
  %t65 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t62, 1
  %t68 = extractvalue { i64, ptr } %t66, 0
  %t69 = extractvalue { i64, ptr } %t66, 1
  %t70 = mul i64 %t68, 1
  %t71 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t70)
  call void @llvm.memcpy.p0.p0.i64(ptr %t71, ptr %t69, i64 %t70, i1 false)
  %t72 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t71, 1
  %t76 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s1, ptr %s1, ptr %t51, { i64, ptr } %t73)
  store { i64, ptr } %t76, ptr %l28
  br label %bb6
bb6:
  %t77 = extractvalue { i64, ptr } { i64 4, ptr @.d78 }, 1
  %t78 = extractvalue { i64, ptr } { i64 4, ptr @.d78 }, 0
  %t79 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 1
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t82 = add i64 %t78, %t81
  %t83 = extractvalue { i64, ptr } { i64 6, ptr @.d79 }, 1
  %t84 = extractvalue { i64, ptr } { i64 6, ptr @.d79 }, 0
  %t85 = add i64 %t82, %t84
  %t86 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = add i64 %t85, %t88
  %t90 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t89)
  call void @olang_textcopy(ptr %t90, ptr %t77, i64 %t78)
  %t91 = getelementptr i8, ptr %t90, i64 %t78
  call void @olang_textcopy(ptr %t91, ptr %t80, i64 %t81)
  %t92 = getelementptr i8, ptr %t91, i64 %t81
  call void @olang_textcopy(ptr %t92, ptr %t83, i64 %t84)
  %t93 = getelementptr i8, ptr %t92, i64 %t84
  call void @olang_textcopy(ptr %t93, ptr %t87, i64 %t88)
  %t94 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t90, 1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t95, ptr %rv
  br label %ret
bb7:
  %t97 = load ptr, ptr %l3, !tbaa !29
  %t98 = load i32, ptr %l4, !tbaa !23
  %t101 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t97, i32 %t98)
  store i1 %t101, ptr %l32
  br label %bb8
bb8:
  %t102 = load i1, ptr %l32, !tbaa !21
  br i1 %t102, label %bb9, label %bb10
bb9:
  %t103 = load ptr, ptr %l3, !tbaa !29
  %t104 = load i32, ptr %l4, !tbaa !23
  %t107 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t103, i32 %t104)
  store i32 %t107, ptr %l36
  br label %bb11
bb10:
  %t108 = load i32, ptr %l4, !tbaa !23
  store i32 %t108, ptr %l33, !tbaa !23
  br label %bb12
bb11:
  %t110 = load i32, ptr %l36, !tbaa !23
  store i32 %t110, ptr %l33, !tbaa !23
  br label %bb12
bb12:
  %t111 = load i32, ptr %l33, !tbaa !23
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t116 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t112, i32 %t111)
  store i32 %t116, ptr %l40
  br label %bb13
bb13:
  %t117 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t118 = load i32, ptr %l40, !tbaa !23
  %t120 = icmp ne i32 %t118, %t117
  br i1 %t120, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s5
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t124 = load i32, ptr %l2, !tbaa !23
  %t128 = call { { i64, ptr }, { i64, ptr } } @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayParts(ptr %v0, ptr %v1, ptr %s5, ptr %t122, { i64, ptr } %t123, i32 %t124)
  store { { i64, ptr }, { i64, ptr } } %t128, ptr %l46
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t129 = load { { i64, ptr }, { i64, ptr } }, ptr %l46
  store { { i64, ptr }, { i64, ptr } } %t129, ptr %l6
  %t130 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l6, i32 0, i32 0
  %t131 = load { i64, ptr }, ptr %t130, !tbaa !27
  store { i64, ptr } %t131, ptr %l47, !tbaa !27
  %t132 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t132, 0
  store i64 %t133, ptr %l48, !tbaa !24
  %t134 = load i64, ptr %l48, !tbaa !24
  %t135 = mul i64 %t134, 1
  %t136 = call ptr @__olang_scope_alloc_zeroed(ptr %s5, i64 %t135)
  %t137 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t136, 1
  store { i64, ptr } %t138, ptr %l49, !tbaa !27
  %t139 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !27
  %t141 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = load i64, ptr %l48, !tbaa !24
  %t144 = mul i64 %t143, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t140, ptr %t142, i64 %t144, i1 false)
  %t145 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t147 = extractvalue { i64, ptr } { i64 4, ptr @.d80 }, 1
  %t148 = extractvalue { i64, ptr } { i64 4, ptr @.d80 }, 0
  %t150 = extractvalue { i64, ptr } %t145, 1
  %t151 = extractvalue { i64, ptr } %t145, 0
  %t152 = add i64 %t148, %t151
  %t153 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t152)
  call void @olang_textcopy(ptr %t153, ptr %t147, i64 %t148)
  %t154 = getelementptr i8, ptr %t153, i64 %t148
  call void @olang_textcopy(ptr %t154, ptr %t150, i64 %t151)
  %t155 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t153, 1
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t156, ptr %rv
  br label %ret
bb17:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load i32, ptr %l4, !tbaa !23
  %t162 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s0, ptr %t158, i32 %t159)
  store { i64, ptr } %t162, ptr %l54
  br label %bb18
bb18:
  %t163 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t164 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t164, 1
  %t166 = extractvalue { i64, ptr } %t164, 0
  %t167 = extractvalue { i64, ptr } { i64 1, ptr @.d81 }, 1
  %t168 = extractvalue { i64, ptr } { i64 1, ptr @.d81 }, 0
  %t169 = add i64 %t166, %t168
  %t171 = extractvalue { i64, ptr } %t163, 1
  %t172 = extractvalue { i64, ptr } %t163, 0
  %t173 = add i64 %t169, %t172
  %t174 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t173)
  call void @olang_textcopy(ptr %t174, ptr %t165, i64 %t166)
  %t175 = getelementptr i8, ptr %t174, i64 %t166
  call void @olang_textcopy(ptr %t175, ptr %t167, i64 %t168)
  %t176 = getelementptr i8, ptr %t175, i64 %t168
  call void @olang_textcopy(ptr %t176, ptr %t171, i64 %t172)
  %t177 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t174, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t178, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efillInPlace(ptr %v0, ptr %a0, %"compiler/mir:Place" %a1, i32 %a2, { i64, [15 x i64] } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Place"
  %l2 = alloca i32
  %l3 = alloca { i64, [15 x i64] }
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca %"compiler/mir:Range"
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i1
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca { { i64, ptr }, i32 }
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l30 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l37 = alloca { { i64, ptr }, i32 }
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, [4 x i64] }
  %l47 = alloca %"compiler/mir:Place"
  %l48 = alloca i32
  %l49 = alloca { { i64, ptr }, i32 }
  %l50 = alloca { i64, ptr }
  %l51 = alloca { { i64, ptr }, i32 }
  %l52 = alloca { i64, ptr }
  %l62 = alloca i32
  %l66 = alloca i1
  %l69 = alloca i1
  %l71 = alloca i1
  %l74 = alloca i32
  %l80 = alloca i64
  %l86 = alloca i32
  %l89 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l97 = alloca i64
  %l100 = alloca i64
  %l121 = alloca { i64, [4 x i64] }
  %l122 = alloca ptr
  %l125 = alloca { i64, [4 x i64] }
  %l127 = alloca i1
  %l132 = alloca ptr
  %l135 = alloca { i64, [4 x i64] }
  %l137 = alloca { i64, ptr }
  %l140 = alloca { { i64, ptr }, i32 }
  %l141 = alloca { i64, ptr }
  %l142 = alloca i64
  %l143 = alloca { i64, ptr }
  %l145 = alloca { i64, ptr }
  %l147 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l151 = alloca { i64, ptr }
  %l165 = alloca { i64, ptr }
  %l167 = alloca { i64, ptr }
  %l180 = alloca { i64, ptr }
  %l195 = alloca { i64, ptr }
  %l212 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l217 = alloca i64
  %l220 = alloca i64
  %l238 = alloca ptr
  %l239 = alloca ptr
  %l243 = alloca { i64, [4 x i64] }
  %l245 = alloca { i64, ptr }
  %l251 = alloca { { i64, ptr }, i32 }
  %l252 = alloca { i64, ptr }
  %l253 = alloca i64
  %l254 = alloca { i64, ptr }
  %l259 = alloca i64
  %l262 = alloca i64
  %l286 = alloca { i64, ptr }
  %l287 = alloca ptr
  %l288 = alloca { i64, ptr }
  %l291 = alloca { i64, ptr }
  %l302 = alloca ptr
  %l305 = alloca i32
  %l306 = alloca i32
  %l310 = alloca i1
  %l314 = alloca i1
  %l319 = alloca ptr
  %l322 = alloca i32
  %l323 = alloca i32
  %l326 = alloca i1
  %l327 = alloca ptr
  %l330 = alloca i32
  %l331 = alloca i1
  %l336 = alloca i64
  %l338 = alloca i1
  %l341 = alloca i32
  %l347 = alloca { { i64, ptr }, i32 }
  %l348 = alloca { i64, ptr }
  %l349 = alloca i64
  %l350 = alloca { i64, ptr }
  %l353 = alloca { { i64, ptr }, i32 }
  %l354 = alloca { i64, ptr }
  %l355 = alloca i64
  %l356 = alloca { i64, ptr }
  %l359 = alloca ptr
  %l360 = alloca { i64, ptr }
  %l361 = alloca { i64, ptr }
  %l364 = alloca i64
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/mir:Place" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, [15 x i64] } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l4, !tbaa !29
  %t9 = load { i64, [15 x i64] }, ptr %l3
  %t11 = extractvalue { i64, [15 x i64] } %t9, 0
  %t12 = icmp eq i64 %t11, 6
  br i1 %t12, label %bb1, label %bb2
bb1:
  %t14 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t15 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t14, i32 0, i32 0
  %t16 = load i32, ptr %t15
  store i32 %t16, ptr %l5, !tbaa !23
  %t18 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t19 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t18, i32 0, i32 2
  %t20 = load %"compiler/mir:Range", ptr %t19
  store %"compiler/mir:Range" %t20, ptr %l6
  br label %bb3
bb2:
  br label %bb98
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l5, !tbaa !23
  %t26 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t26, ptr %l62
  br label %bb4
bb4:
  %t27 = load i32, ptr %l62, !tbaa !23
  store i32 %t27, ptr %l7, !tbaa !23
  %t28 = load i32, ptr %l7, !tbaa !23
  %t29 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t32 = icmp eq i32 %t28, %t29
  br i1 %t32, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb8
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i32, ptr %l7, !tbaa !23
  %t38 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixed(ptr %v0, ptr %t34, i32 %t35)
  store i1 %t38, ptr %l69
  br label %bb7
bb7:
  %t39 = load i1, ptr %l69, !tbaa !21
  %t40 = xor i1 %t39, true
  store i1 %t40, ptr %l66, !tbaa !21
  br label %bb8
bb8:
  %t42 = load i1, ptr %l66, !tbaa !21
  br i1 %t42, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l71, !tbaa !21
  br label %bb12
bb10:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i32, ptr %l2, !tbaa !23
  %t47 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t43, i32 %t44)
  store i32 %t47, ptr %l74
  br label %bb11
bb11:
  %t48 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t49 = load i32, ptr %l74, !tbaa !23
  %t51 = icmp eq i32 %t49, %t48
  store i1 %t51, ptr %l71, !tbaa !21
  br label %bb12
bb12:
  %t53 = load i1, ptr %l71, !tbaa !21
  br i1 %t53, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i32, ptr %l7, !tbaa !23
  %t59 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixedLen(ptr %v0, ptr %t55, i32 %t56)
  store i64 %t59, ptr %l80
  br label %bb16
bb16:
  %t60 = load i64, ptr %l80, !tbaa !24
  store i64 %t60, ptr %l8, !tbaa !24
  %t61 = load i64, ptr %l8, !tbaa !24
  %t63 = icmp sle i64 %t61, 16
  br i1 %t63, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t66 = load ptr, ptr %l4, !tbaa !29
  %t67 = load i32, ptr %l7, !tbaa !23
  %t70 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t66, i32 %t67)
  store i32 %t70, ptr %l86
  br label %bb20
bb20:
  %t71 = load i32, ptr %l86, !tbaa !23
  store i32 %t71, ptr %l9, !tbaa !23
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i32, ptr %l9, !tbaa !23
  %t76 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s1, ptr %t72, i32 %t73)
  store { i64, ptr } %t76, ptr %l89
  br label %bb21
bb21:
  %t77 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t77, ptr %l10, !tbaa !27
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i32, ptr %l7, !tbaa !23
  %t82 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s1, ptr %t78, i32 %t79)
  store { i64, ptr } %t82, ptr %l92
  br label %bb22
bb22:
  %t83 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t83, ptr %l11, !tbaa !27
  store i1 true, ptr %l12, !tbaa !21
  store i64 0, ptr %l13, !tbaa !24
  %t84 = load i64, ptr %l8, !tbaa !24
  store i64 %t84, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t86 = load i64, ptr %l14, !tbaa !24
  %t87 = load i64, ptr %l13, !tbaa !24
  %t90 = icmp sgt i64 %t86, %t87
  br i1 %t90, label %bb23, label %bb24
bb23:
  %t92 = load i64, ptr %l15, !tbaa !24
  %t94 = icmp sgt i64 %t92, 0
  br i1 %t94, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l97, !tbaa !24
  br label %bb28
bb25:
  %t96 = load i64, ptr %l14, !tbaa !24
  %t97 = load i64, ptr %l13, !tbaa !24
  %t100 = sub i64 %t96, %t97
  %t101 = load i64, ptr %l15, !tbaa !24
  %t104 = add i64 %t100, %t101
  %t106 = sub i64 %t104, 1
  %t107 = load i64, ptr %l15, !tbaa !24
  %t110 = sdiv i64 %t106, %t107
  store i64 %t110, ptr %l100, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l100, !tbaa !24
  br label %bb27
bb27:
  %t112 = load i64, ptr %l100, !tbaa !24
  store i64 %t112, ptr %l97, !tbaa !24
  br label %bb28
bb28:
  %t113 = load i64, ptr %l97, !tbaa !24
  store i64 %t113, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s5
  %t114 = load i64, ptr %l17, !tbaa !24
  %t115 = load i64, ptr %l16, !tbaa !24
  %t118 = icmp slt i64 %t114, %t115
  %t120 = xor i1 %t118, true
  br i1 %t120, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb40
bb31:
  br label %bb32
bb32:
  %t122 = load i64, ptr %l13, !tbaa !24
  %t123 = load i64, ptr %l17, !tbaa !24
  %t124 = load i64, ptr %l15, !tbaa !24
  %t127 = mul i64 %t123, %t124
  %t130 = add i64 %t122, %t127
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load %"compiler/mir:Range", ptr %l6
  %t138 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t132, %"compiler/mir:Range" %t133, i64 %t130)
  store { i64, [4 x i64] } %t138, ptr %l121
  br label %bb33
bb33:
  store ptr %l121, ptr %l122, !tbaa !29
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load %"compiler/mir:Range", ptr %l6
  %t143 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t139, %"compiler/mir:Range" %t140, i64 0)
  store { i64, [4 x i64] } %t143, ptr %l125
  br label %bb34
bb34:
  %t144 = load ptr, ptr %l122, !tbaa !29
  %t146 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aOperand(ptr %t144, ptr %l125)
  store i1 %t146, ptr %l127
  br label %bb35
bb35:
  %t147 = load i1, ptr %l127, !tbaa !21
  %t148 = xor i1 %t147, true
  br i1 %t148, label %bb36, label %bb37
bb36:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb38
bb37:
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s5)
  br label %bb39
bb39:
  %t150 = load i64, ptr %l17, !tbaa !24
  %t152 = add i64 %t150, 1
  store i64 %t152, ptr %l17, !tbaa !24
  br label %bb29
bb40:
  %t154 = load i1, ptr %l12, !tbaa !21
  br i1 %t154, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s8
  %t156 = load ptr, ptr %l0, !tbaa !29
  store ptr %t156, ptr %l132, !tbaa !29
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load %"compiler/mir:Range", ptr %l6
  %t161 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t157, %"compiler/mir:Range" %t158, i64 0)
  store { i64, [4 x i64] } %t161, ptr %l135
  br label %bb43
bb42:
  br label %bb65
bb43:
  %t162 = load i32, ptr %l9, !tbaa !23
  %t163 = load ptr, ptr %l132, !tbaa !29
  %t164 = load { i64, [4 x i64] }, ptr %l135
  %t166 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s8, ptr %t163, { i64, [4 x i64] } %t164, i32 %t162)
  store { i64, ptr } %t166, ptr %l137
  br label %bb44
bb44:
  %t167 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t167, ptr %l19, !tbaa !27
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load %"compiler/mir:Place", ptr %l1
  %t172 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s8, ptr %t168, %"compiler/mir:Place" %t169)
  store { { i64, ptr }, i32 } %t172, ptr %l140
  br label %bb45
bb45:
  %t173 = load { { i64, ptr }, i32 }, ptr %l140
  store { { i64, ptr }, i32 } %t173, ptr %l20
  %t174 = getelementptr { { i64, ptr }, i32 }, ptr %l20, i32 0, i32 0
  %t175 = load { i64, ptr }, ptr %t174, !tbaa !27
  store { i64, ptr } %t175, ptr %l141, !tbaa !27
  %t176 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t176, 0
  store i64 %t177, ptr %l142, !tbaa !24
  %t178 = load i64, ptr %l142, !tbaa !24
  %t179 = mul i64 %t178, 1
  %t180 = call ptr @__olang_scope_alloc_zeroed(ptr %s8, i64 %t179)
  %t181 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  store { i64, ptr } %t182, ptr %l143, !tbaa !27
  %t183 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !27
  %t187 = load i64, ptr %l142, !tbaa !24
  %t188 = mul i64 %t187, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t184, ptr %t186, i64 %t188, i1 false)
  %t189 = load { i64, ptr }, ptr %l143, !tbaa !27
  store { i64, ptr } %t189, ptr %l21, !tbaa !27
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t192 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s8, ptr %s8, ptr %t190, { i64, ptr } { i64 4, ptr @.d82 })
  store { i64, ptr } %t192, ptr %l145
  br label %bb46
bb46:
  %t193 = load { i64, ptr }, ptr %l145, !tbaa !27
  store { i64, ptr } %t193, ptr %l22, !tbaa !27
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s8, ptr %s8, ptr %t194, { i64, ptr } { i64 4, ptr @.d83 })
  store { i64, ptr } %t196, ptr %l147
  br label %bb47
bb47:
  %t197 = load { i64, ptr }, ptr %l147, !tbaa !27
  store { i64, ptr } %t197, ptr %l23, !tbaa !27
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s8, ptr %s8, ptr %t198, { i64, ptr } { i64 4, ptr @.d84 })
  store { i64, ptr } %t200, ptr %l149
  br label %bb48
bb48:
  %t201 = load { i64, ptr }, ptr %l149, !tbaa !27
  store { i64, ptr } %t201, ptr %l24, !tbaa !27
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s8, ptr %s8, ptr %t202, { i64, ptr } { i64 4, ptr @.d85 })
  store { i64, ptr } %t204, ptr %l151
  br label %bb49
bb49:
  %t205 = load { i64, ptr }, ptr %l151, !tbaa !27
  store { i64, ptr } %t205, ptr %l25, !tbaa !27
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t207 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t208 = extractvalue { i64, ptr } { i64 10, ptr @.d86 }, 1
  %t209 = extractvalue { i64, ptr } { i64 10, ptr @.d86 }, 0
  %t211 = extractvalue { i64, ptr } %t207, 1
  %t212 = extractvalue { i64, ptr } %t207, 0
  %t213 = add i64 %t209, %t212
  %t214 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t213)
  call void @olang_textcopy(ptr %t214, ptr %t208, i64 %t209)
  %t215 = getelementptr i8, ptr %t214, i64 %t209
  call void @olang_textcopy(ptr %t215, ptr %t211, i64 %t212)
  %t216 = insertvalue { i64, ptr } undef, i64 %t213, 0
  %t217 = insertvalue { i64, ptr } %t216, ptr %t214, 1
  %t219 = extractvalue { i64, ptr } %t217, 0
  %t220 = extractvalue { i64, ptr } %t217, 1
  %t221 = mul i64 %t219, 1
  %t222 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t221)
  call void @llvm.memcpy.p0.p0.i64(ptr %t222, ptr %t220, i64 %t221, i1 false)
  %t223 = insertvalue { i64, ptr } undef, i64 %t219, 0
  %t224 = insertvalue { i64, ptr } %t223, ptr %t222, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s8, ptr %t206, { i64, ptr } %t224)
  br label %bb50
bb50:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load { i64, ptr }, ptr %l25, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s8, ptr %t227, { i64, ptr } %t228)
  br label %bb51
bb51:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t232 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t233 = extractvalue { i64, ptr } { i64 10, ptr @.d87 }, 1
  %t234 = extractvalue { i64, ptr } { i64 10, ptr @.d87 }, 0
  %t236 = extractvalue { i64, ptr } %t232, 1
  %t237 = extractvalue { i64, ptr } %t232, 0
  %t238 = add i64 %t234, %t237
  %t239 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t238)
  call void @olang_textcopy(ptr %t239, ptr %t233, i64 %t234)
  %t240 = getelementptr i8, ptr %t239, i64 %t234
  call void @olang_textcopy(ptr %t240, ptr %t236, i64 %t237)
  %t241 = insertvalue { i64, ptr } undef, i64 %t238, 0
  %t242 = insertvalue { i64, ptr } %t241, ptr %t239, 1
  %t244 = extractvalue { i64, ptr } %t242, 0
  %t245 = extractvalue { i64, ptr } %t242, 1
  %t246 = mul i64 %t244, 1
  %t247 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t246)
  call void @llvm.memcpy.p0.p0.i64(ptr %t247, ptr %t245, i64 %t246, i1 false)
  %t248 = insertvalue { i64, ptr } undef, i64 %t244, 0
  %t249 = insertvalue { i64, ptr } %t248, ptr %t247, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s8, ptr %t231, { i64, ptr } %t249)
  br label %bb52
bb52:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t253 = load { i64, ptr }, ptr %l22, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s8, ptr %t252, { i64, ptr } %t253)
  br label %bb53
bb53:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2etmp(ptr %v0, ptr %s8, ptr %t256)
  store { i64, ptr } %t258, ptr %l165
  br label %bb54
bb54:
  %t259 = load { i64, ptr }, ptr %l165, !tbaa !27
  store { i64, ptr } %t259, ptr %l26, !tbaa !27
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t262 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2etmp(ptr %v0, ptr %s8, ptr %t260)
  store { i64, ptr } %t262, ptr %l167
  br label %bb55
bb55:
  %t263 = load { i64, ptr }, ptr %l167, !tbaa !27
  store { i64, ptr } %t263, ptr %l27, !tbaa !27
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t265 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t266 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t267 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t268 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t270 = extractvalue { i64, ptr } %t265, 1
  %t271 = extractvalue { i64, ptr } %t265, 0
  %t272 = extractvalue { i64, ptr } { i64 17, ptr @.d88 }, 1
  %t273 = extractvalue { i64, ptr } { i64 17, ptr @.d88 }, 0
  %t274 = add i64 %t271, %t273
  %t276 = extractvalue { i64, ptr } %t266, 1
  %t277 = extractvalue { i64, ptr } %t266, 0
  %t278 = add i64 %t274, %t277
  %t279 = extractvalue { i64, ptr } { i64 6, ptr @.d89 }, 1
  %t280 = extractvalue { i64, ptr } { i64 6, ptr @.d89 }, 0
  %t281 = add i64 %t278, %t280
  %t283 = extractvalue { i64, ptr } %t267, 1
  %t284 = extractvalue { i64, ptr } %t267, 0
  %t285 = add i64 %t281, %t284
  %t286 = extractvalue { i64, ptr } { i64 3, ptr @.d90 }, 1
  %t287 = extractvalue { i64, ptr } { i64 3, ptr @.d90 }, 0
  %t288 = add i64 %t285, %t287
  %t290 = extractvalue { i64, ptr } %t268, 1
  %t291 = extractvalue { i64, ptr } %t268, 0
  %t292 = add i64 %t288, %t291
  %t293 = extractvalue { i64, ptr } { i64 2, ptr @.d91 }, 1
  %t294 = extractvalue { i64, ptr } { i64 2, ptr @.d91 }, 0
  %t295 = add i64 %t292, %t294
  %t296 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t295)
  call void @olang_textcopy(ptr %t296, ptr %t270, i64 %t271)
  %t297 = getelementptr i8, ptr %t296, i64 %t271
  call void @olang_textcopy(ptr %t297, ptr %t272, i64 %t273)
  %t298 = getelementptr i8, ptr %t297, i64 %t273
  call void @olang_textcopy(ptr %t298, ptr %t276, i64 %t277)
  %t299 = getelementptr i8, ptr %t298, i64 %t277
  call void @olang_textcopy(ptr %t299, ptr %t279, i64 %t280)
  %t300 = getelementptr i8, ptr %t299, i64 %t280
  call void @olang_textcopy(ptr %t300, ptr %t283, i64 %t284)
  %t301 = getelementptr i8, ptr %t300, i64 %t284
  call void @olang_textcopy(ptr %t301, ptr %t286, i64 %t287)
  %t302 = getelementptr i8, ptr %t301, i64 %t287
  call void @olang_textcopy(ptr %t302, ptr %t290, i64 %t291)
  %t303 = getelementptr i8, ptr %t302, i64 %t291
  call void @olang_textcopy(ptr %t303, ptr %t293, i64 %t294)
  %t304 = insertvalue { i64, ptr } undef, i64 %t295, 0
  %t305 = insertvalue { i64, ptr } %t304, ptr %t296, 1
  %t307 = extractvalue { i64, ptr } %t305, 0
  %t308 = extractvalue { i64, ptr } %t305, 1
  %t309 = mul i64 %t307, 1
  %t310 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t309)
  call void @llvm.memcpy.p0.p0.i64(ptr %t310, ptr %t308, i64 %t309, i1 false)
  %t311 = insertvalue { i64, ptr } undef, i64 %t307, 0
  %t312 = insertvalue { i64, ptr } %t311, ptr %t310, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s8, ptr %t264, { i64, ptr } %t312)
  br label %bb56
bb56:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t316 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t317 = load i64, ptr %l8, !tbaa !24
  %t318 = extractvalue { i64, ptr } { i64 13, ptr @.d92 }, 1
  %t319 = extractvalue { i64, ptr } { i64 13, ptr @.d92 }, 0
  %t321 = extractvalue { i64, ptr } %t316, 1
  %t322 = extractvalue { i64, ptr } %t316, 0
  %t323 = add i64 %t319, %t322
  %t324 = extractvalue { i64, ptr } { i64 2, ptr @.d93 }, 1
  %t325 = extractvalue { i64, ptr } { i64 2, ptr @.d93 }, 0
  %t326 = add i64 %t323, %t325
  %t328 = call i64 @__olang_fmt_i64(ptr null, i64 %t317)
  %t329 = add i64 %t326, %t328
  %t330 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t329)
  call void @olang_textcopy(ptr %t330, ptr %t318, i64 %t319)
  %t331 = getelementptr i8, ptr %t330, i64 %t319
  call void @olang_textcopy(ptr %t331, ptr %t321, i64 %t322)
  %t332 = getelementptr i8, ptr %t331, i64 %t322
  call void @olang_textcopy(ptr %t332, ptr %t324, i64 %t325)
  %t333 = getelementptr i8, ptr %t332, i64 %t325
  %t334 = call i64 @__olang_fmt_i64(ptr %t333, i64 %t317)
  %t335 = insertvalue { i64, ptr } undef, i64 %t329, 0
  %t336 = insertvalue { i64, ptr } %t335, ptr %t330, 1
  %t338 = extractvalue { i64, ptr } %t336, 0
  %t339 = extractvalue { i64, ptr } %t336, 1
  %t340 = mul i64 %t338, 1
  %t341 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t340)
  call void @llvm.memcpy.p0.p0.i64(ptr %t341, ptr %t339, i64 %t340, i1 false)
  %t342 = insertvalue { i64, ptr } undef, i64 %t338, 0
  %t343 = insertvalue { i64, ptr } %t342, ptr %t341, 1
  %t346 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s8, ptr %s8, ptr %t315, { i64, ptr } %t343)
  store { i64, ptr } %t346, ptr %l180
  br label %bb57
bb57:
  %t347 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t350 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t351 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t352 = extractvalue { i64, ptr } { i64 6, ptr @.d94 }, 1
  %t353 = extractvalue { i64, ptr } { i64 6, ptr @.d94 }, 0
  %t355 = extractvalue { i64, ptr } %t347, 1
  %t356 = extractvalue { i64, ptr } %t347, 0
  %t357 = add i64 %t353, %t356
  %t358 = extractvalue { i64, ptr } { i64 9, ptr @.d95 }, 1
  %t359 = extractvalue { i64, ptr } { i64 9, ptr @.d95 }, 0
  %t360 = add i64 %t357, %t359
  %t362 = extractvalue { i64, ptr } %t350, 1
  %t363 = extractvalue { i64, ptr } %t350, 0
  %t364 = add i64 %t360, %t363
  %t365 = extractvalue { i64, ptr } { i64 9, ptr @.d96 }, 1
  %t366 = extractvalue { i64, ptr } { i64 9, ptr @.d96 }, 0
  %t367 = add i64 %t364, %t366
  %t369 = extractvalue { i64, ptr } %t351, 1
  %t370 = extractvalue { i64, ptr } %t351, 0
  %t371 = add i64 %t367, %t370
  %t372 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t371)
  call void @olang_textcopy(ptr %t372, ptr %t352, i64 %t353)
  %t373 = getelementptr i8, ptr %t372, i64 %t353
  call void @olang_textcopy(ptr %t373, ptr %t355, i64 %t356)
  %t374 = getelementptr i8, ptr %t373, i64 %t356
  call void @olang_textcopy(ptr %t374, ptr %t358, i64 %t359)
  %t375 = getelementptr i8, ptr %t374, i64 %t359
  call void @olang_textcopy(ptr %t375, ptr %t362, i64 %t363)
  %t376 = getelementptr i8, ptr %t375, i64 %t363
  call void @olang_textcopy(ptr %t376, ptr %t365, i64 %t366)
  %t377 = getelementptr i8, ptr %t376, i64 %t366
  call void @olang_textcopy(ptr %t377, ptr %t369, i64 %t370)
  %t378 = insertvalue { i64, ptr } undef, i64 %t371, 0
  %t379 = insertvalue { i64, ptr } %t378, ptr %t372, 1
  %t381 = extractvalue { i64, ptr } %t379, 0
  %t382 = extractvalue { i64, ptr } %t379, 1
  %t383 = mul i64 %t381, 1
  %t384 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t383)
  call void @llvm.memcpy.p0.p0.i64(ptr %t384, ptr %t382, i64 %t383, i1 false)
  %t385 = insertvalue { i64, ptr } undef, i64 %t381, 0
  %t386 = insertvalue { i64, ptr } %t385, ptr %t384, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s8, ptr %t348, { i64, ptr } %t386)
  br label %bb58
bb58:
  %t389 = load ptr, ptr %l0, !tbaa !29
  %t390 = load { i64, ptr }, ptr %l23, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s8, ptr %t389, { i64, ptr } %t390)
  br label %bb59
bb59:
  %t393 = load ptr, ptr %l0, !tbaa !29
  %t394 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t395 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t396 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t397 = extractvalue { i64, ptr } { i64 14, ptr @.d97 }, 1
  %t398 = extractvalue { i64, ptr } { i64 14, ptr @.d97 }, 0
  %t400 = extractvalue { i64, ptr } %t394, 1
  %t401 = extractvalue { i64, ptr } %t394, 0
  %t402 = add i64 %t398, %t401
  %t403 = extractvalue { i64, ptr } { i64 6, ptr @.d98 }, 1
  %t404 = extractvalue { i64, ptr } { i64 6, ptr @.d98 }, 0
  %t405 = add i64 %t402, %t404
  %t407 = extractvalue { i64, ptr } %t395, 1
  %t408 = extractvalue { i64, ptr } %t395, 0
  %t409 = add i64 %t405, %t408
  %t410 = extractvalue { i64, ptr } { i64 13, ptr @.d99 }, 1
  %t411 = extractvalue { i64, ptr } { i64 13, ptr @.d99 }, 0
  %t412 = add i64 %t409, %t411
  %t414 = extractvalue { i64, ptr } %t396, 1
  %t415 = extractvalue { i64, ptr } %t396, 0
  %t416 = add i64 %t412, %t415
  %t417 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t416)
  call void @olang_textcopy(ptr %t417, ptr %t397, i64 %t398)
  %t418 = getelementptr i8, ptr %t417, i64 %t398
  call void @olang_textcopy(ptr %t418, ptr %t400, i64 %t401)
  %t419 = getelementptr i8, ptr %t418, i64 %t401
  call void @olang_textcopy(ptr %t419, ptr %t403, i64 %t404)
  %t420 = getelementptr i8, ptr %t419, i64 %t404
  call void @olang_textcopy(ptr %t420, ptr %t407, i64 %t408)
  %t421 = getelementptr i8, ptr %t420, i64 %t408
  call void @olang_textcopy(ptr %t421, ptr %t410, i64 %t411)
  %t422 = getelementptr i8, ptr %t421, i64 %t411
  call void @olang_textcopy(ptr %t422, ptr %t414, i64 %t415)
  %t423 = insertvalue { i64, ptr } undef, i64 %t416, 0
  %t424 = insertvalue { i64, ptr } %t423, ptr %t417, 1
  %t426 = extractvalue { i64, ptr } %t424, 0
  %t427 = extractvalue { i64, ptr } %t424, 1
  %t428 = mul i64 %t426, 1
  %t429 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t428)
  call void @llvm.memcpy.p0.p0.i64(ptr %t429, ptr %t427, i64 %t428, i1 false)
  %t430 = insertvalue { i64, ptr } undef, i64 %t426, 0
  %t431 = insertvalue { i64, ptr } %t430, ptr %t429, 1
  %t434 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s8, ptr %s8, ptr %t393, { i64, ptr } %t431)
  store { i64, ptr } %t434, ptr %l195
  br label %bb60
bb60:
  %t435 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t437 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t438 = load { i64, ptr }, ptr %l19, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s1, ptr %s8, ptr %s8, ptr %s8, ptr %t436, { i64, ptr } %t437, { i64, ptr } %t438, { i64, ptr } %t435, { i64, ptr } { i64 0, ptr @.d100 })
  br label %bb61
bb61:
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t445 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t446 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t448 = extractvalue { i64, ptr } %t445, 1
  %t449 = extractvalue { i64, ptr } %t445, 0
  %t450 = extractvalue { i64, ptr } { i64 11, ptr @.d101 }, 1
  %t451 = extractvalue { i64, ptr } { i64 11, ptr @.d101 }, 0
  %t452 = add i64 %t449, %t451
  %t454 = extractvalue { i64, ptr } %t446, 1
  %t455 = extractvalue { i64, ptr } %t446, 0
  %t456 = add i64 %t452, %t455
  %t457 = extractvalue { i64, ptr } { i64 3, ptr @.d102 }, 1
  %t458 = extractvalue { i64, ptr } { i64 3, ptr @.d102 }, 0
  %t459 = add i64 %t456, %t458
  %t460 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t459)
  call void @olang_textcopy(ptr %t460, ptr %t448, i64 %t449)
  %t461 = getelementptr i8, ptr %t460, i64 %t449
  call void @olang_textcopy(ptr %t461, ptr %t450, i64 %t451)
  %t462 = getelementptr i8, ptr %t461, i64 %t451
  call void @olang_textcopy(ptr %t462, ptr %t454, i64 %t455)
  %t463 = getelementptr i8, ptr %t462, i64 %t455
  call void @olang_textcopy(ptr %t463, ptr %t457, i64 %t458)
  %t464 = insertvalue { i64, ptr } undef, i64 %t459, 0
  %t465 = insertvalue { i64, ptr } %t464, ptr %t460, 1
  %t467 = extractvalue { i64, ptr } %t465, 0
  %t468 = extractvalue { i64, ptr } %t465, 1
  %t469 = mul i64 %t467, 1
  %t470 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t469)
  call void @llvm.memcpy.p0.p0.i64(ptr %t470, ptr %t468, i64 %t469, i1 false)
  %t471 = insertvalue { i64, ptr } undef, i64 %t467, 0
  %t472 = insertvalue { i64, ptr } %t471, ptr %t470, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s8, ptr %t444, { i64, ptr } %t472)
  br label %bb62
bb62:
  %t475 = load ptr, ptr %l0, !tbaa !29
  %t476 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t477 = extractvalue { i64, ptr } { i64 10, ptr @.d103 }, 1
  %t478 = extractvalue { i64, ptr } { i64 10, ptr @.d103 }, 0
  %t480 = extractvalue { i64, ptr } %t476, 1
  %t481 = extractvalue { i64, ptr } %t476, 0
  %t482 = add i64 %t478, %t481
  %t483 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t482)
  call void @olang_textcopy(ptr %t483, ptr %t477, i64 %t478)
  %t484 = getelementptr i8, ptr %t483, i64 %t478
  call void @olang_textcopy(ptr %t484, ptr %t480, i64 %t481)
  %t485 = insertvalue { i64, ptr } undef, i64 %t482, 0
  %t486 = insertvalue { i64, ptr } %t485, ptr %t483, 1
  %t488 = extractvalue { i64, ptr } %t486, 0
  %t489 = extractvalue { i64, ptr } %t486, 1
  %t490 = mul i64 %t488, 1
  %t491 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t490)
  call void @llvm.memcpy.p0.p0.i64(ptr %t491, ptr %t489, i64 %t490, i1 false)
  %t492 = insertvalue { i64, ptr } undef, i64 %t488, 0
  %t493 = insertvalue { i64, ptr } %t492, ptr %t491, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s8, ptr %t475, { i64, ptr } %t493)
  br label %bb63
bb63:
  %t496 = load ptr, ptr %l0, !tbaa !29
  %t497 = load { i64, ptr }, ptr %l24, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s8, ptr %t496, { i64, ptr } %t497)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb65:
  %t501 = load ptr, ptr @__olang_prog_scope
  %t502 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t501)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t502, ptr %l212
  br label %bb66
bb66:
  %t503 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l212
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t503, ptr %l30
  store i64 0, ptr %l31, !tbaa !24
  %t504 = load i64, ptr %l8, !tbaa !24
  store i64 %t504, ptr %l32, !tbaa !24
  store i64 1, ptr %l33, !tbaa !24
  %t506 = load i64, ptr %l32, !tbaa !24
  %t507 = load i64, ptr %l31, !tbaa !24
  %t510 = icmp sgt i64 %t506, %t507
  br i1 %t510, label %bb67, label %bb68
bb67:
  %t512 = load i64, ptr %l33, !tbaa !24
  %t514 = icmp sgt i64 %t512, 0
  br i1 %t514, label %bb69, label %bb70
bb68:
  store i64 0, ptr %l217, !tbaa !24
  br label %bb72
bb69:
  %t516 = load i64, ptr %l32, !tbaa !24
  %t517 = load i64, ptr %l31, !tbaa !24
  %t520 = sub i64 %t516, %t517
  %t521 = load i64, ptr %l33, !tbaa !24
  %t524 = add i64 %t520, %t521
  %t526 = sub i64 %t524, 1
  %t527 = load i64, ptr %l33, !tbaa !24
  %t530 = sdiv i64 %t526, %t527
  store i64 %t530, ptr %l220, !tbaa !24
  br label %bb71
bb70:
  store i64 0, ptr %l220, !tbaa !24
  br label %bb71
bb71:
  %t532 = load i64, ptr %l220, !tbaa !24
  store i64 %t532, ptr %l217, !tbaa !24
  br label %bb72
bb72:
  %t533 = load i64, ptr %l217, !tbaa !24
  store i64 %t533, ptr %l34, !tbaa !24
  store i64 0, ptr %l35, !tbaa !24
  br label %bb73
bb73:
  store %olang.scope zeroinitializer, ptr %s18
  %t534 = load i64, ptr %l35, !tbaa !24
  %t535 = load i64, ptr %l34, !tbaa !24
  %t538 = icmp slt i64 %t534, %t535
  %t540 = xor i1 %t538, true
  br i1 %t540, label %bb74, label %bb75
bb74:
  call void @__olang_scope_close(ptr %s18)
  br label %bb81
bb75:
  br label %bb76
bb76:
  %t542 = load i64, ptr %l31, !tbaa !24
  %t543 = load i64, ptr %l35, !tbaa !24
  %t544 = load i64, ptr %l33, !tbaa !24
  %t547 = mul i64 %t543, %t544
  %t550 = add i64 %t542, %t547
  store ptr %l30, ptr %l238, !tbaa !29
  %t552 = load ptr, ptr %l0, !tbaa !29
  store ptr %t552, ptr %l239, !tbaa !29
  %t553 = load ptr, ptr %l0, !tbaa !29
  %t554 = load %"compiler/mir:Range", ptr %l6
  %t559 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t553, %"compiler/mir:Range" %t554, i64 %t550)
  store { i64, [4 x i64] } %t559, ptr %l243
  br label %bb77
bb77:
  %t560 = load i32, ptr %l9, !tbaa !23
  %t561 = load ptr, ptr %l239, !tbaa !29
  %t562 = load { i64, [4 x i64] }, ptr %l243
  %t564 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s1, ptr %t561, { i64, [4 x i64] } %t562, i32 %t560)
  store { i64, ptr } %t564, ptr %l245
  br label %bb78
bb78:
  %t565 = load { i64, ptr }, ptr %l245, !tbaa !27
  %t566 = extractvalue { i64, ptr } %t565, 0
  %t567 = extractvalue { i64, ptr } %t565, 1
  %t568 = mul i64 %t566, 1
  %t569 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t568)
  call void @llvm.memcpy.p0.p0.i64(ptr %t569, ptr %t567, i64 %t568, i1 false)
  %t570 = insertvalue { i64, ptr } undef, i64 %t566, 0
  %t571 = insertvalue { i64, ptr } %t570, ptr %t569, 1
  %t572 = load ptr, ptr %l238, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s1, ptr %s1, ptr %t572, { i64, ptr } %t571)
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s18)
  br label %bb80
bb80:
  %t574 = load i64, ptr %l35, !tbaa !24
  %t576 = add i64 %t574, 1
  store i64 %t576, ptr %l35, !tbaa !24
  br label %bb73
bb81:
  %t578 = load ptr, ptr %l0, !tbaa !29
  %t579 = load %"compiler/mir:Place", ptr %l1
  %t582 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s1, ptr %t578, %"compiler/mir:Place" %t579)
  store { { i64, ptr }, i32 } %t582, ptr %l251
  br label %bb82
bb82:
  %t583 = load { { i64, ptr }, i32 }, ptr %l251
  store { { i64, ptr }, i32 } %t583, ptr %l37
  %t584 = getelementptr { { i64, ptr }, i32 }, ptr %l37, i32 0, i32 0
  %t585 = load { i64, ptr }, ptr %t584, !tbaa !27
  store { i64, ptr } %t585, ptr %l252, !tbaa !27
  %t586 = load { i64, ptr }, ptr %l252, !tbaa !27
  %t587 = extractvalue { i64, ptr } %t586, 0
  store i64 %t587, ptr %l253, !tbaa !24
  %t588 = load i64, ptr %l253, !tbaa !24
  %t589 = mul i64 %t588, 1
  %t590 = call ptr @__olang_scope_alloc_zeroed(ptr %s1, i64 %t589)
  %t591 = insertvalue { i64, ptr } undef, i64 %t588, 0
  %t592 = insertvalue { i64, ptr } %t591, ptr %t590, 1
  store { i64, ptr } %t592, ptr %l254, !tbaa !27
  %t593 = getelementptr { i64, ptr }, ptr %l254, i32 0, i32 1
  %t594 = load ptr, ptr %t593, !tbaa !27
  %t595 = getelementptr { i64, ptr }, ptr %l252, i32 0, i32 1
  %t596 = load ptr, ptr %t595, !tbaa !27
  %t597 = load i64, ptr %l253, !tbaa !24
  %t598 = mul i64 %t597, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t594, ptr %t596, i64 %t598, i1 false)
  %t599 = load { i64, ptr }, ptr %l254, !tbaa !27
  store { i64, ptr } %t599, ptr %l38, !tbaa !27
  store i64 0, ptr %l39, !tbaa !24
  %t600 = load i64, ptr %l8, !tbaa !24
  store i64 %t600, ptr %l40, !tbaa !24
  store i64 1, ptr %l41, !tbaa !24
  %t602 = load i64, ptr %l40, !tbaa !24
  %t603 = load i64, ptr %l39, !tbaa !24
  %t606 = icmp sgt i64 %t602, %t603
  br i1 %t606, label %bb83, label %bb84
bb83:
  %t608 = load i64, ptr %l41, !tbaa !24
  %t610 = icmp sgt i64 %t608, 0
  br i1 %t610, label %bb85, label %bb86
bb84:
  store i64 0, ptr %l259, !tbaa !24
  br label %bb88
bb85:
  %t612 = load i64, ptr %l40, !tbaa !24
  %t613 = load i64, ptr %l39, !tbaa !24
  %t616 = sub i64 %t612, %t613
  %t617 = load i64, ptr %l41, !tbaa !24
  %t620 = add i64 %t616, %t617
  %t622 = sub i64 %t620, 1
  %t623 = load i64, ptr %l41, !tbaa !24
  %t626 = sdiv i64 %t622, %t623
  store i64 %t626, ptr %l262, !tbaa !24
  br label %bb87
bb86:
  store i64 0, ptr %l262, !tbaa !24
  br label %bb87
bb87:
  %t628 = load i64, ptr %l262, !tbaa !24
  store i64 %t628, ptr %l259, !tbaa !24
  br label %bb88
bb88:
  %t629 = load i64, ptr %l259, !tbaa !24
  store i64 %t629, ptr %l42, !tbaa !24
  store i64 0, ptr %l43, !tbaa !24
  br label %bb89
bb89:
  store %olang.scope zeroinitializer, ptr %s21
  %t630 = load i64, ptr %l43, !tbaa !24
  %t631 = load i64, ptr %l42, !tbaa !24
  %t634 = icmp slt i64 %t630, %t631
  %t636 = xor i1 %t634, true
  br i1 %t636, label %bb90, label %bb91
bb90:
  call void @__olang_scope_close(ptr %s21)
  br label %bb97
bb91:
  br label %bb92
bb92:
  %t638 = load i64, ptr %l39, !tbaa !24
  %t639 = load i64, ptr %l43, !tbaa !24
  %t640 = load i64, ptr %l41, !tbaa !24
  %t643 = mul i64 %t639, %t640
  %t646 = add i64 %t638, %t643
  store i64 %t646, ptr %l44, !tbaa !24
  %t648 = load ptr, ptr %l0, !tbaa !29
  %t649 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t650 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t651 = load i64, ptr %l44, !tbaa !24
  %t652 = extractvalue { i64, ptr } { i64 14, ptr @.d104 }, 1
  %t653 = extractvalue { i64, ptr } { i64 14, ptr @.d104 }, 0
  %t655 = extractvalue { i64, ptr } %t649, 1
  %t656 = extractvalue { i64, ptr } %t649, 0
  %t657 = add i64 %t653, %t656
  %t658 = extractvalue { i64, ptr } { i64 6, ptr @.d105 }, 1
  %t659 = extractvalue { i64, ptr } { i64 6, ptr @.d105 }, 0
  %t660 = add i64 %t657, %t659
  %t662 = extractvalue { i64, ptr } %t650, 1
  %t663 = extractvalue { i64, ptr } %t650, 0
  %t664 = add i64 %t660, %t663
  %t665 = extractvalue { i64, ptr } { i64 13, ptr @.d106 }, 1
  %t666 = extractvalue { i64, ptr } { i64 13, ptr @.d106 }, 0
  %t667 = add i64 %t664, %t666
  %t669 = call i64 @__olang_fmt_i64(ptr null, i64 %t651)
  %t670 = add i64 %t667, %t669
  %t671 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t670)
  call void @olang_textcopy(ptr %t671, ptr %t652, i64 %t653)
  %t672 = getelementptr i8, ptr %t671, i64 %t653
  call void @olang_textcopy(ptr %t672, ptr %t655, i64 %t656)
  %t673 = getelementptr i8, ptr %t672, i64 %t656
  call void @olang_textcopy(ptr %t673, ptr %t658, i64 %t659)
  %t674 = getelementptr i8, ptr %t673, i64 %t659
  call void @olang_textcopy(ptr %t674, ptr %t662, i64 %t663)
  %t675 = getelementptr i8, ptr %t674, i64 %t663
  call void @olang_textcopy(ptr %t675, ptr %t665, i64 %t666)
  %t676 = getelementptr i8, ptr %t675, i64 %t666
  %t677 = call i64 @__olang_fmt_i64(ptr %t676, i64 %t651)
  %t678 = insertvalue { i64, ptr } undef, i64 %t670, 0
  %t679 = insertvalue { i64, ptr } %t678, ptr %t671, 1
  %t681 = extractvalue { i64, ptr } %t679, 0
  %t682 = extractvalue { i64, ptr } %t679, 1
  %t683 = mul i64 %t681, 1
  %t684 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t683)
  call void @llvm.memcpy.p0.p0.i64(ptr %t684, ptr %t682, i64 %t683, i1 false)
  %t685 = insertvalue { i64, ptr } undef, i64 %t681, 0
  %t686 = insertvalue { i64, ptr } %t685, ptr %t684, 1
  %t689 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s21, ptr %s21, ptr %t648, { i64, ptr } %t686)
  store { i64, ptr } %t689, ptr %l286
  br label %bb93
bb93:
  %t690 = load { i64, ptr }, ptr %l286, !tbaa !27
  store { i64, ptr } %t690, ptr %l45, !tbaa !27
  %t691 = load ptr, ptr %l0, !tbaa !29
  store ptr %t691, ptr %l287, !tbaa !29
  %t692 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t692, ptr %l288, !tbaa !27
  %t693 = load i64, ptr %l44, !tbaa !24
  %t696 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s1, ptr %s1, ptr %l30, i64 %t693)
  store { i64, ptr } %t696, ptr %l291
  br label %bb94
bb94:
  %t697 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t698 = load ptr, ptr %l287, !tbaa !29
  %t699 = load { i64, ptr }, ptr %l288, !tbaa !27
  %t700 = load { i64, ptr }, ptr %l291, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s1, ptr %s1, ptr %s21, ptr %s21, ptr %t698, { i64, ptr } %t699, { i64, ptr } %t700, { i64, ptr } %t697, { i64, ptr } { i64 0, ptr @.d107 })
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s21)
  br label %bb96
bb96:
  %t702 = load i64, ptr %l43, !tbaa !24
  %t704 = add i64 %t702, 1
  store i64 %t704, ptr %l43, !tbaa !24
  br label %bb89
bb97:
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb98:
  %t707 = load { i64, [15 x i64] }, ptr %l3
  %t709 = extractvalue { i64, [15 x i64] } %t707, 0
  %t710 = icmp eq i64 %t709, 0
  br i1 %t710, label %bb99, label %bb100
bb99:
  %t712 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t713 = getelementptr { { i64, [4 x i64] } }, ptr %t712, i32 0, i32 0
  %t714 = load { i64, [4 x i64] }, ptr %t713
  store { i64, [4 x i64] } %t714, ptr %l46
  br label %bb101
bb100:
  br label %bb144
bb101:
  %t716 = load { i64, [4 x i64] }, ptr %l46
  %t718 = extractvalue { i64, [4 x i64] } %t716, 0
  %t719 = icmp eq i64 %t718, 1
  br i1 %t719, label %bb102, label %bb103
bb102:
  %t721 = getelementptr { i64, [4 x i64] }, ptr %l46, i32 0, i32 1
  %t722 = getelementptr { %"compiler/mir:Place" }, ptr %t721, i32 0, i32 0
  %t723 = load %"compiler/mir:Place", ptr %t722
  store %"compiler/mir:Place" %t723, ptr %l47
  br label %bb104
bb103:
  br label %bb139
bb104:
  store %olang.scope zeroinitializer, ptr %s25
  %t725 = load ptr, ptr %l4, !tbaa !29
  store ptr %t725, ptr %l302, !tbaa !29
  %t726 = load ptr, ptr %l4, !tbaa !29
  %t727 = load i32, ptr %l2, !tbaa !23
  %t730 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t726, i32 %t727)
  store i32 %t730, ptr %l305
  br label %bb105
bb105:
  %t731 = load ptr, ptr %l302, !tbaa !29
  %t732 = load i32, ptr %l305, !tbaa !23
  %t733 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t731, i32 %t732)
  store i32 %t733, ptr %l306
  br label %bb106
bb106:
  %t734 = load i32, ptr %l306
  store i32 %t734, ptr %l48
  %t735 = load i32, ptr %l48
  %t737 = trunc i64 19 to i32
  %t738 = icmp eq i32 %t735, %t737
  %t740 = xor i1 %t738, true
  br i1 %t740, label %bb107, label %bb108
bb107:
  %t742 = load i32, ptr %l48
  %t744 = trunc i64 18 to i32
  %t745 = icmp eq i32 %t742, %t744
  %t747 = xor i1 %t745, true
  store i1 %t747, ptr %l310, !tbaa !21
  br label %bb109
bb108:
  store i1 false, ptr %l310, !tbaa !21
  br label %bb109
bb109:
  %t749 = load i1, ptr %l310, !tbaa !21
  br i1 %t749, label %bb110, label %bb111
bb110:
  %t750 = load i32, ptr %l48
  %t752 = trunc i64 24 to i32
  %t753 = icmp eq i32 %t750, %t752
  %t755 = xor i1 %t753, true
  store i1 %t755, ptr %l314, !tbaa !21
  br label %bb112
bb111:
  store i1 false, ptr %l314, !tbaa !21
  br label %bb112
bb112:
  %t757 = load i1, ptr %l314, !tbaa !21
  br i1 %t757, label %bb113, label %bb114
bb113:
  call void @__olang_scope_close(ptr %s25)
  store i1 false, ptr %rv
  br label %ret
bb114:
  br label %bb115
bb115:
  %t759 = load ptr, ptr %l4, !tbaa !29
  store ptr %t759, ptr %l319, !tbaa !29
  %t760 = load ptr, ptr %l4, !tbaa !29
  %t761 = load i32, ptr %l2, !tbaa !23
  %t764 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t760, i32 %t761)
  store i32 %t764, ptr %l322
  br label %bb116
bb116:
  %t765 = load ptr, ptr %l319, !tbaa !29
  %t766 = load i32, ptr %l322, !tbaa !23
  %t767 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t765, i32 %t766)
  store i32 %t767, ptr %l323
  br label %bb117
bb117:
  %t768 = load i32, ptr %l323
  %t770 = trunc i64 19 to i32
  %t771 = icmp eq i32 %t768, %t770
  br i1 %t771, label %bb118, label %bb119
bb118:
  %t773 = load ptr, ptr %l0, !tbaa !29
  store ptr %t773, ptr %l327, !tbaa !29
  %t774 = load ptr, ptr %l4, !tbaa !29
  %t775 = load i32, ptr %l2, !tbaa !23
  %t778 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t774, i32 %t775)
  store i32 %t778, ptr %l330
  br label %bb120
bb119:
  store i1 false, ptr %l326, !tbaa !21
  br label %bb122
bb120:
  %t779 = load ptr, ptr %l327, !tbaa !29
  %t780 = load i32, ptr %l330, !tbaa !23
  %t781 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixed(ptr %v0, ptr %t779, i32 %t780)
  store i1 %t781, ptr %l331
  br label %bb121
bb121:
  %t782 = load i1, ptr %l331, !tbaa !21
  %t783 = xor i1 %t782, true
  store i1 %t783, ptr %l326, !tbaa !21
  br label %bb122
bb122:
  %t785 = load i1, ptr %l326, !tbaa !21
  br i1 %t785, label %bb123, label %bb124
bb123:
  call void @__olang_scope_close(ptr %s25)
  store i1 false, ptr %rv
  br label %ret
bb124:
  br label %bb125
bb125:
  %t787 = load ptr, ptr %l0, !tbaa !29
  %t788 = load i32, ptr %l2, !tbaa !23
  %t791 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t787, i32 %t788)
  store i64 %t791, ptr %l336
  br label %bb126
bb126:
  %t792 = load i64, ptr %l336, !tbaa !24
  %t793 = icmp sle i64 %t792, 128
  br i1 %t793, label %bb127, label %bb128
bb127:
  store i1 true, ptr %l338, !tbaa !21
  br label %bb130
bb128:
  %t795 = load ptr, ptr %l0, !tbaa !29
  %t796 = load %"compiler/mir:Place", ptr %l47
  %t799 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eplaceType(ptr %v0, ptr %t795, %"compiler/mir:Place" %t796)
  store i32 %t799, ptr %l341
  br label %bb129
bb129:
  %t800 = load i32, ptr %l2, !tbaa !23
  %t801 = load i32, ptr %l341, !tbaa !23
  %t803 = icmp ne i32 %t801, %t800
  store i1 %t803, ptr %l338, !tbaa !21
  br label %bb130
bb130:
  %t805 = load i1, ptr %l338, !tbaa !21
  br i1 %t805, label %bb131, label %bb132
bb131:
  call void @__olang_scope_close(ptr %s25)
  store i1 false, ptr %rv
  br label %ret
bb132:
  br label %bb133
bb133:
  %t807 = load ptr, ptr %l0, !tbaa !29
  %t808 = load %"compiler/mir:Place", ptr %l47
  %t811 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s25, ptr %t807, %"compiler/mir:Place" %t808)
  store { { i64, ptr }, i32 } %t811, ptr %l347
  br label %bb134
bb134:
  %t812 = load { { i64, ptr }, i32 }, ptr %l347
  store { { i64, ptr }, i32 } %t812, ptr %l49
  %t813 = getelementptr { { i64, ptr }, i32 }, ptr %l49, i32 0, i32 0
  %t814 = load { i64, ptr }, ptr %t813, !tbaa !27
  store { i64, ptr } %t814, ptr %l348, !tbaa !27
  %t815 = load { i64, ptr }, ptr %l348, !tbaa !27
  %t816 = extractvalue { i64, ptr } %t815, 0
  store i64 %t816, ptr %l349, !tbaa !24
  %t817 = load i64, ptr %l349, !tbaa !24
  %t818 = mul i64 %t817, 1
  %t819 = call ptr @__olang_scope_alloc_zeroed(ptr %s25, i64 %t818)
  %t820 = insertvalue { i64, ptr } undef, i64 %t817, 0
  %t821 = insertvalue { i64, ptr } %t820, ptr %t819, 1
  store { i64, ptr } %t821, ptr %l350, !tbaa !27
  %t822 = getelementptr { i64, ptr }, ptr %l350, i32 0, i32 1
  %t823 = load ptr, ptr %t822, !tbaa !27
  %t824 = getelementptr { i64, ptr }, ptr %l348, i32 0, i32 1
  %t825 = load ptr, ptr %t824, !tbaa !27
  %t826 = load i64, ptr %l349, !tbaa !24
  %t827 = mul i64 %t826, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t823, ptr %t825, i64 %t827, i1 false)
  %t828 = load { i64, ptr }, ptr %l350, !tbaa !27
  store { i64, ptr } %t828, ptr %l50, !tbaa !27
  %t829 = load ptr, ptr %l0, !tbaa !29
  %t830 = load %"compiler/mir:Place", ptr %l1
  %t833 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s25, ptr %t829, %"compiler/mir:Place" %t830)
  store { { i64, ptr }, i32 } %t833, ptr %l353
  br label %bb135
bb135:
  %t834 = load { { i64, ptr }, i32 }, ptr %l353
  store { { i64, ptr }, i32 } %t834, ptr %l51
  %t835 = getelementptr { { i64, ptr }, i32 }, ptr %l51, i32 0, i32 0
  %t836 = load { i64, ptr }, ptr %t835, !tbaa !27
  store { i64, ptr } %t836, ptr %l354, !tbaa !27
  %t837 = load { i64, ptr }, ptr %l354, !tbaa !27
  %t838 = extractvalue { i64, ptr } %t837, 0
  store i64 %t838, ptr %l355, !tbaa !24
  %t839 = load i64, ptr %l355, !tbaa !24
  %t840 = mul i64 %t839, 1
  %t841 = call ptr @__olang_scope_alloc_zeroed(ptr %s25, i64 %t840)
  %t842 = insertvalue { i64, ptr } undef, i64 %t839, 0
  %t843 = insertvalue { i64, ptr } %t842, ptr %t841, 1
  store { i64, ptr } %t843, ptr %l356, !tbaa !27
  %t844 = getelementptr { i64, ptr }, ptr %l356, i32 0, i32 1
  %t845 = load ptr, ptr %t844, !tbaa !27
  %t846 = getelementptr { i64, ptr }, ptr %l354, i32 0, i32 1
  %t847 = load ptr, ptr %t846, !tbaa !27
  %t848 = load i64, ptr %l355, !tbaa !24
  %t849 = mul i64 %t848, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t845, ptr %t847, i64 %t849, i1 false)
  %t850 = load { i64, ptr }, ptr %l356, !tbaa !27
  store { i64, ptr } %t850, ptr %l52, !tbaa !27
  %t851 = load ptr, ptr %l0, !tbaa !29
  %t853 = getelementptr %"compiler/emit:fnEm", ptr %t851, i32 0, i32 0
  %t854 = load ptr, ptr %t853, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s25, ptr %s25, ptr %t854, { i64, ptr } { i64 22, ptr @.d108 }, { i64, ptr } { i64 47, ptr @.d109 })
  br label %bb136
bb136:
  %t856 = load ptr, ptr %l0, !tbaa !29
  store ptr %t856, ptr %l359, !tbaa !29
  %t857 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t857, ptr %l360, !tbaa !27
  %t858 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t858, ptr %l361, !tbaa !27
  %t859 = load ptr, ptr %l0, !tbaa !29
  %t860 = load i32, ptr %l2, !tbaa !23
  %t863 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t859, i32 %t860)
  store i64 %t863, ptr %l364
  br label %bb137
bb137:
  %t864 = extractvalue { i64, ptr } { i64 38, ptr @.d110 }, 1
  %t865 = extractvalue { i64, ptr } { i64 38, ptr @.d110 }, 0
  %t866 = load { i64, ptr }, ptr %l360, !tbaa !27
  %t867 = extractvalue { i64, ptr } %t866, 1
  %t868 = extractvalue { i64, ptr } %t866, 0
  %t869 = add i64 %t865, %t868
  %t870 = extractvalue { i64, ptr } { i64 6, ptr @.d111 }, 1
  %t871 = extractvalue { i64, ptr } { i64 6, ptr @.d111 }, 0
  %t872 = add i64 %t869, %t871
  %t873 = load { i64, ptr }, ptr %l361, !tbaa !27
  %t874 = extractvalue { i64, ptr } %t873, 1
  %t875 = extractvalue { i64, ptr } %t873, 0
  %t876 = add i64 %t872, %t875
  %t877 = extractvalue { i64, ptr } { i64 6, ptr @.d112 }, 1
  %t878 = extractvalue { i64, ptr } { i64 6, ptr @.d112 }, 0
  %t879 = add i64 %t876, %t878
  %t880 = load i64, ptr %l364, !tbaa !24
  %t881 = call i64 @__olang_fmt_i64(ptr null, i64 %t880)
  %t882 = add i64 %t879, %t881
  %t883 = extractvalue { i64, ptr } { i64 11, ptr @.d113 }, 1
  %t884 = extractvalue { i64, ptr } { i64 11, ptr @.d113 }, 0
  %t885 = add i64 %t882, %t884
  %t886 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t885)
  call void @olang_textcopy(ptr %t886, ptr %t864, i64 %t865)
  %t887 = getelementptr i8, ptr %t886, i64 %t865
  call void @olang_textcopy(ptr %t887, ptr %t867, i64 %t868)
  %t888 = getelementptr i8, ptr %t887, i64 %t868
  call void @olang_textcopy(ptr %t888, ptr %t870, i64 %t871)
  %t889 = getelementptr i8, ptr %t888, i64 %t871
  call void @olang_textcopy(ptr %t889, ptr %t874, i64 %t875)
  %t890 = getelementptr i8, ptr %t889, i64 %t875
  call void @olang_textcopy(ptr %t890, ptr %t877, i64 %t878)
  %t891 = getelementptr i8, ptr %t890, i64 %t878
  %t892 = call i64 @__olang_fmt_i64(ptr %t891, i64 %t880)
  %t893 = getelementptr i8, ptr %t891, i64 %t881
  call void @olang_textcopy(ptr %t893, ptr %t883, i64 %t884)
  %t894 = insertvalue { i64, ptr } undef, i64 %t885, 0
  %t895 = insertvalue { i64, ptr } %t894, ptr %t886, 1
  %t897 = extractvalue { i64, ptr } %t895, 0
  %t898 = extractvalue { i64, ptr } %t895, 1
  %t899 = mul i64 %t897, 1
  %t900 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t899)
  call void @llvm.memcpy.p0.p0.i64(ptr %t900, ptr %t898, i64 %t899, i1 false)
  %t901 = insertvalue { i64, ptr } undef, i64 %t897, 0
  %t902 = insertvalue { i64, ptr } %t901, ptr %t900, 1
  %t903 = load ptr, ptr %l359, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s25, ptr %t903, { i64, ptr } %t902)
  br label %bb138
bb138:
  call void @__olang_scope_close(ptr %s25)
  store i1 true, ptr %rv
  br label %ret
bb139:
  br i1 true, label %bb140, label %bb141
bb140:
  br label %bb142
bb141:
  br label %bb143
bb142:
  store i1 false, ptr %rv
  br label %ret
bb143:
  call void @__olang_check_failed(ptr @olang_loc_9357034ceffa49e9_ad514f9345461395)
  unreachable
bb144:
  br i1 true, label %bb145, label %bb146
bb145:
  br label %bb147
bb146:
  br label %bb148
bb147:
  store i1 false, ptr %rv
  br label %ret
bb148:
  call void @__olang_check_failed(ptr @olang_loc_1dffb4089bad5318_6447f84abd9ba4a4)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2efindIdle(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca %"compiler/mir:BasicBlock"
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca { i64, [21 x i64] }
  %l22 = alloca { i64, [1 x i64] }
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca { i64, [15 x i64] }
  %l26 = alloca { i64, [1 x i64] }
  %l27 = alloca { i64, [1 x i64] }
  %l28 = alloca { i64, [1 x i64] }
  %l29 = alloca { i64, [7 x i64] }
  %l30 = alloca i32
  %l31 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca %"compiler/mir:Local"
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i32
  %l48 = alloca i64
  %l53 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca i32
  %l66 = alloca { i64, ptr }
  %l72 = alloca i1
  %l73 = alloca i1
  %l82 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l86 = alloca i32
  %l95 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l103 = alloca i32
  %l112 = alloca { i64, ptr }
  %l114 = alloca { i64, [21 x i64] }
  %l115 = alloca { i64, [21 x i64] }
  %l118 = alloca { i64, [21 x i64] }
  %l121 = alloca { i64, [21 x i64] }
  %l127 = alloca i1
  %l128 = alloca i1
  %l130 = alloca { i64, [21 x i64] }
  %l135 = alloca { i64, [21 x i64] }
  %l140 = alloca { i64, [21 x i64] }
  %l155 = alloca i1
  %l156 = alloca i1
  %l165 = alloca i1
  %l166 = alloca i1
  %l171 = alloca i1
  %l172 = alloca i1
  %l192 = alloca { i64, ptr }
  %l195 = alloca { i64, ptr }
  %l196 = alloca i32
  %l205 = alloca { i64, ptr }
  %l210 = alloca i1
  %l215 = alloca i1
  %l216 = alloca i1
  %l225 = alloca i64
  %l229 = alloca i64
  %l232 = alloca i64
  %l253 = alloca %"compiler/mir:ScopeInfo"
  %l258 = alloca i1
  %l264 = alloca i1
  %l266 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s29 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/mir:Fn", ptr %t6, i32 0, i32 8
  %t10 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l48
  br label %bb1
bb1:
  %t11 = load i64, ptr %l48, !tbaa !24
  %t12 = icmp sge i64 %t11, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = load i64, ptr %l48, !tbaa !24
  %t15 = mul i64 %t14, 1
  %t16 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l2, !tbaa !27
  store i1 false, ptr %l3, !tbaa !21
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr %"compiler/mir:Fn", ptr %t20, i32 0, i32 12
  store ptr %t22, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_3b6348629663638e_4d98396f767ecbfa)
  unreachable
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t24 = load ptr, ptr %l4, !tbaa !29
  %t25 = load i64, ptr %l5, !tbaa !24
  %t28 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeRef_3e_2eRunF_Hfdafd2704446aebe706e7a16d9caf3c2(ptr %v0, ptr %t24, i64 %t25)
  %t29 = extractvalue { i32, { i64, ptr } } %t28, 1
  %t30 = extractvalue { i32, { i64, ptr } } %t28, 0
  store i32 %t30, ptr %l57
  %t31 = icmp ne i32 %t30, 0
  br i1 %t31, label %bb6, label %ok.32
ok.32:
  store { i64, ptr } %t29, ptr %l56
  br label %bb5
bb5:
  %t33 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t33, ptr %l53, !tbaa !27
  br label %bb10
bb6:
  %t34 = load i32, ptr %l57, !tbaa !23
  %t35 = ashr i32 %t34, 16
  %t37 = icmp eq i32 %t35, 1
  br i1 %t37, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_f4a19adfa2908824_f7d19e69dc606aa8)
  unreachable
bb9:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb10:
  %t39 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t39, ptr %l6, !tbaa !27
  %t40 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t40, 0
  store i64 %t42, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t44 = load i64, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb13:
  br label %bb14
bb14:
  %t52 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t52, ptr %l66, !tbaa !27
  %t53 = load i64, ptr %l8, !tbaa !24
  %t55 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr { i64, [1 x i64] }, ptr %t56, i64 %t53
  %t58 = load { i64, [1 x i64] }, ptr %t57
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t66 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2euseRef(ptr %v0, ptr %s0, ptr %t60, { i64, [1 x i64] } %t58, { i64, ptr } %t62)
  store i1 %t66, ptr %l72
  br label %bb15
bb15:
  %t67 = load i1, ptr %l72, !tbaa !21
  br i1 %t67, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb18
bb17:
  %t68 = load i1, ptr %l3, !tbaa !21
  store i1 %t68, ptr %l73, !tbaa !21
  br label %bb18
bb18:
  %t70 = load i1, ptr %l73, !tbaa !21
  store i1 %t70, ptr %l3, !tbaa !21
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  %t71 = load i64, ptr %l8, !tbaa !24
  %t73 = add i64 %t71, 1
  store i64 %t73, ptr %l8, !tbaa !24
  br label %bb11
bb20:
  %t75 = load i64, ptr %l5, !tbaa !24
  %t76 = load i64, ptr %l7, !tbaa !24
  %t79 = add i64 %t75, %t76
  store i64 %t79, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb21:
  br label %bb4
bb22:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr %"compiler/mir:Fn", ptr %t81, i32 0, i32 9
  store ptr %t83, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  %t85 = load ptr, ptr %l10, !tbaa !29
  %t86 = load i64, ptr %l11, !tbaa !24
  %t89 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eRu_H05f2a0ad75f6ffeece9ab76b4dcd7cb0(ptr %v0, ptr %t85, i64 %t86)
  %t90 = extractvalue { i32, { i64, ptr } } %t89, 1
  %t91 = extractvalue { i32, { i64, ptr } } %t89, 0
  store i32 %t91, ptr %l86
  %t92 = icmp ne i32 %t91, 0
  br i1 %t92, label %bb25, label %ok.93
ok.93:
  store { i64, ptr } %t90, ptr %l85
  br label %bb24
bb24:
  %t94 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t94, ptr %l82, !tbaa !27
  br label %bb29
bb25:
  %t95 = load i32, ptr %l86, !tbaa !23
  %t96 = ashr i32 %t95, 16
  %t98 = icmp eq i32 %t96, 1
  br i1 %t98, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_7398c824c6ccd25f_37644bbf4fe2ca83)
  unreachable
bb28:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s6)
  br label %bb119
bb29:
  %t100 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t100, ptr %l12, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t101, 0
  store i64 %t103, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s7
  %t105 = load i64, ptr %l14, !tbaa !24
  %t106 = load i64, ptr %l13, !tbaa !24
  %t109 = icmp slt i64 %t105, %t106
  %t111 = xor i1 %t109, true
  br i1 %t111, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s7)
  br label %bb117
bb32:
  br label %bb33
bb33:
  %t113 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t113, ptr %l95, !tbaa !27
  %t114 = load i64, ptr %l14, !tbaa !24
  %t116 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr %"compiler/mir:BasicBlock", ptr %t117, i64 %t114
  %t119 = load %"compiler/mir:BasicBlock", ptr %t118
  store %"compiler/mir:BasicBlock" %t119, ptr %l15
  %t121 = getelementptr %"compiler/mir:BasicBlock", ptr %l15, i32 0, i32 0
  store ptr %t121, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s9
  %t123 = load ptr, ptr %l16, !tbaa !29
  %t124 = load i64, ptr %l17, !tbaa !24
  %t127 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eRunFrom_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t123, i64 %t124)
  %t128 = extractvalue { i32, { i64, ptr } } %t127, 1
  %t129 = extractvalue { i32, { i64, ptr } } %t127, 0
  store i32 %t129, ptr %l103
  %t130 = icmp ne i32 %t129, 0
  br i1 %t130, label %bb36, label %ok.131
ok.131:
  store { i64, ptr } %t128, ptr %l102
  br label %bb35
bb35:
  %t132 = load { i64, ptr }, ptr %l102, !tbaa !27
  store { i64, ptr } %t132, ptr %l99, !tbaa !27
  br label %bb40
bb36:
  %t133 = load i32, ptr %l103, !tbaa !23
  %t134 = ashr i32 %t133, 16
  %t136 = icmp eq i32 %t134, 1
  br i1 %t136, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_5718aedbda8f05de_73125ecff2351902)
  unreachable
bb39:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s9)
  br label %bb106
bb40:
  %t138 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t138, ptr %l18, !tbaa !27
  %t139 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t139, 0
  store i64 %t141, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb41
bb41:
  store %olang.scope zeroinitializer, ptr %s10
  %t143 = load i64, ptr %l20, !tbaa !24
  %t144 = load i64, ptr %l19, !tbaa !24
  %t147 = icmp slt i64 %t143, %t144
  %t149 = xor i1 %t147, true
  br i1 %t149, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s10)
  br label %bb104
bb43:
  br label %bb44
bb44:
  %t151 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t151, ptr %l112, !tbaa !27
  %t152 = load i64, ptr %l20, !tbaa !24
  %t154 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = getelementptr { i64, [21 x i64] }, ptr %t155, i64 %t152
  call void @llvm.memmove.p0.p0.i64(ptr %l114, ptr %t156, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l21, ptr %l114, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l115, ptr %l21, i64 176, i1 false)
  %t157 = load { i64, [21 x i64] }, ptr %l115
  %t158 = extractvalue { i64, [21 x i64] } %t157, 0
  %t159 = icmp eq i64 %t158, 6
  br i1 %t159, label %bb45, label %bb46
bb45:
  %t161 = getelementptr { i64, [21 x i64] }, ptr %l21, i32 0, i32 1
  %t162 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t161, i32 0, i32 1
  %t163 = load { i64, [1 x i64] }, ptr %t162
  store { i64, [1 x i64] } %t163, ptr %l22
  br label %bb51
bb46:
  call void @llvm.memmove.p0.p0.i64(ptr %l118, ptr %l21, i64 176, i1 false)
  %t165 = load { i64, [21 x i64] }, ptr %l118
  %t166 = extractvalue { i64, [21 x i64] } %t165, 0
  %t167 = icmp eq i64 %t166, 7
  br i1 %t167, label %bb47, label %bb48
bb47:
  %t169 = getelementptr { i64, [21 x i64] }, ptr %l21, i32 0, i32 1
  %t170 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, %"compiler/mir:Place" }, ptr %t169, i32 0, i32 1
  %t171 = load { i64, [1 x i64] }, ptr %t170
  store { i64, [1 x i64] } %t171, ptr %l22
  br label %bb51
bb48:
  call void @llvm.memmove.p0.p0.i64(ptr %l121, ptr %l21, i64 176, i1 false)
  %t173 = load { i64, [21 x i64] }, ptr %l121
  %t174 = extractvalue { i64, [21 x i64] } %t173, 0
  %t175 = icmp eq i64 %t174, 9
  br i1 %t175, label %bb49, label %bb50
bb49:
  %t177 = getelementptr { i64, [21 x i64] }, ptr %l21, i32 0, i32 1
  %t178 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t177, i32 0, i32 1
  %t179 = load { i64, [1 x i64] }, ptr %t178
  store { i64, [1 x i64] } %t179, ptr %l22
  br label %bb51
bb50:
  br label %bb56
bb51:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load { i64, [1 x i64] }, ptr %l22
  %t183 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t187 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2euseRef(ptr %v0, ptr %s0, ptr %t181, { i64, [1 x i64] } %t182, { i64, ptr } %t183)
  store i1 %t187, ptr %l127
  br label %bb52
bb52:
  %t188 = load i1, ptr %l127, !tbaa !21
  br i1 %t188, label %bb53, label %bb54
bb53:
  store i1 true, ptr %l128, !tbaa !21
  br label %bb55
bb54:
  %t189 = load i1, ptr %l3, !tbaa !21
  store i1 %t189, ptr %l128, !tbaa !21
  br label %bb55
bb55:
  %t191 = load i1, ptr %l128, !tbaa !21
  store i1 %t191, ptr %l3, !tbaa !21
  br label %bb102
bb56:
  call void @llvm.memmove.p0.p0.i64(ptr %l130, ptr %l21, i64 176, i1 false)
  %t192 = load { i64, [21 x i64] }, ptr %l130
  %t193 = extractvalue { i64, [21 x i64] } %t192, 0
  %t194 = icmp eq i64 %t193, 11
  br i1 %t194, label %bb57, label %bb58
bb57:
  %t196 = getelementptr { i64, [21 x i64] }, ptr %l21, i32 0, i32 1
  %t197 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t196, i32 0, i32 1
  %t198 = load i32, ptr %t197
  store i32 %t198, ptr %l23, !tbaa !23
  br label %bb59
bb58:
  br label %bb60
bb59:
  %t200 = load i32, ptr %l23, !tbaa !23
  %t202 = sext i32 %t200 to i64
  %t204 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !27
  %t206 = getelementptr i1, ptr %t205, i64 %t202
  store i1 true, ptr %t206, !tbaa !31
  br label %bb102
bb60:
  call void @llvm.memmove.p0.p0.i64(ptr %l135, ptr %l21, i64 176, i1 false)
  %t207 = load { i64, [21 x i64] }, ptr %l135
  %t208 = extractvalue { i64, [21 x i64] } %t207, 0
  %t209 = icmp eq i64 %t208, 5
  br i1 %t209, label %bb61, label %bb62
bb61:
  %t211 = getelementptr { i64, [21 x i64] }, ptr %l21, i32 0, i32 1
  %t212 = getelementptr { %"compiler/source:Span", i32 }, ptr %t211, i32 0, i32 1
  %t213 = load i32, ptr %t212
  store i32 %t213, ptr %l24, !tbaa !23
  br label %bb63
bb62:
  br label %bb64
bb63:
  %t215 = load i32, ptr %l24, !tbaa !23
  %t217 = sext i32 %t215 to i64
  %t219 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t220 = load ptr, ptr %t219, !tbaa !27
  %t221 = getelementptr i1, ptr %t220, i64 %t217
  store i1 true, ptr %t221, !tbaa !31
  br label %bb102
bb64:
  call void @llvm.memmove.p0.p0.i64(ptr %l140, ptr %l21, i64 176, i1 false)
  %t222 = load { i64, [21 x i64] }, ptr %l140
  %t223 = extractvalue { i64, [21 x i64] } %t222, 0
  %t224 = icmp eq i64 %t223, 0
  br i1 %t224, label %bb65, label %bb66
bb65:
  %t226 = getelementptr { i64, [21 x i64] }, ptr %l21, i32 0, i32 1
  %t227 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } }, ptr %t226, i32 0, i32 2
  %t228 = load { i64, [15 x i64] }, ptr %t227
  store { i64, [15 x i64] } %t228, ptr %l25
  br label %bb67
bb66:
  br label %bb97
bb67:
  %t230 = load { i64, [15 x i64] }, ptr %l25
  %t232 = extractvalue { i64, [15 x i64] } %t230, 0
  %t233 = icmp eq i64 %t232, 7
  br i1 %t233, label %bb68, label %bb69
bb68:
  %t235 = getelementptr { i64, [15 x i64] }, ptr %l25, i32 0, i32 1
  %t236 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t235, i32 0, i32 0
  %t237 = load { i64, [1 x i64] }, ptr %t236
  store { i64, [1 x i64] } %t237, ptr %l26
  br label %bb74
bb69:
  %t239 = load { i64, [15 x i64] }, ptr %l25
  %t241 = extractvalue { i64, [15 x i64] } %t239, 0
  %t242 = icmp eq i64 %t241, 8
  br i1 %t242, label %bb70, label %bb71
bb70:
  %t244 = getelementptr { i64, [15 x i64] }, ptr %l25, i32 0, i32 1
  %t245 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t244, i32 0, i32 0
  %t246 = load { i64, [1 x i64] }, ptr %t245
  store { i64, [1 x i64] } %t246, ptr %l26
  br label %bb74
bb71:
  %t248 = load { i64, [15 x i64] }, ptr %l25
  %t250 = extractvalue { i64, [15 x i64] } %t248, 0
  %t251 = icmp eq i64 %t250, 10
  br i1 %t251, label %bb72, label %bb73
bb72:
  %t253 = getelementptr { i64, [15 x i64] }, ptr %l25, i32 0, i32 1
  %t254 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t253, i32 0, i32 2
  %t255 = load { i64, [1 x i64] }, ptr %t254
  store { i64, [1 x i64] } %t255, ptr %l26
  br label %bb74
bb73:
  br label %bb79
bb74:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load { i64, [1 x i64] }, ptr %l26
  %t259 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t263 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2euseRef(ptr %v0, ptr %s0, ptr %t257, { i64, [1 x i64] } %t258, { i64, ptr } %t259)
  store i1 %t263, ptr %l155
  br label %bb75
bb75:
  %t264 = load i1, ptr %l155, !tbaa !21
  br i1 %t264, label %bb76, label %bb77
bb76:
  store i1 true, ptr %l156, !tbaa !21
  br label %bb78
bb77:
  %t265 = load i1, ptr %l3, !tbaa !21
  store i1 %t265, ptr %l156, !tbaa !21
  br label %bb78
bb78:
  %t267 = load i1, ptr %l156, !tbaa !21
  store i1 %t267, ptr %l3, !tbaa !21
  br label %bb96
bb79:
  %t268 = load { i64, [15 x i64] }, ptr %l25
  %t270 = extractvalue { i64, [15 x i64] } %t268, 0
  %t271 = icmp eq i64 %t270, 12
  br i1 %t271, label %bb80, label %bb81
bb80:
  %t273 = getelementptr { i64, [15 x i64] }, ptr %l25, i32 0, i32 1
  %t274 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t273, i32 0, i32 0
  %t275 = load { i64, [1 x i64] }, ptr %t274
  store { i64, [1 x i64] } %t275, ptr %l27
  %t277 = getelementptr { i64, [15 x i64] }, ptr %l25, i32 0, i32 1
  %t278 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t277, i32 0, i32 1
  %t279 = load { i64, [1 x i64] }, ptr %t278
  store { i64, [1 x i64] } %t279, ptr %l28
  br label %bb82
bb81:
  br label %bb91
bb82:
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t282 = load { i64, [1 x i64] }, ptr %l27
  %t283 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t287 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2euseRef(ptr %v0, ptr %s0, ptr %t281, { i64, [1 x i64] } %t282, { i64, ptr } %t283)
  store i1 %t287, ptr %l165
  br label %bb83
bb83:
  %t288 = load i1, ptr %l165, !tbaa !21
  br i1 %t288, label %bb84, label %bb85
bb84:
  store i1 true, ptr %l166, !tbaa !21
  br label %bb86
bb85:
  %t289 = load i1, ptr %l3, !tbaa !21
  store i1 %t289, ptr %l166, !tbaa !21
  br label %bb86
bb86:
  %t291 = load i1, ptr %l166, !tbaa !21
  store i1 %t291, ptr %l3, !tbaa !21
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t293 = load { i64, [1 x i64] }, ptr %l28
  %t294 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t298 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2euseRef(ptr %v0, ptr %s0, ptr %t292, { i64, [1 x i64] } %t293, { i64, ptr } %t294)
  store i1 %t298, ptr %l171
  br label %bb87
bb87:
  %t299 = load i1, ptr %l171, !tbaa !21
  br i1 %t299, label %bb88, label %bb89
bb88:
  store i1 true, ptr %l172, !tbaa !21
  br label %bb90
bb89:
  %t300 = load i1, ptr %l3, !tbaa !21
  store i1 %t300, ptr %l172, !tbaa !21
  br label %bb90
bb90:
  %t302 = load i1, ptr %l172, !tbaa !21
  store i1 %t302, ptr %l3, !tbaa !21
  br label %bb96
bb91:
  br i1 true, label %bb92, label %bb93
bb92:
  br label %bb94
bb93:
  br label %bb95
bb94:
  br label %bb96
bb95:
  call void @__olang_check_failed(ptr @olang_loc_c174e5a3b34e67b9_6250aa572b15a6d5)
  unreachable
bb96:
  br label %bb102
bb97:
  br i1 true, label %bb98, label %bb99
bb98:
  br label %bb100
bb99:
  br label %bb101
bb100:
  br label %bb102
bb101:
  call void @__olang_check_failed(ptr @olang_loc_9206c849bcce77e8_1d8ffc9eff2b8ce4)
  unreachable
bb102:
  call void @__olang_scope_close(ptr %s10)
  br label %bb103
bb103:
  %t303 = load i64, ptr %l20, !tbaa !24
  %t305 = add i64 %t303, 1
  store i64 %t305, ptr %l20, !tbaa !24
  br label %bb41
bb104:
  %t307 = load i64, ptr %l17, !tbaa !24
  %t308 = load i64, ptr %l19, !tbaa !24
  %t311 = add i64 %t307, %t308
  store i64 %t311, ptr %l17, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb105
bb105:
  br label %bb34
bb106:
  %t313 = getelementptr %"compiler/mir:BasicBlock", ptr %l15, i32 0, i32 1
  %t314 = load { i64, [7 x i64] }, ptr %t313
  store { i64, [7 x i64] } %t314, ptr %l29
  %t316 = load { i64, [7 x i64] }, ptr %l29
  %t318 = extractvalue { i64, [7 x i64] } %t316, 0
  %t319 = icmp eq i64 %t318, 7
  br i1 %t319, label %bb107, label %bb108
bb107:
  %t321 = getelementptr { i64, [7 x i64] }, ptr %l29, i32 0, i32 1
  %t322 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t321, i32 0, i32 1
  %t323 = load i32, ptr %t322
  store i32 %t323, ptr %l30, !tbaa !23
  br label %bb109
bb108:
  br label %bb110
bb109:
  %t325 = load i32, ptr %l30, !tbaa !23
  %t327 = sext i32 %t325 to i64
  %t329 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t330 = load ptr, ptr %t329, !tbaa !27
  %t331 = getelementptr i1, ptr %t330, i64 %t327
  store i1 true, ptr %t331, !tbaa !31
  br label %bb115
bb110:
  br i1 true, label %bb111, label %bb112
bb111:
  br label %bb113
bb112:
  br label %bb114
bb113:
  br label %bb115
bb114:
  call void @__olang_check_failed(ptr @olang_loc_5234ed07c88e8ec3_fc55cf91bd0a7f1f)
  unreachable
bb115:
  call void @__olang_scope_close(ptr %s7)
  br label %bb116
bb116:
  %t332 = load i64, ptr %l14, !tbaa !24
  %t334 = add i64 %t332, 1
  store i64 %t334, ptr %l14, !tbaa !24
  br label %bb30
bb117:
  %t336 = load i64, ptr %l11, !tbaa !24
  %t337 = load i64, ptr %l13, !tbaa !24
  %t340 = add i64 %t336, %t337
  store i64 %t340, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb118
bb118:
  br label %bb23
bb119:
  %t342 = load ptr, ptr %l1, !tbaa !29
  %t344 = getelementptr %"compiler/mir:Fn", ptr %t342, i32 0, i32 7
  store ptr %t344, ptr %l31, !tbaa !29
  store i64 0, ptr %l32, !tbaa !24
  br label %bb120
bb120:
  store %olang.scope zeroinitializer, ptr %s24
  %t346 = load ptr, ptr %l31, !tbaa !29
  %t347 = load i64, ptr %l32, !tbaa !24
  %t350 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eRunFrom_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t346, i64 %t347)
  %t351 = extractvalue { i32, { i64, ptr } } %t350, 1
  %t352 = extractvalue { i32, { i64, ptr } } %t350, 0
  store i32 %t352, ptr %l196
  %t353 = icmp ne i32 %t352, 0
  br i1 %t353, label %bb122, label %ok.354
ok.354:
  store { i64, ptr } %t351, ptr %l195
  br label %bb121
bb121:
  %t355 = load { i64, ptr }, ptr %l195, !tbaa !27
  store { i64, ptr } %t355, ptr %l192, !tbaa !27
  br label %bb126
bb122:
  %t356 = load i32, ptr %l196, !tbaa !23
  %t357 = ashr i32 %t356, 16
  %t359 = icmp eq i32 %t357, 1
  br i1 %t359, label %bb123, label %bb124
bb123:
  br label %bb125
bb124:
  call void @__olang_check_failed(ptr @olang_loc_163846ebfcde4742_93f6cefa6f5e149e)
  unreachable
bb125:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s24)
  br label %bb142
bb126:
  %t361 = load { i64, ptr }, ptr %l192, !tbaa !27
  store { i64, ptr } %t361, ptr %l33, !tbaa !27
  %t362 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t364 = extractvalue { i64, ptr } %t362, 0
  store i64 %t364, ptr %l34, !tbaa !24
  store i64 0, ptr %l35, !tbaa !24
  br label %bb127
bb127:
  store %olang.scope zeroinitializer, ptr %s25
  %t366 = load i64, ptr %l35, !tbaa !24
  %t367 = load i64, ptr %l34, !tbaa !24
  %t370 = icmp slt i64 %t366, %t367
  %t372 = xor i1 %t370, true
  br i1 %t372, label %bb128, label %bb129
bb128:
  call void @__olang_scope_close(ptr %s25)
  br label %bb140
bb129:
  br label %bb130
bb130:
  %t374 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t374, ptr %l205, !tbaa !27
  %t375 = load i64, ptr %l35, !tbaa !24
  %t377 = getelementptr { i64, ptr }, ptr %l205, i32 0, i32 1
  %t378 = load ptr, ptr %t377, !tbaa !27
  %t379 = getelementptr %"compiler/mir:Local", ptr %t378, i64 %t375
  %t380 = load %"compiler/mir:Local", ptr %t379
  store %"compiler/mir:Local" %t380, ptr %l36
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t383 = getelementptr %"compiler/mir:Local", ptr %l36, i32 0, i32 4
  %t384 = load { i64, [1 x i64] }, ptr %t383
  %t387 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eisFrame(ptr %v0, ptr %t382, { i64, [1 x i64] } %t384)
  store i1 %t387, ptr %l210
  br label %bb131
bb131:
  %t388 = load i1, ptr %l210, !tbaa !21
  %t389 = xor i1 %t388, true
  br i1 %t389, label %bb132, label %bb133
bb132:
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t392 = getelementptr %"compiler/mir:Local", ptr %l36, i32 0, i32 4
  %t393 = load { i64, [1 x i64] }, ptr %t392
  %t394 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t398 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2euseRef(ptr %v0, ptr %s0, ptr %t391, { i64, [1 x i64] } %t393, { i64, ptr } %t394)
  store i1 %t398, ptr %l215
  br label %bb134
bb133:
  br label %bb138
bb134:
  %t399 = load i1, ptr %l215, !tbaa !21
  br i1 %t399, label %bb135, label %bb136
bb135:
  store i1 true, ptr %l216, !tbaa !21
  br label %bb137
bb136:
  %t400 = load i1, ptr %l3, !tbaa !21
  store i1 %t400, ptr %l216, !tbaa !21
  br label %bb137
bb137:
  %t402 = load i1, ptr %l216, !tbaa !21
  store i1 %t402, ptr %l3, !tbaa !21
  br label %bb138
bb138:
  call void @__olang_scope_close(ptr %s25)
  br label %bb139
bb139:
  %t403 = load i64, ptr %l35, !tbaa !24
  %t405 = add i64 %t403, 1
  store i64 %t405, ptr %l35, !tbaa !24
  br label %bb127
bb140:
  %t407 = load i64, ptr %l32, !tbaa !24
  %t408 = load i64, ptr %l34, !tbaa !24
  %t411 = add i64 %t407, %t408
  store i64 %t411, ptr %l32, !tbaa !24
  call void @__olang_scope_close(ptr %s24)
  br label %bb141
bb141:
  br label %bb120
bb142:
  store i64 0, ptr %l37, !tbaa !24
  %t413 = load ptr, ptr %l1, !tbaa !29
  %t415 = getelementptr %"compiler/mir:Fn", ptr %t413, i32 0, i32 8
  %t417 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t415)
  store i64 %t417, ptr %l225
  br label %bb143
bb143:
  %t418 = load i64, ptr %l225, !tbaa !24
  store i64 %t418, ptr %l38, !tbaa !24
  store i64 1, ptr %l39, !tbaa !24
  %t419 = load i64, ptr %l38, !tbaa !24
  %t420 = load i64, ptr %l37, !tbaa !24
  %t423 = icmp sgt i64 %t419, %t420
  br i1 %t423, label %bb144, label %bb145
bb144:
  %t425 = load i64, ptr %l39, !tbaa !24
  %t427 = icmp sgt i64 %t425, 0
  br i1 %t427, label %bb146, label %bb147
bb145:
  store i64 0, ptr %l229, !tbaa !24
  br label %bb149
bb146:
  %t429 = load i64, ptr %l38, !tbaa !24
  %t430 = load i64, ptr %l37, !tbaa !24
  %t433 = sub i64 %t429, %t430
  %t434 = load i64, ptr %l39, !tbaa !24
  %t437 = add i64 %t433, %t434
  %t439 = sub i64 %t437, 1
  %t440 = load i64, ptr %l39, !tbaa !24
  %t443 = sdiv i64 %t439, %t440
  store i64 %t443, ptr %l232, !tbaa !24
  br label %bb148
bb147:
  store i64 0, ptr %l232, !tbaa !24
  br label %bb148
bb148:
  %t445 = load i64, ptr %l232, !tbaa !24
  store i64 %t445, ptr %l229, !tbaa !24
  br label %bb149
bb149:
  %t446 = load i64, ptr %l229, !tbaa !24
  store i64 %t446, ptr %l40, !tbaa !24
  store i64 0, ptr %l41, !tbaa !24
  br label %bb150
bb150:
  store %olang.scope zeroinitializer, ptr %s29
  %t447 = load i64, ptr %l41, !tbaa !24
  %t448 = load i64, ptr %l40, !tbaa !24
  %t451 = icmp slt i64 %t447, %t448
  %t453 = xor i1 %t451, true
  br i1 %t453, label %bb151, label %bb152
bb151:
  call void @__olang_scope_close(ptr %s29)
  br label %bb172
bb152:
  br label %bb153
bb153:
  %t455 = load i64, ptr %l37, !tbaa !24
  %t456 = load i64, ptr %l41, !tbaa !24
  %t457 = load i64, ptr %l39, !tbaa !24
  %t460 = mul i64 %t456, %t457
  %t463 = add i64 %t455, %t460
  store i64 %t463, ptr %l42, !tbaa !24
  %t465 = load ptr, ptr %l1, !tbaa !29
  %t467 = getelementptr %"compiler/mir:Fn", ptr %t465, i32 0, i32 8
  %t468 = load i64, ptr %l42, !tbaa !24
  %t471 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t467, i64 %t468)
  store %"compiler/mir:ScopeInfo" %t471, ptr %l253
  br label %bb154
bb154:
  %t472 = getelementptr %"compiler/mir:ScopeInfo", ptr %l253, i32 0, i32 0
  %t473 = load i32, ptr %t472
  store i32 %t473, ptr %l43
  %t475 = load i32, ptr %l43
  %t477 = trunc i64 0 to i32
  %t478 = icmp eq i32 %t475, %t477
  %t480 = xor i1 %t478, true
  br i1 %t480, label %bb155, label %bb156
bb155:
  %t482 = load i32, ptr %l43
  %t484 = trunc i64 1 to i32
  %t485 = icmp eq i32 %t482, %t484
  %t487 = xor i1 %t485, true
  store i1 %t487, ptr %l258, !tbaa !21
  br label %bb157
bb156:
  store i1 false, ptr %l258, !tbaa !21
  br label %bb157
bb157:
  %t489 = load i1, ptr %l258, !tbaa !21
  br i1 %t489, label %bb158, label %bb159
bb158:
  call void @__olang_scope_close(ptr %s29)
  br label %bb171
bb159:
  br label %bb160
bb160:
  %t490 = load i64, ptr %l42, !tbaa !24
  %t492 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t493 = load ptr, ptr %t492, !tbaa !27
  %t494 = getelementptr i1, ptr %t493, i64 %t490
  %t495 = load i1, ptr %t494, !tbaa !31
  br i1 %t495, label %bb161, label %bb162
bb161:
  store i1 true, ptr %l264, !tbaa !21
  br label %bb166
bb162:
  %t497 = load i1, ptr %l3, !tbaa !21
  br i1 %t497, label %bb163, label %bb164
bb163:
  %t499 = load i64, ptr %l42, !tbaa !24
  %t500 = load ptr, ptr %l0, !tbaa !29
  %t502 = getelementptr %"compiler/emit:fnEm", ptr %t500, i32 0, i32 8
  %t503 = load i64, ptr %t502, !tbaa !24
  %t506 = icmp eq i64 %t499, %t503
  store i1 %t506, ptr %l266, !tbaa !21
  br label %bb165
bb164:
  store i1 false, ptr %l266, !tbaa !21
  br label %bb165
bb165:
  %t508 = load i1, ptr %l266, !tbaa !21
  store i1 %t508, ptr %l264, !tbaa !21
  br label %bb166
bb166:
  %t509 = load i1, ptr %l264, !tbaa !21
  br i1 %t509, label %bb167, label %bb168
bb167:
  call void @__olang_scope_close(ptr %s29)
  br label %bb171
bb168:
  br label %bb169
bb169:
  %t510 = load ptr, ptr %l0, !tbaa !29
  %t512 = getelementptr %"compiler/emit:fnEm", ptr %t510, i32 0, i32 24
  %t513 = load i64, ptr %l42, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t512, i64 %t513, i1 true)
  br label %bb170
bb170:
  call void @__olang_scope_close(ptr %s29)
  br label %bb171
bb171:
  %t516 = load i64, ptr %l41, !tbaa !24
  %t518 = add i64 %t516, 1
  store i64 %t518, ptr %l41, !tbaa !24
  br label %bb150
bb172:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l10 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } { i64 5, ptr @.d114 }, 1
  %t6 = extractvalue { i64, ptr } { i64 5, ptr @.d114 }, 0
  %t8 = extractvalue { i64, ptr } %a1, 1
  %t9 = extractvalue { i64, ptr } %a1, 0
  %t10 = add i64 %t6, %t9
  %t11 = extractvalue { i64, ptr } { i64 6, ptr @.d115 }, 1
  %t12 = extractvalue { i64, ptr } { i64 6, ptr @.d115 }, 0
  %t13 = add i64 %t10, %t12
  %t15 = extractvalue { i64, ptr } %a2, 1
  %t16 = extractvalue { i64, ptr } %a2, 0
  %t17 = add i64 %t13, %t16
  %t19 = extractvalue { i64, ptr } %a3, 1
  %t20 = extractvalue { i64, ptr } %a3, 0
  %t21 = add i64 %t17, %t20
  %t22 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t21)
  call void @olang_textcopy(ptr %t22, ptr %t5, i64 %t6)
  %t23 = getelementptr i8, ptr %t22, i64 %t6
  call void @olang_textcopy(ptr %t23, ptr %t8, i64 %t9)
  %t24 = getelementptr i8, ptr %t23, i64 %t9
  call void @olang_textcopy(ptr %t24, ptr %t11, i64 %t12)
  %t25 = getelementptr i8, ptr %t24, i64 %t12
  call void @olang_textcopy(ptr %t25, ptr %t15, i64 %t16)
  %t26 = getelementptr i8, ptr %t25, i64 %t16
  call void @olang_textcopy(ptr %t26, ptr %t19, i64 %t20)
  %t27 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t22, 1
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t31 = extractvalue { i64, ptr } %t28, 1
  %t32 = mul i64 %t30, 1
  %t33 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t32)
  call void @llvm.memcpy.p0.p0.i64(ptr %t33, ptr %t31, i64 %t32, i1 false)
  %t34 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  %t38 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v4, ptr %v4, ptr %a0, { i64, ptr } %t35)
  store { i64, ptr } %t38, ptr %l10
  br label %bb1
bb1:
  %t39 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t39, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2enarrowBF16(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = extractvalue { i64, ptr } { i64 14, ptr @.d116 }, 1
  %t4 = extractvalue { i64, ptr } { i64 14, ptr @.d116 }, 0
  %t6 = extractvalue { i64, ptr } %a1, 1
  %t7 = extractvalue { i64, ptr } %a1, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 7, ptr @.d117 }, 1
  %t10 = extractvalue { i64, ptr } { i64 7, ptr @.d117 }, 0
  %t11 = add i64 %t8, %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @olang_textcopy(ptr %t12, ptr %t3, i64 %t4)
  %t13 = getelementptr i8, ptr %t12, i64 %t4
  call void @olang_textcopy(ptr %t13, ptr %t6, i64 %t7)
  %t14 = getelementptr i8, ptr %t13, i64 %t7
  call void @olang_textcopy(ptr %t14, ptr %t9, i64 %t10)
  %t15 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t12, 1
  %t18 = extractvalue { i64, ptr } %t16, 0
  %t19 = extractvalue { i64, ptr } %t16, 1
  %t20 = mul i64 %t18, 1
  %t21 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t20)
  call void @llvm.memcpy.p0.p0.i64(ptr %t21, ptr %t19, i64 %t20, i1 false)
  %t22 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  %t26 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t1, { i64, ptr } %t23)
  store { i64, ptr } %t26, ptr %l17
  br label %bb1
bb1:
  %t27 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t27, ptr %l2, !tbaa !27
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t30 = extractvalue { i64, ptr } { i64 9, ptr @.d118 }, 1
  %t31 = extractvalue { i64, ptr } { i64 9, ptr @.d118 }, 0
  %t33 = extractvalue { i64, ptr } %t29, 1
  %t34 = extractvalue { i64, ptr } %t29, 0
  %t35 = add i64 %t31, %t34
  %t36 = extractvalue { i64, ptr } { i64 4, ptr @.d119 }, 1
  %t37 = extractvalue { i64, ptr } { i64 4, ptr @.d119 }, 0
  %t38 = add i64 %t35, %t37
  %t39 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t38)
  call void @olang_textcopy(ptr %t39, ptr %t30, i64 %t31)
  %t40 = getelementptr i8, ptr %t39, i64 %t31
  call void @olang_textcopy(ptr %t40, ptr %t33, i64 %t34)
  %t41 = getelementptr i8, ptr %t40, i64 %t34
  call void @olang_textcopy(ptr %t41, ptr %t36, i64 %t37)
  %t42 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t39, 1
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t46 = extractvalue { i64, ptr } %t43, 1
  %t47 = mul i64 %t45, 1
  %t48 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t47)
  call void @llvm.memcpy.p0.p0.i64(ptr %t48, ptr %t46, i64 %t47, i1 false)
  %t49 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  %t53 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t28, { i64, ptr } %t50)
  store { i64, ptr } %t53, ptr %l22
  br label %bb2
bb2:
  %t54 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t54, ptr %l3, !tbaa !27
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t57 = extractvalue { i64, ptr } { i64 8, ptr @.d120 }, 1
  %t58 = extractvalue { i64, ptr } { i64 8, ptr @.d120 }, 0
  %t60 = extractvalue { i64, ptr } %t56, 1
  %t61 = extractvalue { i64, ptr } %t56, 0
  %t62 = add i64 %t58, %t61
  %t63 = extractvalue { i64, ptr } { i64 3, ptr @.d121 }, 1
  %t64 = extractvalue { i64, ptr } { i64 3, ptr @.d121 }, 0
  %t65 = add i64 %t62, %t64
  %t66 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t65)
  call void @olang_textcopy(ptr %t66, ptr %t57, i64 %t58)
  %t67 = getelementptr i8, ptr %t66, i64 %t58
  call void @olang_textcopy(ptr %t67, ptr %t60, i64 %t61)
  %t68 = getelementptr i8, ptr %t67, i64 %t61
  call void @olang_textcopy(ptr %t68, ptr %t63, i64 %t64)
  %t69 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t66, 1
  %t72 = extractvalue { i64, ptr } %t70, 0
  %t73 = extractvalue { i64, ptr } %t70, 1
  %t74 = mul i64 %t72, 1
  %t75 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t74)
  call void @llvm.memcpy.p0.p0.i64(ptr %t75, ptr %t73, i64 %t74, i1 false)
  %t76 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  %t80 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t55, { i64, ptr } %t77)
  store { i64, ptr } %t80, ptr %l27
  br label %bb3
bb3:
  %t81 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = extractvalue { i64, ptr } { i64 8, ptr @.d122 }, 1
  %t85 = extractvalue { i64, ptr } { i64 8, ptr @.d122 }, 0
  %t87 = extractvalue { i64, ptr } %t81, 1
  %t88 = extractvalue { i64, ptr } %t81, 0
  %t89 = add i64 %t85, %t88
  %t90 = extractvalue { i64, ptr } { i64 7, ptr @.d123 }, 1
  %t91 = extractvalue { i64, ptr } { i64 7, ptr @.d123 }, 0
  %t92 = add i64 %t89, %t91
  %t93 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t92)
  call void @olang_textcopy(ptr %t93, ptr %t84, i64 %t85)
  %t94 = getelementptr i8, ptr %t93, i64 %t85
  call void @olang_textcopy(ptr %t94, ptr %t87, i64 %t88)
  %t95 = getelementptr i8, ptr %t94, i64 %t88
  call void @olang_textcopy(ptr %t95, ptr %t90, i64 %t91)
  %t96 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t93, 1
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t100 = extractvalue { i64, ptr } %t97, 1
  %t101 = mul i64 %t99, 1
  %t102 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t101)
  call void @llvm.memcpy.p0.p0.i64(ptr %t102, ptr %t100, i64 %t101, i1 false)
  %t103 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  %t107 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t82, { i64, ptr } %t104)
  store { i64, ptr } %t107, ptr %l32
  br label %bb4
bb4:
  %t108 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t112 = extractvalue { i64, ptr } { i64 8, ptr @.d124 }, 1
  %t113 = extractvalue { i64, ptr } { i64 8, ptr @.d124 }, 0
  %t115 = extractvalue { i64, ptr } %t110, 1
  %t116 = extractvalue { i64, ptr } %t110, 0
  %t117 = add i64 %t113, %t116
  %t118 = extractvalue { i64, ptr } { i64 2, ptr @.d125 }, 1
  %t119 = extractvalue { i64, ptr } { i64 2, ptr @.d125 }, 0
  %t120 = add i64 %t117, %t119
  %t122 = extractvalue { i64, ptr } %t108, 1
  %t123 = extractvalue { i64, ptr } %t108, 0
  %t124 = add i64 %t120, %t123
  %t125 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t124)
  call void @olang_textcopy(ptr %t125, ptr %t112, i64 %t113)
  %t126 = getelementptr i8, ptr %t125, i64 %t113
  call void @olang_textcopy(ptr %t126, ptr %t115, i64 %t116)
  %t127 = getelementptr i8, ptr %t126, i64 %t116
  call void @olang_textcopy(ptr %t127, ptr %t118, i64 %t119)
  %t128 = getelementptr i8, ptr %t127, i64 %t119
  call void @olang_textcopy(ptr %t128, ptr %t122, i64 %t123)
  %t129 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t125, 1
  %t132 = extractvalue { i64, ptr } %t130, 0
  %t133 = extractvalue { i64, ptr } %t130, 1
  %t134 = mul i64 %t132, 1
  %t135 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t134)
  call void @llvm.memcpy.p0.p0.i64(ptr %t135, ptr %t133, i64 %t134, i1 false)
  %t136 = insertvalue { i64, ptr } undef, i64 %t132, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t135, 1
  %t140 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t109, { i64, ptr } %t137)
  store { i64, ptr } %t140, ptr %l38
  br label %bb5
bb5:
  %t141 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = extractvalue { i64, ptr } { i64 9, ptr @.d126 }, 1
  %t145 = extractvalue { i64, ptr } { i64 9, ptr @.d126 }, 0
  %t147 = extractvalue { i64, ptr } %t141, 1
  %t148 = extractvalue { i64, ptr } %t141, 0
  %t149 = add i64 %t145, %t148
  %t150 = extractvalue { i64, ptr } { i64 4, ptr @.d127 }, 1
  %t151 = extractvalue { i64, ptr } { i64 4, ptr @.d127 }, 0
  %t152 = add i64 %t149, %t151
  %t153 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t152)
  call void @olang_textcopy(ptr %t153, ptr %t144, i64 %t145)
  %t154 = getelementptr i8, ptr %t153, i64 %t145
  call void @olang_textcopy(ptr %t154, ptr %t147, i64 %t148)
  %t155 = getelementptr i8, ptr %t154, i64 %t148
  call void @olang_textcopy(ptr %t155, ptr %t150, i64 %t151)
  %t156 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t153, 1
  %t159 = extractvalue { i64, ptr } %t157, 0
  %t160 = extractvalue { i64, ptr } %t157, 1
  %t161 = mul i64 %t159, 1
  %t162 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t161)
  call void @llvm.memcpy.p0.p0.i64(ptr %t162, ptr %t160, i64 %t161, i1 false)
  %t163 = insertvalue { i64, ptr } undef, i64 %t159, 0
  %t164 = insertvalue { i64, ptr } %t163, ptr %t162, 1
  %t167 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t142, { i64, ptr } %t164)
  store { i64, ptr } %t167, ptr %l43
  br label %bb6
bb6:
  %t168 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t168, ptr %l7, !tbaa !27
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t171 = extractvalue { i64, ptr } { i64 7, ptr @.d128 }, 1
  %t172 = extractvalue { i64, ptr } { i64 7, ptr @.d128 }, 0
  %t174 = extractvalue { i64, ptr } %t170, 1
  %t175 = extractvalue { i64, ptr } %t170, 0
  %t176 = add i64 %t172, %t175
  %t177 = extractvalue { i64, ptr } { i64 4, ptr @.d129 }, 1
  %t178 = extractvalue { i64, ptr } { i64 4, ptr @.d129 }, 0
  %t179 = add i64 %t176, %t178
  %t180 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t179)
  call void @olang_textcopy(ptr %t180, ptr %t171, i64 %t172)
  %t181 = getelementptr i8, ptr %t180, i64 %t172
  call void @olang_textcopy(ptr %t181, ptr %t174, i64 %t175)
  %t182 = getelementptr i8, ptr %t181, i64 %t175
  call void @olang_textcopy(ptr %t182, ptr %t177, i64 %t178)
  %t183 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t180, 1
  %t186 = extractvalue { i64, ptr } %t184, 0
  %t187 = extractvalue { i64, ptr } %t184, 1
  %t188 = mul i64 %t186, 1
  %t189 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t188)
  call void @llvm.memcpy.p0.p0.i64(ptr %t189, ptr %t187, i64 %t188, i1 false)
  %t190 = insertvalue { i64, ptr } undef, i64 %t186, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr %t189, 1
  %t194 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t169, { i64, ptr } %t191)
  store { i64, ptr } %t194, ptr %l48
  br label %bb7
bb7:
  %t195 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t195, ptr %l8, !tbaa !27
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t198 = extractvalue { i64, ptr } { i64 8, ptr @.d130 }, 1
  %t199 = extractvalue { i64, ptr } { i64 8, ptr @.d130 }, 0
  %t201 = extractvalue { i64, ptr } %t197, 1
  %t202 = extractvalue { i64, ptr } %t197, 0
  %t203 = add i64 %t199, %t202
  %t204 = extractvalue { i64, ptr } { i64 12, ptr @.d131 }, 1
  %t205 = extractvalue { i64, ptr } { i64 12, ptr @.d131 }, 0
  %t206 = add i64 %t203, %t205
  %t207 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t206)
  call void @olang_textcopy(ptr %t207, ptr %t198, i64 %t199)
  %t208 = getelementptr i8, ptr %t207, i64 %t199
  call void @olang_textcopy(ptr %t208, ptr %t201, i64 %t202)
  %t209 = getelementptr i8, ptr %t208, i64 %t202
  call void @olang_textcopy(ptr %t209, ptr %t204, i64 %t205)
  %t210 = insertvalue { i64, ptr } undef, i64 %t206, 0
  %t211 = insertvalue { i64, ptr } %t210, ptr %t207, 1
  %t213 = extractvalue { i64, ptr } %t211, 0
  %t214 = extractvalue { i64, ptr } %t211, 1
  %t215 = mul i64 %t213, 1
  %t216 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t215)
  call void @llvm.memcpy.p0.p0.i64(ptr %t216, ptr %t214, i64 %t215, i1 false)
  %t217 = insertvalue { i64, ptr } undef, i64 %t213, 0
  %t218 = insertvalue { i64, ptr } %t217, ptr %t216, 1
  %t221 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t196, { i64, ptr } %t218)
  store { i64, ptr } %t221, ptr %l53
  br label %bb8
bb8:
  %t222 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = extractvalue { i64, ptr } { i64 13, ptr @.d132 }, 1
  %t226 = extractvalue { i64, ptr } { i64 13, ptr @.d132 }, 0
  %t228 = extractvalue { i64, ptr } %t222, 1
  %t229 = extractvalue { i64, ptr } %t222, 0
  %t230 = add i64 %t226, %t229
  %t231 = extractvalue { i64, ptr } { i64 12, ptr @.d133 }, 1
  %t232 = extractvalue { i64, ptr } { i64 12, ptr @.d133 }, 0
  %t233 = add i64 %t230, %t232
  %t234 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t233)
  call void @olang_textcopy(ptr %t234, ptr %t225, i64 %t226)
  %t235 = getelementptr i8, ptr %t234, i64 %t226
  call void @olang_textcopy(ptr %t235, ptr %t228, i64 %t229)
  %t236 = getelementptr i8, ptr %t235, i64 %t229
  call void @olang_textcopy(ptr %t236, ptr %t231, i64 %t232)
  %t237 = insertvalue { i64, ptr } undef, i64 %t233, 0
  %t238 = insertvalue { i64, ptr } %t237, ptr %t234, 1
  %t240 = extractvalue { i64, ptr } %t238, 0
  %t241 = extractvalue { i64, ptr } %t238, 1
  %t242 = mul i64 %t240, 1
  %t243 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t242)
  call void @llvm.memcpy.p0.p0.i64(ptr %t243, ptr %t241, i64 %t242, i1 false)
  %t244 = insertvalue { i64, ptr } undef, i64 %t240, 0
  %t245 = insertvalue { i64, ptr } %t244, ptr %t243, 1
  %t248 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t223, { i64, ptr } %t245)
  store { i64, ptr } %t248, ptr %l58
  br label %bb9
bb9:
  %t249 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t252 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t253 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t254 = extractvalue { i64, ptr } { i64 10, ptr @.d134 }, 1
  %t255 = extractvalue { i64, ptr } { i64 10, ptr @.d134 }, 0
  %t257 = extractvalue { i64, ptr } %t249, 1
  %t258 = extractvalue { i64, ptr } %t249, 0
  %t259 = add i64 %t255, %t258
  %t260 = extractvalue { i64, ptr } { i64 6, ptr @.d135 }, 1
  %t261 = extractvalue { i64, ptr } { i64 6, ptr @.d135 }, 0
  %t262 = add i64 %t259, %t261
  %t264 = extractvalue { i64, ptr } %t252, 1
  %t265 = extractvalue { i64, ptr } %t252, 0
  %t266 = add i64 %t262, %t265
  %t267 = extractvalue { i64, ptr } { i64 6, ptr @.d136 }, 1
  %t268 = extractvalue { i64, ptr } { i64 6, ptr @.d136 }, 0
  %t269 = add i64 %t266, %t268
  %t271 = extractvalue { i64, ptr } %t253, 1
  %t272 = extractvalue { i64, ptr } %t253, 0
  %t273 = add i64 %t269, %t272
  %t274 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t273)
  call void @olang_textcopy(ptr %t274, ptr %t254, i64 %t255)
  %t275 = getelementptr i8, ptr %t274, i64 %t255
  call void @olang_textcopy(ptr %t275, ptr %t257, i64 %t258)
  %t276 = getelementptr i8, ptr %t275, i64 %t258
  call void @olang_textcopy(ptr %t276, ptr %t260, i64 %t261)
  %t277 = getelementptr i8, ptr %t276, i64 %t261
  call void @olang_textcopy(ptr %t277, ptr %t264, i64 %t265)
  %t278 = getelementptr i8, ptr %t277, i64 %t265
  call void @olang_textcopy(ptr %t278, ptr %t267, i64 %t268)
  %t279 = getelementptr i8, ptr %t278, i64 %t268
  call void @olang_textcopy(ptr %t279, ptr %t271, i64 %t272)
  %t280 = insertvalue { i64, ptr } undef, i64 %t273, 0
  %t281 = insertvalue { i64, ptr } %t280, ptr %t274, 1
  %t283 = extractvalue { i64, ptr } %t281, 0
  %t284 = extractvalue { i64, ptr } %t281, 1
  %t285 = mul i64 %t283, 1
  %t286 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t285)
  call void @llvm.memcpy.p0.p0.i64(ptr %t286, ptr %t284, i64 %t285, i1 false)
  %t287 = insertvalue { i64, ptr } undef, i64 %t283, 0
  %t288 = insertvalue { i64, ptr } %t287, ptr %t286, 1
  %t291 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t250, { i64, ptr } %t288)
  store { i64, ptr } %t291, ptr %l65
  br label %bb10
bb10:
  %t292 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = extractvalue { i64, ptr } { i64 10, ptr @.d137 }, 1
  %t296 = extractvalue { i64, ptr } { i64 10, ptr @.d137 }, 0
  %t298 = extractvalue { i64, ptr } %t292, 1
  %t299 = extractvalue { i64, ptr } %t292, 0
  %t300 = add i64 %t296, %t299
  %t301 = extractvalue { i64, ptr } { i64 7, ptr @.d138 }, 1
  %t302 = extractvalue { i64, ptr } { i64 7, ptr @.d138 }, 0
  %t303 = add i64 %t300, %t302
  %t304 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t303)
  call void @olang_textcopy(ptr %t304, ptr %t295, i64 %t296)
  %t305 = getelementptr i8, ptr %t304, i64 %t296
  call void @olang_textcopy(ptr %t305, ptr %t298, i64 %t299)
  %t306 = getelementptr i8, ptr %t305, i64 %t299
  call void @olang_textcopy(ptr %t306, ptr %t301, i64 %t302)
  %t307 = insertvalue { i64, ptr } undef, i64 %t303, 0
  %t308 = insertvalue { i64, ptr } %t307, ptr %t304, 1
  %t310 = extractvalue { i64, ptr } %t308, 0
  %t311 = extractvalue { i64, ptr } %t308, 1
  %t312 = mul i64 %t310, 1
  %t313 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t312)
  call void @llvm.memcpy.p0.p0.i64(ptr %t313, ptr %t311, i64 %t312, i1 false)
  %t314 = insertvalue { i64, ptr } undef, i64 %t310, 0
  %t315 = insertvalue { i64, ptr } %t314, ptr %t313, 1
  %t318 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t293, { i64, ptr } %t315)
  store { i64, ptr } %t318, ptr %l70
  br label %bb11
bb11:
  %t319 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t320 = load ptr, ptr %l0, !tbaa !29
  %t322 = extractvalue { i64, ptr } { i64 12, ptr @.d139 }, 1
  %t323 = extractvalue { i64, ptr } { i64 12, ptr @.d139 }, 0
  %t325 = extractvalue { i64, ptr } %t319, 1
  %t326 = extractvalue { i64, ptr } %t319, 0
  %t327 = add i64 %t323, %t326
  %t328 = extractvalue { i64, ptr } { i64 10, ptr @.d140 }, 1
  %t329 = extractvalue { i64, ptr } { i64 10, ptr @.d140 }, 0
  %t330 = add i64 %t327, %t329
  %t331 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t330)
  call void @olang_textcopy(ptr %t331, ptr %t322, i64 %t323)
  %t332 = getelementptr i8, ptr %t331, i64 %t323
  call void @olang_textcopy(ptr %t332, ptr %t325, i64 %t326)
  %t333 = getelementptr i8, ptr %t332, i64 %t326
  call void @olang_textcopy(ptr %t333, ptr %t328, i64 %t329)
  %t334 = insertvalue { i64, ptr } undef, i64 %t330, 0
  %t335 = insertvalue { i64, ptr } %t334, ptr %t331, 1
  %t337 = extractvalue { i64, ptr } %t335, 0
  %t338 = extractvalue { i64, ptr } %t335, 1
  %t339 = mul i64 %t337, 1
  %t340 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t339)
  call void @llvm.memcpy.p0.p0.i64(ptr %t340, ptr %t338, i64 %t339, i1 false)
  %t341 = insertvalue { i64, ptr } undef, i64 %t337, 0
  %t342 = insertvalue { i64, ptr } %t341, ptr %t340, 1
  %t345 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v2, ptr %v2, ptr %t320, { i64, ptr } %t342)
  store { i64, ptr } %t345, ptr %l75
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  %t346 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t346, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2enewArray(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1, i32 %a2, { i64, [4 x i64] } %a3, { i64, [4 x i64] } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, [4 x i64] }
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca ptr
  %l6 = alloca i32
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i1
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l30 = alloca i32
  %l33 = alloca i1
  %l34 = alloca i32
  %l37 = alloca i32
  %l39 = alloca ptr
  %l42 = alloca i32
  %l43 = alloca i32
  %l44 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l52 = alloca i32
  %l53 = alloca { i64, ptr }
  %l54 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l58 = alloca i64
  %l61 = alloca { i64, ptr }
  %l62 = alloca i1
  %l70 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l73 = alloca i64
  %l74 = alloca { i64, ptr }
  %l78 = alloca i1
  %l84 = alloca i1
  %l92 = alloca { i64, ptr }
  %l94 = alloca i64
  %l100 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l111 = alloca i64
  %l116 = alloca i1
  %l124 = alloca { i64, ptr }
  %l126 = alloca i64
  %l130 = alloca i1
  %l132 = alloca { i64, ptr }
  %l136 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l146 = alloca { i64, ptr }
  %l148 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l159 = alloca { i64, ptr }
  %l165 = alloca { i64, ptr }
  %l180 = alloca { i64, ptr }
  %l190 = alloca ptr
  %l195 = alloca { i64, ptr }
  %l207 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [4 x i64] } %a3, ptr %l3
  store { i64, [4 x i64] } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l5, !tbaa !29
  %t9 = load ptr, ptr %l5, !tbaa !29
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t9, i32 %a2)
  store i32 %t13, ptr %l30
  br label %bb1
bb1:
  %t14 = load i32, ptr %l30, !tbaa !23
  store i32 %t14, ptr %l6, !tbaa !23
  %t15 = load ptr, ptr %l5, !tbaa !29
  %t16 = load i32, ptr %l6, !tbaa !23
  %t19 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l33
  br label %bb2
bb2:
  %t20 = load i1, ptr %l33, !tbaa !21
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t21 = load ptr, ptr %l5, !tbaa !29
  %t22 = load i32, ptr %l6, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l37
  br label %bb5
bb4:
  %t26 = load i32, ptr %l6, !tbaa !23
  store i32 %t26, ptr %l34, !tbaa !23
  br label %bb6
bb5:
  %t28 = load i32, ptr %l37, !tbaa !23
  store i32 %t28, ptr %l34, !tbaa !23
  br label %bb6
bb6:
  %t29 = load i32, ptr %l34, !tbaa !23
  %t30 = load ptr, ptr %l5, !tbaa !29
  store ptr %t30, ptr %l39, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t35 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t31, i32 %t29)
  store i32 %t35, ptr %l42
  br label %bb7
bb7:
  %t36 = load ptr, ptr %l39, !tbaa !29
  %t37 = load i32, ptr %l42, !tbaa !23
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t38, ptr %l43
  br label %bb8
bb8:
  %t39 = load i32, ptr %l43, !tbaa !23
  store i32 %t39, ptr %l8, !tbaa !23
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l44, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load { i64, [4 x i64] }, ptr %l3
  %t43 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t47 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s0, ptr %t41, { i64, [4 x i64] } %t42, i32 %t43)
  store { i64, ptr } %t47, ptr %l48
  br label %bb9
bb9:
  %t48 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 0
  %t50 = extractvalue { i64, ptr } %t48, 1
  %t51 = mul i64 %t49, 1
  %t52 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t51)
  call void @llvm.memcpy.p0.p0.i64(ptr %t52, ptr %t50, i64 %t51, i1 false)
  %t53 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  store { i64, ptr } %t54, ptr %l49, !tbaa !27
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load { i64, [4 x i64] }, ptr %l3
  %t59 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t55, { i64, [4 x i64] } %t56)
  store i32 %t59, ptr %l52
  br label %bb10
bb10:
  %t60 = load ptr, ptr %l44, !tbaa !29
  %t61 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t62 = load i32, ptr %l52, !tbaa !23
  %t63 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eindex(ptr %v0, ptr %s0, ptr %s0, ptr %t60, { i64, ptr } %t61, i32 %t62)
  store { i64, ptr } %t63, ptr %l53
  br label %bb11
bb11:
  %t64 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t64, ptr %l9, !tbaa !27
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l54, !tbaa !29
  %t66 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t66, ptr %l55, !tbaa !27
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i32, ptr %l8, !tbaa !23
  %t71 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t67, i32 %t68)
  store i64 %t71, ptr %l58
  br label %bb12
bb12:
  %t72 = extractvalue { i64, ptr } { i64 8, ptr @.d141 }, 1
  %t73 = extractvalue { i64, ptr } { i64 8, ptr @.d141 }, 0
  %t74 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t74, 1
  %t76 = extractvalue { i64, ptr } %t74, 0
  %t77 = add i64 %t73, %t76
  %t78 = extractvalue { i64, ptr } { i64 2, ptr @.d142 }, 1
  %t79 = extractvalue { i64, ptr } { i64 2, ptr @.d142 }, 0
  %t80 = add i64 %t77, %t79
  %t81 = load i64, ptr %l58, !tbaa !24
  %t82 = call i64 @__olang_fmt_i64(ptr null, i64 %t81)
  %t83 = add i64 %t80, %t82
  %t84 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t83)
  call void @olang_textcopy(ptr %t84, ptr %t72, i64 %t73)
  %t85 = getelementptr i8, ptr %t84, i64 %t73
  call void @olang_textcopy(ptr %t85, ptr %t75, i64 %t76)
  %t86 = getelementptr i8, ptr %t85, i64 %t76
  call void @olang_textcopy(ptr %t86, ptr %t78, i64 %t79)
  %t87 = getelementptr i8, ptr %t86, i64 %t79
  %t88 = call i64 @__olang_fmt_i64(ptr %t87, i64 %t81)
  %t89 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t84, 1
  %t92 = extractvalue { i64, ptr } %t90, 0
  %t93 = extractvalue { i64, ptr } %t90, 1
  %t94 = mul i64 %t92, 1
  %t95 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t94)
  call void @llvm.memcpy.p0.p0.i64(ptr %t95, ptr %t93, i64 %t94, i1 false)
  %t96 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  %t98 = load ptr, ptr %l54, !tbaa !29
  %t100 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t98, { i64, ptr } %t97)
  store { i64, ptr } %t100, ptr %l61
  br label %bb13
bb13:
  %t101 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t101, ptr %l10, !tbaa !27
  %t102 = load { i64, [4 x i64] }, ptr %l4
  %t104 = extractvalue { i64, [4 x i64] } %t102, 0
  %t105 = icmp eq i64 %t104, 2
  br i1 %t105, label %bb14, label %bb15
bb14:
  %t107 = getelementptr { i64, [4 x i64] }, ptr %l4, i32 0, i32 1
  %t108 = getelementptr { i32, i64 }, ptr %t107, i32 0, i32 1
  %t109 = load i64, ptr %t108
  store i64 %t109, ptr %l11, !tbaa !24
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t111 = load i64, ptr %l11, !tbaa !24
  %t113 = icmp eq i64 %t111, 0
  store i1 %t113, ptr %l62, !tbaa !21
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_7367d2b2f6aa7e57_e9ab633458e0a533)
  unreachable
bb22:
  %t115 = load i1, ptr %l62, !tbaa !21
  store i1 %t115, ptr %l12, !tbaa !21
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t120 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %s0, ptr %t116, { i64, [1 x i64] } %a1)
  store { i64, ptr } %t120, ptr %l70
  br label %bb23
bb23:
  %t121 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t121, ptr %l13, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d143 }, ptr %l71, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t122, ptr %l72, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  store i64 %t124, ptr %l73, !tbaa !24
  %t125 = load i64, ptr %l73, !tbaa !24
  %t126 = mul i64 %t125, 1
  %t127 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t126)
  %t128 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  store { i64, ptr } %t129, ptr %l74, !tbaa !27
  %t130 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = load i64, ptr %l73, !tbaa !24
  %t135 = mul i64 %t134, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t131, ptr %t133, i64 %t135, i1 false)
  %t136 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t136, ptr %l14, !tbaa !27
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/emit:fnEm", ptr %t137, i32 0, i32 0
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t142 = getelementptr %"compiler/emit:Emitter", ptr %t140, i32 0, i32 46
  %t143 = load i1, ptr %t142, !tbaa !21
  br i1 %t143, label %bb24, label %bb25
bb24:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/emit:fnEm", ptr %t145, i32 0, i32 0
  %t148 = load ptr, ptr %t147, !tbaa !29
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/emit:fnEm", ptr %t149, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !29
  %t154 = getelementptr %"compiler/mir:Fn", ptr %t152, i32 0, i32 2
  %t155 = load i64, ptr %t154, !tbaa !24
  %t158 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eretires(ptr %v0, ptr %t148, i64 %t155)
  store i1 %t158, ptr %l84
  br label %bb26
bb25:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb27
bb26:
  %t159 = load i1, ptr %l84, !tbaa !21
  store i1 %t159, ptr %l78, !tbaa !21
  br label %bb27
bb27:
  %t160 = load i1, ptr %l78, !tbaa !21
  br i1 %t160, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s4
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/emit:fnEm", ptr %t161, i32 0, i32 0
  %t164 = load ptr, ptr %t163, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s4, ptr %t164, { i64, ptr } { i64 21, ptr @.d144 })
  br label %bb30
bb29:
  %t166 = load i1, ptr %l12, !tbaa !21
  br i1 %t166, label %bb39, label %bb40
bb30:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t170 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t171 = extractvalue { i64, ptr } { i64 36, ptr @.d145 }, 1
  %t172 = extractvalue { i64, ptr } { i64 36, ptr @.d145 }, 0
  %t174 = extractvalue { i64, ptr } %t169, 1
  %t175 = extractvalue { i64, ptr } %t169, 0
  %t176 = add i64 %t172, %t175
  %t177 = extractvalue { i64, ptr } { i64 6, ptr @.d146 }, 1
  %t178 = extractvalue { i64, ptr } { i64 6, ptr @.d146 }, 0
  %t179 = add i64 %t176, %t178
  %t181 = extractvalue { i64, ptr } %t170, 1
  %t182 = extractvalue { i64, ptr } %t170, 0
  %t183 = add i64 %t179, %t182
  %t184 = extractvalue { i64, ptr } { i64 1, ptr @.d147 }, 1
  %t185 = extractvalue { i64, ptr } { i64 1, ptr @.d147 }, 0
  %t186 = add i64 %t183, %t185
  %t187 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t186)
  call void @olang_textcopy(ptr %t187, ptr %t171, i64 %t172)
  %t188 = getelementptr i8, ptr %t187, i64 %t172
  call void @olang_textcopy(ptr %t188, ptr %t174, i64 %t175)
  %t189 = getelementptr i8, ptr %t188, i64 %t175
  call void @olang_textcopy(ptr %t189, ptr %t177, i64 %t178)
  %t190 = getelementptr i8, ptr %t189, i64 %t178
  call void @olang_textcopy(ptr %t190, ptr %t181, i64 %t182)
  %t191 = getelementptr i8, ptr %t190, i64 %t182
  call void @olang_textcopy(ptr %t191, ptr %t184, i64 %t185)
  %t192 = insertvalue { i64, ptr } undef, i64 %t186, 0
  %t193 = insertvalue { i64, ptr } %t192, ptr %t187, 1
  %t195 = extractvalue { i64, ptr } %t193, 0
  %t196 = extractvalue { i64, ptr } %t193, 1
  %t197 = mul i64 %t195, 1
  %t198 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t197)
  call void @llvm.memcpy.p0.p0.i64(ptr %t198, ptr %t196, i64 %t197, i1 false)
  %t199 = insertvalue { i64, ptr } undef, i64 %t195, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr %t198, 1
  %t203 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t168, { i64, ptr } %t200)
  store { i64, ptr } %t203, ptr %l92
  br label %bb31
bb31:
  %t204 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t205 = extractvalue { i64, ptr } %t204, 0
  %t206 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t207 = extractvalue { i64, ptr } %t206, 0
  store i64 %t207, ptr %l94, !tbaa !24
  %t209 = load i64, ptr %l94, !tbaa !24
  %t210 = icmp eq i64 %t205, %t209
  br i1 %t210, label %bb32, label %bb33
bb32:
  %t212 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t213 = load ptr, ptr %t212, !tbaa !27
  %t214 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = load i64, ptr %l94, !tbaa !24
  %t217 = mul i64 %t216, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t213, ptr %t215, i64 %t217, i1 false)
  br label %bb34
bb33:
  %t218 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t218, ptr %l14, !tbaa !27
  br label %bb34
bb34:
  %t219 = load i1, ptr %l12, !tbaa !21
  br i1 %t219, label %bb35, label %bb36
bb35:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t223 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t227 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epair(ptr %v0, ptr %s0, ptr %s0, ptr %v1, ptr %t221, { i64, ptr } %t222, { i64, ptr } %t223)
  store { i64, ptr } %t227, ptr %l100
  br label %bb37
bb36:
  br label %bb38
bb37:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t228 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t228, ptr %rv
  br label %ret
bb38:
  call void @__olang_scope_close(ptr %s4)
  br label %bb47
bb39:
  store %olang.scope zeroinitializer, ptr %s8
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"compiler/emit:fnEm", ptr %t229, i32 0, i32 0
  %t232 = load ptr, ptr %t231, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s8, ptr %t232, { i64, ptr } { i64 26, ptr @.d148 })
  br label %bb41
bb40:
  br label %bb46
bb41:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t236 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t237 = extractvalue { i64, ptr } { i64 41, ptr @.d149 }, 1
  %t238 = extractvalue { i64, ptr } { i64 41, ptr @.d149 }, 0
  %t240 = extractvalue { i64, ptr } %t235, 1
  %t241 = extractvalue { i64, ptr } %t235, 0
  %t242 = add i64 %t238, %t241
  %t243 = extractvalue { i64, ptr } { i64 6, ptr @.d150 }, 1
  %t244 = extractvalue { i64, ptr } { i64 6, ptr @.d150 }, 0
  %t245 = add i64 %t242, %t244
  %t247 = extractvalue { i64, ptr } %t236, 1
  %t248 = extractvalue { i64, ptr } %t236, 0
  %t249 = add i64 %t245, %t248
  %t250 = extractvalue { i64, ptr } { i64 1, ptr @.d151 }, 1
  %t251 = extractvalue { i64, ptr } { i64 1, ptr @.d151 }, 0
  %t252 = add i64 %t249, %t251
  %t253 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t252)
  call void @olang_textcopy(ptr %t253, ptr %t237, i64 %t238)
  %t254 = getelementptr i8, ptr %t253, i64 %t238
  call void @olang_textcopy(ptr %t254, ptr %t240, i64 %t241)
  %t255 = getelementptr i8, ptr %t254, i64 %t241
  call void @olang_textcopy(ptr %t255, ptr %t243, i64 %t244)
  %t256 = getelementptr i8, ptr %t255, i64 %t244
  call void @olang_textcopy(ptr %t256, ptr %t247, i64 %t248)
  %t257 = getelementptr i8, ptr %t256, i64 %t248
  call void @olang_textcopy(ptr %t257, ptr %t250, i64 %t251)
  %t258 = insertvalue { i64, ptr } undef, i64 %t252, 0
  %t259 = insertvalue { i64, ptr } %t258, ptr %t253, 1
  %t261 = extractvalue { i64, ptr } %t259, 0
  %t262 = extractvalue { i64, ptr } %t259, 1
  %t263 = mul i64 %t261, 1
  %t264 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t263)
  call void @llvm.memcpy.p0.p0.i64(ptr %t264, ptr %t262, i64 %t263, i1 false)
  %t265 = insertvalue { i64, ptr } undef, i64 %t261, 0
  %t266 = insertvalue { i64, ptr } %t265, ptr %t264, 1
  %t269 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t234, { i64, ptr } %t266)
  store { i64, ptr } %t269, ptr %l109
  br label %bb42
bb42:
  %t270 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t271 = extractvalue { i64, ptr } %t270, 0
  %t272 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t273 = extractvalue { i64, ptr } %t272, 0
  store i64 %t273, ptr %l111, !tbaa !24
  %t275 = load i64, ptr %l111, !tbaa !24
  %t276 = icmp eq i64 %t271, %t275
  br i1 %t276, label %bb43, label %bb44
bb43:
  %t278 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t281 = load ptr, ptr %t280, !tbaa !27
  %t282 = load i64, ptr %l111, !tbaa !24
  %t283 = mul i64 %t282, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t279, ptr %t281, i64 %t283, i1 false)
  br label %bb45
bb44:
  %t284 = load { i64, ptr }, ptr %l109, !tbaa !27
  store { i64, ptr } %t284, ptr %l14, !tbaa !27
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s8)
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t285 = load i1, ptr %l12, !tbaa !21
  %t287 = xor i1 %t285, true
  br i1 %t287, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s10
  %t289 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t291 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s10, { i64, ptr } %t289, { i64, ptr } { i64 0, ptr @.d152 })
  store i1 %t291, ptr %l116
  br label %bb50
bb49:
  br label %bb86
bb50:
  %t292 = load i1, ptr %l116, !tbaa !21
  br i1 %t292, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s11
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = getelementptr %"compiler/emit:fnEm", ptr %t293, i32 0, i32 0
  %t296 = load ptr, ptr %t295, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s11, ptr %t296, { i64, ptr } { i64 19, ptr @.d153 })
  br label %bb53
bb52:
  br label %bb58
bb53:
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t299 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t300 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t301 = extractvalue { i64, ptr } { i64 34, ptr @.d154 }, 1
  %t302 = extractvalue { i64, ptr } { i64 34, ptr @.d154 }, 0
  %t304 = extractvalue { i64, ptr } %t299, 1
  %t305 = extractvalue { i64, ptr } %t299, 0
  %t306 = add i64 %t302, %t305
  %t307 = extractvalue { i64, ptr } { i64 6, ptr @.d155 }, 1
  %t308 = extractvalue { i64, ptr } { i64 6, ptr @.d155 }, 0
  %t309 = add i64 %t306, %t308
  %t311 = extractvalue { i64, ptr } %t300, 1
  %t312 = extractvalue { i64, ptr } %t300, 0
  %t313 = add i64 %t309, %t312
  %t314 = extractvalue { i64, ptr } { i64 1, ptr @.d156 }, 1
  %t315 = extractvalue { i64, ptr } { i64 1, ptr @.d156 }, 0
  %t316 = add i64 %t313, %t315
  %t317 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t316)
  call void @olang_textcopy(ptr %t317, ptr %t301, i64 %t302)
  %t318 = getelementptr i8, ptr %t317, i64 %t302
  call void @olang_textcopy(ptr %t318, ptr %t304, i64 %t305)
  %t319 = getelementptr i8, ptr %t318, i64 %t305
  call void @olang_textcopy(ptr %t319, ptr %t307, i64 %t308)
  %t320 = getelementptr i8, ptr %t319, i64 %t308
  call void @olang_textcopy(ptr %t320, ptr %t311, i64 %t312)
  %t321 = getelementptr i8, ptr %t320, i64 %t312
  call void @olang_textcopy(ptr %t321, ptr %t314, i64 %t315)
  %t322 = insertvalue { i64, ptr } undef, i64 %t316, 0
  %t323 = insertvalue { i64, ptr } %t322, ptr %t317, 1
  %t325 = extractvalue { i64, ptr } %t323, 0
  %t326 = extractvalue { i64, ptr } %t323, 1
  %t327 = mul i64 %t325, 1
  %t328 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t327)
  call void @llvm.memcpy.p0.p0.i64(ptr %t328, ptr %t326, i64 %t327, i1 false)
  %t329 = insertvalue { i64, ptr } undef, i64 %t325, 0
  %t330 = insertvalue { i64, ptr } %t329, ptr %t328, 1
  %t333 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t298, { i64, ptr } %t330)
  store { i64, ptr } %t333, ptr %l124
  br label %bb54
bb54:
  %t334 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t335 = extractvalue { i64, ptr } %t334, 0
  %t336 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t337 = extractvalue { i64, ptr } %t336, 0
  store i64 %t337, ptr %l126, !tbaa !24
  %t339 = load i64, ptr %l126, !tbaa !24
  %t340 = icmp eq i64 %t335, %t339
  br i1 %t340, label %bb55, label %bb56
bb55:
  %t342 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t343 = load ptr, ptr %t342, !tbaa !27
  %t344 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t345 = load ptr, ptr %t344, !tbaa !27
  %t346 = load i64, ptr %l126, !tbaa !24
  %t347 = mul i64 %t346, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t343, ptr %t345, i64 %t347, i1 false)
  br label %bb57
bb56:
  %t348 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t348, ptr %l14, !tbaa !27
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s11)
  br label %bb58
bb58:
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t350 = load i32, ptr %l8, !tbaa !23
  %t353 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eviaMem(ptr %v0, ptr %t349, i32 %t350)
  store i1 %t353, ptr %l130
  br label %bb59
bb59:
  %t354 = load i1, ptr %l130, !tbaa !21
  store i1 %t354, ptr %l15, !tbaa !21
  %t355 = load i1, ptr %l15, !tbaa !21
  br i1 %t355, label %bb60, label %bb61
bb60:
  store { i64, ptr } { i64 0, ptr @.d157 }, ptr %l132, !tbaa !27
  br label %bb63
bb61:
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t358 = load { i64, [4 x i64] }, ptr %l4
  %t359 = load i32, ptr %l8, !tbaa !23
  %t363 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s10, ptr %t357, { i64, [4 x i64] } %t358, i32 %t359)
  store { i64, ptr } %t363, ptr %l136
  br label %bb62
bb62:
  %t364 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t365 = extractvalue { i64, ptr } %t364, 0
  %t366 = extractvalue { i64, ptr } %t364, 1
  %t367 = mul i64 %t365, 1
  %t368 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t367)
  call void @llvm.memcpy.p0.p0.i64(ptr %t368, ptr %t366, i64 %t367, i1 false)
  %t369 = insertvalue { i64, ptr } undef, i64 %t365, 0
  %t370 = insertvalue { i64, ptr } %t369, ptr %t368, 1
  store { i64, ptr } %t370, ptr %l132, !tbaa !27
  br label %bb63
bb63:
  %t372 = load { i64, ptr }, ptr %l132, !tbaa !27
  store { i64, ptr } %t372, ptr %l16, !tbaa !27
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t374 = load i32, ptr %l8, !tbaa !23
  %t377 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s10, ptr %t373, i32 %t374)
  store { i64, ptr } %t377, ptr %l140
  br label %bb64
bb64:
  %t378 = load { i64, ptr }, ptr %l140, !tbaa !27
  store { i64, ptr } %t378, ptr %l17, !tbaa !27
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t381 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %s10, ptr %s10, ptr %t379, { i64, ptr } { i64 3, ptr @.d158 }, i64 0)
  store { i64, ptr } %t381, ptr %l142
  br label %bb65
bb65:
  %t382 = load { i64, ptr }, ptr %l142, !tbaa !27
  store { i64, ptr } %t382, ptr %l18, !tbaa !27
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t384 = load { i64, ptr }, ptr %l18, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s10, ptr %s10, ptr %s10, ptr %s10, ptr %t383, { i64, ptr } { i64 3, ptr @.d159 }, { i64, ptr } { i64 1, ptr @.d160 }, { i64, ptr } %t384, { i64, ptr } { i64 0, ptr @.d161 })
  br label %bb66
bb66:
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t389 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s10, ptr %s10, ptr %t387, { i64, ptr } { i64 4, ptr @.d162 })
  store { i64, ptr } %t389, ptr %l146
  br label %bb67
bb67:
  %t390 = load { i64, ptr }, ptr %l146, !tbaa !27
  store { i64, ptr } %t390, ptr %l19, !tbaa !27
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t393 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s10, ptr %s10, ptr %t391, { i64, ptr } { i64 5, ptr @.d163 })
  store { i64, ptr } %t393, ptr %l148
  br label %bb68
bb68:
  %t394 = load { i64, ptr }, ptr %l148, !tbaa !27
  store { i64, ptr } %t394, ptr %l20, !tbaa !27
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t397 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s10, ptr %s10, ptr %t395, { i64, ptr } { i64 5, ptr @.d164 })
  store { i64, ptr } %t397, ptr %l150
  br label %bb69
bb69:
  %t398 = load { i64, ptr }, ptr %l150, !tbaa !27
  store { i64, ptr } %t398, ptr %l21, !tbaa !27
  %t399 = load ptr, ptr %l0, !tbaa !29
  %t400 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t401 = extractvalue { i64, ptr } { i64 10, ptr @.d165 }, 1
  %t402 = extractvalue { i64, ptr } { i64 10, ptr @.d165 }, 0
  %t404 = extractvalue { i64, ptr } %t400, 1
  %t405 = extractvalue { i64, ptr } %t400, 0
  %t406 = add i64 %t402, %t405
  %t407 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t406)
  call void @olang_textcopy(ptr %t407, ptr %t401, i64 %t402)
  %t408 = getelementptr i8, ptr %t407, i64 %t402
  call void @olang_textcopy(ptr %t408, ptr %t404, i64 %t405)
  %t409 = insertvalue { i64, ptr } undef, i64 %t406, 0
  %t410 = insertvalue { i64, ptr } %t409, ptr %t407, 1
  %t412 = extractvalue { i64, ptr } %t410, 0
  %t413 = extractvalue { i64, ptr } %t410, 1
  %t414 = mul i64 %t412, 1
  %t415 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t414)
  call void @llvm.memcpy.p0.p0.i64(ptr %t415, ptr %t413, i64 %t414, i1 false)
  %t416 = insertvalue { i64, ptr } undef, i64 %t412, 0
  %t417 = insertvalue { i64, ptr } %t416, ptr %t415, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s10, ptr %t399, { i64, ptr } %t417)
  br label %bb70
bb70:
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t421 = load { i64, ptr }, ptr %l19, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s10, ptr %t420, { i64, ptr } %t421)
  br label %bb71
bb71:
  %t424 = load ptr, ptr %l0, !tbaa !29
  %t425 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t428 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s10, ptr %s10, ptr %s10, ptr %s10, ptr %t424, { i64, ptr } { i64 3, ptr @.d166 }, { i64, ptr } %t425, { i64, ptr } { i64 0, ptr @.d167 })
  store { i64, ptr } %t428, ptr %l159
  br label %bb72
bb72:
  %t429 = load { i64, ptr }, ptr %l159, !tbaa !27
  store { i64, ptr } %t429, ptr %l22, !tbaa !27
  %t430 = load ptr, ptr %l0, !tbaa !29
  %t431 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t432 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t433 = extractvalue { i64, ptr } { i64 13, ptr @.d168 }, 1
  %t434 = extractvalue { i64, ptr } { i64 13, ptr @.d168 }, 0
  %t436 = extractvalue { i64, ptr } %t431, 1
  %t437 = extractvalue { i64, ptr } %t431, 0
  %t438 = add i64 %t434, %t437
  %t439 = extractvalue { i64, ptr } { i64 2, ptr @.d169 }, 1
  %t440 = extractvalue { i64, ptr } { i64 2, ptr @.d169 }, 0
  %t441 = add i64 %t438, %t440
  %t443 = extractvalue { i64, ptr } %t432, 1
  %t444 = extractvalue { i64, ptr } %t432, 0
  %t445 = add i64 %t441, %t444
  %t446 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t445)
  call void @olang_textcopy(ptr %t446, ptr %t433, i64 %t434)
  %t447 = getelementptr i8, ptr %t446, i64 %t434
  call void @olang_textcopy(ptr %t447, ptr %t436, i64 %t437)
  %t448 = getelementptr i8, ptr %t447, i64 %t437
  call void @olang_textcopy(ptr %t448, ptr %t439, i64 %t440)
  %t449 = getelementptr i8, ptr %t448, i64 %t440
  call void @olang_textcopy(ptr %t449, ptr %t443, i64 %t444)
  %t450 = insertvalue { i64, ptr } undef, i64 %t445, 0
  %t451 = insertvalue { i64, ptr } %t450, ptr %t446, 1
  %t453 = extractvalue { i64, ptr } %t451, 0
  %t454 = extractvalue { i64, ptr } %t451, 1
  %t455 = mul i64 %t453, 1
  %t456 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t455)
  call void @llvm.memcpy.p0.p0.i64(ptr %t456, ptr %t454, i64 %t455, i1 false)
  %t457 = insertvalue { i64, ptr } undef, i64 %t453, 0
  %t458 = insertvalue { i64, ptr } %t457, ptr %t456, 1
  %t461 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s10, ptr %s10, ptr %t430, { i64, ptr } %t458)
  store { i64, ptr } %t461, ptr %l165
  br label %bb73
bb73:
  %t462 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t463 = load ptr, ptr %l0, !tbaa !29
  %t465 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t466 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t467 = extractvalue { i64, ptr } { i64 6, ptr @.d170 }, 1
  %t468 = extractvalue { i64, ptr } { i64 6, ptr @.d170 }, 0
  %t470 = extractvalue { i64, ptr } %t462, 1
  %t471 = extractvalue { i64, ptr } %t462, 0
  %t472 = add i64 %t468, %t471
  %t473 = extractvalue { i64, ptr } { i64 9, ptr @.d171 }, 1
  %t474 = extractvalue { i64, ptr } { i64 9, ptr @.d171 }, 0
  %t475 = add i64 %t472, %t474
  %t477 = extractvalue { i64, ptr } %t465, 1
  %t478 = extractvalue { i64, ptr } %t465, 0
  %t479 = add i64 %t475, %t478
  %t480 = extractvalue { i64, ptr } { i64 9, ptr @.d172 }, 1
  %t481 = extractvalue { i64, ptr } { i64 9, ptr @.d172 }, 0
  %t482 = add i64 %t479, %t481
  %t484 = extractvalue { i64, ptr } %t466, 1
  %t485 = extractvalue { i64, ptr } %t466, 0
  %t486 = add i64 %t482, %t485
  %t487 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t486)
  call void @olang_textcopy(ptr %t487, ptr %t467, i64 %t468)
  %t488 = getelementptr i8, ptr %t487, i64 %t468
  call void @olang_textcopy(ptr %t488, ptr %t470, i64 %t471)
  %t489 = getelementptr i8, ptr %t488, i64 %t471
  call void @olang_textcopy(ptr %t489, ptr %t473, i64 %t474)
  %t490 = getelementptr i8, ptr %t489, i64 %t474
  call void @olang_textcopy(ptr %t490, ptr %t477, i64 %t478)
  %t491 = getelementptr i8, ptr %t490, i64 %t478
  call void @olang_textcopy(ptr %t491, ptr %t480, i64 %t481)
  %t492 = getelementptr i8, ptr %t491, i64 %t481
  call void @olang_textcopy(ptr %t492, ptr %t484, i64 %t485)
  %t493 = insertvalue { i64, ptr } undef, i64 %t486, 0
  %t494 = insertvalue { i64, ptr } %t493, ptr %t487, 1
  %t496 = extractvalue { i64, ptr } %t494, 0
  %t497 = extractvalue { i64, ptr } %t494, 1
  %t498 = mul i64 %t496, 1
  %t499 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t498)
  call void @llvm.memcpy.p0.p0.i64(ptr %t499, ptr %t497, i64 %t498, i1 false)
  %t500 = insertvalue { i64, ptr } undef, i64 %t496, 0
  %t501 = insertvalue { i64, ptr } %t500, ptr %t499, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s10, ptr %t463, { i64, ptr } %t501)
  br label %bb74
bb74:
  %t504 = load ptr, ptr %l0, !tbaa !29
  %t505 = load { i64, ptr }, ptr %l20, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s10, ptr %t504, { i64, ptr } %t505)
  br label %bb75
bb75:
  %t508 = load ptr, ptr %l0, !tbaa !29
  %t509 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t510 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t511 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t512 = extractvalue { i64, ptr } { i64 14, ptr @.d173 }, 1
  %t513 = extractvalue { i64, ptr } { i64 14, ptr @.d173 }, 0
  %t515 = extractvalue { i64, ptr } %t509, 1
  %t516 = extractvalue { i64, ptr } %t509, 0
  %t517 = add i64 %t513, %t516
  %t518 = extractvalue { i64, ptr } { i64 6, ptr @.d174 }, 1
  %t519 = extractvalue { i64, ptr } { i64 6, ptr @.d174 }, 0
  %t520 = add i64 %t517, %t519
  %t522 = extractvalue { i64, ptr } %t510, 1
  %t523 = extractvalue { i64, ptr } %t510, 0
  %t524 = add i64 %t520, %t523
  %t525 = extractvalue { i64, ptr } { i64 6, ptr @.d175 }, 1
  %t526 = extractvalue { i64, ptr } { i64 6, ptr @.d175 }, 0
  %t527 = add i64 %t524, %t526
  %t529 = extractvalue { i64, ptr } %t511, 1
  %t530 = extractvalue { i64, ptr } %t511, 0
  %t531 = add i64 %t527, %t530
  %t532 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t531)
  call void @olang_textcopy(ptr %t532, ptr %t512, i64 %t513)
  %t533 = getelementptr i8, ptr %t532, i64 %t513
  call void @olang_textcopy(ptr %t533, ptr %t515, i64 %t516)
  %t534 = getelementptr i8, ptr %t533, i64 %t516
  call void @olang_textcopy(ptr %t534, ptr %t518, i64 %t519)
  %t535 = getelementptr i8, ptr %t534, i64 %t519
  call void @olang_textcopy(ptr %t535, ptr %t522, i64 %t523)
  %t536 = getelementptr i8, ptr %t535, i64 %t523
  call void @olang_textcopy(ptr %t536, ptr %t525, i64 %t526)
  %t537 = getelementptr i8, ptr %t536, i64 %t526
  call void @olang_textcopy(ptr %t537, ptr %t529, i64 %t530)
  %t538 = insertvalue { i64, ptr } undef, i64 %t531, 0
  %t539 = insertvalue { i64, ptr } %t538, ptr %t532, 1
  %t541 = extractvalue { i64, ptr } %t539, 0
  %t542 = extractvalue { i64, ptr } %t539, 1
  %t543 = mul i64 %t541, 1
  %t544 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t543)
  call void @llvm.memcpy.p0.p0.i64(ptr %t544, ptr %t542, i64 %t543, i1 false)
  %t545 = insertvalue { i64, ptr } undef, i64 %t541, 0
  %t546 = insertvalue { i64, ptr } %t545, ptr %t544, 1
  %t549 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s10, ptr %s10, ptr %t508, { i64, ptr } %t546)
  store { i64, ptr } %t549, ptr %l180
  br label %bb76
bb76:
  %t550 = load { i64, ptr }, ptr %l180, !tbaa !27
  store { i64, ptr } %t550, ptr %l24, !tbaa !27
  %t551 = load i1, ptr %l15, !tbaa !21
  br i1 %t551, label %bb77, label %bb78
bb77:
  store %olang.scope zeroinitializer, ptr %s17
  %t553 = load ptr, ptr %l0, !tbaa !29
  %t554 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t555 = load i32, ptr %l8, !tbaa !23
  %t556 = load { i64, [4 x i64] }, ptr %l4
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eput(ptr %v0, ptr %s10, ptr %s17, ptr %t553, { i64, ptr } %t554, i32 %t555, { i64, [4 x i64] } %t556, { i64, ptr } { i64 0, ptr @.d176 })
  br label %bb79
bb78:
  store %olang.scope zeroinitializer, ptr %s18
  %t561 = load ptr, ptr %l0, !tbaa !29
  %t562 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t563 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t564 = load { i64, ptr }, ptr %l24, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s10, ptr %s10, ptr %s10, ptr %s18, ptr %t561, { i64, ptr } %t562, { i64, ptr } %t563, { i64, ptr } %t564, { i64, ptr } { i64 0, ptr @.d177 })
  br label %bb80
bb79:
  call void @__olang_scope_close(ptr %s17)
  br label %bb81
bb80:
  call void @__olang_scope_close(ptr %s18)
  br label %bb81
bb81:
  %t569 = load ptr, ptr %l0, !tbaa !29
  store ptr %t569, ptr %l190, !tbaa !29
  %t570 = load ptr, ptr %l0, !tbaa !29
  %t571 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t572 = extractvalue { i64, ptr } { i64 8, ptr @.d178 }, 1
  %t573 = extractvalue { i64, ptr } { i64 8, ptr @.d178 }, 0
  %t575 = extractvalue { i64, ptr } %t571, 1
  %t576 = extractvalue { i64, ptr } %t571, 0
  %t577 = add i64 %t573, %t576
  %t578 = extractvalue { i64, ptr } { i64 3, ptr @.d179 }, 1
  %t579 = extractvalue { i64, ptr } { i64 3, ptr @.d179 }, 0
  %t580 = add i64 %t577, %t579
  %t581 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t580)
  call void @olang_textcopy(ptr %t581, ptr %t572, i64 %t573)
  %t582 = getelementptr i8, ptr %t581, i64 %t573
  call void @olang_textcopy(ptr %t582, ptr %t575, i64 %t576)
  %t583 = getelementptr i8, ptr %t582, i64 %t576
  call void @olang_textcopy(ptr %t583, ptr %t578, i64 %t579)
  %t584 = insertvalue { i64, ptr } undef, i64 %t580, 0
  %t585 = insertvalue { i64, ptr } %t584, ptr %t581, 1
  %t587 = extractvalue { i64, ptr } %t585, 0
  %t588 = extractvalue { i64, ptr } %t585, 1
  %t589 = mul i64 %t587, 1
  %t590 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t589)
  call void @llvm.memcpy.p0.p0.i64(ptr %t590, ptr %t588, i64 %t589, i1 false)
  %t591 = insertvalue { i64, ptr } undef, i64 %t587, 0
  %t592 = insertvalue { i64, ptr } %t591, ptr %t590, 1
  %t595 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s10, ptr %s10, ptr %t570, { i64, ptr } %t592)
  store { i64, ptr } %t595, ptr %l195
  br label %bb82
bb82:
  %t596 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t597 = extractvalue { i64, ptr } %t596, 0
  %t598 = extractvalue { i64, ptr } %t596, 1
  %t599 = mul i64 %t597, 1
  %t600 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t599)
  call void @llvm.memcpy.p0.p0.i64(ptr %t600, ptr %t598, i64 %t599, i1 false)
  %t601 = insertvalue { i64, ptr } undef, i64 %t597, 0
  %t602 = insertvalue { i64, ptr } %t601, ptr %t600, 1
  %t603 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t604 = load ptr, ptr %l190, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s10, ptr %s10, ptr %s10, ptr %s10, ptr %t604, { i64, ptr } { i64 3, ptr @.d180 }, { i64, ptr } %t602, { i64, ptr } %t603, { i64, ptr } { i64 0, ptr @.d181 })
  br label %bb83
bb83:
  %t607 = load ptr, ptr %l0, !tbaa !29
  %t608 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t609 = extractvalue { i64, ptr } { i64 10, ptr @.d182 }, 1
  %t610 = extractvalue { i64, ptr } { i64 10, ptr @.d182 }, 0
  %t612 = extractvalue { i64, ptr } %t608, 1
  %t613 = extractvalue { i64, ptr } %t608, 0
  %t614 = add i64 %t610, %t613
  %t615 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t614)
  call void @olang_textcopy(ptr %t615, ptr %t609, i64 %t610)
  %t616 = getelementptr i8, ptr %t615, i64 %t610
  call void @olang_textcopy(ptr %t616, ptr %t612, i64 %t613)
  %t617 = insertvalue { i64, ptr } undef, i64 %t614, 0
  %t618 = insertvalue { i64, ptr } %t617, ptr %t615, 1
  %t620 = extractvalue { i64, ptr } %t618, 0
  %t621 = extractvalue { i64, ptr } %t618, 1
  %t622 = mul i64 %t620, 1
  %t623 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t622)
  call void @llvm.memcpy.p0.p0.i64(ptr %t623, ptr %t621, i64 %t622, i1 false)
  %t624 = insertvalue { i64, ptr } undef, i64 %t620, 0
  %t625 = insertvalue { i64, ptr } %t624, ptr %t623, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s10, ptr %t607, { i64, ptr } %t625)
  br label %bb84
bb84:
  %t628 = load ptr, ptr %l0, !tbaa !29
  %t629 = load { i64, ptr }, ptr %l21, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s10, ptr %t628, { i64, ptr } %t629)
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s10)
  br label %bb86
bb86:
  %t632 = load ptr, ptr %l0, !tbaa !29
  %t633 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t634 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t638 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epair(ptr %v0, ptr %s0, ptr %s0, ptr %v1, ptr %t632, { i64, ptr } %t633, { i64, ptr } %t634)
  store { i64, ptr } %t638, ptr %l207
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s0)
  %t639 = load { i64, ptr }, ptr %l207, !tbaa !27
  store { i64, ptr } %t639, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eprim(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, %"compiler/mir:Range" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca %"compiler/mir:Range"
  %l4 = alloca ptr
  %l5 = alloca { i64, [4 x i64] }
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca i1
  %l10 = alloca i1
  %lp11 = alloca ptr
  %l12 = alloca { i64, [4 x i64] }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l24 = alloca i32
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i32
  %l42 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l47 = alloca i32
  %l48 = alloca i32
  %l50 = alloca i32
  %l51 = alloca { i64, ptr }
  %l58 = alloca { i64, [4 x i64] }
  %l61 = alloca i32
  %l64 = alloca i1
  %l68 = alloca i1
  %l72 = alloca ptr
  %l75 = alloca { i64, [4 x i64] }
  %l76 = alloca i32
  %l79 = alloca i32
  %l82 = alloca { i64, ptr }
  %l85 = alloca i1
  %l88 = alloca i1
  %l92 = alloca { i64, ptr }
  %l96 = alloca i1
  %l97 = alloca ptr
  %l98 = alloca ptr
  %l103 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l117 = alloca { i64, ptr }
  %l123 = alloca { i64, ptr }
  %l126 = alloca ptr
  %l127 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l132 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l152 = alloca ptr
  %l153 = alloca { i64, ptr }
  %l154 = alloca { i64, ptr }
  %l157 = alloca { i64, ptr }
  %l159 = alloca { i64, ptr }
  %l164 = alloca { i64, [4 x i64] }
  %l165 = alloca i64
  %l173 = alloca { i64, ptr }
  %l174 = alloca { i64, ptr }
  %l175 = alloca i64
  %l176 = alloca { i64, ptr }
  %l180 = alloca { i64, ptr }
  %l185 = alloca { i64, ptr }
  %l190 = alloca { i64, ptr }
  %l196 = alloca { i64, ptr }
  %l202 = alloca { i64, ptr }
  %l209 = alloca { i64, ptr }
  %l216 = alloca { i64, ptr }
  %l221 = alloca { i64, ptr }
  %l222 = alloca ptr
  %l223 = alloca { i64, ptr }
  %l224 = alloca { i64, ptr }
  %l227 = alloca { i64, ptr }
  %l230 = alloca { i64, ptr }
  %l235 = alloca { i64, ptr }
  %l236 = alloca ptr
  %l237 = alloca { i64, ptr }
  %l239 = alloca ptr
  %l240 = alloca ptr
  %l243 = alloca { i64, [4 x i64] }
  %l244 = alloca i32
  %l245 = alloca { i64, ptr }
  %l248 = alloca { i64, ptr }
  %l253 = alloca i1
  %l254 = alloca i32
  %l257 = alloca i32
  %l261 = alloca i32
  %l265 = alloca i1
  %l269 = alloca i1
  %l272 = alloca i1
  %l278 = alloca { i64, ptr }
  %l283 = alloca { i64, ptr }
  %l284 = alloca ptr
  %l285 = alloca { i64, ptr }
  %l286 = alloca ptr
  %l289 = alloca i32
  %l290 = alloca i64
  %l293 = alloca { i64, ptr }
  %l301 = alloca { i64, ptr }
  %l302 = alloca { i64, ptr }
  %l303 = alloca i64
  %l304 = alloca { i64, ptr }
  %l309 = alloca i1
  %l310 = alloca i32
  %l313 = alloca i32
  %l317 = alloca i32
  %l321 = alloca i1
  %l324 = alloca i1
  %l327 = alloca i64
  %l333 = alloca { i64, ptr }
  %l338 = alloca i32
  %l339 = alloca ptr
  %l342 = alloca { i64, ptr }
  %l343 = alloca { i64, ptr }
  %l346 = alloca i64
  %l349 = alloca { i64, ptr }
  %l358 = alloca { i64, ptr }
  %l361 = alloca { i64, ptr }
  %l366 = alloca ptr
  %l367 = alloca { i64, ptr }
  %l368 = alloca { i64, ptr }
  %l369 = alloca { i64, ptr }
  %l370 = alloca { i64, ptr }
  %l372 = alloca i1
  %l374 = alloca { i64, ptr }
  %l377 = alloca ptr
  %l378 = alloca { i64, ptr }
  %l379 = alloca { i64, ptr }
  %l380 = alloca { i64, ptr }
  %l381 = alloca { i64, ptr }
  %l383 = alloca i1
  %l385 = alloca { i64, ptr }
  %l388 = alloca { i64, ptr }
  %l393 = alloca { i64, ptr }
  %l398 = alloca i64
  %l418 = alloca { i64, ptr }
  %l423 = alloca ptr
  %l424 = alloca ptr
  %l427 = alloca { i64, [4 x i64] }
  %l429 = alloca { i64, ptr }
  %l433 = alloca { i64, ptr }
  %l436 = alloca { i64, ptr }
  %l460 = alloca { i64, ptr }
  %l461 = alloca ptr
  %l464 = alloca { i64, [4 x i64] }
  %l466 = alloca { i64, ptr }
  %l468 = alloca i1
  %l471 = alloca { i64, ptr }
  %l474 = alloca { i64, ptr }
  %l475 = alloca { i64, ptr }
  %l487 = alloca i1
  %l489 = alloca ptr
  %l496 = alloca { i64, ptr }
  %l498 = alloca { i64, ptr }
  %l515 = alloca { i64, ptr }
  %l518 = alloca ptr
  %l520 = alloca { i64, ptr }
  %l526 = alloca { i64, ptr }
  %l529 = alloca ptr
  %l531 = alloca { i64, ptr }
  %l537 = alloca { i64, ptr }
  %l540 = alloca ptr
  %l542 = alloca { i64, ptr }
  %l548 = alloca { i64, ptr }
  %l551 = alloca ptr
  %l553 = alloca { i64, ptr }
  %l555 = alloca { i64, ptr }
  %l561 = alloca { i64, ptr }
  %l564 = alloca ptr
  %l566 = alloca { i64, ptr }
  %l568 = alloca { i64, ptr }
  %l574 = alloca { i64, ptr }
  %l579 = alloca ptr
  %l582 = alloca { i64, [4 x i64] }
  %l583 = alloca i32
  %l584 = alloca ptr
  %l585 = alloca ptr
  %l588 = alloca { i64, [4 x i64] }
  %l590 = alloca { i64, ptr }
  %l594 = alloca { i64, ptr }
  %l597 = alloca { i64, ptr }
  %l599 = alloca { i64, ptr }
  %l607 = alloca { i64, ptr }
  %l616 = alloca { i64, ptr }
  %l625 = alloca { i64, ptr }
  %l634 = alloca { i64, ptr }
  %l652 = alloca { i64, ptr }
  %l656 = alloca i1
  %l657 = alloca i1
  %l659 = alloca i1
  %l661 = alloca i1
  %l662 = alloca { i64, ptr }
  %l663 = alloca ptr
  %l664 = alloca { i64, ptr }
  %l670 = alloca { i64, ptr }
  %l676 = alloca { i64, ptr }
  %l679 = alloca { i64, ptr }
  %l680 = alloca ptr
  %l686 = alloca { i64, ptr }
  %l692 = alloca { i64, ptr }
  %l695 = alloca { i64, ptr }
  %l701 = alloca { i64, ptr }
  %l708 = alloca { i64, ptr }
  %l714 = alloca i1
  %l715 = alloca ptr
  %l721 = alloca { i64, ptr }
  %l725 = alloca { i64, ptr }
  %l726 = alloca ptr
  %l727 = alloca { i64, ptr }
  %l732 = alloca { i64, ptr }
  %l735 = alloca { i64, ptr }
  %l740 = alloca i32
  %l741 = alloca ptr
  %l744 = alloca { i64, ptr }
  %l745 = alloca ptr
  %l748 = alloca { i64, [4 x i64] }
  %l750 = alloca { i64, ptr }
  %l751 = alloca { i64, ptr }
  %l754 = alloca i64
  %l757 = alloca { i64, ptr }
  %l758 = alloca { i64, ptr }
  %l759 = alloca i64
  %l760 = alloca { i64, ptr }
  %l767 = alloca i32
  %l770 = alloca { i64, ptr }
  %l771 = alloca ptr
  %l772 = alloca { i64, ptr }
  %l773 = alloca { i64, ptr }
  %l776 = alloca { i64, ptr }
  %l777 = alloca ptr
  %l780 = alloca { i64, [4 x i64] }
  %l782 = alloca { i64, ptr }
  %l785 = alloca { i64, ptr }
  %l790 = alloca i32
  %l793 = alloca { i64, ptr }
  %l794 = alloca ptr
  %l795 = alloca { i64, ptr }
  %l796 = alloca { i64, ptr }
  %l797 = alloca ptr
  %l800 = alloca { i64, [4 x i64] }
  %l802 = alloca { i64, ptr }
  %l803 = alloca { i64, ptr }
  %l804 = alloca ptr
  %l807 = alloca { i64, [4 x i64] }
  %l809 = alloca { i64, ptr }
  %l812 = alloca { i64, ptr }
  %l818 = alloca { i64, ptr }
  %l819 = alloca ptr
  %l820 = alloca i32
  %l822 = alloca { i64, ptr }
  %l824 = alloca { i64, ptr }
  %l825 = alloca { i64, ptr }
  %l826 = alloca i64
  %l827 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s43 = alloca %olang.scope
  %s47 = alloca %olang.scope
  %s52 = alloca %olang.scope
  %s57 = alloca %olang.scope
  %s78 = alloca %olang.scope
  %s87 = alloca %olang.scope
  %s88 = alloca %olang.scope
  %s97 = alloca %olang.scope
  %s98 = alloca %olang.scope
  %s103 = alloca %olang.scope
  %s105 = alloca %olang.scope
  %s107 = alloca %olang.scope
  %s110 = alloca %olang.scope
  %s111 = alloca %olang.builder
  %s111room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/mir:Range" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load %"compiler/mir:Range", ptr %l3
  %t13 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t9, %"compiler/mir:Range" %t10, i64 0)
  store { i64, [4 x i64] } %t13, ptr %l58
  br label %bb1
bb1:
  %t14 = load { i64, [4 x i64] }, ptr %l58
  store { i64, [4 x i64] } %t14, ptr %l5
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load { i64, [4 x i64] }, ptr %l5
  %t19 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t15, { i64, [4 x i64] } %t16)
  store i32 %t19, ptr %l61
  br label %bb2
bb2:
  %t20 = load i32, ptr %l61, !tbaa !23
  store i32 %t20, ptr %l6, !tbaa !23
  %t21 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t22 = load i32, ptr %t21, !tbaa !23
  %t24 = icmp sgt i32 %t22, 1
  br i1 %t24, label %bb3, label %bb4
bb3:
  %t26 = load i32, ptr %l6, !tbaa !23
  %t27 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t30 = icmp eq i32 %t26, %t27
  br i1 %t30, label %bb5, label %bb6
bb4:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb8
bb5:
  store i1 true, ptr %l68, !tbaa !21
  br label %bb7
bb6:
  %t32 = load i32, ptr %l6, !tbaa !23
  %t33 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t36 = icmp eq i32 %t32, %t33
  store i1 %t36, ptr %l68, !tbaa !21
  br label %bb7
bb7:
  %t38 = load i1, ptr %l68, !tbaa !21
  store i1 %t38, ptr %l64, !tbaa !21
  br label %bb8
bb8:
  %t39 = load i1, ptr %l64, !tbaa !21
  br i1 %t39, label %bb9, label %bb10
bb9:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l72, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load %"compiler/mir:Range", ptr %l3
  %t45 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t41, %"compiler/mir:Range" %t42, i64 1)
  store { i64, [4 x i64] } %t45, ptr %l75
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t46 = load ptr, ptr %l72, !tbaa !29
  %t47 = load { i64, [4 x i64] }, ptr %l75
  %t48 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t46, { i64, [4 x i64] } %t47)
  store i32 %t48, ptr %l76
  br label %bb12
bb12:
  %t49 = load i32, ptr %l76, !tbaa !23
  store i32 %t49, ptr %l6, !tbaa !23
  br label %bb13
bb13:
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t51 = load i32, ptr %l6, !tbaa !23
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t50, i32 %t51)
  store i32 %t54, ptr %l79
  br label %bb14
bb14:
  %t55 = load i32, ptr %l79, !tbaa !23
  store i32 %t55, ptr %l7, !tbaa !23
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i32, ptr %l7, !tbaa !23
  %t60 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s0, ptr %t56, i32 %t57)
  store { i64, ptr } %t60, ptr %l82
  br label %bb15
bb15:
  %t61 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t61, ptr %l8, !tbaa !27
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t63 = load i32, ptr %l7, !tbaa !23
  %t66 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t62, i32 %t63)
  store i1 %t66, ptr %l85
  br label %bb16
bb16:
  %t67 = load i1, ptr %l85, !tbaa !21
  store i1 %t67, ptr %l9, !tbaa !21
  %t68 = load ptr, ptr %l4, !tbaa !29
  %t69 = load i32, ptr %l7, !tbaa !23
  %t72 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t68, i32 %t69)
  store i1 %t72, ptr %l88
  br label %bb17
bb17:
  %t73 = load i1, ptr %l88, !tbaa !21
  store i1 %t73, ptr %l10, !tbaa !21
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load { i64, [4 x i64] }, ptr %l5
  %t76 = load i32, ptr %l6, !tbaa !23
  %t80 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %v1, ptr %t74, { i64, [4 x i64] } %t75, i32 %t76)
  store { i64, ptr } %t80, ptr %l92
  br label %bb18
bb18:
  %t81 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t81, ptr %lp11
  %t82 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t83 = load ptr, ptr %lp11
  store { i64, ptr } %t82, ptr %t83, !tbaa !27
  %t84 = load i32, ptr %l1
  %t86 = trunc i64 0 to i32
  %t87 = icmp eq i32 %t84, %t86
  br i1 %t87, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb34
bb21:
  store %olang.scope zeroinitializer, ptr %s2
  %t89 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t91 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s2, { i64, ptr } %t89, { i64, ptr } { i64 6, ptr @.d183 })
  store i1 %t91, ptr %l96
  br label %bb22
bb22:
  %t92 = load i1, ptr %l96, !tbaa !21
  br i1 %t92, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s3
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l97, !tbaa !29
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l98, !tbaa !29
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load ptr, ptr %lp11
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !27
  %t98 = extractvalue { i64, ptr } { i64 15, ptr @.d184 }, 1
  %t99 = extractvalue { i64, ptr } { i64 15, ptr @.d184 }, 0
  %t101 = extractvalue { i64, ptr } %t97, 1
  %t102 = extractvalue { i64, ptr } %t97, 0
  %t103 = add i64 %t99, %t102
  %t104 = extractvalue { i64, ptr } { i64 7, ptr @.d185 }, 1
  %t105 = extractvalue { i64, ptr } { i64 7, ptr @.d185 }, 0
  %t106 = add i64 %t103, %t105
  %t107 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t106)
  call void @olang_textcopy(ptr %t107, ptr %t98, i64 %t99)
  %t108 = getelementptr i8, ptr %t107, i64 %t99
  call void @olang_textcopy(ptr %t108, ptr %t101, i64 %t102)
  %t109 = getelementptr i8, ptr %t108, i64 %t102
  call void @olang_textcopy(ptr %t109, ptr %t104, i64 %t105)
  %t110 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t107, 1
  %t113 = extractvalue { i64, ptr } %t111, 0
  %t114 = extractvalue { i64, ptr } %t111, 1
  %t115 = mul i64 %t113, 1
  %t116 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t115)
  call void @llvm.memcpy.p0.p0.i64(ptr %t116, ptr %t114, i64 %t115, i1 false)
  %t117 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t116, 1
  %t121 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s3, ptr %s3, ptr %t95, { i64, ptr } %t118)
  store { i64, ptr } %t121, ptr %l103
  br label %bb25
bb24:
  br label %bb28
bb25:
  %t122 = extractvalue { i64, ptr } { i64 8, ptr @.d186 }, 1
  %t123 = extractvalue { i64, ptr } { i64 8, ptr @.d186 }, 0
  %t124 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t124, 1
  %t126 = extractvalue { i64, ptr } %t124, 0
  %t127 = add i64 %t123, %t126
  %t128 = extractvalue { i64, ptr } { i64 8, ptr @.d187 }, 1
  %t129 = extractvalue { i64, ptr } { i64 8, ptr @.d187 }, 0
  %t130 = add i64 %t127, %t129
  %t131 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t130)
  call void @olang_textcopy(ptr %t131, ptr %t122, i64 %t123)
  %t132 = getelementptr i8, ptr %t131, i64 %t123
  call void @olang_textcopy(ptr %t132, ptr %t125, i64 %t126)
  %t133 = getelementptr i8, ptr %t132, i64 %t126
  call void @olang_textcopy(ptr %t133, ptr %t128, i64 %t129)
  %t134 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t131, 1
  %t137 = extractvalue { i64, ptr } %t135, 0
  %t138 = extractvalue { i64, ptr } %t135, 1
  %t139 = mul i64 %t137, 1
  %t140 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t139)
  call void @llvm.memcpy.p0.p0.i64(ptr %t140, ptr %t138, i64 %t139, i1 false)
  %t141 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t140, 1
  %t143 = load ptr, ptr %l98, !tbaa !29
  %t145 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s3, ptr %s3, ptr %t143, { i64, ptr } %t142)
  store { i64, ptr } %t145, ptr %l106
  br label %bb26
bb26:
  %t146 = extractvalue { i64, ptr } { i64 12, ptr @.d188 }, 1
  %t147 = extractvalue { i64, ptr } { i64 12, ptr @.d188 }, 0
  %t148 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t149 = extractvalue { i64, ptr } %t148, 1
  %t150 = extractvalue { i64, ptr } %t148, 0
  %t151 = add i64 %t147, %t150
  %t152 = extractvalue { i64, ptr } { i64 10, ptr @.d189 }, 1
  %t153 = extractvalue { i64, ptr } { i64 10, ptr @.d189 }, 0
  %t154 = add i64 %t151, %t153
  %t155 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t154)
  call void @olang_textcopy(ptr %t155, ptr %t146, i64 %t147)
  %t156 = getelementptr i8, ptr %t155, i64 %t147
  call void @olang_textcopy(ptr %t156, ptr %t149, i64 %t150)
  %t157 = getelementptr i8, ptr %t156, i64 %t150
  call void @olang_textcopy(ptr %t157, ptr %t152, i64 %t153)
  %t158 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t155, 1
  %t161 = extractvalue { i64, ptr } %t159, 0
  %t162 = extractvalue { i64, ptr } %t159, 1
  %t163 = mul i64 %t161, 1
  %t164 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t163)
  call void @llvm.memcpy.p0.p0.i64(ptr %t164, ptr %t162, i64 %t163, i1 false)
  %t165 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t164, 1
  %t167 = load ptr, ptr %l97, !tbaa !29
  %t169 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t167, { i64, ptr } %t166)
  store { i64, ptr } %t169, ptr %l109
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t170 = load { i64, ptr }, ptr %l109, !tbaa !27
  store { i64, ptr } %t170, ptr %rv
  br label %ret
bb28:
  %t171 = load i1, ptr %l9, !tbaa !21
  br i1 %t171, label %bb29, label %bb30
bb29:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t175 = load ptr, ptr %lp11
  %t176 = load { i64, ptr }, ptr %t175, !tbaa !27
  %t177 = extractvalue { i64, ptr } { i64 5, ptr @.d190 }, 1
  %t178 = extractvalue { i64, ptr } { i64 5, ptr @.d190 }, 0
  %t180 = extractvalue { i64, ptr } %t174, 1
  %t181 = extractvalue { i64, ptr } %t174, 0
  %t182 = add i64 %t178, %t181
  %t183 = extractvalue { i64, ptr } { i64 1, ptr @.d191 }, 1
  %t184 = extractvalue { i64, ptr } { i64 1, ptr @.d191 }, 0
  %t185 = add i64 %t182, %t184
  %t187 = extractvalue { i64, ptr } %t176, 1
  %t188 = extractvalue { i64, ptr } %t176, 0
  %t189 = add i64 %t185, %t188
  %t190 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t189)
  call void @olang_textcopy(ptr %t190, ptr %t177, i64 %t178)
  %t191 = getelementptr i8, ptr %t190, i64 %t178
  call void @olang_textcopy(ptr %t191, ptr %t180, i64 %t181)
  %t192 = getelementptr i8, ptr %t191, i64 %t181
  call void @olang_textcopy(ptr %t192, ptr %t183, i64 %t184)
  %t193 = getelementptr i8, ptr %t192, i64 %t184
  call void @olang_textcopy(ptr %t193, ptr %t187, i64 %t188)
  %t194 = insertvalue { i64, ptr } undef, i64 %t189, 0
  %t195 = insertvalue { i64, ptr } %t194, ptr %t190, 1
  %t197 = extractvalue { i64, ptr } %t195, 0
  %t198 = extractvalue { i64, ptr } %t195, 1
  %t199 = mul i64 %t197, 1
  %t200 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t199)
  call void @llvm.memcpy.p0.p0.i64(ptr %t200, ptr %t198, i64 %t199, i1 false)
  %t201 = insertvalue { i64, ptr } undef, i64 %t197, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t200, 1
  %t205 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t173, { i64, ptr } %t202)
  store { i64, ptr } %t205, ptr %l117
  br label %bb31
bb30:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t207 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t208 = load ptr, ptr %lp11
  %t209 = load { i64, ptr }, ptr %t208, !tbaa !27
  %t210 = extractvalue { i64, ptr } { i64 4, ptr @.d192 }, 1
  %t211 = extractvalue { i64, ptr } { i64 4, ptr @.d192 }, 0
  %t213 = extractvalue { i64, ptr } %t207, 1
  %t214 = extractvalue { i64, ptr } %t207, 0
  %t215 = add i64 %t211, %t214
  %t216 = extractvalue { i64, ptr } { i64 4, ptr @.d193 }, 1
  %t217 = extractvalue { i64, ptr } { i64 4, ptr @.d193 }, 0
  %t218 = add i64 %t215, %t217
  %t220 = extractvalue { i64, ptr } %t209, 1
  %t221 = extractvalue { i64, ptr } %t209, 0
  %t222 = add i64 %t218, %t221
  %t223 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t222)
  call void @olang_textcopy(ptr %t223, ptr %t210, i64 %t211)
  %t224 = getelementptr i8, ptr %t223, i64 %t211
  call void @olang_textcopy(ptr %t224, ptr %t213, i64 %t214)
  %t225 = getelementptr i8, ptr %t224, i64 %t214
  call void @olang_textcopy(ptr %t225, ptr %t216, i64 %t217)
  %t226 = getelementptr i8, ptr %t225, i64 %t217
  call void @olang_textcopy(ptr %t226, ptr %t220, i64 %t221)
  %t227 = insertvalue { i64, ptr } undef, i64 %t222, 0
  %t228 = insertvalue { i64, ptr } %t227, ptr %t223, 1
  %t230 = extractvalue { i64, ptr } %t228, 0
  %t231 = extractvalue { i64, ptr } %t228, 1
  %t232 = mul i64 %t230, 1
  %t233 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t232)
  call void @llvm.memcpy.p0.p0.i64(ptr %t233, ptr %t231, i64 %t232, i1 false)
  %t234 = insertvalue { i64, ptr } undef, i64 %t230, 0
  %t235 = insertvalue { i64, ptr } %t234, ptr %t233, 1
  %t238 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t206, { i64, ptr } %t235)
  store { i64, ptr } %t238, ptr %l123
  br label %bb32
bb31:
  %t239 = load { i64, ptr }, ptr %l117, !tbaa !27
  store { i64, ptr } %t239, ptr %l111, !tbaa !27
  br label %bb33
bb32:
  %t240 = load { i64, ptr }, ptr %l123, !tbaa !27
  store { i64, ptr } %t240, ptr %l111, !tbaa !27
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t241 = load { i64, ptr }, ptr %l111, !tbaa !27
  store { i64, ptr } %t241, ptr %rv
  br label %ret
bb34:
  %t242 = load i32, ptr %l1
  %t244 = trunc i64 1 to i32
  %t245 = icmp eq i32 %t242, %t244
  br i1 %t245, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb42
bb37:
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l126, !tbaa !29
  %t248 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t248, ptr %l127, !tbaa !27
  %t249 = load ptr, ptr %lp11
  %t250 = load { i64, ptr }, ptr %t249, !tbaa !27
  store { i64, ptr } %t250, ptr %l128, !tbaa !27
  %t251 = load i32, ptr %l7, !tbaa !23
  %t252 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t255 = icmp eq i32 %t251, %t252
  br i1 %t255, label %bb38, label %bb39
bb38:
  store { i64, ptr } { i64 4, ptr @.d194 }, ptr %l132, !tbaa !27
  br label %bb40
bb39:
  store { i64, ptr } { i64 2, ptr @.d195 }, ptr %l132, !tbaa !27
  br label %bb40
bb40:
  %t257 = extractvalue { i64, ptr } { i64 4, ptr @.d196 }, 1
  %t258 = extractvalue { i64, ptr } { i64 4, ptr @.d196 }, 0
  %t259 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t260 = extractvalue { i64, ptr } %t259, 1
  %t261 = extractvalue { i64, ptr } %t259, 0
  %t262 = add i64 %t258, %t261
  %t263 = extractvalue { i64, ptr } { i64 1, ptr @.d197 }, 1
  %t264 = extractvalue { i64, ptr } { i64 1, ptr @.d197 }, 0
  %t265 = add i64 %t262, %t264
  %t266 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t267 = extractvalue { i64, ptr } %t266, 1
  %t268 = extractvalue { i64, ptr } %t266, 0
  %t269 = add i64 %t265, %t268
  %t270 = extractvalue { i64, ptr } { i64 2, ptr @.d198 }, 1
  %t271 = extractvalue { i64, ptr } { i64 2, ptr @.d198 }, 0
  %t272 = add i64 %t269, %t271
  %t273 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t274 = extractvalue { i64, ptr } %t273, 1
  %t275 = extractvalue { i64, ptr } %t273, 0
  %t276 = add i64 %t272, %t275
  %t277 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t276)
  call void @olang_textcopy(ptr %t277, ptr %t257, i64 %t258)
  %t278 = getelementptr i8, ptr %t277, i64 %t258
  call void @olang_textcopy(ptr %t278, ptr %t260, i64 %t261)
  %t279 = getelementptr i8, ptr %t278, i64 %t261
  call void @olang_textcopy(ptr %t279, ptr %t263, i64 %t264)
  %t280 = getelementptr i8, ptr %t279, i64 %t264
  call void @olang_textcopy(ptr %t280, ptr %t267, i64 %t268)
  %t281 = getelementptr i8, ptr %t280, i64 %t268
  call void @olang_textcopy(ptr %t281, ptr %t270, i64 %t271)
  %t282 = getelementptr i8, ptr %t281, i64 %t271
  call void @olang_textcopy(ptr %t282, ptr %t274, i64 %t275)
  %t283 = insertvalue { i64, ptr } undef, i64 %t276, 0
  %t284 = insertvalue { i64, ptr } %t283, ptr %t277, 1
  %t286 = extractvalue { i64, ptr } %t284, 0
  %t287 = extractvalue { i64, ptr } %t284, 1
  %t288 = mul i64 %t286, 1
  %t289 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t288)
  call void @llvm.memcpy.p0.p0.i64(ptr %t289, ptr %t287, i64 %t288, i1 false)
  %t290 = insertvalue { i64, ptr } undef, i64 %t286, 0
  %t291 = insertvalue { i64, ptr } %t290, ptr %t289, 1
  %t292 = load ptr, ptr %l126, !tbaa !29
  %t294 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t292, { i64, ptr } %t291)
  store { i64, ptr } %t294, ptr %l135
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s0)
  %t295 = load { i64, ptr }, ptr %l135, !tbaa !27
  store { i64, ptr } %t295, ptr %rv
  br label %ret
bb42:
  %t296 = load i32, ptr %l1
  %t298 = trunc i64 2 to i32
  %t299 = icmp eq i32 %t296, %t298
  br i1 %t299, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t302 = load ptr, ptr %lp11
  %t303 = load { i64, ptr }, ptr %t302, !tbaa !27
  %t304 = extractvalue { i64, ptr } { i64 7, ptr @.d199 }, 1
  %t305 = extractvalue { i64, ptr } { i64 7, ptr @.d199 }, 0
  %t307 = extractvalue { i64, ptr } %t303, 1
  %t308 = extractvalue { i64, ptr } %t303, 0
  %t309 = add i64 %t305, %t308
  %t310 = extractvalue { i64, ptr } { i64 6, ptr @.d200 }, 1
  %t311 = extractvalue { i64, ptr } { i64 6, ptr @.d200 }, 0
  %t312 = add i64 %t309, %t311
  %t313 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t312)
  call void @olang_textcopy(ptr %t313, ptr %t304, i64 %t305)
  %t314 = getelementptr i8, ptr %t313, i64 %t305
  call void @olang_textcopy(ptr %t314, ptr %t307, i64 %t308)
  %t315 = getelementptr i8, ptr %t314, i64 %t308
  call void @olang_textcopy(ptr %t315, ptr %t310, i64 %t311)
  %t316 = insertvalue { i64, ptr } undef, i64 %t312, 0
  %t317 = insertvalue { i64, ptr } %t316, ptr %t313, 1
  %t319 = extractvalue { i64, ptr } %t317, 0
  %t320 = extractvalue { i64, ptr } %t317, 1
  %t321 = mul i64 %t319, 1
  %t322 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t321)
  call void @llvm.memcpy.p0.p0.i64(ptr %t322, ptr %t320, i64 %t321, i1 false)
  %t323 = insertvalue { i64, ptr } undef, i64 %t319, 0
  %t324 = insertvalue { i64, ptr } %t323, ptr %t322, 1
  %t327 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t301, { i64, ptr } %t324)
  store { i64, ptr } %t327, ptr %l142
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s0)
  %t328 = load { i64, ptr }, ptr %l142, !tbaa !27
  store { i64, ptr } %t328, ptr %rv
  br label %ret
bb47:
  %t329 = load i32, ptr %l1
  %t331 = trunc i64 20 to i32
  %t332 = icmp eq i32 %t329, %t331
  br i1 %t332, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t335 = load ptr, ptr %lp11
  %t336 = load { i64, ptr }, ptr %t335, !tbaa !27
  %t337 = load i32, ptr %l6, !tbaa !23
  %t338 = load i32, ptr %l2, !tbaa !23
  %t343 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2econvert(ptr %v0, ptr %v1, ptr %v1, ptr %t334, { i64, ptr } %t336, i32 %t337, i32 %t338)
  store { i64, ptr } %t343, ptr %l149
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s0)
  %t344 = load { i64, ptr }, ptr %l149, !tbaa !27
  store { i64, ptr } %t344, ptr %rv
  br label %ret
bb52:
  %t345 = load i32, ptr %l1
  %t347 = trunc i64 21 to i32
  %t348 = icmp eq i32 %t345, %t347
  br i1 %t348, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb58
bb55:
  %t350 = load ptr, ptr %l0, !tbaa !29
  store ptr %t350, ptr %l152, !tbaa !29
  %t351 = load ptr, ptr %lp11
  %t352 = load { i64, ptr }, ptr %t351, !tbaa !27
  store { i64, ptr } %t352, ptr %l153, !tbaa !27
  %t353 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t353, ptr %l154, !tbaa !27
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t355 = load i32, ptr %l2, !tbaa !23
  %t358 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %v1, ptr %t354, i32 %t355)
  store { i64, ptr } %t358, ptr %l157
  br label %bb56
bb56:
  %t359 = load { i64, ptr }, ptr %l157, !tbaa !27
  %t360 = extractvalue { i64, ptr } %t359, 0
  %t361 = extractvalue { i64, ptr } %t359, 1
  %t362 = mul i64 %t360, 1
  %t363 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t362)
  call void @llvm.memcpy.p0.p0.i64(ptr %t363, ptr %t361, i64 %t362, i1 false)
  %t364 = insertvalue { i64, ptr } undef, i64 %t360, 0
  %t365 = insertvalue { i64, ptr } %t364, ptr %t363, 1
  %t366 = load ptr, ptr %l152, !tbaa !29
  %t367 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t368 = load { i64, ptr }, ptr %l154, !tbaa !27
  %t370 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ebitcast(ptr %v0, ptr %v1, ptr %s0, ptr %v1, ptr %v1, ptr %t366, { i64, ptr } %t367, { i64, ptr } %t368, { i64, ptr } %t365)
  store { i64, ptr } %t370, ptr %l159
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s0)
  %t371 = load { i64, ptr }, ptr %l159, !tbaa !27
  store { i64, ptr } %t371, ptr %rv
  br label %ret
bb58:
  %t372 = load i32, ptr %l1
  %t374 = trunc i64 37 to i32
  %t375 = icmp eq i32 %t372, %t374
  br i1 %t375, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb81
bb61:
  store %olang.scope zeroinitializer, ptr %s15
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t378 = load %"compiler/mir:Range", ptr %l3
  %t381 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t377, %"compiler/mir:Range" %t378, i64 1)
  store { i64, [4 x i64] } %t381, ptr %l164
  br label %bb62
bb62:
  %t382 = load { i64, [4 x i64] }, ptr %l164
  store { i64, [4 x i64] } %t382, ptr %l12
  %t383 = load { i64, [4 x i64] }, ptr %l12
  %t385 = extractvalue { i64, [4 x i64] } %t383, 0
  %t386 = icmp eq i64 %t385, 2
  br i1 %t386, label %bb63, label %bb64
bb63:
  %t388 = getelementptr { i64, [4 x i64] }, ptr %l12, i32 0, i32 1
  %t389 = getelementptr { i32, i64 }, ptr %t388, i32 0, i32 1
  %t390 = load i64, ptr %t389
  store i64 %t390, ptr %l13, !tbaa !24
  br label %bb65
bb64:
  br label %bb66
bb65:
  %t392 = load i64, ptr %l13, !tbaa !24
  store i64 %t392, ptr %l165, !tbaa !24
  br label %bb71
bb66:
  br i1 true, label %bb67, label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb70
bb69:
  store i64 -1, ptr %l165, !tbaa !24
  br label %bb71
bb70:
  call void @__olang_check_failed(ptr @olang_loc_69dfe582bfe1941e_f4b5889a4307147a)
  unreachable
bb71:
  %t394 = load i64, ptr %l165, !tbaa !24
  store i64 %t394, ptr %l14, !tbaa !24
  %t395 = load i64, ptr %l14, !tbaa !24
  %t397 = icmp slt i64 %t395, 0
  br i1 %t397, label %bb72, label %bb73
bb72:
  store %olang.scope zeroinitializer, ptr %s18
  %t399 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s18, ptr %t399, { i64, ptr } { i64 20, ptr @.d201 })
  br label %bb74
bb73:
  br label %bb75
bb74:
  store { i64, ptr } { i64 15, ptr @.d202 }, ptr %l173, !tbaa !27
  %t401 = load { i64, ptr }, ptr %l173, !tbaa !27
  store { i64, ptr } %t401, ptr %l174, !tbaa !27
  %t402 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t403 = extractvalue { i64, ptr } %t402, 0
  store i64 %t403, ptr %l175, !tbaa !24
  %t404 = load i64, ptr %l175, !tbaa !24
  %t405 = mul i64 %t404, 1
  %t406 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t405)
  %t407 = insertvalue { i64, ptr } undef, i64 %t404, 0
  %t408 = insertvalue { i64, ptr } %t407, ptr %t406, 1
  store { i64, ptr } %t408, ptr %l176, !tbaa !27
  %t409 = getelementptr { i64, ptr }, ptr %l176, i32 0, i32 1
  %t410 = load ptr, ptr %t409, !tbaa !27
  %t411 = getelementptr { i64, ptr }, ptr %l174, i32 0, i32 1
  %t412 = load ptr, ptr %t411, !tbaa !27
  %t413 = load i64, ptr %l175, !tbaa !24
  %t414 = mul i64 %t413, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t410, ptr %t412, i64 %t414, i1 false)
  %t415 = load { i64, ptr }, ptr %l176, !tbaa !27
  store { i64, ptr } %t415, ptr %l174, !tbaa !27
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t416 = load { i64, ptr }, ptr %l174, !tbaa !27
  store { i64, ptr } %t416, ptr %rv
  br label %ret
bb75:
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t419 = getelementptr %"compiler/emit:fnEm", ptr %t417, i32 0, i32 0
  %t420 = load ptr, ptr %t419, !tbaa !29
  %t421 = load i64, ptr %l14, !tbaa !24
  %t424 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eanyTable(ptr %v0, ptr %s15, ptr %t420, i64 %t421)
  store { i64, ptr } %t424, ptr %l180
  br label %bb76
bb76:
  %t425 = load { i64, ptr }, ptr %l180, !tbaa !27
  store { i64, ptr } %t425, ptr %l15, !tbaa !27
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t427 = load ptr, ptr %lp11
  %t428 = load { i64, ptr }, ptr %t427, !tbaa !27
  %t429 = extractvalue { i64, ptr } { i64 36, ptr @.d203 }, 1
  %t430 = extractvalue { i64, ptr } { i64 36, ptr @.d203 }, 0
  %t432 = extractvalue { i64, ptr } %t428, 1
  %t433 = extractvalue { i64, ptr } %t428, 0
  %t434 = add i64 %t430, %t433
  %t435 = extractvalue { i64, ptr } { i64 3, ptr @.d204 }, 1
  %t436 = extractvalue { i64, ptr } { i64 3, ptr @.d204 }, 0
  %t437 = add i64 %t434, %t436
  %t438 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t437)
  call void @olang_textcopy(ptr %t438, ptr %t429, i64 %t430)
  %t439 = getelementptr i8, ptr %t438, i64 %t430
  call void @olang_textcopy(ptr %t439, ptr %t432, i64 %t433)
  %t440 = getelementptr i8, ptr %t439, i64 %t433
  call void @olang_textcopy(ptr %t440, ptr %t435, i64 %t436)
  %t441 = insertvalue { i64, ptr } undef, i64 %t437, 0
  %t442 = insertvalue { i64, ptr } %t441, ptr %t438, 1
  %t444 = extractvalue { i64, ptr } %t442, 0
  %t445 = extractvalue { i64, ptr } %t442, 1
  %t446 = mul i64 %t444, 1
  %t447 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t446)
  call void @llvm.memcpy.p0.p0.i64(ptr %t447, ptr %t445, i64 %t446, i1 false)
  %t448 = insertvalue { i64, ptr } undef, i64 %t444, 0
  %t449 = insertvalue { i64, ptr } %t448, ptr %t447, 1
  %t452 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s15, ptr %s15, ptr %t426, { i64, ptr } %t449)
  store { i64, ptr } %t452, ptr %l185
  br label %bb77
bb77:
  %t453 = load { i64, ptr }, ptr %l185, !tbaa !27
  store { i64, ptr } %t453, ptr %l16, !tbaa !27
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t455 = load ptr, ptr %lp11
  %t456 = load { i64, ptr }, ptr %t455, !tbaa !27
  %t457 = extractvalue { i64, ptr } { i64 12, ptr @.d205 }, 1
  %t458 = extractvalue { i64, ptr } { i64 12, ptr @.d205 }, 0
  %t460 = extractvalue { i64, ptr } %t456, 1
  %t461 = extractvalue { i64, ptr } %t456, 0
  %t462 = add i64 %t458, %t461
  %t463 = extractvalue { i64, ptr } { i64 6, ptr @.d206 }, 1
  %t464 = extractvalue { i64, ptr } { i64 6, ptr @.d206 }, 0
  %t465 = add i64 %t462, %t464
  %t466 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t465)
  call void @olang_textcopy(ptr %t466, ptr %t457, i64 %t458)
  %t467 = getelementptr i8, ptr %t466, i64 %t458
  call void @olang_textcopy(ptr %t467, ptr %t460, i64 %t461)
  %t468 = getelementptr i8, ptr %t467, i64 %t461
  call void @olang_textcopy(ptr %t468, ptr %t463, i64 %t464)
  %t469 = insertvalue { i64, ptr } undef, i64 %t465, 0
  %t470 = insertvalue { i64, ptr } %t469, ptr %t466, 1
  %t472 = extractvalue { i64, ptr } %t470, 0
  %t473 = extractvalue { i64, ptr } %t470, 1
  %t474 = mul i64 %t472, 1
  %t475 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t474)
  call void @llvm.memcpy.p0.p0.i64(ptr %t475, ptr %t473, i64 %t474, i1 false)
  %t476 = insertvalue { i64, ptr } undef, i64 %t472, 0
  %t477 = insertvalue { i64, ptr } %t476, ptr %t475, 1
  %t480 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s15, ptr %s15, ptr %t454, { i64, ptr } %t477)
  store { i64, ptr } %t480, ptr %l190
  br label %bb78
bb78:
  %t481 = load { i64, ptr }, ptr %l190, !tbaa !27
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t484 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t485 = extractvalue { i64, ptr } { i64 10, ptr @.d207 }, 1
  %t486 = extractvalue { i64, ptr } { i64 10, ptr @.d207 }, 0
  %t488 = extractvalue { i64, ptr } %t481, 1
  %t489 = extractvalue { i64, ptr } %t481, 0
  %t490 = add i64 %t486, %t489
  %t491 = extractvalue { i64, ptr } { i64 7, ptr @.d208 }, 1
  %t492 = extractvalue { i64, ptr } { i64 7, ptr @.d208 }, 0
  %t493 = add i64 %t490, %t492
  %t495 = extractvalue { i64, ptr } %t484, 1
  %t496 = extractvalue { i64, ptr } %t484, 0
  %t497 = add i64 %t493, %t496
  %t498 = extractvalue { i64, ptr } { i64 10, ptr @.d209 }, 1
  %t499 = extractvalue { i64, ptr } { i64 10, ptr @.d209 }, 0
  %t500 = add i64 %t497, %t499
  %t501 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t500)
  call void @olang_textcopy(ptr %t501, ptr %t485, i64 %t486)
  %t502 = getelementptr i8, ptr %t501, i64 %t486
  call void @olang_textcopy(ptr %t502, ptr %t488, i64 %t489)
  %t503 = getelementptr i8, ptr %t502, i64 %t489
  call void @olang_textcopy(ptr %t503, ptr %t491, i64 %t492)
  %t504 = getelementptr i8, ptr %t503, i64 %t492
  call void @olang_textcopy(ptr %t504, ptr %t495, i64 %t496)
  %t505 = getelementptr i8, ptr %t504, i64 %t496
  call void @olang_textcopy(ptr %t505, ptr %t498, i64 %t499)
  %t506 = insertvalue { i64, ptr } undef, i64 %t500, 0
  %t507 = insertvalue { i64, ptr } %t506, ptr %t501, 1
  %t509 = extractvalue { i64, ptr } %t507, 0
  %t510 = extractvalue { i64, ptr } %t507, 1
  %t511 = mul i64 %t509, 1
  %t512 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t511)
  call void @llvm.memcpy.p0.p0.i64(ptr %t512, ptr %t510, i64 %t511, i1 false)
  %t513 = insertvalue { i64, ptr } undef, i64 %t509, 0
  %t514 = insertvalue { i64, ptr } %t513, ptr %t512, 1
  %t517 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s15, ptr %s15, ptr %t482, { i64, ptr } %t514)
  store { i64, ptr } %t517, ptr %l196
  br label %bb79
bb79:
  %t518 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t519 = load ptr, ptr %l0, !tbaa !29
  %t520 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t522 = extractvalue { i64, ptr } { i64 25, ptr @.d210 }, 1
  %t523 = extractvalue { i64, ptr } { i64 25, ptr @.d210 }, 0
  %t525 = extractvalue { i64, ptr } %t520, 1
  %t526 = extractvalue { i64, ptr } %t520, 0
  %t527 = add i64 %t523, %t526
  %t528 = extractvalue { i64, ptr } { i64 6, ptr @.d211 }, 1
  %t529 = extractvalue { i64, ptr } { i64 6, ptr @.d211 }, 0
  %t530 = add i64 %t527, %t529
  %t532 = extractvalue { i64, ptr } %t518, 1
  %t533 = extractvalue { i64, ptr } %t518, 0
  %t534 = add i64 %t530, %t533
  %t535 = extractvalue { i64, ptr } { i64 3, ptr @.d212 }, 1
  %t536 = extractvalue { i64, ptr } { i64 3, ptr @.d212 }, 0
  %t537 = add i64 %t534, %t536
  %t538 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t537)
  call void @olang_textcopy(ptr %t538, ptr %t522, i64 %t523)
  %t539 = getelementptr i8, ptr %t538, i64 %t523
  call void @olang_textcopy(ptr %t539, ptr %t525, i64 %t526)
  %t540 = getelementptr i8, ptr %t539, i64 %t526
  call void @olang_textcopy(ptr %t540, ptr %t528, i64 %t529)
  %t541 = getelementptr i8, ptr %t540, i64 %t529
  call void @olang_textcopy(ptr %t541, ptr %t532, i64 %t533)
  %t542 = getelementptr i8, ptr %t541, i64 %t533
  call void @olang_textcopy(ptr %t542, ptr %t535, i64 %t536)
  %t543 = insertvalue { i64, ptr } undef, i64 %t537, 0
  %t544 = insertvalue { i64, ptr } %t543, ptr %t538, 1
  %t546 = extractvalue { i64, ptr } %t544, 0
  %t547 = extractvalue { i64, ptr } %t544, 1
  %t548 = mul i64 %t546, 1
  %t549 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t548)
  call void @llvm.memcpy.p0.p0.i64(ptr %t549, ptr %t547, i64 %t548, i1 false)
  %t550 = insertvalue { i64, ptr } undef, i64 %t546, 0
  %t551 = insertvalue { i64, ptr } %t550, ptr %t549, 1
  %t554 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t519, { i64, ptr } %t551)
  store { i64, ptr } %t554, ptr %l202
  br label %bb80
bb80:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t555 = load { i64, ptr }, ptr %l202, !tbaa !27
  store { i64, ptr } %t555, ptr %rv
  br label %ret
bb81:
  %t556 = load i32, ptr %l1
  %t558 = trunc i64 38 to i32
  %t559 = icmp eq i32 %t556, %t558
  br i1 %t559, label %bb82, label %bb83
bb82:
  br label %bb84
bb83:
  br label %bb86
bb84:
  %t561 = load ptr, ptr %l0, !tbaa !29
  %t562 = load ptr, ptr %lp11
  %t563 = load { i64, ptr }, ptr %t562, !tbaa !27
  %t564 = extractvalue { i64, ptr } { i64 26, ptr @.d213 }, 1
  %t565 = extractvalue { i64, ptr } { i64 26, ptr @.d213 }, 0
  %t567 = extractvalue { i64, ptr } %t563, 1
  %t568 = extractvalue { i64, ptr } %t563, 0
  %t569 = add i64 %t565, %t568
  %t570 = extractvalue { i64, ptr } { i64 3, ptr @.d214 }, 1
  %t571 = extractvalue { i64, ptr } { i64 3, ptr @.d214 }, 0
  %t572 = add i64 %t569, %t571
  %t573 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t572)
  call void @olang_textcopy(ptr %t573, ptr %t564, i64 %t565)
  %t574 = getelementptr i8, ptr %t573, i64 %t565
  call void @olang_textcopy(ptr %t574, ptr %t567, i64 %t568)
  %t575 = getelementptr i8, ptr %t574, i64 %t568
  call void @olang_textcopy(ptr %t575, ptr %t570, i64 %t571)
  %t576 = insertvalue { i64, ptr } undef, i64 %t572, 0
  %t577 = insertvalue { i64, ptr } %t576, ptr %t573, 1
  %t579 = extractvalue { i64, ptr } %t577, 0
  %t580 = extractvalue { i64, ptr } %t577, 1
  %t581 = mul i64 %t579, 1
  %t582 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t581)
  call void @llvm.memcpy.p0.p0.i64(ptr %t582, ptr %t580, i64 %t581, i1 false)
  %t583 = insertvalue { i64, ptr } undef, i64 %t579, 0
  %t584 = insertvalue { i64, ptr } %t583, ptr %t582, 1
  %t587 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t561, { i64, ptr } %t584)
  store { i64, ptr } %t587, ptr %l209
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s0)
  %t588 = load { i64, ptr }, ptr %l209, !tbaa !27
  store { i64, ptr } %t588, ptr %rv
  br label %ret
bb86:
  %t589 = load i32, ptr %l1
  %t591 = trunc i64 39 to i32
  %t592 = icmp eq i32 %t589, %t591
  br i1 %t592, label %bb87, label %bb88
bb87:
  br label %bb89
bb88:
  br label %bb99
bb89:
  store %olang.scope zeroinitializer, ptr %s25
  %t594 = load ptr, ptr %l0, !tbaa !29
  %t595 = load ptr, ptr %lp11
  %t596 = load { i64, ptr }, ptr %t595, !tbaa !27
  %t597 = extractvalue { i64, ptr } { i64 26, ptr @.d215 }, 1
  %t598 = extractvalue { i64, ptr } { i64 26, ptr @.d215 }, 0
  %t600 = extractvalue { i64, ptr } %t596, 1
  %t601 = extractvalue { i64, ptr } %t596, 0
  %t602 = add i64 %t598, %t601
  %t603 = extractvalue { i64, ptr } { i64 3, ptr @.d216 }, 1
  %t604 = extractvalue { i64, ptr } { i64 3, ptr @.d216 }, 0
  %t605 = add i64 %t602, %t604
  %t606 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t605)
  call void @olang_textcopy(ptr %t606, ptr %t597, i64 %t598)
  %t607 = getelementptr i8, ptr %t606, i64 %t598
  call void @olang_textcopy(ptr %t607, ptr %t600, i64 %t601)
  %t608 = getelementptr i8, ptr %t607, i64 %t601
  call void @olang_textcopy(ptr %t608, ptr %t603, i64 %t604)
  %t609 = insertvalue { i64, ptr } undef, i64 %t605, 0
  %t610 = insertvalue { i64, ptr } %t609, ptr %t606, 1
  %t612 = extractvalue { i64, ptr } %t610, 0
  %t613 = extractvalue { i64, ptr } %t610, 1
  %t614 = mul i64 %t612, 1
  %t615 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t614)
  call void @llvm.memcpy.p0.p0.i64(ptr %t615, ptr %t613, i64 %t614, i1 false)
  %t616 = insertvalue { i64, ptr } undef, i64 %t612, 0
  %t617 = insertvalue { i64, ptr } %t616, ptr %t615, 1
  %t620 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s25, ptr %s25, ptr %t594, { i64, ptr } %t617)
  store { i64, ptr } %t620, ptr %l216
  br label %bb90
bb90:
  %t621 = load { i64, ptr }, ptr %l216, !tbaa !27
  store { i64, ptr } %t621, ptr %l19, !tbaa !27
  %t622 = load ptr, ptr %l0, !tbaa !29
  %t623 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t624 = extractvalue { i64, ptr } { i64 12, ptr @.d217 }, 1
  %t625 = extractvalue { i64, ptr } { i64 12, ptr @.d217 }, 0
  %t627 = extractvalue { i64, ptr } %t623, 1
  %t628 = extractvalue { i64, ptr } %t623, 0
  %t629 = add i64 %t625, %t628
  %t630 = extractvalue { i64, ptr } { i64 6, ptr @.d218 }, 1
  %t631 = extractvalue { i64, ptr } { i64 6, ptr @.d218 }, 0
  %t632 = add i64 %t629, %t631
  %t633 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t632)
  call void @olang_textcopy(ptr %t633, ptr %t624, i64 %t625)
  %t634 = getelementptr i8, ptr %t633, i64 %t625
  call void @olang_textcopy(ptr %t634, ptr %t627, i64 %t628)
  %t635 = getelementptr i8, ptr %t634, i64 %t628
  call void @olang_textcopy(ptr %t635, ptr %t630, i64 %t631)
  %t636 = insertvalue { i64, ptr } undef, i64 %t632, 0
  %t637 = insertvalue { i64, ptr } %t636, ptr %t633, 1
  %t639 = extractvalue { i64, ptr } %t637, 0
  %t640 = extractvalue { i64, ptr } %t637, 1
  %t641 = mul i64 %t639, 1
  %t642 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t641)
  call void @llvm.memcpy.p0.p0.i64(ptr %t642, ptr %t640, i64 %t641, i1 false)
  %t643 = insertvalue { i64, ptr } undef, i64 %t639, 0
  %t644 = insertvalue { i64, ptr } %t643, ptr %t642, 1
  %t647 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s25, ptr %s25, ptr %t622, { i64, ptr } %t644)
  store { i64, ptr } %t647, ptr %l221
  br label %bb91
bb91:
  %t648 = load { i64, ptr }, ptr %l221, !tbaa !27
  %t649 = load ptr, ptr %l0, !tbaa !29
  store ptr %t649, ptr %l222, !tbaa !29
  store { i64, ptr } %t648, ptr %l223, !tbaa !27
  %t651 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t651, ptr %l224, !tbaa !27
  %t652 = load ptr, ptr %l0, !tbaa !29
  %t654 = getelementptr %"compiler/emit:fnEm", ptr %t652, i32 0, i32 0
  %t655 = load ptr, ptr %t654, !tbaa !29
  %t657 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2enoTable(ptr %v0, ptr %s25, ptr %t655)
  store { i64, ptr } %t657, ptr %l227
  br label %bb92
bb92:
  %t658 = extractvalue { i64, ptr } { i64 10, ptr @.d219 }, 1
  %t659 = extractvalue { i64, ptr } { i64 10, ptr @.d219 }, 0
  %t660 = load { i64, ptr }, ptr %l223, !tbaa !27
  %t661 = extractvalue { i64, ptr } %t660, 1
  %t662 = extractvalue { i64, ptr } %t660, 0
  %t663 = add i64 %t659, %t662
  %t664 = extractvalue { i64, ptr } { i64 6, ptr @.d220 }, 1
  %t665 = extractvalue { i64, ptr } { i64 6, ptr @.d220 }, 0
  %t666 = add i64 %t663, %t665
  %t667 = load { i64, ptr }, ptr %l224, !tbaa !27
  %t668 = extractvalue { i64, ptr } %t667, 1
  %t669 = extractvalue { i64, ptr } %t667, 0
  %t670 = add i64 %t666, %t669
  %t671 = extractvalue { i64, ptr } { i64 7, ptr @.d221 }, 1
  %t672 = extractvalue { i64, ptr } { i64 7, ptr @.d221 }, 0
  %t673 = add i64 %t670, %t672
  %t674 = load { i64, ptr }, ptr %l227, !tbaa !27
  %t675 = extractvalue { i64, ptr } %t674, 1
  %t676 = extractvalue { i64, ptr } %t674, 0
  %t677 = add i64 %t673, %t676
  %t678 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t677)
  call void @olang_textcopy(ptr %t678, ptr %t658, i64 %t659)
  %t679 = getelementptr i8, ptr %t678, i64 %t659
  call void @olang_textcopy(ptr %t679, ptr %t661, i64 %t662)
  %t680 = getelementptr i8, ptr %t679, i64 %t662
  call void @olang_textcopy(ptr %t680, ptr %t664, i64 %t665)
  %t681 = getelementptr i8, ptr %t680, i64 %t665
  call void @olang_textcopy(ptr %t681, ptr %t668, i64 %t669)
  %t682 = getelementptr i8, ptr %t681, i64 %t669
  call void @olang_textcopy(ptr %t682, ptr %t671, i64 %t672)
  %t683 = getelementptr i8, ptr %t682, i64 %t672
  call void @olang_textcopy(ptr %t683, ptr %t675, i64 %t676)
  %t684 = insertvalue { i64, ptr } undef, i64 %t677, 0
  %t685 = insertvalue { i64, ptr } %t684, ptr %t678, 1
  %t687 = extractvalue { i64, ptr } %t685, 0
  %t688 = extractvalue { i64, ptr } %t685, 1
  %t689 = mul i64 %t687, 1
  %t690 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t689)
  call void @llvm.memcpy.p0.p0.i64(ptr %t690, ptr %t688, i64 %t689, i1 false)
  %t691 = insertvalue { i64, ptr } undef, i64 %t687, 0
  %t692 = insertvalue { i64, ptr } %t691, ptr %t690, 1
  %t693 = load ptr, ptr %l222, !tbaa !29
  %t695 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s25, ptr %s25, ptr %t693, { i64, ptr } %t692)
  store { i64, ptr } %t695, ptr %l230
  br label %bb93
bb93:
  %t696 = load { i64, ptr }, ptr %l230, !tbaa !27
  %t697 = load ptr, ptr %l0, !tbaa !29
  %t699 = extractvalue { i64, ptr } { i64 14, ptr @.d222 }, 1
  %t700 = extractvalue { i64, ptr } { i64 14, ptr @.d222 }, 0
  %t702 = extractvalue { i64, ptr } %t696, 1
  %t703 = extractvalue { i64, ptr } %t696, 0
  %t704 = add i64 %t700, %t703
  %t705 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t704)
  call void @olang_textcopy(ptr %t705, ptr %t699, i64 %t700)
  %t706 = getelementptr i8, ptr %t705, i64 %t700
  call void @olang_textcopy(ptr %t706, ptr %t702, i64 %t703)
  %t707 = insertvalue { i64, ptr } undef, i64 %t704, 0
  %t708 = insertvalue { i64, ptr } %t707, ptr %t705, 1
  %t710 = extractvalue { i64, ptr } %t708, 0
  %t711 = extractvalue { i64, ptr } %t708, 1
  %t712 = mul i64 %t710, 1
  %t713 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t712)
  call void @llvm.memcpy.p0.p0.i64(ptr %t713, ptr %t711, i64 %t712, i1 false)
  %t714 = insertvalue { i64, ptr } undef, i64 %t710, 0
  %t715 = insertvalue { i64, ptr } %t714, ptr %t713, 1
  %t718 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s25, ptr %s25, ptr %t697, { i64, ptr } %t715)
  store { i64, ptr } %t718, ptr %l235
  br label %bb94
bb94:
  %t719 = load { i64, ptr }, ptr %l235, !tbaa !27
  %t720 = load ptr, ptr %l0, !tbaa !29
  store ptr %t720, ptr %l236, !tbaa !29
  store { i64, ptr } %t719, ptr %l237, !tbaa !27
  %t722 = load ptr, ptr %l0, !tbaa !29
  %t724 = getelementptr %"compiler/emit:fnEm", ptr %t722, i32 0, i32 0
  %t725 = load ptr, ptr %t724, !tbaa !29
  store ptr %t725, ptr %l239, !tbaa !29
  %t726 = load ptr, ptr %l0, !tbaa !29
  store ptr %t726, ptr %l240, !tbaa !29
  %t727 = load ptr, ptr %l0, !tbaa !29
  %t728 = load %"compiler/mir:Range", ptr %l3
  %t731 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t727, %"compiler/mir:Range" %t728, i64 1)
  store { i64, [4 x i64] } %t731, ptr %l243
  br label %bb95
bb95:
  %t732 = load ptr, ptr %l240, !tbaa !29
  %t733 = load { i64, [4 x i64] }, ptr %l243
  %t734 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t732, { i64, [4 x i64] } %t733)
  store i32 %t734, ptr %l244
  br label %bb96
bb96:
  %t735 = load ptr, ptr %l239, !tbaa !29
  %t736 = load i32, ptr %l244, !tbaa !23
  %t737 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etypeid(ptr %v0, ptr %s25, ptr %t735, i32 %t736)
  store { i64, ptr } %t737, ptr %l245
  br label %bb97
bb97:
  %t738 = extractvalue { i64, ptr } { i64 12, ptr @.d223 }, 1
  %t739 = extractvalue { i64, ptr } { i64 12, ptr @.d223 }, 0
  %t740 = load { i64, ptr }, ptr %l237, !tbaa !27
  %t741 = extractvalue { i64, ptr } %t740, 1
  %t742 = extractvalue { i64, ptr } %t740, 0
  %t743 = add i64 %t739, %t742
  %t744 = extractvalue { i64, ptr } { i64 3, ptr @.d224 }, 1
  %t745 = extractvalue { i64, ptr } { i64 3, ptr @.d224 }, 0
  %t746 = add i64 %t743, %t745
  %t747 = load { i64, ptr }, ptr %l245, !tbaa !27
  %t748 = extractvalue { i64, ptr } %t747, 1
  %t749 = extractvalue { i64, ptr } %t747, 0
  %t750 = add i64 %t746, %t749
  %t751 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t750)
  call void @olang_textcopy(ptr %t751, ptr %t738, i64 %t739)
  %t752 = getelementptr i8, ptr %t751, i64 %t739
  call void @olang_textcopy(ptr %t752, ptr %t741, i64 %t742)
  %t753 = getelementptr i8, ptr %t752, i64 %t742
  call void @olang_textcopy(ptr %t753, ptr %t744, i64 %t745)
  %t754 = getelementptr i8, ptr %t753, i64 %t745
  call void @olang_textcopy(ptr %t754, ptr %t748, i64 %t749)
  %t755 = insertvalue { i64, ptr } undef, i64 %t750, 0
  %t756 = insertvalue { i64, ptr } %t755, ptr %t751, 1
  %t758 = extractvalue { i64, ptr } %t756, 0
  %t759 = extractvalue { i64, ptr } %t756, 1
  %t760 = mul i64 %t758, 1
  %t761 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t760)
  call void @llvm.memcpy.p0.p0.i64(ptr %t761, ptr %t759, i64 %t760, i1 false)
  %t762 = insertvalue { i64, ptr } undef, i64 %t758, 0
  %t763 = insertvalue { i64, ptr } %t762, ptr %t761, 1
  %t764 = load ptr, ptr %l236, !tbaa !29
  %t766 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t764, { i64, ptr } %t763)
  store { i64, ptr } %t766, ptr %l248
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s25)
  call void @__olang_scope_close(ptr %s0)
  %t767 = load { i64, ptr }, ptr %l248, !tbaa !27
  store { i64, ptr } %t767, ptr %rv
  br label %ret
bb99:
  %t768 = load i32, ptr %l1
  %t770 = trunc i64 29 to i32
  %t771 = icmp eq i32 %t768, %t770
  br i1 %t771, label %bb100, label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb126
bb102:
  %t773 = load ptr, ptr %l4, !tbaa !29
  %t774 = load i32, ptr %l7, !tbaa !23
  %t777 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t773, i32 %t774)
  store i1 %t777, ptr %l253
  br label %bb103
bb103:
  %t778 = load i1, ptr %l253, !tbaa !21
  br i1 %t778, label %bb104, label %bb105
bb104:
  %t779 = load ptr, ptr %l4, !tbaa !29
  %t780 = load i32, ptr %l7, !tbaa !23
  %t783 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t779, i32 %t780)
  store i32 %t783, ptr %l257
  br label %bb106
bb105:
  %t784 = load i32, ptr %l7, !tbaa !23
  store i32 %t784, ptr %l254, !tbaa !23
  br label %bb107
bb106:
  %t786 = load i32, ptr %l257, !tbaa !23
  store i32 %t786, ptr %l254, !tbaa !23
  br label %bb107
bb107:
  %t787 = load i32, ptr %l254, !tbaa !23
  %t788 = load ptr, ptr %l0, !tbaa !29
  %t792 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t788, i32 %t787)
  store i32 %t792, ptr %l261
  br label %bb108
bb108:
  %t793 = load i32, ptr %l261, !tbaa !23
  store i32 %t793, ptr %l24, !tbaa !23
  %t794 = load ptr, ptr %l0, !tbaa !29
  %t796 = getelementptr %"compiler/emit:fnEm", ptr %t794, i32 0, i32 0
  %t797 = load ptr, ptr %t796, !tbaa !29
  %t799 = getelementptr %"compiler/emit:Emitter", ptr %t797, i32 0, i32 46
  %t800 = load i1, ptr %t799, !tbaa !21
  br i1 %t800, label %bb109, label %bb110
bb109:
  %t802 = load i32, ptr %l24, !tbaa !23
  %t803 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t806 = icmp ne i32 %t802, %t803
  store i1 %t806, ptr %l265, !tbaa !21
  br label %bb111
bb110:
  store i1 false, ptr %l265, !tbaa !21
  br label %bb111
bb111:
  %t808 = load i1, ptr %l265, !tbaa !21
  br i1 %t808, label %bb112, label %bb113
bb112:
  %t809 = load ptr, ptr %l0, !tbaa !29
  %t810 = load i32, ptr %l24, !tbaa !23
  %t813 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixed(ptr %v0, ptr %t809, i32 %t810)
  store i1 %t813, ptr %l272
  br label %bb114
bb113:
  store i1 false, ptr %l269, !tbaa !21
  br label %bb115
bb114:
  %t814 = load i1, ptr %l272, !tbaa !21
  %t815 = xor i1 %t814, true
  store i1 %t815, ptr %l269, !tbaa !21
  br label %bb115
bb115:
  %t817 = load i1, ptr %l269, !tbaa !21
  br i1 %t817, label %bb116, label %bb117
bb116:
  store %olang.scope zeroinitializer, ptr %s32
  %t818 = load ptr, ptr %l0, !tbaa !29
  %t819 = load ptr, ptr %lp11
  %t820 = load { i64, ptr }, ptr %t819, !tbaa !27
  %t821 = extractvalue { i64, ptr } { i64 26, ptr @.d225 }, 1
  %t822 = extractvalue { i64, ptr } { i64 26, ptr @.d225 }, 0
  %t824 = extractvalue { i64, ptr } %t820, 1
  %t825 = extractvalue { i64, ptr } %t820, 0
  %t826 = add i64 %t822, %t825
  %t827 = extractvalue { i64, ptr } { i64 3, ptr @.d226 }, 1
  %t828 = extractvalue { i64, ptr } { i64 3, ptr @.d226 }, 0
  %t829 = add i64 %t826, %t828
  %t830 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t829)
  call void @olang_textcopy(ptr %t830, ptr %t821, i64 %t822)
  %t831 = getelementptr i8, ptr %t830, i64 %t822
  call void @olang_textcopy(ptr %t831, ptr %t824, i64 %t825)
  %t832 = getelementptr i8, ptr %t831, i64 %t825
  call void @olang_textcopy(ptr %t832, ptr %t827, i64 %t828)
  %t833 = insertvalue { i64, ptr } undef, i64 %t829, 0
  %t834 = insertvalue { i64, ptr } %t833, ptr %t830, 1
  %t836 = extractvalue { i64, ptr } %t834, 0
  %t837 = extractvalue { i64, ptr } %t834, 1
  %t838 = mul i64 %t836, 1
  %t839 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t838)
  call void @llvm.memcpy.p0.p0.i64(ptr %t839, ptr %t837, i64 %t838, i1 false)
  %t840 = insertvalue { i64, ptr } undef, i64 %t836, 0
  %t841 = insertvalue { i64, ptr } %t840, ptr %t839, 1
  %t844 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s32, ptr %s32, ptr %t818, { i64, ptr } %t841)
  store { i64, ptr } %t844, ptr %l278
  br label %bb118
bb117:
  br label %bb125
bb118:
  %t845 = load { i64, ptr }, ptr %l278, !tbaa !27
  store { i64, ptr } %t845, ptr %l25, !tbaa !27
  %t846 = load ptr, ptr %l0, !tbaa !29
  %t847 = load ptr, ptr %lp11
  %t848 = load { i64, ptr }, ptr %t847, !tbaa !27
  %t849 = extractvalue { i64, ptr } { i64 26, ptr @.d227 }, 1
  %t850 = extractvalue { i64, ptr } { i64 26, ptr @.d227 }, 0
  %t852 = extractvalue { i64, ptr } %t848, 1
  %t853 = extractvalue { i64, ptr } %t848, 0
  %t854 = add i64 %t850, %t853
  %t855 = extractvalue { i64, ptr } { i64 3, ptr @.d228 }, 1
  %t856 = extractvalue { i64, ptr } { i64 3, ptr @.d228 }, 0
  %t857 = add i64 %t854, %t856
  %t858 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t857)
  call void @olang_textcopy(ptr %t858, ptr %t849, i64 %t850)
  %t859 = getelementptr i8, ptr %t858, i64 %t850
  call void @olang_textcopy(ptr %t859, ptr %t852, i64 %t853)
  %t860 = getelementptr i8, ptr %t859, i64 %t853
  call void @olang_textcopy(ptr %t860, ptr %t855, i64 %t856)
  %t861 = insertvalue { i64, ptr } undef, i64 %t857, 0
  %t862 = insertvalue { i64, ptr } %t861, ptr %t858, 1
  %t864 = extractvalue { i64, ptr } %t862, 0
  %t865 = extractvalue { i64, ptr } %t862, 1
  %t866 = mul i64 %t864, 1
  %t867 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t866)
  call void @llvm.memcpy.p0.p0.i64(ptr %t867, ptr %t865, i64 %t866, i1 false)
  %t868 = insertvalue { i64, ptr } undef, i64 %t864, 0
  %t869 = insertvalue { i64, ptr } %t868, ptr %t867, 1
  %t872 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s32, ptr %s32, ptr %t846, { i64, ptr } %t869)
  store { i64, ptr } %t872, ptr %l283
  br label %bb119
bb119:
  %t873 = load { i64, ptr }, ptr %l283, !tbaa !27
  store { i64, ptr } %t873, ptr %l26, !tbaa !27
  %t874 = load ptr, ptr %l0, !tbaa !29
  store ptr %t874, ptr %l284, !tbaa !29
  %t875 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t875, ptr %l285, !tbaa !27
  %t876 = load ptr, ptr %l0, !tbaa !29
  store ptr %t876, ptr %l286, !tbaa !29
  %t877 = load ptr, ptr %l4, !tbaa !29
  %t878 = load i32, ptr %l24, !tbaa !23
  %t881 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t877, i32 %t878)
  store i32 %t881, ptr %l289
  br label %bb120
bb120:
  %t882 = load ptr, ptr %l286, !tbaa !29
  %t883 = load i32, ptr %l289, !tbaa !23
  %t884 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t882, i32 %t883)
  store i64 %t884, ptr %l290
  br label %bb121
bb121:
  %t885 = extractvalue { i64, ptr } { i64 8, ptr @.d229 }, 1
  %t886 = extractvalue { i64, ptr } { i64 8, ptr @.d229 }, 0
  %t887 = load { i64, ptr }, ptr %l285, !tbaa !27
  %t888 = extractvalue { i64, ptr } %t887, 1
  %t889 = extractvalue { i64, ptr } %t887, 0
  %t890 = add i64 %t886, %t889
  %t891 = extractvalue { i64, ptr } { i64 2, ptr @.d230 }, 1
  %t892 = extractvalue { i64, ptr } { i64 2, ptr @.d230 }, 0
  %t893 = add i64 %t890, %t892
  %t894 = load i64, ptr %l290, !tbaa !24
  %t895 = call i64 @__olang_fmt_i64(ptr null, i64 %t894)
  %t896 = add i64 %t893, %t895
  %t897 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t896)
  call void @olang_textcopy(ptr %t897, ptr %t885, i64 %t886)
  %t898 = getelementptr i8, ptr %t897, i64 %t886
  call void @olang_textcopy(ptr %t898, ptr %t888, i64 %t889)
  %t899 = getelementptr i8, ptr %t898, i64 %t889
  call void @olang_textcopy(ptr %t899, ptr %t891, i64 %t892)
  %t900 = getelementptr i8, ptr %t899, i64 %t892
  %t901 = call i64 @__olang_fmt_i64(ptr %t900, i64 %t894)
  %t902 = insertvalue { i64, ptr } undef, i64 %t896, 0
  %t903 = insertvalue { i64, ptr } %t902, ptr %t897, 1
  %t905 = extractvalue { i64, ptr } %t903, 0
  %t906 = extractvalue { i64, ptr } %t903, 1
  %t907 = mul i64 %t905, 1
  %t908 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t907)
  call void @llvm.memcpy.p0.p0.i64(ptr %t908, ptr %t906, i64 %t907, i1 false)
  %t909 = insertvalue { i64, ptr } undef, i64 %t905, 0
  %t910 = insertvalue { i64, ptr } %t909, ptr %t908, 1
  %t911 = load ptr, ptr %l284, !tbaa !29
  %t913 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s32, ptr %s32, ptr %t911, { i64, ptr } %t910)
  store { i64, ptr } %t913, ptr %l293
  br label %bb122
bb122:
  %t914 = load { i64, ptr }, ptr %l293, !tbaa !27
  store { i64, ptr } %t914, ptr %l27, !tbaa !27
  %t915 = load ptr, ptr %l0, !tbaa !29
  %t917 = getelementptr %"compiler/emit:fnEm", ptr %t915, i32 0, i32 0
  %t918 = load ptr, ptr %t917, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s32, ptr %t918, { i64, ptr } { i64 18, ptr @.d231 })
  br label %bb123
bb123:
  %t920 = load ptr, ptr %l0, !tbaa !29
  %t921 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t922 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t923 = extractvalue { i64, ptr } { i64 34, ptr @.d232 }, 1
  %t924 = extractvalue { i64, ptr } { i64 34, ptr @.d232 }, 0
  %t926 = extractvalue { i64, ptr } %t921, 1
  %t927 = extractvalue { i64, ptr } %t921, 0
  %t928 = add i64 %t924, %t927
  %t929 = extractvalue { i64, ptr } { i64 6, ptr @.d233 }, 1
  %t930 = extractvalue { i64, ptr } { i64 6, ptr @.d233 }, 0
  %t931 = add i64 %t928, %t930
  %t933 = extractvalue { i64, ptr } %t922, 1
  %t934 = extractvalue { i64, ptr } %t922, 0
  %t935 = add i64 %t931, %t934
  %t936 = extractvalue { i64, ptr } { i64 1, ptr @.d234 }, 1
  %t937 = extractvalue { i64, ptr } { i64 1, ptr @.d234 }, 0
  %t938 = add i64 %t935, %t937
  %t939 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t938)
  call void @olang_textcopy(ptr %t939, ptr %t923, i64 %t924)
  %t940 = getelementptr i8, ptr %t939, i64 %t924
  call void @olang_textcopy(ptr %t940, ptr %t926, i64 %t927)
  %t941 = getelementptr i8, ptr %t940, i64 %t927
  call void @olang_textcopy(ptr %t941, ptr %t929, i64 %t930)
  %t942 = getelementptr i8, ptr %t941, i64 %t930
  call void @olang_textcopy(ptr %t942, ptr %t933, i64 %t934)
  %t943 = getelementptr i8, ptr %t942, i64 %t934
  call void @olang_textcopy(ptr %t943, ptr %t936, i64 %t937)
  %t944 = insertvalue { i64, ptr } undef, i64 %t938, 0
  %t945 = insertvalue { i64, ptr } %t944, ptr %t939, 1
  %t947 = extractvalue { i64, ptr } %t945, 0
  %t948 = extractvalue { i64, ptr } %t945, 1
  %t949 = mul i64 %t947, 1
  %t950 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t949)
  call void @llvm.memcpy.p0.p0.i64(ptr %t950, ptr %t948, i64 %t949, i1 false)
  %t951 = insertvalue { i64, ptr } undef, i64 %t947, 0
  %t952 = insertvalue { i64, ptr } %t951, ptr %t950, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s32, ptr %t920, { i64, ptr } %t952)
  br label %bb124
bb124:
  call void @__olang_scope_close(ptr %s32)
  br label %bb125
bb125:
  store { i64, ptr } { i64 5, ptr @.d235 }, ptr %l301, !tbaa !27
  %t955 = load { i64, ptr }, ptr %l301, !tbaa !27
  store { i64, ptr } %t955, ptr %l302, !tbaa !27
  %t956 = load { i64, ptr }, ptr %l302, !tbaa !27
  %t957 = extractvalue { i64, ptr } %t956, 0
  store i64 %t957, ptr %l303, !tbaa !24
  %t958 = load i64, ptr %l303, !tbaa !24
  %t959 = mul i64 %t958, 1
  %t960 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t959)
  %t961 = insertvalue { i64, ptr } undef, i64 %t958, 0
  %t962 = insertvalue { i64, ptr } %t961, ptr %t960, 1
  store { i64, ptr } %t962, ptr %l304, !tbaa !27
  %t963 = getelementptr { i64, ptr }, ptr %l304, i32 0, i32 1
  %t964 = load ptr, ptr %t963, !tbaa !27
  %t965 = getelementptr { i64, ptr }, ptr %l302, i32 0, i32 1
  %t966 = load ptr, ptr %t965, !tbaa !27
  %t967 = load i64, ptr %l303, !tbaa !24
  %t968 = mul i64 %t967, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t964, ptr %t966, i64 %t968, i1 false)
  %t969 = load { i64, ptr }, ptr %l304, !tbaa !27
  store { i64, ptr } %t969, ptr %l302, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t970 = load { i64, ptr }, ptr %l302, !tbaa !27
  store { i64, ptr } %t970, ptr %rv
  br label %ret
bb126:
  %t971 = load i32, ptr %l1
  %t973 = trunc i64 22 to i32
  %t974 = icmp eq i32 %t971, %t973
  br i1 %t974, label %bb127, label %bb128
bb127:
  br label %bb129
bb128:
  br label %bb145
bb129:
  %t976 = load ptr, ptr %l4, !tbaa !29
  %t977 = load i32, ptr %l7, !tbaa !23
  %t980 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t976, i32 %t977)
  store i1 %t980, ptr %l309
  br label %bb130
bb130:
  %t981 = load i1, ptr %l309, !tbaa !21
  br i1 %t981, label %bb131, label %bb132
bb131:
  %t982 = load ptr, ptr %l4, !tbaa !29
  %t983 = load i32, ptr %l7, !tbaa !23
  %t986 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t982, i32 %t983)
  store i32 %t986, ptr %l313
  br label %bb133
bb132:
  %t987 = load i32, ptr %l7, !tbaa !23
  store i32 %t987, ptr %l310, !tbaa !23
  br label %bb134
bb133:
  %t989 = load i32, ptr %l313, !tbaa !23
  store i32 %t989, ptr %l310, !tbaa !23
  br label %bb134
bb134:
  %t990 = load i32, ptr %l310, !tbaa !23
  %t991 = load ptr, ptr %l0, !tbaa !29
  %t995 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t991, i32 %t990)
  store i32 %t995, ptr %l317
  br label %bb135
bb135:
  %t996 = load i32, ptr %l317, !tbaa !23
  store i32 %t996, ptr %l29, !tbaa !23
  %t997 = load i32, ptr %l29, !tbaa !23
  %t998 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t1001 = icmp ne i32 %t997, %t998
  br i1 %t1001, label %bb136, label %bb137
bb136:
  %t1003 = load ptr, ptr %l0, !tbaa !29
  %t1004 = load i32, ptr %l29, !tbaa !23
  %t1007 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixed(ptr %v0, ptr %t1003, i32 %t1004)
  store i1 %t1007, ptr %l324
  br label %bb138
bb137:
  store i1 false, ptr %l321, !tbaa !21
  br label %bb139
bb138:
  %t1008 = load i1, ptr %l324, !tbaa !21
  store i1 %t1008, ptr %l321, !tbaa !21
  br label %bb139
bb139:
  %t1009 = load i1, ptr %l321, !tbaa !21
  br i1 %t1009, label %bb140, label %bb141
bb140:
  %t1010 = load ptr, ptr %l0, !tbaa !29
  %t1011 = load i32, ptr %l29, !tbaa !23
  %t1014 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixedLen(ptr %v0, ptr %t1010, i32 %t1011)
  store i64 %t1014, ptr %l327
  br label %bb142
bb141:
  br label %bb143
bb142:
  %t1015 = load i64, ptr %l327, !tbaa !24
  %t1016 = call i64 @__olang_fmt_i64(ptr null, i64 %t1015)
  %t1017 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1016)
  %t1018 = call i64 @__olang_fmt_i64(ptr %t1017, i64 %t1015)
  %t1019 = insertvalue { i64, ptr } undef, i64 %t1016, 0
  %t1020 = insertvalue { i64, ptr } %t1019, ptr %t1017, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t1020, ptr %rv
  br label %ret
bb143:
  %t1022 = load ptr, ptr %l0, !tbaa !29
  %t1023 = load ptr, ptr %lp11
  %t1024 = load { i64, ptr }, ptr %t1023, !tbaa !27
  %t1025 = extractvalue { i64, ptr } { i64 26, ptr @.d236 }, 1
  %t1026 = extractvalue { i64, ptr } { i64 26, ptr @.d236 }, 0
  %t1028 = extractvalue { i64, ptr } %t1024, 1
  %t1029 = extractvalue { i64, ptr } %t1024, 0
  %t1030 = add i64 %t1026, %t1029
  %t1031 = extractvalue { i64, ptr } { i64 3, ptr @.d237 }, 1
  %t1032 = extractvalue { i64, ptr } { i64 3, ptr @.d237 }, 0
  %t1033 = add i64 %t1030, %t1032
  %t1034 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1033)
  call void @olang_textcopy(ptr %t1034, ptr %t1025, i64 %t1026)
  %t1035 = getelementptr i8, ptr %t1034, i64 %t1026
  call void @olang_textcopy(ptr %t1035, ptr %t1028, i64 %t1029)
  %t1036 = getelementptr i8, ptr %t1035, i64 %t1029
  call void @olang_textcopy(ptr %t1036, ptr %t1031, i64 %t1032)
  %t1037 = insertvalue { i64, ptr } undef, i64 %t1033, 0
  %t1038 = insertvalue { i64, ptr } %t1037, ptr %t1034, 1
  %t1040 = extractvalue { i64, ptr } %t1038, 0
  %t1041 = extractvalue { i64, ptr } %t1038, 1
  %t1042 = mul i64 %t1040, 1
  %t1043 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1042)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1043, ptr %t1041, i64 %t1042, i1 false)
  %t1044 = insertvalue { i64, ptr } undef, i64 %t1040, 0
  %t1045 = insertvalue { i64, ptr } %t1044, ptr %t1043, 1
  %t1048 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t1022, { i64, ptr } %t1045)
  store { i64, ptr } %t1048, ptr %l333
  br label %bb144
bb144:
  call void @__olang_scope_close(ptr %s0)
  %t1049 = load { i64, ptr }, ptr %l333, !tbaa !27
  store { i64, ptr } %t1049, ptr %rv
  br label %ret
bb145:
  %t1050 = load i32, ptr %l1
  %t1052 = trunc i64 24 to i32
  %t1053 = icmp eq i32 %t1050, %t1052
  br i1 %t1053, label %bb146, label %bb147
bb146:
  br label %bb148
bb147:
  br label %bb153
bb148:
  store %olang.scope zeroinitializer, ptr %s41
  %t1055 = load ptr, ptr %l4, !tbaa !29
  %t1056 = load i32, ptr %l7, !tbaa !23
  %t1059 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t1055, i32 %t1056)
  store i32 %t1059, ptr %l338
  br label %bb149
bb149:
  %t1060 = load i32, ptr %l338, !tbaa !23
  store i32 %t1060, ptr %l30, !tbaa !23
  %t1061 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1061, ptr %l339, !tbaa !29
  %t1062 = load ptr, ptr %l0, !tbaa !29
  %t1063 = load i32, ptr %l30, !tbaa !23
  %t1066 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s41, ptr %t1062, i32 %t1063)
  store { i64, ptr } %t1066, ptr %l342
  br label %bb150
bb150:
  %t1067 = load ptr, ptr %lp11
  %t1068 = load { i64, ptr }, ptr %t1067, !tbaa !27
  store { i64, ptr } %t1068, ptr %l343, !tbaa !27
  %t1069 = load ptr, ptr %l0, !tbaa !29
  %t1070 = load i32, ptr %l30, !tbaa !23
  %t1073 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t1069, i32 %t1070)
  store i64 %t1073, ptr %l346
  br label %bb151
bb151:
  %t1074 = extractvalue { i64, ptr } { i64 12, ptr @.d238 }, 1
  %t1075 = extractvalue { i64, ptr } { i64 12, ptr @.d238 }, 0
  %t1076 = load { i64, ptr }, ptr %l342, !tbaa !27
  %t1077 = extractvalue { i64, ptr } %t1076, 1
  %t1078 = extractvalue { i64, ptr } %t1076, 0
  %t1079 = add i64 %t1075, %t1078
  %t1080 = extractvalue { i64, ptr } { i64 6, ptr @.d239 }, 1
  %t1081 = extractvalue { i64, ptr } { i64 6, ptr @.d239 }, 0
  %t1082 = add i64 %t1079, %t1081
  %t1083 = load { i64, ptr }, ptr %l343, !tbaa !27
  %t1084 = extractvalue { i64, ptr } %t1083, 1
  %t1085 = extractvalue { i64, ptr } %t1083, 0
  %t1086 = add i64 %t1082, %t1085
  %t1087 = extractvalue { i64, ptr } { i64 16, ptr @.d240 }, 1
  %t1088 = extractvalue { i64, ptr } { i64 16, ptr @.d240 }, 0
  %t1089 = add i64 %t1086, %t1088
  %t1090 = load i64, ptr %l346, !tbaa !24
  %t1091 = call i64 @__olang_fmt_i64(ptr null, i64 %t1090)
  %t1092 = add i64 %t1089, %t1091
  %t1093 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1092)
  call void @olang_textcopy(ptr %t1093, ptr %t1074, i64 %t1075)
  %t1094 = getelementptr i8, ptr %t1093, i64 %t1075
  call void @olang_textcopy(ptr %t1094, ptr %t1077, i64 %t1078)
  %t1095 = getelementptr i8, ptr %t1094, i64 %t1078
  call void @olang_textcopy(ptr %t1095, ptr %t1080, i64 %t1081)
  %t1096 = getelementptr i8, ptr %t1095, i64 %t1081
  call void @olang_textcopy(ptr %t1096, ptr %t1084, i64 %t1085)
  %t1097 = getelementptr i8, ptr %t1096, i64 %t1085
  call void @olang_textcopy(ptr %t1097, ptr %t1087, i64 %t1088)
  %t1098 = getelementptr i8, ptr %t1097, i64 %t1088
  %t1099 = call i64 @__olang_fmt_i64(ptr %t1098, i64 %t1090)
  %t1100 = insertvalue { i64, ptr } undef, i64 %t1092, 0
  %t1101 = insertvalue { i64, ptr } %t1100, ptr %t1093, 1
  %t1103 = extractvalue { i64, ptr } %t1101, 0
  %t1104 = extractvalue { i64, ptr } %t1101, 1
  %t1105 = mul i64 %t1103, 1
  %t1106 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1105)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1106, ptr %t1104, i64 %t1105, i1 false)
  %t1107 = insertvalue { i64, ptr } undef, i64 %t1103, 0
  %t1108 = insertvalue { i64, ptr } %t1107, ptr %t1106, 1
  %t1109 = load ptr, ptr %l339, !tbaa !29
  %t1111 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t1109, { i64, ptr } %t1108)
  store { i64, ptr } %t1111, ptr %l349
  br label %bb152
bb152:
  call void @__olang_scope_close(ptr %s41)
  call void @__olang_scope_close(ptr %s0)
  %t1112 = load { i64, ptr }, ptr %l349, !tbaa !27
  store { i64, ptr } %t1112, ptr %rv
  br label %ret
bb153:
  %t1113 = load i32, ptr %l1
  %t1115 = trunc i64 30 to i32
  %t1116 = icmp eq i32 %t1113, %t1115
  br i1 %t1116, label %bb154, label %bb155
bb154:
  br label %bb160
bb155:
  %t1118 = load i32, ptr %l1
  %t1120 = trunc i64 31 to i32
  %t1121 = icmp eq i32 %t1118, %t1120
  br i1 %t1121, label %bb156, label %bb157
bb156:
  br label %bb160
bb157:
  %t1123 = load i32, ptr %l1
  %t1125 = trunc i64 32 to i32
  %t1126 = icmp eq i32 %t1123, %t1125
  br i1 %t1126, label %bb158, label %bb159
bb158:
  br label %bb160
bb159:
  br label %bb178
bb160:
  store %olang.scope zeroinitializer, ptr %s43
  %t1128 = load i32, ptr %l1
  %t1130 = trunc i64 32 to i32
  %t1131 = icmp eq i32 %t1128, %t1130
  br i1 %t1131, label %bb161, label %bb162
bb161:
  store { i64, ptr } { i64 5, ptr @.d241 }, ptr %l358, !tbaa !27
  br label %bb166
bb162:
  %t1133 = load i32, ptr %l1
  %t1135 = trunc i64 30 to i32
  %t1136 = icmp eq i32 %t1133, %t1135
  br i1 %t1136, label %bb163, label %bb164
bb163:
  store { i64, ptr } { i64 4, ptr @.d242 }, ptr %l361, !tbaa !27
  br label %bb165
bb164:
  store { i64, ptr } { i64 4, ptr @.d243 }, ptr %l361, !tbaa !27
  br label %bb165
bb165:
  %t1138 = load { i64, ptr }, ptr %l361, !tbaa !27
  store { i64, ptr } %t1138, ptr %l358, !tbaa !27
  br label %bb166
bb166:
  %t1139 = load { i64, ptr }, ptr %l358, !tbaa !27
  store { i64, ptr } %t1139, ptr %l31, !tbaa !27
  %t1140 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t1141 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1142 = extractvalue { i64, ptr } { i64 5, ptr @.d244 }, 1
  %t1143 = extractvalue { i64, ptr } { i64 5, ptr @.d244 }, 0
  %t1145 = extractvalue { i64, ptr } %t1140, 1
  %t1146 = extractvalue { i64, ptr } %t1140, 0
  %t1147 = add i64 %t1143, %t1146
  %t1148 = extractvalue { i64, ptr } { i64 1, ptr @.d245 }, 1
  %t1149 = extractvalue { i64, ptr } { i64 1, ptr @.d245 }, 0
  %t1150 = add i64 %t1147, %t1149
  %t1152 = extractvalue { i64, ptr } %t1141, 1
  %t1153 = extractvalue { i64, ptr } %t1141, 0
  %t1154 = add i64 %t1150, %t1153
  %t1155 = call ptr @__olang_scope_alloc(ptr %s43, i64 %t1154)
  call void @olang_textcopy(ptr %t1155, ptr %t1142, i64 %t1143)
  %t1156 = getelementptr i8, ptr %t1155, i64 %t1143
  call void @olang_textcopy(ptr %t1156, ptr %t1145, i64 %t1146)
  %t1157 = getelementptr i8, ptr %t1156, i64 %t1146
  call void @olang_textcopy(ptr %t1157, ptr %t1148, i64 %t1149)
  %t1158 = getelementptr i8, ptr %t1157, i64 %t1149
  call void @olang_textcopy(ptr %t1158, ptr %t1152, i64 %t1153)
  %t1159 = insertvalue { i64, ptr } undef, i64 %t1154, 0
  %t1160 = insertvalue { i64, ptr } %t1159, ptr %t1155, 1
  store { i64, ptr } %t1160, ptr %l32, !tbaa !27
  %t1162 = load ptr, ptr %l0, !tbaa !29
  %t1164 = getelementptr %"compiler/emit:fnEm", ptr %t1162, i32 0, i32 0
  %t1165 = load ptr, ptr %t1164, !tbaa !29
  store ptr %t1165, ptr %l366, !tbaa !29
  %t1166 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t1166, ptr %l367, !tbaa !27
  %t1167 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t1167, ptr %l368, !tbaa !27
  %t1168 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t1168, ptr %l369, !tbaa !27
  %t1169 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t1169, ptr %l370, !tbaa !27
  %t1170 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t1171 = load ptr, ptr @__olang_prog_scope
  %t1173 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t1171, ptr %s43, { i64, ptr } %t1170, { i64, ptr } { i64 5, ptr @.d246 })
  store i1 %t1173, ptr %l372
  br label %bb167
bb167:
  %t1174 = load i1, ptr %l372, !tbaa !21
  %t1175 = xor i1 %t1174, true
  br i1 %t1175, label %bb168, label %bb169
bb168:
  store { i64, ptr } { i64 5, ptr @.d247 }, ptr %l374, !tbaa !27
  br label %bb170
bb169:
  store { i64, ptr } { i64 1, ptr @.d248 }, ptr %l374, !tbaa !27
  br label %bb170
bb170:
  %t1177 = load { i64, ptr }, ptr %l368, !tbaa !27
  %t1178 = extractvalue { i64, ptr } %t1177, 1
  %t1179 = extractvalue { i64, ptr } %t1177, 0
  %t1180 = extractvalue { i64, ptr } { i64 2, ptr @.d249 }, 1
  %t1181 = extractvalue { i64, ptr } { i64 2, ptr @.d249 }, 0
  %t1182 = add i64 %t1179, %t1181
  %t1183 = load { i64, ptr }, ptr %l369, !tbaa !27
  %t1184 = extractvalue { i64, ptr } %t1183, 1
  %t1185 = extractvalue { i64, ptr } %t1183, 0
  %t1186 = add i64 %t1182, %t1185
  %t1187 = extractvalue { i64, ptr } { i64 1, ptr @.d250 }, 1
  %t1188 = extractvalue { i64, ptr } { i64 1, ptr @.d250 }, 0
  %t1189 = add i64 %t1186, %t1188
  %t1190 = load { i64, ptr }, ptr %l370, !tbaa !27
  %t1191 = extractvalue { i64, ptr } %t1190, 1
  %t1192 = extractvalue { i64, ptr } %t1190, 0
  %t1193 = add i64 %t1189, %t1192
  %t1194 = load { i64, ptr }, ptr %l374, !tbaa !27
  %t1195 = extractvalue { i64, ptr } %t1194, 1
  %t1196 = extractvalue { i64, ptr } %t1194, 0
  %t1197 = add i64 %t1193, %t1196
  %t1198 = call ptr @__olang_scope_alloc(ptr %s43, i64 %t1197)
  call void @olang_textcopy(ptr %t1198, ptr %t1178, i64 %t1179)
  %t1199 = getelementptr i8, ptr %t1198, i64 %t1179
  call void @olang_textcopy(ptr %t1199, ptr %t1180, i64 %t1181)
  %t1200 = getelementptr i8, ptr %t1199, i64 %t1181
  call void @olang_textcopy(ptr %t1200, ptr %t1184, i64 %t1185)
  %t1201 = getelementptr i8, ptr %t1200, i64 %t1185
  call void @olang_textcopy(ptr %t1201, ptr %t1187, i64 %t1188)
  %t1202 = getelementptr i8, ptr %t1201, i64 %t1188
  call void @olang_textcopy(ptr %t1202, ptr %t1191, i64 %t1192)
  %t1203 = getelementptr i8, ptr %t1202, i64 %t1192
  call void @olang_textcopy(ptr %t1203, ptr %t1195, i64 %t1196)
  %t1204 = insertvalue { i64, ptr } undef, i64 %t1197, 0
  %t1205 = insertvalue { i64, ptr } %t1204, ptr %t1198, 1
  %t1207 = extractvalue { i64, ptr } %t1205, 0
  %t1208 = extractvalue { i64, ptr } %t1205, 1
  %t1209 = mul i64 %t1207, 1
  %t1210 = call ptr @__olang_scope_alloc(ptr %s43, i64 %t1209)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1210, ptr %t1208, i64 %t1209, i1 false)
  %t1211 = insertvalue { i64, ptr } undef, i64 %t1207, 0
  %t1212 = insertvalue { i64, ptr } %t1211, ptr %t1210, 1
  %t1213 = load ptr, ptr %l366, !tbaa !29
  %t1214 = load { i64, ptr }, ptr %l367, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s43, ptr %s43, ptr %t1213, { i64, ptr } %t1214, { i64, ptr } %t1212)
  br label %bb171
bb171:
  %t1216 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1216, ptr %l377, !tbaa !29
  %t1217 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t1217, ptr %l378, !tbaa !27
  %t1218 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t1218, ptr %l379, !tbaa !27
  %t1219 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t1219, ptr %l380, !tbaa !27
  %t1220 = load ptr, ptr %lp11
  %t1221 = load { i64, ptr }, ptr %t1220, !tbaa !27
  store { i64, ptr } %t1221, ptr %l381, !tbaa !27
  %t1222 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t1223 = load ptr, ptr @__olang_prog_scope
  %t1225 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t1223, ptr %s43, { i64, ptr } %t1222, { i64, ptr } { i64 5, ptr @.d251 })
  store i1 %t1225, ptr %l383
  br label %bb172
bb172:
  %t1226 = load i1, ptr %l383, !tbaa !21
  %t1227 = xor i1 %t1226, true
  br i1 %t1227, label %bb173, label %bb174
bb173:
  store { i64, ptr } { i64 11, ptr @.d252 }, ptr %l385, !tbaa !27
  br label %bb175
bb174:
  store { i64, ptr } { i64 1, ptr @.d253 }, ptr %l385, !tbaa !27
  br label %bb175
bb175:
  %t1229 = extractvalue { i64, ptr } { i64 5, ptr @.d254 }, 1
  %t1230 = extractvalue { i64, ptr } { i64 5, ptr @.d254 }, 0
  %t1231 = load { i64, ptr }, ptr %l378, !tbaa !27
  %t1232 = extractvalue { i64, ptr } %t1231, 1
  %t1233 = extractvalue { i64, ptr } %t1231, 0
  %t1234 = add i64 %t1230, %t1233
  %t1235 = extractvalue { i64, ptr } { i64 2, ptr @.d255 }, 1
  %t1236 = extractvalue { i64, ptr } { i64 2, ptr @.d255 }, 0
  %t1237 = add i64 %t1234, %t1236
  %t1238 = load { i64, ptr }, ptr %l379, !tbaa !27
  %t1239 = extractvalue { i64, ptr } %t1238, 1
  %t1240 = extractvalue { i64, ptr } %t1238, 0
  %t1241 = add i64 %t1237, %t1240
  %t1242 = extractvalue { i64, ptr } { i64 1, ptr @.d256 }, 1
  %t1243 = extractvalue { i64, ptr } { i64 1, ptr @.d256 }, 0
  %t1244 = add i64 %t1241, %t1243
  %t1245 = load { i64, ptr }, ptr %l380, !tbaa !27
  %t1246 = extractvalue { i64, ptr } %t1245, 1
  %t1247 = extractvalue { i64, ptr } %t1245, 0
  %t1248 = add i64 %t1244, %t1247
  %t1249 = extractvalue { i64, ptr } { i64 1, ptr @.d257 }, 1
  %t1250 = extractvalue { i64, ptr } { i64 1, ptr @.d257 }, 0
  %t1251 = add i64 %t1248, %t1250
  %t1252 = load { i64, ptr }, ptr %l381, !tbaa !27
  %t1253 = extractvalue { i64, ptr } %t1252, 1
  %t1254 = extractvalue { i64, ptr } %t1252, 0
  %t1255 = add i64 %t1251, %t1254
  %t1256 = load { i64, ptr }, ptr %l385, !tbaa !27
  %t1257 = extractvalue { i64, ptr } %t1256, 1
  %t1258 = extractvalue { i64, ptr } %t1256, 0
  %t1259 = add i64 %t1255, %t1258
  %t1260 = call ptr @__olang_scope_alloc(ptr %s43, i64 %t1259)
  call void @olang_textcopy(ptr %t1260, ptr %t1229, i64 %t1230)
  %t1261 = getelementptr i8, ptr %t1260, i64 %t1230
  call void @olang_textcopy(ptr %t1261, ptr %t1232, i64 %t1233)
  %t1262 = getelementptr i8, ptr %t1261, i64 %t1233
  call void @olang_textcopy(ptr %t1262, ptr %t1235, i64 %t1236)
  %t1263 = getelementptr i8, ptr %t1262, i64 %t1236
  call void @olang_textcopy(ptr %t1263, ptr %t1239, i64 %t1240)
  %t1264 = getelementptr i8, ptr %t1263, i64 %t1240
  call void @olang_textcopy(ptr %t1264, ptr %t1242, i64 %t1243)
  %t1265 = getelementptr i8, ptr %t1264, i64 %t1243
  call void @olang_textcopy(ptr %t1265, ptr %t1246, i64 %t1247)
  %t1266 = getelementptr i8, ptr %t1265, i64 %t1247
  call void @olang_textcopy(ptr %t1266, ptr %t1249, i64 %t1250)
  %t1267 = getelementptr i8, ptr %t1266, i64 %t1250
  call void @olang_textcopy(ptr %t1267, ptr %t1253, i64 %t1254)
  %t1268 = getelementptr i8, ptr %t1267, i64 %t1254
  call void @olang_textcopy(ptr %t1268, ptr %t1257, i64 %t1258)
  %t1269 = insertvalue { i64, ptr } undef, i64 %t1259, 0
  %t1270 = insertvalue { i64, ptr } %t1269, ptr %t1260, 1
  %t1272 = extractvalue { i64, ptr } %t1270, 0
  %t1273 = extractvalue { i64, ptr } %t1270, 1
  %t1274 = mul i64 %t1272, 1
  %t1275 = call ptr @__olang_scope_alloc(ptr %s43, i64 %t1274)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1275, ptr %t1273, i64 %t1274, i1 false)
  %t1276 = insertvalue { i64, ptr } undef, i64 %t1272, 0
  %t1277 = insertvalue { i64, ptr } %t1276, ptr %t1275, 1
  %t1278 = load ptr, ptr %l377, !tbaa !29
  %t1280 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s43, ptr %s43, ptr %t1278, { i64, ptr } %t1277)
  store { i64, ptr } %t1280, ptr %l388
  br label %bb176
bb176:
  %t1281 = load { i64, ptr }, ptr %l388, !tbaa !27
  %t1282 = load ptr, ptr %l0, !tbaa !29
  %t1284 = load i32, ptr %l7, !tbaa !23
  %t1285 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t1290 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ewidth(ptr %v0, ptr %s43, ptr %v1, ptr %t1282, { i64, ptr } %t1281, i32 %t1284, i32 %t1285)
  store { i64, ptr } %t1290, ptr %l393
  br label %bb177
bb177:
  call void @__olang_scope_close(ptr %s43)
  call void @__olang_scope_close(ptr %s0)
  %t1291 = load { i64, ptr }, ptr %l393, !tbaa !27
  store { i64, ptr } %t1291, ptr %rv
  br label %ret
bb178:
  %t1292 = load i32, ptr %l1
  %t1294 = trunc i64 35 to i32
  %t1295 = icmp eq i32 %t1292, %t1294
  br i1 %t1295, label %bb179, label %bb180
bb179:
  br label %bb181
bb180:
  br label %bb188
bb181:
  store %olang.scope zeroinitializer, ptr %s47
  %t1297 = load ptr, ptr %l4, !tbaa !29
  %t1298 = load i32, ptr %l7, !tbaa !23
  %t1301 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t1297, i32 %t1298)
  store i64 %t1301, ptr %l398
  br label %bb182
bb182:
  %t1302 = load i64, ptr %l398, !tbaa !24
  %t1303 = icmp eq i64 %t1302, 8
  br i1 %t1303, label %bb183, label %bb184
bb183:
  %t1305 = load ptr, ptr %lp11
  %t1306 = load { i64, ptr }, ptr %t1305, !tbaa !27
  call void @__olang_scope_close(ptr %s47)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t1306, ptr %rv
  br label %ret
bb184:
  br label %bb185
bb185:
  %t1308 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1309 = extractvalue { i64, ptr } { i64 11, ptr @.d258 }, 1
  %t1310 = extractvalue { i64, ptr } { i64 11, ptr @.d258 }, 0
  %t1312 = extractvalue { i64, ptr } %t1308, 1
  %t1313 = extractvalue { i64, ptr } %t1308, 0
  %t1314 = add i64 %t1310, %t1313
  %t1315 = call ptr @__olang_scope_alloc(ptr %s47, i64 %t1314)
  call void @olang_textcopy(ptr %t1315, ptr %t1309, i64 %t1310)
  %t1316 = getelementptr i8, ptr %t1315, i64 %t1310
  call void @olang_textcopy(ptr %t1316, ptr %t1312, i64 %t1313)
  %t1317 = insertvalue { i64, ptr } undef, i64 %t1314, 0
  %t1318 = insertvalue { i64, ptr } %t1317, ptr %t1315, 1
  store { i64, ptr } %t1318, ptr %l34, !tbaa !27
  %t1320 = load ptr, ptr %l0, !tbaa !29
  %t1322 = getelementptr %"compiler/emit:fnEm", ptr %t1320, i32 0, i32 0
  %t1323 = load ptr, ptr %t1322, !tbaa !29
  %t1324 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t1325 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1326 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t1327 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1329 = extractvalue { i64, ptr } %t1325, 1
  %t1330 = extractvalue { i64, ptr } %t1325, 0
  %t1331 = extractvalue { i64, ptr } { i64 2, ptr @.d259 }, 1
  %t1332 = extractvalue { i64, ptr } { i64 2, ptr @.d259 }, 0
  %t1333 = add i64 %t1330, %t1332
  %t1335 = extractvalue { i64, ptr } %t1326, 1
  %t1336 = extractvalue { i64, ptr } %t1326, 0
  %t1337 = add i64 %t1333, %t1336
  %t1338 = extractvalue { i64, ptr } { i64 1, ptr @.d260 }, 1
  %t1339 = extractvalue { i64, ptr } { i64 1, ptr @.d260 }, 0
  %t1340 = add i64 %t1337, %t1339
  %t1342 = extractvalue { i64, ptr } %t1327, 1
  %t1343 = extractvalue { i64, ptr } %t1327, 0
  %t1344 = add i64 %t1340, %t1343
  %t1345 = extractvalue { i64, ptr } { i64 1, ptr @.d261 }, 1
  %t1346 = extractvalue { i64, ptr } { i64 1, ptr @.d261 }, 0
  %t1347 = add i64 %t1344, %t1346
  %t1348 = call ptr @__olang_scope_alloc(ptr %s47, i64 %t1347)
  call void @olang_textcopy(ptr %t1348, ptr %t1329, i64 %t1330)
  %t1349 = getelementptr i8, ptr %t1348, i64 %t1330
  call void @olang_textcopy(ptr %t1349, ptr %t1331, i64 %t1332)
  %t1350 = getelementptr i8, ptr %t1349, i64 %t1332
  call void @olang_textcopy(ptr %t1350, ptr %t1335, i64 %t1336)
  %t1351 = getelementptr i8, ptr %t1350, i64 %t1336
  call void @olang_textcopy(ptr %t1351, ptr %t1338, i64 %t1339)
  %t1352 = getelementptr i8, ptr %t1351, i64 %t1339
  call void @olang_textcopy(ptr %t1352, ptr %t1342, i64 %t1343)
  %t1353 = getelementptr i8, ptr %t1352, i64 %t1343
  call void @olang_textcopy(ptr %t1353, ptr %t1345, i64 %t1346)
  %t1354 = insertvalue { i64, ptr } undef, i64 %t1347, 0
  %t1355 = insertvalue { i64, ptr } %t1354, ptr %t1348, 1
  %t1357 = extractvalue { i64, ptr } %t1355, 0
  %t1358 = extractvalue { i64, ptr } %t1355, 1
  %t1359 = mul i64 %t1357, 1
  %t1360 = call ptr @__olang_scope_alloc(ptr %s47, i64 %t1359)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1360, ptr %t1358, i64 %t1359, i1 false)
  %t1361 = insertvalue { i64, ptr } undef, i64 %t1357, 0
  %t1362 = insertvalue { i64, ptr } %t1361, ptr %t1360, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s47, ptr %s47, ptr %t1323, { i64, ptr } %t1324, { i64, ptr } %t1362)
  br label %bb186
bb186:
  %t1366 = load ptr, ptr %l0, !tbaa !29
  %t1367 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1368 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t1369 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1370 = load ptr, ptr %lp11
  %t1371 = load { i64, ptr }, ptr %t1370, !tbaa !27
  %t1372 = extractvalue { i64, ptr } { i64 5, ptr @.d262 }, 1
  %t1373 = extractvalue { i64, ptr } { i64 5, ptr @.d262 }, 0
  %t1375 = extractvalue { i64, ptr } %t1367, 1
  %t1376 = extractvalue { i64, ptr } %t1367, 0
  %t1377 = add i64 %t1373, %t1376
  %t1378 = extractvalue { i64, ptr } { i64 2, ptr @.d263 }, 1
  %t1379 = extractvalue { i64, ptr } { i64 2, ptr @.d263 }, 0
  %t1380 = add i64 %t1377, %t1379
  %t1382 = extractvalue { i64, ptr } %t1368, 1
  %t1383 = extractvalue { i64, ptr } %t1368, 0
  %t1384 = add i64 %t1380, %t1383
  %t1385 = extractvalue { i64, ptr } { i64 1, ptr @.d264 }, 1
  %t1386 = extractvalue { i64, ptr } { i64 1, ptr @.d264 }, 0
  %t1387 = add i64 %t1384, %t1386
  %t1389 = extractvalue { i64, ptr } %t1369, 1
  %t1390 = extractvalue { i64, ptr } %t1369, 0
  %t1391 = add i64 %t1387, %t1390
  %t1392 = extractvalue { i64, ptr } { i64 1, ptr @.d265 }, 1
  %t1393 = extractvalue { i64, ptr } { i64 1, ptr @.d265 }, 0
  %t1394 = add i64 %t1391, %t1393
  %t1396 = extractvalue { i64, ptr } %t1371, 1
  %t1397 = extractvalue { i64, ptr } %t1371, 0
  %t1398 = add i64 %t1394, %t1397
  %t1399 = extractvalue { i64, ptr } { i64 1, ptr @.d266 }, 1
  %t1400 = extractvalue { i64, ptr } { i64 1, ptr @.d266 }, 0
  %t1401 = add i64 %t1398, %t1400
  %t1402 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1401)
  call void @olang_textcopy(ptr %t1402, ptr %t1372, i64 %t1373)
  %t1403 = getelementptr i8, ptr %t1402, i64 %t1373
  call void @olang_textcopy(ptr %t1403, ptr %t1375, i64 %t1376)
  %t1404 = getelementptr i8, ptr %t1403, i64 %t1376
  call void @olang_textcopy(ptr %t1404, ptr %t1378, i64 %t1379)
  %t1405 = getelementptr i8, ptr %t1404, i64 %t1379
  call void @olang_textcopy(ptr %t1405, ptr %t1382, i64 %t1383)
  %t1406 = getelementptr i8, ptr %t1405, i64 %t1383
  call void @olang_textcopy(ptr %t1406, ptr %t1385, i64 %t1386)
  %t1407 = getelementptr i8, ptr %t1406, i64 %t1386
  call void @olang_textcopy(ptr %t1407, ptr %t1389, i64 %t1390)
  %t1408 = getelementptr i8, ptr %t1407, i64 %t1390
  call void @olang_textcopy(ptr %t1408, ptr %t1392, i64 %t1393)
  %t1409 = getelementptr i8, ptr %t1408, i64 %t1393
  call void @olang_textcopy(ptr %t1409, ptr %t1396, i64 %t1397)
  %t1410 = getelementptr i8, ptr %t1409, i64 %t1397
  call void @olang_textcopy(ptr %t1410, ptr %t1399, i64 %t1400)
  %t1411 = insertvalue { i64, ptr } undef, i64 %t1401, 0
  %t1412 = insertvalue { i64, ptr } %t1411, ptr %t1402, 1
  %t1414 = extractvalue { i64, ptr } %t1412, 0
  %t1415 = extractvalue { i64, ptr } %t1412, 1
  %t1416 = mul i64 %t1414, 1
  %t1417 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1416)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1417, ptr %t1415, i64 %t1416, i1 false)
  %t1418 = insertvalue { i64, ptr } undef, i64 %t1414, 0
  %t1419 = insertvalue { i64, ptr } %t1418, ptr %t1417, 1
  %t1422 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t1366, { i64, ptr } %t1419)
  store { i64, ptr } %t1422, ptr %l418
  br label %bb187
bb187:
  call void @__olang_scope_close(ptr %s47)
  call void @__olang_scope_close(ptr %s0)
  %t1423 = load { i64, ptr }, ptr %l418, !tbaa !27
  store { i64, ptr } %t1423, ptr %rv
  br label %ret
bb188:
  %t1424 = load i32, ptr %l1
  %t1426 = trunc i64 33 to i32
  %t1427 = icmp eq i32 %t1424, %t1426
  br i1 %t1427, label %bb189, label %bb190
bb189:
  br label %bb193
bb190:
  %t1429 = load i32, ptr %l1
  %t1431 = trunc i64 34 to i32
  %t1432 = icmp eq i32 %t1429, %t1431
  br i1 %t1432, label %bb191, label %bb192
bb191:
  br label %bb193
bb192:
  br label %bb202
bb193:
  store %olang.scope zeroinitializer, ptr %s52
  %t1434 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1434, ptr %l423, !tbaa !29
  %t1435 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1435, ptr %l424, !tbaa !29
  %t1436 = load ptr, ptr %l0, !tbaa !29
  %t1437 = load %"compiler/mir:Range", ptr %l3
  %t1440 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t1436, %"compiler/mir:Range" %t1437, i64 1)
  store { i64, [4 x i64] } %t1440, ptr %l427
  br label %bb194
bb194:
  %t1441 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t1442 = load ptr, ptr %l424, !tbaa !29
  %t1443 = load { i64, [4 x i64] }, ptr %l427
  %t1445 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s52, ptr %t1442, { i64, [4 x i64] } %t1443, i32 %t1441)
  store { i64, ptr } %t1445, ptr %l429
  br label %bb195
bb195:
  %t1446 = load { i64, ptr }, ptr %l429, !tbaa !27
  %t1447 = extractvalue { i64, ptr } %t1446, 0
  %t1448 = extractvalue { i64, ptr } %t1446, 1
  %t1449 = mul i64 %t1447, 1
  %t1450 = call ptr @__olang_scope_alloc(ptr %s52, i64 %t1449)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1450, ptr %t1448, i64 %t1449, i1 false)
  %t1451 = insertvalue { i64, ptr } undef, i64 %t1447, 0
  %t1452 = insertvalue { i64, ptr } %t1451, ptr %t1450, 1
  %t1453 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t1454 = load i32, ptr %l7, !tbaa !23
  %t1455 = load ptr, ptr %l423, !tbaa !29
  %t1459 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ewidth(ptr %v0, ptr %s52, ptr %s52, ptr %t1455, { i64, ptr } %t1452, i32 %t1453, i32 %t1454)
  store { i64, ptr } %t1459, ptr %l433
  br label %bb196
bb196:
  %t1460 = load { i64, ptr }, ptr %l433, !tbaa !27
  store { i64, ptr } %t1460, ptr %l35, !tbaa !27
  %t1461 = load i32, ptr %l1
  %t1463 = trunc i64 33 to i32
  %t1464 = icmp eq i32 %t1461, %t1463
  br i1 %t1464, label %bb197, label %bb198
bb197:
  store { i64, ptr } { i64 1, ptr @.d267 }, ptr %l436, !tbaa !27
  br label %bb199
bb198:
  store { i64, ptr } { i64 1, ptr @.d268 }, ptr %l436, !tbaa !27
  br label %bb199
bb199:
  %t1466 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1467 = extractvalue { i64, ptr } { i64 8, ptr @.d269 }, 1
  %t1468 = extractvalue { i64, ptr } { i64 8, ptr @.d269 }, 0
  %t1469 = load { i64, ptr }, ptr %l436, !tbaa !27
  %t1470 = extractvalue { i64, ptr } %t1469, 1
  %t1471 = extractvalue { i64, ptr } %t1469, 0
  %t1472 = add i64 %t1468, %t1471
  %t1473 = extractvalue { i64, ptr } { i64 1, ptr @.d270 }, 1
  %t1474 = extractvalue { i64, ptr } { i64 1, ptr @.d270 }, 0
  %t1475 = add i64 %t1472, %t1474
  %t1477 = extractvalue { i64, ptr } %t1466, 1
  %t1478 = extractvalue { i64, ptr } %t1466, 0
  %t1479 = add i64 %t1475, %t1478
  %t1480 = call ptr @__olang_scope_alloc(ptr %s52, i64 %t1479)
  call void @olang_textcopy(ptr %t1480, ptr %t1467, i64 %t1468)
  %t1481 = getelementptr i8, ptr %t1480, i64 %t1468
  call void @olang_textcopy(ptr %t1481, ptr %t1470, i64 %t1471)
  %t1482 = getelementptr i8, ptr %t1481, i64 %t1471
  call void @olang_textcopy(ptr %t1482, ptr %t1473, i64 %t1474)
  %t1483 = getelementptr i8, ptr %t1482, i64 %t1474
  call void @olang_textcopy(ptr %t1483, ptr %t1477, i64 %t1478)
  %t1484 = insertvalue { i64, ptr } undef, i64 %t1479, 0
  %t1485 = insertvalue { i64, ptr } %t1484, ptr %t1480, 1
  store { i64, ptr } %t1485, ptr %l36, !tbaa !27
  %t1487 = load ptr, ptr %l0, !tbaa !29
  %t1489 = getelementptr %"compiler/emit:fnEm", ptr %t1487, i32 0, i32 0
  %t1490 = load ptr, ptr %t1489, !tbaa !29
  %t1491 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t1492 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1493 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t1494 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1495 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1496 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1498 = extractvalue { i64, ptr } %t1492, 1
  %t1499 = extractvalue { i64, ptr } %t1492, 0
  %t1500 = extractvalue { i64, ptr } { i64 2, ptr @.d271 }, 1
  %t1501 = extractvalue { i64, ptr } { i64 2, ptr @.d271 }, 0
  %t1502 = add i64 %t1499, %t1501
  %t1504 = extractvalue { i64, ptr } %t1493, 1
  %t1505 = extractvalue { i64, ptr } %t1493, 0
  %t1506 = add i64 %t1502, %t1505
  %t1507 = extractvalue { i64, ptr } { i64 1, ptr @.d272 }, 1
  %t1508 = extractvalue { i64, ptr } { i64 1, ptr @.d272 }, 0
  %t1509 = add i64 %t1506, %t1508
  %t1511 = extractvalue { i64, ptr } %t1494, 1
  %t1512 = extractvalue { i64, ptr } %t1494, 0
  %t1513 = add i64 %t1509, %t1512
  %t1514 = extractvalue { i64, ptr } { i64 2, ptr @.d273 }, 1
  %t1515 = extractvalue { i64, ptr } { i64 2, ptr @.d273 }, 0
  %t1516 = add i64 %t1513, %t1515
  %t1518 = extractvalue { i64, ptr } %t1495, 1
  %t1519 = extractvalue { i64, ptr } %t1495, 0
  %t1520 = add i64 %t1516, %t1519
  %t1521 = extractvalue { i64, ptr } { i64 2, ptr @.d274 }, 1
  %t1522 = extractvalue { i64, ptr } { i64 2, ptr @.d274 }, 0
  %t1523 = add i64 %t1520, %t1522
  %t1525 = extractvalue { i64, ptr } %t1496, 1
  %t1526 = extractvalue { i64, ptr } %t1496, 0
  %t1527 = add i64 %t1523, %t1526
  %t1528 = extractvalue { i64, ptr } { i64 1, ptr @.d275 }, 1
  %t1529 = extractvalue { i64, ptr } { i64 1, ptr @.d275 }, 0
  %t1530 = add i64 %t1527, %t1529
  %t1531 = call ptr @__olang_scope_alloc(ptr %s52, i64 %t1530)
  call void @olang_textcopy(ptr %t1531, ptr %t1498, i64 %t1499)
  %t1532 = getelementptr i8, ptr %t1531, i64 %t1499
  call void @olang_textcopy(ptr %t1532, ptr %t1500, i64 %t1501)
  %t1533 = getelementptr i8, ptr %t1532, i64 %t1501
  call void @olang_textcopy(ptr %t1533, ptr %t1504, i64 %t1505)
  %t1534 = getelementptr i8, ptr %t1533, i64 %t1505
  call void @olang_textcopy(ptr %t1534, ptr %t1507, i64 %t1508)
  %t1535 = getelementptr i8, ptr %t1534, i64 %t1508
  call void @olang_textcopy(ptr %t1535, ptr %t1511, i64 %t1512)
  %t1536 = getelementptr i8, ptr %t1535, i64 %t1512
  call void @olang_textcopy(ptr %t1536, ptr %t1514, i64 %t1515)
  %t1537 = getelementptr i8, ptr %t1536, i64 %t1515
  call void @olang_textcopy(ptr %t1537, ptr %t1518, i64 %t1519)
  %t1538 = getelementptr i8, ptr %t1537, i64 %t1519
  call void @olang_textcopy(ptr %t1538, ptr %t1521, i64 %t1522)
  %t1539 = getelementptr i8, ptr %t1538, i64 %t1522
  call void @olang_textcopy(ptr %t1539, ptr %t1525, i64 %t1526)
  %t1540 = getelementptr i8, ptr %t1539, i64 %t1526
  call void @olang_textcopy(ptr %t1540, ptr %t1528, i64 %t1529)
  %t1541 = insertvalue { i64, ptr } undef, i64 %t1530, 0
  %t1542 = insertvalue { i64, ptr } %t1541, ptr %t1531, 1
  %t1544 = extractvalue { i64, ptr } %t1542, 0
  %t1545 = extractvalue { i64, ptr } %t1542, 1
  %t1546 = mul i64 %t1544, 1
  %t1547 = call ptr @__olang_scope_alloc(ptr %s52, i64 %t1546)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1547, ptr %t1545, i64 %t1546, i1 false)
  %t1548 = insertvalue { i64, ptr } undef, i64 %t1544, 0
  %t1549 = insertvalue { i64, ptr } %t1548, ptr %t1547, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s52, ptr %s52, ptr %t1490, { i64, ptr } %t1491, { i64, ptr } %t1549)
  br label %bb200
bb200:
  %t1553 = load ptr, ptr %l0, !tbaa !29
  %t1554 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1555 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t1556 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1557 = load ptr, ptr %lp11
  %t1558 = load { i64, ptr }, ptr %t1557, !tbaa !27
  %t1559 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1560 = load ptr, ptr %lp11
  %t1561 = load { i64, ptr }, ptr %t1560, !tbaa !27
  %t1562 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1563 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t1564 = extractvalue { i64, ptr } { i64 5, ptr @.d276 }, 1
  %t1565 = extractvalue { i64, ptr } { i64 5, ptr @.d276 }, 0
  %t1567 = extractvalue { i64, ptr } %t1554, 1
  %t1568 = extractvalue { i64, ptr } %t1554, 0
  %t1569 = add i64 %t1565, %t1568
  %t1570 = extractvalue { i64, ptr } { i64 2, ptr @.d277 }, 1
  %t1571 = extractvalue { i64, ptr } { i64 2, ptr @.d277 }, 0
  %t1572 = add i64 %t1569, %t1571
  %t1574 = extractvalue { i64, ptr } %t1555, 1
  %t1575 = extractvalue { i64, ptr } %t1555, 0
  %t1576 = add i64 %t1572, %t1575
  %t1577 = extractvalue { i64, ptr } { i64 1, ptr @.d278 }, 1
  %t1578 = extractvalue { i64, ptr } { i64 1, ptr @.d278 }, 0
  %t1579 = add i64 %t1576, %t1578
  %t1581 = extractvalue { i64, ptr } %t1556, 1
  %t1582 = extractvalue { i64, ptr } %t1556, 0
  %t1583 = add i64 %t1579, %t1582
  %t1584 = extractvalue { i64, ptr } { i64 1, ptr @.d279 }, 1
  %t1585 = extractvalue { i64, ptr } { i64 1, ptr @.d279 }, 0
  %t1586 = add i64 %t1583, %t1585
  %t1588 = extractvalue { i64, ptr } %t1558, 1
  %t1589 = extractvalue { i64, ptr } %t1558, 0
  %t1590 = add i64 %t1586, %t1589
  %t1591 = extractvalue { i64, ptr } { i64 2, ptr @.d280 }, 1
  %t1592 = extractvalue { i64, ptr } { i64 2, ptr @.d280 }, 0
  %t1593 = add i64 %t1590, %t1592
  %t1595 = extractvalue { i64, ptr } %t1559, 1
  %t1596 = extractvalue { i64, ptr } %t1559, 0
  %t1597 = add i64 %t1593, %t1596
  %t1598 = extractvalue { i64, ptr } { i64 1, ptr @.d281 }, 1
  %t1599 = extractvalue { i64, ptr } { i64 1, ptr @.d281 }, 0
  %t1600 = add i64 %t1597, %t1599
  %t1602 = extractvalue { i64, ptr } %t1561, 1
  %t1603 = extractvalue { i64, ptr } %t1561, 0
  %t1604 = add i64 %t1600, %t1603
  %t1605 = extractvalue { i64, ptr } { i64 2, ptr @.d282 }, 1
  %t1606 = extractvalue { i64, ptr } { i64 2, ptr @.d282 }, 0
  %t1607 = add i64 %t1604, %t1606
  %t1609 = extractvalue { i64, ptr } %t1562, 1
  %t1610 = extractvalue { i64, ptr } %t1562, 0
  %t1611 = add i64 %t1607, %t1610
  %t1612 = extractvalue { i64, ptr } { i64 1, ptr @.d283 }, 1
  %t1613 = extractvalue { i64, ptr } { i64 1, ptr @.d283 }, 0
  %t1614 = add i64 %t1611, %t1613
  %t1616 = extractvalue { i64, ptr } %t1563, 1
  %t1617 = extractvalue { i64, ptr } %t1563, 0
  %t1618 = add i64 %t1614, %t1617
  %t1619 = extractvalue { i64, ptr } { i64 1, ptr @.d284 }, 1
  %t1620 = extractvalue { i64, ptr } { i64 1, ptr @.d284 }, 0
  %t1621 = add i64 %t1618, %t1620
  %t1622 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1621)
  call void @olang_textcopy(ptr %t1622, ptr %t1564, i64 %t1565)
  %t1623 = getelementptr i8, ptr %t1622, i64 %t1565
  call void @olang_textcopy(ptr %t1623, ptr %t1567, i64 %t1568)
  %t1624 = getelementptr i8, ptr %t1623, i64 %t1568
  call void @olang_textcopy(ptr %t1624, ptr %t1570, i64 %t1571)
  %t1625 = getelementptr i8, ptr %t1624, i64 %t1571
  call void @olang_textcopy(ptr %t1625, ptr %t1574, i64 %t1575)
  %t1626 = getelementptr i8, ptr %t1625, i64 %t1575
  call void @olang_textcopy(ptr %t1626, ptr %t1577, i64 %t1578)
  %t1627 = getelementptr i8, ptr %t1626, i64 %t1578
  call void @olang_textcopy(ptr %t1627, ptr %t1581, i64 %t1582)
  %t1628 = getelementptr i8, ptr %t1627, i64 %t1582
  call void @olang_textcopy(ptr %t1628, ptr %t1584, i64 %t1585)
  %t1629 = getelementptr i8, ptr %t1628, i64 %t1585
  call void @olang_textcopy(ptr %t1629, ptr %t1588, i64 %t1589)
  %t1630 = getelementptr i8, ptr %t1629, i64 %t1589
  call void @olang_textcopy(ptr %t1630, ptr %t1591, i64 %t1592)
  %t1631 = getelementptr i8, ptr %t1630, i64 %t1592
  call void @olang_textcopy(ptr %t1631, ptr %t1595, i64 %t1596)
  %t1632 = getelementptr i8, ptr %t1631, i64 %t1596
  call void @olang_textcopy(ptr %t1632, ptr %t1598, i64 %t1599)
  %t1633 = getelementptr i8, ptr %t1632, i64 %t1599
  call void @olang_textcopy(ptr %t1633, ptr %t1602, i64 %t1603)
  %t1634 = getelementptr i8, ptr %t1633, i64 %t1603
  call void @olang_textcopy(ptr %t1634, ptr %t1605, i64 %t1606)
  %t1635 = getelementptr i8, ptr %t1634, i64 %t1606
  call void @olang_textcopy(ptr %t1635, ptr %t1609, i64 %t1610)
  %t1636 = getelementptr i8, ptr %t1635, i64 %t1610
  call void @olang_textcopy(ptr %t1636, ptr %t1612, i64 %t1613)
  %t1637 = getelementptr i8, ptr %t1636, i64 %t1613
  call void @olang_textcopy(ptr %t1637, ptr %t1616, i64 %t1617)
  %t1638 = getelementptr i8, ptr %t1637, i64 %t1617
  call void @olang_textcopy(ptr %t1638, ptr %t1619, i64 %t1620)
  %t1639 = insertvalue { i64, ptr } undef, i64 %t1621, 0
  %t1640 = insertvalue { i64, ptr } %t1639, ptr %t1622, 1
  %t1642 = extractvalue { i64, ptr } %t1640, 0
  %t1643 = extractvalue { i64, ptr } %t1640, 1
  %t1644 = mul i64 %t1642, 1
  %t1645 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1644)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1645, ptr %t1643, i64 %t1644, i1 false)
  %t1646 = insertvalue { i64, ptr } undef, i64 %t1642, 0
  %t1647 = insertvalue { i64, ptr } %t1646, ptr %t1645, 1
  %t1650 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t1553, { i64, ptr } %t1647)
  store { i64, ptr } %t1650, ptr %l460
  br label %bb201
bb201:
  call void @__olang_scope_close(ptr %s52)
  call void @__olang_scope_close(ptr %s0)
  %t1651 = load { i64, ptr }, ptr %l460, !tbaa !27
  store { i64, ptr } %t1651, ptr %rv
  br label %ret
bb202:
  br i1 true, label %bb203, label %bb204
bb203:
  br label %bb205
bb204:
  br label %bb206
bb205:
  br label %bb207
bb206:
  call void @__olang_check_failed(ptr @olang_loc_d23ee61a0d8dfe9f_a353f177579d38fb)
  unreachable
bb207:
  %t1652 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1652, ptr %l461, !tbaa !29
  %t1653 = load ptr, ptr %l0, !tbaa !29
  %t1654 = load %"compiler/mir:Range", ptr %l3
  %t1657 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t1653, %"compiler/mir:Range" %t1654, i64 1)
  store { i64, [4 x i64] } %t1657, ptr %l464
  br label %bb208
bb208:
  %t1658 = load i32, ptr %l6, !tbaa !23
  %t1659 = load ptr, ptr %l461, !tbaa !29
  %t1660 = load { i64, [4 x i64] }, ptr %l464
  %t1662 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s0, ptr %t1659, { i64, [4 x i64] } %t1660, i32 %t1658)
  store { i64, ptr } %t1662, ptr %l466
  br label %bb209
bb209:
  %t1663 = load { i64, ptr }, ptr %l466, !tbaa !27
  store { i64, ptr } %t1663, ptr %l37, !tbaa !27
  %t1664 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1666 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t1664, { i64, ptr } { i64 6, ptr @.d285 })
  store i1 %t1666, ptr %l468
  br label %bb210
bb210:
  %t1667 = load i1, ptr %l468, !tbaa !21
  br i1 %t1667, label %bb211, label %bb212
bb211:
  store %olang.scope zeroinitializer, ptr %s57
  %t1668 = load ptr, ptr %l0, !tbaa !29
  %t1669 = load ptr, ptr %lp11
  %t1670 = load { i64, ptr }, ptr %t1669, !tbaa !27
  %t1673 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ewidenBF16(ptr %v0, ptr %v1, ptr %s57, ptr %s57, ptr %t1668, { i64, ptr } %t1670, { i64, ptr } { i64 5, ptr @.d286 })
  store { i64, ptr } %t1673, ptr %l471
  br label %bb213
bb212:
  br label %bb266
bb213:
  %t1674 = load { i64, ptr }, ptr %l471, !tbaa !27
  store { i64, ptr } %t1674, ptr %l38, !tbaa !27
  %t1675 = load ptr, ptr %l0, !tbaa !29
  %t1676 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t1679 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ewidenBF16(ptr %v0, ptr %s0, ptr %s57, ptr %s57, ptr %t1675, { i64, ptr } %t1676, { i64, ptr } { i64 5, ptr @.d287 })
  store { i64, ptr } %t1679, ptr %l474
  br label %bb214
bb214:
  %t1680 = load { i64, ptr }, ptr %l474, !tbaa !27
  store { i64, ptr } %t1680, ptr %l39, !tbaa !27
  %t1681 = load i32, ptr %l1
  %t1683 = trunc i64 3 to i32
  %t1684 = icmp eq i32 %t1681, %t1683
  br i1 %t1684, label %bb215, label %bb216
bb215:
  br label %bb217
bb216:
  br label %bb218
bb217:
  store { i64, ptr } { i64 4, ptr @.d288 }, ptr %l475, !tbaa !27
  br label %bb239
bb218:
  %t1686 = load i32, ptr %l1
  %t1688 = trunc i64 4 to i32
  %t1689 = icmp eq i32 %t1686, %t1688
  br i1 %t1689, label %bb219, label %bb220
bb219:
  br label %bb221
bb220:
  br label %bb222
bb221:
  store { i64, ptr } { i64 4, ptr @.d289 }, ptr %l475, !tbaa !27
  br label %bb239
bb222:
  %t1691 = load i32, ptr %l1
  %t1693 = trunc i64 5 to i32
  %t1694 = icmp eq i32 %t1691, %t1693
  br i1 %t1694, label %bb223, label %bb224
bb223:
  br label %bb225
bb224:
  br label %bb226
bb225:
  store { i64, ptr } { i64 4, ptr @.d290 }, ptr %l475, !tbaa !27
  br label %bb239
bb226:
  %t1696 = load i32, ptr %l1
  %t1698 = trunc i64 6 to i32
  %t1699 = icmp eq i32 %t1696, %t1698
  br i1 %t1699, label %bb227, label %bb228
bb227:
  br label %bb229
bb228:
  br label %bb230
bb229:
  store { i64, ptr } { i64 4, ptr @.d291 }, ptr %l475, !tbaa !27
  br label %bb239
bb230:
  %t1701 = load i32, ptr %l1
  %t1703 = trunc i64 7 to i32
  %t1704 = icmp eq i32 %t1701, %t1703
  br i1 %t1704, label %bb231, label %bb232
bb231:
  br label %bb233
bb232:
  br label %bb234
bb233:
  store { i64, ptr } { i64 4, ptr @.d292 }, ptr %l475, !tbaa !27
  br label %bb239
bb234:
  br i1 true, label %bb235, label %bb236
bb235:
  br label %bb237
bb236:
  br label %bb238
bb237:
  store { i64, ptr } { i64 0, ptr @.d293 }, ptr %l475, !tbaa !27
  br label %bb239
bb238:
  call void @__olang_check_failed(ptr @olang_loc_f37913274faf0c64_a4499fcd83081580)
  unreachable
bb239:
  %t1706 = load { i64, ptr }, ptr %l475, !tbaa !27
  store { i64, ptr } %t1706, ptr %l40, !tbaa !27
  %t1707 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t1708 = load ptr, ptr @__olang_prog_scope
  %t1710 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t1708, ptr %s57, { i64, ptr } %t1707, { i64, ptr } { i64 0, ptr @.d294 })
  store i1 %t1710, ptr %l487
  br label %bb240
bb240:
  %t1711 = load i1, ptr %l487, !tbaa !21
  %t1712 = xor i1 %t1711, true
  br i1 %t1712, label %bb241, label %bb242
bb241:
  %t1714 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1714, ptr %l489, !tbaa !29
  %t1715 = load ptr, ptr %l0, !tbaa !29
  %t1716 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t1717 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t1718 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t1720 = extractvalue { i64, ptr } %t1716, 1
  %t1721 = extractvalue { i64, ptr } %t1716, 0
  %t1722 = extractvalue { i64, ptr } { i64 7, ptr @.d295 }, 1
  %t1723 = extractvalue { i64, ptr } { i64 7, ptr @.d295 }, 0
  %t1724 = add i64 %t1721, %t1723
  %t1726 = extractvalue { i64, ptr } %t1717, 1
  %t1727 = extractvalue { i64, ptr } %t1717, 0
  %t1728 = add i64 %t1724, %t1727
  %t1729 = extractvalue { i64, ptr } { i64 2, ptr @.d296 }, 1
  %t1730 = extractvalue { i64, ptr } { i64 2, ptr @.d296 }, 0
  %t1731 = add i64 %t1728, %t1730
  %t1733 = extractvalue { i64, ptr } %t1718, 1
  %t1734 = extractvalue { i64, ptr } %t1718, 0
  %t1735 = add i64 %t1731, %t1734
  %t1736 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1735)
  call void @olang_textcopy(ptr %t1736, ptr %t1720, i64 %t1721)
  %t1737 = getelementptr i8, ptr %t1736, i64 %t1721
  call void @olang_textcopy(ptr %t1737, ptr %t1722, i64 %t1723)
  %t1738 = getelementptr i8, ptr %t1737, i64 %t1723
  call void @olang_textcopy(ptr %t1738, ptr %t1726, i64 %t1727)
  %t1739 = getelementptr i8, ptr %t1738, i64 %t1727
  call void @olang_textcopy(ptr %t1739, ptr %t1729, i64 %t1730)
  %t1740 = getelementptr i8, ptr %t1739, i64 %t1730
  call void @olang_textcopy(ptr %t1740, ptr %t1733, i64 %t1734)
  %t1741 = insertvalue { i64, ptr } undef, i64 %t1735, 0
  %t1742 = insertvalue { i64, ptr } %t1741, ptr %t1736, 1
  %t1744 = extractvalue { i64, ptr } %t1742, 0
  %t1745 = extractvalue { i64, ptr } %t1742, 1
  %t1746 = mul i64 %t1744, 1
  %t1747 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1746)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1747, ptr %t1745, i64 %t1746, i1 false)
  %t1748 = insertvalue { i64, ptr } undef, i64 %t1744, 0
  %t1749 = insertvalue { i64, ptr } %t1748, ptr %t1747, 1
  %t1752 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t1715, { i64, ptr } %t1749)
  store { i64, ptr } %t1752, ptr %l496
  br label %bb243
bb242:
  br label %bb245
bb243:
  %t1753 = load { i64, ptr }, ptr %l496, !tbaa !27
  %t1754 = extractvalue { i64, ptr } %t1753, 0
  %t1755 = extractvalue { i64, ptr } %t1753, 1
  %t1756 = mul i64 %t1754, 1
  %t1757 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1756)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1757, ptr %t1755, i64 %t1756, i1 false)
  %t1758 = insertvalue { i64, ptr } undef, i64 %t1754, 0
  %t1759 = insertvalue { i64, ptr } %t1758, ptr %t1757, 1
  %t1760 = load ptr, ptr %l489, !tbaa !29
  %t1762 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2enarrowBF16(ptr %v0, ptr %v1, ptr %v1, ptr %t1760, { i64, ptr } %t1759)
  store { i64, ptr } %t1762, ptr %l498
  br label %bb244
bb244:
  call void @__olang_scope_close(ptr %s57)
  call void @__olang_scope_close(ptr %s0)
  %t1763 = load { i64, ptr }, ptr %l498, !tbaa !27
  store { i64, ptr } %t1763, ptr %rv
  br label %ret
bb245:
  %t1764 = load i32, ptr %l1
  %t1766 = trunc i64 13 to i32
  %t1767 = icmp eq i32 %t1764, %t1766
  br i1 %t1767, label %bb246, label %bb247
bb246:
  br label %bb258
bb247:
  %t1769 = load i32, ptr %l1
  %t1771 = trunc i64 14 to i32
  %t1772 = icmp eq i32 %t1769, %t1771
  br i1 %t1772, label %bb248, label %bb249
bb248:
  br label %bb258
bb249:
  %t1774 = load i32, ptr %l1
  %t1776 = trunc i64 15 to i32
  %t1777 = icmp eq i32 %t1774, %t1776
  br i1 %t1777, label %bb250, label %bb251
bb250:
  br label %bb258
bb251:
  %t1779 = load i32, ptr %l1
  %t1781 = trunc i64 16 to i32
  %t1782 = icmp eq i32 %t1779, %t1781
  br i1 %t1782, label %bb252, label %bb253
bb252:
  br label %bb258
bb253:
  %t1784 = load i32, ptr %l1
  %t1786 = trunc i64 17 to i32
  %t1787 = icmp eq i32 %t1784, %t1786
  br i1 %t1787, label %bb254, label %bb255
bb254:
  br label %bb258
bb255:
  %t1789 = load i32, ptr %l1
  %t1791 = trunc i64 18 to i32
  %t1792 = icmp eq i32 %t1789, %t1791
  br i1 %t1792, label %bb256, label %bb257
bb256:
  br label %bb258
bb257:
  br label %bb260
bb258:
  %t1794 = load ptr, ptr %l0, !tbaa !29
  %t1795 = load i32, ptr %l1
  %t1796 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t1797 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t1802 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ecompare(ptr %v0, ptr %s57, ptr %s57, ptr %v1, ptr %t1794, i32 %t1795, i32 13, { i64, ptr } %t1796, { i64, ptr } %t1797)
  store { i64, ptr } %t1802, ptr %l515
  br label %bb259
bb259:
  call void @__olang_scope_close(ptr %s57)
  call void @__olang_scope_close(ptr %s0)
  %t1803 = load { i64, ptr }, ptr %l515, !tbaa !27
  store { i64, ptr } %t1803, ptr %rv
  br label %ret
bb260:
  br i1 true, label %bb261, label %bb262
bb261:
  br label %bb263
bb262:
  br label %bb264
bb263:
  br label %bb265
bb264:
  call void @__olang_check_failed(ptr @olang_loc_3839c0df7b992655_2640faef1ba2f611)
  unreachable
bb265:
  call void @__olang_scope_close(ptr %s57)
  br label %bb266
bb266:
  %t1804 = load i32, ptr %l1
  %t1806 = trunc i64 3 to i32
  %t1807 = icmp eq i32 %t1804, %t1806
  br i1 %t1807, label %bb267, label %bb268
bb267:
  br label %bb269
bb268:
  br label %bb274
bb269:
  %t1809 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1809, ptr %l518, !tbaa !29
  %t1810 = load i1, ptr %l9, !tbaa !21
  br i1 %t1810, label %bb270, label %bb271
bb270:
  store { i64, ptr } { i64 5, ptr @.d297 }, ptr %l520, !tbaa !27
  br label %bb272
bb271:
  store { i64, ptr } { i64 4, ptr @.d298 }, ptr %l520, !tbaa !27
  br label %bb272
bb272:
  %t1812 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1813 = load ptr, ptr %lp11
  %t1814 = load { i64, ptr }, ptr %t1813, !tbaa !27
  %t1815 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t1816 = load { i64, ptr }, ptr %l520, !tbaa !27
  %t1817 = extractvalue { i64, ptr } %t1816, 1
  %t1818 = extractvalue { i64, ptr } %t1816, 0
  %t1820 = extractvalue { i64, ptr } %t1812, 1
  %t1821 = extractvalue { i64, ptr } %t1812, 0
  %t1822 = add i64 %t1818, %t1821
  %t1823 = extractvalue { i64, ptr } { i64 1, ptr @.d299 }, 1
  %t1824 = extractvalue { i64, ptr } { i64 1, ptr @.d299 }, 0
  %t1825 = add i64 %t1822, %t1824
  %t1827 = extractvalue { i64, ptr } %t1814, 1
  %t1828 = extractvalue { i64, ptr } %t1814, 0
  %t1829 = add i64 %t1825, %t1828
  %t1830 = extractvalue { i64, ptr } { i64 2, ptr @.d300 }, 1
  %t1831 = extractvalue { i64, ptr } { i64 2, ptr @.d300 }, 0
  %t1832 = add i64 %t1829, %t1831
  %t1834 = extractvalue { i64, ptr } %t1815, 1
  %t1835 = extractvalue { i64, ptr } %t1815, 0
  %t1836 = add i64 %t1832, %t1835
  %t1837 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1836)
  call void @olang_textcopy(ptr %t1837, ptr %t1817, i64 %t1818)
  %t1838 = getelementptr i8, ptr %t1837, i64 %t1818
  call void @olang_textcopy(ptr %t1838, ptr %t1820, i64 %t1821)
  %t1839 = getelementptr i8, ptr %t1838, i64 %t1821
  call void @olang_textcopy(ptr %t1839, ptr %t1823, i64 %t1824)
  %t1840 = getelementptr i8, ptr %t1839, i64 %t1824
  call void @olang_textcopy(ptr %t1840, ptr %t1827, i64 %t1828)
  %t1841 = getelementptr i8, ptr %t1840, i64 %t1828
  call void @olang_textcopy(ptr %t1841, ptr %t1830, i64 %t1831)
  %t1842 = getelementptr i8, ptr %t1841, i64 %t1831
  call void @olang_textcopy(ptr %t1842, ptr %t1834, i64 %t1835)
  %t1843 = insertvalue { i64, ptr } undef, i64 %t1836, 0
  %t1844 = insertvalue { i64, ptr } %t1843, ptr %t1837, 1
  %t1846 = extractvalue { i64, ptr } %t1844, 0
  %t1847 = extractvalue { i64, ptr } %t1844, 1
  %t1848 = mul i64 %t1846, 1
  %t1849 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1848)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1849, ptr %t1847, i64 %t1848, i1 false)
  %t1850 = insertvalue { i64, ptr } undef, i64 %t1846, 0
  %t1851 = insertvalue { i64, ptr } %t1850, ptr %t1849, 1
  %t1852 = load ptr, ptr %l518, !tbaa !29
  %t1854 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t1852, { i64, ptr } %t1851)
  store { i64, ptr } %t1854, ptr %l526
  br label %bb273
bb273:
  call void @__olang_scope_close(ptr %s0)
  %t1855 = load { i64, ptr }, ptr %l526, !tbaa !27
  store { i64, ptr } %t1855, ptr %rv
  br label %ret
bb274:
  %t1856 = load i32, ptr %l1
  %t1858 = trunc i64 4 to i32
  %t1859 = icmp eq i32 %t1856, %t1858
  br i1 %t1859, label %bb275, label %bb276
bb275:
  br label %bb277
bb276:
  br label %bb282
bb277:
  %t1861 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1861, ptr %l529, !tbaa !29
  %t1862 = load i1, ptr %l9, !tbaa !21
  br i1 %t1862, label %bb278, label %bb279
bb278:
  store { i64, ptr } { i64 5, ptr @.d301 }, ptr %l531, !tbaa !27
  br label %bb280
bb279:
  store { i64, ptr } { i64 4, ptr @.d302 }, ptr %l531, !tbaa !27
  br label %bb280
bb280:
  %t1864 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1865 = load ptr, ptr %lp11
  %t1866 = load { i64, ptr }, ptr %t1865, !tbaa !27
  %t1867 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t1868 = load { i64, ptr }, ptr %l531, !tbaa !27
  %t1869 = extractvalue { i64, ptr } %t1868, 1
  %t1870 = extractvalue { i64, ptr } %t1868, 0
  %t1872 = extractvalue { i64, ptr } %t1864, 1
  %t1873 = extractvalue { i64, ptr } %t1864, 0
  %t1874 = add i64 %t1870, %t1873
  %t1875 = extractvalue { i64, ptr } { i64 1, ptr @.d303 }, 1
  %t1876 = extractvalue { i64, ptr } { i64 1, ptr @.d303 }, 0
  %t1877 = add i64 %t1874, %t1876
  %t1879 = extractvalue { i64, ptr } %t1866, 1
  %t1880 = extractvalue { i64, ptr } %t1866, 0
  %t1881 = add i64 %t1877, %t1880
  %t1882 = extractvalue { i64, ptr } { i64 2, ptr @.d304 }, 1
  %t1883 = extractvalue { i64, ptr } { i64 2, ptr @.d304 }, 0
  %t1884 = add i64 %t1881, %t1883
  %t1886 = extractvalue { i64, ptr } %t1867, 1
  %t1887 = extractvalue { i64, ptr } %t1867, 0
  %t1888 = add i64 %t1884, %t1887
  %t1889 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1888)
  call void @olang_textcopy(ptr %t1889, ptr %t1869, i64 %t1870)
  %t1890 = getelementptr i8, ptr %t1889, i64 %t1870
  call void @olang_textcopy(ptr %t1890, ptr %t1872, i64 %t1873)
  %t1891 = getelementptr i8, ptr %t1890, i64 %t1873
  call void @olang_textcopy(ptr %t1891, ptr %t1875, i64 %t1876)
  %t1892 = getelementptr i8, ptr %t1891, i64 %t1876
  call void @olang_textcopy(ptr %t1892, ptr %t1879, i64 %t1880)
  %t1893 = getelementptr i8, ptr %t1892, i64 %t1880
  call void @olang_textcopy(ptr %t1893, ptr %t1882, i64 %t1883)
  %t1894 = getelementptr i8, ptr %t1893, i64 %t1883
  call void @olang_textcopy(ptr %t1894, ptr %t1886, i64 %t1887)
  %t1895 = insertvalue { i64, ptr } undef, i64 %t1888, 0
  %t1896 = insertvalue { i64, ptr } %t1895, ptr %t1889, 1
  %t1898 = extractvalue { i64, ptr } %t1896, 0
  %t1899 = extractvalue { i64, ptr } %t1896, 1
  %t1900 = mul i64 %t1898, 1
  %t1901 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1900)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1901, ptr %t1899, i64 %t1900, i1 false)
  %t1902 = insertvalue { i64, ptr } undef, i64 %t1898, 0
  %t1903 = insertvalue { i64, ptr } %t1902, ptr %t1901, 1
  %t1904 = load ptr, ptr %l529, !tbaa !29
  %t1906 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t1904, { i64, ptr } %t1903)
  store { i64, ptr } %t1906, ptr %l537
  br label %bb281
bb281:
  call void @__olang_scope_close(ptr %s0)
  %t1907 = load { i64, ptr }, ptr %l537, !tbaa !27
  store { i64, ptr } %t1907, ptr %rv
  br label %ret
bb282:
  %t1908 = load i32, ptr %l1
  %t1910 = trunc i64 5 to i32
  %t1911 = icmp eq i32 %t1908, %t1910
  br i1 %t1911, label %bb283, label %bb284
bb283:
  br label %bb285
bb284:
  br label %bb290
bb285:
  %t1913 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1913, ptr %l540, !tbaa !29
  %t1914 = load i1, ptr %l9, !tbaa !21
  br i1 %t1914, label %bb286, label %bb287
bb286:
  store { i64, ptr } { i64 5, ptr @.d305 }, ptr %l542, !tbaa !27
  br label %bb288
bb287:
  store { i64, ptr } { i64 4, ptr @.d306 }, ptr %l542, !tbaa !27
  br label %bb288
bb288:
  %t1916 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1917 = load ptr, ptr %lp11
  %t1918 = load { i64, ptr }, ptr %t1917, !tbaa !27
  %t1919 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t1920 = load { i64, ptr }, ptr %l542, !tbaa !27
  %t1921 = extractvalue { i64, ptr } %t1920, 1
  %t1922 = extractvalue { i64, ptr } %t1920, 0
  %t1924 = extractvalue { i64, ptr } %t1916, 1
  %t1925 = extractvalue { i64, ptr } %t1916, 0
  %t1926 = add i64 %t1922, %t1925
  %t1927 = extractvalue { i64, ptr } { i64 1, ptr @.d307 }, 1
  %t1928 = extractvalue { i64, ptr } { i64 1, ptr @.d307 }, 0
  %t1929 = add i64 %t1926, %t1928
  %t1931 = extractvalue { i64, ptr } %t1918, 1
  %t1932 = extractvalue { i64, ptr } %t1918, 0
  %t1933 = add i64 %t1929, %t1932
  %t1934 = extractvalue { i64, ptr } { i64 2, ptr @.d308 }, 1
  %t1935 = extractvalue { i64, ptr } { i64 2, ptr @.d308 }, 0
  %t1936 = add i64 %t1933, %t1935
  %t1938 = extractvalue { i64, ptr } %t1919, 1
  %t1939 = extractvalue { i64, ptr } %t1919, 0
  %t1940 = add i64 %t1936, %t1939
  %t1941 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1940)
  call void @olang_textcopy(ptr %t1941, ptr %t1921, i64 %t1922)
  %t1942 = getelementptr i8, ptr %t1941, i64 %t1922
  call void @olang_textcopy(ptr %t1942, ptr %t1924, i64 %t1925)
  %t1943 = getelementptr i8, ptr %t1942, i64 %t1925
  call void @olang_textcopy(ptr %t1943, ptr %t1927, i64 %t1928)
  %t1944 = getelementptr i8, ptr %t1943, i64 %t1928
  call void @olang_textcopy(ptr %t1944, ptr %t1931, i64 %t1932)
  %t1945 = getelementptr i8, ptr %t1944, i64 %t1932
  call void @olang_textcopy(ptr %t1945, ptr %t1934, i64 %t1935)
  %t1946 = getelementptr i8, ptr %t1945, i64 %t1935
  call void @olang_textcopy(ptr %t1946, ptr %t1938, i64 %t1939)
  %t1947 = insertvalue { i64, ptr } undef, i64 %t1940, 0
  %t1948 = insertvalue { i64, ptr } %t1947, ptr %t1941, 1
  %t1950 = extractvalue { i64, ptr } %t1948, 0
  %t1951 = extractvalue { i64, ptr } %t1948, 1
  %t1952 = mul i64 %t1950, 1
  %t1953 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1952)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1953, ptr %t1951, i64 %t1952, i1 false)
  %t1954 = insertvalue { i64, ptr } undef, i64 %t1950, 0
  %t1955 = insertvalue { i64, ptr } %t1954, ptr %t1953, 1
  %t1956 = load ptr, ptr %l540, !tbaa !29
  %t1958 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t1956, { i64, ptr } %t1955)
  store { i64, ptr } %t1958, ptr %l548
  br label %bb289
bb289:
  call void @__olang_scope_close(ptr %s0)
  %t1959 = load { i64, ptr }, ptr %l548, !tbaa !27
  store { i64, ptr } %t1959, ptr %rv
  br label %ret
bb290:
  %t1960 = load i32, ptr %l1
  %t1962 = trunc i64 6 to i32
  %t1963 = icmp eq i32 %t1960, %t1962
  br i1 %t1963, label %bb291, label %bb292
bb291:
  br label %bb293
bb292:
  br label %bb301
bb293:
  %t1965 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1965, ptr %l551, !tbaa !29
  %t1966 = load i1, ptr %l9, !tbaa !21
  br i1 %t1966, label %bb294, label %bb295
bb294:
  store { i64, ptr } { i64 5, ptr @.d309 }, ptr %l553, !tbaa !27
  br label %bb299
bb295:
  %t1968 = load i1, ptr %l10, !tbaa !21
  br i1 %t1968, label %bb296, label %bb297
bb296:
  store { i64, ptr } { i64 5, ptr @.d310 }, ptr %l555, !tbaa !27
  br label %bb298
bb297:
  store { i64, ptr } { i64 5, ptr @.d311 }, ptr %l555, !tbaa !27
  br label %bb298
bb298:
  %t1970 = load { i64, ptr }, ptr %l555, !tbaa !27
  store { i64, ptr } %t1970, ptr %l553, !tbaa !27
  br label %bb299
bb299:
  %t1971 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1972 = load ptr, ptr %lp11
  %t1973 = load { i64, ptr }, ptr %t1972, !tbaa !27
  %t1974 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t1975 = load { i64, ptr }, ptr %l553, !tbaa !27
  %t1976 = extractvalue { i64, ptr } %t1975, 1
  %t1977 = extractvalue { i64, ptr } %t1975, 0
  %t1979 = extractvalue { i64, ptr } %t1971, 1
  %t1980 = extractvalue { i64, ptr } %t1971, 0
  %t1981 = add i64 %t1977, %t1980
  %t1982 = extractvalue { i64, ptr } { i64 1, ptr @.d312 }, 1
  %t1983 = extractvalue { i64, ptr } { i64 1, ptr @.d312 }, 0
  %t1984 = add i64 %t1981, %t1983
  %t1986 = extractvalue { i64, ptr } %t1973, 1
  %t1987 = extractvalue { i64, ptr } %t1973, 0
  %t1988 = add i64 %t1984, %t1987
  %t1989 = extractvalue { i64, ptr } { i64 2, ptr @.d313 }, 1
  %t1990 = extractvalue { i64, ptr } { i64 2, ptr @.d313 }, 0
  %t1991 = add i64 %t1988, %t1990
  %t1993 = extractvalue { i64, ptr } %t1974, 1
  %t1994 = extractvalue { i64, ptr } %t1974, 0
  %t1995 = add i64 %t1991, %t1994
  %t1996 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1995)
  call void @olang_textcopy(ptr %t1996, ptr %t1976, i64 %t1977)
  %t1997 = getelementptr i8, ptr %t1996, i64 %t1977
  call void @olang_textcopy(ptr %t1997, ptr %t1979, i64 %t1980)
  %t1998 = getelementptr i8, ptr %t1997, i64 %t1980
  call void @olang_textcopy(ptr %t1998, ptr %t1982, i64 %t1983)
  %t1999 = getelementptr i8, ptr %t1998, i64 %t1983
  call void @olang_textcopy(ptr %t1999, ptr %t1986, i64 %t1987)
  %t2000 = getelementptr i8, ptr %t1999, i64 %t1987
  call void @olang_textcopy(ptr %t2000, ptr %t1989, i64 %t1990)
  %t2001 = getelementptr i8, ptr %t2000, i64 %t1990
  call void @olang_textcopy(ptr %t2001, ptr %t1993, i64 %t1994)
  %t2002 = insertvalue { i64, ptr } undef, i64 %t1995, 0
  %t2003 = insertvalue { i64, ptr } %t2002, ptr %t1996, 1
  %t2005 = extractvalue { i64, ptr } %t2003, 0
  %t2006 = extractvalue { i64, ptr } %t2003, 1
  %t2007 = mul i64 %t2005, 1
  %t2008 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2007)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2008, ptr %t2006, i64 %t2007, i1 false)
  %t2009 = insertvalue { i64, ptr } undef, i64 %t2005, 0
  %t2010 = insertvalue { i64, ptr } %t2009, ptr %t2008, 1
  %t2011 = load ptr, ptr %l551, !tbaa !29
  %t2013 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t2011, { i64, ptr } %t2010)
  store { i64, ptr } %t2013, ptr %l561
  br label %bb300
bb300:
  call void @__olang_scope_close(ptr %s0)
  %t2014 = load { i64, ptr }, ptr %l561, !tbaa !27
  store { i64, ptr } %t2014, ptr %rv
  br label %ret
bb301:
  %t2015 = load i32, ptr %l1
  %t2017 = trunc i64 7 to i32
  %t2018 = icmp eq i32 %t2015, %t2017
  br i1 %t2018, label %bb302, label %bb303
bb302:
  br label %bb304
bb303:
  br label %bb312
bb304:
  %t2020 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2020, ptr %l564, !tbaa !29
  %t2021 = load i1, ptr %l9, !tbaa !21
  br i1 %t2021, label %bb305, label %bb306
bb305:
  store { i64, ptr } { i64 5, ptr @.d314 }, ptr %l566, !tbaa !27
  br label %bb310
bb306:
  %t2023 = load i1, ptr %l10, !tbaa !21
  br i1 %t2023, label %bb307, label %bb308
bb307:
  store { i64, ptr } { i64 5, ptr @.d315 }, ptr %l568, !tbaa !27
  br label %bb309
bb308:
  store { i64, ptr } { i64 5, ptr @.d316 }, ptr %l568, !tbaa !27
  br label %bb309
bb309:
  %t2025 = load { i64, ptr }, ptr %l568, !tbaa !27
  store { i64, ptr } %t2025, ptr %l566, !tbaa !27
  br label %bb310
bb310:
  %t2026 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t2027 = load ptr, ptr %lp11
  %t2028 = load { i64, ptr }, ptr %t2027, !tbaa !27
  %t2029 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t2030 = load { i64, ptr }, ptr %l566, !tbaa !27
  %t2031 = extractvalue { i64, ptr } %t2030, 1
  %t2032 = extractvalue { i64, ptr } %t2030, 0
  %t2034 = extractvalue { i64, ptr } %t2026, 1
  %t2035 = extractvalue { i64, ptr } %t2026, 0
  %t2036 = add i64 %t2032, %t2035
  %t2037 = extractvalue { i64, ptr } { i64 1, ptr @.d317 }, 1
  %t2038 = extractvalue { i64, ptr } { i64 1, ptr @.d317 }, 0
  %t2039 = add i64 %t2036, %t2038
  %t2041 = extractvalue { i64, ptr } %t2028, 1
  %t2042 = extractvalue { i64, ptr } %t2028, 0
  %t2043 = add i64 %t2039, %t2042
  %t2044 = extractvalue { i64, ptr } { i64 2, ptr @.d318 }, 1
  %t2045 = extractvalue { i64, ptr } { i64 2, ptr @.d318 }, 0
  %t2046 = add i64 %t2043, %t2045
  %t2048 = extractvalue { i64, ptr } %t2029, 1
  %t2049 = extractvalue { i64, ptr } %t2029, 0
  %t2050 = add i64 %t2046, %t2049
  %t2051 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2050)
  call void @olang_textcopy(ptr %t2051, ptr %t2031, i64 %t2032)
  %t2052 = getelementptr i8, ptr %t2051, i64 %t2032
  call void @olang_textcopy(ptr %t2052, ptr %t2034, i64 %t2035)
  %t2053 = getelementptr i8, ptr %t2052, i64 %t2035
  call void @olang_textcopy(ptr %t2053, ptr %t2037, i64 %t2038)
  %t2054 = getelementptr i8, ptr %t2053, i64 %t2038
  call void @olang_textcopy(ptr %t2054, ptr %t2041, i64 %t2042)
  %t2055 = getelementptr i8, ptr %t2054, i64 %t2042
  call void @olang_textcopy(ptr %t2055, ptr %t2044, i64 %t2045)
  %t2056 = getelementptr i8, ptr %t2055, i64 %t2045
  call void @olang_textcopy(ptr %t2056, ptr %t2048, i64 %t2049)
  %t2057 = insertvalue { i64, ptr } undef, i64 %t2050, 0
  %t2058 = insertvalue { i64, ptr } %t2057, ptr %t2051, 1
  %t2060 = extractvalue { i64, ptr } %t2058, 0
  %t2061 = extractvalue { i64, ptr } %t2058, 1
  %t2062 = mul i64 %t2060, 1
  %t2063 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2062)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2063, ptr %t2061, i64 %t2062, i1 false)
  %t2064 = insertvalue { i64, ptr } undef, i64 %t2060, 0
  %t2065 = insertvalue { i64, ptr } %t2064, ptr %t2063, 1
  %t2066 = load ptr, ptr %l564, !tbaa !29
  %t2068 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t2066, { i64, ptr } %t2065)
  store { i64, ptr } %t2068, ptr %l574
  br label %bb311
bb311:
  call void @__olang_scope_close(ptr %s0)
  %t2069 = load { i64, ptr }, ptr %l574, !tbaa !27
  store { i64, ptr } %t2069, ptr %rv
  br label %ret
bb312:
  %t2070 = load i32, ptr %l1
  %t2072 = trunc i64 8 to i32
  %t2073 = icmp eq i32 %t2070, %t2072
  br i1 %t2073, label %bb313, label %bb314
bb313:
  br label %bb317
bb314:
  %t2075 = load i32, ptr %l1
  %t2077 = trunc i64 9 to i32
  %t2078 = icmp eq i32 %t2075, %t2077
  br i1 %t2078, label %bb315, label %bb316
bb315:
  br label %bb317
bb316:
  br label %bb330
bb317:
  store %olang.scope zeroinitializer, ptr %s78
  %t2080 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2080, ptr %l579, !tbaa !29
  %t2081 = load ptr, ptr %l0, !tbaa !29
  %t2082 = load %"compiler/mir:Range", ptr %l3
  %t2085 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t2081, %"compiler/mir:Range" %t2082, i64 1)
  store { i64, [4 x i64] } %t2085, ptr %l582
  br label %bb318
bb318:
  %t2086 = load ptr, ptr %l579, !tbaa !29
  %t2087 = load { i64, [4 x i64] }, ptr %l582
  %t2088 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t2086, { i64, [4 x i64] } %t2087)
  store i32 %t2088, ptr %l583
  br label %bb319
bb319:
  %t2089 = load i32, ptr %l583, !tbaa !23
  store i32 %t2089, ptr %l41, !tbaa !23
  %t2090 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2090, ptr %l584, !tbaa !29
  %t2091 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2091, ptr %l585, !tbaa !29
  %t2092 = load ptr, ptr %l0, !tbaa !29
  %t2093 = load %"compiler/mir:Range", ptr %l3
  %t2096 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t2092, %"compiler/mir:Range" %t2093, i64 1)
  store { i64, [4 x i64] } %t2096, ptr %l588
  br label %bb320
bb320:
  %t2097 = load i32, ptr %l41, !tbaa !23
  %t2098 = load ptr, ptr %l585, !tbaa !29
  %t2099 = load { i64, [4 x i64] }, ptr %l588
  %t2101 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s78, ptr %t2098, { i64, [4 x i64] } %t2099, i32 %t2097)
  store { i64, ptr } %t2101, ptr %l590
  br label %bb321
bb321:
  %t2102 = load { i64, ptr }, ptr %l590, !tbaa !27
  %t2103 = extractvalue { i64, ptr } %t2102, 0
  %t2104 = extractvalue { i64, ptr } %t2102, 1
  %t2105 = mul i64 %t2103, 1
  %t2106 = call ptr @__olang_scope_alloc(ptr %s78, i64 %t2105)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2106, ptr %t2104, i64 %t2105, i1 false)
  %t2107 = insertvalue { i64, ptr } undef, i64 %t2103, 0
  %t2108 = insertvalue { i64, ptr } %t2107, ptr %t2106, 1
  %t2109 = load i32, ptr %l41, !tbaa !23
  %t2110 = load i32, ptr %l7, !tbaa !23
  %t2111 = load ptr, ptr %l584, !tbaa !29
  %t2115 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ewidth(ptr %v0, ptr %s78, ptr %s78, ptr %t2111, { i64, ptr } %t2108, i32 %t2109, i32 %t2110)
  store { i64, ptr } %t2115, ptr %l594
  br label %bb322
bb322:
  %t2116 = load { i64, ptr }, ptr %l594, !tbaa !27
  store { i64, ptr } %t2116, ptr %l42, !tbaa !27
  %t2117 = load i32, ptr %l1
  %t2119 = trunc i64 8 to i32
  %t2120 = icmp eq i32 %t2117, %t2119
  br i1 %t2120, label %bb323, label %bb324
bb323:
  store { i64, ptr } { i64 4, ptr @.d319 }, ptr %l597, !tbaa !27
  br label %bb328
bb324:
  %t2122 = load i1, ptr %l10, !tbaa !21
  br i1 %t2122, label %bb325, label %bb326
bb325:
  store { i64, ptr } { i64 5, ptr @.d320 }, ptr %l599, !tbaa !27
  br label %bb327
bb326:
  store { i64, ptr } { i64 5, ptr @.d321 }, ptr %l599, !tbaa !27
  br label %bb327
bb327:
  %t2124 = load { i64, ptr }, ptr %l599, !tbaa !27
  store { i64, ptr } %t2124, ptr %l597, !tbaa !27
  br label %bb328
bb328:
  %t2125 = load { i64, ptr }, ptr %l597, !tbaa !27
  %t2126 = load ptr, ptr %l0, !tbaa !29
  %t2128 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t2129 = load ptr, ptr %lp11
  %t2130 = load { i64, ptr }, ptr %t2129, !tbaa !27
  %t2131 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t2133 = extractvalue { i64, ptr } %t2125, 1
  %t2134 = extractvalue { i64, ptr } %t2125, 0
  %t2136 = extractvalue { i64, ptr } %t2128, 1
  %t2137 = extractvalue { i64, ptr } %t2128, 0
  %t2138 = add i64 %t2134, %t2137
  %t2139 = extractvalue { i64, ptr } { i64 1, ptr @.d322 }, 1
  %t2140 = extractvalue { i64, ptr } { i64 1, ptr @.d322 }, 0
  %t2141 = add i64 %t2138, %t2140
  %t2143 = extractvalue { i64, ptr } %t2130, 1
  %t2144 = extractvalue { i64, ptr } %t2130, 0
  %t2145 = add i64 %t2141, %t2144
  %t2146 = extractvalue { i64, ptr } { i64 2, ptr @.d323 }, 1
  %t2147 = extractvalue { i64, ptr } { i64 2, ptr @.d323 }, 0
  %t2148 = add i64 %t2145, %t2147
  %t2150 = extractvalue { i64, ptr } %t2131, 1
  %t2151 = extractvalue { i64, ptr } %t2131, 0
  %t2152 = add i64 %t2148, %t2151
  %t2153 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2152)
  call void @olang_textcopy(ptr %t2153, ptr %t2133, i64 %t2134)
  %t2154 = getelementptr i8, ptr %t2153, i64 %t2134
  call void @olang_textcopy(ptr %t2154, ptr %t2136, i64 %t2137)
  %t2155 = getelementptr i8, ptr %t2154, i64 %t2137
  call void @olang_textcopy(ptr %t2155, ptr %t2139, i64 %t2140)
  %t2156 = getelementptr i8, ptr %t2155, i64 %t2140
  call void @olang_textcopy(ptr %t2156, ptr %t2143, i64 %t2144)
  %t2157 = getelementptr i8, ptr %t2156, i64 %t2144
  call void @olang_textcopy(ptr %t2157, ptr %t2146, i64 %t2147)
  %t2158 = getelementptr i8, ptr %t2157, i64 %t2147
  call void @olang_textcopy(ptr %t2158, ptr %t2150, i64 %t2151)
  %t2159 = insertvalue { i64, ptr } undef, i64 %t2152, 0
  %t2160 = insertvalue { i64, ptr } %t2159, ptr %t2153, 1
  %t2162 = extractvalue { i64, ptr } %t2160, 0
  %t2163 = extractvalue { i64, ptr } %t2160, 1
  %t2164 = mul i64 %t2162, 1
  %t2165 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2164)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2165, ptr %t2163, i64 %t2164, i1 false)
  %t2166 = insertvalue { i64, ptr } undef, i64 %t2162, 0
  %t2167 = insertvalue { i64, ptr } %t2166, ptr %t2165, 1
  %t2170 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t2126, { i64, ptr } %t2167)
  store { i64, ptr } %t2170, ptr %l607
  br label %bb329
bb329:
  call void @__olang_scope_close(ptr %s78)
  call void @__olang_scope_close(ptr %s0)
  %t2171 = load { i64, ptr }, ptr %l607, !tbaa !27
  store { i64, ptr } %t2171, ptr %rv
  br label %ret
bb330:
  %t2172 = load i32, ptr %l1
  %t2174 = trunc i64 10 to i32
  %t2175 = icmp eq i32 %t2172, %t2174
  br i1 %t2175, label %bb331, label %bb332
bb331:
  br label %bb333
bb332:
  br label %bb335
bb333:
  %t2177 = load ptr, ptr %l0, !tbaa !29
  %t2178 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t2179 = load ptr, ptr %lp11
  %t2180 = load { i64, ptr }, ptr %t2179, !tbaa !27
  %t2181 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t2182 = extractvalue { i64, ptr } { i64 4, ptr @.d324 }, 1
  %t2183 = extractvalue { i64, ptr } { i64 4, ptr @.d324 }, 0
  %t2185 = extractvalue { i64, ptr } %t2178, 1
  %t2186 = extractvalue { i64, ptr } %t2178, 0
  %t2187 = add i64 %t2183, %t2186
  %t2188 = extractvalue { i64, ptr } { i64 1, ptr @.d325 }, 1
  %t2189 = extractvalue { i64, ptr } { i64 1, ptr @.d325 }, 0
  %t2190 = add i64 %t2187, %t2189
  %t2192 = extractvalue { i64, ptr } %t2180, 1
  %t2193 = extractvalue { i64, ptr } %t2180, 0
  %t2194 = add i64 %t2190, %t2193
  %t2195 = extractvalue { i64, ptr } { i64 2, ptr @.d326 }, 1
  %t2196 = extractvalue { i64, ptr } { i64 2, ptr @.d326 }, 0
  %t2197 = add i64 %t2194, %t2196
  %t2199 = extractvalue { i64, ptr } %t2181, 1
  %t2200 = extractvalue { i64, ptr } %t2181, 0
  %t2201 = add i64 %t2197, %t2200
  %t2202 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2201)
  call void @olang_textcopy(ptr %t2202, ptr %t2182, i64 %t2183)
  %t2203 = getelementptr i8, ptr %t2202, i64 %t2183
  call void @olang_textcopy(ptr %t2203, ptr %t2185, i64 %t2186)
  %t2204 = getelementptr i8, ptr %t2203, i64 %t2186
  call void @olang_textcopy(ptr %t2204, ptr %t2188, i64 %t2189)
  %t2205 = getelementptr i8, ptr %t2204, i64 %t2189
  call void @olang_textcopy(ptr %t2205, ptr %t2192, i64 %t2193)
  %t2206 = getelementptr i8, ptr %t2205, i64 %t2193
  call void @olang_textcopy(ptr %t2206, ptr %t2195, i64 %t2196)
  %t2207 = getelementptr i8, ptr %t2206, i64 %t2196
  call void @olang_textcopy(ptr %t2207, ptr %t2199, i64 %t2200)
  %t2208 = insertvalue { i64, ptr } undef, i64 %t2201, 0
  %t2209 = insertvalue { i64, ptr } %t2208, ptr %t2202, 1
  %t2211 = extractvalue { i64, ptr } %t2209, 0
  %t2212 = extractvalue { i64, ptr } %t2209, 1
  %t2213 = mul i64 %t2211, 1
  %t2214 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2213)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2214, ptr %t2212, i64 %t2213, i1 false)
  %t2215 = insertvalue { i64, ptr } undef, i64 %t2211, 0
  %t2216 = insertvalue { i64, ptr } %t2215, ptr %t2214, 1
  %t2219 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t2177, { i64, ptr } %t2216)
  store { i64, ptr } %t2219, ptr %l616
  br label %bb334
bb334:
  call void @__olang_scope_close(ptr %s0)
  %t2220 = load { i64, ptr }, ptr %l616, !tbaa !27
  store { i64, ptr } %t2220, ptr %rv
  br label %ret
bb335:
  %t2221 = load i32, ptr %l1
  %t2223 = trunc i64 11 to i32
  %t2224 = icmp eq i32 %t2221, %t2223
  br i1 %t2224, label %bb336, label %bb337
bb336:
  br label %bb338
bb337:
  br label %bb340
bb338:
  %t2226 = load ptr, ptr %l0, !tbaa !29
  %t2227 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t2228 = load ptr, ptr %lp11
  %t2229 = load { i64, ptr }, ptr %t2228, !tbaa !27
  %t2230 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t2231 = extractvalue { i64, ptr } { i64 3, ptr @.d327 }, 1
  %t2232 = extractvalue { i64, ptr } { i64 3, ptr @.d327 }, 0
  %t2234 = extractvalue { i64, ptr } %t2227, 1
  %t2235 = extractvalue { i64, ptr } %t2227, 0
  %t2236 = add i64 %t2232, %t2235
  %t2237 = extractvalue { i64, ptr } { i64 1, ptr @.d328 }, 1
  %t2238 = extractvalue { i64, ptr } { i64 1, ptr @.d328 }, 0
  %t2239 = add i64 %t2236, %t2238
  %t2241 = extractvalue { i64, ptr } %t2229, 1
  %t2242 = extractvalue { i64, ptr } %t2229, 0
  %t2243 = add i64 %t2239, %t2242
  %t2244 = extractvalue { i64, ptr } { i64 2, ptr @.d329 }, 1
  %t2245 = extractvalue { i64, ptr } { i64 2, ptr @.d329 }, 0
  %t2246 = add i64 %t2243, %t2245
  %t2248 = extractvalue { i64, ptr } %t2230, 1
  %t2249 = extractvalue { i64, ptr } %t2230, 0
  %t2250 = add i64 %t2246, %t2249
  %t2251 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2250)
  call void @olang_textcopy(ptr %t2251, ptr %t2231, i64 %t2232)
  %t2252 = getelementptr i8, ptr %t2251, i64 %t2232
  call void @olang_textcopy(ptr %t2252, ptr %t2234, i64 %t2235)
  %t2253 = getelementptr i8, ptr %t2252, i64 %t2235
  call void @olang_textcopy(ptr %t2253, ptr %t2237, i64 %t2238)
  %t2254 = getelementptr i8, ptr %t2253, i64 %t2238
  call void @olang_textcopy(ptr %t2254, ptr %t2241, i64 %t2242)
  %t2255 = getelementptr i8, ptr %t2254, i64 %t2242
  call void @olang_textcopy(ptr %t2255, ptr %t2244, i64 %t2245)
  %t2256 = getelementptr i8, ptr %t2255, i64 %t2245
  call void @olang_textcopy(ptr %t2256, ptr %t2248, i64 %t2249)
  %t2257 = insertvalue { i64, ptr } undef, i64 %t2250, 0
  %t2258 = insertvalue { i64, ptr } %t2257, ptr %t2251, 1
  %t2260 = extractvalue { i64, ptr } %t2258, 0
  %t2261 = extractvalue { i64, ptr } %t2258, 1
  %t2262 = mul i64 %t2260, 1
  %t2263 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2262)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2263, ptr %t2261, i64 %t2262, i1 false)
  %t2264 = insertvalue { i64, ptr } undef, i64 %t2260, 0
  %t2265 = insertvalue { i64, ptr } %t2264, ptr %t2263, 1
  %t2268 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t2226, { i64, ptr } %t2265)
  store { i64, ptr } %t2268, ptr %l625
  br label %bb339
bb339:
  call void @__olang_scope_close(ptr %s0)
  %t2269 = load { i64, ptr }, ptr %l625, !tbaa !27
  store { i64, ptr } %t2269, ptr %rv
  br label %ret
bb340:
  %t2270 = load i32, ptr %l1
  %t2272 = trunc i64 12 to i32
  %t2273 = icmp eq i32 %t2270, %t2272
  br i1 %t2273, label %bb341, label %bb342
bb341:
  br label %bb343
bb342:
  br label %bb345
bb343:
  %t2275 = load ptr, ptr %l0, !tbaa !29
  %t2276 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t2277 = load ptr, ptr %lp11
  %t2278 = load { i64, ptr }, ptr %t2277, !tbaa !27
  %t2279 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t2280 = extractvalue { i64, ptr } { i64 4, ptr @.d330 }, 1
  %t2281 = extractvalue { i64, ptr } { i64 4, ptr @.d330 }, 0
  %t2283 = extractvalue { i64, ptr } %t2276, 1
  %t2284 = extractvalue { i64, ptr } %t2276, 0
  %t2285 = add i64 %t2281, %t2284
  %t2286 = extractvalue { i64, ptr } { i64 1, ptr @.d331 }, 1
  %t2287 = extractvalue { i64, ptr } { i64 1, ptr @.d331 }, 0
  %t2288 = add i64 %t2285, %t2287
  %t2290 = extractvalue { i64, ptr } %t2278, 1
  %t2291 = extractvalue { i64, ptr } %t2278, 0
  %t2292 = add i64 %t2288, %t2291
  %t2293 = extractvalue { i64, ptr } { i64 2, ptr @.d332 }, 1
  %t2294 = extractvalue { i64, ptr } { i64 2, ptr @.d332 }, 0
  %t2295 = add i64 %t2292, %t2294
  %t2297 = extractvalue { i64, ptr } %t2279, 1
  %t2298 = extractvalue { i64, ptr } %t2279, 0
  %t2299 = add i64 %t2295, %t2298
  %t2300 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2299)
  call void @olang_textcopy(ptr %t2300, ptr %t2280, i64 %t2281)
  %t2301 = getelementptr i8, ptr %t2300, i64 %t2281
  call void @olang_textcopy(ptr %t2301, ptr %t2283, i64 %t2284)
  %t2302 = getelementptr i8, ptr %t2301, i64 %t2284
  call void @olang_textcopy(ptr %t2302, ptr %t2286, i64 %t2287)
  %t2303 = getelementptr i8, ptr %t2302, i64 %t2287
  call void @olang_textcopy(ptr %t2303, ptr %t2290, i64 %t2291)
  %t2304 = getelementptr i8, ptr %t2303, i64 %t2291
  call void @olang_textcopy(ptr %t2304, ptr %t2293, i64 %t2294)
  %t2305 = getelementptr i8, ptr %t2304, i64 %t2294
  call void @olang_textcopy(ptr %t2305, ptr %t2297, i64 %t2298)
  %t2306 = insertvalue { i64, ptr } undef, i64 %t2299, 0
  %t2307 = insertvalue { i64, ptr } %t2306, ptr %t2300, 1
  %t2309 = extractvalue { i64, ptr } %t2307, 0
  %t2310 = extractvalue { i64, ptr } %t2307, 1
  %t2311 = mul i64 %t2309, 1
  %t2312 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2311)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2312, ptr %t2310, i64 %t2311, i1 false)
  %t2313 = insertvalue { i64, ptr } undef, i64 %t2309, 0
  %t2314 = insertvalue { i64, ptr } %t2313, ptr %t2312, 1
  %t2317 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t2275, { i64, ptr } %t2314)
  store { i64, ptr } %t2317, ptr %l634
  br label %bb344
bb344:
  call void @__olang_scope_close(ptr %s0)
  %t2318 = load { i64, ptr }, ptr %l634, !tbaa !27
  store { i64, ptr } %t2318, ptr %rv
  br label %ret
bb345:
  %t2319 = load i32, ptr %l1
  %t2321 = trunc i64 13 to i32
  %t2322 = icmp eq i32 %t2319, %t2321
  br i1 %t2322, label %bb346, label %bb347
bb346:
  br label %bb358
bb347:
  %t2324 = load i32, ptr %l1
  %t2326 = trunc i64 14 to i32
  %t2327 = icmp eq i32 %t2324, %t2326
  br i1 %t2327, label %bb348, label %bb349
bb348:
  br label %bb358
bb349:
  %t2329 = load i32, ptr %l1
  %t2331 = trunc i64 15 to i32
  %t2332 = icmp eq i32 %t2329, %t2331
  br i1 %t2332, label %bb350, label %bb351
bb350:
  br label %bb358
bb351:
  %t2334 = load i32, ptr %l1
  %t2336 = trunc i64 16 to i32
  %t2337 = icmp eq i32 %t2334, %t2336
  br i1 %t2337, label %bb352, label %bb353
bb352:
  br label %bb358
bb353:
  %t2339 = load i32, ptr %l1
  %t2341 = trunc i64 17 to i32
  %t2342 = icmp eq i32 %t2339, %t2341
  br i1 %t2342, label %bb354, label %bb355
bb354:
  br label %bb358
bb355:
  %t2344 = load i32, ptr %l1
  %t2346 = trunc i64 18 to i32
  %t2347 = icmp eq i32 %t2344, %t2346
  br i1 %t2347, label %bb356, label %bb357
bb356:
  br label %bb358
bb357:
  br label %bb360
bb358:
  %t2349 = load ptr, ptr %l0, !tbaa !29
  %t2350 = load i32, ptr %l1
  %t2351 = load i32, ptr %l7, !tbaa !23
  %t2352 = load ptr, ptr %lp11
  %t2353 = load { i64, ptr }, ptr %t2352, !tbaa !27
  %t2354 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t2360 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ecompare(ptr %v0, ptr %v1, ptr %s0, ptr %v1, ptr %t2349, i32 %t2350, i32 %t2351, { i64, ptr } %t2353, { i64, ptr } %t2354)
  store { i64, ptr } %t2360, ptr %l652
  br label %bb359
bb359:
  call void @__olang_scope_close(ptr %s0)
  %t2361 = load { i64, ptr }, ptr %l652, !tbaa !27
  store { i64, ptr } %t2361, ptr %rv
  br label %ret
bb360:
  %t2362 = load i32, ptr %l1
  %t2364 = trunc i64 19 to i32
  %t2365 = icmp eq i32 %t2362, %t2364
  br i1 %t2365, label %bb361, label %bb362
bb361:
  br label %bb363
bb362:
  br label %bb384
bb363:
  store %olang.scope zeroinitializer, ptr %s87
  %t2367 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t2369 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s87, { i64, ptr } %t2367, { i64, ptr } { i64 12, ptr @.d333 })
  store i1 %t2369, ptr %l656
  br label %bb364
bb364:
  %t2370 = load i1, ptr %l656, !tbaa !21
  br i1 %t2370, label %bb365, label %bb366
bb365:
  store i1 true, ptr %l657, !tbaa !21
  br label %bb368
bb366:
  %t2371 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t2373 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s87, { i64, ptr } %t2371, { i64, ptr } { i64 12, ptr @.d334 })
  store i1 %t2373, ptr %l659
  br label %bb367
bb367:
  %t2374 = load i1, ptr %l659, !tbaa !21
  store i1 %t2374, ptr %l657, !tbaa !21
  br label %bb368
bb368:
  %t2375 = load i1, ptr %l657, !tbaa !21
  br i1 %t2375, label %bb369, label %bb370
bb369:
  store %olang.scope zeroinitializer, ptr %s88
  %t2376 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t2378 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s88, { i64, ptr } %t2376, { i64, ptr } { i64 12, ptr @.d335 })
  store i1 %t2378, ptr %l661
  br label %bb371
bb370:
  br label %bb382
bb371:
  %t2379 = load i1, ptr %l661, !tbaa !21
  br i1 %t2379, label %bb372, label %bb373
bb372:
  store { i64, ptr } { i64 4, ptr @.d336 }, ptr %l662, !tbaa !27
  br label %bb374
bb373:
  store { i64, ptr } { i64 4, ptr @.d337 }, ptr %l662, !tbaa !27
  br label %bb374
bb374:
  %t2380 = load { i64, ptr }, ptr %l662, !tbaa !27
  %t2381 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2381, ptr %l663, !tbaa !29
  store { i64, ptr } %t2380, ptr %l664, !tbaa !27
  %t2383 = load ptr, ptr %l0, !tbaa !29
  %t2384 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t2385 = load ptr, ptr %lp11
  %t2386 = load { i64, ptr }, ptr %t2385, !tbaa !27
  %t2387 = extractvalue { i64, ptr } { i64 13, ptr @.d338 }, 1
  %t2388 = extractvalue { i64, ptr } { i64 13, ptr @.d338 }, 0
  %t2390 = extractvalue { i64, ptr } %t2384, 1
  %t2391 = extractvalue { i64, ptr } %t2384, 0
  %t2392 = add i64 %t2388, %t2391
  %t2393 = extractvalue { i64, ptr } { i64 1, ptr @.d339 }, 1
  %t2394 = extractvalue { i64, ptr } { i64 1, ptr @.d339 }, 0
  %t2395 = add i64 %t2392, %t2394
  %t2397 = extractvalue { i64, ptr } %t2386, 1
  %t2398 = extractvalue { i64, ptr } %t2386, 0
  %t2399 = add i64 %t2395, %t2398
  %t2400 = extractvalue { i64, ptr } { i64 3, ptr @.d340 }, 1
  %t2401 = extractvalue { i64, ptr } { i64 3, ptr @.d340 }, 0
  %t2402 = add i64 %t2399, %t2401
  %t2403 = call ptr @__olang_scope_alloc(ptr %s88, i64 %t2402)
  call void @olang_textcopy(ptr %t2403, ptr %t2387, i64 %t2388)
  %t2404 = getelementptr i8, ptr %t2403, i64 %t2388
  call void @olang_textcopy(ptr %t2404, ptr %t2390, i64 %t2391)
  %t2405 = getelementptr i8, ptr %t2404, i64 %t2391
  call void @olang_textcopy(ptr %t2405, ptr %t2393, i64 %t2394)
  %t2406 = getelementptr i8, ptr %t2405, i64 %t2394
  call void @olang_textcopy(ptr %t2406, ptr %t2397, i64 %t2398)
  %t2407 = getelementptr i8, ptr %t2406, i64 %t2398
  call void @olang_textcopy(ptr %t2407, ptr %t2400, i64 %t2401)
  %t2408 = insertvalue { i64, ptr } undef, i64 %t2402, 0
  %t2409 = insertvalue { i64, ptr } %t2408, ptr %t2403, 1
  %t2411 = extractvalue { i64, ptr } %t2409, 0
  %t2412 = extractvalue { i64, ptr } %t2409, 1
  %t2413 = mul i64 %t2411, 1
  %t2414 = call ptr @__olang_scope_alloc(ptr %s88, i64 %t2413)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2414, ptr %t2412, i64 %t2413, i1 false)
  %t2415 = insertvalue { i64, ptr } undef, i64 %t2411, 0
  %t2416 = insertvalue { i64, ptr } %t2415, ptr %t2414, 1
  %t2419 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s88, ptr %s88, ptr %t2383, { i64, ptr } %t2416)
  store { i64, ptr } %t2419, ptr %l670
  br label %bb375
bb375:
  %t2420 = load ptr, ptr %l0, !tbaa !29
  %t2421 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t2422 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t2423 = extractvalue { i64, ptr } { i64 13, ptr @.d341 }, 1
  %t2424 = extractvalue { i64, ptr } { i64 13, ptr @.d341 }, 0
  %t2426 = extractvalue { i64, ptr } %t2421, 1
  %t2427 = extractvalue { i64, ptr } %t2421, 0
  %t2428 = add i64 %t2424, %t2427
  %t2429 = extractvalue { i64, ptr } { i64 1, ptr @.d342 }, 1
  %t2430 = extractvalue { i64, ptr } { i64 1, ptr @.d342 }, 0
  %t2431 = add i64 %t2428, %t2430
  %t2433 = extractvalue { i64, ptr } %t2422, 1
  %t2434 = extractvalue { i64, ptr } %t2422, 0
  %t2435 = add i64 %t2431, %t2434
  %t2436 = extractvalue { i64, ptr } { i64 3, ptr @.d343 }, 1
  %t2437 = extractvalue { i64, ptr } { i64 3, ptr @.d343 }, 0
  %t2438 = add i64 %t2435, %t2437
  %t2439 = call ptr @__olang_scope_alloc(ptr %s88, i64 %t2438)
  call void @olang_textcopy(ptr %t2439, ptr %t2423, i64 %t2424)
  %t2440 = getelementptr i8, ptr %t2439, i64 %t2424
  call void @olang_textcopy(ptr %t2440, ptr %t2426, i64 %t2427)
  %t2441 = getelementptr i8, ptr %t2440, i64 %t2427
  call void @olang_textcopy(ptr %t2441, ptr %t2429, i64 %t2430)
  %t2442 = getelementptr i8, ptr %t2441, i64 %t2430
  call void @olang_textcopy(ptr %t2442, ptr %t2433, i64 %t2434)
  %t2443 = getelementptr i8, ptr %t2442, i64 %t2434
  call void @olang_textcopy(ptr %t2443, ptr %t2436, i64 %t2437)
  %t2444 = insertvalue { i64, ptr } undef, i64 %t2438, 0
  %t2445 = insertvalue { i64, ptr } %t2444, ptr %t2439, 1
  %t2447 = extractvalue { i64, ptr } %t2445, 0
  %t2448 = extractvalue { i64, ptr } %t2445, 1
  %t2449 = mul i64 %t2447, 1
  %t2450 = call ptr @__olang_scope_alloc(ptr %s88, i64 %t2449)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2450, ptr %t2448, i64 %t2449, i1 false)
  %t2451 = insertvalue { i64, ptr } undef, i64 %t2447, 0
  %t2452 = insertvalue { i64, ptr } %t2451, ptr %t2450, 1
  %t2455 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s88, ptr %s88, ptr %t2420, { i64, ptr } %t2452)
  store { i64, ptr } %t2455, ptr %l676
  br label %bb376
bb376:
  %t2456 = extractvalue { i64, ptr } { i64 8, ptr @.d344 }, 1
  %t2457 = extractvalue { i64, ptr } { i64 8, ptr @.d344 }, 0
  %t2458 = load { i64, ptr }, ptr %l664, !tbaa !27
  %t2459 = extractvalue { i64, ptr } %t2458, 1
  %t2460 = extractvalue { i64, ptr } %t2458, 0
  %t2461 = add i64 %t2457, %t2460
  %t2462 = load { i64, ptr }, ptr %l670, !tbaa !27
  %t2463 = extractvalue { i64, ptr } %t2462, 1
  %t2464 = extractvalue { i64, ptr } %t2462, 0
  %t2465 = add i64 %t2461, %t2464
  %t2466 = extractvalue { i64, ptr } { i64 2, ptr @.d345 }, 1
  %t2467 = extractvalue { i64, ptr } { i64 2, ptr @.d345 }, 0
  %t2468 = add i64 %t2465, %t2467
  %t2469 = load { i64, ptr }, ptr %l676, !tbaa !27
  %t2470 = extractvalue { i64, ptr } %t2469, 1
  %t2471 = extractvalue { i64, ptr } %t2469, 0
  %t2472 = add i64 %t2468, %t2471
  %t2473 = call ptr @__olang_scope_alloc(ptr %s88, i64 %t2472)
  call void @olang_textcopy(ptr %t2473, ptr %t2456, i64 %t2457)
  %t2474 = getelementptr i8, ptr %t2473, i64 %t2457
  call void @olang_textcopy(ptr %t2474, ptr %t2459, i64 %t2460)
  %t2475 = getelementptr i8, ptr %t2474, i64 %t2460
  call void @olang_textcopy(ptr %t2475, ptr %t2463, i64 %t2464)
  %t2476 = getelementptr i8, ptr %t2475, i64 %t2464
  call void @olang_textcopy(ptr %t2476, ptr %t2466, i64 %t2467)
  %t2477 = getelementptr i8, ptr %t2476, i64 %t2467
  call void @olang_textcopy(ptr %t2477, ptr %t2470, i64 %t2471)
  %t2478 = insertvalue { i64, ptr } undef, i64 %t2472, 0
  %t2479 = insertvalue { i64, ptr } %t2478, ptr %t2473, 1
  %t2481 = extractvalue { i64, ptr } %t2479, 0
  %t2482 = extractvalue { i64, ptr } %t2479, 1
  %t2483 = mul i64 %t2481, 1
  %t2484 = call ptr @__olang_scope_alloc(ptr %s88, i64 %t2483)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2484, ptr %t2482, i64 %t2483, i1 false)
  %t2485 = insertvalue { i64, ptr } undef, i64 %t2481, 0
  %t2486 = insertvalue { i64, ptr } %t2485, ptr %t2484, 1
  %t2487 = load ptr, ptr %l663, !tbaa !29
  %t2489 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s88, ptr %s88, ptr %t2487, { i64, ptr } %t2486)
  store { i64, ptr } %t2489, ptr %l679
  br label %bb377
bb377:
  %t2490 = load { i64, ptr }, ptr %l679, !tbaa !27
  store { i64, ptr } %t2490, ptr %l45, !tbaa !27
  %t2491 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2491, ptr %l680, !tbaa !29
  %t2492 = load ptr, ptr %l0, !tbaa !29
  %t2493 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t2494 = load ptr, ptr %lp11
  %t2495 = load { i64, ptr }, ptr %t2494, !tbaa !27
  %t2496 = extractvalue { i64, ptr } { i64 13, ptr @.d346 }, 1
  %t2497 = extractvalue { i64, ptr } { i64 13, ptr @.d346 }, 0
  %t2499 = extractvalue { i64, ptr } %t2493, 1
  %t2500 = extractvalue { i64, ptr } %t2493, 0
  %t2501 = add i64 %t2497, %t2500
  %t2502 = extractvalue { i64, ptr } { i64 1, ptr @.d347 }, 1
  %t2503 = extractvalue { i64, ptr } { i64 1, ptr @.d347 }, 0
  %t2504 = add i64 %t2501, %t2503
  %t2506 = extractvalue { i64, ptr } %t2495, 1
  %t2507 = extractvalue { i64, ptr } %t2495, 0
  %t2508 = add i64 %t2504, %t2507
  %t2509 = extractvalue { i64, ptr } { i64 3, ptr @.d348 }, 1
  %t2510 = extractvalue { i64, ptr } { i64 3, ptr @.d348 }, 0
  %t2511 = add i64 %t2508, %t2510
  %t2512 = call ptr @__olang_scope_alloc(ptr %s88, i64 %t2511)
  call void @olang_textcopy(ptr %t2512, ptr %t2496, i64 %t2497)
  %t2513 = getelementptr i8, ptr %t2512, i64 %t2497
  call void @olang_textcopy(ptr %t2513, ptr %t2499, i64 %t2500)
  %t2514 = getelementptr i8, ptr %t2513, i64 %t2500
  call void @olang_textcopy(ptr %t2514, ptr %t2502, i64 %t2503)
  %t2515 = getelementptr i8, ptr %t2514, i64 %t2503
  call void @olang_textcopy(ptr %t2515, ptr %t2506, i64 %t2507)
  %t2516 = getelementptr i8, ptr %t2515, i64 %t2507
  call void @olang_textcopy(ptr %t2516, ptr %t2509, i64 %t2510)
  %t2517 = insertvalue { i64, ptr } undef, i64 %t2511, 0
  %t2518 = insertvalue { i64, ptr } %t2517, ptr %t2512, 1
  %t2520 = extractvalue { i64, ptr } %t2518, 0
  %t2521 = extractvalue { i64, ptr } %t2518, 1
  %t2522 = mul i64 %t2520, 1
  %t2523 = call ptr @__olang_scope_alloc(ptr %s88, i64 %t2522)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2523, ptr %t2521, i64 %t2522, i1 false)
  %t2524 = insertvalue { i64, ptr } undef, i64 %t2520, 0
  %t2525 = insertvalue { i64, ptr } %t2524, ptr %t2523, 1
  %t2528 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s88, ptr %s88, ptr %t2492, { i64, ptr } %t2525)
  store { i64, ptr } %t2528, ptr %l686
  br label %bb378
bb378:
  %t2529 = load ptr, ptr %l0, !tbaa !29
  %t2530 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t2531 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t2532 = extractvalue { i64, ptr } { i64 13, ptr @.d349 }, 1
  %t2533 = extractvalue { i64, ptr } { i64 13, ptr @.d349 }, 0
  %t2535 = extractvalue { i64, ptr } %t2530, 1
  %t2536 = extractvalue { i64, ptr } %t2530, 0
  %t2537 = add i64 %t2533, %t2536
  %t2538 = extractvalue { i64, ptr } { i64 1, ptr @.d350 }, 1
  %t2539 = extractvalue { i64, ptr } { i64 1, ptr @.d350 }, 0
  %t2540 = add i64 %t2537, %t2539
  %t2542 = extractvalue { i64, ptr } %t2531, 1
  %t2543 = extractvalue { i64, ptr } %t2531, 0
  %t2544 = add i64 %t2540, %t2543
  %t2545 = extractvalue { i64, ptr } { i64 3, ptr @.d351 }, 1
  %t2546 = extractvalue { i64, ptr } { i64 3, ptr @.d351 }, 0
  %t2547 = add i64 %t2544, %t2546
  %t2548 = call ptr @__olang_scope_alloc(ptr %s88, i64 %t2547)
  call void @olang_textcopy(ptr %t2548, ptr %t2532, i64 %t2533)
  %t2549 = getelementptr i8, ptr %t2548, i64 %t2533
  call void @olang_textcopy(ptr %t2549, ptr %t2535, i64 %t2536)
  %t2550 = getelementptr i8, ptr %t2549, i64 %t2536
  call void @olang_textcopy(ptr %t2550, ptr %t2538, i64 %t2539)
  %t2551 = getelementptr i8, ptr %t2550, i64 %t2539
  call void @olang_textcopy(ptr %t2551, ptr %t2542, i64 %t2543)
  %t2552 = getelementptr i8, ptr %t2551, i64 %t2543
  call void @olang_textcopy(ptr %t2552, ptr %t2545, i64 %t2546)
  %t2553 = insertvalue { i64, ptr } undef, i64 %t2547, 0
  %t2554 = insertvalue { i64, ptr } %t2553, ptr %t2548, 1
  %t2556 = extractvalue { i64, ptr } %t2554, 0
  %t2557 = extractvalue { i64, ptr } %t2554, 1
  %t2558 = mul i64 %t2556, 1
  %t2559 = call ptr @__olang_scope_alloc(ptr %s88, i64 %t2558)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2559, ptr %t2557, i64 %t2558, i1 false)
  %t2560 = insertvalue { i64, ptr } undef, i64 %t2556, 0
  %t2561 = insertvalue { i64, ptr } %t2560, ptr %t2559, 1
  %t2564 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s88, ptr %s88, ptr %t2529, { i64, ptr } %t2561)
  store { i64, ptr } %t2564, ptr %l692
  br label %bb379
bb379:
  %t2565 = extractvalue { i64, ptr } { i64 12, ptr @.d352 }, 1
  %t2566 = extractvalue { i64, ptr } { i64 12, ptr @.d352 }, 0
  %t2567 = load { i64, ptr }, ptr %l686, !tbaa !27
  %t2568 = extractvalue { i64, ptr } %t2567, 1
  %t2569 = extractvalue { i64, ptr } %t2567, 0
  %t2570 = add i64 %t2566, %t2569
  %t2571 = extractvalue { i64, ptr } { i64 2, ptr @.d353 }, 1
  %t2572 = extractvalue { i64, ptr } { i64 2, ptr @.d353 }, 0
  %t2573 = add i64 %t2570, %t2572
  %t2574 = load { i64, ptr }, ptr %l692, !tbaa !27
  %t2575 = extractvalue { i64, ptr } %t2574, 1
  %t2576 = extractvalue { i64, ptr } %t2574, 0
  %t2577 = add i64 %t2573, %t2576
  %t2578 = call ptr @__olang_scope_alloc(ptr %s88, i64 %t2577)
  call void @olang_textcopy(ptr %t2578, ptr %t2565, i64 %t2566)
  %t2579 = getelementptr i8, ptr %t2578, i64 %t2566
  call void @olang_textcopy(ptr %t2579, ptr %t2568, i64 %t2569)
  %t2580 = getelementptr i8, ptr %t2579, i64 %t2569
  call void @olang_textcopy(ptr %t2580, ptr %t2571, i64 %t2572)
  %t2581 = getelementptr i8, ptr %t2580, i64 %t2572
  call void @olang_textcopy(ptr %t2581, ptr %t2575, i64 %t2576)
  %t2582 = insertvalue { i64, ptr } undef, i64 %t2577, 0
  %t2583 = insertvalue { i64, ptr } %t2582, ptr %t2578, 1
  %t2585 = extractvalue { i64, ptr } %t2583, 0
  %t2586 = extractvalue { i64, ptr } %t2583, 1
  %t2587 = mul i64 %t2585, 1
  %t2588 = call ptr @__olang_scope_alloc(ptr %s88, i64 %t2587)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2588, ptr %t2586, i64 %t2587, i1 false)
  %t2589 = insertvalue { i64, ptr } undef, i64 %t2585, 0
  %t2590 = insertvalue { i64, ptr } %t2589, ptr %t2588, 1
  %t2591 = load ptr, ptr %l680, !tbaa !29
  %t2593 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s88, ptr %s88, ptr %t2591, { i64, ptr } %t2590)
  store { i64, ptr } %t2593, ptr %l695
  br label %bb380
bb380:
  %t2594 = load { i64, ptr }, ptr %l695, !tbaa !27
  %t2595 = load ptr, ptr %l0, !tbaa !29
  %t2596 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t2598 = extractvalue { i64, ptr } { i64 7, ptr @.d354 }, 1
  %t2599 = extractvalue { i64, ptr } { i64 7, ptr @.d354 }, 0
  %t2601 = extractvalue { i64, ptr } %t2596, 1
  %t2602 = extractvalue { i64, ptr } %t2596, 0
  %t2603 = add i64 %t2599, %t2602
  %t2604 = extractvalue { i64, ptr } { i64 2, ptr @.d355 }, 1
  %t2605 = extractvalue { i64, ptr } { i64 2, ptr @.d355 }, 0
  %t2606 = add i64 %t2603, %t2605
  %t2608 = extractvalue { i64, ptr } %t2594, 1
  %t2609 = extractvalue { i64, ptr } %t2594, 0
  %t2610 = add i64 %t2606, %t2609
  %t2611 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2610)
  call void @olang_textcopy(ptr %t2611, ptr %t2598, i64 %t2599)
  %t2612 = getelementptr i8, ptr %t2611, i64 %t2599
  call void @olang_textcopy(ptr %t2612, ptr %t2601, i64 %t2602)
  %t2613 = getelementptr i8, ptr %t2612, i64 %t2602
  call void @olang_textcopy(ptr %t2613, ptr %t2604, i64 %t2605)
  %t2614 = getelementptr i8, ptr %t2613, i64 %t2605
  call void @olang_textcopy(ptr %t2614, ptr %t2608, i64 %t2609)
  %t2615 = insertvalue { i64, ptr } undef, i64 %t2610, 0
  %t2616 = insertvalue { i64, ptr } %t2615, ptr %t2611, 1
  %t2618 = extractvalue { i64, ptr } %t2616, 0
  %t2619 = extractvalue { i64, ptr } %t2616, 1
  %t2620 = mul i64 %t2618, 1
  %t2621 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2620)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2621, ptr %t2619, i64 %t2620, i1 false)
  %t2622 = insertvalue { i64, ptr } undef, i64 %t2618, 0
  %t2623 = insertvalue { i64, ptr } %t2622, ptr %t2621, 1
  %t2626 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t2595, { i64, ptr } %t2623)
  store { i64, ptr } %t2626, ptr %l701
  br label %bb381
bb381:
  call void @__olang_scope_close(ptr %s88)
  call void @__olang_scope_close(ptr %s87)
  call void @__olang_scope_close(ptr %s0)
  %t2627 = load { i64, ptr }, ptr %l701, !tbaa !27
  store { i64, ptr } %t2627, ptr %rv
  br label %ret
bb382:
  %t2628 = load ptr, ptr %l0, !tbaa !29
  %t2629 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t2630 = load ptr, ptr %lp11
  %t2631 = load { i64, ptr }, ptr %t2630, !tbaa !27
  %t2632 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t2633 = extractvalue { i64, ptr } { i64 8, ptr @.d356 }, 1
  %t2634 = extractvalue { i64, ptr } { i64 8, ptr @.d356 }, 0
  %t2636 = extractvalue { i64, ptr } %t2629, 1
  %t2637 = extractvalue { i64, ptr } %t2629, 0
  %t2638 = add i64 %t2634, %t2637
  %t2639 = extractvalue { i64, ptr } { i64 1, ptr @.d357 }, 1
  %t2640 = extractvalue { i64, ptr } { i64 1, ptr @.d357 }, 0
  %t2641 = add i64 %t2638, %t2640
  %t2643 = extractvalue { i64, ptr } %t2631, 1
  %t2644 = extractvalue { i64, ptr } %t2631, 0
  %t2645 = add i64 %t2641, %t2644
  %t2646 = extractvalue { i64, ptr } { i64 2, ptr @.d358 }, 1
  %t2647 = extractvalue { i64, ptr } { i64 2, ptr @.d358 }, 0
  %t2648 = add i64 %t2645, %t2647
  %t2650 = extractvalue { i64, ptr } %t2632, 1
  %t2651 = extractvalue { i64, ptr } %t2632, 0
  %t2652 = add i64 %t2648, %t2651
  %t2653 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2652)
  call void @olang_textcopy(ptr %t2653, ptr %t2633, i64 %t2634)
  %t2654 = getelementptr i8, ptr %t2653, i64 %t2634
  call void @olang_textcopy(ptr %t2654, ptr %t2636, i64 %t2637)
  %t2655 = getelementptr i8, ptr %t2654, i64 %t2637
  call void @olang_textcopy(ptr %t2655, ptr %t2639, i64 %t2640)
  %t2656 = getelementptr i8, ptr %t2655, i64 %t2640
  call void @olang_textcopy(ptr %t2656, ptr %t2643, i64 %t2644)
  %t2657 = getelementptr i8, ptr %t2656, i64 %t2644
  call void @olang_textcopy(ptr %t2657, ptr %t2646, i64 %t2647)
  %t2658 = getelementptr i8, ptr %t2657, i64 %t2647
  call void @olang_textcopy(ptr %t2658, ptr %t2650, i64 %t2651)
  %t2659 = insertvalue { i64, ptr } undef, i64 %t2652, 0
  %t2660 = insertvalue { i64, ptr } %t2659, ptr %t2653, 1
  %t2662 = extractvalue { i64, ptr } %t2660, 0
  %t2663 = extractvalue { i64, ptr } %t2660, 1
  %t2664 = mul i64 %t2662, 1
  %t2665 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2664)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2665, ptr %t2663, i64 %t2664, i1 false)
  %t2666 = insertvalue { i64, ptr } undef, i64 %t2662, 0
  %t2667 = insertvalue { i64, ptr } %t2666, ptr %t2665, 1
  %t2670 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t2628, { i64, ptr } %t2667)
  store { i64, ptr } %t2670, ptr %l708
  br label %bb383
bb383:
  call void @__olang_scope_close(ptr %s87)
  call void @__olang_scope_close(ptr %s0)
  %t2671 = load { i64, ptr }, ptr %l708, !tbaa !27
  store { i64, ptr } %t2671, ptr %rv
  br label %ret
bb384:
  %t2672 = load i32, ptr %l1
  %t2674 = trunc i64 23 to i32
  %t2675 = icmp eq i32 %t2672, %t2674
  br i1 %t2675, label %bb385, label %bb386
bb385:
  br label %bb387
bb386:
  br label %bb396
bb387:
  store %olang.scope zeroinitializer, ptr %s97
  %t2677 = load ptr, ptr %l0, !tbaa !29
  %t2679 = getelementptr %"compiler/emit:fnEm", ptr %t2677, i32 0, i32 0
  %t2680 = load ptr, ptr %t2679, !tbaa !29
  %t2681 = load i32, ptr %l7, !tbaa !23
  %t2684 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eenumWords(ptr %v0, ptr %t2680, i32 %t2681)
  store i1 %t2684, ptr %l714
  br label %bb388
bb388:
  %t2685 = load i1, ptr %l714, !tbaa !21
  br i1 %t2685, label %bb389, label %bb390
bb389:
  store %olang.scope zeroinitializer, ptr %s98
  %t2686 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2686, ptr %l715, !tbaa !29
  %t2687 = load ptr, ptr %l0, !tbaa !29
  %t2688 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t2689 = load ptr, ptr %lp11
  %t2690 = load { i64, ptr }, ptr %t2689, !tbaa !27
  %t2691 = extractvalue { i64, ptr } { i64 13, ptr @.d359 }, 1
  %t2692 = extractvalue { i64, ptr } { i64 13, ptr @.d359 }, 0
  %t2694 = extractvalue { i64, ptr } %t2688, 1
  %t2695 = extractvalue { i64, ptr } %t2688, 0
  %t2696 = add i64 %t2692, %t2695
  %t2697 = extractvalue { i64, ptr } { i64 1, ptr @.d360 }, 1
  %t2698 = extractvalue { i64, ptr } { i64 1, ptr @.d360 }, 0
  %t2699 = add i64 %t2696, %t2698
  %t2701 = extractvalue { i64, ptr } %t2690, 1
  %t2702 = extractvalue { i64, ptr } %t2690, 0
  %t2703 = add i64 %t2699, %t2702
  %t2704 = extractvalue { i64, ptr } { i64 3, ptr @.d361 }, 1
  %t2705 = extractvalue { i64, ptr } { i64 3, ptr @.d361 }, 0
  %t2706 = add i64 %t2703, %t2705
  %t2707 = call ptr @__olang_scope_alloc(ptr %s98, i64 %t2706)
  call void @olang_textcopy(ptr %t2707, ptr %t2691, i64 %t2692)
  %t2708 = getelementptr i8, ptr %t2707, i64 %t2692
  call void @olang_textcopy(ptr %t2708, ptr %t2694, i64 %t2695)
  %t2709 = getelementptr i8, ptr %t2708, i64 %t2695
  call void @olang_textcopy(ptr %t2709, ptr %t2697, i64 %t2698)
  %t2710 = getelementptr i8, ptr %t2709, i64 %t2698
  call void @olang_textcopy(ptr %t2710, ptr %t2701, i64 %t2702)
  %t2711 = getelementptr i8, ptr %t2710, i64 %t2702
  call void @olang_textcopy(ptr %t2711, ptr %t2704, i64 %t2705)
  %t2712 = insertvalue { i64, ptr } undef, i64 %t2706, 0
  %t2713 = insertvalue { i64, ptr } %t2712, ptr %t2707, 1
  %t2715 = extractvalue { i64, ptr } %t2713, 0
  %t2716 = extractvalue { i64, ptr } %t2713, 1
  %t2717 = mul i64 %t2715, 1
  %t2718 = call ptr @__olang_scope_alloc(ptr %s98, i64 %t2717)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2718, ptr %t2716, i64 %t2717, i1 false)
  %t2719 = insertvalue { i64, ptr } undef, i64 %t2715, 0
  %t2720 = insertvalue { i64, ptr } %t2719, ptr %t2718, 1
  %t2723 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s98, ptr %s98, ptr %t2687, { i64, ptr } %t2720)
  store { i64, ptr } %t2723, ptr %l721
  br label %bb391
bb390:
  br label %bb393
bb391:
  %t2724 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t2725 = extractvalue { i64, ptr } { i64 12, ptr @.d362 }, 1
  %t2726 = extractvalue { i64, ptr } { i64 12, ptr @.d362 }, 0
  %t2727 = load { i64, ptr }, ptr %l721, !tbaa !27
  %t2728 = extractvalue { i64, ptr } %t2727, 1
  %t2729 = extractvalue { i64, ptr } %t2727, 0
  %t2730 = add i64 %t2726, %t2729
  %t2731 = extractvalue { i64, ptr } { i64 2, ptr @.d363 }, 1
  %t2732 = extractvalue { i64, ptr } { i64 2, ptr @.d363 }, 0
  %t2733 = add i64 %t2730, %t2732
  %t2735 = extractvalue { i64, ptr } %t2724, 1
  %t2736 = extractvalue { i64, ptr } %t2724, 0
  %t2737 = add i64 %t2733, %t2736
  %t2738 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2737)
  call void @olang_textcopy(ptr %t2738, ptr %t2725, i64 %t2726)
  %t2739 = getelementptr i8, ptr %t2738, i64 %t2726
  call void @olang_textcopy(ptr %t2739, ptr %t2728, i64 %t2729)
  %t2740 = getelementptr i8, ptr %t2739, i64 %t2729
  call void @olang_textcopy(ptr %t2740, ptr %t2731, i64 %t2732)
  %t2741 = getelementptr i8, ptr %t2740, i64 %t2732
  call void @olang_textcopy(ptr %t2741, ptr %t2735, i64 %t2736)
  %t2742 = insertvalue { i64, ptr } undef, i64 %t2737, 0
  %t2743 = insertvalue { i64, ptr } %t2742, ptr %t2738, 1
  %t2745 = extractvalue { i64, ptr } %t2743, 0
  %t2746 = extractvalue { i64, ptr } %t2743, 1
  %t2747 = mul i64 %t2745, 1
  %t2748 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2747)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2748, ptr %t2746, i64 %t2747, i1 false)
  %t2749 = insertvalue { i64, ptr } undef, i64 %t2745, 0
  %t2750 = insertvalue { i64, ptr } %t2749, ptr %t2748, 1
  %t2751 = load ptr, ptr %l715, !tbaa !29
  %t2753 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t2751, { i64, ptr } %t2750)
  store { i64, ptr } %t2753, ptr %l725
  br label %bb392
bb392:
  call void @__olang_scope_close(ptr %s98)
  call void @__olang_scope_close(ptr %s97)
  call void @__olang_scope_close(ptr %s0)
  %t2754 = load { i64, ptr }, ptr %l725, !tbaa !27
  store { i64, ptr } %t2754, ptr %rv
  br label %ret
bb393:
  %t2755 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2755, ptr %l726, !tbaa !29
  %t2756 = load ptr, ptr %lp11
  %t2757 = load { i64, ptr }, ptr %t2756, !tbaa !27
  store { i64, ptr } %t2757, ptr %l727, !tbaa !27
  %t2758 = load ptr, ptr %l0, !tbaa !29
  %t2759 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t2760 = extractvalue { i64, ptr } { i64 10, ptr @.d364 }, 1
  %t2761 = extractvalue { i64, ptr } { i64 10, ptr @.d364 }, 0
  %t2763 = extractvalue { i64, ptr } %t2759, 1
  %t2764 = extractvalue { i64, ptr } %t2759, 0
  %t2765 = add i64 %t2761, %t2764
  %t2766 = extractvalue { i64, ptr } { i64 7, ptr @.d365 }, 1
  %t2767 = extractvalue { i64, ptr } { i64 7, ptr @.d365 }, 0
  %t2768 = add i64 %t2765, %t2767
  %t2769 = call ptr @__olang_scope_alloc(ptr %s97, i64 %t2768)
  call void @olang_textcopy(ptr %t2769, ptr %t2760, i64 %t2761)
  %t2770 = getelementptr i8, ptr %t2769, i64 %t2761
  call void @olang_textcopy(ptr %t2770, ptr %t2763, i64 %t2764)
  %t2771 = getelementptr i8, ptr %t2770, i64 %t2764
  call void @olang_textcopy(ptr %t2771, ptr %t2766, i64 %t2767)
  %t2772 = insertvalue { i64, ptr } undef, i64 %t2768, 0
  %t2773 = insertvalue { i64, ptr } %t2772, ptr %t2769, 1
  %t2775 = extractvalue { i64, ptr } %t2773, 0
  %t2776 = extractvalue { i64, ptr } %t2773, 1
  %t2777 = mul i64 %t2775, 1
  %t2778 = call ptr @__olang_scope_alloc(ptr %s97, i64 %t2777)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2778, ptr %t2776, i64 %t2777, i1 false)
  %t2779 = insertvalue { i64, ptr } undef, i64 %t2775, 0
  %t2780 = insertvalue { i64, ptr } %t2779, ptr %t2778, 1
  %t2783 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s97, ptr %s97, ptr %t2758, { i64, ptr } %t2780)
  store { i64, ptr } %t2783, ptr %l732
  br label %bb394
bb394:
  %t2784 = extractvalue { i64, ptr } { i64 12, ptr @.d366 }, 1
  %t2785 = extractvalue { i64, ptr } { i64 12, ptr @.d366 }, 0
  %t2786 = load { i64, ptr }, ptr %l727, !tbaa !27
  %t2787 = extractvalue { i64, ptr } %t2786, 1
  %t2788 = extractvalue { i64, ptr } %t2786, 0
  %t2789 = add i64 %t2785, %t2788
  %t2790 = extractvalue { i64, ptr } { i64 2, ptr @.d367 }, 1
  %t2791 = extractvalue { i64, ptr } { i64 2, ptr @.d367 }, 0
  %t2792 = add i64 %t2789, %t2791
  %t2793 = load { i64, ptr }, ptr %l732, !tbaa !27
  %t2794 = extractvalue { i64, ptr } %t2793, 1
  %t2795 = extractvalue { i64, ptr } %t2793, 0
  %t2796 = add i64 %t2792, %t2795
  %t2797 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2796)
  call void @olang_textcopy(ptr %t2797, ptr %t2784, i64 %t2785)
  %t2798 = getelementptr i8, ptr %t2797, i64 %t2785
  call void @olang_textcopy(ptr %t2798, ptr %t2787, i64 %t2788)
  %t2799 = getelementptr i8, ptr %t2798, i64 %t2788
  call void @olang_textcopy(ptr %t2799, ptr %t2790, i64 %t2791)
  %t2800 = getelementptr i8, ptr %t2799, i64 %t2791
  call void @olang_textcopy(ptr %t2800, ptr %t2794, i64 %t2795)
  %t2801 = insertvalue { i64, ptr } undef, i64 %t2796, 0
  %t2802 = insertvalue { i64, ptr } %t2801, ptr %t2797, 1
  %t2804 = extractvalue { i64, ptr } %t2802, 0
  %t2805 = extractvalue { i64, ptr } %t2802, 1
  %t2806 = mul i64 %t2804, 1
  %t2807 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2806)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2807, ptr %t2805, i64 %t2806, i1 false)
  %t2808 = insertvalue { i64, ptr } undef, i64 %t2804, 0
  %t2809 = insertvalue { i64, ptr } %t2808, ptr %t2807, 1
  %t2810 = load ptr, ptr %l726, !tbaa !29
  %t2812 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t2810, { i64, ptr } %t2809)
  store { i64, ptr } %t2812, ptr %l735
  br label %bb395
bb395:
  call void @__olang_scope_close(ptr %s97)
  call void @__olang_scope_close(ptr %s0)
  %t2813 = load { i64, ptr }, ptr %l735, !tbaa !27
  store { i64, ptr } %t2813, ptr %rv
  br label %ret
bb396:
  %t2814 = load i32, ptr %l1
  %t2816 = trunc i64 25 to i32
  %t2817 = icmp eq i32 %t2814, %t2816
  br i1 %t2817, label %bb397, label %bb398
bb397:
  br label %bb399
bb398:
  br label %bb406
bb399:
  store %olang.scope zeroinitializer, ptr %s103
  %t2819 = load ptr, ptr %l4, !tbaa !29
  %t2820 = load i32, ptr %l7, !tbaa !23
  %t2823 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t2819, i32 %t2820)
  store i32 %t2823, ptr %l740
  br label %bb400
bb400:
  %t2824 = load i32, ptr %l740, !tbaa !23
  store i32 %t2824, ptr %l47, !tbaa !23
  %t2825 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2825, ptr %l741, !tbaa !29
  %t2826 = load ptr, ptr %l0, !tbaa !29
  %t2827 = load i32, ptr %l47, !tbaa !23
  %t2830 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s103, ptr %t2826, i32 %t2827)
  store { i64, ptr } %t2830, ptr %l744
  br label %bb401
bb401:
  %t2831 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2831, ptr %l745, !tbaa !29
  %t2832 = load ptr, ptr %l0, !tbaa !29
  %t2833 = load %"compiler/mir:Range", ptr %l3
  %t2836 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t2832, %"compiler/mir:Range" %t2833, i64 1)
  store { i64, [4 x i64] } %t2836, ptr %l748
  br label %bb402
bb402:
  %t2837 = load i32, ptr %l47, !tbaa !23
  %t2838 = load ptr, ptr %l745, !tbaa !29
  %t2839 = load { i64, [4 x i64] }, ptr %l748
  %t2841 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s103, ptr %t2838, { i64, [4 x i64] } %t2839, i32 %t2837)
  store { i64, ptr } %t2841, ptr %l750
  br label %bb403
bb403:
  %t2842 = load ptr, ptr %lp11
  %t2843 = load { i64, ptr }, ptr %t2842, !tbaa !27
  store { i64, ptr } %t2843, ptr %l751, !tbaa !27
  %t2844 = load ptr, ptr %l0, !tbaa !29
  %t2845 = load i32, ptr %l47, !tbaa !23
  %t2848 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t2844, i32 %t2845)
  store i64 %t2848, ptr %l754
  br label %bb404
bb404:
  %t2849 = extractvalue { i64, ptr } { i64 13, ptr @.d368 }, 1
  %t2850 = extractvalue { i64, ptr } { i64 13, ptr @.d368 }, 0
  %t2851 = load { i64, ptr }, ptr %l744, !tbaa !27
  %t2852 = extractvalue { i64, ptr } %t2851, 1
  %t2853 = extractvalue { i64, ptr } %t2851, 0
  %t2854 = add i64 %t2850, %t2853
  %t2855 = extractvalue { i64, ptr } { i64 1, ptr @.d369 }, 1
  %t2856 = extractvalue { i64, ptr } { i64 1, ptr @.d369 }, 0
  %t2857 = add i64 %t2854, %t2856
  %t2858 = load { i64, ptr }, ptr %l750, !tbaa !27
  %t2859 = extractvalue { i64, ptr } %t2858, 1
  %t2860 = extractvalue { i64, ptr } %t2858, 0
  %t2861 = add i64 %t2857, %t2860
  %t2862 = extractvalue { i64, ptr } { i64 6, ptr @.d370 }, 1
  %t2863 = extractvalue { i64, ptr } { i64 6, ptr @.d370 }, 0
  %t2864 = add i64 %t2861, %t2863
  %t2865 = load { i64, ptr }, ptr %l751, !tbaa !27
  %t2866 = extractvalue { i64, ptr } %t2865, 1
  %t2867 = extractvalue { i64, ptr } %t2865, 0
  %t2868 = add i64 %t2864, %t2867
  %t2869 = extractvalue { i64, ptr } { i64 16, ptr @.d371 }, 1
  %t2870 = extractvalue { i64, ptr } { i64 16, ptr @.d371 }, 0
  %t2871 = add i64 %t2868, %t2870
  %t2872 = load i64, ptr %l754, !tbaa !24
  %t2873 = call i64 @__olang_fmt_i64(ptr null, i64 %t2872)
  %t2874 = add i64 %t2871, %t2873
  %t2875 = call ptr @__olang_scope_alloc(ptr %s103, i64 %t2874)
  call void @olang_textcopy(ptr %t2875, ptr %t2849, i64 %t2850)
  %t2876 = getelementptr i8, ptr %t2875, i64 %t2850
  call void @olang_textcopy(ptr %t2876, ptr %t2852, i64 %t2853)
  %t2877 = getelementptr i8, ptr %t2876, i64 %t2853
  call void @olang_textcopy(ptr %t2877, ptr %t2855, i64 %t2856)
  %t2878 = getelementptr i8, ptr %t2877, i64 %t2856
  call void @olang_textcopy(ptr %t2878, ptr %t2859, i64 %t2860)
  %t2879 = getelementptr i8, ptr %t2878, i64 %t2860
  call void @olang_textcopy(ptr %t2879, ptr %t2862, i64 %t2863)
  %t2880 = getelementptr i8, ptr %t2879, i64 %t2863
  call void @olang_textcopy(ptr %t2880, ptr %t2866, i64 %t2867)
  %t2881 = getelementptr i8, ptr %t2880, i64 %t2867
  call void @olang_textcopy(ptr %t2881, ptr %t2869, i64 %t2870)
  %t2882 = getelementptr i8, ptr %t2881, i64 %t2870
  %t2883 = call i64 @__olang_fmt_i64(ptr %t2882, i64 %t2872)
  %t2884 = insertvalue { i64, ptr } undef, i64 %t2874, 0
  %t2885 = insertvalue { i64, ptr } %t2884, ptr %t2875, 1
  %t2887 = extractvalue { i64, ptr } %t2885, 0
  %t2888 = extractvalue { i64, ptr } %t2885, 1
  %t2889 = mul i64 %t2887, 1
  %t2890 = call ptr @__olang_scope_alloc(ptr %s103, i64 %t2889)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2890, ptr %t2888, i64 %t2889, i1 false)
  %t2891 = insertvalue { i64, ptr } undef, i64 %t2887, 0
  %t2892 = insertvalue { i64, ptr } %t2891, ptr %t2890, 1
  %t2893 = load ptr, ptr %l741, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s103, ptr %t2893, { i64, ptr } %t2892)
  br label %bb405
bb405:
  store { i64, ptr } { i64 5, ptr @.d372 }, ptr %l757, !tbaa !27
  %t2895 = load { i64, ptr }, ptr %l757, !tbaa !27
  store { i64, ptr } %t2895, ptr %l758, !tbaa !27
  %t2896 = load { i64, ptr }, ptr %l758, !tbaa !27
  %t2897 = extractvalue { i64, ptr } %t2896, 0
  store i64 %t2897, ptr %l759, !tbaa !24
  %t2898 = load i64, ptr %l759, !tbaa !24
  %t2899 = mul i64 %t2898, 1
  %t2900 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t2899)
  %t2901 = insertvalue { i64, ptr } undef, i64 %t2898, 0
  %t2902 = insertvalue { i64, ptr } %t2901, ptr %t2900, 1
  store { i64, ptr } %t2902, ptr %l760, !tbaa !27
  %t2903 = getelementptr { i64, ptr }, ptr %l760, i32 0, i32 1
  %t2904 = load ptr, ptr %t2903, !tbaa !27
  %t2905 = getelementptr { i64, ptr }, ptr %l758, i32 0, i32 1
  %t2906 = load ptr, ptr %t2905, !tbaa !27
  %t2907 = load i64, ptr %l759, !tbaa !24
  %t2908 = mul i64 %t2907, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t2904, ptr %t2906, i64 %t2908, i1 false)
  %t2909 = load { i64, ptr }, ptr %l760, !tbaa !27
  store { i64, ptr } %t2909, ptr %l758, !tbaa !27
  call void @__olang_scope_close(ptr %s103)
  call void @__olang_scope_close(ptr %s0)
  %t2910 = load { i64, ptr }, ptr %l758, !tbaa !27
  store { i64, ptr } %t2910, ptr %rv
  br label %ret
bb406:
  %t2911 = load i32, ptr %l1
  %t2913 = trunc i64 26 to i32
  %t2914 = icmp eq i32 %t2911, %t2913
  br i1 %t2914, label %bb407, label %bb408
bb407:
  br label %bb411
bb408:
  %t2916 = load i32, ptr %l1
  %t2918 = trunc i64 27 to i32
  %t2919 = icmp eq i32 %t2916, %t2918
  br i1 %t2919, label %bb409, label %bb410
bb409:
  br label %bb411
bb410:
  br label %bb420
bb411:
  store %olang.scope zeroinitializer, ptr %s105
  %t2921 = load ptr, ptr %l4, !tbaa !29
  %t2922 = load i32, ptr %l7, !tbaa !23
  %t2925 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t2921, i32 %t2922)
  store i32 %t2925, ptr %l767
  br label %bb412
bb412:
  %t2926 = load i32, ptr %l767, !tbaa !23
  store i32 %t2926, ptr %l48, !tbaa !23
  %t2927 = load i32, ptr %l1
  %t2929 = trunc i64 26 to i32
  %t2930 = icmp eq i32 %t2927, %t2929
  br i1 %t2930, label %bb413, label %bb414
bb413:
  store { i64, ptr } { i64 3, ptr @.d373 }, ptr %l770, !tbaa !27
  br label %bb415
bb414:
  store { i64, ptr } { i64 4, ptr @.d374 }, ptr %l770, !tbaa !27
  br label %bb415
bb415:
  %t2932 = load { i64, ptr }, ptr %l770, !tbaa !27
  %t2933 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2933, ptr %l771, !tbaa !29
  store { i64, ptr } %t2932, ptr %l772, !tbaa !27
  %t2935 = load ptr, ptr %lp11
  %t2936 = load { i64, ptr }, ptr %t2935, !tbaa !27
  store { i64, ptr } %t2936, ptr %l773, !tbaa !27
  %t2937 = load ptr, ptr %l0, !tbaa !29
  %t2938 = load i32, ptr %l48, !tbaa !23
  %t2941 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s105, ptr %t2937, i32 %t2938)
  store { i64, ptr } %t2941, ptr %l776
  br label %bb416
bb416:
  %t2942 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2942, ptr %l777, !tbaa !29
  %t2943 = load ptr, ptr %l0, !tbaa !29
  %t2944 = load %"compiler/mir:Range", ptr %l3
  %t2947 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t2943, %"compiler/mir:Range" %t2944, i64 1)
  store { i64, [4 x i64] } %t2947, ptr %l780
  br label %bb417
bb417:
  %t2948 = load i32, ptr %l48, !tbaa !23
  %t2949 = load ptr, ptr %l777, !tbaa !29
  %t2950 = load { i64, [4 x i64] }, ptr %l780
  %t2952 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s105, ptr %t2949, { i64, [4 x i64] } %t2950, i32 %t2948)
  store { i64, ptr } %t2952, ptr %l782
  br label %bb418
bb418:
  %t2953 = extractvalue { i64, ptr } { i64 10, ptr @.d375 }, 1
  %t2954 = extractvalue { i64, ptr } { i64 10, ptr @.d375 }, 0
  %t2955 = load { i64, ptr }, ptr %l772, !tbaa !27
  %t2956 = extractvalue { i64, ptr } %t2955, 1
  %t2957 = extractvalue { i64, ptr } %t2955, 0
  %t2958 = add i64 %t2954, %t2957
  %t2959 = extractvalue { i64, ptr } { i64 5, ptr @.d376 }, 1
  %t2960 = extractvalue { i64, ptr } { i64 5, ptr @.d376 }, 0
  %t2961 = add i64 %t2958, %t2960
  %t2962 = load { i64, ptr }, ptr %l773, !tbaa !27
  %t2963 = extractvalue { i64, ptr } %t2962, 1
  %t2964 = extractvalue { i64, ptr } %t2962, 0
  %t2965 = add i64 %t2961, %t2964
  %t2966 = extractvalue { i64, ptr } { i64 2, ptr @.d377 }, 1
  %t2967 = extractvalue { i64, ptr } { i64 2, ptr @.d377 }, 0
  %t2968 = add i64 %t2965, %t2967
  %t2969 = load { i64, ptr }, ptr %l776, !tbaa !27
  %t2970 = extractvalue { i64, ptr } %t2969, 1
  %t2971 = extractvalue { i64, ptr } %t2969, 0
  %t2972 = add i64 %t2968, %t2971
  %t2973 = extractvalue { i64, ptr } { i64 1, ptr @.d378 }, 1
  %t2974 = extractvalue { i64, ptr } { i64 1, ptr @.d378 }, 0
  %t2975 = add i64 %t2972, %t2974
  %t2976 = load { i64, ptr }, ptr %l782, !tbaa !27
  %t2977 = extractvalue { i64, ptr } %t2976, 1
  %t2978 = extractvalue { i64, ptr } %t2976, 0
  %t2979 = add i64 %t2975, %t2978
  %t2980 = extractvalue { i64, ptr } { i64 8, ptr @.d379 }, 1
  %t2981 = extractvalue { i64, ptr } { i64 8, ptr @.d379 }, 0
  %t2982 = add i64 %t2979, %t2981
  %t2983 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2982)
  call void @olang_textcopy(ptr %t2983, ptr %t2953, i64 %t2954)
  %t2984 = getelementptr i8, ptr %t2983, i64 %t2954
  call void @olang_textcopy(ptr %t2984, ptr %t2956, i64 %t2957)
  %t2985 = getelementptr i8, ptr %t2984, i64 %t2957
  call void @olang_textcopy(ptr %t2985, ptr %t2959, i64 %t2960)
  %t2986 = getelementptr i8, ptr %t2985, i64 %t2960
  call void @olang_textcopy(ptr %t2986, ptr %t2963, i64 %t2964)
  %t2987 = getelementptr i8, ptr %t2986, i64 %t2964
  call void @olang_textcopy(ptr %t2987, ptr %t2966, i64 %t2967)
  %t2988 = getelementptr i8, ptr %t2987, i64 %t2967
  call void @olang_textcopy(ptr %t2988, ptr %t2970, i64 %t2971)
  %t2989 = getelementptr i8, ptr %t2988, i64 %t2971
  call void @olang_textcopy(ptr %t2989, ptr %t2973, i64 %t2974)
  %t2990 = getelementptr i8, ptr %t2989, i64 %t2974
  call void @olang_textcopy(ptr %t2990, ptr %t2977, i64 %t2978)
  %t2991 = getelementptr i8, ptr %t2990, i64 %t2978
  call void @olang_textcopy(ptr %t2991, ptr %t2980, i64 %t2981)
  %t2992 = insertvalue { i64, ptr } undef, i64 %t2982, 0
  %t2993 = insertvalue { i64, ptr } %t2992, ptr %t2983, 1
  %t2995 = extractvalue { i64, ptr } %t2993, 0
  %t2996 = extractvalue { i64, ptr } %t2993, 1
  %t2997 = mul i64 %t2995, 1
  %t2998 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t2997)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2998, ptr %t2996, i64 %t2997, i1 false)
  %t2999 = insertvalue { i64, ptr } undef, i64 %t2995, 0
  %t3000 = insertvalue { i64, ptr } %t2999, ptr %t2998, 1
  %t3001 = load ptr, ptr %l771, !tbaa !29
  %t3003 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t3001, { i64, ptr } %t3000)
  store { i64, ptr } %t3003, ptr %l785
  br label %bb419
bb419:
  call void @__olang_scope_close(ptr %s105)
  call void @__olang_scope_close(ptr %s0)
  %t3004 = load { i64, ptr }, ptr %l785, !tbaa !27
  store { i64, ptr } %t3004, ptr %rv
  br label %ret
bb420:
  %t3005 = load i32, ptr %l1
  %t3007 = trunc i64 28 to i32
  %t3008 = icmp eq i32 %t3005, %t3007
  br i1 %t3008, label %bb421, label %bb422
bb421:
  br label %bb423
bb422:
  br label %bb432
bb423:
  store %olang.scope zeroinitializer, ptr %s107
  %t3010 = load ptr, ptr %l4, !tbaa !29
  %t3011 = load i32, ptr %l7, !tbaa !23
  %t3014 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t3010, i32 %t3011)
  store i32 %t3014, ptr %l790
  br label %bb424
bb424:
  %t3015 = load i32, ptr %l790, !tbaa !23
  store i32 %t3015, ptr %l50, !tbaa !23
  %t3016 = load ptr, ptr %l0, !tbaa !29
  %t3017 = load i32, ptr %l50, !tbaa !23
  %t3020 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s107, ptr %t3016, i32 %t3017)
  store { i64, ptr } %t3020, ptr %l793
  br label %bb425
bb425:
  %t3021 = load { i64, ptr }, ptr %l793, !tbaa !27
  store { i64, ptr } %t3021, ptr %l51, !tbaa !27
  %t3022 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3022, ptr %l794, !tbaa !29
  %t3023 = load ptr, ptr %lp11
  %t3024 = load { i64, ptr }, ptr %t3023, !tbaa !27
  store { i64, ptr } %t3024, ptr %l795, !tbaa !27
  %t3025 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t3025, ptr %l796, !tbaa !27
  %t3026 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3026, ptr %l797, !tbaa !29
  %t3027 = load ptr, ptr %l0, !tbaa !29
  %t3028 = load %"compiler/mir:Range", ptr %l3
  %t3031 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t3027, %"compiler/mir:Range" %t3028, i64 1)
  store { i64, [4 x i64] } %t3031, ptr %l800
  br label %bb426
bb426:
  %t3032 = load i32, ptr %l50, !tbaa !23
  %t3033 = load ptr, ptr %l797, !tbaa !29
  %t3034 = load { i64, [4 x i64] }, ptr %l800
  %t3036 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s107, ptr %t3033, { i64, [4 x i64] } %t3034, i32 %t3032)
  store { i64, ptr } %t3036, ptr %l802
  br label %bb427
bb427:
  %t3037 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t3037, ptr %l803, !tbaa !27
  %t3038 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3038, ptr %l804, !tbaa !29
  %t3039 = load ptr, ptr %l0, !tbaa !29
  %t3040 = load %"compiler/mir:Range", ptr %l3
  %t3043 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t3039, %"compiler/mir:Range" %t3040, i64 2)
  store { i64, [4 x i64] } %t3043, ptr %l807
  br label %bb428
bb428:
  %t3044 = load i32, ptr %l50, !tbaa !23
  %t3045 = load ptr, ptr %l804, !tbaa !29
  %t3046 = load { i64, [4 x i64] }, ptr %l807
  %t3048 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s107, ptr %t3045, { i64, [4 x i64] } %t3046, i32 %t3044)
  store { i64, ptr } %t3048, ptr %l809
  br label %bb429
bb429:
  %t3049 = extractvalue { i64, ptr } { i64 12, ptr @.d380 }, 1
  %t3050 = extractvalue { i64, ptr } { i64 12, ptr @.d380 }, 0
  %t3051 = load { i64, ptr }, ptr %l795, !tbaa !27
  %t3052 = extractvalue { i64, ptr } %t3051, 1
  %t3053 = extractvalue { i64, ptr } %t3051, 0
  %t3054 = add i64 %t3050, %t3053
  %t3055 = extractvalue { i64, ptr } { i64 2, ptr @.d381 }, 1
  %t3056 = extractvalue { i64, ptr } { i64 2, ptr @.d381 }, 0
  %t3057 = add i64 %t3054, %t3056
  %t3058 = load { i64, ptr }, ptr %l796, !tbaa !27
  %t3059 = extractvalue { i64, ptr } %t3058, 1
  %t3060 = extractvalue { i64, ptr } %t3058, 0
  %t3061 = add i64 %t3057, %t3060
  %t3062 = extractvalue { i64, ptr } { i64 1, ptr @.d382 }, 1
  %t3063 = extractvalue { i64, ptr } { i64 1, ptr @.d382 }, 0
  %t3064 = add i64 %t3061, %t3063
  %t3065 = load { i64, ptr }, ptr %l802, !tbaa !27
  %t3066 = extractvalue { i64, ptr } %t3065, 1
  %t3067 = extractvalue { i64, ptr } %t3065, 0
  %t3068 = add i64 %t3064, %t3067
  %t3069 = extractvalue { i64, ptr } { i64 2, ptr @.d383 }, 1
  %t3070 = extractvalue { i64, ptr } { i64 2, ptr @.d383 }, 0
  %t3071 = add i64 %t3068, %t3070
  %t3072 = load { i64, ptr }, ptr %l803, !tbaa !27
  %t3073 = extractvalue { i64, ptr } %t3072, 1
  %t3074 = extractvalue { i64, ptr } %t3072, 0
  %t3075 = add i64 %t3071, %t3074
  %t3076 = extractvalue { i64, ptr } { i64 1, ptr @.d384 }, 1
  %t3077 = extractvalue { i64, ptr } { i64 1, ptr @.d384 }, 0
  %t3078 = add i64 %t3075, %t3077
  %t3079 = load { i64, ptr }, ptr %l809, !tbaa !27
  %t3080 = extractvalue { i64, ptr } %t3079, 1
  %t3081 = extractvalue { i64, ptr } %t3079, 0
  %t3082 = add i64 %t3078, %t3081
  %t3083 = extractvalue { i64, ptr } { i64 16, ptr @.d385 }, 1
  %t3084 = extractvalue { i64, ptr } { i64 16, ptr @.d385 }, 0
  %t3085 = add i64 %t3082, %t3084
  %t3086 = call ptr @__olang_scope_alloc(ptr %s107, i64 %t3085)
  call void @olang_textcopy(ptr %t3086, ptr %t3049, i64 %t3050)
  %t3087 = getelementptr i8, ptr %t3086, i64 %t3050
  call void @olang_textcopy(ptr %t3087, ptr %t3052, i64 %t3053)
  %t3088 = getelementptr i8, ptr %t3087, i64 %t3053
  call void @olang_textcopy(ptr %t3088, ptr %t3055, i64 %t3056)
  %t3089 = getelementptr i8, ptr %t3088, i64 %t3056
  call void @olang_textcopy(ptr %t3089, ptr %t3059, i64 %t3060)
  %t3090 = getelementptr i8, ptr %t3089, i64 %t3060
  call void @olang_textcopy(ptr %t3090, ptr %t3062, i64 %t3063)
  %t3091 = getelementptr i8, ptr %t3090, i64 %t3063
  call void @olang_textcopy(ptr %t3091, ptr %t3066, i64 %t3067)
  %t3092 = getelementptr i8, ptr %t3091, i64 %t3067
  call void @olang_textcopy(ptr %t3092, ptr %t3069, i64 %t3070)
  %t3093 = getelementptr i8, ptr %t3092, i64 %t3070
  call void @olang_textcopy(ptr %t3093, ptr %t3073, i64 %t3074)
  %t3094 = getelementptr i8, ptr %t3093, i64 %t3074
  call void @olang_textcopy(ptr %t3094, ptr %t3076, i64 %t3077)
  %t3095 = getelementptr i8, ptr %t3094, i64 %t3077
  call void @olang_textcopy(ptr %t3095, ptr %t3080, i64 %t3081)
  %t3096 = getelementptr i8, ptr %t3095, i64 %t3081
  call void @olang_textcopy(ptr %t3096, ptr %t3083, i64 %t3084)
  %t3097 = insertvalue { i64, ptr } undef, i64 %t3085, 0
  %t3098 = insertvalue { i64, ptr } %t3097, ptr %t3086, 1
  %t3100 = extractvalue { i64, ptr } %t3098, 0
  %t3101 = extractvalue { i64, ptr } %t3098, 1
  %t3102 = mul i64 %t3100, 1
  %t3103 = call ptr @__olang_scope_alloc(ptr %s107, i64 %t3102)
  call void @llvm.memcpy.p0.p0.i64(ptr %t3103, ptr %t3101, i64 %t3102, i1 false)
  %t3104 = insertvalue { i64, ptr } undef, i64 %t3100, 0
  %t3105 = insertvalue { i64, ptr } %t3104, ptr %t3103, 1
  %t3106 = load ptr, ptr %l794, !tbaa !29
  %t3108 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s107, ptr %s107, ptr %t3106, { i64, ptr } %t3105)
  store { i64, ptr } %t3108, ptr %l812
  br label %bb430
bb430:
  %t3109 = load { i64, ptr }, ptr %l812, !tbaa !27
  %t3110 = load ptr, ptr %l0, !tbaa !29
  %t3111 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t3113 = extractvalue { i64, ptr } { i64 15, ptr @.d386 }, 1
  %t3114 = extractvalue { i64, ptr } { i64 15, ptr @.d386 }, 0
  %t3116 = extractvalue { i64, ptr } %t3111, 1
  %t3117 = extractvalue { i64, ptr } %t3111, 0
  %t3118 = add i64 %t3114, %t3117
  %t3119 = extractvalue { i64, ptr } { i64 7, ptr @.d387 }, 1
  %t3120 = extractvalue { i64, ptr } { i64 7, ptr @.d387 }, 0
  %t3121 = add i64 %t3118, %t3120
  %t3123 = extractvalue { i64, ptr } %t3109, 1
  %t3124 = extractvalue { i64, ptr } %t3109, 0
  %t3125 = add i64 %t3121, %t3124
  %t3126 = extractvalue { i64, ptr } { i64 3, ptr @.d388 }, 1
  %t3127 = extractvalue { i64, ptr } { i64 3, ptr @.d388 }, 0
  %t3128 = add i64 %t3125, %t3127
  %t3129 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t3128)
  call void @olang_textcopy(ptr %t3129, ptr %t3113, i64 %t3114)
  %t3130 = getelementptr i8, ptr %t3129, i64 %t3114
  call void @olang_textcopy(ptr %t3130, ptr %t3116, i64 %t3117)
  %t3131 = getelementptr i8, ptr %t3130, i64 %t3117
  call void @olang_textcopy(ptr %t3131, ptr %t3119, i64 %t3120)
  %t3132 = getelementptr i8, ptr %t3131, i64 %t3120
  call void @olang_textcopy(ptr %t3132, ptr %t3123, i64 %t3124)
  %t3133 = getelementptr i8, ptr %t3132, i64 %t3124
  call void @olang_textcopy(ptr %t3133, ptr %t3126, i64 %t3127)
  %t3134 = insertvalue { i64, ptr } undef, i64 %t3128, 0
  %t3135 = insertvalue { i64, ptr } %t3134, ptr %t3129, 1
  %t3137 = extractvalue { i64, ptr } %t3135, 0
  %t3138 = extractvalue { i64, ptr } %t3135, 1
  %t3139 = mul i64 %t3137, 1
  %t3140 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t3139)
  call void @llvm.memcpy.p0.p0.i64(ptr %t3140, ptr %t3138, i64 %t3139, i1 false)
  %t3141 = insertvalue { i64, ptr } undef, i64 %t3137, 0
  %t3142 = insertvalue { i64, ptr } %t3141, ptr %t3140, 1
  %t3145 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t3110, { i64, ptr } %t3142)
  store { i64, ptr } %t3145, ptr %l818
  br label %bb431
bb431:
  call void @__olang_scope_close(ptr %s107)
  call void @__olang_scope_close(ptr %s0)
  %t3146 = load { i64, ptr }, ptr %l818, !tbaa !27
  store { i64, ptr } %t3146, ptr %rv
  br label %ret
bb432:
  br i1 true, label %bb433, label %bb434
bb433:
  br label %bb435
bb434:
  br label %bb438
bb435:
  store %olang.scope zeroinitializer, ptr %s110
  %t3147 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3147, ptr %l819, !tbaa !29
  %t3148 = load i32, ptr %l1
  store i32 %t3148, ptr %l820
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s111
  store ptr %s111room, ptr %s111
  %t3149 = extractvalue { i64, ptr } { i64 14, ptr @.d389 }, 1
  %t3150 = extractvalue { i64, ptr } { i64 14, ptr @.d389 }, 0
  call void @__olang_sb_put(ptr %s111, ptr %t3149, i64 %t3150)
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s111, ptr %l820, i64 0)
  br label %bb436
bb436:
  %t3152 = load ptr, ptr %s111
  %t3153 = getelementptr %olang.builder, ptr %s111, i32 0, i32 1
  %t3154 = load i64, ptr %t3153
  %t3155 = call ptr @__olang_scope_alloc(ptr %s110, i64 %t3154)
  call void @olang_textcopy(ptr %t3155, ptr %t3152, i64 %t3154)
  %t3156 = insertvalue { i64, ptr } undef, i64 %t3154, 0
  %t3157 = insertvalue { i64, ptr } %t3156, ptr %t3155, 1
  store { i64, ptr } %t3157, ptr %l822, !tbaa !27
  %t3158 = getelementptr %olang.builder, ptr %s111, i32 0, i32 3
  %t3159 = load ptr, ptr %t3158
  %t3160 = icmp ne ptr %t3159, null
  br i1 %t3160, label %sbgrew.3161, label %sbdone.3162
sbgrew.3161:
  call void @__olang_sb_done(ptr %s111)
  br label %sbdone.3162
sbdone.3162:
  %t3163 = load { i64, ptr }, ptr %l822, !tbaa !27
  %t3164 = extractvalue { i64, ptr } %t3163, 0
  %t3165 = extractvalue { i64, ptr } %t3163, 1
  %t3166 = mul i64 %t3164, 1
  %t3167 = call ptr @__olang_scope_alloc(ptr %s110, i64 %t3166)
  call void @llvm.memcpy.p0.p0.i64(ptr %t3167, ptr %t3165, i64 %t3166, i1 false)
  %t3168 = insertvalue { i64, ptr } undef, i64 %t3164, 0
  %t3169 = insertvalue { i64, ptr } %t3168, ptr %t3167, 1
  %t3170 = load ptr, ptr %l819, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s110, ptr %t3170, { i64, ptr } %t3169)
  br label %bb437
bb437:
  store { i64, ptr } { i64 5, ptr @.d390 }, ptr %l824, !tbaa !27
  %t3172 = load { i64, ptr }, ptr %l824, !tbaa !27
  store { i64, ptr } %t3172, ptr %l825, !tbaa !27
  %t3173 = load { i64, ptr }, ptr %l825, !tbaa !27
  %t3174 = extractvalue { i64, ptr } %t3173, 0
  store i64 %t3174, ptr %l826, !tbaa !24
  %t3175 = load i64, ptr %l826, !tbaa !24
  %t3176 = mul i64 %t3175, 1
  %t3177 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t3176)
  %t3178 = insertvalue { i64, ptr } undef, i64 %t3175, 0
  %t3179 = insertvalue { i64, ptr } %t3178, ptr %t3177, 1
  store { i64, ptr } %t3179, ptr %l827, !tbaa !27
  %t3180 = getelementptr { i64, ptr }, ptr %l827, i32 0, i32 1
  %t3181 = load ptr, ptr %t3180, !tbaa !27
  %t3182 = getelementptr { i64, ptr }, ptr %l825, i32 0, i32 1
  %t3183 = load ptr, ptr %t3182, !tbaa !27
  %t3184 = load i64, ptr %l826, !tbaa !24
  %t3185 = mul i64 %t3184, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t3181, ptr %t3183, i64 %t3185, i1 false)
  %t3186 = load { i64, ptr }, ptr %l827, !tbaa !27
  store { i64, ptr } %t3186, ptr %l825, !tbaa !27
  call void @__olang_scope_close(ptr %s110)
  call void @__olang_scope_close(ptr %s0)
  %t3187 = load { i64, ptr }, ptr %l825, !tbaa !27
  store { i64, ptr } %t3187, ptr %rv
  br label %ret
bb438:
  call void @__olang_check_failed(ptr @olang_loc_48fb755842b89882_1da88e591314daf6)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2equoted(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s0, ptr %t4, { i64, ptr } { i64 16, ptr @.d391 })
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/emit:fnEm", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s0, ptr %t9, { i64, ptr } { i64 15, ptr @.d392 })
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/emit:fnEm", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s0, ptr %t14, { i64, ptr } { i64 14, ptr @.d393 })
  br label %bb3
bb3:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t19 = load i64, ptr %l4, !tbaa !24
  %t20 = extractvalue { i64, ptr } { i64 48, ptr @.d394 }, 1
  %t21 = extractvalue { i64, ptr } { i64 48, ptr @.d394 }, 0
  %t23 = extractvalue { i64, ptr } %t17, 1
  %t24 = extractvalue { i64, ptr } %t17, 0
  %t25 = add i64 %t21, %t24
  %t26 = extractvalue { i64, ptr } { i64 6, ptr @.d395 }, 1
  %t27 = extractvalue { i64, ptr } { i64 6, ptr @.d395 }, 0
  %t28 = add i64 %t25, %t27
  %t30 = extractvalue { i64, ptr } %t18, 1
  %t31 = extractvalue { i64, ptr } %t18, 0
  %t32 = add i64 %t28, %t31
  %t33 = extractvalue { i64, ptr } { i64 5, ptr @.d396 }, 1
  %t34 = extractvalue { i64, ptr } { i64 5, ptr @.d396 }, 0
  %t35 = add i64 %t32, %t34
  %t37 = call i64 @__olang_fmt_i64(ptr null, i64 %t19)
  %t38 = add i64 %t35, %t37
  %t39 = extractvalue { i64, ptr } { i64 1, ptr @.d397 }, 1
  %t40 = extractvalue { i64, ptr } { i64 1, ptr @.d397 }, 0
  %t41 = add i64 %t38, %t40
  %t42 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t41)
  call void @olang_textcopy(ptr %t42, ptr %t20, i64 %t21)
  %t43 = getelementptr i8, ptr %t42, i64 %t21
  call void @olang_textcopy(ptr %t43, ptr %t23, i64 %t24)
  %t44 = getelementptr i8, ptr %t43, i64 %t24
  call void @olang_textcopy(ptr %t44, ptr %t26, i64 %t27)
  %t45 = getelementptr i8, ptr %t44, i64 %t27
  call void @olang_textcopy(ptr %t45, ptr %t30, i64 %t31)
  %t46 = getelementptr i8, ptr %t45, i64 %t31
  call void @olang_textcopy(ptr %t46, ptr %t33, i64 %t34)
  %t47 = getelementptr i8, ptr %t46, i64 %t34
  %t48 = call i64 @__olang_fmt_i64(ptr %t47, i64 %t19)
  %t49 = getelementptr i8, ptr %t47, i64 %t37
  call void @olang_textcopy(ptr %t49, ptr %t39, i64 %t40)
  %t50 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t42, 1
  %t53 = extractvalue { i64, ptr } %t51, 0
  %t54 = extractvalue { i64, ptr } %t51, 1
  %t55 = mul i64 %t53, 1
  %t56 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t55)
  call void @llvm.memcpy.p0.p0.i64(ptr %t56, ptr %t54, i64 %t55, i1 false)
  %t57 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  %t61 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t16, { i64, ptr } %t58)
  store { i64, ptr } %t61, ptr %l19
  br label %bb4
bb4:
  %t62 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t62, ptr %l5, !tbaa !27
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t66 = extractvalue { i64, ptr } { i64 30, ptr @.d398 }, 1
  %t67 = extractvalue { i64, ptr } { i64 30, ptr @.d398 }, 0
  %t69 = extractvalue { i64, ptr } %t64, 1
  %t70 = extractvalue { i64, ptr } %t64, 0
  %t71 = add i64 %t67, %t70
  %t72 = extractvalue { i64, ptr } { i64 6, ptr @.d399 }, 1
  %t73 = extractvalue { i64, ptr } { i64 6, ptr @.d399 }, 0
  %t74 = add i64 %t71, %t73
  %t76 = extractvalue { i64, ptr } %t65, 1
  %t77 = extractvalue { i64, ptr } %t65, 0
  %t78 = add i64 %t74, %t77
  %t79 = extractvalue { i64, ptr } { i64 1, ptr @.d400 }, 1
  %t80 = extractvalue { i64, ptr } { i64 1, ptr @.d400 }, 0
  %t81 = add i64 %t78, %t80
  %t82 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t81)
  call void @olang_textcopy(ptr %t82, ptr %t66, i64 %t67)
  %t83 = getelementptr i8, ptr %t82, i64 %t67
  call void @olang_textcopy(ptr %t83, ptr %t69, i64 %t70)
  %t84 = getelementptr i8, ptr %t83, i64 %t70
  call void @olang_textcopy(ptr %t84, ptr %t72, i64 %t73)
  %t85 = getelementptr i8, ptr %t84, i64 %t73
  call void @olang_textcopy(ptr %t85, ptr %t76, i64 %t77)
  %t86 = getelementptr i8, ptr %t85, i64 %t77
  call void @olang_textcopy(ptr %t86, ptr %t79, i64 %t80)
  %t87 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t82, 1
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t91 = extractvalue { i64, ptr } %t88, 1
  %t92 = mul i64 %t90, 1
  %t93 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t92)
  call void @llvm.memcpy.p0.p0.i64(ptr %t93, ptr %t91, i64 %t92, i1 false)
  %t94 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t93, 1
  %t98 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t63, { i64, ptr } %t95)
  store { i64, ptr } %t98, ptr %l25
  br label %bb5
bb5:
  %t99 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t104 = load i64, ptr %l4, !tbaa !24
  %t105 = extractvalue { i64, ptr } { i64 31, ptr @.d401 }, 1
  %t106 = extractvalue { i64, ptr } { i64 31, ptr @.d401 }, 0
  %t108 = extractvalue { i64, ptr } %t99, 1
  %t109 = extractvalue { i64, ptr } %t99, 0
  %t110 = add i64 %t106, %t109
  %t111 = extractvalue { i64, ptr } { i64 13, ptr @.d402 }, 1
  %t112 = extractvalue { i64, ptr } { i64 13, ptr @.d402 }, 0
  %t113 = add i64 %t110, %t112
  %t115 = extractvalue { i64, ptr } %t102, 1
  %t116 = extractvalue { i64, ptr } %t102, 0
  %t117 = add i64 %t113, %t116
  %t118 = extractvalue { i64, ptr } { i64 6, ptr @.d403 }, 1
  %t119 = extractvalue { i64, ptr } { i64 6, ptr @.d403 }, 0
  %t120 = add i64 %t117, %t119
  %t122 = extractvalue { i64, ptr } %t103, 1
  %t123 = extractvalue { i64, ptr } %t103, 0
  %t124 = add i64 %t120, %t123
  %t125 = extractvalue { i64, ptr } { i64 5, ptr @.d404 }, 1
  %t126 = extractvalue { i64, ptr } { i64 5, ptr @.d404 }, 0
  %t127 = add i64 %t124, %t126
  %t129 = call i64 @__olang_fmt_i64(ptr null, i64 %t104)
  %t130 = add i64 %t127, %t129
  %t131 = extractvalue { i64, ptr } { i64 1, ptr @.d405 }, 1
  %t132 = extractvalue { i64, ptr } { i64 1, ptr @.d405 }, 0
  %t133 = add i64 %t130, %t132
  %t134 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t133)
  call void @olang_textcopy(ptr %t134, ptr %t105, i64 %t106)
  %t135 = getelementptr i8, ptr %t134, i64 %t106
  call void @olang_textcopy(ptr %t135, ptr %t108, i64 %t109)
  %t136 = getelementptr i8, ptr %t135, i64 %t109
  call void @olang_textcopy(ptr %t136, ptr %t111, i64 %t112)
  %t137 = getelementptr i8, ptr %t136, i64 %t112
  call void @olang_textcopy(ptr %t137, ptr %t115, i64 %t116)
  %t138 = getelementptr i8, ptr %t137, i64 %t116
  call void @olang_textcopy(ptr %t138, ptr %t118, i64 %t119)
  %t139 = getelementptr i8, ptr %t138, i64 %t119
  call void @olang_textcopy(ptr %t139, ptr %t122, i64 %t123)
  %t140 = getelementptr i8, ptr %t139, i64 %t123
  call void @olang_textcopy(ptr %t140, ptr %t125, i64 %t126)
  %t141 = getelementptr i8, ptr %t140, i64 %t126
  %t142 = call i64 @__olang_fmt_i64(ptr %t141, i64 %t104)
  %t143 = getelementptr i8, ptr %t141, i64 %t129
  call void @olang_textcopy(ptr %t143, ptr %t131, i64 %t132)
  %t144 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t134, 1
  %t147 = extractvalue { i64, ptr } %t145, 0
  %t148 = extractvalue { i64, ptr } %t145, 1
  %t149 = mul i64 %t147, 1
  %t150 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t149)
  call void @llvm.memcpy.p0.p0.i64(ptr %t150, ptr %t148, i64 %t149, i1 false)
  %t151 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t150, 1
  %t155 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t100, { i64, ptr } %t152)
  store { i64, ptr } %t155, ptr %l33
  br label %bb6
bb6:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t158 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t159 = extractvalue { i64, ptr } { i64 30, ptr @.d406 }, 1
  %t160 = extractvalue { i64, ptr } { i64 30, ptr @.d406 }, 0
  %t162 = extractvalue { i64, ptr } %t157, 1
  %t163 = extractvalue { i64, ptr } %t157, 0
  %t164 = add i64 %t160, %t163
  %t165 = extractvalue { i64, ptr } { i64 6, ptr @.d407 }, 1
  %t166 = extractvalue { i64, ptr } { i64 6, ptr @.d407 }, 0
  %t167 = add i64 %t164, %t166
  %t169 = extractvalue { i64, ptr } %t158, 1
  %t170 = extractvalue { i64, ptr } %t158, 0
  %t171 = add i64 %t167, %t170
  %t172 = extractvalue { i64, ptr } { i64 1, ptr @.d408 }, 1
  %t173 = extractvalue { i64, ptr } { i64 1, ptr @.d408 }, 0
  %t174 = add i64 %t171, %t173
  %t175 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t174)
  call void @olang_textcopy(ptr %t175, ptr %t159, i64 %t160)
  %t176 = getelementptr i8, ptr %t175, i64 %t160
  call void @olang_textcopy(ptr %t176, ptr %t162, i64 %t163)
  %t177 = getelementptr i8, ptr %t176, i64 %t163
  call void @olang_textcopy(ptr %t177, ptr %t165, i64 %t166)
  %t178 = getelementptr i8, ptr %t177, i64 %t166
  call void @olang_textcopy(ptr %t178, ptr %t169, i64 %t170)
  %t179 = getelementptr i8, ptr %t178, i64 %t170
  call void @olang_textcopy(ptr %t179, ptr %t172, i64 %t173)
  %t180 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t181 = insertvalue { i64, ptr } %t180, ptr %t175, 1
  %t183 = extractvalue { i64, ptr } %t181, 0
  %t184 = extractvalue { i64, ptr } %t181, 1
  %t185 = mul i64 %t183, 1
  %t186 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t185)
  call void @llvm.memcpy.p0.p0.i64(ptr %t186, ptr %t184, i64 %t185, i1 false)
  %t187 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t186, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t156, { i64, ptr } %t188)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ervalue(ptr %v0, ptr %v1, ptr %a0, { i64, [15 x i64] } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [15 x i64] }
  %l3 = alloca ptr
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca %"compiler/mir:Place"
  %l6 = alloca i32
  %l7 = alloca %"compiler/mir:Place"
  %l8 = alloca { { i64, ptr }, i32 }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %lp11 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca %"compiler/mir:Range"
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca %"compiler/mir:Range"
  %l18 = alloca %"compiler/mir:Place"
  %l19 = alloca { { i64, ptr }, i32 }
  %l20 = alloca { i64, ptr }
  %l22 = alloca i32
  %l23 = alloca i64
  %l24 = alloca %"compiler/mir:Range"
  %l25 = alloca { i64, [1 x i64] }
  %l26 = alloca { i64, [4 x i64] }
  %l27 = alloca i32
  %l28 = alloca i32
  %lp29 = alloca ptr
  %l30 = alloca { i64, ptr }
  %lp31 = alloca ptr
  %l32 = alloca { i64, [1 x i64] }
  %l33 = alloca i32
  %l34 = alloca { i64, [4 x i64] }
  %l35 = alloca { i64, [4 x i64] }
  %l36 = alloca %"compiler/mir:Place"
  %l37 = alloca { i64, [4 x i64] }
  %l38 = alloca { i64, [4 x i64] }
  %l39 = alloca i32
  %l40 = alloca { i64, [2 x i64] }
  %l41 = alloca i32
  %l42 = alloca { i64, [1 x i64] }
  %l43 = alloca %"compiler/mir:Range"
  %l44 = alloca %"compiler/mir:Range"
  %l45 = alloca { i64, [4 x i64] }
  %l46 = alloca i32
  %l47 = alloca i32
  %l48 = alloca { i64, [1 x i64] }
  %l49 = alloca { i64, [1 x i64] }
  %l50 = alloca i32
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l78 = alloca { { i64, ptr }, i32 }
  %l79 = alloca { i64, ptr }
  %l80 = alloca i64
  %l81 = alloca { i64, ptr }
  %l83 = alloca ptr
  %l86 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l90 = alloca ptr
  %l93 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l127 = alloca { { i64, ptr }, i32 }
  %l128 = alloca { i64, ptr }
  %l129 = alloca i64
  %l130 = alloca { i64, ptr }
  %l135 = alloca i1
  %l138 = alloca { i64, ptr }
  %l139 = alloca ptr
  %l142 = alloca { i64, ptr }
  %l145 = alloca { i64, ptr }
  %l155 = alloca { i64, ptr }
  %l161 = alloca ptr
  %l164 = alloca i32
  %l165 = alloca i32
  %l168 = alloca i1
  %l169 = alloca ptr
  %l170 = alloca { i64, [1 x i64] }
  %l173 = alloca i64
  %l175 = alloca { i64, ptr }
  %l178 = alloca i64
  %l181 = alloca { i64, ptr }
  %l183 = alloca { i64, ptr }
  %l192 = alloca { i64, ptr }
  %l195 = alloca i1
  %l200 = alloca { i64, ptr }
  %l201 = alloca ptr
  %l202 = alloca { i64, [1 x i64] }
  %l205 = alloca i64
  %l207 = alloca { i64, ptr }
  %l210 = alloca i64
  %l213 = alloca { i64, ptr }
  %l215 = alloca { i64, ptr }
  %l216 = alloca ptr
  %l219 = alloca { i64, ptr }
  %l235 = alloca { i64, ptr }
  %l247 = alloca { i64, ptr }
  %l261 = alloca { i64, ptr }
  %l267 = alloca ptr
  %l271 = alloca { i64, ptr }
  %l275 = alloca { i64, ptr }
  %l283 = alloca i1
  %l286 = alloca { i64, ptr }
  %l289 = alloca { i64, ptr }
  %l292 = alloca { i64, ptr }
  %l293 = alloca ptr
  %l298 = alloca { i64, ptr }
  %l300 = alloca { i64, ptr }
  %l303 = alloca ptr
  %l306 = alloca { i64, ptr }
  %l310 = alloca { i64, ptr }
  %l322 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [15 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l3, !tbaa !29
  %t9 = load { i64, [15 x i64] }, ptr %l1
  %t11 = extractvalue { i64, [15 x i64] } %t9, 0
  %t12 = icmp eq i64 %t11, 0
  br i1 %t12, label %bb1, label %bb2
bb1:
  %t14 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t15 = getelementptr { { i64, [4 x i64] } }, ptr %t14, i32 0, i32 0
  %t16 = load { i64, [4 x i64] }, ptr %t15
  store { i64, [4 x i64] } %t16, ptr %l4
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load { i64, [4 x i64] }, ptr %l4
  %t24 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %v1, ptr %t18, { i64, [4 x i64] } %t19, i32 %a2)
  store { i64, ptr } %t24, ptr %l64
  br label %bb4
bb4:
  %t25 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t25, ptr %rv
  br label %ret
bb5:
  %t26 = load { i64, [15 x i64] }, ptr %l1
  %t28 = extractvalue { i64, [15 x i64] } %t26, 0
  %t29 = icmp eq i64 %t28, 1
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t31 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t32 = getelementptr { %"compiler/mir:Place", i32 }, ptr %t31, i32 0, i32 0
  %t33 = load %"compiler/mir:Place", ptr %t32
  store %"compiler/mir:Place" %t33, ptr %l5
  %t35 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t36 = getelementptr { %"compiler/mir:Place", i32 }, ptr %t35, i32 0, i32 1
  %t37 = load i32, ptr %t36
  store i32 %t37, ptr %l6, !tbaa !23
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load %"compiler/mir:Place", ptr %l5
  %t41 = load i32, ptr %l6, !tbaa !23
  %t45 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eref(ptr %v0, ptr %v1, ptr %t39, %"compiler/mir:Place" %t40, i32 %t41)
  store { i64, ptr } %t45, ptr %l72
  br label %bb9
bb9:
  %t46 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t46, ptr %rv
  br label %ret
bb10:
  %t47 = load { i64, [15 x i64] }, ptr %l1
  %t49 = extractvalue { i64, [15 x i64] } %t47, 0
  %t50 = icmp eq i64 %t49, 2
  br i1 %t50, label %bb11, label %bb12
bb11:
  %t52 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t53 = getelementptr { %"compiler/mir:Place" }, ptr %t52, i32 0, i32 0
  %t54 = load %"compiler/mir:Place", ptr %t53
  store %"compiler/mir:Place" %t54, ptr %l7
  br label %bb13
bb12:
  br label %bb20
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load %"compiler/mir:Place", ptr %l7
  %t60 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s3, ptr %t56, %"compiler/mir:Place" %t57)
  store { { i64, ptr }, i32 } %t60, ptr %l78
  br label %bb14
bb14:
  %t61 = load { { i64, ptr }, i32 }, ptr %l78
  store { { i64, ptr }, i32 } %t61, ptr %l8
  %t62 = getelementptr { { i64, ptr }, i32 }, ptr %l8, i32 0, i32 0
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  store { i64, ptr } %t63, ptr %l79, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l80, !tbaa !24
  %t66 = load i64, ptr %l80, !tbaa !24
  %t67 = mul i64 %t66, 1
  %t68 = call ptr @__olang_scope_alloc_zeroed(ptr %s3, i64 %t67)
  %t69 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t68, 1
  store { i64, ptr } %t70, ptr %l81, !tbaa !27
  %t71 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = load i64, ptr %l80, !tbaa !24
  %t76 = mul i64 %t75, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t72, ptr %t74, i64 %t76, i1 false)
  %t77 = load { i64, ptr }, ptr %l81, !tbaa !27
  store { i64, ptr } %t77, ptr %l9, !tbaa !27
  %t78 = getelementptr { { i64, ptr }, i32 }, ptr %l8, i32 0, i32 1
  %t79 = load i32, ptr %t78, !tbaa !23
  store i32 %t79, ptr %l10, !tbaa !23
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l83, !tbaa !29
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i32, ptr %l10, !tbaa !23
  %t86 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %v1, ptr %t82, i32 %t83)
  store { i64, ptr } %t86, ptr %l86
  br label %bb15
bb15:
  %t87 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  %t89 = extractvalue { i64, ptr } %t87, 1
  %t90 = mul i64 %t88, 1
  %t91 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t90)
  call void @llvm.memcpy.p0.p0.i64(ptr %t91, ptr %t89, i64 %t90, i1 false)
  %t92 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  %t94 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t95 = load ptr, ptr %l83, !tbaa !29
  %t98 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %v1, ptr %s3, ptr %v1, ptr %v1, ptr %t95, { i64, ptr } %t93, { i64, ptr } %t94, { i64, ptr } { i64 0, ptr @.d409 })
  store { i64, ptr } %t98, ptr %l89
  br label %bb16
bb16:
  %t99 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t99, ptr %lp11
  %t100 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t101 = load ptr, ptr %lp11
  store { i64, ptr } %t100, ptr %t101, !tbaa !27
  %t102 = load ptr, ptr %l0, !tbaa !29
  store ptr %t102, ptr %l90, !tbaa !29
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load i32, ptr %l10, !tbaa !23
  %t107 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s3, ptr %t103, i32 %t104)
  store { i64, ptr } %t107, ptr %l93
  br label %bb17
bb17:
  %t108 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t108, 0
  %t110 = extractvalue { i64, ptr } %t108, 1
  %t111 = mul i64 %t109, 1
  %t112 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t111)
  call void @llvm.memcpy.p0.p0.i64(ptr %t112, ptr %t110, i64 %t111, i1 false)
  %t113 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t112, 1
  store { i64, ptr } %t114, ptr %l94, !tbaa !27
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/emit:fnEm", ptr %t115, i32 0, i32 0
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t119 = load i32, ptr %l10, !tbaa !23
  %t122 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %v0, ptr %s3, ptr %t118, i32 %t119, i64 0)
  store { i64, ptr } %t122, ptr %l98
  br label %bb18
bb18:
  %t123 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  %t125 = extractvalue { i64, ptr } %t123, 1
  %t126 = mul i64 %t124, 1
  %t127 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t126)
  call void @llvm.memcpy.p0.p0.i64(ptr %t127, ptr %t125, i64 %t126, i1 false)
  %t128 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  %t130 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t131 = load ptr, ptr %l90, !tbaa !29
  %t132 = load { i64, ptr }, ptr %l94, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s3, ptr %s3, ptr %s3, ptr %s3, ptr %t131, { i64, ptr } %t132, { i64, ptr } %t129, { i64, ptr } %t130, { i64, ptr } { i64 0, ptr @.d410 })
  br label %bb19
bb19:
  %t135 = load ptr, ptr %lp11
  %t136 = load { i64, ptr }, ptr %t135, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  store { i64, ptr } %t136, ptr %rv
  br label %ret
bb20:
  %t138 = load { i64, [15 x i64] }, ptr %l1
  %t140 = extractvalue { i64, [15 x i64] } %t138, 0
  %t141 = icmp eq i64 %t140, 3
  br i1 %t141, label %bb21, label %bb22
bb21:
  %t143 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t144 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t143, i32 0, i32 0
  %t145 = load i32, ptr %t144
  store i32 %t145, ptr %l12
  %t147 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t148 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t147, i32 0, i32 1
  %t149 = load i32, ptr %t148
  store i32 %t149, ptr %l13, !tbaa !23
  %t151 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t152 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t151, i32 0, i32 2
  %t153 = load %"compiler/mir:Range", ptr %t152
  store %"compiler/mir:Range" %t153, ptr %l14
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load i32, ptr %l12
  %t157 = load i32, ptr %l13, !tbaa !23
  %t158 = load %"compiler/mir:Range", ptr %l14
  %t163 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eprim(ptr %v0, ptr %v1, ptr %t155, i32 %t156, i32 %t157, %"compiler/mir:Range" %t158)
  store { i64, ptr } %t163, ptr %l111
  br label %bb24
bb24:
  %t164 = load { i64, ptr }, ptr %l111, !tbaa !27
  store { i64, ptr } %t164, ptr %rv
  br label %ret
bb25:
  %t165 = load { i64, [15 x i64] }, ptr %l1
  %t167 = extractvalue { i64, [15 x i64] } %t165, 0
  %t168 = icmp eq i64 %t167, 4
  br i1 %t168, label %bb26, label %bb27
bb26:
  %t170 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t171 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t170, i32 0, i32 0
  %t172 = load i32, ptr %t171
  store i32 %t172, ptr %l15
  %t174 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t175 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t174, i32 0, i32 1
  %t176 = load i32, ptr %t175
  store i32 %t176, ptr %l16, !tbaa !23
  %t178 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t179 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t178, i32 0, i32 2
  %t180 = load %"compiler/mir:Range", ptr %t179
  store %"compiler/mir:Range" %t180, ptr %l17
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load i32, ptr %l15
  %t184 = load i32, ptr %l16, !tbaa !23
  %t185 = load %"compiler/mir:Range", ptr %l17
  %t190 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eoverflows(ptr %v0, ptr %v1, ptr %t182, i32 %t183, i32 %t184, %"compiler/mir:Range" %t185)
  store { i64, ptr } %t190, ptr %l121
  br label %bb29
bb29:
  %t191 = load { i64, ptr }, ptr %l121, !tbaa !27
  store { i64, ptr } %t191, ptr %rv
  br label %ret
bb30:
  %t192 = load { i64, [15 x i64] }, ptr %l1
  %t194 = extractvalue { i64, [15 x i64] } %t192, 0
  %t195 = icmp eq i64 %t194, 5
  br i1 %t195, label %bb31, label %bb32
bb31:
  %t197 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t198 = getelementptr { %"compiler/mir:Place" }, ptr %t197, i32 0, i32 0
  %t199 = load %"compiler/mir:Place", ptr %t198
  store %"compiler/mir:Place" %t199, ptr %l18
  br label %bb33
bb32:
  br label %bb42
bb33:
  store %olang.scope zeroinitializer, ptr %s6
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load %"compiler/mir:Place", ptr %l18
  %t205 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s6, ptr %t201, %"compiler/mir:Place" %t202)
  store { { i64, ptr }, i32 } %t205, ptr %l127
  br label %bb34
bb34:
  %t206 = load { { i64, ptr }, i32 }, ptr %l127
  store { { i64, ptr }, i32 } %t206, ptr %l19
  %t207 = getelementptr { { i64, ptr }, i32 }, ptr %l19, i32 0, i32 0
  %t208 = load { i64, ptr }, ptr %t207, !tbaa !27
  store { i64, ptr } %t208, ptr %l128, !tbaa !27
  %t209 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t210 = extractvalue { i64, ptr } %t209, 0
  store i64 %t210, ptr %l129, !tbaa !24
  %t211 = load i64, ptr %l129, !tbaa !24
  %t212 = mul i64 %t211, 1
  %t213 = call ptr @__olang_scope_alloc_zeroed(ptr %s6, i64 %t212)
  %t214 = insertvalue { i64, ptr } undef, i64 %t211, 0
  %t215 = insertvalue { i64, ptr } %t214, ptr %t213, 1
  store { i64, ptr } %t215, ptr %l130, !tbaa !27
  %t216 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !27
  %t220 = load i64, ptr %l129, !tbaa !24
  %t221 = mul i64 %t220, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t217, ptr %t219, i64 %t221, i1 false)
  %t222 = load { i64, ptr }, ptr %l130, !tbaa !27
  store { i64, ptr } %t222, ptr %l20, !tbaa !27
  %t223 = getelementptr { { i64, ptr }, i32 }, ptr %l19, i32 0, i32 1
  %t224 = load i32, ptr %t223, !tbaa !23
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/emit:fnEm", ptr %t226, i32 0, i32 0
  %t229 = load ptr, ptr %t228, !tbaa !29
  %t233 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eenumWords(ptr %v0, ptr %t229, i32 %t224)
  store i1 %t233, ptr %l135
  br label %bb35
bb35:
  %t234 = load i1, ptr %l135, !tbaa !21
  br i1 %t234, label %bb36, label %bb37
bb36:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t239 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %v1, ptr %s6, ptr %v1, ptr %v1, ptr %t235, { i64, ptr } { i64 3, ptr @.d411 }, { i64, ptr } %t236, { i64, ptr } { i64 0, ptr @.d412 })
  store { i64, ptr } %t239, ptr %l138
  br label %bb38
bb37:
  br label %bb39
bb38:
  call void @__olang_scope_close(ptr %s6)
  %t240 = load { i64, ptr }, ptr %l138, !tbaa !27
  store { i64, ptr } %t240, ptr %rv
  br label %ret
bb39:
  %t241 = load ptr, ptr %l0, !tbaa !29
  store ptr %t241, ptr %l139, !tbaa !29
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t246 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s6, ptr %s6, ptr %s6, ptr %s6, ptr %t242, { i64, ptr } { i64 3, ptr @.d413 }, { i64, ptr } %t243, { i64, ptr } { i64 0, ptr @.d414 })
  store { i64, ptr } %t246, ptr %l142
  br label %bb40
bb40:
  %t247 = extractvalue { i64, ptr } { i64 9, ptr @.d415 }, 1
  %t248 = extractvalue { i64, ptr } { i64 9, ptr @.d415 }, 0
  %t249 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t250 = extractvalue { i64, ptr } %t249, 1
  %t251 = extractvalue { i64, ptr } %t249, 0
  %t252 = add i64 %t248, %t251
  %t253 = extractvalue { i64, ptr } { i64 7, ptr @.d416 }, 1
  %t254 = extractvalue { i64, ptr } { i64 7, ptr @.d416 }, 0
  %t255 = add i64 %t252, %t254
  %t256 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t255)
  call void @olang_textcopy(ptr %t256, ptr %t247, i64 %t248)
  %t257 = getelementptr i8, ptr %t256, i64 %t248
  call void @olang_textcopy(ptr %t257, ptr %t250, i64 %t251)
  %t258 = getelementptr i8, ptr %t257, i64 %t251
  call void @olang_textcopy(ptr %t258, ptr %t253, i64 %t254)
  %t259 = insertvalue { i64, ptr } undef, i64 %t255, 0
  %t260 = insertvalue { i64, ptr } %t259, ptr %t256, 1
  %t262 = extractvalue { i64, ptr } %t260, 0
  %t263 = extractvalue { i64, ptr } %t260, 1
  %t264 = mul i64 %t262, 1
  %t265 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t264)
  call void @llvm.memcpy.p0.p0.i64(ptr %t265, ptr %t263, i64 %t264, i1 false)
  %t266 = insertvalue { i64, ptr } undef, i64 %t262, 0
  %t267 = insertvalue { i64, ptr } %t266, ptr %t265, 1
  %t268 = load ptr, ptr %l139, !tbaa !29
  %t270 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t268, { i64, ptr } %t267)
  store { i64, ptr } %t270, ptr %l145
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s6)
  %t271 = load { i64, ptr }, ptr %l145, !tbaa !27
  store { i64, ptr } %t271, ptr %rv
  br label %ret
bb42:
  %t272 = load { i64, [15 x i64] }, ptr %l1
  %t274 = extractvalue { i64, [15 x i64] } %t272, 0
  %t275 = icmp eq i64 %t274, 6
  br i1 %t275, label %bb43, label %bb44
bb43:
  %t277 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t278 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t277, i32 0, i32 0
  %t279 = load i32, ptr %t278
  store i32 %t279, ptr %l22, !tbaa !23
  %t281 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t282 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t281, i32 0, i32 1
  %t283 = load i64, ptr %t282
  store i64 %t283, ptr %l23, !tbaa !24
  %t285 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t286 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t285, i32 0, i32 2
  %t287 = load %"compiler/mir:Range", ptr %t286
  store %"compiler/mir:Range" %t287, ptr %l24
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t290 = load i32, ptr %l22, !tbaa !23
  %t291 = load i64, ptr %l23, !tbaa !24
  %t292 = load %"compiler/mir:Range", ptr %l24
  %t297 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaggregate(ptr %v0, ptr %v1, ptr %t289, i32 %t290, i64 %t291, %"compiler/mir:Range" %t292)
  store { i64, ptr } %t297, ptr %l155
  br label %bb46
bb46:
  %t298 = load { i64, ptr }, ptr %l155, !tbaa !27
  store { i64, ptr } %t298, ptr %rv
  br label %ret
bb47:
  %t299 = load { i64, [15 x i64] }, ptr %l1
  %t301 = extractvalue { i64, [15 x i64] } %t299, 0
  %t302 = icmp eq i64 %t301, 7
  br i1 %t302, label %bb48, label %bb49
bb48:
  %t304 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t305 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t304, i32 0, i32 0
  %t306 = load { i64, [1 x i64] }, ptr %t305
  store { i64, [1 x i64] } %t306, ptr %l25
  %t308 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t309 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t308, i32 0, i32 1
  %t310 = load { i64, [4 x i64] }, ptr %t309
  store { i64, [4 x i64] } %t310, ptr %l26
  %t312 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t313 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t312, i32 0, i32 2
  %t314 = load i32, ptr %t313
  store i32 %t314, ptr %l27, !tbaa !23
  br label %bb50
bb49:
  br label %bb74
bb50:
  store %olang.scope zeroinitializer, ptr %s10
  %t316 = load ptr, ptr %l3, !tbaa !29
  store ptr %t316, ptr %l161, !tbaa !29
  %t317 = load ptr, ptr %l3, !tbaa !29
  %t318 = load i32, ptr %l27, !tbaa !23
  %t321 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t317, i32 %t318)
  store i32 %t321, ptr %l164
  br label %bb51
bb51:
  %t322 = load ptr, ptr %l161, !tbaa !29
  %t323 = load i32, ptr %l164, !tbaa !23
  %t324 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t322, i32 %t323)
  store i32 %t324, ptr %l165
  br label %bb52
bb52:
  %t325 = load i32, ptr %l165, !tbaa !23
  store i32 %t325, ptr %l28, !tbaa !23
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t327 = load i32, ptr %l28, !tbaa !23
  %t330 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eviaMem(ptr %v0, ptr %t326, i32 %t327)
  store i1 %t330, ptr %l168
  br label %bb53
bb53:
  %t331 = load i1, ptr %l168, !tbaa !21
  br i1 %t331, label %bb54, label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s11
  %t332 = load ptr, ptr %l0, !tbaa !29
  store ptr %t332, ptr %l169, !tbaa !29
  %t333 = load { i64, [1 x i64] }, ptr %l25
  store { i64, [1 x i64] } %t333, ptr %l170
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t335 = load i32, ptr %l28, !tbaa !23
  %t338 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t334, i32 %t335)
  store i64 %t338, ptr %l173
  br label %bb56
bb55:
  br label %bb61
bb56:
  %t339 = load i64, ptr %l173, !tbaa !24
  %t340 = call i64 @__olang_fmt_i64(ptr null, i64 %t339)
  %t341 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t340)
  %t342 = call i64 @__olang_fmt_i64(ptr %t341, i64 %t339)
  %t343 = insertvalue { i64, ptr } undef, i64 %t340, 0
  %t344 = insertvalue { i64, ptr } %t343, ptr %t341, 1
  %t346 = extractvalue { i64, ptr } %t344, 0
  %t347 = extractvalue { i64, ptr } %t344, 1
  %t348 = mul i64 %t346, 1
  %t349 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t348)
  call void @llvm.memcpy.p0.p0.i64(ptr %t349, ptr %t347, i64 %t348, i1 false)
  %t350 = insertvalue { i64, ptr } undef, i64 %t346, 0
  %t351 = insertvalue { i64, ptr } %t350, ptr %t349, 1
  store { i64, ptr } %t351, ptr %l175, !tbaa !27
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t353 = load i32, ptr %l28, !tbaa !23
  %t356 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ealign(ptr %v0, ptr %t352, i32 %t353)
  store i64 %t356, ptr %l178
  br label %bb57
bb57:
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t358 = load i32, ptr %l28, !tbaa !23
  %t361 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %v1, ptr %t357, i32 %t358)
  store { i64, ptr } %t361, ptr %l181
  br label %bb58
bb58:
  %t362 = load { i64, ptr }, ptr %l181, !tbaa !27
  %t363 = extractvalue { i64, ptr } %t362, 0
  %t364 = extractvalue { i64, ptr } %t362, 1
  %t365 = mul i64 %t363, 1
  %t366 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t365)
  call void @llvm.memcpy.p0.p0.i64(ptr %t366, ptr %t364, i64 %t365, i1 false)
  %t367 = insertvalue { i64, ptr } undef, i64 %t363, 0
  %t368 = insertvalue { i64, ptr } %t367, ptr %t366, 1
  %t369 = load ptr, ptr %l169, !tbaa !29
  %t370 = load { i64, [1 x i64] }, ptr %l170
  %t371 = load { i64, ptr }, ptr %l175, !tbaa !27
  %t372 = load i64, ptr %l178, !tbaa !24
  %t374 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloc(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %t369, { i64, [1 x i64] } %t370, { i64, ptr } %t371, i64 %t372, { i64, ptr } %t368)
  store { i64, ptr } %t374, ptr %l183
  br label %bb59
bb59:
  %t375 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t375, ptr %lp29
  %t376 = load { i64, ptr }, ptr %l183, !tbaa !27
  %t377 = load ptr, ptr %lp29
  store { i64, ptr } %t376, ptr %t377, !tbaa !27
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t379 = load ptr, ptr %lp29
  %t380 = load { i64, ptr }, ptr %t379, !tbaa !27
  %t381 = load i32, ptr %l28, !tbaa !23
  %t382 = load { i64, [4 x i64] }, ptr %l26
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eput(ptr %v0, ptr %v1, ptr %s11, ptr %t378, { i64, ptr } %t380, i32 %t381, { i64, [4 x i64] } %t382, { i64, ptr } { i64 0, ptr @.d417 })
  br label %bb60
bb60:
  %t387 = load ptr, ptr %lp29
  %t388 = load { i64, ptr }, ptr %t387, !tbaa !27
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s10)
  store { i64, ptr } %t388, ptr %rv
  br label %ret
bb61:
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t391 = load { i64, [4 x i64] }, ptr %l26
  %t392 = load i32, ptr %l28, !tbaa !23
  %t396 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s10, ptr %t390, { i64, [4 x i64] } %t391, i32 %t392)
  store { i64, ptr } %t396, ptr %l192
  br label %bb62
bb62:
  %t397 = load { i64, ptr }, ptr %l192, !tbaa !27
  store { i64, ptr } %t397, ptr %l30, !tbaa !27
  %t398 = load ptr, ptr %l0, !tbaa !29
  %t399 = load i32, ptr %l28, !tbaa !23
  %t402 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erunTime(ptr %v0, ptr %t398, i32 %t399)
  store i1 %t402, ptr %l195
  br label %bb63
bb63:
  %t403 = load i1, ptr %l195, !tbaa !21
  br i1 %t403, label %bb64, label %bb65
bb64:
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t405 = load { i64, [1 x i64] }, ptr %l25
  %t406 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t407 = load i32, ptr %l28, !tbaa !23
  %t412 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ecopyArray(ptr %v0, ptr %s10, ptr %v1, ptr %t404, { i64, [1 x i64] } %t405, { i64, ptr } %t406, i32 %t407)
  store { i64, ptr } %t412, ptr %l200
  br label %bb66
bb65:
  br label %bb67
bb66:
  call void @__olang_scope_close(ptr %s10)
  %t413 = load { i64, ptr }, ptr %l200, !tbaa !27
  store { i64, ptr } %t413, ptr %rv
  br label %ret
bb67:
  %t414 = load ptr, ptr %l0, !tbaa !29
  store ptr %t414, ptr %l201, !tbaa !29
  %t415 = load { i64, [1 x i64] }, ptr %l25
  store { i64, [1 x i64] } %t415, ptr %l202
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t417 = load i32, ptr %l28, !tbaa !23
  %t420 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t416, i32 %t417)
  store i64 %t420, ptr %l205
  br label %bb68
bb68:
  %t421 = load i64, ptr %l205, !tbaa !24
  %t422 = call i64 @__olang_fmt_i64(ptr null, i64 %t421)
  %t423 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t422)
  %t424 = call i64 @__olang_fmt_i64(ptr %t423, i64 %t421)
  %t425 = insertvalue { i64, ptr } undef, i64 %t422, 0
  %t426 = insertvalue { i64, ptr } %t425, ptr %t423, 1
  %t428 = extractvalue { i64, ptr } %t426, 0
  %t429 = extractvalue { i64, ptr } %t426, 1
  %t430 = mul i64 %t428, 1
  %t431 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t430)
  call void @llvm.memcpy.p0.p0.i64(ptr %t431, ptr %t429, i64 %t430, i1 false)
  %t432 = insertvalue { i64, ptr } undef, i64 %t428, 0
  %t433 = insertvalue { i64, ptr } %t432, ptr %t431, 1
  store { i64, ptr } %t433, ptr %l207, !tbaa !27
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t435 = load i32, ptr %l28, !tbaa !23
  %t438 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ealign(ptr %v0, ptr %t434, i32 %t435)
  store i64 %t438, ptr %l210
  br label %bb69
bb69:
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t440 = load i32, ptr %l28, !tbaa !23
  %t443 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %v1, ptr %t439, i32 %t440)
  store { i64, ptr } %t443, ptr %l213
  br label %bb70
bb70:
  %t444 = load { i64, ptr }, ptr %l213, !tbaa !27
  %t445 = extractvalue { i64, ptr } %t444, 0
  %t446 = extractvalue { i64, ptr } %t444, 1
  %t447 = mul i64 %t445, 1
  %t448 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t447)
  call void @llvm.memcpy.p0.p0.i64(ptr %t448, ptr %t446, i64 %t447, i1 false)
  %t449 = insertvalue { i64, ptr } undef, i64 %t445, 0
  %t450 = insertvalue { i64, ptr } %t449, ptr %t448, 1
  %t451 = load ptr, ptr %l201, !tbaa !29
  %t452 = load { i64, [1 x i64] }, ptr %l202
  %t453 = load { i64, ptr }, ptr %l207, !tbaa !27
  %t454 = load i64, ptr %l210, !tbaa !24
  %t456 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloc(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %t451, { i64, [1 x i64] } %t452, { i64, ptr } %t453, i64 %t454, { i64, ptr } %t450)
  store { i64, ptr } %t456, ptr %l215
  br label %bb71
bb71:
  %t457 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t457, ptr %lp31
  %t458 = load { i64, ptr }, ptr %l215, !tbaa !27
  %t459 = load ptr, ptr %lp31
  store { i64, ptr } %t458, ptr %t459, !tbaa !27
  %t460 = load ptr, ptr %l0, !tbaa !29
  store ptr %t460, ptr %l216, !tbaa !29
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t462 = load i32, ptr %l28, !tbaa !23
  %t465 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s10, ptr %t461, i32 %t462)
  store { i64, ptr } %t465, ptr %l219
  br label %bb72
bb72:
  %t466 = load { i64, ptr }, ptr %l219, !tbaa !27
  %t467 = extractvalue { i64, ptr } %t466, 0
  %t468 = extractvalue { i64, ptr } %t466, 1
  %t469 = mul i64 %t467, 1
  %t470 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t469)
  call void @llvm.memcpy.p0.p0.i64(ptr %t470, ptr %t468, i64 %t469, i1 false)
  %t471 = insertvalue { i64, ptr } undef, i64 %t467, 0
  %t472 = insertvalue { i64, ptr } %t471, ptr %t470, 1
  %t473 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t474 = load ptr, ptr %lp31
  %t475 = load { i64, ptr }, ptr %t474, !tbaa !27
  %t476 = load ptr, ptr %l216, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s10, ptr %s10, ptr %v1, ptr %s10, ptr %t476, { i64, ptr } %t472, { i64, ptr } %t473, { i64, ptr } %t475, { i64, ptr } { i64 0, ptr @.d418 })
  br label %bb73
bb73:
  %t480 = load ptr, ptr %lp31
  %t481 = load { i64, ptr }, ptr %t480, !tbaa !27
  call void @__olang_scope_close(ptr %s10)
  store { i64, ptr } %t481, ptr %rv
  br label %ret
bb74:
  %t483 = load { i64, [15 x i64] }, ptr %l1
  %t485 = extractvalue { i64, [15 x i64] } %t483, 0
  %t486 = icmp eq i64 %t485, 8
  br i1 %t486, label %bb75, label %bb76
bb75:
  %t488 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t489 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t488, i32 0, i32 0
  %t490 = load { i64, [1 x i64] }, ptr %t489
  store { i64, [1 x i64] } %t490, ptr %l32
  %t492 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t493 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t492, i32 0, i32 1
  %t494 = load i32, ptr %t493
  store i32 %t494, ptr %l33, !tbaa !23
  %t496 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t497 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t496, i32 0, i32 2
  %t498 = load { i64, [4 x i64] }, ptr %t497
  store { i64, [4 x i64] } %t498, ptr %l34
  %t500 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t501 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t500, i32 0, i32 3
  %t502 = load { i64, [4 x i64] }, ptr %t501
  store { i64, [4 x i64] } %t502, ptr %l35
  br label %bb77
bb76:
  br label %bb79
bb77:
  %t504 = load ptr, ptr %l0, !tbaa !29
  %t505 = load { i64, [1 x i64] }, ptr %l32
  %t506 = load i32, ptr %l33, !tbaa !23
  %t507 = load { i64, [4 x i64] }, ptr %l34
  %t508 = load { i64, [4 x i64] }, ptr %l35
  %t514 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2enewArray(ptr %v0, ptr %v1, ptr %t504, { i64, [1 x i64] } %t505, i32 %t506, { i64, [4 x i64] } %t507, { i64, [4 x i64] } %t508)
  store { i64, ptr } %t514, ptr %l235
  br label %bb78
bb78:
  %t515 = load { i64, ptr }, ptr %l235, !tbaa !27
  store { i64, ptr } %t515, ptr %rv
  br label %ret
bb79:
  %t516 = load { i64, [15 x i64] }, ptr %l1
  %t518 = extractvalue { i64, [15 x i64] } %t516, 0
  %t519 = icmp eq i64 %t518, 9
  br i1 %t519, label %bb80, label %bb81
bb80:
  %t521 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t522 = getelementptr { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t521, i32 0, i32 0
  %t523 = load %"compiler/mir:Place", ptr %t522
  store %"compiler/mir:Place" %t523, ptr %l36
  %t525 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t526 = getelementptr { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t525, i32 0, i32 1
  %t527 = load { i64, [4 x i64] }, ptr %t526
  store { i64, [4 x i64] } %t527, ptr %l37
  %t529 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t530 = getelementptr { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t529, i32 0, i32 2
  %t531 = load { i64, [4 x i64] }, ptr %t530
  store { i64, [4 x i64] } %t531, ptr %l38
  %t533 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t534 = getelementptr { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t533, i32 0, i32 3
  %t535 = load i32, ptr %t534
  store i32 %t535, ptr %l39, !tbaa !23
  br label %bb82
bb81:
  br label %bb84
bb82:
  %t537 = load ptr, ptr %l0, !tbaa !29
  %t538 = load %"compiler/mir:Place", ptr %l36
  %t539 = load { i64, [4 x i64] }, ptr %l37
  %t540 = load { i64, [4 x i64] }, ptr %l38
  %t541 = load i32, ptr %l39, !tbaa !23
  %t547 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eslice(ptr %v0, ptr %v1, ptr %t537, %"compiler/mir:Place" %t538, { i64, [4 x i64] } %t539, { i64, [4 x i64] } %t540, i32 %t541)
  store { i64, ptr } %t547, ptr %l247
  br label %bb83
bb83:
  %t548 = load { i64, ptr }, ptr %l247, !tbaa !27
  store { i64, ptr } %t548, ptr %rv
  br label %ret
bb84:
  %t549 = load { i64, [15 x i64] }, ptr %l1
  %t551 = extractvalue { i64, [15 x i64] } %t549, 0
  %t552 = icmp eq i64 %t551, 10
  br i1 %t552, label %bb85, label %bb86
bb85:
  %t554 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t555 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t554, i32 0, i32 0
  %t556 = load { i64, [2 x i64] }, ptr %t555
  store { i64, [2 x i64] } %t556, ptr %l40
  %t558 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t559 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t558, i32 0, i32 1
  %t560 = load i32, ptr %t559
  store i32 %t560, ptr %l41, !tbaa !23
  %t562 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t563 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t562, i32 0, i32 2
  %t564 = load { i64, [1 x i64] }, ptr %t563
  store { i64, [1 x i64] } %t564, ptr %l42
  %t566 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t567 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t566, i32 0, i32 3
  %t568 = load %"compiler/mir:Range", ptr %t567
  store %"compiler/mir:Range" %t568, ptr %l43
  %t570 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t571 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t570, i32 0, i32 4
  %t572 = load %"compiler/mir:Range", ptr %t571
  store %"compiler/mir:Range" %t572, ptr %l44
  br label %bb87
bb86:
  br label %bb89
bb87:
  %t574 = load ptr, ptr %l0, !tbaa !29
  %t575 = load { i64, [2 x i64] }, ptr %l40
  %t576 = load i32, ptr %l41, !tbaa !23
  %t577 = load { i64, [1 x i64] }, ptr %l42
  %t578 = load %"compiler/mir:Range", ptr %l43
  %t579 = load %"compiler/mir:Range", ptr %l44
  %t586 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eclosure(ptr %v0, ptr %v1, ptr %t574, { i64, [2 x i64] } %t575, i32 %t576, { i64, [1 x i64] } %t577, %"compiler/mir:Range" %t578, %"compiler/mir:Range" %t579)
  store { i64, ptr } %t586, ptr %l261
  br label %bb88
bb88:
  %t587 = load { i64, ptr }, ptr %l261, !tbaa !27
  store { i64, ptr } %t587, ptr %rv
  br label %ret
bb89:
  %t588 = load { i64, [15 x i64] }, ptr %l1
  %t590 = extractvalue { i64, [15 x i64] } %t588, 0
  %t591 = icmp eq i64 %t590, 11
  br i1 %t591, label %bb90, label %bb91
bb90:
  %t593 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t594 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t593, i32 0, i32 0
  %t595 = load { i64, [4 x i64] }, ptr %t594
  store { i64, [4 x i64] } %t595, ptr %l45
  %t597 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t598 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t597, i32 0, i32 1
  %t599 = load i32, ptr %t598
  store i32 %t599, ptr %l46, !tbaa !23
  %t601 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t602 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t601, i32 0, i32 2
  %t603 = load i32, ptr %t602
  store i32 %t603, ptr %l47, !tbaa !23
  br label %bb92
bb91:
  br label %bb95
bb92:
  %t605 = load ptr, ptr %l0, !tbaa !29
  store ptr %t605, ptr %l267, !tbaa !29
  %t606 = load ptr, ptr %l0, !tbaa !29
  %t607 = load { i64, [4 x i64] }, ptr %l45
  %t608 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t612 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %v1, ptr %t606, { i64, [4 x i64] } %t607, i32 %t608)
  store { i64, ptr } %t612, ptr %l271
  br label %bb93
bb93:
  %t613 = load { i64, ptr }, ptr %l271, !tbaa !27
  %t614 = extractvalue { i64, ptr } %t613, 0
  %t615 = extractvalue { i64, ptr } %t613, 1
  %t616 = mul i64 %t614, 1
  %t617 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t616)
  call void @llvm.memcpy.p0.p0.i64(ptr %t617, ptr %t615, i64 %t616, i1 false)
  %t618 = insertvalue { i64, ptr } undef, i64 %t614, 0
  %t619 = insertvalue { i64, ptr } %t618, ptr %t617, 1
  %t620 = load i32, ptr %l46, !tbaa !23
  %t621 = load i32, ptr %l47, !tbaa !23
  %t622 = load ptr, ptr %l267, !tbaa !29
  %t626 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2erecode(ptr %v0, ptr %v1, ptr %v1, ptr %t622, { i64, ptr } %t619, i32 %t620, i32 %t621)
  store { i64, ptr } %t626, ptr %l275
  br label %bb94
bb94:
  %t627 = load { i64, ptr }, ptr %l275, !tbaa !27
  store { i64, ptr } %t627, ptr %rv
  br label %ret
bb95:
  %t628 = load { i64, [15 x i64] }, ptr %l1
  %t630 = extractvalue { i64, [15 x i64] } %t628, 0
  %t631 = icmp eq i64 %t630, 12
  br i1 %t631, label %bb96, label %bb97
bb96:
  %t633 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t634 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t633, i32 0, i32 0
  %t635 = load { i64, [1 x i64] }, ptr %t634
  store { i64, [1 x i64] } %t635, ptr %l48
  %t637 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t638 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t637, i32 0, i32 1
  %t639 = load { i64, [1 x i64] }, ptr %t638
  store { i64, [1 x i64] } %t639, ptr %l49
  %t641 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t642 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t641, i32 0, i32 2
  %t643 = load i32, ptr %t642
  store i32 %t643, ptr %l50, !tbaa !23
  br label %bb98
bb97:
  br label %bb114
bb98:
  store %olang.scope zeroinitializer, ptr %s19
  %t645 = load ptr, ptr %l0, !tbaa !29
  %t646 = load { i64, [1 x i64] }, ptr %l48
  %t649 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2edirectRef(ptr %v0, ptr %t645, { i64, [1 x i64] } %t646)
  store i1 %t649, ptr %l283
  br label %bb99
bb99:
  %t650 = load i1, ptr %l283, !tbaa !21
  br i1 %t650, label %bb100, label %bb101
bb100:
  %t651 = load ptr, ptr %l0, !tbaa !29
  %t652 = load { i64, [1 x i64] }, ptr %l49
  %t655 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edirectText(ptr %v0, ptr %v1, ptr %t651, { i64, [1 x i64] } %t652)
  store { i64, ptr } %t655, ptr %l286
  br label %bb102
bb101:
  br label %bb103
bb102:
  call void @__olang_scope_close(ptr %s19)
  %t656 = load { i64, ptr }, ptr %l286, !tbaa !27
  store { i64, ptr } %t656, ptr %rv
  br label %ret
bb103:
  %t657 = load ptr, ptr %l0, !tbaa !29
  %t658 = load { i64, [1 x i64] }, ptr %l48
  %t661 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %s19, ptr %t657, { i64, [1 x i64] } %t658)
  store { i64, ptr } %t661, ptr %l289
  br label %bb104
bb104:
  %t662 = load { i64, ptr }, ptr %l289, !tbaa !27
  store { i64, ptr } %t662, ptr %l51, !tbaa !27
  %t663 = load ptr, ptr %l0, !tbaa !29
  %t664 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t667 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s19, ptr %s19, ptr %s19, ptr %s19, ptr %t663, { i64, ptr } { i64 3, ptr @.d419 }, { i64, ptr } %t664, { i64, ptr } { i64 0, ptr @.d420 })
  store { i64, ptr } %t667, ptr %l292
  br label %bb105
bb105:
  %t668 = load { i64, ptr }, ptr %l292, !tbaa !27
  store { i64, ptr } %t668, ptr %l52, !tbaa !27
  %t669 = load ptr, ptr %l0, !tbaa !29
  store ptr %t669, ptr %l293, !tbaa !29
  %t670 = load ptr, ptr %l0, !tbaa !29
  %t671 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t672 = extractvalue { i64, ptr } { i64 34, ptr @.d421 }, 1
  %t673 = extractvalue { i64, ptr } { i64 34, ptr @.d421 }, 0
  %t675 = extractvalue { i64, ptr } %t671, 1
  %t676 = extractvalue { i64, ptr } %t671, 0
  %t677 = add i64 %t673, %t676
  %t678 = extractvalue { i64, ptr } { i64 14, ptr @.d422 }, 1
  %t679 = extractvalue { i64, ptr } { i64 14, ptr @.d422 }, 0
  %t680 = add i64 %t677, %t679
  %t681 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t680)
  call void @olang_textcopy(ptr %t681, ptr %t672, i64 %t673)
  %t682 = getelementptr i8, ptr %t681, i64 %t673
  call void @olang_textcopy(ptr %t682, ptr %t675, i64 %t676)
  %t683 = getelementptr i8, ptr %t682, i64 %t676
  call void @olang_textcopy(ptr %t683, ptr %t678, i64 %t679)
  %t684 = insertvalue { i64, ptr } undef, i64 %t680, 0
  %t685 = insertvalue { i64, ptr } %t684, ptr %t681, 1
  %t687 = extractvalue { i64, ptr } %t685, 0
  %t688 = extractvalue { i64, ptr } %t685, 1
  %t689 = mul i64 %t687, 1
  %t690 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t689)
  call void @llvm.memcpy.p0.p0.i64(ptr %t690, ptr %t688, i64 %t689, i1 false)
  %t691 = insertvalue { i64, ptr } undef, i64 %t687, 0
  %t692 = insertvalue { i64, ptr } %t691, ptr %t690, 1
  %t695 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s19, ptr %s19, ptr %t670, { i64, ptr } %t692)
  store { i64, ptr } %t695, ptr %l298
  br label %bb106
bb106:
  %t696 = load { i64, ptr }, ptr %l298, !tbaa !27
  %t697 = extractvalue { i64, ptr } %t696, 0
  %t698 = extractvalue { i64, ptr } %t696, 1
  %t699 = mul i64 %t697, 1
  %t700 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t699)
  call void @llvm.memcpy.p0.p0.i64(ptr %t700, ptr %t698, i64 %t699, i1 false)
  %t701 = insertvalue { i64, ptr } undef, i64 %t697, 0
  %t702 = insertvalue { i64, ptr } %t701, ptr %t700, 1
  %t703 = load ptr, ptr %l293, !tbaa !29
  %t705 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s19, ptr %s19, ptr %s19, ptr %s19, ptr %t703, { i64, ptr } { i64 3, ptr @.d423 }, { i64, ptr } %t702, { i64, ptr } { i64 0, ptr @.d424 })
  store { i64, ptr } %t705, ptr %l300
  br label %bb107
bb107:
  %t706 = load { i64, ptr }, ptr %l300, !tbaa !27
  store { i64, ptr } %t706, ptr %l53, !tbaa !27
  %t707 = load ptr, ptr %l0, !tbaa !29
  %t709 = getelementptr %"compiler/emit:fnEm", ptr %t707, i32 0, i32 0
  %t710 = load ptr, ptr %t709, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s19, ptr %t710, { i64, ptr } { i64 19, ptr @.d425 })
  br label %bb108
bb108:
  %t712 = load ptr, ptr %l0, !tbaa !29
  store ptr %t712, ptr %l303, !tbaa !29
  %t713 = load ptr, ptr %l0, !tbaa !29
  %t714 = load { i64, [1 x i64] }, ptr %l49
  %t717 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %s19, ptr %t713, { i64, [1 x i64] } %t714)
  store { i64, ptr } %t717, ptr %l306
  br label %bb109
bb109:
  %t718 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t719 = extractvalue { i64, ptr } { i64 34, ptr @.d426 }, 1
  %t720 = extractvalue { i64, ptr } { i64 34, ptr @.d426 }, 0
  %t721 = load { i64, ptr }, ptr %l306, !tbaa !27
  %t722 = extractvalue { i64, ptr } %t721, 1
  %t723 = extractvalue { i64, ptr } %t721, 0
  %t724 = add i64 %t720, %t723
  %t725 = extractvalue { i64, ptr } { i64 6, ptr @.d427 }, 1
  %t726 = extractvalue { i64, ptr } { i64 6, ptr @.d427 }, 0
  %t727 = add i64 %t724, %t726
  %t729 = extractvalue { i64, ptr } %t718, 1
  %t730 = extractvalue { i64, ptr } %t718, 0
  %t731 = add i64 %t727, %t730
  %t732 = extractvalue { i64, ptr } { i64 1, ptr @.d428 }, 1
  %t733 = extractvalue { i64, ptr } { i64 1, ptr @.d428 }, 0
  %t734 = add i64 %t731, %t733
  %t735 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t734)
  call void @olang_textcopy(ptr %t735, ptr %t719, i64 %t720)
  %t736 = getelementptr i8, ptr %t735, i64 %t720
  call void @olang_textcopy(ptr %t736, ptr %t722, i64 %t723)
  %t737 = getelementptr i8, ptr %t736, i64 %t723
  call void @olang_textcopy(ptr %t737, ptr %t725, i64 %t726)
  %t738 = getelementptr i8, ptr %t737, i64 %t726
  call void @olang_textcopy(ptr %t738, ptr %t729, i64 %t730)
  %t739 = getelementptr i8, ptr %t738, i64 %t730
  call void @olang_textcopy(ptr %t739, ptr %t732, i64 %t733)
  %t740 = insertvalue { i64, ptr } undef, i64 %t734, 0
  %t741 = insertvalue { i64, ptr } %t740, ptr %t735, 1
  %t743 = extractvalue { i64, ptr } %t741, 0
  %t744 = extractvalue { i64, ptr } %t741, 1
  %t745 = mul i64 %t743, 1
  %t746 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t745)
  call void @llvm.memcpy.p0.p0.i64(ptr %t746, ptr %t744, i64 %t745, i1 false)
  %t747 = insertvalue { i64, ptr } undef, i64 %t743, 0
  %t748 = insertvalue { i64, ptr } %t747, ptr %t746, 1
  %t749 = load ptr, ptr %l303, !tbaa !29
  %t751 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s19, ptr %s19, ptr %t749, { i64, ptr } %t748)
  store { i64, ptr } %t751, ptr %l310
  br label %bb110
bb110:
  %t752 = load { i64, ptr }, ptr %l310, !tbaa !27
  store { i64, ptr } %t752, ptr %l54, !tbaa !27
  %t753 = load ptr, ptr %l0, !tbaa !29
  %t755 = getelementptr %"compiler/emit:fnEm", ptr %t753, i32 0, i32 0
  %t756 = load ptr, ptr %t755, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2etextCopy(ptr %v0, ptr %t756)
  br label %bb111
bb111:
  %t758 = load ptr, ptr %l0, !tbaa !29
  %t759 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t760 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t761 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t762 = extractvalue { i64, ptr } { i64 30, ptr @.d429 }, 1
  %t763 = extractvalue { i64, ptr } { i64 30, ptr @.d429 }, 0
  %t765 = extractvalue { i64, ptr } %t759, 1
  %t766 = extractvalue { i64, ptr } %t759, 0
  %t767 = add i64 %t763, %t766
  %t768 = extractvalue { i64, ptr } { i64 6, ptr @.d430 }, 1
  %t769 = extractvalue { i64, ptr } { i64 6, ptr @.d430 }, 0
  %t770 = add i64 %t767, %t769
  %t772 = extractvalue { i64, ptr } %t760, 1
  %t773 = extractvalue { i64, ptr } %t760, 0
  %t774 = add i64 %t770, %t773
  %t775 = extractvalue { i64, ptr } { i64 6, ptr @.d431 }, 1
  %t776 = extractvalue { i64, ptr } { i64 6, ptr @.d431 }, 0
  %t777 = add i64 %t774, %t776
  %t779 = extractvalue { i64, ptr } %t761, 1
  %t780 = extractvalue { i64, ptr } %t761, 0
  %t781 = add i64 %t777, %t780
  %t782 = extractvalue { i64, ptr } { i64 1, ptr @.d432 }, 1
  %t783 = extractvalue { i64, ptr } { i64 1, ptr @.d432 }, 0
  %t784 = add i64 %t781, %t783
  %t785 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t784)
  call void @olang_textcopy(ptr %t785, ptr %t762, i64 %t763)
  %t786 = getelementptr i8, ptr %t785, i64 %t763
  call void @olang_textcopy(ptr %t786, ptr %t765, i64 %t766)
  %t787 = getelementptr i8, ptr %t786, i64 %t766
  call void @olang_textcopy(ptr %t787, ptr %t768, i64 %t769)
  %t788 = getelementptr i8, ptr %t787, i64 %t769
  call void @olang_textcopy(ptr %t788, ptr %t772, i64 %t773)
  %t789 = getelementptr i8, ptr %t788, i64 %t773
  call void @olang_textcopy(ptr %t789, ptr %t775, i64 %t776)
  %t790 = getelementptr i8, ptr %t789, i64 %t776
  call void @olang_textcopy(ptr %t790, ptr %t779, i64 %t780)
  %t791 = getelementptr i8, ptr %t790, i64 %t780
  call void @olang_textcopy(ptr %t791, ptr %t782, i64 %t783)
  %t792 = insertvalue { i64, ptr } undef, i64 %t784, 0
  %t793 = insertvalue { i64, ptr } %t792, ptr %t785, 1
  %t795 = extractvalue { i64, ptr } %t793, 0
  %t796 = extractvalue { i64, ptr } %t793, 1
  %t797 = mul i64 %t795, 1
  %t798 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t797)
  call void @llvm.memcpy.p0.p0.i64(ptr %t798, ptr %t796, i64 %t797, i1 false)
  %t799 = insertvalue { i64, ptr } undef, i64 %t795, 0
  %t800 = insertvalue { i64, ptr } %t799, ptr %t798, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s19, ptr %t758, { i64, ptr } %t800)
  br label %bb112
bb112:
  %t803 = load ptr, ptr %l0, !tbaa !29
  %t804 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t805 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t809 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epair(ptr %v0, ptr %s19, ptr %s19, ptr %v1, ptr %t803, { i64, ptr } %t804, { i64, ptr } %t805)
  store { i64, ptr } %t809, ptr %l322
  br label %bb113
bb113:
  call void @__olang_scope_close(ptr %s19)
  %t810 = load { i64, ptr }, ptr %l322, !tbaa !27
  store { i64, ptr } %t810, ptr %rv
  br label %ret
bb114:
  call void @__olang_check_failed(ptr @olang_loc_b25f444594da9527_de5411018827488b)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2eunwindPush(ptr %v0, ptr %a0, i32 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %s0, ptr %s0, ptr %t4, { i64, ptr } { i64 18, ptr @.d433 }, { i64, ptr } { i64 67, ptr @.d434 })
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t6, { i64, ptr } { i64 3, ptr @.d435 }, { i64, ptr } { i64 19, ptr @.d436 }, { i64, ptr } { i64 0, ptr @.d437 })
  store { i64, ptr } %t8, ptr %l7
  br label %bb2
bb2:
  %t9 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l8, !tbaa !29
  store { i64, ptr } %t9, ptr %l9, !tbaa !27
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l1, !tbaa !23
  %t14 = extractvalue { i64, ptr } { i64 35, ptr @.d438 }, 1
  %t15 = extractvalue { i64, ptr } { i64 35, ptr @.d438 }, 0
  %t17 = sext i32 %t13 to i64
  %t18 = call i64 @__olang_fmt_i64(ptr null, i64 %t17)
  %t19 = add i64 %t15, %t18
  %t20 = extractvalue { i64, ptr } { i64 14, ptr @.d439 }, 1
  %t21 = extractvalue { i64, ptr } { i64 14, ptr @.d439 }, 0
  %t22 = add i64 %t19, %t21
  %t23 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t14, i64 %t15)
  %t24 = getelementptr i8, ptr %t23, i64 %t15
  %t25 = call i64 @__olang_fmt_i64(ptr %t24, i64 %t17)
  %t26 = getelementptr i8, ptr %t24, i64 %t18
  call void @olang_textcopy(ptr %t26, ptr %t20, i64 %t21)
  %t27 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t23, 1
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t31 = extractvalue { i64, ptr } %t28, 1
  %t32 = mul i64 %t30, 1
  %t33 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t32)
  call void @llvm.memcpy.p0.p0.i64(ptr %t33, ptr %t31, i64 %t32, i1 false)
  %t34 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  %t38 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t12, { i64, ptr } %t35)
  store { i64, ptr } %t38, ptr %l14
  br label %bb3
bb3:
  %t39 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  %t41 = extractvalue { i64, ptr } %t39, 1
  %t42 = mul i64 %t40, 1
  %t43 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t42)
  call void @llvm.memcpy.p0.p0.i64(ptr %t43, ptr %t41, i64 %t42, i1 false)
  %t44 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  %t46 = load ptr, ptr %l8, !tbaa !29
  %t47 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t46, { i64, ptr } { i64 3, ptr @.d440 }, { i64, ptr } %t47, { i64, ptr } %t45, { i64, ptr } { i64 0, ptr @.d441 })
  br label %bb4
bb4:
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l16, !tbaa !29
  %t50 = load i32, ptr %l1, !tbaa !23
  %t51 = extractvalue { i64, ptr } { i64 2, ptr @.d442 }, 1
  %t52 = extractvalue { i64, ptr } { i64 2, ptr @.d442 }, 0
  %t54 = sext i32 %t50 to i64
  %t55 = call i64 @__olang_fmt_i64(ptr null, i64 %t54)
  %t56 = add i64 %t52, %t55
  %t57 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t51, i64 %t52)
  %t58 = getelementptr i8, ptr %t57, i64 %t52
  %t59 = call i64 @__olang_fmt_i64(ptr %t58, i64 %t54)
  %t60 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t57, 1
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t64 = extractvalue { i64, ptr } %t61, 1
  %t65 = mul i64 %t63, 1
  %t66 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t65)
  call void @llvm.memcpy.p0.p0.i64(ptr %t66, ptr %t64, i64 %t65, i1 false)
  %t67 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  store { i64, ptr } %t68, ptr %l19, !tbaa !27
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i32, ptr %l1, !tbaa !23
  %t71 = extractvalue { i64, ptr } { i64 35, ptr @.d443 }, 1
  %t72 = extractvalue { i64, ptr } { i64 35, ptr @.d443 }, 0
  %t74 = sext i32 %t70 to i64
  %t75 = call i64 @__olang_fmt_i64(ptr null, i64 %t74)
  %t76 = add i64 %t72, %t75
  %t77 = extractvalue { i64, ptr } { i64 14, ptr @.d444 }, 1
  %t78 = extractvalue { i64, ptr } { i64 14, ptr @.d444 }, 0
  %t79 = add i64 %t76, %t78
  %t80 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t79)
  call void @olang_textcopy(ptr %t80, ptr %t71, i64 %t72)
  %t81 = getelementptr i8, ptr %t80, i64 %t72
  %t82 = call i64 @__olang_fmt_i64(ptr %t81, i64 %t74)
  %t83 = getelementptr i8, ptr %t81, i64 %t75
  call void @olang_textcopy(ptr %t83, ptr %t77, i64 %t78)
  %t84 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t80, 1
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t88 = extractvalue { i64, ptr } %t85, 1
  %t89 = mul i64 %t87, 1
  %t90 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t89)
  call void @llvm.memcpy.p0.p0.i64(ptr %t90, ptr %t88, i64 %t89, i1 false)
  %t91 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t90, 1
  %t95 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t69, { i64, ptr } %t92)
  store { i64, ptr } %t95, ptr %l24
  br label %bb5
bb5:
  %t96 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 0
  %t98 = extractvalue { i64, ptr } %t96, 1
  %t99 = mul i64 %t97, 1
  %t100 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t99)
  call void @llvm.memcpy.p0.p0.i64(ptr %t100, ptr %t98, i64 %t99, i1 false)
  %t101 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t100, 1
  %t103 = load ptr, ptr %l16, !tbaa !29
  %t104 = load { i64, ptr }, ptr %l19, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t103, { i64, ptr } { i64 3, ptr @.d445 }, { i64, ptr } %t104, { i64, ptr } %t102, { i64, ptr } { i64 0, ptr @.d446 })
  br label %bb6
bb6:
  %t106 = load ptr, ptr %l0, !tbaa !29
  store ptr %t106, ptr %l26, !tbaa !29
  br i1 %a2, label %bb7, label %bb8
bb7:
  %t109 = load i32, ptr %l1, !tbaa !23
  %t110 = extractvalue { i64, ptr } { i64 3, ptr @.d447 }, 1
  %t111 = extractvalue { i64, ptr } { i64 3, ptr @.d447 }, 0
  %t113 = sext i32 %t109 to i64
  %t114 = call i64 @__olang_fmt_i64(ptr null, i64 %t113)
  %t115 = add i64 %t111, %t114
  %t116 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t115)
  call void @olang_textcopy(ptr %t116, ptr %t110, i64 %t111)
  %t117 = getelementptr i8, ptr %t116, i64 %t111
  %t118 = call i64 @__olang_fmt_i64(ptr %t117, i64 %t113)
  %t119 = insertvalue { i64, ptr } undef, i64 %t115, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t116, 1
  %t122 = extractvalue { i64, ptr } %t120, 0
  %t123 = extractvalue { i64, ptr } %t120, 1
  %t124 = mul i64 %t122, 1
  %t125 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t124)
  call void @llvm.memcpy.p0.p0.i64(ptr %t125, ptr %t123, i64 %t124, i1 false)
  %t126 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t125, 1
  store { i64, ptr } %t127, ptr %l28, !tbaa !27
  br label %bb9
bb8:
  store { i64, ptr } { i64 4, ptr @.d448 }, ptr %l28, !tbaa !27
  br label %bb9
bb9:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load i32, ptr %l1, !tbaa !23
  %t131 = extractvalue { i64, ptr } { i64 35, ptr @.d449 }, 1
  %t132 = extractvalue { i64, ptr } { i64 35, ptr @.d449 }, 0
  %t134 = sext i32 %t130 to i64
  %t135 = call i64 @__olang_fmt_i64(ptr null, i64 %t134)
  %t136 = add i64 %t132, %t135
  %t137 = extractvalue { i64, ptr } { i64 14, ptr @.d450 }, 1
  %t138 = extractvalue { i64, ptr } { i64 14, ptr @.d450 }, 0
  %t139 = add i64 %t136, %t138
  %t140 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t139)
  call void @olang_textcopy(ptr %t140, ptr %t131, i64 %t132)
  %t141 = getelementptr i8, ptr %t140, i64 %t132
  %t142 = call i64 @__olang_fmt_i64(ptr %t141, i64 %t134)
  %t143 = getelementptr i8, ptr %t141, i64 %t135
  call void @olang_textcopy(ptr %t143, ptr %t137, i64 %t138)
  %t144 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t140, 1
  %t147 = extractvalue { i64, ptr } %t145, 0
  %t148 = extractvalue { i64, ptr } %t145, 1
  %t149 = mul i64 %t147, 1
  %t150 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t149)
  call void @llvm.memcpy.p0.p0.i64(ptr %t150, ptr %t148, i64 %t149, i1 false)
  %t151 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t150, 1
  %t155 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t129, { i64, ptr } %t152)
  store { i64, ptr } %t155, ptr %l36
  br label %bb10
bb10:
  %t156 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t156, 0
  %t158 = extractvalue { i64, ptr } %t156, 1
  %t159 = mul i64 %t157, 1
  %t160 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t159)
  call void @llvm.memcpy.p0.p0.i64(ptr %t160, ptr %t158, i64 %t159, i1 false)
  %t161 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t160, 1
  %t163 = load ptr, ptr %l26, !tbaa !29
  %t164 = load { i64, ptr }, ptr %l28, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t163, { i64, ptr } { i64 3, ptr @.d451 }, { i64, ptr } %t164, { i64, ptr } %t162, { i64, ptr } { i64 0, ptr @.d452 })
  br label %bb11
bb11:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load i32, ptr %l1, !tbaa !23
  %t168 = extractvalue { i64, ptr } { i64 2, ptr @.d453 }, 1
  %t169 = extractvalue { i64, ptr } { i64 2, ptr @.d453 }, 0
  %t171 = sext i32 %t167 to i64
  %t172 = call i64 @__olang_fmt_i64(ptr null, i64 %t171)
  %t173 = add i64 %t169, %t172
  %t174 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t173)
  call void @olang_textcopy(ptr %t174, ptr %t168, i64 %t169)
  %t175 = getelementptr i8, ptr %t174, i64 %t169
  %t176 = call i64 @__olang_fmt_i64(ptr %t175, i64 %t171)
  %t177 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t174, 1
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t181 = extractvalue { i64, ptr } %t178, 1
  %t182 = mul i64 %t180, 1
  %t183 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t182)
  call void @llvm.memcpy.p0.p0.i64(ptr %t183, ptr %t181, i64 %t182, i1 false)
  %t184 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t183, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t166, { i64, ptr } { i64 3, ptr @.d454 }, { i64, ptr } %t185, { i64, ptr } { i64 19, ptr @.d455 }, { i64, ptr } { i64 0, ptr @.d456 })
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2emathExact_2einit() #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2emathExactTable(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr @G_2ecompiler_2femit_2emathExact
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_3aEmitter_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca i64
  %l17 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l21 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l23 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i1
  %l28 = alloca i64
  %l29 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l30 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l31 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l32 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l33 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l34 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l35 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l36 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l37 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l38 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l39 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l40 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l41 = alloca i1
  %l42 = alloca i1
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i1
  %l46 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l47 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l48 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l49 = alloca { i64, ptr }
  %l50 = alloca i1
  %l51 = alloca i1
  %l52 = alloca { i64, ptr }
  %l53 = alloca i1
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l59 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l60 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l61 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l62 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l63 = alloca i1
  %l64 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l65 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l66 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l67 = alloca i1
  %l68 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l69 = alloca i1
  %l70 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l71 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l77 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l78 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l79 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l80 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l81 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l82 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l83 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l84 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l85 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l86 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l87 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l88 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l89 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l90 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l91 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l92 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l93 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l94 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l95 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l96 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l97 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l98 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l99 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l101 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l102 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l103 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l104 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l105 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l106 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l107 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l108 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l109 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l110 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l111 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l112 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l113 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l114 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l115 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l116 = alloca %"compiler/emit:Emitter"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l4, !tbaa !29
  store ptr %a1, ptr %l5, !tbaa !29
  store ptr %a2, ptr %l6, !tbaa !29
  store ptr %a3, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  store i1 false, ptr %l9, !tbaa !21
  store i1 false, ptr %l10, !tbaa !21
  store i1 true, ptr %l11, !tbaa !21
  store { i64, ptr } { i64 0, ptr @.d457 }, ptr %l12, !tbaa !27
  %t9 = load ptr, ptr @__olang_prog_scope
  %t10 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t9)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l77
  br label %bb1
bb1:
  %t11 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l77
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l13
  %t12 = load ptr, ptr @__olang_prog_scope
  %t13 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e(ptr %t12)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l78
  br label %bb2
bb2:
  %t14 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l78
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, ptr %l14
  %t15 = load ptr, ptr @__olang_prog_scope
  %t16 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e(ptr %t15)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l79
  br label %bb3
bb3:
  %t17 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l79
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, ptr %l15
  store i64 -1, ptr %l16, !tbaa !24
  %t18 = load ptr, ptr @__olang_prog_scope
  %t19 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %t18)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, ptr %l80
  br label %bb4
bb4:
  %t20 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l80
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t20, ptr %l17
  %t21 = load ptr, ptr @__olang_prog_scope
  %t22 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e(ptr %t21)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l81
  br label %bb5
bb5:
  %t23 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l81
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %l18
  %t24 = load ptr, ptr @__olang_prog_scope
  %t25 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t24)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l82
  br label %bb6
bb6:
  %t26 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l82
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t26, ptr %l19
  %t27 = load ptr, ptr @__olang_prog_scope
  %t28 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t27)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, ptr %l83
  br label %bb7
bb7:
  %t29 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l83
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t29, ptr %l20
  %t30 = load ptr, ptr @__olang_prog_scope
  %t31 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t30)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t31, ptr %l84
  br label %bb8
bb8:
  %t32 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l84
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %l21
  %t33 = load ptr, ptr @__olang_prog_scope
  %t34 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t33)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t34, ptr %l85
  br label %bb9
bb9:
  %t35 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l85
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t35, ptr %l22
  %t36 = load ptr, ptr @__olang_prog_scope
  %t37 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %t36)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t37, ptr %l86
  br label %bb10
bb10:
  %t38 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l86
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t38, ptr %l23
  %t39 = load ptr, ptr @__olang_prog_scope
  %t40 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e(ptr %t39)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, ptr %l87
  br label %bb11
bb11:
  %t41 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l87
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t41, ptr %l24
  store { i64, ptr } { i64 19, ptr @.d458 }, ptr %l25, !tbaa !27
  store i64 0, ptr %l26, !tbaa !24
  store i1 false, ptr %l27, !tbaa !21
  store i64 0, ptr %l28, !tbaa !24
  %t42 = load ptr, ptr @__olang_prog_scope
  %t43 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_Hf48d6d4096e547b8075d5a903caa3d54(ptr %t42)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t43, ptr %l88
  br label %bb12
bb12:
  %t44 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l88
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t44, ptr %l29
  %t45 = load ptr, ptr @__olang_prog_scope
  %t46 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t45)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t46, ptr %l89
  br label %bb13
bb13:
  %t47 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l89
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t47, ptr %l30
  %t48 = load ptr, ptr @__olang_prog_scope
  %t49 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %t48)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t49, ptr %l90
  br label %bb14
bb14:
  %t50 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l90
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t50, ptr %l31
  %t51 = load ptr, ptr @__olang_prog_scope
  %t52 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e(ptr %t51)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t52, ptr %l91
  br label %bb15
bb15:
  %t53 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l91
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t53, ptr %l32
  %t54 = load ptr, ptr @__olang_prog_scope
  %t55 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %t54)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t55, ptr %l92
  br label %bb16
bb16:
  %t56 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l92
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t56, ptr %l33
  %t57 = load ptr, ptr @__olang_prog_scope
  %t58 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %t57)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t58, ptr %l93
  br label %bb17
bb17:
  %t59 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l93
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t59, ptr %l34
  %t60 = load ptr, ptr @__olang_prog_scope
  %t61 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %t60)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t61, ptr %l94
  br label %bb18
bb18:
  %t62 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l94
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t62, ptr %l35
  %t63 = load ptr, ptr @__olang_prog_scope
  %t64 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %t63)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t64, ptr %l95
  br label %bb19
bb19:
  %t65 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l95
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t65, ptr %l36
  %t66 = load ptr, ptr @__olang_prog_scope
  %t67 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e(ptr %t66)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t67, ptr %l96
  br label %bb20
bb20:
  %t68 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l96
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t68, ptr %l37
  %t69 = load ptr, ptr @__olang_prog_scope
  %t70 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e(ptr %t69)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t70, ptr %l97
  br label %bb21
bb21:
  %t71 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l97
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t71, ptr %l38
  %t72 = load ptr, ptr @__olang_prog_scope
  %t73 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %t72)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t73, ptr %l98
  br label %bb22
bb22:
  %t74 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l98
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t74, ptr %l39
  %t75 = load ptr, ptr @__olang_prog_scope
  %t76 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %t75)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t76, ptr %l99
  br label %bb23
bb23:
  %t77 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l99
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t77, ptr %l40
  store i1 false, ptr %l41, !tbaa !21
  store i1 false, ptr %l42, !tbaa !21
  store i64 4611686018427387904, ptr %l43, !tbaa !24
  %t78 = load i64, ptr @G_2ecompiler_2femit_2ePartSize, !tbaa !24
  store i64 %t78, ptr %l44, !tbaa !24
  store i1 false, ptr %l45, !tbaa !21
  %t80 = load ptr, ptr @__olang_prog_scope
  %t81 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t80)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t81, ptr %l101
  br label %bb24
bb24:
  %t82 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l101
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t82, ptr %l46
  %t83 = load ptr, ptr @__olang_prog_scope
  %t84 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %t83)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t84, ptr %l102
  br label %bb25
bb25:
  %t85 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l102
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t85, ptr %l47
  %t86 = load ptr, ptr @__olang_prog_scope
  %t87 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e(ptr %t86)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t87, ptr %l103
  br label %bb26
bb26:
  %t88 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l103
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t88, ptr %l48
  store { i64, ptr } { i64 6, ptr @.d459 }, ptr %l49, !tbaa !27
  store i1 false, ptr %l50, !tbaa !21
  store i1 false, ptr %l51, !tbaa !21
  store { i64, ptr } { i64 0, ptr @.d460 }, ptr %l52, !tbaa !27
  store i1 false, ptr %l53, !tbaa !21
  store i64 1000, ptr %l54, !tbaa !24
  store i64 -1, ptr %l55, !tbaa !24
  store i64 -1, ptr %l56, !tbaa !24
  store i64 -1, ptr %l57, !tbaa !24
  %t89 = load ptr, ptr @__olang_prog_scope
  %t90 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t89)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t90, ptr %l104
  br label %bb27
bb27:
  %t91 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l104
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t91, ptr %l58
  %t92 = load ptr, ptr @__olang_prog_scope
  %t93 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t92)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t93, ptr %l105
  br label %bb28
bb28:
  %t94 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l105
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t94, ptr %l59
  %t95 = load ptr, ptr @__olang_prog_scope
  %t96 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t95)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t96, ptr %l106
  br label %bb29
bb29:
  %t97 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l106
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t97, ptr %l60
  %t98 = load ptr, ptr @__olang_prog_scope
  %t99 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t98)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t99, ptr %l107
  br label %bb30
bb30:
  %t100 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l107
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t100, ptr %l61
  %t101 = load ptr, ptr @__olang_prog_scope
  %t102 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e(ptr %t101)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t102, ptr %l108
  br label %bb31
bb31:
  %t103 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l108
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t103, ptr %l62
  store i1 false, ptr %l63, !tbaa !21
  %t104 = load ptr, ptr @__olang_prog_scope
  %t105 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e(ptr %t104)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t105, ptr %l109
  br label %bb32
bb32:
  %t106 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l109
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t106, ptr %l64
  %t107 = load ptr, ptr @__olang_prog_scope
  %t108 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t107)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t108, ptr %l110
  br label %bb33
bb33:
  %t109 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l110
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t109, ptr %l65
  %t110 = load ptr, ptr @__olang_prog_scope
  %t111 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e(ptr %t110)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t111, ptr %l111
  br label %bb34
bb34:
  %t112 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l111
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t112, ptr %l66
  store i1 false, ptr %l67, !tbaa !21
  %t113 = load ptr, ptr @__olang_prog_scope
  %t114 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e(ptr %t113)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t114, ptr %l112
  br label %bb35
bb35:
  %t115 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l112
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t115, ptr %l68
  store i1 false, ptr %l69, !tbaa !21
  %t116 = load ptr, ptr @__olang_prog_scope
  %t117 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t116)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t117, ptr %l113
  br label %bb36
bb36:
  %t118 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l113
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t118, ptr %l70
  %t119 = load ptr, ptr @__olang_prog_scope
  %t120 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t119)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t120, ptr %l114
  br label %bb37
bb37:
  %t121 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l114
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t121, ptr %l71
  %t122 = load ptr, ptr @__olang_prog_scope
  %t123 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t122)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t123, ptr %l115
  br label %bb38
bb38:
  %t124 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l115
  %t125 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 0
  %t126 = load ptr, ptr %l4, !tbaa !29
  store ptr %t126, ptr %t125, !tbaa !29
  %t127 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 1
  %t128 = load ptr, ptr %l5, !tbaa !29
  store ptr %t128, ptr %t127, !tbaa !29
  %t129 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 2
  %t130 = load ptr, ptr %l6, !tbaa !29
  store ptr %t130, ptr %t129, !tbaa !29
  %t131 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 3
  %t132 = load ptr, ptr %l7, !tbaa !29
  store ptr %t132, ptr %t131, !tbaa !29
  %t133 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 4
  %t134 = load i1, ptr %l8, !tbaa !21
  store i1 %t134, ptr %t133, !tbaa !21
  %t135 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 5
  %t136 = load i1, ptr %l9, !tbaa !21
  store i1 %t136, ptr %t135, !tbaa !21
  %t137 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 6
  %t138 = load i1, ptr %l10, !tbaa !21
  store i1 %t138, ptr %t137, !tbaa !21
  %t139 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 7
  %t140 = load i1, ptr %l11, !tbaa !21
  store i1 %t140, ptr %t139, !tbaa !21
  %t141 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 8
  %t142 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t142, ptr %t141, !tbaa !27
  %t143 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 9
  %t144 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t144, ptr %t143
  %t145 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 10
  %t146 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l14
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t146, ptr %t145
  %t147 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 11
  %t148 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l15
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t148, ptr %t147
  %t149 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 12
  %t150 = load i64, ptr %l16, !tbaa !24
  store i64 %t150, ptr %t149, !tbaa !24
  %t151 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 13
  %t152 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l17
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t152, ptr %t151
  %t153 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 14
  %t154 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l18
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t154, ptr %t153
  %t155 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 15
  %t156 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t156, ptr %t155
  %t157 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 16
  %t158 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t158, ptr %t157
  %t159 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 17
  %t160 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l21
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t160, ptr %t159
  %t161 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 18
  %t162 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l22
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t162, ptr %t161
  %t163 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 19
  %t164 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l23
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t164, ptr %t163
  %t165 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 20
  %t166 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l24
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t166, ptr %t165
  %t167 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 21
  %t168 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t168, ptr %t167, !tbaa !27
  %t169 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 22
  %t170 = load i64, ptr %l26, !tbaa !24
  store i64 %t170, ptr %t169, !tbaa !24
  %t171 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 23
  %t172 = load i1, ptr %l27, !tbaa !21
  store i1 %t172, ptr %t171, !tbaa !21
  %t173 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 24
  %t174 = load i64, ptr %l28, !tbaa !24
  store i64 %t174, ptr %t173, !tbaa !24
  %t175 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 25
  %t176 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l29
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t176, ptr %t175
  %t177 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 26
  %t178 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l30
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t178, ptr %t177
  %t179 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 27
  %t180 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l31
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t180, ptr %t179
  %t181 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 28
  %t182 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l32
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t182, ptr %t181
  %t183 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 29
  %t184 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l33
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t184, ptr %t183
  %t185 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 30
  %t186 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l34
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t186, ptr %t185
  %t187 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 31
  %t188 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l35
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t188, ptr %t187
  %t189 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 32
  %t190 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l36
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t190, ptr %t189
  %t191 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 33
  %t192 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l37
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t192, ptr %t191
  %t193 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 34
  %t194 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l38
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t194, ptr %t193
  %t195 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 35
  %t196 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l39
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t196, ptr %t195
  %t197 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 36
  %t198 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l40
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t198, ptr %t197
  %t199 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 37
  %t200 = load i1, ptr %l41, !tbaa !21
  store i1 %t200, ptr %t199, !tbaa !21
  %t201 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 38
  %t202 = load i1, ptr %l42, !tbaa !21
  store i1 %t202, ptr %t201, !tbaa !21
  %t203 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 39
  %t204 = load i64, ptr %l43, !tbaa !24
  store i64 %t204, ptr %t203, !tbaa !24
  %t205 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 40
  %t206 = load i64, ptr %l44, !tbaa !24
  store i64 %t206, ptr %t205, !tbaa !24
  %t207 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 41
  %t208 = load i1, ptr %l45, !tbaa !21
  store i1 %t208, ptr %t207, !tbaa !21
  %t209 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 42
  %t210 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l46
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t210, ptr %t209
  %t211 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 43
  %t212 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l47
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t212, ptr %t211
  %t213 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 44
  %t214 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l48
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t214, ptr %t213
  %t215 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 45
  %t216 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t216, ptr %t215, !tbaa !27
  %t217 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 46
  %t218 = load i1, ptr %l50, !tbaa !21
  store i1 %t218, ptr %t217, !tbaa !21
  %t219 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 47
  %t220 = load i1, ptr %l51, !tbaa !21
  store i1 %t220, ptr %t219, !tbaa !21
  %t221 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 48
  %t222 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t222, ptr %t221, !tbaa !27
  %t223 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 49
  %t224 = load i1, ptr %l53, !tbaa !21
  store i1 %t224, ptr %t223, !tbaa !21
  %t225 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 50
  %t226 = load i64, ptr %l54, !tbaa !24
  store i64 %t226, ptr %t225, !tbaa !24
  %t227 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 51
  %t228 = load i64, ptr %l55, !tbaa !24
  store i64 %t228, ptr %t227, !tbaa !24
  %t229 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 52
  %t230 = load i64, ptr %l56, !tbaa !24
  store i64 %t230, ptr %t229, !tbaa !24
  %t231 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 53
  %t232 = load i64, ptr %l57, !tbaa !24
  store i64 %t232, ptr %t231, !tbaa !24
  %t233 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 54
  %t234 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l58
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t234, ptr %t233
  %t235 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 55
  %t236 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l59
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t236, ptr %t235
  %t237 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 56
  %t238 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l60
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t238, ptr %t237
  %t239 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 57
  %t240 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l61
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t240, ptr %t239
  %t241 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 58
  %t242 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l62
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t242, ptr %t241
  %t243 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 59
  %t244 = load i1, ptr %l63, !tbaa !21
  store i1 %t244, ptr %t243, !tbaa !21
  %t245 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 60
  %t246 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l64
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t246, ptr %t245
  %t247 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 61
  %t248 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l65
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t248, ptr %t247
  %t249 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 62
  %t250 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l66
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t250, ptr %t249
  %t251 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 63
  %t252 = load i1, ptr %l67, !tbaa !21
  store i1 %t252, ptr %t251, !tbaa !21
  %t253 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 64
  %t254 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l68
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t254, ptr %t253
  %t255 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 65
  %t256 = load i1, ptr %l69, !tbaa !21
  store i1 %t256, ptr %t255, !tbaa !21
  %t257 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 66
  %t258 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l70
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t258, ptr %t257
  %t259 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 67
  %t260 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l71
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t260, ptr %t259
  %t261 = getelementptr %"compiler/emit:Emitter", ptr %l116, i32 0, i32 68
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t124, ptr %t261
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l116, i64 544, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/emit:Object" @compiler_2femit_3aObject_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %rv = alloca %"compiler/emit:Object"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/emit:Object" undef, { i64, ptr } %a0, 0
  %t10 = insertvalue %"compiler/emit:Object" %t8, i32 %a1, 1
  %t12 = insertvalue %"compiler/emit:Object" %t10, { i64, ptr } %a2, 2
  %t14 = insertvalue %"compiler/emit:Object" %t12, i64 -1, 3
  store %"compiler/emit:Object" %t14, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/emit:Object", ptr %rv
  ret %"compiler/emit:Object" %rr
}

@.d0 = private constant [1 x i8] c"|"
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d1 = private constant [0 x i8] c""
@.d2 = private constant [1 x i8] c"<"
@.d3 = private constant [1 x i8] c">"
@.d4 = private constant [5 x i8] c".ctor"
@.d5 = private constant [5 x i8] c".dtor"
@.d6 = private constant [13 x i8] c"olang_lambda_"
declare i64 @__olang_fmt_i64(ptr, i64)
@.d7 = private constant [1 x i8] c"."
@.d8 = private constant [5 x i8] c".init"
@.d9 = private constant [11 x i8] c"olang_case_"
@.d10 = private constant [11 x i8] c"olang_cond_"
declare void @__olang_sb_put(ptr, ptr, i64)
@.d11 = private constant [10 x i8] c".contract."
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aContractKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 16, ptr @.d461 }, 1
  %t6 = extractvalue { i64, ptr } { i64 16, ptr @.d461 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
ret:
  ret void
}

@.d12 = private constant [1 x i8] c"."
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare void @__olang_sb_add(ptr, i64)
declare void @__olang_sb_done(ptr)
@.d13 = private constant [11 x i8] c"olang.slot."
@.d14 = private constant [1 x i8] c"."
@.d15 = private constant [16 x i8] c"olang.traitslot."
@.d16 = private constant [1 x i8] c"."
declare void @__olang_check_failed(ptr)
@.d17 = private constant [1 x i8] c"!"
@.d18 = private constant [1 x i8] c"!"
@.d19 = private constant [3 x i8] c" = "
@.d20 = private constant [1 x i8] c"\0A"
@.d21 = private constant [0 x i8] c""
@.d22 = private constant [4 x i8] c"void"
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare void @__olang_ert_req_clear()
@.d23 = private constant [11 x i8] c"olang_test_"
@.d24 = private constant [4 x i8] c"main"
@.d25 = private constant [8 x i8] c"|adapter"
@.d26 = private constant [0 x i8] c""
@.d27 = private constant [1 x i8] c"|"
@.d28 = private constant [1 x i8] c"f"
@.d29 = private constant [0 x i8] c""
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d30 = private constant [0 x i8] c""
@.d31 = private constant [0 x i8] c""
@.d32 = private constant [2 x i8] c"32"
@.d33 = private constant [2 x i8] c"64"
@.d34 = private constant [5 x i8] c"llvm."
@.d35 = private constant [2 x i8] c".f"
@.d36 = private constant [13 x i8] c"olang.notable"
@.d37 = private constant [48 x i8] c"@olang.notable = linkonce_odr constant ptr null\0A"
@.d38 = private constant [0 x i8] c""
@.d39 = private constant [13 x i8] c"olang.notable"
@.d40 = private constant [18 x i8] c"  %rhi = lshr i32 "
@.d41 = private constant [21 x i8] c", 16\0A  %rw = and i32 "
@.d42 = private constant [8 x i8] c", 65535\0A"
@.d43 = private constant [1 x i8] c"0"
@.d44 = private constant [5 x i8] c"  %rh"
@.d45 = private constant [21 x i8] c" = icmp eq i32 %rhi, "
@.d46 = private constant [1 x i8] c"\0A"
@.d47 = private constant [5 x i8] c"  %rp"
@.d48 = private constant [16 x i8] c" = select i1 %rh"
@.d49 = private constant [6 x i8] c", i32 "
@.d50 = private constant [6 x i8] c", i32 "
@.d51 = private constant [1 x i8] c"\0A"
@.d52 = private constant [3 x i8] c"%rp"
@.d53 = private constant [16 x i8] c"  %rs = shl i32 "
@.d54 = private constant [30 x i8] c", 16\0A  %rv2 = or i32 %rs, %rw\0A"
@.d55 = private constant [4 x i8] c"%rv2"
@.d56 = private constant [66 x i8] c"the runtime's text (std/runtime/runtime.ll could not be filled in)"
@.d57 = private constant [0 x i8] c""
@.d58 = private constant [0 x i8] c""
@.d59 = private constant [1 x i8] c"}"
@.d60 = private constant [0 x i8] c""
@.d61 = private constant [1 x i8] c"%"
@.d62 = private constant [0 x i8] c""
@.d63 = private constant [7 x i8] c"define "
@.d64 = private constant [1 x i8] c"\0A"
@.d65 = private constant [0 x i8] c""
@.d66 = private constant [50 x i8] c"%olang.builder = type { ptr, i64, i64, ptr, ptr }\0A"
@.d67 = private constant [3 x i8] c"ptr"
@.d68 = private constant [15 x i8] c"an unknown type"
@.d69 = private constant [2 x i8] c"i8"
@.d70 = private constant [23 x i8] c"a type with no layout: "
@.d71 = private constant [15 x i8] c"bitcast bfloat "
@.d72 = private constant [7 x i8] c" to i16"
@.d73 = private constant [0 x i8] c""
@.d74 = private constant [26 x i8] c"extractvalue { ptr, ptr } "
@.d75 = private constant [3 x i8] c", 0"
@.d76 = private constant [26 x i8] c"extractvalue { ptr, ptr } "
@.d77 = private constant [3 x i8] c", 1"
@.d78 = private constant [4 x i8] c"ptr "
@.d79 = private constant [6 x i8] c", ptr "
@.d80 = private constant [4 x i8] c"ptr "
@.d81 = private constant [1 x i8] c" "
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aOperand(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %l8 = alloca i1
  %l26 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb16
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 i64 3, label %bb6 ]
bb3:
  br label %bb16
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { %"compiler/mir:Place" }, ptr %t11, i32 0, i32 0
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr { i64, [4 x i64] }, ptr %t13, i32 0, i32 1
  %t15 = getelementptr { %"compiler/mir:Place" }, ptr %t14, i32 0, i32 0
  %t18 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aPlace(ptr %t12, ptr %t15)
  store i1 %t18, ptr %l8
  br label %bb7
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t21 = getelementptr { i32, i64 }, ptr %t20, i32 0, i32 0
  %t22 = load i32, ptr %t21
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t23, i32 0, i32 1
  %t25 = getelementptr { i32, i64 }, ptr %t24, i32 0, i32 0
  %t26 = load i32, ptr %t25
  %t29 = icmp eq i32 %t22, %t26
  br i1 %t29, label %bb9, label %bb1
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t33 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t32, i32 0, i32 0
  %t34 = load i32, ptr %t33
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr { i64, [4 x i64] }, ptr %t35, i32 0, i32 1
  %t37 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t36, i32 0, i32 0
  %t38 = load i32, ptr %t37
  %t41 = icmp eq i32 %t34, %t38
  br i1 %t41, label %bb11, label %bb1
bb7:
  %t43 = load i1, ptr %l8, !tbaa !21
  br i1 %t43, label %bb8, label %bb1
bb8:
  br label %bb3
bb9:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 1
  %t46 = getelementptr { i32, i64 }, ptr %t45, i32 0, i32 1
  %t47 = load i64, ptr %t46
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr { i64, [4 x i64] }, ptr %t48, i32 0, i32 1
  %t50 = getelementptr { i32, i64 }, ptr %t49, i32 0, i32 1
  %t51 = load i64, ptr %t50
  %t54 = icmp eq i64 %t47, %t51
  br i1 %t54, label %bb10, label %bb1
bb10:
  br label %bb3
bb11:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t56, i32 0, i32 1
  %t58 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t57, i32 0, i32 1
  %t59 = load i32, ptr %t58
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t60, i32 0, i32 1
  %t62 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t61, i32 0, i32 1
  %t63 = load i32, ptr %t62
  %t66 = icmp eq i32 %t59, %t63
  br i1 %t66, label %bb12, label %bb1
bb12:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 1
  %t70 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t69, i32 0, i32 2
  %t71 = load i64, ptr %t70
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr { i64, [4 x i64] }, ptr %t72, i32 0, i32 1
  %t74 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t73, i32 0, i32 2
  %t75 = load i64, ptr %t74
  %t78 = icmp eq i64 %t71, %t75
  br i1 %t78, label %bb13, label %bb1
bb13:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr { i64, [4 x i64] }, ptr %t80, i32 0, i32 1
  %t82 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t81, i32 0, i32 3
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr { i64, [4 x i64] }, ptr %t83, i32 0, i32 1
  %t85 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t84, i32 0, i32 3
  %t88 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %t82, ptr %t85)
  store i1 %t88, ptr %l26
  br label %bb14
bb14:
  %t89 = load i1, ptr %l26, !tbaa !21
  br i1 %t89, label %bb15, label %bb1
bb15:
  br label %bb3
bb16:
  %t90 = load i1, ptr %l2, !tbaa !21
  store i1 %t90, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d82 = private constant [4 x i8] c"fill"
@.d83 = private constant [4 x i8] c"fill"
@.d84 = private constant [4 x i8] c"fill"
@.d85 = private constant [4 x i8] c"fill"
@.d86 = private constant [10 x i8] c"br label %"
@.d87 = private constant [10 x i8] c"br label %"
@.d88 = private constant [17 x i8] c" = phi i64 [ 0, %"
@.d89 = private constant [6 x i8] c" ], [ "
@.d90 = private constant [3 x i8] c", %"
@.d91 = private constant [2 x i8] c" ]"
@.d92 = private constant [13 x i8] c"icmp slt i64 "
@.d93 = private constant [2 x i8] c", "
@.d94 = private constant [6 x i8] c"br i1 "
@.d95 = private constant [9 x i8] c", label %"
@.d96 = private constant [9 x i8] c", label %"
@.d97 = private constant [14 x i8] c"getelementptr "
@.d98 = private constant [6 x i8] c", ptr "
@.d99 = private constant [13 x i8] c", i64 0, i64 "
@.d100 = private constant [0 x i8] c""
@.d101 = private constant [11 x i8] c" = add i64 "
@.d102 = private constant [3 x i8] c", 1"
@.d103 = private constant [10 x i8] c"br label %"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d104 = private constant [14 x i8] c"getelementptr "
@.d105 = private constant [6 x i8] c", ptr "
@.d106 = private constant [13 x i8] c", i64 0, i64 "
@.d107 = private constant [0 x i8] c""
@.d108 = private constant [22 x i8] c"llvm.memmove.p0.p0.i64"
@.d109 = private constant [47 x i8] c"void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)"
@.d110 = private constant [38 x i8] c"call void @llvm.memmove.p0.p0.i64(ptr "
@.d111 = private constant [6 x i8] c", ptr "
@.d112 = private constant [6 x i8] c", i64 "
@.d113 = private constant [11 x i8] c", i1 false)"
@.d114 = private constant [5 x i8] c"load "
@.d115 = private constant [6 x i8] c", ptr "
@.d116 = private constant [14 x i8] c"bitcast float "
@.d117 = private constant [7 x i8] c" to i32"
@.d118 = private constant [9 x i8] c"lshr i32 "
@.d119 = private constant [4 x i8] c", 16"
@.d120 = private constant [8 x i8] c"and i32 "
@.d121 = private constant [3 x i8] c", 1"
@.d122 = private constant [8 x i8] c"add i32 "
@.d123 = private constant [7 x i8] c", 32767"
@.d124 = private constant [8 x i8] c"add i32 "
@.d125 = private constant [2 x i8] c", "
@.d126 = private constant [9 x i8] c"lshr i32 "
@.d127 = private constant [4 x i8] c", 16"
@.d128 = private constant [7 x i8] c"or i32 "
@.d129 = private constant [4 x i8] c", 64"
@.d130 = private constant [8 x i8] c"and i32 "
@.d131 = private constant [12 x i8] c", 2147483647"
@.d132 = private constant [13 x i8] c"icmp ugt i32 "
@.d133 = private constant [12 x i8] c", 2139095040"
@.d134 = private constant [10 x i8] c"select i1 "
@.d135 = private constant [6 x i8] c", i32 "
@.d136 = private constant [6 x i8] c", i32 "
@.d137 = private constant [10 x i8] c"trunc i32 "
@.d138 = private constant [7 x i8] c" to i16"
@.d139 = private constant [12 x i8] c"bitcast i16 "
@.d140 = private constant [10 x i8] c" to bfloat"
@.d141 = private constant [8 x i8] c"mul i64 "
@.d142 = private constant [2 x i8] c", "
@.d143 = private constant [0 x i8] c""
@.d144 = private constant [21 x i8] c"__olang_san_alloc_own"
@.d145 = private constant [36 x i8] c"call ptr @__olang_san_alloc_own(ptr "
@.d146 = private constant [6 x i8] c", i64 "
@.d147 = private constant [1 x i8] c")"
@.d148 = private constant [26 x i8] c"__olang_scope_alloc_zeroed"
@.d149 = private constant [41 x i8] c"call ptr @__olang_scope_alloc_zeroed(ptr "
@.d150 = private constant [6 x i8] c", i64 "
@.d151 = private constant [1 x i8] c")"
@.d152 = private constant [0 x i8] c""
@.d153 = private constant [19 x i8] c"__olang_scope_alloc"
@.d154 = private constant [34 x i8] c"call ptr @__olang_scope_alloc(ptr "
@.d155 = private constant [6 x i8] c", i64 "
@.d156 = private constant [1 x i8] c")"
@.d157 = private constant [0 x i8] c""
@.d158 = private constant [3 x i8] c"i64"
@.d159 = private constant [3 x i8] c"i64"
@.d160 = private constant [1 x i8] c"0"
@.d161 = private constant [0 x i8] c""
@.d162 = private constant [4 x i8] c"fill"
@.d163 = private constant [5 x i8] c"fillb"
@.d164 = private constant [5 x i8] c"filld"
@.d165 = private constant [10 x i8] c"br label %"
@.d166 = private constant [3 x i8] c"i64"
@.d167 = private constant [0 x i8] c""
@.d168 = private constant [13 x i8] c"icmp slt i64 "
@.d169 = private constant [2 x i8] c", "
@.d170 = private constant [6 x i8] c"br i1 "
@.d171 = private constant [9 x i8] c", label %"
@.d172 = private constant [9 x i8] c", label %"
@.d173 = private constant [14 x i8] c"getelementptr "
@.d174 = private constant [6 x i8] c", ptr "
@.d175 = private constant [6 x i8] c", i64 "
@.d176 = private constant [0 x i8] c""
@.d177 = private constant [0 x i8] c""
@.d178 = private constant [8 x i8] c"add i64 "
@.d179 = private constant [3 x i8] c", 1"
@.d180 = private constant [3 x i8] c"i64"
@.d181 = private constant [0 x i8] c""
@.d182 = private constant [10 x i8] c"br label %"
@.d183 = private constant [6 x i8] c"bfloat"
@.d184 = private constant [15 x i8] c"bitcast bfloat "
@.d185 = private constant [7 x i8] c" to i16"
@.d186 = private constant [8 x i8] c"xor i16 "
@.d187 = private constant [8 x i8] c", -32768"
@.d188 = private constant [12 x i8] c"bitcast i16 "
@.d189 = private constant [10 x i8] c" to bfloat"
@.d190 = private constant [5 x i8] c"fneg "
@.d191 = private constant [1 x i8] c" "
@.d192 = private constant [4 x i8] c"sub "
@.d193 = private constant [4 x i8] c" 0, "
@.d194 = private constant [4 x i8] c"true"
@.d195 = private constant [2 x i8] c"-1"
@.d196 = private constant [4 x i8] c"xor "
@.d197 = private constant [1 x i8] c" "
@.d198 = private constant [2 x i8] c", "
@.d199 = private constant [7 x i8] c"xor i1 "
@.d200 = private constant [6 x i8] c", true"
@.d201 = private constant [20 x i8] c"an any with no table"
@.d202 = private constant [15 x i8] c"zeroinitializer"
@.d203 = private constant [36 x i8] c"insertvalue { ptr, ptr } undef, ptr "
@.d204 = private constant [3 x i8] c", 0"
@.d205 = private constant [12 x i8] c"icmp ne ptr "
@.d206 = private constant [6 x i8] c", null"
@.d207 = private constant [10 x i8] c"select i1 "
@.d208 = private constant [7 x i8] c", ptr @"
@.d209 = private constant [10 x i8] c", ptr null"
@.d210 = private constant [25 x i8] c"insertvalue { ptr, ptr } "
@.d211 = private constant [6 x i8] c", ptr "
@.d212 = private constant [3 x i8] c", 1"
@.d213 = private constant [26 x i8] c"extractvalue { ptr, ptr } "
@.d214 = private constant [3 x i8] c", 0"
@.d215 = private constant [26 x i8] c"extractvalue { ptr, ptr } "
@.d216 = private constant [3 x i8] c", 1"
@.d217 = private constant [12 x i8] c"icmp ne ptr "
@.d218 = private constant [6 x i8] c", null"
@.d219 = private constant [10 x i8] c"select i1 "
@.d220 = private constant [6 x i8] c", ptr "
@.d221 = private constant [7 x i8] c", ptr @"
@.d222 = private constant [14 x i8] c"load ptr, ptr "
@.d223 = private constant [12 x i8] c"icmp eq ptr "
@.d224 = private constant [3 x i8] c", @"
@.d225 = private constant [26 x i8] c"extractvalue { i64, ptr } "
@.d226 = private constant [3 x i8] c", 0"
@.d227 = private constant [26 x i8] c"extractvalue { i64, ptr } "
@.d228 = private constant [3 x i8] c", 1"
@.d229 = private constant [8 x i8] c"mul i64 "
@.d230 = private constant [2 x i8] c", "
@.d231 = private constant [18 x i8] c"__olang_san_retire"
@.d232 = private constant [34 x i8] c"call void @__olang_san_retire(ptr "
@.d233 = private constant [6 x i8] c", i64 "
@.d234 = private constant [1 x i8] c")"
@.d235 = private constant [5 x i8] c"undef"
@.d236 = private constant [26 x i8] c"extractvalue { i64, ptr } "
@.d237 = private constant [3 x i8] c", 0"
@.d238 = private constant [12 x i8] c"load atomic "
@.d239 = private constant [6 x i8] c", ptr "
@.d240 = private constant [16 x i8] c" seq_cst, align "
@.d241 = private constant [5 x i8] c"ctpop"
@.d242 = private constant [4 x i8] c"ctlz"
@.d243 = private constant [4 x i8] c"cttz"
@.d244 = private constant [5 x i8] c"llvm."
@.d245 = private constant [1 x i8] c"."
@.d246 = private constant [5 x i8] c"ctpop"
@.d247 = private constant [5 x i8] c", i1)"
@.d248 = private constant [1 x i8] c")"
@.d249 = private constant [2 x i8] c" @"
@.d250 = private constant [1 x i8] c"("
@.d251 = private constant [5 x i8] c"ctpop"
@.d252 = private constant [11 x i8] c", i1 false)"
@.d253 = private constant [1 x i8] c")"
@.d254 = private constant [5 x i8] c"call "
@.d255 = private constant [2 x i8] c" @"
@.d256 = private constant [1 x i8] c"("
@.d257 = private constant [1 x i8] c" "
@.d258 = private constant [11 x i8] c"llvm.bswap."
@.d259 = private constant [2 x i8] c" @"
@.d260 = private constant [1 x i8] c"("
@.d261 = private constant [1 x i8] c")"
@.d262 = private constant [5 x i8] c"call "
@.d263 = private constant [2 x i8] c" @"
@.d264 = private constant [1 x i8] c"("
@.d265 = private constant [1 x i8] c" "
@.d266 = private constant [1 x i8] c")"
@.d267 = private constant [1 x i8] c"l"
@.d268 = private constant [1 x i8] c"r"
@.d269 = private constant [8 x i8] c"llvm.fsh"
@.d270 = private constant [1 x i8] c"."
@.d271 = private constant [2 x i8] c" @"
@.d272 = private constant [1 x i8] c"("
@.d273 = private constant [2 x i8] c", "
@.d274 = private constant [2 x i8] c", "
@.d275 = private constant [1 x i8] c")"
@.d276 = private constant [5 x i8] c"call "
@.d277 = private constant [2 x i8] c" @"
@.d278 = private constant [1 x i8] c"("
@.d279 = private constant [1 x i8] c" "
@.d280 = private constant [2 x i8] c", "
@.d281 = private constant [1 x i8] c" "
@.d282 = private constant [2 x i8] c", "
@.d283 = private constant [1 x i8] c" "
@.d284 = private constant [1 x i8] c")"
@.d285 = private constant [6 x i8] c"bfloat"
@.d286 = private constant [5 x i8] c"float"
@.d287 = private constant [5 x i8] c"float"
@.d288 = private constant [4 x i8] c"fadd"
@.d289 = private constant [4 x i8] c"fsub"
@.d290 = private constant [4 x i8] c"fmul"
@.d291 = private constant [4 x i8] c"fdiv"
@.d292 = private constant [4 x i8] c"frem"
@.d293 = private constant [0 x i8] c""
@.d294 = private constant [0 x i8] c""
@.d295 = private constant [7 x i8] c" float "
@.d296 = private constant [2 x i8] c", "
@.d297 = private constant [5 x i8] c"fadd "
@.d298 = private constant [4 x i8] c"add "
@.d299 = private constant [1 x i8] c" "
@.d300 = private constant [2 x i8] c", "
@.d301 = private constant [5 x i8] c"fsub "
@.d302 = private constant [4 x i8] c"sub "
@.d303 = private constant [1 x i8] c" "
@.d304 = private constant [2 x i8] c", "
@.d305 = private constant [5 x i8] c"fmul "
@.d306 = private constant [4 x i8] c"mul "
@.d307 = private constant [1 x i8] c" "
@.d308 = private constant [2 x i8] c", "
@.d309 = private constant [5 x i8] c"fdiv "
@.d310 = private constant [5 x i8] c"udiv "
@.d311 = private constant [5 x i8] c"sdiv "
@.d312 = private constant [1 x i8] c" "
@.d313 = private constant [2 x i8] c", "
@.d314 = private constant [5 x i8] c"frem "
@.d315 = private constant [5 x i8] c"urem "
@.d316 = private constant [5 x i8] c"srem "
@.d317 = private constant [1 x i8] c" "
@.d318 = private constant [2 x i8] c", "
@.d319 = private constant [4 x i8] c"shl "
@.d320 = private constant [5 x i8] c"lshr "
@.d321 = private constant [5 x i8] c"ashr "
@.d322 = private constant [1 x i8] c" "
@.d323 = private constant [2 x i8] c", "
@.d324 = private constant [4 x i8] c"and "
@.d325 = private constant [1 x i8] c" "
@.d326 = private constant [2 x i8] c", "
@.d327 = private constant [3 x i8] c"or "
@.d328 = private constant [1 x i8] c" "
@.d329 = private constant [2 x i8] c", "
@.d330 = private constant [4 x i8] c"xor "
@.d331 = private constant [1 x i8] c" "
@.d332 = private constant [2 x i8] c", "
@.d333 = private constant [12 x i8] c"{ i64, ptr }"
@.d334 = private constant [12 x i8] c"{ ptr, ptr }"
@.d335 = private constant [12 x i8] c"{ i64, ptr }"
@.d336 = private constant [4 x i8] c"i64 "
@.d337 = private constant [4 x i8] c"ptr "
@.d338 = private constant [13 x i8] c"extractvalue "
@.d339 = private constant [1 x i8] c" "
@.d340 = private constant [3 x i8] c", 0"
@.d341 = private constant [13 x i8] c"extractvalue "
@.d342 = private constant [1 x i8] c" "
@.d343 = private constant [3 x i8] c", 0"
@.d344 = private constant [8 x i8] c"icmp eq "
@.d345 = private constant [2 x i8] c", "
@.d346 = private constant [13 x i8] c"extractvalue "
@.d347 = private constant [1 x i8] c" "
@.d348 = private constant [3 x i8] c", 1"
@.d349 = private constant [13 x i8] c"extractvalue "
@.d350 = private constant [1 x i8] c" "
@.d351 = private constant [3 x i8] c", 1"
@.d352 = private constant [12 x i8] c"icmp eq ptr "
@.d353 = private constant [2 x i8] c", "
@.d354 = private constant [7 x i8] c"and i1 "
@.d355 = private constant [2 x i8] c", "
@.d356 = private constant [8 x i8] c"icmp eq "
@.d357 = private constant [1 x i8] c" "
@.d358 = private constant [2 x i8] c", "
@.d359 = private constant [13 x i8] c"extractvalue "
@.d360 = private constant [1 x i8] c" "
@.d361 = private constant [3 x i8] c", 0"
@.d362 = private constant [12 x i8] c"icmp eq i64 "
@.d363 = private constant [2 x i8] c", "
@.d364 = private constant [10 x i8] c"trunc i64 "
@.d365 = private constant [7 x i8] c" to i32"
@.d366 = private constant [12 x i8] c"icmp eq i32 "
@.d367 = private constant [2 x i8] c", "
@.d368 = private constant [13 x i8] c"store atomic "
@.d369 = private constant [1 x i8] c" "
@.d370 = private constant [6 x i8] c", ptr "
@.d371 = private constant [16 x i8] c" seq_cst, align "
@.d372 = private constant [5 x i8] c"undef"
@.d373 = private constant [3 x i8] c"add"
@.d374 = private constant [4 x i8] c"xchg"
@.d375 = private constant [10 x i8] c"atomicrmw "
@.d376 = private constant [5 x i8] c" ptr "
@.d377 = private constant [2 x i8] c", "
@.d378 = private constant [1 x i8] c" "
@.d379 = private constant [8 x i8] c" seq_cst"
@.d380 = private constant [12 x i8] c"cmpxchg ptr "
@.d381 = private constant [2 x i8] c", "
@.d382 = private constant [1 x i8] c" "
@.d383 = private constant [2 x i8] c", "
@.d384 = private constant [1 x i8] c" "
@.d385 = private constant [16 x i8] c" seq_cst seq_cst"
@.d386 = private constant [15 x i8] c"extractvalue { "
@.d387 = private constant [7 x i8] c", i1 } "
@.d388 = private constant [3 x i8] c", 0"
@.d389 = private constant [14 x i8] c"the operation "
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 i64 7, label %bb9 i64 8, label %bb10 i64 9, label %bb11 i64 10, label %bb12 i64 11, label %bb13 i64 12, label %bb14 i64 13, label %bb15 i64 14, label %bb16 i64 15, label %bb17 i64 16, label %bb18 i64 17, label %bb19 i64 18, label %bb20 i64 19, label %bb21 i64 20, label %bb22 i64 21, label %bb23 i64 22, label %bb24 i64 23, label %bb25 i64 24, label %bb26 i64 25, label %bb27 i64 26, label %bb28 i64 27, label %bb29 i64 28, label %bb30 i64 29, label %bb31 i64 30, label %bb32 i64 31, label %bb33 i64 32, label %bb34 i64 33, label %bb35 i64 34, label %bb36 i64 35, label %bb37 i64 36, label %bb38 i64 37, label %bb39 i64 38, label %bb40 i64 39, label %bb41 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 10, ptr @.d462 }, 1
  %t6 = extractvalue { i64, ptr } { i64 10, ptr @.d462 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 13, ptr @.d463 }, 1
  %t8 = extractvalue { i64, ptr } { i64 13, ptr @.d463 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 10, ptr @.d464 }, 1
  %t10 = extractvalue { i64, ptr } { i64 10, ptr @.d464 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 10, ptr @.d465 }, 1
  %t12 = extractvalue { i64, ptr } { i64 10, ptr @.d465 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
bb6:
  %t13 = extractvalue { i64, ptr } { i64 10, ptr @.d466 }, 1
  %t14 = extractvalue { i64, ptr } { i64 10, ptr @.d466 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t13, i64 %t14)
  br label %bb1
bb7:
  %t15 = extractvalue { i64, ptr } { i64 10, ptr @.d467 }, 1
  %t16 = extractvalue { i64, ptr } { i64 10, ptr @.d467 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t15, i64 %t16)
  br label %bb1
bb8:
  %t17 = extractvalue { i64, ptr } { i64 10, ptr @.d468 }, 1
  %t18 = extractvalue { i64, ptr } { i64 10, ptr @.d468 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t17, i64 %t18)
  br label %bb1
bb9:
  %t19 = extractvalue { i64, ptr } { i64 10, ptr @.d469 }, 1
  %t20 = extractvalue { i64, ptr } { i64 10, ptr @.d469 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t19, i64 %t20)
  br label %bb1
bb10:
  %t21 = extractvalue { i64, ptr } { i64 10, ptr @.d470 }, 1
  %t22 = extractvalue { i64, ptr } { i64 10, ptr @.d470 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t21, i64 %t22)
  br label %bb1
bb11:
  %t23 = extractvalue { i64, ptr } { i64 10, ptr @.d471 }, 1
  %t24 = extractvalue { i64, ptr } { i64 10, ptr @.d471 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t23, i64 %t24)
  br label %bb1
bb12:
  %t25 = extractvalue { i64, ptr } { i64 13, ptr @.d472 }, 1
  %t26 = extractvalue { i64, ptr } { i64 13, ptr @.d472 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t25, i64 %t26)
  br label %bb1
bb13:
  %t27 = extractvalue { i64, ptr } { i64 12, ptr @.d473 }, 1
  %t28 = extractvalue { i64, ptr } { i64 12, ptr @.d473 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t27, i64 %t28)
  br label %bb1
bb14:
  %t29 = extractvalue { i64, ptr } { i64 13, ptr @.d474 }, 1
  %t30 = extractvalue { i64, ptr } { i64 13, ptr @.d474 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t29, i64 %t30)
  br label %bb1
bb15:
  %t31 = extractvalue { i64, ptr } { i64 9, ptr @.d475 }, 1
  %t32 = extractvalue { i64, ptr } { i64 9, ptr @.d475 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t31, i64 %t32)
  br label %bb1
bb16:
  %t33 = extractvalue { i64, ptr } { i64 9, ptr @.d476 }, 1
  %t34 = extractvalue { i64, ptr } { i64 9, ptr @.d476 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t33, i64 %t34)
  br label %bb1
bb17:
  %t35 = extractvalue { i64, ptr } { i64 9, ptr @.d477 }, 1
  %t36 = extractvalue { i64, ptr } { i64 9, ptr @.d477 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t35, i64 %t36)
  br label %bb1
bb18:
  %t37 = extractvalue { i64, ptr } { i64 9, ptr @.d478 }, 1
  %t38 = extractvalue { i64, ptr } { i64 9, ptr @.d478 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t37, i64 %t38)
  br label %bb1
bb19:
  %t39 = extractvalue { i64, ptr } { i64 9, ptr @.d479 }, 1
  %t40 = extractvalue { i64, ptr } { i64 9, ptr @.d479 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t39, i64 %t40)
  br label %bb1
bb20:
  %t41 = extractvalue { i64, ptr } { i64 9, ptr @.d480 }, 1
  %t42 = extractvalue { i64, ptr } { i64 9, ptr @.d480 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t41, i64 %t42)
  br label %bb1
bb21:
  %t43 = extractvalue { i64, ptr } { i64 11, ptr @.d481 }, 1
  %t44 = extractvalue { i64, ptr } { i64 11, ptr @.d481 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t43, i64 %t44)
  br label %bb1
bb22:
  %t45 = extractvalue { i64, ptr } { i64 14, ptr @.d482 }, 1
  %t46 = extractvalue { i64, ptr } { i64 14, ptr @.d482 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t45, i64 %t46)
  br label %bb1
bb23:
  %t47 = extractvalue { i64, ptr } { i64 14, ptr @.d483 }, 1
  %t48 = extractvalue { i64, ptr } { i64 14, ptr @.d483 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t47, i64 %t48)
  br label %bb1
bb24:
  %t49 = extractvalue { i64, ptr } { i64 10, ptr @.d484 }, 1
  %t50 = extractvalue { i64, ptr } { i64 10, ptr @.d484 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t49, i64 %t50)
  br label %bb1
bb25:
  %t51 = extractvalue { i64, ptr } { i64 13, ptr @.d485 }, 1
  %t52 = extractvalue { i64, ptr } { i64 13, ptr @.d485 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t51, i64 %t52)
  br label %bb1
bb26:
  %t53 = extractvalue { i64, ptr } { i64 17, ptr @.d486 }, 1
  %t54 = extractvalue { i64, ptr } { i64 17, ptr @.d486 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t53, i64 %t54)
  br label %bb1
bb27:
  %t55 = extractvalue { i64, ptr } { i64 18, ptr @.d487 }, 1
  %t56 = extractvalue { i64, ptr } { i64 18, ptr @.d487 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t55, i64 %t56)
  br label %bb1
bb28:
  %t57 = extractvalue { i64, ptr } { i64 16, ptr @.d488 }, 1
  %t58 = extractvalue { i64, ptr } { i64 16, ptr @.d488 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t57, i64 %t58)
  br label %bb1
bb29:
  %t59 = extractvalue { i64, ptr } { i64 17, ptr @.d489 }, 1
  %t60 = extractvalue { i64, ptr } { i64 17, ptr @.d489 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t59, i64 %t60)
  br label %bb1
bb30:
  %t61 = extractvalue { i64, ptr } { i64 24, ptr @.d490 }, 1
  %t62 = extractvalue { i64, ptr } { i64 24, ptr @.d490 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t61, i64 %t62)
  br label %bb1
bb31:
  %t63 = extractvalue { i64, ptr } { i64 13, ptr @.d491 }, 1
  %t64 = extractvalue { i64, ptr } { i64 13, ptr @.d491 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t63, i64 %t64)
  br label %bb1
bb32:
  %t65 = extractvalue { i64, ptr } { i64 19, ptr @.d492 }, 1
  %t66 = extractvalue { i64, ptr } { i64 19, ptr @.d492 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t65, i64 %t66)
  br label %bb1
bb33:
  %t67 = extractvalue { i64, ptr } { i64 20, ptr @.d493 }, 1
  %t68 = extractvalue { i64, ptr } { i64 20, ptr @.d493 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t67, i64 %t68)
  br label %bb1
bb34:
  %t69 = extractvalue { i64, ptr } { i64 15, ptr @.d494 }, 1
  %t70 = extractvalue { i64, ptr } { i64 15, ptr @.d494 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t69, i64 %t70)
  br label %bb1
bb35:
  %t71 = extractvalue { i64, ptr } { i64 17, ptr @.d495 }, 1
  %t72 = extractvalue { i64, ptr } { i64 17, ptr @.d495 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t71, i64 %t72)
  br label %bb1
bb36:
  %t73 = extractvalue { i64, ptr } { i64 18, ptr @.d496 }, 1
  %t74 = extractvalue { i64, ptr } { i64 18, ptr @.d496 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t73, i64 %t74)
  br label %bb1
bb37:
  %t75 = extractvalue { i64, ptr } { i64 15, ptr @.d497 }, 1
  %t76 = extractvalue { i64, ptr } { i64 15, ptr @.d497 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t75, i64 %t76)
  br label %bb1
bb38:
  %t77 = extractvalue { i64, ptr } { i64 12, ptr @.d498 }, 1
  %t78 = extractvalue { i64, ptr } { i64 12, ptr @.d498 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t77, i64 %t78)
  br label %bb1
bb39:
  %t79 = extractvalue { i64, ptr } { i64 14, ptr @.d499 }, 1
  %t80 = extractvalue { i64, ptr } { i64 14, ptr @.d499 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t79, i64 %t80)
  br label %bb1
bb40:
  %t81 = extractvalue { i64, ptr } { i64 18, ptr @.d500 }, 1
  %t82 = extractvalue { i64, ptr } { i64 18, ptr @.d500 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t81, i64 %t82)
  br label %bb1
bb41:
  %t83 = extractvalue { i64, ptr } { i64 12, ptr @.d501 }, 1
  %t84 = extractvalue { i64, ptr } { i64 12, ptr @.d501 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t83, i64 %t84)
  br label %bb1
ret:
  ret void
}

@.d390 = private constant [5 x i8] c"undef"
@.d391 = private constant [16 x i8] c"__olang_rd_quote"
@.d392 = private constant [15 x i8] c"__olang_sb_room"
@.d393 = private constant [14 x i8] c"__olang_sb_add"
@.d394 = private constant [48 x i8] c"call i64 @__olang_rd_quote(ptr null, i64 0, ptr "
@.d395 = private constant [6 x i8] c", i64 "
@.d396 = private constant [5 x i8] c", i8 "
@.d397 = private constant [1 x i8] c")"
@.d398 = private constant [30 x i8] c"call ptr @__olang_sb_room(ptr "
@.d399 = private constant [6 x i8] c", i64 "
@.d400 = private constant [1 x i8] c")"
@.d401 = private constant [31 x i8] c"call i64 @__olang_rd_quote(ptr "
@.d402 = private constant [13 x i8] c", i64 0, ptr "
@.d403 = private constant [6 x i8] c", i64 "
@.d404 = private constant [5 x i8] c", i8 "
@.d405 = private constant [1 x i8] c")"
@.d406 = private constant [30 x i8] c"call void @__olang_sb_add(ptr "
@.d407 = private constant [6 x i8] c", i64 "
@.d408 = private constant [1 x i8] c")"
@.d409 = private constant [0 x i8] c""
@.d410 = private constant [0 x i8] c""
@.d411 = private constant [3 x i8] c"i64"
@.d412 = private constant [0 x i8] c""
@.d413 = private constant [3 x i8] c"i32"
@.d414 = private constant [0 x i8] c""
@.d415 = private constant [9 x i8] c"sext i32 "
@.d416 = private constant [7 x i8] c" to i64"
@.d417 = private constant [0 x i8] c""
@.d418 = private constant [0 x i8] c""
@.d419 = private constant [3 x i8] c"ptr"
@.d420 = private constant [0 x i8] c""
@.d421 = private constant [34 x i8] c"getelementptr %olang.builder, ptr "
@.d422 = private constant [14 x i8] c", i32 0, i32 1"
@.d423 = private constant [3 x i8] c"i64"
@.d424 = private constant [0 x i8] c""
@.d425 = private constant [19 x i8] c"__olang_scope_alloc"
@.d426 = private constant [34 x i8] c"call ptr @__olang_scope_alloc(ptr "
@.d427 = private constant [6 x i8] c", i64 "
@.d428 = private constant [1 x i8] c")"
@.d429 = private constant [30 x i8] c"call void @olang_textcopy(ptr "
@.d430 = private constant [6 x i8] c", ptr "
@.d431 = private constant [6 x i8] c", i64 "
@.d432 = private constant [1 x i8] c")"
@.d433 = private constant [18 x i8] c"__olang_unwind_top"
@.d434 = private constant [67 x i8] c"@__olang_unwind_top = external thread_local(initialexec) global ptr"
@.d435 = private constant [3 x i8] c"ptr"
@.d436 = private constant [19 x i8] c"@__olang_unwind_top"
@.d437 = private constant [0 x i8] c""
@.d438 = private constant [35 x i8] c"getelementptr %olang.unwind, ptr %u"
@.d439 = private constant [14 x i8] c", i32 0, i32 0"
@.d440 = private constant [3 x i8] c"ptr"
@.d441 = private constant [0 x i8] c""
@.d442 = private constant [2 x i8] c"%s"
@.d443 = private constant [35 x i8] c"getelementptr %olang.unwind, ptr %u"
@.d444 = private constant [14 x i8] c", i32 0, i32 1"
@.d445 = private constant [3 x i8] c"ptr"
@.d446 = private constant [0 x i8] c""
@.d447 = private constant [3 x i8] c"%jh"
@.d448 = private constant [4 x i8] c"null"
@.d449 = private constant [35 x i8] c"getelementptr %olang.unwind, ptr %u"
@.d450 = private constant [14 x i8] c", i32 0, i32 2"
@.d451 = private constant [3 x i8] c"ptr"
@.d452 = private constant [0 x i8] c""
@.d453 = private constant [2 x i8] c"%u"
@.d454 = private constant [3 x i8] c"ptr"
@.d455 = private constant [19 x i8] c"@__olang_unwind_top"
@.d456 = private constant [0 x i8] c""
@.d457 = private constant [0 x i8] c""
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d458 = private constant [19 x i8] c"x86_64-pc-linux-gnu"
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_Hf48d6d4096e547b8075d5a903caa3d54(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d459 = private constant [6 x i8] c"x86_64"
@.d460 = private constant [0 x i8] c""
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@.d461 = private unnamed_addr constant [16 x i8] c"ContractKind.Req"
declare ptr @__olang_sb_grow(ptr, i64) noinline
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aPlace(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l5 = alloca i1
  %l8 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/mir:Place", ptr %t1, i32 0, i32 0
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/mir:Place", ptr %t3, i32 0, i32 0
  %t7 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aBase(ptr %t2, ptr %t4)
  store i1 %t7, ptr %l5
  br label %bb2
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb6
bb2:
  %t8 = load i1, ptr %l5, !tbaa !21
  br i1 %t8, label %bb3, label %bb1
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/mir:Place", ptr %t9, i32 0, i32 1
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/mir:Place", ptr %t11, i32 0, i32 1
  %t15 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aRange(ptr %t10, ptr %t12)
  store i1 %t15, ptr %l8
  br label %bb4
bb4:
  %t16 = load i1, ptr %l8, !tbaa !21
  br i1 %t16, label %bb5, label %bb1
bb5:
  br label %bb6
bb6:
  %t17 = load i1, ptr %l2, !tbaa !21
  store i1 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/source:Span", ptr %t1, i32 0, i32 0
  %t3 = load i32, ptr %t2, !tbaa !23
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/source:Span", ptr %t4, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  %t9 = icmp eq i32 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb4
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/source:Span", ptr %t11, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/source:Span", ptr %t14, i32 0, i32 1
  %t16 = load i32, ptr %t15, !tbaa !23
  %t19 = icmp eq i32 %t13, %t16
  br i1 %t19, label %bb3, label %bb1
bb3:
  br label %bb4
bb4:
  %t21 = load i1, ptr %l2, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d462 = private unnamed_addr constant [10 x i8] c"PrimOp.Neg"
@.d463 = private unnamed_addr constant [13 x i8] c"PrimOp.BitNot"
@.d464 = private unnamed_addr constant [10 x i8] c"PrimOp.Not"
@.d465 = private unnamed_addr constant [10 x i8] c"PrimOp.Add"
@.d466 = private unnamed_addr constant [10 x i8] c"PrimOp.Sub"
@.d467 = private unnamed_addr constant [10 x i8] c"PrimOp.Mul"
@.d468 = private unnamed_addr constant [10 x i8] c"PrimOp.Div"
@.d469 = private unnamed_addr constant [10 x i8] c"PrimOp.Rem"
@.d470 = private unnamed_addr constant [10 x i8] c"PrimOp.Shl"
@.d471 = private unnamed_addr constant [10 x i8] c"PrimOp.Shr"
@.d472 = private unnamed_addr constant [13 x i8] c"PrimOp.BitAnd"
@.d473 = private unnamed_addr constant [12 x i8] c"PrimOp.BitOr"
@.d474 = private unnamed_addr constant [13 x i8] c"PrimOp.BitXor"
@.d475 = private unnamed_addr constant [9 x i8] c"PrimOp.Eq"
@.d476 = private unnamed_addr constant [9 x i8] c"PrimOp.Ne"
@.d477 = private unnamed_addr constant [9 x i8] c"PrimOp.Lt"
@.d478 = private unnamed_addr constant [9 x i8] c"PrimOp.Le"
@.d479 = private unnamed_addr constant [9 x i8] c"PrimOp.Gt"
@.d480 = private unnamed_addr constant [9 x i8] c"PrimOp.Ge"
@.d481 = private unnamed_addr constant [11 x i8] c"PrimOp.Same"
@.d482 = private unnamed_addr constant [14 x i8] c"PrimOp.Convert"
@.d483 = private unnamed_addr constant [14 x i8] c"PrimOp.Bitcast"
@.d484 = private unnamed_addr constant [10 x i8] c"PrimOp.Len"
@.d485 = private unnamed_addr constant [13 x i8] c"PrimOp.IsCase"
@.d486 = private unnamed_addr constant [17 x i8] c"PrimOp.AtomicLoad"
@.d487 = private unnamed_addr constant [18 x i8] c"PrimOp.AtomicStore"
@.d488 = private unnamed_addr constant [16 x i8] c"PrimOp.AtomicAdd"
@.d489 = private unnamed_addr constant [17 x i8] c"PrimOp.AtomicSwap"
@.d490 = private unnamed_addr constant [24 x i8] c"PrimOp.AtomicCompareSwap"
@.d491 = private unnamed_addr constant [13 x i8] c"PrimOp.Retire"
@.d492 = private unnamed_addr constant [19 x i8] c"PrimOp.LeadingZeros"
@.d493 = private unnamed_addr constant [20 x i8] c"PrimOp.TrailingZeros"
@.d494 = private unnamed_addr constant [15 x i8] c"PrimOp.PopCount"
@.d495 = private unnamed_addr constant [17 x i8] c"PrimOp.RotateLeft"
@.d496 = private unnamed_addr constant [18 x i8] c"PrimOp.RotateRight"
@.d497 = private unnamed_addr constant [15 x i8] c"PrimOp.ByteSwap"
@.d498 = private unnamed_addr constant [12 x i8] c"PrimOp.Holds"
@.d499 = private unnamed_addr constant [14 x i8] c"PrimOp.AnyMake"
@.d500 = private unnamed_addr constant [18 x i8] c"PrimOp.AnyInstance"
@.d501 = private unnamed_addr constant [12 x i8] c"PrimOp.AnyIs"
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aBase(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb10
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 ]
bb3:
  br label %bb10
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [2 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  %t20 = icmp eq i32 %t13, %t17
  br i1 %t20, label %bb6, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64, i32, i32 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64, i32, i32 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb7, label %bb1
bb6:
  br label %bb3
bb7:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [2 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i64, i32, i32 }, ptr %t35, i32 0, i32 1
  %t37 = load i32, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [2 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i64, i32, i32 }, ptr %t39, i32 0, i32 1
  %t41 = load i32, ptr %t40
  %t44 = icmp eq i32 %t37, %t41
  br i1 %t44, label %bb8, label %bb1
bb8:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [2 x i64] }, ptr %t46, i32 0, i32 1
  %t48 = getelementptr { i64, i32, i32 }, ptr %t47, i32 0, i32 2
  %t49 = load i32, ptr %t48
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [2 x i64] }, ptr %t50, i32 0, i32 1
  %t52 = getelementptr { i64, i32, i32 }, ptr %t51, i32 0, i32 2
  %t53 = load i32, ptr %t52
  %t56 = icmp eq i32 %t49, %t53
  br i1 %t56, label %bb9, label %bb1
bb9:
  br label %bb3
bb10:
  %t58 = load i1, ptr %l2, !tbaa !21
  store i1 %t58, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aRange(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/mir:Range", ptr %t1, i32 0, i32 0
  %t3 = load i32, ptr %t2, !tbaa !23
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/mir:Range", ptr %t4, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  %t9 = icmp eq i32 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb4
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/mir:Range", ptr %t11, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/mir:Range", ptr %t14, i32 0, i32 1
  %t16 = load i32, ptr %t15, !tbaa !23
  %t19 = icmp eq i32 %t13, %t16
  br i1 %t19, label %bb3, label %bb1
bb3:
  br label %bb4
bb4:
  %t21 = load i1, ptr %l2, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@G_2ecompiler_2femit_2eHomeInst = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FD\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2femit_2eHomeLoc = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FC\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceName(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanonList(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etestSym(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etableName(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecanonOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_de1fe604fb5e87cf_ff4728625cff78d3 = external constant [0 x i8]
@G_2ecompiler_2femit_2eHomeShared = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i64 %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_5ad0f5036011b2cd_7d6f5911e17dc851 = external constant [0 x i8]
@olang_loc_aa3eb0efeafaca9c_7799b263c8155fc0 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_eb6d9c3809493fd7_39d95642e792ba3b = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_616c6f643d0ce9fd_dfe523617d4699c1 = external constant [0 x i8]
@olang_loc_b37ed008d0080fcc_cc9019489ebc5a30 = external constant [0 x i8]
@olang_loc_7f6c4a9881f0c77f_244fd8f3f85b2bab = external constant [0 x i8]
@olang_loc_1cb2b0b1c80ab6bb_ff3b7bcb0dec81bf = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1)
@olang_loc_dd4469a9ae312a3a_602f574df5758ebe = external constant [0 x i8]
@olang_loc_e68028fa4f0f457e_ac0c180900ac4e62 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2femit_2emathExact = external constant <{ ptr }>
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_8b9f7f38fd25c7fb_28bbaeaad75485df = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eposition(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H8fdab0f9e4aba8682af3c4e1d27c3999(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_6092aa485d103db2_ba7372f362365566 = external constant [0 x i8]
declare { i32, { i64, ptr } } @compiler_2fruntime_2eText(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1, i1 %a2)
@olang_loc_49795d8549fab862_b41831e08981cb6 = external constant [0 x i8]
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2egap(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare { i64, ptr } @compiler_2fruntime_2eDecls(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %a0)
@olang_loc_e59d8160838b9663_ee3833e61d72b057 = external constant [0 x i8]
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2femit_2edeclaredSymbol(ptr %v0, ptr %v1, { i64, ptr } %a0)
@G_2ecompiler_2ftypes_2eNullT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\0F\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eneed(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eRunFrom_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_cd6d5a2ace167e0b_158f6ef781c59597 = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eopaque16(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aConstNode_3e_2eAt_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %a0, i64 %a1)
declare i8 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cU8_3e_2eAt_3cU8_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_a00373ca27d5619a_9315010cb9ead296 = external constant [0 x i8]
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edbgLine(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_e9e71ccb75095175_3df52a9a91674c89 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
declare { { i64, ptr }, { i64, ptr } } @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayParts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixed(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixedLen(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1, i64 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %v1, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2)
declare { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Place" %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2etmp(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eplaceType(ptr %v0, ptr %a0, %"compiler/mir:Place" %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@olang_loc_9357034ceffa49e9_ad514f9345461395 = external constant [0 x i8]
@olang_loc_1dffb4089bad5318_6447f84abd9ba4a4 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0)
@olang_loc_3b6348629663638e_4d98396f767ecbfa = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeRef_3e_2eRunF_Hfdafd2704446aebe706e7a16d9caf3c2(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_f4a19adfa2908824_f7d19e69dc606aa8 = external constant [0 x i8]
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2euseRef(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1, { i64, ptr } %a2)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eRu_H05f2a0ad75f6ffeece9ab76b4dcd7cb0(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_7398c824c6ccd25f_37644bbf4fe2ca83 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eRunFrom_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_5718aedbda8f05de_73125ecff2351902 = external constant [0 x i8]
@olang_loc_c174e5a3b34e67b9_6250aa572b15a6d5 = external constant [0 x i8]
@olang_loc_9206c849bcce77e8_1d8ffc9eff2b8ce4 = external constant [0 x i8]
@olang_loc_5234ed07c88e8ec3_fc55cf91bd0a7f1f = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eRunFrom_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_163846ebfcde4742_93f6cefa6f5e149e = external constant [0 x i8]
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eisFrame(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare %"compiler/mir:ScopeInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eindex(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2)
@olang_loc_7367d2b2f6aa7e57_e9ab633458e0a533 = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epair(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eviaMem(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2eput(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, [4 x i64] } %a3, { i64, ptr } %a4)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2econvert(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, i32 %a3)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ebitcast(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
@olang_loc_69dfe582bfe1941e_f4b5889a4307147a = external constant [0 x i8]
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eanyTable(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etypeid(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@G_2ecompiler_2fmir_2eI64T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\06\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ewidth(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, i32 %a3)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_d23ee61a0d8dfe9f_a353f177579d38fb = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ewidenBF16(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@olang_loc_f37913274faf0c64_a4499fcd83081580 = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ecompare(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3, { i64, ptr } %a4)
@olang_loc_3839c0df7b992655_2640faef1ba2f611 = external constant [0 x i8]
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eenumWords(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_48fb755842b89882_1da88e591314daf6 = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eref(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Place" %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eoverflows(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, %"compiler/mir:Range" %a3)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaggregate(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2, %"compiler/mir:Range" %a3)
declare i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ealign(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloc(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [1 x i64] } %a1, { i64, ptr } %a2, i64 %a3, { i64, ptr } %a4)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erunTime(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ecopyArray(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [1 x i64] } %a1, { i64, ptr } %a2, i32 %a3)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eslice(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Place" %a1, { i64, [4 x i64] } %a2, { i64, [4 x i64] } %a3, i32 %a4)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eclosure(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, { i64, [1 x i64] } %a3, %"compiler/mir:Range" %a4, %"compiler/mir:Range" %a5)
@G_2ecompiler_2fmir_2eI32T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\05\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2erecode(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, i32 %a3)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2edirectRef(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edirectText(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2etextCopy(ptr %v0, ptr %a0)
@olang_loc_b25f444594da9527_de5411018827488b = external constant [0 x i8]
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2emathExactTable(ptr %v0)
@G_2ecompiler_2femit_2ePartSize = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\10\00\00\00\00\00" }>, align 8
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
