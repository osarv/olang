; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64 }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/io:Writer" = type { i32, { i64, ptr }, i64, { i32, { i64, [1 x i64] } } }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"std/os:FileInfo" = type { i32, i64, i64 }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
@G_2ecompiler_2ffix_2eBatch = constant <{ [8 x i8] }> <{ [8 x i8] c"\C8\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eBuildWidth = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eCheckWidth = constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eDrivenArg = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eDrivenOpt = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eFixCacheCap = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\08\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eStdTool = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eTextTool = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eToolKeywords = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\74\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolKeywords.k1 }>, align 8
@G_2ecompiler_2ffix_2eToolKeywords.k1 = internal constant <{ [116 x i8] }> <{ [116 x i8] c"\61\6E\79\7C\75\6E\69\71\75\65\7C\69\6D\6D\75\74\7C\70\61\63\6B\65\64\7C\63\6F\6D\6D\75\74\65\73\7C\77\65\61\6B\7C\72\65\74\75\72\6E\73\7C\6E\6F\61\6C\6C\6F\63\7C\6E\6F\62\6C\6F\63\6B\7C\6E\6F\73\70\61\77\6E\7C\6E\6F\72\65\63\75\72\73\65\7C\6E\6F\65\78\74\65\72\6E\7C\70\75\72\65\7C\6B\65\65\70\73\7C\62\6F\72\72\6F\77\73\7C\6E\6F\62\6F\72\72\6F\77" }>, align 64
@G_2ecompiler_2ffix_2eToolKinds = constant <{ [360 x i8] }> <{ [360 x i8] c"\01\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\03\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2ffix_2eToolNames = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k1, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k2, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k3, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k4, [8 x i8] c"\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k5, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k6, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k7, [8 x i8] c"\0C\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k8, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k9, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k10, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k11, [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k12, [8 x i8] c"\0C\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k13, [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k14, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k15, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k16, [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k17, [8 x i8] c"\0B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k18, [8 x i8] c"\0A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k19, [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k20, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k21, [8 x i8] c"\0C\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k22, [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k23, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k24, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k25, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k26, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k27, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k28, [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k29, [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k30, [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k31, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k32, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k33, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k34, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k35, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k36, [8 x i8] c"\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k37, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k38, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k39, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k40, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k41, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k42, [8 x i8] c"\0C\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k43, [8 x i8] c"\0C\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k44, [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k45 }>, align 64
@G_2ecompiler_2ffix_2eToolNames.k1 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\62\61\72\65\5F\74\79\70\65\76\61\72\73" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k2 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\70\65\72\6D\5F\6D\75\74" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k3 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\69\6E\74\5F\6C\69\74\65\72\61\6C\5F\69\36\34" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k4 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\65\72\72\6F\72\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k5 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\63\6C\69\5F\77\6F\72\64\73" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k6 = internal constant <{ [16 x i8] }> <{ [16 x i8] c"\64\6F\6E\65\66\61\69\6C\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k7 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\73\79\6E\74\61\78\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k8 = internal constant <{ [12 x i8] }> <{ [12 x i8] c"\6D\61\74\68\5F\6D\65\74\68\6F\64\73" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k9 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\61\72\72\61\79\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k10 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\72\65\73\75\6C\74\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k11 = internal constant <{ [16 x i8] }> <{ [16 x i8] c"\65\71\75\61\6C\69\74\79\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k12 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\68\65\6C\70\65\72\5F\72\65\6E\61\6D\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k13 = internal constant <{ [12 x i8] }> <{ [12 x i8] c"\6E\75\6C\6C\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k14 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\63\68\65\63\6B\65\72\72\6F\72\5F\72\65\6E\61\6D\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k15 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\73\74\75\74\74\65\72\5F\72\65\6E\61\6D\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k16 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\63\68\65\63\6B\65\64\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k17 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\63\6F\6E\74\72\61\63\74\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k18 = internal constant <{ [11 x i8] }> <{ [11 x i8] c"\74\72\79\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k19 = internal constant <{ [10 x i8] }> <{ [10 x i8] c"\61\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k20 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\65\72\72\6F\72\74\79\70\65\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k21 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\6C\69\73\74\5F\76\65\63" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k22 = internal constant <{ [12 x i8] }> <{ [12 x i8] c"\6C\69\6E\6B\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k23 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\6D\61\74\63\68\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k24 = internal constant <{ [16 x i8] }> <{ [16 x i8] c"\71\75\65\73\74\69\6F\6E\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k25 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\75\6E\75\73\65\64\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k26 = internal constant <{ [16 x i8] }> <{ [16 x i8] c"\65\72\72\6F\72\63\61\73\65\5F\72\65\6E\61\6D\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k27 = internal constant <{ [16 x i8] }> <{ [16 x i8] c"\76\61\72\69\61\64\69\63\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k28 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\73\63\6F\70\65\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k29 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\66\6E\72\65\66\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k30 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\63\6C\6F\6E\65\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k31 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\74\65\78\74\62\75\69\6C\64\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k32 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\75\6E\69\71\75\65\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k33 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\62\75\69\6C\64\65\72\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k34 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\6C\69\74\65\72\61\6C\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k35 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\6B\65\79\77\6F\72\64\5F\72\65\6E\61\6D\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k36 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\64\65\73\74\72\6F\79\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k37 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\69\6F\5F\72\65\6E\61\6D\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k38 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\6F\6E\65\6C\69\6E\65\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k39 = internal constant <{ [16 x i8] }> <{ [16 x i8] c"\6E\75\6C\6C\74\65\73\74\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k40 = internal constant <{ [16 x i8] }> <{ [16 x i8] c"\74\65\78\74\6A\6F\69\6E\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k41 = internal constant <{ [16 x i8] }> <{ [16 x i8] c"\72\65\71\75\69\72\65\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k42 = internal constant <{ [16 x i8] }> <{ [16 x i8] c"\63\68\61\6E\69\6E\69\74\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k43 = internal constant <{ [12 x i8] }> <{ [12 x i8] c"\66\69\6C\65\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k44 = internal constant <{ [12 x i8] }> <{ [12 x i8] c"\70\75\74\6C\6E\5F\72\65\6E\61\6D\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k45 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\64\65\66\65\72\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k1, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k2, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k3, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k4, [8 x i8] c"\0B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k5, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k6, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k7, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k8, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k9, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k10, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k11, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k12, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k13, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k14, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k15, [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k16, [8 x i8] c"\01\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k17, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k18, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k19, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k20, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k21, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k22, [8 x i8] c"\0A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k23, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k24, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k25, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k26, [8 x i8] c"\17\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k27, [8 x i8] c"\01\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k28, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k29, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k30, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k31, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k32, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k33, [8 x i8] c"\01\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k34, [8 x i8] c"\74\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolKeywords.k1, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k35, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k36, [8 x i8] c"\01\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k37, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k38, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k39, [8 x i8] c"\01\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k40, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k41, [8 x i8] c"\2B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k42, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k43, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k44 }>, align 64
@G_2ecompiler_2ffix_2eToolTriggers.k1 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k2 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\6D\75\74" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k3 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k4 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k5 = internal constant <{ [11 x i8] }> <{ [11 x i8] c"\6F\6C\61\6E\67\7C\66\6C\61\67\73" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k6 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\64\6F\6E\65\7C\66\61\69\6C\7C\61\62\6F\72\74" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k7 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k8 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\6D\61\74\68" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k9 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\41\72\72\61\79\3C" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k10 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k11 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\69\73" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k12 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\41\6E\79\7C\41\6C\6C" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k13 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k14 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\42\75\69\6C\74\69\6E" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k15 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\45\72\72\6F\72" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k16 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\63\68\65\63\6B\65\64\7C\43\68\65\63\6B" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k17 = internal constant <{ [1 x i8] }> <{ [1 x i8] c"\5B" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k18 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\74\72\79" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k19 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\61\73" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k20 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\65\72\72\6F\72" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k21 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\4C\69\73\74" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k22 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\6C\69\6E\6B" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k23 = internal constant <{ [10 x i8] }> <{ [10 x i8] c"\6E\6F\6D\61\74\63\68\7C\3D\3E" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k24 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k25 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k26 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k27 = internal constant <{ [23 x i8] }> <{ [23 x i8] c"\45\78\65\63\7C\53\74\61\72\74\7C\68\74\74\70\2E\7C\52\65\63\6F\72\64" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k28 = internal constant <{ [1 x i8] }> <{ [1 x i8] c"\26" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k29 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\66\6E" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k30 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\43\6C\6F\6E\65" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k31 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\53\74\72\69\6E\67" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k32 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\64\65\73\74\72\75\63\74" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k33 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k34 = internal constant <{ [1 x i8] }> <{ [1 x i8] c"\5B" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k35 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\44\65\73\74\72\6F\79" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k36 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\50\72\69\6E\74" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k37 = internal constant <{ [1 x i8] }> <{ [1 x i8] c"\7B" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k38 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\69\73" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k39 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\22\7C\24" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k40 = internal constant <{ [1 x i8] }> <{ [1 x i8] c"\5B" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k41 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\49\6E\69\74\28" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k42 = internal constant <{ [43 x i8] }> <{ [43 x i8] c"\4F\70\65\6E\28\7C\43\72\65\61\74\65\28\7C\43\6C\6F\73\65\28\7C\52\65\61\64\65\72\28\7C\57\72\69\74\65\72\28\7C\4C\69\6E\65\73\28" }>, align 32
@G_2ecompiler_2ffix_2eToolTriggers.k43 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\4C\69\6E\65" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k44 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\64\65\66\65\72" }>, align 8
define dso_local { i64, ptr } @compiler_2ffix_2eBinDir(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i64, ptr } @compiler_2fbuild_2eCacheDir(ptr %s0, ptr %v0, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store { i64, ptr } %t1, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t2, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2ffix_2eFiles(ptr %v0, ptr %v1, ptr %v2, i1 %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca i1
  %l4 = alloca %"std/io:Writer"
  %l5 = alloca %"std/io:Writer"
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l13 = alloca i32
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l25 = alloca %"std/io:Writer"
  %l29 = alloca %"std/io:Writer"
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca { i64, ptr }
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l42 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i32
  %l50 = alloca i1
  %l59 = alloca i32
  %l61 = alloca i1
  %l74 = alloca i32
  %l80 = alloca i64
  %l83 = alloca i64
  %l101 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l106 = alloca i32
  %l108 = alloca i1
  %l111 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l115 = alloca i1
  %l119 = alloca { i64, ptr }
  %l126 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l131 = alloca { i64, ptr }
  %l133 = alloca i32
  %l135 = alloca i1
  %l139 = alloca { i64, ptr }
  %l148 = alloca i32
  %l150 = alloca i1
  %l155 = alloca i32
  %l157 = alloca i1
  %l165 = alloca i1
  %l168 = alloca i1
  %l171 = alloca i32
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca i32
  store i1 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr @G_2estd_2fio_2eStderr, !tbaa !23
  %t3 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 4, i64 8)
  store i32 %t1, ptr %t3
  %t5 = insertvalue { ptr, ptr } undef, ptr %t3, 0
  %t6 = icmp ne ptr %t3, null
  %t7 = select i1 %t6, ptr @olang_2etable_2eI32_7cstd_2fio_3aDescriptor, ptr null
  %t8 = insertvalue { ptr, ptr } %t5, ptr %t7, 1
  %t10 = call %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %s0, ptr %s0, { ptr, ptr } %t8, i64 65536)
  store %"std/io:Writer" %t10, ptr %l25
  br label %bb1
bb1:
  %t11 = load %"std/io:Writer", ptr %l25
  store %"std/io:Writer" %t11, ptr %l4
  %t12 = load i32, ptr @G_2estd_2fio_2eStdout, !tbaa !23
  %t14 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 4, i64 8)
  store i32 %t12, ptr %t14
  %t16 = insertvalue { ptr, ptr } undef, ptr %t14, 0
  %t17 = icmp ne ptr %t14, null
  %t18 = select i1 %t17, ptr @olang_2etable_2eI32_7cstd_2fio_3aDescriptor, ptr null
  %t19 = insertvalue { ptr, ptr } %t16, ptr %t18, 1
  %t21 = call %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %s0, ptr %s0, { ptr, ptr } %t19, i64 65536)
  store %"std/io:Writer" %t21, ptr %l29
  br label %bb2
bb2:
  %t22 = load %"std/io:Writer", ptr %l29
  store %"std/io:Writer" %t22, ptr %l5
  %t25 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffix_2eexpand(ptr %v0, ptr %v0, { i64, ptr } %a1)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l31
  br label %bb3
bb3:
  %t26 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31
  %t27 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %t27
  %t29 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %s0, ptr %t27)
  store { i64, ptr } %t29, ptr %l33
  br label %bb4
bb4:
  %t30 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t30, ptr %l6, !tbaa !27
  %t31 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t31, ptr %l34
  br label %bb5
bb5:
  %t32 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %l7
  %t33 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t33, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  store i64 %t37, ptr %l10, !tbaa !24
  br label %bb6
bb6:
  %t39 = load i64, ptr %l9, !tbaa !24
  %t40 = load i64, ptr %l10, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb7, label %bb8
bb7:
  br label %bb25
bb8:
  br label %bb9
bb9:
  %t47 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t47, ptr %l42, !tbaa !27
  %t48 = load i64, ptr %l9, !tbaa !24
  %t50 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr { i64, ptr }, ptr %t51, i64 %t48
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !37
  store { i64, ptr } %t53, ptr %l11, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t57 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } %t55)
  %t58 = extractvalue { i32, { i64, ptr } } %t57, 1
  %t59 = extractvalue { i32, { i64, ptr } } %t57, 0
  store i32 %t59, ptr %l48
  %t60 = icmp ne i32 %t59, 0
  br i1 %t60, label %bb11, label %ok.61, !prof !99
ok.61:
  store { i64, ptr } %t58, ptr %l47
  br label %bb10
bb10:
  %t62 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t62, ptr %l45, !tbaa !27
  br label %bb22
bb11:
  %t63 = load i32, ptr %l48, !tbaa !23
  %t64 = ashr i32 %t63, 16
  %t66 = icmp eq i32 %t64, 1
  store i1 %t66, ptr %l50, !tbaa !21
  %t67 = load i32, ptr %l48, !tbaa !23
  %t68 = ashr i32 %t67, 16
  %t70 = icmp eq i32 %t68, 1
  br i1 %t70, label %bb12, label %bb13
bb12:
  call void @__olang_errpay_pop()
  br label %bb13
bb13:
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t72 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t73 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t74 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t76 = extractvalue { i64, ptr } %t72, 1
  %t77 = extractvalue { i64, ptr } %t72, 0
  %t78 = add i64 %t74, %t77
  %t79 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t81 = add i64 %t78, %t80
  %t82 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t81)
  call void @olang_textcopy(ptr %t82, ptr %t73, i64 %t74)
  %t83 = getelementptr i8, ptr %t82, i64 %t74
  call void @olang_textcopy(ptr %t83, ptr %t76, i64 %t77)
  %t84 = getelementptr i8, ptr %t83, i64 %t77
  call void @olang_textcopy(ptr %t84, ptr %t79, i64 %t80)
  %t85 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t82, 1
  %t89 = extractvalue { i64, ptr } %t86, 0
  %t90 = extractvalue { i64, ptr } %t86, 1
  %t91 = mul i64 %t89, 1
  %t92 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t91)
  call void @llvm.memcpy.p0.p0.i64(ptr %t92, ptr %t90, i64 %t91, i1 false)
  %t93 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s3, ptr %l4, { i64, ptr } %t94)
  br label %bb15
bb15:
  %t98 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l4)
  store i32 %t98, ptr %l59
  %t99 = icmp ne i32 %t98, 0
  br i1 %t99, label %bb17, label %ok.100, !prof !99
ok.100:
  br label %bb16
bb16:
  br label %bb21
bb17:
  %t101 = load i32, ptr %l59, !tbaa !23
  %t102 = ashr i32 %t101, 16
  %t104 = icmp eq i32 %t102, 1
  store i1 %t104, ptr %l61, !tbaa !21
  %t105 = load i32, ptr %l59, !tbaa !23
  %t106 = ashr i32 %t105, 16
  %t108 = icmp eq i32 %t106, 1
  br i1 %t108, label %bb18, label %bb19
bb18:
  call void @__olang_errpay_pop()
  br label %bb19
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb22:
  %t111 = load { i64, ptr }, ptr %l45, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } %t111)
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t115 = load i64, ptr %l9, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l9, !tbaa !24
  br label %bb6
bb25:
  %t119 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t127 = call i32 @compiler_2ffix_2erun(ptr %s0, ptr %s0, ptr %v1, ptr %v2, ptr %s0, { i64, ptr } %t119, ptr %l7, { i64, ptr } %a2, { i64, ptr } %a3, ptr %l4)
  store i32 %t127, ptr %l74
  br label %bb26
bb26:
  %t128 = load i32, ptr %l74, !tbaa !23
  store i32 %t128, ptr %l13, !tbaa !23
  store i64 0, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  %t129 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t129, 0
  store i64 %t131, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t133 = load i64, ptr %l16, !tbaa !24
  %t134 = load i64, ptr %l15, !tbaa !24
  %t137 = icmp sgt i64 %t133, %t134
  br i1 %t137, label %bb27, label %bb28
bb27:
  %t139 = load i64, ptr %l17, !tbaa !24
  %t141 = icmp sgt i64 %t139, 0
  br i1 %t141, label %bb29, label %bb30
bb28:
  store i64 0, ptr %l80, !tbaa !24
  br label %bb32
bb29:
  %t143 = load i64, ptr %l16, !tbaa !24
  %t144 = load i64, ptr %l15, !tbaa !24
  %t147 = sub i64 %t143, %t144
  %t148 = load i64, ptr %l17, !tbaa !24
  %t151 = add i64 %t147, %t148
  %t153 = sub i64 %t151, 1
  %t154 = load i64, ptr %l17, !tbaa !24
  %t157 = sdiv i64 %t153, %t154
  store i64 %t157, ptr %l83, !tbaa !24
  br label %bb31
bb30:
  store i64 0, ptr %l83, !tbaa !24
  br label %bb31
bb31:
  %t159 = load i64, ptr %l83, !tbaa !24
  store i64 %t159, ptr %l80, !tbaa !24
  br label %bb32
bb32:
  %t160 = load i64, ptr %l80, !tbaa !24
  store i64 %t160, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s8
  %t161 = load i64, ptr %l19, !tbaa !24
  %t162 = load i64, ptr %l18, !tbaa !24
  %t165 = icmp slt i64 %t161, %t162
  %t167 = xor i1 %t165, true
  br i1 %t167, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s8)
  br label %bb61
bb35:
  br label %bb36
bb36:
  %t169 = load i64, ptr %l15, !tbaa !24
  %t170 = load i64, ptr %l19, !tbaa !24
  %t171 = load i64, ptr %l17, !tbaa !24
  %t174 = mul i64 %t170, %t171
  %t177 = add i64 %t169, %t174
  store i64 %t177, ptr %l20, !tbaa !24
  %t179 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t179, ptr %l102, !tbaa !27
  %t180 = load i64, ptr %l20, !tbaa !24
  %t182 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !27
  %t184 = getelementptr { i64, ptr }, ptr %t183, i64 %t180
  %t185 = load { i64, ptr }, ptr %t184, !tbaa !37
  %t187 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s8, { i64, ptr } %t185)
  %t188 = extractvalue { i32, { i64, ptr } } %t187, 1
  %t189 = extractvalue { i32, { i64, ptr } } %t187, 0
  store i32 %t189, ptr %l106
  %t190 = icmp ne i32 %t189, 0
  br i1 %t190, label %bb38, label %ok.191, !prof !99
ok.191:
  store { i64, ptr } %t188, ptr %l105
  br label %bb37
bb37:
  %t192 = load { i64, ptr }, ptr %l105, !tbaa !27
  store { i64, ptr } %t192, ptr %l101, !tbaa !27
  br label %bb42
bb38:
  %t193 = load i32, ptr %l106, !tbaa !23
  %t194 = ashr i32 %t193, 16
  %t196 = icmp eq i32 %t194, 1
  store i1 %t196, ptr %l108, !tbaa !21
  %t197 = load i32, ptr %l106, !tbaa !23
  %t198 = ashr i32 %t197, 16
  %t200 = icmp eq i32 %t198, 1
  br i1 %t200, label %bb39, label %bb40
bb39:
  call void @__olang_errpay_pop()
  br label %bb40
bb40:
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s8)
  br label %bb60
bb42:
  %t202 = load { i64, ptr }, ptr %l101, !tbaa !27
  store { i64, ptr } %t202, ptr %l111, !tbaa !27
  %t204 = load i64, ptr %l20, !tbaa !24
  %t207 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l7, i64 %t204)
  store { i64, ptr } %t207, ptr %l114
  br label %bb43
bb43:
  %t208 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t209 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t210 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s8, ptr %s0, { i64, ptr } %t208, { i64, ptr } %t209)
  store i1 %t210, ptr %l115
  br label %bb44
bb44:
  %t211 = load i1, ptr %l115, !tbaa !21
  br i1 %t211, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s8)
  br label %bb60
bb46:
  br label %bb47
bb47:
  %t212 = load i64, ptr %l14, !tbaa !24
  %t214 = add i64 %t212, 1
  store i64 %t214, ptr %l14, !tbaa !24
  %t216 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t216, ptr %l119, !tbaa !27
  %t217 = load i64, ptr %l20, !tbaa !24
  %t219 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t220 = load ptr, ptr %t219, !tbaa !27
  %t221 = getelementptr { i64, ptr }, ptr %t220, i64 %t217
  %t222 = load { i64, ptr }, ptr %t221, !tbaa !37
  %t224 = extractvalue { i64, ptr } %t222, 1
  %t225 = extractvalue { i64, ptr } %t222, 0
  %t226 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t227 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t228 = add i64 %t225, %t227
  %t229 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t228)
  call void @olang_textcopy(ptr %t229, ptr %t224, i64 %t225)
  %t230 = getelementptr i8, ptr %t229, i64 %t225
  call void @olang_textcopy(ptr %t230, ptr %t226, i64 %t227)
  %t231 = insertvalue { i64, ptr } undef, i64 %t228, 0
  %t232 = insertvalue { i64, ptr } %t231, ptr %t229, 1
  %t235 = extractvalue { i64, ptr } %t232, 0
  %t236 = extractvalue { i64, ptr } %t232, 1
  %t237 = mul i64 %t235, 1
  %t238 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t237)
  call void @llvm.memcpy.p0.p0.i64(ptr %t238, ptr %t236, i64 %t237, i1 false)
  %t239 = insertvalue { i64, ptr } undef, i64 %t235, 0
  %t240 = insertvalue { i64, ptr } %t239, ptr %t238, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s8, ptr %l5, { i64, ptr } %t240)
  br label %bb48
bb48:
  %t243 = load i1, ptr %l0, !tbaa !21
  br i1 %t243, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s12
  %t245 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t245, ptr %l126, !tbaa !27
  %t246 = load i64, ptr %l20, !tbaa !24
  %t248 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !27
  %t250 = getelementptr { i64, ptr }, ptr %t249, i64 %t246
  %t251 = load { i64, ptr }, ptr %t250, !tbaa !37
  store { i64, ptr } %t251, ptr %l128, !tbaa !27
  %t252 = load i64, ptr %l20, !tbaa !24
  %t255 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s12, ptr %l7, i64 %t252)
  store { i64, ptr } %t255, ptr %l131
  br label %bb51
bb50:
  br label %bb59
bb51:
  %t256 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t257 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t259 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s12, { i64, ptr } %t257, { i64, ptr } %t256)
  store i32 %t259, ptr %l133
  %t260 = icmp ne i32 %t259, 0
  br i1 %t260, label %bb53, label %ok.261, !prof !99
ok.261:
  br label %bb52
bb52:
  br label %bb58
bb53:
  %t262 = load i32, ptr %l133, !tbaa !23
  %t263 = ashr i32 %t262, 16
  %t265 = icmp eq i32 %t263, 1
  store i1 %t265, ptr %l135, !tbaa !21
  %t266 = load i32, ptr %l133, !tbaa !23
  %t267 = ashr i32 %t266, 16
  %t269 = icmp eq i32 %t267, 1
  br i1 %t269, label %bb54, label %bb55
bb54:
  call void @__olang_errpay_pop()
  br label %bb55
bb55:
  br label %bb56
bb56:
  store %olang.scope zeroinitializer, ptr %s13
  %t271 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t271, ptr %l139, !tbaa !27
  %t272 = load i64, ptr %l20, !tbaa !24
  %t274 = getelementptr { i64, ptr }, ptr %l139, i32 0, i32 1
  %t275 = load ptr, ptr %t274, !tbaa !27
  %t276 = getelementptr { i64, ptr }, ptr %t275, i64 %t272
  %t277 = load { i64, ptr }, ptr %t276, !tbaa !37
  %t278 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t279 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t281 = extractvalue { i64, ptr } %t277, 1
  %t282 = extractvalue { i64, ptr } %t277, 0
  %t283 = add i64 %t279, %t282
  %t284 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t285 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t286 = add i64 %t283, %t285
  %t287 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t286)
  call void @olang_textcopy(ptr %t287, ptr %t278, i64 %t279)
  %t288 = getelementptr i8, ptr %t287, i64 %t279
  call void @olang_textcopy(ptr %t288, ptr %t281, i64 %t282)
  %t289 = getelementptr i8, ptr %t288, i64 %t282
  call void @olang_textcopy(ptr %t289, ptr %t284, i64 %t285)
  %t290 = insertvalue { i64, ptr } undef, i64 %t286, 0
  %t291 = insertvalue { i64, ptr } %t290, ptr %t287, 1
  %t294 = extractvalue { i64, ptr } %t291, 0
  %t295 = extractvalue { i64, ptr } %t291, 1
  %t296 = mul i64 %t294, 1
  %t297 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t296)
  call void @llvm.memcpy.p0.p0.i64(ptr %t297, ptr %t295, i64 %t296, i1 false)
  %t298 = insertvalue { i64, ptr } undef, i64 %t294, 0
  %t299 = insertvalue { i64, ptr } %t298, ptr %t297, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s13, ptr %l4, { i64, ptr } %t299)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s13)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s12)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s8)
  br label %bb60
bb60:
  %t302 = load i64, ptr %l19, !tbaa !24
  %t304 = add i64 %t302, 1
  store i64 %t304, ptr %l19, !tbaa !24
  br label %bb33
bb61:
  %t307 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l5)
  store i32 %t307, ptr %l148
  %t308 = icmp ne i32 %t307, 0
  br i1 %t308, label %bb63, label %ok.309, !prof !99
ok.309:
  br label %bb62
bb62:
  br label %bb67
bb63:
  %t310 = load i32, ptr %l148, !tbaa !23
  %t311 = ashr i32 %t310, 16
  %t313 = icmp eq i32 %t311, 1
  store i1 %t313, ptr %l150, !tbaa !21
  %t314 = load i32, ptr %l148, !tbaa !23
  %t315 = ashr i32 %t314, 16
  %t317 = icmp eq i32 %t315, 1
  br i1 %t317, label %bb64, label %bb65
bb64:
  call void @__olang_errpay_pop()
  br label %bb65
bb65:
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb67:
  %t321 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l4)
  store i32 %t321, ptr %l155
  %t322 = icmp ne i32 %t321, 0
  br i1 %t322, label %bb69, label %ok.323, !prof !99
ok.323:
  br label %bb68
bb68:
  br label %bb73
bb69:
  %t324 = load i32, ptr %l155, !tbaa !23
  %t325 = ashr i32 %t324, 16
  %t327 = icmp eq i32 %t325, 1
  store i1 %t327, ptr %l157, !tbaa !21
  %t328 = load i32, ptr %l155, !tbaa !23
  %t329 = ashr i32 %t328, 16
  %t331 = icmp eq i32 %t329, 1
  br i1 %t331, label %bb70, label %bb71
bb70:
  call void @__olang_errpay_pop()
  br label %bb71
bb71:
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb73:
  %t334 = load i32, ptr %l13, !tbaa !23
  %t336 = icmp eq i32 %t334, 2
  br i1 %t336, label %bb74, label %bb75
bb74:
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb75:
  br label %bb76
bb76:
  %t339 = load i1, ptr %l0, !tbaa !21
  br i1 %t339, label %bb77, label %bb78
bb77:
  %t341 = load i64, ptr %l14, !tbaa !24
  %t343 = icmp sgt i64 %t341, 0
  store i1 %t343, ptr %l165, !tbaa !21
  br label %bb79
bb78:
  store i1 false, ptr %l165, !tbaa !21
  br label %bb79
bb79:
  %t345 = load i1, ptr %l165, !tbaa !21
  br i1 %t345, label %bb80, label %bb81
bb80:
  store i1 true, ptr %l168, !tbaa !21
  br label %bb82
bb81:
  %t346 = load i32, ptr %l13, !tbaa !23
  %t348 = icmp eq i32 %t346, 1
  store i1 %t348, ptr %l168, !tbaa !21
  br label %bb82
bb82:
  %t350 = load i1, ptr %l168, !tbaa !21
  br i1 %t350, label %bb83, label %bb84
bb83:
  store i32 1, ptr %l171, !tbaa !23
  br label %bb85
bb84:
  store i32 0, ptr %l171, !tbaa !23
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s0)
  %t351 = load i32, ptr %l171, !tbaa !23
  store i32 %t351, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ffix_2eOrder(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca [45 x { i64, ptr }]
  %l28 = alloca i64
  %l31 = alloca i64
  %l51 = alloca i1
  %l53 = alloca i1
  %l62 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l64 = alloca i64
  %l65 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l0
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t4 = insertvalue [2 x { i64, ptr }] %t3, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t6 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store [2 x { i64, ptr }] %t4, ptr %t6
  store ptr %t6, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t8 = load ptr, ptr %l1
  store i64 2, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l2, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  br label %bb25
bb4:
  br label %bb5
bb5:
  %t19 = load ptr, ptr %l1
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = getelementptr [2 x { i64, ptr }], ptr %t19, i64 0, i64 %t20
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !37
  store { i64, ptr } %t24, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l23, ptr @G_2ecompiler_2ffix_2eToolNames, i64 720, i1 false)
  %t26 = load [45 x { i64, ptr }], ptr %l23
  store i64 45, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t28 = load i64, ptr %l6, !tbaa !24
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = icmp sgt i64 %t28, %t29
  br i1 %t32, label %bb6, label %bb7
bb6:
  %t34 = load i64, ptr %l7, !tbaa !24
  %t36 = icmp sgt i64 %t34, 0
  br i1 %t36, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb11
bb8:
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = sub i64 %t38, %t39
  %t43 = load i64, ptr %l7, !tbaa !24
  %t46 = add i64 %t42, %t43
  %t48 = sub i64 %t46, 1
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = sdiv i64 %t48, %t49
  store i64 %t52, ptr %l31, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb10
bb10:
  %t54 = load i64, ptr %l31, !tbaa !24
  store i64 %t54, ptr %l28, !tbaa !24
  br label %bb11
bb11:
  %t55 = load i64, ptr %l28, !tbaa !24
  store i64 %t55, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t56 = load i64, ptr %l9, !tbaa !24
  %t57 = load i64, ptr %l8, !tbaa !24
  %t60 = icmp slt i64 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb14:
  br label %bb15
bb15:
  %t64 = load i64, ptr %l5, !tbaa !24
  %t65 = load i64, ptr %l9, !tbaa !24
  %t66 = load i64, ptr %l7, !tbaa !24
  %t69 = mul i64 %t65, %t66
  %t72 = add i64 %t64, %t69
  store i64 %t72, ptr %l10, !tbaa !24
  %t74 = load i64, ptr %l10, !tbaa !24
  %t76 = getelementptr [45 x i64], ptr @G_2ecompiler_2ffix_2eToolKinds, i64 0, i64 %t74
  %t77 = load i64, ptr %t76, !tbaa !34
  %t79 = call i1 @compiler_2ffix_2edriven(i64 %t77)
  store i1 %t79, ptr %l51
  br label %bb16
bb16:
  %t80 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t81 = load ptr, ptr @__olang_prog_scope
  %t83 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t81, ptr %s4, { i64, ptr } %t80, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i1 %t83, ptr %l53
  br label %bb17
bb17:
  %t84 = load i1, ptr %l51, !tbaa !21
  %t85 = load i1, ptr %l53, !tbaa !21
  %t86 = icmp eq i1 %t84, %t85
  br i1 %t86, label %bb18, label %bb19
bb18:
  %t88 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l0, i64 %t88)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb22:
  %t91 = load i64, ptr %l9, !tbaa !24
  %t93 = add i64 %t91, 1
  store i64 %t93, ptr %l9, !tbaa !24
  br label %bb12
bb23:
  br label %bb24
bb24:
  %t95 = load i64, ptr %l2, !tbaa !24
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l2, !tbaa !24
  br label %bb2
bb25:
  call void @__olang_scope_close(ptr %s1)
  %t100 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %l0)
  store { i64, ptr } %t100, ptr %l62
  br label %bb26
bb26:
  %t101 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t101, ptr %l63, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 0
  store i64 %t103, ptr %l64, !tbaa !24
  %t104 = load i64, ptr %l64, !tbaa !24
  %t105 = mul i64 %t104, 8
  %t106 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t105)
  %t107 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  store { i64, ptr } %t108, ptr %l65, !tbaa !27
  %t109 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = load i64, ptr %l64, !tbaa !24
  %t114 = mul i64 %t113, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t110, ptr %t112, i64 %t114, i1 false)
  %t115 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t115, ptr %l63, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t116 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t116, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ffix_2eProgramOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l7 = alloca [2 x { i64, ptr }]
  %l8 = alloca [2 x { i64, ptr }]
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l24 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l31 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l44 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v3, ptr %l5, { i64, ptr } %a3)
  br label %bb2
bb2:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v4, ptr %l5, { i64, ptr } %a4)
  br label %bb3
bb3:
  %t9 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t9, ptr %l14
  br label %bb4
bb4:
  %t10 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l14
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t10, ptr %l6
  store { i64, ptr } %a2, ptr %l15, !tbaa !27
  %t12 = ptrtoint ptr %s0 to i64
  store i64 %t12, ptr %l16, !tbaa !24
  %t13 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_202_3e_2e_2d1
  br i1 %t13, label %bb5, label %bb6
bb5:
  %t15 = call ptr @__olang_region_make(ptr %s0)
  %t16 = ptrtoint ptr %t15 to i64
  store i64 %t16, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t17 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 1
  %t20 = extractvalue { i64, ptr } %t17, 0
  %t21 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t23 = add i64 %t20, %t22
  %t24 = load i64, ptr %l16
  %t25 = inttoptr i64 %t24 to ptr
  %t26 = call ptr @__olang_held_alloc(ptr %t25, i64 %t23)
  call void @olang_textcopy(ptr %t26, ptr %t19, i64 %t20)
  %t27 = getelementptr i8, ptr %t26, i64 %t20
  call void @olang_textcopy(ptr %t27, ptr %t21, i64 %t22)
  %t28 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t26, 1
  %t31 = load i64, ptr %l16
  %t32 = inttoptr i64 %t31 to ptr
  %t33 = extractvalue { i64, ptr } %t29, 0
  %t34 = extractvalue { i64, ptr } %t29, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_held_alloc(ptr %t32, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t39 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t40 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t39, 0
  %t42 = insertvalue [2 x { i64, ptr }] %t40, { i64, ptr } %t38, 1
  store [2 x { i64, ptr }] %t42, ptr %l7
  %t45 = insertvalue { i64, ptr } undef, i64 2, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %l7, 1
  %t48 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t46)
  store { i64, ptr } %t48, ptr %l24
  br label %bb7
bb7:
  %t49 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  %t51 = extractvalue { i64, ptr } %t49, 1
  %t52 = mul i64 %t50, 1
  %t53 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t52)
  call void @llvm.memcpy.p0.p0.i64(ptr %t53, ptr %t51, i64 %t52, i1 false)
  %t54 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  call void @compiler_2ffix_2eclosure(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t55, ptr %l6, ptr %l5)
  br label %bb8
bb8:
  store { i64, ptr } %a0, ptr %l28, !tbaa !27
  %t60 = ptrtoint ptr %s0 to i64
  store i64 %t60, ptr %l29, !tbaa !24
  %t61 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_202_3e_2e_2d1
  br i1 %t61, label %bb9, label %bb10
bb9:
  %t63 = call ptr @__olang_region_make(ptr %s0)
  %t64 = ptrtoint ptr %t63 to i64
  store i64 %t64, ptr %l29, !tbaa !24
  br label %bb10
bb10:
  %t65 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t65, ptr %l31, !tbaa !27
  %t67 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s0, ptr %s0, ptr %l5)
  store { i64, ptr } %t67, ptr %l33
  br label %bb11
bb11:
  %t68 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  store i64 %t69, ptr %l34, !tbaa !24
  %t70 = icmp sge i64 0, 0
  br i1 %t70, label %bb12, label %bb13
bb12:
  %t72 = icmp sle i64 0, 16
  br i1 %t72, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_cce2230832d6a50c_2dcd918d424b1980)
  unreachable
bb14:
  %t74 = load i64, ptr %l34, !tbaa !24
  %t75 = icmp sle i64 16, %t74
  br i1 %t75, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_cce2230832d6a50c_2dcd918d424b1980)
  unreachable
bb16:
  %t77 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr i8, ptr %t78, i64 0
  %t80 = sub i64 16, 0
  %t81 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t79, 1
  %t83 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t84 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t85 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 1
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t88 = add i64 %t84, %t87
  %t89 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t90 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t91 = add i64 %t88, %t90
  %t93 = extractvalue { i64, ptr } %t82, 1
  %t94 = extractvalue { i64, ptr } %t82, 0
  %t95 = add i64 %t91, %t94
  %t96 = load i64, ptr %l29
  %t97 = inttoptr i64 %t96 to ptr
  %t98 = call ptr @__olang_held_alloc(ptr %t97, i64 %t95)
  call void @olang_textcopy(ptr %t98, ptr %t83, i64 %t84)
  %t99 = getelementptr i8, ptr %t98, i64 %t84
  call void @olang_textcopy(ptr %t99, ptr %t86, i64 %t87)
  %t100 = getelementptr i8, ptr %t99, i64 %t87
  call void @olang_textcopy(ptr %t100, ptr %t89, i64 %t90)
  %t101 = getelementptr i8, ptr %t100, i64 %t90
  call void @olang_textcopy(ptr %t101, ptr %t93, i64 %t94)
  %t102 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t98, 1
  %t105 = load i64, ptr %l29
  %t106 = inttoptr i64 %t105 to ptr
  %t107 = extractvalue { i64, ptr } %t103, 0
  %t108 = extractvalue { i64, ptr } %t103, 1
  %t109 = mul i64 %t107, 1
  %t110 = call ptr @__olang_held_alloc(ptr %t106, i64 %t109)
  call void @llvm.memcpy.p0.p0.i64(ptr %t110, ptr %t108, i64 %t109, i1 false)
  %t111 = insertvalue { i64, ptr } undef, i64 %t107, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  %t113 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t114 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t113, 0
  %t116 = insertvalue [2 x { i64, ptr }] %t114, { i64, ptr } %t112, 1
  store [2 x { i64, ptr }] %t116, ptr %l8
  %t119 = insertvalue { i64, ptr } undef, i64 2, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %l8, 1
  %t122 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %v5, { i64, ptr } %t120)
  store { i64, ptr } %t122, ptr %l44
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_cce2230832d6a50c_2dcd918d424b1980)
  unreachable
bb18:
  call void @__olang_scope_close(ptr %s0)
  %t123 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t123, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ffix_2eToolsDir(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca [2 x { i64, ptr }]
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l11 = alloca i1
  %l16 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l22 = alloca i1
  %l26 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d12, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l7
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  store { i64, ptr } %t2, ptr %l6
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t6, ptr %l5, !tbaa !27
  br label %bb6
bb2:
  %t7 = load i32, ptr %l7, !tbaa !23
  %t8 = ashr i32 %t7, 16
  %t10 = icmp eq i32 %t8, 1
  br i1 %t10, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d13, i32 0, i32 1) }, ptr %l5, !tbaa !27
  br label %bb6
bb6:
  %t12 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t12, ptr %l2, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t15 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t13, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i1 %t15, ptr %l11
  br label %bb7
bb7:
  %t16 = load i1, ptr %l11, !tbaa !21
  %t17 = xor i1 %t16, true
  br i1 %t17, label %bb8, label %bb9
bb8:
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = extractvalue { i64, ptr } %t19, 0
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t21, i64 %t22)
  %t24 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t25, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t29 = call { i64, ptr } @std_2ffilepath_2eDir(ptr %v1, ptr %s0, { i64, ptr } %a1)
  store { i64, ptr } %t29, ptr %l16
  br label %bb11
bb11:
  %t30 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t31 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t30, 0
  %t32 = insertvalue [2 x { i64, ptr }] %t31, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  store [2 x { i64, ptr }] %t32, ptr %l3
  %t35 = insertvalue { i64, ptr } undef, i64 2, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %l3, 1
  %t38 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t36)
  store { i64, ptr } %t38, ptr %l20
  br label %bb12
bb12:
  %t39 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t39, ptr %l4, !tbaa !27
  %t40 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t42 = call i1 @std_2fos_2eIsDir(ptr %s0, { i64, ptr } %t40)
  store i1 %t42, ptr %l22
  br label %bb13
bb13:
  %t43 = load i1, ptr %l22, !tbaa !21
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t44 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 1
  %t47 = extractvalue { i64, ptr } %t44, 0
  %t48 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t47)
  call void @olang_textcopy(ptr %t48, ptr %t46, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t50, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t54 = call { i64, ptr } @std_2ffilepath_2eDir(ptr %v0, ptr %s0, { i64, ptr } %a0)
  store { i64, ptr } %t54, ptr %l26
  br label %bb17
bb17:
  %t55 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 1
  %t57 = extractvalue { i64, ptr } %t55, 0
  %t58 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t59 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t60 = add i64 %t57, %t59
  %t61 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t60)
  call void @olang_textcopy(ptr %t61, ptr %t56, i64 %t57)
  %t62 = getelementptr i8, ptr %t61, i64 %t57
  call void @olang_textcopy(ptr %t62, ptr %t58, i64 %t59)
  %t63 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t61, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t64, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ffix_2earguments(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %lp5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l37 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 32, i64 8)
  store ptr %t2, ptr %lp5
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  %t4 = load ptr, ptr %lp5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load ptr, ptr %lp5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v0, ptr %t5, { i64, ptr } %a0)
  br label %bb2
bb2:
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = load i64, ptr @G_2ecompiler_2ffix_2eStdTool, !tbaa !24
  %t13 = icmp eq i64 %t9, %t10
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %lp5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t15, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d17, i32 0, i32 1) })
  br label %bb5
bb4:
  %t17 = load i64, ptr %l1, !tbaa !24
  %t18 = load i64, ptr @G_2ecompiler_2ffix_2eDrivenOpt, !tbaa !24
  %t21 = icmp eq i64 %t17, %t18
  br i1 %t21, label %bb7, label %bb8
bb5:
  %t23 = load ptr, ptr %lp5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v2, ptr %t23, { i64, ptr } %a3)
  br label %bb6
bb6:
  br label %bb16
bb7:
  %t27 = load ptr, ptr %lp5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t27, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d18, i32 0, i32 1) })
  br label %bb9
bb8:
  %t29 = load i64, ptr %l1, !tbaa !24
  %t30 = load i64, ptr @G_2ecompiler_2ffix_2eDrivenArg, !tbaa !24
  %t33 = icmp eq i64 %t29, %t30
  br i1 %t33, label %bb11, label %bb12
bb9:
  %t35 = load ptr, ptr %lp5
  %t36 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v1, ptr %t35, { i64, ptr } %t36)
  br label %bb10
bb10:
  br label %bb15
bb11:
  %t39 = load ptr, ptr %lp5
  %t40 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v1, ptr %t39, { i64, ptr } %t40)
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  store { i64, ptr } %a4, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t45 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  store i64 %t47, ptr %l8, !tbaa !24
  br label %bb17
bb17:
  %t49 = load i64, ptr %l7, !tbaa !24
  %t50 = load i64, ptr %l8, !tbaa !24
  %t53 = icmp slt i64 %t49, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb18, label %bb19
bb18:
  br label %bb23
bb19:
  br label %bb20
bb20:
  %t57 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t57, ptr %l37, !tbaa !27
  %t58 = load i64, ptr %l7, !tbaa !24
  %t60 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr { i64, ptr }, ptr %t61, i64 %t58
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !37
  %t65 = load ptr, ptr %lp5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v3, ptr %t65, { i64, ptr } %t63)
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t69 = load i64, ptr %l7, !tbaa !24
  %t71 = add i64 %t69, 1
  store i64 %t71, ptr %l7, !tbaa !24
  br label %bb17
bb23:
  %t73 = load ptr, ptr %lp5
  %t75 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v4, ptr %v4, ptr %t73)
  store { i64, ptr } %t75, ptr %l45
  br label %bb24
bb24:
  %t76 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t76, ptr %l46, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t77, 0
  store i64 %t78, ptr %l47, !tbaa !24
  %t79 = load i64, ptr %l47, !tbaa !24
  %t80 = mul i64 %t79, 16
  %t81 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t80)
  %t82 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t81, 1
  store { i64, ptr } %t83, ptr %l48, !tbaa !27
  %t84 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = load i64, ptr %l47, !tbaa !24
  %t89 = mul i64 %t88, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t85, ptr %t87, i64 %t89, i1 false)
  %t90 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t90, ptr %l46, !tbaa !27
  %t91 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t91, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ffix_2ebuildAll(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, { i64, ptr } %a4) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca [45 x { i64, ptr }]
  %l18 = alloca i64
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca i64
  %l26 = alloca i64
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l35 = alloca i1
  %l44 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l51 = alloca i64
  %l54 = alloca i64
  %l82 = alloca { i64, ptr }
  %l83 = alloca i64
  %l84 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %jh5 = alloca ptr
  %rv = alloca { i64, ptr }
  %t11 = alloca i64
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @llvm.memmove.p0.p0.i64(ptr %l17, ptr @G_2ecompiler_2ffix_2eToolNames, i64 720, i1 false)
  %t1 = load [45 x { i64, ptr }], ptr %l17
  store i64 45, ptr %l18, !tbaa !24
  %t2 = load i64, ptr %l18, !tbaa !24
  %t3 = icmp sge i64 %t2, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l18, !tbaa !24
  %t6 = icmp sle i64 %t5, 576460752303423487
  br i1 %t6, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_f01e9d7c18290f7e_330799ec5065ffa2)
  unreachable
bb3:
  %t8 = load i64, ptr %l18, !tbaa !24
  %t9 = mul i64 %t8, 16
  %t10 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t9)
  store i64 0, ptr %t11
  br label %fill.12
fill.12:
  %t15 = load i64, ptr %t11
  %t16 = icmp slt i64 %t15, %t8
  br i1 %t16, label %fillb.13, label %filld.14
fillb.13:
  %t17 = getelementptr { i64, ptr }, ptr %t10, i64 %t15
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %t17
  %t18 = add i64 %t15, 1
  store i64 %t18, ptr %t11
  br label %fill.12
filld.14:
  %t19 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t10, 1
  store { i64, ptr } %t20, ptr %l5, !tbaa !27
  %t22 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l22
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_f01e9d7c18290f7e_330799ec5065ffa2)
  unreachable
bb5:
  %t23 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l6
  store ptr %a3, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb6
bb6:
  %t26 = load i64, ptr %l8, !tbaa !24
  store i64 %t26, ptr %l24, !tbaa !24
  %t27 = load ptr, ptr %l7, !tbaa !29
  %t29 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v3, ptr %t27)
  store i64 %t29, ptr %l26
  br label %bb7
bb7:
  %t30 = load i64, ptr %l24, !tbaa !24
  %t31 = load i64, ptr %l26, !tbaa !24
  %t32 = icmp slt i64 %t30, %t31
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb8, label %bb9
bb8:
  br label %bb18
bb9:
  br label %bb10
bb10:
  %t36 = load ptr, ptr %l7, !tbaa !29
  %t37 = load i64, ptr %l8, !tbaa !24
  %t40 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v3, ptr %t36, i64 %t37)
  store i64 %t40, ptr %l31
  br label %bb11
bb11:
  %t41 = load i64, ptr %l31, !tbaa !24
  store i64 %t41, ptr %l9, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t42, ptr %l32, !tbaa !27
  %t43 = load i64, ptr %l9, !tbaa !24
  %t45 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr { i64, ptr }, ptr %t46, i64 %t43
  %t48 = load { i64, ptr }, ptr %t47, !tbaa !37
  %t50 = call i1 @std_2fos_2eExists(ptr %v4, { i64, ptr } %t48)
  store i1 %t50, ptr %l35
  br label %bb12
bb12:
  %t51 = load i1, ptr %l35, !tbaa !21
  %t52 = xor i1 %t51, true
  br i1 %t52, label %bb13, label %bb14
bb13:
  %t54 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l6, i64 %t54)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t57 = load i64, ptr %l8, !tbaa !24
  %t59 = add i64 %t57, 1
  store i64 %t59, ptr %l8, !tbaa !24
  br label %bb6
bb18:
  %t61 = icmp sge i64 1, 0
  br i1 %t61, label %bb19, label %bb20
bb19:
  %t63 = icmp sle i64 1, 1152921504606846975
  br i1 %t63, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_5136839c006764b3_5260dfbee4468c57)
  unreachable
bb21:
  %t65 = mul i64 1, 8
  %t66 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t65)
  %t67 = insertvalue { i64, ptr } undef, i64 1, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  store { i64, ptr } %t68, ptr %l10, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s5
  store ptr null, ptr %jh5
  store i64 0, ptr %l11, !tbaa !24
  %t70 = load i64, ptr @G_2ecompiler_2ffix_2eBuildWidth, !tbaa !24
  store i64 %t70, ptr %l44, !tbaa !24
  %t72 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l6)
  store i64 %t72, ptr %l46
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_5136839c006764b3_5260dfbee4468c57)
  unreachable
bb23:
  %t73 = load i64, ptr %l44, !tbaa !24
  %t74 = load i64, ptr %l46, !tbaa !24
  %t75 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t73, i64 %t74)
  store i64 %t75, ptr %l47
  br label %bb24
bb24:
  %t76 = load i64, ptr %l47, !tbaa !24
  store i64 %t76, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t77 = load i64, ptr %l12, !tbaa !24
  %t78 = load i64, ptr %l11, !tbaa !24
  %t81 = icmp sgt i64 %t77, %t78
  br i1 %t81, label %bb25, label %bb26
bb25:
  %t83 = load i64, ptr %l13, !tbaa !24
  %t85 = icmp sgt i64 %t83, 0
  br i1 %t85, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb30
bb27:
  %t87 = load i64, ptr %l12, !tbaa !24
  %t88 = load i64, ptr %l11, !tbaa !24
  %t91 = sub i64 %t87, %t88
  %t92 = load i64, ptr %l13, !tbaa !24
  %t95 = add i64 %t91, %t92
  %t97 = sub i64 %t95, 1
  %t98 = load i64, ptr %l13, !tbaa !24
  %t101 = sdiv i64 %t97, %t98
  store i64 %t101, ptr %l54, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb29
bb29:
  %t103 = load i64, ptr %l54, !tbaa !24
  store i64 %t103, ptr %l51, !tbaa !24
  br label %bb30
bb30:
  %t104 = load i64, ptr %l51, !tbaa !24
  store i64 %t104, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb31
bb31:
  %t105 = load i64, ptr %l15, !tbaa !24
  %t106 = load i64, ptr %l14, !tbaa !24
  %t109 = icmp slt i64 %t105, %t106
  %t111 = xor i1 %t109, true
  br i1 %t111, label %bb32, label %bb33
bb32:
  br label %bb36
bb33:
  br label %bb34
bb34:
  %t113 = load i64, ptr %l11, !tbaa !24
  %t114 = load i64, ptr %l15, !tbaa !24
  %t115 = load i64, ptr %l13, !tbaa !24
  %t118 = mul i64 %t114, %t115
  %t121 = add i64 %t113, %t118
  store i64 %t121, ptr %l16, !tbaa !24
  %t126 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t127 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t128 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t136 = call ptr @__olang_standin(ptr %v0)
  %t137 = call ptr @__olang_standin(ptr %v1)
  %t138 = call ptr @__olang_standin(ptr %v2)
  %t139 = call ptr @__olang_standin(ptr %s0)
  %t140 = call ptr @__olang_standin(ptr %v4)
  %t141 = call ptr @__olang_standin(ptr %s0)
  %t142 = call ptr @__olang_standin(ptr %v5)
  %t143 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr null, i32 1
  %t144 = ptrtoint ptr %t143 to i64
  %t145 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 %t144, i64 8)
  %t146 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t145, i32 0, i32 0
  store { i64, ptr } %a0, ptr %t146
  %t147 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t145, i32 0, i32 1
  store { i64, ptr } %a1, ptr %t147
  %t148 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t145, i32 0, i32 2
  store { i64, ptr } %a2, ptr %t148
  %t149 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t145, i32 0, i32 3
  store ptr %l6, ptr %t149
  %t150 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t145, i32 0, i32 4
  store { i64, ptr } %t126, ptr %t150
  %t151 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t145, i32 0, i32 5
  store { i64, ptr } %t127, ptr %t151
  %t152 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t145, i32 0, i32 6
  store { i64, ptr } %t128, ptr %t152
  %t153 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t145, i32 0, i32 7
  store ptr %t136, ptr %t153
  %t154 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t145, i32 0, i32 8
  store ptr %t137, ptr %t154
  %t155 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t145, i32 0, i32 9
  store ptr %t138, ptr %t155
  %t156 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t145, i32 0, i32 10
  store ptr %t139, ptr %t156
  %t157 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t145, i32 0, i32 11
  store ptr %t140, ptr %t157
  %t158 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t145, i32 0, i32 12
  store ptr %t141, ptr %t158
  %t159 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t145, i32 0, i32 13
  store ptr %t142, ptr %t159
  %t160 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 40, i64 8)
  %t161 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 16, i64 8)
  store ptr null, ptr %t161
  %t162 = getelementptr { ptr, ptr }, ptr %t161, i32 0, i32 1
  store ptr %t136, ptr %t162
  %t163 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 16, i64 8)
  store ptr %t161, ptr %t163
  %t164 = getelementptr { ptr, ptr }, ptr %t163, i32 0, i32 1
  store ptr %t137, ptr %t164
  %t165 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 16, i64 8)
  store ptr %t163, ptr %t165
  %t166 = getelementptr { ptr, ptr }, ptr %t165, i32 0, i32 1
  store ptr %t138, ptr %t166
  %t167 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 16, i64 8)
  store ptr %t165, ptr %t167
  %t168 = getelementptr { ptr, ptr }, ptr %t167, i32 0, i32 1
  store ptr %t139, ptr %t168
  %t169 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 16, i64 8)
  store ptr %t167, ptr %t169
  %t170 = getelementptr { ptr, ptr }, ptr %t169, i32 0, i32 1
  store ptr %t140, ptr %t170
  %t171 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 16, i64 8)
  store ptr %t169, ptr %t171
  %t172 = getelementptr { ptr, ptr }, ptr %t171, i32 0, i32 1
  store ptr %t141, ptr %t172
  %t173 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 16, i64 8)
  store ptr %t171, ptr %t173
  %t174 = getelementptr { ptr, ptr }, ptr %t173, i32 0, i32 1
  store ptr %t142, ptr %t174
  %t175 = getelementptr { ptr, i64, ptr, i64, ptr }, ptr %t160, i32 0, i32 2
  store ptr %t173, ptr %t175
  %t176 = getelementptr { ptr, i64, ptr, i64, ptr }, ptr %t160, i32 0, i32 1
  store i64 0, ptr %t176
  %t177 = getelementptr { ptr, i64, ptr, i64, ptr }, ptr %t160, i32 0, i32 3
  store i64 0, ptr %t177
  %t178 = getelementptr { ptr, i64, ptr, i64, ptr }, ptr %t160, i32 0, i32 4
  store ptr null, ptr %t178
  %t179 = call ptr @__olang_worker_get()
  call void @__olang_worker_start(ptr %t179, ptr @olang_task20, ptr %t145, ptr %t160)
  %t180 = load ptr, ptr %jh5
  store ptr %t180, ptr %t160
  store ptr %t160, ptr %jh5
  br label %bb35
bb35:
  %t181 = load i64, ptr %l15, !tbaa !24
  %t183 = add i64 %t181, 1
  store i64 %t183, ptr %l15, !tbaa !24
  br label %bb31
bb36:
  %t185 = call i64 @__olang_join_tasks_keep(ptr %jh5, i1 false)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s5)
  br label %bb38
bb38:
  %t186 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t186, ptr %l82, !tbaa !27
  %t188 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t188, 0
  store i64 %t189, ptr %l83, !tbaa !24
  %t190 = load i64, ptr %l83, !tbaa !24
  %t191 = mul i64 %t190, 16
  %t192 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t191)
  %t193 = insertvalue { i64, ptr } undef, i64 %t190, 0
  %t194 = insertvalue { i64, ptr } %t193, ptr %t192, 1
  store { i64, ptr } %t194, ptr %l84, !tbaa !27
  %t195 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !27
  %t199 = load i64, ptr %l83, !tbaa !24
  %t200 = mul i64 %t199, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t196, ptr %t198, i64 %t200, i1 false)
  %t201 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t201, ptr %l82, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t202 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t202, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2ffix_2ebuildTool(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i32, { i64, [2 x i64] } }
  %l6 = alloca { i64, ptr }
  %l7 = alloca [2 x { i64, ptr }]
  %l8 = alloca { i64, ptr }
  %l9 = alloca [2 x { i64, ptr }]
  %l10 = alloca [5 x { i64, ptr }]
  %l11 = alloca { i32, { i64, [2 x i64] } }
  %l12 = alloca %"std/os:Output"
  %l13 = alloca { i32, { i64, [2 x i64] } }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca [2 x { i64, ptr }]
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i32
  %l29 = alloca i1
  %l30 = alloca { i32, { i64, [2 x i64] } }
  %l31 = alloca { i32, { i64, [2 x i64] } }
  %l32 = alloca i32
  %l37 = alloca { i32, { i64, [2 x i64] } }
  %l38 = alloca { i32, { i64, [2 x i64] } }
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i32, { i64, [2 x i64] } }
  %l44 = alloca { i32, { i64, [2 x i64] } }
  %l45 = alloca i32
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i64, [2 x i64] }
  %l62 = alloca i64
  %l64 = alloca { i64, [2 x i64] }
  %l67 = alloca { i64, ptr }
  %l68 = alloca i64
  %l76 = alloca { i64, ptr }
  %l77 = alloca %"std/os:Output"
  %l78 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l80 = alloca i64
  %l82 = alloca { i64, ptr }
  %l83 = alloca i64
  %l91 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l98 = alloca %"std/os:Output"
  %l99 = alloca i32
  %l101 = alloca i1
  %l102 = alloca { i32, { i64, [2 x i64] } }
  %l103 = alloca { i32, { i64, [2 x i64] } }
  %l104 = alloca i32
  %l109 = alloca { i32, { i64, [2 x i64] } }
  %l110 = alloca { i32, { i64, [2 x i64] } }
  %l113 = alloca { i64, ptr }
  %l114 = alloca { i32, { i64, [2 x i64] } }
  %l116 = alloca { i32, { i64, [2 x i64] } }
  %l117 = alloca i32
  %l132 = alloca { i64, ptr }
  %l133 = alloca { i64, [2 x i64] }
  %l134 = alloca i64
  %l136 = alloca { i64, [2 x i64] }
  %l138 = alloca i32
  %l140 = alloca i32
  %l142 = alloca i1
  %l151 = alloca { i64, [2 x i64] }
  %l152 = alloca i64
  %l154 = alloca { i64, [2 x i64] }
  %l156 = alloca i32
  %l158 = alloca i32
  %l160 = alloca i1
  %l165 = alloca i32
  %l167 = alloca i1
  %l168 = alloca { i32, { i64, [2 x i64] } }
  %l169 = alloca { i32, { i64, [2 x i64] } }
  %l170 = alloca i32
  %l175 = alloca { i32, { i64, [2 x i64] } }
  %l176 = alloca { i32, { i64, [2 x i64] } }
  %l179 = alloca { i64, ptr }
  %l180 = alloca { i32, { i64, [2 x i64] } }
  %l182 = alloca { i32, { i64, [2 x i64] } }
  %l183 = alloca i32
  %l198 = alloca { i64, ptr }
  %l199 = alloca { i64, [2 x i64] }
  %l200 = alloca i64
  %l202 = alloca { i64, [2 x i64] }
  %l204 = alloca i32
  %l206 = alloca i32
  %l208 = alloca i1
  %l211 = alloca { i64, ptr }
  %l213 = alloca { i64, ptr }
  %l214 = alloca i32
  %l227 = alloca { i64, ptr }
  %l235 = alloca { i64, ptr }
  %l240 = alloca i1
  %l241 = alloca i1
  %l244 = alloca i1
  %l247 = alloca i32
  %l249 = alloca i1
  %l255 = alloca i32
  %l257 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.builder
  %s3room = alloca [64 x i8], align 8
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.builder
  %s7room = alloca [64 x i8], align 8
  %s10 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.builder
  %s15room = alloca [64 x i8], align 8
  %s19 = alloca %olang.scope
  %rv = alloca i32
  %t97 = alloca { i64, [2 x i64] }, align 8
  %t430 = alloca { i64, [2 x i64] }, align 8
  %t629 = alloca { i64, [2 x i64] }, align 8
  %t733 = alloca { i64, [2 x i64] }, align 8
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t3 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %t2, 1
  %t7 = extractvalue { i64, ptr } %t2, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @olang_textcopy(ptr %t12, ptr %t3, i64 %t4)
  %t13 = getelementptr i8, ptr %t12, i64 %t4
  call void @olang_textcopy(ptr %t13, ptr %t6, i64 %t7)
  %t14 = getelementptr i8, ptr %t13, i64 %t7
  call void @olang_textcopy(ptr %t14, ptr %t9, i64 %t10)
  %t15 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t12, 1
  %t18 = extractvalue { i64, ptr } %t16, 0
  %t19 = extractvalue { i64, ptr } %t16, 1
  %t20 = mul i64 %t18, 1
  %t21 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t20)
  call void @llvm.memcpy.p0.p0.i64(ptr %t21, ptr %t19, i64 %t20, i1 false)
  %t22 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  %t26 = call { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %v2, ptr %s0, ptr %s0, { i64, ptr } %t1, { i64, ptr } %t23)
  %t27 = extractvalue { i32, { i64, ptr } } %t26, 1
  %t28 = extractvalue { i32, { i64, ptr } } %t26, 0
  store i32 %t28, ptr %l27
  %t29 = icmp ne i32 %t28, 0
  br i1 %t29, label %bb2, label %ok.30, !prof !99
ok.30:
  store { i64, ptr } %t27, ptr %l26
  br label %bb1
bb1:
  %t31 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t31, ptr %l21, !tbaa !27
  br label %bb26
bb2:
  %t32 = load i32, ptr %l27, !tbaa !23
  %t33 = ashr i32 %t32, 16
  %t35 = icmp eq i32 %t33, 1
  store i1 %t35, ptr %l29, !tbaa !21
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l5
  %t36 = load i32, ptr %l27, !tbaa !23
  %t37 = lshr i32 %t36, 16
  %t38 = and i32 %t36, 65535
  %t39 = icmp eq i32 %t37, 1
  %t40 = select i1 %t39, i32 1, i32 0
  %t41 = icmp eq i32 %t36, 0
  %t42 = shl i32 %t40, 16
  %t43 = or i32 %t42, %t38
  %t44 = select i1 %t41, i32 0, i32 %t43
  %t45 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l5, i32 0, i32 0
  store i32 %t44, ptr %t45, !tbaa !23
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t46 = load { i32, { i64, [2 x i64] } }, ptr %l5
  store { i32, { i64, [2 x i64] } } %t46, ptr %l30
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l31
  %t47 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l30, i32 0, i32 0
  %t48 = load i32, ptr %t47, !tbaa !23
  store i32 %t48, ptr %l32, !tbaa !23
  %t49 = load i32, ptr %l32, !tbaa !23
  %t50 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l31, i32 0, i32 0
  store i32 %t49, ptr %t50, !tbaa !23
  %t51 = load i32, ptr %l32, !tbaa !23
  %t52 = ashr i32 %t51, 16
  %t54 = icmp eq i32 %t52, 1
  br i1 %t54, label %bb4, label %bb5
bb4:
  %t56 = call ptr @__olang_errpay_top_get()
  %t58 = load { i64, [2 x i64] }, ptr %t56
  %t59 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l31, i32 0, i32 1
  store { i64, [2 x i64] } %t58, ptr %t59
  br label %bb5
bb5:
  %t61 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fos_3aError_7d(ptr %s0, ptr %l31)
  store { i32, { i64, [2 x i64] } } %t61, ptr %l37
  br label %bb6
bb6:
  %t62 = load { i32, { i64, [2 x i64] } }, ptr %l37
  store { i32, { i64, [2 x i64] } } %t62, ptr %l5
  %t63 = load { i32, { i64, [2 x i64] } }, ptr %l5
  store { i32, { i64, [2 x i64] } } %t63, ptr %l38
  %t64 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l38, i32 0, i32 0
  %t65 = load i32, ptr %t64, !tbaa !23
  %t66 = ashr i32 %t65, 16
  %t68 = icmp eq i32 %t66, 1
  br i1 %t68, label %bb7, label %bb8
bb7:
  call void @__olang_errpay_pop()
  br label %bb8
bb8:
  %t70 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t70, ptr %l41, !tbaa !27
  %t71 = load { i32, { i64, [2 x i64] } }, ptr %l5
  store { i32, { i64, [2 x i64] } } %t71, ptr %l42
  %t73 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fos_3aError_7d(ptr %s2, ptr %l42)
  store { i32, { i64, [2 x i64] } } %t73, ptr %l44
  br label %bb9
bb9:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s3
  store ptr %s3room, ptr %s3
  %t74 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t75 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t74, i64 %t75)
  %t76 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 1
  %t78 = extractvalue { i64, ptr } %t76, 0
  call void @__olang_sb_put(ptr %s3, ptr %t77, i64 %t78)
  %t79 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t79, i64 %t80)
  %t81 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l44, i32 0, i32 0
  %t82 = load i32, ptr %t81, !tbaa !23
  store i32 %t82, ptr %l45, !tbaa !23
  %t83 = load i32, ptr %l45, !tbaa !23
  %t84 = icmp eq i32 %t83, 0
  br i1 %t84, label %bb11, label %bb12
bb10:
  %t86 = load ptr, ptr %s3
  %t87 = getelementptr %olang.builder, ptr %s3, i32 0, i32 1
  %t88 = load i64, ptr %t87
  %t89 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t88)
  call void @olang_textcopy(ptr %t89, ptr %t86, i64 %t88)
  %t90 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  store { i64, ptr } %t91, ptr %l60, !tbaa !27
  %t92 = getelementptr %olang.builder, ptr %s3, i32 0, i32 3
  %t93 = load ptr, ptr %t92
  %t94 = icmp ne ptr %t93, null
  br i1 %t94, label %sbgrew.95, label %sbdone.96
sbgrew.95:
  call void @__olang_sb_done(ptr %s3)
  br label %sbdone.96
sbdone.96:
  store { i64, [2 x i64] } zeroinitializer, ptr %t97
  %t98 = getelementptr { i64, [2 x i64] }, ptr %t97, i32 0, i32 0
  store i64 0, ptr %t98
  %t99 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t100 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t99, 0
  %t101 = getelementptr { i64, [2 x i64] }, ptr %t97, i32 0, i32 1
  store { { i64, ptr } } %t100, ptr %t101
  %t102 = load { i64, [2 x i64] }, ptr %t97
  store { i64, [2 x i64] } %t102, ptr %l61
  %t103 = call ptr @__olang_errpay_push()
  %t104 = ptrtoint ptr %t103 to i64
  store i64 %t104, ptr %l62, !tbaa !24
  %t105 = load i64, ptr %l62
  %t106 = inttoptr i64 %t105 to ptr
  %t108 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffix_3aNotBuilt_24payload(ptr %t106, ptr %l61)
  store { i64, [2 x i64] } %t108, ptr %l64
  br label %bb25
bb11:
  %t109 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t110 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t109, i64 %t110)
  br label %bb10
bb12:
  %t111 = load i32, ptr %l45, !tbaa !23
  %t112 = icmp eq i32 %t111, 65536
  br i1 %t112, label %bb13, label %bb14
bb13:
  %t114 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t115 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t114, i64 %t115)
  %t116 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t117 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t116, i64 %t117)
  %t118 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l44, i32 0, i32 1
  %t119 = getelementptr { i64, [2 x i64] }, ptr %t118, i32 0, i32 1
  %t120 = getelementptr { { i64, ptr } }, ptr %t119, i32 0, i32 0
  %t121 = load { i64, ptr }, ptr %t120
  %t123 = extractvalue { i64, ptr } %t121, 1
  %t124 = extractvalue { i64, ptr } %t121, 0
  %t125 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t123, i64 %t124, i8 34)
  %t126 = call ptr @__olang_sb_room(ptr %s3, i64 %t125)
  %t127 = call i64 @__olang_rd_quote(ptr %t126, i64 0, ptr %t123, i64 %t124, i8 34)
  call void @__olang_sb_add(ptr %s3, i64 %t125)
  %t128 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t129 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t128, i64 %t129)
  br label %bb10
bb14:
  %t130 = load i32, ptr %l45, !tbaa !23
  %t131 = icmp eq i32 %t130, 65537
  br i1 %t131, label %bb15, label %bb16
bb15:
  %t133 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t134 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t133, i64 %t134)
  %t135 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t136 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t135, i64 %t136)
  %t137 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l44, i32 0, i32 1
  %t138 = getelementptr { i64, [2 x i64] }, ptr %t137, i32 0, i32 1
  %t139 = getelementptr { { i64, ptr } }, ptr %t138, i32 0, i32 0
  %t140 = load { i64, ptr }, ptr %t139
  %t142 = extractvalue { i64, ptr } %t140, 1
  %t143 = extractvalue { i64, ptr } %t140, 0
  %t144 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t142, i64 %t143, i8 34)
  %t145 = call ptr @__olang_sb_room(ptr %s3, i64 %t144)
  %t146 = call i64 @__olang_rd_quote(ptr %t145, i64 0, ptr %t142, i64 %t143, i8 34)
  call void @__olang_sb_add(ptr %s3, i64 %t144)
  %t147 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t148 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t147, i64 %t148)
  br label %bb10
bb16:
  %t149 = load i32, ptr %l45, !tbaa !23
  %t150 = icmp eq i32 %t149, 65538
  br i1 %t150, label %bb17, label %bb18
bb17:
  %t152 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t153 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t152, i64 %t153)
  %t154 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t155 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t154, i64 %t155)
  %t156 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l44, i32 0, i32 1
  %t157 = getelementptr { i64, [2 x i64] }, ptr %t156, i32 0, i32 1
  %t158 = getelementptr { { i64, ptr } }, ptr %t157, i32 0, i32 0
  %t159 = load { i64, ptr }, ptr %t158
  %t161 = extractvalue { i64, ptr } %t159, 1
  %t162 = extractvalue { i64, ptr } %t159, 0
  %t163 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t161, i64 %t162, i8 34)
  %t164 = call ptr @__olang_sb_room(ptr %s3, i64 %t163)
  %t165 = call i64 @__olang_rd_quote(ptr %t164, i64 0, ptr %t161, i64 %t162, i8 34)
  call void @__olang_sb_add(ptr %s3, i64 %t163)
  %t166 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t167 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t166, i64 %t167)
  br label %bb10
bb18:
  %t168 = load i32, ptr %l45, !tbaa !23
  %t169 = icmp eq i32 %t168, 65539
  br i1 %t169, label %bb19, label %bb20
bb19:
  %t171 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t172 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t171, i64 %t172)
  %t173 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t174 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t173, i64 %t174)
  %t175 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l44, i32 0, i32 1
  %t176 = getelementptr { i64, [2 x i64] }, ptr %t175, i32 0, i32 1
  %t177 = getelementptr { { i64, ptr } }, ptr %t176, i32 0, i32 0
  %t178 = load { i64, ptr }, ptr %t177
  %t180 = extractvalue { i64, ptr } %t178, 1
  %t181 = extractvalue { i64, ptr } %t178, 0
  %t182 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t180, i64 %t181, i8 34)
  %t183 = call ptr @__olang_sb_room(ptr %s3, i64 %t182)
  %t184 = call i64 @__olang_rd_quote(ptr %t183, i64 0, ptr %t180, i64 %t181, i8 34)
  call void @__olang_sb_add(ptr %s3, i64 %t182)
  %t185 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t186 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t185, i64 %t186)
  br label %bb10
bb20:
  %t187 = load i32, ptr %l45, !tbaa !23
  %t188 = icmp eq i32 %t187, 65540
  br i1 %t188, label %bb21, label %bb22
bb21:
  %t190 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t191 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t190, i64 %t191)
  %t192 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t193 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t192, i64 %t193)
  %t194 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l44, i32 0, i32 1
  %t195 = getelementptr { i64, [2 x i64] }, ptr %t194, i32 0, i32 1
  %t196 = getelementptr { { i64, ptr } }, ptr %t195, i32 0, i32 0
  %t197 = load { i64, ptr }, ptr %t196
  %t199 = extractvalue { i64, ptr } %t197, 1
  %t200 = extractvalue { i64, ptr } %t197, 0
  %t201 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t199, i64 %t200, i8 34)
  %t202 = call ptr @__olang_sb_room(ptr %s3, i64 %t201)
  %t203 = call i64 @__olang_rd_quote(ptr %t202, i64 0, ptr %t199, i64 %t200, i8 34)
  call void @__olang_sb_add(ptr %s3, i64 %t201)
  %t204 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t205 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t204, i64 %t205)
  br label %bb10
bb22:
  %t206 = load i32, ptr %l45, !tbaa !23
  %t207 = icmp eq i32 %t206, 65541
  br i1 %t207, label %bb23, label %bb24
bb23:
  %t209 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t210 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t209, i64 %t210)
  %t211 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t212 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t211, i64 %t212)
  %t213 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l44, i32 0, i32 1
  %t214 = getelementptr { i64, [2 x i64] }, ptr %t213, i32 0, i32 1
  %t215 = getelementptr { { i64, ptr } }, ptr %t214, i32 0, i32 0
  %t216 = load { i64, ptr }, ptr %t215
  %t218 = extractvalue { i64, ptr } %t216, 1
  %t219 = extractvalue { i64, ptr } %t216, 0
  %t220 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t218, i64 %t219, i8 34)
  %t221 = call ptr @__olang_sb_room(ptr %s3, i64 %t220)
  %t222 = call i64 @__olang_rd_quote(ptr %t221, i64 0, ptr %t218, i64 %t219, i8 34)
  call void @__olang_sb_add(ptr %s3, i64 %t220)
  %t223 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t224 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t223, i64 %t224)
  br label %bb10
bb24:
  %t225 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t226 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t225, i64 %t226)
  %t227 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t228 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t227, i64 %t228)
  %t229 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l44, i32 0, i32 1
  %t230 = getelementptr { i64, [2 x i64] }, ptr %t229, i32 0, i32 1
  %t231 = getelementptr { { i64, ptr } }, ptr %t230, i32 0, i32 0
  %t232 = load { i64, ptr }, ptr %t231
  %t234 = extractvalue { i64, ptr } %t232, 1
  %t235 = extractvalue { i64, ptr } %t232, 0
  %t236 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t234, i64 %t235, i8 34)
  %t237 = call ptr @__olang_sb_room(ptr %s3, i64 %t236)
  %t238 = call i64 @__olang_rd_quote(ptr %t237, i64 0, ptr %t234, i64 %t235, i8 34)
  call void @__olang_sb_add(ptr %s3, i64 %t236)
  %t239 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t240 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t239, i64 %t240)
  br label %bb10
bb25:
  %t241 = load { i64, [2 x i64] }, ptr %l64
  %t242 = load i64, ptr %l62
  %t243 = inttoptr i64 %t242 to ptr
  %t244 = call ptr @__olang_scope_alloc_a(ptr %t243, i64 24, i64 8)
  store { i64, [2 x i64] } %t241, ptr %t244
  call void @__olang_errpay_set(ptr %t244)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb26:
  %t247 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t247, ptr %l6, !tbaa !27
  %t248 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t248, ptr %l67, !tbaa !27
  %t249 = ptrtoint ptr %s0 to i64
  store i64 %t249, ptr %l68, !tbaa !24
  %t250 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_202_3e_2e_2d1
  br i1 %t250, label %bb27, label %bb28
bb27:
  %t252 = call ptr @__olang_region_make(ptr %s0)
  %t253 = ptrtoint ptr %t252 to i64
  store i64 %t253, ptr %l68, !tbaa !24
  br label %bb28
bb28:
  %t254 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t255 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t256 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t258 = extractvalue { i64, ptr } %t254, 1
  %t259 = extractvalue { i64, ptr } %t254, 0
  %t260 = add i64 %t256, %t259
  %t261 = load i64, ptr %l68
  %t262 = inttoptr i64 %t261 to ptr
  %t263 = call ptr @__olang_held_alloc(ptr %t262, i64 %t260)
  call void @olang_textcopy(ptr %t263, ptr %t255, i64 %t256)
  %t264 = getelementptr i8, ptr %t263, i64 %t256
  call void @olang_textcopy(ptr %t264, ptr %t258, i64 %t259)
  %t265 = insertvalue { i64, ptr } undef, i64 %t260, 0
  %t266 = insertvalue { i64, ptr } %t265, ptr %t263, 1
  %t268 = load i64, ptr %l68
  %t269 = inttoptr i64 %t268 to ptr
  %t270 = extractvalue { i64, ptr } %t266, 0
  %t271 = extractvalue { i64, ptr } %t266, 1
  %t272 = mul i64 %t270, 1
  %t273 = call ptr @__olang_held_alloc(ptr %t269, i64 %t272)
  call void @llvm.memcpy.p0.p0.i64(ptr %t273, ptr %t271, i64 %t272, i1 false)
  %t274 = insertvalue { i64, ptr } undef, i64 %t270, 0
  %t275 = insertvalue { i64, ptr } %t274, ptr %t273, 1
  %t276 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t277 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t276, 0
  %t279 = insertvalue [2 x { i64, ptr }] %t277, { i64, ptr } %t275, 1
  store [2 x { i64, ptr }] %t279, ptr %l7
  %t282 = insertvalue { i64, ptr } undef, i64 2, 0
  %t283 = insertvalue { i64, ptr } %t282, ptr %l7, 1
  %t285 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t283)
  store { i64, ptr } %t285, ptr %l76
  br label %bb29
bb29:
  %t286 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t286, ptr %l8, !tbaa !27
  %t287 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t287, ptr %l78, !tbaa !27
  %t288 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t288, ptr %l79, !tbaa !27
  %t289 = ptrtoint ptr %s0 to i64
  store i64 %t289, ptr %l80, !tbaa !24
  %t290 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_205_3e_2e_2d1
  br i1 %t290, label %bb30, label %bb31
bb30:
  %t292 = call ptr @__olang_region_make(ptr %s0)
  %t293 = ptrtoint ptr %t292 to i64
  store i64 %t293, ptr %l80, !tbaa !24
  br label %bb31
bb31:
  store { i64, ptr } %a1, ptr %l82, !tbaa !27
  %t295 = ptrtoint ptr %s0 to i64
  store i64 %t295, ptr %l83, !tbaa !24
  %t296 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_202_3e_2e_2d1
  br i1 %t296, label %bb32, label %bb33
bb32:
  %t298 = call ptr @__olang_region_make(ptr %s0)
  %t299 = ptrtoint ptr %t298 to i64
  store i64 %t299, ptr %l83, !tbaa !24
  br label %bb33
bb33:
  %t300 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t302 = extractvalue { i64, ptr } %t300, 1
  %t303 = extractvalue { i64, ptr } %t300, 0
  %t304 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t305 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t306 = add i64 %t303, %t305
  %t307 = load i64, ptr %l83
  %t308 = inttoptr i64 %t307 to ptr
  %t309 = call ptr @__olang_held_alloc(ptr %t308, i64 %t306)
  call void @olang_textcopy(ptr %t309, ptr %t302, i64 %t303)
  %t310 = getelementptr i8, ptr %t309, i64 %t303
  call void @olang_textcopy(ptr %t310, ptr %t304, i64 %t305)
  %t311 = insertvalue { i64, ptr } undef, i64 %t306, 0
  %t312 = insertvalue { i64, ptr } %t311, ptr %t309, 1
  %t314 = load i64, ptr %l83
  %t315 = inttoptr i64 %t314 to ptr
  %t316 = extractvalue { i64, ptr } %t312, 0
  %t317 = extractvalue { i64, ptr } %t312, 1
  %t318 = mul i64 %t316, 1
  %t319 = call ptr @__olang_held_alloc(ptr %t315, i64 %t318)
  call void @llvm.memcpy.p0.p0.i64(ptr %t319, ptr %t317, i64 %t318, i1 false)
  %t320 = insertvalue { i64, ptr } undef, i64 %t316, 0
  %t321 = insertvalue { i64, ptr } %t320, ptr %t319, 1
  %t322 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t323 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t322, 0
  %t325 = insertvalue [2 x { i64, ptr }] %t323, { i64, ptr } %t321, 1
  store [2 x { i64, ptr }] %t325, ptr %l9
  %t328 = insertvalue { i64, ptr } undef, i64 2, 0
  %t329 = insertvalue { i64, ptr } %t328, ptr %l9, 1
  %t330 = load i64, ptr %l80
  %t331 = inttoptr i64 %t330 to ptr
  %t333 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %t331, { i64, ptr } %t329)
  store { i64, ptr } %t333, ptr %l91
  br label %bb34
bb34:
  %t334 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t335 = load i64, ptr %l80
  %t336 = inttoptr i64 %t335 to ptr
  %t337 = extractvalue { i64, ptr } %t334, 0
  %t338 = extractvalue { i64, ptr } %t334, 1
  %t339 = mul i64 %t337, 1
  %t340 = call ptr @__olang_held_alloc(ptr %t336, i64 %t339)
  call void @llvm.memcpy.p0.p0.i64(ptr %t340, ptr %t338, i64 %t339, i1 false)
  %t341 = insertvalue { i64, ptr } undef, i64 %t337, 0
  %t342 = insertvalue { i64, ptr } %t341, ptr %t340, 1
  %t343 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t344 = insertvalue [5 x { i64, ptr }] undef, { i64, ptr } %t343, 0
  %t345 = insertvalue [5 x { i64, ptr }] %t344, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t346 = insertvalue [5 x { i64, ptr }] %t345, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d38, i32 0, i32 1) }, 2
  %t347 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t348 = insertvalue [5 x { i64, ptr }] %t346, { i64, ptr } %t347, 3
  %t350 = insertvalue [5 x { i64, ptr }] %t348, { i64, ptr } %t342, 4
  store [5 x { i64, ptr }] %t350, ptr %l10
  %t353 = insertvalue { i64, ptr } undef, i64 5, 0
  %t354 = insertvalue { i64, ptr } %t353, ptr %l10, 1
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d39, i32 0, i32 1) }, ptr %l96, !tbaa !27
  %t355 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t357 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t359 = call { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t354, { i64, ptr } %t357, i1 true, { i64, ptr } %t355)
  %t360 = extractvalue { i32, %"std/os:Output" } %t359, 1
  %t361 = extractvalue { i32, %"std/os:Output" } %t359, 0
  store i32 %t361, ptr %l99
  %t362 = icmp ne i32 %t361, 0
  br i1 %t362, label %bb36, label %ok.363, !prof !99
ok.363:
  store %"std/os:Output" %t360, ptr %l98
  br label %bb35
bb35:
  %t364 = load %"std/os:Output", ptr %l98
  store %"std/os:Output" %t364, ptr %l77
  br label %bb66
bb36:
  %t365 = load i32, ptr %l99, !tbaa !23
  %t366 = ashr i32 %t365, 16
  %t368 = icmp eq i32 %t366, 1
  store i1 %t368, ptr %l101, !tbaa !21
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l11
  %t369 = load i32, ptr %l99, !tbaa !23
  %t370 = lshr i32 %t369, 16
  %t371 = and i32 %t369, 65535
  %t372 = icmp eq i32 %t370, 1
  %t373 = select i1 %t372, i32 1, i32 0
  %t374 = icmp eq i32 %t369, 0
  %t375 = shl i32 %t373, 16
  %t376 = or i32 %t375, %t371
  %t377 = select i1 %t374, i32 0, i32 %t376
  %t378 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l11, i32 0, i32 0
  store i32 %t377, ptr %t378, !tbaa !23
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s6
  %t379 = load { i32, { i64, [2 x i64] } }, ptr %l11
  store { i32, { i64, [2 x i64] } } %t379, ptr %l102
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l103
  %t380 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l102, i32 0, i32 0
  %t381 = load i32, ptr %t380, !tbaa !23
  store i32 %t381, ptr %l104, !tbaa !23
  %t382 = load i32, ptr %l104, !tbaa !23
  %t383 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l103, i32 0, i32 0
  store i32 %t382, ptr %t383, !tbaa !23
  %t384 = load i32, ptr %l104, !tbaa !23
  %t385 = ashr i32 %t384, 16
  %t387 = icmp eq i32 %t385, 1
  br i1 %t387, label %bb38, label %bb39
bb38:
  %t389 = call ptr @__olang_errpay_top_get()
  %t391 = load { i64, [2 x i64] }, ptr %t389
  %t392 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l103, i32 0, i32 1
  store { i64, [2 x i64] } %t391, ptr %t392
  br label %bb39
bb39:
  %t394 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fos_3aError_7d(ptr %s0, ptr %l103)
  store { i32, { i64, [2 x i64] } } %t394, ptr %l109
  br label %bb40
bb40:
  %t395 = load { i32, { i64, [2 x i64] } }, ptr %l109
  store { i32, { i64, [2 x i64] } } %t395, ptr %l11
  %t396 = load { i32, { i64, [2 x i64] } }, ptr %l11
  store { i32, { i64, [2 x i64] } } %t396, ptr %l110
  %t397 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l110, i32 0, i32 0
  %t398 = load i32, ptr %t397, !tbaa !23
  %t399 = ashr i32 %t398, 16
  %t401 = icmp eq i32 %t399, 1
  br i1 %t401, label %bb41, label %bb42
bb41:
  call void @__olang_errpay_pop()
  br label %bb42
bb42:
  %t403 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t403, ptr %l113, !tbaa !27
  %t404 = load { i32, { i64, [2 x i64] } }, ptr %l11
  store { i32, { i64, [2 x i64] } } %t404, ptr %l114
  %t406 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fos_3aError_7d(ptr %s6, ptr %l114)
  store { i32, { i64, [2 x i64] } } %t406, ptr %l116
  br label %bb43
bb43:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s7
  store ptr %s7room, ptr %s7
  %t407 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t408 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t407, i64 %t408)
  %t409 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t410 = extractvalue { i64, ptr } %t409, 1
  %t411 = extractvalue { i64, ptr } %t409, 0
  call void @__olang_sb_put(ptr %s7, ptr %t410, i64 %t411)
  %t412 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t413 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t412, i64 %t413)
  %t414 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l116, i32 0, i32 0
  %t415 = load i32, ptr %t414, !tbaa !23
  store i32 %t415, ptr %l117, !tbaa !23
  %t416 = load i32, ptr %l117, !tbaa !23
  %t417 = icmp eq i32 %t416, 0
  br i1 %t417, label %bb45, label %bb46
bb44:
  %t419 = load ptr, ptr %s7
  %t420 = getelementptr %olang.builder, ptr %s7, i32 0, i32 1
  %t421 = load i64, ptr %t420
  %t422 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t421)
  call void @olang_textcopy(ptr %t422, ptr %t419, i64 %t421)
  %t423 = insertvalue { i64, ptr } undef, i64 %t421, 0
  %t424 = insertvalue { i64, ptr } %t423, ptr %t422, 1
  store { i64, ptr } %t424, ptr %l132, !tbaa !27
  %t425 = getelementptr %olang.builder, ptr %s7, i32 0, i32 3
  %t426 = load ptr, ptr %t425
  %t427 = icmp ne ptr %t426, null
  br i1 %t427, label %sbgrew.428, label %sbdone.429
sbgrew.428:
  call void @__olang_sb_done(ptr %s7)
  br label %sbdone.429
sbdone.429:
  store { i64, [2 x i64] } zeroinitializer, ptr %t430
  %t431 = getelementptr { i64, [2 x i64] }, ptr %t430, i32 0, i32 0
  store i64 0, ptr %t431
  %t432 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t433 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t432, 0
  %t434 = getelementptr { i64, [2 x i64] }, ptr %t430, i32 0, i32 1
  store { { i64, ptr } } %t433, ptr %t434
  %t435 = load { i64, [2 x i64] }, ptr %t430
  store { i64, [2 x i64] } %t435, ptr %l133
  %t436 = call ptr @__olang_errpay_push()
  %t437 = ptrtoint ptr %t436 to i64
  store i64 %t437, ptr %l134, !tbaa !24
  %t438 = load i64, ptr %l134
  %t439 = inttoptr i64 %t438 to ptr
  %t441 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffix_3aNotBuilt_24payload(ptr %t439, ptr %l133)
  store { i64, [2 x i64] } %t441, ptr %l136
  br label %bb59
bb45:
  %t442 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t443 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t442, i64 %t443)
  br label %bb44
bb46:
  %t444 = load i32, ptr %l117, !tbaa !23
  %t445 = icmp eq i32 %t444, 65536
  br i1 %t445, label %bb47, label %bb48
bb47:
  %t447 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t448 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t447, i64 %t448)
  %t449 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t450 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t449, i64 %t450)
  %t451 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l116, i32 0, i32 1
  %t452 = getelementptr { i64, [2 x i64] }, ptr %t451, i32 0, i32 1
  %t453 = getelementptr { { i64, ptr } }, ptr %t452, i32 0, i32 0
  %t454 = load { i64, ptr }, ptr %t453
  %t456 = extractvalue { i64, ptr } %t454, 1
  %t457 = extractvalue { i64, ptr } %t454, 0
  %t458 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t456, i64 %t457, i8 34)
  %t459 = call ptr @__olang_sb_room(ptr %s7, i64 %t458)
  %t460 = call i64 @__olang_rd_quote(ptr %t459, i64 0, ptr %t456, i64 %t457, i8 34)
  call void @__olang_sb_add(ptr %s7, i64 %t458)
  %t461 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t462 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t461, i64 %t462)
  br label %bb44
bb48:
  %t463 = load i32, ptr %l117, !tbaa !23
  %t464 = icmp eq i32 %t463, 65537
  br i1 %t464, label %bb49, label %bb50
bb49:
  %t466 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t467 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t466, i64 %t467)
  %t468 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t469 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t468, i64 %t469)
  %t470 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l116, i32 0, i32 1
  %t471 = getelementptr { i64, [2 x i64] }, ptr %t470, i32 0, i32 1
  %t472 = getelementptr { { i64, ptr } }, ptr %t471, i32 0, i32 0
  %t473 = load { i64, ptr }, ptr %t472
  %t475 = extractvalue { i64, ptr } %t473, 1
  %t476 = extractvalue { i64, ptr } %t473, 0
  %t477 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t475, i64 %t476, i8 34)
  %t478 = call ptr @__olang_sb_room(ptr %s7, i64 %t477)
  %t479 = call i64 @__olang_rd_quote(ptr %t478, i64 0, ptr %t475, i64 %t476, i8 34)
  call void @__olang_sb_add(ptr %s7, i64 %t477)
  %t480 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t481 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t480, i64 %t481)
  br label %bb44
bb50:
  %t482 = load i32, ptr %l117, !tbaa !23
  %t483 = icmp eq i32 %t482, 65538
  br i1 %t483, label %bb51, label %bb52
bb51:
  %t485 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t486 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t485, i64 %t486)
  %t487 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t488 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t487, i64 %t488)
  %t489 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l116, i32 0, i32 1
  %t490 = getelementptr { i64, [2 x i64] }, ptr %t489, i32 0, i32 1
  %t491 = getelementptr { { i64, ptr } }, ptr %t490, i32 0, i32 0
  %t492 = load { i64, ptr }, ptr %t491
  %t494 = extractvalue { i64, ptr } %t492, 1
  %t495 = extractvalue { i64, ptr } %t492, 0
  %t496 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t494, i64 %t495, i8 34)
  %t497 = call ptr @__olang_sb_room(ptr %s7, i64 %t496)
  %t498 = call i64 @__olang_rd_quote(ptr %t497, i64 0, ptr %t494, i64 %t495, i8 34)
  call void @__olang_sb_add(ptr %s7, i64 %t496)
  %t499 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t500 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t499, i64 %t500)
  br label %bb44
bb52:
  %t501 = load i32, ptr %l117, !tbaa !23
  %t502 = icmp eq i32 %t501, 65539
  br i1 %t502, label %bb53, label %bb54
bb53:
  %t504 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t505 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t504, i64 %t505)
  %t506 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t507 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t506, i64 %t507)
  %t508 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l116, i32 0, i32 1
  %t509 = getelementptr { i64, [2 x i64] }, ptr %t508, i32 0, i32 1
  %t510 = getelementptr { { i64, ptr } }, ptr %t509, i32 0, i32 0
  %t511 = load { i64, ptr }, ptr %t510
  %t513 = extractvalue { i64, ptr } %t511, 1
  %t514 = extractvalue { i64, ptr } %t511, 0
  %t515 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t513, i64 %t514, i8 34)
  %t516 = call ptr @__olang_sb_room(ptr %s7, i64 %t515)
  %t517 = call i64 @__olang_rd_quote(ptr %t516, i64 0, ptr %t513, i64 %t514, i8 34)
  call void @__olang_sb_add(ptr %s7, i64 %t515)
  %t518 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t519 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t518, i64 %t519)
  br label %bb44
bb54:
  %t520 = load i32, ptr %l117, !tbaa !23
  %t521 = icmp eq i32 %t520, 65540
  br i1 %t521, label %bb55, label %bb56
bb55:
  %t523 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t524 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t523, i64 %t524)
  %t525 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t526 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t525, i64 %t526)
  %t527 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l116, i32 0, i32 1
  %t528 = getelementptr { i64, [2 x i64] }, ptr %t527, i32 0, i32 1
  %t529 = getelementptr { { i64, ptr } }, ptr %t528, i32 0, i32 0
  %t530 = load { i64, ptr }, ptr %t529
  %t532 = extractvalue { i64, ptr } %t530, 1
  %t533 = extractvalue { i64, ptr } %t530, 0
  %t534 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t532, i64 %t533, i8 34)
  %t535 = call ptr @__olang_sb_room(ptr %s7, i64 %t534)
  %t536 = call i64 @__olang_rd_quote(ptr %t535, i64 0, ptr %t532, i64 %t533, i8 34)
  call void @__olang_sb_add(ptr %s7, i64 %t534)
  %t537 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t538 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t537, i64 %t538)
  br label %bb44
bb56:
  %t539 = load i32, ptr %l117, !tbaa !23
  %t540 = icmp eq i32 %t539, 65541
  br i1 %t540, label %bb57, label %bb58
bb57:
  %t542 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t543 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t542, i64 %t543)
  %t544 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t545 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t544, i64 %t545)
  %t546 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l116, i32 0, i32 1
  %t547 = getelementptr { i64, [2 x i64] }, ptr %t546, i32 0, i32 1
  %t548 = getelementptr { { i64, ptr } }, ptr %t547, i32 0, i32 0
  %t549 = load { i64, ptr }, ptr %t548
  %t551 = extractvalue { i64, ptr } %t549, 1
  %t552 = extractvalue { i64, ptr } %t549, 0
  %t553 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t551, i64 %t552, i8 34)
  %t554 = call ptr @__olang_sb_room(ptr %s7, i64 %t553)
  %t555 = call i64 @__olang_rd_quote(ptr %t554, i64 0, ptr %t551, i64 %t552, i8 34)
  call void @__olang_sb_add(ptr %s7, i64 %t553)
  %t556 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t557 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t556, i64 %t557)
  br label %bb44
bb58:
  %t558 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t559 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t558, i64 %t559)
  %t560 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t561 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t560, i64 %t561)
  %t562 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l116, i32 0, i32 1
  %t563 = getelementptr { i64, [2 x i64] }, ptr %t562, i32 0, i32 1
  %t564 = getelementptr { { i64, ptr } }, ptr %t563, i32 0, i32 0
  %t565 = load { i64, ptr }, ptr %t564
  %t567 = extractvalue { i64, ptr } %t565, 1
  %t568 = extractvalue { i64, ptr } %t565, 0
  %t569 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t567, i64 %t568, i8 34)
  %t570 = call ptr @__olang_sb_room(ptr %s7, i64 %t569)
  %t571 = call i64 @__olang_rd_quote(ptr %t570, i64 0, ptr %t567, i64 %t568, i8 34)
  call void @__olang_sb_add(ptr %s7, i64 %t569)
  %t572 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t573 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t572, i64 %t573)
  br label %bb44
bb59:
  %t574 = load { i64, [2 x i64] }, ptr %l136
  %t575 = load i64, ptr %l134
  %t576 = inttoptr i64 %t575 to ptr
  %t577 = call ptr @__olang_scope_alloc_a(ptr %t576, i64 24, i64 8)
  store { i64, [2 x i64] } %t574, ptr %t577
  call void @__olang_errpay_set(ptr %t577)
  store i32 65536, ptr %l138, !tbaa !23
  call void @__olang_scope_close(ptr %s6)
  %t579 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t581 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t579)
  store i32 %t581, ptr %l140
  %t582 = icmp ne i32 %t581, 0
  br i1 %t582, label %bb61, label %ok.583, !prof !99
ok.583:
  br label %bb60
bb60:
  br label %bb65
bb61:
  %t584 = load i32, ptr %l140, !tbaa !23
  %t585 = ashr i32 %t584, 16
  %t587 = icmp eq i32 %t585, 1
  store i1 %t587, ptr %l142, !tbaa !21
  %t588 = load i32, ptr %l140, !tbaa !23
  %t589 = ashr i32 %t588, 16
  %t591 = icmp eq i32 %t589, 1
  br i1 %t591, label %bb62, label %bb63
bb62:
  call void @__olang_errpay_pop()
  br label %bb63
bb63:
  br label %bb64
bb64:
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s0)
  %t593 = load i32, ptr %l138, !tbaa !23
  store i32 %t593, ptr %rv
  br label %ret
bb66:
  %t594 = load %"std/os:Output", ptr %l77
  store %"std/os:Output" %t594, ptr %l12
  %t595 = getelementptr %"std/os:Output", ptr %l12, i32 0, i32 0
  %t596 = load i32, ptr %t595, !tbaa !23
  %t598 = icmp ne i32 %t596, 0
  br i1 %t598, label %bb67, label %bb68
bb67:
  store %olang.scope zeroinitializer, ptr %s10
  %t600 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t601 = getelementptr %"std/os:Output", ptr %l12, i32 0, i32 1
  %t602 = load { i64, ptr }, ptr %t601, !tbaa !27
  %t603 = getelementptr %"std/os:Output", ptr %l12, i32 0, i32 2
  %t604 = load { i64, ptr }, ptr %t603, !tbaa !27
  %t605 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t606 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t608 = extractvalue { i64, ptr } %t600, 1
  %t609 = extractvalue { i64, ptr } %t600, 0
  %t610 = add i64 %t606, %t609
  %t611 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t612 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t613 = add i64 %t610, %t612
  %t615 = extractvalue { i64, ptr } %t602, 1
  %t616 = extractvalue { i64, ptr } %t602, 0
  %t617 = add i64 %t613, %t616
  %t619 = extractvalue { i64, ptr } %t604, 1
  %t620 = extractvalue { i64, ptr } %t604, 0
  %t621 = add i64 %t617, %t620
  %t622 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t621)
  call void @olang_textcopy(ptr %t622, ptr %t605, i64 %t606)
  %t623 = getelementptr i8, ptr %t622, i64 %t606
  call void @olang_textcopy(ptr %t623, ptr %t608, i64 %t609)
  %t624 = getelementptr i8, ptr %t623, i64 %t609
  call void @olang_textcopy(ptr %t624, ptr %t611, i64 %t612)
  %t625 = getelementptr i8, ptr %t624, i64 %t612
  call void @olang_textcopy(ptr %t625, ptr %t615, i64 %t616)
  %t626 = getelementptr i8, ptr %t625, i64 %t616
  call void @olang_textcopy(ptr %t626, ptr %t619, i64 %t620)
  %t627 = insertvalue { i64, ptr } undef, i64 %t621, 0
  %t628 = insertvalue { i64, ptr } %t627, ptr %t622, 1
  store { i64, [2 x i64] } zeroinitializer, ptr %t629
  %t630 = getelementptr { i64, [2 x i64] }, ptr %t629, i32 0, i32 0
  store i64 0, ptr %t630
  %t632 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t628, 0
  %t633 = getelementptr { i64, [2 x i64] }, ptr %t629, i32 0, i32 1
  store { { i64, ptr } } %t632, ptr %t633
  %t634 = load { i64, [2 x i64] }, ptr %t629
  store { i64, [2 x i64] } %t634, ptr %l151
  %t635 = call ptr @__olang_errpay_push()
  %t636 = ptrtoint ptr %t635 to i64
  store i64 %t636, ptr %l152, !tbaa !24
  %t637 = load i64, ptr %l152
  %t638 = inttoptr i64 %t637 to ptr
  %t640 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffix_3aNotBuilt_24payload(ptr %t638, ptr %l151)
  store { i64, [2 x i64] } %t640, ptr %l154
  br label %bb69
bb68:
  br label %bb76
bb69:
  %t641 = load { i64, [2 x i64] }, ptr %l154
  %t642 = load i64, ptr %l152
  %t643 = inttoptr i64 %t642 to ptr
  %t644 = call ptr @__olang_scope_alloc_a(ptr %t643, i64 24, i64 8)
  store { i64, [2 x i64] } %t641, ptr %t644
  call void @__olang_errpay_set(ptr %t644)
  store i32 65536, ptr %l156, !tbaa !23
  call void @__olang_scope_close(ptr %s10)
  %t646 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t648 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t646)
  store i32 %t648, ptr %l158
  %t649 = icmp ne i32 %t648, 0
  br i1 %t649, label %bb71, label %ok.650, !prof !99
ok.650:
  br label %bb70
bb70:
  br label %bb75
bb71:
  %t651 = load i32, ptr %l158, !tbaa !23
  %t652 = ashr i32 %t651, 16
  %t654 = icmp eq i32 %t652, 1
  store i1 %t654, ptr %l160, !tbaa !21
  %t655 = load i32, ptr %l158, !tbaa !23
  %t656 = ashr i32 %t655, 16
  %t658 = icmp eq i32 %t656, 1
  br i1 %t658, label %bb72, label %bb73
bb72:
  call void @__olang_errpay_pop()
  br label %bb73
bb73:
  br label %bb74
bb74:
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s0)
  %t660 = load i32, ptr %l156, !tbaa !23
  store i32 %t660, ptr %rv
  br label %ret
bb76:
  %t661 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t662 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t665 = call i32 @std_2fos_2eRename(ptr %s0, ptr %v4, { i64, ptr } %t661, { i64, ptr } %t662)
  store i32 %t665, ptr %l165
  %t666 = icmp ne i32 %t665, 0
  br i1 %t666, label %bb78, label %ok.667, !prof !99
ok.667:
  br label %bb77
bb77:
  br label %bb108
bb78:
  %t668 = load i32, ptr %l165, !tbaa !23
  %t669 = ashr i32 %t668, 16
  %t671 = icmp eq i32 %t669, 1
  store i1 %t671, ptr %l167, !tbaa !21
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l13
  %t672 = load i32, ptr %l165, !tbaa !23
  %t673 = lshr i32 %t672, 16
  %t674 = and i32 %t672, 65535
  %t675 = icmp eq i32 %t673, 1
  %t676 = select i1 %t675, i32 1, i32 0
  %t677 = icmp eq i32 %t672, 0
  %t678 = shl i32 %t676, 16
  %t679 = or i32 %t678, %t674
  %t680 = select i1 %t677, i32 0, i32 %t679
  %t681 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l13, i32 0, i32 0
  store i32 %t680, ptr %t681, !tbaa !23
  br label %bb79
bb79:
  store %olang.scope zeroinitializer, ptr %s14
  %t682 = load { i32, { i64, [2 x i64] } }, ptr %l13
  store { i32, { i64, [2 x i64] } } %t682, ptr %l168
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l169
  %t683 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l168, i32 0, i32 0
  %t684 = load i32, ptr %t683, !tbaa !23
  store i32 %t684, ptr %l170, !tbaa !23
  %t685 = load i32, ptr %l170, !tbaa !23
  %t686 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l169, i32 0, i32 0
  store i32 %t685, ptr %t686, !tbaa !23
  %t687 = load i32, ptr %l170, !tbaa !23
  %t688 = ashr i32 %t687, 16
  %t690 = icmp eq i32 %t688, 1
  br i1 %t690, label %bb80, label %bb81
bb80:
  %t692 = call ptr @__olang_errpay_top_get()
  %t694 = load { i64, [2 x i64] }, ptr %t692
  %t695 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l169, i32 0, i32 1
  store { i64, [2 x i64] } %t694, ptr %t695
  br label %bb81
bb81:
  %t697 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fos_3aError_7d(ptr %s0, ptr %l169)
  store { i32, { i64, [2 x i64] } } %t697, ptr %l175
  br label %bb82
bb82:
  %t698 = load { i32, { i64, [2 x i64] } }, ptr %l175
  store { i32, { i64, [2 x i64] } } %t698, ptr %l13
  %t699 = load { i32, { i64, [2 x i64] } }, ptr %l13
  store { i32, { i64, [2 x i64] } } %t699, ptr %l176
  %t700 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l176, i32 0, i32 0
  %t701 = load i32, ptr %t700, !tbaa !23
  %t702 = ashr i32 %t701, 16
  %t704 = icmp eq i32 %t702, 1
  br i1 %t704, label %bb83, label %bb84
bb83:
  call void @__olang_errpay_pop()
  br label %bb84
bb84:
  %t706 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t706, ptr %l179, !tbaa !27
  %t707 = load { i32, { i64, [2 x i64] } }, ptr %l13
  store { i32, { i64, [2 x i64] } } %t707, ptr %l180
  %t709 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fos_3aError_7d(ptr %s14, ptr %l180)
  store { i32, { i64, [2 x i64] } } %t709, ptr %l182
  br label %bb85
bb85:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s15
  store ptr %s15room, ptr %s15
  %t710 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d54, i32 0, i32 1) }, 1
  %t711 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d54, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t710, i64 %t711)
  %t712 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t713 = extractvalue { i64, ptr } %t712, 1
  %t714 = extractvalue { i64, ptr } %t712, 0
  call void @__olang_sb_put(ptr %s15, ptr %t713, i64 %t714)
  %t715 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t716 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t715, i64 %t716)
  %t717 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l182, i32 0, i32 0
  %t718 = load i32, ptr %t717, !tbaa !23
  store i32 %t718, ptr %l183, !tbaa !23
  %t719 = load i32, ptr %l183, !tbaa !23
  %t720 = icmp eq i32 %t719, 0
  br i1 %t720, label %bb87, label %bb88
bb86:
  %t722 = load ptr, ptr %s15
  %t723 = getelementptr %olang.builder, ptr %s15, i32 0, i32 1
  %t724 = load i64, ptr %t723
  %t725 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t724)
  call void @olang_textcopy(ptr %t725, ptr %t722, i64 %t724)
  %t726 = insertvalue { i64, ptr } undef, i64 %t724, 0
  %t727 = insertvalue { i64, ptr } %t726, ptr %t725, 1
  store { i64, ptr } %t727, ptr %l198, !tbaa !27
  %t728 = getelementptr %olang.builder, ptr %s15, i32 0, i32 3
  %t729 = load ptr, ptr %t728
  %t730 = icmp ne ptr %t729, null
  br i1 %t730, label %sbgrew.731, label %sbdone.732
sbgrew.731:
  call void @__olang_sb_done(ptr %s15)
  br label %sbdone.732
sbdone.732:
  store { i64, [2 x i64] } zeroinitializer, ptr %t733
  %t734 = getelementptr { i64, [2 x i64] }, ptr %t733, i32 0, i32 0
  store i64 0, ptr %t734
  %t735 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t736 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t735, 0
  %t737 = getelementptr { i64, [2 x i64] }, ptr %t733, i32 0, i32 1
  store { { i64, ptr } } %t736, ptr %t737
  %t738 = load { i64, [2 x i64] }, ptr %t733
  store { i64, [2 x i64] } %t738, ptr %l199
  %t739 = call ptr @__olang_errpay_push()
  %t740 = ptrtoint ptr %t739 to i64
  store i64 %t740, ptr %l200, !tbaa !24
  %t741 = load i64, ptr %l200
  %t742 = inttoptr i64 %t741 to ptr
  %t744 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffix_3aNotBuilt_24payload(ptr %t742, ptr %l199)
  store { i64, [2 x i64] } %t744, ptr %l202
  br label %bb101
bb87:
  %t745 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t746 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t745, i64 %t746)
  br label %bb86
bb88:
  %t747 = load i32, ptr %l183, !tbaa !23
  %t748 = icmp eq i32 %t747, 65536
  br i1 %t748, label %bb89, label %bb90
bb89:
  %t750 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d57, i32 0, i32 1) }, 1
  %t751 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d57, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t750, i64 %t751)
  %t752 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t753 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t752, i64 %t753)
  %t754 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l182, i32 0, i32 1
  %t755 = getelementptr { i64, [2 x i64] }, ptr %t754, i32 0, i32 1
  %t756 = getelementptr { { i64, ptr } }, ptr %t755, i32 0, i32 0
  %t757 = load { i64, ptr }, ptr %t756
  %t759 = extractvalue { i64, ptr } %t757, 1
  %t760 = extractvalue { i64, ptr } %t757, 0
  %t761 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t759, i64 %t760, i8 34)
  %t762 = call ptr @__olang_sb_room(ptr %s15, i64 %t761)
  %t763 = call i64 @__olang_rd_quote(ptr %t762, i64 0, ptr %t759, i64 %t760, i8 34)
  call void @__olang_sb_add(ptr %s15, i64 %t761)
  %t764 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t765 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t764, i64 %t765)
  br label %bb86
bb90:
  %t766 = load i32, ptr %l183, !tbaa !23
  %t767 = icmp eq i32 %t766, 65537
  br i1 %t767, label %bb91, label %bb92
bb91:
  %t769 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t770 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t769, i64 %t770)
  %t771 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t772 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t771, i64 %t772)
  %t773 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l182, i32 0, i32 1
  %t774 = getelementptr { i64, [2 x i64] }, ptr %t773, i32 0, i32 1
  %t775 = getelementptr { { i64, ptr } }, ptr %t774, i32 0, i32 0
  %t776 = load { i64, ptr }, ptr %t775
  %t778 = extractvalue { i64, ptr } %t776, 1
  %t779 = extractvalue { i64, ptr } %t776, 0
  %t780 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t778, i64 %t779, i8 34)
  %t781 = call ptr @__olang_sb_room(ptr %s15, i64 %t780)
  %t782 = call i64 @__olang_rd_quote(ptr %t781, i64 0, ptr %t778, i64 %t779, i8 34)
  call void @__olang_sb_add(ptr %s15, i64 %t780)
  %t783 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t784 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t783, i64 %t784)
  br label %bb86
bb92:
  %t785 = load i32, ptr %l183, !tbaa !23
  %t786 = icmp eq i32 %t785, 65538
  br i1 %t786, label %bb93, label %bb94
bb93:
  %t788 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t789 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t788, i64 %t789)
  %t790 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t791 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t790, i64 %t791)
  %t792 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l182, i32 0, i32 1
  %t793 = getelementptr { i64, [2 x i64] }, ptr %t792, i32 0, i32 1
  %t794 = getelementptr { { i64, ptr } }, ptr %t793, i32 0, i32 0
  %t795 = load { i64, ptr }, ptr %t794
  %t797 = extractvalue { i64, ptr } %t795, 1
  %t798 = extractvalue { i64, ptr } %t795, 0
  %t799 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t797, i64 %t798, i8 34)
  %t800 = call ptr @__olang_sb_room(ptr %s15, i64 %t799)
  %t801 = call i64 @__olang_rd_quote(ptr %t800, i64 0, ptr %t797, i64 %t798, i8 34)
  call void @__olang_sb_add(ptr %s15, i64 %t799)
  %t802 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t803 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t802, i64 %t803)
  br label %bb86
bb94:
  %t804 = load i32, ptr %l183, !tbaa !23
  %t805 = icmp eq i32 %t804, 65539
  br i1 %t805, label %bb95, label %bb96
bb95:
  %t807 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t808 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t807, i64 %t808)
  %t809 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t810 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t809, i64 %t810)
  %t811 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l182, i32 0, i32 1
  %t812 = getelementptr { i64, [2 x i64] }, ptr %t811, i32 0, i32 1
  %t813 = getelementptr { { i64, ptr } }, ptr %t812, i32 0, i32 0
  %t814 = load { i64, ptr }, ptr %t813
  %t816 = extractvalue { i64, ptr } %t814, 1
  %t817 = extractvalue { i64, ptr } %t814, 0
  %t818 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t816, i64 %t817, i8 34)
  %t819 = call ptr @__olang_sb_room(ptr %s15, i64 %t818)
  %t820 = call i64 @__olang_rd_quote(ptr %t819, i64 0, ptr %t816, i64 %t817, i8 34)
  call void @__olang_sb_add(ptr %s15, i64 %t818)
  %t821 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t822 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t821, i64 %t822)
  br label %bb86
bb96:
  %t823 = load i32, ptr %l183, !tbaa !23
  %t824 = icmp eq i32 %t823, 65540
  br i1 %t824, label %bb97, label %bb98
bb97:
  %t826 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t827 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t826, i64 %t827)
  %t828 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t829 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t828, i64 %t829)
  %t830 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l182, i32 0, i32 1
  %t831 = getelementptr { i64, [2 x i64] }, ptr %t830, i32 0, i32 1
  %t832 = getelementptr { { i64, ptr } }, ptr %t831, i32 0, i32 0
  %t833 = load { i64, ptr }, ptr %t832
  %t835 = extractvalue { i64, ptr } %t833, 1
  %t836 = extractvalue { i64, ptr } %t833, 0
  %t837 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t835, i64 %t836, i8 34)
  %t838 = call ptr @__olang_sb_room(ptr %s15, i64 %t837)
  %t839 = call i64 @__olang_rd_quote(ptr %t838, i64 0, ptr %t835, i64 %t836, i8 34)
  call void @__olang_sb_add(ptr %s15, i64 %t837)
  %t840 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t841 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t840, i64 %t841)
  br label %bb86
bb98:
  %t842 = load i32, ptr %l183, !tbaa !23
  %t843 = icmp eq i32 %t842, 65541
  br i1 %t843, label %bb99, label %bb100
bb99:
  %t845 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t846 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t845, i64 %t846)
  %t847 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t848 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t847, i64 %t848)
  %t849 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l182, i32 0, i32 1
  %t850 = getelementptr { i64, [2 x i64] }, ptr %t849, i32 0, i32 1
  %t851 = getelementptr { { i64, ptr } }, ptr %t850, i32 0, i32 0
  %t852 = load { i64, ptr }, ptr %t851
  %t854 = extractvalue { i64, ptr } %t852, 1
  %t855 = extractvalue { i64, ptr } %t852, 0
  %t856 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t854, i64 %t855, i8 34)
  %t857 = call ptr @__olang_sb_room(ptr %s15, i64 %t856)
  %t858 = call i64 @__olang_rd_quote(ptr %t857, i64 0, ptr %t854, i64 %t855, i8 34)
  call void @__olang_sb_add(ptr %s15, i64 %t856)
  %t859 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t860 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t859, i64 %t860)
  br label %bb86
bb100:
  %t861 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t862 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t861, i64 %t862)
  %t863 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t864 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t863, i64 %t864)
  %t865 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l182, i32 0, i32 1
  %t866 = getelementptr { i64, [2 x i64] }, ptr %t865, i32 0, i32 1
  %t867 = getelementptr { { i64, ptr } }, ptr %t866, i32 0, i32 0
  %t868 = load { i64, ptr }, ptr %t867
  %t870 = extractvalue { i64, ptr } %t868, 1
  %t871 = extractvalue { i64, ptr } %t868, 0
  %t872 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t870, i64 %t871, i8 34)
  %t873 = call ptr @__olang_sb_room(ptr %s15, i64 %t872)
  %t874 = call i64 @__olang_rd_quote(ptr %t873, i64 0, ptr %t870, i64 %t871, i8 34)
  call void @__olang_sb_add(ptr %s15, i64 %t872)
  %t875 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t876 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t875, i64 %t876)
  br label %bb86
bb101:
  %t877 = load { i64, [2 x i64] }, ptr %l202
  %t878 = load i64, ptr %l200
  %t879 = inttoptr i64 %t878 to ptr
  %t880 = call ptr @__olang_scope_alloc_a(ptr %t879, i64 24, i64 8)
  store { i64, [2 x i64] } %t877, ptr %t880
  call void @__olang_errpay_set(ptr %t880)
  store i32 65536, ptr %l204, !tbaa !23
  call void @__olang_scope_close(ptr %s14)
  %t882 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t884 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t882)
  store i32 %t884, ptr %l206
  %t885 = icmp ne i32 %t884, 0
  br i1 %t885, label %bb103, label %ok.886, !prof !99
ok.886:
  br label %bb102
bb102:
  br label %bb107
bb103:
  %t887 = load i32, ptr %l206, !tbaa !23
  %t888 = ashr i32 %t887, 16
  %t890 = icmp eq i32 %t888, 1
  store i1 %t890, ptr %l208, !tbaa !21
  %t891 = load i32, ptr %l206, !tbaa !23
  %t892 = ashr i32 %t891, 16
  %t894 = icmp eq i32 %t892, 1
  br i1 %t894, label %bb104, label %bb105
bb104:
  call void @__olang_errpay_pop()
  br label %bb105
bb105:
  br label %bb106
bb106:
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s0)
  %t896 = load i32, ptr %l204, !tbaa !23
  store i32 %t896, ptr %rv
  br label %ret
bb108:
  %t897 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t899 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v2, ptr %s0, { i64, ptr } %t897)
  %t900 = extractvalue { i32, { i64, ptr } } %t899, 1
  %t901 = extractvalue { i32, { i64, ptr } } %t899, 0
  store i32 %t901, ptr %l214
  %t902 = icmp ne i32 %t901, 0
  br i1 %t902, label %bb110, label %ok.903, !prof !99
ok.903:
  store { i64, ptr } %t900, ptr %l213
  br label %bb109
bb109:
  %t904 = load { i64, ptr }, ptr %l213, !tbaa !27
  store { i64, ptr } %t904, ptr %l211, !tbaa !27
  br label %bb118
bb110:
  %t905 = load i32, ptr %l214, !tbaa !23
  %t906 = ashr i32 %t905, 16
  %t908 = icmp eq i32 %t906, 1
  br i1 %t908, label %bb111, label %bb112
bb111:
  call void @__olang_errpay_pop()
  br label %bb112
bb112:
  br label %bb113
bb113:
  %t910 = icmp sge i64 0, 0
  br i1 %t910, label %bb114, label %bb115
bb114:
  %t912 = icmp sle i64 0, 576460752303423487
  br i1 %t912, label %bb116, label %bb117
bb115:
  call void @__olang_check_failed(ptr @olang_loc_233d982910cd3e61_6bc76ac40e1a9c3d)
  unreachable
bb116:
  %t914 = mul i64 0, 16
  %t915 = insertvalue { i64, ptr } undef, i64 0, 0
  %t916 = insertvalue { i64, ptr } %t915, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t916, ptr %l211, !tbaa !27
  br label %bb118
bb117:
  call void @__olang_check_failed(ptr @olang_loc_233d982910cd3e61_6bc76ac40e1a9c3d)
  unreachable
bb118:
  %t918 = load { i64, ptr }, ptr %l211, !tbaa !27
  store { i64, ptr } %t918, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t921 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t923 = extractvalue { i64, ptr } %t921, 0
  store i64 %t923, ptr %l17, !tbaa !24
  br label %bb119
bb119:
  store %olang.scope zeroinitializer, ptr %s19
  %t925 = load i64, ptr %l16, !tbaa !24
  %t926 = load i64, ptr %l17, !tbaa !24
  %t929 = icmp slt i64 %t925, %t926
  %t931 = xor i1 %t929, true
  br i1 %t931, label %bb120, label %bb121
bb120:
  call void @__olang_scope_close(ptr %s19)
  br label %bb139
bb121:
  br label %bb122
bb122:
  %t933 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t933, ptr %l227, !tbaa !27
  %t934 = load i64, ptr %l16, !tbaa !24
  %t936 = getelementptr { i64, ptr }, ptr %l227, i32 0, i32 1
  %t937 = load ptr, ptr %t936, !tbaa !27
  %t938 = getelementptr { i64, ptr }, ptr %t937, i64 %t934
  %t939 = load { i64, ptr }, ptr %t938, !tbaa !37
  store { i64, ptr } %t939, ptr %l18, !tbaa !27
  %t941 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t942 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t944 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t941, 0
  %t946 = insertvalue [2 x { i64, ptr }] %t944, { i64, ptr } %t942, 1
  store [2 x { i64, ptr }] %t946, ptr %l19
  %t949 = insertvalue { i64, ptr } undef, i64 2, 0
  %t950 = insertvalue { i64, ptr } %t949, ptr %l19, 1
  %t952 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s19, ptr %s19, { i64, ptr } %t950)
  store { i64, ptr } %t952, ptr %l235
  br label %bb123
bb123:
  %t953 = load { i64, ptr }, ptr %l235, !tbaa !27
  store { i64, ptr } %t953, ptr %l20, !tbaa !27
  %t954 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t955 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t956 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t957 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t959 = extractvalue { i64, ptr } %t955, 1
  %t960 = extractvalue { i64, ptr } %t955, 0
  %t961 = add i64 %t957, %t960
  %t962 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t963 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t964 = add i64 %t961, %t963
  %t965 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t964)
  call void @olang_textcopy(ptr %t965, ptr %t956, i64 %t957)
  %t966 = getelementptr i8, ptr %t965, i64 %t957
  call void @olang_textcopy(ptr %t966, ptr %t959, i64 %t960)
  %t967 = getelementptr i8, ptr %t966, i64 %t960
  call void @olang_textcopy(ptr %t967, ptr %t962, i64 %t963)
  %t968 = insertvalue { i64, ptr } undef, i64 %t964, 0
  %t969 = insertvalue { i64, ptr } %t968, ptr %t965, 1
  %t971 = extractvalue { i64, ptr } %t969, 0
  %t972 = extractvalue { i64, ptr } %t969, 1
  %t973 = mul i64 %t971, 1
  %t974 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t973)
  call void @llvm.memcpy.p0.p0.i64(ptr %t974, ptr %t972, i64 %t973, i1 false)
  %t975 = insertvalue { i64, ptr } undef, i64 %t971, 0
  %t976 = insertvalue { i64, ptr } %t975, ptr %t974, 1
  %t979 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s19, { i64, ptr } %t954, { i64, ptr } %t976)
  store i1 %t979, ptr %l240
  br label %bb124
bb124:
  %t980 = load i1, ptr %l240, !tbaa !21
  br i1 %t980, label %bb125, label %bb126
bb125:
  %t981 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t982 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t985 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s19, ptr %v4, { i64, ptr } %t981, { i64, ptr } %t982)
  store i1 %t985, ptr %l244
  br label %bb127
bb126:
  store i1 false, ptr %l241, !tbaa !21
  br label %bb128
bb127:
  %t986 = load i1, ptr %l244, !tbaa !21
  %t987 = xor i1 %t986, true
  store i1 %t987, ptr %l241, !tbaa !21
  br label %bb128
bb128:
  %t989 = load i1, ptr %l241, !tbaa !21
  br i1 %t989, label %bb129, label %bb130
bb129:
  %t990 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t992 = call i32 @std_2fos_2eRemoveAll(ptr %s19, { i64, ptr } %t990)
  store i32 %t992, ptr %l247
  %t993 = icmp ne i32 %t992, 0
  br i1 %t993, label %bb132, label %ok.994, !prof !99
ok.994:
  br label %bb131
bb130:
  br label %bb137
bb131:
  br label %bb136
bb132:
  %t995 = load i32, ptr %l247, !tbaa !23
  %t996 = ashr i32 %t995, 16
  %t998 = icmp eq i32 %t996, 1
  store i1 %t998, ptr %l249, !tbaa !21
  %t999 = load i32, ptr %l247, !tbaa !23
  %t1000 = ashr i32 %t999, 16
  %t1002 = icmp eq i32 %t1000, 1
  br i1 %t1002, label %bb133, label %bb134
bb133:
  call void @__olang_errpay_pop()
  br label %bb134
bb134:
  br label %bb135
bb135:
  br label %bb136
bb136:
  br label %bb137
bb137:
  call void @__olang_scope_close(ptr %s19)
  br label %bb138
bb138:
  %t1004 = load i64, ptr %l16, !tbaa !24
  %t1006 = add i64 %t1004, 1
  store i64 %t1006, ptr %l16, !tbaa !24
  br label %bb119
bb139:
  %t1008 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t1010 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t1008)
  store i32 %t1010, ptr %l255
  %t1011 = icmp ne i32 %t1010, 0
  br i1 %t1011, label %bb141, label %ok.1012, !prof !99
ok.1012:
  br label %bb140
bb140:
  br label %bb145
bb141:
  %t1013 = load i32, ptr %l255, !tbaa !23
  %t1014 = ashr i32 %t1013, 16
  %t1016 = icmp eq i32 %t1014, 1
  store i1 %t1016, ptr %l257, !tbaa !21
  %t1017 = load i32, ptr %l255, !tbaa !23
  %t1018 = ashr i32 %t1017, 16
  %t1020 = icmp eq i32 %t1018, 1
  br i1 %t1020, label %bb142, label %bb143
bb142:
  call void @__olang_errpay_pop()
  br label %bb143
bb143:
  br label %bb144
bb144:
  br label %bb145
bb145:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2ffix_2ebuilder(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, { i64, ptr } %a4, { i64, ptr } %a5, { i64, ptr } %a6) #0 {
entry:
  %l3 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i32, { i64, [2 x i64] } }
  %l10 = alloca { i64, ptr }
  %l13 = alloca i64
  %l15 = alloca i64
  %l19 = alloca i64
  %l25 = alloca { i64, ptr }
  %l28 = alloca i32
  %l30 = alloca i1
  %l31 = alloca { i32, { i64, [2 x i64] } }
  %l32 = alloca { i32, { i64, [2 x i64] } }
  %l33 = alloca i32
  %l38 = alloca { i32, { i64, [2 x i64] } }
  %l39 = alloca { i32, { i64, [2 x i64] } }
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca i64
  %s1 = alloca %olang.scope
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  store { i64, ptr } %a5, ptr %l10, !tbaa !27
  %t2 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t3 = load ptr, ptr %t2, !tbaa !27
  %t4 = getelementptr i64, ptr %t3, i64 0
  %t6 = atomicrmw add ptr %t4, i64 1 seq_cst
  store i64 %t6, ptr %l7, !tbaa !24
  %t8 = load i64, ptr %l7, !tbaa !24
  store i64 %t8, ptr %l13, !tbaa !24
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v3, ptr %t9)
  store i64 %t11, ptr %l15
  br label %bb2
bb2:
  %t12 = load i64, ptr %l13, !tbaa !24
  %t13 = load i64, ptr %l15, !tbaa !24
  %t14 = icmp sge i64 %t12, %t13
  br i1 %t14, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb4:
  br label %bb5
bb5:
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t17 = load i64, ptr %l7, !tbaa !24
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v3, ptr %t16, i64 %t17)
  store i64 %t20, ptr %l19
  br label %bb6
bb6:
  %t21 = load i64, ptr %l19, !tbaa !24
  store i64 %t21, ptr %l8, !tbaa !24
  %t25 = load i64, ptr %l8, !tbaa !24
  %t27 = getelementptr [45 x { i64, ptr }], ptr @G_2ecompiler_2ffix_2eToolNames, i64 0, i64 %t25
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !37
  store { i64, ptr } %a4, ptr %l25, !tbaa !27
  %t30 = load i64, ptr %l8, !tbaa !24
  %t32 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr { i64, ptr }, ptr %t33, i64 %t30
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !37
  %t36 = load ptr, ptr @__olang_prog_scope
  %t42 = call i32 @compiler_2ffix_2ebuildTool(ptr %v0, ptr %v1, ptr %v2, ptr %t36, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %t28, { i64, ptr } %t35)
  store i32 %t42, ptr %l28
  %t43 = icmp ne i32 %t42, 0
  br i1 %t43, label %bb8, label %ok.44, !prof !99
ok.44:
  br label %bb7
bb7:
  br label %bb17
bb8:
  %t45 = load i32, ptr %l28, !tbaa !23
  %t46 = ashr i32 %t45, 16
  %t48 = icmp eq i32 %t46, 1
  store i1 %t48, ptr %l30, !tbaa !21
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l9
  %t49 = load i32, ptr %l28, !tbaa !23
  %t50 = lshr i32 %t49, 16
  %t51 = and i32 %t49, 65535
  %t52 = icmp eq i32 %t50, 1
  %t53 = select i1 %t52, i32 1, i32 0
  %t54 = icmp eq i32 %t49, 0
  %t55 = shl i32 %t53, 16
  %t56 = or i32 %t55, %t51
  %t57 = select i1 %t54, i32 0, i32 %t56
  %t58 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l9, i32 0, i32 0
  store i32 %t57, ptr %t58, !tbaa !23
  br label %bb9
bb9:
  %t59 = load { i32, { i64, [2 x i64] } }, ptr %l9
  store { i32, { i64, [2 x i64] } } %t59, ptr %l31
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l32
  %t60 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l31, i32 0, i32 0
  %t61 = load i32, ptr %t60, !tbaa !23
  store i32 %t61, ptr %l33, !tbaa !23
  %t62 = load i32, ptr %l33, !tbaa !23
  %t63 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l32, i32 0, i32 0
  store i32 %t62, ptr %t63, !tbaa !23
  %t64 = load i32, ptr %l33, !tbaa !23
  %t65 = ashr i32 %t64, 16
  %t67 = icmp eq i32 %t65, 1
  br i1 %t67, label %bb10, label %bb11
bb10:
  %t69 = call ptr @__olang_errpay_top_get()
  %t71 = load { i64, [2 x i64] }, ptr %t69
  %t72 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l32, i32 0, i32 1
  store { i64, [2 x i64] } %t71, ptr %t72
  br label %bb11
bb11:
  %t74 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bcompiler_2ffix_3aNotBuilt_7d(ptr %s1, ptr %l32)
  store { i32, { i64, [2 x i64] } } %t74, ptr %l38
  br label %bb12
bb12:
  %t75 = load { i32, { i64, [2 x i64] } }, ptr %l38
  store { i32, { i64, [2 x i64] } } %t75, ptr %l9
  %t76 = load { i32, { i64, [2 x i64] } }, ptr %l9
  store { i32, { i64, [2 x i64] } } %t76, ptr %l39
  %t77 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l39, i32 0, i32 0
  %t78 = load i32, ptr %t77, !tbaa !23
  %t79 = ashr i32 %t78, 16
  %t81 = icmp eq i32 %t79, 1
  br i1 %t81, label %bb13, label %bb14
bb13:
  call void @__olang_errpay_pop()
  br label %bb14
bb14:
  store { i64, ptr } %a6, ptr %l42, !tbaa !27
  %t84 = load i64, ptr %l8, !tbaa !24
  store i64 %t84, ptr %l43, !tbaa !24
  %t85 = ptrtoint ptr %v6 to i64
  store i64 %t85, ptr %l44, !tbaa !24
  %t86 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t86, label %bb15, label %bb16
bb15:
  %t88 = call ptr @__olang_region_make(ptr %v6)
  %t89 = ptrtoint ptr %t88 to i64
  store i64 %t89, ptr %l44, !tbaa !24
  br label %bb16
bb16:
  %t90 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l9, i32 0, i32 1
  %t91 = getelementptr { i64, [2 x i64] }, ptr %t90, i32 0, i32 1
  %t92 = getelementptr { { i64, ptr } }, ptr %t91, i32 0, i32 0
  %t93 = load { i64, ptr }, ptr %t92
  %t95 = extractvalue { i64, ptr } %t93, 1
  %t96 = extractvalue { i64, ptr } %t93, 0
  %t97 = load i64, ptr %l44
  %t98 = inttoptr i64 %t97 to ptr
  %t99 = call ptr @__olang_held_alloc(ptr %t98, i64 %t96)
  call void @olang_textcopy(ptr %t99, ptr %t95, i64 %t96)
  %t100 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %t99, 1
  %t103 = load i64, ptr %l44
  %t104 = inttoptr i64 %t103 to ptr
  %t105 = extractvalue { i64, ptr } %t101, 0
  %t106 = extractvalue { i64, ptr } %t101, 1
  %t107 = mul i64 %t105, 1
  %t108 = call ptr @__olang_held_alloc(ptr %t104, i64 %t107)
  call void @llvm.memcpy.p0.p0.i64(ptr %t108, ptr %t106, i64 %t107, i1 false)
  %t109 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  %t112 = load i64, ptr %l43, !tbaa !24
  %t113 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr { i64, ptr }, ptr %t114, i64 %t112
  store { i64, ptr } %t110, ptr %t115, !tbaa !37
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s1)
  br label %bb18
bb18:
  br label %bb1
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ffix_2ebuiltBy(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/os:FileInfo"
  %l3 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l12 = alloca %"std/os:FileInfo"
  %l14 = alloca %"std/os:FileInfo"
  %l15 = alloca i32
  %l17 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %s0, { i64, ptr } %t1)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l6
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l5
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  br label %bb6
bb2:
  %t9 = load i32, ptr %l6, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  br i1 %t12, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  %t14 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 1
  %t17 = extractvalue { i64, ptr } %t14, 0
  %t18 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t17)
  call void @olang_textcopy(ptr %t18, ptr %t16, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t23 = extractvalue { i64, ptr } %t20, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l3, !tbaa !27
  br label %bb6
bb6:
  %t29 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t29, ptr %l1, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t32 = call { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %s0, { i64, ptr } %t30)
  %t33 = extractvalue { i32, %"std/os:FileInfo" } %t32, 1
  %t34 = extractvalue { i32, %"std/os:FileInfo" } %t32, 0
  store i32 %t34, ptr %l15
  %t35 = icmp ne i32 %t34, 0
  br i1 %t35, label %bb8, label %ok.36, !prof !99
ok.36:
  store %"std/os:FileInfo" %t33, ptr %l14
  br label %bb7
bb7:
  %t37 = load %"std/os:FileInfo", ptr %l14
  store %"std/os:FileInfo" %t37, ptr %l12
  br label %bb12
bb8:
  %t38 = load i32, ptr %l15, !tbaa !23
  %t39 = ashr i32 %t38, 16
  %t41 = icmp eq i32 %t39, 1
  store i1 %t41, ptr %l17, !tbaa !21
  %t42 = load i32, ptr %l15, !tbaa !23
  %t43 = ashr i32 %t42, 16
  %t45 = icmp eq i32 %t43, 1
  br i1 %t45, label %bb9, label %bb10
bb9:
  call void @__olang_errpay_pop()
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t47 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 1
  %t50 = extractvalue { i64, ptr } %t47, 0
  %t51 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t50)
  call void @olang_textcopy(ptr %t51, ptr %t49, i64 %t50)
  %t52 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t51, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t53, ptr %rv
  br label %ret
bb12:
  %t55 = load %"std/os:FileInfo", ptr %l12
  store %"std/os:FileInfo" %t55, ptr %l2
  %t56 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t57 = getelementptr %"std/os:FileInfo", ptr %l2, i32 0, i32 1
  %t58 = load i64, ptr %t57, !tbaa !24
  %t59 = getelementptr %"std/os:FileInfo", ptr %l2, i32 0, i32 2
  %t60 = load i64, ptr %t59, !tbaa !24
  %t62 = extractvalue { i64, ptr } %t56, 1
  %t63 = extractvalue { i64, ptr } %t56, 0
  %t64 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t65 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t66 = add i64 %t63, %t65
  %t68 = call i64 @__olang_fmt_i64(ptr null, i64 %t58)
  %t69 = add i64 %t66, %t68
  %t70 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t71 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t72 = add i64 %t69, %t71
  %t74 = call i64 @__olang_fmt_i64(ptr null, i64 %t60)
  %t75 = add i64 %t72, %t74
  %t76 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t75)
  call void @olang_textcopy(ptr %t76, ptr %t62, i64 %t63)
  %t77 = getelementptr i8, ptr %t76, i64 %t63
  call void @olang_textcopy(ptr %t77, ptr %t64, i64 %t65)
  %t78 = getelementptr i8, ptr %t77, i64 %t65
  %t79 = call i64 @__olang_fmt_i64(ptr %t78, i64 %t58)
  %t80 = getelementptr i8, ptr %t78, i64 %t68
  call void @olang_textcopy(ptr %t80, ptr %t70, i64 %t71)
  %t81 = getelementptr i8, ptr %t80, i64 %t71
  %t82 = call i64 @__olang_fmt_i64(ptr %t81, i64 %t60)
  %t83 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t76, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t84, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ffix_2ebyHand(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca %"std/prelude/text:LineIter"
  %l4 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/text:LineIter"
  %l7 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l12 = alloca i1
  %l14 = alloca i1
  %l18 = alloca i1
  %l20 = alloca i1
  %l22 = alloca i1
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  store i1 false, ptr %l2, !tbaa !21
  %t3 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store %"std/prelude/text:LineIter" %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load %"std/prelude/text:LineIter", ptr %l6
  store %"std/prelude/text:LineIter" %t4, ptr %l3
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t6 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v0, ptr %l3)
  %t7 = extractvalue { i32, { i64, ptr } } %t6, 1
  %t8 = extractvalue { i32, { i64, ptr } } %t6, 0
  store i32 %t8, ptr %l10
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb4, label %ok.10, !prof !99
ok.10:
  store { i64, ptr } %t7, ptr %l9
  br label %bb3
bb3:
  %t11 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t11, ptr %l7, !tbaa !27
  br label %bb6
bb4:
  %t12 = load i32, ptr %l10, !tbaa !23
  %t13 = ashr i32 %t12, 16
  %t15 = icmp eq i32 %t13, 1
  store i1 %t15, ptr %l12, !tbaa !21
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb6:
  %t16 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t16, ptr %l4, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t17, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d69, i32 0, i32 1) })
  store i1 %t19, ptr %l14
  br label %bb7
bb7:
  %t20 = load i1, ptr %l14, !tbaa !21
  br i1 %t20, label %bb8, label %bb9
bb8:
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = add i64 %t21, 1
  store i64 %t23, ptr %l1, !tbaa !24
  br label %bb21
bb9:
  store %olang.scope zeroinitializer, ptr %s4
  %t25 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t25, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d70, i32 0, i32 1) })
  store i1 %t27, ptr %l18
  br label %bb10
bb10:
  %t28 = load i1, ptr %l18, !tbaa !21
  br i1 %t28, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb20
bb12:
  store %olang.scope zeroinitializer, ptr %s6
  %t29 = load i1, ptr %l2, !tbaa !21
  br i1 %t29, label %bb13, label %bb14
bb13:
  %t31 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t33 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s6, { i64, ptr } %t31, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d71, i32 0, i32 1) })
  store i1 %t33, ptr %l22
  br label %bb15
bb14:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb16
bb15:
  %t34 = load i1, ptr %l22, !tbaa !21
  store i1 %t34, ptr %l20, !tbaa !21
  br label %bb16
bb16:
  %t35 = load i1, ptr %l20, !tbaa !21
  br i1 %t35, label %bb17, label %bb18
bb17:
  %t36 = load i64, ptr %l1, !tbaa !24
  %t38 = add i64 %t36, 1
  store i64 %t38, ptr %l1, !tbaa !24
  br label %bb19
bb18:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s6)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  br label %bb2
bb23:
  %t40 = load i64, ptr %l1, !tbaa !24
  store i64 %t40, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffix_2echecker(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca i1
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  br label %bb1
bb1:
  store { i64, ptr } %a2, ptr %l5, !tbaa !27
  %t2 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t3 = load ptr, ptr %t2, !tbaa !27
  %t4 = getelementptr i64, ptr %t3, i64 0
  %t6 = atomicrmw add ptr %t4, i64 1 seq_cst
  store i64 %t6, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t14 = icmp sge i64 %t8, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  store { i64, ptr } %a3, ptr %l12, !tbaa !27
  %t17 = load i64, ptr %l4, !tbaa !24
  store i64 %t17, ptr %l13, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t19, ptr %l15, !tbaa !27
  %t20 = load i64, ptr %l4, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %t23, i64 %t20
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !37
  %t28 = call i1 @compiler_2ffix_2ecompiles(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %t25)
  store i1 %t28, ptr %l18
  br label %bb5
bb5:
  %t29 = load i1, ptr %l18, !tbaa !21
  %t30 = xor i1 %t29, true
  %t32 = load i64, ptr %l13, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr i1, ptr %t34, i64 %t32
  store i1 %t30, ptr %t35, !tbaa !31
  br label %bb6
bb6:
  br label %bb1
ret:
  ret void
}

define dso_local void @compiler_2ffix_2eclosure(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/text:LineIter"
  %l7 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca [2 x { i64, ptr }]
  %l15 = alloca i1
  %l19 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i32
  %l30 = alloca %"std/prelude/text:LineIter"
  %l31 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i32
  %l36 = alloca i1
  %l38 = alloca { i64, ptr }
  %l40 = alloca i1
  %l42 = alloca i1
  %l44 = alloca i1
  %l46 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i32
  %l50 = alloca { i64, ptr }
  %l52 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l62 = alloca i1
  %l63 = alloca i1
  %l65 = alloca i1
  %l66 = alloca i1
  %l68 = alloca i1
  %l70 = alloca { i64, ptr }
  %l71 = alloca i64
  %l79 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t8 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20Boo_Hb38d151ad2865ce380f5e3d42761bdf3(ptr %v1, ptr %t3, { i64, ptr } %t1)
  store i1 %t8, ptr %l15
  br label %bb1
bb1:
  %t9 = load i1, ptr %l15, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 1
  %t14 = extractvalue { i64, ptr } %t11, 0
  %t15 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t14)
  call void @olang_textcopy(ptr %t15, ptr %t13, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20Boo_H6b1fa5c8028973ecd947936aac3caef3(ptr %v1, ptr %t10, { i64, ptr } %t17, i1 true)
  br label %bb5
bb5:
  %t20 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t22 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v2, { i64, ptr } %t20)
  %t23 = extractvalue { i32, { i64, ptr } } %t22, 1
  %t24 = extractvalue { i32, { i64, ptr } } %t22, 0
  store i32 %t24, ptr %l22
  %t25 = icmp ne i32 %t24, 0
  br i1 %t25, label %bb7, label %ok.26, !prof !99
ok.26:
  store { i64, ptr } %t23, ptr %l21
  br label %bb6
bb6:
  %t27 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t27, ptr %l19, !tbaa !27
  br label %bb11
bb7:
  %t28 = load i32, ptr %l22, !tbaa !23
  %t29 = ashr i32 %t28, 16
  %t31 = icmp eq i32 %t29, 1
  br i1 %t31, label %bb8, label %bb9
bb8:
  call void @__olang_errpay_pop()
  br label %bb9
bb9:
  br label %bb10
bb10:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d72, i32 0, i32 1) }, ptr %l19, !tbaa !27
  br label %bb11
bb11:
  %t33 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t33, ptr %l4, !tbaa !27
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t35 = load { i64, ptr }, ptr %l0, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v0, ptr %t34, { i64, ptr } %t35)
  br label %bb12
bb12:
  %t38 = load ptr, ptr %l2, !tbaa !29
  %t39 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t38, { i64, ptr } %t39)
  br label %bb13
bb13:
  %t42 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t44 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v2, ptr %v2, { i64, ptr } %t42)
  store %"std/prelude/text:LineIter" %t44, ptr %l30
  br label %bb14
bb14:
  %t45 = load %"std/prelude/text:LineIter", ptr %l30
  store %"std/prelude/text:LineIter" %t45, ptr %l5
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t47 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v2, ptr %v2, ptr %l5)
  %t48 = extractvalue { i32, { i64, ptr } } %t47, 1
  %t49 = extractvalue { i32, { i64, ptr } } %t47, 0
  store i32 %t49, ptr %l34
  %t50 = icmp ne i32 %t49, 0
  br i1 %t50, label %bb17, label %ok.51, !prof !99
ok.51:
  store { i64, ptr } %t48, ptr %l33
  br label %bb16
bb16:
  %t52 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t52, ptr %l31, !tbaa !27
  br label %bb19
bb17:
  %t53 = load i32, ptr %l34, !tbaa !23
  %t54 = ashr i32 %t53, 16
  %t56 = icmp eq i32 %t54, 1
  store i1 %t56, ptr %l36, !tbaa !21
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb57
bb19:
  %t57 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t60 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v2, ptr %v2, { i64, ptr } %t57)
  store { i64, ptr } %t60, ptr %l38
  br label %bb20
bb20:
  %t61 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t61, ptr %l7, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t64 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v2, ptr %s4, { i64, ptr } %t62, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d73, i32 0, i32 1) })
  store i1 %t64, ptr %l40
  br label %bb21
bb21:
  %t65 = load i1, ptr %l40, !tbaa !21
  %t66 = xor i1 %t65, true
  br i1 %t66, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb25
bb23:
  %t68 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t70 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v2, ptr %s4, { i64, ptr } %t68, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d74, i32 0, i32 1) })
  store i1 %t70, ptr %l44
  br label %bb24
bb24:
  %t71 = load i1, ptr %l44, !tbaa !21
  %t72 = xor i1 %t71, true
  store i1 %t72, ptr %l42, !tbaa !21
  br label %bb25
bb25:
  %t74 = load i1, ptr %l42, !tbaa !21
  br i1 %t74, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s4)
  br label %bb56
bb27:
  br label %bb28
bb28:
  %t75 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t77 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v2, ptr %s4, { i64, ptr } %t75, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d75, i32 0, i32 1) })
  %t78 = extractvalue { i32, i64 } %t77, 1
  %t79 = extractvalue { i32, i64 } %t77, 0
  store i32 %t79, ptr %l49
  %t80 = icmp ne i32 %t79, 0
  br i1 %t80, label %bb30, label %ok.81, !prof !99
ok.81:
  store i64 %t78, ptr %l48
  br label %bb29
bb29:
  %t82 = load i64, ptr %l48, !tbaa !24
  store i64 %t82, ptr %l46, !tbaa !24
  br label %bb32
bb30:
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s4)
  br label %bb56
bb32:
  %t83 = load i64, ptr %l46, !tbaa !24
  %t84 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t84, ptr %l50, !tbaa !27
  %t87 = add i64 %t83, 1
  store i64 %t87, ptr %l52, !tbaa !24
  %t88 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t92 = sub i64 %t90, 1
  store i64 %t92, ptr %l55, !tbaa !24
  %t93 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 0
  store i64 %t94, ptr %l56, !tbaa !24
  %t95 = load i64, ptr %l52, !tbaa !24
  %t96 = icmp sge i64 %t95, 0
  br i1 %t96, label %bb33, label %bb34
bb33:
  %t98 = load i64, ptr %l52, !tbaa !24
  %t99 = load i64, ptr %l55, !tbaa !24
  %t100 = icmp sle i64 %t98, %t99
  br i1 %t100, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_d81bb51d20d074b4_82b493c82ed1c1e0)
  unreachable
bb35:
  %t102 = load i64, ptr %l55, !tbaa !24
  %t103 = load i64, ptr %l56, !tbaa !24
  %t104 = icmp sle i64 %t102, %t103
  br i1 %t104, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_d81bb51d20d074b4_82b493c82ed1c1e0)
  unreachable
bb37:
  %t106 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = load i64, ptr %l52, !tbaa !24
  %t109 = load i64, ptr %l55, !tbaa !24
  %t110 = getelementptr i8, ptr %t107, i64 %t108
  %t111 = sub i64 %t109, %t108
  %t112 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t110, 1
  store { i64, ptr } %t113, ptr %l9, !tbaa !27
  %t115 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t117 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v2, ptr %s4, { i64, ptr } %t115, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d76, i32 0, i32 1) })
  store i1 %t117, ptr %l62
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_d81bb51d20d074b4_82b493c82ed1c1e0)
  unreachable
bb39:
  %t118 = load i1, ptr %l62, !tbaa !21
  br i1 %t118, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l63, !tbaa !21
  br label %bb43
bb41:
  %t119 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t121 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v2, ptr %s4, { i64, ptr } %t119, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d77, i32 0, i32 1) })
  store i1 %t121, ptr %l65
  br label %bb42
bb42:
  %t122 = load i1, ptr %l65, !tbaa !21
  store i1 %t122, ptr %l63, !tbaa !21
  br label %bb43
bb43:
  %t123 = load i1, ptr %l63, !tbaa !21
  br i1 %t123, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb47
bb45:
  %t124 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t126 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v2, ptr %s4, { i64, ptr } %t124, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d78, i32 0, i32 1) })
  store i1 %t126, ptr %l68
  br label %bb46
bb46:
  %t127 = load i1, ptr %l68, !tbaa !21
  store i1 %t127, ptr %l66, !tbaa !21
  br label %bb47
bb47:
  %t128 = load i1, ptr %l66, !tbaa !21
  br i1 %t128, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s4)
  br label %bb56
bb49:
  br label %bb50
bb50:
  %t129 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t131 = call { i64, ptr } @std_2ffilepath_2eDir(ptr %v0, ptr %s4, { i64, ptr } %t129)
  store { i64, ptr } %t131, ptr %l70
  br label %bb51
bb51:
  %t132 = ptrtoint ptr %s4 to i64
  store i64 %t132, ptr %l71, !tbaa !24
  %t133 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_202_3e_2e_2d1
  br i1 %t133, label %bb52, label %bb53
bb52:
  %t135 = call ptr @__olang_region_make(ptr %s4)
  %t136 = ptrtoint ptr %t135 to i64
  store i64 %t136, ptr %l71, !tbaa !24
  br label %bb53
bb53:
  %t137 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t137, 1
  %t140 = extractvalue { i64, ptr } %t137, 0
  %t141 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d79, i32 0, i32 1) }, 1
  %t142 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d79, i32 0, i32 1) }, 0
  %t143 = add i64 %t140, %t142
  %t144 = load i64, ptr %l71
  %t145 = inttoptr i64 %t144 to ptr
  %t146 = call ptr @__olang_held_alloc(ptr %t145, i64 %t143)
  call void @olang_textcopy(ptr %t146, ptr %t139, i64 %t140)
  %t147 = getelementptr i8, ptr %t146, i64 %t140
  call void @olang_textcopy(ptr %t147, ptr %t141, i64 %t142)
  %t148 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t146, 1
  %t151 = load i64, ptr %l71
  %t152 = inttoptr i64 %t151 to ptr
  %t153 = extractvalue { i64, ptr } %t149, 0
  %t154 = extractvalue { i64, ptr } %t149, 1
  %t155 = mul i64 %t153, 1
  %t156 = call ptr @__olang_held_alloc(ptr %t152, i64 %t155)
  call void @llvm.memcpy.p0.p0.i64(ptr %t156, ptr %t154, i64 %t155, i1 false)
  %t157 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t156, 1
  %t159 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t160 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t159, 0
  %t162 = insertvalue [2 x { i64, ptr }] %t160, { i64, ptr } %t158, 1
  store [2 x { i64, ptr }] %t162, ptr %l10
  %t165 = insertvalue { i64, ptr } undef, i64 2, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %l10, 1
  %t168 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s4, ptr %v2, { i64, ptr } %t166)
  store { i64, ptr } %t168, ptr %l79
  br label %bb54
bb54:
  %t169 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t169, 0
  %t171 = extractvalue { i64, ptr } %t169, 1
  %t172 = mul i64 %t170, 1
  %t173 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t172)
  call void @llvm.memcpy.p0.p0.i64(ptr %t173, ptr %t171, i64 %t172, i1 false)
  %t174 = insertvalue { i64, ptr } undef, i64 %t170, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t173, 1
  %t176 = load ptr, ptr %l1, !tbaa !29
  %t177 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ffix_2eclosure(ptr %v2, ptr %v1, ptr %v2, { i64, ptr } %t175, ptr %t176, ptr %t177)
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s4)
  br label %bb56
bb56:
  br label %bb15
bb57:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffix_2ecompiles(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca [2 x { i64, ptr }]
  %l5 = alloca [6 x { i64, ptr }]
  %l6 = alloca %"std/os:Output"
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %l11 = alloca i1
  %l15 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l24 = alloca %"std/os:Output"
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l32 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l40 = alloca %"std/os:Output"
  %l41 = alloca i32
  %l43 = alloca i1
  %l46 = alloca i1
  %l48 = alloca i32
  %l50 = alloca i1
  %l54 = alloca i1
  %l56 = alloca i32
  %l58 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d80, i32 0, i32 1) }, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d81, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l9
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  store { i64, ptr } %t2, ptr %l8
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t6, ptr %l7, !tbaa !27
  br label %bb6
bb2:
  %t7 = load i32, ptr %l9, !tbaa !23
  %t8 = ashr i32 %t7, 16
  %t10 = icmp eq i32 %t8, 1
  store i1 %t10, ptr %l11, !tbaa !21
  %t11 = load i32, ptr %l9, !tbaa !23
  %t12 = ashr i32 %t11, 16
  %t14 = icmp eq i32 %t12, 1
  br i1 %t14, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  %t17 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t17, ptr %l2, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t20 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v1, ptr %s0, { i64, ptr } %t18)
  %t21 = extractvalue { i32, { i64, ptr } } %t20, 1
  %t22 = extractvalue { i32, { i64, ptr } } %t20, 0
  store i32 %t22, ptr %l18
  %t23 = icmp ne i32 %t22, 0
  br i1 %t23, label %bb8, label %ok.24, !prof !99
ok.24:
  store { i64, ptr } %t21, ptr %l17
  br label %bb7
bb7:
  %t25 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t25, ptr %l15, !tbaa !27
  br label %bb12
bb8:
  %t26 = load i32, ptr %l18, !tbaa !23
  %t27 = ashr i32 %t26, 16
  %t29 = icmp eq i32 %t27, 1
  br i1 %t29, label %bb9, label %bb10
bb9:
  call void @__olang_errpay_pop()
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t31 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 1
  %t34 = extractvalue { i64, ptr } %t31, 0
  %t35 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t34)
  call void @olang_textcopy(ptr %t35, ptr %t33, i64 %t34)
  %t36 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t40 = extractvalue { i64, ptr } %t37, 1
  %t41 = mul i64 %t39, 1
  %t42 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t41)
  call void @llvm.memcpy.p0.p0.i64(ptr %t42, ptr %t40, i64 %t41, i1 false)
  %t43 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  store { i64, ptr } %t44, ptr %l15, !tbaa !27
  br label %bb12
bb12:
  %t46 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t46, ptr %l3, !tbaa !27
  store { i64, ptr } %a0, ptr %l25, !tbaa !27
  %t48 = ptrtoint ptr %s0 to i64
  store i64 %t48, ptr %l26, !tbaa !24
  %t49 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_206_3e_2e_2d1
  br i1 %t49, label %bb13, label %bb14
bb13:
  %t51 = call ptr @__olang_region_make(ptr %s0)
  %t52 = ptrtoint ptr %t51 to i64
  store i64 %t52, ptr %l26, !tbaa !24
  br label %bb14
bb14:
  %t53 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t55 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t53, 0
  %t56 = insertvalue [2 x { i64, ptr }] %t55, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d82, i32 0, i32 1) }, 1
  store [2 x { i64, ptr }] %t56, ptr %l4
  %t59 = insertvalue { i64, ptr } undef, i64 2, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %l4, 1
  %t61 = load i64, ptr %l26
  %t62 = inttoptr i64 %t61 to ptr
  %t64 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %t62, { i64, ptr } %t60)
  store { i64, ptr } %t64, ptr %l32
  br label %bb15
bb15:
  %t65 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t66 = load i64, ptr %l26
  %t67 = inttoptr i64 %t66 to ptr
  %t68 = extractvalue { i64, ptr } %t65, 0
  %t69 = extractvalue { i64, ptr } %t65, 1
  %t70 = mul i64 %t68, 1
  %t71 = call ptr @__olang_held_alloc(ptr %t67, i64 %t70)
  call void @llvm.memcpy.p0.p0.i64(ptr %t71, ptr %t69, i64 %t70, i1 false)
  %t72 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t71, 1
  %t74 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t76 = insertvalue [6 x { i64, ptr }] undef, { i64, ptr } %t75, 0
  %t77 = insertvalue [6 x { i64, ptr }] %t76, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d83, i32 0, i32 1) }, 1
  %t78 = insertvalue [6 x { i64, ptr }] %t77, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d84, i32 0, i32 1) }, 2
  %t79 = insertvalue [6 x { i64, ptr }] %t78, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d85, i32 0, i32 1) }, 3
  %t81 = insertvalue [6 x { i64, ptr }] %t79, { i64, ptr } %t73, 4
  %t83 = insertvalue [6 x { i64, ptr }] %t81, { i64, ptr } %t74, 5
  store [6 x { i64, ptr }] %t83, ptr %l5
  %t86 = insertvalue { i64, ptr } undef, i64 6, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %l5, 1
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d39, i32 0, i32 1) }, ptr %l38, !tbaa !27
  %t88 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t92 = call { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t87, { i64, ptr } %t90, i1 true, { i64, ptr } %t88)
  %t93 = extractvalue { i32, %"std/os:Output" } %t92, 1
  %t94 = extractvalue { i32, %"std/os:Output" } %t92, 0
  store i32 %t94, ptr %l41
  %t95 = icmp ne i32 %t94, 0
  br i1 %t95, label %bb17, label %ok.96, !prof !99
ok.96:
  store %"std/os:Output" %t93, ptr %l40
  br label %bb16
bb16:
  %t97 = load %"std/os:Output", ptr %l40
  store %"std/os:Output" %t97, ptr %l24
  br label %bb27
bb17:
  %t98 = load i32, ptr %l41, !tbaa !23
  %t99 = ashr i32 %t98, 16
  %t101 = icmp eq i32 %t99, 1
  store i1 %t101, ptr %l43, !tbaa !21
  %t102 = load i32, ptr %l41, !tbaa !23
  %t103 = ashr i32 %t102, 16
  %t105 = icmp eq i32 %t103, 1
  br i1 %t105, label %bb18, label %bb19
bb18:
  call void @__olang_errpay_pop()
  br label %bb19
bb19:
  br label %bb20
bb20:
  store i1 false, ptr %l46, !tbaa !21
  %t107 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t109 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t107)
  store i32 %t109, ptr %l48
  %t110 = icmp ne i32 %t109, 0
  br i1 %t110, label %bb22, label %ok.111, !prof !99
ok.111:
  br label %bb21
bb21:
  br label %bb26
bb22:
  %t112 = load i32, ptr %l48, !tbaa !23
  %t113 = ashr i32 %t112, 16
  %t115 = icmp eq i32 %t113, 1
  store i1 %t115, ptr %l50, !tbaa !21
  %t116 = load i32, ptr %l48, !tbaa !23
  %t117 = ashr i32 %t116, 16
  %t119 = icmp eq i32 %t117, 1
  br i1 %t119, label %bb23, label %bb24
bb23:
  call void @__olang_errpay_pop()
  br label %bb24
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  %t121 = load i1, ptr %l46, !tbaa !21
  store i1 %t121, ptr %rv
  br label %ret
bb27:
  %t122 = load %"std/os:Output", ptr %l24
  store %"std/os:Output" %t122, ptr %l6
  %t123 = getelementptr %"std/os:Output", ptr %l6, i32 0, i32 0
  %t124 = load i32, ptr %t123, !tbaa !23
  %t126 = icmp eq i32 %t124, 0
  store i1 %t126, ptr %l54, !tbaa !21
  %t127 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t129 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t127)
  store i32 %t129, ptr %l56
  %t130 = icmp ne i32 %t129, 0
  br i1 %t130, label %bb29, label %ok.131, !prof !99
ok.131:
  br label %bb28
bb28:
  br label %bb33
bb29:
  %t132 = load i32, ptr %l56, !tbaa !23
  %t133 = ashr i32 %t132, 16
  %t135 = icmp eq i32 %t133, 1
  store i1 %t135, ptr %l58, !tbaa !21
  %t136 = load i32, ptr %l56, !tbaa !23
  %t137 = ashr i32 %t136, 16
  %t139 = icmp eq i32 %t137, 1
  br i1 %t139, label %bb30, label %bb31
bb30:
  call void @__olang_errpay_pop()
  br label %bb31
bb31:
  br label %bb32
bb32:
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s0)
  %t141 = load i1, ptr %l54, !tbaa !21
  store i1 %t141, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffix_2edriven(i64 %a0) #0 {
entry:
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i64, ptr @G_2ecompiler_2ffix_2eDrivenOpt, !tbaa !24
  %t5 = icmp sge i64 %a0, %t2
  store i1 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffix_2eexpand(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %lp1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca { i64, ptr }
  %l18 = alloca i1
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  br label %bb5
bb5:
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t19, ptr %l14, !tbaa !27
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %t23, i64 %t20
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !37
  store { i64, ptr } %t25, ptr %l5, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t29 = call i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %t27)
  store i1 %t29, ptr %l18
  br label %bb6
bb6:
  %t30 = load i1, ptr %l18, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  %t31 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t32 = load ptr, ptr %lp1
  call void @compiler_2ffix_2ewalk(ptr %v0, ptr %v1, { i64, ptr } %t31, ptr %t32)
  br label %bb9
bb8:
  %t35 = load ptr, ptr %lp1
  %t36 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v0, ptr %t35, { i64, ptr } %t36)
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t41 = add i64 %t39, 1
  store i64 %t41, ptr %l3, !tbaa !24
  br label %bb2
bb13:
  %t43 = load ptr, ptr %lp1
  %t44 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t43
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local { i64, ptr } @compiler_2ffix_2efailing(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %lp10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca i64
  %l27 = alloca i64
  %l31 = alloca i64
  %l34 = alloca i64
  %l58 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l64 = alloca i64
  %l67 = alloca i64
  %l85 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l97 = alloca i64
  %l98 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %jh1 = alloca ptr
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l18, !tbaa !24
  %t4 = load i64, ptr %l18, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l18, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l2, !tbaa !27
  %t13 = icmp sge i64 1, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_40dc5ad5899010ef_fc275eeb26e8323)
  unreachable
bb3:
  %t15 = icmp sle i64 1, 1152921504606846975
  br i1 %t15, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_20258a28ab60401a_640e38b19bcc26ae)
  unreachable
bb5:
  %t17 = mul i64 1, 8
  %t18 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 1, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s1
  store ptr null, ptr %jh1
  store i64 0, ptr %l4, !tbaa !24
  %t22 = load i64, ptr @G_2ecompiler_2ffix_2eCheckWidth, !tbaa !24
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t28 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t22, i64 %t25)
  store i64 %t28, ptr %l27
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_20258a28ab60401a_640e38b19bcc26ae)
  unreachable
bb7:
  %t29 = load i64, ptr %l27, !tbaa !24
  store i64 %t29, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = icmp sgt i64 %t30, %t31
  br i1 %t34, label %bb8, label %bb9
bb8:
  %t36 = load i64, ptr %l6, !tbaa !24
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb13
bb10:
  %t40 = load i64, ptr %l5, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = sub i64 %t40, %t41
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = add i64 %t44, %t45
  %t50 = sub i64 %t48, 1
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = sdiv i64 %t50, %t51
  store i64 %t54, ptr %l34, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb12
bb12:
  %t56 = load i64, ptr %l34, !tbaa !24
  store i64 %t56, ptr %l31, !tbaa !24
  br label %bb13
bb13:
  %t57 = load i64, ptr %l31, !tbaa !24
  store i64 %t57, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb14
bb14:
  %t58 = load i64, ptr %l8, !tbaa !24
  %t59 = load i64, ptr %l7, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb15, label %bb16
bb15:
  br label %bb19
bb16:
  br label %bb17
bb17:
  %t66 = load i64, ptr %l4, !tbaa !24
  %t67 = load i64, ptr %l8, !tbaa !24
  %t68 = load i64, ptr %l6, !tbaa !24
  %t71 = mul i64 %t67, %t68
  %t74 = add i64 %t66, %t71
  store i64 %t74, ptr %l9, !tbaa !24
  %t77 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t78 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t84 = call ptr @__olang_standin(ptr %v0)
  %t85 = call ptr @__olang_standin(ptr %v1)
  %t86 = call ptr @__olang_standin(ptr %s0)
  %t87 = call ptr @__olang_standin(ptr %s0)
  %t88 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr null, i32 1
  %t89 = ptrtoint ptr %t88 to i64
  %t90 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 %t89, i64 8)
  %t91 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t90, i32 0, i32 0
  store { i64, ptr } %a0, ptr %t91
  %t92 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t90, i32 0, i32 1
  store { i64, ptr } %t77, ptr %t92
  %t93 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t90, i32 0, i32 2
  store { i64, ptr } %t78, ptr %t93
  %t94 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t90, i32 0, i32 3
  store { i64, ptr } %t79, ptr %t94
  %t95 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t90, i32 0, i32 4
  store ptr %t84, ptr %t95
  %t96 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t90, i32 0, i32 5
  store ptr %t85, ptr %t96
  %t97 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t90, i32 0, i32 6
  store ptr %t86, ptr %t97
  %t98 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t90, i32 0, i32 7
  store ptr %t87, ptr %t98
  %t99 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 40, i64 8)
  %t100 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 16, i64 8)
  store ptr null, ptr %t100
  %t101 = getelementptr { ptr, ptr }, ptr %t100, i32 0, i32 1
  store ptr %t84, ptr %t101
  %t102 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 16, i64 8)
  store ptr %t100, ptr %t102
  %t103 = getelementptr { ptr, ptr }, ptr %t102, i32 0, i32 1
  store ptr %t85, ptr %t103
  %t104 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 16, i64 8)
  store ptr %t102, ptr %t104
  %t105 = getelementptr { ptr, ptr }, ptr %t104, i32 0, i32 1
  store ptr %t86, ptr %t105
  %t106 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 16, i64 8)
  store ptr %t104, ptr %t106
  %t107 = getelementptr { ptr, ptr }, ptr %t106, i32 0, i32 1
  store ptr %t87, ptr %t107
  %t108 = getelementptr { ptr, i64, ptr, i64, ptr }, ptr %t99, i32 0, i32 2
  store ptr %t106, ptr %t108
  %t109 = getelementptr { ptr, i64, ptr, i64, ptr }, ptr %t99, i32 0, i32 1
  store i64 0, ptr %t109
  %t110 = getelementptr { ptr, i64, ptr, i64, ptr }, ptr %t99, i32 0, i32 3
  store i64 0, ptr %t110
  %t111 = getelementptr { ptr, i64, ptr, i64, ptr }, ptr %t99, i32 0, i32 4
  store ptr null, ptr %t111
  %t112 = call ptr @__olang_worker_get()
  call void @__olang_worker_start(ptr %t112, ptr @olang_task86, ptr %t90, ptr %t99)
  %t113 = load ptr, ptr %jh1
  store ptr %t113, ptr %t99
  store ptr %t99, ptr %jh1
  br label %bb18
bb18:
  %t114 = load i64, ptr %l8, !tbaa !24
  %t116 = add i64 %t114, 1
  store i64 %t116, ptr %l8, !tbaa !24
  br label %bb14
bb19:
  %t118 = call i64 @__olang_join_tasks_keep(ptr %jh1, i1 false)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s1)
  br label %bb21
bb21:
  %t119 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t119, ptr %l58
  br label %bb22
bb22:
  %t120 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t120, ptr %lp10
  %t121 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l58
  %t122 = load ptr, ptr %lp10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t121, ptr %t122
  store i64 0, ptr %l11, !tbaa !24
  %t123 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t123, 0
  store i64 %t125, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t127 = load i64, ptr %l12, !tbaa !24
  %t128 = load i64, ptr %l11, !tbaa !24
  %t131 = icmp sgt i64 %t127, %t128
  br i1 %t131, label %bb23, label %bb24
bb23:
  %t133 = load i64, ptr %l13, !tbaa !24
  %t135 = icmp sgt i64 %t133, 0
  br i1 %t135, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb28
bb25:
  %t137 = load i64, ptr %l12, !tbaa !24
  %t138 = load i64, ptr %l11, !tbaa !24
  %t141 = sub i64 %t137, %t138
  %t142 = load i64, ptr %l13, !tbaa !24
  %t145 = add i64 %t141, %t142
  %t147 = sub i64 %t145, 1
  %t148 = load i64, ptr %l13, !tbaa !24
  %t151 = sdiv i64 %t147, %t148
  store i64 %t151, ptr %l67, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l67, !tbaa !24
  br label %bb27
bb27:
  %t153 = load i64, ptr %l67, !tbaa !24
  store i64 %t153, ptr %l64, !tbaa !24
  br label %bb28
bb28:
  %t154 = load i64, ptr %l64, !tbaa !24
  store i64 %t154, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb29
bb29:
  %t155 = load i64, ptr %l15, !tbaa !24
  %t156 = load i64, ptr %l14, !tbaa !24
  %t159 = icmp slt i64 %t155, %t156
  %t161 = xor i1 %t159, true
  br i1 %t161, label %bb30, label %bb31
bb30:
  br label %bb38
bb31:
  br label %bb32
bb32:
  %t163 = load i64, ptr %l11, !tbaa !24
  %t164 = load i64, ptr %l15, !tbaa !24
  %t165 = load i64, ptr %l13, !tbaa !24
  %t168 = mul i64 %t164, %t165
  %t171 = add i64 %t163, %t168
  store i64 %t171, ptr %l16, !tbaa !24
  %t173 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t173, ptr %l85, !tbaa !27
  %t174 = load i64, ptr %l16, !tbaa !24
  %t176 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr i1, ptr %t177, i64 %t174
  %t179 = load i1, ptr %t178, !tbaa !31
  br i1 %t179, label %bb33, label %bb34
bb33:
  %t181 = load ptr, ptr %lp10
  %t182 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t182, ptr %l89, !tbaa !27
  %t183 = load i64, ptr %l16, !tbaa !24
  %t185 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !27
  %t187 = getelementptr { i64, ptr }, ptr %t186, i64 %t183
  %t188 = load { i64, ptr }, ptr %t187, !tbaa !37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v1, ptr %t181, { i64, ptr } %t188)
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t191 = load i64, ptr %l15, !tbaa !24
  %t193 = add i64 %t191, 1
  store i64 %t193, ptr %l15, !tbaa !24
  br label %bb29
bb38:
  %t195 = load ptr, ptr %lp10
  %t197 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v2, ptr %v2, ptr %t195)
  store { i64, ptr } %t197, ptr %l95
  br label %bb39
bb39:
  %t198 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t198, ptr %l96, !tbaa !27
  %t199 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t200 = extractvalue { i64, ptr } %t199, 0
  store i64 %t200, ptr %l97, !tbaa !24
  %t201 = load i64, ptr %l97, !tbaa !24
  %t202 = mul i64 %t201, 16
  %t203 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t202)
  %t204 = insertvalue { i64, ptr } undef, i64 %t201, 0
  %t205 = insertvalue { i64, ptr } %t204, ptr %t203, 1
  store { i64, ptr } %t205, ptr %l98, !tbaa !27
  %t206 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !27
  %t208 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = load i64, ptr %l97, !tbaa !24
  %t211 = mul i64 %t210, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t207, ptr %t209, i64 %t211, i1 false)
  %t212 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t212, ptr %l96, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t213 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t213, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ffix_2emigrationTool(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l16 = alloca i1
  %l18 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l34 = alloca i1
  %l35 = alloca i1
  %l42 = alloca i1
  %l43 = alloca i1
  %l50 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l4, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t2, 0
  %t6 = sub i64 %t4, 6
  store i64 %t6, ptr %l7, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l8, !tbaa !24
  %t9 = icmp sge i64 0, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l7, !tbaa !24
  %t12 = icmp sle i64 0, %t11
  br i1 %t12, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_565177cd6d363dc5_57077917db9ab2b9)
  unreachable
bb3:
  %t14 = load i64, ptr %l7, !tbaa !24
  %t15 = load i64, ptr %l8, !tbaa !24
  %t16 = icmp sle i64 %t14, %t15
  br i1 %t16, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_565177cd6d363dc5_57077917db9ab2b9)
  unreachable
bb5:
  %t18 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l7, !tbaa !24
  %t21 = getelementptr i8, ptr %t19, i64 0
  %t22 = sub i64 %t20, 0
  %t23 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t21, 1
  %t27 = insertvalue { i64, ptr } undef, i64 45, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr @G_2ecompiler_2ffix_2eToolNames, 1
  %t30 = load ptr, ptr @__olang_prog_scope
  %t33 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t30, ptr %v0, { i64, ptr } %t28, { i64, ptr } %t24)
  store i1 %t33, ptr %l16
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_565177cd6d363dc5_57077917db9ab2b9)
  unreachable
bb7:
  %t34 = load i1, ptr %l16, !tbaa !21
  br i1 %t34, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t36 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t36, ptr %l18, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t41 = sub i64 %t39, 6
  store i64 %t41, ptr %l21, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l22, !tbaa !24
  %t44 = icmp sge i64 0, 0
  br i1 %t44, label %bb11, label %bb12
bb11:
  %t46 = load i64, ptr %l21, !tbaa !24
  %t47 = icmp sle i64 0, %t46
  br i1 %t47, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_aba33d98e166d1e8_68a02edac36c0e8c)
  unreachable
bb13:
  %t49 = load i64, ptr %l21, !tbaa !24
  %t50 = load i64, ptr %l22, !tbaa !24
  %t51 = icmp sle i64 %t49, %t50
  br i1 %t51, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_aba33d98e166d1e8_68a02edac36c0e8c)
  unreachable
bb15:
  %t53 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = load i64, ptr %l21, !tbaa !24
  %t56 = getelementptr i8, ptr %t54, i64 0
  %t57 = sub i64 %t55, 0
  %t58 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t56, 1
  %t60 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d87, i32 0, i32 1) }, 1
  %t61 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d87, i32 0, i32 1) }, 0
  %t63 = extractvalue { i64, ptr } %t59, 1
  %t64 = extractvalue { i64, ptr } %t59, 0
  %t65 = add i64 %t61, %t64
  %t66 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t65)
  call void @olang_textcopy(ptr %t66, ptr %t60, i64 %t61)
  %t67 = getelementptr i8, ptr %t66, i64 %t61
  call void @olang_textcopy(ptr %t67, ptr %t63, i64 %t64)
  %t68 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t66, 1
  store { i64, ptr } %t69, ptr %l3, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t73 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t74 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d88, i32 0, i32 1) }, 1
  %t75 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d88, i32 0, i32 1) }, 0
  %t77 = extractvalue { i64, ptr } %t73, 1
  %t78 = extractvalue { i64, ptr } %t73, 0
  %t79 = add i64 %t75, %t78
  %t80 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d89, i32 0, i32 1) }, 1
  %t81 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d89, i32 0, i32 1) }, 0
  %t82 = add i64 %t79, %t81
  %t83 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t82)
  call void @olang_textcopy(ptr %t83, ptr %t74, i64 %t75)
  %t84 = getelementptr i8, ptr %t83, i64 %t75
  call void @olang_textcopy(ptr %t84, ptr %t77, i64 %t78)
  %t85 = getelementptr i8, ptr %t84, i64 %t78
  call void @olang_textcopy(ptr %t85, ptr %t80, i64 %t81)
  %t86 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t83, 1
  %t90 = extractvalue { i64, ptr } %t87, 0
  %t91 = extractvalue { i64, ptr } %t87, 1
  %t92 = mul i64 %t90, 1
  %t93 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t92)
  call void @llvm.memcpy.p0.p0.i64(ptr %t93, ptr %t91, i64 %t92, i1 false)
  %t94 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t93, 1
  %t98 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t71, { i64, ptr } %t95)
  store i1 %t98, ptr %l34
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_aba33d98e166d1e8_68a02edac36c0e8c)
  unreachable
bb17:
  %t99 = load i1, ptr %l34, !tbaa !21
  br i1 %t99, label %bb18, label %bb19
bb18:
  %t100 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t102, 1
  %t105 = extractvalue { i64, ptr } %t102, 0
  %t106 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d90, i32 0, i32 1) }, 1
  %t107 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d90, i32 0, i32 1) }, 0
  %t108 = add i64 %t105, %t107
  %t109 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t108)
  call void @olang_textcopy(ptr %t109, ptr %t104, i64 %t105)
  %t110 = getelementptr i8, ptr %t109, i64 %t105
  call void @olang_textcopy(ptr %t110, ptr %t106, i64 %t107)
  %t111 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t109, 1
  %t115 = extractvalue { i64, ptr } %t112, 0
  %t116 = extractvalue { i64, ptr } %t112, 1
  %t117 = mul i64 %t115, 1
  %t118 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t117)
  call void @llvm.memcpy.p0.p0.i64(ptr %t118, ptr %t116, i64 %t117, i1 false)
  %t119 = insertvalue { i64, ptr } undef, i64 %t115, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t118, 1
  %t123 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t100, { i64, ptr } %t120)
  store i1 %t123, ptr %l42
  br label %bb20
bb19:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb25
bb20:
  %t124 = load i1, ptr %l42, !tbaa !21
  br i1 %t124, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb24
bb22:
  %t125 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t127 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t127, 1
  %t130 = extractvalue { i64, ptr } %t127, 0
  %t131 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d91, i32 0, i32 1) }, 1
  %t132 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d91, i32 0, i32 1) }, 0
  %t133 = add i64 %t130, %t132
  %t134 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t133)
  call void @olang_textcopy(ptr %t134, ptr %t129, i64 %t130)
  %t135 = getelementptr i8, ptr %t134, i64 %t130
  call void @olang_textcopy(ptr %t135, ptr %t131, i64 %t132)
  %t136 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t134, 1
  %t140 = extractvalue { i64, ptr } %t137, 0
  %t141 = extractvalue { i64, ptr } %t137, 1
  %t142 = mul i64 %t140, 1
  %t143 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t142)
  call void @llvm.memcpy.p0.p0.i64(ptr %t143, ptr %t141, i64 %t142, i1 false)
  %t144 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t143, 1
  %t148 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t125, { i64, ptr } %t145)
  store i1 %t148, ptr %l50
  br label %bb23
bb23:
  %t149 = load i1, ptr %l50, !tbaa !21
  store i1 %t149, ptr %l43, !tbaa !21
  br label %bb24
bb24:
  %t150 = load i1, ptr %l43, !tbaa !21
  store i1 %t150, ptr %l35, !tbaa !21
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t151 = load i1, ptr %l35, !tbaa !21
  store i1 %t151, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffix_2emustFail(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l9 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %s0, { i64, ptr } %a0)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  br label %bb6
bb2:
  %t9 = load i32, ptr %l5, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  br i1 %t12, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d92, i32 0, i32 1) }, ptr %l2, !tbaa !27
  br label %bb6
bb6:
  %t14 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t17 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s0, { i64, ptr } %t14, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d93, i32 0, i32 1) })
  store i1 %t17, ptr %l9
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t18 = load i1, ptr %l9, !tbaa !21
  store i1 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ffix_2erun(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i1
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i1
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i32, { i64, [2 x i64] } }
  %l29 = alloca i64
  %l30 = alloca i64
  %l34 = alloca { i64, ptr }
  %l36 = alloca i1
  %l44 = alloca { i64, ptr }
  %l46 = alloca i32
  %l48 = alloca i1
  %l57 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l59 = alloca i32
  %l62 = alloca i1
  %l64 = alloca i64
  %l66 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l69 = alloca [45 x { i64, ptr }]
  %l70 = alloca i64
  %l74 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l75 = alloca [45 x { i64, ptr }]
  %l80 = alloca i64
  %l83 = alloca i64
  %l101 = alloca { i64, ptr }
  %l102 = alloca i64
  %l103 = alloca i64
  %l111 = alloca { i64, ptr }
  %l116 = alloca i1
  %l126 = alloca { i64, ptr }
  %l130 = alloca ptr
  %l132 = alloca i64
  %l133 = alloca [45 x { i64, ptr }]
  %l134 = alloca i64
  %l135 = alloca i64
  %l143 = alloca { i64, ptr }
  %l151 = alloca { i64, ptr }
  %l156 = alloca i1
  %l157 = alloca i1
  %l162 = alloca { i64, ptr }
  %l176 = alloca i1
  %l178 = alloca { i64, ptr }
  %l179 = alloca { i64, ptr }
  %l181 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l183 = alloca i1
  %l189 = alloca i1
  %l191 = alloca i1
  %l192 = alloca { i64, ptr }
  %l195 = alloca i1
  %l199 = alloca i1
  %l204 = alloca { i64, ptr }
  %l207 = alloca i32
  %l209 = alloca i1
  %l210 = alloca { i32, { i64, [2 x i64] } }
  %l211 = alloca { i32, { i64, [2 x i64] } }
  %l212 = alloca i32
  %l217 = alloca { i32, { i64, [2 x i64] } }
  %l218 = alloca { i32, { i64, [2 x i64] } }
  %l221 = alloca i64
  %l222 = alloca i64
  %l229 = alloca i1
  %l238 = alloca i64
  %l240 = alloca { i64, ptr }
  %l245 = alloca { i64, ptr }
  %l248 = alloca i64
  %l250 = alloca ptr
  %l251 = alloca { i64, ptr }
  %l252 = alloca i64
  %l272 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %rv = alloca i32
  %t119 = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = call { i64, ptr } @compiler_2ffix_2eToolsDir(ptr %v2, ptr %v3, ptr %s0, { i64, ptr } %t1, { i64, ptr } %t2)
  store { i64, ptr } %t5, ptr %l34
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t6, ptr %l5, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t9 = call i1 @std_2fos_2eIsDir(ptr %s0, { i64, ptr } %t7)
  store i1 %t9, ptr %l36
  br label %bb2
bb2:
  %t10 = load i1, ptr %l36, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = load ptr, ptr %l4, !tbaa !29
  %t14 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t15 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  %t18 = extractvalue { i64, ptr } %t14, 1
  %t19 = extractvalue { i64, ptr } %t14, 0
  %t20 = add i64 %t16, %t19
  %t21 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  %t23 = add i64 %t20, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t15, i64 %t16)
  %t25 = getelementptr i8, ptr %t24, i64 %t16
  call void @olang_textcopy(ptr %t25, ptr %t18, i64 %t19)
  %t26 = getelementptr i8, ptr %t25, i64 %t19
  call void @olang_textcopy(ptr %t26, ptr %t21, i64 %t22)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t24, 1
  %t31 = extractvalue { i64, ptr } %t28, 0
  %t32 = extractvalue { i64, ptr } %t28, 1
  %t33 = mul i64 %t31, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t33)
  call void @llvm.memcpy.p0.p0.i64(ptr %t34, ptr %t32, i64 %t33, i1 false)
  %t35 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v4, ptr %s1, ptr %t13, { i64, ptr } %t36)
  br label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb6:
  %t40 = call { i64, ptr } @compiler_2ffix_2eBinDir(ptr %s0)
  store { i64, ptr } %t40, ptr %l44
  br label %bb7
bb7:
  %t41 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t41, ptr %l6, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t44 = call i32 @std_2fos_2eMkDirAll(ptr %s0, { i64, ptr } %t42)
  store i32 %t44, ptr %l46
  %t45 = icmp ne i32 %t44, 0
  br i1 %t45, label %bb9, label %ok.46, !prof !99
ok.46:
  br label %bb8
bb8:
  br label %bb14
bb9:
  %t47 = load i32, ptr %l46, !tbaa !23
  %t48 = ashr i32 %t47, 16
  %t50 = icmp eq i32 %t48, 1
  store i1 %t50, ptr %l48, !tbaa !21
  %t51 = load i32, ptr %l46, !tbaa !23
  %t52 = ashr i32 %t51, 16
  %t54 = icmp eq i32 %t52, 1
  br i1 %t54, label %bb10, label %bb11
bb10:
  call void @__olang_errpay_pop()
  br label %bb11
bb11:
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t56 = load ptr, ptr %l4, !tbaa !29
  %t57 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t58 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d96, i32 0, i32 1) }, 1
  %t59 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d96, i32 0, i32 1) }, 0
  %t61 = extractvalue { i64, ptr } %t57, 1
  %t62 = extractvalue { i64, ptr } %t57, 0
  %t63 = add i64 %t59, %t62
  %t64 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d97, i32 0, i32 1) }, 1
  %t65 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d97, i32 0, i32 1) }, 0
  %t66 = add i64 %t63, %t65
  %t67 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t66)
  call void @olang_textcopy(ptr %t67, ptr %t58, i64 %t59)
  %t68 = getelementptr i8, ptr %t67, i64 %t59
  call void @olang_textcopy(ptr %t68, ptr %t61, i64 %t62)
  %t69 = getelementptr i8, ptr %t68, i64 %t62
  call void @olang_textcopy(ptr %t69, ptr %t64, i64 %t65)
  %t70 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t67, 1
  %t74 = extractvalue { i64, ptr } %t71, 0
  %t75 = extractvalue { i64, ptr } %t71, 1
  %t76 = mul i64 %t74, 1
  %t77 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t76)
  call void @llvm.memcpy.p0.p0.i64(ptr %t77, ptr %t75, i64 %t76, i1 false)
  %t78 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v4, ptr %s3, ptr %t56, { i64, ptr } %t79)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb14:
  %t83 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d98, i32 0, i32 1) })
  %t84 = extractvalue { i32, { i64, ptr } } %t83, 1
  %t85 = extractvalue { i32, { i64, ptr } } %t83, 0
  store i32 %t85, ptr %l59
  %t86 = icmp ne i32 %t85, 0
  br i1 %t86, label %bb16, label %ok.87, !prof !99
ok.87:
  store { i64, ptr } %t84, ptr %l58
  br label %bb15
bb15:
  %t88 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t88, ptr %l57, !tbaa !27
  br label %bb20
bb16:
  %t89 = load i32, ptr %l59, !tbaa !23
  %t90 = ashr i32 %t89, 16
  %t92 = icmp eq i32 %t90, 1
  br i1 %t92, label %bb17, label %bb18
bb17:
  call void @__olang_errpay_pop()
  br label %bb18
bb18:
  br label %bb19
bb19:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d99, i32 0, i32 1) }, ptr %l57, !tbaa !27
  br label %bb20
bb20:
  %t94 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t95 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t94, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d100, i32 0, i32 1) })
  store i1 %t95, ptr %l62
  br label %bb21
bb21:
  %t96 = load i1, ptr %l62, !tbaa !21
  %t97 = xor i1 %t96, true
  store i1 %t97, ptr %l7, !tbaa !21
  %t99 = call i64 @std_2ftime_2eNow()
  store i64 %t99, ptr %l64
  br label %bb22
bb22:
  %t100 = load i64, ptr %l64, !tbaa !24
  store i64 %t100, ptr %l8, !tbaa !24
  %t101 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t103 = call { i64, ptr } @compiler_2ffix_2ebuiltBy(ptr %v2, ptr %s0, { i64, ptr } %t101)
  store { i64, ptr } %t103, ptr %l66
  br label %bb23
bb23:
  %t104 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t104, ptr %l9, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t107 = call { i64, ptr } @compiler_2ffix_2estdKey(ptr %v3, ptr %s0, { i64, ptr } %t105)
  store { i64, ptr } %t107, ptr %l68
  br label %bb24
bb24:
  %t108 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t108, ptr %l10, !tbaa !27
  call void @llvm.memmove.p0.p0.i64(ptr %l69, ptr @G_2ecompiler_2ffix_2eToolNames, i64 720, i1 false)
  %t109 = load [45 x { i64, ptr }], ptr %l69
  store i64 45, ptr %l70, !tbaa !24
  %t110 = load i64, ptr %l70, !tbaa !24
  %t111 = icmp sge i64 %t110, 0
  br i1 %t111, label %bb25, label %bb26
bb25:
  %t113 = load i64, ptr %l70, !tbaa !24
  %t114 = icmp sle i64 %t113, 576460752303423487
  br i1 %t114, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_7ff6490bc64d8e4c_ced9be9374cda200)
  unreachable
bb27:
  %t116 = load i64, ptr %l70, !tbaa !24
  %t117 = mul i64 %t116, 16
  %t118 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t117)
  store i64 0, ptr %t119
  br label %fill.120
fill.120:
  %t123 = load i64, ptr %t119
  %t124 = icmp slt i64 %t123, %t116
  br i1 %t124, label %fillb.121, label %filld.122
fillb.121:
  %t125 = getelementptr { i64, ptr }, ptr %t118, i64 %t123
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d101, i32 0, i32 1) }, ptr %t125
  %t126 = add i64 %t123, 1
  store i64 %t126, ptr %t119
  br label %fill.120
filld.122:
  %t127 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t118, 1
  store { i64, ptr } %t128, ptr %l11, !tbaa !27
  %t130 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t130, ptr %l74
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_7ff6490bc64d8e4c_ced9be9374cda200)
  unreachable
bb29:
  %t131 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l74
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t131, ptr %l12
  store i64 0, ptr %l13, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l75, ptr @G_2ecompiler_2ffix_2eToolNames, i64 720, i1 false)
  %t132 = load [45 x { i64, ptr }], ptr %l75
  store i64 45, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t134 = load i64, ptr %l14, !tbaa !24
  %t135 = load i64, ptr %l13, !tbaa !24
  %t138 = icmp sgt i64 %t134, %t135
  br i1 %t138, label %bb30, label %bb31
bb30:
  %t140 = load i64, ptr %l15, !tbaa !24
  %t142 = icmp sgt i64 %t140, 0
  br i1 %t142, label %bb32, label %bb33
bb31:
  store i64 0, ptr %l80, !tbaa !24
  br label %bb35
bb32:
  %t144 = load i64, ptr %l14, !tbaa !24
  %t145 = load i64, ptr %l13, !tbaa !24
  %t148 = sub i64 %t144, %t145
  %t149 = load i64, ptr %l15, !tbaa !24
  %t152 = add i64 %t148, %t149
  %t154 = sub i64 %t152, 1
  %t155 = load i64, ptr %l15, !tbaa !24
  %t158 = sdiv i64 %t154, %t155
  store i64 %t158, ptr %l83, !tbaa !24
  br label %bb34
bb33:
  store i64 0, ptr %l83, !tbaa !24
  br label %bb34
bb34:
  %t160 = load i64, ptr %l83, !tbaa !24
  store i64 %t160, ptr %l80, !tbaa !24
  br label %bb35
bb35:
  %t161 = load i64, ptr %l80, !tbaa !24
  store i64 %t161, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb36
bb36:
  %t162 = load i64, ptr %l17, !tbaa !24
  %t163 = load i64, ptr %l16, !tbaa !24
  %t166 = icmp slt i64 %t162, %t163
  %t168 = xor i1 %t166, true
  br i1 %t168, label %bb37, label %bb38
bb37:
  br label %bb49
bb38:
  br label %bb39
bb39:
  %t170 = load i64, ptr %l13, !tbaa !24
  %t171 = load i64, ptr %l17, !tbaa !24
  %t172 = load i64, ptr %l15, !tbaa !24
  %t175 = mul i64 %t171, %t172
  %t178 = add i64 %t170, %t175
  store i64 %t178, ptr %l18, !tbaa !24
  %t180 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t180, ptr %l101, !tbaa !27
  %t181 = load i64, ptr %l18, !tbaa !24
  store i64 %t181, ptr %l102, !tbaa !24
  %t182 = ptrtoint ptr %s0 to i64
  store i64 %t182, ptr %l103, !tbaa !24
  %t183 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t183, label %bb40, label %bb41
bb40:
  %t185 = call ptr @__olang_region_make(ptr %s0)
  %t186 = ptrtoint ptr %t185 to i64
  store i64 %t186, ptr %l103, !tbaa !24
  br label %bb41
bb41:
  %t187 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t188 = load i64, ptr %l18, !tbaa !24
  %t190 = getelementptr [45 x { i64, ptr }], ptr @G_2ecompiler_2ffix_2eToolNames, i64 0, i64 %t188
  %t191 = load { i64, ptr }, ptr %t190, !tbaa !37
  %t192 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t193 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t194 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t195 = load ptr, ptr @__olang_prog_scope
  %t196 = load i64, ptr %l103
  %t197 = inttoptr i64 %t196 to ptr
  %t203 = call { i64, ptr } @compiler_2ffix_2eProgramOf(ptr %s0, ptr %t195, ptr %s0, ptr %s0, ptr %s0, ptr %t197, { i64, ptr } %t187, { i64, ptr } %t191, { i64, ptr } %t192, { i64, ptr } %t193, { i64, ptr } %t194)
  store { i64, ptr } %t203, ptr %l111
  br label %bb42
bb42:
  %t204 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t205 = load i64, ptr %l103
  %t206 = inttoptr i64 %t205 to ptr
  %t207 = extractvalue { i64, ptr } %t204, 0
  %t208 = extractvalue { i64, ptr } %t204, 1
  %t209 = mul i64 %t207, 1
  %t210 = call ptr @__olang_held_alloc(ptr %t206, i64 %t209)
  call void @llvm.memcpy.p0.p0.i64(ptr %t210, ptr %t208, i64 %t209, i1 false)
  %t211 = insertvalue { i64, ptr } undef, i64 %t207, 0
  %t212 = insertvalue { i64, ptr } %t211, ptr %t210, 1
  %t214 = load i64, ptr %l102, !tbaa !24
  %t215 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !27
  %t217 = getelementptr { i64, ptr }, ptr %t216, i64 %t214
  store { i64, ptr } %t212, ptr %t217, !tbaa !37
  %t218 = load i64, ptr %l18, !tbaa !24
  %t220 = getelementptr [45 x { i64, ptr }], ptr @G_2ecompiler_2ffix_2eToolTriggers, i64 0, i64 %t218
  %t221 = load { i64, ptr }, ptr %t220, !tbaa !37
  %t223 = load ptr, ptr @__olang_prog_scope
  %t226 = call i1 @compiler_2ffix_2etriggered(ptr %t223, ptr %v1, { i64, ptr } %t221, ptr %a1)
  store i1 %t226, ptr %l116
  br label %bb43
bb43:
  %t227 = load i1, ptr %l116, !tbaa !21
  br i1 %t227, label %bb44, label %bb45
bb44:
  %t228 = load i64, ptr %l18, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l12, i64 %t228)
  br label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t231 = load i64, ptr %l17, !tbaa !24
  %t233 = add i64 %t231, 1
  store i64 %t233, ptr %l17, !tbaa !24
  br label %bb36
bb49:
  %t235 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t236 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t237 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t238 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t244 = call { i64, ptr } @compiler_2ffix_2ebuildAll(ptr %v2, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t235, { i64, ptr } %t236, { i64, ptr } %t237, ptr %l12, { i64, ptr } %t238)
  store { i64, ptr } %t244, ptr %l126
  br label %bb50
bb50:
  %t245 = load { i64, ptr }, ptr %l126, !tbaa !27
  store { i64, ptr } %t245, ptr %l19, !tbaa !27
  %t246 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t247 = load { i64, ptr }, ptr %l11, !tbaa !27
  call void @compiler_2ffix_2etrimBin(ptr %s0, ptr %s0, { i64, ptr } %t246, { i64, ptr } %t247)
  br label %bb51
bb51:
  %t250 = load i1, ptr %l7, !tbaa !21
  br i1 %t250, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s9
  %t252 = load ptr, ptr %l4, !tbaa !29
  store ptr %t252, ptr %l130, !tbaa !29
  %t254 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l12)
  store i64 %t254, ptr %l132
  br label %bb54
bb53:
  br label %bb57
bb54:
  call void @llvm.memmove.p0.p0.i64(ptr %l133, ptr @G_2ecompiler_2ffix_2eToolNames, i64 720, i1 false)
  %t255 = load [45 x { i64, ptr }], ptr %l133
  store i64 45, ptr %l134, !tbaa !24
  %t256 = call i64 @std_2ftime_2eNow()
  store i64 %t256, ptr %l135
  br label %bb55
bb55:
  %t257 = load i64, ptr %l8, !tbaa !24
  %t258 = load i64, ptr %l135, !tbaa !24
  %t260 = sub i64 %t258, %t257
  %t262 = sdiv i64 %t260, 1000000
  %t263 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d102, i32 0, i32 1) }, 1
  %t264 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d102, i32 0, i32 1) }, 0
  %t265 = load i64, ptr %l132, !tbaa !24
  %t266 = call i64 @__olang_fmt_i64(ptr null, i64 %t265)
  %t267 = add i64 %t264, %t266
  %t268 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d103, i32 0, i32 1) }, 1
  %t269 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d103, i32 0, i32 1) }, 0
  %t270 = add i64 %t267, %t269
  %t271 = load i64, ptr %l134, !tbaa !24
  %t272 = call i64 @__olang_fmt_i64(ptr null, i64 %t271)
  %t273 = add i64 %t270, %t272
  %t274 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d104, i32 0, i32 1) }, 1
  %t275 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d104, i32 0, i32 1) }, 0
  %t276 = add i64 %t273, %t275
  %t278 = call i64 @__olang_fmt_i64(ptr null, i64 %t262)
  %t279 = add i64 %t276, %t278
  %t280 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d105, i32 0, i32 1) }, 1
  %t281 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d105, i32 0, i32 1) }, 0
  %t282 = add i64 %t279, %t281
  %t283 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t282)
  call void @olang_textcopy(ptr %t283, ptr %t263, i64 %t264)
  %t284 = getelementptr i8, ptr %t283, i64 %t264
  %t285 = call i64 @__olang_fmt_i64(ptr %t284, i64 %t265)
  %t286 = getelementptr i8, ptr %t284, i64 %t266
  call void @olang_textcopy(ptr %t286, ptr %t268, i64 %t269)
  %t287 = getelementptr i8, ptr %t286, i64 %t269
  %t288 = call i64 @__olang_fmt_i64(ptr %t287, i64 %t271)
  %t289 = getelementptr i8, ptr %t287, i64 %t272
  call void @olang_textcopy(ptr %t289, ptr %t274, i64 %t275)
  %t290 = getelementptr i8, ptr %t289, i64 %t275
  %t291 = call i64 @__olang_fmt_i64(ptr %t290, i64 %t262)
  %t292 = getelementptr i8, ptr %t290, i64 %t278
  call void @olang_textcopy(ptr %t292, ptr %t280, i64 %t281)
  %t293 = insertvalue { i64, ptr } undef, i64 %t282, 0
  %t294 = insertvalue { i64, ptr } %t293, ptr %t283, 1
  %t297 = extractvalue { i64, ptr } %t294, 0
  %t298 = extractvalue { i64, ptr } %t294, 1
  %t299 = mul i64 %t297, 1
  %t300 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t299)
  call void @llvm.memcpy.p0.p0.i64(ptr %t300, ptr %t298, i64 %t299, i1 false)
  %t301 = insertvalue { i64, ptr } undef, i64 %t297, 0
  %t302 = insertvalue { i64, ptr } %t301, ptr %t300, 1
  %t303 = load ptr, ptr %l130, !tbaa !29
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v4, ptr %s9, ptr %t303, { i64, ptr } %t302)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s9)
  br label %bb57
bb57:
  store i64 0, ptr %l20, !tbaa !24
  store i1 false, ptr %l21, !tbaa !21
  %t305 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t305, ptr %l22, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s11
  %t307 = call { i64, ptr } @compiler_2ffix_2eOrder(ptr %s11)
  store { i64, ptr } %t307, ptr %l143
  br label %bb58
bb58:
  %t308 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t309 = extractvalue { i64, ptr } %t308, 0
  %t310 = extractvalue { i64, ptr } %t308, 1
  %t311 = mul i64 %t309, 8
  %t312 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t311)
  call void @llvm.memcpy.p0.p0.i64(ptr %t312, ptr %t310, i64 %t311, i1 false)
  %t313 = insertvalue { i64, ptr } undef, i64 %t309, 0
  %t314 = insertvalue { i64, ptr } %t313, ptr %t312, 1
  store { i64, ptr } %t314, ptr %l23, !tbaa !27
  store i64 0, ptr %l24, !tbaa !24
  %t316 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t318 = extractvalue { i64, ptr } %t316, 0
  store i64 %t318, ptr %l25, !tbaa !24
  br label %bb59
bb59:
  store %olang.scope zeroinitializer, ptr %s12
  %t320 = load i64, ptr %l24, !tbaa !24
  %t321 = load i64, ptr %l25, !tbaa !24
  %t324 = icmp slt i64 %t320, %t321
  %t326 = xor i1 %t324, true
  br i1 %t326, label %bb60, label %bb61
bb60:
  call void @__olang_scope_close(ptr %s12)
  br label %bb122
bb61:
  br label %bb62
bb62:
  %t328 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t328, ptr %l151, !tbaa !27
  %t329 = load i64, ptr %l24, !tbaa !24
  %t331 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t332 = load ptr, ptr %t331, !tbaa !27
  %t333 = getelementptr i64, ptr %t332, i64 %t329
  %t334 = load i64, ptr %t333, !tbaa !34
  store i64 %t334, ptr %l26, !tbaa !24
  %t336 = load i64, ptr %l26, !tbaa !24
  %t338 = getelementptr [45 x i64], ptr @G_2ecompiler_2ffix_2eToolKinds, i64 0, i64 %t336
  %t339 = load i64, ptr %t338, !tbaa !34
  %t341 = call i1 @compiler_2ffix_2edriven(i64 %t339)
  store i1 %t341, ptr %l156
  br label %bb63
bb63:
  %t342 = load i1, ptr %l156, !tbaa !21
  br i1 %t342, label %bb64, label %bb65
bb64:
  %t343 = load i1, ptr %l21, !tbaa !21
  %t345 = xor i1 %t343, true
  store i1 %t345, ptr %l157, !tbaa !21
  br label %bb66
bb65:
  store i1 false, ptr %l157, !tbaa !21
  br label %bb66
bb66:
  %t347 = load i1, ptr %l157, !tbaa !21
  br i1 %t347, label %bb67, label %bb68
bb67:
  store i1 true, ptr %l21, !tbaa !21
  %t348 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t349 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t352 = call { i64, ptr } @compiler_2ffix_2efailing(ptr %v2, ptr %v0, ptr %s0, { i64, ptr } %t348, { i64, ptr } %t349)
  store { i64, ptr } %t352, ptr %l162
  br label %bb69
bb68:
  br label %bb74
bb69:
  %t353 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t354 = extractvalue { i64, ptr } %t353, 0
  %t355 = extractvalue { i64, ptr } %t353, 1
  %t356 = mul i64 %t354, 16
  %t357 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t356)
  call void @llvm.memcpy.p0.p0.i64(ptr %t357, ptr %t355, i64 %t356, i1 false)
  %t358 = insertvalue { i64, ptr } undef, i64 %t354, 0
  %t359 = insertvalue { i64, ptr } %t358, ptr %t357, 1
  store { i64, ptr } %t359, ptr %l22, !tbaa !27
  %t361 = load i1, ptr %l7, !tbaa !21
  br i1 %t361, label %bb70, label %bb71
bb70:
  store %olang.scope zeroinitializer, ptr %s14
  %t363 = load ptr, ptr %l4, !tbaa !29
  %t364 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t366 = extractvalue { i64, ptr } %t364, 0
  %t367 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t369 = extractvalue { i64, ptr } %t367, 0
  %t370 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d106, i32 0, i32 1) }, 1
  %t371 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d106, i32 0, i32 1) }, 0
  %t373 = call i64 @__olang_fmt_i64(ptr null, i64 %t366)
  %t374 = add i64 %t371, %t373
  %t375 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d107, i32 0, i32 1) }, 1
  %t376 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d107, i32 0, i32 1) }, 0
  %t377 = add i64 %t374, %t376
  %t379 = call i64 @__olang_fmt_i64(ptr null, i64 %t369)
  %t380 = add i64 %t377, %t379
  %t381 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d108, i32 0, i32 1) }, 1
  %t382 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d108, i32 0, i32 1) }, 0
  %t383 = add i64 %t380, %t382
  %t384 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t383)
  call void @olang_textcopy(ptr %t384, ptr %t370, i64 %t371)
  %t385 = getelementptr i8, ptr %t384, i64 %t371
  %t386 = call i64 @__olang_fmt_i64(ptr %t385, i64 %t366)
  %t387 = getelementptr i8, ptr %t385, i64 %t373
  call void @olang_textcopy(ptr %t387, ptr %t375, i64 %t376)
  %t388 = getelementptr i8, ptr %t387, i64 %t376
  %t389 = call i64 @__olang_fmt_i64(ptr %t388, i64 %t369)
  %t390 = getelementptr i8, ptr %t388, i64 %t379
  call void @olang_textcopy(ptr %t390, ptr %t381, i64 %t382)
  %t391 = insertvalue { i64, ptr } undef, i64 %t383, 0
  %t392 = insertvalue { i64, ptr } %t391, ptr %t384, 1
  %t395 = extractvalue { i64, ptr } %t392, 0
  %t396 = extractvalue { i64, ptr } %t392, 1
  %t397 = mul i64 %t395, 1
  %t398 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t397)
  call void @llvm.memcpy.p0.p0.i64(ptr %t398, ptr %t396, i64 %t397, i1 false)
  %t399 = insertvalue { i64, ptr } undef, i64 %t395, 0
  %t400 = insertvalue { i64, ptr } %t399, ptr %t398, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v4, ptr %s14, ptr %t363, { i64, ptr } %t400)
  br label %bb72
bb71:
  br label %bb73
bb72:
  call void @__olang_scope_close(ptr %s14)
  br label %bb73
bb73:
  br label %bb74
bb74:
  %t403 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t405 = extractvalue { i64, ptr } %t403, 0
  %t407 = icmp eq i64 %t405, 0
  br i1 %t407, label %bb75, label %bb76
bb75:
  store i1 true, ptr %l176, !tbaa !21
  br label %bb79
bb76:
  %t409 = load i64, ptr %l26, !tbaa !24
  %t411 = getelementptr [45 x { i64, ptr }], ptr @G_2ecompiler_2ffix_2eToolTriggers, i64 0, i64 %t409
  %t412 = load { i64, ptr }, ptr %t411, !tbaa !37
  store { i64, ptr } %t412, ptr %l178, !tbaa !27
  %t413 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t413, ptr %l179, !tbaa !27
  %t414 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t415 = extractvalue { i64, ptr } %t414, 1
  %t416 = call ptr @__olang_scope_of(ptr %t415, ptr null)
  %t417 = ptrtoint ptr %t416 to i64
  %t419 = inttoptr i64 %t417 to ptr
  %t420 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t421 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffix_2etextsOf(ptr %t419, ptr %s12, { i64, ptr } %t420)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t421, ptr %l181
  br label %bb77
bb77:
  %t422 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l181
  %t423 = call ptr @__olang_scope_alloc_a(ptr %s12, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t422, ptr %t423
  %t424 = load ptr, ptr @__olang_prog_scope
  %t425 = load { i64, ptr }, ptr %l178, !tbaa !27
  %t427 = call i1 @compiler_2ffix_2etriggered(ptr %t424, ptr %s12, { i64, ptr } %t425, ptr %t423)
  store i1 %t427, ptr %l183
  br label %bb78
bb78:
  %t428 = load i1, ptr %l183, !tbaa !21
  %t429 = xor i1 %t428, true
  store i1 %t429, ptr %l176, !tbaa !21
  br label %bb79
bb79:
  %t431 = load i1, ptr %l176, !tbaa !21
  br i1 %t431, label %bb80, label %bb81
bb80:
  call void @__olang_scope_close(ptr %s12)
  br label %bb121
bb81:
  br label %bb82
bb82:
  %t432 = load i64, ptr %l26, !tbaa !24
  %t434 = getelementptr [45 x { i64, ptr }], ptr @G_2ecompiler_2ffix_2eToolNames, i64 0, i64 %t432
  %t435 = load { i64, ptr }, ptr %t434, !tbaa !37
  store { i64, ptr } %t435, ptr %l27, !tbaa !27
  %t437 = load i64, ptr %l26, !tbaa !24
  %t439 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t440 = load ptr, ptr %t439, !tbaa !27
  %t441 = getelementptr { i64, ptr }, ptr %t440, i64 %t437
  %t442 = load { i64, ptr }, ptr %t441, !tbaa !37
  %t444 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s12, { i64, ptr } %t442, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d109, i32 0, i32 1) })
  store i1 %t444, ptr %l189
  br label %bb83
bb83:
  %t445 = load i1, ptr %l189, !tbaa !21
  %t446 = xor i1 %t445, true
  br i1 %t446, label %bb84, label %bb85
bb84:
  store i1 true, ptr %l191, !tbaa !21
  br label %bb87
bb85:
  %t448 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t448, ptr %l192, !tbaa !27
  %t449 = load i64, ptr %l26, !tbaa !24
  %t451 = getelementptr { i64, ptr }, ptr %l192, i32 0, i32 1
  %t452 = load ptr, ptr %t451, !tbaa !27
  %t453 = getelementptr { i64, ptr }, ptr %t452, i64 %t449
  %t454 = load { i64, ptr }, ptr %t453, !tbaa !37
  %t456 = call i1 @std_2fos_2eExists(ptr %s0, { i64, ptr } %t454)
  store i1 %t456, ptr %l195
  br label %bb86
bb86:
  %t457 = load i1, ptr %l195, !tbaa !21
  %t458 = xor i1 %t457, true
  store i1 %t458, ptr %l191, !tbaa !21
  br label %bb87
bb87:
  %t460 = load i1, ptr %l191, !tbaa !21
  br i1 %t460, label %bb88, label %bb89
bb88:
  store %olang.scope zeroinitializer, ptr %s17
  %t461 = load i64, ptr %l26, !tbaa !24
  %t463 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t464 = load ptr, ptr %t463, !tbaa !27
  %t465 = getelementptr { i64, ptr }, ptr %t464, i64 %t461
  %t466 = load { i64, ptr }, ptr %t465, !tbaa !37
  %t468 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s17, { i64, ptr } %t466, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d110, i32 0, i32 1) })
  store i1 %t468, ptr %l199
  br label %bb90
bb89:
  br label %bb110
bb90:
  %t469 = load i1, ptr %l199, !tbaa !21
  br i1 %t469, label %bb91, label %bb92
bb91:
  store %olang.scope zeroinitializer, ptr %s18
  %t470 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t471 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t472 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t473 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t474 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t474, ptr %l204, !tbaa !27
  %t475 = load i64, ptr %l26, !tbaa !24
  %t477 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t478 = load ptr, ptr %t477, !tbaa !27
  %t479 = getelementptr { i64, ptr }, ptr %t478, i64 %t475
  %t480 = load { i64, ptr }, ptr %t479, !tbaa !37
  %t481 = load ptr, ptr @__olang_prog_scope
  %t487 = call i32 @compiler_2ffix_2ebuildTool(ptr %v2, ptr %s0, ptr %s0, ptr %t481, ptr %s0, { i64, ptr } %t470, { i64, ptr } %t471, { i64, ptr } %t472, { i64, ptr } %t473, { i64, ptr } %t480)
  store i32 %t487, ptr %l207
  %t488 = icmp ne i32 %t487, 0
  br i1 %t488, label %bb94, label %ok.489, !prof !99
ok.489:
  br label %bb93
bb92:
  br label %bb104
bb93:
  br label %bb103
bb94:
  %t490 = load i32, ptr %l207, !tbaa !23
  %t491 = ashr i32 %t490, 16
  %t493 = icmp eq i32 %t491, 1
  store i1 %t493, ptr %l209, !tbaa !21
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l28
  %t494 = load i32, ptr %l207, !tbaa !23
  %t495 = lshr i32 %t494, 16
  %t496 = and i32 %t494, 65535
  %t497 = icmp eq i32 %t495, 1
  %t498 = select i1 %t497, i32 1, i32 0
  %t499 = icmp eq i32 %t494, 0
  %t500 = shl i32 %t498, 16
  %t501 = or i32 %t500, %t496
  %t502 = select i1 %t499, i32 0, i32 %t501
  %t503 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l28, i32 0, i32 0
  store i32 %t502, ptr %t503, !tbaa !23
  br label %bb95
bb95:
  %t504 = load { i32, { i64, [2 x i64] } }, ptr %l28
  store { i32, { i64, [2 x i64] } } %t504, ptr %l210
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l211
  %t505 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l210, i32 0, i32 0
  %t506 = load i32, ptr %t505, !tbaa !23
  store i32 %t506, ptr %l212, !tbaa !23
  %t507 = load i32, ptr %l212, !tbaa !23
  %t508 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l211, i32 0, i32 0
  store i32 %t507, ptr %t508, !tbaa !23
  %t509 = load i32, ptr %l212, !tbaa !23
  %t510 = ashr i32 %t509, 16
  %t512 = icmp eq i32 %t510, 1
  br i1 %t512, label %bb96, label %bb97
bb96:
  %t514 = call ptr @__olang_errpay_top_get()
  %t516 = load { i64, [2 x i64] }, ptr %t514
  %t517 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l211, i32 0, i32 1
  store { i64, [2 x i64] } %t516, ptr %t517
  br label %bb97
bb97:
  %t519 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bcompiler_2ffix_3aNotBuilt_7d(ptr %s18, ptr %l211)
  store { i32, { i64, [2 x i64] } } %t519, ptr %l217
  br label %bb98
bb98:
  %t520 = load { i32, { i64, [2 x i64] } }, ptr %l217
  store { i32, { i64, [2 x i64] } } %t520, ptr %l28
  %t521 = load { i32, { i64, [2 x i64] } }, ptr %l28
  store { i32, { i64, [2 x i64] } } %t521, ptr %l218
  %t522 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l218, i32 0, i32 0
  %t523 = load i32, ptr %t522, !tbaa !23
  %t524 = ashr i32 %t523, 16
  %t526 = icmp eq i32 %t524, 1
  br i1 %t526, label %bb99, label %bb100
bb99:
  call void @__olang_errpay_pop()
  br label %bb100
bb100:
  %t528 = load i64, ptr %l26, !tbaa !24
  store i64 %t528, ptr %l221, !tbaa !24
  %t529 = ptrtoint ptr %s0 to i64
  store i64 %t529, ptr %l222, !tbaa !24
  %t530 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t530, label %bb101, label %bb102
bb101:
  %t532 = call ptr @__olang_region_make(ptr %s0)
  %t533 = ptrtoint ptr %t532 to i64
  store i64 %t533, ptr %l222, !tbaa !24
  br label %bb102
bb102:
  %t534 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l28, i32 0, i32 1
  %t535 = getelementptr { i64, [2 x i64] }, ptr %t534, i32 0, i32 1
  %t536 = getelementptr { { i64, ptr } }, ptr %t535, i32 0, i32 0
  %t537 = load { i64, ptr }, ptr %t536
  %t539 = extractvalue { i64, ptr } %t537, 1
  %t540 = extractvalue { i64, ptr } %t537, 0
  %t541 = load i64, ptr %l222
  %t542 = inttoptr i64 %t541 to ptr
  %t543 = call ptr @__olang_held_alloc(ptr %t542, i64 %t540)
  call void @olang_textcopy(ptr %t543, ptr %t539, i64 %t540)
  %t544 = insertvalue { i64, ptr } undef, i64 %t540, 0
  %t545 = insertvalue { i64, ptr } %t544, ptr %t543, 1
  %t547 = load i64, ptr %l222
  %t548 = inttoptr i64 %t547 to ptr
  %t549 = extractvalue { i64, ptr } %t545, 0
  %t550 = extractvalue { i64, ptr } %t545, 1
  %t551 = mul i64 %t549, 1
  %t552 = call ptr @__olang_held_alloc(ptr %t548, i64 %t551)
  call void @llvm.memcpy.p0.p0.i64(ptr %t552, ptr %t550, i64 %t551, i1 false)
  %t553 = insertvalue { i64, ptr } undef, i64 %t549, 0
  %t554 = insertvalue { i64, ptr } %t553, ptr %t552, 1
  %t556 = load i64, ptr %l221, !tbaa !24
  %t557 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t558 = load ptr, ptr %t557, !tbaa !27
  %t559 = getelementptr { i64, ptr }, ptr %t558, i64 %t556
  store { i64, ptr } %t554, ptr %t559, !tbaa !37
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s18)
  br label %bb104
bb104:
  %t560 = load i64, ptr %l26, !tbaa !24
  %t562 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t563 = load ptr, ptr %t562, !tbaa !27
  %t564 = getelementptr { i64, ptr }, ptr %t563, i64 %t560
  %t565 = load { i64, ptr }, ptr %t564, !tbaa !37
  %t567 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s17, { i64, ptr } %t565, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d111, i32 0, i32 1) })
  store i1 %t567, ptr %l229
  br label %bb105
bb105:
  %t568 = load i1, ptr %l229, !tbaa !21
  %t569 = xor i1 %t568, true
  br i1 %t569, label %bb106, label %bb107
bb106:
  store %olang.scope zeroinitializer, ptr %s21
  %t571 = load ptr, ptr %l4, !tbaa !29
  %t572 = load i64, ptr %l26, !tbaa !24
  %t574 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t575 = load ptr, ptr %t574, !tbaa !27
  %t576 = getelementptr { i64, ptr }, ptr %t575, i64 %t572
  %t577 = load { i64, ptr }, ptr %t576, !tbaa !37
  %t578 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d112, i32 0, i32 1) }, 1
  %t579 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d112, i32 0, i32 1) }, 0
  %t581 = extractvalue { i64, ptr } %t577, 1
  %t582 = extractvalue { i64, ptr } %t577, 0
  %t583 = add i64 %t579, %t582
  %t584 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d113, i32 0, i32 1) }, 1
  %t585 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d113, i32 0, i32 1) }, 0
  %t586 = add i64 %t583, %t585
  %t587 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t586)
  call void @olang_textcopy(ptr %t587, ptr %t578, i64 %t579)
  %t588 = getelementptr i8, ptr %t587, i64 %t579
  call void @olang_textcopy(ptr %t588, ptr %t581, i64 %t582)
  %t589 = getelementptr i8, ptr %t588, i64 %t582
  call void @olang_textcopy(ptr %t589, ptr %t584, i64 %t585)
  %t590 = insertvalue { i64, ptr } undef, i64 %t586, 0
  %t591 = insertvalue { i64, ptr } %t590, ptr %t587, 1
  %t594 = extractvalue { i64, ptr } %t591, 0
  %t595 = extractvalue { i64, ptr } %t591, 1
  %t596 = mul i64 %t594, 1
  %t597 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t596)
  call void @llvm.memcpy.p0.p0.i64(ptr %t597, ptr %t595, i64 %t596, i1 false)
  %t598 = insertvalue { i64, ptr } undef, i64 %t594, 0
  %t599 = insertvalue { i64, ptr } %t598, ptr %t597, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v4, ptr %s21, ptr %t571, { i64, ptr } %t599)
  br label %bb108
bb107:
  br label %bb109
bb108:
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb109:
  call void @__olang_scope_close(ptr %s17)
  br label %bb110
bb110:
  %t603 = call i64 @std_2ftime_2eNow()
  store i64 %t603, ptr %l238
  br label %bb111
bb111:
  %t604 = load i64, ptr %l238, !tbaa !24
  store i64 %t604, ptr %l29, !tbaa !24
  %t605 = load i64, ptr %l26, !tbaa !24
  %t606 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t606, ptr %l240, !tbaa !27
  %t607 = load i64, ptr %l26, !tbaa !24
  %t609 = getelementptr { i64, ptr }, ptr %l240, i32 0, i32 1
  %t610 = load ptr, ptr %t609, !tbaa !27
  %t611 = getelementptr { i64, ptr }, ptr %t610, i64 %t607
  %t612 = load { i64, ptr }, ptr %t611, !tbaa !37
  %t613 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t614 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t615 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t615, ptr %l245, !tbaa !27
  %t616 = load ptr, ptr %l4, !tbaa !29
  %t617 = load { i64, ptr }, ptr %l245, !tbaa !27
  %t618 = extractvalue { i64, ptr } %t617, 1
  %t619 = call ptr @__olang_scope_of(ptr %t618, ptr null)
  %t620 = ptrtoint ptr %t619 to i64
  %t622 = inttoptr i64 %t620 to ptr
  %t627 = load { i64, ptr }, ptr %l245, !tbaa !27
  %t629 = call i64 @compiler_2ffix_2erunTool(ptr %s0, ptr %v2, ptr %v3, ptr %t622, ptr %v4, i64 %t605, { i64, ptr } %t612, { i64, ptr } %t613, { i64, ptr } %t614, { i64, ptr } %t627, ptr %t616)
  store i64 %t629, ptr %l248
  br label %bb112
bb112:
  %t630 = load i64, ptr %l248, !tbaa !24
  store i64 %t630, ptr %l30, !tbaa !24
  %t631 = load i1, ptr %l7, !tbaa !21
  br i1 %t631, label %bb113, label %bb114
bb113:
  store %olang.scope zeroinitializer, ptr %s23
  %t633 = load ptr, ptr %l4, !tbaa !29
  store ptr %t633, ptr %l250, !tbaa !29
  %t634 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t634, ptr %l251, !tbaa !27
  %t635 = call i64 @std_2ftime_2eNow()
  store i64 %t635, ptr %l252
  br label %bb115
bb114:
  br label %bb117
bb115:
  %t636 = load i64, ptr %l29, !tbaa !24
  %t637 = load i64, ptr %l252, !tbaa !24
  %t639 = sub i64 %t637, %t636
  %t641 = sdiv i64 %t639, 1000000
  %t642 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d114, i32 0, i32 1) }, 1
  %t643 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d114, i32 0, i32 1) }, 0
  %t644 = load { i64, ptr }, ptr %l251, !tbaa !27
  %t645 = extractvalue { i64, ptr } %t644, 1
  %t646 = extractvalue { i64, ptr } %t644, 0
  %t647 = add i64 %t643, %t646
  %t648 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d115, i32 0, i32 1) }, 1
  %t649 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d115, i32 0, i32 1) }, 0
  %t650 = add i64 %t647, %t649
  %t652 = call i64 @__olang_fmt_i64(ptr null, i64 %t641)
  %t653 = add i64 %t650, %t652
  %t654 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d116, i32 0, i32 1) }, 1
  %t655 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d116, i32 0, i32 1) }, 0
  %t656 = add i64 %t653, %t655
  %t657 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t656)
  call void @olang_textcopy(ptr %t657, ptr %t642, i64 %t643)
  %t658 = getelementptr i8, ptr %t657, i64 %t643
  call void @olang_textcopy(ptr %t658, ptr %t645, i64 %t646)
  %t659 = getelementptr i8, ptr %t658, i64 %t646
  call void @olang_textcopy(ptr %t659, ptr %t648, i64 %t649)
  %t660 = getelementptr i8, ptr %t659, i64 %t649
  %t661 = call i64 @__olang_fmt_i64(ptr %t660, i64 %t641)
  %t662 = getelementptr i8, ptr %t660, i64 %t652
  call void @olang_textcopy(ptr %t662, ptr %t654, i64 %t655)
  %t663 = insertvalue { i64, ptr } undef, i64 %t656, 0
  %t664 = insertvalue { i64, ptr } %t663, ptr %t657, 1
  %t667 = extractvalue { i64, ptr } %t664, 0
  %t668 = extractvalue { i64, ptr } %t664, 1
  %t669 = mul i64 %t667, 1
  %t670 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t669)
  call void @llvm.memcpy.p0.p0.i64(ptr %t670, ptr %t668, i64 %t669, i1 false)
  %t671 = insertvalue { i64, ptr } undef, i64 %t667, 0
  %t672 = insertvalue { i64, ptr } %t671, ptr %t670, 1
  %t673 = load ptr, ptr %l250, !tbaa !29
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v4, ptr %s23, ptr %t673, { i64, ptr } %t672)
  br label %bb116
bb116:
  call void @__olang_scope_close(ptr %s23)
  br label %bb117
bb117:
  %t675 = load i64, ptr %l30, !tbaa !24
  %t677 = icmp slt i64 %t675, 0
  br i1 %t677, label %bb118, label %bb119
bb118:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb119:
  br label %bb120
bb120:
  %t680 = load i64, ptr %l20, !tbaa !24
  %t681 = load i64, ptr %l30, !tbaa !24
  %t684 = add i64 %t680, %t681
  store i64 %t684, ptr %l20, !tbaa !24
  call void @__olang_scope_close(ptr %s12)
  br label %bb121
bb121:
  %t686 = load i64, ptr %l24, !tbaa !24
  %t688 = add i64 %t686, 1
  store i64 %t688, ptr %l24, !tbaa !24
  br label %bb59
bb122:
  call void @__olang_scope_close(ptr %s11)
  %t690 = load i64, ptr %l20, !tbaa !24
  %t692 = icmp eq i64 %t690, 0
  br i1 %t692, label %bb123, label %bb124
bb123:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb124:
  br label %bb125
bb125:
  %t695 = load i64, ptr %l20, !tbaa !24
  %t697 = icmp eq i64 %t695, 1
  br i1 %t697, label %bb126, label %bb127
bb126:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d117, i32 0, i32 1) }, ptr %l272, !tbaa !27
  br label %bb128
bb127:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d118, i32 0, i32 1) }, ptr %l272, !tbaa !27
  br label %bb128
bb128:
  %t699 = load { i64, ptr }, ptr %l272, !tbaa !27
  %t700 = load ptr, ptr %l4, !tbaa !29
  %t701 = load i64, ptr %l20, !tbaa !24
  %t703 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d119, i32 0, i32 1) }, 1
  %t704 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d119, i32 0, i32 1) }, 0
  %t706 = call i64 @__olang_fmt_i64(ptr null, i64 %t701)
  %t707 = add i64 %t704, %t706
  %t708 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d120, i32 0, i32 1) }, 1
  %t709 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d120, i32 0, i32 1) }, 0
  %t710 = add i64 %t707, %t709
  %t712 = extractvalue { i64, ptr } %t699, 1
  %t713 = extractvalue { i64, ptr } %t699, 0
  %t714 = add i64 %t710, %t713
  %t715 = extractvalue { i64, ptr } { i64 89, ptr getelementptr inbounds (<{ i64, [89 x i8] }>, ptr @.d121, i32 0, i32 1) }, 1
  %t716 = extractvalue { i64, ptr } { i64 89, ptr getelementptr inbounds (<{ i64, [89 x i8] }>, ptr @.d121, i32 0, i32 1) }, 0
  %t717 = add i64 %t714, %t716
  %t718 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t717)
  call void @olang_textcopy(ptr %t718, ptr %t703, i64 %t704)
  %t719 = getelementptr i8, ptr %t718, i64 %t704
  %t720 = call i64 @__olang_fmt_i64(ptr %t719, i64 %t701)
  %t721 = getelementptr i8, ptr %t719, i64 %t706
  call void @olang_textcopy(ptr %t721, ptr %t708, i64 %t709)
  %t722 = getelementptr i8, ptr %t721, i64 %t709
  call void @olang_textcopy(ptr %t722, ptr %t712, i64 %t713)
  %t723 = getelementptr i8, ptr %t722, i64 %t713
  call void @olang_textcopy(ptr %t723, ptr %t715, i64 %t716)
  %t724 = insertvalue { i64, ptr } undef, i64 %t717, 0
  %t725 = insertvalue { i64, ptr } %t724, ptr %t718, 1
  %t728 = extractvalue { i64, ptr } %t725, 0
  %t729 = extractvalue { i64, ptr } %t725, 1
  %t730 = mul i64 %t728, 1
  %t731 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t730)
  call void @llvm.memcpy.p0.p0.i64(ptr %t731, ptr %t729, i64 %t730, i1 false)
  %t732 = insertvalue { i64, ptr } undef, i64 %t728, 0
  %t733 = insertvalue { i64, ptr } %t732, ptr %t731, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v4, ptr %s0, ptr %t700, { i64, ptr } %t733)
  br label %bb129
bb129:
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ffix_2erunTool(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, i64 %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, ptr %a5) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca { i32, { i64, [2 x i64] } }
  %l16 = alloca %"std/os:Output"
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l27 = alloca i64
  %l30 = alloca i64
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l61 = alloca %"std/os:Output"
  %l68 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l71 = alloca %"std/os:Output"
  %l72 = alloca i32
  %l74 = alloca i1
  %l75 = alloca { i32, { i64, [2 x i64] } }
  %l76 = alloca { i32, { i64, [2 x i64] } }
  %l77 = alloca i32
  %l82 = alloca { i32, { i64, [2 x i64] } }
  %l83 = alloca { i32, { i64, [2 x i64] } }
  %l86 = alloca ptr
  %l87 = alloca { i64, ptr }
  %l88 = alloca { i32, { i64, [2 x i64] } }
  %l90 = alloca { i32, { i64, [2 x i64] } }
  %l91 = alloca i32
  %l106 = alloca { i64, ptr }
  %l114 = alloca i64
  %l117 = alloca i1
  %l127 = alloca i1
  %l130 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.builder
  %s4room = alloca [64 x i8], align 8
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca i64
  store i64 %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t3 = getelementptr [45 x { i64, ptr }], ptr @G_2ecompiler_2ffix_2eToolNames, i64 0, i64 %t1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !37
  store { i64, ptr } %t4, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l9, !tbaa !24
  %t10 = load i64, ptr @G_2ecompiler_2ffix_2eBatch, !tbaa !24
  store i64 %t10, ptr %l10, !tbaa !24
  %t12 = load i64, ptr %l9, !tbaa !24
  %t13 = load i64, ptr %l8, !tbaa !24
  %t16 = icmp sgt i64 %t12, %t13
  br i1 %t16, label %bb1, label %bb2
bb1:
  %t18 = load i64, ptr %l10, !tbaa !24
  %t20 = icmp sgt i64 %t18, 0
  br i1 %t20, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb6
bb3:
  %t22 = load i64, ptr %l9, !tbaa !24
  %t23 = load i64, ptr %l8, !tbaa !24
  %t26 = sub i64 %t22, %t23
  %t27 = load i64, ptr %l10, !tbaa !24
  %t30 = add i64 %t26, %t27
  %t32 = sub i64 %t30, 1
  %t33 = load i64, ptr %l10, !tbaa !24
  %t36 = sdiv i64 %t32, %t33
  store i64 %t36, ptr %l30, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb5
bb5:
  %t38 = load i64, ptr %l30, !tbaa !24
  store i64 %t38, ptr %l27, !tbaa !24
  br label %bb6
bb6:
  %t39 = load i64, ptr %l27, !tbaa !24
  store i64 %t39, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t40 = load i64, ptr %l12, !tbaa !24
  %t41 = load i64, ptr %l11, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb62
bb9:
  br label %bb10
bb10:
  %t48 = load i64, ptr %l8, !tbaa !24
  %t49 = load i64, ptr %l12, !tbaa !24
  %t50 = load i64, ptr %l10, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store i64 %t56, ptr %l13, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t58, ptr %l48, !tbaa !27
  %t59 = load i64, ptr %l13, !tbaa !24
  store i64 %t59, ptr %l49, !tbaa !24
  %t60 = load i64, ptr %l13, !tbaa !24
  %t61 = load i64, ptr @G_2ecompiler_2ffix_2eBatch, !tbaa !24
  %t64 = add i64 %t60, %t61
  %t65 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t65, 0
  %t70 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t64, i64 %t67)
  store i64 %t70, ptr %l55
  br label %bb11
bb11:
  %t71 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 0
  store i64 %t72, ptr %l56, !tbaa !24
  %t73 = load i64, ptr %l49, !tbaa !24
  %t74 = icmp sge i64 %t73, 0
  br i1 %t74, label %bb12, label %bb13
bb12:
  %t76 = load i64, ptr %l49, !tbaa !24
  %t77 = load i64, ptr %l55, !tbaa !24
  %t78 = icmp sle i64 %t76, %t77
  br i1 %t78, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_4ea6f09d5973466a_f399989f0872f916)
  unreachable
bb14:
  %t80 = load i64, ptr %l55, !tbaa !24
  %t81 = load i64, ptr %l56, !tbaa !24
  %t82 = icmp sle i64 %t80, %t81
  br i1 %t82, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_4ea6f09d5973466a_f399989f0872f916)
  unreachable
bb16:
  %t84 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = load i64, ptr %l49, !tbaa !24
  %t87 = load i64, ptr %l55, !tbaa !24
  %t88 = getelementptr { i64, ptr }, ptr %t85, i64 %t86
  %t89 = sub i64 %t87, %t86
  %t90 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t88, 1
  %t93 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t94 = load i64, ptr %l0, !tbaa !24
  %t96 = getelementptr [45 x i64], ptr @G_2ecompiler_2ffix_2eToolKinds, i64 0, i64 %t94
  %t97 = load i64, ptr %t96, !tbaa !34
  %t106 = call { i64, ptr } @compiler_2ffix_2earguments(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %s2, { i64, ptr } %t93, i64 %t97, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %t91)
  store { i64, ptr } %t106, ptr %l68
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_4ea6f09d5973466a_f399989f0872f916)
  unreachable
bb18:
  %t107 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t107, 0
  %t109 = extractvalue { i64, ptr } %t107, 1
  %t110 = mul i64 %t108, 16
  %t111 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t110)
  call void @llvm.memcpy.p0.p0.i64(ptr %t111, ptr %t109, i64 %t110, i1 false)
  %t112 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t111, 1
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d39, i32 0, i32 1) }, ptr %l70, !tbaa !27
  %t115 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t116 = call { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %s2, ptr %s2, ptr %s2, ptr %s2, { i64, ptr } %t113, { i64, ptr } %t115, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d122, i32 0, i32 1) })
  %t117 = extractvalue { i32, %"std/os:Output" } %t116, 1
  %t118 = extractvalue { i32, %"std/os:Output" } %t116, 0
  store i32 %t118, ptr %l72
  %t119 = icmp ne i32 %t118, 0
  br i1 %t119, label %bb20, label %ok.120, !prof !99
ok.120:
  store %"std/os:Output" %t117, ptr %l71
  br label %bb19
bb19:
  %t121 = load %"std/os:Output", ptr %l71
  store %"std/os:Output" %t121, ptr %l61
  br label %bb44
bb20:
  %t122 = load i32, ptr %l72, !tbaa !23
  %t123 = ashr i32 %t122, 16
  %t125 = icmp eq i32 %t123, 1
  store i1 %t125, ptr %l74, !tbaa !21
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l15
  %t126 = load i32, ptr %l72, !tbaa !23
  %t127 = lshr i32 %t126, 16
  %t128 = and i32 %t126, 65535
  %t129 = icmp eq i32 %t127, 1
  %t130 = select i1 %t129, i32 1, i32 0
  %t131 = icmp eq i32 %t126, 0
  %t132 = shl i32 %t130, 16
  %t133 = or i32 %t132, %t128
  %t134 = select i1 %t131, i32 0, i32 %t133
  %t135 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l15, i32 0, i32 0
  store i32 %t134, ptr %t135, !tbaa !23
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  %t136 = load { i32, { i64, [2 x i64] } }, ptr %l15
  store { i32, { i64, [2 x i64] } } %t136, ptr %l75
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l76
  %t137 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l75, i32 0, i32 0
  %t138 = load i32, ptr %t137, !tbaa !23
  store i32 %t138, ptr %l77, !tbaa !23
  %t139 = load i32, ptr %l77, !tbaa !23
  %t140 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l76, i32 0, i32 0
  store i32 %t139, ptr %t140, !tbaa !23
  %t141 = load i32, ptr %l77, !tbaa !23
  %t142 = ashr i32 %t141, 16
  %t144 = icmp eq i32 %t142, 1
  br i1 %t144, label %bb22, label %bb23
bb22:
  %t146 = call ptr @__olang_errpay_top_get()
  %t148 = load { i64, [2 x i64] }, ptr %t146
  %t149 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l76, i32 0, i32 1
  store { i64, [2 x i64] } %t148, ptr %t149
  br label %bb23
bb23:
  %t151 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fos_3aError_7d(ptr %s2, ptr %l76)
  store { i32, { i64, [2 x i64] } } %t151, ptr %l82
  br label %bb24
bb24:
  %t152 = load { i32, { i64, [2 x i64] } }, ptr %l82
  store { i32, { i64, [2 x i64] } } %t152, ptr %l15
  %t153 = load { i32, { i64, [2 x i64] } }, ptr %l15
  store { i32, { i64, [2 x i64] } } %t153, ptr %l83
  %t154 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l83, i32 0, i32 0
  %t155 = load i32, ptr %t154, !tbaa !23
  %t156 = ashr i32 %t155, 16
  %t158 = icmp eq i32 %t156, 1
  br i1 %t158, label %bb25, label %bb26
bb25:
  call void @__olang_errpay_pop()
  br label %bb26
bb26:
  %t160 = load ptr, ptr %l5, !tbaa !29
  store ptr %t160, ptr %l86, !tbaa !29
  %t161 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t161, ptr %l87, !tbaa !27
  %t162 = load { i32, { i64, [2 x i64] } }, ptr %l15
  store { i32, { i64, [2 x i64] } } %t162, ptr %l88
  %t164 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fos_3aError_7d(ptr %s3, ptr %l88)
  store { i32, { i64, [2 x i64] } } %t164, ptr %l90
  br label %bb27
bb27:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s4
  store ptr %s4room, ptr %s4
  %t165 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d123, i32 0, i32 1) }, 1
  %t166 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d123, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t165, i64 %t166)
  %t167 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t167, 1
  %t169 = extractvalue { i64, ptr } %t167, 0
  call void @__olang_sb_put(ptr %s4, ptr %t168, i64 %t169)
  %t170 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d124, i32 0, i32 1) }, 1
  %t171 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d124, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t170, i64 %t171)
  %t172 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l90, i32 0, i32 0
  %t173 = load i32, ptr %t172, !tbaa !23
  store i32 %t173, ptr %l91, !tbaa !23
  %t174 = load i32, ptr %l91, !tbaa !23
  %t175 = icmp eq i32 %t174, 0
  br i1 %t175, label %bb29, label %bb30
bb28:
  %t177 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d125, i32 0, i32 1) }, 1
  %t178 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d125, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t177, i64 %t178)
  %t179 = load ptr, ptr %s4
  %t180 = getelementptr %olang.builder, ptr %s4, i32 0, i32 1
  %t181 = load i64, ptr %t180
  %t182 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t181)
  call void @olang_textcopy(ptr %t182, ptr %t179, i64 %t181)
  %t183 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t182, 1
  store { i64, ptr } %t184, ptr %l106, !tbaa !27
  %t185 = getelementptr %olang.builder, ptr %s4, i32 0, i32 3
  %t186 = load ptr, ptr %t185
  %t187 = icmp ne ptr %t186, null
  br i1 %t187, label %sbgrew.188, label %sbdone.189
sbgrew.188:
  call void @__olang_sb_done(ptr %s4)
  br label %sbdone.189
sbdone.189:
  %t190 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t190, 0
  %t193 = extractvalue { i64, ptr } %t190, 1
  %t194 = mul i64 %t192, 1
  %t195 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t194)
  call void @llvm.memcpy.p0.p0.i64(ptr %t195, ptr %t193, i64 %t194, i1 false)
  %t196 = insertvalue { i64, ptr } undef, i64 %t192, 0
  %t197 = insertvalue { i64, ptr } %t196, ptr %t195, 1
  %t198 = load ptr, ptr %l86, !tbaa !29
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v4, ptr %s3, ptr %t198, { i64, ptr } %t197)
  br label %bb43
bb29:
  %t200 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d126, i32 0, i32 1) }, 1
  %t201 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d126, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t200, i64 %t201)
  br label %bb28
bb30:
  %t202 = load i32, ptr %l91, !tbaa !23
  %t203 = icmp eq i32 %t202, 65536
  br i1 %t203, label %bb31, label %bb32
bb31:
  %t205 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d127, i32 0, i32 1) }, 1
  %t206 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d127, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t205, i64 %t206)
  %t207 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 1
  %t208 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t207, i64 %t208)
  %t209 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l90, i32 0, i32 1
  %t210 = getelementptr { i64, [2 x i64] }, ptr %t209, i32 0, i32 1
  %t211 = getelementptr { { i64, ptr } }, ptr %t210, i32 0, i32 0
  %t212 = load { i64, ptr }, ptr %t211
  %t214 = extractvalue { i64, ptr } %t212, 1
  %t215 = extractvalue { i64, ptr } %t212, 0
  %t216 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t214, i64 %t215, i8 34)
  %t217 = call ptr @__olang_sb_room(ptr %s4, i64 %t216)
  %t218 = call i64 @__olang_rd_quote(ptr %t217, i64 0, ptr %t214, i64 %t215, i8 34)
  call void @__olang_sb_add(ptr %s4, i64 %t216)
  %t219 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d129, i32 0, i32 1) }, 1
  %t220 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d129, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t219, i64 %t220)
  br label %bb28
bb32:
  %t221 = load i32, ptr %l91, !tbaa !23
  %t222 = icmp eq i32 %t221, 65537
  br i1 %t222, label %bb33, label %bb34
bb33:
  %t224 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d130, i32 0, i32 1) }, 1
  %t225 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d130, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t224, i64 %t225)
  %t226 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 1
  %t227 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t226, i64 %t227)
  %t228 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l90, i32 0, i32 1
  %t229 = getelementptr { i64, [2 x i64] }, ptr %t228, i32 0, i32 1
  %t230 = getelementptr { { i64, ptr } }, ptr %t229, i32 0, i32 0
  %t231 = load { i64, ptr }, ptr %t230
  %t233 = extractvalue { i64, ptr } %t231, 1
  %t234 = extractvalue { i64, ptr } %t231, 0
  %t235 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t233, i64 %t234, i8 34)
  %t236 = call ptr @__olang_sb_room(ptr %s4, i64 %t235)
  %t237 = call i64 @__olang_rd_quote(ptr %t236, i64 0, ptr %t233, i64 %t234, i8 34)
  call void @__olang_sb_add(ptr %s4, i64 %t235)
  %t238 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d129, i32 0, i32 1) }, 1
  %t239 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d129, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t238, i64 %t239)
  br label %bb28
bb34:
  %t240 = load i32, ptr %l91, !tbaa !23
  %t241 = icmp eq i32 %t240, 65538
  br i1 %t241, label %bb35, label %bb36
bb35:
  %t243 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d131, i32 0, i32 1) }, 1
  %t244 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d131, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t243, i64 %t244)
  %t245 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 1
  %t246 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t245, i64 %t246)
  %t247 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l90, i32 0, i32 1
  %t248 = getelementptr { i64, [2 x i64] }, ptr %t247, i32 0, i32 1
  %t249 = getelementptr { { i64, ptr } }, ptr %t248, i32 0, i32 0
  %t250 = load { i64, ptr }, ptr %t249
  %t252 = extractvalue { i64, ptr } %t250, 1
  %t253 = extractvalue { i64, ptr } %t250, 0
  %t254 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t252, i64 %t253, i8 34)
  %t255 = call ptr @__olang_sb_room(ptr %s4, i64 %t254)
  %t256 = call i64 @__olang_rd_quote(ptr %t255, i64 0, ptr %t252, i64 %t253, i8 34)
  call void @__olang_sb_add(ptr %s4, i64 %t254)
  %t257 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d129, i32 0, i32 1) }, 1
  %t258 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d129, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t257, i64 %t258)
  br label %bb28
bb36:
  %t259 = load i32, ptr %l91, !tbaa !23
  %t260 = icmp eq i32 %t259, 65539
  br i1 %t260, label %bb37, label %bb38
bb37:
  %t262 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d132, i32 0, i32 1) }, 1
  %t263 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d132, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t262, i64 %t263)
  %t264 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 1
  %t265 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t264, i64 %t265)
  %t266 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l90, i32 0, i32 1
  %t267 = getelementptr { i64, [2 x i64] }, ptr %t266, i32 0, i32 1
  %t268 = getelementptr { { i64, ptr } }, ptr %t267, i32 0, i32 0
  %t269 = load { i64, ptr }, ptr %t268
  %t271 = extractvalue { i64, ptr } %t269, 1
  %t272 = extractvalue { i64, ptr } %t269, 0
  %t273 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t271, i64 %t272, i8 34)
  %t274 = call ptr @__olang_sb_room(ptr %s4, i64 %t273)
  %t275 = call i64 @__olang_rd_quote(ptr %t274, i64 0, ptr %t271, i64 %t272, i8 34)
  call void @__olang_sb_add(ptr %s4, i64 %t273)
  %t276 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d129, i32 0, i32 1) }, 1
  %t277 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d129, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t276, i64 %t277)
  br label %bb28
bb38:
  %t278 = load i32, ptr %l91, !tbaa !23
  %t279 = icmp eq i32 %t278, 65540
  br i1 %t279, label %bb39, label %bb40
bb39:
  %t281 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d133, i32 0, i32 1) }, 1
  %t282 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d133, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t281, i64 %t282)
  %t283 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 1
  %t284 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t283, i64 %t284)
  %t285 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l90, i32 0, i32 1
  %t286 = getelementptr { i64, [2 x i64] }, ptr %t285, i32 0, i32 1
  %t287 = getelementptr { { i64, ptr } }, ptr %t286, i32 0, i32 0
  %t288 = load { i64, ptr }, ptr %t287
  %t290 = extractvalue { i64, ptr } %t288, 1
  %t291 = extractvalue { i64, ptr } %t288, 0
  %t292 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t290, i64 %t291, i8 34)
  %t293 = call ptr @__olang_sb_room(ptr %s4, i64 %t292)
  %t294 = call i64 @__olang_rd_quote(ptr %t293, i64 0, ptr %t290, i64 %t291, i8 34)
  call void @__olang_sb_add(ptr %s4, i64 %t292)
  %t295 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d129, i32 0, i32 1) }, 1
  %t296 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d129, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t295, i64 %t296)
  br label %bb28
bb40:
  %t297 = load i32, ptr %l91, !tbaa !23
  %t298 = icmp eq i32 %t297, 65541
  br i1 %t298, label %bb41, label %bb42
bb41:
  %t300 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d134, i32 0, i32 1) }, 1
  %t301 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d134, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t300, i64 %t301)
  %t302 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 1
  %t303 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t302, i64 %t303)
  %t304 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l90, i32 0, i32 1
  %t305 = getelementptr { i64, [2 x i64] }, ptr %t304, i32 0, i32 1
  %t306 = getelementptr { { i64, ptr } }, ptr %t305, i32 0, i32 0
  %t307 = load { i64, ptr }, ptr %t306
  %t309 = extractvalue { i64, ptr } %t307, 1
  %t310 = extractvalue { i64, ptr } %t307, 0
  %t311 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t309, i64 %t310, i8 34)
  %t312 = call ptr @__olang_sb_room(ptr %s4, i64 %t311)
  %t313 = call i64 @__olang_rd_quote(ptr %t312, i64 0, ptr %t309, i64 %t310, i8 34)
  call void @__olang_sb_add(ptr %s4, i64 %t311)
  %t314 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d129, i32 0, i32 1) }, 1
  %t315 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d129, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t314, i64 %t315)
  br label %bb28
bb42:
  %t316 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d135, i32 0, i32 1) }, 1
  %t317 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d135, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t316, i64 %t317)
  %t318 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 1
  %t319 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t318, i64 %t319)
  %t320 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l90, i32 0, i32 1
  %t321 = getelementptr { i64, [2 x i64] }, ptr %t320, i32 0, i32 1
  %t322 = getelementptr { { i64, ptr } }, ptr %t321, i32 0, i32 0
  %t323 = load { i64, ptr }, ptr %t322
  %t325 = extractvalue { i64, ptr } %t323, 1
  %t326 = extractvalue { i64, ptr } %t323, 0
  %t327 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t325, i64 %t326, i8 34)
  %t328 = call ptr @__olang_sb_room(ptr %s4, i64 %t327)
  %t329 = call i64 @__olang_rd_quote(ptr %t328, i64 0, ptr %t325, i64 %t326, i8 34)
  call void @__olang_sb_add(ptr %s4, i64 %t327)
  %t330 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d129, i32 0, i32 1) }, 1
  %t331 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d129, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t330, i64 %t331)
  br label %bb28
bb43:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  store i64 -1, ptr %rv
  br label %ret
bb44:
  %t333 = load %"std/os:Output", ptr %l61
  store %"std/os:Output" %t333, ptr %l16
  %t334 = getelementptr %"std/os:Output", ptr %l16, i32 0, i32 1
  %t335 = load { i64, ptr }, ptr %t334, !tbaa !27
  %t336 = getelementptr %"std/os:Output", ptr %l16, i32 0, i32 2
  %t337 = load { i64, ptr }, ptr %t336, !tbaa !27
  %t339 = extractvalue { i64, ptr } %t335, 1
  %t340 = extractvalue { i64, ptr } %t335, 0
  %t342 = extractvalue { i64, ptr } %t337, 1
  %t343 = extractvalue { i64, ptr } %t337, 0
  %t344 = add i64 %t340, %t343
  %t345 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t344)
  call void @olang_textcopy(ptr %t345, ptr %t339, i64 %t340)
  %t346 = getelementptr i8, ptr %t345, i64 %t340
  call void @olang_textcopy(ptr %t346, ptr %t342, i64 %t343)
  %t347 = insertvalue { i64, ptr } undef, i64 %t344, 0
  %t348 = insertvalue { i64, ptr } %t347, ptr %t345, 1
  store { i64, ptr } %t348, ptr %l17, !tbaa !27
  %t350 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t352 = call i64 @compiler_2ffix_2ebyHand(ptr %s2, { i64, ptr } %t350)
  store i64 %t352, ptr %l114
  br label %bb45
bb45:
  %t353 = load i64, ptr %l114, !tbaa !24
  store i64 %t353, ptr %l18, !tbaa !24
  %t354 = getelementptr %"std/os:Output", ptr %l16, i32 0, i32 0
  %t355 = load i32, ptr %t354, !tbaa !23
  %t357 = icmp sgt i32 %t355, 1
  br i1 %t357, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l117, !tbaa !21
  br label %bb48
bb47:
  %t359 = load i64, ptr %l18, !tbaa !24
  %t361 = icmp sgt i64 %t359, 0
  store i1 %t361, ptr %l117, !tbaa !21
  br label %bb48
bb48:
  %t363 = load i1, ptr %l117, !tbaa !21
  br i1 %t363, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s6
  %t364 = load ptr, ptr %l5, !tbaa !29
  %t365 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t366 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t368 = extractvalue { i64, ptr } %t365, 1
  %t369 = extractvalue { i64, ptr } %t365, 0
  %t370 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d136, i32 0, i32 1) }, 1
  %t371 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d136, i32 0, i32 1) }, 0
  %t372 = add i64 %t369, %t371
  %t374 = extractvalue { i64, ptr } %t366, 1
  %t375 = extractvalue { i64, ptr } %t366, 0
  %t376 = add i64 %t372, %t375
  %t377 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t376)
  call void @olang_textcopy(ptr %t377, ptr %t368, i64 %t369)
  %t378 = getelementptr i8, ptr %t377, i64 %t369
  call void @olang_textcopy(ptr %t378, ptr %t370, i64 %t371)
  %t379 = getelementptr i8, ptr %t378, i64 %t371
  call void @olang_textcopy(ptr %t379, ptr %t374, i64 %t375)
  %t380 = insertvalue { i64, ptr } undef, i64 %t376, 0
  %t381 = insertvalue { i64, ptr } %t380, ptr %t377, 1
  %t384 = extractvalue { i64, ptr } %t381, 0
  %t385 = extractvalue { i64, ptr } %t381, 1
  %t386 = mul i64 %t384, 1
  %t387 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t386)
  call void @llvm.memcpy.p0.p0.i64(ptr %t387, ptr %t385, i64 %t386, i1 false)
  %t388 = insertvalue { i64, ptr } undef, i64 %t384, 0
  %t389 = insertvalue { i64, ptr } %t388, ptr %t387, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v4, ptr %s6, ptr %t364, { i64, ptr } %t389)
  br label %bb51
bb50:
  br label %bb57
bb51:
  %t392 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t394 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s2, ptr %s6, { i64, ptr } %t392, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d137, i32 0, i32 1) })
  store i1 %t394, ptr %l127
  br label %bb52
bb52:
  %t395 = load i1, ptr %l127, !tbaa !21
  %t396 = xor i1 %t395, true
  br i1 %t396, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s8
  %t398 = load ptr, ptr %l5, !tbaa !29
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d138, i32 0, i32 1) }, ptr %l130, !tbaa !27
  %t400 = load { i64, ptr }, ptr %l130, !tbaa !27
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v4, ptr %s8, ptr %t398, { i64, ptr } %t400)
  br label %bb55
bb54:
  br label %bb56
bb55:
  call void @__olang_scope_close(ptr %s8)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s6)
  br label %bb57
bb57:
  %t401 = getelementptr %"std/os:Output", ptr %l16, i32 0, i32 0
  %t402 = load i32, ptr %t401, !tbaa !23
  %t404 = icmp sgt i32 %t402, 1
  br i1 %t404, label %bb58, label %bb59
bb58:
  call void @__olang_scope_close(ptr %s2)
  store i64 -1, ptr %rv
  br label %ret
bb59:
  br label %bb60
bb60:
  %t407 = load i64, ptr %l7, !tbaa !24
  %t408 = load i64, ptr %l18, !tbaa !24
  %t411 = add i64 %t407, %t408
  store i64 %t411, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb61
bb61:
  %t413 = load i64, ptr %l12, !tbaa !24
  %t415 = add i64 %t413, 1
  store i64 %t415, ptr %l12, !tbaa !24
  br label %bb7
bb62:
  %t417 = load i64, ptr %l7, !tbaa !24
  store i64 %t417, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2ffix_2estdKey(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca [2 x { i64, ptr }]
  %l3 = alloca [2 x { i64, ptr }]
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca [2 x { i64, ptr }]
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l31 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca i32
  %l60 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l70 = alloca i1
  %l73 = alloca ptr
  %l74 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l77 = alloca i32
  %l85 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l15
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t3, ptr %l16, !tbaa !27
  %t4 = ptrtoint ptr %s1 to i64
  store i64 %t4, ptr %l17, !tbaa !24
  %t5 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_203_3e_2e_2d1
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = call ptr @__olang_region_make(ptr %s1)
  %t8 = ptrtoint ptr %t7 to i64
  store i64 %t8, ptr %l17, !tbaa !24
  br label %bb3
bb3:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t11 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t9, 0
  %t12 = insertvalue [2 x { i64, ptr }] %t11, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d139, i32 0, i32 1) }, 1
  store [2 x { i64, ptr }] %t12, ptr %l2
  %t15 = insertvalue { i64, ptr } undef, i64 2, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %l2, 1
  %t17 = load i64, ptr %l17
  %t18 = inttoptr i64 %t17 to ptr
  %t20 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s1, ptr %t18, { i64, ptr } %t16)
  store { i64, ptr } %t20, ptr %l23
  br label %bb4
bb4:
  %t21 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t22 = load i64, ptr %l17
  %t23 = inttoptr i64 %t22 to ptr
  %t24 = extractvalue { i64, ptr } %t21, 0
  %t25 = extractvalue { i64, ptr } %t21, 1
  %t26 = mul i64 %t24, 1
  %t27 = call ptr @__olang_held_alloc(ptr %t23, i64 %t26)
  call void @llvm.memcpy.p0.p0.i64(ptr %t27, ptr %t25, i64 %t26, i1 false)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  store { i64, ptr } %t29, ptr %l24, !tbaa !27
  %t30 = ptrtoint ptr %s1 to i64
  store i64 %t30, ptr %l25, !tbaa !24
  %t31 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_203_3e_2e_2d1
  br i1 %t31, label %bb5, label %bb6
bb5:
  %t33 = call ptr @__olang_region_make(ptr %s1)
  %t34 = ptrtoint ptr %t33 to i64
  store i64 %t34, ptr %l25, !tbaa !24
  br label %bb6
bb6:
  %t35 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t37 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t35, 0
  %t38 = insertvalue [2 x { i64, ptr }] %t37, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d140, i32 0, i32 1) }, 1
  store [2 x { i64, ptr }] %t38, ptr %l3
  %t41 = insertvalue { i64, ptr } undef, i64 2, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %l3, 1
  %t43 = load i64, ptr %l25
  %t44 = inttoptr i64 %t43 to ptr
  %t46 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s1, ptr %t44, { i64, ptr } %t42)
  store { i64, ptr } %t46, ptr %l31
  br label %bb7
bb7:
  %t47 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t48 = load i64, ptr %l25
  %t49 = inttoptr i64 %t48 to ptr
  %t50 = extractvalue { i64, ptr } %t47, 0
  %t51 = extractvalue { i64, ptr } %t47, 1
  %t52 = mul i64 %t50, 1
  %t53 = call ptr @__olang_held_alloc(ptr %t49, i64 %t52)
  call void @llvm.memcpy.p0.p0.i64(ptr %t53, ptr %t51, i64 %t52, i1 false)
  %t54 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  %t56 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t57 = insertvalue [3 x { i64, ptr }] undef, { i64, ptr } %t56, 0
  %t58 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t59 = insertvalue [3 x { i64, ptr }] %t57, { i64, ptr } %t58, 1
  %t61 = insertvalue [3 x { i64, ptr }] %t59, { i64, ptr } %t55, 2
  %t63 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 48, i64 8)
  store [3 x { i64, ptr }] %t61, ptr %t63
  store ptr %t63, ptr %l4
  store i64 0, ptr %l5, !tbaa !24
  %t65 = load ptr, ptr %l4
  store i64 3, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t68 = load i64, ptr %l5, !tbaa !24
  %t69 = load i64, ptr %l6, !tbaa !24
  %t72 = icmp slt i64 %t68, %t69
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb42
bb10:
  br label %bb11
bb11:
  %t76 = load ptr, ptr %l4
  %t77 = load i64, ptr %l5, !tbaa !24
  %t80 = getelementptr [3 x { i64, ptr }], ptr %t76, i64 0, i64 %t77
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !37
  store { i64, ptr } %t81, ptr %l7, !tbaa !27
  %t83 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t85 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %s1, ptr %s2, { i64, ptr } %t83)
  %t86 = extractvalue { i32, { i64, ptr } } %t85, 1
  %t87 = extractvalue { i32, { i64, ptr } } %t85, 0
  store i32 %t87, ptr %l47
  %t88 = icmp ne i32 %t87, 0
  br i1 %t88, label %bb13, label %ok.89, !prof !99
ok.89:
  store { i64, ptr } %t86, ptr %l46
  br label %bb12
bb12:
  %t90 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t90, ptr %l44, !tbaa !27
  br label %bb21
bb13:
  %t91 = load i32, ptr %l47, !tbaa !23
  %t92 = ashr i32 %t91, 16
  %t94 = icmp eq i32 %t92, 1
  br i1 %t94, label %bb14, label %bb15
bb14:
  call void @__olang_errpay_pop()
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t96 = icmp sge i64 0, 0
  br i1 %t96, label %bb17, label %bb18
bb17:
  %t98 = icmp sle i64 0, 576460752303423487
  br i1 %t98, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_e9114cb26b1b823b_db9b8e7e24054f2f)
  unreachable
bb19:
  %t100 = mul i64 0, 16
  %t101 = insertvalue { i64, ptr } undef, i64 0, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t102, ptr %l44, !tbaa !27
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_e9114cb26b1b823b_db9b8e7e24054f2f)
  unreachable
bb21:
  %t104 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t104, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t107 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t107, 0
  store i64 %t109, ptr %l11, !tbaa !24
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s4
  %t111 = load i64, ptr %l10, !tbaa !24
  %t112 = load i64, ptr %l11, !tbaa !24
  %t115 = icmp slt i64 %t111, %t112
  %t117 = xor i1 %t115, true
  br i1 %t117, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s4)
  br label %bb40
bb24:
  br label %bb25
bb25:
  %t119 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t119, ptr %l60, !tbaa !27
  %t120 = load i64, ptr %l10, !tbaa !24
  %t122 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr { i64, ptr }, ptr %t123, i64 %t120
  %t125 = load { i64, ptr }, ptr %t124, !tbaa !37
  %t127 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t130 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t127, 0
  %t132 = insertvalue [2 x { i64, ptr }] %t130, { i64, ptr } %t125, 1
  store [2 x { i64, ptr }] %t132, ptr %l13
  %t135 = insertvalue { i64, ptr } undef, i64 2, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %l13, 1
  %t138 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s4, ptr %s0, { i64, ptr } %t136)
  store { i64, ptr } %t138, ptr %l68
  br label %bb26
bb26:
  %t139 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t139, ptr %l14, !tbaa !27
  %t140 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t142 = call i1 @std_2fos_2eIsDir(ptr %s0, { i64, ptr } %t140)
  store i1 %t142, ptr %l70
  br label %bb27
bb27:
  %t143 = load i1, ptr %l70, !tbaa !21
  br i1 %t143, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s4)
  br label %bb39
bb29:
  br label %bb30
bb30:
  %t144 = load { i64, ptr }, ptr %l14, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } %t144)
  br label %bb31
bb31:
  store ptr %l1, ptr %l73, !tbaa !29
  %t147 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t149 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } %t147)
  %t150 = extractvalue { i32, { i64, ptr } } %t149, 1
  %t151 = extractvalue { i32, { i64, ptr } } %t149, 0
  store i32 %t151, ptr %l77
  %t152 = icmp ne i32 %t151, 0
  br i1 %t152, label %bb33, label %ok.153, !prof !99
ok.153:
  store { i64, ptr } %t150, ptr %l76
  br label %bb32
bb32:
  %t154 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t154, ptr %l74, !tbaa !27
  br label %bb37
bb33:
  %t155 = load i32, ptr %l77, !tbaa !23
  %t156 = ashr i32 %t155, 16
  %t158 = icmp eq i32 %t156, 1
  br i1 %t158, label %bb34, label %bb35
bb34:
  call void @__olang_errpay_pop()
  br label %bb35
bb35:
  br label %bb36
bb36:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d141, i32 0, i32 1) }, ptr %l74, !tbaa !27
  br label %bb37
bb37:
  %t160 = load ptr, ptr %l73, !tbaa !29
  %t161 = load { i64, ptr }, ptr %l74, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t160, { i64, ptr } %t161)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s4)
  br label %bb39
bb39:
  %t162 = load i64, ptr %l10, !tbaa !24
  %t164 = add i64 %t162, 1
  store i64 %t164, ptr %l10, !tbaa !24
  br label %bb22
bb40:
  call void @__olang_scope_close(ptr %s2)
  br label %bb41
bb41:
  %t166 = load i64, ptr %l5, !tbaa !24
  %t168 = add i64 %t166, 1
  store i64 %t168, ptr %l5, !tbaa !24
  br label %bb8
bb42:
  call void @__olang_scope_close(ptr %s1)
  %t171 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t171, ptr %l85
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s0)
  %t172 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t172, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffix_2etextsOf(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i32
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l14, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %t21, i64 %t18
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !37
  store ptr %l1, ptr %l17, !tbaa !29
  %t27 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %t23)
  %t28 = extractvalue { i32, { i64, ptr } } %t27, 1
  %t29 = extractvalue { i32, { i64, ptr } } %t27, 0
  store i32 %t29, ptr %l21
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb7, label %ok.31, !prof !99
ok.31:
  store { i64, ptr } %t28, ptr %l20
  br label %bb6
bb6:
  %t32 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t32, ptr %l18, !tbaa !27
  br label %bb11
bb7:
  %t33 = load i32, ptr %l21, !tbaa !23
  %t34 = ashr i32 %t33, 16
  %t36 = icmp eq i32 %t34, 1
  br i1 %t36, label %bb8, label %bb9
bb8:
  call void @__olang_errpay_pop()
  br label %bb9
bb9:
  br label %bb10
bb10:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d142, i32 0, i32 1) }, ptr %l18, !tbaa !27
  br label %bb11
bb11:
  %t38 = load ptr, ptr %l17, !tbaa !29
  %t39 = load { i64, ptr }, ptr %l18, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t38, { i64, ptr } %t39)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t40 = load i64, ptr %l3, !tbaa !24
  %t42 = add i64 %t40, 1
  store i64 %t42, ptr %l3, !tbaa !24
  br label %bb2
bb14:
  %t44 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i1 @compiler_2ffix_2etriggered(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i1
  %l13 = alloca i64
  %l15 = alloca i64
  %l20 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l36 = alloca i1
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d143, i32 0, i32 1) })
  store i1 %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load i1, ptr %l10, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store ptr %a1, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb5
bb5:
  %t8 = load i64, ptr %l3, !tbaa !24
  store i64 %t8, ptr %l13, !tbaa !24
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v1, ptr %t9)
  store i64 %t11, ptr %l15
  br label %bb6
bb6:
  %t12 = load i64, ptr %l13, !tbaa !24
  %t13 = load i64, ptr %l15, !tbaa !24
  %t14 = icmp slt i64 %t12, %t13
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb7, label %bb8
bb7:
  br label %bb23
bb8:
  br label %bb9
bb9:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t18, i64 %t19)
  store { i64, ptr } %t22, ptr %l20
  br label %bb10
bb10:
  %t23 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t23, ptr %l4, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s4
  %t24 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t26 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %s4, ptr %s4, { i64, ptr } %t24, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d144, i32 0, i32 1) })
  store { i64, ptr } %t26, ptr %l22
  br label %bb11
bb11:
  %t27 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t27, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t28 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  store i64 %t30, ptr %l7, !tbaa !24
  br label %bb12
bb12:
  %t32 = load i64, ptr %l6, !tbaa !24
  %t33 = load i64, ptr %l7, !tbaa !24
  %t36 = icmp slt i64 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb13, label %bb14
bb13:
  br label %bb21
bb14:
  br label %bb15
bb15:
  %t40 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t40, ptr %l29, !tbaa !27
  %t41 = load i64, ptr %l6, !tbaa !24
  %t43 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %t44, i64 %t41
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !37
  %t48 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t54 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s4, { i64, ptr } %t48, { i64, ptr } %t46)
  store i1 %t54, ptr %l36
  br label %bb16
bb16:
  %t55 = load i1, ptr %l36, !tbaa !21
  br i1 %t55, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t57 = load i64, ptr %l6, !tbaa !24
  %t59 = add i64 %t57, 1
  store i64 %t59, ptr %l6, !tbaa !24
  br label %bb12
bb21:
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb22:
  %t61 = load i64, ptr %l3, !tbaa !24
  %t63 = add i64 %t61, 1
  store i64 %t63, ptr %l3, !tbaa !24
  br label %bb5
bb23:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffix_2etrimBin(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l16 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca i64
  %s0 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l8
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l2
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l4, !tbaa !24
  %t10 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb10
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t17, ptr %l16, !tbaa !27
  %t18 = load i64, ptr %l4, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %t21, i64 %t18
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !37
  store { i64, ptr } %t23, ptr %l6, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2fbuild_2eTouch(ptr %v1, { i64, ptr } %t25)
  br label %bb6
bb6:
  store ptr %l2, ptr %l20, !tbaa !29
  %t27 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t29 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %v1, ptr %v1, { i64, ptr } %t27)
  store { i64, ptr } %t29, ptr %l22
  br label %bb7
bb7:
  %t30 = load ptr, ptr %l20, !tbaa !29
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %s0, ptr %v1, ptr %t30, { i64, ptr } %t31, i1 true)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t32 = load i64, ptr %l4, !tbaa !24
  %t34 = add i64 %t32, 1
  store i64 %t34, ptr %l4, !tbaa !24
  br label %bb2
bb10:
  %t36 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t38 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbuild_2eHoldings(ptr %v0, ptr %s0, { i64, ptr } %t36, i64 0, i1 true)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t38, ptr %l26
  br label %bb11
bb11:
  %t39 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %l7
  %t40 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t40, ptr %l27, !tbaa !27
  store ptr %l7, ptr %l28, !tbaa !29
  store ptr %l2, ptr %l29, !tbaa !29
  %t41 = call i64 @compiler_2fbuild_2eRecent()
  store i64 %t41, ptr %l30
  br label %bb12
bb12:
  %t42 = load i64, ptr @G_2ecompiler_2ffix_2eFixCacheCap, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t44 = load ptr, ptr %l28, !tbaa !29
  %t45 = load ptr, ptr %l29, !tbaa !29
  %t46 = load i64, ptr %l30, !tbaa !24
  call void @compiler_2fbuild_2eTrim(ptr %v0, ptr %s0, ptr %s0, { i64, ptr } %t43, ptr %t44, ptr %t45, i64 %t46, i64 %t42)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffix_2ewalk(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca [2 x { i64, ptr }]
  %l3 = alloca { i64, ptr }
  %l4 = alloca [2 x { i64, ptr }]
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca [2 x { i64, ptr }]
  %lp11 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l18 = alloca i1
  %l19 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i32
  %l28 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i32
  %l46 = alloca { i64, ptr }
  %l50 = alloca i1
  %l51 = alloca i1
  %l53 = alloca i1
  %l59 = alloca { i64, ptr }
  %l61 = alloca i1
  %l65 = alloca i1
  %l66 = alloca i1
  %l69 = alloca i1
  %l71 = alloca i1
  %l73 = alloca i1
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t1, 0
  %t4 = insertvalue [2 x { i64, ptr }] %t3, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d145, i32 0, i32 1) }, 1
  store [2 x { i64, ptr }] %t4, ptr %l2
  %t7 = insertvalue { i64, ptr } undef, i64 2, 0
  %t8 = insertvalue { i64, ptr } %t7, ptr %l2, 1
  %t10 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t8)
  store { i64, ptr } %t10, ptr %l16
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  %t13 = extractvalue { i64, ptr } %t11, 1
  %t14 = mul i64 %t12, 1
  %t15 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t14)
  call void @llvm.memcpy.p0.p0.i64(ptr %t15, ptr %t13, i64 %t14, i1 false)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  %t19 = call i1 @std_2fos_2eExists(ptr %s0, { i64, ptr } %t17)
  store i1 %t19, ptr %l18
  br label %bb2
bb2:
  %t20 = load i1, ptr %l18, !tbaa !21
  br i1 %t20, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t23 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %s0, { i64, ptr } %t21)
  %t24 = extractvalue { i32, { i64, ptr } } %t23, 1
  %t25 = extractvalue { i32, { i64, ptr } } %t23, 0
  store i32 %t25, ptr %l22
  %t26 = icmp ne i32 %t25, 0
  br i1 %t26, label %bb7, label %ok.27, !prof !99
ok.27:
  store { i64, ptr } %t24, ptr %l21
  br label %bb6
bb6:
  %t28 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t28, ptr %l19, !tbaa !27
  br label %bb15
bb7:
  %t29 = load i32, ptr %l22, !tbaa !23
  %t30 = ashr i32 %t29, 16
  %t32 = icmp eq i32 %t30, 1
  br i1 %t32, label %bb8, label %bb9
bb8:
  call void @__olang_errpay_pop()
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t34 = icmp sge i64 0, 0
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t36 = icmp sle i64 0, 576460752303423487
  br i1 %t36, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_9433da86f750b978_3ff5b65d50af9d4)
  unreachable
bb13:
  %t38 = mul i64 0, 16
  %t39 = insertvalue { i64, ptr } undef, i64 0, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t40, ptr %l19, !tbaa !27
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_9433da86f750b978_3ff5b65d50af9d4)
  unreachable
bb15:
  %t42 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t42, ptr %l3, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t45 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t43, 0
  %t46 = insertvalue [2 x { i64, ptr }] %t45, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d146, i32 0, i32 1) }, 1
  store [2 x { i64, ptr }] %t46, ptr %l4
  %t49 = insertvalue { i64, ptr } undef, i64 2, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %l4, 1
  %t52 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t50)
  store { i64, ptr } %t52, ptr %l33
  br label %bb16
bb16:
  %t53 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 0
  %t55 = extractvalue { i64, ptr } %t53, 1
  %t56 = mul i64 %t54, 1
  %t57 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t56)
  call void @llvm.memcpy.p0.p0.i64(ptr %t57, ptr %t55, i64 %t56, i1 false)
  %t58 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  %t61 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } %t59)
  %t62 = extractvalue { i32, { i64, ptr } } %t61, 1
  %t63 = extractvalue { i32, { i64, ptr } } %t61, 0
  store i32 %t63, ptr %l36
  %t64 = icmp ne i32 %t63, 0
  br i1 %t64, label %bb18, label %ok.65, !prof !99
ok.65:
  store { i64, ptr } %t62, ptr %l35
  br label %bb17
bb17:
  %t66 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t66, ptr %l28, !tbaa !27
  br label %bb22
bb18:
  %t67 = load i32, ptr %l36, !tbaa !23
  %t68 = ashr i32 %t67, 16
  %t70 = icmp eq i32 %t68, 1
  br i1 %t70, label %bb19, label %bb20
bb19:
  call void @__olang_errpay_pop()
  br label %bb20
bb20:
  br label %bb21
bb21:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d147, i32 0, i32 1) }, ptr %l28, !tbaa !27
  br label %bb22
bb22:
  %t72 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t72, ptr %l5, !tbaa !27
  %t73 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t73, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t75 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t75, 0
  store i64 %t77, ptr %l8, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s3
  %t79 = load i64, ptr %l7, !tbaa !24
  %t80 = load i64, ptr %l8, !tbaa !24
  %t83 = icmp slt i64 %t79, %t80
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s3)
  br label %bb55
bb25:
  br label %bb26
bb26:
  %t87 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t87, ptr %l46, !tbaa !27
  %t88 = load i64, ptr %l7, !tbaa !24
  %t90 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %t91, i64 %t88
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !37
  store { i64, ptr } %t93, ptr %l9, !tbaa !27
  %t95 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t97 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s3, { i64, ptr } %t95, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d148, i32 0, i32 1) })
  store i1 %t97, ptr %l50
  br label %bb27
bb27:
  %t98 = load i1, ptr %l50, !tbaa !21
  br i1 %t98, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb31
bb29:
  %t99 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t101 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s3, { i64, ptr } %t99, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d149, i32 0, i32 1) })
  store i1 %t101, ptr %l53
  br label %bb30
bb30:
  %t102 = load i1, ptr %l53, !tbaa !21
  store i1 %t102, ptr %l51, !tbaa !21
  br label %bb31
bb31:
  %t103 = load i1, ptr %l51, !tbaa !21
  br i1 %t103, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s3)
  br label %bb54
bb33:
  br label %bb34
bb34:
  %t104 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t107 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t104, 0
  %t109 = insertvalue [2 x { i64, ptr }] %t107, { i64, ptr } %t105, 1
  store [2 x { i64, ptr }] %t109, ptr %l10
  %t112 = insertvalue { i64, ptr } undef, i64 2, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %l10, 1
  %t115 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s3, ptr %v1, { i64, ptr } %t113)
  store { i64, ptr } %t115, ptr %l59
  br label %bb35
bb35:
  %t116 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t116, ptr %lp11
  %t117 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t118 = load ptr, ptr %lp11
  store { i64, ptr } %t117, ptr %t118, !tbaa !27
  %t119 = load ptr, ptr %lp11
  %t120 = load { i64, ptr }, ptr %t119, !tbaa !27
  %t122 = call i1 @std_2fos_2eIsDir(ptr %v1, { i64, ptr } %t120)
  store i1 %t122, ptr %l61
  br label %bb36
bb36:
  %t123 = load i1, ptr %l61, !tbaa !21
  br i1 %t123, label %bb37, label %bb38
bb37:
  %t124 = load ptr, ptr %lp11
  %t125 = load { i64, ptr }, ptr %t124, !tbaa !27
  %t126 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ffix_2ewalk(ptr %v1, ptr %v1, { i64, ptr } %t125, ptr %t126)
  br label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s6
  %t129 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t131 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s6, { i64, ptr } %t129, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d150, i32 0, i32 1) })
  store i1 %t131, ptr %l65
  br label %bb40
bb39:
  br label %bb53
bb40:
  %t132 = load i1, ptr %l65, !tbaa !21
  br i1 %t132, label %bb41, label %bb42
bb41:
  %t133 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t134 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t137 = call i1 @compiler_2ffix_2emigrationTool(ptr %s0, ptr %s0, { i64, ptr } %t133, { i64, ptr } %t134)
  store i1 %t137, ptr %l69
  br label %bb43
bb42:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb44
bb43:
  %t138 = load i1, ptr %l69, !tbaa !21
  %t139 = xor i1 %t138, true
  store i1 %t139, ptr %l66, !tbaa !21
  br label %bb44
bb44:
  %t141 = load i1, ptr %l66, !tbaa !21
  br i1 %t141, label %bb45, label %bb46
bb45:
  %t142 = load ptr, ptr %lp11
  %t143 = load { i64, ptr }, ptr %t142, !tbaa !27
  %t145 = call i1 @compiler_2ffix_2emustFail(ptr %v1, { i64, ptr } %t143)
  store i1 %t145, ptr %l73
  br label %bb47
bb46:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb48
bb47:
  %t146 = load i1, ptr %l73, !tbaa !21
  %t147 = xor i1 %t146, true
  store i1 %t147, ptr %l71, !tbaa !21
  br label %bb48
bb48:
  %t149 = load i1, ptr %l71, !tbaa !21
  br i1 %t149, label %bb49, label %bb50
bb49:
  %t150 = load ptr, ptr %l1, !tbaa !29
  %t151 = load ptr, ptr %lp11
  %t152 = load { i64, ptr }, ptr %t151, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t150, { i64, ptr } %t152)
  br label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s6)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s3)
  br label %bb54
bb54:
  %t155 = load i64, ptr %l7, !tbaa !24
  %t157 = add i64 %t155, 1
  store i64 %t157, ptr %l7, !tbaa !24
  br label %bb23
bb55:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

@.d0 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fix" }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@olang_2etable_2eI32_7cstd_2fio_3aDescriptor = linkonce_odr constant [4 x ptr] [ptr @olang_2etypeid_2eI32, ptr @olang_2eanyrender_2eI32_7cstd_2fio_3aDescriptor, ptr @olang_2eanyrender_2etop_2eI32_7cstd_2fio_3aDescriptor, ptr @olang_2eslot_2eI32_7cstd_2fio_3aDescriptor_2e0]
declare void @__olang_errpay_pop()
@.d1 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d2 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c": cannot be read\0A" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d3 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d4 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d5 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c": cannot be written\0A" }>, align 8
@.d6 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"text" }>, align 8
@.d7 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"driven" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d8 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"driven" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_202_3e_2e_2d1 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
@.d9 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @__olang_check_failed(ptr) cold noreturn
@.d10 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"tools_" }>, align 8
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
@.d12 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"OLANG_TOOLS" }>, align 8
@.d13 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d14 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d15 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"tools" }>, align 8
@.d16 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"/../tools" }>, align 8
@.d17 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"--std" }>, align 8
@.d18 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"--olang" }>, align 8
@.d19 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare ptr @__olang_standin(ptr)
declare ptr @__olang_worker_get()
declare void @__olang_worker_start(ptr, ptr, ptr, ptr)
define internal ptr @olang_task20(ptr %env) #0 {
entry:
  %f0 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 0
  %f1 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 1
  %f2 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 2
  %f3 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 3
  %f4 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 4
  %f5 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 5
  %f6 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 6
  %f7 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 7
  %f8 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 8
  %f9 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 9
  %f10 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 10
  %f11 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 11
  %f12 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 12
  %f13 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 13
  %sc0 = load ptr, ptr %f7
  %sn0 = icmp eq ptr %sc0, null
  %sg0 = load ptr, ptr @__olang_prog_scope
  %ss0 = select i1 %sn0, ptr %sg0, ptr %sc0
  %sc1 = load ptr, ptr %f8
  %sn1 = icmp eq ptr %sc1, null
  %sg1 = load ptr, ptr @__olang_prog_scope
  %ss1 = select i1 %sn1, ptr %sg1, ptr %sc1
  %sc2 = load ptr, ptr %f9
  %sn2 = icmp eq ptr %sc2, null
  %sg2 = load ptr, ptr @__olang_prog_scope
  %ss2 = select i1 %sn2, ptr %sg2, ptr %sc2
  %sc3 = load ptr, ptr %f10
  %sn3 = icmp eq ptr %sc3, null
  %sg3 = load ptr, ptr @__olang_prog_scope
  %ss3 = select i1 %sn3, ptr %sg3, ptr %sc3
  %sc4 = load ptr, ptr %f11
  %sn4 = icmp eq ptr %sc4, null
  %sg4 = load ptr, ptr @__olang_prog_scope
  %ss4 = select i1 %sn4, ptr %sg4, ptr %sc4
  %sc5 = load ptr, ptr %f12
  %sn5 = icmp eq ptr %sc5, null
  %sg5 = load ptr, ptr @__olang_prog_scope
  %ss5 = select i1 %sn5, ptr %sg5, ptr %sc5
  %sc6 = load ptr, ptr %f13
  %sn6 = icmp eq ptr %sc6, null
  %sg6 = load ptr, ptr @__olang_prog_scope
  %ss6 = select i1 %sn6, ptr %sg6, ptr %sc6
  %a0 = load { i64, ptr }, ptr %f0
  %a1 = load { i64, ptr }, ptr %f1
  %a2 = load { i64, ptr }, ptr %f2
  %a3 = load ptr, ptr %f3
  %a4 = load { i64, ptr }, ptr %f4
  %a5 = load { i64, ptr }, ptr %f5
  %a6 = load { i64, ptr }, ptr %f6
  call void @compiler_2ffix_2ebuilder(ptr %ss0, ptr %ss1, ptr %ss2, ptr %ss3, ptr %ss4, ptr %ss5, ptr %ss6, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, { i64, ptr } %a4, { i64, ptr } %a5, { i64, ptr } %a6)
  ret ptr null
}

declare i64 @__olang_join_tasks_keep(ptr, i1)
@.d21 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"tools_" }>, align 8
@.d22 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
declare ptr @__olang_errpay_top_get()
define linkonce_odr { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fos_3aError_7d(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i32, { i64, [2 x i64] } }
  %l3 = alloca { i64, [2 x i64] }
  %rv = alloca { i32, { i64, [2 x i64] } }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i32, { i64, [2 x i64] } }, ptr %a0
  store { i32, { i64, [2 x i64] } } %t2, ptr %l1
  %t3 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l1, i32 0, i32 1
  %t5 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fos_3aError_24payload(ptr %v0, ptr %t3)
  store { i64, [2 x i64] } %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load { i64, [2 x i64] }, ptr %l3
  %t7 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l1, i32 0, i32 1
  store { i64, [2 x i64] } %t6, ptr %t7
  %t8 = load { i32, { i64, [2 x i64] } }, ptr %l1
  store { i32, { i64, [2 x i64] } } %t8, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, [2 x i64] } }, ptr %rv
  ret { i32, { i64, [2 x i64] } } %rr
}

@.d23 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"cannot build tools/" }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
@.d24 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c".olang: " }>, align 8
declare void @__olang_sb_done(ptr)
declare ptr @__olang_errpay_push() cold
define linkonce_odr { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffix_3aNotBuilt_24payload(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, [2 x i64] }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, [2 x i64] }, ptr %a0
  store { i64, [2 x i64] } %t2, ptr %l1
  %t3 = load i64, ptr %l1, !range !{i64 0, i64 1}
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 ]
bb1:
  %t5 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t5, ptr %rv
  br label %ret
bb2:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, ptr } }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l5, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = mul i64 %t20, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t24 = getelementptr { { i64, ptr } }, ptr %t23, i32 0, i32 0
  store { i64, ptr } %t22, ptr %t24
  br label %bb1
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

@.d25 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d26 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"os.Error.NotFound" }>, align 8
@.d27 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
declare i64 @__olang_rd_quote(ptr, i64, ptr, i64, i8)
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare void @__olang_sb_add(ptr, i64)
@.d28 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d29 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Exists" }>, align 8
@.d30 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Denied" }>, align 8
@.d31 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.NotDir" }>, align 8
@.d32 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"os.Error.IsDir" }>, align 8
@.d33 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"os.Error.NotEmpty" }>, align 8
@.d34 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Failed" }>, align 8
declare void @__olang_errpay_set(ptr) cold
@.d35 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"tools_" }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_205_3e_2e_2d1 = weak hidden constant i1 false
@.d36 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@.d37 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"build" }>, align 8
@.d38 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"-output" }>, align 8
@.d39 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d40 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"cannot run " }>, align 8
@.d41 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d42 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d43 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"os.Error.NotFound" }>, align 8
@.d44 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d45 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d46 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Exists" }>, align 8
@.d47 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Denied" }>, align 8
@.d48 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.NotDir" }>, align 8
@.d49 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"os.Error.IsDir" }>, align 8
@.d50 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"os.Error.NotEmpty" }>, align 8
@.d51 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Failed" }>, align 8
@.d52 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"tools/" }>, align 8
@.d53 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c".olang does not build:\0A" }>, align 8
@.d54 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"cannot put tools_" }>, align 8
@.d55 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c" in place: " }>, align 8
@.d56 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d57 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"os.Error.NotFound" }>, align 8
@.d58 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d59 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d60 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Exists" }>, align 8
@.d61 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Denied" }>, align 8
@.d62 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.NotDir" }>, align 8
@.d63 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"os.Error.IsDir" }>, align 8
@.d64 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"os.Error.NotEmpty" }>, align 8
@.d65 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Failed" }>, align 8
@__olang_empty_array = external constant [16 x i64]
@.d66 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"tools_" }>, align 8
@.d67 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
define linkonce_odr { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bcompiler_2ffix_3aNotBuilt_7d(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i32, { i64, [2 x i64] } }
  %l3 = alloca { i64, [2 x i64] }
  %rv = alloca { i32, { i64, [2 x i64] } }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i32, { i64, [2 x i64] } }, ptr %a0
  store { i32, { i64, [2 x i64] } } %t2, ptr %l1
  %t3 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l1, i32 0, i32 1
  %t5 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffix_3aNotBuilt_24payload(ptr %v0, ptr %t3)
  store { i64, [2 x i64] } %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load { i64, [2 x i64] }, ptr %l3
  %t7 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l1, i32 0, i32 1
  store { i64, [2 x i64] } %t6, ptr %t7
  %t8 = load { i32, { i64, [2 x i64] } }, ptr %l1
  store { i32, { i64, [2 x i64] } } %t8, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, [2 x i64] } }, ptr %rv
  ret { i32, { i64, [2 x i64] } } %rr
}

@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
@.d68 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d69 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"by hand:" }>, align 8
@.d70 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"for a person:" }>, align 8
@.d71 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d72 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d73 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"import " }>, align 8
@.d74 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\22" }>, align 8
@.d75 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\22" }>, align 8
@.d76 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
@.d77 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".h" }>, align 8
@.d78 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".c" }>, align 8
@.d79 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@.d80 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d81 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"olang-fix." }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_206_3e_2e_2d1 = weak hidden constant i1 false
@.d82 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"m.o" }>, align 8
@.d83 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"compile" }>, align 8
@.d84 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"-quick" }>, align 8
@.d85 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"-output" }>, align 8
define internal ptr @olang_task86(ptr %env) #0 {
entry:
  %f0 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 0
  %f1 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 1
  %f2 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 2
  %f3 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 3
  %f4 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 4
  %f5 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 5
  %f6 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 6
  %f7 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 7
  %sc0 = load ptr, ptr %f4
  %sn0 = icmp eq ptr %sc0, null
  %sg0 = load ptr, ptr @__olang_prog_scope
  %ss0 = select i1 %sn0, ptr %sg0, ptr %sc0
  %sc1 = load ptr, ptr %f5
  %sn1 = icmp eq ptr %sc1, null
  %sg1 = load ptr, ptr @__olang_prog_scope
  %ss1 = select i1 %sn1, ptr %sg1, ptr %sc1
  %sc2 = load ptr, ptr %f6
  %sn2 = icmp eq ptr %sc2, null
  %sg2 = load ptr, ptr @__olang_prog_scope
  %ss2 = select i1 %sn2, ptr %sg2, ptr %sc2
  %sc3 = load ptr, ptr %f7
  %sn3 = icmp eq ptr %sc3, null
  %sg3 = load ptr, ptr @__olang_prog_scope
  %ss3 = select i1 %sn3, ptr %sg3, ptr %sc3
  %a0 = load { i64, ptr }, ptr %f0
  %a1 = load { i64, ptr }, ptr %f1
  %a2 = load { i64, ptr }, ptr %f2
  %a3 = load { i64, ptr }, ptr %f3
  call void @compiler_2ffix_2echecker(ptr %ss0, ptr %ss1, ptr %ss2, ptr %ss3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
  ret ptr null
}

@.d87 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"tools_" }>, align 8
@.d88 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"| `" }>, align 8
@.d89 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"` |" }>, align 8
@.d90 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d91 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"`" }>, align 8
@.d92 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d93 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"# check: fail" }>, align 8
@.d94 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"olang: fix: no tools directory at " }>, align 8
@.d95 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c" (OLANG_TOOLS names another)\0A" }>, align 8
@.d96 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"olang: fix: cannot make " }>, align 8
@.d97 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d98 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"OLANG_TIMES" }>, align 8
@.d99 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d100 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d101 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d102 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"olang fix: " }>, align 8
@.d103 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" of " }>, align 8
@.d104 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c" tools wanted, built in " }>, align 8
@.d105 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" ms\0A" }>, align 8
@.d106 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"olang fix: " }>, align 8
@.d107 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" of " }>, align 8
@.d108 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c" files the compiler reports an error in\0A" }>, align 8
declare ptr @__olang_scope_of(ptr, ptr) noinline
@.d109 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d110 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d111 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d112 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"olang: fix: " }>, align 8
@.d113 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d114 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"olang fix: " }>, align 8
@.d115 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d116 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" ms\0A" }>, align 8
@.d117 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d118 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d119 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"olang fix: " }>, align 8
@.d120 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" place" }>, align 8
@.d121 = private constant <{ i64, [89 x i8] }> <{ i64 0, [89 x i8] c" above may mean something else in the language of today than when written - look at each\0A" }>, align 8
@.d122 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d123 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"olang: fix: cannot run " }>, align 8
@.d124 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d125 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d126 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d127 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"os.Error.NotFound" }>, align 8
@.d128 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d129 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d130 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Exists" }>, align 8
@.d131 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Denied" }>, align 8
@.d132 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.NotDir" }>, align 8
@.d133 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"os.Error.IsDir" }>, align 8
@.d134 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"os.Error.NotEmpty" }>, align 8
@.d135 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Failed" }>, align 8
@.d136 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c":\0A" }>, align 8
@.d137 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d138 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_203_3e_2e_2d1 = weak hidden constant i1 false
@.d139 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"prelude" }>, align 8
@.d140 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"runtime" }>, align 8
@.d141 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d142 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d143 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d144 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"|" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d145 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c".olangfix" }>, align 8
@.d146 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"README.md" }>, align 8
@.d147 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d148 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d149 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"build" }>, align 8
@.d150 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@olang_2etypeid_2eI32 = linkonce_odr constant i8 0
define linkonce_odr void @olang_2eanyrender_2eI32_7cstd_2fio_3aDescriptor(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !tbaa !23
  %t4 = sext i32 %t2 to i64
  %t5 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t6 = call i64 @__olang_fmt_i64(ptr %t5, i64 %t4)
  call void @__olang_sb_add(ptr %v0, i64 %t6)
  br label %ret
ret:
  ret void
}

define linkonce_odr void @olang_2eanyrender_2etop_2eI32_7cstd_2fio_3aDescriptor(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !tbaa !23
  %t3 = sext i32 %t2 to i64
  %t4 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t5 = call i64 @__olang_fmt_i64(ptr %t4, i64 %t3)
  call void @__olang_sb_add(ptr %v0, i64 %t5)
  br label %ret
ret:
  ret void
}

define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fos_3aError_24payload(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %rv = alloca { i64, [2 x i64] }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, [2 x i64] }, ptr %a0
  store { i64, [2 x i64] } %t2, ptr %l1
  %t3 = load i64, ptr %l1, !range !{i64 0, i64 7}
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 ]
bb1:
  %t5 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t5, ptr %rv
  br label %ret
bb2:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, ptr } }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l5, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = mul i64 %t20, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t24 = getelementptr { { i64, ptr } }, ptr %t23, i32 0, i32 0
  store { i64, ptr } %t22, ptr %t24
  br label %bb1
bb3:
  %t25 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t26 = getelementptr { { i64, ptr } }, ptr %t25, i32 0, i32 0
  %t27 = load { i64, ptr }, ptr %t26
  store { i64, ptr } %t27, ptr %l6, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l7, !tbaa !24
  %t30 = load i64, ptr %l7, !tbaa !24
  %t31 = mul i64 %t30, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l8, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = load i64, ptr %l7, !tbaa !24
  %t40 = mul i64 %t39, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t36, ptr %t38, i64 %t40, i1 false)
  %t41 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t42 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t43 = getelementptr { { i64, ptr } }, ptr %t42, i32 0, i32 0
  store { i64, ptr } %t41, ptr %t43
  br label %bb1
bb4:
  %t44 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t45 = getelementptr { { i64, ptr } }, ptr %t44, i32 0, i32 0
  %t46 = load { i64, ptr }, ptr %t45
  store { i64, ptr } %t46, ptr %l9, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t47, 0
  store i64 %t48, ptr %l10, !tbaa !24
  %t49 = load i64, ptr %l10, !tbaa !24
  %t50 = mul i64 %t49, 1
  %t51 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t50)
  %t52 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t51, 1
  store { i64, ptr } %t53, ptr %l11, !tbaa !27
  %t54 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = load i64, ptr %l10, !tbaa !24
  %t59 = mul i64 %t58, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t55, ptr %t57, i64 %t59, i1 false)
  %t60 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t61 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t62 = getelementptr { { i64, ptr } }, ptr %t61, i32 0, i32 0
  store { i64, ptr } %t60, ptr %t62
  br label %bb1
bb5:
  %t63 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t64 = getelementptr { { i64, ptr } }, ptr %t63, i32 0, i32 0
  %t65 = load { i64, ptr }, ptr %t64
  store { i64, ptr } %t65, ptr %l12, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  store i64 %t67, ptr %l13, !tbaa !24
  %t68 = load i64, ptr %l13, !tbaa !24
  %t69 = mul i64 %t68, 1
  %t70 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t69)
  %t71 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l14, !tbaa !27
  %t73 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l13, !tbaa !24
  %t78 = mul i64 %t77, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t74, ptr %t76, i64 %t78, i1 false)
  %t79 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t80 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t81 = getelementptr { { i64, ptr } }, ptr %t80, i32 0, i32 0
  store { i64, ptr } %t79, ptr %t81
  br label %bb1
bb6:
  %t82 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t83 = getelementptr { { i64, ptr } }, ptr %t82, i32 0, i32 0
  %t84 = load { i64, ptr }, ptr %t83
  store { i64, ptr } %t84, ptr %l15, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 0
  store i64 %t86, ptr %l16, !tbaa !24
  %t87 = load i64, ptr %l16, !tbaa !24
  %t88 = mul i64 %t87, 1
  %t89 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t88)
  %t90 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  store { i64, ptr } %t91, ptr %l17, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = load i64, ptr %l16, !tbaa !24
  %t97 = mul i64 %t96, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t93, ptr %t95, i64 %t97, i1 false)
  %t98 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t99 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t100 = getelementptr { { i64, ptr } }, ptr %t99, i32 0, i32 0
  store { i64, ptr } %t98, ptr %t100
  br label %bb1
bb7:
  %t101 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t102 = getelementptr { { i64, ptr } }, ptr %t101, i32 0, i32 0
  %t103 = load { i64, ptr }, ptr %t102
  store { i64, ptr } %t103, ptr %l18, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  store i64 %t105, ptr %l19, !tbaa !24
  %t106 = load i64, ptr %l19, !tbaa !24
  %t107 = mul i64 %t106, 1
  %t108 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t107)
  %t109 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  store { i64, ptr } %t110, ptr %l20, !tbaa !27
  %t111 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = load i64, ptr %l19, !tbaa !24
  %t116 = mul i64 %t115, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t112, ptr %t114, i64 %t116, i1 false)
  %t117 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t118 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t119 = getelementptr { { i64, ptr } }, ptr %t118, i32 0, i32 0
  store { i64, ptr } %t117, ptr %t119
  br label %bb1
bb8:
  %t120 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t121 = getelementptr { { i64, ptr } }, ptr %t120, i32 0, i32 0
  %t122 = load { i64, ptr }, ptr %t121
  store { i64, ptr } %t122, ptr %l21, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  store i64 %t124, ptr %l22, !tbaa !24
  %t125 = load i64, ptr %l22, !tbaa !24
  %t126 = mul i64 %t125, 1
  %t127 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t126)
  %t128 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  store { i64, ptr } %t129, ptr %l23, !tbaa !27
  %t130 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = load i64, ptr %l22, !tbaa !24
  %t135 = mul i64 %t134, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t131, ptr %t133, i64 %t135, i1 false)
  %t136 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t137 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t138 = getelementptr { { i64, ptr } }, ptr %t137, i32 0, i32 0
  store { i64, ptr } %t136, ptr %t138
  br label %bb1
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

declare ptr @__olang_sb_grow(ptr, i64) noinline
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
declare { i64, ptr } @compiler_2fbuild_2eCacheDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
@G_2estd_2fio_2eStderr = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %v0, ptr %v1, { ptr, ptr } %a0, i64 %a1)
@G_2estd_2fio_2eStdout = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_cce2230832d6a50c_2dcd918d424b1980 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2ffilepath_2eDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %a0)
@olang_loc_f01e9d7c18290f7e_330799ec5065ffa2 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fos_2eExists(ptr %v0, { i64, ptr } %a0)
@olang_loc_5136839c006764b3_5260dfbee4468c57 = external constant [0 x i8]
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
declare i32 @std_2fos_2eRemoveAll(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fos_2eRename(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_233d982910cd3e61_6bc76ac40e1a9c3d = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %v0, { i64, ptr } %a0)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20Boo_Hb38d151ad2865ce380f5e3d42761bdf3(ptr %v0, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20Boo_H6b1fa5c8028973ecd947936aac3caef3(ptr %v0, ptr %a0, { i64, ptr } %a1, i1 %a2)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_d81bb51d20d074b4_82b493c82ed1c1e0 = external constant [0 x i8]
@olang_loc_40dc5ad5899010ef_fc275eeb26e8323 = external constant [0 x i8]
@olang_loc_20258a28ab60401a_640e38b19bcc26ae = external constant [0 x i8]
@olang_loc_565177cd6d363dc5_57077917db9ab2b9 = external constant [0 x i8]
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_aba33d98e166d1e8_68a02edac36c0e8c = external constant [0 x i8]
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
declare i64 @std_2ftime_2eNow()
@olang_loc_7ff6490bc64d8e4c_ced9be9374cda200 = external constant [0 x i8]
@olang_loc_4ea6f09d5973466a_f399989f0872f916 = external constant [0 x i8]
@olang_loc_e9114cb26b1b823b_db9b8e7e24054f2f = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fbuild_2eTouch(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @std_2ffilepath_2eBase(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i1 %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbuild_2eHoldings(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i1 %a2)
declare i64 @compiler_2fbuild_2eRecent()
declare void @compiler_2fbuild_2eTrim(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4)
@olang_loc_9433da86f750b978_3ff5b65d50af9d4 = external constant [0 x i8]
declare i32 @olang_2eslot_2eI32_7cstd_2fio_3aDescriptor_2e0(ptr %v0, ptr %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
