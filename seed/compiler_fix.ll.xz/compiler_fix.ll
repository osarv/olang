; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/io:Writer" = type { i32, { i64, ptr }, i64, i32 }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"std/os:FileInfo" = type { i32, i64, i64 }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
@G_2ecompiler_2ffix_2eBatch = constant <{ [8 x i8] }> <{ [8 x i8] c"\C8\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eDrivenArg = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eDrivenOpt = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eStdTool = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eTextTool = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eToolKinds = constant <{ [192 x i8] }> <{ [192 x i8] c"\01\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\03\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2ffix_2eToolNames = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k1, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k2, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k3, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k4, [8 x i8] c"\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k5, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k6, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k7, [8 x i8] c"\0C\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k8, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k9, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k10, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k11, [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k12, [8 x i8] c"\0C\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k13, [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k14, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k15, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k16, [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k17, [8 x i8] c"\0B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k18, [8 x i8] c"\0A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k19, [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k20, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k21, [8 x i8] c"\0C\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k22, [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k23, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k24 }>, align 64
@G_2ecompiler_2ffix_2eToolNames.k1 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\62\61\72\65\5F\74\79\70\65\76\61\72\73" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k2 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\70\65\72\6D\5F\6D\75\74" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k3 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\69\6E\74\5F\6C\69\74\65\72\61\6C\5F\69\36\34" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k4 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\65\72\72\6F\72\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k5 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\63\6C\69\5F\77\6F\72\64\73" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k6 = internal constant <{ [16 x i8] }> <{ [16 x i8] c"\64\6F\6E\65\66\61\69\6C\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k7 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\73\79\6E\74\61\78\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k8 = internal constant <{ [12 x i8] }> <{ [12 x i8] c"\6D\61\74\68\5F\6D\65\74\68\6F\64\73" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k9 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\61\72\72\61\79\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k10 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\72\65\73\75\6C\74\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k11 = internal constant <{ [16 x i8] }> <{ [16 x i8] c"\65\71\75\61\6C\69\74\79\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k12 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\68\65\6C\70\65\72\5F\72\65\6E\61\6D\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k13 = internal constant <{ [12 x i8] }> <{ [12 x i8] c"\6E\75\6C\6C\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k14 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\63\68\65\63\6B\65\72\72\6F\72\5F\72\65\6E\61\6D\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k15 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\73\74\75\74\74\65\72\5F\72\65\6E\61\6D\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k16 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\63\68\65\63\6B\65\64\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k17 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\63\6F\6E\74\72\61\63\74\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k18 = internal constant <{ [11 x i8] }> <{ [11 x i8] c"\74\72\79\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k19 = internal constant <{ [10 x i8] }> <{ [10 x i8] c"\61\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k20 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\65\72\72\6F\72\74\79\70\65\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k21 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\6C\69\73\74\5F\76\65\63" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k22 = internal constant <{ [12 x i8] }> <{ [12 x i8] c"\6C\69\6E\6B\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k23 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\6D\61\74\63\68\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k24 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\75\6E\75\73\65\64\5F\6D\69\67\72\61\74\65" }>, align 8
define dso_local void @compiler_2ffix_2eBatch_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 200, ptr @G_2ecompiler_2ffix_2eBatch, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ffix_2eBinDir(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l12 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l19 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l28 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l39 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %s0, { i64, ptr } %t1)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l8
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l7
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t8, ptr %l5, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 1
  %t12 = extractvalue { i64, ptr } %t9, 0
  %t13 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t11, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l5, !tbaa !27
  br label %bb4
bb4:
  %t24 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t24, ptr %l2, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t27 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v1, ptr %s0, { i64, ptr } %t25)
  %t28 = extractvalue { i32, { i64, ptr } } %t27, 1
  %t29 = extractvalue { i32, { i64, ptr } } %t27, 0
  store i32 %t29, ptr %l15
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb6, label %ok.31, !prof !99
ok.31:
  store { i64, ptr } %t28, ptr %l14
  br label %bb5
bb5:
  %t32 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t32, ptr %l12, !tbaa !27
  br label %bb8
bb6:
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  %t33 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 1
  %t36 = extractvalue { i64, ptr } %t33, 0
  %t37 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t36)
  call void @olang_textcopy(ptr %t37, ptr %t35, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t42 = extractvalue { i64, ptr } %t39, 1
  %t43 = mul i64 %t41, 1
  %t44 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t43)
  call void @llvm.memcpy.p0.p0.i64(ptr %t44, ptr %t42, i64 %t43, i1 false)
  %t45 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t44, 1
  store { i64, ptr } %t46, ptr %l12, !tbaa !27
  br label %bb8
bb8:
  %t48 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t49 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t49, ptr %l19
  br label %bb9
bb9:
  %t50 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t50, ptr %l4
  %t51 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t51, 1
  %t54 = extractvalue { i64, ptr } %t51, 0
  %t55 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t54)
  call void @olang_textcopy(ptr %t55, ptr %t53, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t60 = extractvalue { i64, ptr } %t57, 1
  %t61 = mul i64 %t59, 1
  %t62 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t61)
  call void @llvm.memcpy.p0.p0.i64(ptr %t62, ptr %t60, i64 %t61, i1 false)
  %t63 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } %t64)
  br label %bb10
bb10:
  %t67 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 1
  %t70 = extractvalue { i64, ptr } %t67, 0
  %t71 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t70)
  call void @olang_textcopy(ptr %t71, ptr %t69, i64 %t70)
  %t72 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t71, 1
  %t75 = extractvalue { i64, ptr } %t73, 0
  %t76 = extractvalue { i64, ptr } %t73, 1
  %t77 = mul i64 %t75, 1
  %t78 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t77)
  call void @llvm.memcpy.p0.p0.i64(ptr %t78, ptr %t76, i64 %t77, i1 false)
  %t79 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t78, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } %t80)
  br label %bb11
bb11:
  %t83 = call { i64, ptr } @compiler_2ffetch_2eCacheDir(ptr %v2)
  store { i64, ptr } %t83, ptr %l28
  br label %bb12
bb12:
  %t84 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 0
  %t86 = extractvalue { i64, ptr } %t84, 1
  %t87 = mul i64 %t85, 1
  %t88 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t87)
  call void @llvm.memcpy.p0.p0.i64(ptr %t88, ptr %t86, i64 %t87, i1 false)
  %t89 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  %t92 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t90, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d0, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d2, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d3, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store { i64, ptr } %t92, ptr %l30
  br label %bb13
bb13:
  %t93 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 0
  %t95 = extractvalue { i64, ptr } %t93, 1
  %t96 = mul i64 %t94, 1
  %t97 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t96)
  call void @llvm.memcpy.p0.p0.i64(ptr %t97, ptr %t95, i64 %t96, i1 false)
  %t98 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t97, 1
  store { i64, ptr } %t99, ptr %l31, !tbaa !27
  %t101 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s0, ptr %s0, ptr %l4)
  store { i64, ptr } %t101, ptr %l33
  br label %bb14
bb14:
  %t102 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 0
  store i64 %t103, ptr %l34, !tbaa !24
  %t104 = icmp sge i64 0, 0
  br i1 %t104, label %bb15, label %bb16
bb15:
  %t106 = icmp sle i64 0, 16
  br i1 %t106, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_74a546a3dd225c9b_f3beb7f3829b0fbf)
  unreachable
bb17:
  %t108 = load i64, ptr %l34, !tbaa !24
  %t109 = icmp sle i64 16, %t108
  br i1 %t109, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_74a546a3dd225c9b_f3beb7f3829b0fbf)
  unreachable
bb19:
  %t111 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr i8, ptr %t112, i64 0
  %t114 = sub i64 16, 0
  %t115 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t113, 1
  %t117 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t119 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %v2, ptr %s0, ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t117, { i64, ptr } %t116, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d2, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d3, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store { i64, ptr } %t119, ptr %l39
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_74a546a3dd225c9b_f3beb7f3829b0fbf)
  unreachable
bb21:
  call void @__olang_scope_close(ptr %s0)
  %t120 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t120, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ffix_2eDrivenArg_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 3, ptr @G_2ecompiler_2ffix_2eDrivenArg, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffix_2eDrivenOpt_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 2, ptr @G_2ecompiler_2ffix_2eDrivenOpt, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2ffix_2eFiles(ptr %v0, ptr %v1, ptr %v2, i1 %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca i1
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/io:Writer"
  %l5 = alloca %"std/io:Writer"
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l30 = alloca %"std/os:Output"
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l42 = alloca %"std/io:Writer"
  %l43 = alloca %"std/io:Writer"
  %l45 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l47 = alloca { i64, ptr }
  %l48 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l56 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca i32
  %l64 = alloca i1
  %l71 = alloca i32
  %l73 = alloca i1
  %l82 = alloca { i64, ptr }
  %l84 = alloca i1
  %l92 = alloca i32
  %l94 = alloca i1
  %l98 = alloca { i64, ptr }
  %l100 = alloca i32
  %l102 = alloca i1
  %l109 = alloca i32
  %l111 = alloca i1
  %l113 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l132 = alloca i1
  %l138 = alloca { i64, ptr }
  %l145 = alloca i64
  %l148 = alloca i64
  %l166 = alloca { i64, ptr }
  %l167 = alloca i64
  %l173 = alloca i64
  %l174 = alloca i64
  %l179 = alloca %"std/os:Output"
  %l186 = alloca { i64, ptr }
  %l188 = alloca { i64, ptr }
  %l189 = alloca %"std/os:Output"
  %l190 = alloca i32
  %l192 = alloca i1
  %l202 = alloca i64
  %l205 = alloca i1
  %l215 = alloca i1
  %l218 = alloca { i64, ptr }
  %l235 = alloca i64
  %l238 = alloca i64
  %l256 = alloca { i64, ptr }
  %l257 = alloca { i64, ptr }
  %l260 = alloca { i64, ptr }
  %l261 = alloca i32
  %l263 = alloca i1
  %l264 = alloca { i64, ptr }
  %l267 = alloca { i64, ptr }
  %l268 = alloca i1
  %l272 = alloca { i64, ptr }
  %l279 = alloca { i64, ptr }
  %l281 = alloca { i64, ptr }
  %l284 = alloca { i64, ptr }
  %l286 = alloca i32
  %l288 = alloca i1
  %l290 = alloca { i64, ptr }
  %l300 = alloca i1
  %l305 = alloca { i64, ptr }
  %l313 = alloca i32
  %l315 = alloca i1
  %l318 = alloca i32
  %l320 = alloca i1
  %l326 = alloca i1
  %l329 = alloca i1
  %l332 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %rv = alloca i32
  store i1 %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %s0, i32 2, i64 65536)
  store %"std/io:Writer" %t1, ptr %l42
  br label %bb1
bb1:
  %t2 = load %"std/io:Writer", ptr %l42
  store %"std/io:Writer" %t2, ptr %l4
  %t3 = call %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %s0, i32 1, i64 65536)
  store %"std/io:Writer" %t3, ptr %l43
  br label %bb2
bb2:
  %t4 = load %"std/io:Writer", ptr %l43
  store %"std/io:Writer" %t4, ptr %l5
  %t7 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffix_2eexpand(ptr %v0, ptr %s0, { i64, ptr } %a1)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l45
  br label %bb3
bb3:
  %t8 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l45
  %t9 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %t9
  %t11 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s0, ptr %s0, ptr %t9)
  store { i64, ptr } %t11, ptr %l47
  br label %bb4
bb4:
  %t12 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t12, ptr %l6, !tbaa !27
  %t13 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l48
  br label %bb5
bb5:
  %t14 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l48
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, ptr %l7
  %t15 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t15, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  store i64 %t19, ptr %l10, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t21 = load i64, ptr %l9, !tbaa !24
  %t22 = load i64, ptr %l10, !tbaa !24
  %t25 = icmp slt i64 %t21, %t22
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb8:
  br label %bb9
bb9:
  %t29 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t29, ptr %l56, !tbaa !27
  %t30 = load i64, ptr %l9, !tbaa !24
  %t32 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr { i64, ptr }, ptr %t33, i64 %t30
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !37
  store { i64, ptr } %t35, ptr %l11, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t39 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s2, { i64, ptr } %t37)
  %t40 = extractvalue { i32, { i64, ptr } } %t39, 1
  %t41 = extractvalue { i32, { i64, ptr } } %t39, 0
  store i32 %t41, ptr %l62
  %t42 = icmp ne i32 %t41, 0
  br i1 %t42, label %bb11, label %ok.43, !prof !99
ok.43:
  store { i64, ptr } %t40, ptr %l61
  br label %bb10
bb10:
  %t44 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t44, ptr %l59, !tbaa !27
  br label %bb18
bb11:
  %t45 = load i32, ptr %l62, !tbaa !23
  %t46 = ashr i32 %t45, 16
  %t48 = icmp eq i32 %t46, 1
  store i1 %t48, ptr %l64, !tbaa !21
  br label %bb12
bb12:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s3
  %t49 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t50 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t51 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t53 = extractvalue { i64, ptr } %t49, 1
  %t54 = extractvalue { i64, ptr } %t49, 0
  %t55 = add i64 %t51, %t54
  %t56 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t57 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t58 = add i64 %t55, %t57
  %t59 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t58)
  call void @olang_textcopy(ptr %t59, ptr %t50, i64 %t51)
  %t60 = getelementptr i8, ptr %t59, i64 %t51
  call void @olang_textcopy(ptr %t60, ptr %t53, i64 %t54)
  %t61 = getelementptr i8, ptr %t60, i64 %t54
  call void @olang_textcopy(ptr %t61, ptr %t56, i64 %t57)
  %t62 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t59, 1
  %t66 = extractvalue { i64, ptr } %t63, 0
  %t67 = extractvalue { i64, ptr } %t63, 1
  %t68 = mul i64 %t66, 1
  %t69 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t68)
  call void @llvm.memcpy.p0.p0.i64(ptr %t69, ptr %t67, i64 %t68, i1 false)
  %t70 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s3, ptr %l4, { i64, ptr } %t71)
  br label %bb13
bb13:
  %t75 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l4)
  store i32 %t75, ptr %l71
  %t76 = icmp ne i32 %t75, 0
  br i1 %t76, label %bb15, label %ok.77, !prof !99
ok.77:
  br label %bb14
bb14:
  br label %bb17
bb15:
  %t78 = load i32, ptr %l71, !tbaa !23
  %t79 = ashr i32 %t78, 16
  %t81 = icmp eq i32 %t79, 1
  store i1 %t81, ptr %l73, !tbaa !21
  br label %bb16
bb16:
  call void @__olang_ert_req_clear()
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb18:
  %t83 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t83, 1
  %t87 = extractvalue { i64, ptr } %t83, 0
  %t88 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t87)
  call void @olang_textcopy(ptr %t88, ptr %t86, i64 %t87)
  %t89 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  %t92 = extractvalue { i64, ptr } %t90, 0
  %t93 = extractvalue { i64, ptr } %t90, 1
  %t94 = mul i64 %t92, 1
  %t95 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t94)
  call void @llvm.memcpy.p0.p0.i64(ptr %t95, ptr %t93, i64 %t94, i1 false)
  %t96 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } %t97)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  %t100 = load i64, ptr %l9, !tbaa !24
  %t102 = add i64 %t100, 1
  store i64 %t102, ptr %l9, !tbaa !24
  br label %bb6
bb21:
  %t104 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t106 = call { i64, ptr } @compiler_2ffix_2eToolsDir(ptr %v1, ptr %s0, { i64, ptr } %t104)
  store { i64, ptr } %t106, ptr %l82
  br label %bb22
bb22:
  %t107 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t107, ptr %l13, !tbaa !27
  %t108 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t110 = call i1 @std_2fos_2eIsDir(ptr %s0, { i64, ptr } %t108)
  store i1 %t110, ptr %l84
  br label %bb23
bb23:
  %t111 = load i1, ptr %l84, !tbaa !21
  %t112 = xor i1 %t111, true
  br i1 %t112, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s8
  %t114 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t115 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t116 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t118 = extractvalue { i64, ptr } %t114, 1
  %t119 = extractvalue { i64, ptr } %t114, 0
  %t120 = add i64 %t116, %t119
  %t121 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t122 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t123 = add i64 %t120, %t122
  %t124 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t123)
  call void @olang_textcopy(ptr %t124, ptr %t115, i64 %t116)
  %t125 = getelementptr i8, ptr %t124, i64 %t116
  call void @olang_textcopy(ptr %t125, ptr %t118, i64 %t119)
  %t126 = getelementptr i8, ptr %t125, i64 %t119
  call void @olang_textcopy(ptr %t126, ptr %t121, i64 %t122)
  %t127 = insertvalue { i64, ptr } undef, i64 %t123, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t124, 1
  %t131 = extractvalue { i64, ptr } %t128, 0
  %t132 = extractvalue { i64, ptr } %t128, 1
  %t133 = mul i64 %t131, 1
  %t134 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t133)
  call void @llvm.memcpy.p0.p0.i64(ptr %t134, ptr %t132, i64 %t133, i1 false)
  %t135 = insertvalue { i64, ptr } undef, i64 %t131, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t134, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s8, ptr %l4, { i64, ptr } %t136)
  br label %bb26
bb25:
  br label %bb31
bb26:
  %t140 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l4)
  store i32 %t140, ptr %l92
  %t141 = icmp ne i32 %t140, 0
  br i1 %t141, label %bb28, label %ok.142, !prof !99
ok.142:
  br label %bb27
bb27:
  br label %bb30
bb28:
  %t143 = load i32, ptr %l92, !tbaa !23
  %t144 = ashr i32 %t143, 16
  %t146 = icmp eq i32 %t144, 1
  store i1 %t146, ptr %l94, !tbaa !21
  br label %bb29
bb29:
  call void @__olang_ert_req_clear()
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb31:
  %t148 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t149 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t152 = call { i64, ptr } @compiler_2ffix_2eBinDir(ptr %v1, ptr %s0, ptr %s0, { i64, ptr } %t148, { i64, ptr } %t149)
  store { i64, ptr } %t152, ptr %l98
  br label %bb32
bb32:
  %t153 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t153, ptr %l14, !tbaa !27
  %t154 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t156 = call i32 @std_2fos_2eMkDirAll(ptr %s0, { i64, ptr } %t154)
  store i32 %t156, ptr %l100
  %t157 = icmp ne i32 %t156, 0
  br i1 %t157, label %bb34, label %ok.158, !prof !99
ok.158:
  br label %bb33
bb33:
  br label %bb41
bb34:
  %t159 = load i32, ptr %l100, !tbaa !23
  %t160 = ashr i32 %t159, 16
  %t162 = icmp eq i32 %t160, 1
  store i1 %t162, ptr %l102, !tbaa !21
  br label %bb35
bb35:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s11
  %t163 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t164 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t165 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t167 = extractvalue { i64, ptr } %t163, 1
  %t168 = extractvalue { i64, ptr } %t163, 0
  %t169 = add i64 %t165, %t168
  %t170 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t171 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t172 = add i64 %t169, %t171
  %t173 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t172)
  call void @olang_textcopy(ptr %t173, ptr %t164, i64 %t165)
  %t174 = getelementptr i8, ptr %t173, i64 %t165
  call void @olang_textcopy(ptr %t174, ptr %t167, i64 %t168)
  %t175 = getelementptr i8, ptr %t174, i64 %t168
  call void @olang_textcopy(ptr %t175, ptr %t170, i64 %t171)
  %t176 = insertvalue { i64, ptr } undef, i64 %t172, 0
  %t177 = insertvalue { i64, ptr } %t176, ptr %t173, 1
  %t180 = extractvalue { i64, ptr } %t177, 0
  %t181 = extractvalue { i64, ptr } %t177, 1
  %t182 = mul i64 %t180, 1
  %t183 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t182)
  call void @llvm.memcpy.p0.p0.i64(ptr %t183, ptr %t181, i64 %t182, i1 false)
  %t184 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t183, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s11, ptr %l4, { i64, ptr } %t185)
  br label %bb36
bb36:
  %t189 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l4)
  store i32 %t189, ptr %l109
  %t190 = icmp ne i32 %t189, 0
  br i1 %t190, label %bb38, label %ok.191, !prof !99
ok.191:
  br label %bb37
bb37:
  br label %bb40
bb38:
  %t192 = load i32, ptr %l109, !tbaa !23
  %t193 = ashr i32 %t192, 16
  %t195 = icmp eq i32 %t193, 1
  store i1 %t195, ptr %l111, !tbaa !21
  br label %bb39
bb39:
  call void @__olang_ert_req_clear()
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb41:
  store i32 0, ptr %l15, !tbaa !23
  store i64 0, ptr %l16, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s14
  %t197 = call { i64, ptr } @compiler_2ffix_2eOrder(ptr %s14)
  store { i64, ptr } %t197, ptr %l113
  br label %bb42
bb42:
  %t198 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t198, 0
  %t200 = extractvalue { i64, ptr } %t198, 1
  %t201 = mul i64 %t199, 8
  %t202 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t201)
  call void @llvm.memcpy.p0.p0.i64(ptr %t202, ptr %t200, i64 %t201, i1 false)
  %t203 = insertvalue { i64, ptr } undef, i64 %t199, 0
  %t204 = insertvalue { i64, ptr } %t203, ptr %t202, 1
  store { i64, ptr } %t204, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t206 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t206, 0
  store i64 %t208, ptr %l19, !tbaa !24
  br label %bb43
bb43:
  store %olang.scope zeroinitializer, ptr %s15
  %t210 = load i64, ptr %l18, !tbaa !24
  %t211 = load i64, ptr %l19, !tbaa !24
  %t214 = icmp slt i64 %t210, %t211
  %t216 = xor i1 %t214, true
  br i1 %t216, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s15)
  br label %bb97
bb45:
  br label %bb46
bb46:
  %t218 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t218, ptr %l121, !tbaa !27
  %t219 = load i64, ptr %l18, !tbaa !24
  %t221 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t222 = load ptr, ptr %t221, !tbaa !27
  %t223 = getelementptr i64, ptr %t222, i64 %t219
  %t224 = load i64, ptr %t223, !tbaa !34
  store i64 %t224, ptr %l20, !tbaa !24
  %t226 = load i64, ptr %l20, !tbaa !24
  %t228 = getelementptr [24 x { i64, ptr }], ptr @G_2ecompiler_2ffix_2eToolNames, i64 0, i64 %t226
  %t229 = load { i64, ptr }, ptr %t228, !tbaa !37
  store { i64, ptr } %t229, ptr %l21, !tbaa !27
  %t231 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t232 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t233 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t234 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t235 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t236 = load ptr, ptr @__olang_prog_scope
  %t243 = call i1 @compiler_2ffix_2eensureBuilt(ptr %v1, ptr %s0, ptr %s0, ptr %t236, ptr %v2, ptr %s0, { i64, ptr } %t231, { i64, ptr } %t232, { i64, ptr } %t233, { i64, ptr } %t234, { i64, ptr } %t235, ptr %l4)
  store i1 %t243, ptr %l132
  br label %bb47
bb47:
  %t244 = load i1, ptr %l132, !tbaa !21
  %t245 = xor i1 %t244, true
  br i1 %t245, label %bb48, label %bb49
bb48:
  store i32 2, ptr %l15, !tbaa !23
  call void @__olang_scope_close(ptr %s15)
  br label %bb97
bb49:
  br label %bb50
bb50:
  %t247 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t248 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t249 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t250 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t252 = extractvalue { i64, ptr } %t248, 1
  %t253 = extractvalue { i64, ptr } %t248, 0
  %t254 = add i64 %t250, %t253
  %t255 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t254)
  call void @olang_textcopy(ptr %t255, ptr %t249, i64 %t250)
  %t256 = getelementptr i8, ptr %t255, i64 %t250
  call void @olang_textcopy(ptr %t256, ptr %t252, i64 %t253)
  %t257 = insertvalue { i64, ptr } undef, i64 %t254, 0
  %t258 = insertvalue { i64, ptr } %t257, ptr %t255, 1
  %t260 = extractvalue { i64, ptr } %t258, 0
  %t261 = extractvalue { i64, ptr } %t258, 1
  %t262 = mul i64 %t260, 1
  %t263 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t262)
  call void @llvm.memcpy.p0.p0.i64(ptr %t263, ptr %t261, i64 %t262, i1 false)
  %t264 = insertvalue { i64, ptr } undef, i64 %t260, 0
  %t265 = insertvalue { i64, ptr } %t264, ptr %t263, 1
  %t268 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s15, ptr %s15, ptr %s15, ptr %s15, ptr %s15, ptr %s15, { i64, ptr } %t247, { i64, ptr } %t265, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d2, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d3, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store { i64, ptr } %t268, ptr %l138
  br label %bb51
bb51:
  %t269 = load { i64, ptr }, ptr %l138, !tbaa !27
  store { i64, ptr } %t269, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t270 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t272 = extractvalue { i64, ptr } %t270, 0
  store i64 %t272, ptr %l24, !tbaa !24
  %t274 = load i64, ptr @G_2ecompiler_2ffix_2eBatch, !tbaa !24
  store i64 %t274, ptr %l25, !tbaa !24
  %t276 = load i64, ptr %l24, !tbaa !24
  %t277 = load i64, ptr %l23, !tbaa !24
  %t280 = icmp sgt i64 %t276, %t277
  br i1 %t280, label %bb52, label %bb53
bb52:
  %t282 = load i64, ptr %l25, !tbaa !24
  %t284 = icmp sgt i64 %t282, 0
  br i1 %t284, label %bb54, label %bb55
bb53:
  store i64 0, ptr %l145, !tbaa !24
  br label %bb57
bb54:
  %t286 = load i64, ptr %l24, !tbaa !24
  %t287 = load i64, ptr %l23, !tbaa !24
  %t290 = sub i64 %t286, %t287
  %t291 = load i64, ptr %l25, !tbaa !24
  %t294 = add i64 %t290, %t291
  %t296 = sub i64 %t294, 1
  %t297 = load i64, ptr %l25, !tbaa !24
  %t300 = sdiv i64 %t296, %t297
  store i64 %t300, ptr %l148, !tbaa !24
  br label %bb56
bb55:
  store i64 0, ptr %l148, !tbaa !24
  br label %bb56
bb56:
  %t302 = load i64, ptr %l148, !tbaa !24
  store i64 %t302, ptr %l145, !tbaa !24
  br label %bb57
bb57:
  %t303 = load i64, ptr %l145, !tbaa !24
  store i64 %t303, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb58
bb58:
  store %olang.scope zeroinitializer, ptr %s19
  %t304 = load i64, ptr %l27, !tbaa !24
  %t305 = load i64, ptr %l26, !tbaa !24
  %t308 = icmp slt i64 %t304, %t305
  %t310 = xor i1 %t308, true
  br i1 %t310, label %bb59, label %bb60
bb59:
  call void @__olang_scope_close(ptr %s19)
  br label %bb92
bb60:
  br label %bb61
bb61:
  %t312 = load i64, ptr %l23, !tbaa !24
  %t313 = load i64, ptr %l27, !tbaa !24
  %t314 = load i64, ptr %l25, !tbaa !24
  %t317 = mul i64 %t313, %t314
  %t320 = add i64 %t312, %t317
  store i64 %t320, ptr %l28, !tbaa !24
  %t322 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t322, ptr %l166, !tbaa !27
  %t323 = load i64, ptr %l28, !tbaa !24
  store i64 %t323, ptr %l167, !tbaa !24
  %t324 = load i64, ptr %l28, !tbaa !24
  %t325 = load i64, ptr @G_2ecompiler_2ffix_2eBatch, !tbaa !24
  %t328 = add i64 %t324, %t325
  %t329 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t331 = extractvalue { i64, ptr } %t329, 0
  %t334 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t328, i64 %t331)
  store i64 %t334, ptr %l173
  br label %bb62
bb62:
  %t335 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t336 = extractvalue { i64, ptr } %t335, 0
  store i64 %t336, ptr %l174, !tbaa !24
  %t337 = load i64, ptr %l167, !tbaa !24
  %t338 = icmp sge i64 %t337, 0
  br i1 %t338, label %bb63, label %bb64
bb63:
  %t340 = load i64, ptr %l167, !tbaa !24
  %t341 = load i64, ptr %l173, !tbaa !24
  %t342 = icmp sle i64 %t340, %t341
  br i1 %t342, label %bb65, label %bb66
bb64:
  call void @__olang_check_failed(ptr @olang_loc_299e69389bcee8f2_b185402659ea7d46)
  unreachable
bb65:
  %t344 = load i64, ptr %l173, !tbaa !24
  %t345 = load i64, ptr %l174, !tbaa !24
  %t346 = icmp sle i64 %t344, %t345
  br i1 %t346, label %bb67, label %bb68
bb66:
  call void @__olang_check_failed(ptr @olang_loc_299e69389bcee8f2_b185402659ea7d46)
  unreachable
bb67:
  %t348 = getelementptr { i64, ptr }, ptr %l166, i32 0, i32 1
  %t349 = load ptr, ptr %t348, !tbaa !27
  %t350 = load i64, ptr %l167, !tbaa !24
  %t351 = load i64, ptr %l173, !tbaa !24
  %t352 = getelementptr { i64, ptr }, ptr %t349, i64 %t350
  %t353 = sub i64 %t351, %t350
  %t354 = insertvalue { i64, ptr } undef, i64 %t353, 0
  %t355 = insertvalue { i64, ptr } %t354, ptr %t352, 1
  %t357 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t358 = load i64, ptr %l20, !tbaa !24
  %t360 = getelementptr [24 x i64], ptr @G_2ecompiler_2ffix_2eToolKinds, i64 0, i64 %t358
  %t361 = load i64, ptr %t360, !tbaa !34
  %t362 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t363 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t370 = call { i64, ptr } @compiler_2ffix_2earguments(ptr %s15, ptr %v1, ptr %v2, ptr %s0, ptr %s19, { i64, ptr } %t357, i64 %t361, { i64, ptr } %t362, { i64, ptr } %t363, { i64, ptr } %t355)
  store { i64, ptr } %t370, ptr %l186
  br label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_299e69389bcee8f2_b185402659ea7d46)
  unreachable
bb69:
  %t371 = load { i64, ptr }, ptr %l186, !tbaa !27
  %t372 = extractvalue { i64, ptr } %t371, 0
  %t373 = extractvalue { i64, ptr } %t371, 1
  %t374 = mul i64 %t372, 16
  %t375 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t374)
  call void @llvm.memcpy.p0.p0.i64(ptr %t375, ptr %t373, i64 %t374, i1 false)
  %t376 = insertvalue { i64, ptr } undef, i64 %t372, 0
  %t377 = insertvalue { i64, ptr } %t376, ptr %t375, 1
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr %l188, !tbaa !27
  %t379 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t380 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s19, ptr %s19, ptr %s19, ptr %s19, { i64, ptr } %t377, { i64, ptr } %t379, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d13, i32 0, i32 1) })
  %t381 = extractvalue { i32, %"std/os:Output" } %t380, 1
  %t382 = extractvalue { i32, %"std/os:Output" } %t380, 0
  store i32 %t382, ptr %l190
  %t383 = icmp ne i32 %t382, 0
  br i1 %t383, label %bb71, label %ok.384, !prof !99
ok.384:
  store %"std/os:Output" %t381, ptr %l189
  br label %bb70
bb70:
  %t385 = load %"std/os:Output", ptr %l189
  store %"std/os:Output" %t385, ptr %l179
  br label %bb74
bb71:
  %t386 = load i32, ptr %l190, !tbaa !23
  %t387 = ashr i32 %t386, 16
  %t389 = icmp eq i32 %t387, 1
  store i1 %t389, ptr %l192, !tbaa !21
  br label %bb72
bb72:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s20
  %t390 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t391 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t392 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t394 = extractvalue { i64, ptr } %t390, 1
  %t395 = extractvalue { i64, ptr } %t390, 0
  %t396 = add i64 %t392, %t395
  %t397 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t398 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t399 = add i64 %t396, %t398
  %t400 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t399)
  call void @olang_textcopy(ptr %t400, ptr %t391, i64 %t392)
  %t401 = getelementptr i8, ptr %t400, i64 %t392
  call void @olang_textcopy(ptr %t401, ptr %t394, i64 %t395)
  %t402 = getelementptr i8, ptr %t401, i64 %t395
  call void @olang_textcopy(ptr %t402, ptr %t397, i64 %t398)
  %t403 = insertvalue { i64, ptr } undef, i64 %t399, 0
  %t404 = insertvalue { i64, ptr } %t403, ptr %t400, 1
  %t407 = extractvalue { i64, ptr } %t404, 0
  %t408 = extractvalue { i64, ptr } %t404, 1
  %t409 = mul i64 %t407, 1
  %t410 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t409)
  call void @llvm.memcpy.p0.p0.i64(ptr %t410, ptr %t408, i64 %t409, i1 false)
  %t411 = insertvalue { i64, ptr } undef, i64 %t407, 0
  %t412 = insertvalue { i64, ptr } %t411, ptr %t410, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s20, ptr %l4, { i64, ptr } %t412)
  br label %bb73
bb73:
  store i32 2, ptr %l15, !tbaa !23
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s19)
  br label %bb92
bb74:
  %t415 = load %"std/os:Output", ptr %l179
  store %"std/os:Output" %t415, ptr %l30
  %t416 = getelementptr %"std/os:Output", ptr %l30, i32 0, i32 1
  %t417 = load { i64, ptr }, ptr %t416, !tbaa !27
  %t418 = getelementptr %"std/os:Output", ptr %l30, i32 0, i32 2
  %t419 = load { i64, ptr }, ptr %t418, !tbaa !27
  %t421 = extractvalue { i64, ptr } %t417, 1
  %t422 = extractvalue { i64, ptr } %t417, 0
  %t424 = extractvalue { i64, ptr } %t419, 1
  %t425 = extractvalue { i64, ptr } %t419, 0
  %t426 = add i64 %t422, %t425
  %t427 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t426)
  call void @olang_textcopy(ptr %t427, ptr %t421, i64 %t422)
  %t428 = getelementptr i8, ptr %t427, i64 %t422
  call void @olang_textcopy(ptr %t428, ptr %t424, i64 %t425)
  %t429 = insertvalue { i64, ptr } undef, i64 %t426, 0
  %t430 = insertvalue { i64, ptr } %t429, ptr %t427, 1
  store { i64, ptr } %t430, ptr %l31, !tbaa !27
  %t432 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t434 = call i64 @compiler_2ffix_2ebyHand(ptr %s19, { i64, ptr } %t432)
  store i64 %t434, ptr %l202
  br label %bb75
bb75:
  %t435 = load i64, ptr %l202, !tbaa !24
  store i64 %t435, ptr %l32, !tbaa !24
  %t436 = getelementptr %"std/os:Output", ptr %l30, i32 0, i32 0
  %t437 = load i32, ptr %t436, !tbaa !23
  %t439 = icmp sgt i32 %t437, 1
  br i1 %t439, label %bb76, label %bb77
bb76:
  store i1 true, ptr %l205, !tbaa !21
  br label %bb78
bb77:
  %t441 = load i64, ptr %l32, !tbaa !24
  %t443 = icmp sgt i64 %t441, 0
  store i1 %t443, ptr %l205, !tbaa !21
  br label %bb78
bb78:
  %t445 = load i1, ptr %l205, !tbaa !21
  br i1 %t445, label %bb79, label %bb80
bb79:
  store %olang.scope zeroinitializer, ptr %s23
  %t446 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t447 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t449 = extractvalue { i64, ptr } %t446, 1
  %t450 = extractvalue { i64, ptr } %t446, 0
  %t451 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t452 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t453 = add i64 %t450, %t452
  %t455 = extractvalue { i64, ptr } %t447, 1
  %t456 = extractvalue { i64, ptr } %t447, 0
  %t457 = add i64 %t453, %t456
  %t458 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t457)
  call void @olang_textcopy(ptr %t458, ptr %t449, i64 %t450)
  %t459 = getelementptr i8, ptr %t458, i64 %t450
  call void @olang_textcopy(ptr %t459, ptr %t451, i64 %t452)
  %t460 = getelementptr i8, ptr %t459, i64 %t452
  call void @olang_textcopy(ptr %t460, ptr %t455, i64 %t456)
  %t461 = insertvalue { i64, ptr } undef, i64 %t457, 0
  %t462 = insertvalue { i64, ptr } %t461, ptr %t458, 1
  %t465 = extractvalue { i64, ptr } %t462, 0
  %t466 = extractvalue { i64, ptr } %t462, 1
  %t467 = mul i64 %t465, 1
  %t468 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t467)
  call void @llvm.memcpy.p0.p0.i64(ptr %t468, ptr %t466, i64 %t467, i1 false)
  %t469 = insertvalue { i64, ptr } undef, i64 %t465, 0
  %t470 = insertvalue { i64, ptr } %t469, ptr %t468, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s23, ptr %l4, { i64, ptr } %t470)
  br label %bb81
bb80:
  br label %bb87
bb81:
  %t473 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t475 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s19, ptr %s23, { i64, ptr } %t473, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store i1 %t475, ptr %l215
  br label %bb82
bb82:
  %t476 = load i1, ptr %l215, !tbaa !21
  %t477 = xor i1 %t476, true
  br i1 %t477, label %bb83, label %bb84
bb83:
  store %olang.scope zeroinitializer, ptr %s25
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l218, !tbaa !27
  %t480 = load { i64, ptr }, ptr %l218, !tbaa !27
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s25, ptr %l4, { i64, ptr } %t480)
  br label %bb85
bb84:
  br label %bb86
bb85:
  call void @__olang_scope_close(ptr %s25)
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s23)
  br label %bb87
bb87:
  %t481 = load i64, ptr %l16, !tbaa !24
  %t482 = load i64, ptr %l32, !tbaa !24
  %t485 = add i64 %t481, %t482
  store i64 %t485, ptr %l16, !tbaa !24
  %t487 = getelementptr %"std/os:Output", ptr %l30, i32 0, i32 0
  %t488 = load i32, ptr %t487, !tbaa !23
  %t490 = icmp sgt i32 %t488, 1
  br i1 %t490, label %bb88, label %bb89
bb88:
  store i32 2, ptr %l15, !tbaa !23
  br label %bb90
bb89:
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s19)
  br label %bb91
bb91:
  %t492 = load i64, ptr %l27, !tbaa !24
  %t494 = add i64 %t492, 1
  store i64 %t494, ptr %l27, !tbaa !24
  br label %bb58
bb92:
  %t496 = load i32, ptr %l15, !tbaa !23
  %t498 = icmp ne i32 %t496, 0
  br i1 %t498, label %bb93, label %bb94
bb93:
  call void @__olang_scope_close(ptr %s15)
  br label %bb97
bb94:
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s15)
  br label %bb96
bb96:
  %t500 = load i64, ptr %l18, !tbaa !24
  %t502 = add i64 %t500, 1
  store i64 %t502, ptr %l18, !tbaa !24
  br label %bb43
bb97:
  call void @__olang_scope_close(ptr %s14)
  store i64 0, ptr %l33, !tbaa !24
  store i64 0, ptr %l34, !tbaa !24
  %t504 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t506 = extractvalue { i64, ptr } %t504, 0
  store i64 %t506, ptr %l35, !tbaa !24
  store i64 1, ptr %l36, !tbaa !24
  %t508 = load i64, ptr %l35, !tbaa !24
  %t509 = load i64, ptr %l34, !tbaa !24
  %t512 = icmp sgt i64 %t508, %t509
  br i1 %t512, label %bb98, label %bb99
bb98:
  %t514 = load i64, ptr %l36, !tbaa !24
  %t516 = icmp sgt i64 %t514, 0
  br i1 %t516, label %bb100, label %bb101
bb99:
  store i64 0, ptr %l235, !tbaa !24
  br label %bb103
bb100:
  %t518 = load i64, ptr %l35, !tbaa !24
  %t519 = load i64, ptr %l34, !tbaa !24
  %t522 = sub i64 %t518, %t519
  %t523 = load i64, ptr %l36, !tbaa !24
  %t526 = add i64 %t522, %t523
  %t528 = sub i64 %t526, 1
  %t529 = load i64, ptr %l36, !tbaa !24
  %t532 = sdiv i64 %t528, %t529
  store i64 %t532, ptr %l238, !tbaa !24
  br label %bb102
bb101:
  store i64 0, ptr %l238, !tbaa !24
  br label %bb102
bb102:
  %t534 = load i64, ptr %l238, !tbaa !24
  store i64 %t534, ptr %l235, !tbaa !24
  br label %bb103
bb103:
  %t535 = load i64, ptr %l235, !tbaa !24
  store i64 %t535, ptr %l37, !tbaa !24
  store i64 0, ptr %l38, !tbaa !24
  br label %bb104
bb104:
  store %olang.scope zeroinitializer, ptr %s31
  %t536 = load i64, ptr %l38, !tbaa !24
  %t537 = load i64, ptr %l37, !tbaa !24
  %t540 = icmp slt i64 %t536, %t537
  %t542 = xor i1 %t540, true
  br i1 %t542, label %bb105, label %bb106
bb105:
  call void @__olang_scope_close(ptr %s31)
  br label %bb128
bb106:
  br label %bb107
bb107:
  %t544 = load i64, ptr %l34, !tbaa !24
  %t545 = load i64, ptr %l38, !tbaa !24
  %t546 = load i64, ptr %l36, !tbaa !24
  %t549 = mul i64 %t545, %t546
  %t552 = add i64 %t544, %t549
  store i64 %t552, ptr %l39, !tbaa !24
  %t554 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t554, ptr %l257, !tbaa !27
  %t555 = load i64, ptr %l39, !tbaa !24
  %t557 = getelementptr { i64, ptr }, ptr %l257, i32 0, i32 1
  %t558 = load ptr, ptr %t557, !tbaa !27
  %t559 = getelementptr { i64, ptr }, ptr %t558, i64 %t555
  %t560 = load { i64, ptr }, ptr %t559, !tbaa !37
  %t562 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s31, { i64, ptr } %t560)
  %t563 = extractvalue { i32, { i64, ptr } } %t562, 1
  %t564 = extractvalue { i32, { i64, ptr } } %t562, 0
  store i32 %t564, ptr %l261
  %t565 = icmp ne i32 %t564, 0
  br i1 %t565, label %bb109, label %ok.566, !prof !99
ok.566:
  store { i64, ptr } %t563, ptr %l260
  br label %bb108
bb108:
  %t567 = load { i64, ptr }, ptr %l260, !tbaa !27
  store { i64, ptr } %t567, ptr %l256, !tbaa !27
  br label %bb111
bb109:
  %t568 = load i32, ptr %l261, !tbaa !23
  %t569 = ashr i32 %t568, 16
  %t571 = icmp eq i32 %t569, 1
  store i1 %t571, ptr %l263, !tbaa !21
  br label %bb110
bb110:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s31)
  br label %bb127
bb111:
  %t572 = load { i64, ptr }, ptr %l256, !tbaa !27
  store { i64, ptr } %t572, ptr %l264, !tbaa !27
  %t574 = load i64, ptr %l39, !tbaa !24
  %t577 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l7, i64 %t574)
  store { i64, ptr } %t577, ptr %l267
  br label %bb112
bb112:
  %t578 = load { i64, ptr }, ptr %l264, !tbaa !27
  %t579 = load { i64, ptr }, ptr %l267, !tbaa !27
  %t580 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s31, ptr %s0, { i64, ptr } %t578, { i64, ptr } %t579)
  store i1 %t580, ptr %l268
  br label %bb113
bb113:
  %t581 = load i1, ptr %l268, !tbaa !21
  br i1 %t581, label %bb114, label %bb115
bb114:
  call void @__olang_scope_close(ptr %s31)
  br label %bb127
bb115:
  br label %bb116
bb116:
  %t582 = load i64, ptr %l33, !tbaa !24
  %t584 = add i64 %t582, 1
  store i64 %t584, ptr %l33, !tbaa !24
  %t586 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t586, ptr %l272, !tbaa !27
  %t587 = load i64, ptr %l39, !tbaa !24
  %t589 = getelementptr { i64, ptr }, ptr %l272, i32 0, i32 1
  %t590 = load ptr, ptr %t589, !tbaa !27
  %t591 = getelementptr { i64, ptr }, ptr %t590, i64 %t587
  %t592 = load { i64, ptr }, ptr %t591, !tbaa !37
  %t594 = extractvalue { i64, ptr } %t592, 1
  %t595 = extractvalue { i64, ptr } %t592, 0
  %t596 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t597 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t598 = add i64 %t595, %t597
  %t599 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t598)
  call void @olang_textcopy(ptr %t599, ptr %t594, i64 %t595)
  %t600 = getelementptr i8, ptr %t599, i64 %t595
  call void @olang_textcopy(ptr %t600, ptr %t596, i64 %t597)
  %t601 = insertvalue { i64, ptr } undef, i64 %t598, 0
  %t602 = insertvalue { i64, ptr } %t601, ptr %t599, 1
  %t605 = extractvalue { i64, ptr } %t602, 0
  %t606 = extractvalue { i64, ptr } %t602, 1
  %t607 = mul i64 %t605, 1
  %t608 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t607)
  call void @llvm.memcpy.p0.p0.i64(ptr %t608, ptr %t606, i64 %t607, i1 false)
  %t609 = insertvalue { i64, ptr } undef, i64 %t605, 0
  %t610 = insertvalue { i64, ptr } %t609, ptr %t608, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s31, ptr %l5, { i64, ptr } %t610)
  br label %bb117
bb117:
  %t613 = load i1, ptr %l0, !tbaa !21
  br i1 %t613, label %bb118, label %bb119
bb118:
  store %olang.scope zeroinitializer, ptr %s35
  %t615 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t615, ptr %l279, !tbaa !27
  %t616 = load i64, ptr %l39, !tbaa !24
  %t618 = getelementptr { i64, ptr }, ptr %l279, i32 0, i32 1
  %t619 = load ptr, ptr %t618, !tbaa !27
  %t620 = getelementptr { i64, ptr }, ptr %t619, i64 %t616
  %t621 = load { i64, ptr }, ptr %t620, !tbaa !37
  store { i64, ptr } %t621, ptr %l281, !tbaa !27
  %t622 = load i64, ptr %l39, !tbaa !24
  %t625 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s35, ptr %l7, i64 %t622)
  store { i64, ptr } %t625, ptr %l284
  br label %bb120
bb119:
  br label %bb126
bb120:
  %t626 = load { i64, ptr }, ptr %l284, !tbaa !27
  %t627 = load { i64, ptr }, ptr %l281, !tbaa !27
  %t629 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s35, { i64, ptr } %t627, { i64, ptr } %t626)
  store i32 %t629, ptr %l286
  %t630 = icmp ne i32 %t629, 0
  br i1 %t630, label %bb122, label %ok.631, !prof !99
ok.631:
  br label %bb121
bb121:
  br label %bb125
bb122:
  %t632 = load i32, ptr %l286, !tbaa !23
  %t633 = ashr i32 %t632, 16
  %t635 = icmp eq i32 %t633, 1
  store i1 %t635, ptr %l288, !tbaa !21
  br label %bb123
bb123:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s36
  %t636 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t636, ptr %l290, !tbaa !27
  %t637 = load i64, ptr %l39, !tbaa !24
  %t639 = getelementptr { i64, ptr }, ptr %l290, i32 0, i32 1
  %t640 = load ptr, ptr %t639, !tbaa !27
  %t641 = getelementptr { i64, ptr }, ptr %t640, i64 %t637
  %t642 = load { i64, ptr }, ptr %t641, !tbaa !37
  %t643 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t644 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t646 = extractvalue { i64, ptr } %t642, 1
  %t647 = extractvalue { i64, ptr } %t642, 0
  %t648 = add i64 %t644, %t647
  %t649 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t650 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t651 = add i64 %t648, %t650
  %t652 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t651)
  call void @olang_textcopy(ptr %t652, ptr %t643, i64 %t644)
  %t653 = getelementptr i8, ptr %t652, i64 %t644
  call void @olang_textcopy(ptr %t653, ptr %t646, i64 %t647)
  %t654 = getelementptr i8, ptr %t653, i64 %t647
  call void @olang_textcopy(ptr %t654, ptr %t649, i64 %t650)
  %t655 = insertvalue { i64, ptr } undef, i64 %t651, 0
  %t656 = insertvalue { i64, ptr } %t655, ptr %t652, 1
  %t659 = extractvalue { i64, ptr } %t656, 0
  %t660 = extractvalue { i64, ptr } %t656, 1
  %t661 = mul i64 %t659, 1
  %t662 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t661)
  call void @llvm.memcpy.p0.p0.i64(ptr %t662, ptr %t660, i64 %t661, i1 false)
  %t663 = insertvalue { i64, ptr } undef, i64 %t659, 0
  %t664 = insertvalue { i64, ptr } %t663, ptr %t662, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s36, ptr %l4, { i64, ptr } %t664)
  br label %bb124
bb124:
  call void @__olang_scope_close(ptr %s36)
  br label %bb125
bb125:
  call void @__olang_scope_close(ptr %s35)
  br label %bb126
bb126:
  call void @__olang_scope_close(ptr %s31)
  br label %bb127
bb127:
  %t667 = load i64, ptr %l38, !tbaa !24
  %t669 = add i64 %t667, 1
  store i64 %t669, ptr %l38, !tbaa !24
  br label %bb104
bb128:
  %t671 = load i64, ptr %l16, !tbaa !24
  %t673 = icmp sgt i64 %t671, 0
  br i1 %t673, label %bb129, label %bb130
bb129:
  %t675 = load i32, ptr %l15, !tbaa !23
  %t677 = icmp eq i32 %t675, 0
  store i1 %t677, ptr %l300, !tbaa !21
  br label %bb131
bb130:
  store i1 false, ptr %l300, !tbaa !21
  br label %bb131
bb131:
  %t679 = load i1, ptr %l300, !tbaa !21
  br i1 %t679, label %bb132, label %bb133
bb132:
  store %olang.scope zeroinitializer, ptr %s39
  %t680 = load i64, ptr %l16, !tbaa !24
  %t682 = icmp eq i64 %t680, 1
  br i1 %t682, label %bb134, label %bb135
bb133:
  br label %bb138
bb134:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l305, !tbaa !27
  br label %bb136
bb135:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l305, !tbaa !27
  br label %bb136
bb136:
  %t684 = load { i64, ptr }, ptr %l305, !tbaa !27
  %t685 = load i64, ptr %l16, !tbaa !24
  %t687 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t688 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t690 = call i64 @__olang_fmt_i64(ptr null, i64 %t685)
  %t691 = add i64 %t688, %t690
  %t692 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t693 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t694 = add i64 %t691, %t693
  %t696 = extractvalue { i64, ptr } %t684, 1
  %t697 = extractvalue { i64, ptr } %t684, 0
  %t698 = add i64 %t694, %t697
  %t699 = extractvalue { i64, ptr } { i64 89, ptr getelementptr inbounds (<{ i64, [89 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t700 = extractvalue { i64, ptr } { i64 89, ptr getelementptr inbounds (<{ i64, [89 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t701 = add i64 %t698, %t700
  %t702 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t701)
  call void @olang_textcopy(ptr %t702, ptr %t687, i64 %t688)
  %t703 = getelementptr i8, ptr %t702, i64 %t688
  %t704 = call i64 @__olang_fmt_i64(ptr %t703, i64 %t685)
  %t705 = getelementptr i8, ptr %t703, i64 %t690
  call void @olang_textcopy(ptr %t705, ptr %t692, i64 %t693)
  %t706 = getelementptr i8, ptr %t705, i64 %t693
  call void @olang_textcopy(ptr %t706, ptr %t696, i64 %t697)
  %t707 = getelementptr i8, ptr %t706, i64 %t697
  call void @olang_textcopy(ptr %t707, ptr %t699, i64 %t700)
  %t708 = insertvalue { i64, ptr } undef, i64 %t701, 0
  %t709 = insertvalue { i64, ptr } %t708, ptr %t702, 1
  %t712 = extractvalue { i64, ptr } %t709, 0
  %t713 = extractvalue { i64, ptr } %t709, 1
  %t714 = mul i64 %t712, 1
  %t715 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t714)
  call void @llvm.memcpy.p0.p0.i64(ptr %t715, ptr %t713, i64 %t714, i1 false)
  %t716 = insertvalue { i64, ptr } undef, i64 %t712, 0
  %t717 = insertvalue { i64, ptr } %t716, ptr %t715, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s39, ptr %l4, { i64, ptr } %t717)
  br label %bb137
bb137:
  call void @__olang_scope_close(ptr %s39)
  br label %bb138
bb138:
  %t721 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l5)
  store i32 %t721, ptr %l313
  %t722 = icmp ne i32 %t721, 0
  br i1 %t722, label %bb140, label %ok.723, !prof !99
ok.723:
  br label %bb139
bb139:
  br label %bb142
bb140:
  %t724 = load i32, ptr %l313, !tbaa !23
  %t725 = ashr i32 %t724, 16
  %t727 = icmp eq i32 %t725, 1
  store i1 %t727, ptr %l315, !tbaa !21
  br label %bb141
bb141:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb142:
  %t730 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l4)
  store i32 %t730, ptr %l318
  %t731 = icmp ne i32 %t730, 0
  br i1 %t731, label %bb144, label %ok.732, !prof !99
ok.732:
  br label %bb143
bb143:
  br label %bb146
bb144:
  %t733 = load i32, ptr %l318, !tbaa !23
  %t734 = ashr i32 %t733, 16
  %t736 = icmp eq i32 %t734, 1
  store i1 %t736, ptr %l320, !tbaa !21
  br label %bb145
bb145:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb146:
  %t738 = load i32, ptr %l15, !tbaa !23
  %t740 = icmp ne i32 %t738, 0
  br i1 %t740, label %bb147, label %bb148
bb147:
  %t742 = load i32, ptr %l15, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t742, ptr %rv
  br label %ret
bb148:
  br label %bb149
bb149:
  %t744 = load i1, ptr %l0, !tbaa !21
  br i1 %t744, label %bb150, label %bb151
bb150:
  %t746 = load i64, ptr %l33, !tbaa !24
  %t748 = icmp sgt i64 %t746, 0
  store i1 %t748, ptr %l326, !tbaa !21
  br label %bb152
bb151:
  store i1 false, ptr %l326, !tbaa !21
  br label %bb152
bb152:
  %t750 = load i1, ptr %l326, !tbaa !21
  br i1 %t750, label %bb153, label %bb154
bb153:
  store i1 true, ptr %l329, !tbaa !21
  br label %bb155
bb154:
  %t751 = load i64, ptr %l16, !tbaa !24
  %t753 = icmp sgt i64 %t751, 0
  store i1 %t753, ptr %l329, !tbaa !21
  br label %bb155
bb155:
  %t755 = load i1, ptr %l329, !tbaa !21
  br i1 %t755, label %bb156, label %bb157
bb156:
  store i32 1, ptr %l332, !tbaa !23
  br label %bb158
bb157:
  store i32 0, ptr %l332, !tbaa !23
  br label %bb158
bb158:
  call void @__olang_scope_close(ptr %s0)
  %t756 = load i32, ptr %l332, !tbaa !23
  store i32 %t756, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ffix_2eOrder(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l23 = alloca [24 x { i64, ptr }]
  %l28 = alloca i64
  %l31 = alloca i64
  %l51 = alloca i1
  %l53 = alloca i1
  %l62 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l64 = alloca i64
  %l65 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t4 = insertvalue [2 x { i64, ptr }] %t3, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t6 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store [2 x { i64, ptr }] %t4, ptr %t6
  store ptr %t6, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t8 = load ptr, ptr %l1
  store i64 2, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l2, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  br label %bb25
bb4:
  br label %bb5
bb5:
  %t19 = load ptr, ptr %l1
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = getelementptr [2 x { i64, ptr }], ptr %t19, i64 0, i64 %t20
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !37
  store { i64, ptr } %t24, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l23, ptr @G_2ecompiler_2ffix_2eToolNames, i64 384, i1 false)
  %t26 = load [24 x { i64, ptr }], ptr %l23
  store i64 24, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t28 = load i64, ptr %l6, !tbaa !24
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = icmp sgt i64 %t28, %t29
  br i1 %t32, label %bb6, label %bb7
bb6:
  %t34 = load i64, ptr %l7, !tbaa !24
  %t36 = icmp sgt i64 %t34, 0
  br i1 %t36, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb11
bb8:
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = sub i64 %t38, %t39
  %t43 = load i64, ptr %l7, !tbaa !24
  %t46 = add i64 %t42, %t43
  %t48 = sub i64 %t46, 1
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = sdiv i64 %t48, %t49
  store i64 %t52, ptr %l31, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb10
bb10:
  %t54 = load i64, ptr %l31, !tbaa !24
  store i64 %t54, ptr %l28, !tbaa !24
  br label %bb11
bb11:
  %t55 = load i64, ptr %l28, !tbaa !24
  store i64 %t55, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t56 = load i64, ptr %l9, !tbaa !24
  %t57 = load i64, ptr %l8, !tbaa !24
  %t60 = icmp slt i64 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb14:
  br label %bb15
bb15:
  %t64 = load i64, ptr %l5, !tbaa !24
  %t65 = load i64, ptr %l9, !tbaa !24
  %t66 = load i64, ptr %l7, !tbaa !24
  %t69 = mul i64 %t65, %t66
  %t72 = add i64 %t64, %t69
  store i64 %t72, ptr %l10, !tbaa !24
  %t74 = load i64, ptr %l10, !tbaa !24
  %t76 = getelementptr [24 x i64], ptr @G_2ecompiler_2ffix_2eToolKinds, i64 0, i64 %t74
  %t77 = load i64, ptr %t76, !tbaa !34
  %t79 = call i1 @compiler_2ffix_2edriven(i64 %t77)
  store i1 %t79, ptr %l51
  br label %bb16
bb16:
  %t80 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t81 = load ptr, ptr @__olang_prog_scope
  %t83 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t81, ptr %s4, { i64, ptr } %t80, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store i1 %t83, ptr %l53
  br label %bb17
bb17:
  %t84 = load i1, ptr %l51, !tbaa !21
  %t85 = load i1, ptr %l53, !tbaa !21
  %t86 = icmp eq i1 %t84, %t85
  br i1 %t86, label %bb18, label %bb19
bb18:
  %t88 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l0, i64 %t88)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb22:
  %t91 = load i64, ptr %l9, !tbaa !24
  %t93 = add i64 %t91, 1
  store i64 %t93, ptr %l9, !tbaa !24
  br label %bb12
bb23:
  br label %bb24
bb24:
  %t95 = load i64, ptr %l2, !tbaa !24
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l2, !tbaa !24
  br label %bb2
bb25:
  call void @__olang_scope_close(ptr %s1)
  %t100 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %v0, ptr %l0)
  store { i64, ptr } %t100, ptr %l62
  br label %bb26
bb26:
  %t101 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t101, ptr %l63, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 0
  store i64 %t103, ptr %l64, !tbaa !24
  %t104 = load i64, ptr %l64, !tbaa !24
  %t105 = mul i64 %t104, 8
  %t106 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t105)
  %t107 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  store { i64, ptr } %t108, ptr %l65, !tbaa !27
  %t109 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = load i64, ptr %l64, !tbaa !24
  %t114 = mul i64 %t113, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t110, ptr %t112, i64 %t114, i1 false)
  %t115 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t115, ptr %l63, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t116 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t116, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ffix_2eStdTool_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr @G_2ecompiler_2ffix_2eStdTool, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffix_2eTextTool_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr @G_2ecompiler_2ffix_2eTextTool, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffix_2eToolKinds_2einit() #0 {
entry:
  %l0 = alloca [24 x i64]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr [24 x i64], ptr %l0, i64 0, i64 0
  store i64 1, ptr %t1
  %t2 = getelementptr [24 x i64], ptr %l0, i64 0, i64 1
  store i64 2, ptr %t2
  %t3 = getelementptr [24 x i64], ptr %l0, i64 0, i64 2
  store i64 2, ptr %t3
  %t4 = getelementptr [24 x i64], ptr %l0, i64 0, i64 3
  store i64 3, ptr %t4
  %t5 = getelementptr [24 x i64], ptr %l0, i64 0, i64 4
  store i64 0, ptr %t5
  %t6 = getelementptr [24 x i64], ptr %l0, i64 0, i64 5
  store i64 0, ptr %t6
  %t7 = getelementptr [24 x i64], ptr %l0, i64 0, i64 6
  store i64 0, ptr %t7
  %t8 = getelementptr [24 x i64], ptr %l0, i64 0, i64 7
  store i64 0, ptr %t8
  %t9 = getelementptr [24 x i64], ptr %l0, i64 0, i64 8
  store i64 0, ptr %t9
  %t10 = getelementptr [24 x i64], ptr %l0, i64 0, i64 9
  store i64 0, ptr %t10
  %t11 = getelementptr [24 x i64], ptr %l0, i64 0, i64 10
  store i64 0, ptr %t11
  %t12 = getelementptr [24 x i64], ptr %l0, i64 0, i64 11
  store i64 0, ptr %t12
  %t13 = getelementptr [24 x i64], ptr %l0, i64 0, i64 12
  store i64 2, ptr %t13
  %t14 = getelementptr [24 x i64], ptr %l0, i64 0, i64 13
  store i64 0, ptr %t14
  %t15 = getelementptr [24 x i64], ptr %l0, i64 0, i64 14
  store i64 0, ptr %t15
  %t16 = getelementptr [24 x i64], ptr %l0, i64 0, i64 15
  store i64 0, ptr %t16
  %t17 = getelementptr [24 x i64], ptr %l0, i64 0, i64 16
  store i64 0, ptr %t17
  %t18 = getelementptr [24 x i64], ptr %l0, i64 0, i64 17
  store i64 0, ptr %t18
  %t19 = getelementptr [24 x i64], ptr %l0, i64 0, i64 18
  store i64 2, ptr %t19
  %t20 = getelementptr [24 x i64], ptr %l0, i64 0, i64 19
  store i64 0, ptr %t20
  %t21 = getelementptr [24 x i64], ptr %l0, i64 0, i64 20
  store i64 0, ptr %t21
  %t22 = getelementptr [24 x i64], ptr %l0, i64 0, i64 21
  store i64 0, ptr %t22
  %t23 = getelementptr [24 x i64], ptr %l0, i64 0, i64 22
  store i64 0, ptr %t23
  %t24 = getelementptr [24 x i64], ptr %l0, i64 0, i64 23
  store i64 2, ptr %t24
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2ffix_2eToolKinds, ptr %l0, i64 192, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffix_2eToolNames_2einit() #0 {
entry:
  %l0 = alloca [24 x { i64, ptr }]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr [24 x { i64, ptr }], ptr %l0, i64 0, i64 0
  store { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d30, i32 0, i32 1) }, ptr %t1
  %t2 = getelementptr [24 x { i64, ptr }], ptr %l0, i64 0, i64 1
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %t2
  %t3 = getelementptr [24 x { i64, ptr }], ptr %l0, i64 0, i64 2
  store { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d32, i32 0, i32 1) }, ptr %t3
  %t4 = getelementptr [24 x { i64, ptr }], ptr %l0, i64 0, i64 3
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d33, i32 0, i32 1) }, ptr %t4
  %t5 = getelementptr [24 x { i64, ptr }], ptr %l0, i64 0, i64 4
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d34, i32 0, i32 1) }, ptr %t5
  %t6 = getelementptr [24 x { i64, ptr }], ptr %l0, i64 0, i64 5
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d35, i32 0, i32 1) }, ptr %t6
  %t7 = getelementptr [24 x { i64, ptr }], ptr %l0, i64 0, i64 6
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d36, i32 0, i32 1) }, ptr %t7
  %t8 = getelementptr [24 x { i64, ptr }], ptr %l0, i64 0, i64 7
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d37, i32 0, i32 1) }, ptr %t8
  %t9 = getelementptr [24 x { i64, ptr }], ptr %l0, i64 0, i64 8
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %t9
  %t10 = getelementptr [24 x { i64, ptr }], ptr %l0, i64 0, i64 9
  store { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d39, i32 0, i32 1) }, ptr %t10
  %t11 = getelementptr [24 x { i64, ptr }], ptr %l0, i64 0, i64 10
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %t11
  %t12 = getelementptr [24 x { i64, ptr }], ptr %l0, i64 0, i64 11
  store { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d41, i32 0, i32 1) }, ptr %t12
  %t13 = getelementptr [24 x { i64, ptr }], ptr %l0, i64 0, i64 12
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d42, i32 0, i32 1) }, ptr %t13
  %t14 = getelementptr [24 x { i64, ptr }], ptr %l0, i64 0, i64 13
  store { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d43, i32 0, i32 1) }, ptr %t14
  %t15 = getelementptr [24 x { i64, ptr }], ptr %l0, i64 0, i64 14
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d44, i32 0, i32 1) }, ptr %t15
  %t16 = getelementptr [24 x { i64, ptr }], ptr %l0, i64 0, i64 15
  store { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d45, i32 0, i32 1) }, ptr %t16
  %t17 = getelementptr [24 x { i64, ptr }], ptr %l0, i64 0, i64 16
  store { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d46, i32 0, i32 1) }, ptr %t17
  %t18 = getelementptr [24 x { i64, ptr }], ptr %l0, i64 0, i64 17
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d47, i32 0, i32 1) }, ptr %t18
  %t19 = getelementptr [24 x { i64, ptr }], ptr %l0, i64 0, i64 18
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %t19
  %t20 = getelementptr [24 x { i64, ptr }], ptr %l0, i64 0, i64 19
  store { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d49, i32 0, i32 1) }, ptr %t20
  %t21 = getelementptr [24 x { i64, ptr }], ptr %l0, i64 0, i64 20
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d50, i32 0, i32 1) }, ptr %t21
  %t22 = getelementptr [24 x { i64, ptr }], ptr %l0, i64 0, i64 21
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d51, i32 0, i32 1) }, ptr %t22
  %t23 = getelementptr [24 x { i64, ptr }], ptr %l0, i64 0, i64 22
  store { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d52, i32 0, i32 1) }, ptr %t23
  %t24 = getelementptr [24 x { i64, ptr }], ptr %l0, i64 0, i64 23
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d53, i32 0, i32 1) }, ptr %t24
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2ffix_2eToolNames, ptr %l0, i64 384, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ffix_2eToolsDir(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l9 = alloca i1
  %l14 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d54, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l4
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  store { i64, ptr } %t2, ptr %l3
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %l5, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t10 = extractvalue { i64, ptr } %t7, 1
  %t11 = mul i64 %t9, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t10, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  br label %bb4
bb4:
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t16, ptr %l1, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t17, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d56, i32 0, i32 1) })
  store i1 %t19, ptr %l9
  br label %bb5
bb5:
  %t20 = load i1, ptr %l9, !tbaa !21
  %t21 = xor i1 %t20, true
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = extractvalue { i64, ptr } %t23, 0
  %t27 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t25, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t29, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t33 = call { i64, ptr } @std_2ffilepath_2eDir(ptr %v0, { i64, ptr } %a0)
  store { i64, ptr } %t33, ptr %l14
  br label %bb9
bb9:
  %t34 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 1
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t37 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d57, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d57, i32 0, i32 1) }, 0
  %t39 = add i64 %t36, %t38
  %t40 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t39)
  call void @olang_textcopy(ptr %t40, ptr %t35, i64 %t36)
  %t41 = getelementptr i8, ptr %t40, i64 %t36
  call void @olang_textcopy(ptr %t41, ptr %t37, i64 %t38)
  %t42 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t40, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t43, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ffix_2earguments(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %lp5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l45 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 8, i64 8)
  store ptr %t2, ptr %lp5
  %t3 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  %t4 = load ptr, ptr %lp5
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  %t5 = load ptr, ptr %lp5
  %t8 = extractvalue { i64, ptr } %a0, 1
  %t9 = extractvalue { i64, ptr } %a0, 0
  %t10 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t9)
  call void @olang_textcopy(ptr %t10, ptr %t8, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t15 = extractvalue { i64, ptr } %t12, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t5, { i64, ptr } %t19)
  br label %bb2
bb2:
  %t22 = load i64, ptr %l1, !tbaa !24
  %t23 = load i64, ptr @G_2ecompiler_2ffix_2eStdTool, !tbaa !24
  %t26 = icmp eq i64 %t22, %t23
  br i1 %t26, label %bb3, label %bb4
bb3:
  %t28 = load ptr, ptr %lp5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t28, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d58, i32 0, i32 1) })
  br label %bb5
bb4:
  %t30 = load i64, ptr %l1, !tbaa !24
  %t31 = load i64, ptr @G_2ecompiler_2ffix_2eDrivenOpt, !tbaa !24
  %t34 = icmp eq i64 %t30, %t31
  br i1 %t34, label %bb7, label %bb8
bb5:
  %t36 = load ptr, ptr %lp5
  %t39 = extractvalue { i64, ptr } %a3, 1
  %t40 = extractvalue { i64, ptr } %a3, 0
  %t41 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t40)
  call void @olang_textcopy(ptr %t41, ptr %t39, i64 %t40)
  %t42 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t46 = extractvalue { i64, ptr } %t43, 1
  %t47 = mul i64 %t45, 1
  %t48 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t47)
  call void @llvm.memcpy.p0.p0.i64(ptr %t48, ptr %t46, i64 %t47, i1 false)
  %t49 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t36, { i64, ptr } %t50)
  br label %bb6
bb6:
  br label %bb16
bb7:
  %t53 = load ptr, ptr %lp5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t53, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d59, i32 0, i32 1) })
  br label %bb9
bb8:
  %t55 = load i64, ptr %l1, !tbaa !24
  %t56 = load i64, ptr @G_2ecompiler_2ffix_2eDrivenArg, !tbaa !24
  %t59 = icmp eq i64 %t55, %t56
  br i1 %t59, label %bb11, label %bb12
bb9:
  %t61 = load ptr, ptr %lp5
  %t62 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t62, 1
  %t65 = extractvalue { i64, ptr } %t62, 0
  %t66 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t65)
  call void @olang_textcopy(ptr %t66, ptr %t64, i64 %t65)
  %t67 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t71 = extractvalue { i64, ptr } %t68, 1
  %t72 = mul i64 %t70, 1
  %t73 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t72)
  call void @llvm.memcpy.p0.p0.i64(ptr %t73, ptr %t71, i64 %t72, i1 false)
  %t74 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t61, { i64, ptr } %t75)
  br label %bb10
bb10:
  br label %bb15
bb11:
  %t78 = load ptr, ptr %lp5
  %t79 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t79, 1
  %t82 = extractvalue { i64, ptr } %t79, 0
  %t83 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t82)
  call void @olang_textcopy(ptr %t83, ptr %t81, i64 %t82)
  %t84 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t83, 1
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t88 = extractvalue { i64, ptr } %t85, 1
  %t89 = mul i64 %t87, 1
  %t90 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t89)
  call void @llvm.memcpy.p0.p0.i64(ptr %t90, ptr %t88, i64 %t89, i1 false)
  %t91 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t90, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t78, { i64, ptr } %t92)
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  store { i64, ptr } %a4, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t97 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  store i64 %t99, ptr %l8, !tbaa !24
  br label %bb17
bb17:
  %t101 = load i64, ptr %l7, !tbaa !24
  %t102 = load i64, ptr %l8, !tbaa !24
  %t105 = icmp slt i64 %t101, %t102
  %t107 = xor i1 %t105, true
  br i1 %t107, label %bb18, label %bb19
bb18:
  br label %bb23
bb19:
  br label %bb20
bb20:
  %t109 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t109, ptr %l45, !tbaa !27
  %t110 = load i64, ptr %l7, !tbaa !24
  %t112 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr { i64, ptr }, ptr %t113, i64 %t110
  %t115 = load { i64, ptr }, ptr %t114, !tbaa !37
  %t117 = load ptr, ptr %lp5
  %t120 = extractvalue { i64, ptr } %t115, 1
  %t121 = extractvalue { i64, ptr } %t115, 0
  %t122 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t121)
  call void @olang_textcopy(ptr %t122, ptr %t120, i64 %t121)
  %t123 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  %t126 = extractvalue { i64, ptr } %t124, 0
  %t127 = extractvalue { i64, ptr } %t124, 1
  %t128 = mul i64 %t126, 1
  %t129 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t128)
  call void @llvm.memcpy.p0.p0.i64(ptr %t129, ptr %t127, i64 %t128, i1 false)
  %t130 = insertvalue { i64, ptr } undef, i64 %t126, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t129, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t117, { i64, ptr } %t131)
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t134 = load i64, ptr %l7, !tbaa !24
  %t136 = add i64 %t134, 1
  store i64 %t136, ptr %l7, !tbaa !24
  br label %bb17
bb23:
  %t138 = load ptr, ptr %lp5
  %t140 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v4, ptr %v4, ptr %t138)
  store { i64, ptr } %t140, ptr %l55
  br label %bb24
bb24:
  %t141 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t141, ptr %l56, !tbaa !27
  %t142 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t142, 0
  store i64 %t143, ptr %l57, !tbaa !24
  %t144 = load i64, ptr %l57, !tbaa !24
  %t145 = mul i64 %t144, 16
  %t146 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t145)
  %t147 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  store { i64, ptr } %t148, ptr %l58, !tbaa !27
  %t149 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = load i64, ptr %l57, !tbaa !24
  %t154 = mul i64 %t153, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t150, ptr %t152, i64 %t154, i1 false)
  %t155 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t155, ptr %l56, !tbaa !27
  %t156 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t156, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ffix_2ebuiltBy(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/os:FileInfo"
  %l2 = alloca %"std/os:FileInfo"
  %l4 = alloca %"std/os:FileInfo"
  %l5 = alloca i32
  %l7 = alloca i1
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v0, { i64, ptr } %t1)
  %t4 = extractvalue { i32, %"std/os:FileInfo" } %t3, 1
  %t5 = extractvalue { i32, %"std/os:FileInfo" } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store %"std/os:FileInfo" %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load %"std/os:FileInfo", ptr %l4
  store %"std/os:FileInfo" %t8, ptr %l2
  br label %bb4
bb2:
  %t9 = load i32, ptr %l5, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  store i1 %t12, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = extractvalue { i64, ptr } %t13, 0
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t15, i64 %t16)
  %t18 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %rv
  br label %ret
bb4:
  %t21 = load %"std/os:FileInfo", ptr %l2
  store %"std/os:FileInfo" %t21, ptr %l1
  %t22 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t23 = getelementptr %"std/os:FileInfo", ptr %l1, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t25 = getelementptr %"std/os:FileInfo", ptr %l1, i32 0, i32 2
  %t26 = load i64, ptr %t25, !tbaa !24
  %t28 = extractvalue { i64, ptr } %t22, 1
  %t29 = extractvalue { i64, ptr } %t22, 0
  %t30 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t32 = add i64 %t29, %t31
  %t34 = call i64 @__olang_fmt_i64(ptr null, i64 %t24)
  %t35 = add i64 %t32, %t34
  %t36 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t37 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t38 = add i64 %t35, %t37
  %t40 = call i64 @__olang_fmt_i64(ptr null, i64 %t26)
  %t41 = add i64 %t38, %t40
  %t42 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t43 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  %t44 = add i64 %t41, %t43
  %t45 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t44)
  call void @olang_textcopy(ptr %t45, ptr %t28, i64 %t29)
  %t46 = getelementptr i8, ptr %t45, i64 %t29
  call void @olang_textcopy(ptr %t46, ptr %t30, i64 %t31)
  %t47 = getelementptr i8, ptr %t46, i64 %t31
  %t48 = call i64 @__olang_fmt_i64(ptr %t47, i64 %t24)
  %t49 = getelementptr i8, ptr %t47, i64 %t34
  call void @olang_textcopy(ptr %t49, ptr %t36, i64 %t37)
  %t50 = getelementptr i8, ptr %t49, i64 %t37
  %t51 = call i64 @__olang_fmt_i64(ptr %t50, i64 %t26)
  %t52 = getelementptr i8, ptr %t50, i64 %t40
  call void @olang_textcopy(ptr %t52, ptr %t42, i64 %t43)
  %t53 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t45, 1
  store { i64, ptr } %t54, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ffix_2ebyHand(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca %"std/prelude/text:LineIter"
  %l4 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/text:LineIter"
  %l7 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l12 = alloca i1
  %l14 = alloca i1
  %l18 = alloca i1
  %l20 = alloca i1
  %l22 = alloca i1
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  store i1 false, ptr %l2, !tbaa !21
  %t3 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store %"std/prelude/text:LineIter" %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load %"std/prelude/text:LineIter", ptr %l6
  store %"std/prelude/text:LineIter" %t4, ptr %l3
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t6 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %l3)
  %t7 = extractvalue { i32, { i64, ptr } } %t6, 1
  %t8 = extractvalue { i32, { i64, ptr } } %t6, 0
  store i32 %t8, ptr %l10
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb4, label %ok.10, !prof !99
ok.10:
  store { i64, ptr } %t7, ptr %l9
  br label %bb3
bb3:
  %t11 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t11, ptr %l7, !tbaa !27
  br label %bb6
bb4:
  %t12 = load i32, ptr %l10, !tbaa !23
  %t13 = ashr i32 %t12, 16
  %t15 = icmp eq i32 %t13, 1
  store i1 %t15, ptr %l12, !tbaa !21
  br label %bb5
bb5:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb6:
  %t16 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t16, ptr %l4, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t17, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d62, i32 0, i32 1) })
  store i1 %t19, ptr %l14
  br label %bb7
bb7:
  %t20 = load i1, ptr %l14, !tbaa !21
  br i1 %t20, label %bb8, label %bb9
bb8:
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = add i64 %t21, 1
  store i64 %t23, ptr %l1, !tbaa !24
  br label %bb21
bb9:
  store %olang.scope zeroinitializer, ptr %s4
  %t25 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t25, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d63, i32 0, i32 1) })
  store i1 %t27, ptr %l18
  br label %bb10
bb10:
  %t28 = load i1, ptr %l18, !tbaa !21
  br i1 %t28, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb20
bb12:
  store %olang.scope zeroinitializer, ptr %s6
  %t29 = load i1, ptr %l2, !tbaa !21
  br i1 %t29, label %bb13, label %bb14
bb13:
  %t31 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t33 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s6, { i64, ptr } %t31, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d64, i32 0, i32 1) })
  store i1 %t33, ptr %l22
  br label %bb15
bb14:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb16
bb15:
  %t34 = load i1, ptr %l22, !tbaa !21
  store i1 %t34, ptr %l20, !tbaa !21
  br label %bb16
bb16:
  %t35 = load i1, ptr %l20, !tbaa !21
  br i1 %t35, label %bb17, label %bb18
bb17:
  %t36 = load i64, ptr %l1, !tbaa !24
  %t38 = add i64 %t36, 1
  store i64 %t38, ptr %l1, !tbaa !24
  br label %bb19
bb18:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s6)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  br label %bb2
bb23:
  %t40 = load i64, ptr %l1, !tbaa !24
  store i64 %t40, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffix_2edriven(i64 %a0) #0 {
entry:
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i64, ptr @G_2ecompiler_2ffix_2eDrivenOpt, !tbaa !24
  %t5 = icmp sge i64 %a0, %t2
  store i1 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffix_2eensureBuilt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, ptr %a5) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"std/os:Output"
  %l16 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i32
  %l23 = alloca { i64, ptr }
  %l27 = alloca i64
  %l29 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l34 = alloca i64
  %l36 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l46 = alloca i1
  %l47 = alloca i1
  %l49 = alloca i64
  %l54 = alloca i32
  %l56 = alloca i1
  %l57 = alloca %"std/os:Output"
  %l58 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l69 = alloca %"std/os:Output"
  %l70 = alloca i32
  %l72 = alloca i1
  %l89 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l94 = alloca i32
  %l96 = alloca i1
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t3 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %t2, 1
  %t7 = extractvalue { i64, ptr } %t2, 0
  %t8 = add i64 %t4, %t7
  %t9 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t8)
  call void @olang_textcopy(ptr %t9, ptr %t3, i64 %t4)
  %t10 = getelementptr i8, ptr %t9, i64 %t4
  call void @olang_textcopy(ptr %t10, ptr %t6, i64 %t7)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t9, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t15 = extractvalue { i64, ptr } %t12, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  %t22 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %v2, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t1, { i64, ptr } %t19, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d2, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d3, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store { i64, ptr } %t22, ptr %l16
  br label %bb1
bb1:
  %t23 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t23, ptr %l6, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 1
  %t27 = extractvalue { i64, ptr } %t24, 0
  %t28 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t29 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t30 = add i64 %t27, %t29
  %t31 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t30)
  call void @olang_textcopy(ptr %t31, ptr %t26, i64 %t27)
  %t32 = getelementptr i8, ptr %t31, i64 %t27
  call void @olang_textcopy(ptr %t32, ptr %t28, i64 %t29)
  %t33 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t31, 1
  store { i64, ptr } %t34, ptr %l7, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t38 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } %t36)
  %t39 = extractvalue { i32, { i64, ptr } } %t38, 1
  %t40 = extractvalue { i32, { i64, ptr } } %t38, 0
  store i32 %t40, ptr %l22
  %t41 = icmp ne i32 %t40, 0
  br i1 %t41, label %bb3, label %ok.42, !prof !99
ok.42:
  store { i64, ptr } %t39, ptr %l21
  br label %bb2
bb2:
  %t43 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t43, ptr %l19, !tbaa !27
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d67, i32 0, i32 1) }, ptr %l23, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t47 = extractvalue { i64, ptr } %t44, 1
  %t48 = mul i64 %t46, 1
  %t49 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t48)
  call void @llvm.memcpy.p0.p0.i64(ptr %t49, ptr %t47, i64 %t48, i1 false)
  %t50 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  store { i64, ptr } %t51, ptr %l19, !tbaa !27
  br label %bb5
bb5:
  %t53 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t53, ptr %l8, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t56 = call i64 @compiler_2ffix_2enewest(ptr %v4, { i64, ptr } %t54)
  store i64 %t56, ptr %l27
  br label %bb6
bb6:
  %t57 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t59 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %v4, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t57, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d68, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d2, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d3, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store { i64, ptr } %t59, ptr %l29
  br label %bb7
bb7:
  %t60 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t60, 0
  %t62 = extractvalue { i64, ptr } %t60, 1
  %t63 = mul i64 %t61, 1
  %t64 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t63)
  call void @llvm.memcpy.p0.p0.i64(ptr %t64, ptr %t62, i64 %t63, i1 false)
  %t65 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t64, 1
  %t68 = call i64 @compiler_2ffix_2enewest(ptr %s0, { i64, ptr } %t66)
  store i64 %t68, ptr %l31
  br label %bb8
bb8:
  %t69 = load i64, ptr %l27, !tbaa !24
  %t70 = load i64, ptr %l31, !tbaa !24
  %t71 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t69, i64 %t70)
  store i64 %t71, ptr %l32
  br label %bb9
bb9:
  %t72 = load i64, ptr %l32, !tbaa !24
  store i64 %t72, ptr %l9, !tbaa !24
  %t73 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t75 = call i64 @compiler_2ffix_2enewest(ptr %v1, { i64, ptr } %t73)
  store i64 %t75, ptr %l34
  br label %bb10
bb10:
  %t76 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t78 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %v1, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t76, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d69, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d2, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d3, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store { i64, ptr } %t78, ptr %l36
  br label %bb11
bb11:
  %t79 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 0
  %t81 = extractvalue { i64, ptr } %t79, 1
  %t82 = mul i64 %t80, 1
  %t83 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t82)
  call void @llvm.memcpy.p0.p0.i64(ptr %t83, ptr %t81, i64 %t82, i1 false)
  %t84 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t83, 1
  %t87 = call i64 @compiler_2ffix_2enewest(ptr %s0, { i64, ptr } %t85)
  store i64 %t87, ptr %l38
  br label %bb12
bb12:
  %t88 = load i64, ptr %l34, !tbaa !24
  %t89 = load i64, ptr %l38, !tbaa !24
  %t90 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t88, i64 %t89)
  store i64 %t90, ptr %l39
  br label %bb13
bb13:
  %t91 = load i64, ptr %l9, !tbaa !24
  %t92 = load i64, ptr %l39, !tbaa !24
  %t94 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t92, i64 %t91)
  store i64 %t94, ptr %l41
  br label %bb14
bb14:
  %t95 = load i64, ptr %l41, !tbaa !24
  store i64 %t95, ptr %l10, !tbaa !24
  %t96 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t96, ptr %l42, !tbaa !27
  %t97 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t99 = call { i64, ptr } @compiler_2ffix_2ebuiltBy(ptr %v0, ptr %s0, { i64, ptr } %t97)
  store { i64, ptr } %t99, ptr %l44
  br label %bb15
bb15:
  %t100 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t102 = extractvalue { i64, ptr } %t100, 1
  %t103 = mul i64 %t101, 1
  %t104 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t103)
  call void @llvm.memcpy.p0.p0.i64(ptr %t104, ptr %t102, i64 %t103, i1 false)
  %t105 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  %t107 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t109 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t107, { i64, ptr } %t106)
  store i1 %t109, ptr %l46
  br label %bb16
bb16:
  %t110 = load i1, ptr %l46, !tbaa !21
  br i1 %t110, label %bb17, label %bb18
bb17:
  %t111 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t113 = call i64 @compiler_2ffix_2emtime(ptr %s0, { i64, ptr } %t111)
  store i64 %t113, ptr %l49
  br label %bb19
bb18:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb20
bb19:
  %t114 = load i64, ptr %l10, !tbaa !24
  %t115 = load i64, ptr %l49, !tbaa !24
  %t117 = icmp sgt i64 %t115, %t114
  store i1 %t117, ptr %l47, !tbaa !21
  br label %bb20
bb20:
  %t119 = load i1, ptr %l47, !tbaa !21
  br i1 %t119, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t121 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t123 = call i32 @std_2fos_2eRemove(ptr %s0, { i64, ptr } %t121)
  store i32 %t123, ptr %l54
  %t124 = icmp ne i32 %t123, 0
  br i1 %t124, label %bb25, label %ok.125, !prof !99
ok.125:
  br label %bb24
bb24:
  br label %bb27
bb25:
  %t126 = load i32, ptr %l54, !tbaa !23
  %t127 = ashr i32 %t126, 16
  %t129 = icmp eq i32 %t127, 1
  store i1 %t129, ptr %l56, !tbaa !21
  br label %bb26
bb26:
  call void @__olang_ert_req_clear()
  br label %bb27
bb27:
  %t130 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t130, ptr %l58, !tbaa !27
  %t131 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t131, ptr %l59, !tbaa !27
  %t132 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t133, 1
  %t136 = extractvalue { i64, ptr } %t133, 0
  %t137 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t138 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t139 = add i64 %t136, %t138
  %t140 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t139)
  call void @olang_textcopy(ptr %t140, ptr %t135, i64 %t136)
  %t141 = getelementptr i8, ptr %t140, i64 %t136
  call void @olang_textcopy(ptr %t141, ptr %t137, i64 %t138)
  %t142 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t140, 1
  %t145 = extractvalue { i64, ptr } %t143, 0
  %t146 = extractvalue { i64, ptr } %t143, 1
  %t147 = mul i64 %t145, 1
  %t148 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t147)
  call void @llvm.memcpy.p0.p0.i64(ptr %t148, ptr %t146, i64 %t147, i1 false)
  %t149 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t148, 1
  %t153 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %v1, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t132, { i64, ptr } %t150, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d2, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d3, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store { i64, ptr } %t153, ptr %l64
  br label %bb28
bb28:
  %t154 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t154, 0
  %t156 = extractvalue { i64, ptr } %t154, 1
  %t157 = mul i64 %t155, 1
  %t158 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t157)
  call void @llvm.memcpy.p0.p0.i64(ptr %t158, ptr %t156, i64 %t157, i1 false)
  %t159 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t158, 1
  %t161 = mul i64 5, 16
  %t162 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t161)
  %t163 = insertvalue { i64, ptr } undef, i64 5, 0
  %t164 = insertvalue { i64, ptr } %t163, ptr %t162, 1
  store { i64, ptr } %t164, ptr %l66, !tbaa !27
  %t165 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t166 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr { i64, ptr }, ptr %t167, i64 0
  store { i64, ptr } %t165, ptr %t168, !tbaa !37
  %t169 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !27
  %t171 = getelementptr { i64, ptr }, ptr %t170, i64 1
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d71, i32 0, i32 1) }, ptr %t171, !tbaa !37
  %t172 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = getelementptr { i64, ptr }, ptr %t173, i64 2
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d72, i32 0, i32 1) }, ptr %t174, !tbaa !37
  %t175 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t176 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr { i64, ptr }, ptr %t177, i64 3
  store { i64, ptr } %t175, ptr %t178, !tbaa !37
  %t180 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !27
  %t182 = getelementptr { i64, ptr }, ptr %t181, i64 4
  store { i64, ptr } %t160, ptr %t182, !tbaa !37
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d73, i32 0, i32 1) }, ptr %l67, !tbaa !27
  %t183 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t184 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t185 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t187 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s0, ptr %s0, ptr %v2, ptr %s0, { i64, ptr } %t184, { i64, ptr } %t185, i1 true, { i64, ptr } %t183)
  %t188 = extractvalue { i32, %"std/os:Output" } %t187, 1
  %t189 = extractvalue { i32, %"std/os:Output" } %t187, 0
  store i32 %t189, ptr %l70
  %t190 = icmp ne i32 %t189, 0
  br i1 %t190, label %bb30, label %ok.191, !prof !99
ok.191:
  store %"std/os:Output" %t188, ptr %l69
  br label %bb29
bb29:
  %t192 = load %"std/os:Output", ptr %l69
  store %"std/os:Output" %t192, ptr %l57
  br label %bb33
bb30:
  %t193 = load i32, ptr %l70, !tbaa !23
  %t194 = ashr i32 %t193, 16
  %t196 = icmp eq i32 %t194, 1
  store i1 %t196, ptr %l72, !tbaa !21
  br label %bb31
bb31:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s6
  %t197 = load ptr, ptr %l5, !tbaa !29
  %t198 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t199 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t200 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t202 = extractvalue { i64, ptr } %t198, 1
  %t203 = extractvalue { i64, ptr } %t198, 0
  %t204 = add i64 %t200, %t203
  %t205 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d75, i32 0, i32 1) }, 1
  %t206 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d75, i32 0, i32 1) }, 0
  %t207 = add i64 %t204, %t206
  %t208 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t207)
  call void @olang_textcopy(ptr %t208, ptr %t199, i64 %t200)
  %t209 = getelementptr i8, ptr %t208, i64 %t200
  call void @olang_textcopy(ptr %t209, ptr %t202, i64 %t203)
  %t210 = getelementptr i8, ptr %t209, i64 %t203
  call void @olang_textcopy(ptr %t210, ptr %t205, i64 %t206)
  %t211 = insertvalue { i64, ptr } undef, i64 %t207, 0
  %t212 = insertvalue { i64, ptr } %t211, ptr %t208, 1
  %t215 = extractvalue { i64, ptr } %t212, 0
  %t216 = extractvalue { i64, ptr } %t212, 1
  %t217 = mul i64 %t215, 1
  %t218 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t217)
  call void @llvm.memcpy.p0.p0.i64(ptr %t218, ptr %t216, i64 %t217, i1 false)
  %t219 = insertvalue { i64, ptr } undef, i64 %t215, 0
  %t220 = insertvalue { i64, ptr } %t219, ptr %t218, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v5, ptr %s6, ptr %t197, { i64, ptr } %t220)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb33:
  %t224 = load %"std/os:Output", ptr %l57
  store %"std/os:Output" %t224, ptr %l11
  %t225 = getelementptr %"std/os:Output", ptr %l11, i32 0, i32 0
  %t226 = load i32, ptr %t225, !tbaa !23
  %t228 = icmp ne i32 %t226, 0
  br i1 %t228, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s8
  %t230 = load ptr, ptr %l5, !tbaa !29
  %t231 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t232 = getelementptr %"std/os:Output", ptr %l11, i32 0, i32 1
  %t233 = load { i64, ptr }, ptr %t232, !tbaa !27
  %t234 = getelementptr %"std/os:Output", ptr %l11, i32 0, i32 2
  %t235 = load { i64, ptr }, ptr %t234, !tbaa !27
  %t236 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d76, i32 0, i32 1) }, 1
  %t237 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d76, i32 0, i32 1) }, 0
  %t239 = extractvalue { i64, ptr } %t231, 1
  %t240 = extractvalue { i64, ptr } %t231, 0
  %t241 = add i64 %t237, %t240
  %t242 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t243 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  %t244 = add i64 %t241, %t243
  %t246 = extractvalue { i64, ptr } %t233, 1
  %t247 = extractvalue { i64, ptr } %t233, 0
  %t248 = add i64 %t244, %t247
  %t250 = extractvalue { i64, ptr } %t235, 1
  %t251 = extractvalue { i64, ptr } %t235, 0
  %t252 = add i64 %t248, %t251
  %t253 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t252)
  call void @olang_textcopy(ptr %t253, ptr %t236, i64 %t237)
  %t254 = getelementptr i8, ptr %t253, i64 %t237
  call void @olang_textcopy(ptr %t254, ptr %t239, i64 %t240)
  %t255 = getelementptr i8, ptr %t254, i64 %t240
  call void @olang_textcopy(ptr %t255, ptr %t242, i64 %t243)
  %t256 = getelementptr i8, ptr %t255, i64 %t243
  call void @olang_textcopy(ptr %t256, ptr %t246, i64 %t247)
  %t257 = getelementptr i8, ptr %t256, i64 %t247
  call void @olang_textcopy(ptr %t257, ptr %t250, i64 %t251)
  %t258 = insertvalue { i64, ptr } undef, i64 %t252, 0
  %t259 = insertvalue { i64, ptr } %t258, ptr %t253, 1
  %t262 = extractvalue { i64, ptr } %t259, 0
  %t263 = extractvalue { i64, ptr } %t259, 1
  %t264 = mul i64 %t262, 1
  %t265 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t264)
  call void @llvm.memcpy.p0.p0.i64(ptr %t265, ptr %t263, i64 %t264, i1 false)
  %t266 = insertvalue { i64, ptr } undef, i64 %t262, 0
  %t267 = insertvalue { i64, ptr } %t266, ptr %t265, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v5, ptr %s8, ptr %t230, { i64, ptr } %t267)
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb37:
  %t271 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t271, ptr %l89, !tbaa !27
  %t272 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t274 = call { i64, ptr } @compiler_2ffix_2ebuiltBy(ptr %v0, ptr %s0, { i64, ptr } %t272)
  store { i64, ptr } %t274, ptr %l91
  br label %bb38
bb38:
  %t275 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t277 = extractvalue { i64, ptr } %t275, 0
  %t278 = extractvalue { i64, ptr } %t275, 1
  %t279 = mul i64 %t277, 1
  %t280 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t279)
  call void @llvm.memcpy.p0.p0.i64(ptr %t280, ptr %t278, i64 %t279, i1 false)
  %t281 = insertvalue { i64, ptr } undef, i64 %t277, 0
  %t282 = insertvalue { i64, ptr } %t281, ptr %t280, 1
  %t283 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t285 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t283, { i64, ptr } %t282)
  store i32 %t285, ptr %l94
  %t286 = icmp ne i32 %t285, 0
  br i1 %t286, label %bb40, label %ok.287, !prof !99
ok.287:
  br label %bb39
bb39:
  br label %bb42
bb40:
  %t288 = load i32, ptr %l94, !tbaa !23
  %t289 = ashr i32 %t288, 16
  %t291 = icmp eq i32 %t289, 1
  store i1 %t291, ptr %l96, !tbaa !21
  br label %bb41
bb41:
  call void @__olang_ert_req_clear()
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffix_2eexpand(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %lp1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca { i64, ptr }
  %l18 = alloca i1
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  br label %bb5
bb5:
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t19, ptr %l14, !tbaa !27
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %t23, i64 %t20
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !37
  store { i64, ptr } %t25, ptr %l5, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t29 = call i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %t27)
  store i1 %t29, ptr %l18
  br label %bb6
bb6:
  %t30 = load i1, ptr %l18, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  %t31 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t32 = load ptr, ptr %lp1
  call void @compiler_2ffix_2ewalk(ptr %v0, ptr %v1, { i64, ptr } %t31, ptr %t32)
  br label %bb9
bb8:
  %t35 = load ptr, ptr %lp1
  %t36 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 1
  %t39 = extractvalue { i64, ptr } %t36, 0
  %t40 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t39)
  call void @olang_textcopy(ptr %t40, ptr %t38, i64 %t39)
  %t41 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t45 = extractvalue { i64, ptr } %t42, 1
  %t46 = mul i64 %t44, 1
  %t47 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t46)
  call void @llvm.memcpy.p0.p0.i64(ptr %t47, ptr %t45, i64 %t46, i1 false)
  %t48 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t35, { i64, ptr } %t49)
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t52 = load i64, ptr %l3, !tbaa !24
  %t54 = add i64 %t52, 1
  store i64 %t54, ptr %l3, !tbaa !24
  br label %bb2
bb13:
  %t56 = load ptr, ptr %lp1
  %t57 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t56
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t57, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i64 @compiler_2ffix_2emtime(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/os:FileInfo"
  %l2 = alloca %"std/os:FileInfo"
  %l4 = alloca %"std/os:FileInfo"
  %l5 = alloca i32
  %l7 = alloca i1
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v0, { i64, ptr } %a0)
  %t4 = extractvalue { i32, %"std/os:FileInfo" } %t3, 1
  %t5 = extractvalue { i32, %"std/os:FileInfo" } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store %"std/os:FileInfo" %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load %"std/os:FileInfo", ptr %l4
  store %"std/os:FileInfo" %t8, ptr %l2
  br label %bb4
bb2:
  %t9 = load i32, ptr %l5, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  store i1 %t12, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %rv
  br label %ret
bb4:
  %t14 = load %"std/os:FileInfo", ptr %l2
  store %"std/os:FileInfo" %t14, ptr %l1
  %t15 = getelementptr %"std/os:FileInfo", ptr %l1, i32 0, i32 2
  %t16 = load i64, ptr %t15, !tbaa !24
  store i64 %t16, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ffix_2enewest(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l21 = alloca { i64, ptr }
  %l25 = alloca i1
  %l26 = alloca i64
  %l29 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %s0, { i64, ptr } %t1)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l10
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l9
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t8, ptr %l7, !tbaa !27
  br label %bb8
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  %t9 = icmp sge i64 0, 0
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t11 = icmp sle i64 0, 576460752303423487
  br i1 %t11, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_8fcf87cfa7be21dd_bbd76dac3520f231)
  unreachable
bb6:
  %t13 = mul i64 0, 16
  %t14 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 0, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l7, !tbaa !27
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_8fcf87cfa7be21dd_bbd76dac3520f231)
  unreachable
bb8:
  %t18 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t18, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l5, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t25 = load i64, ptr %l4, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb11:
  br label %bb12
bb12:
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t33, ptr %l21, !tbaa !27
  %t34 = load i64, ptr %l4, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %t37, i64 %t34
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !37
  store { i64, ptr } %t39, ptr %l6, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t43 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s2, { i64, ptr } %t41, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d78, i32 0, i32 1) })
  store i1 %t43, ptr %l25
  br label %bb13
bb13:
  %t44 = load i1, ptr %l25, !tbaa !21
  br i1 %t44, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t45 = load i64, ptr %l1, !tbaa !24
  store i64 %t45, ptr %l26, !tbaa !24
  %t46 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t50 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %s0, ptr %s3, ptr %s3, ptr %s3, ptr %s3, ptr %s3, { i64, ptr } %t46, { i64, ptr } %t47, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d2, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d3, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store { i64, ptr } %t50, ptr %l29
  br label %bb16
bb15:
  br label %bb19
bb16:
  %t51 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t51, 0
  %t53 = extractvalue { i64, ptr } %t51, 1
  %t54 = mul i64 %t52, 1
  %t55 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t54)
  call void @llvm.memcpy.p0.p0.i64(ptr %t55, ptr %t53, i64 %t54, i1 false)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  %t59 = call i64 @compiler_2ffix_2emtime(ptr %s3, { i64, ptr } %t57)
  store i64 %t59, ptr %l31
  br label %bb17
bb17:
  %t60 = load i64, ptr %l26, !tbaa !24
  %t61 = load i64, ptr %l31, !tbaa !24
  %t62 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t60, i64 %t61)
  store i64 %t62, ptr %l32
  br label %bb18
bb18:
  %t63 = load i64, ptr %l32, !tbaa !24
  store i64 %t63, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  %t64 = load i64, ptr %l4, !tbaa !24
  %t66 = add i64 %t64, 1
  store i64 %t66, ptr %l4, !tbaa !24
  br label %bb9
bb21:
  %t68 = load i64, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t68, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffix_2ewalk(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i32
  %l22 = alloca { i64, ptr }
  %l26 = alloca i1
  %l27 = alloca i1
  %l29 = alloca i1
  %l32 = alloca { i64, ptr }
  %l34 = alloca i1
  %l38 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %s0, { i64, ptr } %t1)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l11
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l10
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t8, ptr %l8, !tbaa !27
  br label %bb8
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  %t9 = icmp sge i64 0, 0
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t11 = icmp sle i64 0, 576460752303423487
  br i1 %t11, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_9433da86f750b978_3ff5b65d50af9d4)
  unreachable
bb6:
  %t13 = mul i64 0, 16
  %t14 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 0, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l8, !tbaa !27
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_9433da86f750b978_3ff5b65d50af9d4)
  unreachable
bb8:
  %t18 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t18, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l5, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t25 = load i64, ptr %l4, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb11:
  br label %bb12
bb12:
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t33, ptr %l22, !tbaa !27
  %t34 = load i64, ptr %l4, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %t37, i64 %t34
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !37
  store { i64, ptr } %t39, ptr %l6, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t43 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s2, { i64, ptr } %t41, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d79, i32 0, i32 1) })
  store i1 %t43, ptr %l26
  br label %bb13
bb13:
  %t44 = load i1, ptr %l26, !tbaa !21
  br i1 %t44, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb17
bb15:
  %t45 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t47 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s2, { i64, ptr } %t45, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d80, i32 0, i32 1) })
  store i1 %t47, ptr %l29
  br label %bb16
bb16:
  %t48 = load i1, ptr %l29, !tbaa !21
  store i1 %t48, ptr %l27, !tbaa !21
  br label %bb17
bb17:
  %t49 = load i1, ptr %l27, !tbaa !21
  br i1 %t49, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb19:
  br label %bb20
bb20:
  %t50 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t54 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %s0, ptr %s2, ptr %s2, ptr %s2, ptr %s2, ptr %s2, { i64, ptr } %t50, { i64, ptr } %t51, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d2, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d3, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store { i64, ptr } %t54, ptr %l32
  br label %bb21
bb21:
  %t55 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t55, ptr %l7, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t58 = call i1 @std_2fos_2eIsDir(ptr %s2, { i64, ptr } %t56)
  store i1 %t58, ptr %l34
  br label %bb22
bb22:
  %t59 = load i1, ptr %l34, !tbaa !21
  br i1 %t59, label %bb23, label %bb24
bb23:
  %t60 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t61 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ffix_2ewalk(ptr %s2, ptr %v1, { i64, ptr } %t60, ptr %t61)
  br label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t64 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t66 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s5, { i64, ptr } %t64, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d81, i32 0, i32 1) })
  store i1 %t66, ptr %l38
  br label %bb26
bb25:
  br label %bb31
bb26:
  %t67 = load i1, ptr %l38, !tbaa !21
  br i1 %t67, label %bb27, label %bb28
bb27:
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t69 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t69, 1
  %t72 = extractvalue { i64, ptr } %t69, 0
  %t73 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t72)
  call void @olang_textcopy(ptr %t73, ptr %t71, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  %t77 = extractvalue { i64, ptr } %t75, 0
  %t78 = extractvalue { i64, ptr } %t75, 1
  %t79 = mul i64 %t77, 1
  %t80 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t79)
  call void @llvm.memcpy.p0.p0.i64(ptr %t80, ptr %t78, i64 %t79, i1 false)
  %t81 = insertvalue { i64, ptr } undef, i64 %t77, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t80, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t68, { i64, ptr } %t82)
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb32:
  %t85 = load i64, ptr %l4, !tbaa !24
  %t87 = add i64 %t85, 1
  store i64 %t87, ptr %l4, !tbaa !24
  br label %bb9
bb33:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @olang_2einit_2ecompiler_2ffix() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2ffix_2eTextTool_2einit()
  br label %bb1
bb1:
  call void @compiler_2ffix_2eStdTool_2einit()
  br label %bb2
bb2:
  call void @compiler_2ffix_2eDrivenOpt_2einit()
  br label %bb3
bb3:
  call void @compiler_2ffix_2eDrivenArg_2einit()
  br label %bb4
bb4:
  call void @compiler_2ffix_2eToolNames_2einit()
  br label %bb5
bb5:
  call void @compiler_2ffix_2eToolKinds_2einit()
  br label %bb6
bb6:
  call void @compiler_2ffix_2eBatch_2einit()
  br label %bb7
bb7:
  br label %ret
ret:
  ret void
}

declare void @__olang_ert_req_clear()
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d0 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fix" }>, align 8
@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d2 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d3 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d4 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.d5 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d6 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c": cannot be read\0A" }>, align 8
@.d7 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"olang: fix: no tools directory at " }>, align 8
@.d8 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c" (OLANG_TOOLS names another)\0A" }>, align 8
@.d9 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"olang: fix: cannot make " }>, align 8
@.d10 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d11 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"tools_" }>, align 8
@.d12 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d13 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d14 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"olang: fix: cannot run " }>, align 8
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d16 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c":\0A" }>, align 8
@.d17 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d18 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d19 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d20 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d21 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c": cannot be written\0A" }>, align 8
@.d22 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d23 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d24 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"olang fix: " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d25 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" place" }>, align 8
@.d26 = private constant <{ i64, [89 x i8] }> <{ i64 0, [89 x i8] c" above may mean something else in the language of today than when written - look at each\0A" }>, align 8
@.d27 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"text" }>, align 8
@.d28 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"driven" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d29 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"driven" }>, align 8
@.d30 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"bare_typevars" }>, align 8
@.d31 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"perm_mut" }>, align 8
@.d32 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"int_literal_i64" }>, align 8
@.d33 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"errors_migrate" }>, align 8
@.d34 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"cli_words" }>, align 8
@.d35 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"donefail_migrate" }>, align 8
@.d36 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"syntax_migrate" }>, align 8
@.d37 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"math_methods" }>, align 8
@.d38 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"arrays_migrate" }>, align 8
@.d39 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"results_migrate" }>, align 8
@.d40 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"equality_migrate" }>, align 8
@.d41 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"helper_rename" }>, align 8
@.d42 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"null_migrate" }>, align 8
@.d43 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"checkerror_rename" }>, align 8
@.d44 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"stutter_rename" }>, align 8
@.d45 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"checked_migrate" }>, align 8
@.d46 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"contracts_migrate" }>, align 8
@.d47 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"try_migrate" }>, align 8
@.d48 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"as_migrate" }>, align 8
@.d49 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"errortype_migrate" }>, align 8
@.d50 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"list_vec" }>, align 8
@.d51 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"link_migrate" }>, align 8
@.d52 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"match_migrate" }>, align 8
@.d53 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"unused_migrate" }>, align 8
@.d54 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"OLANG_TOOLS" }>, align 8
@.d55 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d56 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d57 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"/../tools" }>, align 8
@.d58 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"--std" }>, align 8
@.d59 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"--olang" }>, align 8
@.d60 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d61 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d62 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"by hand:" }>, align 8
@.d63 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"for a person:" }>, align 8
@.d64 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d65 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"tools_" }>, align 8
@.d66 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".from" }>, align 8
@.d67 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d68 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"prelude" }>, align 8
@.d69 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"../compiler" }>, align 8
@.d70 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d71 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"build" }>, align 8
@.d72 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"-output" }>, align 8
@.d73 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d74 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"olang: fix: cannot run " }>, align 8
@.d75 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d76 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"olang: fix: tools/" }>, align 8
@.d77 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c".olang does not build:\0A" }>, align 8
@.d78 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@.d79 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d80 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"build" }>, align 8
@.d81 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2ffetch_2eCacheDir(ptr %v0)
declare { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, { i64, ptr } %a5)
declare { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_74a546a3dd225c9b_f3beb7f3829b0fbf = external constant [0 x i8]
declare %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %v0, i32 %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %v0, ptr %a0)
declare i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
@olang_loc_299e69389bcee8f2_b185402659ea7d46 = external constant [0 x i8]
declare { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2ffilepath_2eDir(ptr %v0, { i64, ptr } %a0)
declare { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v0, { i64, ptr } %a0)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %a0, i64 %a1)
declare i32 @std_2fos_2eRemove(ptr %v0, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_8fcf87cfa7be21dd_bbd76dac3520f231 = external constant [0 x i8]
@olang_loc_9433da86f750b978_3ff5b65d50af9d4 = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
