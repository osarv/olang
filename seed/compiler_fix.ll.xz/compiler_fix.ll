; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
@G_2ecompiler_2ffix_2eBatch = constant <{ [8 x i8] }> <{ [8 x i8] c"\C8\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eBuildWidth = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eCheckWidth = constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eDrivenArg = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eDrivenOpt = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eFixCacheCap = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\08\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eStdTool = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eTextTool = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eToolKeywords = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\74\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolKeywords.k1 }>, align 8
@G_2ecompiler_2ffix_2eToolKeywords.k1 = internal constant <{ [116 x i8] }> <{ [116 x i8] c"\61\6E\79\7C\75\6E\69\71\75\65\7C\69\6D\6D\75\74\7C\70\61\63\6B\65\64\7C\63\6F\6D\6D\75\74\65\73\7C\77\65\61\6B\7C\72\65\74\75\72\6E\73\7C\6E\6F\61\6C\6C\6F\63\7C\6E\6F\62\6C\6F\63\6B\7C\6E\6F\73\70\61\77\6E\7C\6E\6F\72\65\63\75\72\73\65\7C\6E\6F\65\78\74\65\72\6E\7C\70\75\72\65\7C\6B\65\65\70\73\7C\62\6F\72\72\6F\77\73\7C\6E\6F\62\6F\72\72\6F\77" }>, align 64
@G_2ecompiler_2ffix_2eToolKinds = constant <{ [368 x i8] }> <{ [368 x i8] c"\01\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\03\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2ffix_2eToolNames = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k1, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k2, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k3, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k4, [8 x i8] c"\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k5, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k6, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k7, [8 x i8] c"\0C\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k8, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k9, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k10, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k11, [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k12, [8 x i8] c"\0C\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k13, [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k14, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k15, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k16, [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k17, [8 x i8] c"\0B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k18, [8 x i8] c"\0A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k19, [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k20, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k21, [8 x i8] c"\0C\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k22, [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k23, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k24, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k25, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k26, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k27, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k28, [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k29, [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k30, [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k31, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k32, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k33, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k34, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k35, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k36, [8 x i8] c"\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k37, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k38, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k39, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k40, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k41, [8 x i8] c"\0C\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k42, [8 x i8] c"\0C\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k43, [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k44, [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k45, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k46 }>, align 64
@G_2ecompiler_2ffix_2eToolNames.k1 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\62\61\72\65\5F\74\79\70\65\76\61\72\73" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k2 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\70\65\72\6D\5F\6D\75\74" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k3 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\69\6E\74\5F\6C\69\74\65\72\61\6C\5F\69\36\34" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k4 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\65\72\72\6F\72\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k5 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\63\6C\69\5F\77\6F\72\64\73" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k6 = internal constant <{ [16 x i8] }> <{ [16 x i8] c"\64\6F\6E\65\66\61\69\6C\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k7 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\73\79\6E\74\61\78\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k8 = internal constant <{ [12 x i8] }> <{ [12 x i8] c"\6D\61\74\68\5F\6D\65\74\68\6F\64\73" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k9 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\61\72\72\61\79\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k10 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\72\65\73\75\6C\74\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k11 = internal constant <{ [16 x i8] }> <{ [16 x i8] c"\65\71\75\61\6C\69\74\79\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k12 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\68\65\6C\70\65\72\5F\72\65\6E\61\6D\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k13 = internal constant <{ [12 x i8] }> <{ [12 x i8] c"\6E\75\6C\6C\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k14 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\63\68\65\63\6B\65\72\72\6F\72\5F\72\65\6E\61\6D\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k15 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\73\74\75\74\74\65\72\5F\72\65\6E\61\6D\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k16 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\63\68\65\63\6B\65\64\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k17 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\63\6F\6E\74\72\61\63\74\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k18 = internal constant <{ [11 x i8] }> <{ [11 x i8] c"\74\72\79\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k19 = internal constant <{ [10 x i8] }> <{ [10 x i8] c"\61\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k20 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\65\72\72\6F\72\74\79\70\65\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k21 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\6C\69\73\74\5F\76\65\63" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k22 = internal constant <{ [12 x i8] }> <{ [12 x i8] c"\6C\69\6E\6B\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k23 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\6D\61\74\63\68\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k24 = internal constant <{ [16 x i8] }> <{ [16 x i8] c"\71\75\65\73\74\69\6F\6E\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k25 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\75\6E\75\73\65\64\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k26 = internal constant <{ [16 x i8] }> <{ [16 x i8] c"\65\72\72\6F\72\63\61\73\65\5F\72\65\6E\61\6D\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k27 = internal constant <{ [16 x i8] }> <{ [16 x i8] c"\76\61\72\69\61\64\69\63\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k28 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\73\63\6F\70\65\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k29 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\66\6E\72\65\66\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k30 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\63\6C\6F\6E\65\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k31 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\74\65\78\74\62\75\69\6C\64\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k32 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\75\6E\69\71\75\65\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k33 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\62\75\69\6C\64\65\72\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k34 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\6C\69\74\65\72\61\6C\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k35 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\6B\65\79\77\6F\72\64\5F\72\65\6E\61\6D\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k36 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\64\65\73\74\72\6F\79\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k37 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\69\6F\5F\72\65\6E\61\6D\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k38 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\6F\6E\65\6C\69\6E\65\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k39 = internal constant <{ [16 x i8] }> <{ [16 x i8] c"\74\65\78\74\6A\6F\69\6E\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k40 = internal constant <{ [16 x i8] }> <{ [16 x i8] c"\72\65\71\75\69\72\65\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k41 = internal constant <{ [16 x i8] }> <{ [16 x i8] c"\63\68\61\6E\69\6E\69\74\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k42 = internal constant <{ [12 x i8] }> <{ [12 x i8] c"\66\69\6C\65\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k43 = internal constant <{ [12 x i8] }> <{ [12 x i8] c"\70\75\74\6C\6E\5F\72\65\6E\61\6D\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k44 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\64\65\66\65\72\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k45 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\61\74\74\72\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k46 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\61\73\73\69\67\6E\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k1, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k2, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k3, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k4, [8 x i8] c"\0B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k5, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k6, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k7, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k8, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k9, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k10, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k11, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k12, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k13, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k14, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k15, [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k16, [8 x i8] c"\01\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k17, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k18, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k19, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k20, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k21, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k22, [8 x i8] c"\0A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k23, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k24, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k25, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k26, [8 x i8] c"\17\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k27, [8 x i8] c"\01\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k28, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k29, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k30, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k31, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k32, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k33, [8 x i8] c"\01\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k34, [8 x i8] c"\74\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolKeywords.k1, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k35, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k36, [8 x i8] c"\01\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k37, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k38, [8 x i8] c"\01\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k39, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k40, [8 x i8] c"\2B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k41, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k42, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k43, [8 x i8] c"\01\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k44, [8 x i8] c"\01\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolTriggers.k45 }>, align 64
@G_2ecompiler_2ffix_2eToolTriggers.k1 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k2 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\6D\75\74" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k3 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k4 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k5 = internal constant <{ [11 x i8] }> <{ [11 x i8] c"\6F\6C\61\6E\67\7C\66\6C\61\67\73" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k6 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\64\6F\6E\65\7C\66\61\69\6C\7C\61\62\6F\72\74" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k7 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k8 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\6D\61\74\68" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k9 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\41\72\72\61\79\3C" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k10 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k11 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\69\73" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k12 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\41\6E\79\7C\41\6C\6C" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k13 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k14 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\42\75\69\6C\74\69\6E" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k15 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\45\72\72\6F\72" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k16 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\63\68\65\63\6B\65\64\7C\43\68\65\63\6B" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k17 = internal constant <{ [1 x i8] }> <{ [1 x i8] c"\5B" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k18 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\74\72\79" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k19 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\61\73" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k20 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\65\72\72\6F\72" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k21 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\4C\69\73\74" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k22 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\6C\69\6E\6B" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k23 = internal constant <{ [10 x i8] }> <{ [10 x i8] c"\6E\6F\6D\61\74\63\68\7C\3D\3E" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k24 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k25 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k26 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k27 = internal constant <{ [23 x i8] }> <{ [23 x i8] c"\45\78\65\63\7C\53\74\61\72\74\7C\68\74\74\70\2E\7C\52\65\63\6F\72\64" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k28 = internal constant <{ [1 x i8] }> <{ [1 x i8] c"\26" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k29 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\66\6E" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k30 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\43\6C\6F\6E\65" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k31 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\53\74\72\69\6E\67" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k32 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\64\65\73\74\72\75\63\74" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k33 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k34 = internal constant <{ [1 x i8] }> <{ [1 x i8] c"\5B" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k35 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\44\65\73\74\72\6F\79" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k36 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\50\72\69\6E\74" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k37 = internal constant <{ [1 x i8] }> <{ [1 x i8] c"\7B" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k38 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\22\7C\24" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k39 = internal constant <{ [1 x i8] }> <{ [1 x i8] c"\5B" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k40 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\49\6E\69\74\28" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k41 = internal constant <{ [43 x i8] }> <{ [43 x i8] c"\4F\70\65\6E\28\7C\43\72\65\61\74\65\28\7C\43\6C\6F\73\65\28\7C\52\65\61\64\65\72\28\7C\57\72\69\74\65\72\28\7C\4C\69\6E\65\73\28" }>, align 32
@G_2ecompiler_2ffix_2eToolTriggers.k42 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\4C\69\6E\65" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k43 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\64\65\66\65\72" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k44 = internal constant <{ [1 x i8] }> <{ [1 x i8] c"\40" }>, align 8
@G_2ecompiler_2ffix_2eToolTriggers.k45 = internal constant <{ [1 x i8] }> <{ [1 x i8] c"\3D" }>, align 8
define dso_local void @compiler_2ffix_2ebuilder(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, { i64, ptr } %a4, { i64, ptr } %a5, { i64, ptr } %a6) #0 {
entry:
  %l3 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i32, { i64, [2 x i64] } }
  %l10 = alloca { i64, ptr }
  %l13 = alloca i64
  %l15 = alloca i64
  %l19 = alloca i64
  %l25 = alloca { i64, ptr }
  %l28 = alloca i32
  %l30 = alloca i1
  %l31 = alloca { i32, { i64, [2 x i64] } }
  %l32 = alloca { i32, { i64, [2 x i64] } }
  %l33 = alloca i32
  %l38 = alloca { i32, { i64, [2 x i64] } }
  %l39 = alloca { i32, { i64, [2 x i64] } }
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca i64
  %s1 = alloca %olang.scope
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  store { i64, ptr } %a5, ptr %l10, !tbaa !27
  %t2 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t3 = load ptr, ptr %t2, !tbaa !27
  %t4 = getelementptr i64, ptr %t3, i64 0
  %t6 = atomicrmw add ptr %t4, i64 1 seq_cst
  store i64 %t6, ptr %l7, !tbaa !24
  %t8 = load i64, ptr %l7, !tbaa !24
  store i64 %t8, ptr %l13, !tbaa !24
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v3, ptr %t9)
  store i64 %t11, ptr %l15
  br label %bb2
bb2:
  %t12 = load i64, ptr %l13, !tbaa !24
  %t13 = load i64, ptr %l15, !tbaa !24
  %t14 = icmp sge i64 %t12, %t13
  br i1 %t14, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb4:
  br label %bb5
bb5:
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t17 = load i64, ptr %l7, !tbaa !24
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v3, ptr %t16, i64 %t17)
  store i64 %t20, ptr %l19
  br label %bb6
bb6:
  %t21 = load i64, ptr %l19, !tbaa !24
  store i64 %t21, ptr %l8, !tbaa !24
  %t25 = load i64, ptr %l8, !tbaa !24
  %t27 = getelementptr [46 x { i64, ptr }], ptr @G_2ecompiler_2ffix_2eToolNames, i64 0, i64 %t25
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !37
  store { i64, ptr } %a4, ptr %l25, !tbaa !27
  %t30 = load i64, ptr %l8, !tbaa !24
  %t32 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr { i64, ptr }, ptr %t33, i64 %t30
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !37
  %t36 = load ptr, ptr @__olang_prog_scope
  %t42 = call i32 @compiler_2ffix_2ebuildTool(ptr %v0, ptr %v1, ptr %v2, ptr %t36, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %t28, { i64, ptr } %t35)
  store i32 %t42, ptr %l28
  %t43 = icmp ne i32 %t42, 0
  br i1 %t43, label %bb8, label %ok.44, !prof !99
ok.44:
  br label %bb7
bb7:
  br label %bb17
bb8:
  %t45 = load i32, ptr %l28, !tbaa !23
  %t46 = ashr i32 %t45, 16
  %t48 = icmp eq i32 %t46, 1
  store i1 %t48, ptr %l30, !tbaa !21
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l9
  %t49 = load i32, ptr %l28, !tbaa !23
  %t50 = lshr i32 %t49, 16
  %t51 = and i32 %t49, 65535
  %t52 = icmp eq i32 %t50, 1
  %t53 = select i1 %t52, i32 1, i32 0
  %t54 = icmp eq i32 %t49, 0
  %t55 = shl i32 %t53, 16
  %t56 = or i32 %t55, %t51
  %t57 = select i1 %t54, i32 0, i32 %t56
  %t58 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l9, i32 0, i32 0
  store i32 %t57, ptr %t58, !tbaa !23
  br label %bb9
bb9:
  %t59 = load { i32, { i64, [2 x i64] } }, ptr %l9
  store { i32, { i64, [2 x i64] } } %t59, ptr %l31
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l32
  %t60 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l31, i32 0, i32 0
  %t61 = load i32, ptr %t60, !tbaa !23
  store i32 %t61, ptr %l33, !tbaa !23
  %t62 = load i32, ptr %l33, !tbaa !23
  %t63 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l32, i32 0, i32 0
  store i32 %t62, ptr %t63, !tbaa !23
  %t64 = load i32, ptr %l33, !tbaa !23
  %t65 = ashr i32 %t64, 16
  %t67 = icmp eq i32 %t65, 1
  br i1 %t67, label %bb10, label %bb11
bb10:
  %t69 = call ptr @__olang_errpay_top_get()
  %t71 = load { i64, [2 x i64] }, ptr %t69
  %t72 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l32, i32 0, i32 1
  store { i64, [2 x i64] } %t71, ptr %t72
  br label %bb11
bb11:
  %t74 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bcompiler_2ffix_3aNotBuilt_7d(ptr %s1, ptr %l32)
  store { i32, { i64, [2 x i64] } } %t74, ptr %l38
  br label %bb12
bb12:
  %t75 = load { i32, { i64, [2 x i64] } }, ptr %l38
  store { i32, { i64, [2 x i64] } } %t75, ptr %l9
  %t76 = load { i32, { i64, [2 x i64] } }, ptr %l9
  store { i32, { i64, [2 x i64] } } %t76, ptr %l39
  %t77 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l39, i32 0, i32 0
  %t78 = load i32, ptr %t77, !tbaa !23
  %t79 = ashr i32 %t78, 16
  %t81 = icmp eq i32 %t79, 1
  br i1 %t81, label %bb13, label %bb14
bb13:
  call void @__olang_errpay_pop()
  br label %bb14
bb14:
  store { i64, ptr } %a6, ptr %l42, !tbaa !27
  %t84 = load i64, ptr %l8, !tbaa !24
  store i64 %t84, ptr %l43, !tbaa !24
  %t85 = call ptr @__olang_scope_hold(ptr %v6)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l44, !tbaa !24
  %t87 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t87, label %bb15, label %bb16
bb15:
  %t89 = call ptr @__olang_region_make(ptr %v6)
  %t90 = ptrtoint ptr %t89 to i64
  store i64 %t90, ptr %l44, !tbaa !24
  br label %bb16
bb16:
  %t91 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l9, i32 0, i32 1
  %t92 = getelementptr { i64, [2 x i64] }, ptr %t91, i32 0, i32 1
  %t93 = getelementptr { { i64, ptr } }, ptr %t92, i32 0, i32 0
  %t94 = load { i64, ptr }, ptr %t93
  %t96 = extractvalue { i64, ptr } %t94, 1
  %t97 = extractvalue { i64, ptr } %t94, 0
  %t98 = load i64, ptr %l44
  %t99 = inttoptr i64 %t98 to ptr
  %t100 = call ptr @__olang_held_alloc(ptr %t99, i64 %t97)
  call void @olang_textcopy(ptr %t100, ptr %t96, i64 %t97)
  %t101 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t100, 1
  %t105 = load i64, ptr %l43, !tbaa !24
  %t106 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr { i64, ptr }, ptr %t107, i64 %t105
  store { i64, ptr } %t102, ptr %t108, !tbaa !37
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s1)
  br label %bb18
bb18:
  br label %bb1
ret:
  ret void
}

define dso_local void @compiler_2ffix_2echecker(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, { i64, ptr } %a5, { i64, ptr } %a6) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l18 = alloca { i64, ptr }
  %l24 = alloca i1
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  br label %bb1
bb1:
  store { i64, ptr } %a2, ptr %l8, !tbaa !27
  %t2 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t3 = load ptr, ptr %t2, !tbaa !27
  %t4 = getelementptr i64, ptr %t3, i64 0
  %t6 = atomicrmw add ptr %t4, i64 1 seq_cst
  store i64 %t6, ptr %l7, !tbaa !24
  %t8 = load i64, ptr %l7, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t14 = icmp sge i64 %t8, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  store { i64, ptr } %a3, ptr %l15, !tbaa !27
  %t17 = load i64, ptr %l7, !tbaa !24
  store i64 %t17, ptr %l16, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t19, ptr %l18, !tbaa !27
  %t20 = load i64, ptr %l7, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %t23, i64 %t20
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !37
  %t34 = call i1 @compiler_2ffix_2everdict(ptr %v0, ptr %v1, ptr %v4, ptr %v5, ptr %v6, { i64, ptr } %a0, { i64, ptr } %t25, { i64, ptr } %a4, { i64, ptr } %a5, { i64, ptr } %a6)
  store i1 %t34, ptr %l24
  br label %bb5
bb5:
  %t35 = load i1, ptr %l24, !tbaa !21
  %t36 = xor i1 %t35, true
  %t38 = load i64, ptr %l16, !tbaa !24
  %t39 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr i1, ptr %t40, i64 %t38
  store i1 %t36, ptr %t41, !tbaa !31
  br label %bb6
bb6:
  br label %bb1
ret:
  ret void
}

define dso_local i1 @compiler_2ffix_2edriven(i64 %a0) #0 {
entry:
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i64, ptr @G_2ecompiler_2ffix_2eDrivenOpt, !tbaa !24
  %t5 = icmp sge i64 %a0, %t2
  store i1 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@__olang_prog_scope = external thread_local(initialexec) global ptr
declare ptr @__olang_errpay_top_get()
define linkonce_odr { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bcompiler_2ffix_3aNotBuilt_7d(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i32, { i64, [2 x i64] } }
  %l3 = alloca { i64, [2 x i64] }
  %rv = alloca { i32, { i64, [2 x i64] } }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i32, { i64, [2 x i64] } }, ptr %a0
  store { i32, { i64, [2 x i64] } } %t2, ptr %l1
  %t3 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l1, i32 0, i32 1
  %t5 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffix_3aNotBuilt_24payload(ptr %v0, ptr %t3)
  store { i64, [2 x i64] } %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load { i64, [2 x i64] }, ptr %l3
  %t7 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l1, i32 0, i32 1
  store { i64, [2 x i64] } %t6, ptr %t7
  %t8 = load { i32, { i64, [2 x i64] } }, ptr %l1
  store { i32, { i64, [2 x i64] } } %t8, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, [2 x i64] } }, ptr %rv
  ret { i32, { i64, [2 x i64] } } %rr
}

declare void @__olang_errpay_pop()
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
define linkonce_odr { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffix_3aNotBuilt_24payload(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, [2 x i64] }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, [2 x i64] }, ptr %a0
  store { i64, [2 x i64] } %t2, ptr %l1
  %t3 = load i64, ptr %l1, !range !{i64 0, i64 1}
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 ]
bb1:
  %t5 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t5, ptr %rv
  br label %ret
bb2:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, ptr } }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l5, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = mul i64 %t20, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t24 = getelementptr { { i64, ptr } }, ptr %t23, i32 0, i32 0
  store { i64, ptr } %t22, ptr %t24
  br label %bb1
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ffix_2ebuildTool(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare i1 @compiler_2ffix_2everdict(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
