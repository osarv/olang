; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/io:Writer" = type { i32, { i64, ptr }, i64, { i32, { i64, [1 x i64] } } }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"std/os:FileInfo" = type { i32, i64, i64 }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
@G_2ecompiler_2ffix_2eBatch = constant <{ [8 x i8] }> <{ [8 x i8] c"\C8\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eDrivenArg = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eDrivenOpt = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eStdTool = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eTextTool = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eToolKinds = constant <{ [288 x i8] }> <{ [288 x i8] c"\01\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\03\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2ffix_2eToolNames = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k1, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k2, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k3, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k4, [8 x i8] c"\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k5, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k6, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k7, [8 x i8] c"\0C\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k8, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k9, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k10, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k11, [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k12, [8 x i8] c"\0C\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k13, [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k14, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k15, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k16, [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k17, [8 x i8] c"\0B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k18, [8 x i8] c"\0A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k19, [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k20, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k21, [8 x i8] c"\0C\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k22, [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k23, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k24, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k25, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k26, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k27, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k28, [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k29, [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k30, [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k31, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k32, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k33, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k34, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k35, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k36 }>, align 64
@G_2ecompiler_2ffix_2eToolNames.k1 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\62\61\72\65\5F\74\79\70\65\76\61\72\73" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k2 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\70\65\72\6D\5F\6D\75\74" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k3 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\69\6E\74\5F\6C\69\74\65\72\61\6C\5F\69\36\34" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k4 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\65\72\72\6F\72\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k5 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\63\6C\69\5F\77\6F\72\64\73" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k6 = internal constant <{ [16 x i8] }> <{ [16 x i8] c"\64\6F\6E\65\66\61\69\6C\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k7 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\73\79\6E\74\61\78\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k8 = internal constant <{ [12 x i8] }> <{ [12 x i8] c"\6D\61\74\68\5F\6D\65\74\68\6F\64\73" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k9 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\61\72\72\61\79\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k10 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\72\65\73\75\6C\74\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k11 = internal constant <{ [16 x i8] }> <{ [16 x i8] c"\65\71\75\61\6C\69\74\79\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k12 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\68\65\6C\70\65\72\5F\72\65\6E\61\6D\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k13 = internal constant <{ [12 x i8] }> <{ [12 x i8] c"\6E\75\6C\6C\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k14 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\63\68\65\63\6B\65\72\72\6F\72\5F\72\65\6E\61\6D\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k15 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\73\74\75\74\74\65\72\5F\72\65\6E\61\6D\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k16 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\63\68\65\63\6B\65\64\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k17 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\63\6F\6E\74\72\61\63\74\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k18 = internal constant <{ [11 x i8] }> <{ [11 x i8] c"\74\72\79\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k19 = internal constant <{ [10 x i8] }> <{ [10 x i8] c"\61\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k20 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\65\72\72\6F\72\74\79\70\65\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k21 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\6C\69\73\74\5F\76\65\63" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k22 = internal constant <{ [12 x i8] }> <{ [12 x i8] c"\6C\69\6E\6B\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k23 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\6D\61\74\63\68\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k24 = internal constant <{ [16 x i8] }> <{ [16 x i8] c"\71\75\65\73\74\69\6F\6E\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k25 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\75\6E\75\73\65\64\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k26 = internal constant <{ [16 x i8] }> <{ [16 x i8] c"\65\72\72\6F\72\63\61\73\65\5F\72\65\6E\61\6D\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k27 = internal constant <{ [16 x i8] }> <{ [16 x i8] c"\76\61\72\69\61\64\69\63\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k28 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\73\63\6F\70\65\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k29 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\66\6E\72\65\66\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k30 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\63\6C\6F\6E\65\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k31 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\74\65\78\74\62\75\69\6C\64\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k32 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\75\6E\69\71\75\65\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k33 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\62\75\69\6C\64\65\72\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k34 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\6C\69\74\65\72\61\6C\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k35 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\6B\65\79\77\6F\72\64\5F\72\65\6E\61\6D\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k36 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\64\65\73\74\72\6F\79\5F\6D\69\67\72\61\74\65" }>, align 8
define dso_local { i64, ptr } @compiler_2ffix_2eBinDir(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca [2 x { i64, ptr }]
  %l6 = alloca [2 x { i64, ptr }]
  %l7 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l16 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i32
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l51 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %s0, { i64, ptr } %t1)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l10
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l9
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t8, ptr %l7, !tbaa !27
  br label %bb6
bb2:
  %t9 = load i32, ptr %l10, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  br i1 %t12, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  %t14 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 1
  %t17 = extractvalue { i64, ptr } %t14, 0
  %t18 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t17)
  call void @olang_textcopy(ptr %t18, ptr %t16, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t23 = extractvalue { i64, ptr } %t20, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l7, !tbaa !27
  br label %bb6
bb6:
  %t29 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t29, ptr %l2, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t32 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v1, ptr %s0, { i64, ptr } %t30)
  %t33 = extractvalue { i32, { i64, ptr } } %t32, 1
  %t34 = extractvalue { i32, { i64, ptr } } %t32, 0
  store i32 %t34, ptr %l19
  %t35 = icmp ne i32 %t34, 0
  br i1 %t35, label %bb8, label %ok.36, !prof !99
ok.36:
  store { i64, ptr } %t33, ptr %l18
  br label %bb7
bb7:
  %t37 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t37, ptr %l16, !tbaa !27
  br label %bb12
bb8:
  %t38 = load i32, ptr %l19, !tbaa !23
  %t39 = ashr i32 %t38, 16
  %t41 = icmp eq i32 %t39, 1
  br i1 %t41, label %bb9, label %bb10
bb9:
  call void @__olang_errpay_pop()
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t43 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 1
  %t46 = extractvalue { i64, ptr } %t43, 0
  %t47 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t46)
  call void @olang_textcopy(ptr %t47, ptr %t45, i64 %t46)
  %t48 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t52 = extractvalue { i64, ptr } %t49, 1
  %t53 = mul i64 %t51, 1
  %t54 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t53)
  call void @llvm.memcpy.p0.p0.i64(ptr %t54, ptr %t52, i64 %t53, i1 false)
  %t55 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t54, 1
  store { i64, ptr } %t56, ptr %l16, !tbaa !27
  br label %bb12
bb12:
  %t58 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t58, ptr %l3, !tbaa !27
  %t59 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t59, ptr %l25
  br label %bb13
bb13:
  %t60 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t60, ptr %l4
  %t61 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t61, 1
  %t64 = extractvalue { i64, ptr } %t61, 0
  %t65 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t64)
  call void @olang_textcopy(ptr %t65, ptr %t63, i64 %t64)
  %t66 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t65, 1
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t70 = extractvalue { i64, ptr } %t67, 1
  %t71 = mul i64 %t69, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t70, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } %t74)
  br label %bb14
bb14:
  %t77 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t77, 1
  %t80 = extractvalue { i64, ptr } %t77, 0
  %t81 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t80)
  call void @olang_textcopy(ptr %t81, ptr %t79, i64 %t80)
  %t82 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t81, 1
  %t85 = extractvalue { i64, ptr } %t83, 0
  %t86 = extractvalue { i64, ptr } %t83, 1
  %t87 = mul i64 %t85, 1
  %t88 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t87)
  call void @llvm.memcpy.p0.p0.i64(ptr %t88, ptr %t86, i64 %t87, i1 false)
  %t89 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } %t90)
  br label %bb15
bb15:
  %t93 = call { i64, ptr } @compiler_2ffetch_2eCacheDir(ptr %s0)
  store { i64, ptr } %t93, ptr %l34
  br label %bb16
bb16:
  %t94 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 0
  %t96 = extractvalue { i64, ptr } %t94, 1
  %t97 = mul i64 %t95, 1
  %t98 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t97)
  call void @llvm.memcpy.p0.p0.i64(ptr %t98, ptr %t96, i64 %t97, i1 false)
  %t99 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  %t102 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t100, 0
  %t103 = insertvalue [2 x { i64, ptr }] %t102, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  store [2 x { i64, ptr }] %t103, ptr %l5
  %t106 = insertvalue { i64, ptr } undef, i64 2, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %l5, 1
  %t109 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t107)
  store { i64, ptr } %t109, ptr %l39
  br label %bb17
bb17:
  %t110 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t110, 0
  %t112 = extractvalue { i64, ptr } %t110, 1
  %t113 = mul i64 %t111, 1
  %t114 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t113)
  call void @llvm.memcpy.p0.p0.i64(ptr %t114, ptr %t112, i64 %t113, i1 false)
  %t115 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t114, 1
  store { i64, ptr } %t116, ptr %l40, !tbaa !27
  %t118 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s0, ptr %s0, ptr %l4)
  store { i64, ptr } %t118, ptr %l42
  br label %bb18
bb18:
  %t119 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t119, 0
  store i64 %t120, ptr %l43, !tbaa !24
  %t121 = icmp sge i64 0, 0
  br i1 %t121, label %bb19, label %bb20
bb19:
  %t123 = icmp sle i64 0, 16
  br i1 %t123, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_74a546a3dd225c9b_f3beb7f3829b0fbf)
  unreachable
bb21:
  %t125 = load i64, ptr %l43, !tbaa !24
  %t126 = icmp sle i64 16, %t125
  br i1 %t126, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_74a546a3dd225c9b_f3beb7f3829b0fbf)
  unreachable
bb23:
  %t128 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr i8, ptr %t129, i64 0
  %t131 = sub i64 16, 0
  %t132 = insertvalue { i64, ptr } undef, i64 %t131, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t130, 1
  %t134 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t135 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t134, 0
  %t137 = insertvalue [2 x { i64, ptr }] %t135, { i64, ptr } %t133, 1
  store [2 x { i64, ptr }] %t137, ptr %l6
  %t140 = insertvalue { i64, ptr } undef, i64 2, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %l6, 1
  %t143 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %v2, { i64, ptr } %t141)
  store { i64, ptr } %t143, ptr %l51
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_74a546a3dd225c9b_f3beb7f3829b0fbf)
  unreachable
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t144 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t144, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2ffix_2eFiles(ptr %v0, ptr %v1, ptr %v2, i1 %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca i1
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/io:Writer"
  %l5 = alloca %"std/io:Writer"
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca [2 x { i64, ptr }]
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l31 = alloca { i32, { i64, [2 x i64] } }
  %l32 = alloca %"std/os:Output"
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l44 = alloca %"std/io:Writer"
  %l45 = alloca %"std/io:Writer"
  %l47 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l49 = alloca { i64, ptr }
  %l50 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l58 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l64 = alloca i32
  %l66 = alloca i1
  %l75 = alloca i32
  %l77 = alloca i1
  %l88 = alloca { i64, ptr }
  %l90 = alloca i1
  %l98 = alloca i32
  %l100 = alloca i1
  %l106 = alloca { i64, ptr }
  %l108 = alloca i32
  %l110 = alloca i1
  %l119 = alloca i32
  %l121 = alloca i1
  %l125 = alloca { i64, ptr }
  %l133 = alloca { i64, ptr }
  %l144 = alloca i32
  %l146 = alloca i1
  %l154 = alloca { i64, ptr }
  %l161 = alloca i64
  %l164 = alloca i64
  %l182 = alloca { i64, ptr }
  %l183 = alloca i64
  %l189 = alloca i64
  %l190 = alloca i64
  %l195 = alloca %"std/os:Output"
  %l202 = alloca { i64, ptr }
  %l204 = alloca { i64, ptr }
  %l205 = alloca %"std/os:Output"
  %l206 = alloca i32
  %l208 = alloca i1
  %l209 = alloca { i32, { i64, [2 x i64] } }
  %l210 = alloca { i32, { i64, [2 x i64] } }
  %l211 = alloca i32
  %l216 = alloca { i32, { i64, [2 x i64] } }
  %l217 = alloca { i32, { i64, [2 x i64] } }
  %l220 = alloca ptr
  %l221 = alloca { i64, ptr }
  %l222 = alloca { i32, { i64, [2 x i64] } }
  %l224 = alloca { i32, { i64, [2 x i64] } }
  %l225 = alloca i32
  %l240 = alloca { i64, ptr }
  %l247 = alloca i64
  %l250 = alloca i1
  %l260 = alloca i1
  %l263 = alloca { i64, ptr }
  %l280 = alloca i64
  %l283 = alloca i64
  %l301 = alloca { i64, ptr }
  %l302 = alloca { i64, ptr }
  %l305 = alloca { i64, ptr }
  %l306 = alloca i32
  %l308 = alloca i1
  %l311 = alloca { i64, ptr }
  %l314 = alloca { i64, ptr }
  %l315 = alloca i1
  %l319 = alloca { i64, ptr }
  %l326 = alloca { i64, ptr }
  %l328 = alloca { i64, ptr }
  %l331 = alloca { i64, ptr }
  %l333 = alloca i32
  %l335 = alloca i1
  %l339 = alloca { i64, ptr }
  %l349 = alloca i1
  %l354 = alloca { i64, ptr }
  %l362 = alloca i32
  %l364 = alloca i1
  %l369 = alloca i32
  %l371 = alloca i1
  %l379 = alloca i1
  %l382 = alloca i1
  %l385 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.builder
  %s21room = alloca [64 x i8], align 8
  %s23 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %rv = alloca i32
  store i1 %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %s0, i32 2, i64 65536)
  store %"std/io:Writer" %t1, ptr %l44
  br label %bb1
bb1:
  %t2 = load %"std/io:Writer", ptr %l44
  store %"std/io:Writer" %t2, ptr %l4
  %t3 = call %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %s0, i32 1, i64 65536)
  store %"std/io:Writer" %t3, ptr %l45
  br label %bb2
bb2:
  %t4 = load %"std/io:Writer", ptr %l45
  store %"std/io:Writer" %t4, ptr %l5
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffix_2eexpand(ptr %v0, ptr %s0, { i64, ptr } %a1)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l47
  br label %bb3
bb3:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l47
  %t9 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %t9
  %t11 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s0, ptr %s0, ptr %t9)
  store { i64, ptr } %t11, ptr %l49
  br label %bb4
bb4:
  %t12 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t12, ptr %l6, !tbaa !27
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l50
  br label %bb5
bb5:
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l50
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l7
  %t15 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t15, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  store i64 %t19, ptr %l10, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t21 = load i64, ptr %l9, !tbaa !24
  %t22 = load i64, ptr %l10, !tbaa !24
  %t25 = icmp slt i64 %t21, %t22
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb8:
  br label %bb9
bb9:
  %t29 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t29, ptr %l58, !tbaa !27
  %t30 = load i64, ptr %l9, !tbaa !24
  %t32 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr { i64, ptr }, ptr %t33, i64 %t30
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !37
  store { i64, ptr } %t35, ptr %l11, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t39 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s2, { i64, ptr } %t37)
  %t40 = extractvalue { i32, { i64, ptr } } %t39, 1
  %t41 = extractvalue { i32, { i64, ptr } } %t39, 0
  store i32 %t41, ptr %l64
  %t42 = icmp ne i32 %t41, 0
  br i1 %t42, label %bb11, label %ok.43, !prof !99
ok.43:
  store { i64, ptr } %t40, ptr %l63
  br label %bb10
bb10:
  %t44 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t44, ptr %l61, !tbaa !27
  br label %bb22
bb11:
  %t45 = load i32, ptr %l64, !tbaa !23
  %t46 = ashr i32 %t45, 16
  %t48 = icmp eq i32 %t46, 1
  store i1 %t48, ptr %l66, !tbaa !21
  %t49 = load i32, ptr %l64, !tbaa !23
  %t50 = ashr i32 %t49, 16
  %t52 = icmp eq i32 %t50, 1
  br i1 %t52, label %bb12, label %bb13
bb12:
  call void @__olang_errpay_pop()
  br label %bb13
bb13:
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t54 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t55 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t58 = extractvalue { i64, ptr } %t54, 1
  %t59 = extractvalue { i64, ptr } %t54, 0
  %t60 = add i64 %t56, %t59
  %t61 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t62 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t63 = add i64 %t60, %t62
  %t64 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t63)
  call void @olang_textcopy(ptr %t64, ptr %t55, i64 %t56)
  %t65 = getelementptr i8, ptr %t64, i64 %t56
  call void @olang_textcopy(ptr %t65, ptr %t58, i64 %t59)
  %t66 = getelementptr i8, ptr %t65, i64 %t59
  call void @olang_textcopy(ptr %t66, ptr %t61, i64 %t62)
  %t67 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t64, 1
  %t71 = extractvalue { i64, ptr } %t68, 0
  %t72 = extractvalue { i64, ptr } %t68, 1
  %t73 = mul i64 %t71, 1
  %t74 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t73)
  call void @llvm.memcpy.p0.p0.i64(ptr %t74, ptr %t72, i64 %t73, i1 false)
  %t75 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s3, ptr %l4, { i64, ptr } %t76)
  br label %bb15
bb15:
  %t80 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l4)
  store i32 %t80, ptr %l75
  %t81 = icmp ne i32 %t80, 0
  br i1 %t81, label %bb17, label %ok.82, !prof !99
ok.82:
  br label %bb16
bb16:
  br label %bb21
bb17:
  %t83 = load i32, ptr %l75, !tbaa !23
  %t84 = ashr i32 %t83, 16
  %t86 = icmp eq i32 %t84, 1
  store i1 %t86, ptr %l77, !tbaa !21
  %t87 = load i32, ptr %l75, !tbaa !23
  %t88 = ashr i32 %t87, 16
  %t90 = icmp eq i32 %t88, 1
  br i1 %t90, label %bb18, label %bb19
bb18:
  call void @__olang_errpay_pop()
  br label %bb19
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb22:
  %t93 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t93, 1
  %t97 = extractvalue { i64, ptr } %t93, 0
  %t98 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t97)
  call void @olang_textcopy(ptr %t98, ptr %t96, i64 %t97)
  %t99 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = extractvalue { i64, ptr } %t100, 1
  %t104 = mul i64 %t102, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t104)
  call void @llvm.memcpy.p0.p0.i64(ptr %t105, ptr %t103, i64 %t104, i1 false)
  %t106 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } %t107)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb24:
  %t110 = load i64, ptr %l9, !tbaa !24
  %t112 = add i64 %t110, 1
  store i64 %t112, ptr %l9, !tbaa !24
  br label %bb6
bb25:
  %t114 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t116 = call { i64, ptr } @compiler_2ffix_2eToolsDir(ptr %v1, ptr %s0, { i64, ptr } %t114)
  store { i64, ptr } %t116, ptr %l88
  br label %bb26
bb26:
  %t117 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t117, ptr %l13, !tbaa !27
  %t118 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t120 = call i1 @std_2fos_2eIsDir(ptr %s0, { i64, ptr } %t118)
  store i1 %t120, ptr %l90
  br label %bb27
bb27:
  %t121 = load i1, ptr %l90, !tbaa !21
  %t122 = xor i1 %t121, true
  br i1 %t122, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s8
  %t124 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t125 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t126 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t128 = extractvalue { i64, ptr } %t124, 1
  %t129 = extractvalue { i64, ptr } %t124, 0
  %t130 = add i64 %t126, %t129
  %t131 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t132 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t133 = add i64 %t130, %t132
  %t134 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t133)
  call void @olang_textcopy(ptr %t134, ptr %t125, i64 %t126)
  %t135 = getelementptr i8, ptr %t134, i64 %t126
  call void @olang_textcopy(ptr %t135, ptr %t128, i64 %t129)
  %t136 = getelementptr i8, ptr %t135, i64 %t129
  call void @olang_textcopy(ptr %t136, ptr %t131, i64 %t132)
  %t137 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t134, 1
  %t141 = extractvalue { i64, ptr } %t138, 0
  %t142 = extractvalue { i64, ptr } %t138, 1
  %t143 = mul i64 %t141, 1
  %t144 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t143)
  call void @llvm.memcpy.p0.p0.i64(ptr %t144, ptr %t142, i64 %t143, i1 false)
  %t145 = insertvalue { i64, ptr } undef, i64 %t141, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t144, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s8, ptr %l4, { i64, ptr } %t146)
  br label %bb30
bb29:
  br label %bb37
bb30:
  %t150 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l4)
  store i32 %t150, ptr %l98
  %t151 = icmp ne i32 %t150, 0
  br i1 %t151, label %bb32, label %ok.152, !prof !99
ok.152:
  br label %bb31
bb31:
  br label %bb36
bb32:
  %t153 = load i32, ptr %l98, !tbaa !23
  %t154 = ashr i32 %t153, 16
  %t156 = icmp eq i32 %t154, 1
  store i1 %t156, ptr %l100, !tbaa !21
  %t157 = load i32, ptr %l98, !tbaa !23
  %t158 = ashr i32 %t157, 16
  %t160 = icmp eq i32 %t158, 1
  br i1 %t160, label %bb33, label %bb34
bb33:
  call void @__olang_errpay_pop()
  br label %bb34
bb34:
  br label %bb35
bb35:
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb37:
  %t163 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t164 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t167 = call { i64, ptr } @compiler_2ffix_2eBinDir(ptr %v1, ptr %s0, ptr %s0, { i64, ptr } %t163, { i64, ptr } %t164)
  store { i64, ptr } %t167, ptr %l106
  br label %bb38
bb38:
  %t168 = load { i64, ptr }, ptr %l106, !tbaa !27
  store { i64, ptr } %t168, ptr %l14, !tbaa !27
  %t169 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t171 = call i32 @std_2fos_2eMkDirAll(ptr %s0, { i64, ptr } %t169)
  store i32 %t171, ptr %l108
  %t172 = icmp ne i32 %t171, 0
  br i1 %t172, label %bb40, label %ok.173, !prof !99
ok.173:
  br label %bb39
bb39:
  br label %bb51
bb40:
  %t174 = load i32, ptr %l108, !tbaa !23
  %t175 = ashr i32 %t174, 16
  %t177 = icmp eq i32 %t175, 1
  store i1 %t177, ptr %l110, !tbaa !21
  %t178 = load i32, ptr %l108, !tbaa !23
  %t179 = ashr i32 %t178, 16
  %t181 = icmp eq i32 %t179, 1
  br i1 %t181, label %bb41, label %bb42
bb41:
  call void @__olang_errpay_pop()
  br label %bb42
bb42:
  br label %bb43
bb43:
  store %olang.scope zeroinitializer, ptr %s11
  %t183 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t184 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t185 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t187 = extractvalue { i64, ptr } %t183, 1
  %t188 = extractvalue { i64, ptr } %t183, 0
  %t189 = add i64 %t185, %t188
  %t190 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t191 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t192 = add i64 %t189, %t191
  %t193 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t192)
  call void @olang_textcopy(ptr %t193, ptr %t184, i64 %t185)
  %t194 = getelementptr i8, ptr %t193, i64 %t185
  call void @olang_textcopy(ptr %t194, ptr %t187, i64 %t188)
  %t195 = getelementptr i8, ptr %t194, i64 %t188
  call void @olang_textcopy(ptr %t195, ptr %t190, i64 %t191)
  %t196 = insertvalue { i64, ptr } undef, i64 %t192, 0
  %t197 = insertvalue { i64, ptr } %t196, ptr %t193, 1
  %t200 = extractvalue { i64, ptr } %t197, 0
  %t201 = extractvalue { i64, ptr } %t197, 1
  %t202 = mul i64 %t200, 1
  %t203 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t202)
  call void @llvm.memcpy.p0.p0.i64(ptr %t203, ptr %t201, i64 %t202, i1 false)
  %t204 = insertvalue { i64, ptr } undef, i64 %t200, 0
  %t205 = insertvalue { i64, ptr } %t204, ptr %t203, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s11, ptr %l4, { i64, ptr } %t205)
  br label %bb44
bb44:
  %t209 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l4)
  store i32 %t209, ptr %l119
  %t210 = icmp ne i32 %t209, 0
  br i1 %t210, label %bb46, label %ok.211, !prof !99
ok.211:
  br label %bb45
bb45:
  br label %bb50
bb46:
  %t212 = load i32, ptr %l119, !tbaa !23
  %t213 = ashr i32 %t212, 16
  %t215 = icmp eq i32 %t213, 1
  store i1 %t215, ptr %l121, !tbaa !21
  %t216 = load i32, ptr %l119, !tbaa !23
  %t217 = ashr i32 %t216, 16
  %t219 = icmp eq i32 %t217, 1
  br i1 %t219, label %bb47, label %bb48
bb47:
  call void @__olang_errpay_pop()
  br label %bb48
bb48:
  br label %bb49
bb49:
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb51:
  store i32 0, ptr %l15, !tbaa !23
  store i64 0, ptr %l16, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s14
  %t222 = call { i64, ptr } @compiler_2ffix_2eOrder(ptr %s14)
  store { i64, ptr } %t222, ptr %l125
  br label %bb52
bb52:
  %t223 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t224 = extractvalue { i64, ptr } %t223, 0
  %t225 = extractvalue { i64, ptr } %t223, 1
  %t226 = mul i64 %t224, 8
  %t227 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t226)
  call void @llvm.memcpy.p0.p0.i64(ptr %t227, ptr %t225, i64 %t226, i1 false)
  %t228 = insertvalue { i64, ptr } undef, i64 %t224, 0
  %t229 = insertvalue { i64, ptr } %t228, ptr %t227, 1
  store { i64, ptr } %t229, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t231 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t233 = extractvalue { i64, ptr } %t231, 0
  store i64 %t233, ptr %l19, !tbaa !24
  br label %bb53
bb53:
  store %olang.scope zeroinitializer, ptr %s15
  %t235 = load i64, ptr %l18, !tbaa !24
  %t236 = load i64, ptr %l19, !tbaa !24
  %t239 = icmp slt i64 %t235, %t236
  %t241 = xor i1 %t239, true
  br i1 %t241, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s15)
  br label %bb128
bb55:
  br label %bb56
bb56:
  %t243 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t243, ptr %l133, !tbaa !27
  %t244 = load i64, ptr %l18, !tbaa !24
  %t246 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t247 = load ptr, ptr %t246, !tbaa !27
  %t248 = getelementptr i64, ptr %t247, i64 %t244
  %t249 = load i64, ptr %t248, !tbaa !34
  store i64 %t249, ptr %l20, !tbaa !24
  %t251 = load i64, ptr %l20, !tbaa !24
  %t253 = getelementptr [36 x { i64, ptr }], ptr @G_2ecompiler_2ffix_2eToolNames, i64 0, i64 %t251
  %t254 = load { i64, ptr }, ptr %t253, !tbaa !37
  store { i64, ptr } %t254, ptr %l21, !tbaa !27
  %t256 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t257 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t258 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t259 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t260 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t261 = load ptr, ptr @__olang_prog_scope
  %t268 = call i32 @compiler_2ffix_2eensureBuilt(ptr %v1, ptr %s0, ptr %s0, ptr %t261, ptr %v2, ptr %s0, { i64, ptr } %t256, { i64, ptr } %t257, { i64, ptr } %t258, { i64, ptr } %t259, { i64, ptr } %t260, ptr %l4)
  store i32 %t268, ptr %l144
  %t269 = icmp ne i32 %t268, 0
  br i1 %t269, label %bb58, label %ok.270, !prof !99
ok.270:
  br label %bb57
bb57:
  br label %bb60
bb58:
  %t271 = load i32, ptr %l144, !tbaa !23
  %t272 = ashr i32 %t271, 16
  %t274 = icmp eq i32 %t272, 1
  store i1 %t274, ptr %l146, !tbaa !21
  br label %bb59
bb59:
  store i32 2, ptr %l15, !tbaa !23
  call void @__olang_scope_close(ptr %s15)
  br label %bb128
bb60:
  %t275 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t276 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t277 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t278 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t280 = extractvalue { i64, ptr } %t276, 1
  %t281 = extractvalue { i64, ptr } %t276, 0
  %t282 = add i64 %t278, %t281
  %t283 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t282)
  call void @olang_textcopy(ptr %t283, ptr %t277, i64 %t278)
  %t284 = getelementptr i8, ptr %t283, i64 %t278
  call void @olang_textcopy(ptr %t284, ptr %t280, i64 %t281)
  %t285 = insertvalue { i64, ptr } undef, i64 %t282, 0
  %t286 = insertvalue { i64, ptr } %t285, ptr %t283, 1
  %t288 = extractvalue { i64, ptr } %t286, 0
  %t289 = extractvalue { i64, ptr } %t286, 1
  %t290 = mul i64 %t288, 1
  %t291 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t290)
  call void @llvm.memcpy.p0.p0.i64(ptr %t291, ptr %t289, i64 %t290, i1 false)
  %t292 = insertvalue { i64, ptr } undef, i64 %t288, 0
  %t293 = insertvalue { i64, ptr } %t292, ptr %t291, 1
  %t295 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t275, 0
  %t297 = insertvalue [2 x { i64, ptr }] %t295, { i64, ptr } %t293, 1
  store [2 x { i64, ptr }] %t297, ptr %l22
  %t300 = insertvalue { i64, ptr } undef, i64 2, 0
  %t301 = insertvalue { i64, ptr } %t300, ptr %l22, 1
  %t303 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s15, ptr %s15, { i64, ptr } %t301)
  store { i64, ptr } %t303, ptr %l154
  br label %bb61
bb61:
  %t304 = load { i64, ptr }, ptr %l154, !tbaa !27
  store { i64, ptr } %t304, ptr %l23, !tbaa !27
  store i64 0, ptr %l24, !tbaa !24
  %t305 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t307 = extractvalue { i64, ptr } %t305, 0
  store i64 %t307, ptr %l25, !tbaa !24
  %t309 = load i64, ptr @G_2ecompiler_2ffix_2eBatch, !tbaa !24
  store i64 %t309, ptr %l26, !tbaa !24
  %t311 = load i64, ptr %l25, !tbaa !24
  %t312 = load i64, ptr %l24, !tbaa !24
  %t315 = icmp sgt i64 %t311, %t312
  br i1 %t315, label %bb62, label %bb63
bb62:
  %t317 = load i64, ptr %l26, !tbaa !24
  %t319 = icmp sgt i64 %t317, 0
  br i1 %t319, label %bb64, label %bb65
bb63:
  store i64 0, ptr %l161, !tbaa !24
  br label %bb67
bb64:
  %t321 = load i64, ptr %l25, !tbaa !24
  %t322 = load i64, ptr %l24, !tbaa !24
  %t325 = sub i64 %t321, %t322
  %t326 = load i64, ptr %l26, !tbaa !24
  %t329 = add i64 %t325, %t326
  %t331 = sub i64 %t329, 1
  %t332 = load i64, ptr %l26, !tbaa !24
  %t335 = sdiv i64 %t331, %t332
  store i64 %t335, ptr %l164, !tbaa !24
  br label %bb66
bb65:
  store i64 0, ptr %l164, !tbaa !24
  br label %bb66
bb66:
  %t337 = load i64, ptr %l164, !tbaa !24
  store i64 %t337, ptr %l161, !tbaa !24
  br label %bb67
bb67:
  %t338 = load i64, ptr %l161, !tbaa !24
  store i64 %t338, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb68
bb68:
  store %olang.scope zeroinitializer, ptr %s19
  %t339 = load i64, ptr %l28, !tbaa !24
  %t340 = load i64, ptr %l27, !tbaa !24
  %t343 = icmp slt i64 %t339, %t340
  %t345 = xor i1 %t343, true
  br i1 %t345, label %bb69, label %bb70
bb69:
  call void @__olang_scope_close(ptr %s19)
  br label %bb123
bb70:
  br label %bb71
bb71:
  %t347 = load i64, ptr %l24, !tbaa !24
  %t348 = load i64, ptr %l28, !tbaa !24
  %t349 = load i64, ptr %l26, !tbaa !24
  %t352 = mul i64 %t348, %t349
  %t355 = add i64 %t347, %t352
  store i64 %t355, ptr %l29, !tbaa !24
  %t357 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t357, ptr %l182, !tbaa !27
  %t358 = load i64, ptr %l29, !tbaa !24
  store i64 %t358, ptr %l183, !tbaa !24
  %t359 = load i64, ptr %l29, !tbaa !24
  %t360 = load i64, ptr @G_2ecompiler_2ffix_2eBatch, !tbaa !24
  %t363 = add i64 %t359, %t360
  %t364 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t366 = extractvalue { i64, ptr } %t364, 0
  %t369 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t363, i64 %t366)
  store i64 %t369, ptr %l189
  br label %bb72
bb72:
  %t370 = load { i64, ptr }, ptr %l182, !tbaa !27
  %t371 = extractvalue { i64, ptr } %t370, 0
  store i64 %t371, ptr %l190, !tbaa !24
  %t372 = load i64, ptr %l183, !tbaa !24
  %t373 = icmp sge i64 %t372, 0
  br i1 %t373, label %bb73, label %bb74
bb73:
  %t375 = load i64, ptr %l183, !tbaa !24
  %t376 = load i64, ptr %l189, !tbaa !24
  %t377 = icmp sle i64 %t375, %t376
  br i1 %t377, label %bb75, label %bb76
bb74:
  call void @__olang_check_failed(ptr @olang_loc_299e69389bcee8f2_b185402659ea7d46)
  unreachable
bb75:
  %t379 = load i64, ptr %l189, !tbaa !24
  %t380 = load i64, ptr %l190, !tbaa !24
  %t381 = icmp sle i64 %t379, %t380
  br i1 %t381, label %bb77, label %bb78
bb76:
  call void @__olang_check_failed(ptr @olang_loc_299e69389bcee8f2_b185402659ea7d46)
  unreachable
bb77:
  %t383 = getelementptr { i64, ptr }, ptr %l182, i32 0, i32 1
  %t384 = load ptr, ptr %t383, !tbaa !27
  %t385 = load i64, ptr %l183, !tbaa !24
  %t386 = load i64, ptr %l189, !tbaa !24
  %t387 = getelementptr { i64, ptr }, ptr %t384, i64 %t385
  %t388 = sub i64 %t386, %t385
  %t389 = insertvalue { i64, ptr } undef, i64 %t388, 0
  %t390 = insertvalue { i64, ptr } %t389, ptr %t387, 1
  %t392 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t393 = load i64, ptr %l20, !tbaa !24
  %t395 = getelementptr [36 x i64], ptr @G_2ecompiler_2ffix_2eToolKinds, i64 0, i64 %t393
  %t396 = load i64, ptr %t395, !tbaa !34
  %t397 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t398 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t405 = call { i64, ptr } @compiler_2ffix_2earguments(ptr %s15, ptr %v1, ptr %v2, ptr %s0, ptr %s19, { i64, ptr } %t392, i64 %t396, { i64, ptr } %t397, { i64, ptr } %t398, { i64, ptr } %t390)
  store { i64, ptr } %t405, ptr %l202
  br label %bb79
bb78:
  call void @__olang_check_failed(ptr @olang_loc_299e69389bcee8f2_b185402659ea7d46)
  unreachable
bb79:
  %t406 = load { i64, ptr }, ptr %l202, !tbaa !27
  %t407 = extractvalue { i64, ptr } %t406, 0
  %t408 = extractvalue { i64, ptr } %t406, 1
  %t409 = mul i64 %t407, 16
  %t410 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t409)
  call void @llvm.memcpy.p0.p0.i64(ptr %t410, ptr %t408, i64 %t409, i1 false)
  %t411 = insertvalue { i64, ptr } undef, i64 %t407, 0
  %t412 = insertvalue { i64, ptr } %t411, ptr %t410, 1
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l204, !tbaa !27
  %t414 = load { i64, ptr }, ptr %l204, !tbaa !27
  %t415 = call { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %s19, ptr %s19, ptr %s19, ptr %s19, { i64, ptr } %t412, { i64, ptr } %t414, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d9, i32 0, i32 1) })
  %t416 = extractvalue { i32, %"std/os:Output" } %t415, 1
  %t417 = extractvalue { i32, %"std/os:Output" } %t415, 0
  store i32 %t417, ptr %l206
  %t418 = icmp ne i32 %t417, 0
  br i1 %t418, label %bb81, label %ok.419, !prof !99
ok.419:
  store %"std/os:Output" %t416, ptr %l205
  br label %bb80
bb80:
  %t420 = load %"std/os:Output", ptr %l205
  store %"std/os:Output" %t420, ptr %l195
  br label %bb105
bb81:
  %t421 = load i32, ptr %l206, !tbaa !23
  %t422 = ashr i32 %t421, 16
  %t424 = icmp eq i32 %t422, 1
  store i1 %t424, ptr %l208, !tbaa !21
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l31
  %t425 = load i32, ptr %l206, !tbaa !23
  %t426 = lshr i32 %t425, 16
  %t427 = and i32 %t425, 65535
  %t428 = icmp eq i32 %t426, 1
  %t429 = select i1 %t428, i32 1, i32 0
  %t430 = icmp eq i32 %t425, 0
  %t431 = shl i32 %t429, 16
  %t432 = or i32 %t431, %t427
  %t433 = select i1 %t430, i32 0, i32 %t432
  %t434 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l31, i32 0, i32 0
  store i32 %t433, ptr %t434, !tbaa !23
  br label %bb82
bb82:
  store %olang.scope zeroinitializer, ptr %s20
  %t435 = load { i32, { i64, [2 x i64] } }, ptr %l31
  store { i32, { i64, [2 x i64] } } %t435, ptr %l209
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l210
  %t436 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l209, i32 0, i32 0
  %t437 = load i32, ptr %t436, !tbaa !23
  store i32 %t437, ptr %l211, !tbaa !23
  %t438 = load i32, ptr %l211, !tbaa !23
  %t439 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l210, i32 0, i32 0
  store i32 %t438, ptr %t439, !tbaa !23
  %t440 = load i32, ptr %l211, !tbaa !23
  %t441 = ashr i32 %t440, 16
  %t443 = icmp eq i32 %t441, 1
  br i1 %t443, label %bb83, label %bb84
bb83:
  %t445 = call ptr @__olang_errpay_top_get()
  %t447 = load { i64, [2 x i64] }, ptr %t445
  %t448 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l210, i32 0, i32 1
  store { i64, [2 x i64] } %t447, ptr %t448
  br label %bb84
bb84:
  %t450 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fos_3aError_7d(ptr %s19, ptr %l210)
  store { i32, { i64, [2 x i64] } } %t450, ptr %l216
  br label %bb85
bb85:
  %t451 = load { i32, { i64, [2 x i64] } }, ptr %l216
  store { i32, { i64, [2 x i64] } } %t451, ptr %l31
  %t452 = load { i32, { i64, [2 x i64] } }, ptr %l31
  store { i32, { i64, [2 x i64] } } %t452, ptr %l217
  %t453 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l217, i32 0, i32 0
  %t454 = load i32, ptr %t453, !tbaa !23
  %t455 = ashr i32 %t454, 16
  %t457 = icmp eq i32 %t455, 1
  br i1 %t457, label %bb86, label %bb87
bb86:
  call void @__olang_errpay_pop()
  br label %bb87
bb87:
  store ptr %l4, ptr %l220, !tbaa !29
  %t459 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t459, ptr %l221, !tbaa !27
  %t460 = load { i32, { i64, [2 x i64] } }, ptr %l31
  store { i32, { i64, [2 x i64] } } %t460, ptr %l222
  %t462 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fos_3aError_7d(ptr %s20, ptr %l222)
  store { i32, { i64, [2 x i64] } } %t462, ptr %l224
  br label %bb88
bb88:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s21
  store ptr %s21room, ptr %s21
  %t463 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t464 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t463, i64 %t464)
  %t465 = load { i64, ptr }, ptr %l221, !tbaa !27
  %t466 = extractvalue { i64, ptr } %t465, 1
  %t467 = extractvalue { i64, ptr } %t465, 0
  call void @__olang_sb_put(ptr %s21, ptr %t466, i64 %t467)
  %t468 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t469 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t468, i64 %t469)
  %t470 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l224, i32 0, i32 0
  %t471 = load i32, ptr %t470, !tbaa !23
  store i32 %t471, ptr %l225, !tbaa !23
  %t472 = load i32, ptr %l225, !tbaa !23
  %t473 = icmp eq i32 %t472, 0
  br i1 %t473, label %bb90, label %bb91
bb89:
  %t475 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t476 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t475, i64 %t476)
  %t477 = load ptr, ptr %s21
  %t478 = getelementptr %olang.builder, ptr %s21, i32 0, i32 1
  %t479 = load i64, ptr %t478
  %t480 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t479)
  call void @olang_textcopy(ptr %t480, ptr %t477, i64 %t479)
  %t481 = insertvalue { i64, ptr } undef, i64 %t479, 0
  %t482 = insertvalue { i64, ptr } %t481, ptr %t480, 1
  store { i64, ptr } %t482, ptr %l240, !tbaa !27
  %t483 = getelementptr %olang.builder, ptr %s21, i32 0, i32 3
  %t484 = load ptr, ptr %t483
  %t485 = icmp ne ptr %t484, null
  br i1 %t485, label %sbgrew.486, label %sbdone.487
sbgrew.486:
  call void @__olang_sb_done(ptr %s21)
  br label %sbdone.487
sbdone.487:
  %t488 = load { i64, ptr }, ptr %l240, !tbaa !27
  %t490 = extractvalue { i64, ptr } %t488, 0
  %t491 = extractvalue { i64, ptr } %t488, 1
  %t492 = mul i64 %t490, 1
  %t493 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t492)
  call void @llvm.memcpy.p0.p0.i64(ptr %t493, ptr %t491, i64 %t492, i1 false)
  %t494 = insertvalue { i64, ptr } undef, i64 %t490, 0
  %t495 = insertvalue { i64, ptr } %t494, ptr %t493, 1
  %t496 = load ptr, ptr %l220, !tbaa !29
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s20, ptr %t496, { i64, ptr } %t495)
  br label %bb104
bb90:
  %t498 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t499 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t498, i64 %t499)
  br label %bb89
bb91:
  %t500 = load i32, ptr %l225, !tbaa !23
  %t501 = icmp eq i32 %t500, 65536
  br i1 %t501, label %bb92, label %bb93
bb92:
  %t503 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t504 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t503, i64 %t504)
  %t505 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t506 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t505, i64 %t506)
  %t507 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l224, i32 0, i32 1
  %t508 = getelementptr { i64, [2 x i64] }, ptr %t507, i32 0, i32 1
  %t509 = getelementptr { { i64, ptr } }, ptr %t508, i32 0, i32 0
  %t510 = load { i64, ptr }, ptr %t509
  %t512 = extractvalue { i64, ptr } %t510, 1
  %t513 = extractvalue { i64, ptr } %t510, 0
  %t514 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t512, i64 %t513, i8 34)
  %t515 = call ptr @__olang_sb_room(ptr %s21, i64 %t514)
  %t516 = call i64 @__olang_rd_quote(ptr %t515, i64 0, ptr %t512, i64 %t513, i8 34)
  call void @__olang_sb_add(ptr %s21, i64 %t514)
  %t517 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t518 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t517, i64 %t518)
  br label %bb89
bb93:
  %t519 = load i32, ptr %l225, !tbaa !23
  %t520 = icmp eq i32 %t519, 65537
  br i1 %t520, label %bb94, label %bb95
bb94:
  %t522 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t523 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t522, i64 %t523)
  %t524 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t525 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t524, i64 %t525)
  %t526 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l224, i32 0, i32 1
  %t527 = getelementptr { i64, [2 x i64] }, ptr %t526, i32 0, i32 1
  %t528 = getelementptr { { i64, ptr } }, ptr %t527, i32 0, i32 0
  %t529 = load { i64, ptr }, ptr %t528
  %t531 = extractvalue { i64, ptr } %t529, 1
  %t532 = extractvalue { i64, ptr } %t529, 0
  %t533 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t531, i64 %t532, i8 34)
  %t534 = call ptr @__olang_sb_room(ptr %s21, i64 %t533)
  %t535 = call i64 @__olang_rd_quote(ptr %t534, i64 0, ptr %t531, i64 %t532, i8 34)
  call void @__olang_sb_add(ptr %s21, i64 %t533)
  %t536 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t537 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t536, i64 %t537)
  br label %bb89
bb95:
  %t538 = load i32, ptr %l225, !tbaa !23
  %t539 = icmp eq i32 %t538, 65538
  br i1 %t539, label %bb96, label %bb97
bb96:
  %t541 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t542 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t541, i64 %t542)
  %t543 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t544 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t543, i64 %t544)
  %t545 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l224, i32 0, i32 1
  %t546 = getelementptr { i64, [2 x i64] }, ptr %t545, i32 0, i32 1
  %t547 = getelementptr { { i64, ptr } }, ptr %t546, i32 0, i32 0
  %t548 = load { i64, ptr }, ptr %t547
  %t550 = extractvalue { i64, ptr } %t548, 1
  %t551 = extractvalue { i64, ptr } %t548, 0
  %t552 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t550, i64 %t551, i8 34)
  %t553 = call ptr @__olang_sb_room(ptr %s21, i64 %t552)
  %t554 = call i64 @__olang_rd_quote(ptr %t553, i64 0, ptr %t550, i64 %t551, i8 34)
  call void @__olang_sb_add(ptr %s21, i64 %t552)
  %t555 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t556 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t555, i64 %t556)
  br label %bb89
bb97:
  %t557 = load i32, ptr %l225, !tbaa !23
  %t558 = icmp eq i32 %t557, 65539
  br i1 %t558, label %bb98, label %bb99
bb98:
  %t560 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t561 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t560, i64 %t561)
  %t562 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t563 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t562, i64 %t563)
  %t564 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l224, i32 0, i32 1
  %t565 = getelementptr { i64, [2 x i64] }, ptr %t564, i32 0, i32 1
  %t566 = getelementptr { { i64, ptr } }, ptr %t565, i32 0, i32 0
  %t567 = load { i64, ptr }, ptr %t566
  %t569 = extractvalue { i64, ptr } %t567, 1
  %t570 = extractvalue { i64, ptr } %t567, 0
  %t571 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t569, i64 %t570, i8 34)
  %t572 = call ptr @__olang_sb_room(ptr %s21, i64 %t571)
  %t573 = call i64 @__olang_rd_quote(ptr %t572, i64 0, ptr %t569, i64 %t570, i8 34)
  call void @__olang_sb_add(ptr %s21, i64 %t571)
  %t574 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t575 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t574, i64 %t575)
  br label %bb89
bb99:
  %t576 = load i32, ptr %l225, !tbaa !23
  %t577 = icmp eq i32 %t576, 65540
  br i1 %t577, label %bb100, label %bb101
bb100:
  %t579 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t580 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t579, i64 %t580)
  %t581 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t582 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t581, i64 %t582)
  %t583 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l224, i32 0, i32 1
  %t584 = getelementptr { i64, [2 x i64] }, ptr %t583, i32 0, i32 1
  %t585 = getelementptr { { i64, ptr } }, ptr %t584, i32 0, i32 0
  %t586 = load { i64, ptr }, ptr %t585
  %t588 = extractvalue { i64, ptr } %t586, 1
  %t589 = extractvalue { i64, ptr } %t586, 0
  %t590 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t588, i64 %t589, i8 34)
  %t591 = call ptr @__olang_sb_room(ptr %s21, i64 %t590)
  %t592 = call i64 @__olang_rd_quote(ptr %t591, i64 0, ptr %t588, i64 %t589, i8 34)
  call void @__olang_sb_add(ptr %s21, i64 %t590)
  %t593 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t594 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t593, i64 %t594)
  br label %bb89
bb101:
  %t595 = load i32, ptr %l225, !tbaa !23
  %t596 = icmp eq i32 %t595, 65541
  br i1 %t596, label %bb102, label %bb103
bb102:
  %t598 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t599 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t598, i64 %t599)
  %t600 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t601 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t600, i64 %t601)
  %t602 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l224, i32 0, i32 1
  %t603 = getelementptr { i64, [2 x i64] }, ptr %t602, i32 0, i32 1
  %t604 = getelementptr { { i64, ptr } }, ptr %t603, i32 0, i32 0
  %t605 = load { i64, ptr }, ptr %t604
  %t607 = extractvalue { i64, ptr } %t605, 1
  %t608 = extractvalue { i64, ptr } %t605, 0
  %t609 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t607, i64 %t608, i8 34)
  %t610 = call ptr @__olang_sb_room(ptr %s21, i64 %t609)
  %t611 = call i64 @__olang_rd_quote(ptr %t610, i64 0, ptr %t607, i64 %t608, i8 34)
  call void @__olang_sb_add(ptr %s21, i64 %t609)
  %t612 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t613 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t612, i64 %t613)
  br label %bb89
bb103:
  %t614 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t615 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t614, i64 %t615)
  %t616 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t617 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t616, i64 %t617)
  %t618 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l224, i32 0, i32 1
  %t619 = getelementptr { i64, [2 x i64] }, ptr %t618, i32 0, i32 1
  %t620 = getelementptr { { i64, ptr } }, ptr %t619, i32 0, i32 0
  %t621 = load { i64, ptr }, ptr %t620
  %t623 = extractvalue { i64, ptr } %t621, 1
  %t624 = extractvalue { i64, ptr } %t621, 0
  %t625 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t623, i64 %t624, i8 34)
  %t626 = call ptr @__olang_sb_room(ptr %s21, i64 %t625)
  %t627 = call i64 @__olang_rd_quote(ptr %t626, i64 0, ptr %t623, i64 %t624, i8 34)
  call void @__olang_sb_add(ptr %s21, i64 %t625)
  %t628 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t629 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t628, i64 %t629)
  br label %bb89
bb104:
  store i32 2, ptr %l15, !tbaa !23
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s19)
  br label %bb123
bb105:
  %t630 = load %"std/os:Output", ptr %l195
  store %"std/os:Output" %t630, ptr %l32
  %t631 = getelementptr %"std/os:Output", ptr %l32, i32 0, i32 1
  %t632 = load { i64, ptr }, ptr %t631, !tbaa !27
  %t633 = getelementptr %"std/os:Output", ptr %l32, i32 0, i32 2
  %t634 = load { i64, ptr }, ptr %t633, !tbaa !27
  %t636 = extractvalue { i64, ptr } %t632, 1
  %t637 = extractvalue { i64, ptr } %t632, 0
  %t639 = extractvalue { i64, ptr } %t634, 1
  %t640 = extractvalue { i64, ptr } %t634, 0
  %t641 = add i64 %t637, %t640
  %t642 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t641)
  call void @olang_textcopy(ptr %t642, ptr %t636, i64 %t637)
  %t643 = getelementptr i8, ptr %t642, i64 %t637
  call void @olang_textcopy(ptr %t643, ptr %t639, i64 %t640)
  %t644 = insertvalue { i64, ptr } undef, i64 %t641, 0
  %t645 = insertvalue { i64, ptr } %t644, ptr %t642, 1
  store { i64, ptr } %t645, ptr %l33, !tbaa !27
  %t647 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t649 = call i64 @compiler_2ffix_2ebyHand(ptr %s19, { i64, ptr } %t647)
  store i64 %t649, ptr %l247
  br label %bb106
bb106:
  %t650 = load i64, ptr %l247, !tbaa !24
  store i64 %t650, ptr %l34, !tbaa !24
  %t651 = getelementptr %"std/os:Output", ptr %l32, i32 0, i32 0
  %t652 = load i32, ptr %t651, !tbaa !23
  %t654 = icmp sgt i32 %t652, 1
  br i1 %t654, label %bb107, label %bb108
bb107:
  store i1 true, ptr %l250, !tbaa !21
  br label %bb109
bb108:
  %t656 = load i64, ptr %l34, !tbaa !24
  %t658 = icmp sgt i64 %t656, 0
  store i1 %t658, ptr %l250, !tbaa !21
  br label %bb109
bb109:
  %t660 = load i1, ptr %l250, !tbaa !21
  br i1 %t660, label %bb110, label %bb111
bb110:
  store %olang.scope zeroinitializer, ptr %s23
  %t661 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t662 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t664 = extractvalue { i64, ptr } %t661, 1
  %t665 = extractvalue { i64, ptr } %t661, 0
  %t666 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t667 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t668 = add i64 %t665, %t667
  %t670 = extractvalue { i64, ptr } %t662, 1
  %t671 = extractvalue { i64, ptr } %t662, 0
  %t672 = add i64 %t668, %t671
  %t673 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t672)
  call void @olang_textcopy(ptr %t673, ptr %t664, i64 %t665)
  %t674 = getelementptr i8, ptr %t673, i64 %t665
  call void @olang_textcopy(ptr %t674, ptr %t666, i64 %t667)
  %t675 = getelementptr i8, ptr %t674, i64 %t667
  call void @olang_textcopy(ptr %t675, ptr %t670, i64 %t671)
  %t676 = insertvalue { i64, ptr } undef, i64 %t672, 0
  %t677 = insertvalue { i64, ptr } %t676, ptr %t673, 1
  %t680 = extractvalue { i64, ptr } %t677, 0
  %t681 = extractvalue { i64, ptr } %t677, 1
  %t682 = mul i64 %t680, 1
  %t683 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t682)
  call void @llvm.memcpy.p0.p0.i64(ptr %t683, ptr %t681, i64 %t682, i1 false)
  %t684 = insertvalue { i64, ptr } undef, i64 %t680, 0
  %t685 = insertvalue { i64, ptr } %t684, ptr %t683, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s23, ptr %l4, { i64, ptr } %t685)
  br label %bb112
bb111:
  br label %bb118
bb112:
  %t688 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t690 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s19, ptr %s23, { i64, ptr } %t688, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) })
  store i1 %t690, ptr %l260
  br label %bb113
bb113:
  %t691 = load i1, ptr %l260, !tbaa !21
  %t692 = xor i1 %t691, true
  br i1 %t692, label %bb114, label %bb115
bb114:
  store %olang.scope zeroinitializer, ptr %s25
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %l263, !tbaa !27
  %t695 = load { i64, ptr }, ptr %l263, !tbaa !27
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s25, ptr %l4, { i64, ptr } %t695)
  br label %bb116
bb115:
  br label %bb117
bb116:
  call void @__olang_scope_close(ptr %s25)
  br label %bb117
bb117:
  call void @__olang_scope_close(ptr %s23)
  br label %bb118
bb118:
  %t696 = load i64, ptr %l16, !tbaa !24
  %t697 = load i64, ptr %l34, !tbaa !24
  %t700 = add i64 %t696, %t697
  store i64 %t700, ptr %l16, !tbaa !24
  %t702 = getelementptr %"std/os:Output", ptr %l32, i32 0, i32 0
  %t703 = load i32, ptr %t702, !tbaa !23
  %t705 = icmp sgt i32 %t703, 1
  br i1 %t705, label %bb119, label %bb120
bb119:
  store i32 2, ptr %l15, !tbaa !23
  br label %bb121
bb120:
  br label %bb121
bb121:
  call void @__olang_scope_close(ptr %s19)
  br label %bb122
bb122:
  %t707 = load i64, ptr %l28, !tbaa !24
  %t709 = add i64 %t707, 1
  store i64 %t709, ptr %l28, !tbaa !24
  br label %bb68
bb123:
  %t711 = load i32, ptr %l15, !tbaa !23
  %t713 = icmp ne i32 %t711, 0
  br i1 %t713, label %bb124, label %bb125
bb124:
  call void @__olang_scope_close(ptr %s15)
  br label %bb128
bb125:
  br label %bb126
bb126:
  call void @__olang_scope_close(ptr %s15)
  br label %bb127
bb127:
  %t715 = load i64, ptr %l18, !tbaa !24
  %t717 = add i64 %t715, 1
  store i64 %t717, ptr %l18, !tbaa !24
  br label %bb53
bb128:
  call void @__olang_scope_close(ptr %s14)
  store i64 0, ptr %l35, !tbaa !24
  store i64 0, ptr %l36, !tbaa !24
  %t719 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t721 = extractvalue { i64, ptr } %t719, 0
  store i64 %t721, ptr %l37, !tbaa !24
  store i64 1, ptr %l38, !tbaa !24
  %t723 = load i64, ptr %l37, !tbaa !24
  %t724 = load i64, ptr %l36, !tbaa !24
  %t727 = icmp sgt i64 %t723, %t724
  br i1 %t727, label %bb129, label %bb130
bb129:
  %t729 = load i64, ptr %l38, !tbaa !24
  %t731 = icmp sgt i64 %t729, 0
  br i1 %t731, label %bb131, label %bb132
bb130:
  store i64 0, ptr %l280, !tbaa !24
  br label %bb134
bb131:
  %t733 = load i64, ptr %l37, !tbaa !24
  %t734 = load i64, ptr %l36, !tbaa !24
  %t737 = sub i64 %t733, %t734
  %t738 = load i64, ptr %l38, !tbaa !24
  %t741 = add i64 %t737, %t738
  %t743 = sub i64 %t741, 1
  %t744 = load i64, ptr %l38, !tbaa !24
  %t747 = sdiv i64 %t743, %t744
  store i64 %t747, ptr %l283, !tbaa !24
  br label %bb133
bb132:
  store i64 0, ptr %l283, !tbaa !24
  br label %bb133
bb133:
  %t749 = load i64, ptr %l283, !tbaa !24
  store i64 %t749, ptr %l280, !tbaa !24
  br label %bb134
bb134:
  %t750 = load i64, ptr %l280, !tbaa !24
  store i64 %t750, ptr %l39, !tbaa !24
  store i64 0, ptr %l40, !tbaa !24
  br label %bb135
bb135:
  store %olang.scope zeroinitializer, ptr %s31
  %t751 = load i64, ptr %l40, !tbaa !24
  %t752 = load i64, ptr %l39, !tbaa !24
  %t755 = icmp slt i64 %t751, %t752
  %t757 = xor i1 %t755, true
  br i1 %t757, label %bb136, label %bb137
bb136:
  call void @__olang_scope_close(ptr %s31)
  br label %bb163
bb137:
  br label %bb138
bb138:
  %t759 = load i64, ptr %l36, !tbaa !24
  %t760 = load i64, ptr %l40, !tbaa !24
  %t761 = load i64, ptr %l38, !tbaa !24
  %t764 = mul i64 %t760, %t761
  %t767 = add i64 %t759, %t764
  store i64 %t767, ptr %l41, !tbaa !24
  %t769 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t769, ptr %l302, !tbaa !27
  %t770 = load i64, ptr %l41, !tbaa !24
  %t772 = getelementptr { i64, ptr }, ptr %l302, i32 0, i32 1
  %t773 = load ptr, ptr %t772, !tbaa !27
  %t774 = getelementptr { i64, ptr }, ptr %t773, i64 %t770
  %t775 = load { i64, ptr }, ptr %t774, !tbaa !37
  %t777 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s31, { i64, ptr } %t775)
  %t778 = extractvalue { i32, { i64, ptr } } %t777, 1
  %t779 = extractvalue { i32, { i64, ptr } } %t777, 0
  store i32 %t779, ptr %l306
  %t780 = icmp ne i32 %t779, 0
  br i1 %t780, label %bb140, label %ok.781, !prof !99
ok.781:
  store { i64, ptr } %t778, ptr %l305
  br label %bb139
bb139:
  %t782 = load { i64, ptr }, ptr %l305, !tbaa !27
  store { i64, ptr } %t782, ptr %l301, !tbaa !27
  br label %bb144
bb140:
  %t783 = load i32, ptr %l306, !tbaa !23
  %t784 = ashr i32 %t783, 16
  %t786 = icmp eq i32 %t784, 1
  store i1 %t786, ptr %l308, !tbaa !21
  %t787 = load i32, ptr %l306, !tbaa !23
  %t788 = ashr i32 %t787, 16
  %t790 = icmp eq i32 %t788, 1
  br i1 %t790, label %bb141, label %bb142
bb141:
  call void @__olang_errpay_pop()
  br label %bb142
bb142:
  br label %bb143
bb143:
  call void @__olang_scope_close(ptr %s31)
  br label %bb162
bb144:
  %t792 = load { i64, ptr }, ptr %l301, !tbaa !27
  store { i64, ptr } %t792, ptr %l311, !tbaa !27
  %t794 = load i64, ptr %l41, !tbaa !24
  %t797 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l7, i64 %t794)
  store { i64, ptr } %t797, ptr %l314
  br label %bb145
bb145:
  %t798 = load { i64, ptr }, ptr %l311, !tbaa !27
  %t799 = load { i64, ptr }, ptr %l314, !tbaa !27
  %t800 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s31, ptr %s0, { i64, ptr } %t798, { i64, ptr } %t799)
  store i1 %t800, ptr %l315
  br label %bb146
bb146:
  %t801 = load i1, ptr %l315, !tbaa !21
  br i1 %t801, label %bb147, label %bb148
bb147:
  call void @__olang_scope_close(ptr %s31)
  br label %bb162
bb148:
  br label %bb149
bb149:
  %t802 = load i64, ptr %l35, !tbaa !24
  %t804 = add i64 %t802, 1
  store i64 %t804, ptr %l35, !tbaa !24
  %t806 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t806, ptr %l319, !tbaa !27
  %t807 = load i64, ptr %l41, !tbaa !24
  %t809 = getelementptr { i64, ptr }, ptr %l319, i32 0, i32 1
  %t810 = load ptr, ptr %t809, !tbaa !27
  %t811 = getelementptr { i64, ptr }, ptr %t810, i64 %t807
  %t812 = load { i64, ptr }, ptr %t811, !tbaa !37
  %t814 = extractvalue { i64, ptr } %t812, 1
  %t815 = extractvalue { i64, ptr } %t812, 0
  %t816 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t817 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t818 = add i64 %t815, %t817
  %t819 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t818)
  call void @olang_textcopy(ptr %t819, ptr %t814, i64 %t815)
  %t820 = getelementptr i8, ptr %t819, i64 %t815
  call void @olang_textcopy(ptr %t820, ptr %t816, i64 %t817)
  %t821 = insertvalue { i64, ptr } undef, i64 %t818, 0
  %t822 = insertvalue { i64, ptr } %t821, ptr %t819, 1
  %t825 = extractvalue { i64, ptr } %t822, 0
  %t826 = extractvalue { i64, ptr } %t822, 1
  %t827 = mul i64 %t825, 1
  %t828 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t827)
  call void @llvm.memcpy.p0.p0.i64(ptr %t828, ptr %t826, i64 %t827, i1 false)
  %t829 = insertvalue { i64, ptr } undef, i64 %t825, 0
  %t830 = insertvalue { i64, ptr } %t829, ptr %t828, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s31, ptr %l5, { i64, ptr } %t830)
  br label %bb150
bb150:
  %t833 = load i1, ptr %l0, !tbaa !21
  br i1 %t833, label %bb151, label %bb152
bb151:
  store %olang.scope zeroinitializer, ptr %s35
  %t835 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t835, ptr %l326, !tbaa !27
  %t836 = load i64, ptr %l41, !tbaa !24
  %t838 = getelementptr { i64, ptr }, ptr %l326, i32 0, i32 1
  %t839 = load ptr, ptr %t838, !tbaa !27
  %t840 = getelementptr { i64, ptr }, ptr %t839, i64 %t836
  %t841 = load { i64, ptr }, ptr %t840, !tbaa !37
  store { i64, ptr } %t841, ptr %l328, !tbaa !27
  %t842 = load i64, ptr %l41, !tbaa !24
  %t845 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s35, ptr %l7, i64 %t842)
  store { i64, ptr } %t845, ptr %l331
  br label %bb153
bb152:
  br label %bb161
bb153:
  %t846 = load { i64, ptr }, ptr %l331, !tbaa !27
  %t847 = load { i64, ptr }, ptr %l328, !tbaa !27
  %t849 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s35, { i64, ptr } %t847, { i64, ptr } %t846)
  store i32 %t849, ptr %l333
  %t850 = icmp ne i32 %t849, 0
  br i1 %t850, label %bb155, label %ok.851, !prof !99
ok.851:
  br label %bb154
bb154:
  br label %bb160
bb155:
  %t852 = load i32, ptr %l333, !tbaa !23
  %t853 = ashr i32 %t852, 16
  %t855 = icmp eq i32 %t853, 1
  store i1 %t855, ptr %l335, !tbaa !21
  %t856 = load i32, ptr %l333, !tbaa !23
  %t857 = ashr i32 %t856, 16
  %t859 = icmp eq i32 %t857, 1
  br i1 %t859, label %bb156, label %bb157
bb156:
  call void @__olang_errpay_pop()
  br label %bb157
bb157:
  br label %bb158
bb158:
  store %olang.scope zeroinitializer, ptr %s36
  %t861 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t861, ptr %l339, !tbaa !27
  %t862 = load i64, ptr %l41, !tbaa !24
  %t864 = getelementptr { i64, ptr }, ptr %l339, i32 0, i32 1
  %t865 = load ptr, ptr %t864, !tbaa !27
  %t866 = getelementptr { i64, ptr }, ptr %t865, i64 %t862
  %t867 = load { i64, ptr }, ptr %t866, !tbaa !37
  %t868 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t869 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t871 = extractvalue { i64, ptr } %t867, 1
  %t872 = extractvalue { i64, ptr } %t867, 0
  %t873 = add i64 %t869, %t872
  %t874 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t875 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t876 = add i64 %t873, %t875
  %t877 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t876)
  call void @olang_textcopy(ptr %t877, ptr %t868, i64 %t869)
  %t878 = getelementptr i8, ptr %t877, i64 %t869
  call void @olang_textcopy(ptr %t878, ptr %t871, i64 %t872)
  %t879 = getelementptr i8, ptr %t878, i64 %t872
  call void @olang_textcopy(ptr %t879, ptr %t874, i64 %t875)
  %t880 = insertvalue { i64, ptr } undef, i64 %t876, 0
  %t881 = insertvalue { i64, ptr } %t880, ptr %t877, 1
  %t884 = extractvalue { i64, ptr } %t881, 0
  %t885 = extractvalue { i64, ptr } %t881, 1
  %t886 = mul i64 %t884, 1
  %t887 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t886)
  call void @llvm.memcpy.p0.p0.i64(ptr %t887, ptr %t885, i64 %t886, i1 false)
  %t888 = insertvalue { i64, ptr } undef, i64 %t884, 0
  %t889 = insertvalue { i64, ptr } %t888, ptr %t887, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s36, ptr %l4, { i64, ptr } %t889)
  br label %bb159
bb159:
  call void @__olang_scope_close(ptr %s36)
  br label %bb160
bb160:
  call void @__olang_scope_close(ptr %s35)
  br label %bb161
bb161:
  call void @__olang_scope_close(ptr %s31)
  br label %bb162
bb162:
  %t892 = load i64, ptr %l40, !tbaa !24
  %t894 = add i64 %t892, 1
  store i64 %t894, ptr %l40, !tbaa !24
  br label %bb135
bb163:
  %t896 = load i64, ptr %l16, !tbaa !24
  %t898 = icmp sgt i64 %t896, 0
  br i1 %t898, label %bb164, label %bb165
bb164:
  %t900 = load i32, ptr %l15, !tbaa !23
  %t902 = icmp eq i32 %t900, 0
  store i1 %t902, ptr %l349, !tbaa !21
  br label %bb166
bb165:
  store i1 false, ptr %l349, !tbaa !21
  br label %bb166
bb166:
  %t904 = load i1, ptr %l349, !tbaa !21
  br i1 %t904, label %bb167, label %bb168
bb167:
  store %olang.scope zeroinitializer, ptr %s39
  %t905 = load i64, ptr %l16, !tbaa !24
  %t907 = icmp eq i64 %t905, 1
  br i1 %t907, label %bb169, label %bb170
bb168:
  br label %bb173
bb169:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) }, ptr %l354, !tbaa !27
  br label %bb171
bb170:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) }, ptr %l354, !tbaa !27
  br label %bb171
bb171:
  %t909 = load { i64, ptr }, ptr %l354, !tbaa !27
  %t910 = load i64, ptr %l16, !tbaa !24
  %t912 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t913 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t915 = call i64 @__olang_fmt_i64(ptr null, i64 %t910)
  %t916 = add i64 %t913, %t915
  %t917 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t918 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t919 = add i64 %t916, %t918
  %t921 = extractvalue { i64, ptr } %t909, 1
  %t922 = extractvalue { i64, ptr } %t909, 0
  %t923 = add i64 %t919, %t922
  %t924 = extractvalue { i64, ptr } { i64 89, ptr getelementptr inbounds (<{ i64, [89 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t925 = extractvalue { i64, ptr } { i64 89, ptr getelementptr inbounds (<{ i64, [89 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t926 = add i64 %t923, %t925
  %t927 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t926)
  call void @olang_textcopy(ptr %t927, ptr %t912, i64 %t913)
  %t928 = getelementptr i8, ptr %t927, i64 %t913
  %t929 = call i64 @__olang_fmt_i64(ptr %t928, i64 %t910)
  %t930 = getelementptr i8, ptr %t928, i64 %t915
  call void @olang_textcopy(ptr %t930, ptr %t917, i64 %t918)
  %t931 = getelementptr i8, ptr %t930, i64 %t918
  call void @olang_textcopy(ptr %t931, ptr %t921, i64 %t922)
  %t932 = getelementptr i8, ptr %t931, i64 %t922
  call void @olang_textcopy(ptr %t932, ptr %t924, i64 %t925)
  %t933 = insertvalue { i64, ptr } undef, i64 %t926, 0
  %t934 = insertvalue { i64, ptr } %t933, ptr %t927, 1
  %t937 = extractvalue { i64, ptr } %t934, 0
  %t938 = extractvalue { i64, ptr } %t934, 1
  %t939 = mul i64 %t937, 1
  %t940 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t939)
  call void @llvm.memcpy.p0.p0.i64(ptr %t940, ptr %t938, i64 %t939, i1 false)
  %t941 = insertvalue { i64, ptr } undef, i64 %t937, 0
  %t942 = insertvalue { i64, ptr } %t941, ptr %t940, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s39, ptr %l4, { i64, ptr } %t942)
  br label %bb172
bb172:
  call void @__olang_scope_close(ptr %s39)
  br label %bb173
bb173:
  %t946 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l5)
  store i32 %t946, ptr %l362
  %t947 = icmp ne i32 %t946, 0
  br i1 %t947, label %bb175, label %ok.948, !prof !99
ok.948:
  br label %bb174
bb174:
  br label %bb179
bb175:
  %t949 = load i32, ptr %l362, !tbaa !23
  %t950 = ashr i32 %t949, 16
  %t952 = icmp eq i32 %t950, 1
  store i1 %t952, ptr %l364, !tbaa !21
  %t953 = load i32, ptr %l362, !tbaa !23
  %t954 = ashr i32 %t953, 16
  %t956 = icmp eq i32 %t954, 1
  br i1 %t956, label %bb176, label %bb177
bb176:
  call void @__olang_errpay_pop()
  br label %bb177
bb177:
  br label %bb178
bb178:
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb179:
  %t960 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l4)
  store i32 %t960, ptr %l369
  %t961 = icmp ne i32 %t960, 0
  br i1 %t961, label %bb181, label %ok.962, !prof !99
ok.962:
  br label %bb180
bb180:
  br label %bb185
bb181:
  %t963 = load i32, ptr %l369, !tbaa !23
  %t964 = ashr i32 %t963, 16
  %t966 = icmp eq i32 %t964, 1
  store i1 %t966, ptr %l371, !tbaa !21
  %t967 = load i32, ptr %l369, !tbaa !23
  %t968 = ashr i32 %t967, 16
  %t970 = icmp eq i32 %t968, 1
  br i1 %t970, label %bb182, label %bb183
bb182:
  call void @__olang_errpay_pop()
  br label %bb183
bb183:
  br label %bb184
bb184:
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb185:
  %t973 = load i32, ptr %l15, !tbaa !23
  %t975 = icmp ne i32 %t973, 0
  br i1 %t975, label %bb186, label %bb187
bb186:
  %t977 = load i32, ptr %l15, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t977, ptr %rv
  br label %ret
bb187:
  br label %bb188
bb188:
  %t979 = load i1, ptr %l0, !tbaa !21
  br i1 %t979, label %bb189, label %bb190
bb189:
  %t981 = load i64, ptr %l35, !tbaa !24
  %t983 = icmp sgt i64 %t981, 0
  store i1 %t983, ptr %l379, !tbaa !21
  br label %bb191
bb190:
  store i1 false, ptr %l379, !tbaa !21
  br label %bb191
bb191:
  %t985 = load i1, ptr %l379, !tbaa !21
  br i1 %t985, label %bb192, label %bb193
bb192:
  store i1 true, ptr %l382, !tbaa !21
  br label %bb194
bb193:
  %t986 = load i64, ptr %l16, !tbaa !24
  %t988 = icmp sgt i64 %t986, 0
  store i1 %t988, ptr %l382, !tbaa !21
  br label %bb194
bb194:
  %t990 = load i1, ptr %l382, !tbaa !21
  br i1 %t990, label %bb195, label %bb196
bb195:
  store i32 1, ptr %l385, !tbaa !23
  br label %bb197
bb196:
  store i32 0, ptr %l385, !tbaa !23
  br label %bb197
bb197:
  call void @__olang_scope_close(ptr %s0)
  %t991 = load i32, ptr %l385, !tbaa !23
  store i32 %t991, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ffix_2eOrder(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca [36 x { i64, ptr }]
  %l28 = alloca i64
  %l31 = alloca i64
  %l51 = alloca i1
  %l53 = alloca i1
  %l62 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l64 = alloca i64
  %l65 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l0
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t4 = insertvalue [2 x { i64, ptr }] %t3, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t6 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store [2 x { i64, ptr }] %t4, ptr %t6
  store ptr %t6, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t8 = load ptr, ptr %l1
  store i64 2, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l2, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  br label %bb25
bb4:
  br label %bb5
bb5:
  %t19 = load ptr, ptr %l1
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = getelementptr [2 x { i64, ptr }], ptr %t19, i64 0, i64 %t20
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !37
  store { i64, ptr } %t24, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l23, ptr @G_2ecompiler_2ffix_2eToolNames, i64 576, i1 false)
  %t26 = load [36 x { i64, ptr }], ptr %l23
  store i64 36, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t28 = load i64, ptr %l6, !tbaa !24
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = icmp sgt i64 %t28, %t29
  br i1 %t32, label %bb6, label %bb7
bb6:
  %t34 = load i64, ptr %l7, !tbaa !24
  %t36 = icmp sgt i64 %t34, 0
  br i1 %t36, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb11
bb8:
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = sub i64 %t38, %t39
  %t43 = load i64, ptr %l7, !tbaa !24
  %t46 = add i64 %t42, %t43
  %t48 = sub i64 %t46, 1
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = sdiv i64 %t48, %t49
  store i64 %t52, ptr %l31, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb10
bb10:
  %t54 = load i64, ptr %l31, !tbaa !24
  store i64 %t54, ptr %l28, !tbaa !24
  br label %bb11
bb11:
  %t55 = load i64, ptr %l28, !tbaa !24
  store i64 %t55, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t56 = load i64, ptr %l9, !tbaa !24
  %t57 = load i64, ptr %l8, !tbaa !24
  %t60 = icmp slt i64 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb14:
  br label %bb15
bb15:
  %t64 = load i64, ptr %l5, !tbaa !24
  %t65 = load i64, ptr %l9, !tbaa !24
  %t66 = load i64, ptr %l7, !tbaa !24
  %t69 = mul i64 %t65, %t66
  %t72 = add i64 %t64, %t69
  store i64 %t72, ptr %l10, !tbaa !24
  %t74 = load i64, ptr %l10, !tbaa !24
  %t76 = getelementptr [36 x i64], ptr @G_2ecompiler_2ffix_2eToolKinds, i64 0, i64 %t74
  %t77 = load i64, ptr %t76, !tbaa !34
  %t79 = call i1 @compiler_2ffix_2edriven(i64 %t77)
  store i1 %t79, ptr %l51
  br label %bb16
bb16:
  %t80 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t81 = load ptr, ptr @__olang_prog_scope
  %t83 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t81, ptr %s4, { i64, ptr } %t80, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d36, i32 0, i32 1) })
  store i1 %t83, ptr %l53
  br label %bb17
bb17:
  %t84 = load i1, ptr %l51, !tbaa !21
  %t85 = load i1, ptr %l53, !tbaa !21
  %t86 = icmp eq i1 %t84, %t85
  br i1 %t86, label %bb18, label %bb19
bb18:
  %t88 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l0, i64 %t88)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb22:
  %t91 = load i64, ptr %l9, !tbaa !24
  %t93 = add i64 %t91, 1
  store i64 %t93, ptr %l9, !tbaa !24
  br label %bb12
bb23:
  br label %bb24
bb24:
  %t95 = load i64, ptr %l2, !tbaa !24
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l2, !tbaa !24
  br label %bb2
bb25:
  call void @__olang_scope_close(ptr %s1)
  %t100 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %l0)
  store { i64, ptr } %t100, ptr %l62
  br label %bb26
bb26:
  %t101 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t101, ptr %l63, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 0
  store i64 %t103, ptr %l64, !tbaa !24
  %t104 = load i64, ptr %l64, !tbaa !24
  %t105 = mul i64 %t104, 8
  %t106 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t105)
  %t107 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  store { i64, ptr } %t108, ptr %l65, !tbaa !27
  %t109 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = load i64, ptr %l64, !tbaa !24
  %t114 = mul i64 %t113, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t110, ptr %t112, i64 %t114, i1 false)
  %t115 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t115, ptr %l63, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t116 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t116, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ffix_2eToolsDir(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l8 = alloca i1
  %l13 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d37, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l4
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  store { i64, ptr } %t2, ptr %l3
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  br label %bb6
bb2:
  %t7 = load i32, ptr %l4, !tbaa !23
  %t8 = ashr i32 %t7, 16
  %t10 = icmp eq i32 %t8, 1
  br i1 %t10, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l2, !tbaa !27
  br label %bb6
bb6:
  %t12 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t12, ptr %l1, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t15 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t13, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d39, i32 0, i32 1) })
  store i1 %t15, ptr %l8
  br label %bb7
bb7:
  %t16 = load i1, ptr %l8, !tbaa !21
  %t17 = xor i1 %t16, true
  br i1 %t17, label %bb8, label %bb9
bb8:
  %t19 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = extractvalue { i64, ptr } %t19, 0
  %t23 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t21, i64 %t22)
  %t24 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t25, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t29 = call { i64, ptr } @std_2ffilepath_2eDir(ptr %v0, ptr %s0, { i64, ptr } %a0)
  store { i64, ptr } %t29, ptr %l13
  br label %bb11
bb11:
  %t30 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t30, 1
  %t32 = extractvalue { i64, ptr } %t30, 0
  %t33 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  %t35 = add i64 %t32, %t34
  %t36 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t35)
  call void @olang_textcopy(ptr %t36, ptr %t31, i64 %t32)
  %t37 = getelementptr i8, ptr %t36, i64 %t32
  call void @olang_textcopy(ptr %t37, ptr %t33, i64 %t34)
  %t38 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t36, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t39, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ffix_2earguments(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %lp5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 32, i64 8)
  store ptr %t2, ptr %lp5
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  %t4 = load ptr, ptr %lp5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load ptr, ptr %lp5
  %t8 = extractvalue { i64, ptr } %a0, 1
  %t9 = extractvalue { i64, ptr } %a0, 0
  %t10 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t9)
  call void @olang_textcopy(ptr %t10, ptr %t8, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t15 = extractvalue { i64, ptr } %t12, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t5, { i64, ptr } %t19)
  br label %bb2
bb2:
  %t22 = load i64, ptr %l1, !tbaa !24
  %t23 = load i64, ptr @G_2ecompiler_2ffix_2eStdTool, !tbaa !24
  %t26 = icmp eq i64 %t22, %t23
  br i1 %t26, label %bb3, label %bb4
bb3:
  %t28 = load ptr, ptr %lp5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t28, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d41, i32 0, i32 1) })
  br label %bb5
bb4:
  %t30 = load i64, ptr %l1, !tbaa !24
  %t31 = load i64, ptr @G_2ecompiler_2ffix_2eDrivenOpt, !tbaa !24
  %t34 = icmp eq i64 %t30, %t31
  br i1 %t34, label %bb7, label %bb8
bb5:
  %t36 = load ptr, ptr %lp5
  %t39 = extractvalue { i64, ptr } %a3, 1
  %t40 = extractvalue { i64, ptr } %a3, 0
  %t41 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t40)
  call void @olang_textcopy(ptr %t41, ptr %t39, i64 %t40)
  %t42 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t46 = extractvalue { i64, ptr } %t43, 1
  %t47 = mul i64 %t45, 1
  %t48 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t47)
  call void @llvm.memcpy.p0.p0.i64(ptr %t48, ptr %t46, i64 %t47, i1 false)
  %t49 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t36, { i64, ptr } %t50)
  br label %bb6
bb6:
  br label %bb16
bb7:
  %t53 = load ptr, ptr %lp5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t53, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d42, i32 0, i32 1) })
  br label %bb9
bb8:
  %t55 = load i64, ptr %l1, !tbaa !24
  %t56 = load i64, ptr @G_2ecompiler_2ffix_2eDrivenArg, !tbaa !24
  %t59 = icmp eq i64 %t55, %t56
  br i1 %t59, label %bb11, label %bb12
bb9:
  %t61 = load ptr, ptr %lp5
  %t62 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t62, 1
  %t65 = extractvalue { i64, ptr } %t62, 0
  %t66 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t65)
  call void @olang_textcopy(ptr %t66, ptr %t64, i64 %t65)
  %t67 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t71 = extractvalue { i64, ptr } %t68, 1
  %t72 = mul i64 %t70, 1
  %t73 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t72)
  call void @llvm.memcpy.p0.p0.i64(ptr %t73, ptr %t71, i64 %t72, i1 false)
  %t74 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t61, { i64, ptr } %t75)
  br label %bb10
bb10:
  br label %bb15
bb11:
  %t78 = load ptr, ptr %lp5
  %t79 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t79, 1
  %t82 = extractvalue { i64, ptr } %t79, 0
  %t83 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t82)
  call void @olang_textcopy(ptr %t83, ptr %t81, i64 %t82)
  %t84 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t83, 1
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t88 = extractvalue { i64, ptr } %t85, 1
  %t89 = mul i64 %t87, 1
  %t90 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t89)
  call void @llvm.memcpy.p0.p0.i64(ptr %t90, ptr %t88, i64 %t89, i1 false)
  %t91 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t90, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t78, { i64, ptr } %t92)
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  store { i64, ptr } %a4, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t97 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  store i64 %t99, ptr %l8, !tbaa !24
  br label %bb17
bb17:
  %t101 = load i64, ptr %l7, !tbaa !24
  %t102 = load i64, ptr %l8, !tbaa !24
  %t105 = icmp slt i64 %t101, %t102
  %t107 = xor i1 %t105, true
  br i1 %t107, label %bb18, label %bb19
bb18:
  br label %bb23
bb19:
  br label %bb20
bb20:
  %t109 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t109, ptr %l45, !tbaa !27
  %t110 = load i64, ptr %l7, !tbaa !24
  %t112 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr { i64, ptr }, ptr %t113, i64 %t110
  %t115 = load { i64, ptr }, ptr %t114, !tbaa !37
  %t117 = load ptr, ptr %lp5
  %t120 = extractvalue { i64, ptr } %t115, 1
  %t121 = extractvalue { i64, ptr } %t115, 0
  %t122 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t121)
  call void @olang_textcopy(ptr %t122, ptr %t120, i64 %t121)
  %t123 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  %t126 = extractvalue { i64, ptr } %t124, 0
  %t127 = extractvalue { i64, ptr } %t124, 1
  %t128 = mul i64 %t126, 1
  %t129 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t128)
  call void @llvm.memcpy.p0.p0.i64(ptr %t129, ptr %t127, i64 %t128, i1 false)
  %t130 = insertvalue { i64, ptr } undef, i64 %t126, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t129, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t117, { i64, ptr } %t131)
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t134 = load i64, ptr %l7, !tbaa !24
  %t136 = add i64 %t134, 1
  store i64 %t136, ptr %l7, !tbaa !24
  br label %bb17
bb23:
  %t138 = load ptr, ptr %lp5
  %t140 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v4, ptr %v4, ptr %t138)
  store { i64, ptr } %t140, ptr %l55
  br label %bb24
bb24:
  %t141 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t141, ptr %l56, !tbaa !27
  %t142 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t142, 0
  store i64 %t143, ptr %l57, !tbaa !24
  %t144 = load i64, ptr %l57, !tbaa !24
  %t145 = mul i64 %t144, 16
  %t146 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t145)
  %t147 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  store { i64, ptr } %t148, ptr %l58, !tbaa !27
  %t149 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = load i64, ptr %l57, !tbaa !24
  %t154 = mul i64 %t153, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t150, ptr %t152, i64 %t154, i1 false)
  %t155 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t155, ptr %l56, !tbaa !27
  %t156 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t156, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ffix_2ebuiltBy(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/os:FileInfo"
  %l2 = alloca %"std/os:FileInfo"
  %l4 = alloca %"std/os:FileInfo"
  %l5 = alloca i32
  %l7 = alloca i1
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %v0, { i64, ptr } %t1)
  %t4 = extractvalue { i32, %"std/os:FileInfo" } %t3, 1
  %t5 = extractvalue { i32, %"std/os:FileInfo" } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store %"std/os:FileInfo" %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load %"std/os:FileInfo", ptr %l4
  store %"std/os:FileInfo" %t8, ptr %l2
  br label %bb6
bb2:
  %t9 = load i32, ptr %l5, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  store i1 %t12, ptr %l7, !tbaa !21
  %t13 = load i32, ptr %l5, !tbaa !23
  %t14 = ashr i32 %t13, 16
  %t16 = icmp eq i32 %t14, 1
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  %t18 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 1
  %t21 = extractvalue { i64, ptr } %t18, 0
  %t22 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t21)
  call void @olang_textcopy(ptr %t22, ptr %t20, i64 %t21)
  %t23 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  store { i64, ptr } %t24, ptr %rv
  br label %ret
bb6:
  %t26 = load %"std/os:FileInfo", ptr %l2
  store %"std/os:FileInfo" %t26, ptr %l1
  %t27 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t28 = getelementptr %"std/os:FileInfo", ptr %l1, i32 0, i32 1
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = getelementptr %"std/os:FileInfo", ptr %l1, i32 0, i32 2
  %t31 = load i64, ptr %t30, !tbaa !24
  %t33 = extractvalue { i64, ptr } %t27, 1
  %t34 = extractvalue { i64, ptr } %t27, 0
  %t35 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t37 = add i64 %t34, %t36
  %t39 = call i64 @__olang_fmt_i64(ptr null, i64 %t29)
  %t40 = add i64 %t37, %t39
  %t41 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t42 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t43 = add i64 %t40, %t42
  %t45 = call i64 @__olang_fmt_i64(ptr null, i64 %t31)
  %t46 = add i64 %t43, %t45
  %t47 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t48 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t49 = add i64 %t46, %t48
  %t50 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t49)
  call void @olang_textcopy(ptr %t50, ptr %t33, i64 %t34)
  %t51 = getelementptr i8, ptr %t50, i64 %t34
  call void @olang_textcopy(ptr %t51, ptr %t35, i64 %t36)
  %t52 = getelementptr i8, ptr %t51, i64 %t36
  %t53 = call i64 @__olang_fmt_i64(ptr %t52, i64 %t29)
  %t54 = getelementptr i8, ptr %t52, i64 %t39
  call void @olang_textcopy(ptr %t54, ptr %t41, i64 %t42)
  %t55 = getelementptr i8, ptr %t54, i64 %t42
  %t56 = call i64 @__olang_fmt_i64(ptr %t55, i64 %t31)
  %t57 = getelementptr i8, ptr %t55, i64 %t45
  call void @olang_textcopy(ptr %t57, ptr %t47, i64 %t48)
  %t58 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t50, 1
  store { i64, ptr } %t59, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ffix_2ebyHand(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca %"std/prelude/text:LineIter"
  %l4 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/text:LineIter"
  %l7 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l12 = alloca i1
  %l14 = alloca i1
  %l18 = alloca i1
  %l20 = alloca i1
  %l22 = alloca i1
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  store i1 false, ptr %l2, !tbaa !21
  %t3 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store %"std/prelude/text:LineIter" %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load %"std/prelude/text:LineIter", ptr %l6
  store %"std/prelude/text:LineIter" %t4, ptr %l3
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t6 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v0, ptr %l3)
  %t7 = extractvalue { i32, { i64, ptr } } %t6, 1
  %t8 = extractvalue { i32, { i64, ptr } } %t6, 0
  store i32 %t8, ptr %l10
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb4, label %ok.10, !prof !99
ok.10:
  store { i64, ptr } %t7, ptr %l9
  br label %bb3
bb3:
  %t11 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t11, ptr %l7, !tbaa !27
  br label %bb6
bb4:
  %t12 = load i32, ptr %l10, !tbaa !23
  %t13 = ashr i32 %t12, 16
  %t15 = icmp eq i32 %t13, 1
  store i1 %t15, ptr %l12, !tbaa !21
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb6:
  %t16 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t16, ptr %l4, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t17, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d45, i32 0, i32 1) })
  store i1 %t19, ptr %l14
  br label %bb7
bb7:
  %t20 = load i1, ptr %l14, !tbaa !21
  br i1 %t20, label %bb8, label %bb9
bb8:
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = add i64 %t21, 1
  store i64 %t23, ptr %l1, !tbaa !24
  br label %bb21
bb9:
  store %olang.scope zeroinitializer, ptr %s4
  %t25 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t25, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d46, i32 0, i32 1) })
  store i1 %t27, ptr %l18
  br label %bb10
bb10:
  %t28 = load i1, ptr %l18, !tbaa !21
  br i1 %t28, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb20
bb12:
  store %olang.scope zeroinitializer, ptr %s6
  %t29 = load i1, ptr %l2, !tbaa !21
  br i1 %t29, label %bb13, label %bb14
bb13:
  %t31 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t33 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s6, { i64, ptr } %t31, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d47, i32 0, i32 1) })
  store i1 %t33, ptr %l22
  br label %bb15
bb14:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb16
bb15:
  %t34 = load i1, ptr %l22, !tbaa !21
  store i1 %t34, ptr %l20, !tbaa !21
  br label %bb16
bb16:
  %t35 = load i1, ptr %l20, !tbaa !21
  br i1 %t35, label %bb17, label %bb18
bb17:
  %t36 = load i64, ptr %l1, !tbaa !24
  %t38 = add i64 %t36, 1
  store i64 %t38, ptr %l1, !tbaa !24
  br label %bb19
bb18:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s6)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  br label %bb2
bb23:
  %t40 = load i64, ptr %l1, !tbaa !24
  store i64 %t40, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffix_2edriven(i64 %a0) #0 {
entry:
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i64, ptr @G_2ecompiler_2ffix_2eDrivenOpt, !tbaa !24
  %t5 = icmp sge i64 %a0, %t2
  store i1 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ffix_2eensureBuilt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, ptr %a5) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca [2 x { i64, ptr }]
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca [2 x { i64, ptr }]
  %l11 = alloca i64
  %l12 = alloca [2 x { i64, ptr }]
  %l13 = alloca i64
  %l14 = alloca { i32, { i64, [2 x i64] } }
  %l15 = alloca { i64, ptr }
  %l16 = alloca [2 x { i64, ptr }]
  %l17 = alloca { i64, ptr }
  %l18 = alloca [2 x { i64, ptr }]
  %l19 = alloca [5 x { i64, ptr }]
  %l20 = alloca { i32, { i64, [2 x i64] } }
  %l21 = alloca %"std/os:Output"
  %l22 = alloca { i32, { i64, [2 x i64] } }
  %l30 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i32
  %l40 = alloca i64
  %l45 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca i64
  %l50 = alloca i64
  %l55 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca i64
  %l60 = alloca i64
  %l61 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l65 = alloca i1
  %l66 = alloca i1
  %l68 = alloca i64
  %l71 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l77 = alloca i32
  %l79 = alloca i1
  %l80 = alloca { i32, { i64, [2 x i64] } }
  %l81 = alloca { i32, { i64, [2 x i64] } }
  %l82 = alloca i32
  %l87 = alloca { i32, { i64, [2 x i64] } }
  %l88 = alloca { i32, { i64, [2 x i64] } }
  %l91 = alloca ptr
  %l92 = alloca { i64, ptr }
  %l93 = alloca { i32, { i64, [2 x i64] } }
  %l95 = alloca { i32, { i64, [2 x i64] } }
  %l96 = alloca i32
  %l111 = alloca { i64, ptr }
  %l122 = alloca { i64, ptr }
  %l123 = alloca %"std/os:Output"
  %l124 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l133 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l140 = alloca %"std/os:Output"
  %l141 = alloca i32
  %l143 = alloca i1
  %l144 = alloca { i32, { i64, [2 x i64] } }
  %l145 = alloca { i32, { i64, [2 x i64] } }
  %l146 = alloca i32
  %l151 = alloca { i32, { i64, [2 x i64] } }
  %l152 = alloca { i32, { i64, [2 x i64] } }
  %l155 = alloca ptr
  %l156 = alloca { i64, ptr }
  %l157 = alloca { i32, { i64, [2 x i64] } }
  %l159 = alloca { i32, { i64, [2 x i64] } }
  %l160 = alloca i32
  %l175 = alloca { i64, ptr }
  %l178 = alloca i32
  %l180 = alloca i32
  %l182 = alloca i1
  %l194 = alloca i32
  %l196 = alloca i32
  %l198 = alloca i1
  %l203 = alloca i32
  %l205 = alloca i1
  %l206 = alloca { i32, { i64, [2 x i64] } }
  %l207 = alloca { i32, { i64, [2 x i64] } }
  %l208 = alloca i32
  %l213 = alloca { i32, { i64, [2 x i64] } }
  %l214 = alloca { i32, { i64, [2 x i64] } }
  %l217 = alloca ptr
  %l218 = alloca { i64, ptr }
  %l219 = alloca { i32, { i64, [2 x i64] } }
  %l221 = alloca { i32, { i64, [2 x i64] } }
  %l222 = alloca i32
  %l237 = alloca { i64, ptr }
  %l240 = alloca i32
  %l242 = alloca i32
  %l244 = alloca i1
  %l247 = alloca { i64, ptr }
  %l249 = alloca { i64, ptr }
  %l252 = alloca i32
  %l254 = alloca i1
  %l258 = alloca i32
  %l260 = alloca i1
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.builder
  %s6room = alloca [64 x i8], align 8
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.builder
  %s10room = alloca [64 x i8], align 8
  %s13 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.builder
  %s18room = alloca [64 x i8], align 8
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t3 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %t2, 1
  %t7 = extractvalue { i64, ptr } %t2, 0
  %t8 = add i64 %t4, %t7
  %t9 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t8)
  call void @olang_textcopy(ptr %t9, ptr %t3, i64 %t4)
  %t10 = getelementptr i8, ptr %t9, i64 %t4
  call void @olang_textcopy(ptr %t10, ptr %t6, i64 %t7)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t9, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t15 = extractvalue { i64, ptr } %t12, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  %t21 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t1, 0
  %t23 = insertvalue [2 x { i64, ptr }] %t21, { i64, ptr } %t19, 1
  store [2 x { i64, ptr }] %t23, ptr %l6
  %t26 = insertvalue { i64, ptr } undef, i64 2, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %l6, 1
  %t29 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t27)
  store { i64, ptr } %t29, ptr %l30
  br label %bb1
bb1:
  %t30 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t30, ptr %l7, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 1
  %t34 = extractvalue { i64, ptr } %t31, 0
  %t35 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t37 = add i64 %t34, %t36
  %t38 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t37)
  call void @olang_textcopy(ptr %t38, ptr %t33, i64 %t34)
  %t39 = getelementptr i8, ptr %t38, i64 %t34
  call void @olang_textcopy(ptr %t39, ptr %t35, i64 %t36)
  %t40 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t38, 1
  store { i64, ptr } %t41, ptr %l8, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t45 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } %t43)
  %t46 = extractvalue { i32, { i64, ptr } } %t45, 1
  %t47 = extractvalue { i32, { i64, ptr } } %t45, 0
  store i32 %t47, ptr %l36
  %t48 = icmp ne i32 %t47, 0
  br i1 %t48, label %bb3, label %ok.49, !prof !99
ok.49:
  store { i64, ptr } %t46, ptr %l35
  br label %bb2
bb2:
  %t50 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t50, ptr %l33, !tbaa !27
  br label %bb7
bb3:
  %t51 = load i32, ptr %l36, !tbaa !23
  %t52 = ashr i32 %t51, 16
  %t54 = icmp eq i32 %t52, 1
  br i1 %t54, label %bb4, label %bb5
bb4:
  call void @__olang_errpay_pop()
  br label %bb5
bb5:
  br label %bb6
bb6:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d50, i32 0, i32 1) }, ptr %l33, !tbaa !27
  br label %bb7
bb7:
  %t56 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t56, ptr %l9, !tbaa !27
  %t57 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t59 = call i64 @compiler_2ffix_2enewest(ptr %v4, { i64, ptr } %t57)
  store i64 %t59, ptr %l40
  br label %bb8
bb8:
  %t60 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t62 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t60, 0
  %t63 = insertvalue [2 x { i64, ptr }] %t62, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  store [2 x { i64, ptr }] %t63, ptr %l10
  %t66 = insertvalue { i64, ptr } undef, i64 2, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %l10, 1
  %t69 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t67)
  store { i64, ptr } %t69, ptr %l45
  br label %bb9
bb9:
  %t70 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 0
  %t72 = extractvalue { i64, ptr } %t70, 1
  %t73 = mul i64 %t71, 1
  %t74 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t73)
  call void @llvm.memcpy.p0.p0.i64(ptr %t74, ptr %t72, i64 %t73, i1 false)
  %t75 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  %t78 = call i64 @compiler_2ffix_2enewest(ptr %s0, { i64, ptr } %t76)
  store i64 %t78, ptr %l47
  br label %bb10
bb10:
  %t79 = load i64, ptr %l40, !tbaa !24
  %t80 = load i64, ptr %l47, !tbaa !24
  %t81 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t79, i64 %t80)
  store i64 %t81, ptr %l48
  br label %bb11
bb11:
  %t82 = load i64, ptr %l48, !tbaa !24
  store i64 %t82, ptr %l11, !tbaa !24
  %t83 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t85 = call i64 @compiler_2ffix_2enewest(ptr %v1, { i64, ptr } %t83)
  store i64 %t85, ptr %l50
  br label %bb12
bb12:
  %t86 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t88 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t86, 0
  %t89 = insertvalue [2 x { i64, ptr }] %t88, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  store [2 x { i64, ptr }] %t89, ptr %l12
  %t92 = insertvalue { i64, ptr } undef, i64 2, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %l12, 1
  %t95 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t93)
  store { i64, ptr } %t95, ptr %l55
  br label %bb13
bb13:
  %t96 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 0
  %t98 = extractvalue { i64, ptr } %t96, 1
  %t99 = mul i64 %t97, 1
  %t100 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t99)
  call void @llvm.memcpy.p0.p0.i64(ptr %t100, ptr %t98, i64 %t99, i1 false)
  %t101 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t100, 1
  %t104 = call i64 @compiler_2ffix_2enewest(ptr %s0, { i64, ptr } %t102)
  store i64 %t104, ptr %l57
  br label %bb14
bb14:
  %t105 = load i64, ptr %l50, !tbaa !24
  %t106 = load i64, ptr %l57, !tbaa !24
  %t107 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t105, i64 %t106)
  store i64 %t107, ptr %l58
  br label %bb15
bb15:
  %t108 = load i64, ptr %l11, !tbaa !24
  %t109 = load i64, ptr %l58, !tbaa !24
  %t111 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t109, i64 %t108)
  store i64 %t111, ptr %l60
  br label %bb16
bb16:
  %t112 = load i64, ptr %l60, !tbaa !24
  store i64 %t112, ptr %l13, !tbaa !24
  %t113 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t113, ptr %l61, !tbaa !27
  %t114 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t116 = call { i64, ptr } @compiler_2ffix_2ebuiltBy(ptr %v0, ptr %s0, { i64, ptr } %t114)
  store { i64, ptr } %t116, ptr %l63
  br label %bb17
bb17:
  %t117 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t117, 0
  %t119 = extractvalue { i64, ptr } %t117, 1
  %t120 = mul i64 %t118, 1
  %t121 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t120)
  call void @llvm.memcpy.p0.p0.i64(ptr %t121, ptr %t119, i64 %t120, i1 false)
  %t122 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t121, 1
  %t124 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t126 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t124, { i64, ptr } %t123)
  store i1 %t126, ptr %l65
  br label %bb18
bb18:
  %t127 = load i1, ptr %l65, !tbaa !21
  br i1 %t127, label %bb19, label %bb20
bb19:
  %t128 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t130 = call i64 @compiler_2ffix_2emtime(ptr %s0, { i64, ptr } %t128)
  store i64 %t130, ptr %l68
  br label %bb21
bb20:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb22
bb21:
  %t131 = load i64, ptr %l13, !tbaa !24
  %t132 = load i64, ptr %l68, !tbaa !24
  %t134 = icmp sgt i64 %t132, %t131
  store i1 %t134, ptr %l66, !tbaa !21
  br label %bb22
bb22:
  %t136 = load i1, ptr %l66, !tbaa !21
  br i1 %t136, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t137 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t138 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t139 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t140 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t142 = extractvalue { i64, ptr } %t138, 1
  %t143 = extractvalue { i64, ptr } %t138, 0
  %t144 = add i64 %t140, %t143
  %t145 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d54, i32 0, i32 1) }, 1
  %t146 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d54, i32 0, i32 1) }, 0
  %t147 = add i64 %t144, %t146
  %t148 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t147)
  call void @olang_textcopy(ptr %t148, ptr %t139, i64 %t140)
  %t149 = getelementptr i8, ptr %t148, i64 %t140
  call void @olang_textcopy(ptr %t149, ptr %t142, i64 %t143)
  %t150 = getelementptr i8, ptr %t149, i64 %t143
  call void @olang_textcopy(ptr %t150, ptr %t145, i64 %t146)
  %t151 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t148, 1
  %t154 = extractvalue { i64, ptr } %t152, 0
  %t155 = extractvalue { i64, ptr } %t152, 1
  %t156 = mul i64 %t154, 1
  %t157 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t156)
  call void @llvm.memcpy.p0.p0.i64(ptr %t157, ptr %t155, i64 %t156, i1 false)
  %t158 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t157, 1
  %t162 = call { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %v2, ptr %s0, ptr %s0, { i64, ptr } %t137, { i64, ptr } %t159)
  %t163 = extractvalue { i32, { i64, ptr } } %t162, 1
  %t164 = extractvalue { i32, { i64, ptr } } %t162, 0
  store i32 %t164, ptr %l77
  %t165 = icmp ne i32 %t164, 0
  br i1 %t165, label %bb27, label %ok.166, !prof !99
ok.166:
  store { i64, ptr } %t163, ptr %l76
  br label %bb26
bb26:
  %t167 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t167, ptr %l71, !tbaa !27
  br label %bb51
bb27:
  %t168 = load i32, ptr %l77, !tbaa !23
  %t169 = ashr i32 %t168, 16
  %t171 = icmp eq i32 %t169, 1
  store i1 %t171, ptr %l79, !tbaa !21
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l14
  %t172 = load i32, ptr %l77, !tbaa !23
  %t173 = lshr i32 %t172, 16
  %t174 = and i32 %t172, 65535
  %t175 = icmp eq i32 %t173, 1
  %t176 = select i1 %t175, i32 1, i32 0
  %t177 = icmp eq i32 %t172, 0
  %t178 = shl i32 %t176, 16
  %t179 = or i32 %t178, %t174
  %t180 = select i1 %t177, i32 0, i32 %t179
  %t181 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l14, i32 0, i32 0
  store i32 %t180, ptr %t181, !tbaa !23
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s5
  %t182 = load { i32, { i64, [2 x i64] } }, ptr %l14
  store { i32, { i64, [2 x i64] } } %t182, ptr %l80
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l81
  %t183 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l80, i32 0, i32 0
  %t184 = load i32, ptr %t183, !tbaa !23
  store i32 %t184, ptr %l82, !tbaa !23
  %t185 = load i32, ptr %l82, !tbaa !23
  %t186 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l81, i32 0, i32 0
  store i32 %t185, ptr %t186, !tbaa !23
  %t187 = load i32, ptr %l82, !tbaa !23
  %t188 = ashr i32 %t187, 16
  %t190 = icmp eq i32 %t188, 1
  br i1 %t190, label %bb29, label %bb30
bb29:
  %t192 = call ptr @__olang_errpay_top_get()
  %t194 = load { i64, [2 x i64] }, ptr %t192
  %t195 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l81, i32 0, i32 1
  store { i64, [2 x i64] } %t194, ptr %t195
  br label %bb30
bb30:
  %t197 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fos_3aError_7d(ptr %s0, ptr %l81)
  store { i32, { i64, [2 x i64] } } %t197, ptr %l87
  br label %bb31
bb31:
  %t198 = load { i32, { i64, [2 x i64] } }, ptr %l87
  store { i32, { i64, [2 x i64] } } %t198, ptr %l14
  %t199 = load { i32, { i64, [2 x i64] } }, ptr %l14
  store { i32, { i64, [2 x i64] } } %t199, ptr %l88
  %t200 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l88, i32 0, i32 0
  %t201 = load i32, ptr %t200, !tbaa !23
  %t202 = ashr i32 %t201, 16
  %t204 = icmp eq i32 %t202, 1
  br i1 %t204, label %bb32, label %bb33
bb32:
  call void @__olang_errpay_pop()
  br label %bb33
bb33:
  %t206 = load ptr, ptr %l5, !tbaa !29
  store ptr %t206, ptr %l91, !tbaa !29
  %t207 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t207, ptr %l92, !tbaa !27
  %t208 = load { i32, { i64, [2 x i64] } }, ptr %l14
  store { i32, { i64, [2 x i64] } } %t208, ptr %l93
  %t210 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fos_3aError_7d(ptr %s5, ptr %l93)
  store { i32, { i64, [2 x i64] } } %t210, ptr %l95
  br label %bb34
bb34:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s6
  store ptr %s6room, ptr %s6
  %t211 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t212 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s6, ptr %t211, i64 %t212)
  %t213 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t214 = extractvalue { i64, ptr } %t213, 1
  %t215 = extractvalue { i64, ptr } %t213, 0
  call void @__olang_sb_put(ptr %s6, ptr %t214, i64 %t215)
  %t216 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t217 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s6, ptr %t216, i64 %t217)
  %t218 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l95, i32 0, i32 0
  %t219 = load i32, ptr %t218, !tbaa !23
  store i32 %t219, ptr %l96, !tbaa !23
  %t220 = load i32, ptr %l96, !tbaa !23
  %t221 = icmp eq i32 %t220, 0
  br i1 %t221, label %bb36, label %bb37
bb35:
  %t223 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d57, i32 0, i32 1) }, 1
  %t224 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d57, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s6, ptr %t223, i64 %t224)
  %t225 = load ptr, ptr %s6
  %t226 = getelementptr %olang.builder, ptr %s6, i32 0, i32 1
  %t227 = load i64, ptr %t226
  %t228 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t227)
  call void @olang_textcopy(ptr %t228, ptr %t225, i64 %t227)
  %t229 = insertvalue { i64, ptr } undef, i64 %t227, 0
  %t230 = insertvalue { i64, ptr } %t229, ptr %t228, 1
  store { i64, ptr } %t230, ptr %l111, !tbaa !27
  %t231 = getelementptr %olang.builder, ptr %s6, i32 0, i32 3
  %t232 = load ptr, ptr %t231
  %t233 = icmp ne ptr %t232, null
  br i1 %t233, label %sbgrew.234, label %sbdone.235
sbgrew.234:
  call void @__olang_sb_done(ptr %s6)
  br label %sbdone.235
sbdone.235:
  %t236 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t238 = extractvalue { i64, ptr } %t236, 0
  %t239 = extractvalue { i64, ptr } %t236, 1
  %t240 = mul i64 %t238, 1
  %t241 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t240)
  call void @llvm.memcpy.p0.p0.i64(ptr %t241, ptr %t239, i64 %t240, i1 false)
  %t242 = insertvalue { i64, ptr } undef, i64 %t238, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t241, 1
  %t244 = load ptr, ptr %l91, !tbaa !29
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v5, ptr %s5, ptr %t244, { i64, ptr } %t243)
  br label %bb50
bb36:
  %t246 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t247 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s6, ptr %t246, i64 %t247)
  br label %bb35
bb37:
  %t248 = load i32, ptr %l96, !tbaa !23
  %t249 = icmp eq i32 %t248, 65536
  br i1 %t249, label %bb38, label %bb39
bb38:
  %t251 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t252 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s6, ptr %t251, i64 %t252)
  %t253 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t254 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s6, ptr %t253, i64 %t254)
  %t255 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l95, i32 0, i32 1
  %t256 = getelementptr { i64, [2 x i64] }, ptr %t255, i32 0, i32 1
  %t257 = getelementptr { { i64, ptr } }, ptr %t256, i32 0, i32 0
  %t258 = load { i64, ptr }, ptr %t257
  %t260 = extractvalue { i64, ptr } %t258, 1
  %t261 = extractvalue { i64, ptr } %t258, 0
  %t262 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t260, i64 %t261, i8 34)
  %t263 = call ptr @__olang_sb_room(ptr %s6, i64 %t262)
  %t264 = call i64 @__olang_rd_quote(ptr %t263, i64 0, ptr %t260, i64 %t261, i8 34)
  call void @__olang_sb_add(ptr %s6, i64 %t262)
  %t265 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t266 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s6, ptr %t265, i64 %t266)
  br label %bb35
bb39:
  %t267 = load i32, ptr %l96, !tbaa !23
  %t268 = icmp eq i32 %t267, 65537
  br i1 %t268, label %bb40, label %bb41
bb40:
  %t270 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t271 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s6, ptr %t270, i64 %t271)
  %t272 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t273 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s6, ptr %t272, i64 %t273)
  %t274 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l95, i32 0, i32 1
  %t275 = getelementptr { i64, [2 x i64] }, ptr %t274, i32 0, i32 1
  %t276 = getelementptr { { i64, ptr } }, ptr %t275, i32 0, i32 0
  %t277 = load { i64, ptr }, ptr %t276
  %t279 = extractvalue { i64, ptr } %t277, 1
  %t280 = extractvalue { i64, ptr } %t277, 0
  %t281 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t279, i64 %t280, i8 34)
  %t282 = call ptr @__olang_sb_room(ptr %s6, i64 %t281)
  %t283 = call i64 @__olang_rd_quote(ptr %t282, i64 0, ptr %t279, i64 %t280, i8 34)
  call void @__olang_sb_add(ptr %s6, i64 %t281)
  %t284 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t285 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s6, ptr %t284, i64 %t285)
  br label %bb35
bb41:
  %t286 = load i32, ptr %l96, !tbaa !23
  %t287 = icmp eq i32 %t286, 65538
  br i1 %t287, label %bb42, label %bb43
bb42:
  %t289 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t290 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s6, ptr %t289, i64 %t290)
  %t291 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t292 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s6, ptr %t291, i64 %t292)
  %t293 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l95, i32 0, i32 1
  %t294 = getelementptr { i64, [2 x i64] }, ptr %t293, i32 0, i32 1
  %t295 = getelementptr { { i64, ptr } }, ptr %t294, i32 0, i32 0
  %t296 = load { i64, ptr }, ptr %t295
  %t298 = extractvalue { i64, ptr } %t296, 1
  %t299 = extractvalue { i64, ptr } %t296, 0
  %t300 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t298, i64 %t299, i8 34)
  %t301 = call ptr @__olang_sb_room(ptr %s6, i64 %t300)
  %t302 = call i64 @__olang_rd_quote(ptr %t301, i64 0, ptr %t298, i64 %t299, i8 34)
  call void @__olang_sb_add(ptr %s6, i64 %t300)
  %t303 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t304 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s6, ptr %t303, i64 %t304)
  br label %bb35
bb43:
  %t305 = load i32, ptr %l96, !tbaa !23
  %t306 = icmp eq i32 %t305, 65539
  br i1 %t306, label %bb44, label %bb45
bb44:
  %t308 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t309 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s6, ptr %t308, i64 %t309)
  %t310 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t311 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s6, ptr %t310, i64 %t311)
  %t312 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l95, i32 0, i32 1
  %t313 = getelementptr { i64, [2 x i64] }, ptr %t312, i32 0, i32 1
  %t314 = getelementptr { { i64, ptr } }, ptr %t313, i32 0, i32 0
  %t315 = load { i64, ptr }, ptr %t314
  %t317 = extractvalue { i64, ptr } %t315, 1
  %t318 = extractvalue { i64, ptr } %t315, 0
  %t319 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t317, i64 %t318, i8 34)
  %t320 = call ptr @__olang_sb_room(ptr %s6, i64 %t319)
  %t321 = call i64 @__olang_rd_quote(ptr %t320, i64 0, ptr %t317, i64 %t318, i8 34)
  call void @__olang_sb_add(ptr %s6, i64 %t319)
  %t322 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t323 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s6, ptr %t322, i64 %t323)
  br label %bb35
bb45:
  %t324 = load i32, ptr %l96, !tbaa !23
  %t325 = icmp eq i32 %t324, 65540
  br i1 %t325, label %bb46, label %bb47
bb46:
  %t327 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t328 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s6, ptr %t327, i64 %t328)
  %t329 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t330 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s6, ptr %t329, i64 %t330)
  %t331 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l95, i32 0, i32 1
  %t332 = getelementptr { i64, [2 x i64] }, ptr %t331, i32 0, i32 1
  %t333 = getelementptr { { i64, ptr } }, ptr %t332, i32 0, i32 0
  %t334 = load { i64, ptr }, ptr %t333
  %t336 = extractvalue { i64, ptr } %t334, 1
  %t337 = extractvalue { i64, ptr } %t334, 0
  %t338 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t336, i64 %t337, i8 34)
  %t339 = call ptr @__olang_sb_room(ptr %s6, i64 %t338)
  %t340 = call i64 @__olang_rd_quote(ptr %t339, i64 0, ptr %t336, i64 %t337, i8 34)
  call void @__olang_sb_add(ptr %s6, i64 %t338)
  %t341 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t342 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s6, ptr %t341, i64 %t342)
  br label %bb35
bb47:
  %t343 = load i32, ptr %l96, !tbaa !23
  %t344 = icmp eq i32 %t343, 65541
  br i1 %t344, label %bb48, label %bb49
bb48:
  %t346 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t347 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s6, ptr %t346, i64 %t347)
  %t348 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t349 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s6, ptr %t348, i64 %t349)
  %t350 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l95, i32 0, i32 1
  %t351 = getelementptr { i64, [2 x i64] }, ptr %t350, i32 0, i32 1
  %t352 = getelementptr { { i64, ptr } }, ptr %t351, i32 0, i32 0
  %t353 = load { i64, ptr }, ptr %t352
  %t355 = extractvalue { i64, ptr } %t353, 1
  %t356 = extractvalue { i64, ptr } %t353, 0
  %t357 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t355, i64 %t356, i8 34)
  %t358 = call ptr @__olang_sb_room(ptr %s6, i64 %t357)
  %t359 = call i64 @__olang_rd_quote(ptr %t358, i64 0, ptr %t355, i64 %t356, i8 34)
  call void @__olang_sb_add(ptr %s6, i64 %t357)
  %t360 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t361 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s6, ptr %t360, i64 %t361)
  br label %bb35
bb49:
  %t362 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t363 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s6, ptr %t362, i64 %t363)
  %t364 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t365 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s6, ptr %t364, i64 %t365)
  %t366 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l95, i32 0, i32 1
  %t367 = getelementptr { i64, [2 x i64] }, ptr %t366, i32 0, i32 1
  %t368 = getelementptr { { i64, ptr } }, ptr %t367, i32 0, i32 0
  %t369 = load { i64, ptr }, ptr %t368
  %t371 = extractvalue { i64, ptr } %t369, 1
  %t372 = extractvalue { i64, ptr } %t369, 0
  %t373 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t371, i64 %t372, i8 34)
  %t374 = call ptr @__olang_sb_room(ptr %s6, i64 %t373)
  %t375 = call i64 @__olang_rd_quote(ptr %t374, i64 0, ptr %t371, i64 %t372, i8 34)
  call void @__olang_sb_add(ptr %s6, i64 %t373)
  %t376 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t377 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s6, ptr %t376, i64 %t377)
  br label %bb35
bb50:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb51:
  %t379 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t379, ptr %l15, !tbaa !27
  %t380 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t381 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t382 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t383 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t385 = extractvalue { i64, ptr } %t381, 1
  %t386 = extractvalue { i64, ptr } %t381, 0
  %t387 = add i64 %t383, %t386
  %t388 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t387)
  call void @olang_textcopy(ptr %t388, ptr %t382, i64 %t383)
  %t389 = getelementptr i8, ptr %t388, i64 %t383
  call void @olang_textcopy(ptr %t389, ptr %t385, i64 %t386)
  %t390 = insertvalue { i64, ptr } undef, i64 %t387, 0
  %t391 = insertvalue { i64, ptr } %t390, ptr %t388, 1
  %t393 = extractvalue { i64, ptr } %t391, 0
  %t394 = extractvalue { i64, ptr } %t391, 1
  %t395 = mul i64 %t393, 1
  %t396 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t395)
  call void @llvm.memcpy.p0.p0.i64(ptr %t396, ptr %t394, i64 %t395, i1 false)
  %t397 = insertvalue { i64, ptr } undef, i64 %t393, 0
  %t398 = insertvalue { i64, ptr } %t397, ptr %t396, 1
  %t400 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t380, 0
  %t402 = insertvalue [2 x { i64, ptr }] %t400, { i64, ptr } %t398, 1
  store [2 x { i64, ptr }] %t402, ptr %l16
  %t405 = insertvalue { i64, ptr } undef, i64 2, 0
  %t406 = insertvalue { i64, ptr } %t405, ptr %l16, 1
  %t408 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t406)
  store { i64, ptr } %t408, ptr %l122
  br label %bb52
bb52:
  %t409 = load { i64, ptr }, ptr %l122, !tbaa !27
  store { i64, ptr } %t409, ptr %l17, !tbaa !27
  %t410 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t410, ptr %l124, !tbaa !27
  %t411 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t411, ptr %l125, !tbaa !27
  %t412 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t413 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t415 = extractvalue { i64, ptr } %t413, 1
  %t416 = extractvalue { i64, ptr } %t413, 0
  %t417 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d69, i32 0, i32 1) }, 1
  %t418 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d69, i32 0, i32 1) }, 0
  %t419 = add i64 %t416, %t418
  %t420 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t419)
  call void @olang_textcopy(ptr %t420, ptr %t415, i64 %t416)
  %t421 = getelementptr i8, ptr %t420, i64 %t416
  call void @olang_textcopy(ptr %t421, ptr %t417, i64 %t418)
  %t422 = insertvalue { i64, ptr } undef, i64 %t419, 0
  %t423 = insertvalue { i64, ptr } %t422, ptr %t420, 1
  %t425 = extractvalue { i64, ptr } %t423, 0
  %t426 = extractvalue { i64, ptr } %t423, 1
  %t427 = mul i64 %t425, 1
  %t428 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t427)
  call void @llvm.memcpy.p0.p0.i64(ptr %t428, ptr %t426, i64 %t427, i1 false)
  %t429 = insertvalue { i64, ptr } undef, i64 %t425, 0
  %t430 = insertvalue { i64, ptr } %t429, ptr %t428, 1
  %t432 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t412, 0
  %t434 = insertvalue [2 x { i64, ptr }] %t432, { i64, ptr } %t430, 1
  store [2 x { i64, ptr }] %t434, ptr %l18
  %t437 = insertvalue { i64, ptr } undef, i64 2, 0
  %t438 = insertvalue { i64, ptr } %t437, ptr %l18, 1
  %t440 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t438)
  store { i64, ptr } %t440, ptr %l133
  br label %bb53
bb53:
  %t441 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t442 = extractvalue { i64, ptr } %t441, 0
  %t443 = extractvalue { i64, ptr } %t441, 1
  %t444 = mul i64 %t442, 1
  %t445 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t444)
  call void @llvm.memcpy.p0.p0.i64(ptr %t445, ptr %t443, i64 %t444, i1 false)
  %t446 = insertvalue { i64, ptr } undef, i64 %t442, 0
  %t447 = insertvalue { i64, ptr } %t446, ptr %t445, 1
  %t448 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t449 = insertvalue [5 x { i64, ptr }] undef, { i64, ptr } %t448, 0
  %t450 = insertvalue [5 x { i64, ptr }] %t449, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t451 = insertvalue [5 x { i64, ptr }] %t450, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d71, i32 0, i32 1) }, 2
  %t452 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t453 = insertvalue [5 x { i64, ptr }] %t451, { i64, ptr } %t452, 3
  %t455 = insertvalue [5 x { i64, ptr }] %t453, { i64, ptr } %t447, 4
  store [5 x { i64, ptr }] %t455, ptr %l19
  %t458 = insertvalue { i64, ptr } undef, i64 5, 0
  %t459 = insertvalue { i64, ptr } %t458, ptr %l19, 1
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l138, !tbaa !27
  %t460 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t462 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t464 = call { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %s0, ptr %s0, ptr %v2, ptr %s0, { i64, ptr } %t459, { i64, ptr } %t462, i1 true, { i64, ptr } %t460)
  %t465 = extractvalue { i32, %"std/os:Output" } %t464, 1
  %t466 = extractvalue { i32, %"std/os:Output" } %t464, 0
  store i32 %t466, ptr %l141
  %t467 = icmp ne i32 %t466, 0
  br i1 %t467, label %bb55, label %ok.468, !prof !99
ok.468:
  store %"std/os:Output" %t465, ptr %l140
  br label %bb54
bb54:
  %t469 = load %"std/os:Output", ptr %l140
  store %"std/os:Output" %t469, ptr %l123
  br label %bb85
bb55:
  %t470 = load i32, ptr %l141, !tbaa !23
  %t471 = ashr i32 %t470, 16
  %t473 = icmp eq i32 %t471, 1
  store i1 %t473, ptr %l143, !tbaa !21
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l20
  %t474 = load i32, ptr %l141, !tbaa !23
  %t475 = lshr i32 %t474, 16
  %t476 = and i32 %t474, 65535
  %t477 = icmp eq i32 %t475, 1
  %t478 = select i1 %t477, i32 1, i32 0
  %t479 = icmp eq i32 %t474, 0
  %t480 = shl i32 %t478, 16
  %t481 = or i32 %t480, %t476
  %t482 = select i1 %t479, i32 0, i32 %t481
  %t483 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l20, i32 0, i32 0
  store i32 %t482, ptr %t483, !tbaa !23
  br label %bb56
bb56:
  store %olang.scope zeroinitializer, ptr %s9
  %t484 = load { i32, { i64, [2 x i64] } }, ptr %l20
  store { i32, { i64, [2 x i64] } } %t484, ptr %l144
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l145
  %t485 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l144, i32 0, i32 0
  %t486 = load i32, ptr %t485, !tbaa !23
  store i32 %t486, ptr %l146, !tbaa !23
  %t487 = load i32, ptr %l146, !tbaa !23
  %t488 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l145, i32 0, i32 0
  store i32 %t487, ptr %t488, !tbaa !23
  %t489 = load i32, ptr %l146, !tbaa !23
  %t490 = ashr i32 %t489, 16
  %t492 = icmp eq i32 %t490, 1
  br i1 %t492, label %bb57, label %bb58
bb57:
  %t494 = call ptr @__olang_errpay_top_get()
  %t496 = load { i64, [2 x i64] }, ptr %t494
  %t497 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l145, i32 0, i32 1
  store { i64, [2 x i64] } %t496, ptr %t497
  br label %bb58
bb58:
  %t499 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fos_3aError_7d(ptr %s0, ptr %l145)
  store { i32, { i64, [2 x i64] } } %t499, ptr %l151
  br label %bb59
bb59:
  %t500 = load { i32, { i64, [2 x i64] } }, ptr %l151
  store { i32, { i64, [2 x i64] } } %t500, ptr %l20
  %t501 = load { i32, { i64, [2 x i64] } }, ptr %l20
  store { i32, { i64, [2 x i64] } } %t501, ptr %l152
  %t502 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l152, i32 0, i32 0
  %t503 = load i32, ptr %t502, !tbaa !23
  %t504 = ashr i32 %t503, 16
  %t506 = icmp eq i32 %t504, 1
  br i1 %t506, label %bb60, label %bb61
bb60:
  call void @__olang_errpay_pop()
  br label %bb61
bb61:
  %t508 = load ptr, ptr %l5, !tbaa !29
  store ptr %t508, ptr %l155, !tbaa !29
  %t509 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t509, ptr %l156, !tbaa !27
  %t510 = load { i32, { i64, [2 x i64] } }, ptr %l20
  store { i32, { i64, [2 x i64] } } %t510, ptr %l157
  %t512 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fos_3aError_7d(ptr %s9, ptr %l157)
  store { i32, { i64, [2 x i64] } } %t512, ptr %l159
  br label %bb62
bb62:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s10
  store ptr %s10room, ptr %s10
  %t513 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t514 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t513, i64 %t514)
  %t515 = load { i64, ptr }, ptr %l156, !tbaa !27
  %t516 = extractvalue { i64, ptr } %t515, 1
  %t517 = extractvalue { i64, ptr } %t515, 0
  call void @__olang_sb_put(ptr %s10, ptr %t516, i64 %t517)
  %t518 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t519 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t518, i64 %t519)
  %t520 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l159, i32 0, i32 0
  %t521 = load i32, ptr %t520, !tbaa !23
  store i32 %t521, ptr %l160, !tbaa !23
  %t522 = load i32, ptr %l160, !tbaa !23
  %t523 = icmp eq i32 %t522, 0
  br i1 %t523, label %bb64, label %bb65
bb63:
  %t525 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t526 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t525, i64 %t526)
  %t527 = load ptr, ptr %s10
  %t528 = getelementptr %olang.builder, ptr %s10, i32 0, i32 1
  %t529 = load i64, ptr %t528
  %t530 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t529)
  call void @olang_textcopy(ptr %t530, ptr %t527, i64 %t529)
  %t531 = insertvalue { i64, ptr } undef, i64 %t529, 0
  %t532 = insertvalue { i64, ptr } %t531, ptr %t530, 1
  store { i64, ptr } %t532, ptr %l175, !tbaa !27
  %t533 = getelementptr %olang.builder, ptr %s10, i32 0, i32 3
  %t534 = load ptr, ptr %t533
  %t535 = icmp ne ptr %t534, null
  br i1 %t535, label %sbgrew.536, label %sbdone.537
sbgrew.536:
  call void @__olang_sb_done(ptr %s10)
  br label %sbdone.537
sbdone.537:
  %t538 = load { i64, ptr }, ptr %l175, !tbaa !27
  %t540 = extractvalue { i64, ptr } %t538, 0
  %t541 = extractvalue { i64, ptr } %t538, 1
  %t542 = mul i64 %t540, 1
  %t543 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t542)
  call void @llvm.memcpy.p0.p0.i64(ptr %t543, ptr %t541, i64 %t542, i1 false)
  %t544 = insertvalue { i64, ptr } undef, i64 %t540, 0
  %t545 = insertvalue { i64, ptr } %t544, ptr %t543, 1
  %t546 = load ptr, ptr %l155, !tbaa !29
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v5, ptr %s9, ptr %t546, { i64, ptr } %t545)
  br label %bb78
bb64:
  %t548 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d75, i32 0, i32 1) }, 1
  %t549 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d75, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t548, i64 %t549)
  br label %bb63
bb65:
  %t550 = load i32, ptr %l160, !tbaa !23
  %t551 = icmp eq i32 %t550, 65536
  br i1 %t551, label %bb66, label %bb67
bb66:
  %t553 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d76, i32 0, i32 1) }, 1
  %t554 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d76, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t553, i64 %t554)
  %t555 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t556 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t555, i64 %t556)
  %t557 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l159, i32 0, i32 1
  %t558 = getelementptr { i64, [2 x i64] }, ptr %t557, i32 0, i32 1
  %t559 = getelementptr { { i64, ptr } }, ptr %t558, i32 0, i32 0
  %t560 = load { i64, ptr }, ptr %t559
  %t562 = extractvalue { i64, ptr } %t560, 1
  %t563 = extractvalue { i64, ptr } %t560, 0
  %t564 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t562, i64 %t563, i8 34)
  %t565 = call ptr @__olang_sb_room(ptr %s10, i64 %t564)
  %t566 = call i64 @__olang_rd_quote(ptr %t565, i64 0, ptr %t562, i64 %t563, i8 34)
  call void @__olang_sb_add(ptr %s10, i64 %t564)
  %t567 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d78, i32 0, i32 1) }, 1
  %t568 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d78, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t567, i64 %t568)
  br label %bb63
bb67:
  %t569 = load i32, ptr %l160, !tbaa !23
  %t570 = icmp eq i32 %t569, 65537
  br i1 %t570, label %bb68, label %bb69
bb68:
  %t572 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d79, i32 0, i32 1) }, 1
  %t573 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d79, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t572, i64 %t573)
  %t574 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t575 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t574, i64 %t575)
  %t576 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l159, i32 0, i32 1
  %t577 = getelementptr { i64, [2 x i64] }, ptr %t576, i32 0, i32 1
  %t578 = getelementptr { { i64, ptr } }, ptr %t577, i32 0, i32 0
  %t579 = load { i64, ptr }, ptr %t578
  %t581 = extractvalue { i64, ptr } %t579, 1
  %t582 = extractvalue { i64, ptr } %t579, 0
  %t583 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t581, i64 %t582, i8 34)
  %t584 = call ptr @__olang_sb_room(ptr %s10, i64 %t583)
  %t585 = call i64 @__olang_rd_quote(ptr %t584, i64 0, ptr %t581, i64 %t582, i8 34)
  call void @__olang_sb_add(ptr %s10, i64 %t583)
  %t586 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d78, i32 0, i32 1) }, 1
  %t587 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d78, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t586, i64 %t587)
  br label %bb63
bb69:
  %t588 = load i32, ptr %l160, !tbaa !23
  %t589 = icmp eq i32 %t588, 65538
  br i1 %t589, label %bb70, label %bb71
bb70:
  %t591 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d80, i32 0, i32 1) }, 1
  %t592 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d80, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t591, i64 %t592)
  %t593 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t594 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t593, i64 %t594)
  %t595 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l159, i32 0, i32 1
  %t596 = getelementptr { i64, [2 x i64] }, ptr %t595, i32 0, i32 1
  %t597 = getelementptr { { i64, ptr } }, ptr %t596, i32 0, i32 0
  %t598 = load { i64, ptr }, ptr %t597
  %t600 = extractvalue { i64, ptr } %t598, 1
  %t601 = extractvalue { i64, ptr } %t598, 0
  %t602 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t600, i64 %t601, i8 34)
  %t603 = call ptr @__olang_sb_room(ptr %s10, i64 %t602)
  %t604 = call i64 @__olang_rd_quote(ptr %t603, i64 0, ptr %t600, i64 %t601, i8 34)
  call void @__olang_sb_add(ptr %s10, i64 %t602)
  %t605 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d78, i32 0, i32 1) }, 1
  %t606 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d78, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t605, i64 %t606)
  br label %bb63
bb71:
  %t607 = load i32, ptr %l160, !tbaa !23
  %t608 = icmp eq i32 %t607, 65539
  br i1 %t608, label %bb72, label %bb73
bb72:
  %t610 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d81, i32 0, i32 1) }, 1
  %t611 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d81, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t610, i64 %t611)
  %t612 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t613 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t612, i64 %t613)
  %t614 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l159, i32 0, i32 1
  %t615 = getelementptr { i64, [2 x i64] }, ptr %t614, i32 0, i32 1
  %t616 = getelementptr { { i64, ptr } }, ptr %t615, i32 0, i32 0
  %t617 = load { i64, ptr }, ptr %t616
  %t619 = extractvalue { i64, ptr } %t617, 1
  %t620 = extractvalue { i64, ptr } %t617, 0
  %t621 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t619, i64 %t620, i8 34)
  %t622 = call ptr @__olang_sb_room(ptr %s10, i64 %t621)
  %t623 = call i64 @__olang_rd_quote(ptr %t622, i64 0, ptr %t619, i64 %t620, i8 34)
  call void @__olang_sb_add(ptr %s10, i64 %t621)
  %t624 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d78, i32 0, i32 1) }, 1
  %t625 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d78, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t624, i64 %t625)
  br label %bb63
bb73:
  %t626 = load i32, ptr %l160, !tbaa !23
  %t627 = icmp eq i32 %t626, 65540
  br i1 %t627, label %bb74, label %bb75
bb74:
  %t629 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d82, i32 0, i32 1) }, 1
  %t630 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d82, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t629, i64 %t630)
  %t631 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t632 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t631, i64 %t632)
  %t633 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l159, i32 0, i32 1
  %t634 = getelementptr { i64, [2 x i64] }, ptr %t633, i32 0, i32 1
  %t635 = getelementptr { { i64, ptr } }, ptr %t634, i32 0, i32 0
  %t636 = load { i64, ptr }, ptr %t635
  %t638 = extractvalue { i64, ptr } %t636, 1
  %t639 = extractvalue { i64, ptr } %t636, 0
  %t640 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t638, i64 %t639, i8 34)
  %t641 = call ptr @__olang_sb_room(ptr %s10, i64 %t640)
  %t642 = call i64 @__olang_rd_quote(ptr %t641, i64 0, ptr %t638, i64 %t639, i8 34)
  call void @__olang_sb_add(ptr %s10, i64 %t640)
  %t643 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d78, i32 0, i32 1) }, 1
  %t644 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d78, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t643, i64 %t644)
  br label %bb63
bb75:
  %t645 = load i32, ptr %l160, !tbaa !23
  %t646 = icmp eq i32 %t645, 65541
  br i1 %t646, label %bb76, label %bb77
bb76:
  %t648 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d83, i32 0, i32 1) }, 1
  %t649 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d83, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t648, i64 %t649)
  %t650 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t651 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t650, i64 %t651)
  %t652 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l159, i32 0, i32 1
  %t653 = getelementptr { i64, [2 x i64] }, ptr %t652, i32 0, i32 1
  %t654 = getelementptr { { i64, ptr } }, ptr %t653, i32 0, i32 0
  %t655 = load { i64, ptr }, ptr %t654
  %t657 = extractvalue { i64, ptr } %t655, 1
  %t658 = extractvalue { i64, ptr } %t655, 0
  %t659 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t657, i64 %t658, i8 34)
  %t660 = call ptr @__olang_sb_room(ptr %s10, i64 %t659)
  %t661 = call i64 @__olang_rd_quote(ptr %t660, i64 0, ptr %t657, i64 %t658, i8 34)
  call void @__olang_sb_add(ptr %s10, i64 %t659)
  %t662 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d78, i32 0, i32 1) }, 1
  %t663 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d78, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t662, i64 %t663)
  br label %bb63
bb77:
  %t664 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d84, i32 0, i32 1) }, 1
  %t665 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d84, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t664, i64 %t665)
  %t666 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t667 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t666, i64 %t667)
  %t668 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l159, i32 0, i32 1
  %t669 = getelementptr { i64, [2 x i64] }, ptr %t668, i32 0, i32 1
  %t670 = getelementptr { { i64, ptr } }, ptr %t669, i32 0, i32 0
  %t671 = load { i64, ptr }, ptr %t670
  %t673 = extractvalue { i64, ptr } %t671, 1
  %t674 = extractvalue { i64, ptr } %t671, 0
  %t675 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t673, i64 %t674, i8 34)
  %t676 = call ptr @__olang_sb_room(ptr %s10, i64 %t675)
  %t677 = call i64 @__olang_rd_quote(ptr %t676, i64 0, ptr %t673, i64 %t674, i8 34)
  call void @__olang_sb_add(ptr %s10, i64 %t675)
  %t678 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d78, i32 0, i32 1) }, 1
  %t679 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d78, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t678, i64 %t679)
  br label %bb63
bb78:
  store i32 65536, ptr %l178, !tbaa !23
  call void @__olang_scope_close(ptr %s9)
  %t680 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t682 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t680)
  store i32 %t682, ptr %l180
  %t683 = icmp ne i32 %t682, 0
  br i1 %t683, label %bb80, label %ok.684, !prof !99
ok.684:
  br label %bb79
bb79:
  br label %bb84
bb80:
  %t685 = load i32, ptr %l180, !tbaa !23
  %t686 = ashr i32 %t685, 16
  %t688 = icmp eq i32 %t686, 1
  store i1 %t688, ptr %l182, !tbaa !21
  %t689 = load i32, ptr %l180, !tbaa !23
  %t690 = ashr i32 %t689, 16
  %t692 = icmp eq i32 %t690, 1
  br i1 %t692, label %bb81, label %bb82
bb81:
  call void @__olang_errpay_pop()
  br label %bb82
bb82:
  br label %bb83
bb83:
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s0)
  %t694 = load i32, ptr %l178, !tbaa !23
  store i32 %t694, ptr %rv
  br label %ret
bb85:
  %t695 = load %"std/os:Output", ptr %l123
  store %"std/os:Output" %t695, ptr %l21
  %t696 = getelementptr %"std/os:Output", ptr %l21, i32 0, i32 0
  %t697 = load i32, ptr %t696, !tbaa !23
  %t699 = icmp ne i32 %t697, 0
  br i1 %t699, label %bb86, label %bb87
bb86:
  store %olang.scope zeroinitializer, ptr %s13
  %t701 = load ptr, ptr %l5, !tbaa !29
  %t702 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t703 = getelementptr %"std/os:Output", ptr %l21, i32 0, i32 1
  %t704 = load { i64, ptr }, ptr %t703, !tbaa !27
  %t705 = getelementptr %"std/os:Output", ptr %l21, i32 0, i32 2
  %t706 = load { i64, ptr }, ptr %t705, !tbaa !27
  %t707 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d85, i32 0, i32 1) }, 1
  %t708 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d85, i32 0, i32 1) }, 0
  %t710 = extractvalue { i64, ptr } %t702, 1
  %t711 = extractvalue { i64, ptr } %t702, 0
  %t712 = add i64 %t708, %t711
  %t713 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d86, i32 0, i32 1) }, 1
  %t714 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d86, i32 0, i32 1) }, 0
  %t715 = add i64 %t712, %t714
  %t717 = extractvalue { i64, ptr } %t704, 1
  %t718 = extractvalue { i64, ptr } %t704, 0
  %t719 = add i64 %t715, %t718
  %t721 = extractvalue { i64, ptr } %t706, 1
  %t722 = extractvalue { i64, ptr } %t706, 0
  %t723 = add i64 %t719, %t722
  %t724 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t723)
  call void @olang_textcopy(ptr %t724, ptr %t707, i64 %t708)
  %t725 = getelementptr i8, ptr %t724, i64 %t708
  call void @olang_textcopy(ptr %t725, ptr %t710, i64 %t711)
  %t726 = getelementptr i8, ptr %t725, i64 %t711
  call void @olang_textcopy(ptr %t726, ptr %t713, i64 %t714)
  %t727 = getelementptr i8, ptr %t726, i64 %t714
  call void @olang_textcopy(ptr %t727, ptr %t717, i64 %t718)
  %t728 = getelementptr i8, ptr %t727, i64 %t718
  call void @olang_textcopy(ptr %t728, ptr %t721, i64 %t722)
  %t729 = insertvalue { i64, ptr } undef, i64 %t723, 0
  %t730 = insertvalue { i64, ptr } %t729, ptr %t724, 1
  %t733 = extractvalue { i64, ptr } %t730, 0
  %t734 = extractvalue { i64, ptr } %t730, 1
  %t735 = mul i64 %t733, 1
  %t736 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t735)
  call void @llvm.memcpy.p0.p0.i64(ptr %t736, ptr %t734, i64 %t735, i1 false)
  %t737 = insertvalue { i64, ptr } undef, i64 %t733, 0
  %t738 = insertvalue { i64, ptr } %t737, ptr %t736, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v5, ptr %s13, ptr %t701, { i64, ptr } %t738)
  br label %bb88
bb87:
  br label %bb95
bb88:
  store i32 65536, ptr %l194, !tbaa !23
  call void @__olang_scope_close(ptr %s13)
  %t741 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t743 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t741)
  store i32 %t743, ptr %l196
  %t744 = icmp ne i32 %t743, 0
  br i1 %t744, label %bb90, label %ok.745, !prof !99
ok.745:
  br label %bb89
bb89:
  br label %bb94
bb90:
  %t746 = load i32, ptr %l196, !tbaa !23
  %t747 = ashr i32 %t746, 16
  %t749 = icmp eq i32 %t747, 1
  store i1 %t749, ptr %l198, !tbaa !21
  %t750 = load i32, ptr %l196, !tbaa !23
  %t751 = ashr i32 %t750, 16
  %t753 = icmp eq i32 %t751, 1
  br i1 %t753, label %bb91, label %bb92
bb91:
  call void @__olang_errpay_pop()
  br label %bb92
bb92:
  br label %bb93
bb93:
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s0)
  %t755 = load i32, ptr %l194, !tbaa !23
  store i32 %t755, ptr %rv
  br label %ret
bb95:
  %t756 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t757 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t760 = call i32 @std_2fos_2eRename(ptr %s0, ptr %s0, { i64, ptr } %t756, { i64, ptr } %t757)
  store i32 %t760, ptr %l203
  %t761 = icmp ne i32 %t760, 0
  br i1 %t761, label %bb97, label %ok.762, !prof !99
ok.762:
  br label %bb96
bb96:
  br label %bb127
bb97:
  %t763 = load i32, ptr %l203, !tbaa !23
  %t764 = ashr i32 %t763, 16
  %t766 = icmp eq i32 %t764, 1
  store i1 %t766, ptr %l205, !tbaa !21
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l22
  %t767 = load i32, ptr %l203, !tbaa !23
  %t768 = lshr i32 %t767, 16
  %t769 = and i32 %t767, 65535
  %t770 = icmp eq i32 %t768, 1
  %t771 = select i1 %t770, i32 1, i32 0
  %t772 = icmp eq i32 %t767, 0
  %t773 = shl i32 %t771, 16
  %t774 = or i32 %t773, %t769
  %t775 = select i1 %t772, i32 0, i32 %t774
  %t776 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l22, i32 0, i32 0
  store i32 %t775, ptr %t776, !tbaa !23
  br label %bb98
bb98:
  store %olang.scope zeroinitializer, ptr %s17
  %t777 = load { i32, { i64, [2 x i64] } }, ptr %l22
  store { i32, { i64, [2 x i64] } } %t777, ptr %l206
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l207
  %t778 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l206, i32 0, i32 0
  %t779 = load i32, ptr %t778, !tbaa !23
  store i32 %t779, ptr %l208, !tbaa !23
  %t780 = load i32, ptr %l208, !tbaa !23
  %t781 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l207, i32 0, i32 0
  store i32 %t780, ptr %t781, !tbaa !23
  %t782 = load i32, ptr %l208, !tbaa !23
  %t783 = ashr i32 %t782, 16
  %t785 = icmp eq i32 %t783, 1
  br i1 %t785, label %bb99, label %bb100
bb99:
  %t787 = call ptr @__olang_errpay_top_get()
  %t789 = load { i64, [2 x i64] }, ptr %t787
  %t790 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l207, i32 0, i32 1
  store { i64, [2 x i64] } %t789, ptr %t790
  br label %bb100
bb100:
  %t792 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fos_3aError_7d(ptr %s0, ptr %l207)
  store { i32, { i64, [2 x i64] } } %t792, ptr %l213
  br label %bb101
bb101:
  %t793 = load { i32, { i64, [2 x i64] } }, ptr %l213
  store { i32, { i64, [2 x i64] } } %t793, ptr %l22
  %t794 = load { i32, { i64, [2 x i64] } }, ptr %l22
  store { i32, { i64, [2 x i64] } } %t794, ptr %l214
  %t795 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l214, i32 0, i32 0
  %t796 = load i32, ptr %t795, !tbaa !23
  %t797 = ashr i32 %t796, 16
  %t799 = icmp eq i32 %t797, 1
  br i1 %t799, label %bb102, label %bb103
bb102:
  call void @__olang_errpay_pop()
  br label %bb103
bb103:
  %t801 = load ptr, ptr %l5, !tbaa !29
  store ptr %t801, ptr %l217, !tbaa !29
  %t802 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t802, ptr %l218, !tbaa !27
  %t803 = load { i32, { i64, [2 x i64] } }, ptr %l22
  store { i32, { i64, [2 x i64] } } %t803, ptr %l219
  %t805 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fos_3aError_7d(ptr %s17, ptr %l219)
  store { i32, { i64, [2 x i64] } } %t805, ptr %l221
  br label %bb104
bb104:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s18
  store ptr %s18room, ptr %s18
  %t806 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d87, i32 0, i32 1) }, 1
  %t807 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d87, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t806, i64 %t807)
  %t808 = load { i64, ptr }, ptr %l218, !tbaa !27
  %t809 = extractvalue { i64, ptr } %t808, 1
  %t810 = extractvalue { i64, ptr } %t808, 0
  call void @__olang_sb_put(ptr %s18, ptr %t809, i64 %t810)
  %t811 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d88, i32 0, i32 1) }, 1
  %t812 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d88, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t811, i64 %t812)
  %t813 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l221, i32 0, i32 0
  %t814 = load i32, ptr %t813, !tbaa !23
  store i32 %t814, ptr %l222, !tbaa !23
  %t815 = load i32, ptr %l222, !tbaa !23
  %t816 = icmp eq i32 %t815, 0
  br i1 %t816, label %bb106, label %bb107
bb105:
  %t818 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d89, i32 0, i32 1) }, 1
  %t819 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d89, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t818, i64 %t819)
  %t820 = load ptr, ptr %s18
  %t821 = getelementptr %olang.builder, ptr %s18, i32 0, i32 1
  %t822 = load i64, ptr %t821
  %t823 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t822)
  call void @olang_textcopy(ptr %t823, ptr %t820, i64 %t822)
  %t824 = insertvalue { i64, ptr } undef, i64 %t822, 0
  %t825 = insertvalue { i64, ptr } %t824, ptr %t823, 1
  store { i64, ptr } %t825, ptr %l237, !tbaa !27
  %t826 = getelementptr %olang.builder, ptr %s18, i32 0, i32 3
  %t827 = load ptr, ptr %t826
  %t828 = icmp ne ptr %t827, null
  br i1 %t828, label %sbgrew.829, label %sbdone.830
sbgrew.829:
  call void @__olang_sb_done(ptr %s18)
  br label %sbdone.830
sbdone.830:
  %t831 = load { i64, ptr }, ptr %l237, !tbaa !27
  %t833 = extractvalue { i64, ptr } %t831, 0
  %t834 = extractvalue { i64, ptr } %t831, 1
  %t835 = mul i64 %t833, 1
  %t836 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t835)
  call void @llvm.memcpy.p0.p0.i64(ptr %t836, ptr %t834, i64 %t835, i1 false)
  %t837 = insertvalue { i64, ptr } undef, i64 %t833, 0
  %t838 = insertvalue { i64, ptr } %t837, ptr %t836, 1
  %t839 = load ptr, ptr %l217, !tbaa !29
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v5, ptr %s17, ptr %t839, { i64, ptr } %t838)
  br label %bb120
bb106:
  %t841 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d90, i32 0, i32 1) }, 1
  %t842 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d90, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t841, i64 %t842)
  br label %bb105
bb107:
  %t843 = load i32, ptr %l222, !tbaa !23
  %t844 = icmp eq i32 %t843, 65536
  br i1 %t844, label %bb108, label %bb109
bb108:
  %t846 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d91, i32 0, i32 1) }, 1
  %t847 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d91, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t846, i64 %t847)
  %t848 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t849 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t848, i64 %t849)
  %t850 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l221, i32 0, i32 1
  %t851 = getelementptr { i64, [2 x i64] }, ptr %t850, i32 0, i32 1
  %t852 = getelementptr { { i64, ptr } }, ptr %t851, i32 0, i32 0
  %t853 = load { i64, ptr }, ptr %t852
  %t855 = extractvalue { i64, ptr } %t853, 1
  %t856 = extractvalue { i64, ptr } %t853, 0
  %t857 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t855, i64 %t856, i8 34)
  %t858 = call ptr @__olang_sb_room(ptr %s18, i64 %t857)
  %t859 = call i64 @__olang_rd_quote(ptr %t858, i64 0, ptr %t855, i64 %t856, i8 34)
  call void @__olang_sb_add(ptr %s18, i64 %t857)
  %t860 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d93, i32 0, i32 1) }, 1
  %t861 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d93, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t860, i64 %t861)
  br label %bb105
bb109:
  %t862 = load i32, ptr %l222, !tbaa !23
  %t863 = icmp eq i32 %t862, 65537
  br i1 %t863, label %bb110, label %bb111
bb110:
  %t865 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t866 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t865, i64 %t866)
  %t867 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t868 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t867, i64 %t868)
  %t869 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l221, i32 0, i32 1
  %t870 = getelementptr { i64, [2 x i64] }, ptr %t869, i32 0, i32 1
  %t871 = getelementptr { { i64, ptr } }, ptr %t870, i32 0, i32 0
  %t872 = load { i64, ptr }, ptr %t871
  %t874 = extractvalue { i64, ptr } %t872, 1
  %t875 = extractvalue { i64, ptr } %t872, 0
  %t876 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t874, i64 %t875, i8 34)
  %t877 = call ptr @__olang_sb_room(ptr %s18, i64 %t876)
  %t878 = call i64 @__olang_rd_quote(ptr %t877, i64 0, ptr %t874, i64 %t875, i8 34)
  call void @__olang_sb_add(ptr %s18, i64 %t876)
  %t879 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d93, i32 0, i32 1) }, 1
  %t880 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d93, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t879, i64 %t880)
  br label %bb105
bb111:
  %t881 = load i32, ptr %l222, !tbaa !23
  %t882 = icmp eq i32 %t881, 65538
  br i1 %t882, label %bb112, label %bb113
bb112:
  %t884 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t885 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t884, i64 %t885)
  %t886 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t887 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t886, i64 %t887)
  %t888 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l221, i32 0, i32 1
  %t889 = getelementptr { i64, [2 x i64] }, ptr %t888, i32 0, i32 1
  %t890 = getelementptr { { i64, ptr } }, ptr %t889, i32 0, i32 0
  %t891 = load { i64, ptr }, ptr %t890
  %t893 = extractvalue { i64, ptr } %t891, 1
  %t894 = extractvalue { i64, ptr } %t891, 0
  %t895 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t893, i64 %t894, i8 34)
  %t896 = call ptr @__olang_sb_room(ptr %s18, i64 %t895)
  %t897 = call i64 @__olang_rd_quote(ptr %t896, i64 0, ptr %t893, i64 %t894, i8 34)
  call void @__olang_sb_add(ptr %s18, i64 %t895)
  %t898 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d93, i32 0, i32 1) }, 1
  %t899 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d93, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t898, i64 %t899)
  br label %bb105
bb113:
  %t900 = load i32, ptr %l222, !tbaa !23
  %t901 = icmp eq i32 %t900, 65539
  br i1 %t901, label %bb114, label %bb115
bb114:
  %t903 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d96, i32 0, i32 1) }, 1
  %t904 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d96, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t903, i64 %t904)
  %t905 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t906 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t905, i64 %t906)
  %t907 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l221, i32 0, i32 1
  %t908 = getelementptr { i64, [2 x i64] }, ptr %t907, i32 0, i32 1
  %t909 = getelementptr { { i64, ptr } }, ptr %t908, i32 0, i32 0
  %t910 = load { i64, ptr }, ptr %t909
  %t912 = extractvalue { i64, ptr } %t910, 1
  %t913 = extractvalue { i64, ptr } %t910, 0
  %t914 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t912, i64 %t913, i8 34)
  %t915 = call ptr @__olang_sb_room(ptr %s18, i64 %t914)
  %t916 = call i64 @__olang_rd_quote(ptr %t915, i64 0, ptr %t912, i64 %t913, i8 34)
  call void @__olang_sb_add(ptr %s18, i64 %t914)
  %t917 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d93, i32 0, i32 1) }, 1
  %t918 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d93, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t917, i64 %t918)
  br label %bb105
bb115:
  %t919 = load i32, ptr %l222, !tbaa !23
  %t920 = icmp eq i32 %t919, 65540
  br i1 %t920, label %bb116, label %bb117
bb116:
  %t922 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d97, i32 0, i32 1) }, 1
  %t923 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d97, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t922, i64 %t923)
  %t924 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t925 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t924, i64 %t925)
  %t926 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l221, i32 0, i32 1
  %t927 = getelementptr { i64, [2 x i64] }, ptr %t926, i32 0, i32 1
  %t928 = getelementptr { { i64, ptr } }, ptr %t927, i32 0, i32 0
  %t929 = load { i64, ptr }, ptr %t928
  %t931 = extractvalue { i64, ptr } %t929, 1
  %t932 = extractvalue { i64, ptr } %t929, 0
  %t933 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t931, i64 %t932, i8 34)
  %t934 = call ptr @__olang_sb_room(ptr %s18, i64 %t933)
  %t935 = call i64 @__olang_rd_quote(ptr %t934, i64 0, ptr %t931, i64 %t932, i8 34)
  call void @__olang_sb_add(ptr %s18, i64 %t933)
  %t936 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d93, i32 0, i32 1) }, 1
  %t937 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d93, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t936, i64 %t937)
  br label %bb105
bb117:
  %t938 = load i32, ptr %l222, !tbaa !23
  %t939 = icmp eq i32 %t938, 65541
  br i1 %t939, label %bb118, label %bb119
bb118:
  %t941 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d98, i32 0, i32 1) }, 1
  %t942 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d98, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t941, i64 %t942)
  %t943 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t944 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t943, i64 %t944)
  %t945 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l221, i32 0, i32 1
  %t946 = getelementptr { i64, [2 x i64] }, ptr %t945, i32 0, i32 1
  %t947 = getelementptr { { i64, ptr } }, ptr %t946, i32 0, i32 0
  %t948 = load { i64, ptr }, ptr %t947
  %t950 = extractvalue { i64, ptr } %t948, 1
  %t951 = extractvalue { i64, ptr } %t948, 0
  %t952 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t950, i64 %t951, i8 34)
  %t953 = call ptr @__olang_sb_room(ptr %s18, i64 %t952)
  %t954 = call i64 @__olang_rd_quote(ptr %t953, i64 0, ptr %t950, i64 %t951, i8 34)
  call void @__olang_sb_add(ptr %s18, i64 %t952)
  %t955 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d93, i32 0, i32 1) }, 1
  %t956 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d93, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t955, i64 %t956)
  br label %bb105
bb119:
  %t957 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d99, i32 0, i32 1) }, 1
  %t958 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d99, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t957, i64 %t958)
  %t959 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t960 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t959, i64 %t960)
  %t961 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l221, i32 0, i32 1
  %t962 = getelementptr { i64, [2 x i64] }, ptr %t961, i32 0, i32 1
  %t963 = getelementptr { { i64, ptr } }, ptr %t962, i32 0, i32 0
  %t964 = load { i64, ptr }, ptr %t963
  %t966 = extractvalue { i64, ptr } %t964, 1
  %t967 = extractvalue { i64, ptr } %t964, 0
  %t968 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t966, i64 %t967, i8 34)
  %t969 = call ptr @__olang_sb_room(ptr %s18, i64 %t968)
  %t970 = call i64 @__olang_rd_quote(ptr %t969, i64 0, ptr %t966, i64 %t967, i8 34)
  call void @__olang_sb_add(ptr %s18, i64 %t968)
  %t971 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d93, i32 0, i32 1) }, 1
  %t972 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d93, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t971, i64 %t972)
  br label %bb105
bb120:
  store i32 65536, ptr %l240, !tbaa !23
  call void @__olang_scope_close(ptr %s17)
  %t973 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t975 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t973)
  store i32 %t975, ptr %l242
  %t976 = icmp ne i32 %t975, 0
  br i1 %t976, label %bb122, label %ok.977, !prof !99
ok.977:
  br label %bb121
bb121:
  br label %bb126
bb122:
  %t978 = load i32, ptr %l242, !tbaa !23
  %t979 = ashr i32 %t978, 16
  %t981 = icmp eq i32 %t979, 1
  store i1 %t981, ptr %l244, !tbaa !21
  %t982 = load i32, ptr %l242, !tbaa !23
  %t983 = ashr i32 %t982, 16
  %t985 = icmp eq i32 %t983, 1
  br i1 %t985, label %bb123, label %bb124
bb123:
  call void @__olang_errpay_pop()
  br label %bb124
bb124:
  br label %bb125
bb125:
  br label %bb126
bb126:
  call void @__olang_scope_close(ptr %s0)
  %t987 = load i32, ptr %l240, !tbaa !23
  store i32 %t987, ptr %rv
  br label %ret
bb127:
  %t988 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t988, ptr %l247, !tbaa !27
  %t989 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t991 = call { i64, ptr } @compiler_2ffix_2ebuiltBy(ptr %v0, ptr %s0, { i64, ptr } %t989)
  store { i64, ptr } %t991, ptr %l249
  br label %bb128
bb128:
  %t992 = load { i64, ptr }, ptr %l249, !tbaa !27
  %t994 = extractvalue { i64, ptr } %t992, 0
  %t995 = extractvalue { i64, ptr } %t992, 1
  %t996 = mul i64 %t994, 1
  %t997 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t996)
  call void @llvm.memcpy.p0.p0.i64(ptr %t997, ptr %t995, i64 %t996, i1 false)
  %t998 = insertvalue { i64, ptr } undef, i64 %t994, 0
  %t999 = insertvalue { i64, ptr } %t998, ptr %t997, 1
  %t1000 = load { i64, ptr }, ptr %l247, !tbaa !27
  %t1002 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t1000, { i64, ptr } %t999)
  store i32 %t1002, ptr %l252
  %t1003 = icmp ne i32 %t1002, 0
  br i1 %t1003, label %bb130, label %ok.1004, !prof !99
ok.1004:
  br label %bb129
bb129:
  br label %bb134
bb130:
  %t1005 = load i32, ptr %l252, !tbaa !23
  %t1006 = ashr i32 %t1005, 16
  %t1008 = icmp eq i32 %t1006, 1
  store i1 %t1008, ptr %l254, !tbaa !21
  %t1009 = load i32, ptr %l252, !tbaa !23
  %t1010 = ashr i32 %t1009, 16
  %t1012 = icmp eq i32 %t1010, 1
  br i1 %t1012, label %bb131, label %bb132
bb131:
  call void @__olang_errpay_pop()
  br label %bb132
bb132:
  br label %bb133
bb133:
  br label %bb134
bb134:
  %t1014 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t1016 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t1014)
  store i32 %t1016, ptr %l258
  %t1017 = icmp ne i32 %t1016, 0
  br i1 %t1017, label %bb136, label %ok.1018, !prof !99
ok.1018:
  br label %bb135
bb135:
  br label %bb140
bb136:
  %t1019 = load i32, ptr %l258, !tbaa !23
  %t1020 = ashr i32 %t1019, 16
  %t1022 = icmp eq i32 %t1020, 1
  store i1 %t1022, ptr %l260, !tbaa !21
  %t1023 = load i32, ptr %l258, !tbaa !23
  %t1024 = ashr i32 %t1023, 16
  %t1026 = icmp eq i32 %t1024, 1
  br i1 %t1026, label %bb137, label %bb138
bb137:
  call void @__olang_errpay_pop()
  br label %bb138
bb138:
  br label %bb139
bb139:
  br label %bb140
bb140:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffix_2eexpand(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %lp1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca { i64, ptr }
  %l18 = alloca i1
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  br label %bb5
bb5:
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t19, ptr %l14, !tbaa !27
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %t23, i64 %t20
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !37
  store { i64, ptr } %t25, ptr %l5, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t29 = call i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %t27)
  store i1 %t29, ptr %l18
  br label %bb6
bb6:
  %t30 = load i1, ptr %l18, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  %t31 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t32 = load ptr, ptr %lp1
  call void @compiler_2ffix_2ewalk(ptr %v0, ptr %v1, { i64, ptr } %t31, ptr %t32)
  br label %bb9
bb8:
  %t35 = load ptr, ptr %lp1
  %t36 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 1
  %t39 = extractvalue { i64, ptr } %t36, 0
  %t40 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t39)
  call void @olang_textcopy(ptr %t40, ptr %t38, i64 %t39)
  %t41 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t45 = extractvalue { i64, ptr } %t42, 1
  %t46 = mul i64 %t44, 1
  %t47 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t46)
  call void @llvm.memcpy.p0.p0.i64(ptr %t47, ptr %t45, i64 %t46, i1 false)
  %t48 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t35, { i64, ptr } %t49)
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t52 = load i64, ptr %l3, !tbaa !24
  %t54 = add i64 %t52, 1
  store i64 %t54, ptr %l3, !tbaa !24
  br label %bb2
bb13:
  %t56 = load ptr, ptr %lp1
  %t57 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t56
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t57, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i64 @compiler_2ffix_2emtime(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/os:FileInfo"
  %l2 = alloca %"std/os:FileInfo"
  %l4 = alloca %"std/os:FileInfo"
  %l5 = alloca i32
  %l7 = alloca i1
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %v0, { i64, ptr } %a0)
  %t4 = extractvalue { i32, %"std/os:FileInfo" } %t3, 1
  %t5 = extractvalue { i32, %"std/os:FileInfo" } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store %"std/os:FileInfo" %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load %"std/os:FileInfo", ptr %l4
  store %"std/os:FileInfo" %t8, ptr %l2
  br label %bb6
bb2:
  %t9 = load i32, ptr %l5, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  store i1 %t12, ptr %l7, !tbaa !21
  %t13 = load i32, ptr %l5, !tbaa !23
  %t14 = ashr i32 %t13, 16
  %t16 = icmp eq i32 %t14, 1
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  store i64 0, ptr %rv
  br label %ret
bb6:
  %t19 = load %"std/os:FileInfo", ptr %l2
  store %"std/os:FileInfo" %t19, ptr %l1
  %t20 = getelementptr %"std/os:FileInfo", ptr %l1, i32 0, i32 2
  %t21 = load i64, ptr %t20, !tbaa !24
  store i64 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ffix_2enewest(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca [2 x { i64, ptr }]
  %l8 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i32
  %l24 = alloca { i64, ptr }
  %l28 = alloca i1
  %l29 = alloca i64
  %l35 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %s0, { i64, ptr } %t1)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l11
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l10
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t8, ptr %l8, !tbaa !27
  br label %bb10
bb2:
  %t9 = load i32, ptr %l11, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  br i1 %t12, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  %t14 = icmp sge i64 0, 0
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t16 = icmp sle i64 0, 576460752303423487
  br i1 %t16, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_8fcf87cfa7be21dd_bbd76dac3520f231)
  unreachable
bb8:
  %t18 = mul i64 0, 16
  %t19 = insertvalue { i64, ptr } undef, i64 0, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t20, ptr %l8, !tbaa !27
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_8fcf87cfa7be21dd_bbd76dac3520f231)
  unreachable
bb10:
  %t22 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t22, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  store i64 %t27, ptr %l5, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t29 = load i64, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb13:
  br label %bb14
bb14:
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t37, ptr %l24, !tbaa !27
  %t38 = load i64, ptr %l4, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %t41, i64 %t38
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !37
  store { i64, ptr } %t43, ptr %l6, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t47 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s2, { i64, ptr } %t45, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d100, i32 0, i32 1) })
  store i1 %t47, ptr %l28
  br label %bb15
bb15:
  %t48 = load i1, ptr %l28, !tbaa !21
  br i1 %t48, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t49 = load i64, ptr %l1, !tbaa !24
  store i64 %t49, ptr %l29, !tbaa !24
  %t50 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t53 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t50, 0
  %t55 = insertvalue [2 x { i64, ptr }] %t53, { i64, ptr } %t51, 1
  store [2 x { i64, ptr }] %t55, ptr %l7
  %t58 = insertvalue { i64, ptr } undef, i64 2, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %l7, 1
  %t61 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s3, ptr %s3, { i64, ptr } %t59)
  store { i64, ptr } %t61, ptr %l35
  br label %bb18
bb17:
  br label %bb21
bb18:
  %t62 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t62, 0
  %t64 = extractvalue { i64, ptr } %t62, 1
  %t65 = mul i64 %t63, 1
  %t66 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t65)
  call void @llvm.memcpy.p0.p0.i64(ptr %t66, ptr %t64, i64 %t65, i1 false)
  %t67 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  %t70 = call i64 @compiler_2ffix_2emtime(ptr %s3, { i64, ptr } %t68)
  store i64 %t70, ptr %l37
  br label %bb19
bb19:
  %t71 = load i64, ptr %l29, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t71, i64 %t72)
  store i64 %t73, ptr %l38
  br label %bb20
bb20:
  %t74 = load i64, ptr %l38, !tbaa !24
  store i64 %t74, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  %t75 = load i64, ptr %l4, !tbaa !24
  %t77 = add i64 %t75, 1
  store i64 %t77, ptr %l4, !tbaa !24
  br label %bb11
bb23:
  %t79 = load i64, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t79, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffix_2ewalk(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca [2 x { i64, ptr }]
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i32
  %l25 = alloca { i64, ptr }
  %l29 = alloca i1
  %l30 = alloca i1
  %l32 = alloca i1
  %l38 = alloca { i64, ptr }
  %l40 = alloca i1
  %l44 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %s0, { i64, ptr } %t1)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l12
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l11
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t8, ptr %l9, !tbaa !27
  br label %bb10
bb2:
  %t9 = load i32, ptr %l12, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  br i1 %t12, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  %t14 = icmp sge i64 0, 0
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t16 = icmp sle i64 0, 576460752303423487
  br i1 %t16, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_9433da86f750b978_3ff5b65d50af9d4)
  unreachable
bb8:
  %t18 = mul i64 0, 16
  %t19 = insertvalue { i64, ptr } undef, i64 0, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t20, ptr %l9, !tbaa !27
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_9433da86f750b978_3ff5b65d50af9d4)
  unreachable
bb10:
  %t22 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t22, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  store i64 %t27, ptr %l5, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t29 = load i64, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb35
bb13:
  br label %bb14
bb14:
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t37, ptr %l25, !tbaa !27
  %t38 = load i64, ptr %l4, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %t41, i64 %t38
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !37
  store { i64, ptr } %t43, ptr %l6, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t47 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s2, { i64, ptr } %t45, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d101, i32 0, i32 1) })
  store i1 %t47, ptr %l29
  br label %bb15
bb15:
  %t48 = load i1, ptr %l29, !tbaa !21
  br i1 %t48, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb19
bb17:
  %t49 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t51 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s2, { i64, ptr } %t49, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d102, i32 0, i32 1) })
  store i1 %t51, ptr %l32
  br label %bb18
bb18:
  %t52 = load i1, ptr %l32, !tbaa !21
  store i1 %t52, ptr %l30, !tbaa !21
  br label %bb19
bb19:
  %t53 = load i1, ptr %l30, !tbaa !21
  br i1 %t53, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb21:
  br label %bb22
bb22:
  %t54 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t57 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t54, 0
  %t59 = insertvalue [2 x { i64, ptr }] %t57, { i64, ptr } %t55, 1
  store [2 x { i64, ptr }] %t59, ptr %l7
  %t62 = insertvalue { i64, ptr } undef, i64 2, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %l7, 1
  %t65 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s2, ptr %s2, { i64, ptr } %t63)
  store { i64, ptr } %t65, ptr %l38
  br label %bb23
bb23:
  %t66 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t66, ptr %l8, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t69 = call i1 @std_2fos_2eIsDir(ptr %s2, { i64, ptr } %t67)
  store i1 %t69, ptr %l40
  br label %bb24
bb24:
  %t70 = load i1, ptr %l40, !tbaa !21
  br i1 %t70, label %bb25, label %bb26
bb25:
  %t71 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t72 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ffix_2ewalk(ptr %s2, ptr %v1, { i64, ptr } %t71, ptr %t72)
  br label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t75 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t77 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s5, { i64, ptr } %t75, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d103, i32 0, i32 1) })
  store i1 %t77, ptr %l44
  br label %bb28
bb27:
  br label %bb33
bb28:
  %t78 = load i1, ptr %l44, !tbaa !21
  br i1 %t78, label %bb29, label %bb30
bb29:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t80 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t80, 1
  %t83 = extractvalue { i64, ptr } %t80, 0
  %t84 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t83)
  call void @olang_textcopy(ptr %t84, ptr %t82, i64 %t83)
  %t85 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = extractvalue { i64, ptr } %t86, 1
  %t90 = mul i64 %t88, 1
  %t91 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t90)
  call void @llvm.memcpy.p0.p0.i64(ptr %t91, ptr %t89, i64 %t90, i1 false)
  %t92 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t79, { i64, ptr } %t93)
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s5)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb34:
  %t96 = load i64, ptr %l4, !tbaa !24
  %t98 = add i64 %t96, 1
  store i64 %t98, ptr %l4, !tbaa !24
  br label %bb11
bb35:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

declare void @__olang_errpay_pop()
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d0 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fix" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d1 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d2 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c": cannot be read\0A" }>, align 8
@.d3 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"olang: fix: no tools directory at " }>, align 8
@.d4 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c" (OLANG_TOOLS names another)\0A" }>, align 8
@.d5 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"olang: fix: cannot make " }>, align 8
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d7 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"tools_" }>, align 8
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d9 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare ptr @__olang_errpay_top_get()
define linkonce_odr { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fos_3aError_7d(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i32, { i64, [2 x i64] } }
  %l3 = alloca { i64, [2 x i64] }
  %rv = alloca { i32, { i64, [2 x i64] } }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i32, { i64, [2 x i64] } }, ptr %a0
  store { i32, { i64, [2 x i64] } } %t2, ptr %l1
  %t3 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l1, i32 0, i32 1
  %t5 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fos_3aError_24payload(ptr %v0, ptr %t3)
  store { i64, [2 x i64] } %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load { i64, [2 x i64] }, ptr %l3
  %t7 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l1, i32 0, i32 1
  store { i64, [2 x i64] } %t6, ptr %t7
  %t8 = load { i32, { i64, [2 x i64] } }, ptr %l1
  store { i32, { i64, [2 x i64] } } %t8, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, [2 x i64] } }, ptr %rv
  ret { i32, { i64, [2 x i64] } } %rr
}

@.d10 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"olang: fix: cannot run " }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
@.d11 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d12 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
declare void @__olang_sb_done(ptr)
@.d13 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d14 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"os.Error.NotFound" }>, align 8
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
declare i64 @__olang_rd_quote(ptr, i64, ptr, i64, i8)
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare void @__olang_sb_add(ptr, i64)
@.d16 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d17 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Exists" }>, align 8
@.d18 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Denied" }>, align 8
@.d19 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.NotDir" }>, align 8
@.d20 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"os.Error.IsDir" }>, align 8
@.d21 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"os.Error.NotEmpty" }>, align 8
@.d22 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Failed" }>, align 8
@.d23 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c":\0A" }>, align 8
@.d24 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d25 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d26 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d27 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d28 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c": cannot be written\0A" }>, align 8
@.d29 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d30 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d31 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"olang fix: " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d32 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" place" }>, align 8
@.d33 = private constant <{ i64, [89 x i8] }> <{ i64 0, [89 x i8] c" above may mean something else in the language of today than when written - look at each\0A" }>, align 8
@.d34 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"text" }>, align 8
@.d35 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"driven" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d36 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"driven" }>, align 8
@.d37 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"OLANG_TOOLS" }>, align 8
@.d38 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d39 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d40 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"/../tools" }>, align 8
@.d41 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"--std" }>, align 8
@.d42 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"--olang" }>, align 8
@.d43 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d44 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d45 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"by hand:" }>, align 8
@.d46 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"for a person:" }>, align 8
@.d47 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d48 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"tools_" }>, align 8
@.d49 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".from" }>, align 8
@.d50 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d51 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"prelude" }>, align 8
@.d52 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"../compiler" }>, align 8
@.d53 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"tools_" }>, align 8
@.d54 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d55 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"olang: fix: cannot build tools/" }>, align 8
@.d56 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c".olang: " }>, align 8
@.d57 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d58 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d59 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"os.Error.NotFound" }>, align 8
@.d60 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d61 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d62 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Exists" }>, align 8
@.d63 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Denied" }>, align 8
@.d64 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.NotDir" }>, align 8
@.d65 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"os.Error.IsDir" }>, align 8
@.d66 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"os.Error.NotEmpty" }>, align 8
@.d67 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Failed" }>, align 8
@.d68 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"tools_" }>, align 8
@.d69 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@.d70 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"build" }>, align 8
@.d71 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"-output" }>, align 8
@.d72 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"olang: fix: cannot run " }>, align 8
@.d73 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d74 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d75 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d76 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"os.Error.NotFound" }>, align 8
@.d77 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d78 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d79 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Exists" }>, align 8
@.d80 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Denied" }>, align 8
@.d81 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.NotDir" }>, align 8
@.d82 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"os.Error.IsDir" }>, align 8
@.d83 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"os.Error.NotEmpty" }>, align 8
@.d84 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Failed" }>, align 8
@.d85 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"olang: fix: tools/" }>, align 8
@.d86 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c".olang does not build:\0A" }>, align 8
@.d87 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"olang: fix: cannot put tools_" }>, align 8
@.d88 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c" in place: " }>, align 8
@.d89 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d90 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d91 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"os.Error.NotFound" }>, align 8
@.d92 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d93 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d94 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Exists" }>, align 8
@.d95 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Denied" }>, align 8
@.d96 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.NotDir" }>, align 8
@.d97 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"os.Error.IsDir" }>, align 8
@.d98 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"os.Error.NotEmpty" }>, align 8
@.d99 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Failed" }>, align 8
@__olang_empty_array = external constant [16 x i64]
@.d100 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@.d101 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d102 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"build" }>, align 8
@.d103 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
define linkonce_odr { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fos_3aError_24payload(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %rv = alloca { i64, [2 x i64] }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, [2 x i64] }, ptr %a0
  store { i64, [2 x i64] } %t2, ptr %l1
  %t3 = load i64, ptr %l1, !range !{i64 0, i64 7}
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 ]
bb1:
  %t5 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t5, ptr %rv
  br label %ret
bb2:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, ptr } }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l5, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = mul i64 %t20, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t24 = getelementptr { { i64, ptr } }, ptr %t23, i32 0, i32 0
  store { i64, ptr } %t22, ptr %t24
  br label %bb1
bb3:
  %t25 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t26 = getelementptr { { i64, ptr } }, ptr %t25, i32 0, i32 0
  %t27 = load { i64, ptr }, ptr %t26
  store { i64, ptr } %t27, ptr %l6, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l7, !tbaa !24
  %t30 = load i64, ptr %l7, !tbaa !24
  %t31 = mul i64 %t30, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l8, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = load i64, ptr %l7, !tbaa !24
  %t40 = mul i64 %t39, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t36, ptr %t38, i64 %t40, i1 false)
  %t41 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t42 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t43 = getelementptr { { i64, ptr } }, ptr %t42, i32 0, i32 0
  store { i64, ptr } %t41, ptr %t43
  br label %bb1
bb4:
  %t44 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t45 = getelementptr { { i64, ptr } }, ptr %t44, i32 0, i32 0
  %t46 = load { i64, ptr }, ptr %t45
  store { i64, ptr } %t46, ptr %l9, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t47, 0
  store i64 %t48, ptr %l10, !tbaa !24
  %t49 = load i64, ptr %l10, !tbaa !24
  %t50 = mul i64 %t49, 1
  %t51 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t50)
  %t52 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t51, 1
  store { i64, ptr } %t53, ptr %l11, !tbaa !27
  %t54 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = load i64, ptr %l10, !tbaa !24
  %t59 = mul i64 %t58, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t55, ptr %t57, i64 %t59, i1 false)
  %t60 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t61 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t62 = getelementptr { { i64, ptr } }, ptr %t61, i32 0, i32 0
  store { i64, ptr } %t60, ptr %t62
  br label %bb1
bb5:
  %t63 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t64 = getelementptr { { i64, ptr } }, ptr %t63, i32 0, i32 0
  %t65 = load { i64, ptr }, ptr %t64
  store { i64, ptr } %t65, ptr %l12, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  store i64 %t67, ptr %l13, !tbaa !24
  %t68 = load i64, ptr %l13, !tbaa !24
  %t69 = mul i64 %t68, 1
  %t70 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t69)
  %t71 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l14, !tbaa !27
  %t73 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l13, !tbaa !24
  %t78 = mul i64 %t77, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t74, ptr %t76, i64 %t78, i1 false)
  %t79 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t80 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t81 = getelementptr { { i64, ptr } }, ptr %t80, i32 0, i32 0
  store { i64, ptr } %t79, ptr %t81
  br label %bb1
bb6:
  %t82 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t83 = getelementptr { { i64, ptr } }, ptr %t82, i32 0, i32 0
  %t84 = load { i64, ptr }, ptr %t83
  store { i64, ptr } %t84, ptr %l15, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 0
  store i64 %t86, ptr %l16, !tbaa !24
  %t87 = load i64, ptr %l16, !tbaa !24
  %t88 = mul i64 %t87, 1
  %t89 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t88)
  %t90 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  store { i64, ptr } %t91, ptr %l17, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = load i64, ptr %l16, !tbaa !24
  %t97 = mul i64 %t96, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t93, ptr %t95, i64 %t97, i1 false)
  %t98 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t99 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t100 = getelementptr { { i64, ptr } }, ptr %t99, i32 0, i32 0
  store { i64, ptr } %t98, ptr %t100
  br label %bb1
bb7:
  %t101 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t102 = getelementptr { { i64, ptr } }, ptr %t101, i32 0, i32 0
  %t103 = load { i64, ptr }, ptr %t102
  store { i64, ptr } %t103, ptr %l18, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  store i64 %t105, ptr %l19, !tbaa !24
  %t106 = load i64, ptr %l19, !tbaa !24
  %t107 = mul i64 %t106, 1
  %t108 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t107)
  %t109 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  store { i64, ptr } %t110, ptr %l20, !tbaa !27
  %t111 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = load i64, ptr %l19, !tbaa !24
  %t116 = mul i64 %t115, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t112, ptr %t114, i64 %t116, i1 false)
  %t117 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t118 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t119 = getelementptr { { i64, ptr } }, ptr %t118, i32 0, i32 0
  store { i64, ptr } %t117, ptr %t119
  br label %bb1
bb8:
  %t120 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t121 = getelementptr { { i64, ptr } }, ptr %t120, i32 0, i32 0
  %t122 = load { i64, ptr }, ptr %t121
  store { i64, ptr } %t122, ptr %l21, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  store i64 %t124, ptr %l22, !tbaa !24
  %t125 = load i64, ptr %l22, !tbaa !24
  %t126 = mul i64 %t125, 1
  %t127 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t126)
  %t128 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  store { i64, ptr } %t129, ptr %l23, !tbaa !27
  %t130 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = load i64, ptr %l22, !tbaa !24
  %t135 = mul i64 %t134, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t131, ptr %t133, i64 %t135, i1 false)
  %t136 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t137 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t138 = getelementptr { { i64, ptr } }, ptr %t137, i32 0, i32 0
  store { i64, ptr } %t136, ptr %t138
  br label %bb1
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

declare ptr @__olang_sb_grow(ptr, i64) noinline
declare { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2ffetch_2eCacheDir(ptr %v0)
declare { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_74a546a3dd225c9b_f3beb7f3829b0fbf = external constant [0 x i8]
declare %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %v0, i32 %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %v0, ptr %a0)
declare i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
@olang_loc_299e69389bcee8f2_b185402659ea7d46 = external constant [0 x i8]
declare { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2ffilepath_2eDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %v0, { i64, ptr } %a0)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eRemoveAll(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fos_2eRename(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_8fcf87cfa7be21dd_bbd76dac3520f231 = external constant [0 x i8]
@olang_loc_9433da86f750b978_3ff5b65d50af9d4 = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
