; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/io:Writer" = type { i32, { i64, ptr }, i64, i32 }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"std/os:FileInfo" = type { i32, i64, i64 }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
@G_2ecompiler_2ffix_2eBatch = constant <{ [8 x i8] }> <{ [8 x i8] c"\C8\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eDrivenArg = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eDrivenOpt = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eStdTool = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eTextTool = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eToolKinds = constant <{ [256 x i8] }> <{ [256 x i8] c"\01\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\03\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2ffix_2eToolNames = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k1, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k2, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k3, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k4, [8 x i8] c"\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k5, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k6, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k7, [8 x i8] c"\0C\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k8, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k9, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k10, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k11, [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k12, [8 x i8] c"\0C\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k13, [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k14, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k15, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k16, [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k17, [8 x i8] c"\0B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k18, [8 x i8] c"\0A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k19, [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k20, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k21, [8 x i8] c"\0C\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k22, [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k23, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k24, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k25, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k26, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k27, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k28, [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k29, [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k30, [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k31, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k32 }>, align 64
@G_2ecompiler_2ffix_2eToolNames.k1 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\62\61\72\65\5F\74\79\70\65\76\61\72\73" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k2 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\70\65\72\6D\5F\6D\75\74" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k3 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\69\6E\74\5F\6C\69\74\65\72\61\6C\5F\69\36\34" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k4 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\65\72\72\6F\72\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k5 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\63\6C\69\5F\77\6F\72\64\73" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k6 = internal constant <{ [16 x i8] }> <{ [16 x i8] c"\64\6F\6E\65\66\61\69\6C\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k7 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\73\79\6E\74\61\78\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k8 = internal constant <{ [12 x i8] }> <{ [12 x i8] c"\6D\61\74\68\5F\6D\65\74\68\6F\64\73" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k9 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\61\72\72\61\79\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k10 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\72\65\73\75\6C\74\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k11 = internal constant <{ [16 x i8] }> <{ [16 x i8] c"\65\71\75\61\6C\69\74\79\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k12 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\68\65\6C\70\65\72\5F\72\65\6E\61\6D\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k13 = internal constant <{ [12 x i8] }> <{ [12 x i8] c"\6E\75\6C\6C\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k14 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\63\68\65\63\6B\65\72\72\6F\72\5F\72\65\6E\61\6D\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k15 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\73\74\75\74\74\65\72\5F\72\65\6E\61\6D\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k16 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\63\68\65\63\6B\65\64\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k17 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\63\6F\6E\74\72\61\63\74\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k18 = internal constant <{ [11 x i8] }> <{ [11 x i8] c"\74\72\79\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k19 = internal constant <{ [10 x i8] }> <{ [10 x i8] c"\61\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k20 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\65\72\72\6F\72\74\79\70\65\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k21 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\6C\69\73\74\5F\76\65\63" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k22 = internal constant <{ [12 x i8] }> <{ [12 x i8] c"\6C\69\6E\6B\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k23 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\6D\61\74\63\68\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k24 = internal constant <{ [16 x i8] }> <{ [16 x i8] c"\71\75\65\73\74\69\6F\6E\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k25 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\75\6E\75\73\65\64\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k26 = internal constant <{ [16 x i8] }> <{ [16 x i8] c"\65\72\72\6F\72\63\61\73\65\5F\72\65\6E\61\6D\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k27 = internal constant <{ [16 x i8] }> <{ [16 x i8] c"\76\61\72\69\61\64\69\63\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k28 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\73\63\6F\70\65\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k29 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\66\6E\72\65\66\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k30 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\63\6C\6F\6E\65\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k31 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\74\65\78\74\62\75\69\6C\64\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k32 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\75\6E\69\71\75\65\5F\6D\69\67\72\61\74\65" }>, align 8
define dso_local { i64, ptr } @compiler_2ffix_2eBinDir(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca [2 x { i64, ptr }]
  %l6 = alloca [2 x { i64, ptr }]
  %l7 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l14 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i32
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l47 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %s0, { i64, ptr } %t1)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l10
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l9
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t8, ptr %l7, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 1
  %t12 = extractvalue { i64, ptr } %t9, 0
  %t13 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t11, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l7, !tbaa !27
  br label %bb4
bb4:
  %t24 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t24, ptr %l2, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t27 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v1, ptr %s0, { i64, ptr } %t25)
  %t28 = extractvalue { i32, { i64, ptr } } %t27, 1
  %t29 = extractvalue { i32, { i64, ptr } } %t27, 0
  store i32 %t29, ptr %l17
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb6, label %ok.31, !prof !99
ok.31:
  store { i64, ptr } %t28, ptr %l16
  br label %bb5
bb5:
  %t32 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t32, ptr %l14, !tbaa !27
  br label %bb8
bb6:
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  %t33 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 1
  %t36 = extractvalue { i64, ptr } %t33, 0
  %t37 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t36)
  call void @olang_textcopy(ptr %t37, ptr %t35, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t42 = extractvalue { i64, ptr } %t39, 1
  %t43 = mul i64 %t41, 1
  %t44 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t43)
  call void @llvm.memcpy.p0.p0.i64(ptr %t44, ptr %t42, i64 %t43, i1 false)
  %t45 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t44, 1
  store { i64, ptr } %t46, ptr %l14, !tbaa !27
  br label %bb8
bb8:
  %t48 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t49 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %l21
  br label %bb9
bb9:
  %t50 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t50, ptr %l4
  %t51 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t51, 1
  %t54 = extractvalue { i64, ptr } %t51, 0
  %t55 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t54)
  call void @olang_textcopy(ptr %t55, ptr %t53, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t60 = extractvalue { i64, ptr } %t57, 1
  %t61 = mul i64 %t59, 1
  %t62 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t61)
  call void @llvm.memcpy.p0.p0.i64(ptr %t62, ptr %t60, i64 %t61, i1 false)
  %t63 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } %t64)
  br label %bb10
bb10:
  %t67 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 1
  %t70 = extractvalue { i64, ptr } %t67, 0
  %t71 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t70)
  call void @olang_textcopy(ptr %t71, ptr %t69, i64 %t70)
  %t72 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t71, 1
  %t75 = extractvalue { i64, ptr } %t73, 0
  %t76 = extractvalue { i64, ptr } %t73, 1
  %t77 = mul i64 %t75, 1
  %t78 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t77)
  call void @llvm.memcpy.p0.p0.i64(ptr %t78, ptr %t76, i64 %t77, i1 false)
  %t79 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t78, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } %t80)
  br label %bb11
bb11:
  %t83 = call { i64, ptr } @compiler_2ffetch_2eCacheDir(ptr %s0)
  store { i64, ptr } %t83, ptr %l30
  br label %bb12
bb12:
  %t84 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 0
  %t86 = extractvalue { i64, ptr } %t84, 1
  %t87 = mul i64 %t85, 1
  %t88 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t87)
  call void @llvm.memcpy.p0.p0.i64(ptr %t88, ptr %t86, i64 %t87, i1 false)
  %t89 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  %t92 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t90, 0
  %t93 = insertvalue [2 x { i64, ptr }] %t92, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  store [2 x { i64, ptr }] %t93, ptr %l5
  %t96 = insertvalue { i64, ptr } undef, i64 2, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %l5, 1
  %t99 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t97)
  store { i64, ptr } %t99, ptr %l35
  br label %bb13
bb13:
  %t100 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t102 = extractvalue { i64, ptr } %t100, 1
  %t103 = mul i64 %t101, 1
  %t104 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t103)
  call void @llvm.memcpy.p0.p0.i64(ptr %t104, ptr %t102, i64 %t103, i1 false)
  %t105 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  store { i64, ptr } %t106, ptr %l36, !tbaa !27
  %t108 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s0, ptr %s0, ptr %l4)
  store { i64, ptr } %t108, ptr %l38
  br label %bb14
bb14:
  %t109 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  store i64 %t110, ptr %l39, !tbaa !24
  %t111 = icmp sge i64 0, 0
  br i1 %t111, label %bb15, label %bb16
bb15:
  %t113 = icmp sle i64 0, 16
  br i1 %t113, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_74a546a3dd225c9b_f3beb7f3829b0fbf)
  unreachable
bb17:
  %t115 = load i64, ptr %l39, !tbaa !24
  %t116 = icmp sle i64 16, %t115
  br i1 %t116, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_74a546a3dd225c9b_f3beb7f3829b0fbf)
  unreachable
bb19:
  %t118 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr i8, ptr %t119, i64 0
  %t121 = sub i64 16, 0
  %t122 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t120, 1
  %t124 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t125 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t124, 0
  %t127 = insertvalue [2 x { i64, ptr }] %t125, { i64, ptr } %t123, 1
  store [2 x { i64, ptr }] %t127, ptr %l6
  %t130 = insertvalue { i64, ptr } undef, i64 2, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %l6, 1
  %t133 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %v2, { i64, ptr } %t131)
  store { i64, ptr } %t133, ptr %l47
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_74a546a3dd225c9b_f3beb7f3829b0fbf)
  unreachable
bb21:
  call void @__olang_scope_close(ptr %s0)
  %t134 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t134, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2ffix_2eFiles(ptr %v0, ptr %v1, ptr %v2, i1 %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca i1
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/io:Writer"
  %l5 = alloca %"std/io:Writer"
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca [2 x { i64, ptr }]
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l31 = alloca %"std/os:Output"
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l43 = alloca %"std/io:Writer"
  %l44 = alloca %"std/io:Writer"
  %l46 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l48 = alloca { i64, ptr }
  %l49 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l57 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l63 = alloca i32
  %l65 = alloca i1
  %l72 = alloca i32
  %l74 = alloca i1
  %l83 = alloca { i64, ptr }
  %l85 = alloca i1
  %l93 = alloca i32
  %l95 = alloca i1
  %l99 = alloca { i64, ptr }
  %l101 = alloca i32
  %l103 = alloca i1
  %l110 = alloca i32
  %l112 = alloca i1
  %l114 = alloca { i64, ptr }
  %l122 = alloca { i64, ptr }
  %l133 = alloca i32
  %l135 = alloca i1
  %l143 = alloca { i64, ptr }
  %l150 = alloca i64
  %l153 = alloca i64
  %l171 = alloca { i64, ptr }
  %l172 = alloca i64
  %l178 = alloca i64
  %l179 = alloca i64
  %l184 = alloca %"std/os:Output"
  %l191 = alloca { i64, ptr }
  %l193 = alloca { i64, ptr }
  %l194 = alloca %"std/os:Output"
  %l195 = alloca i32
  %l197 = alloca i1
  %l207 = alloca i64
  %l210 = alloca i1
  %l220 = alloca i1
  %l223 = alloca { i64, ptr }
  %l240 = alloca i64
  %l243 = alloca i64
  %l261 = alloca { i64, ptr }
  %l262 = alloca { i64, ptr }
  %l265 = alloca { i64, ptr }
  %l266 = alloca i32
  %l268 = alloca i1
  %l269 = alloca { i64, ptr }
  %l272 = alloca { i64, ptr }
  %l273 = alloca i1
  %l277 = alloca { i64, ptr }
  %l284 = alloca { i64, ptr }
  %l286 = alloca { i64, ptr }
  %l289 = alloca { i64, ptr }
  %l291 = alloca i32
  %l293 = alloca i1
  %l295 = alloca { i64, ptr }
  %l305 = alloca i1
  %l310 = alloca { i64, ptr }
  %l318 = alloca i32
  %l320 = alloca i1
  %l323 = alloca i32
  %l325 = alloca i1
  %l331 = alloca i1
  %l334 = alloca i1
  %l337 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %rv = alloca i32
  store i1 %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %s0, i32 2, i64 65536)
  store %"std/io:Writer" %t1, ptr %l43
  br label %bb1
bb1:
  %t2 = load %"std/io:Writer", ptr %l43
  store %"std/io:Writer" %t2, ptr %l4
  %t3 = call %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %s0, i32 1, i64 65536)
  store %"std/io:Writer" %t3, ptr %l44
  br label %bb2
bb2:
  %t4 = load %"std/io:Writer", ptr %l44
  store %"std/io:Writer" %t4, ptr %l5
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffix_2eexpand(ptr %v0, ptr %s0, { i64, ptr } %a1)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l46
  br label %bb3
bb3:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l46
  %t9 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %t9
  %t11 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s0, ptr %s0, ptr %t9)
  store { i64, ptr } %t11, ptr %l48
  br label %bb4
bb4:
  %t12 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t12, ptr %l6, !tbaa !27
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l49
  br label %bb5
bb5:
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l49
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l7
  %t15 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t15, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  store i64 %t19, ptr %l10, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t21 = load i64, ptr %l9, !tbaa !24
  %t22 = load i64, ptr %l10, !tbaa !24
  %t25 = icmp slt i64 %t21, %t22
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb8:
  br label %bb9
bb9:
  %t29 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t29, ptr %l57, !tbaa !27
  %t30 = load i64, ptr %l9, !tbaa !24
  %t32 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr { i64, ptr }, ptr %t33, i64 %t30
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !37
  store { i64, ptr } %t35, ptr %l11, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t39 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s2, { i64, ptr } %t37)
  %t40 = extractvalue { i32, { i64, ptr } } %t39, 1
  %t41 = extractvalue { i32, { i64, ptr } } %t39, 0
  store i32 %t41, ptr %l63
  %t42 = icmp ne i32 %t41, 0
  br i1 %t42, label %bb11, label %ok.43, !prof !99
ok.43:
  store { i64, ptr } %t40, ptr %l62
  br label %bb10
bb10:
  %t44 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t44, ptr %l60, !tbaa !27
  br label %bb18
bb11:
  %t45 = load i32, ptr %l63, !tbaa !23
  %t46 = ashr i32 %t45, 16
  %t48 = icmp eq i32 %t46, 1
  store i1 %t48, ptr %l65, !tbaa !21
  br label %bb12
bb12:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s3
  %t49 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t50 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t51 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t53 = extractvalue { i64, ptr } %t49, 1
  %t54 = extractvalue { i64, ptr } %t49, 0
  %t55 = add i64 %t51, %t54
  %t56 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t57 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t58 = add i64 %t55, %t57
  %t59 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t58)
  call void @olang_textcopy(ptr %t59, ptr %t50, i64 %t51)
  %t60 = getelementptr i8, ptr %t59, i64 %t51
  call void @olang_textcopy(ptr %t60, ptr %t53, i64 %t54)
  %t61 = getelementptr i8, ptr %t60, i64 %t54
  call void @olang_textcopy(ptr %t61, ptr %t56, i64 %t57)
  %t62 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t59, 1
  %t66 = extractvalue { i64, ptr } %t63, 0
  %t67 = extractvalue { i64, ptr } %t63, 1
  %t68 = mul i64 %t66, 1
  %t69 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t68)
  call void @llvm.memcpy.p0.p0.i64(ptr %t69, ptr %t67, i64 %t68, i1 false)
  %t70 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s3, ptr %l4, { i64, ptr } %t71)
  br label %bb13
bb13:
  %t75 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l4)
  store i32 %t75, ptr %l72
  %t76 = icmp ne i32 %t75, 0
  br i1 %t76, label %bb15, label %ok.77, !prof !99
ok.77:
  br label %bb14
bb14:
  br label %bb17
bb15:
  %t78 = load i32, ptr %l72, !tbaa !23
  %t79 = ashr i32 %t78, 16
  %t81 = icmp eq i32 %t79, 1
  store i1 %t81, ptr %l74, !tbaa !21
  br label %bb16
bb16:
  call void @__olang_ert_req_clear()
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb18:
  %t83 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t83, 1
  %t87 = extractvalue { i64, ptr } %t83, 0
  %t88 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t87)
  call void @olang_textcopy(ptr %t88, ptr %t86, i64 %t87)
  %t89 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  %t92 = extractvalue { i64, ptr } %t90, 0
  %t93 = extractvalue { i64, ptr } %t90, 1
  %t94 = mul i64 %t92, 1
  %t95 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t94)
  call void @llvm.memcpy.p0.p0.i64(ptr %t95, ptr %t93, i64 %t94, i1 false)
  %t96 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } %t97)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  %t100 = load i64, ptr %l9, !tbaa !24
  %t102 = add i64 %t100, 1
  store i64 %t102, ptr %l9, !tbaa !24
  br label %bb6
bb21:
  %t104 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t106 = call { i64, ptr } @compiler_2ffix_2eToolsDir(ptr %v1, ptr %s0, { i64, ptr } %t104)
  store { i64, ptr } %t106, ptr %l83
  br label %bb22
bb22:
  %t107 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t107, ptr %l13, !tbaa !27
  %t108 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t110 = call i1 @std_2fos_2eIsDir(ptr %s0, { i64, ptr } %t108)
  store i1 %t110, ptr %l85
  br label %bb23
bb23:
  %t111 = load i1, ptr %l85, !tbaa !21
  %t112 = xor i1 %t111, true
  br i1 %t112, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s8
  %t114 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t115 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t116 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t118 = extractvalue { i64, ptr } %t114, 1
  %t119 = extractvalue { i64, ptr } %t114, 0
  %t120 = add i64 %t116, %t119
  %t121 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t122 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t123 = add i64 %t120, %t122
  %t124 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t123)
  call void @olang_textcopy(ptr %t124, ptr %t115, i64 %t116)
  %t125 = getelementptr i8, ptr %t124, i64 %t116
  call void @olang_textcopy(ptr %t125, ptr %t118, i64 %t119)
  %t126 = getelementptr i8, ptr %t125, i64 %t119
  call void @olang_textcopy(ptr %t126, ptr %t121, i64 %t122)
  %t127 = insertvalue { i64, ptr } undef, i64 %t123, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t124, 1
  %t131 = extractvalue { i64, ptr } %t128, 0
  %t132 = extractvalue { i64, ptr } %t128, 1
  %t133 = mul i64 %t131, 1
  %t134 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t133)
  call void @llvm.memcpy.p0.p0.i64(ptr %t134, ptr %t132, i64 %t133, i1 false)
  %t135 = insertvalue { i64, ptr } undef, i64 %t131, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t134, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s8, ptr %l4, { i64, ptr } %t136)
  br label %bb26
bb25:
  br label %bb31
bb26:
  %t140 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l4)
  store i32 %t140, ptr %l93
  %t141 = icmp ne i32 %t140, 0
  br i1 %t141, label %bb28, label %ok.142, !prof !99
ok.142:
  br label %bb27
bb27:
  br label %bb30
bb28:
  %t143 = load i32, ptr %l93, !tbaa !23
  %t144 = ashr i32 %t143, 16
  %t146 = icmp eq i32 %t144, 1
  store i1 %t146, ptr %l95, !tbaa !21
  br label %bb29
bb29:
  call void @__olang_ert_req_clear()
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb31:
  %t148 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t149 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t152 = call { i64, ptr } @compiler_2ffix_2eBinDir(ptr %v1, ptr %s0, ptr %s0, { i64, ptr } %t148, { i64, ptr } %t149)
  store { i64, ptr } %t152, ptr %l99
  br label %bb32
bb32:
  %t153 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t153, ptr %l14, !tbaa !27
  %t154 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t156 = call i32 @std_2fos_2eMkDirAll(ptr %s0, { i64, ptr } %t154)
  store i32 %t156, ptr %l101
  %t157 = icmp ne i32 %t156, 0
  br i1 %t157, label %bb34, label %ok.158, !prof !99
ok.158:
  br label %bb33
bb33:
  br label %bb41
bb34:
  %t159 = load i32, ptr %l101, !tbaa !23
  %t160 = ashr i32 %t159, 16
  %t162 = icmp eq i32 %t160, 1
  store i1 %t162, ptr %l103, !tbaa !21
  br label %bb35
bb35:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s11
  %t163 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t164 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t165 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t167 = extractvalue { i64, ptr } %t163, 1
  %t168 = extractvalue { i64, ptr } %t163, 0
  %t169 = add i64 %t165, %t168
  %t170 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t171 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t172 = add i64 %t169, %t171
  %t173 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t172)
  call void @olang_textcopy(ptr %t173, ptr %t164, i64 %t165)
  %t174 = getelementptr i8, ptr %t173, i64 %t165
  call void @olang_textcopy(ptr %t174, ptr %t167, i64 %t168)
  %t175 = getelementptr i8, ptr %t174, i64 %t168
  call void @olang_textcopy(ptr %t175, ptr %t170, i64 %t171)
  %t176 = insertvalue { i64, ptr } undef, i64 %t172, 0
  %t177 = insertvalue { i64, ptr } %t176, ptr %t173, 1
  %t180 = extractvalue { i64, ptr } %t177, 0
  %t181 = extractvalue { i64, ptr } %t177, 1
  %t182 = mul i64 %t180, 1
  %t183 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t182)
  call void @llvm.memcpy.p0.p0.i64(ptr %t183, ptr %t181, i64 %t182, i1 false)
  %t184 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t183, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s11, ptr %l4, { i64, ptr } %t185)
  br label %bb36
bb36:
  %t189 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l4)
  store i32 %t189, ptr %l110
  %t190 = icmp ne i32 %t189, 0
  br i1 %t190, label %bb38, label %ok.191, !prof !99
ok.191:
  br label %bb37
bb37:
  br label %bb40
bb38:
  %t192 = load i32, ptr %l110, !tbaa !23
  %t193 = ashr i32 %t192, 16
  %t195 = icmp eq i32 %t193, 1
  store i1 %t195, ptr %l112, !tbaa !21
  br label %bb39
bb39:
  call void @__olang_ert_req_clear()
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb41:
  store i32 0, ptr %l15, !tbaa !23
  store i64 0, ptr %l16, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s14
  %t197 = call { i64, ptr } @compiler_2ffix_2eOrder(ptr %s14)
  store { i64, ptr } %t197, ptr %l114
  br label %bb42
bb42:
  %t198 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t198, 0
  %t200 = extractvalue { i64, ptr } %t198, 1
  %t201 = mul i64 %t199, 8
  %t202 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t201)
  call void @llvm.memcpy.p0.p0.i64(ptr %t202, ptr %t200, i64 %t201, i1 false)
  %t203 = insertvalue { i64, ptr } undef, i64 %t199, 0
  %t204 = insertvalue { i64, ptr } %t203, ptr %t202, 1
  store { i64, ptr } %t204, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t206 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t206, 0
  store i64 %t208, ptr %l19, !tbaa !24
  br label %bb43
bb43:
  store %olang.scope zeroinitializer, ptr %s15
  %t210 = load i64, ptr %l18, !tbaa !24
  %t211 = load i64, ptr %l19, !tbaa !24
  %t214 = icmp slt i64 %t210, %t211
  %t216 = xor i1 %t214, true
  br i1 %t216, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s15)
  br label %bb97
bb45:
  br label %bb46
bb46:
  %t218 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t218, ptr %l122, !tbaa !27
  %t219 = load i64, ptr %l18, !tbaa !24
  %t221 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t222 = load ptr, ptr %t221, !tbaa !27
  %t223 = getelementptr i64, ptr %t222, i64 %t219
  %t224 = load i64, ptr %t223, !tbaa !34
  store i64 %t224, ptr %l20, !tbaa !24
  %t226 = load i64, ptr %l20, !tbaa !24
  %t228 = getelementptr [32 x { i64, ptr }], ptr @G_2ecompiler_2ffix_2eToolNames, i64 0, i64 %t226
  %t229 = load { i64, ptr }, ptr %t228, !tbaa !37
  store { i64, ptr } %t229, ptr %l21, !tbaa !27
  %t231 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t232 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t233 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t234 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t235 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t236 = load ptr, ptr @__olang_prog_scope
  %t243 = call i32 @compiler_2ffix_2eensureBuilt(ptr %v1, ptr %s0, ptr %s0, ptr %t236, ptr %v2, ptr %s0, { i64, ptr } %t231, { i64, ptr } %t232, { i64, ptr } %t233, { i64, ptr } %t234, { i64, ptr } %t235, ptr %l4)
  store i32 %t243, ptr %l133
  %t244 = icmp ne i32 %t243, 0
  br i1 %t244, label %bb48, label %ok.245, !prof !99
ok.245:
  br label %bb47
bb47:
  br label %bb50
bb48:
  %t246 = load i32, ptr %l133, !tbaa !23
  %t247 = ashr i32 %t246, 16
  %t249 = icmp eq i32 %t247, 1
  store i1 %t249, ptr %l135, !tbaa !21
  br label %bb49
bb49:
  call void @__olang_ert_req_clear()
  store i32 2, ptr %l15, !tbaa !23
  call void @__olang_scope_close(ptr %s15)
  br label %bb97
bb50:
  %t250 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t251 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t252 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t253 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t255 = extractvalue { i64, ptr } %t251, 1
  %t256 = extractvalue { i64, ptr } %t251, 0
  %t257 = add i64 %t253, %t256
  %t258 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t257)
  call void @olang_textcopy(ptr %t258, ptr %t252, i64 %t253)
  %t259 = getelementptr i8, ptr %t258, i64 %t253
  call void @olang_textcopy(ptr %t259, ptr %t255, i64 %t256)
  %t260 = insertvalue { i64, ptr } undef, i64 %t257, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t258, 1
  %t263 = extractvalue { i64, ptr } %t261, 0
  %t264 = extractvalue { i64, ptr } %t261, 1
  %t265 = mul i64 %t263, 1
  %t266 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t265)
  call void @llvm.memcpy.p0.p0.i64(ptr %t266, ptr %t264, i64 %t265, i1 false)
  %t267 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t266, 1
  %t270 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t250, 0
  %t272 = insertvalue [2 x { i64, ptr }] %t270, { i64, ptr } %t268, 1
  store [2 x { i64, ptr }] %t272, ptr %l22
  %t275 = insertvalue { i64, ptr } undef, i64 2, 0
  %t276 = insertvalue { i64, ptr } %t275, ptr %l22, 1
  %t278 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s15, ptr %s15, { i64, ptr } %t276)
  store { i64, ptr } %t278, ptr %l143
  br label %bb51
bb51:
  %t279 = load { i64, ptr }, ptr %l143, !tbaa !27
  store { i64, ptr } %t279, ptr %l23, !tbaa !27
  store i64 0, ptr %l24, !tbaa !24
  %t280 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t282 = extractvalue { i64, ptr } %t280, 0
  store i64 %t282, ptr %l25, !tbaa !24
  %t284 = load i64, ptr @G_2ecompiler_2ffix_2eBatch, !tbaa !24
  store i64 %t284, ptr %l26, !tbaa !24
  %t286 = load i64, ptr %l25, !tbaa !24
  %t287 = load i64, ptr %l24, !tbaa !24
  %t290 = icmp sgt i64 %t286, %t287
  br i1 %t290, label %bb52, label %bb53
bb52:
  %t292 = load i64, ptr %l26, !tbaa !24
  %t294 = icmp sgt i64 %t292, 0
  br i1 %t294, label %bb54, label %bb55
bb53:
  store i64 0, ptr %l150, !tbaa !24
  br label %bb57
bb54:
  %t296 = load i64, ptr %l25, !tbaa !24
  %t297 = load i64, ptr %l24, !tbaa !24
  %t300 = sub i64 %t296, %t297
  %t301 = load i64, ptr %l26, !tbaa !24
  %t304 = add i64 %t300, %t301
  %t306 = sub i64 %t304, 1
  %t307 = load i64, ptr %l26, !tbaa !24
  %t310 = sdiv i64 %t306, %t307
  store i64 %t310, ptr %l153, !tbaa !24
  br label %bb56
bb55:
  store i64 0, ptr %l153, !tbaa !24
  br label %bb56
bb56:
  %t312 = load i64, ptr %l153, !tbaa !24
  store i64 %t312, ptr %l150, !tbaa !24
  br label %bb57
bb57:
  %t313 = load i64, ptr %l150, !tbaa !24
  store i64 %t313, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb58
bb58:
  store %olang.scope zeroinitializer, ptr %s19
  %t314 = load i64, ptr %l28, !tbaa !24
  %t315 = load i64, ptr %l27, !tbaa !24
  %t318 = icmp slt i64 %t314, %t315
  %t320 = xor i1 %t318, true
  br i1 %t320, label %bb59, label %bb60
bb59:
  call void @__olang_scope_close(ptr %s19)
  br label %bb92
bb60:
  br label %bb61
bb61:
  %t322 = load i64, ptr %l24, !tbaa !24
  %t323 = load i64, ptr %l28, !tbaa !24
  %t324 = load i64, ptr %l26, !tbaa !24
  %t327 = mul i64 %t323, %t324
  %t330 = add i64 %t322, %t327
  store i64 %t330, ptr %l29, !tbaa !24
  %t332 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t332, ptr %l171, !tbaa !27
  %t333 = load i64, ptr %l29, !tbaa !24
  store i64 %t333, ptr %l172, !tbaa !24
  %t334 = load i64, ptr %l29, !tbaa !24
  %t335 = load i64, ptr @G_2ecompiler_2ffix_2eBatch, !tbaa !24
  %t338 = add i64 %t334, %t335
  %t339 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t341 = extractvalue { i64, ptr } %t339, 0
  %t344 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t338, i64 %t341)
  store i64 %t344, ptr %l178
  br label %bb62
bb62:
  %t345 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t346 = extractvalue { i64, ptr } %t345, 0
  store i64 %t346, ptr %l179, !tbaa !24
  %t347 = load i64, ptr %l172, !tbaa !24
  %t348 = icmp sge i64 %t347, 0
  br i1 %t348, label %bb63, label %bb64
bb63:
  %t350 = load i64, ptr %l172, !tbaa !24
  %t351 = load i64, ptr %l178, !tbaa !24
  %t352 = icmp sle i64 %t350, %t351
  br i1 %t352, label %bb65, label %bb66
bb64:
  call void @__olang_check_failed(ptr @olang_loc_299e69389bcee8f2_b185402659ea7d46)
  unreachable
bb65:
  %t354 = load i64, ptr %l178, !tbaa !24
  %t355 = load i64, ptr %l179, !tbaa !24
  %t356 = icmp sle i64 %t354, %t355
  br i1 %t356, label %bb67, label %bb68
bb66:
  call void @__olang_check_failed(ptr @olang_loc_299e69389bcee8f2_b185402659ea7d46)
  unreachable
bb67:
  %t358 = getelementptr { i64, ptr }, ptr %l171, i32 0, i32 1
  %t359 = load ptr, ptr %t358, !tbaa !27
  %t360 = load i64, ptr %l172, !tbaa !24
  %t361 = load i64, ptr %l178, !tbaa !24
  %t362 = getelementptr { i64, ptr }, ptr %t359, i64 %t360
  %t363 = sub i64 %t361, %t360
  %t364 = insertvalue { i64, ptr } undef, i64 %t363, 0
  %t365 = insertvalue { i64, ptr } %t364, ptr %t362, 1
  %t367 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t368 = load i64, ptr %l20, !tbaa !24
  %t370 = getelementptr [32 x i64], ptr @G_2ecompiler_2ffix_2eToolKinds, i64 0, i64 %t368
  %t371 = load i64, ptr %t370, !tbaa !34
  %t372 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t373 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t380 = call { i64, ptr } @compiler_2ffix_2earguments(ptr %s15, ptr %v1, ptr %v2, ptr %s0, ptr %s19, { i64, ptr } %t367, i64 %t371, { i64, ptr } %t372, { i64, ptr } %t373, { i64, ptr } %t365)
  store { i64, ptr } %t380, ptr %l191
  br label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_299e69389bcee8f2_b185402659ea7d46)
  unreachable
bb69:
  %t381 = load { i64, ptr }, ptr %l191, !tbaa !27
  %t382 = extractvalue { i64, ptr } %t381, 0
  %t383 = extractvalue { i64, ptr } %t381, 1
  %t384 = mul i64 %t382, 16
  %t385 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t384)
  call void @llvm.memcpy.p0.p0.i64(ptr %t385, ptr %t383, i64 %t384, i1 false)
  %t386 = insertvalue { i64, ptr } undef, i64 %t382, 0
  %t387 = insertvalue { i64, ptr } %t386, ptr %t385, 1
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l193, !tbaa !27
  %t389 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t390 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s19, ptr %s19, ptr %s19, ptr %s19, { i64, ptr } %t387, { i64, ptr } %t389, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d9, i32 0, i32 1) })
  %t391 = extractvalue { i32, %"std/os:Output" } %t390, 1
  %t392 = extractvalue { i32, %"std/os:Output" } %t390, 0
  store i32 %t392, ptr %l195
  %t393 = icmp ne i32 %t392, 0
  br i1 %t393, label %bb71, label %ok.394, !prof !99
ok.394:
  store %"std/os:Output" %t391, ptr %l194
  br label %bb70
bb70:
  %t395 = load %"std/os:Output", ptr %l194
  store %"std/os:Output" %t395, ptr %l184
  br label %bb74
bb71:
  %t396 = load i32, ptr %l195, !tbaa !23
  %t397 = ashr i32 %t396, 16
  %t399 = icmp eq i32 %t397, 1
  store i1 %t399, ptr %l197, !tbaa !21
  br label %bb72
bb72:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s20
  %t400 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t401 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t402 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t404 = extractvalue { i64, ptr } %t400, 1
  %t405 = extractvalue { i64, ptr } %t400, 0
  %t406 = add i64 %t402, %t405
  %t407 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t408 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t409 = add i64 %t406, %t408
  %t410 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t409)
  call void @olang_textcopy(ptr %t410, ptr %t401, i64 %t402)
  %t411 = getelementptr i8, ptr %t410, i64 %t402
  call void @olang_textcopy(ptr %t411, ptr %t404, i64 %t405)
  %t412 = getelementptr i8, ptr %t411, i64 %t405
  call void @olang_textcopy(ptr %t412, ptr %t407, i64 %t408)
  %t413 = insertvalue { i64, ptr } undef, i64 %t409, 0
  %t414 = insertvalue { i64, ptr } %t413, ptr %t410, 1
  %t417 = extractvalue { i64, ptr } %t414, 0
  %t418 = extractvalue { i64, ptr } %t414, 1
  %t419 = mul i64 %t417, 1
  %t420 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t419)
  call void @llvm.memcpy.p0.p0.i64(ptr %t420, ptr %t418, i64 %t419, i1 false)
  %t421 = insertvalue { i64, ptr } undef, i64 %t417, 0
  %t422 = insertvalue { i64, ptr } %t421, ptr %t420, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s20, ptr %l4, { i64, ptr } %t422)
  br label %bb73
bb73:
  store i32 2, ptr %l15, !tbaa !23
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s19)
  br label %bb92
bb74:
  %t425 = load %"std/os:Output", ptr %l184
  store %"std/os:Output" %t425, ptr %l31
  %t426 = getelementptr %"std/os:Output", ptr %l31, i32 0, i32 1
  %t427 = load { i64, ptr }, ptr %t426, !tbaa !27
  %t428 = getelementptr %"std/os:Output", ptr %l31, i32 0, i32 2
  %t429 = load { i64, ptr }, ptr %t428, !tbaa !27
  %t431 = extractvalue { i64, ptr } %t427, 1
  %t432 = extractvalue { i64, ptr } %t427, 0
  %t434 = extractvalue { i64, ptr } %t429, 1
  %t435 = extractvalue { i64, ptr } %t429, 0
  %t436 = add i64 %t432, %t435
  %t437 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t436)
  call void @olang_textcopy(ptr %t437, ptr %t431, i64 %t432)
  %t438 = getelementptr i8, ptr %t437, i64 %t432
  call void @olang_textcopy(ptr %t438, ptr %t434, i64 %t435)
  %t439 = insertvalue { i64, ptr } undef, i64 %t436, 0
  %t440 = insertvalue { i64, ptr } %t439, ptr %t437, 1
  store { i64, ptr } %t440, ptr %l32, !tbaa !27
  %t442 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t444 = call i64 @compiler_2ffix_2ebyHand(ptr %s19, { i64, ptr } %t442)
  store i64 %t444, ptr %l207
  br label %bb75
bb75:
  %t445 = load i64, ptr %l207, !tbaa !24
  store i64 %t445, ptr %l33, !tbaa !24
  %t446 = getelementptr %"std/os:Output", ptr %l31, i32 0, i32 0
  %t447 = load i32, ptr %t446, !tbaa !23
  %t449 = icmp sgt i32 %t447, 1
  br i1 %t449, label %bb76, label %bb77
bb76:
  store i1 true, ptr %l210, !tbaa !21
  br label %bb78
bb77:
  %t451 = load i64, ptr %l33, !tbaa !24
  %t453 = icmp sgt i64 %t451, 0
  store i1 %t453, ptr %l210, !tbaa !21
  br label %bb78
bb78:
  %t455 = load i1, ptr %l210, !tbaa !21
  br i1 %t455, label %bb79, label %bb80
bb79:
  store %olang.scope zeroinitializer, ptr %s23
  %t456 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t457 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t459 = extractvalue { i64, ptr } %t456, 1
  %t460 = extractvalue { i64, ptr } %t456, 0
  %t461 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t462 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t463 = add i64 %t460, %t462
  %t465 = extractvalue { i64, ptr } %t457, 1
  %t466 = extractvalue { i64, ptr } %t457, 0
  %t467 = add i64 %t463, %t466
  %t468 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t467)
  call void @olang_textcopy(ptr %t468, ptr %t459, i64 %t460)
  %t469 = getelementptr i8, ptr %t468, i64 %t460
  call void @olang_textcopy(ptr %t469, ptr %t461, i64 %t462)
  %t470 = getelementptr i8, ptr %t469, i64 %t462
  call void @olang_textcopy(ptr %t470, ptr %t465, i64 %t466)
  %t471 = insertvalue { i64, ptr } undef, i64 %t467, 0
  %t472 = insertvalue { i64, ptr } %t471, ptr %t468, 1
  %t475 = extractvalue { i64, ptr } %t472, 0
  %t476 = extractvalue { i64, ptr } %t472, 1
  %t477 = mul i64 %t475, 1
  %t478 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t477)
  call void @llvm.memcpy.p0.p0.i64(ptr %t478, ptr %t476, i64 %t477, i1 false)
  %t479 = insertvalue { i64, ptr } undef, i64 %t475, 0
  %t480 = insertvalue { i64, ptr } %t479, ptr %t478, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s23, ptr %l4, { i64, ptr } %t480)
  br label %bb81
bb80:
  br label %bb87
bb81:
  %t483 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t485 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s19, ptr %s23, { i64, ptr } %t483, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i1 %t485, ptr %l220
  br label %bb82
bb82:
  %t486 = load i1, ptr %l220, !tbaa !21
  %t487 = xor i1 %t486, true
  br i1 %t487, label %bb83, label %bb84
bb83:
  store %olang.scope zeroinitializer, ptr %s25
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, ptr %l223, !tbaa !27
  %t490 = load { i64, ptr }, ptr %l223, !tbaa !27
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s25, ptr %l4, { i64, ptr } %t490)
  br label %bb85
bb84:
  br label %bb86
bb85:
  call void @__olang_scope_close(ptr %s25)
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s23)
  br label %bb87
bb87:
  %t491 = load i64, ptr %l16, !tbaa !24
  %t492 = load i64, ptr %l33, !tbaa !24
  %t495 = add i64 %t491, %t492
  store i64 %t495, ptr %l16, !tbaa !24
  %t497 = getelementptr %"std/os:Output", ptr %l31, i32 0, i32 0
  %t498 = load i32, ptr %t497, !tbaa !23
  %t500 = icmp sgt i32 %t498, 1
  br i1 %t500, label %bb88, label %bb89
bb88:
  store i32 2, ptr %l15, !tbaa !23
  br label %bb90
bb89:
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s19)
  br label %bb91
bb91:
  %t502 = load i64, ptr %l28, !tbaa !24
  %t504 = add i64 %t502, 1
  store i64 %t504, ptr %l28, !tbaa !24
  br label %bb58
bb92:
  %t506 = load i32, ptr %l15, !tbaa !23
  %t508 = icmp ne i32 %t506, 0
  br i1 %t508, label %bb93, label %bb94
bb93:
  call void @__olang_scope_close(ptr %s15)
  br label %bb97
bb94:
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s15)
  br label %bb96
bb96:
  %t510 = load i64, ptr %l18, !tbaa !24
  %t512 = add i64 %t510, 1
  store i64 %t512, ptr %l18, !tbaa !24
  br label %bb43
bb97:
  call void @__olang_scope_close(ptr %s14)
  store i64 0, ptr %l34, !tbaa !24
  store i64 0, ptr %l35, !tbaa !24
  %t514 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t516 = extractvalue { i64, ptr } %t514, 0
  store i64 %t516, ptr %l36, !tbaa !24
  store i64 1, ptr %l37, !tbaa !24
  %t518 = load i64, ptr %l36, !tbaa !24
  %t519 = load i64, ptr %l35, !tbaa !24
  %t522 = icmp sgt i64 %t518, %t519
  br i1 %t522, label %bb98, label %bb99
bb98:
  %t524 = load i64, ptr %l37, !tbaa !24
  %t526 = icmp sgt i64 %t524, 0
  br i1 %t526, label %bb100, label %bb101
bb99:
  store i64 0, ptr %l240, !tbaa !24
  br label %bb103
bb100:
  %t528 = load i64, ptr %l36, !tbaa !24
  %t529 = load i64, ptr %l35, !tbaa !24
  %t532 = sub i64 %t528, %t529
  %t533 = load i64, ptr %l37, !tbaa !24
  %t536 = add i64 %t532, %t533
  %t538 = sub i64 %t536, 1
  %t539 = load i64, ptr %l37, !tbaa !24
  %t542 = sdiv i64 %t538, %t539
  store i64 %t542, ptr %l243, !tbaa !24
  br label %bb102
bb101:
  store i64 0, ptr %l243, !tbaa !24
  br label %bb102
bb102:
  %t544 = load i64, ptr %l243, !tbaa !24
  store i64 %t544, ptr %l240, !tbaa !24
  br label %bb103
bb103:
  %t545 = load i64, ptr %l240, !tbaa !24
  store i64 %t545, ptr %l38, !tbaa !24
  store i64 0, ptr %l39, !tbaa !24
  br label %bb104
bb104:
  store %olang.scope zeroinitializer, ptr %s31
  %t546 = load i64, ptr %l39, !tbaa !24
  %t547 = load i64, ptr %l38, !tbaa !24
  %t550 = icmp slt i64 %t546, %t547
  %t552 = xor i1 %t550, true
  br i1 %t552, label %bb105, label %bb106
bb105:
  call void @__olang_scope_close(ptr %s31)
  br label %bb128
bb106:
  br label %bb107
bb107:
  %t554 = load i64, ptr %l35, !tbaa !24
  %t555 = load i64, ptr %l39, !tbaa !24
  %t556 = load i64, ptr %l37, !tbaa !24
  %t559 = mul i64 %t555, %t556
  %t562 = add i64 %t554, %t559
  store i64 %t562, ptr %l40, !tbaa !24
  %t564 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t564, ptr %l262, !tbaa !27
  %t565 = load i64, ptr %l40, !tbaa !24
  %t567 = getelementptr { i64, ptr }, ptr %l262, i32 0, i32 1
  %t568 = load ptr, ptr %t567, !tbaa !27
  %t569 = getelementptr { i64, ptr }, ptr %t568, i64 %t565
  %t570 = load { i64, ptr }, ptr %t569, !tbaa !37
  %t572 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s31, { i64, ptr } %t570)
  %t573 = extractvalue { i32, { i64, ptr } } %t572, 1
  %t574 = extractvalue { i32, { i64, ptr } } %t572, 0
  store i32 %t574, ptr %l266
  %t575 = icmp ne i32 %t574, 0
  br i1 %t575, label %bb109, label %ok.576, !prof !99
ok.576:
  store { i64, ptr } %t573, ptr %l265
  br label %bb108
bb108:
  %t577 = load { i64, ptr }, ptr %l265, !tbaa !27
  store { i64, ptr } %t577, ptr %l261, !tbaa !27
  br label %bb111
bb109:
  %t578 = load i32, ptr %l266, !tbaa !23
  %t579 = ashr i32 %t578, 16
  %t581 = icmp eq i32 %t579, 1
  store i1 %t581, ptr %l268, !tbaa !21
  br label %bb110
bb110:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s31)
  br label %bb127
bb111:
  %t582 = load { i64, ptr }, ptr %l261, !tbaa !27
  store { i64, ptr } %t582, ptr %l269, !tbaa !27
  %t584 = load i64, ptr %l40, !tbaa !24
  %t587 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l7, i64 %t584)
  store { i64, ptr } %t587, ptr %l272
  br label %bb112
bb112:
  %t588 = load { i64, ptr }, ptr %l269, !tbaa !27
  %t589 = load { i64, ptr }, ptr %l272, !tbaa !27
  %t590 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s31, ptr %s0, { i64, ptr } %t588, { i64, ptr } %t589)
  store i1 %t590, ptr %l273
  br label %bb113
bb113:
  %t591 = load i1, ptr %l273, !tbaa !21
  br i1 %t591, label %bb114, label %bb115
bb114:
  call void @__olang_scope_close(ptr %s31)
  br label %bb127
bb115:
  br label %bb116
bb116:
  %t592 = load i64, ptr %l34, !tbaa !24
  %t594 = add i64 %t592, 1
  store i64 %t594, ptr %l34, !tbaa !24
  %t596 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t596, ptr %l277, !tbaa !27
  %t597 = load i64, ptr %l40, !tbaa !24
  %t599 = getelementptr { i64, ptr }, ptr %l277, i32 0, i32 1
  %t600 = load ptr, ptr %t599, !tbaa !27
  %t601 = getelementptr { i64, ptr }, ptr %t600, i64 %t597
  %t602 = load { i64, ptr }, ptr %t601, !tbaa !37
  %t604 = extractvalue { i64, ptr } %t602, 1
  %t605 = extractvalue { i64, ptr } %t602, 0
  %t606 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t607 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t608 = add i64 %t605, %t607
  %t609 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t608)
  call void @olang_textcopy(ptr %t609, ptr %t604, i64 %t605)
  %t610 = getelementptr i8, ptr %t609, i64 %t605
  call void @olang_textcopy(ptr %t610, ptr %t606, i64 %t607)
  %t611 = insertvalue { i64, ptr } undef, i64 %t608, 0
  %t612 = insertvalue { i64, ptr } %t611, ptr %t609, 1
  %t615 = extractvalue { i64, ptr } %t612, 0
  %t616 = extractvalue { i64, ptr } %t612, 1
  %t617 = mul i64 %t615, 1
  %t618 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t617)
  call void @llvm.memcpy.p0.p0.i64(ptr %t618, ptr %t616, i64 %t617, i1 false)
  %t619 = insertvalue { i64, ptr } undef, i64 %t615, 0
  %t620 = insertvalue { i64, ptr } %t619, ptr %t618, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s31, ptr %l5, { i64, ptr } %t620)
  br label %bb117
bb117:
  %t623 = load i1, ptr %l0, !tbaa !21
  br i1 %t623, label %bb118, label %bb119
bb118:
  store %olang.scope zeroinitializer, ptr %s35
  %t625 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t625, ptr %l284, !tbaa !27
  %t626 = load i64, ptr %l40, !tbaa !24
  %t628 = getelementptr { i64, ptr }, ptr %l284, i32 0, i32 1
  %t629 = load ptr, ptr %t628, !tbaa !27
  %t630 = getelementptr { i64, ptr }, ptr %t629, i64 %t626
  %t631 = load { i64, ptr }, ptr %t630, !tbaa !37
  store { i64, ptr } %t631, ptr %l286, !tbaa !27
  %t632 = load i64, ptr %l40, !tbaa !24
  %t635 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s35, ptr %l7, i64 %t632)
  store { i64, ptr } %t635, ptr %l289
  br label %bb120
bb119:
  br label %bb126
bb120:
  %t636 = load { i64, ptr }, ptr %l289, !tbaa !27
  %t637 = load { i64, ptr }, ptr %l286, !tbaa !27
  %t639 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s35, { i64, ptr } %t637, { i64, ptr } %t636)
  store i32 %t639, ptr %l291
  %t640 = icmp ne i32 %t639, 0
  br i1 %t640, label %bb122, label %ok.641, !prof !99
ok.641:
  br label %bb121
bb121:
  br label %bb125
bb122:
  %t642 = load i32, ptr %l291, !tbaa !23
  %t643 = ashr i32 %t642, 16
  %t645 = icmp eq i32 %t643, 1
  store i1 %t645, ptr %l293, !tbaa !21
  br label %bb123
bb123:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s36
  %t646 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t646, ptr %l295, !tbaa !27
  %t647 = load i64, ptr %l40, !tbaa !24
  %t649 = getelementptr { i64, ptr }, ptr %l295, i32 0, i32 1
  %t650 = load ptr, ptr %t649, !tbaa !27
  %t651 = getelementptr { i64, ptr }, ptr %t650, i64 %t647
  %t652 = load { i64, ptr }, ptr %t651, !tbaa !37
  %t653 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t654 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t656 = extractvalue { i64, ptr } %t652, 1
  %t657 = extractvalue { i64, ptr } %t652, 0
  %t658 = add i64 %t654, %t657
  %t659 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t660 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t661 = add i64 %t658, %t660
  %t662 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t661)
  call void @olang_textcopy(ptr %t662, ptr %t653, i64 %t654)
  %t663 = getelementptr i8, ptr %t662, i64 %t654
  call void @olang_textcopy(ptr %t663, ptr %t656, i64 %t657)
  %t664 = getelementptr i8, ptr %t663, i64 %t657
  call void @olang_textcopy(ptr %t664, ptr %t659, i64 %t660)
  %t665 = insertvalue { i64, ptr } undef, i64 %t661, 0
  %t666 = insertvalue { i64, ptr } %t665, ptr %t662, 1
  %t669 = extractvalue { i64, ptr } %t666, 0
  %t670 = extractvalue { i64, ptr } %t666, 1
  %t671 = mul i64 %t669, 1
  %t672 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t671)
  call void @llvm.memcpy.p0.p0.i64(ptr %t672, ptr %t670, i64 %t671, i1 false)
  %t673 = insertvalue { i64, ptr } undef, i64 %t669, 0
  %t674 = insertvalue { i64, ptr } %t673, ptr %t672, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s36, ptr %l4, { i64, ptr } %t674)
  br label %bb124
bb124:
  call void @__olang_scope_close(ptr %s36)
  br label %bb125
bb125:
  call void @__olang_scope_close(ptr %s35)
  br label %bb126
bb126:
  call void @__olang_scope_close(ptr %s31)
  br label %bb127
bb127:
  %t677 = load i64, ptr %l39, !tbaa !24
  %t679 = add i64 %t677, 1
  store i64 %t679, ptr %l39, !tbaa !24
  br label %bb104
bb128:
  %t681 = load i64, ptr %l16, !tbaa !24
  %t683 = icmp sgt i64 %t681, 0
  br i1 %t683, label %bb129, label %bb130
bb129:
  %t685 = load i32, ptr %l15, !tbaa !23
  %t687 = icmp eq i32 %t685, 0
  store i1 %t687, ptr %l305, !tbaa !21
  br label %bb131
bb130:
  store i1 false, ptr %l305, !tbaa !21
  br label %bb131
bb131:
  %t689 = load i1, ptr %l305, !tbaa !21
  br i1 %t689, label %bb132, label %bb133
bb132:
  store %olang.scope zeroinitializer, ptr %s39
  %t690 = load i64, ptr %l16, !tbaa !24
  %t692 = icmp eq i64 %t690, 1
  br i1 %t692, label %bb134, label %bb135
bb133:
  br label %bb138
bb134:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l310, !tbaa !27
  br label %bb136
bb135:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l310, !tbaa !27
  br label %bb136
bb136:
  %t694 = load { i64, ptr }, ptr %l310, !tbaa !27
  %t695 = load i64, ptr %l16, !tbaa !24
  %t697 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t698 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t700 = call i64 @__olang_fmt_i64(ptr null, i64 %t695)
  %t701 = add i64 %t698, %t700
  %t702 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t703 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t704 = add i64 %t701, %t703
  %t706 = extractvalue { i64, ptr } %t694, 1
  %t707 = extractvalue { i64, ptr } %t694, 0
  %t708 = add i64 %t704, %t707
  %t709 = extractvalue { i64, ptr } { i64 89, ptr getelementptr inbounds (<{ i64, [89 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t710 = extractvalue { i64, ptr } { i64 89, ptr getelementptr inbounds (<{ i64, [89 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t711 = add i64 %t708, %t710
  %t712 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t711)
  call void @olang_textcopy(ptr %t712, ptr %t697, i64 %t698)
  %t713 = getelementptr i8, ptr %t712, i64 %t698
  %t714 = call i64 @__olang_fmt_i64(ptr %t713, i64 %t695)
  %t715 = getelementptr i8, ptr %t713, i64 %t700
  call void @olang_textcopy(ptr %t715, ptr %t702, i64 %t703)
  %t716 = getelementptr i8, ptr %t715, i64 %t703
  call void @olang_textcopy(ptr %t716, ptr %t706, i64 %t707)
  %t717 = getelementptr i8, ptr %t716, i64 %t707
  call void @olang_textcopy(ptr %t717, ptr %t709, i64 %t710)
  %t718 = insertvalue { i64, ptr } undef, i64 %t711, 0
  %t719 = insertvalue { i64, ptr } %t718, ptr %t712, 1
  %t722 = extractvalue { i64, ptr } %t719, 0
  %t723 = extractvalue { i64, ptr } %t719, 1
  %t724 = mul i64 %t722, 1
  %t725 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t724)
  call void @llvm.memcpy.p0.p0.i64(ptr %t725, ptr %t723, i64 %t724, i1 false)
  %t726 = insertvalue { i64, ptr } undef, i64 %t722, 0
  %t727 = insertvalue { i64, ptr } %t726, ptr %t725, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s39, ptr %l4, { i64, ptr } %t727)
  br label %bb137
bb137:
  call void @__olang_scope_close(ptr %s39)
  br label %bb138
bb138:
  %t731 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l5)
  store i32 %t731, ptr %l318
  %t732 = icmp ne i32 %t731, 0
  br i1 %t732, label %bb140, label %ok.733, !prof !99
ok.733:
  br label %bb139
bb139:
  br label %bb142
bb140:
  %t734 = load i32, ptr %l318, !tbaa !23
  %t735 = ashr i32 %t734, 16
  %t737 = icmp eq i32 %t735, 1
  store i1 %t737, ptr %l320, !tbaa !21
  br label %bb141
bb141:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb142:
  %t740 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l4)
  store i32 %t740, ptr %l323
  %t741 = icmp ne i32 %t740, 0
  br i1 %t741, label %bb144, label %ok.742, !prof !99
ok.742:
  br label %bb143
bb143:
  br label %bb146
bb144:
  %t743 = load i32, ptr %l323, !tbaa !23
  %t744 = ashr i32 %t743, 16
  %t746 = icmp eq i32 %t744, 1
  store i1 %t746, ptr %l325, !tbaa !21
  br label %bb145
bb145:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb146:
  %t748 = load i32, ptr %l15, !tbaa !23
  %t750 = icmp ne i32 %t748, 0
  br i1 %t750, label %bb147, label %bb148
bb147:
  %t752 = load i32, ptr %l15, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t752, ptr %rv
  br label %ret
bb148:
  br label %bb149
bb149:
  %t754 = load i1, ptr %l0, !tbaa !21
  br i1 %t754, label %bb150, label %bb151
bb150:
  %t756 = load i64, ptr %l34, !tbaa !24
  %t758 = icmp sgt i64 %t756, 0
  store i1 %t758, ptr %l331, !tbaa !21
  br label %bb152
bb151:
  store i1 false, ptr %l331, !tbaa !21
  br label %bb152
bb152:
  %t760 = load i1, ptr %l331, !tbaa !21
  br i1 %t760, label %bb153, label %bb154
bb153:
  store i1 true, ptr %l334, !tbaa !21
  br label %bb155
bb154:
  %t761 = load i64, ptr %l16, !tbaa !24
  %t763 = icmp sgt i64 %t761, 0
  store i1 %t763, ptr %l334, !tbaa !21
  br label %bb155
bb155:
  %t765 = load i1, ptr %l334, !tbaa !21
  br i1 %t765, label %bb156, label %bb157
bb156:
  store i32 1, ptr %l337, !tbaa !23
  br label %bb158
bb157:
  store i32 0, ptr %l337, !tbaa !23
  br label %bb158
bb158:
  call void @__olang_scope_close(ptr %s0)
  %t766 = load i32, ptr %l337, !tbaa !23
  store i32 %t766, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ffix_2eOrder(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca [32 x { i64, ptr }]
  %l28 = alloca i64
  %l31 = alloca i64
  %l51 = alloca i1
  %l53 = alloca i1
  %l62 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l64 = alloca i64
  %l65 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l0
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t4 = insertvalue [2 x { i64, ptr }] %t3, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t6 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store [2 x { i64, ptr }] %t4, ptr %t6
  store ptr %t6, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t8 = load ptr, ptr %l1
  store i64 2, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l2, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  br label %bb25
bb4:
  br label %bb5
bb5:
  %t19 = load ptr, ptr %l1
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = getelementptr [2 x { i64, ptr }], ptr %t19, i64 0, i64 %t20
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !37
  store { i64, ptr } %t24, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l23, ptr @G_2ecompiler_2ffix_2eToolNames, i64 512, i1 false)
  %t26 = load [32 x { i64, ptr }], ptr %l23
  store i64 32, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t28 = load i64, ptr %l6, !tbaa !24
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = icmp sgt i64 %t28, %t29
  br i1 %t32, label %bb6, label %bb7
bb6:
  %t34 = load i64, ptr %l7, !tbaa !24
  %t36 = icmp sgt i64 %t34, 0
  br i1 %t36, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb11
bb8:
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = sub i64 %t38, %t39
  %t43 = load i64, ptr %l7, !tbaa !24
  %t46 = add i64 %t42, %t43
  %t48 = sub i64 %t46, 1
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = sdiv i64 %t48, %t49
  store i64 %t52, ptr %l31, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb10
bb10:
  %t54 = load i64, ptr %l31, !tbaa !24
  store i64 %t54, ptr %l28, !tbaa !24
  br label %bb11
bb11:
  %t55 = load i64, ptr %l28, !tbaa !24
  store i64 %t55, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t56 = load i64, ptr %l9, !tbaa !24
  %t57 = load i64, ptr %l8, !tbaa !24
  %t60 = icmp slt i64 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb14:
  br label %bb15
bb15:
  %t64 = load i64, ptr %l5, !tbaa !24
  %t65 = load i64, ptr %l9, !tbaa !24
  %t66 = load i64, ptr %l7, !tbaa !24
  %t69 = mul i64 %t65, %t66
  %t72 = add i64 %t64, %t69
  store i64 %t72, ptr %l10, !tbaa !24
  %t74 = load i64, ptr %l10, !tbaa !24
  %t76 = getelementptr [32 x i64], ptr @G_2ecompiler_2ffix_2eToolKinds, i64 0, i64 %t74
  %t77 = load i64, ptr %t76, !tbaa !34
  %t79 = call i1 @compiler_2ffix_2edriven(i64 %t77)
  store i1 %t79, ptr %l51
  br label %bb16
bb16:
  %t80 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t81 = load ptr, ptr @__olang_prog_scope
  %t83 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t81, ptr %s4, { i64, ptr } %t80, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d25, i32 0, i32 1) })
  store i1 %t83, ptr %l53
  br label %bb17
bb17:
  %t84 = load i1, ptr %l51, !tbaa !21
  %t85 = load i1, ptr %l53, !tbaa !21
  %t86 = icmp eq i1 %t84, %t85
  br i1 %t86, label %bb18, label %bb19
bb18:
  %t88 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l0, i64 %t88)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb22:
  %t91 = load i64, ptr %l9, !tbaa !24
  %t93 = add i64 %t91, 1
  store i64 %t93, ptr %l9, !tbaa !24
  br label %bb12
bb23:
  br label %bb24
bb24:
  %t95 = load i64, ptr %l2, !tbaa !24
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l2, !tbaa !24
  br label %bb2
bb25:
  call void @__olang_scope_close(ptr %s1)
  %t100 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %l0)
  store { i64, ptr } %t100, ptr %l62
  br label %bb26
bb26:
  %t101 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t101, ptr %l63, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 0
  store i64 %t103, ptr %l64, !tbaa !24
  %t104 = load i64, ptr %l64, !tbaa !24
  %t105 = mul i64 %t104, 8
  %t106 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t105)
  %t107 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  store { i64, ptr } %t108, ptr %l65, !tbaa !27
  %t109 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = load i64, ptr %l64, !tbaa !24
  %t114 = mul i64 %t113, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t110, ptr %t112, i64 %t114, i1 false)
  %t115 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t115, ptr %l63, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t116 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t116, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ffix_2eToolsDir(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l6 = alloca i1
  %l11 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d26, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l4
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  store { i64, ptr } %t2, ptr %l3
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %l2, !tbaa !27
  br label %bb4
bb4:
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t7, ptr %l1, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t10 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t8, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d28, i32 0, i32 1) })
  store i1 %t10, ptr %l6
  br label %bb5
bb5:
  %t11 = load i1, ptr %l6, !tbaa !21
  %t12 = xor i1 %t11, true
  br i1 %t12, label %bb6, label %bb7
bb6:
  %t14 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 1
  %t17 = extractvalue { i64, ptr } %t14, 0
  %t18 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t17)
  call void @olang_textcopy(ptr %t18, ptr %t16, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t20, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t24 = call { i64, ptr } @std_2ffilepath_2eDir(ptr %v0, ptr %s0, { i64, ptr } %a0)
  store { i64, ptr } %t24, ptr %l11
  br label %bb9
bb9:
  %t25 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t25, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t29 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t30 = add i64 %t27, %t29
  %t31 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t30)
  call void @olang_textcopy(ptr %t31, ptr %t26, i64 %t27)
  %t32 = getelementptr i8, ptr %t31, i64 %t27
  call void @olang_textcopy(ptr %t32, ptr %t28, i64 %t29)
  %t33 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t31, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t34, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ffix_2earguments(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %lp5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 32, i64 8)
  store ptr %t2, ptr %lp5
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  %t4 = load ptr, ptr %lp5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load ptr, ptr %lp5
  %t8 = extractvalue { i64, ptr } %a0, 1
  %t9 = extractvalue { i64, ptr } %a0, 0
  %t10 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t9)
  call void @olang_textcopy(ptr %t10, ptr %t8, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t15 = extractvalue { i64, ptr } %t12, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t5, { i64, ptr } %t19)
  br label %bb2
bb2:
  %t22 = load i64, ptr %l1, !tbaa !24
  %t23 = load i64, ptr @G_2ecompiler_2ffix_2eStdTool, !tbaa !24
  %t26 = icmp eq i64 %t22, %t23
  br i1 %t26, label %bb3, label %bb4
bb3:
  %t28 = load ptr, ptr %lp5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t28, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d30, i32 0, i32 1) })
  br label %bb5
bb4:
  %t30 = load i64, ptr %l1, !tbaa !24
  %t31 = load i64, ptr @G_2ecompiler_2ffix_2eDrivenOpt, !tbaa !24
  %t34 = icmp eq i64 %t30, %t31
  br i1 %t34, label %bb7, label %bb8
bb5:
  %t36 = load ptr, ptr %lp5
  %t39 = extractvalue { i64, ptr } %a3, 1
  %t40 = extractvalue { i64, ptr } %a3, 0
  %t41 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t40)
  call void @olang_textcopy(ptr %t41, ptr %t39, i64 %t40)
  %t42 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t46 = extractvalue { i64, ptr } %t43, 1
  %t47 = mul i64 %t45, 1
  %t48 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t47)
  call void @llvm.memcpy.p0.p0.i64(ptr %t48, ptr %t46, i64 %t47, i1 false)
  %t49 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t36, { i64, ptr } %t50)
  br label %bb6
bb6:
  br label %bb16
bb7:
  %t53 = load ptr, ptr %lp5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t53, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d31, i32 0, i32 1) })
  br label %bb9
bb8:
  %t55 = load i64, ptr %l1, !tbaa !24
  %t56 = load i64, ptr @G_2ecompiler_2ffix_2eDrivenArg, !tbaa !24
  %t59 = icmp eq i64 %t55, %t56
  br i1 %t59, label %bb11, label %bb12
bb9:
  %t61 = load ptr, ptr %lp5
  %t62 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t62, 1
  %t65 = extractvalue { i64, ptr } %t62, 0
  %t66 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t65)
  call void @olang_textcopy(ptr %t66, ptr %t64, i64 %t65)
  %t67 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t71 = extractvalue { i64, ptr } %t68, 1
  %t72 = mul i64 %t70, 1
  %t73 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t72)
  call void @llvm.memcpy.p0.p0.i64(ptr %t73, ptr %t71, i64 %t72, i1 false)
  %t74 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t61, { i64, ptr } %t75)
  br label %bb10
bb10:
  br label %bb15
bb11:
  %t78 = load ptr, ptr %lp5
  %t79 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t79, 1
  %t82 = extractvalue { i64, ptr } %t79, 0
  %t83 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t82)
  call void @olang_textcopy(ptr %t83, ptr %t81, i64 %t82)
  %t84 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t83, 1
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t88 = extractvalue { i64, ptr } %t85, 1
  %t89 = mul i64 %t87, 1
  %t90 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t89)
  call void @llvm.memcpy.p0.p0.i64(ptr %t90, ptr %t88, i64 %t89, i1 false)
  %t91 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t90, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t78, { i64, ptr } %t92)
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  store { i64, ptr } %a4, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t97 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  store i64 %t99, ptr %l8, !tbaa !24
  br label %bb17
bb17:
  %t101 = load i64, ptr %l7, !tbaa !24
  %t102 = load i64, ptr %l8, !tbaa !24
  %t105 = icmp slt i64 %t101, %t102
  %t107 = xor i1 %t105, true
  br i1 %t107, label %bb18, label %bb19
bb18:
  br label %bb23
bb19:
  br label %bb20
bb20:
  %t109 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t109, ptr %l45, !tbaa !27
  %t110 = load i64, ptr %l7, !tbaa !24
  %t112 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr { i64, ptr }, ptr %t113, i64 %t110
  %t115 = load { i64, ptr }, ptr %t114, !tbaa !37
  %t117 = load ptr, ptr %lp5
  %t120 = extractvalue { i64, ptr } %t115, 1
  %t121 = extractvalue { i64, ptr } %t115, 0
  %t122 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t121)
  call void @olang_textcopy(ptr %t122, ptr %t120, i64 %t121)
  %t123 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  %t126 = extractvalue { i64, ptr } %t124, 0
  %t127 = extractvalue { i64, ptr } %t124, 1
  %t128 = mul i64 %t126, 1
  %t129 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t128)
  call void @llvm.memcpy.p0.p0.i64(ptr %t129, ptr %t127, i64 %t128, i1 false)
  %t130 = insertvalue { i64, ptr } undef, i64 %t126, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t129, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t117, { i64, ptr } %t131)
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t134 = load i64, ptr %l7, !tbaa !24
  %t136 = add i64 %t134, 1
  store i64 %t136, ptr %l7, !tbaa !24
  br label %bb17
bb23:
  %t138 = load ptr, ptr %lp5
  %t140 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v4, ptr %v4, ptr %t138)
  store { i64, ptr } %t140, ptr %l55
  br label %bb24
bb24:
  %t141 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t141, ptr %l56, !tbaa !27
  %t142 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t142, 0
  store i64 %t143, ptr %l57, !tbaa !24
  %t144 = load i64, ptr %l57, !tbaa !24
  %t145 = mul i64 %t144, 16
  %t146 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t145)
  %t147 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  store { i64, ptr } %t148, ptr %l58, !tbaa !27
  %t149 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = load i64, ptr %l57, !tbaa !24
  %t154 = mul i64 %t153, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t150, ptr %t152, i64 %t154, i1 false)
  %t155 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t155, ptr %l56, !tbaa !27
  %t156 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t156, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ffix_2ebuiltBy(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/os:FileInfo"
  %l2 = alloca %"std/os:FileInfo"
  %l4 = alloca %"std/os:FileInfo"
  %l5 = alloca i32
  %l7 = alloca i1
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v0, { i64, ptr } %t1)
  %t4 = extractvalue { i32, %"std/os:FileInfo" } %t3, 1
  %t5 = extractvalue { i32, %"std/os:FileInfo" } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store %"std/os:FileInfo" %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load %"std/os:FileInfo", ptr %l4
  store %"std/os:FileInfo" %t8, ptr %l2
  br label %bb4
bb2:
  %t9 = load i32, ptr %l5, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  store i1 %t12, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = extractvalue { i64, ptr } %t13, 0
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t15, i64 %t16)
  %t18 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %rv
  br label %ret
bb4:
  %t21 = load %"std/os:FileInfo", ptr %l2
  store %"std/os:FileInfo" %t21, ptr %l1
  %t22 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t23 = getelementptr %"std/os:FileInfo", ptr %l1, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t25 = getelementptr %"std/os:FileInfo", ptr %l1, i32 0, i32 2
  %t26 = load i64, ptr %t25, !tbaa !24
  %t28 = extractvalue { i64, ptr } %t22, 1
  %t29 = extractvalue { i64, ptr } %t22, 0
  %t30 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t32 = add i64 %t29, %t31
  %t34 = call i64 @__olang_fmt_i64(ptr null, i64 %t24)
  %t35 = add i64 %t32, %t34
  %t36 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t37 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t38 = add i64 %t35, %t37
  %t40 = call i64 @__olang_fmt_i64(ptr null, i64 %t26)
  %t41 = add i64 %t38, %t40
  %t42 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t43 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t44 = add i64 %t41, %t43
  %t45 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t44)
  call void @olang_textcopy(ptr %t45, ptr %t28, i64 %t29)
  %t46 = getelementptr i8, ptr %t45, i64 %t29
  call void @olang_textcopy(ptr %t46, ptr %t30, i64 %t31)
  %t47 = getelementptr i8, ptr %t46, i64 %t31
  %t48 = call i64 @__olang_fmt_i64(ptr %t47, i64 %t24)
  %t49 = getelementptr i8, ptr %t47, i64 %t34
  call void @olang_textcopy(ptr %t49, ptr %t36, i64 %t37)
  %t50 = getelementptr i8, ptr %t49, i64 %t37
  %t51 = call i64 @__olang_fmt_i64(ptr %t50, i64 %t26)
  %t52 = getelementptr i8, ptr %t50, i64 %t40
  call void @olang_textcopy(ptr %t52, ptr %t42, i64 %t43)
  %t53 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t45, 1
  store { i64, ptr } %t54, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ffix_2ebyHand(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca %"std/prelude/text:LineIter"
  %l4 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/text:LineIter"
  %l7 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l12 = alloca i1
  %l14 = alloca i1
  %l18 = alloca i1
  %l20 = alloca i1
  %l22 = alloca i1
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  store i1 false, ptr %l2, !tbaa !21
  %t3 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store %"std/prelude/text:LineIter" %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load %"std/prelude/text:LineIter", ptr %l6
  store %"std/prelude/text:LineIter" %t4, ptr %l3
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t6 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v0, ptr %l3)
  %t7 = extractvalue { i32, { i64, ptr } } %t6, 1
  %t8 = extractvalue { i32, { i64, ptr } } %t6, 0
  store i32 %t8, ptr %l10
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb4, label %ok.10, !prof !99
ok.10:
  store { i64, ptr } %t7, ptr %l9
  br label %bb3
bb3:
  %t11 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t11, ptr %l7, !tbaa !27
  br label %bb6
bb4:
  %t12 = load i32, ptr %l10, !tbaa !23
  %t13 = ashr i32 %t12, 16
  %t15 = icmp eq i32 %t13, 1
  store i1 %t15, ptr %l12, !tbaa !21
  br label %bb5
bb5:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb6:
  %t16 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t16, ptr %l4, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t17, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d34, i32 0, i32 1) })
  store i1 %t19, ptr %l14
  br label %bb7
bb7:
  %t20 = load i1, ptr %l14, !tbaa !21
  br i1 %t20, label %bb8, label %bb9
bb8:
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = add i64 %t21, 1
  store i64 %t23, ptr %l1, !tbaa !24
  br label %bb21
bb9:
  store %olang.scope zeroinitializer, ptr %s4
  %t25 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t25, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store i1 %t27, ptr %l18
  br label %bb10
bb10:
  %t28 = load i1, ptr %l18, !tbaa !21
  br i1 %t28, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb20
bb12:
  store %olang.scope zeroinitializer, ptr %s6
  %t29 = load i1, ptr %l2, !tbaa !21
  br i1 %t29, label %bb13, label %bb14
bb13:
  %t31 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t33 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s6, { i64, ptr } %t31, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d36, i32 0, i32 1) })
  store i1 %t33, ptr %l22
  br label %bb15
bb14:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb16
bb15:
  %t34 = load i1, ptr %l22, !tbaa !21
  store i1 %t34, ptr %l20, !tbaa !21
  br label %bb16
bb16:
  %t35 = load i1, ptr %l20, !tbaa !21
  br i1 %t35, label %bb17, label %bb18
bb17:
  %t36 = load i64, ptr %l1, !tbaa !24
  %t38 = add i64 %t36, 1
  store i64 %t38, ptr %l1, !tbaa !24
  br label %bb19
bb18:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s6)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  br label %bb2
bb23:
  %t40 = load i64, ptr %l1, !tbaa !24
  store i64 %t40, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffix_2edriven(i64 %a0) #0 {
entry:
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i64, ptr @G_2ecompiler_2ffix_2eDrivenOpt, !tbaa !24
  %t5 = icmp sge i64 %a0, %t2
  store i1 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ffix_2eensureBuilt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, ptr %a5) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca [2 x { i64, ptr }]
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca [2 x { i64, ptr }]
  %l11 = alloca i64
  %l12 = alloca [2 x { i64, ptr }]
  %l13 = alloca i64
  %l14 = alloca [2 x { i64, ptr }]
  %l15 = alloca [5 x { i64, ptr }]
  %l16 = alloca %"std/os:Output"
  %l24 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i32
  %l32 = alloca i64
  %l37 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l42 = alloca i64
  %l47 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca i64
  %l52 = alloca i64
  %l53 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l57 = alloca i1
  %l58 = alloca i1
  %l60 = alloca i64
  %l64 = alloca i32
  %l66 = alloca i1
  %l67 = alloca %"std/os:Output"
  %l68 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l84 = alloca %"std/os:Output"
  %l85 = alloca i32
  %l87 = alloca i1
  %l104 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l109 = alloca i32
  %l111 = alloca i1
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t3 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %t2, 1
  %t7 = extractvalue { i64, ptr } %t2, 0
  %t8 = add i64 %t4, %t7
  %t9 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t8)
  call void @olang_textcopy(ptr %t9, ptr %t3, i64 %t4)
  %t10 = getelementptr i8, ptr %t9, i64 %t4
  call void @olang_textcopy(ptr %t10, ptr %t6, i64 %t7)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t9, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t15 = extractvalue { i64, ptr } %t12, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  %t21 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t1, 0
  %t23 = insertvalue [2 x { i64, ptr }] %t21, { i64, ptr } %t19, 1
  store [2 x { i64, ptr }] %t23, ptr %l6
  %t26 = insertvalue { i64, ptr } undef, i64 2, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %l6, 1
  %t29 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t27)
  store { i64, ptr } %t29, ptr %l24
  br label %bb1
bb1:
  %t30 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t30, ptr %l7, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 1
  %t34 = extractvalue { i64, ptr } %t31, 0
  %t35 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t37 = add i64 %t34, %t36
  %t38 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t37)
  call void @olang_textcopy(ptr %t38, ptr %t33, i64 %t34)
  %t39 = getelementptr i8, ptr %t38, i64 %t34
  call void @olang_textcopy(ptr %t39, ptr %t35, i64 %t36)
  %t40 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t38, 1
  store { i64, ptr } %t41, ptr %l8, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t45 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } %t43)
  %t46 = extractvalue { i32, { i64, ptr } } %t45, 1
  %t47 = extractvalue { i32, { i64, ptr } } %t45, 0
  store i32 %t47, ptr %l30
  %t48 = icmp ne i32 %t47, 0
  br i1 %t48, label %bb3, label %ok.49, !prof !99
ok.49:
  store { i64, ptr } %t46, ptr %l29
  br label %bb2
bb2:
  %t50 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t50, ptr %l27, !tbaa !27
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d39, i32 0, i32 1) }, ptr %l27, !tbaa !27
  br label %bb5
bb5:
  %t51 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t51, ptr %l9, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t54 = call i64 @compiler_2ffix_2enewest(ptr %v4, { i64, ptr } %t52)
  store i64 %t54, ptr %l32
  br label %bb6
bb6:
  %t55 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t57 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t55, 0
  %t58 = insertvalue [2 x { i64, ptr }] %t57, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  store [2 x { i64, ptr }] %t58, ptr %l10
  %t61 = insertvalue { i64, ptr } undef, i64 2, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %l10, 1
  %t64 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t62)
  store { i64, ptr } %t64, ptr %l37
  br label %bb7
bb7:
  %t65 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  %t67 = extractvalue { i64, ptr } %t65, 1
  %t68 = mul i64 %t66, 1
  %t69 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t68)
  call void @llvm.memcpy.p0.p0.i64(ptr %t69, ptr %t67, i64 %t68, i1 false)
  %t70 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  %t73 = call i64 @compiler_2ffix_2enewest(ptr %s0, { i64, ptr } %t71)
  store i64 %t73, ptr %l39
  br label %bb8
bb8:
  %t74 = load i64, ptr %l32, !tbaa !24
  %t75 = load i64, ptr %l39, !tbaa !24
  %t76 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t74, i64 %t75)
  store i64 %t76, ptr %l40
  br label %bb9
bb9:
  %t77 = load i64, ptr %l40, !tbaa !24
  store i64 %t77, ptr %l11, !tbaa !24
  %t78 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t80 = call i64 @compiler_2ffix_2enewest(ptr %v1, { i64, ptr } %t78)
  store i64 %t80, ptr %l42
  br label %bb10
bb10:
  %t81 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t83 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t81, 0
  %t84 = insertvalue [2 x { i64, ptr }] %t83, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  store [2 x { i64, ptr }] %t84, ptr %l12
  %t87 = insertvalue { i64, ptr } undef, i64 2, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %l12, 1
  %t90 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t88)
  store { i64, ptr } %t90, ptr %l47
  br label %bb11
bb11:
  %t91 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t91, 0
  %t93 = extractvalue { i64, ptr } %t91, 1
  %t94 = mul i64 %t92, 1
  %t95 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t94)
  call void @llvm.memcpy.p0.p0.i64(ptr %t95, ptr %t93, i64 %t94, i1 false)
  %t96 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  %t99 = call i64 @compiler_2ffix_2enewest(ptr %s0, { i64, ptr } %t97)
  store i64 %t99, ptr %l49
  br label %bb12
bb12:
  %t100 = load i64, ptr %l42, !tbaa !24
  %t101 = load i64, ptr %l49, !tbaa !24
  %t102 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t100, i64 %t101)
  store i64 %t102, ptr %l50
  br label %bb13
bb13:
  %t103 = load i64, ptr %l11, !tbaa !24
  %t104 = load i64, ptr %l50, !tbaa !24
  %t106 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t104, i64 %t103)
  store i64 %t106, ptr %l52
  br label %bb14
bb14:
  %t107 = load i64, ptr %l52, !tbaa !24
  store i64 %t107, ptr %l13, !tbaa !24
  %t108 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t108, ptr %l53, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t111 = call { i64, ptr } @compiler_2ffix_2ebuiltBy(ptr %v0, ptr %s0, { i64, ptr } %t109)
  store { i64, ptr } %t111, ptr %l55
  br label %bb15
bb15:
  %t112 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t112, 0
  %t114 = extractvalue { i64, ptr } %t112, 1
  %t115 = mul i64 %t113, 1
  %t116 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t115)
  call void @llvm.memcpy.p0.p0.i64(ptr %t116, ptr %t114, i64 %t115, i1 false)
  %t117 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t116, 1
  %t119 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t121 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t119, { i64, ptr } %t118)
  store i1 %t121, ptr %l57
  br label %bb16
bb16:
  %t122 = load i1, ptr %l57, !tbaa !21
  br i1 %t122, label %bb17, label %bb18
bb17:
  %t123 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t125 = call i64 @compiler_2ffix_2emtime(ptr %s0, { i64, ptr } %t123)
  store i64 %t125, ptr %l60
  br label %bb19
bb18:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb20
bb19:
  %t126 = load i64, ptr %l13, !tbaa !24
  %t127 = load i64, ptr %l60, !tbaa !24
  %t129 = icmp sgt i64 %t127, %t126
  store i1 %t129, ptr %l58, !tbaa !21
  br label %bb20
bb20:
  %t131 = load i1, ptr %l58, !tbaa !21
  br i1 %t131, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t132 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t134 = call i32 @std_2fos_2eRemove(ptr %s0, { i64, ptr } %t132)
  store i32 %t134, ptr %l64
  %t135 = icmp ne i32 %t134, 0
  br i1 %t135, label %bb25, label %ok.136, !prof !99
ok.136:
  br label %bb24
bb24:
  br label %bb27
bb25:
  %t137 = load i32, ptr %l64, !tbaa !23
  %t138 = ashr i32 %t137, 16
  %t140 = icmp eq i32 %t138, 1
  store i1 %t140, ptr %l66, !tbaa !21
  br label %bb26
bb26:
  call void @__olang_ert_req_clear()
  br label %bb27
bb27:
  %t141 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t141, ptr %l68, !tbaa !27
  %t142 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t142, ptr %l69, !tbaa !27
  %t143 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t144 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t144, 1
  %t147 = extractvalue { i64, ptr } %t144, 0
  %t148 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t149 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t150 = add i64 %t147, %t149
  %t151 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t150)
  call void @olang_textcopy(ptr %t151, ptr %t146, i64 %t147)
  %t152 = getelementptr i8, ptr %t151, i64 %t147
  call void @olang_textcopy(ptr %t152, ptr %t148, i64 %t149)
  %t153 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t151, 1
  %t156 = extractvalue { i64, ptr } %t154, 0
  %t157 = extractvalue { i64, ptr } %t154, 1
  %t158 = mul i64 %t156, 1
  %t159 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t158)
  call void @llvm.memcpy.p0.p0.i64(ptr %t159, ptr %t157, i64 %t158, i1 false)
  %t160 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t161 = insertvalue { i64, ptr } %t160, ptr %t159, 1
  %t163 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t143, 0
  %t165 = insertvalue [2 x { i64, ptr }] %t163, { i64, ptr } %t161, 1
  store [2 x { i64, ptr }] %t165, ptr %l14
  %t168 = insertvalue { i64, ptr } undef, i64 2, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr %l14, 1
  %t171 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t169)
  store { i64, ptr } %t171, ptr %l77
  br label %bb28
bb28:
  %t172 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t173 = extractvalue { i64, ptr } %t172, 0
  %t174 = extractvalue { i64, ptr } %t172, 1
  %t175 = mul i64 %t173, 1
  %t176 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t175)
  call void @llvm.memcpy.p0.p0.i64(ptr %t176, ptr %t174, i64 %t175, i1 false)
  %t177 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t176, 1
  %t179 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t180 = insertvalue [5 x { i64, ptr }] undef, { i64, ptr } %t179, 0
  %t181 = insertvalue [5 x { i64, ptr }] %t180, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t182 = insertvalue [5 x { i64, ptr }] %t181, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d44, i32 0, i32 1) }, 2
  %t183 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t184 = insertvalue [5 x { i64, ptr }] %t182, { i64, ptr } %t183, 3
  %t186 = insertvalue [5 x { i64, ptr }] %t184, { i64, ptr } %t178, 4
  store [5 x { i64, ptr }] %t186, ptr %l15
  %t189 = insertvalue { i64, ptr } undef, i64 5, 0
  %t190 = insertvalue { i64, ptr } %t189, ptr %l15, 1
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l82, !tbaa !27
  %t191 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t193 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t195 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s0, ptr %s0, ptr %v2, ptr %s0, { i64, ptr } %t190, { i64, ptr } %t193, i1 true, { i64, ptr } %t191)
  %t196 = extractvalue { i32, %"std/os:Output" } %t195, 1
  %t197 = extractvalue { i32, %"std/os:Output" } %t195, 0
  store i32 %t197, ptr %l85
  %t198 = icmp ne i32 %t197, 0
  br i1 %t198, label %bb30, label %ok.199, !prof !99
ok.199:
  store %"std/os:Output" %t196, ptr %l84
  br label %bb29
bb29:
  %t200 = load %"std/os:Output", ptr %l84
  store %"std/os:Output" %t200, ptr %l67
  br label %bb33
bb30:
  %t201 = load i32, ptr %l85, !tbaa !23
  %t202 = ashr i32 %t201, 16
  %t204 = icmp eq i32 %t202, 1
  store i1 %t204, ptr %l87, !tbaa !21
  br label %bb31
bb31:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s6
  %t205 = load ptr, ptr %l5, !tbaa !29
  %t206 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t207 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t208 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t210 = extractvalue { i64, ptr } %t206, 1
  %t211 = extractvalue { i64, ptr } %t206, 0
  %t212 = add i64 %t208, %t211
  %t213 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t214 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t215 = add i64 %t212, %t214
  %t216 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t215)
  call void @olang_textcopy(ptr %t216, ptr %t207, i64 %t208)
  %t217 = getelementptr i8, ptr %t216, i64 %t208
  call void @olang_textcopy(ptr %t217, ptr %t210, i64 %t211)
  %t218 = getelementptr i8, ptr %t217, i64 %t211
  call void @olang_textcopy(ptr %t218, ptr %t213, i64 %t214)
  %t219 = insertvalue { i64, ptr } undef, i64 %t215, 0
  %t220 = insertvalue { i64, ptr } %t219, ptr %t216, 1
  %t223 = extractvalue { i64, ptr } %t220, 0
  %t224 = extractvalue { i64, ptr } %t220, 1
  %t225 = mul i64 %t223, 1
  %t226 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t225)
  call void @llvm.memcpy.p0.p0.i64(ptr %t226, ptr %t224, i64 %t225, i1 false)
  %t227 = insertvalue { i64, ptr } undef, i64 %t223, 0
  %t228 = insertvalue { i64, ptr } %t227, ptr %t226, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v5, ptr %s6, ptr %t205, { i64, ptr } %t228)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb33:
  %t232 = load %"std/os:Output", ptr %l67
  store %"std/os:Output" %t232, ptr %l16
  %t233 = getelementptr %"std/os:Output", ptr %l16, i32 0, i32 0
  %t234 = load i32, ptr %t233, !tbaa !23
  %t236 = icmp ne i32 %t234, 0
  br i1 %t236, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s8
  %t238 = load ptr, ptr %l5, !tbaa !29
  %t239 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t240 = getelementptr %"std/os:Output", ptr %l16, i32 0, i32 1
  %t241 = load { i64, ptr }, ptr %t240, !tbaa !27
  %t242 = getelementptr %"std/os:Output", ptr %l16, i32 0, i32 2
  %t243 = load { i64, ptr }, ptr %t242, !tbaa !27
  %t244 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t245 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  %t247 = extractvalue { i64, ptr } %t239, 1
  %t248 = extractvalue { i64, ptr } %t239, 0
  %t249 = add i64 %t245, %t248
  %t250 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t251 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  %t252 = add i64 %t249, %t251
  %t254 = extractvalue { i64, ptr } %t241, 1
  %t255 = extractvalue { i64, ptr } %t241, 0
  %t256 = add i64 %t252, %t255
  %t258 = extractvalue { i64, ptr } %t243, 1
  %t259 = extractvalue { i64, ptr } %t243, 0
  %t260 = add i64 %t256, %t259
  %t261 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t260)
  call void @olang_textcopy(ptr %t261, ptr %t244, i64 %t245)
  %t262 = getelementptr i8, ptr %t261, i64 %t245
  call void @olang_textcopy(ptr %t262, ptr %t247, i64 %t248)
  %t263 = getelementptr i8, ptr %t262, i64 %t248
  call void @olang_textcopy(ptr %t263, ptr %t250, i64 %t251)
  %t264 = getelementptr i8, ptr %t263, i64 %t251
  call void @olang_textcopy(ptr %t264, ptr %t254, i64 %t255)
  %t265 = getelementptr i8, ptr %t264, i64 %t255
  call void @olang_textcopy(ptr %t265, ptr %t258, i64 %t259)
  %t266 = insertvalue { i64, ptr } undef, i64 %t260, 0
  %t267 = insertvalue { i64, ptr } %t266, ptr %t261, 1
  %t270 = extractvalue { i64, ptr } %t267, 0
  %t271 = extractvalue { i64, ptr } %t267, 1
  %t272 = mul i64 %t270, 1
  %t273 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t272)
  call void @llvm.memcpy.p0.p0.i64(ptr %t273, ptr %t271, i64 %t272, i1 false)
  %t274 = insertvalue { i64, ptr } undef, i64 %t270, 0
  %t275 = insertvalue { i64, ptr } %t274, ptr %t273, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v5, ptr %s8, ptr %t238, { i64, ptr } %t275)
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb37:
  %t279 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t279, ptr %l104, !tbaa !27
  %t280 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t282 = call { i64, ptr } @compiler_2ffix_2ebuiltBy(ptr %v0, ptr %s0, { i64, ptr } %t280)
  store { i64, ptr } %t282, ptr %l106
  br label %bb38
bb38:
  %t283 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t285 = extractvalue { i64, ptr } %t283, 0
  %t286 = extractvalue { i64, ptr } %t283, 1
  %t287 = mul i64 %t285, 1
  %t288 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t287)
  call void @llvm.memcpy.p0.p0.i64(ptr %t288, ptr %t286, i64 %t287, i1 false)
  %t289 = insertvalue { i64, ptr } undef, i64 %t285, 0
  %t290 = insertvalue { i64, ptr } %t289, ptr %t288, 1
  %t291 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t293 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t291, { i64, ptr } %t290)
  store i32 %t293, ptr %l109
  %t294 = icmp ne i32 %t293, 0
  br i1 %t294, label %bb40, label %ok.295, !prof !99
ok.295:
  br label %bb39
bb39:
  br label %bb42
bb40:
  %t296 = load i32, ptr %l109, !tbaa !23
  %t297 = ashr i32 %t296, 16
  %t299 = icmp eq i32 %t297, 1
  store i1 %t299, ptr %l111, !tbaa !21
  br label %bb41
bb41:
  call void @__olang_ert_req_clear()
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffix_2eexpand(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %lp1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca { i64, ptr }
  %l18 = alloca i1
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  br label %bb5
bb5:
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t19, ptr %l14, !tbaa !27
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %t23, i64 %t20
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !37
  store { i64, ptr } %t25, ptr %l5, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t29 = call i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %t27)
  store i1 %t29, ptr %l18
  br label %bb6
bb6:
  %t30 = load i1, ptr %l18, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  %t31 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t32 = load ptr, ptr %lp1
  call void @compiler_2ffix_2ewalk(ptr %v0, ptr %v1, { i64, ptr } %t31, ptr %t32)
  br label %bb9
bb8:
  %t35 = load ptr, ptr %lp1
  %t36 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 1
  %t39 = extractvalue { i64, ptr } %t36, 0
  %t40 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t39)
  call void @olang_textcopy(ptr %t40, ptr %t38, i64 %t39)
  %t41 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t45 = extractvalue { i64, ptr } %t42, 1
  %t46 = mul i64 %t44, 1
  %t47 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t46)
  call void @llvm.memcpy.p0.p0.i64(ptr %t47, ptr %t45, i64 %t46, i1 false)
  %t48 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t35, { i64, ptr } %t49)
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t52 = load i64, ptr %l3, !tbaa !24
  %t54 = add i64 %t52, 1
  store i64 %t54, ptr %l3, !tbaa !24
  br label %bb2
bb13:
  %t56 = load ptr, ptr %lp1
  %t57 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t56
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t57, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i64 @compiler_2ffix_2emtime(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/os:FileInfo"
  %l2 = alloca %"std/os:FileInfo"
  %l4 = alloca %"std/os:FileInfo"
  %l5 = alloca i32
  %l7 = alloca i1
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v0, { i64, ptr } %a0)
  %t4 = extractvalue { i32, %"std/os:FileInfo" } %t3, 1
  %t5 = extractvalue { i32, %"std/os:FileInfo" } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store %"std/os:FileInfo" %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load %"std/os:FileInfo", ptr %l4
  store %"std/os:FileInfo" %t8, ptr %l2
  br label %bb4
bb2:
  %t9 = load i32, ptr %l5, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  store i1 %t12, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %rv
  br label %ret
bb4:
  %t14 = load %"std/os:FileInfo", ptr %l2
  store %"std/os:FileInfo" %t14, ptr %l1
  %t15 = getelementptr %"std/os:FileInfo", ptr %l1, i32 0, i32 2
  %t16 = load i64, ptr %t15, !tbaa !24
  store i64 %t16, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ffix_2enewest(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca [2 x { i64, ptr }]
  %l8 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i32
  %l22 = alloca { i64, ptr }
  %l26 = alloca i1
  %l27 = alloca i64
  %l33 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %s0, { i64, ptr } %t1)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l11
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l10
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t8, ptr %l8, !tbaa !27
  br label %bb8
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  %t9 = icmp sge i64 0, 0
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t11 = icmp sle i64 0, 576460752303423487
  br i1 %t11, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_8fcf87cfa7be21dd_bbd76dac3520f231)
  unreachable
bb6:
  %t13 = mul i64 0, 16
  %t14 = insertvalue { i64, ptr } undef, i64 0, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t15, ptr %l8, !tbaa !27
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_8fcf87cfa7be21dd_bbd76dac3520f231)
  unreachable
bb8:
  %t17 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t17, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  store i64 %t22, ptr %l5, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t24 = load i64, ptr %l4, !tbaa !24
  %t25 = load i64, ptr %l5, !tbaa !24
  %t28 = icmp slt i64 %t24, %t25
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb11:
  br label %bb12
bb12:
  %t32 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t32, ptr %l22, !tbaa !27
  %t33 = load i64, ptr %l4, !tbaa !24
  %t35 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %t36, i64 %t33
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !37
  store { i64, ptr } %t38, ptr %l6, !tbaa !27
  %t40 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t42 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s2, { i64, ptr } %t40, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d49, i32 0, i32 1) })
  store i1 %t42, ptr %l26
  br label %bb13
bb13:
  %t43 = load i1, ptr %l26, !tbaa !21
  br i1 %t43, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t44 = load i64, ptr %l1, !tbaa !24
  store i64 %t44, ptr %l27, !tbaa !24
  %t45 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t48 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t45, 0
  %t50 = insertvalue [2 x { i64, ptr }] %t48, { i64, ptr } %t46, 1
  store [2 x { i64, ptr }] %t50, ptr %l7
  %t53 = insertvalue { i64, ptr } undef, i64 2, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %l7, 1
  %t56 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s3, ptr %s3, { i64, ptr } %t54)
  store { i64, ptr } %t56, ptr %l33
  br label %bb16
bb15:
  br label %bb19
bb16:
  %t57 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t57, 0
  %t59 = extractvalue { i64, ptr } %t57, 1
  %t60 = mul i64 %t58, 1
  %t61 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t60)
  call void @llvm.memcpy.p0.p0.i64(ptr %t61, ptr %t59, i64 %t60, i1 false)
  %t62 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t61, 1
  %t65 = call i64 @compiler_2ffix_2emtime(ptr %s3, { i64, ptr } %t63)
  store i64 %t65, ptr %l35
  br label %bb17
bb17:
  %t66 = load i64, ptr %l27, !tbaa !24
  %t67 = load i64, ptr %l35, !tbaa !24
  %t68 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t66, i64 %t67)
  store i64 %t68, ptr %l36
  br label %bb18
bb18:
  %t69 = load i64, ptr %l36, !tbaa !24
  store i64 %t69, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  %t70 = load i64, ptr %l4, !tbaa !24
  %t72 = add i64 %t70, 1
  store i64 %t72, ptr %l4, !tbaa !24
  br label %bb9
bb21:
  %t74 = load i64, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t74, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffix_2ewalk(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca [2 x { i64, ptr }]
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i32
  %l23 = alloca { i64, ptr }
  %l27 = alloca i1
  %l28 = alloca i1
  %l30 = alloca i1
  %l36 = alloca { i64, ptr }
  %l38 = alloca i1
  %l42 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %s0, { i64, ptr } %t1)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l12
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l11
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t8, ptr %l9, !tbaa !27
  br label %bb8
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  %t9 = icmp sge i64 0, 0
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t11 = icmp sle i64 0, 576460752303423487
  br i1 %t11, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_9433da86f750b978_3ff5b65d50af9d4)
  unreachable
bb6:
  %t13 = mul i64 0, 16
  %t14 = insertvalue { i64, ptr } undef, i64 0, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t15, ptr %l9, !tbaa !27
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_9433da86f750b978_3ff5b65d50af9d4)
  unreachable
bb8:
  %t17 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t17, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  store i64 %t22, ptr %l5, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t24 = load i64, ptr %l4, !tbaa !24
  %t25 = load i64, ptr %l5, !tbaa !24
  %t28 = icmp slt i64 %t24, %t25
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb11:
  br label %bb12
bb12:
  %t32 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t32, ptr %l23, !tbaa !27
  %t33 = load i64, ptr %l4, !tbaa !24
  %t35 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %t36, i64 %t33
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !37
  store { i64, ptr } %t38, ptr %l6, !tbaa !27
  %t40 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t42 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s2, { i64, ptr } %t40, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) })
  store i1 %t42, ptr %l27
  br label %bb13
bb13:
  %t43 = load i1, ptr %l27, !tbaa !21
  br i1 %t43, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb17
bb15:
  %t44 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t46 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s2, { i64, ptr } %t44, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d51, i32 0, i32 1) })
  store i1 %t46, ptr %l30
  br label %bb16
bb16:
  %t47 = load i1, ptr %l30, !tbaa !21
  store i1 %t47, ptr %l28, !tbaa !21
  br label %bb17
bb17:
  %t48 = load i1, ptr %l28, !tbaa !21
  br i1 %t48, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb19:
  br label %bb20
bb20:
  %t49 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t52 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t49, 0
  %t54 = insertvalue [2 x { i64, ptr }] %t52, { i64, ptr } %t50, 1
  store [2 x { i64, ptr }] %t54, ptr %l7
  %t57 = insertvalue { i64, ptr } undef, i64 2, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %l7, 1
  %t60 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s2, ptr %s2, { i64, ptr } %t58)
  store { i64, ptr } %t60, ptr %l36
  br label %bb21
bb21:
  %t61 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t61, ptr %l8, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t64 = call i1 @std_2fos_2eIsDir(ptr %s2, { i64, ptr } %t62)
  store i1 %t64, ptr %l38
  br label %bb22
bb22:
  %t65 = load i1, ptr %l38, !tbaa !21
  br i1 %t65, label %bb23, label %bb24
bb23:
  %t66 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t67 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ffix_2ewalk(ptr %s2, ptr %v1, { i64, ptr } %t66, ptr %t67)
  br label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t70 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t72 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s5, { i64, ptr } %t70, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d52, i32 0, i32 1) })
  store i1 %t72, ptr %l42
  br label %bb26
bb25:
  br label %bb31
bb26:
  %t73 = load i1, ptr %l42, !tbaa !21
  br i1 %t73, label %bb27, label %bb28
bb27:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t75 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t75, 1
  %t78 = extractvalue { i64, ptr } %t75, 0
  %t79 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t78)
  call void @olang_textcopy(ptr %t79, ptr %t77, i64 %t78)
  %t80 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t79, 1
  %t83 = extractvalue { i64, ptr } %t81, 0
  %t84 = extractvalue { i64, ptr } %t81, 1
  %t85 = mul i64 %t83, 1
  %t86 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t85)
  call void @llvm.memcpy.p0.p0.i64(ptr %t86, ptr %t84, i64 %t85, i1 false)
  %t87 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t86, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t74, { i64, ptr } %t88)
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb32:
  %t91 = load i64, ptr %l4, !tbaa !24
  %t93 = add i64 %t91, 1
  store i64 %t93, ptr %l4, !tbaa !24
  br label %bb9
bb33:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

declare void @__olang_ert_req_clear()
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d0 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fix" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d1 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d2 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c": cannot be read\0A" }>, align 8
@.d3 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"olang: fix: no tools directory at " }>, align 8
@.d4 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c" (OLANG_TOOLS names another)\0A" }>, align 8
@.d5 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"olang: fix: cannot make " }>, align 8
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d7 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"tools_" }>, align 8
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d9 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d10 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"olang: fix: cannot run " }>, align 8
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d12 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c":\0A" }>, align 8
@.d13 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d16 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d17 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c": cannot be written\0A" }>, align 8
@.d18 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d19 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d20 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"olang fix: " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d21 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" place" }>, align 8
@.d22 = private constant <{ i64, [89 x i8] }> <{ i64 0, [89 x i8] c" above may mean something else in the language of today than when written - look at each\0A" }>, align 8
@.d23 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"text" }>, align 8
@.d24 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"driven" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d25 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"driven" }>, align 8
@.d26 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"OLANG_TOOLS" }>, align 8
@.d27 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d28 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d29 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"/../tools" }>, align 8
@.d30 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"--std" }>, align 8
@.d31 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"--olang" }>, align 8
@.d32 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d33 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d34 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"by hand:" }>, align 8
@.d35 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"for a person:" }>, align 8
@.d36 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d37 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"tools_" }>, align 8
@.d38 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".from" }>, align 8
@.d39 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d40 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"prelude" }>, align 8
@.d41 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"../compiler" }>, align 8
@.d42 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@.d43 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"build" }>, align 8
@.d44 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"-output" }>, align 8
@.d45 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"olang: fix: cannot run " }>, align 8
@.d46 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d47 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"olang: fix: tools/" }>, align 8
@.d48 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c".olang does not build:\0A" }>, align 8
@__olang_empty_array = external constant [16 x i64]
@.d49 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@.d50 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d51 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"build" }>, align 8
@.d52 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2ffetch_2eCacheDir(ptr %v0)
declare { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_74a546a3dd225c9b_f3beb7f3829b0fbf = external constant [0 x i8]
declare %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %v0, i32 %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %v0, ptr %a0)
declare i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
@olang_loc_299e69389bcee8f2_b185402659ea7d46 = external constant [0 x i8]
declare { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2ffilepath_2eDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v0, { i64, ptr } %a0)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %a0, i64 %a1)
declare i32 @std_2fos_2eRemove(ptr %v0, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_8fcf87cfa7be21dd_bbd76dac3520f231 = external constant [0 x i8]
@olang_loc_9433da86f750b978_3ff5b65d50af9d4 = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
