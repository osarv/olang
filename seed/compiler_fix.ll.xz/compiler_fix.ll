; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/io:Writer" = type { i32, { i64, ptr }, i64, { i32, { i64, [1 x i64] } } }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"std/os:FileInfo" = type { i32, i64, i64 }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
@G_2ecompiler_2ffix_2eBatch = constant <{ [8 x i8] }> <{ [8 x i8] c"\C8\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eDrivenArg = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eDrivenOpt = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eStdTool = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eTextTool = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eToolKinds = constant <{ [264 x i8] }> <{ [264 x i8] c"\01\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\03\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2ffix_2eToolNames = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k1, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k2, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k3, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k4, [8 x i8] c"\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k5, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k6, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k7, [8 x i8] c"\0C\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k8, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k9, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k10, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k11, [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k12, [8 x i8] c"\0C\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k13, [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k14, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k15, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k16, [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k17, [8 x i8] c"\0B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k18, [8 x i8] c"\0A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k19, [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k20, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k21, [8 x i8] c"\0C\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k22, [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k23, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k24, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k25, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k26, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k27, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k28, [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k29, [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k30, [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k31, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k32, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k33 }>, align 64
@G_2ecompiler_2ffix_2eToolNames.k1 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\62\61\72\65\5F\74\79\70\65\76\61\72\73" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k2 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\70\65\72\6D\5F\6D\75\74" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k3 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\69\6E\74\5F\6C\69\74\65\72\61\6C\5F\69\36\34" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k4 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\65\72\72\6F\72\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k5 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\63\6C\69\5F\77\6F\72\64\73" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k6 = internal constant <{ [16 x i8] }> <{ [16 x i8] c"\64\6F\6E\65\66\61\69\6C\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k7 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\73\79\6E\74\61\78\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k8 = internal constant <{ [12 x i8] }> <{ [12 x i8] c"\6D\61\74\68\5F\6D\65\74\68\6F\64\73" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k9 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\61\72\72\61\79\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k10 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\72\65\73\75\6C\74\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k11 = internal constant <{ [16 x i8] }> <{ [16 x i8] c"\65\71\75\61\6C\69\74\79\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k12 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\68\65\6C\70\65\72\5F\72\65\6E\61\6D\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k13 = internal constant <{ [12 x i8] }> <{ [12 x i8] c"\6E\75\6C\6C\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k14 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\63\68\65\63\6B\65\72\72\6F\72\5F\72\65\6E\61\6D\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k15 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\73\74\75\74\74\65\72\5F\72\65\6E\61\6D\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k16 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\63\68\65\63\6B\65\64\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k17 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\63\6F\6E\74\72\61\63\74\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k18 = internal constant <{ [11 x i8] }> <{ [11 x i8] c"\74\72\79\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k19 = internal constant <{ [10 x i8] }> <{ [10 x i8] c"\61\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k20 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\65\72\72\6F\72\74\79\70\65\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k21 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\6C\69\73\74\5F\76\65\63" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k22 = internal constant <{ [12 x i8] }> <{ [12 x i8] c"\6C\69\6E\6B\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k23 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\6D\61\74\63\68\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k24 = internal constant <{ [16 x i8] }> <{ [16 x i8] c"\71\75\65\73\74\69\6F\6E\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k25 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\75\6E\75\73\65\64\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k26 = internal constant <{ [16 x i8] }> <{ [16 x i8] c"\65\72\72\6F\72\63\61\73\65\5F\72\65\6E\61\6D\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k27 = internal constant <{ [16 x i8] }> <{ [16 x i8] c"\76\61\72\69\61\64\69\63\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k28 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\73\63\6F\70\65\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k29 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\66\6E\72\65\66\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k30 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\63\6C\6F\6E\65\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k31 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\74\65\78\74\62\75\69\6C\64\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k32 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\75\6E\69\71\75\65\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k33 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\62\75\69\6C\64\65\72\5F\6D\69\67\72\61\74\65" }>, align 8
define dso_local { i64, ptr } @compiler_2ffix_2eBinDir(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca [2 x { i64, ptr }]
  %l6 = alloca [2 x { i64, ptr }]
  %l7 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l16 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i32
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l51 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %s0, { i64, ptr } %t1)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l10
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l9
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t8, ptr %l7, !tbaa !27
  br label %bb6
bb2:
  %t9 = load i32, ptr %l10, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  br i1 %t12, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  %t14 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 1
  %t17 = extractvalue { i64, ptr } %t14, 0
  %t18 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t17)
  call void @olang_textcopy(ptr %t18, ptr %t16, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t23 = extractvalue { i64, ptr } %t20, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l7, !tbaa !27
  br label %bb6
bb6:
  %t29 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t29, ptr %l2, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t32 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v1, ptr %s0, { i64, ptr } %t30)
  %t33 = extractvalue { i32, { i64, ptr } } %t32, 1
  %t34 = extractvalue { i32, { i64, ptr } } %t32, 0
  store i32 %t34, ptr %l19
  %t35 = icmp ne i32 %t34, 0
  br i1 %t35, label %bb8, label %ok.36, !prof !99
ok.36:
  store { i64, ptr } %t33, ptr %l18
  br label %bb7
bb7:
  %t37 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t37, ptr %l16, !tbaa !27
  br label %bb12
bb8:
  %t38 = load i32, ptr %l19, !tbaa !23
  %t39 = ashr i32 %t38, 16
  %t41 = icmp eq i32 %t39, 1
  br i1 %t41, label %bb9, label %bb10
bb9:
  call void @__olang_errpay_pop()
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t43 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 1
  %t46 = extractvalue { i64, ptr } %t43, 0
  %t47 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t46)
  call void @olang_textcopy(ptr %t47, ptr %t45, i64 %t46)
  %t48 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t52 = extractvalue { i64, ptr } %t49, 1
  %t53 = mul i64 %t51, 1
  %t54 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t53)
  call void @llvm.memcpy.p0.p0.i64(ptr %t54, ptr %t52, i64 %t53, i1 false)
  %t55 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t54, 1
  store { i64, ptr } %t56, ptr %l16, !tbaa !27
  br label %bb12
bb12:
  %t58 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t58, ptr %l3, !tbaa !27
  %t59 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t59, ptr %l25
  br label %bb13
bb13:
  %t60 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t60, ptr %l4
  %t61 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t61, 1
  %t64 = extractvalue { i64, ptr } %t61, 0
  %t65 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t64)
  call void @olang_textcopy(ptr %t65, ptr %t63, i64 %t64)
  %t66 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t65, 1
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t70 = extractvalue { i64, ptr } %t67, 1
  %t71 = mul i64 %t69, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t70, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } %t74)
  br label %bb14
bb14:
  %t77 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t77, 1
  %t80 = extractvalue { i64, ptr } %t77, 0
  %t81 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t80)
  call void @olang_textcopy(ptr %t81, ptr %t79, i64 %t80)
  %t82 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t81, 1
  %t85 = extractvalue { i64, ptr } %t83, 0
  %t86 = extractvalue { i64, ptr } %t83, 1
  %t87 = mul i64 %t85, 1
  %t88 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t87)
  call void @llvm.memcpy.p0.p0.i64(ptr %t88, ptr %t86, i64 %t87, i1 false)
  %t89 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } %t90)
  br label %bb15
bb15:
  %t93 = call { i64, ptr } @compiler_2ffetch_2eCacheDir(ptr %s0)
  store { i64, ptr } %t93, ptr %l34
  br label %bb16
bb16:
  %t94 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 0
  %t96 = extractvalue { i64, ptr } %t94, 1
  %t97 = mul i64 %t95, 1
  %t98 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t97)
  call void @llvm.memcpy.p0.p0.i64(ptr %t98, ptr %t96, i64 %t97, i1 false)
  %t99 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  %t102 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t100, 0
  %t103 = insertvalue [2 x { i64, ptr }] %t102, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  store [2 x { i64, ptr }] %t103, ptr %l5
  %t106 = insertvalue { i64, ptr } undef, i64 2, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %l5, 1
  %t109 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t107)
  store { i64, ptr } %t109, ptr %l39
  br label %bb17
bb17:
  %t110 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t110, 0
  %t112 = extractvalue { i64, ptr } %t110, 1
  %t113 = mul i64 %t111, 1
  %t114 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t113)
  call void @llvm.memcpy.p0.p0.i64(ptr %t114, ptr %t112, i64 %t113, i1 false)
  %t115 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t114, 1
  store { i64, ptr } %t116, ptr %l40, !tbaa !27
  %t118 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s0, ptr %s0, ptr %l4)
  store { i64, ptr } %t118, ptr %l42
  br label %bb18
bb18:
  %t119 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t119, 0
  store i64 %t120, ptr %l43, !tbaa !24
  %t121 = icmp sge i64 0, 0
  br i1 %t121, label %bb19, label %bb20
bb19:
  %t123 = icmp sle i64 0, 16
  br i1 %t123, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_74a546a3dd225c9b_f3beb7f3829b0fbf)
  unreachable
bb21:
  %t125 = load i64, ptr %l43, !tbaa !24
  %t126 = icmp sle i64 16, %t125
  br i1 %t126, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_74a546a3dd225c9b_f3beb7f3829b0fbf)
  unreachable
bb23:
  %t128 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr i8, ptr %t129, i64 0
  %t131 = sub i64 16, 0
  %t132 = insertvalue { i64, ptr } undef, i64 %t131, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t130, 1
  %t134 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t135 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t134, 0
  %t137 = insertvalue [2 x { i64, ptr }] %t135, { i64, ptr } %t133, 1
  store [2 x { i64, ptr }] %t137, ptr %l6
  %t140 = insertvalue { i64, ptr } undef, i64 2, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %l6, 1
  %t143 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %v2, { i64, ptr } %t141)
  store { i64, ptr } %t143, ptr %l51
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_74a546a3dd225c9b_f3beb7f3829b0fbf)
  unreachable
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t144 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t144, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2ffix_2eFiles(ptr %v0, ptr %v1, ptr %v2, i1 %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca i1
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/io:Writer"
  %l5 = alloca %"std/io:Writer"
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca [2 x { i64, ptr }]
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l31 = alloca %"std/os:Output"
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l43 = alloca %"std/io:Writer"
  %l44 = alloca %"std/io:Writer"
  %l46 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l48 = alloca { i64, ptr }
  %l49 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l57 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l63 = alloca i32
  %l65 = alloca i1
  %l74 = alloca i32
  %l76 = alloca i1
  %l87 = alloca { i64, ptr }
  %l89 = alloca i1
  %l97 = alloca i32
  %l99 = alloca i1
  %l105 = alloca { i64, ptr }
  %l107 = alloca i32
  %l109 = alloca i1
  %l118 = alloca i32
  %l120 = alloca i1
  %l124 = alloca { i64, ptr }
  %l132 = alloca { i64, ptr }
  %l143 = alloca i32
  %l145 = alloca i1
  %l153 = alloca { i64, ptr }
  %l160 = alloca i64
  %l163 = alloca i64
  %l181 = alloca { i64, ptr }
  %l182 = alloca i64
  %l188 = alloca i64
  %l189 = alloca i64
  %l194 = alloca %"std/os:Output"
  %l201 = alloca { i64, ptr }
  %l203 = alloca { i64, ptr }
  %l204 = alloca %"std/os:Output"
  %l205 = alloca i32
  %l207 = alloca i1
  %l219 = alloca i64
  %l222 = alloca i1
  %l232 = alloca i1
  %l235 = alloca { i64, ptr }
  %l252 = alloca i64
  %l255 = alloca i64
  %l273 = alloca { i64, ptr }
  %l274 = alloca { i64, ptr }
  %l277 = alloca { i64, ptr }
  %l278 = alloca i32
  %l280 = alloca i1
  %l283 = alloca { i64, ptr }
  %l286 = alloca { i64, ptr }
  %l287 = alloca i1
  %l291 = alloca { i64, ptr }
  %l298 = alloca { i64, ptr }
  %l300 = alloca { i64, ptr }
  %l303 = alloca { i64, ptr }
  %l305 = alloca i32
  %l307 = alloca i1
  %l311 = alloca { i64, ptr }
  %l321 = alloca i1
  %l326 = alloca { i64, ptr }
  %l334 = alloca i32
  %l336 = alloca i1
  %l341 = alloca i32
  %l343 = alloca i1
  %l351 = alloca i1
  %l354 = alloca i1
  %l357 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %rv = alloca i32
  store i1 %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %s0, i32 2, i64 65536)
  store %"std/io:Writer" %t1, ptr %l43
  br label %bb1
bb1:
  %t2 = load %"std/io:Writer", ptr %l43
  store %"std/io:Writer" %t2, ptr %l4
  %t3 = call %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %s0, i32 1, i64 65536)
  store %"std/io:Writer" %t3, ptr %l44
  br label %bb2
bb2:
  %t4 = load %"std/io:Writer", ptr %l44
  store %"std/io:Writer" %t4, ptr %l5
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffix_2eexpand(ptr %v0, ptr %s0, { i64, ptr } %a1)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l46
  br label %bb3
bb3:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l46
  %t9 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %t9
  %t11 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s0, ptr %s0, ptr %t9)
  store { i64, ptr } %t11, ptr %l48
  br label %bb4
bb4:
  %t12 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t12, ptr %l6, !tbaa !27
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l49
  br label %bb5
bb5:
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l49
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l7
  %t15 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t15, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  store i64 %t19, ptr %l10, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t21 = load i64, ptr %l9, !tbaa !24
  %t22 = load i64, ptr %l10, !tbaa !24
  %t25 = icmp slt i64 %t21, %t22
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb8:
  br label %bb9
bb9:
  %t29 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t29, ptr %l57, !tbaa !27
  %t30 = load i64, ptr %l9, !tbaa !24
  %t32 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr { i64, ptr }, ptr %t33, i64 %t30
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !37
  store { i64, ptr } %t35, ptr %l11, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t39 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s2, { i64, ptr } %t37)
  %t40 = extractvalue { i32, { i64, ptr } } %t39, 1
  %t41 = extractvalue { i32, { i64, ptr } } %t39, 0
  store i32 %t41, ptr %l63
  %t42 = icmp ne i32 %t41, 0
  br i1 %t42, label %bb11, label %ok.43, !prof !99
ok.43:
  store { i64, ptr } %t40, ptr %l62
  br label %bb10
bb10:
  %t44 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t44, ptr %l60, !tbaa !27
  br label %bb22
bb11:
  %t45 = load i32, ptr %l63, !tbaa !23
  %t46 = ashr i32 %t45, 16
  %t48 = icmp eq i32 %t46, 1
  store i1 %t48, ptr %l65, !tbaa !21
  %t49 = load i32, ptr %l63, !tbaa !23
  %t50 = ashr i32 %t49, 16
  %t52 = icmp eq i32 %t50, 1
  br i1 %t52, label %bb12, label %bb13
bb12:
  call void @__olang_errpay_pop()
  br label %bb13
bb13:
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t54 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t55 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t58 = extractvalue { i64, ptr } %t54, 1
  %t59 = extractvalue { i64, ptr } %t54, 0
  %t60 = add i64 %t56, %t59
  %t61 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t62 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t63 = add i64 %t60, %t62
  %t64 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t63)
  call void @olang_textcopy(ptr %t64, ptr %t55, i64 %t56)
  %t65 = getelementptr i8, ptr %t64, i64 %t56
  call void @olang_textcopy(ptr %t65, ptr %t58, i64 %t59)
  %t66 = getelementptr i8, ptr %t65, i64 %t59
  call void @olang_textcopy(ptr %t66, ptr %t61, i64 %t62)
  %t67 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t64, 1
  %t71 = extractvalue { i64, ptr } %t68, 0
  %t72 = extractvalue { i64, ptr } %t68, 1
  %t73 = mul i64 %t71, 1
  %t74 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t73)
  call void @llvm.memcpy.p0.p0.i64(ptr %t74, ptr %t72, i64 %t73, i1 false)
  %t75 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s3, ptr %l4, { i64, ptr } %t76)
  br label %bb15
bb15:
  %t80 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l4)
  store i32 %t80, ptr %l74
  %t81 = icmp ne i32 %t80, 0
  br i1 %t81, label %bb17, label %ok.82, !prof !99
ok.82:
  br label %bb16
bb16:
  br label %bb21
bb17:
  %t83 = load i32, ptr %l74, !tbaa !23
  %t84 = ashr i32 %t83, 16
  %t86 = icmp eq i32 %t84, 1
  store i1 %t86, ptr %l76, !tbaa !21
  %t87 = load i32, ptr %l74, !tbaa !23
  %t88 = ashr i32 %t87, 16
  %t90 = icmp eq i32 %t88, 1
  br i1 %t90, label %bb18, label %bb19
bb18:
  call void @__olang_errpay_pop()
  br label %bb19
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb22:
  %t93 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t93, 1
  %t97 = extractvalue { i64, ptr } %t93, 0
  %t98 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t97)
  call void @olang_textcopy(ptr %t98, ptr %t96, i64 %t97)
  %t99 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = extractvalue { i64, ptr } %t100, 1
  %t104 = mul i64 %t102, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t104)
  call void @llvm.memcpy.p0.p0.i64(ptr %t105, ptr %t103, i64 %t104, i1 false)
  %t106 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } %t107)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb24:
  %t110 = load i64, ptr %l9, !tbaa !24
  %t112 = add i64 %t110, 1
  store i64 %t112, ptr %l9, !tbaa !24
  br label %bb6
bb25:
  %t114 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t116 = call { i64, ptr } @compiler_2ffix_2eToolsDir(ptr %v1, ptr %s0, { i64, ptr } %t114)
  store { i64, ptr } %t116, ptr %l87
  br label %bb26
bb26:
  %t117 = load { i64, ptr }, ptr %l87, !tbaa !27
  store { i64, ptr } %t117, ptr %l13, !tbaa !27
  %t118 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t120 = call i1 @std_2fos_2eIsDir(ptr %s0, { i64, ptr } %t118)
  store i1 %t120, ptr %l89
  br label %bb27
bb27:
  %t121 = load i1, ptr %l89, !tbaa !21
  %t122 = xor i1 %t121, true
  br i1 %t122, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s8
  %t124 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t125 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t126 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t128 = extractvalue { i64, ptr } %t124, 1
  %t129 = extractvalue { i64, ptr } %t124, 0
  %t130 = add i64 %t126, %t129
  %t131 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t132 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t133 = add i64 %t130, %t132
  %t134 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t133)
  call void @olang_textcopy(ptr %t134, ptr %t125, i64 %t126)
  %t135 = getelementptr i8, ptr %t134, i64 %t126
  call void @olang_textcopy(ptr %t135, ptr %t128, i64 %t129)
  %t136 = getelementptr i8, ptr %t135, i64 %t129
  call void @olang_textcopy(ptr %t136, ptr %t131, i64 %t132)
  %t137 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t134, 1
  %t141 = extractvalue { i64, ptr } %t138, 0
  %t142 = extractvalue { i64, ptr } %t138, 1
  %t143 = mul i64 %t141, 1
  %t144 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t143)
  call void @llvm.memcpy.p0.p0.i64(ptr %t144, ptr %t142, i64 %t143, i1 false)
  %t145 = insertvalue { i64, ptr } undef, i64 %t141, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t144, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s8, ptr %l4, { i64, ptr } %t146)
  br label %bb30
bb29:
  br label %bb37
bb30:
  %t150 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l4)
  store i32 %t150, ptr %l97
  %t151 = icmp ne i32 %t150, 0
  br i1 %t151, label %bb32, label %ok.152, !prof !99
ok.152:
  br label %bb31
bb31:
  br label %bb36
bb32:
  %t153 = load i32, ptr %l97, !tbaa !23
  %t154 = ashr i32 %t153, 16
  %t156 = icmp eq i32 %t154, 1
  store i1 %t156, ptr %l99, !tbaa !21
  %t157 = load i32, ptr %l97, !tbaa !23
  %t158 = ashr i32 %t157, 16
  %t160 = icmp eq i32 %t158, 1
  br i1 %t160, label %bb33, label %bb34
bb33:
  call void @__olang_errpay_pop()
  br label %bb34
bb34:
  br label %bb35
bb35:
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb37:
  %t163 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t164 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t167 = call { i64, ptr } @compiler_2ffix_2eBinDir(ptr %v1, ptr %s0, ptr %s0, { i64, ptr } %t163, { i64, ptr } %t164)
  store { i64, ptr } %t167, ptr %l105
  br label %bb38
bb38:
  %t168 = load { i64, ptr }, ptr %l105, !tbaa !27
  store { i64, ptr } %t168, ptr %l14, !tbaa !27
  %t169 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t171 = call i32 @std_2fos_2eMkDirAll(ptr %s0, { i64, ptr } %t169)
  store i32 %t171, ptr %l107
  %t172 = icmp ne i32 %t171, 0
  br i1 %t172, label %bb40, label %ok.173, !prof !99
ok.173:
  br label %bb39
bb39:
  br label %bb51
bb40:
  %t174 = load i32, ptr %l107, !tbaa !23
  %t175 = ashr i32 %t174, 16
  %t177 = icmp eq i32 %t175, 1
  store i1 %t177, ptr %l109, !tbaa !21
  %t178 = load i32, ptr %l107, !tbaa !23
  %t179 = ashr i32 %t178, 16
  %t181 = icmp eq i32 %t179, 1
  br i1 %t181, label %bb41, label %bb42
bb41:
  call void @__olang_errpay_pop()
  br label %bb42
bb42:
  br label %bb43
bb43:
  store %olang.scope zeroinitializer, ptr %s11
  %t183 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t184 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t185 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t187 = extractvalue { i64, ptr } %t183, 1
  %t188 = extractvalue { i64, ptr } %t183, 0
  %t189 = add i64 %t185, %t188
  %t190 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t191 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t192 = add i64 %t189, %t191
  %t193 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t192)
  call void @olang_textcopy(ptr %t193, ptr %t184, i64 %t185)
  %t194 = getelementptr i8, ptr %t193, i64 %t185
  call void @olang_textcopy(ptr %t194, ptr %t187, i64 %t188)
  %t195 = getelementptr i8, ptr %t194, i64 %t188
  call void @olang_textcopy(ptr %t195, ptr %t190, i64 %t191)
  %t196 = insertvalue { i64, ptr } undef, i64 %t192, 0
  %t197 = insertvalue { i64, ptr } %t196, ptr %t193, 1
  %t200 = extractvalue { i64, ptr } %t197, 0
  %t201 = extractvalue { i64, ptr } %t197, 1
  %t202 = mul i64 %t200, 1
  %t203 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t202)
  call void @llvm.memcpy.p0.p0.i64(ptr %t203, ptr %t201, i64 %t202, i1 false)
  %t204 = insertvalue { i64, ptr } undef, i64 %t200, 0
  %t205 = insertvalue { i64, ptr } %t204, ptr %t203, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s11, ptr %l4, { i64, ptr } %t205)
  br label %bb44
bb44:
  %t209 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l4)
  store i32 %t209, ptr %l118
  %t210 = icmp ne i32 %t209, 0
  br i1 %t210, label %bb46, label %ok.211, !prof !99
ok.211:
  br label %bb45
bb45:
  br label %bb50
bb46:
  %t212 = load i32, ptr %l118, !tbaa !23
  %t213 = ashr i32 %t212, 16
  %t215 = icmp eq i32 %t213, 1
  store i1 %t215, ptr %l120, !tbaa !21
  %t216 = load i32, ptr %l118, !tbaa !23
  %t217 = ashr i32 %t216, 16
  %t219 = icmp eq i32 %t217, 1
  br i1 %t219, label %bb47, label %bb48
bb47:
  call void @__olang_errpay_pop()
  br label %bb48
bb48:
  br label %bb49
bb49:
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb51:
  store i32 0, ptr %l15, !tbaa !23
  store i64 0, ptr %l16, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s14
  %t222 = call { i64, ptr } @compiler_2ffix_2eOrder(ptr %s14)
  store { i64, ptr } %t222, ptr %l124
  br label %bb52
bb52:
  %t223 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t224 = extractvalue { i64, ptr } %t223, 0
  %t225 = extractvalue { i64, ptr } %t223, 1
  %t226 = mul i64 %t224, 8
  %t227 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t226)
  call void @llvm.memcpy.p0.p0.i64(ptr %t227, ptr %t225, i64 %t226, i1 false)
  %t228 = insertvalue { i64, ptr } undef, i64 %t224, 0
  %t229 = insertvalue { i64, ptr } %t228, ptr %t227, 1
  store { i64, ptr } %t229, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t231 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t233 = extractvalue { i64, ptr } %t231, 0
  store i64 %t233, ptr %l19, !tbaa !24
  br label %bb53
bb53:
  store %olang.scope zeroinitializer, ptr %s15
  %t235 = load i64, ptr %l18, !tbaa !24
  %t236 = load i64, ptr %l19, !tbaa !24
  %t239 = icmp slt i64 %t235, %t236
  %t241 = xor i1 %t239, true
  br i1 %t241, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s15)
  br label %bb109
bb55:
  br label %bb56
bb56:
  %t243 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t243, ptr %l132, !tbaa !27
  %t244 = load i64, ptr %l18, !tbaa !24
  %t246 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t247 = load ptr, ptr %t246, !tbaa !27
  %t248 = getelementptr i64, ptr %t247, i64 %t244
  %t249 = load i64, ptr %t248, !tbaa !34
  store i64 %t249, ptr %l20, !tbaa !24
  %t251 = load i64, ptr %l20, !tbaa !24
  %t253 = getelementptr [33 x { i64, ptr }], ptr @G_2ecompiler_2ffix_2eToolNames, i64 0, i64 %t251
  %t254 = load { i64, ptr }, ptr %t253, !tbaa !37
  store { i64, ptr } %t254, ptr %l21, !tbaa !27
  %t256 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t257 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t258 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t259 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t260 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t261 = load ptr, ptr @__olang_prog_scope
  %t268 = call i32 @compiler_2ffix_2eensureBuilt(ptr %v1, ptr %s0, ptr %s0, ptr %t261, ptr %v2, ptr %s0, { i64, ptr } %t256, { i64, ptr } %t257, { i64, ptr } %t258, { i64, ptr } %t259, { i64, ptr } %t260, ptr %l4)
  store i32 %t268, ptr %l143
  %t269 = icmp ne i32 %t268, 0
  br i1 %t269, label %bb58, label %ok.270, !prof !99
ok.270:
  br label %bb57
bb57:
  br label %bb60
bb58:
  %t271 = load i32, ptr %l143, !tbaa !23
  %t272 = ashr i32 %t271, 16
  %t274 = icmp eq i32 %t272, 1
  store i1 %t274, ptr %l145, !tbaa !21
  br label %bb59
bb59:
  store i32 2, ptr %l15, !tbaa !23
  call void @__olang_scope_close(ptr %s15)
  br label %bb109
bb60:
  %t275 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t276 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t277 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t278 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t280 = extractvalue { i64, ptr } %t276, 1
  %t281 = extractvalue { i64, ptr } %t276, 0
  %t282 = add i64 %t278, %t281
  %t283 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t282)
  call void @olang_textcopy(ptr %t283, ptr %t277, i64 %t278)
  %t284 = getelementptr i8, ptr %t283, i64 %t278
  call void @olang_textcopy(ptr %t284, ptr %t280, i64 %t281)
  %t285 = insertvalue { i64, ptr } undef, i64 %t282, 0
  %t286 = insertvalue { i64, ptr } %t285, ptr %t283, 1
  %t288 = extractvalue { i64, ptr } %t286, 0
  %t289 = extractvalue { i64, ptr } %t286, 1
  %t290 = mul i64 %t288, 1
  %t291 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t290)
  call void @llvm.memcpy.p0.p0.i64(ptr %t291, ptr %t289, i64 %t290, i1 false)
  %t292 = insertvalue { i64, ptr } undef, i64 %t288, 0
  %t293 = insertvalue { i64, ptr } %t292, ptr %t291, 1
  %t295 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t275, 0
  %t297 = insertvalue [2 x { i64, ptr }] %t295, { i64, ptr } %t293, 1
  store [2 x { i64, ptr }] %t297, ptr %l22
  %t300 = insertvalue { i64, ptr } undef, i64 2, 0
  %t301 = insertvalue { i64, ptr } %t300, ptr %l22, 1
  %t303 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s15, ptr %s15, { i64, ptr } %t301)
  store { i64, ptr } %t303, ptr %l153
  br label %bb61
bb61:
  %t304 = load { i64, ptr }, ptr %l153, !tbaa !27
  store { i64, ptr } %t304, ptr %l23, !tbaa !27
  store i64 0, ptr %l24, !tbaa !24
  %t305 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t307 = extractvalue { i64, ptr } %t305, 0
  store i64 %t307, ptr %l25, !tbaa !24
  %t309 = load i64, ptr @G_2ecompiler_2ffix_2eBatch, !tbaa !24
  store i64 %t309, ptr %l26, !tbaa !24
  %t311 = load i64, ptr %l25, !tbaa !24
  %t312 = load i64, ptr %l24, !tbaa !24
  %t315 = icmp sgt i64 %t311, %t312
  br i1 %t315, label %bb62, label %bb63
bb62:
  %t317 = load i64, ptr %l26, !tbaa !24
  %t319 = icmp sgt i64 %t317, 0
  br i1 %t319, label %bb64, label %bb65
bb63:
  store i64 0, ptr %l160, !tbaa !24
  br label %bb67
bb64:
  %t321 = load i64, ptr %l25, !tbaa !24
  %t322 = load i64, ptr %l24, !tbaa !24
  %t325 = sub i64 %t321, %t322
  %t326 = load i64, ptr %l26, !tbaa !24
  %t329 = add i64 %t325, %t326
  %t331 = sub i64 %t329, 1
  %t332 = load i64, ptr %l26, !tbaa !24
  %t335 = sdiv i64 %t331, %t332
  store i64 %t335, ptr %l163, !tbaa !24
  br label %bb66
bb65:
  store i64 0, ptr %l163, !tbaa !24
  br label %bb66
bb66:
  %t337 = load i64, ptr %l163, !tbaa !24
  store i64 %t337, ptr %l160, !tbaa !24
  br label %bb67
bb67:
  %t338 = load i64, ptr %l160, !tbaa !24
  store i64 %t338, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb68
bb68:
  store %olang.scope zeroinitializer, ptr %s19
  %t339 = load i64, ptr %l28, !tbaa !24
  %t340 = load i64, ptr %l27, !tbaa !24
  %t343 = icmp slt i64 %t339, %t340
  %t345 = xor i1 %t343, true
  br i1 %t345, label %bb69, label %bb70
bb69:
  call void @__olang_scope_close(ptr %s19)
  br label %bb104
bb70:
  br label %bb71
bb71:
  %t347 = load i64, ptr %l24, !tbaa !24
  %t348 = load i64, ptr %l28, !tbaa !24
  %t349 = load i64, ptr %l26, !tbaa !24
  %t352 = mul i64 %t348, %t349
  %t355 = add i64 %t347, %t352
  store i64 %t355, ptr %l29, !tbaa !24
  %t357 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t357, ptr %l181, !tbaa !27
  %t358 = load i64, ptr %l29, !tbaa !24
  store i64 %t358, ptr %l182, !tbaa !24
  %t359 = load i64, ptr %l29, !tbaa !24
  %t360 = load i64, ptr @G_2ecompiler_2ffix_2eBatch, !tbaa !24
  %t363 = add i64 %t359, %t360
  %t364 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t366 = extractvalue { i64, ptr } %t364, 0
  %t369 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t363, i64 %t366)
  store i64 %t369, ptr %l188
  br label %bb72
bb72:
  %t370 = load { i64, ptr }, ptr %l181, !tbaa !27
  %t371 = extractvalue { i64, ptr } %t370, 0
  store i64 %t371, ptr %l189, !tbaa !24
  %t372 = load i64, ptr %l182, !tbaa !24
  %t373 = icmp sge i64 %t372, 0
  br i1 %t373, label %bb73, label %bb74
bb73:
  %t375 = load i64, ptr %l182, !tbaa !24
  %t376 = load i64, ptr %l188, !tbaa !24
  %t377 = icmp sle i64 %t375, %t376
  br i1 %t377, label %bb75, label %bb76
bb74:
  call void @__olang_check_failed(ptr @olang_loc_299e69389bcee8f2_b185402659ea7d46)
  unreachable
bb75:
  %t379 = load i64, ptr %l188, !tbaa !24
  %t380 = load i64, ptr %l189, !tbaa !24
  %t381 = icmp sle i64 %t379, %t380
  br i1 %t381, label %bb77, label %bb78
bb76:
  call void @__olang_check_failed(ptr @olang_loc_299e69389bcee8f2_b185402659ea7d46)
  unreachable
bb77:
  %t383 = getelementptr { i64, ptr }, ptr %l181, i32 0, i32 1
  %t384 = load ptr, ptr %t383, !tbaa !27
  %t385 = load i64, ptr %l182, !tbaa !24
  %t386 = load i64, ptr %l188, !tbaa !24
  %t387 = getelementptr { i64, ptr }, ptr %t384, i64 %t385
  %t388 = sub i64 %t386, %t385
  %t389 = insertvalue { i64, ptr } undef, i64 %t388, 0
  %t390 = insertvalue { i64, ptr } %t389, ptr %t387, 1
  %t392 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t393 = load i64, ptr %l20, !tbaa !24
  %t395 = getelementptr [33 x i64], ptr @G_2ecompiler_2ffix_2eToolKinds, i64 0, i64 %t393
  %t396 = load i64, ptr %t395, !tbaa !34
  %t397 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t398 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t405 = call { i64, ptr } @compiler_2ffix_2earguments(ptr %s15, ptr %v1, ptr %v2, ptr %s0, ptr %s19, { i64, ptr } %t392, i64 %t396, { i64, ptr } %t397, { i64, ptr } %t398, { i64, ptr } %t390)
  store { i64, ptr } %t405, ptr %l201
  br label %bb79
bb78:
  call void @__olang_check_failed(ptr @olang_loc_299e69389bcee8f2_b185402659ea7d46)
  unreachable
bb79:
  %t406 = load { i64, ptr }, ptr %l201, !tbaa !27
  %t407 = extractvalue { i64, ptr } %t406, 0
  %t408 = extractvalue { i64, ptr } %t406, 1
  %t409 = mul i64 %t407, 16
  %t410 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t409)
  call void @llvm.memcpy.p0.p0.i64(ptr %t410, ptr %t408, i64 %t409, i1 false)
  %t411 = insertvalue { i64, ptr } undef, i64 %t407, 0
  %t412 = insertvalue { i64, ptr } %t411, ptr %t410, 1
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l203, !tbaa !27
  %t414 = load { i64, ptr }, ptr %l203, !tbaa !27
  %t415 = call { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %s19, ptr %s19, ptr %s19, ptr %s19, { i64, ptr } %t412, { i64, ptr } %t414, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d9, i32 0, i32 1) })
  %t416 = extractvalue { i32, %"std/os:Output" } %t415, 1
  %t417 = extractvalue { i32, %"std/os:Output" } %t415, 0
  store i32 %t417, ptr %l205
  %t418 = icmp ne i32 %t417, 0
  br i1 %t418, label %bb81, label %ok.419, !prof !99
ok.419:
  store %"std/os:Output" %t416, ptr %l204
  br label %bb80
bb80:
  %t420 = load %"std/os:Output", ptr %l204
  store %"std/os:Output" %t420, ptr %l194
  br label %bb86
bb81:
  %t421 = load i32, ptr %l205, !tbaa !23
  %t422 = ashr i32 %t421, 16
  %t424 = icmp eq i32 %t422, 1
  store i1 %t424, ptr %l207, !tbaa !21
  %t425 = load i32, ptr %l205, !tbaa !23
  %t426 = ashr i32 %t425, 16
  %t428 = icmp eq i32 %t426, 1
  br i1 %t428, label %bb82, label %bb83
bb82:
  call void @__olang_errpay_pop()
  br label %bb83
bb83:
  br label %bb84
bb84:
  store %olang.scope zeroinitializer, ptr %s20
  %t430 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t431 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t432 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t434 = extractvalue { i64, ptr } %t430, 1
  %t435 = extractvalue { i64, ptr } %t430, 0
  %t436 = add i64 %t432, %t435
  %t437 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t438 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t439 = add i64 %t436, %t438
  %t440 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t439)
  call void @olang_textcopy(ptr %t440, ptr %t431, i64 %t432)
  %t441 = getelementptr i8, ptr %t440, i64 %t432
  call void @olang_textcopy(ptr %t441, ptr %t434, i64 %t435)
  %t442 = getelementptr i8, ptr %t441, i64 %t435
  call void @olang_textcopy(ptr %t442, ptr %t437, i64 %t438)
  %t443 = insertvalue { i64, ptr } undef, i64 %t439, 0
  %t444 = insertvalue { i64, ptr } %t443, ptr %t440, 1
  %t447 = extractvalue { i64, ptr } %t444, 0
  %t448 = extractvalue { i64, ptr } %t444, 1
  %t449 = mul i64 %t447, 1
  %t450 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t449)
  call void @llvm.memcpy.p0.p0.i64(ptr %t450, ptr %t448, i64 %t449, i1 false)
  %t451 = insertvalue { i64, ptr } undef, i64 %t447, 0
  %t452 = insertvalue { i64, ptr } %t451, ptr %t450, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s20, ptr %l4, { i64, ptr } %t452)
  br label %bb85
bb85:
  store i32 2, ptr %l15, !tbaa !23
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s19)
  br label %bb104
bb86:
  %t455 = load %"std/os:Output", ptr %l194
  store %"std/os:Output" %t455, ptr %l31
  %t456 = getelementptr %"std/os:Output", ptr %l31, i32 0, i32 1
  %t457 = load { i64, ptr }, ptr %t456, !tbaa !27
  %t458 = getelementptr %"std/os:Output", ptr %l31, i32 0, i32 2
  %t459 = load { i64, ptr }, ptr %t458, !tbaa !27
  %t461 = extractvalue { i64, ptr } %t457, 1
  %t462 = extractvalue { i64, ptr } %t457, 0
  %t464 = extractvalue { i64, ptr } %t459, 1
  %t465 = extractvalue { i64, ptr } %t459, 0
  %t466 = add i64 %t462, %t465
  %t467 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t466)
  call void @olang_textcopy(ptr %t467, ptr %t461, i64 %t462)
  %t468 = getelementptr i8, ptr %t467, i64 %t462
  call void @olang_textcopy(ptr %t468, ptr %t464, i64 %t465)
  %t469 = insertvalue { i64, ptr } undef, i64 %t466, 0
  %t470 = insertvalue { i64, ptr } %t469, ptr %t467, 1
  store { i64, ptr } %t470, ptr %l32, !tbaa !27
  %t472 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t474 = call i64 @compiler_2ffix_2ebyHand(ptr %s19, { i64, ptr } %t472)
  store i64 %t474, ptr %l219
  br label %bb87
bb87:
  %t475 = load i64, ptr %l219, !tbaa !24
  store i64 %t475, ptr %l33, !tbaa !24
  %t476 = getelementptr %"std/os:Output", ptr %l31, i32 0, i32 0
  %t477 = load i32, ptr %t476, !tbaa !23
  %t479 = icmp sgt i32 %t477, 1
  br i1 %t479, label %bb88, label %bb89
bb88:
  store i1 true, ptr %l222, !tbaa !21
  br label %bb90
bb89:
  %t481 = load i64, ptr %l33, !tbaa !24
  %t483 = icmp sgt i64 %t481, 0
  store i1 %t483, ptr %l222, !tbaa !21
  br label %bb90
bb90:
  %t485 = load i1, ptr %l222, !tbaa !21
  br i1 %t485, label %bb91, label %bb92
bb91:
  store %olang.scope zeroinitializer, ptr %s23
  %t486 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t487 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t489 = extractvalue { i64, ptr } %t486, 1
  %t490 = extractvalue { i64, ptr } %t486, 0
  %t491 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t492 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t493 = add i64 %t490, %t492
  %t495 = extractvalue { i64, ptr } %t487, 1
  %t496 = extractvalue { i64, ptr } %t487, 0
  %t497 = add i64 %t493, %t496
  %t498 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t497)
  call void @olang_textcopy(ptr %t498, ptr %t489, i64 %t490)
  %t499 = getelementptr i8, ptr %t498, i64 %t490
  call void @olang_textcopy(ptr %t499, ptr %t491, i64 %t492)
  %t500 = getelementptr i8, ptr %t499, i64 %t492
  call void @olang_textcopy(ptr %t500, ptr %t495, i64 %t496)
  %t501 = insertvalue { i64, ptr } undef, i64 %t497, 0
  %t502 = insertvalue { i64, ptr } %t501, ptr %t498, 1
  %t505 = extractvalue { i64, ptr } %t502, 0
  %t506 = extractvalue { i64, ptr } %t502, 1
  %t507 = mul i64 %t505, 1
  %t508 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t507)
  call void @llvm.memcpy.p0.p0.i64(ptr %t508, ptr %t506, i64 %t507, i1 false)
  %t509 = insertvalue { i64, ptr } undef, i64 %t505, 0
  %t510 = insertvalue { i64, ptr } %t509, ptr %t508, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s23, ptr %l4, { i64, ptr } %t510)
  br label %bb93
bb92:
  br label %bb99
bb93:
  %t513 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t515 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s19, ptr %s23, { i64, ptr } %t513, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i1 %t515, ptr %l232
  br label %bb94
bb94:
  %t516 = load i1, ptr %l232, !tbaa !21
  %t517 = xor i1 %t516, true
  br i1 %t517, label %bb95, label %bb96
bb95:
  store %olang.scope zeroinitializer, ptr %s25
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, ptr %l235, !tbaa !27
  %t520 = load { i64, ptr }, ptr %l235, !tbaa !27
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s25, ptr %l4, { i64, ptr } %t520)
  br label %bb97
bb96:
  br label %bb98
bb97:
  call void @__olang_scope_close(ptr %s25)
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s23)
  br label %bb99
bb99:
  %t521 = load i64, ptr %l16, !tbaa !24
  %t522 = load i64, ptr %l33, !tbaa !24
  %t525 = add i64 %t521, %t522
  store i64 %t525, ptr %l16, !tbaa !24
  %t527 = getelementptr %"std/os:Output", ptr %l31, i32 0, i32 0
  %t528 = load i32, ptr %t527, !tbaa !23
  %t530 = icmp sgt i32 %t528, 1
  br i1 %t530, label %bb100, label %bb101
bb100:
  store i32 2, ptr %l15, !tbaa !23
  br label %bb102
bb101:
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s19)
  br label %bb103
bb103:
  %t532 = load i64, ptr %l28, !tbaa !24
  %t534 = add i64 %t532, 1
  store i64 %t534, ptr %l28, !tbaa !24
  br label %bb68
bb104:
  %t536 = load i32, ptr %l15, !tbaa !23
  %t538 = icmp ne i32 %t536, 0
  br i1 %t538, label %bb105, label %bb106
bb105:
  call void @__olang_scope_close(ptr %s15)
  br label %bb109
bb106:
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s15)
  br label %bb108
bb108:
  %t540 = load i64, ptr %l18, !tbaa !24
  %t542 = add i64 %t540, 1
  store i64 %t542, ptr %l18, !tbaa !24
  br label %bb53
bb109:
  call void @__olang_scope_close(ptr %s14)
  store i64 0, ptr %l34, !tbaa !24
  store i64 0, ptr %l35, !tbaa !24
  %t544 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t546 = extractvalue { i64, ptr } %t544, 0
  store i64 %t546, ptr %l36, !tbaa !24
  store i64 1, ptr %l37, !tbaa !24
  %t548 = load i64, ptr %l36, !tbaa !24
  %t549 = load i64, ptr %l35, !tbaa !24
  %t552 = icmp sgt i64 %t548, %t549
  br i1 %t552, label %bb110, label %bb111
bb110:
  %t554 = load i64, ptr %l37, !tbaa !24
  %t556 = icmp sgt i64 %t554, 0
  br i1 %t556, label %bb112, label %bb113
bb111:
  store i64 0, ptr %l252, !tbaa !24
  br label %bb115
bb112:
  %t558 = load i64, ptr %l36, !tbaa !24
  %t559 = load i64, ptr %l35, !tbaa !24
  %t562 = sub i64 %t558, %t559
  %t563 = load i64, ptr %l37, !tbaa !24
  %t566 = add i64 %t562, %t563
  %t568 = sub i64 %t566, 1
  %t569 = load i64, ptr %l37, !tbaa !24
  %t572 = sdiv i64 %t568, %t569
  store i64 %t572, ptr %l255, !tbaa !24
  br label %bb114
bb113:
  store i64 0, ptr %l255, !tbaa !24
  br label %bb114
bb114:
  %t574 = load i64, ptr %l255, !tbaa !24
  store i64 %t574, ptr %l252, !tbaa !24
  br label %bb115
bb115:
  %t575 = load i64, ptr %l252, !tbaa !24
  store i64 %t575, ptr %l38, !tbaa !24
  store i64 0, ptr %l39, !tbaa !24
  br label %bb116
bb116:
  store %olang.scope zeroinitializer, ptr %s31
  %t576 = load i64, ptr %l39, !tbaa !24
  %t577 = load i64, ptr %l38, !tbaa !24
  %t580 = icmp slt i64 %t576, %t577
  %t582 = xor i1 %t580, true
  br i1 %t582, label %bb117, label %bb118
bb117:
  call void @__olang_scope_close(ptr %s31)
  br label %bb144
bb118:
  br label %bb119
bb119:
  %t584 = load i64, ptr %l35, !tbaa !24
  %t585 = load i64, ptr %l39, !tbaa !24
  %t586 = load i64, ptr %l37, !tbaa !24
  %t589 = mul i64 %t585, %t586
  %t592 = add i64 %t584, %t589
  store i64 %t592, ptr %l40, !tbaa !24
  %t594 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t594, ptr %l274, !tbaa !27
  %t595 = load i64, ptr %l40, !tbaa !24
  %t597 = getelementptr { i64, ptr }, ptr %l274, i32 0, i32 1
  %t598 = load ptr, ptr %t597, !tbaa !27
  %t599 = getelementptr { i64, ptr }, ptr %t598, i64 %t595
  %t600 = load { i64, ptr }, ptr %t599, !tbaa !37
  %t602 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s31, { i64, ptr } %t600)
  %t603 = extractvalue { i32, { i64, ptr } } %t602, 1
  %t604 = extractvalue { i32, { i64, ptr } } %t602, 0
  store i32 %t604, ptr %l278
  %t605 = icmp ne i32 %t604, 0
  br i1 %t605, label %bb121, label %ok.606, !prof !99
ok.606:
  store { i64, ptr } %t603, ptr %l277
  br label %bb120
bb120:
  %t607 = load { i64, ptr }, ptr %l277, !tbaa !27
  store { i64, ptr } %t607, ptr %l273, !tbaa !27
  br label %bb125
bb121:
  %t608 = load i32, ptr %l278, !tbaa !23
  %t609 = ashr i32 %t608, 16
  %t611 = icmp eq i32 %t609, 1
  store i1 %t611, ptr %l280, !tbaa !21
  %t612 = load i32, ptr %l278, !tbaa !23
  %t613 = ashr i32 %t612, 16
  %t615 = icmp eq i32 %t613, 1
  br i1 %t615, label %bb122, label %bb123
bb122:
  call void @__olang_errpay_pop()
  br label %bb123
bb123:
  br label %bb124
bb124:
  call void @__olang_scope_close(ptr %s31)
  br label %bb143
bb125:
  %t617 = load { i64, ptr }, ptr %l273, !tbaa !27
  store { i64, ptr } %t617, ptr %l283, !tbaa !27
  %t619 = load i64, ptr %l40, !tbaa !24
  %t622 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l7, i64 %t619)
  store { i64, ptr } %t622, ptr %l286
  br label %bb126
bb126:
  %t623 = load { i64, ptr }, ptr %l283, !tbaa !27
  %t624 = load { i64, ptr }, ptr %l286, !tbaa !27
  %t625 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s31, ptr %s0, { i64, ptr } %t623, { i64, ptr } %t624)
  store i1 %t625, ptr %l287
  br label %bb127
bb127:
  %t626 = load i1, ptr %l287, !tbaa !21
  br i1 %t626, label %bb128, label %bb129
bb128:
  call void @__olang_scope_close(ptr %s31)
  br label %bb143
bb129:
  br label %bb130
bb130:
  %t627 = load i64, ptr %l34, !tbaa !24
  %t629 = add i64 %t627, 1
  store i64 %t629, ptr %l34, !tbaa !24
  %t631 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t631, ptr %l291, !tbaa !27
  %t632 = load i64, ptr %l40, !tbaa !24
  %t634 = getelementptr { i64, ptr }, ptr %l291, i32 0, i32 1
  %t635 = load ptr, ptr %t634, !tbaa !27
  %t636 = getelementptr { i64, ptr }, ptr %t635, i64 %t632
  %t637 = load { i64, ptr }, ptr %t636, !tbaa !37
  %t639 = extractvalue { i64, ptr } %t637, 1
  %t640 = extractvalue { i64, ptr } %t637, 0
  %t641 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t642 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t643 = add i64 %t640, %t642
  %t644 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t643)
  call void @olang_textcopy(ptr %t644, ptr %t639, i64 %t640)
  %t645 = getelementptr i8, ptr %t644, i64 %t640
  call void @olang_textcopy(ptr %t645, ptr %t641, i64 %t642)
  %t646 = insertvalue { i64, ptr } undef, i64 %t643, 0
  %t647 = insertvalue { i64, ptr } %t646, ptr %t644, 1
  %t650 = extractvalue { i64, ptr } %t647, 0
  %t651 = extractvalue { i64, ptr } %t647, 1
  %t652 = mul i64 %t650, 1
  %t653 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t652)
  call void @llvm.memcpy.p0.p0.i64(ptr %t653, ptr %t651, i64 %t652, i1 false)
  %t654 = insertvalue { i64, ptr } undef, i64 %t650, 0
  %t655 = insertvalue { i64, ptr } %t654, ptr %t653, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s31, ptr %l5, { i64, ptr } %t655)
  br label %bb131
bb131:
  %t658 = load i1, ptr %l0, !tbaa !21
  br i1 %t658, label %bb132, label %bb133
bb132:
  store %olang.scope zeroinitializer, ptr %s35
  %t660 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t660, ptr %l298, !tbaa !27
  %t661 = load i64, ptr %l40, !tbaa !24
  %t663 = getelementptr { i64, ptr }, ptr %l298, i32 0, i32 1
  %t664 = load ptr, ptr %t663, !tbaa !27
  %t665 = getelementptr { i64, ptr }, ptr %t664, i64 %t661
  %t666 = load { i64, ptr }, ptr %t665, !tbaa !37
  store { i64, ptr } %t666, ptr %l300, !tbaa !27
  %t667 = load i64, ptr %l40, !tbaa !24
  %t670 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s35, ptr %l7, i64 %t667)
  store { i64, ptr } %t670, ptr %l303
  br label %bb134
bb133:
  br label %bb142
bb134:
  %t671 = load { i64, ptr }, ptr %l303, !tbaa !27
  %t672 = load { i64, ptr }, ptr %l300, !tbaa !27
  %t674 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s35, { i64, ptr } %t672, { i64, ptr } %t671)
  store i32 %t674, ptr %l305
  %t675 = icmp ne i32 %t674, 0
  br i1 %t675, label %bb136, label %ok.676, !prof !99
ok.676:
  br label %bb135
bb135:
  br label %bb141
bb136:
  %t677 = load i32, ptr %l305, !tbaa !23
  %t678 = ashr i32 %t677, 16
  %t680 = icmp eq i32 %t678, 1
  store i1 %t680, ptr %l307, !tbaa !21
  %t681 = load i32, ptr %l305, !tbaa !23
  %t682 = ashr i32 %t681, 16
  %t684 = icmp eq i32 %t682, 1
  br i1 %t684, label %bb137, label %bb138
bb137:
  call void @__olang_errpay_pop()
  br label %bb138
bb138:
  br label %bb139
bb139:
  store %olang.scope zeroinitializer, ptr %s36
  %t686 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t686, ptr %l311, !tbaa !27
  %t687 = load i64, ptr %l40, !tbaa !24
  %t689 = getelementptr { i64, ptr }, ptr %l311, i32 0, i32 1
  %t690 = load ptr, ptr %t689, !tbaa !27
  %t691 = getelementptr { i64, ptr }, ptr %t690, i64 %t687
  %t692 = load { i64, ptr }, ptr %t691, !tbaa !37
  %t693 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t694 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t696 = extractvalue { i64, ptr } %t692, 1
  %t697 = extractvalue { i64, ptr } %t692, 0
  %t698 = add i64 %t694, %t697
  %t699 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t700 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t701 = add i64 %t698, %t700
  %t702 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t701)
  call void @olang_textcopy(ptr %t702, ptr %t693, i64 %t694)
  %t703 = getelementptr i8, ptr %t702, i64 %t694
  call void @olang_textcopy(ptr %t703, ptr %t696, i64 %t697)
  %t704 = getelementptr i8, ptr %t703, i64 %t697
  call void @olang_textcopy(ptr %t704, ptr %t699, i64 %t700)
  %t705 = insertvalue { i64, ptr } undef, i64 %t701, 0
  %t706 = insertvalue { i64, ptr } %t705, ptr %t702, 1
  %t709 = extractvalue { i64, ptr } %t706, 0
  %t710 = extractvalue { i64, ptr } %t706, 1
  %t711 = mul i64 %t709, 1
  %t712 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t711)
  call void @llvm.memcpy.p0.p0.i64(ptr %t712, ptr %t710, i64 %t711, i1 false)
  %t713 = insertvalue { i64, ptr } undef, i64 %t709, 0
  %t714 = insertvalue { i64, ptr } %t713, ptr %t712, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s36, ptr %l4, { i64, ptr } %t714)
  br label %bb140
bb140:
  call void @__olang_scope_close(ptr %s36)
  br label %bb141
bb141:
  call void @__olang_scope_close(ptr %s35)
  br label %bb142
bb142:
  call void @__olang_scope_close(ptr %s31)
  br label %bb143
bb143:
  %t717 = load i64, ptr %l39, !tbaa !24
  %t719 = add i64 %t717, 1
  store i64 %t719, ptr %l39, !tbaa !24
  br label %bb116
bb144:
  %t721 = load i64, ptr %l16, !tbaa !24
  %t723 = icmp sgt i64 %t721, 0
  br i1 %t723, label %bb145, label %bb146
bb145:
  %t725 = load i32, ptr %l15, !tbaa !23
  %t727 = icmp eq i32 %t725, 0
  store i1 %t727, ptr %l321, !tbaa !21
  br label %bb147
bb146:
  store i1 false, ptr %l321, !tbaa !21
  br label %bb147
bb147:
  %t729 = load i1, ptr %l321, !tbaa !21
  br i1 %t729, label %bb148, label %bb149
bb148:
  store %olang.scope zeroinitializer, ptr %s39
  %t730 = load i64, ptr %l16, !tbaa !24
  %t732 = icmp eq i64 %t730, 1
  br i1 %t732, label %bb150, label %bb151
bb149:
  br label %bb154
bb150:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l326, !tbaa !27
  br label %bb152
bb151:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l326, !tbaa !27
  br label %bb152
bb152:
  %t734 = load { i64, ptr }, ptr %l326, !tbaa !27
  %t735 = load i64, ptr %l16, !tbaa !24
  %t737 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t738 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t740 = call i64 @__olang_fmt_i64(ptr null, i64 %t735)
  %t741 = add i64 %t738, %t740
  %t742 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t743 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t744 = add i64 %t741, %t743
  %t746 = extractvalue { i64, ptr } %t734, 1
  %t747 = extractvalue { i64, ptr } %t734, 0
  %t748 = add i64 %t744, %t747
  %t749 = extractvalue { i64, ptr } { i64 89, ptr getelementptr inbounds (<{ i64, [89 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t750 = extractvalue { i64, ptr } { i64 89, ptr getelementptr inbounds (<{ i64, [89 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t751 = add i64 %t748, %t750
  %t752 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t751)
  call void @olang_textcopy(ptr %t752, ptr %t737, i64 %t738)
  %t753 = getelementptr i8, ptr %t752, i64 %t738
  %t754 = call i64 @__olang_fmt_i64(ptr %t753, i64 %t735)
  %t755 = getelementptr i8, ptr %t753, i64 %t740
  call void @olang_textcopy(ptr %t755, ptr %t742, i64 %t743)
  %t756 = getelementptr i8, ptr %t755, i64 %t743
  call void @olang_textcopy(ptr %t756, ptr %t746, i64 %t747)
  %t757 = getelementptr i8, ptr %t756, i64 %t747
  call void @olang_textcopy(ptr %t757, ptr %t749, i64 %t750)
  %t758 = insertvalue { i64, ptr } undef, i64 %t751, 0
  %t759 = insertvalue { i64, ptr } %t758, ptr %t752, 1
  %t762 = extractvalue { i64, ptr } %t759, 0
  %t763 = extractvalue { i64, ptr } %t759, 1
  %t764 = mul i64 %t762, 1
  %t765 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t764)
  call void @llvm.memcpy.p0.p0.i64(ptr %t765, ptr %t763, i64 %t764, i1 false)
  %t766 = insertvalue { i64, ptr } undef, i64 %t762, 0
  %t767 = insertvalue { i64, ptr } %t766, ptr %t765, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s39, ptr %l4, { i64, ptr } %t767)
  br label %bb153
bb153:
  call void @__olang_scope_close(ptr %s39)
  br label %bb154
bb154:
  %t771 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l5)
  store i32 %t771, ptr %l334
  %t772 = icmp ne i32 %t771, 0
  br i1 %t772, label %bb156, label %ok.773, !prof !99
ok.773:
  br label %bb155
bb155:
  br label %bb160
bb156:
  %t774 = load i32, ptr %l334, !tbaa !23
  %t775 = ashr i32 %t774, 16
  %t777 = icmp eq i32 %t775, 1
  store i1 %t777, ptr %l336, !tbaa !21
  %t778 = load i32, ptr %l334, !tbaa !23
  %t779 = ashr i32 %t778, 16
  %t781 = icmp eq i32 %t779, 1
  br i1 %t781, label %bb157, label %bb158
bb157:
  call void @__olang_errpay_pop()
  br label %bb158
bb158:
  br label %bb159
bb159:
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb160:
  %t785 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l4)
  store i32 %t785, ptr %l341
  %t786 = icmp ne i32 %t785, 0
  br i1 %t786, label %bb162, label %ok.787, !prof !99
ok.787:
  br label %bb161
bb161:
  br label %bb166
bb162:
  %t788 = load i32, ptr %l341, !tbaa !23
  %t789 = ashr i32 %t788, 16
  %t791 = icmp eq i32 %t789, 1
  store i1 %t791, ptr %l343, !tbaa !21
  %t792 = load i32, ptr %l341, !tbaa !23
  %t793 = ashr i32 %t792, 16
  %t795 = icmp eq i32 %t793, 1
  br i1 %t795, label %bb163, label %bb164
bb163:
  call void @__olang_errpay_pop()
  br label %bb164
bb164:
  br label %bb165
bb165:
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb166:
  %t798 = load i32, ptr %l15, !tbaa !23
  %t800 = icmp ne i32 %t798, 0
  br i1 %t800, label %bb167, label %bb168
bb167:
  %t802 = load i32, ptr %l15, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t802, ptr %rv
  br label %ret
bb168:
  br label %bb169
bb169:
  %t804 = load i1, ptr %l0, !tbaa !21
  br i1 %t804, label %bb170, label %bb171
bb170:
  %t806 = load i64, ptr %l34, !tbaa !24
  %t808 = icmp sgt i64 %t806, 0
  store i1 %t808, ptr %l351, !tbaa !21
  br label %bb172
bb171:
  store i1 false, ptr %l351, !tbaa !21
  br label %bb172
bb172:
  %t810 = load i1, ptr %l351, !tbaa !21
  br i1 %t810, label %bb173, label %bb174
bb173:
  store i1 true, ptr %l354, !tbaa !21
  br label %bb175
bb174:
  %t811 = load i64, ptr %l16, !tbaa !24
  %t813 = icmp sgt i64 %t811, 0
  store i1 %t813, ptr %l354, !tbaa !21
  br label %bb175
bb175:
  %t815 = load i1, ptr %l354, !tbaa !21
  br i1 %t815, label %bb176, label %bb177
bb176:
  store i32 1, ptr %l357, !tbaa !23
  br label %bb178
bb177:
  store i32 0, ptr %l357, !tbaa !23
  br label %bb178
bb178:
  call void @__olang_scope_close(ptr %s0)
  %t816 = load i32, ptr %l357, !tbaa !23
  store i32 %t816, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ffix_2eOrder(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca [33 x { i64, ptr }]
  %l28 = alloca i64
  %l31 = alloca i64
  %l51 = alloca i1
  %l53 = alloca i1
  %l62 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l64 = alloca i64
  %l65 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l0
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t4 = insertvalue [2 x { i64, ptr }] %t3, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t6 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store [2 x { i64, ptr }] %t4, ptr %t6
  store ptr %t6, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t8 = load ptr, ptr %l1
  store i64 2, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l2, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  br label %bb25
bb4:
  br label %bb5
bb5:
  %t19 = load ptr, ptr %l1
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = getelementptr [2 x { i64, ptr }], ptr %t19, i64 0, i64 %t20
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !37
  store { i64, ptr } %t24, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l23, ptr @G_2ecompiler_2ffix_2eToolNames, i64 528, i1 false)
  %t26 = load [33 x { i64, ptr }], ptr %l23
  store i64 33, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t28 = load i64, ptr %l6, !tbaa !24
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = icmp sgt i64 %t28, %t29
  br i1 %t32, label %bb6, label %bb7
bb6:
  %t34 = load i64, ptr %l7, !tbaa !24
  %t36 = icmp sgt i64 %t34, 0
  br i1 %t36, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb11
bb8:
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = sub i64 %t38, %t39
  %t43 = load i64, ptr %l7, !tbaa !24
  %t46 = add i64 %t42, %t43
  %t48 = sub i64 %t46, 1
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = sdiv i64 %t48, %t49
  store i64 %t52, ptr %l31, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb10
bb10:
  %t54 = load i64, ptr %l31, !tbaa !24
  store i64 %t54, ptr %l28, !tbaa !24
  br label %bb11
bb11:
  %t55 = load i64, ptr %l28, !tbaa !24
  store i64 %t55, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t56 = load i64, ptr %l9, !tbaa !24
  %t57 = load i64, ptr %l8, !tbaa !24
  %t60 = icmp slt i64 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb14:
  br label %bb15
bb15:
  %t64 = load i64, ptr %l5, !tbaa !24
  %t65 = load i64, ptr %l9, !tbaa !24
  %t66 = load i64, ptr %l7, !tbaa !24
  %t69 = mul i64 %t65, %t66
  %t72 = add i64 %t64, %t69
  store i64 %t72, ptr %l10, !tbaa !24
  %t74 = load i64, ptr %l10, !tbaa !24
  %t76 = getelementptr [33 x i64], ptr @G_2ecompiler_2ffix_2eToolKinds, i64 0, i64 %t74
  %t77 = load i64, ptr %t76, !tbaa !34
  %t79 = call i1 @compiler_2ffix_2edriven(i64 %t77)
  store i1 %t79, ptr %l51
  br label %bb16
bb16:
  %t80 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t81 = load ptr, ptr @__olang_prog_scope
  %t83 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t81, ptr %s4, { i64, ptr } %t80, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d25, i32 0, i32 1) })
  store i1 %t83, ptr %l53
  br label %bb17
bb17:
  %t84 = load i1, ptr %l51, !tbaa !21
  %t85 = load i1, ptr %l53, !tbaa !21
  %t86 = icmp eq i1 %t84, %t85
  br i1 %t86, label %bb18, label %bb19
bb18:
  %t88 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l0, i64 %t88)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb22:
  %t91 = load i64, ptr %l9, !tbaa !24
  %t93 = add i64 %t91, 1
  store i64 %t93, ptr %l9, !tbaa !24
  br label %bb12
bb23:
  br label %bb24
bb24:
  %t95 = load i64, ptr %l2, !tbaa !24
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l2, !tbaa !24
  br label %bb2
bb25:
  call void @__olang_scope_close(ptr %s1)
  %t100 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %l0)
  store { i64, ptr } %t100, ptr %l62
  br label %bb26
bb26:
  %t101 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t101, ptr %l63, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 0
  store i64 %t103, ptr %l64, !tbaa !24
  %t104 = load i64, ptr %l64, !tbaa !24
  %t105 = mul i64 %t104, 8
  %t106 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t105)
  %t107 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  store { i64, ptr } %t108, ptr %l65, !tbaa !27
  %t109 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = load i64, ptr %l64, !tbaa !24
  %t114 = mul i64 %t113, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t110, ptr %t112, i64 %t114, i1 false)
  %t115 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t115, ptr %l63, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t116 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t116, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ffix_2eToolsDir(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l8 = alloca i1
  %l13 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d26, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l4
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  store { i64, ptr } %t2, ptr %l3
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  br label %bb6
bb2:
  %t7 = load i32, ptr %l4, !tbaa !23
  %t8 = ashr i32 %t7, 16
  %t10 = icmp eq i32 %t8, 1
  br i1 %t10, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %l2, !tbaa !27
  br label %bb6
bb6:
  %t12 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t12, ptr %l1, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t15 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t13, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d28, i32 0, i32 1) })
  store i1 %t15, ptr %l8
  br label %bb7
bb7:
  %t16 = load i1, ptr %l8, !tbaa !21
  %t17 = xor i1 %t16, true
  br i1 %t17, label %bb8, label %bb9
bb8:
  %t19 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = extractvalue { i64, ptr } %t19, 0
  %t23 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t21, i64 %t22)
  %t24 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t25, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t29 = call { i64, ptr } @std_2ffilepath_2eDir(ptr %v0, ptr %s0, { i64, ptr } %a0)
  store { i64, ptr } %t29, ptr %l13
  br label %bb11
bb11:
  %t30 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t30, 1
  %t32 = extractvalue { i64, ptr } %t30, 0
  %t33 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t35 = add i64 %t32, %t34
  %t36 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t35)
  call void @olang_textcopy(ptr %t36, ptr %t31, i64 %t32)
  %t37 = getelementptr i8, ptr %t36, i64 %t32
  call void @olang_textcopy(ptr %t37, ptr %t33, i64 %t34)
  %t38 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t36, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t39, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ffix_2earguments(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %lp5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 32, i64 8)
  store ptr %t2, ptr %lp5
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  %t4 = load ptr, ptr %lp5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load ptr, ptr %lp5
  %t8 = extractvalue { i64, ptr } %a0, 1
  %t9 = extractvalue { i64, ptr } %a0, 0
  %t10 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t9)
  call void @olang_textcopy(ptr %t10, ptr %t8, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t15 = extractvalue { i64, ptr } %t12, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t5, { i64, ptr } %t19)
  br label %bb2
bb2:
  %t22 = load i64, ptr %l1, !tbaa !24
  %t23 = load i64, ptr @G_2ecompiler_2ffix_2eStdTool, !tbaa !24
  %t26 = icmp eq i64 %t22, %t23
  br i1 %t26, label %bb3, label %bb4
bb3:
  %t28 = load ptr, ptr %lp5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t28, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d30, i32 0, i32 1) })
  br label %bb5
bb4:
  %t30 = load i64, ptr %l1, !tbaa !24
  %t31 = load i64, ptr @G_2ecompiler_2ffix_2eDrivenOpt, !tbaa !24
  %t34 = icmp eq i64 %t30, %t31
  br i1 %t34, label %bb7, label %bb8
bb5:
  %t36 = load ptr, ptr %lp5
  %t39 = extractvalue { i64, ptr } %a3, 1
  %t40 = extractvalue { i64, ptr } %a3, 0
  %t41 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t40)
  call void @olang_textcopy(ptr %t41, ptr %t39, i64 %t40)
  %t42 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t46 = extractvalue { i64, ptr } %t43, 1
  %t47 = mul i64 %t45, 1
  %t48 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t47)
  call void @llvm.memcpy.p0.p0.i64(ptr %t48, ptr %t46, i64 %t47, i1 false)
  %t49 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t36, { i64, ptr } %t50)
  br label %bb6
bb6:
  br label %bb16
bb7:
  %t53 = load ptr, ptr %lp5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t53, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d31, i32 0, i32 1) })
  br label %bb9
bb8:
  %t55 = load i64, ptr %l1, !tbaa !24
  %t56 = load i64, ptr @G_2ecompiler_2ffix_2eDrivenArg, !tbaa !24
  %t59 = icmp eq i64 %t55, %t56
  br i1 %t59, label %bb11, label %bb12
bb9:
  %t61 = load ptr, ptr %lp5
  %t62 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t62, 1
  %t65 = extractvalue { i64, ptr } %t62, 0
  %t66 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t65)
  call void @olang_textcopy(ptr %t66, ptr %t64, i64 %t65)
  %t67 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t71 = extractvalue { i64, ptr } %t68, 1
  %t72 = mul i64 %t70, 1
  %t73 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t72)
  call void @llvm.memcpy.p0.p0.i64(ptr %t73, ptr %t71, i64 %t72, i1 false)
  %t74 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t61, { i64, ptr } %t75)
  br label %bb10
bb10:
  br label %bb15
bb11:
  %t78 = load ptr, ptr %lp5
  %t79 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t79, 1
  %t82 = extractvalue { i64, ptr } %t79, 0
  %t83 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t82)
  call void @olang_textcopy(ptr %t83, ptr %t81, i64 %t82)
  %t84 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t83, 1
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t88 = extractvalue { i64, ptr } %t85, 1
  %t89 = mul i64 %t87, 1
  %t90 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t89)
  call void @llvm.memcpy.p0.p0.i64(ptr %t90, ptr %t88, i64 %t89, i1 false)
  %t91 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t90, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t78, { i64, ptr } %t92)
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  store { i64, ptr } %a4, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t97 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  store i64 %t99, ptr %l8, !tbaa !24
  br label %bb17
bb17:
  %t101 = load i64, ptr %l7, !tbaa !24
  %t102 = load i64, ptr %l8, !tbaa !24
  %t105 = icmp slt i64 %t101, %t102
  %t107 = xor i1 %t105, true
  br i1 %t107, label %bb18, label %bb19
bb18:
  br label %bb23
bb19:
  br label %bb20
bb20:
  %t109 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t109, ptr %l45, !tbaa !27
  %t110 = load i64, ptr %l7, !tbaa !24
  %t112 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr { i64, ptr }, ptr %t113, i64 %t110
  %t115 = load { i64, ptr }, ptr %t114, !tbaa !37
  %t117 = load ptr, ptr %lp5
  %t120 = extractvalue { i64, ptr } %t115, 1
  %t121 = extractvalue { i64, ptr } %t115, 0
  %t122 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t121)
  call void @olang_textcopy(ptr %t122, ptr %t120, i64 %t121)
  %t123 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  %t126 = extractvalue { i64, ptr } %t124, 0
  %t127 = extractvalue { i64, ptr } %t124, 1
  %t128 = mul i64 %t126, 1
  %t129 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t128)
  call void @llvm.memcpy.p0.p0.i64(ptr %t129, ptr %t127, i64 %t128, i1 false)
  %t130 = insertvalue { i64, ptr } undef, i64 %t126, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t129, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t117, { i64, ptr } %t131)
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t134 = load i64, ptr %l7, !tbaa !24
  %t136 = add i64 %t134, 1
  store i64 %t136, ptr %l7, !tbaa !24
  br label %bb17
bb23:
  %t138 = load ptr, ptr %lp5
  %t140 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v4, ptr %v4, ptr %t138)
  store { i64, ptr } %t140, ptr %l55
  br label %bb24
bb24:
  %t141 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t141, ptr %l56, !tbaa !27
  %t142 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t142, 0
  store i64 %t143, ptr %l57, !tbaa !24
  %t144 = load i64, ptr %l57, !tbaa !24
  %t145 = mul i64 %t144, 16
  %t146 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t145)
  %t147 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  store { i64, ptr } %t148, ptr %l58, !tbaa !27
  %t149 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = load i64, ptr %l57, !tbaa !24
  %t154 = mul i64 %t153, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t150, ptr %t152, i64 %t154, i1 false)
  %t155 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t155, ptr %l56, !tbaa !27
  %t156 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t156, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ffix_2ebuiltBy(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/os:FileInfo"
  %l2 = alloca %"std/os:FileInfo"
  %l4 = alloca %"std/os:FileInfo"
  %l5 = alloca i32
  %l7 = alloca i1
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %v0, { i64, ptr } %t1)
  %t4 = extractvalue { i32, %"std/os:FileInfo" } %t3, 1
  %t5 = extractvalue { i32, %"std/os:FileInfo" } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store %"std/os:FileInfo" %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load %"std/os:FileInfo", ptr %l4
  store %"std/os:FileInfo" %t8, ptr %l2
  br label %bb6
bb2:
  %t9 = load i32, ptr %l5, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  store i1 %t12, ptr %l7, !tbaa !21
  %t13 = load i32, ptr %l5, !tbaa !23
  %t14 = ashr i32 %t13, 16
  %t16 = icmp eq i32 %t14, 1
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  %t18 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 1
  %t21 = extractvalue { i64, ptr } %t18, 0
  %t22 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t21)
  call void @olang_textcopy(ptr %t22, ptr %t20, i64 %t21)
  %t23 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  store { i64, ptr } %t24, ptr %rv
  br label %ret
bb6:
  %t26 = load %"std/os:FileInfo", ptr %l2
  store %"std/os:FileInfo" %t26, ptr %l1
  %t27 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t28 = getelementptr %"std/os:FileInfo", ptr %l1, i32 0, i32 1
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = getelementptr %"std/os:FileInfo", ptr %l1, i32 0, i32 2
  %t31 = load i64, ptr %t30, !tbaa !24
  %t33 = extractvalue { i64, ptr } %t27, 1
  %t34 = extractvalue { i64, ptr } %t27, 0
  %t35 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t37 = add i64 %t34, %t36
  %t39 = call i64 @__olang_fmt_i64(ptr null, i64 %t29)
  %t40 = add i64 %t37, %t39
  %t41 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t42 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t43 = add i64 %t40, %t42
  %t45 = call i64 @__olang_fmt_i64(ptr null, i64 %t31)
  %t46 = add i64 %t43, %t45
  %t47 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t48 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t49 = add i64 %t46, %t48
  %t50 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t49)
  call void @olang_textcopy(ptr %t50, ptr %t33, i64 %t34)
  %t51 = getelementptr i8, ptr %t50, i64 %t34
  call void @olang_textcopy(ptr %t51, ptr %t35, i64 %t36)
  %t52 = getelementptr i8, ptr %t51, i64 %t36
  %t53 = call i64 @__olang_fmt_i64(ptr %t52, i64 %t29)
  %t54 = getelementptr i8, ptr %t52, i64 %t39
  call void @olang_textcopy(ptr %t54, ptr %t41, i64 %t42)
  %t55 = getelementptr i8, ptr %t54, i64 %t42
  %t56 = call i64 @__olang_fmt_i64(ptr %t55, i64 %t31)
  %t57 = getelementptr i8, ptr %t55, i64 %t45
  call void @olang_textcopy(ptr %t57, ptr %t47, i64 %t48)
  %t58 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t50, 1
  store { i64, ptr } %t59, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ffix_2ebyHand(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca %"std/prelude/text:LineIter"
  %l4 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/text:LineIter"
  %l7 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l12 = alloca i1
  %l14 = alloca i1
  %l18 = alloca i1
  %l20 = alloca i1
  %l22 = alloca i1
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  store i1 false, ptr %l2, !tbaa !21
  %t3 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store %"std/prelude/text:LineIter" %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load %"std/prelude/text:LineIter", ptr %l6
  store %"std/prelude/text:LineIter" %t4, ptr %l3
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t6 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v0, ptr %l3)
  %t7 = extractvalue { i32, { i64, ptr } } %t6, 1
  %t8 = extractvalue { i32, { i64, ptr } } %t6, 0
  store i32 %t8, ptr %l10
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb4, label %ok.10, !prof !99
ok.10:
  store { i64, ptr } %t7, ptr %l9
  br label %bb3
bb3:
  %t11 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t11, ptr %l7, !tbaa !27
  br label %bb6
bb4:
  %t12 = load i32, ptr %l10, !tbaa !23
  %t13 = ashr i32 %t12, 16
  %t15 = icmp eq i32 %t13, 1
  store i1 %t15, ptr %l12, !tbaa !21
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb6:
  %t16 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t16, ptr %l4, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t17, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d34, i32 0, i32 1) })
  store i1 %t19, ptr %l14
  br label %bb7
bb7:
  %t20 = load i1, ptr %l14, !tbaa !21
  br i1 %t20, label %bb8, label %bb9
bb8:
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = add i64 %t21, 1
  store i64 %t23, ptr %l1, !tbaa !24
  br label %bb21
bb9:
  store %olang.scope zeroinitializer, ptr %s4
  %t25 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t25, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store i1 %t27, ptr %l18
  br label %bb10
bb10:
  %t28 = load i1, ptr %l18, !tbaa !21
  br i1 %t28, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb20
bb12:
  store %olang.scope zeroinitializer, ptr %s6
  %t29 = load i1, ptr %l2, !tbaa !21
  br i1 %t29, label %bb13, label %bb14
bb13:
  %t31 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t33 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s6, { i64, ptr } %t31, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d36, i32 0, i32 1) })
  store i1 %t33, ptr %l22
  br label %bb15
bb14:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb16
bb15:
  %t34 = load i1, ptr %l22, !tbaa !21
  store i1 %t34, ptr %l20, !tbaa !21
  br label %bb16
bb16:
  %t35 = load i1, ptr %l20, !tbaa !21
  br i1 %t35, label %bb17, label %bb18
bb17:
  %t36 = load i64, ptr %l1, !tbaa !24
  %t38 = add i64 %t36, 1
  store i64 %t38, ptr %l1, !tbaa !24
  br label %bb19
bb18:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s6)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  br label %bb2
bb23:
  %t40 = load i64, ptr %l1, !tbaa !24
  store i64 %t40, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffix_2edriven(i64 %a0) #0 {
entry:
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i64, ptr @G_2ecompiler_2ffix_2eDrivenOpt, !tbaa !24
  %t5 = icmp sge i64 %a0, %t2
  store i1 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ffix_2eensureBuilt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, ptr %a5) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca [2 x { i64, ptr }]
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca [2 x { i64, ptr }]
  %l11 = alloca i64
  %l12 = alloca [2 x { i64, ptr }]
  %l13 = alloca i64
  %l14 = alloca [2 x { i64, ptr }]
  %l15 = alloca [5 x { i64, ptr }]
  %l16 = alloca %"std/os:Output"
  %l24 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i32
  %l34 = alloca i64
  %l39 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca i64
  %l44 = alloca i64
  %l49 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca i64
  %l54 = alloca i64
  %l55 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l59 = alloca i1
  %l60 = alloca i1
  %l62 = alloca i64
  %l66 = alloca i32
  %l68 = alloca i1
  %l71 = alloca %"std/os:Output"
  %l72 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l88 = alloca %"std/os:Output"
  %l89 = alloca i32
  %l91 = alloca i1
  %l110 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l115 = alloca i32
  %l117 = alloca i1
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t3 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %t2, 1
  %t7 = extractvalue { i64, ptr } %t2, 0
  %t8 = add i64 %t4, %t7
  %t9 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t8)
  call void @olang_textcopy(ptr %t9, ptr %t3, i64 %t4)
  %t10 = getelementptr i8, ptr %t9, i64 %t4
  call void @olang_textcopy(ptr %t10, ptr %t6, i64 %t7)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t9, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t15 = extractvalue { i64, ptr } %t12, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  %t21 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t1, 0
  %t23 = insertvalue [2 x { i64, ptr }] %t21, { i64, ptr } %t19, 1
  store [2 x { i64, ptr }] %t23, ptr %l6
  %t26 = insertvalue { i64, ptr } undef, i64 2, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %l6, 1
  %t29 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t27)
  store { i64, ptr } %t29, ptr %l24
  br label %bb1
bb1:
  %t30 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t30, ptr %l7, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 1
  %t34 = extractvalue { i64, ptr } %t31, 0
  %t35 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t37 = add i64 %t34, %t36
  %t38 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t37)
  call void @olang_textcopy(ptr %t38, ptr %t33, i64 %t34)
  %t39 = getelementptr i8, ptr %t38, i64 %t34
  call void @olang_textcopy(ptr %t39, ptr %t35, i64 %t36)
  %t40 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t38, 1
  store { i64, ptr } %t41, ptr %l8, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t45 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } %t43)
  %t46 = extractvalue { i32, { i64, ptr } } %t45, 1
  %t47 = extractvalue { i32, { i64, ptr } } %t45, 0
  store i32 %t47, ptr %l30
  %t48 = icmp ne i32 %t47, 0
  br i1 %t48, label %bb3, label %ok.49, !prof !99
ok.49:
  store { i64, ptr } %t46, ptr %l29
  br label %bb2
bb2:
  %t50 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t50, ptr %l27, !tbaa !27
  br label %bb7
bb3:
  %t51 = load i32, ptr %l30, !tbaa !23
  %t52 = ashr i32 %t51, 16
  %t54 = icmp eq i32 %t52, 1
  br i1 %t54, label %bb4, label %bb5
bb4:
  call void @__olang_errpay_pop()
  br label %bb5
bb5:
  br label %bb6
bb6:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d39, i32 0, i32 1) }, ptr %l27, !tbaa !27
  br label %bb7
bb7:
  %t56 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t56, ptr %l9, !tbaa !27
  %t57 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t59 = call i64 @compiler_2ffix_2enewest(ptr %v4, { i64, ptr } %t57)
  store i64 %t59, ptr %l34
  br label %bb8
bb8:
  %t60 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t62 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t60, 0
  %t63 = insertvalue [2 x { i64, ptr }] %t62, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  store [2 x { i64, ptr }] %t63, ptr %l10
  %t66 = insertvalue { i64, ptr } undef, i64 2, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %l10, 1
  %t69 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t67)
  store { i64, ptr } %t69, ptr %l39
  br label %bb9
bb9:
  %t70 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 0
  %t72 = extractvalue { i64, ptr } %t70, 1
  %t73 = mul i64 %t71, 1
  %t74 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t73)
  call void @llvm.memcpy.p0.p0.i64(ptr %t74, ptr %t72, i64 %t73, i1 false)
  %t75 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  %t78 = call i64 @compiler_2ffix_2enewest(ptr %s0, { i64, ptr } %t76)
  store i64 %t78, ptr %l41
  br label %bb10
bb10:
  %t79 = load i64, ptr %l34, !tbaa !24
  %t80 = load i64, ptr %l41, !tbaa !24
  %t81 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t79, i64 %t80)
  store i64 %t81, ptr %l42
  br label %bb11
bb11:
  %t82 = load i64, ptr %l42, !tbaa !24
  store i64 %t82, ptr %l11, !tbaa !24
  %t83 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t85 = call i64 @compiler_2ffix_2enewest(ptr %v1, { i64, ptr } %t83)
  store i64 %t85, ptr %l44
  br label %bb12
bb12:
  %t86 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t88 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t86, 0
  %t89 = insertvalue [2 x { i64, ptr }] %t88, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  store [2 x { i64, ptr }] %t89, ptr %l12
  %t92 = insertvalue { i64, ptr } undef, i64 2, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %l12, 1
  %t95 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t93)
  store { i64, ptr } %t95, ptr %l49
  br label %bb13
bb13:
  %t96 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 0
  %t98 = extractvalue { i64, ptr } %t96, 1
  %t99 = mul i64 %t97, 1
  %t100 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t99)
  call void @llvm.memcpy.p0.p0.i64(ptr %t100, ptr %t98, i64 %t99, i1 false)
  %t101 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t100, 1
  %t104 = call i64 @compiler_2ffix_2enewest(ptr %s0, { i64, ptr } %t102)
  store i64 %t104, ptr %l51
  br label %bb14
bb14:
  %t105 = load i64, ptr %l44, !tbaa !24
  %t106 = load i64, ptr %l51, !tbaa !24
  %t107 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t105, i64 %t106)
  store i64 %t107, ptr %l52
  br label %bb15
bb15:
  %t108 = load i64, ptr %l11, !tbaa !24
  %t109 = load i64, ptr %l52, !tbaa !24
  %t111 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t109, i64 %t108)
  store i64 %t111, ptr %l54
  br label %bb16
bb16:
  %t112 = load i64, ptr %l54, !tbaa !24
  store i64 %t112, ptr %l13, !tbaa !24
  %t113 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t113, ptr %l55, !tbaa !27
  %t114 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t116 = call { i64, ptr } @compiler_2ffix_2ebuiltBy(ptr %v0, ptr %s0, { i64, ptr } %t114)
  store { i64, ptr } %t116, ptr %l57
  br label %bb17
bb17:
  %t117 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t117, 0
  %t119 = extractvalue { i64, ptr } %t117, 1
  %t120 = mul i64 %t118, 1
  %t121 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t120)
  call void @llvm.memcpy.p0.p0.i64(ptr %t121, ptr %t119, i64 %t120, i1 false)
  %t122 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t121, 1
  %t124 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t126 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t124, { i64, ptr } %t123)
  store i1 %t126, ptr %l59
  br label %bb18
bb18:
  %t127 = load i1, ptr %l59, !tbaa !21
  br i1 %t127, label %bb19, label %bb20
bb19:
  %t128 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t130 = call i64 @compiler_2ffix_2emtime(ptr %s0, { i64, ptr } %t128)
  store i64 %t130, ptr %l62
  br label %bb21
bb20:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb22
bb21:
  %t131 = load i64, ptr %l13, !tbaa !24
  %t132 = load i64, ptr %l62, !tbaa !24
  %t134 = icmp sgt i64 %t132, %t131
  store i1 %t134, ptr %l60, !tbaa !21
  br label %bb22
bb22:
  %t136 = load i1, ptr %l60, !tbaa !21
  br i1 %t136, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t137 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t139 = call i32 @std_2fos_2eRemove(ptr %s0, { i64, ptr } %t137)
  store i32 %t139, ptr %l66
  %t140 = icmp ne i32 %t139, 0
  br i1 %t140, label %bb27, label %ok.141, !prof !99
ok.141:
  br label %bb26
bb26:
  br label %bb31
bb27:
  %t142 = load i32, ptr %l66, !tbaa !23
  %t143 = ashr i32 %t142, 16
  %t145 = icmp eq i32 %t143, 1
  store i1 %t145, ptr %l68, !tbaa !21
  %t146 = load i32, ptr %l66, !tbaa !23
  %t147 = ashr i32 %t146, 16
  %t149 = icmp eq i32 %t147, 1
  br i1 %t149, label %bb28, label %bb29
bb28:
  call void @__olang_errpay_pop()
  br label %bb29
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t151 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t151, ptr %l72, !tbaa !27
  %t152 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t152, ptr %l73, !tbaa !27
  %t153 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t154 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t154, 1
  %t157 = extractvalue { i64, ptr } %t154, 0
  %t158 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t159 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t160 = add i64 %t157, %t159
  %t161 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t160)
  call void @olang_textcopy(ptr %t161, ptr %t156, i64 %t157)
  %t162 = getelementptr i8, ptr %t161, i64 %t157
  call void @olang_textcopy(ptr %t162, ptr %t158, i64 %t159)
  %t163 = insertvalue { i64, ptr } undef, i64 %t160, 0
  %t164 = insertvalue { i64, ptr } %t163, ptr %t161, 1
  %t166 = extractvalue { i64, ptr } %t164, 0
  %t167 = extractvalue { i64, ptr } %t164, 1
  %t168 = mul i64 %t166, 1
  %t169 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t168)
  call void @llvm.memcpy.p0.p0.i64(ptr %t169, ptr %t167, i64 %t168, i1 false)
  %t170 = insertvalue { i64, ptr } undef, i64 %t166, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t169, 1
  %t173 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t153, 0
  %t175 = insertvalue [2 x { i64, ptr }] %t173, { i64, ptr } %t171, 1
  store [2 x { i64, ptr }] %t175, ptr %l14
  %t178 = insertvalue { i64, ptr } undef, i64 2, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %l14, 1
  %t181 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t179)
  store { i64, ptr } %t181, ptr %l81
  br label %bb32
bb32:
  %t182 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t182, 0
  %t184 = extractvalue { i64, ptr } %t182, 1
  %t185 = mul i64 %t183, 1
  %t186 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t185)
  call void @llvm.memcpy.p0.p0.i64(ptr %t186, ptr %t184, i64 %t185, i1 false)
  %t187 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t186, 1
  %t189 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t190 = insertvalue [5 x { i64, ptr }] undef, { i64, ptr } %t189, 0
  %t191 = insertvalue [5 x { i64, ptr }] %t190, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t192 = insertvalue [5 x { i64, ptr }] %t191, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d44, i32 0, i32 1) }, 2
  %t193 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t194 = insertvalue [5 x { i64, ptr }] %t192, { i64, ptr } %t193, 3
  %t196 = insertvalue [5 x { i64, ptr }] %t194, { i64, ptr } %t188, 4
  store [5 x { i64, ptr }] %t196, ptr %l15
  %t199 = insertvalue { i64, ptr } undef, i64 5, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr %l15, 1
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l86, !tbaa !27
  %t201 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t203 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t205 = call { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %s0, ptr %s0, ptr %v2, ptr %s0, { i64, ptr } %t200, { i64, ptr } %t203, i1 true, { i64, ptr } %t201)
  %t206 = extractvalue { i32, %"std/os:Output" } %t205, 1
  %t207 = extractvalue { i32, %"std/os:Output" } %t205, 0
  store i32 %t207, ptr %l89
  %t208 = icmp ne i32 %t207, 0
  br i1 %t208, label %bb34, label %ok.209, !prof !99
ok.209:
  store %"std/os:Output" %t206, ptr %l88
  br label %bb33
bb33:
  %t210 = load %"std/os:Output", ptr %l88
  store %"std/os:Output" %t210, ptr %l71
  br label %bb39
bb34:
  %t211 = load i32, ptr %l89, !tbaa !23
  %t212 = ashr i32 %t211, 16
  %t214 = icmp eq i32 %t212, 1
  store i1 %t214, ptr %l91, !tbaa !21
  %t215 = load i32, ptr %l89, !tbaa !23
  %t216 = ashr i32 %t215, 16
  %t218 = icmp eq i32 %t216, 1
  br i1 %t218, label %bb35, label %bb36
bb35:
  call void @__olang_errpay_pop()
  br label %bb36
bb36:
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s6
  %t220 = load ptr, ptr %l5, !tbaa !29
  %t221 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t222 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t223 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t225 = extractvalue { i64, ptr } %t221, 1
  %t226 = extractvalue { i64, ptr } %t221, 0
  %t227 = add i64 %t223, %t226
  %t228 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t229 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t230 = add i64 %t227, %t229
  %t231 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t230)
  call void @olang_textcopy(ptr %t231, ptr %t222, i64 %t223)
  %t232 = getelementptr i8, ptr %t231, i64 %t223
  call void @olang_textcopy(ptr %t232, ptr %t225, i64 %t226)
  %t233 = getelementptr i8, ptr %t232, i64 %t226
  call void @olang_textcopy(ptr %t233, ptr %t228, i64 %t229)
  %t234 = insertvalue { i64, ptr } undef, i64 %t230, 0
  %t235 = insertvalue { i64, ptr } %t234, ptr %t231, 1
  %t238 = extractvalue { i64, ptr } %t235, 0
  %t239 = extractvalue { i64, ptr } %t235, 1
  %t240 = mul i64 %t238, 1
  %t241 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t240)
  call void @llvm.memcpy.p0.p0.i64(ptr %t241, ptr %t239, i64 %t240, i1 false)
  %t242 = insertvalue { i64, ptr } undef, i64 %t238, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t241, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v5, ptr %s6, ptr %t220, { i64, ptr } %t243)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb39:
  %t247 = load %"std/os:Output", ptr %l71
  store %"std/os:Output" %t247, ptr %l16
  %t248 = getelementptr %"std/os:Output", ptr %l16, i32 0, i32 0
  %t249 = load i32, ptr %t248, !tbaa !23
  %t251 = icmp ne i32 %t249, 0
  br i1 %t251, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s8
  %t253 = load ptr, ptr %l5, !tbaa !29
  %t254 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t255 = getelementptr %"std/os:Output", ptr %l16, i32 0, i32 1
  %t256 = load { i64, ptr }, ptr %t255, !tbaa !27
  %t257 = getelementptr %"std/os:Output", ptr %l16, i32 0, i32 2
  %t258 = load { i64, ptr }, ptr %t257, !tbaa !27
  %t259 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t260 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  %t262 = extractvalue { i64, ptr } %t254, 1
  %t263 = extractvalue { i64, ptr } %t254, 0
  %t264 = add i64 %t260, %t263
  %t265 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t266 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  %t267 = add i64 %t264, %t266
  %t269 = extractvalue { i64, ptr } %t256, 1
  %t270 = extractvalue { i64, ptr } %t256, 0
  %t271 = add i64 %t267, %t270
  %t273 = extractvalue { i64, ptr } %t258, 1
  %t274 = extractvalue { i64, ptr } %t258, 0
  %t275 = add i64 %t271, %t274
  %t276 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t275)
  call void @olang_textcopy(ptr %t276, ptr %t259, i64 %t260)
  %t277 = getelementptr i8, ptr %t276, i64 %t260
  call void @olang_textcopy(ptr %t277, ptr %t262, i64 %t263)
  %t278 = getelementptr i8, ptr %t277, i64 %t263
  call void @olang_textcopy(ptr %t278, ptr %t265, i64 %t266)
  %t279 = getelementptr i8, ptr %t278, i64 %t266
  call void @olang_textcopy(ptr %t279, ptr %t269, i64 %t270)
  %t280 = getelementptr i8, ptr %t279, i64 %t270
  call void @olang_textcopy(ptr %t280, ptr %t273, i64 %t274)
  %t281 = insertvalue { i64, ptr } undef, i64 %t275, 0
  %t282 = insertvalue { i64, ptr } %t281, ptr %t276, 1
  %t285 = extractvalue { i64, ptr } %t282, 0
  %t286 = extractvalue { i64, ptr } %t282, 1
  %t287 = mul i64 %t285, 1
  %t288 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t287)
  call void @llvm.memcpy.p0.p0.i64(ptr %t288, ptr %t286, i64 %t287, i1 false)
  %t289 = insertvalue { i64, ptr } undef, i64 %t285, 0
  %t290 = insertvalue { i64, ptr } %t289, ptr %t288, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v5, ptr %s8, ptr %t253, { i64, ptr } %t290)
  br label %bb42
bb41:
  br label %bb43
bb42:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb43:
  %t294 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t294, ptr %l110, !tbaa !27
  %t295 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t297 = call { i64, ptr } @compiler_2ffix_2ebuiltBy(ptr %v0, ptr %s0, { i64, ptr } %t295)
  store { i64, ptr } %t297, ptr %l112
  br label %bb44
bb44:
  %t298 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t300 = extractvalue { i64, ptr } %t298, 0
  %t301 = extractvalue { i64, ptr } %t298, 1
  %t302 = mul i64 %t300, 1
  %t303 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t302)
  call void @llvm.memcpy.p0.p0.i64(ptr %t303, ptr %t301, i64 %t302, i1 false)
  %t304 = insertvalue { i64, ptr } undef, i64 %t300, 0
  %t305 = insertvalue { i64, ptr } %t304, ptr %t303, 1
  %t306 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t308 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t306, { i64, ptr } %t305)
  store i32 %t308, ptr %l115
  %t309 = icmp ne i32 %t308, 0
  br i1 %t309, label %bb46, label %ok.310, !prof !99
ok.310:
  br label %bb45
bb45:
  br label %bb50
bb46:
  %t311 = load i32, ptr %l115, !tbaa !23
  %t312 = ashr i32 %t311, 16
  %t314 = icmp eq i32 %t312, 1
  store i1 %t314, ptr %l117, !tbaa !21
  %t315 = load i32, ptr %l115, !tbaa !23
  %t316 = ashr i32 %t315, 16
  %t318 = icmp eq i32 %t316, 1
  br i1 %t318, label %bb47, label %bb48
bb47:
  call void @__olang_errpay_pop()
  br label %bb48
bb48:
  br label %bb49
bb49:
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffix_2eexpand(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %lp1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca { i64, ptr }
  %l18 = alloca i1
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  br label %bb5
bb5:
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t19, ptr %l14, !tbaa !27
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %t23, i64 %t20
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !37
  store { i64, ptr } %t25, ptr %l5, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t29 = call i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %t27)
  store i1 %t29, ptr %l18
  br label %bb6
bb6:
  %t30 = load i1, ptr %l18, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  %t31 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t32 = load ptr, ptr %lp1
  call void @compiler_2ffix_2ewalk(ptr %v0, ptr %v1, { i64, ptr } %t31, ptr %t32)
  br label %bb9
bb8:
  %t35 = load ptr, ptr %lp1
  %t36 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 1
  %t39 = extractvalue { i64, ptr } %t36, 0
  %t40 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t39)
  call void @olang_textcopy(ptr %t40, ptr %t38, i64 %t39)
  %t41 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t45 = extractvalue { i64, ptr } %t42, 1
  %t46 = mul i64 %t44, 1
  %t47 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t46)
  call void @llvm.memcpy.p0.p0.i64(ptr %t47, ptr %t45, i64 %t46, i1 false)
  %t48 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t35, { i64, ptr } %t49)
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t52 = load i64, ptr %l3, !tbaa !24
  %t54 = add i64 %t52, 1
  store i64 %t54, ptr %l3, !tbaa !24
  br label %bb2
bb13:
  %t56 = load ptr, ptr %lp1
  %t57 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t56
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t57, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i64 @compiler_2ffix_2emtime(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/os:FileInfo"
  %l2 = alloca %"std/os:FileInfo"
  %l4 = alloca %"std/os:FileInfo"
  %l5 = alloca i32
  %l7 = alloca i1
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %v0, { i64, ptr } %a0)
  %t4 = extractvalue { i32, %"std/os:FileInfo" } %t3, 1
  %t5 = extractvalue { i32, %"std/os:FileInfo" } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store %"std/os:FileInfo" %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load %"std/os:FileInfo", ptr %l4
  store %"std/os:FileInfo" %t8, ptr %l2
  br label %bb6
bb2:
  %t9 = load i32, ptr %l5, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  store i1 %t12, ptr %l7, !tbaa !21
  %t13 = load i32, ptr %l5, !tbaa !23
  %t14 = ashr i32 %t13, 16
  %t16 = icmp eq i32 %t14, 1
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  store i64 0, ptr %rv
  br label %ret
bb6:
  %t19 = load %"std/os:FileInfo", ptr %l2
  store %"std/os:FileInfo" %t19, ptr %l1
  %t20 = getelementptr %"std/os:FileInfo", ptr %l1, i32 0, i32 2
  %t21 = load i64, ptr %t20, !tbaa !24
  store i64 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ffix_2enewest(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca [2 x { i64, ptr }]
  %l8 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i32
  %l24 = alloca { i64, ptr }
  %l28 = alloca i1
  %l29 = alloca i64
  %l35 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %s0, { i64, ptr } %t1)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l11
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l10
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t8, ptr %l8, !tbaa !27
  br label %bb10
bb2:
  %t9 = load i32, ptr %l11, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  br i1 %t12, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  %t14 = icmp sge i64 0, 0
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t16 = icmp sle i64 0, 576460752303423487
  br i1 %t16, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_8fcf87cfa7be21dd_bbd76dac3520f231)
  unreachable
bb8:
  %t18 = mul i64 0, 16
  %t19 = insertvalue { i64, ptr } undef, i64 0, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t20, ptr %l8, !tbaa !27
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_8fcf87cfa7be21dd_bbd76dac3520f231)
  unreachable
bb10:
  %t22 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t22, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  store i64 %t27, ptr %l5, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t29 = load i64, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb13:
  br label %bb14
bb14:
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t37, ptr %l24, !tbaa !27
  %t38 = load i64, ptr %l4, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %t41, i64 %t38
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !37
  store { i64, ptr } %t43, ptr %l6, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t47 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s2, { i64, ptr } %t45, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d49, i32 0, i32 1) })
  store i1 %t47, ptr %l28
  br label %bb15
bb15:
  %t48 = load i1, ptr %l28, !tbaa !21
  br i1 %t48, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t49 = load i64, ptr %l1, !tbaa !24
  store i64 %t49, ptr %l29, !tbaa !24
  %t50 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t53 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t50, 0
  %t55 = insertvalue [2 x { i64, ptr }] %t53, { i64, ptr } %t51, 1
  store [2 x { i64, ptr }] %t55, ptr %l7
  %t58 = insertvalue { i64, ptr } undef, i64 2, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %l7, 1
  %t61 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s3, ptr %s3, { i64, ptr } %t59)
  store { i64, ptr } %t61, ptr %l35
  br label %bb18
bb17:
  br label %bb21
bb18:
  %t62 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t62, 0
  %t64 = extractvalue { i64, ptr } %t62, 1
  %t65 = mul i64 %t63, 1
  %t66 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t65)
  call void @llvm.memcpy.p0.p0.i64(ptr %t66, ptr %t64, i64 %t65, i1 false)
  %t67 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  %t70 = call i64 @compiler_2ffix_2emtime(ptr %s3, { i64, ptr } %t68)
  store i64 %t70, ptr %l37
  br label %bb19
bb19:
  %t71 = load i64, ptr %l29, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t71, i64 %t72)
  store i64 %t73, ptr %l38
  br label %bb20
bb20:
  %t74 = load i64, ptr %l38, !tbaa !24
  store i64 %t74, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  %t75 = load i64, ptr %l4, !tbaa !24
  %t77 = add i64 %t75, 1
  store i64 %t77, ptr %l4, !tbaa !24
  br label %bb11
bb23:
  %t79 = load i64, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t79, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffix_2ewalk(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca [2 x { i64, ptr }]
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i32
  %l25 = alloca { i64, ptr }
  %l29 = alloca i1
  %l30 = alloca i1
  %l32 = alloca i1
  %l38 = alloca { i64, ptr }
  %l40 = alloca i1
  %l44 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %s0, { i64, ptr } %t1)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l12
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l11
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t8, ptr %l9, !tbaa !27
  br label %bb10
bb2:
  %t9 = load i32, ptr %l12, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  br i1 %t12, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  %t14 = icmp sge i64 0, 0
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t16 = icmp sle i64 0, 576460752303423487
  br i1 %t16, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_9433da86f750b978_3ff5b65d50af9d4)
  unreachable
bb8:
  %t18 = mul i64 0, 16
  %t19 = insertvalue { i64, ptr } undef, i64 0, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t20, ptr %l9, !tbaa !27
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_9433da86f750b978_3ff5b65d50af9d4)
  unreachable
bb10:
  %t22 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t22, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  store i64 %t27, ptr %l5, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t29 = load i64, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb35
bb13:
  br label %bb14
bb14:
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t37, ptr %l25, !tbaa !27
  %t38 = load i64, ptr %l4, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %t41, i64 %t38
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !37
  store { i64, ptr } %t43, ptr %l6, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t47 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s2, { i64, ptr } %t45, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) })
  store i1 %t47, ptr %l29
  br label %bb15
bb15:
  %t48 = load i1, ptr %l29, !tbaa !21
  br i1 %t48, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb19
bb17:
  %t49 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t51 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s2, { i64, ptr } %t49, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d51, i32 0, i32 1) })
  store i1 %t51, ptr %l32
  br label %bb18
bb18:
  %t52 = load i1, ptr %l32, !tbaa !21
  store i1 %t52, ptr %l30, !tbaa !21
  br label %bb19
bb19:
  %t53 = load i1, ptr %l30, !tbaa !21
  br i1 %t53, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb21:
  br label %bb22
bb22:
  %t54 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t57 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t54, 0
  %t59 = insertvalue [2 x { i64, ptr }] %t57, { i64, ptr } %t55, 1
  store [2 x { i64, ptr }] %t59, ptr %l7
  %t62 = insertvalue { i64, ptr } undef, i64 2, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %l7, 1
  %t65 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s2, ptr %s2, { i64, ptr } %t63)
  store { i64, ptr } %t65, ptr %l38
  br label %bb23
bb23:
  %t66 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t66, ptr %l8, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t69 = call i1 @std_2fos_2eIsDir(ptr %s2, { i64, ptr } %t67)
  store i1 %t69, ptr %l40
  br label %bb24
bb24:
  %t70 = load i1, ptr %l40, !tbaa !21
  br i1 %t70, label %bb25, label %bb26
bb25:
  %t71 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t72 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ffix_2ewalk(ptr %s2, ptr %v1, { i64, ptr } %t71, ptr %t72)
  br label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t75 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t77 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s5, { i64, ptr } %t75, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d52, i32 0, i32 1) })
  store i1 %t77, ptr %l44
  br label %bb28
bb27:
  br label %bb33
bb28:
  %t78 = load i1, ptr %l44, !tbaa !21
  br i1 %t78, label %bb29, label %bb30
bb29:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t80 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t80, 1
  %t83 = extractvalue { i64, ptr } %t80, 0
  %t84 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t83)
  call void @olang_textcopy(ptr %t84, ptr %t82, i64 %t83)
  %t85 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = extractvalue { i64, ptr } %t86, 1
  %t90 = mul i64 %t88, 1
  %t91 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t90)
  call void @llvm.memcpy.p0.p0.i64(ptr %t91, ptr %t89, i64 %t90, i1 false)
  %t92 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t79, { i64, ptr } %t93)
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s5)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb34:
  %t96 = load i64, ptr %l4, !tbaa !24
  %t98 = add i64 %t96, 1
  store i64 %t98, ptr %l4, !tbaa !24
  br label %bb11
bb35:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

declare void @__olang_errpay_pop()
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d0 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fix" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d1 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d2 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c": cannot be read\0A" }>, align 8
@.d3 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"olang: fix: no tools directory at " }>, align 8
@.d4 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c" (OLANG_TOOLS names another)\0A" }>, align 8
@.d5 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"olang: fix: cannot make " }>, align 8
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d7 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"tools_" }>, align 8
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d9 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d10 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"olang: fix: cannot run " }>, align 8
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d12 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c":\0A" }>, align 8
@.d13 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d16 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d17 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c": cannot be written\0A" }>, align 8
@.d18 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d19 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d20 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"olang fix: " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d21 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" place" }>, align 8
@.d22 = private constant <{ i64, [89 x i8] }> <{ i64 0, [89 x i8] c" above may mean something else in the language of today than when written - look at each\0A" }>, align 8
@.d23 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"text" }>, align 8
@.d24 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"driven" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d25 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"driven" }>, align 8
@.d26 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"OLANG_TOOLS" }>, align 8
@.d27 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d28 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d29 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"/../tools" }>, align 8
@.d30 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"--std" }>, align 8
@.d31 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"--olang" }>, align 8
@.d32 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d33 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d34 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"by hand:" }>, align 8
@.d35 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"for a person:" }>, align 8
@.d36 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d37 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"tools_" }>, align 8
@.d38 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".from" }>, align 8
@.d39 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d40 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"prelude" }>, align 8
@.d41 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"../compiler" }>, align 8
@.d42 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@.d43 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"build" }>, align 8
@.d44 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"-output" }>, align 8
@.d45 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"olang: fix: cannot run " }>, align 8
@.d46 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d47 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"olang: fix: tools/" }>, align 8
@.d48 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c".olang does not build:\0A" }>, align 8
@__olang_empty_array = external constant [16 x i64]
@.d49 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@.d50 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d51 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"build" }>, align 8
@.d52 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2ffetch_2eCacheDir(ptr %v0)
declare { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_74a546a3dd225c9b_f3beb7f3829b0fbf = external constant [0 x i8]
declare %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %v0, i32 %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %v0, ptr %a0)
declare i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
@olang_loc_299e69389bcee8f2_b185402659ea7d46 = external constant [0 x i8]
declare { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2ffilepath_2eDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %v0, { i64, ptr } %a0)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %a0, i64 %a1)
declare i32 @std_2fos_2eRemove(ptr %v0, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_8fcf87cfa7be21dd_bbd76dac3520f231 = external constant [0 x i8]
@olang_loc_9433da86f750b978_3ff5b65d50af9d4 = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
