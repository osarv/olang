; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/io:Writer" = type { i32, { i64, ptr }, i64, i32 }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
%"std/os:FileInfo" = type { i32, i64, i64 }
@G_2ecompiler_2ffix_2eBatch = constant <{ [8 x i8] }> <{ [8 x i8] c"\C8\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eDrivenArg = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eDrivenOpt = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eStdTool = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eTextTool = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eToolKinds = constant <{ [152 x i8] }> <{ [152 x i8] c"\01\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\03\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2ffix_2eToolNames = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k1, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k2, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k3, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k4, [8 x i8] c"\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k5, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k6, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k7, [8 x i8] c"\0C\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k8, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k9, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k10, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k11, [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k12, [8 x i8] c"\0C\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k13, [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k14, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k15, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k16, [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k17, [8 x i8] c"\0B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k18, [8 x i8] c"\0A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k19 }>, align 64
@G_2ecompiler_2ffix_2eToolNames.k1 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\62\61\72\65\5F\74\79\70\65\76\61\72\73" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k2 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\70\65\72\6D\5F\6D\75\74" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k3 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\69\6E\74\5F\6C\69\74\65\72\61\6C\5F\69\36\34" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k4 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\65\72\72\6F\72\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k5 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\63\6C\69\5F\77\6F\72\64\73" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k6 = internal constant <{ [16 x i8] }> <{ [16 x i8] c"\64\6F\6E\65\66\61\69\6C\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k7 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\73\79\6E\74\61\78\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k8 = internal constant <{ [12 x i8] }> <{ [12 x i8] c"\6D\61\74\68\5F\6D\65\74\68\6F\64\73" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k9 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\61\72\72\61\79\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k10 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\72\65\73\75\6C\74\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k11 = internal constant <{ [16 x i8] }> <{ [16 x i8] c"\65\71\75\61\6C\69\74\79\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k12 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\68\65\6C\70\65\72\5F\72\65\6E\61\6D\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k13 = internal constant <{ [12 x i8] }> <{ [12 x i8] c"\6E\75\6C\6C\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k14 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\63\68\65\63\6B\65\72\72\6F\72\5F\72\65\6E\61\6D\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k15 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\73\74\75\74\74\65\72\5F\72\65\6E\61\6D\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k16 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\63\68\65\63\6B\65\64\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k17 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\63\6F\6E\74\72\61\63\74\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k18 = internal constant <{ [11 x i8] }> <{ [11 x i8] c"\74\72\79\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k19 = internal constant <{ [10 x i8] }> <{ [10 x i8] c"\61\73\5F\6D\69\67\72\61\74\65" }>, align 8
define dso_local void @compiler_2ffix_2eBatch_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 200, ptr @G_2ecompiler_2ffix_2eBatch, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffix_2eDrivenArg_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 3, ptr @G_2ecompiler_2ffix_2eDrivenArg, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffix_2eDrivenOpt_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 2, ptr @G_2ecompiler_2ffix_2eDrivenOpt, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2ffix_2eFiles(ptr %v0, ptr %v1, ptr %v2, i1 %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca i1
  %l2 = alloca { i64, ptr }
  %l4 = alloca %"std/io:Writer"
  %l5 = alloca %"std/io:Writer"
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l30 = alloca %"std/os:Output"
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l42 = alloca %"std/io:Writer"
  %l43 = alloca %"std/io:Writer"
  %l45 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l47 = alloca { i64, ptr }
  %l48 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l56 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca i32
  %l71 = alloca i32
  %l82 = alloca { i64, ptr }
  %l84 = alloca i1
  %l92 = alloca i32
  %l96 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l100 = alloca i32
  %l109 = alloca i32
  %l113 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l131 = alloca i1
  %l137 = alloca { i64, ptr }
  %l144 = alloca i64
  %l147 = alloca i64
  %l165 = alloca { i64, ptr }
  %l166 = alloca i64
  %l172 = alloca i64
  %l173 = alloca i64
  %l178 = alloca %"std/os:Output"
  %l185 = alloca { i64, ptr }
  %l187 = alloca { i64, ptr }
  %l188 = alloca %"std/os:Output"
  %l189 = alloca i32
  %l201 = alloca i64
  %l204 = alloca i1
  %l214 = alloca i1
  %l217 = alloca { i64, ptr }
  %l234 = alloca i64
  %l237 = alloca i64
  %l255 = alloca { i64, ptr }
  %l256 = alloca { i64, ptr }
  %l259 = alloca { i64, ptr }
  %l260 = alloca i32
  %l263 = alloca { i64, ptr }
  %l266 = alloca { i64, ptr }
  %l267 = alloca i1
  %l271 = alloca { i64, ptr }
  %l278 = alloca { i64, ptr }
  %l280 = alloca { i64, ptr }
  %l283 = alloca { i64, ptr }
  %l285 = alloca i32
  %l289 = alloca { i64, ptr }
  %l299 = alloca i1
  %l304 = alloca { i64, ptr }
  %l312 = alloca i32
  %l317 = alloca i32
  %l325 = alloca i1
  %l328 = alloca i1
  %l331 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %rv = alloca i32
  store i1 %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %s0, i32 2, i64 65536)
  store %"std/io:Writer" %t1, ptr %l42
  br label %bb1
bb1:
  %t2 = load %"std/io:Writer", ptr %l42
  store %"std/io:Writer" %t2, ptr %l4
  %t3 = call %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %s0, i32 1, i64 65536)
  store %"std/io:Writer" %t3, ptr %l43
  br label %bb2
bb2:
  %t4 = load %"std/io:Writer", ptr %l43
  store %"std/io:Writer" %t4, ptr %l5
  %t7 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffix_2eexpand(ptr %v0, ptr %s0, { i64, ptr } %a1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l45
  br label %bb3
bb3:
  %t8 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l45
  %t9 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %t9
  %t11 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hd4bdf3befe2f7a35847f168802c5df68(ptr %s0, ptr %s0, ptr %t9)
  store { i64, ptr } %t11, ptr %l47
  br label %bb4
bb4:
  %t12 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t12, ptr %l6, !tbaa !27
  %t13 = load ptr, ptr @__olang_prog_scope
  %t14 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t13)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, ptr %l48
  br label %bb5
bb5:
  %t15 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l48
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %l7
  %t16 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t16, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  store i64 %t20, ptr %l10, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t22 = load i64, ptr %l9, !tbaa !24
  %t23 = load i64, ptr %l10, !tbaa !24
  %t26 = icmp slt i64 %t22, %t23
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb8:
  br label %bb9
bb9:
  %t30 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t30, ptr %l56, !tbaa !27
  %t31 = load i64, ptr %l9, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %t34, i64 %t31
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !37
  store { i64, ptr } %t36, ptr %l11, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t40 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s2, { i64, ptr } %t38)
  %t41 = extractvalue { i32, { i64, ptr } } %t40, 1
  %t42 = extractvalue { i32, { i64, ptr } } %t40, 0
  store i32 %t42, ptr %l62
  %t43 = icmp ne i32 %t42, 0
  br i1 %t43, label %bb11, label %ok.44
ok.44:
  store { i64, ptr } %t41, ptr %l61
  br label %bb10
bb10:
  %t45 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t45, ptr %l59, !tbaa !27
  br label %bb22
bb11:
  %t46 = load i32, ptr %l62, !tbaa !23
  %t47 = ashr i32 %t46, 16
  %t49 = icmp eq i32 %t47, 1
  br i1 %t49, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_55e63acaa25cfd39_d0989827e133efd)
  unreachable
bb14:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s3
  %t51 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t52 = extractvalue { i64, ptr } { i64 7, ptr @.d0 }, 1
  %t53 = extractvalue { i64, ptr } { i64 7, ptr @.d0 }, 0
  %t55 = extractvalue { i64, ptr } %t51, 1
  %t56 = extractvalue { i64, ptr } %t51, 0
  %t57 = add i64 %t53, %t56
  %t58 = extractvalue { i64, ptr } { i64 17, ptr @.d1 }, 1
  %t59 = extractvalue { i64, ptr } { i64 17, ptr @.d1 }, 0
  %t60 = add i64 %t57, %t59
  %t61 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t60)
  call void @olang_textcopy(ptr %t61, ptr %t52, i64 %t53)
  %t62 = getelementptr i8, ptr %t61, i64 %t53
  call void @olang_textcopy(ptr %t62, ptr %t55, i64 %t56)
  %t63 = getelementptr i8, ptr %t62, i64 %t56
  call void @olang_textcopy(ptr %t63, ptr %t58, i64 %t59)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t61, 1
  %t68 = extractvalue { i64, ptr } %t65, 0
  %t69 = extractvalue { i64, ptr } %t65, 1
  %t70 = mul i64 %t68, 1
  %t71 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t70)
  call void @llvm.memcpy.p0.p0.i64(ptr %t71, ptr %t69, i64 %t70, i1 false)
  %t72 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t71, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s3, ptr %l4, { i64, ptr } %t73)
  br label %bb15
bb15:
  %t77 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l4)
  store i32 %t77, ptr %l71
  %t78 = icmp ne i32 %t77, 0
  br i1 %t78, label %bb17, label %ok.79
ok.79:
  br label %bb16
bb16:
  br label %bb21
bb17:
  %t80 = load i32, ptr %l71, !tbaa !23
  %t81 = ashr i32 %t80, 16
  %t83 = icmp eq i32 %t81, 1
  br i1 %t83, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_26781d70abdd0d68_5f1bea27110e64cc)
  unreachable
bb20:
  call void @__olang_ert_req_clear()
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb22:
  %t86 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t86, 1
  %t90 = extractvalue { i64, ptr } %t86, 0
  %t91 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t90)
  call void @olang_textcopy(ptr %t91, ptr %t89, i64 %t90)
  %t92 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t96 = extractvalue { i64, ptr } %t93, 1
  %t97 = mul i64 %t95, 1
  %t98 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t97)
  call void @llvm.memcpy.p0.p0.i64(ptr %t98, ptr %t96, i64 %t97, i1 false)
  %t99 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } %t100)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb24:
  %t103 = load i64, ptr %l9, !tbaa !24
  %t105 = add i64 %t103, 1
  store i64 %t105, ptr %l9, !tbaa !24
  br label %bb6
bb25:
  %t107 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t109 = call { i64, ptr } @compiler_2ffix_2eToolsDir(ptr %v1, ptr %s0, { i64, ptr } %t107)
  store { i64, ptr } %t109, ptr %l82
  br label %bb26
bb26:
  %t110 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t110, ptr %l13, !tbaa !27
  %t111 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t113 = call i1 @std_2fos_2eIsDir(ptr %s0, { i64, ptr } %t111)
  store i1 %t113, ptr %l84
  br label %bb27
bb27:
  %t114 = load i1, ptr %l84, !tbaa !21
  %t115 = xor i1 %t114, true
  br i1 %t115, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s8
  %t117 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t118 = extractvalue { i64, ptr } { i64 34, ptr @.d2 }, 1
  %t119 = extractvalue { i64, ptr } { i64 34, ptr @.d2 }, 0
  %t121 = extractvalue { i64, ptr } %t117, 1
  %t122 = extractvalue { i64, ptr } %t117, 0
  %t123 = add i64 %t119, %t122
  %t124 = extractvalue { i64, ptr } { i64 29, ptr @.d3 }, 1
  %t125 = extractvalue { i64, ptr } { i64 29, ptr @.d3 }, 0
  %t126 = add i64 %t123, %t125
  %t127 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t126)
  call void @olang_textcopy(ptr %t127, ptr %t118, i64 %t119)
  %t128 = getelementptr i8, ptr %t127, i64 %t119
  call void @olang_textcopy(ptr %t128, ptr %t121, i64 %t122)
  %t129 = getelementptr i8, ptr %t128, i64 %t122
  call void @olang_textcopy(ptr %t129, ptr %t124, i64 %t125)
  %t130 = insertvalue { i64, ptr } undef, i64 %t126, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t127, 1
  %t134 = extractvalue { i64, ptr } %t131, 0
  %t135 = extractvalue { i64, ptr } %t131, 1
  %t136 = mul i64 %t134, 1
  %t137 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t136)
  call void @llvm.memcpy.p0.p0.i64(ptr %t137, ptr %t135, i64 %t136, i1 false)
  %t138 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t137, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s8, ptr %l4, { i64, ptr } %t139)
  br label %bb30
bb29:
  br label %bb37
bb30:
  %t143 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l4)
  store i32 %t143, ptr %l92
  %t144 = icmp ne i32 %t143, 0
  br i1 %t144, label %bb32, label %ok.145
ok.145:
  br label %bb31
bb31:
  br label %bb36
bb32:
  %t146 = load i32, ptr %l92, !tbaa !23
  %t147 = ashr i32 %t146, 16
  %t149 = icmp eq i32 %t147, 1
  br i1 %t149, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_e6a6422eb79d2443_db90500efc9fb0c7)
  unreachable
bb35:
  call void @__olang_ert_req_clear()
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb37:
  %t152 = call { i64, ptr } @compiler_2ffetch_2eCacheDir(ptr %s0)
  store { i64, ptr } %t152, ptr %l96
  br label %bb38
bb38:
  %t153 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t154 = extractvalue { i64, ptr } %t153, 0
  %t155 = extractvalue { i64, ptr } %t153, 1
  %t156 = mul i64 %t154, 1
  %t157 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t156)
  call void @llvm.memcpy.p0.p0.i64(ptr %t157, ptr %t155, i64 %t156, i1 false)
  %t158 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t157, 1
  %t161 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t159, { i64, ptr } { i64 3, ptr @.d4 }, { i64, ptr } { i64 0, ptr @.d5 }, { i64, ptr } { i64 0, ptr @.d6 }, { i64, ptr } { i64 0, ptr @.d7 }, { i64, ptr } { i64 0, ptr @.d8 })
  store { i64, ptr } %t161, ptr %l98
  br label %bb39
bb39:
  %t162 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t162, ptr %l14, !tbaa !27
  %t163 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t165 = call i32 @std_2fos_2eMkDirAll(ptr %s0, { i64, ptr } %t163)
  store i32 %t165, ptr %l100
  %t166 = icmp ne i32 %t165, 0
  br i1 %t166, label %bb41, label %ok.167
ok.167:
  br label %bb40
bb40:
  br label %bb52
bb41:
  %t168 = load i32, ptr %l100, !tbaa !23
  %t169 = ashr i32 %t168, 16
  %t171 = icmp eq i32 %t169, 1
  br i1 %t171, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_aaa99c12ebecdcc2_f002f5bd4abfbc66)
  unreachable
bb44:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s11
  %t173 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t174 = extractvalue { i64, ptr } { i64 24, ptr @.d9 }, 1
  %t175 = extractvalue { i64, ptr } { i64 24, ptr @.d9 }, 0
  %t177 = extractvalue { i64, ptr } %t173, 1
  %t178 = extractvalue { i64, ptr } %t173, 0
  %t179 = add i64 %t175, %t178
  %t180 = extractvalue { i64, ptr } { i64 1, ptr @.d10 }, 1
  %t181 = extractvalue { i64, ptr } { i64 1, ptr @.d10 }, 0
  %t182 = add i64 %t179, %t181
  %t183 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t182)
  call void @olang_textcopy(ptr %t183, ptr %t174, i64 %t175)
  %t184 = getelementptr i8, ptr %t183, i64 %t175
  call void @olang_textcopy(ptr %t184, ptr %t177, i64 %t178)
  %t185 = getelementptr i8, ptr %t184, i64 %t178
  call void @olang_textcopy(ptr %t185, ptr %t180, i64 %t181)
  %t186 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t183, 1
  %t190 = extractvalue { i64, ptr } %t187, 0
  %t191 = extractvalue { i64, ptr } %t187, 1
  %t192 = mul i64 %t190, 1
  %t193 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t192)
  call void @llvm.memcpy.p0.p0.i64(ptr %t193, ptr %t191, i64 %t192, i1 false)
  %t194 = insertvalue { i64, ptr } undef, i64 %t190, 0
  %t195 = insertvalue { i64, ptr } %t194, ptr %t193, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s11, ptr %l4, { i64, ptr } %t195)
  br label %bb45
bb45:
  %t199 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l4)
  store i32 %t199, ptr %l109
  %t200 = icmp ne i32 %t199, 0
  br i1 %t200, label %bb47, label %ok.201
ok.201:
  br label %bb46
bb46:
  br label %bb51
bb47:
  %t202 = load i32, ptr %l109, !tbaa !23
  %t203 = ashr i32 %t202, 16
  %t205 = icmp eq i32 %t203, 1
  br i1 %t205, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_d21c474f19498c95_d0832220e57344c1)
  unreachable
bb50:
  call void @__olang_ert_req_clear()
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb52:
  store i32 0, ptr %l15, !tbaa !23
  store i64 0, ptr %l16, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s14
  %t208 = call { i64, ptr } @compiler_2ffix_2eOrder(ptr %s14)
  store { i64, ptr } %t208, ptr %l113
  br label %bb53
bb53:
  %t209 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t210 = extractvalue { i64, ptr } %t209, 0
  %t211 = extractvalue { i64, ptr } %t209, 1
  %t212 = mul i64 %t210, 8
  %t213 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t212)
  call void @llvm.memcpy.p0.p0.i64(ptr %t213, ptr %t211, i64 %t212, i1 false)
  %t214 = insertvalue { i64, ptr } undef, i64 %t210, 0
  %t215 = insertvalue { i64, ptr } %t214, ptr %t213, 1
  store { i64, ptr } %t215, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t217 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t219 = extractvalue { i64, ptr } %t217, 0
  store i64 %t219, ptr %l19, !tbaa !24
  br label %bb54
bb54:
  store %olang.scope zeroinitializer, ptr %s15
  %t221 = load i64, ptr %l18, !tbaa !24
  %t222 = load i64, ptr %l19, !tbaa !24
  %t225 = icmp slt i64 %t221, %t222
  %t227 = xor i1 %t225, true
  br i1 %t227, label %bb55, label %bb56
bb55:
  call void @__olang_scope_close(ptr %s15)
  br label %bb110
bb56:
  br label %bb57
bb57:
  %t229 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t229, ptr %l121, !tbaa !27
  %t230 = load i64, ptr %l18, !tbaa !24
  %t232 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !27
  %t234 = getelementptr i64, ptr %t233, i64 %t230
  %t235 = load i64, ptr %t234, !tbaa !34
  store i64 %t235, ptr %l20, !tbaa !24
  %t237 = load i64, ptr %l20, !tbaa !24
  %t239 = getelementptr [19 x { i64, ptr }], ptr @G_2ecompiler_2ffix_2eToolNames, i64 0, i64 %t237
  %t240 = load { i64, ptr }, ptr %t239, !tbaa !37
  store { i64, ptr } %t240, ptr %l21, !tbaa !27
  %t242 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t243 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t244 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t245 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t246 = load ptr, ptr @__olang_prog_scope
  %t252 = call i1 @compiler_2ffix_2eensureBuilt(ptr %v1, ptr %s0, ptr %s0, ptr %t246, ptr %s0, { i64, ptr } %t242, { i64, ptr } %t243, { i64, ptr } %t244, { i64, ptr } %t245, ptr %l4)
  store i1 %t252, ptr %l131
  br label %bb58
bb58:
  %t253 = load i1, ptr %l131, !tbaa !21
  %t254 = xor i1 %t253, true
  br i1 %t254, label %bb59, label %bb60
bb59:
  store i32 2, ptr %l15, !tbaa !23
  call void @__olang_scope_close(ptr %s15)
  br label %bb110
bb60:
  br label %bb61
bb61:
  %t256 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t257 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t258 = extractvalue { i64, ptr } { i64 6, ptr @.d11 }, 1
  %t259 = extractvalue { i64, ptr } { i64 6, ptr @.d11 }, 0
  %t261 = extractvalue { i64, ptr } %t257, 1
  %t262 = extractvalue { i64, ptr } %t257, 0
  %t263 = add i64 %t259, %t262
  %t264 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t263)
  call void @olang_textcopy(ptr %t264, ptr %t258, i64 %t259)
  %t265 = getelementptr i8, ptr %t264, i64 %t259
  call void @olang_textcopy(ptr %t265, ptr %t261, i64 %t262)
  %t266 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t267 = insertvalue { i64, ptr } %t266, ptr %t264, 1
  %t269 = extractvalue { i64, ptr } %t267, 0
  %t270 = extractvalue { i64, ptr } %t267, 1
  %t271 = mul i64 %t269, 1
  %t272 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t271)
  call void @llvm.memcpy.p0.p0.i64(ptr %t272, ptr %t270, i64 %t271, i1 false)
  %t273 = insertvalue { i64, ptr } undef, i64 %t269, 0
  %t274 = insertvalue { i64, ptr } %t273, ptr %t272, 1
  %t277 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s15, ptr %s15, ptr %s15, ptr %s15, ptr %s15, ptr %s15, { i64, ptr } %t256, { i64, ptr } %t274, { i64, ptr } { i64 0, ptr @.d12 }, { i64, ptr } { i64 0, ptr @.d13 }, { i64, ptr } { i64 0, ptr @.d14 }, { i64, ptr } { i64 0, ptr @.d15 })
  store { i64, ptr } %t277, ptr %l137
  br label %bb62
bb62:
  %t278 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t278, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t279 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t281 = extractvalue { i64, ptr } %t279, 0
  store i64 %t281, ptr %l24, !tbaa !24
  %t283 = load i64, ptr @G_2ecompiler_2ffix_2eBatch, !tbaa !24
  store i64 %t283, ptr %l25, !tbaa !24
  %t285 = load i64, ptr %l24, !tbaa !24
  %t286 = load i64, ptr %l23, !tbaa !24
  %t289 = icmp sgt i64 %t285, %t286
  br i1 %t289, label %bb63, label %bb64
bb63:
  %t291 = load i64, ptr %l25, !tbaa !24
  %t293 = icmp sgt i64 %t291, 0
  br i1 %t293, label %bb65, label %bb66
bb64:
  store i64 0, ptr %l144, !tbaa !24
  br label %bb68
bb65:
  %t295 = load i64, ptr %l24, !tbaa !24
  %t296 = load i64, ptr %l23, !tbaa !24
  %t299 = sub i64 %t295, %t296
  %t300 = load i64, ptr %l25, !tbaa !24
  %t303 = add i64 %t299, %t300
  %t305 = sub i64 %t303, 1
  %t306 = load i64, ptr %l25, !tbaa !24
  %t309 = sdiv i64 %t305, %t306
  store i64 %t309, ptr %l147, !tbaa !24
  br label %bb67
bb66:
  store i64 0, ptr %l147, !tbaa !24
  br label %bb67
bb67:
  %t311 = load i64, ptr %l147, !tbaa !24
  store i64 %t311, ptr %l144, !tbaa !24
  br label %bb68
bb68:
  %t312 = load i64, ptr %l144, !tbaa !24
  store i64 %t312, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb69
bb69:
  store %olang.scope zeroinitializer, ptr %s19
  %t313 = load i64, ptr %l27, !tbaa !24
  %t314 = load i64, ptr %l26, !tbaa !24
  %t317 = icmp slt i64 %t313, %t314
  %t319 = xor i1 %t317, true
  br i1 %t319, label %bb70, label %bb71
bb70:
  call void @__olang_scope_close(ptr %s19)
  br label %bb105
bb71:
  br label %bb72
bb72:
  %t321 = load i64, ptr %l23, !tbaa !24
  %t322 = load i64, ptr %l27, !tbaa !24
  %t323 = load i64, ptr %l25, !tbaa !24
  %t326 = mul i64 %t322, %t323
  %t329 = add i64 %t321, %t326
  store i64 %t329, ptr %l28, !tbaa !24
  %t331 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t331, ptr %l165, !tbaa !27
  %t332 = load i64, ptr %l28, !tbaa !24
  store i64 %t332, ptr %l166, !tbaa !24
  %t333 = load i64, ptr %l28, !tbaa !24
  %t334 = load i64, ptr @G_2ecompiler_2ffix_2eBatch, !tbaa !24
  %t337 = add i64 %t333, %t334
  %t338 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t340 = extractvalue { i64, ptr } %t338, 0
  %t343 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t337, i64 %t340)
  store i64 %t343, ptr %l172
  br label %bb73
bb73:
  %t344 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t345 = extractvalue { i64, ptr } %t344, 0
  store i64 %t345, ptr %l173, !tbaa !24
  %t346 = load i64, ptr %l166, !tbaa !24
  %t347 = icmp sge i64 %t346, 0
  br i1 %t347, label %bb74, label %bb75
bb74:
  %t349 = load i64, ptr %l166, !tbaa !24
  %t350 = load i64, ptr %l172, !tbaa !24
  %t351 = icmp sle i64 %t349, %t350
  br i1 %t351, label %bb76, label %bb77
bb75:
  call void @__olang_check_failed(ptr @olang_loc_914b199b24af8e0b_cb2ee6ecbe673f47)
  unreachable
bb76:
  %t353 = load i64, ptr %l172, !tbaa !24
  %t354 = load i64, ptr %l173, !tbaa !24
  %t355 = icmp sle i64 %t353, %t354
  br i1 %t355, label %bb78, label %bb79
bb77:
  call void @__olang_check_failed(ptr @olang_loc_914b199b24af8e0b_cb2ee6ecbe673f47)
  unreachable
bb78:
  %t357 = getelementptr { i64, ptr }, ptr %l165, i32 0, i32 1
  %t358 = load ptr, ptr %t357, !tbaa !27
  %t359 = load i64, ptr %l166, !tbaa !24
  %t360 = load i64, ptr %l172, !tbaa !24
  %t361 = getelementptr { i64, ptr }, ptr %t358, i64 %t359
  %t362 = sub i64 %t360, %t359
  %t363 = insertvalue { i64, ptr } undef, i64 %t362, 0
  %t364 = insertvalue { i64, ptr } %t363, ptr %t361, 1
  %t366 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t367 = load i64, ptr %l20, !tbaa !24
  %t369 = getelementptr [19 x i64], ptr @G_2ecompiler_2ffix_2eToolKinds, i64 0, i64 %t367
  %t370 = load i64, ptr %t369, !tbaa !34
  %t371 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t379 = call { i64, ptr } @compiler_2ffix_2earguments(ptr %s15, ptr %v1, ptr %v2, ptr %s0, ptr %s19, { i64, ptr } %t366, i64 %t370, { i64, ptr } %t371, { i64, ptr } %a3, { i64, ptr } %t364)
  store { i64, ptr } %t379, ptr %l185
  br label %bb80
bb79:
  call void @__olang_check_failed(ptr @olang_loc_914b199b24af8e0b_cb2ee6ecbe673f47)
  unreachable
bb80:
  %t380 = load { i64, ptr }, ptr %l185, !tbaa !27
  %t381 = extractvalue { i64, ptr } %t380, 0
  %t382 = extractvalue { i64, ptr } %t380, 1
  %t383 = mul i64 %t381, 16
  %t384 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t383)
  call void @llvm.memcpy.p0.p0.i64(ptr %t384, ptr %t382, i64 %t383, i1 false)
  %t385 = insertvalue { i64, ptr } undef, i64 %t381, 0
  %t386 = insertvalue { i64, ptr } %t385, ptr %t384, 1
  store { i64, ptr } { i64 0, ptr @.d16 }, ptr %l187, !tbaa !27
  %t388 = load { i64, ptr }, ptr %l187, !tbaa !27
  %t389 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s19, ptr %s19, ptr %s19, ptr %s19, { i64, ptr } %t386, { i64, ptr } %t388, i1 true, { i64, ptr } { i64 0, ptr @.d17 })
  %t390 = extractvalue { i32, %"std/os:Output" } %t389, 1
  %t391 = extractvalue { i32, %"std/os:Output" } %t389, 0
  store i32 %t391, ptr %l189
  %t392 = icmp ne i32 %t391, 0
  br i1 %t392, label %bb82, label %ok.393
ok.393:
  store %"std/os:Output" %t390, ptr %l188
  br label %bb81
bb81:
  %t394 = load %"std/os:Output", ptr %l188
  store %"std/os:Output" %t394, ptr %l178
  br label %bb87
bb82:
  %t395 = load i32, ptr %l189, !tbaa !23
  %t396 = ashr i32 %t395, 16
  %t398 = icmp eq i32 %t396, 1
  br i1 %t398, label %bb83, label %bb84
bb83:
  br label %bb85
bb84:
  call void @__olang_check_failed(ptr @olang_loc_80a1d4bb5db67df_9b65eebf7bc7956b)
  unreachable
bb85:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s20
  %t400 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t401 = extractvalue { i64, ptr } { i64 23, ptr @.d18 }, 1
  %t402 = extractvalue { i64, ptr } { i64 23, ptr @.d18 }, 0
  %t404 = extractvalue { i64, ptr } %t400, 1
  %t405 = extractvalue { i64, ptr } %t400, 0
  %t406 = add i64 %t402, %t405
  %t407 = extractvalue { i64, ptr } { i64 1, ptr @.d19 }, 1
  %t408 = extractvalue { i64, ptr } { i64 1, ptr @.d19 }, 0
  %t409 = add i64 %t406, %t408
  %t410 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t409)
  call void @olang_textcopy(ptr %t410, ptr %t401, i64 %t402)
  %t411 = getelementptr i8, ptr %t410, i64 %t402
  call void @olang_textcopy(ptr %t411, ptr %t404, i64 %t405)
  %t412 = getelementptr i8, ptr %t411, i64 %t405
  call void @olang_textcopy(ptr %t412, ptr %t407, i64 %t408)
  %t413 = insertvalue { i64, ptr } undef, i64 %t409, 0
  %t414 = insertvalue { i64, ptr } %t413, ptr %t410, 1
  %t417 = extractvalue { i64, ptr } %t414, 0
  %t418 = extractvalue { i64, ptr } %t414, 1
  %t419 = mul i64 %t417, 1
  %t420 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t419)
  call void @llvm.memcpy.p0.p0.i64(ptr %t420, ptr %t418, i64 %t419, i1 false)
  %t421 = insertvalue { i64, ptr } undef, i64 %t417, 0
  %t422 = insertvalue { i64, ptr } %t421, ptr %t420, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s20, ptr %l4, { i64, ptr } %t422)
  br label %bb86
bb86:
  store i32 2, ptr %l15, !tbaa !23
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s19)
  br label %bb105
bb87:
  %t425 = load %"std/os:Output", ptr %l178
  store %"std/os:Output" %t425, ptr %l30
  %t426 = getelementptr %"std/os:Output", ptr %l30, i32 0, i32 1
  %t427 = load { i64, ptr }, ptr %t426, !tbaa !27
  %t428 = getelementptr %"std/os:Output", ptr %l30, i32 0, i32 2
  %t429 = load { i64, ptr }, ptr %t428, !tbaa !27
  %t431 = extractvalue { i64, ptr } %t427, 1
  %t432 = extractvalue { i64, ptr } %t427, 0
  %t434 = extractvalue { i64, ptr } %t429, 1
  %t435 = extractvalue { i64, ptr } %t429, 0
  %t436 = add i64 %t432, %t435
  %t437 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t436)
  call void @olang_textcopy(ptr %t437, ptr %t431, i64 %t432)
  %t438 = getelementptr i8, ptr %t437, i64 %t432
  call void @olang_textcopy(ptr %t438, ptr %t434, i64 %t435)
  %t439 = insertvalue { i64, ptr } undef, i64 %t436, 0
  %t440 = insertvalue { i64, ptr } %t439, ptr %t437, 1
  store { i64, ptr } %t440, ptr %l31, !tbaa !27
  %t442 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t444 = call i64 @compiler_2ffix_2ebyHand(ptr %s19, { i64, ptr } %t442)
  store i64 %t444, ptr %l201
  br label %bb88
bb88:
  %t445 = load i64, ptr %l201, !tbaa !24
  store i64 %t445, ptr %l32, !tbaa !24
  %t446 = getelementptr %"std/os:Output", ptr %l30, i32 0, i32 0
  %t447 = load i32, ptr %t446, !tbaa !23
  %t449 = icmp sgt i32 %t447, 1
  br i1 %t449, label %bb89, label %bb90
bb89:
  store i1 true, ptr %l204, !tbaa !21
  br label %bb91
bb90:
  %t451 = load i64, ptr %l32, !tbaa !24
  %t453 = icmp sgt i64 %t451, 0
  store i1 %t453, ptr %l204, !tbaa !21
  br label %bb91
bb91:
  %t455 = load i1, ptr %l204, !tbaa !21
  br i1 %t455, label %bb92, label %bb93
bb92:
  store %olang.scope zeroinitializer, ptr %s23
  %t456 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t457 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t459 = extractvalue { i64, ptr } %t456, 1
  %t460 = extractvalue { i64, ptr } %t456, 0
  %t461 = extractvalue { i64, ptr } { i64 2, ptr @.d20 }, 1
  %t462 = extractvalue { i64, ptr } { i64 2, ptr @.d20 }, 0
  %t463 = add i64 %t460, %t462
  %t465 = extractvalue { i64, ptr } %t457, 1
  %t466 = extractvalue { i64, ptr } %t457, 0
  %t467 = add i64 %t463, %t466
  %t468 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t467)
  call void @olang_textcopy(ptr %t468, ptr %t459, i64 %t460)
  %t469 = getelementptr i8, ptr %t468, i64 %t460
  call void @olang_textcopy(ptr %t469, ptr %t461, i64 %t462)
  %t470 = getelementptr i8, ptr %t469, i64 %t462
  call void @olang_textcopy(ptr %t470, ptr %t465, i64 %t466)
  %t471 = insertvalue { i64, ptr } undef, i64 %t467, 0
  %t472 = insertvalue { i64, ptr } %t471, ptr %t468, 1
  %t475 = extractvalue { i64, ptr } %t472, 0
  %t476 = extractvalue { i64, ptr } %t472, 1
  %t477 = mul i64 %t475, 1
  %t478 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t477)
  call void @llvm.memcpy.p0.p0.i64(ptr %t478, ptr %t476, i64 %t477, i1 false)
  %t479 = insertvalue { i64, ptr } undef, i64 %t475, 0
  %t480 = insertvalue { i64, ptr } %t479, ptr %t478, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s23, ptr %l4, { i64, ptr } %t480)
  br label %bb94
bb93:
  br label %bb100
bb94:
  %t483 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t485 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s19, ptr %s23, { i64, ptr } %t483, { i64, ptr } { i64 1, ptr @.d21 })
  store i1 %t485, ptr %l214
  br label %bb95
bb95:
  %t486 = load i1, ptr %l214, !tbaa !21
  %t487 = xor i1 %t486, true
  br i1 %t487, label %bb96, label %bb97
bb96:
  store %olang.scope zeroinitializer, ptr %s25
  store { i64, ptr } { i64 1, ptr @.d22 }, ptr %l217, !tbaa !27
  %t490 = load { i64, ptr }, ptr %l217, !tbaa !27
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s25, ptr %l4, { i64, ptr } %t490)
  br label %bb98
bb97:
  br label %bb99
bb98:
  call void @__olang_scope_close(ptr %s25)
  br label %bb99
bb99:
  call void @__olang_scope_close(ptr %s23)
  br label %bb100
bb100:
  %t491 = load i64, ptr %l16, !tbaa !24
  %t492 = load i64, ptr %l32, !tbaa !24
  %t495 = add i64 %t491, %t492
  store i64 %t495, ptr %l16, !tbaa !24
  %t497 = getelementptr %"std/os:Output", ptr %l30, i32 0, i32 0
  %t498 = load i32, ptr %t497, !tbaa !23
  %t500 = icmp sgt i32 %t498, 1
  br i1 %t500, label %bb101, label %bb102
bb101:
  store i32 2, ptr %l15, !tbaa !23
  br label %bb103
bb102:
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s19)
  br label %bb104
bb104:
  %t502 = load i64, ptr %l27, !tbaa !24
  %t504 = add i64 %t502, 1
  store i64 %t504, ptr %l27, !tbaa !24
  br label %bb69
bb105:
  %t506 = load i32, ptr %l15, !tbaa !23
  %t508 = icmp ne i32 %t506, 0
  br i1 %t508, label %bb106, label %bb107
bb106:
  call void @__olang_scope_close(ptr %s15)
  br label %bb110
bb107:
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s15)
  br label %bb109
bb109:
  %t510 = load i64, ptr %l18, !tbaa !24
  %t512 = add i64 %t510, 1
  store i64 %t512, ptr %l18, !tbaa !24
  br label %bb54
bb110:
  call void @__olang_scope_close(ptr %s14)
  store i64 0, ptr %l33, !tbaa !24
  store i64 0, ptr %l34, !tbaa !24
  %t514 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t516 = extractvalue { i64, ptr } %t514, 0
  store i64 %t516, ptr %l35, !tbaa !24
  store i64 1, ptr %l36, !tbaa !24
  %t518 = load i64, ptr %l35, !tbaa !24
  %t519 = load i64, ptr %l34, !tbaa !24
  %t522 = icmp sgt i64 %t518, %t519
  br i1 %t522, label %bb111, label %bb112
bb111:
  %t524 = load i64, ptr %l36, !tbaa !24
  %t526 = icmp sgt i64 %t524, 0
  br i1 %t526, label %bb113, label %bb114
bb112:
  store i64 0, ptr %l234, !tbaa !24
  br label %bb116
bb113:
  %t528 = load i64, ptr %l35, !tbaa !24
  %t529 = load i64, ptr %l34, !tbaa !24
  %t532 = sub i64 %t528, %t529
  %t533 = load i64, ptr %l36, !tbaa !24
  %t536 = add i64 %t532, %t533
  %t538 = sub i64 %t536, 1
  %t539 = load i64, ptr %l36, !tbaa !24
  %t542 = sdiv i64 %t538, %t539
  store i64 %t542, ptr %l237, !tbaa !24
  br label %bb115
bb114:
  store i64 0, ptr %l237, !tbaa !24
  br label %bb115
bb115:
  %t544 = load i64, ptr %l237, !tbaa !24
  store i64 %t544, ptr %l234, !tbaa !24
  br label %bb116
bb116:
  %t545 = load i64, ptr %l234, !tbaa !24
  store i64 %t545, ptr %l37, !tbaa !24
  store i64 0, ptr %l38, !tbaa !24
  br label %bb117
bb117:
  store %olang.scope zeroinitializer, ptr %s31
  %t546 = load i64, ptr %l38, !tbaa !24
  %t547 = load i64, ptr %l37, !tbaa !24
  %t550 = icmp slt i64 %t546, %t547
  %t552 = xor i1 %t550, true
  br i1 %t552, label %bb118, label %bb119
bb118:
  call void @__olang_scope_close(ptr %s31)
  br label %bb145
bb119:
  br label %bb120
bb120:
  %t554 = load i64, ptr %l34, !tbaa !24
  %t555 = load i64, ptr %l38, !tbaa !24
  %t556 = load i64, ptr %l36, !tbaa !24
  %t559 = mul i64 %t555, %t556
  %t562 = add i64 %t554, %t559
  store i64 %t562, ptr %l39, !tbaa !24
  %t564 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t564, ptr %l256, !tbaa !27
  %t565 = load i64, ptr %l39, !tbaa !24
  %t567 = getelementptr { i64, ptr }, ptr %l256, i32 0, i32 1
  %t568 = load ptr, ptr %t567, !tbaa !27
  %t569 = getelementptr { i64, ptr }, ptr %t568, i64 %t565
  %t570 = load { i64, ptr }, ptr %t569, !tbaa !37
  %t572 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s31, { i64, ptr } %t570)
  %t573 = extractvalue { i32, { i64, ptr } } %t572, 1
  %t574 = extractvalue { i32, { i64, ptr } } %t572, 0
  store i32 %t574, ptr %l260
  %t575 = icmp ne i32 %t574, 0
  br i1 %t575, label %bb122, label %ok.576
ok.576:
  store { i64, ptr } %t573, ptr %l259
  br label %bb121
bb121:
  %t577 = load { i64, ptr }, ptr %l259, !tbaa !27
  store { i64, ptr } %t577, ptr %l255, !tbaa !27
  br label %bb126
bb122:
  %t578 = load i32, ptr %l260, !tbaa !23
  %t579 = ashr i32 %t578, 16
  %t581 = icmp eq i32 %t579, 1
  br i1 %t581, label %bb123, label %bb124
bb123:
  br label %bb125
bb124:
  call void @__olang_check_failed(ptr @olang_loc_eb8a0402c99d9b5e_35ace7251e3366aa)
  unreachable
bb125:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s31)
  br label %bb144
bb126:
  %t583 = load { i64, ptr }, ptr %l255, !tbaa !27
  store { i64, ptr } %t583, ptr %l263, !tbaa !27
  %t585 = load i64, ptr %l39, !tbaa !24
  %t588 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s0, ptr %l7, i64 %t585)
  store { i64, ptr } %t588, ptr %l266
  br label %bb127
bb127:
  %t589 = load { i64, ptr }, ptr %l263, !tbaa !27
  %t590 = load { i64, ptr }, ptr %l266, !tbaa !27
  %t591 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s31, ptr %s0, { i64, ptr } %t589, { i64, ptr } %t590)
  store i1 %t591, ptr %l267
  br label %bb128
bb128:
  %t592 = load i1, ptr %l267, !tbaa !21
  br i1 %t592, label %bb129, label %bb130
bb129:
  call void @__olang_scope_close(ptr %s31)
  br label %bb144
bb130:
  br label %bb131
bb131:
  %t593 = load i64, ptr %l33, !tbaa !24
  %t595 = add i64 %t593, 1
  store i64 %t595, ptr %l33, !tbaa !24
  %t597 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t597, ptr %l271, !tbaa !27
  %t598 = load i64, ptr %l39, !tbaa !24
  %t600 = getelementptr { i64, ptr }, ptr %l271, i32 0, i32 1
  %t601 = load ptr, ptr %t600, !tbaa !27
  %t602 = getelementptr { i64, ptr }, ptr %t601, i64 %t598
  %t603 = load { i64, ptr }, ptr %t602, !tbaa !37
  %t605 = extractvalue { i64, ptr } %t603, 1
  %t606 = extractvalue { i64, ptr } %t603, 0
  %t607 = extractvalue { i64, ptr } { i64 1, ptr @.d23 }, 1
  %t608 = extractvalue { i64, ptr } { i64 1, ptr @.d23 }, 0
  %t609 = add i64 %t606, %t608
  %t610 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t609)
  call void @olang_textcopy(ptr %t610, ptr %t605, i64 %t606)
  %t611 = getelementptr i8, ptr %t610, i64 %t606
  call void @olang_textcopy(ptr %t611, ptr %t607, i64 %t608)
  %t612 = insertvalue { i64, ptr } undef, i64 %t609, 0
  %t613 = insertvalue { i64, ptr } %t612, ptr %t610, 1
  %t616 = extractvalue { i64, ptr } %t613, 0
  %t617 = extractvalue { i64, ptr } %t613, 1
  %t618 = mul i64 %t616, 1
  %t619 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t618)
  call void @llvm.memcpy.p0.p0.i64(ptr %t619, ptr %t617, i64 %t618, i1 false)
  %t620 = insertvalue { i64, ptr } undef, i64 %t616, 0
  %t621 = insertvalue { i64, ptr } %t620, ptr %t619, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s31, ptr %l5, { i64, ptr } %t621)
  br label %bb132
bb132:
  %t624 = load i1, ptr %l0, !tbaa !21
  br i1 %t624, label %bb133, label %bb134
bb133:
  store %olang.scope zeroinitializer, ptr %s35
  %t626 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t626, ptr %l278, !tbaa !27
  %t627 = load i64, ptr %l39, !tbaa !24
  %t629 = getelementptr { i64, ptr }, ptr %l278, i32 0, i32 1
  %t630 = load ptr, ptr %t629, !tbaa !27
  %t631 = getelementptr { i64, ptr }, ptr %t630, i64 %t627
  %t632 = load { i64, ptr }, ptr %t631, !tbaa !37
  store { i64, ptr } %t632, ptr %l280, !tbaa !27
  %t633 = load i64, ptr %l39, !tbaa !24
  %t636 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s35, ptr %l7, i64 %t633)
  store { i64, ptr } %t636, ptr %l283
  br label %bb135
bb134:
  br label %bb143
bb135:
  %t637 = load { i64, ptr }, ptr %l283, !tbaa !27
  %t638 = load { i64, ptr }, ptr %l280, !tbaa !27
  %t640 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s35, { i64, ptr } %t638, { i64, ptr } %t637)
  store i32 %t640, ptr %l285
  %t641 = icmp ne i32 %t640, 0
  br i1 %t641, label %bb137, label %ok.642
ok.642:
  br label %bb136
bb136:
  br label %bb142
bb137:
  %t643 = load i32, ptr %l285, !tbaa !23
  %t644 = ashr i32 %t643, 16
  %t646 = icmp eq i32 %t644, 1
  br i1 %t646, label %bb138, label %bb139
bb138:
  br label %bb140
bb139:
  call void @__olang_check_failed(ptr @olang_loc_f68d3ad0be646bb1_542defd6f5c5cce5)
  unreachable
bb140:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s36
  %t648 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t648, ptr %l289, !tbaa !27
  %t649 = load i64, ptr %l39, !tbaa !24
  %t651 = getelementptr { i64, ptr }, ptr %l289, i32 0, i32 1
  %t652 = load ptr, ptr %t651, !tbaa !27
  %t653 = getelementptr { i64, ptr }, ptr %t652, i64 %t649
  %t654 = load { i64, ptr }, ptr %t653, !tbaa !37
  %t655 = extractvalue { i64, ptr } { i64 7, ptr @.d24 }, 1
  %t656 = extractvalue { i64, ptr } { i64 7, ptr @.d24 }, 0
  %t658 = extractvalue { i64, ptr } %t654, 1
  %t659 = extractvalue { i64, ptr } %t654, 0
  %t660 = add i64 %t656, %t659
  %t661 = extractvalue { i64, ptr } { i64 20, ptr @.d25 }, 1
  %t662 = extractvalue { i64, ptr } { i64 20, ptr @.d25 }, 0
  %t663 = add i64 %t660, %t662
  %t664 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t663)
  call void @olang_textcopy(ptr %t664, ptr %t655, i64 %t656)
  %t665 = getelementptr i8, ptr %t664, i64 %t656
  call void @olang_textcopy(ptr %t665, ptr %t658, i64 %t659)
  %t666 = getelementptr i8, ptr %t665, i64 %t659
  call void @olang_textcopy(ptr %t666, ptr %t661, i64 %t662)
  %t667 = insertvalue { i64, ptr } undef, i64 %t663, 0
  %t668 = insertvalue { i64, ptr } %t667, ptr %t664, 1
  %t671 = extractvalue { i64, ptr } %t668, 0
  %t672 = extractvalue { i64, ptr } %t668, 1
  %t673 = mul i64 %t671, 1
  %t674 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t673)
  call void @llvm.memcpy.p0.p0.i64(ptr %t674, ptr %t672, i64 %t673, i1 false)
  %t675 = insertvalue { i64, ptr } undef, i64 %t671, 0
  %t676 = insertvalue { i64, ptr } %t675, ptr %t674, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s36, ptr %l4, { i64, ptr } %t676)
  br label %bb141
bb141:
  call void @__olang_scope_close(ptr %s36)
  br label %bb142
bb142:
  call void @__olang_scope_close(ptr %s35)
  br label %bb143
bb143:
  call void @__olang_scope_close(ptr %s31)
  br label %bb144
bb144:
  %t679 = load i64, ptr %l38, !tbaa !24
  %t681 = add i64 %t679, 1
  store i64 %t681, ptr %l38, !tbaa !24
  br label %bb117
bb145:
  %t683 = load i64, ptr %l16, !tbaa !24
  %t685 = icmp sgt i64 %t683, 0
  br i1 %t685, label %bb146, label %bb147
bb146:
  %t687 = load i32, ptr %l15, !tbaa !23
  %t689 = icmp eq i32 %t687, 0
  store i1 %t689, ptr %l299, !tbaa !21
  br label %bb148
bb147:
  store i1 false, ptr %l299, !tbaa !21
  br label %bb148
bb148:
  %t691 = load i1, ptr %l299, !tbaa !21
  br i1 %t691, label %bb149, label %bb150
bb149:
  store %olang.scope zeroinitializer, ptr %s39
  %t692 = load i64, ptr %l16, !tbaa !24
  %t694 = icmp eq i64 %t692, 1
  br i1 %t694, label %bb151, label %bb152
bb150:
  br label %bb155
bb151:
  store { i64, ptr } { i64 0, ptr @.d26 }, ptr %l304, !tbaa !27
  br label %bb153
bb152:
  store { i64, ptr } { i64 1, ptr @.d27 }, ptr %l304, !tbaa !27
  br label %bb153
bb153:
  %t696 = load { i64, ptr }, ptr %l304, !tbaa !27
  %t697 = load i64, ptr %l16, !tbaa !24
  %t699 = extractvalue { i64, ptr } { i64 11, ptr @.d28 }, 1
  %t700 = extractvalue { i64, ptr } { i64 11, ptr @.d28 }, 0
  %t702 = call i64 @__olang_fmt_i64(ptr null, i64 %t697)
  %t703 = add i64 %t700, %t702
  %t704 = extractvalue { i64, ptr } { i64 6, ptr @.d29 }, 1
  %t705 = extractvalue { i64, ptr } { i64 6, ptr @.d29 }, 0
  %t706 = add i64 %t703, %t705
  %t708 = extractvalue { i64, ptr } %t696, 1
  %t709 = extractvalue { i64, ptr } %t696, 0
  %t710 = add i64 %t706, %t709
  %t711 = extractvalue { i64, ptr } { i64 89, ptr @.d30 }, 1
  %t712 = extractvalue { i64, ptr } { i64 89, ptr @.d30 }, 0
  %t713 = add i64 %t710, %t712
  %t714 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t713)
  call void @olang_textcopy(ptr %t714, ptr %t699, i64 %t700)
  %t715 = getelementptr i8, ptr %t714, i64 %t700
  %t716 = call i64 @__olang_fmt_i64(ptr %t715, i64 %t697)
  %t717 = getelementptr i8, ptr %t715, i64 %t702
  call void @olang_textcopy(ptr %t717, ptr %t704, i64 %t705)
  %t718 = getelementptr i8, ptr %t717, i64 %t705
  call void @olang_textcopy(ptr %t718, ptr %t708, i64 %t709)
  %t719 = getelementptr i8, ptr %t718, i64 %t709
  call void @olang_textcopy(ptr %t719, ptr %t711, i64 %t712)
  %t720 = insertvalue { i64, ptr } undef, i64 %t713, 0
  %t721 = insertvalue { i64, ptr } %t720, ptr %t714, 1
  %t724 = extractvalue { i64, ptr } %t721, 0
  %t725 = extractvalue { i64, ptr } %t721, 1
  %t726 = mul i64 %t724, 1
  %t727 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t726)
  call void @llvm.memcpy.p0.p0.i64(ptr %t727, ptr %t725, i64 %t726, i1 false)
  %t728 = insertvalue { i64, ptr } undef, i64 %t724, 0
  %t729 = insertvalue { i64, ptr } %t728, ptr %t727, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s39, ptr %l4, { i64, ptr } %t729)
  br label %bb154
bb154:
  call void @__olang_scope_close(ptr %s39)
  br label %bb155
bb155:
  %t733 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l5)
  store i32 %t733, ptr %l312
  %t734 = icmp ne i32 %t733, 0
  br i1 %t734, label %bb157, label %ok.735
ok.735:
  br label %bb156
bb156:
  br label %bb161
bb157:
  %t736 = load i32, ptr %l312, !tbaa !23
  %t737 = ashr i32 %t736, 16
  %t739 = icmp eq i32 %t737, 1
  br i1 %t739, label %bb158, label %bb159
bb158:
  br label %bb160
bb159:
  call void @__olang_check_failed(ptr @olang_loc_553f258c1fa4e7a0_ff2b7e647292c5b4)
  unreachable
bb160:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb161:
  %t743 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l4)
  store i32 %t743, ptr %l317
  %t744 = icmp ne i32 %t743, 0
  br i1 %t744, label %bb163, label %ok.745
ok.745:
  br label %bb162
bb162:
  br label %bb167
bb163:
  %t746 = load i32, ptr %l317, !tbaa !23
  %t747 = ashr i32 %t746, 16
  %t749 = icmp eq i32 %t747, 1
  br i1 %t749, label %bb164, label %bb165
bb164:
  br label %bb166
bb165:
  call void @__olang_check_failed(ptr @olang_loc_96d60822e5550738_7384588370384e4)
  unreachable
bb166:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb167:
  %t752 = load i32, ptr %l15, !tbaa !23
  %t754 = icmp ne i32 %t752, 0
  br i1 %t754, label %bb168, label %bb169
bb168:
  %t756 = load i32, ptr %l15, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t756, ptr %rv
  br label %ret
bb169:
  br label %bb170
bb170:
  %t758 = load i1, ptr %l0, !tbaa !21
  br i1 %t758, label %bb171, label %bb172
bb171:
  %t760 = load i64, ptr %l33, !tbaa !24
  %t762 = icmp sgt i64 %t760, 0
  store i1 %t762, ptr %l325, !tbaa !21
  br label %bb173
bb172:
  store i1 false, ptr %l325, !tbaa !21
  br label %bb173
bb173:
  %t764 = load i1, ptr %l325, !tbaa !21
  br i1 %t764, label %bb174, label %bb175
bb174:
  store i1 true, ptr %l328, !tbaa !21
  br label %bb176
bb175:
  %t765 = load i64, ptr %l16, !tbaa !24
  %t767 = icmp sgt i64 %t765, 0
  store i1 %t767, ptr %l328, !tbaa !21
  br label %bb176
bb176:
  %t769 = load i1, ptr %l328, !tbaa !21
  br i1 %t769, label %bb177, label %bb178
bb177:
  store i32 1, ptr %l331, !tbaa !23
  br label %bb179
bb178:
  store i32 0, ptr %l331, !tbaa !23
  br label %bb179
bb179:
  call void @__olang_scope_close(ptr %s0)
  %t770 = load i32, ptr %l331, !tbaa !23
  store i32 %t770, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ffix_2eOrder(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l23 = alloca [19 x { i64, ptr }]
  %l28 = alloca i64
  %l31 = alloca i64
  %l51 = alloca i1
  %l53 = alloca i1
  %l62 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l64 = alloca i64
  %l65 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l11
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l0
  store %olang.scope zeroinitializer, ptr %s1
  %t4 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } { i64 4, ptr @.d31 }, 0
  %t5 = insertvalue [2 x { i64, ptr }] %t4, { i64, ptr } { i64 6, ptr @.d32 }, 1
  %t7 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store [2 x { i64, ptr }] %t5, ptr %t7
  store ptr %t7, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t9 = load ptr, ptr %l1
  store i64 2, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t12 = load i64, ptr %l2, !tbaa !24
  %t13 = load i64, ptr %l3, !tbaa !24
  %t16 = icmp slt i64 %t12, %t13
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb4:
  br label %bb5
bb5:
  %t20 = load ptr, ptr %l1
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = getelementptr [2 x { i64, ptr }], ptr %t20, i64 0, i64 %t21
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !37
  store { i64, ptr } %t25, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l23, ptr @G_2ecompiler_2ffix_2eToolNames, i64 304, i1 false)
  %t27 = load [19 x { i64, ptr }], ptr %l23
  store i64 19, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t29 = load i64, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = icmp sgt i64 %t29, %t30
  br i1 %t33, label %bb6, label %bb7
bb6:
  %t35 = load i64, ptr %l7, !tbaa !24
  %t37 = icmp sgt i64 %t35, 0
  br i1 %t37, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb11
bb8:
  %t39 = load i64, ptr %l6, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = sub i64 %t39, %t40
  %t44 = load i64, ptr %l7, !tbaa !24
  %t47 = add i64 %t43, %t44
  %t49 = sub i64 %t47, 1
  %t50 = load i64, ptr %l7, !tbaa !24
  %t53 = sdiv i64 %t49, %t50
  store i64 %t53, ptr %l31, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb10
bb10:
  %t55 = load i64, ptr %l31, !tbaa !24
  store i64 %t55, ptr %l28, !tbaa !24
  br label %bb11
bb11:
  %t56 = load i64, ptr %l28, !tbaa !24
  store i64 %t56, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t57 = load i64, ptr %l9, !tbaa !24
  %t58 = load i64, ptr %l8, !tbaa !24
  %t61 = icmp slt i64 %t57, %t58
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb14:
  br label %bb15
bb15:
  %t65 = load i64, ptr %l5, !tbaa !24
  %t66 = load i64, ptr %l9, !tbaa !24
  %t67 = load i64, ptr %l7, !tbaa !24
  %t70 = mul i64 %t66, %t67
  %t73 = add i64 %t65, %t70
  store i64 %t73, ptr %l10, !tbaa !24
  %t75 = load i64, ptr %l10, !tbaa !24
  %t77 = getelementptr [19 x i64], ptr @G_2ecompiler_2ffix_2eToolKinds, i64 0, i64 %t75
  %t78 = load i64, ptr %t77, !tbaa !34
  %t80 = call i1 @compiler_2ffix_2edriven(i64 %t78)
  store i1 %t80, ptr %l51
  br label %bb16
bb16:
  %t81 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t82 = load ptr, ptr @__olang_prog_scope
  %t84 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t82, ptr %s4, { i64, ptr } %t81, { i64, ptr } { i64 6, ptr @.d33 })
  store i1 %t84, ptr %l53
  br label %bb17
bb17:
  %t85 = load i1, ptr %l51, !tbaa !21
  %t86 = load i1, ptr %l53, !tbaa !21
  %t87 = icmp eq i1 %t85, %t86
  br i1 %t87, label %bb18, label %bb19
bb18:
  %t89 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l0, i64 %t89)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb22:
  %t92 = load i64, ptr %l9, !tbaa !24
  %t94 = add i64 %t92, 1
  store i64 %t94, ptr %l9, !tbaa !24
  br label %bb12
bb23:
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb24:
  %t96 = load i64, ptr %l2, !tbaa !24
  %t98 = add i64 %t96, 1
  store i64 %t98, ptr %l2, !tbaa !24
  br label %bb2
bb25:
  call void @__olang_scope_close(ptr %s1)
  %t101 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %v0, ptr %l0)
  store { i64, ptr } %t101, ptr %l62
  br label %bb26
bb26:
  %t102 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t102, ptr %l63, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 0
  store i64 %t104, ptr %l64, !tbaa !24
  %t105 = load i64, ptr %l64, !tbaa !24
  %t106 = mul i64 %t105, 8
  %t107 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t106)
  %t108 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t107, 1
  store { i64, ptr } %t109, ptr %l65, !tbaa !27
  %t110 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = load i64, ptr %l64, !tbaa !24
  %t115 = mul i64 %t114, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t111, ptr %t113, i64 %t115, i1 false)
  %t116 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t116, ptr %l63, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t117 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t117, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ffix_2eStdTool_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr @G_2ecompiler_2ffix_2eStdTool, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffix_2eTextTool_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr @G_2ecompiler_2ffix_2eTextTool, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffix_2eToolKinds_2einit() #0 {
entry:
  %l0 = alloca [19 x i64]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr [19 x i64], ptr %l0, i64 0, i64 0
  store i64 1, ptr %t1
  %t2 = getelementptr [19 x i64], ptr %l0, i64 0, i64 1
  store i64 2, ptr %t2
  %t3 = getelementptr [19 x i64], ptr %l0, i64 0, i64 2
  store i64 2, ptr %t3
  %t4 = getelementptr [19 x i64], ptr %l0, i64 0, i64 3
  store i64 3, ptr %t4
  %t5 = getelementptr [19 x i64], ptr %l0, i64 0, i64 4
  store i64 0, ptr %t5
  %t6 = getelementptr [19 x i64], ptr %l0, i64 0, i64 5
  store i64 0, ptr %t6
  %t7 = getelementptr [19 x i64], ptr %l0, i64 0, i64 6
  store i64 0, ptr %t7
  %t8 = getelementptr [19 x i64], ptr %l0, i64 0, i64 7
  store i64 0, ptr %t8
  %t9 = getelementptr [19 x i64], ptr %l0, i64 0, i64 8
  store i64 0, ptr %t9
  %t10 = getelementptr [19 x i64], ptr %l0, i64 0, i64 9
  store i64 0, ptr %t10
  %t11 = getelementptr [19 x i64], ptr %l0, i64 0, i64 10
  store i64 0, ptr %t11
  %t12 = getelementptr [19 x i64], ptr %l0, i64 0, i64 11
  store i64 0, ptr %t12
  %t13 = getelementptr [19 x i64], ptr %l0, i64 0, i64 12
  store i64 2, ptr %t13
  %t14 = getelementptr [19 x i64], ptr %l0, i64 0, i64 13
  store i64 0, ptr %t14
  %t15 = getelementptr [19 x i64], ptr %l0, i64 0, i64 14
  store i64 0, ptr %t15
  %t16 = getelementptr [19 x i64], ptr %l0, i64 0, i64 15
  store i64 0, ptr %t16
  %t17 = getelementptr [19 x i64], ptr %l0, i64 0, i64 16
  store i64 0, ptr %t17
  %t18 = getelementptr [19 x i64], ptr %l0, i64 0, i64 17
  store i64 0, ptr %t18
  %t19 = getelementptr [19 x i64], ptr %l0, i64 0, i64 18
  store i64 2, ptr %t19
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2ffix_2eToolKinds, ptr %l0, i64 152, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffix_2eToolNames_2einit() #0 {
entry:
  %l0 = alloca [19 x { i64, ptr }]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr [19 x { i64, ptr }], ptr %l0, i64 0, i64 0
  store { i64, ptr } { i64 13, ptr @.d34 }, ptr %t1
  %t2 = getelementptr [19 x { i64, ptr }], ptr %l0, i64 0, i64 1
  store { i64, ptr } { i64 8, ptr @.d35 }, ptr %t2
  %t3 = getelementptr [19 x { i64, ptr }], ptr %l0, i64 0, i64 2
  store { i64, ptr } { i64 15, ptr @.d36 }, ptr %t3
  %t4 = getelementptr [19 x { i64, ptr }], ptr %l0, i64 0, i64 3
  store { i64, ptr } { i64 14, ptr @.d37 }, ptr %t4
  %t5 = getelementptr [19 x { i64, ptr }], ptr %l0, i64 0, i64 4
  store { i64, ptr } { i64 9, ptr @.d38 }, ptr %t5
  %t6 = getelementptr [19 x { i64, ptr }], ptr %l0, i64 0, i64 5
  store { i64, ptr } { i64 16, ptr @.d39 }, ptr %t6
  %t7 = getelementptr [19 x { i64, ptr }], ptr %l0, i64 0, i64 6
  store { i64, ptr } { i64 14, ptr @.d40 }, ptr %t7
  %t8 = getelementptr [19 x { i64, ptr }], ptr %l0, i64 0, i64 7
  store { i64, ptr } { i64 12, ptr @.d41 }, ptr %t8
  %t9 = getelementptr [19 x { i64, ptr }], ptr %l0, i64 0, i64 8
  store { i64, ptr } { i64 14, ptr @.d42 }, ptr %t9
  %t10 = getelementptr [19 x { i64, ptr }], ptr %l0, i64 0, i64 9
  store { i64, ptr } { i64 15, ptr @.d43 }, ptr %t10
  %t11 = getelementptr [19 x { i64, ptr }], ptr %l0, i64 0, i64 10
  store { i64, ptr } { i64 16, ptr @.d44 }, ptr %t11
  %t12 = getelementptr [19 x { i64, ptr }], ptr %l0, i64 0, i64 11
  store { i64, ptr } { i64 13, ptr @.d45 }, ptr %t12
  %t13 = getelementptr [19 x { i64, ptr }], ptr %l0, i64 0, i64 12
  store { i64, ptr } { i64 12, ptr @.d46 }, ptr %t13
  %t14 = getelementptr [19 x { i64, ptr }], ptr %l0, i64 0, i64 13
  store { i64, ptr } { i64 17, ptr @.d47 }, ptr %t14
  %t15 = getelementptr [19 x { i64, ptr }], ptr %l0, i64 0, i64 14
  store { i64, ptr } { i64 14, ptr @.d48 }, ptr %t15
  %t16 = getelementptr [19 x { i64, ptr }], ptr %l0, i64 0, i64 15
  store { i64, ptr } { i64 15, ptr @.d49 }, ptr %t16
  %t17 = getelementptr [19 x { i64, ptr }], ptr %l0, i64 0, i64 16
  store { i64, ptr } { i64 17, ptr @.d50 }, ptr %t17
  %t18 = getelementptr [19 x { i64, ptr }], ptr %l0, i64 0, i64 17
  store { i64, ptr } { i64 11, ptr @.d51 }, ptr %t18
  %t19 = getelementptr [19 x { i64, ptr }], ptr %l0, i64 0, i64 18
  store { i64, ptr } { i64 10, ptr @.d52 }, ptr %t19
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2ffix_2eToolNames, ptr %l0, i64 304, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ffix_2eToolsDir(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l9 = alloca i1
  %l14 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 11, ptr @.d53 })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l4
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  store { i64, ptr } %t2, ptr %l3
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr @.d54 }, ptr %l5, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t10 = extractvalue { i64, ptr } %t7, 1
  %t11 = mul i64 %t9, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t10, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  br label %bb4
bb4:
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t16, ptr %l1, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t17, { i64, ptr } { i64 0, ptr @.d55 })
  store i1 %t19, ptr %l9
  br label %bb5
bb5:
  %t20 = load i1, ptr %l9, !tbaa !21
  %t21 = xor i1 %t20, true
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = extractvalue { i64, ptr } %t23, 0
  %t27 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t25, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t29, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t33 = call { i64, ptr } @std_2ffilepath_2eDir(ptr %v0, { i64, ptr } %a0)
  store { i64, ptr } %t33, ptr %l14
  br label %bb9
bb9:
  %t34 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 1
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t37 = extractvalue { i64, ptr } { i64 9, ptr @.d56 }, 1
  %t38 = extractvalue { i64, ptr } { i64 9, ptr @.d56 }, 0
  %t39 = add i64 %t36, %t38
  %t40 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t39)
  call void @olang_textcopy(ptr %t40, ptr %t35, i64 %t36)
  %t41 = getelementptr i8, ptr %t40, i64 %t36
  call void @olang_textcopy(ptr %t41, ptr %t37, i64 %t38)
  %t42 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t40, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t43, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ffix_2earguments(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %lp5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l45 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca { i64, ptr }
  %s11 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l10
  br label %bb1
bb1:
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 8, i64 8)
  store ptr %t3, ptr %lp5
  %t4 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  %t5 = load ptr, ptr %lp5
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %t5
  %t6 = load ptr, ptr %lp5
  %t9 = extractvalue { i64, ptr } %a0, 1
  %t10 = extractvalue { i64, ptr } %a0, 0
  %t11 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t9, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t16 = extractvalue { i64, ptr } %t13, 1
  %t17 = mul i64 %t15, 1
  %t18 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t16, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v4, ptr %v4, ptr %t6, { i64, ptr } %t20)
  br label %bb2
bb2:
  %t23 = load i64, ptr %l1, !tbaa !24
  %t24 = load i64, ptr @G_2ecompiler_2ffix_2eStdTool, !tbaa !24
  %t27 = icmp eq i64 %t23, %t24
  br i1 %t27, label %bb3, label %bb4
bb3:
  %t29 = load ptr, ptr %lp5
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v4, ptr %v4, ptr %t29, { i64, ptr } { i64 5, ptr @.d57 })
  br label %bb5
bb4:
  %t31 = load i64, ptr %l1, !tbaa !24
  %t32 = load i64, ptr @G_2ecompiler_2ffix_2eDrivenOpt, !tbaa !24
  %t35 = icmp eq i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb5:
  %t37 = load ptr, ptr %lp5
  %t40 = extractvalue { i64, ptr } %a3, 1
  %t41 = extractvalue { i64, ptr } %a3, 0
  %t42 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t41)
  call void @olang_textcopy(ptr %t42, ptr %t40, i64 %t41)
  %t43 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t47 = extractvalue { i64, ptr } %t44, 1
  %t48 = mul i64 %t46, 1
  %t49 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t48)
  call void @llvm.memcpy.p0.p0.i64(ptr %t49, ptr %t47, i64 %t48, i1 false)
  %t50 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v4, ptr %v4, ptr %t37, { i64, ptr } %t51)
  br label %bb6
bb6:
  br label %bb16
bb7:
  %t54 = load ptr, ptr %lp5
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v4, ptr %v4, ptr %t54, { i64, ptr } { i64 7, ptr @.d58 })
  br label %bb9
bb8:
  %t56 = load i64, ptr %l1, !tbaa !24
  %t57 = load i64, ptr @G_2ecompiler_2ffix_2eDrivenArg, !tbaa !24
  %t60 = icmp eq i64 %t56, %t57
  br i1 %t60, label %bb11, label %bb12
bb9:
  %t62 = load ptr, ptr %lp5
  %t63 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t63, 1
  %t66 = extractvalue { i64, ptr } %t63, 0
  %t67 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t66)
  call void @olang_textcopy(ptr %t67, ptr %t65, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  %t71 = extractvalue { i64, ptr } %t69, 0
  %t72 = extractvalue { i64, ptr } %t69, 1
  %t73 = mul i64 %t71, 1
  %t74 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t73)
  call void @llvm.memcpy.p0.p0.i64(ptr %t74, ptr %t72, i64 %t73, i1 false)
  %t75 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v4, ptr %v4, ptr %t62, { i64, ptr } %t76)
  br label %bb10
bb10:
  br label %bb15
bb11:
  %t79 = load ptr, ptr %lp5
  %t80 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t80, 1
  %t83 = extractvalue { i64, ptr } %t80, 0
  %t84 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t83)
  call void @olang_textcopy(ptr %t84, ptr %t82, i64 %t83)
  %t85 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = extractvalue { i64, ptr } %t86, 1
  %t90 = mul i64 %t88, 1
  %t91 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t90)
  call void @llvm.memcpy.p0.p0.i64(ptr %t91, ptr %t89, i64 %t90, i1 false)
  %t92 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v4, ptr %v4, ptr %t79, { i64, ptr } %t93)
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  store { i64, ptr } %a4, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t98 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t98, 0
  store i64 %t100, ptr %l8, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s11
  %t102 = load i64, ptr %l7, !tbaa !24
  %t103 = load i64, ptr %l8, !tbaa !24
  %t106 = icmp slt i64 %t102, %t103
  %t108 = xor i1 %t106, true
  br i1 %t108, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s11)
  br label %bb23
bb19:
  br label %bb20
bb20:
  %t110 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t110, ptr %l45, !tbaa !27
  %t111 = load i64, ptr %l7, !tbaa !24
  %t113 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr { i64, ptr }, ptr %t114, i64 %t111
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !37
  %t118 = load ptr, ptr %lp5
  %t121 = extractvalue { i64, ptr } %t116, 1
  %t122 = extractvalue { i64, ptr } %t116, 0
  %t123 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t122)
  call void @olang_textcopy(ptr %t123, ptr %t121, i64 %t122)
  %t124 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t123, 1
  %t127 = extractvalue { i64, ptr } %t125, 0
  %t128 = extractvalue { i64, ptr } %t125, 1
  %t129 = mul i64 %t127, 1
  %t130 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t129)
  call void @llvm.memcpy.p0.p0.i64(ptr %t130, ptr %t128, i64 %t129, i1 false)
  %t131 = insertvalue { i64, ptr } undef, i64 %t127, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v4, ptr %v4, ptr %t118, { i64, ptr } %t132)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s11)
  br label %bb22
bb22:
  %t135 = load i64, ptr %l7, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l7, !tbaa !24
  br label %bb17
bb23:
  %t139 = load ptr, ptr %lp5
  %t141 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hd4bdf3befe2f7a35847f168802c5df68(ptr %v4, ptr %v4, ptr %t139)
  store { i64, ptr } %t141, ptr %l55
  br label %bb24
bb24:
  %t142 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t142, ptr %l56, !tbaa !27
  %t143 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t143, 0
  store i64 %t144, ptr %l57, !tbaa !24
  %t145 = load i64, ptr %l57, !tbaa !24
  %t146 = mul i64 %t145, 16
  %t147 = call ptr @__olang_scope_alloc_zeroed(ptr %v4, i64 %t146)
  %t148 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t147, 1
  store { i64, ptr } %t149, ptr %l58, !tbaa !27
  %t150 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = load i64, ptr %l57, !tbaa !24
  %t155 = mul i64 %t154, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t151, ptr %t153, i64 %t155, i1 false)
  %t156 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t156, ptr %l56, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t157, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ffix_2ebyHand(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca %"std/prelude/text:LineIter"
  %l4 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/text:LineIter"
  %l7 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l14 = alloca i1
  %l18 = alloca i1
  %l20 = alloca i1
  %l22 = alloca i1
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  store i1 false, ptr %l2, !tbaa !21
  %t3 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store %"std/prelude/text:LineIter" %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load %"std/prelude/text:LineIter", ptr %l6
  store %"std/prelude/text:LineIter" %t4, ptr %l3
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t6 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %l3)
  %t7 = extractvalue { i32, { i64, ptr } } %t6, 1
  %t8 = extractvalue { i32, { i64, ptr } } %t6, 0
  store i32 %t8, ptr %l10
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb4, label %ok.10
ok.10:
  store { i64, ptr } %t7, ptr %l9
  br label %bb3
bb3:
  %t11 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t11, ptr %l7, !tbaa !27
  br label %bb8
bb4:
  %t12 = load i32, ptr %l10, !tbaa !23
  %t13 = ashr i32 %t12, 16
  %t15 = icmp eq i32 %t13, 1
  br i1 %t15, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_e6e24e0024ea2a04_be8f31c3c206f038)
  unreachable
bb7:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb8:
  %t17 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t17, ptr %l4, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t20 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t18, { i64, ptr } { i64 8, ptr @.d59 })
  store i1 %t20, ptr %l14
  br label %bb9
bb9:
  %t21 = load i1, ptr %l14, !tbaa !21
  br i1 %t21, label %bb10, label %bb11
bb10:
  %t22 = load i64, ptr %l1, !tbaa !24
  %t24 = add i64 %t22, 1
  store i64 %t24, ptr %l1, !tbaa !24
  br label %bb23
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t26 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t28 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t26, { i64, ptr } { i64 13, ptr @.d60 })
  store i1 %t28, ptr %l18
  br label %bb12
bb12:
  %t29 = load i1, ptr %l18, !tbaa !21
  br i1 %t29, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb22
bb14:
  store %olang.scope zeroinitializer, ptr %s6
  %t30 = load i1, ptr %l2, !tbaa !21
  br i1 %t30, label %bb15, label %bb16
bb15:
  %t32 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t34 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s6, { i64, ptr } %t32, { i64, ptr } { i64 2, ptr @.d61 })
  store i1 %t34, ptr %l22
  br label %bb17
bb16:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb18
bb17:
  %t35 = load i1, ptr %l22, !tbaa !21
  store i1 %t35, ptr %l20, !tbaa !21
  br label %bb18
bb18:
  %t36 = load i1, ptr %l20, !tbaa !21
  br i1 %t36, label %bb19, label %bb20
bb19:
  %t37 = load i64, ptr %l1, !tbaa !24
  %t39 = add i64 %t37, 1
  store i64 %t39, ptr %l1, !tbaa !24
  br label %bb21
bb20:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s6)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb24:
  br label %bb2
bb25:
  %t41 = load i64, ptr %l1, !tbaa !24
  store i64 %t41, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffix_2edriven(i64 %a0) #0 {
entry:
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i64, ptr @G_2ecompiler_2ffix_2eDrivenOpt, !tbaa !24
  %t5 = icmp sge i64 %a0, %t2
  store i1 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffix_2eensureBuilt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/os:Output"
  %l11 = alloca { i64, ptr }
  %l13 = alloca i64
  %l15 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l21 = alloca %"std/os:Output"
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l33 = alloca %"std/os:Output"
  %l34 = alloca i32
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t3 = extractvalue { i64, ptr } { i64 6, ptr @.d62 }, 1
  %t4 = extractvalue { i64, ptr } { i64 6, ptr @.d62 }, 0
  %t6 = extractvalue { i64, ptr } %t2, 1
  %t7 = extractvalue { i64, ptr } %t2, 0
  %t8 = add i64 %t4, %t7
  %t9 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t8)
  call void @olang_textcopy(ptr %t9, ptr %t3, i64 %t4)
  %t10 = getelementptr i8, ptr %t9, i64 %t4
  call void @olang_textcopy(ptr %t10, ptr %t6, i64 %t7)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t9, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t15 = extractvalue { i64, ptr } %t12, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  %t22 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %v2, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t1, { i64, ptr } %t19, { i64, ptr } { i64 0, ptr @.d63 }, { i64, ptr } { i64 0, ptr @.d64 }, { i64, ptr } { i64 0, ptr @.d65 }, { i64, ptr } { i64 0, ptr @.d66 })
  store { i64, ptr } %t22, ptr %l11
  br label %bb1
bb1:
  %t23 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t23, ptr %l5, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t26 = call i64 @compiler_2ffix_2emtime(ptr %s0, { i64, ptr } %t24)
  store i64 %t26, ptr %l13
  br label %bb2
bb2:
  %t27 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t29 = call i64 @compiler_2ffix_2emtime(ptr %v0, { i64, ptr } %t27)
  store i64 %t29, ptr %l15
  br label %bb3
bb3:
  %t30 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t32 = call i64 @compiler_2ffix_2enewest(ptr %v1, { i64, ptr } %t30)
  store i64 %t32, ptr %l17
  br label %bb4
bb4:
  %t33 = load i64, ptr %l15, !tbaa !24
  %t34 = load i64, ptr %l17, !tbaa !24
  %t35 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t33, i64 %t34)
  store i64 %t35, ptr %l18
  br label %bb5
bb5:
  %t36 = load i64, ptr %l13, !tbaa !24
  %t37 = load i64, ptr %l18, !tbaa !24
  %t38 = icmp sgt i64 %t36, %t37
  br i1 %t38, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t41 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t41, ptr %l22, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t42, ptr %l23, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 1
  %t47 = extractvalue { i64, ptr } %t44, 0
  %t48 = extractvalue { i64, ptr } { i64 6, ptr @.d67 }, 1
  %t49 = extractvalue { i64, ptr } { i64 6, ptr @.d67 }, 0
  %t50 = add i64 %t47, %t49
  %t51 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t50)
  call void @olang_textcopy(ptr %t51, ptr %t46, i64 %t47)
  %t52 = getelementptr i8, ptr %t51, i64 %t47
  call void @olang_textcopy(ptr %t52, ptr %t48, i64 %t49)
  %t53 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t51, 1
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t57 = extractvalue { i64, ptr } %t54, 1
  %t58 = mul i64 %t56, 1
  %t59 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t58)
  call void @llvm.memcpy.p0.p0.i64(ptr %t59, ptr %t57, i64 %t58, i1 false)
  %t60 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  %t64 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %v1, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t43, { i64, ptr } %t61, { i64, ptr } { i64 0, ptr @.d68 }, { i64, ptr } { i64 0, ptr @.d69 }, { i64, ptr } { i64 0, ptr @.d70 }, { i64, ptr } { i64 0, ptr @.d71 })
  store { i64, ptr } %t64, ptr %l28
  br label %bb9
bb9:
  %t65 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  %t67 = extractvalue { i64, ptr } %t65, 1
  %t68 = mul i64 %t66, 1
  %t69 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t68)
  call void @llvm.memcpy.p0.p0.i64(ptr %t69, ptr %t67, i64 %t68, i1 false)
  %t70 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  %t72 = mul i64 5, 16
  %t73 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 5, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  store { i64, ptr } %t75, ptr %l30, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t77 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %t78, i64 0
  store { i64, ptr } %t76, ptr %t79, !tbaa !37
  %t80 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr { i64, ptr }, ptr %t81, i64 1
  store { i64, ptr } { i64 5, ptr @.d72 }, ptr %t82, !tbaa !37
  %t83 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr { i64, ptr }, ptr %t84, i64 2
  store { i64, ptr } { i64 7, ptr @.d73 }, ptr %t85, !tbaa !37
  %t86 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t87 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr { i64, ptr }, ptr %t88, i64 3
  store { i64, ptr } %t86, ptr %t89, !tbaa !37
  %t91 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr { i64, ptr }, ptr %t92, i64 4
  store { i64, ptr } %t71, ptr %t93, !tbaa !37
  store { i64, ptr } { i64 0, ptr @.d74 }, ptr %l31, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t95 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t98 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s0, ptr %s0, ptr %v2, ptr %s0, { i64, ptr } %t95, { i64, ptr } %t96, i1 true, { i64, ptr } %t94)
  %t99 = extractvalue { i32, %"std/os:Output" } %t98, 1
  %t100 = extractvalue { i32, %"std/os:Output" } %t98, 0
  store i32 %t100, ptr %l34
  %t101 = icmp ne i32 %t100, 0
  br i1 %t101, label %bb11, label %ok.102
ok.102:
  store %"std/os:Output" %t99, ptr %l33
  br label %bb10
bb10:
  %t103 = load %"std/os:Output", ptr %l33
  store %"std/os:Output" %t103, ptr %l21
  br label %bb16
bb11:
  %t104 = load i32, ptr %l34, !tbaa !23
  %t105 = ashr i32 %t104, 16
  %t107 = icmp eq i32 %t105, 1
  br i1 %t107, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_9e1364cb140a9a66_28aa9a3ffa2ccf1a)
  unreachable
bb14:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s4
  %t109 = load ptr, ptr %l4, !tbaa !29
  %t110 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t111 = extractvalue { i64, ptr } { i64 23, ptr @.d75 }, 1
  %t112 = extractvalue { i64, ptr } { i64 23, ptr @.d75 }, 0
  %t114 = extractvalue { i64, ptr } %t110, 1
  %t115 = extractvalue { i64, ptr } %t110, 0
  %t116 = add i64 %t112, %t115
  %t117 = extractvalue { i64, ptr } { i64 1, ptr @.d76 }, 1
  %t118 = extractvalue { i64, ptr } { i64 1, ptr @.d76 }, 0
  %t119 = add i64 %t116, %t118
  %t120 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t119)
  call void @olang_textcopy(ptr %t120, ptr %t111, i64 %t112)
  %t121 = getelementptr i8, ptr %t120, i64 %t112
  call void @olang_textcopy(ptr %t121, ptr %t114, i64 %t115)
  %t122 = getelementptr i8, ptr %t121, i64 %t115
  call void @olang_textcopy(ptr %t122, ptr %t117, i64 %t118)
  %t123 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t120, 1
  %t127 = extractvalue { i64, ptr } %t124, 0
  %t128 = extractvalue { i64, ptr } %t124, 1
  %t129 = mul i64 %t127, 1
  %t130 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t129)
  call void @llvm.memcpy.p0.p0.i64(ptr %t130, ptr %t128, i64 %t129, i1 false)
  %t131 = insertvalue { i64, ptr } undef, i64 %t127, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v4, ptr %s4, ptr %t109, { i64, ptr } %t132)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb16:
  %t136 = load %"std/os:Output", ptr %l21
  store %"std/os:Output" %t136, ptr %l6
  %t137 = getelementptr %"std/os:Output", ptr %l6, i32 0, i32 0
  %t138 = load i32, ptr %t137, !tbaa !23
  %t140 = icmp ne i32 %t138, 0
  br i1 %t140, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  %t142 = load ptr, ptr %l4, !tbaa !29
  %t143 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t144 = getelementptr %"std/os:Output", ptr %l6, i32 0, i32 1
  %t145 = load { i64, ptr }, ptr %t144, !tbaa !27
  %t146 = getelementptr %"std/os:Output", ptr %l6, i32 0, i32 2
  %t147 = load { i64, ptr }, ptr %t146, !tbaa !27
  %t148 = extractvalue { i64, ptr } { i64 18, ptr @.d77 }, 1
  %t149 = extractvalue { i64, ptr } { i64 18, ptr @.d77 }, 0
  %t151 = extractvalue { i64, ptr } %t143, 1
  %t152 = extractvalue { i64, ptr } %t143, 0
  %t153 = add i64 %t149, %t152
  %t154 = extractvalue { i64, ptr } { i64 23, ptr @.d78 }, 1
  %t155 = extractvalue { i64, ptr } { i64 23, ptr @.d78 }, 0
  %t156 = add i64 %t153, %t155
  %t158 = extractvalue { i64, ptr } %t145, 1
  %t159 = extractvalue { i64, ptr } %t145, 0
  %t160 = add i64 %t156, %t159
  %t162 = extractvalue { i64, ptr } %t147, 1
  %t163 = extractvalue { i64, ptr } %t147, 0
  %t164 = add i64 %t160, %t163
  %t165 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t164)
  call void @olang_textcopy(ptr %t165, ptr %t148, i64 %t149)
  %t166 = getelementptr i8, ptr %t165, i64 %t149
  call void @olang_textcopy(ptr %t166, ptr %t151, i64 %t152)
  %t167 = getelementptr i8, ptr %t166, i64 %t152
  call void @olang_textcopy(ptr %t167, ptr %t154, i64 %t155)
  %t168 = getelementptr i8, ptr %t167, i64 %t155
  call void @olang_textcopy(ptr %t168, ptr %t158, i64 %t159)
  %t169 = getelementptr i8, ptr %t168, i64 %t159
  call void @olang_textcopy(ptr %t169, ptr %t162, i64 %t163)
  %t170 = insertvalue { i64, ptr } undef, i64 %t164, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t165, 1
  %t174 = extractvalue { i64, ptr } %t171, 0
  %t175 = extractvalue { i64, ptr } %t171, 1
  %t176 = mul i64 %t174, 1
  %t177 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t176)
  call void @llvm.memcpy.p0.p0.i64(ptr %t177, ptr %t175, i64 %t176, i1 false)
  %t178 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t177, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v4, ptr %s6, ptr %t142, { i64, ptr } %t179)
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb20:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffix_2eexpand(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %lp1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca { i64, ptr }
  %l18 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l6
  br label %bb1
bb1:
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t3, ptr %lp1
  %t4 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  %t5 = load ptr, ptr %lp1
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %t5
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  store i64 %t10, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = load i64, ptr %l4, !tbaa !24
  %t16 = icmp slt i64 %t12, %t13
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb4:
  br label %bb5
bb5:
  %t20 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t20, ptr %l14, !tbaa !27
  %t21 = load i64, ptr %l3, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %t24, i64 %t21
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !37
  store { i64, ptr } %t26, ptr %l5, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t30 = call i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %t28)
  store i1 %t30, ptr %l18
  br label %bb6
bb6:
  %t31 = load i1, ptr %l18, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t33 = load ptr, ptr %lp1
  call void @compiler_2ffix_2ewalk(ptr %v0, ptr %v1, { i64, ptr } %t32, ptr %t33)
  br label %bb9
bb8:
  %t36 = load ptr, ptr %lp1
  %t37 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 1
  %t40 = extractvalue { i64, ptr } %t37, 0
  %t41 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t40)
  call void @olang_textcopy(ptr %t41, ptr %t39, i64 %t40)
  %t42 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t46 = extractvalue { i64, ptr } %t43, 1
  %t47 = mul i64 %t45, 1
  %t48 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t47)
  call void @llvm.memcpy.p0.p0.i64(ptr %t48, ptr %t46, i64 %t47, i1 false)
  %t49 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t36, { i64, ptr } %t50)
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb12:
  %t53 = load i64, ptr %l3, !tbaa !24
  %t55 = add i64 %t53, 1
  store i64 %t55, ptr %l3, !tbaa !24
  br label %bb2
bb13:
  %t57 = load ptr, ptr %lp1
  %t58 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t57
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t58, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i64 @compiler_2ffix_2emtime(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/os:FileInfo"
  %l2 = alloca %"std/os:FileInfo"
  %l4 = alloca %"std/os:FileInfo"
  %l5 = alloca i32
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v0, { i64, ptr } %a0)
  %t4 = extractvalue { i32, %"std/os:FileInfo" } %t3, 1
  %t5 = extractvalue { i32, %"std/os:FileInfo" } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store %"std/os:FileInfo" %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load %"std/os:FileInfo", ptr %l4
  store %"std/os:FileInfo" %t8, ptr %l2
  br label %bb6
bb2:
  %t9 = load i32, ptr %l5, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  br i1 %t12, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_23f451298266bf5e_2593b028faf03d0a)
  unreachable
bb5:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %rv
  br label %ret
bb6:
  %t15 = load %"std/os:FileInfo", ptr %l2
  store %"std/os:FileInfo" %t15, ptr %l1
  %t16 = getelementptr %"std/os:FileInfo", ptr %l1, i32 0, i32 2
  %t17 = load i64, ptr %t16, !tbaa !24
  store i64 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ffix_2enewest(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l21 = alloca { i64, ptr }
  %l25 = alloca i1
  %l26 = alloca i64
  %l29 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %s0, { i64, ptr } %t1)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l10
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store { i64, ptr } %t4, ptr %l9
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t8, ptr %l7, !tbaa !27
  br label %bb8
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  %t9 = icmp sge i64 0, 0
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t11 = icmp sle i64 0, 576460752303423487
  br i1 %t11, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_8fcf87cfa7be21dd_bbd76dac3520f231)
  unreachable
bb6:
  %t13 = mul i64 0, 16
  %t14 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 0, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l7, !tbaa !27
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_8fcf87cfa7be21dd_bbd76dac3520f231)
  unreachable
bb8:
  %t18 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t18, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l5, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t25 = load i64, ptr %l4, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb11:
  br label %bb12
bb12:
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t33, ptr %l21, !tbaa !27
  %t34 = load i64, ptr %l4, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %t37, i64 %t34
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !37
  store { i64, ptr } %t39, ptr %l6, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t43 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s2, { i64, ptr } %t41, { i64, ptr } { i64 6, ptr @.d79 })
  store i1 %t43, ptr %l25
  br label %bb13
bb13:
  %t44 = load i1, ptr %l25, !tbaa !21
  br i1 %t44, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t45 = load i64, ptr %l1, !tbaa !24
  store i64 %t45, ptr %l26, !tbaa !24
  %t46 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t50 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %s0, ptr %s3, ptr %s3, ptr %s3, ptr %s3, ptr %s3, { i64, ptr } %t46, { i64, ptr } %t47, { i64, ptr } { i64 0, ptr @.d63 }, { i64, ptr } { i64 0, ptr @.d64 }, { i64, ptr } { i64 0, ptr @.d65 }, { i64, ptr } { i64 0, ptr @.d66 })
  store { i64, ptr } %t50, ptr %l29
  br label %bb16
bb15:
  br label %bb19
bb16:
  %t51 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t51, 0
  %t53 = extractvalue { i64, ptr } %t51, 1
  %t54 = mul i64 %t52, 1
  %t55 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t54)
  call void @llvm.memcpy.p0.p0.i64(ptr %t55, ptr %t53, i64 %t54, i1 false)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  %t59 = call i64 @compiler_2ffix_2emtime(ptr %s3, { i64, ptr } %t57)
  store i64 %t59, ptr %l31
  br label %bb17
bb17:
  %t60 = load i64, ptr %l26, !tbaa !24
  %t61 = load i64, ptr %l31, !tbaa !24
  %t62 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t60, i64 %t61)
  store i64 %t62, ptr %l32
  br label %bb18
bb18:
  %t63 = load i64, ptr %l32, !tbaa !24
  store i64 %t63, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  %t64 = load i64, ptr %l4, !tbaa !24
  %t66 = add i64 %t64, 1
  store i64 %t66, ptr %l4, !tbaa !24
  br label %bb9
bb21:
  %t68 = load i64, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t68, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffix_2ewalk(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i32
  %l22 = alloca { i64, ptr }
  %l26 = alloca i1
  %l27 = alloca i1
  %l29 = alloca i1
  %l32 = alloca { i64, ptr }
  %l34 = alloca i1
  %l38 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %s0, { i64, ptr } %t1)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l11
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store { i64, ptr } %t4, ptr %l10
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t8, ptr %l8, !tbaa !27
  br label %bb8
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  %t9 = icmp sge i64 0, 0
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t11 = icmp sle i64 0, 576460752303423487
  br i1 %t11, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_9433da86f750b978_3ff5b65d50af9d4)
  unreachable
bb6:
  %t13 = mul i64 0, 16
  %t14 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 0, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l8, !tbaa !27
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_9433da86f750b978_3ff5b65d50af9d4)
  unreachable
bb8:
  %t18 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t18, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l5, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t25 = load i64, ptr %l4, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb11:
  br label %bb12
bb12:
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t33, ptr %l22, !tbaa !27
  %t34 = load i64, ptr %l4, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %t37, i64 %t34
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !37
  store { i64, ptr } %t39, ptr %l6, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t43 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s2, { i64, ptr } %t41, { i64, ptr } { i64 1, ptr @.d80 })
  store i1 %t43, ptr %l26
  br label %bb13
bb13:
  %t44 = load i1, ptr %l26, !tbaa !21
  br i1 %t44, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb17
bb15:
  %t45 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t47 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s2, { i64, ptr } %t45, { i64, ptr } { i64 5, ptr @.d81 })
  store i1 %t47, ptr %l29
  br label %bb16
bb16:
  %t48 = load i1, ptr %l29, !tbaa !21
  store i1 %t48, ptr %l27, !tbaa !21
  br label %bb17
bb17:
  %t49 = load i1, ptr %l27, !tbaa !21
  br i1 %t49, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb19:
  br label %bb20
bb20:
  %t50 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t54 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %s0, ptr %s2, ptr %s2, ptr %s2, ptr %s2, ptr %s2, { i64, ptr } %t50, { i64, ptr } %t51, { i64, ptr } { i64 0, ptr @.d82 }, { i64, ptr } { i64 0, ptr @.d83 }, { i64, ptr } { i64 0, ptr @.d84 }, { i64, ptr } { i64 0, ptr @.d85 })
  store { i64, ptr } %t54, ptr %l32
  br label %bb21
bb21:
  %t55 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t55, ptr %l7, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t58 = call i1 @std_2fos_2eIsDir(ptr %s2, { i64, ptr } %t56)
  store i1 %t58, ptr %l34
  br label %bb22
bb22:
  %t59 = load i1, ptr %l34, !tbaa !21
  br i1 %t59, label %bb23, label %bb24
bb23:
  %t60 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t61 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ffix_2ewalk(ptr %s2, ptr %v1, { i64, ptr } %t60, ptr %t61)
  br label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t64 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t66 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s5, { i64, ptr } %t64, { i64, ptr } { i64 6, ptr @.d86 })
  store i1 %t66, ptr %l38
  br label %bb26
bb25:
  br label %bb31
bb26:
  %t67 = load i1, ptr %l38, !tbaa !21
  br i1 %t67, label %bb27, label %bb28
bb27:
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t69 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t69, 1
  %t72 = extractvalue { i64, ptr } %t69, 0
  %t73 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t72)
  call void @olang_textcopy(ptr %t73, ptr %t71, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  %t77 = extractvalue { i64, ptr } %t75, 0
  %t78 = extractvalue { i64, ptr } %t75, 1
  %t79 = mul i64 %t77, 1
  %t80 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t79)
  call void @llvm.memcpy.p0.p0.i64(ptr %t80, ptr %t78, i64 %t79, i1 false)
  %t81 = insertvalue { i64, ptr } undef, i64 %t77, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t80, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t68, { i64, ptr } %t82)
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb32:
  %t85 = load i64, ptr %l4, !tbaa !24
  %t87 = add i64 %t85, 1
  store i64 %t87, ptr %l4, !tbaa !24
  br label %bb9
bb33:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @olang_2einit_2ecompiler_2ffix() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2ffix_2eTextTool_2einit()
  br label %bb1
bb1:
  call void @compiler_2ffix_2eStdTool_2einit()
  br label %bb2
bb2:
  call void @compiler_2ffix_2eDrivenOpt_2einit()
  br label %bb3
bb3:
  call void @compiler_2ffix_2eDrivenArg_2einit()
  br label %bb4
bb4:
  call void @compiler_2ffix_2eToolNames_2einit()
  br label %bb5
bb5:
  call void @compiler_2ffix_2eToolKinds_2einit()
  br label %bb6
bb6:
  call void @compiler_2ffix_2eBatch_2einit()
  br label %bb7
bb7:
  br label %ret
ret:
  ret void
}

declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr)
declare void @__olang_ert_req_clear()
@.d0 = private constant [7 x i8] c"olang: "
@.d1 = private constant [17 x i8] c": cannot be read\0A"
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d2 = private constant [34 x i8] c"olang: fix: no tools directory at "
@.d3 = private constant [29 x i8] c" (OLANG_TOOLS names another)\0A"
@.d4 = private constant [3 x i8] c"fix"
@.d5 = private constant [0 x i8] c""
@.d6 = private constant [0 x i8] c""
@.d7 = private constant [0 x i8] c""
@.d8 = private constant [0 x i8] c""
@.d9 = private constant [24 x i8] c"olang: fix: cannot make "
@.d10 = private constant [1 x i8] c"\0A"
@.d11 = private constant [6 x i8] c"tools_"
@.d12 = private constant [0 x i8] c""
@.d13 = private constant [0 x i8] c""
@.d14 = private constant [0 x i8] c""
@.d15 = private constant [0 x i8] c""
@.d16 = private constant [0 x i8] c""
@.d17 = private constant [0 x i8] c""
@.d18 = private constant [23 x i8] c"olang: fix: cannot run "
@.d19 = private constant [1 x i8] c"\0A"
@.d20 = private constant [2 x i8] c":\0A"
@.d21 = private constant [1 x i8] c"\0A"
@.d22 = private constant [1 x i8] c"\0A"
@.d23 = private constant [1 x i8] c"\0A"
@.d24 = private constant [7 x i8] c"olang: "
@.d25 = private constant [20 x i8] c": cannot be written\0A"
@.d26 = private constant [0 x i8] c""
@.d27 = private constant [1 x i8] c"s"
@.d28 = private constant [11 x i8] c"olang fix: "
declare i64 @__olang_fmt_i64(ptr, i64)
@.d29 = private constant [6 x i8] c" place"
@.d30 = private constant [89 x i8] c" above may mean something else in the language of today than when written - look at each\0A"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d31 = private constant [4 x i8] c"text"
@.d32 = private constant [6 x i8] c"driven"
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d33 = private constant [6 x i8] c"driven"
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d34 = private constant [13 x i8] c"bare_typevars"
@.d35 = private constant [8 x i8] c"perm_mut"
@.d36 = private constant [15 x i8] c"int_literal_i64"
@.d37 = private constant [14 x i8] c"errors_migrate"
@.d38 = private constant [9 x i8] c"cli_words"
@.d39 = private constant [16 x i8] c"donefail_migrate"
@.d40 = private constant [14 x i8] c"syntax_migrate"
@.d41 = private constant [12 x i8] c"math_methods"
@.d42 = private constant [14 x i8] c"arrays_migrate"
@.d43 = private constant [15 x i8] c"results_migrate"
@.d44 = private constant [16 x i8] c"equality_migrate"
@.d45 = private constant [13 x i8] c"helper_rename"
@.d46 = private constant [12 x i8] c"null_migrate"
@.d47 = private constant [17 x i8] c"checkerror_rename"
@.d48 = private constant [14 x i8] c"stutter_rename"
@.d49 = private constant [15 x i8] c"checked_migrate"
@.d50 = private constant [17 x i8] c"contracts_migrate"
@.d51 = private constant [11 x i8] c"try_migrate"
@.d52 = private constant [10 x i8] c"as_migrate"
@.d53 = private constant [11 x i8] c"OLANG_TOOLS"
@.d54 = private constant [0 x i8] c""
@.d55 = private constant [0 x i8] c""
@.d56 = private constant [9 x i8] c"/../tools"
@.d57 = private constant [5 x i8] c"--std"
@.d58 = private constant [7 x i8] c"--olang"
@.d59 = private constant [8 x i8] c"by hand:"
@.d60 = private constant [13 x i8] c"for a person:"
@.d61 = private constant [2 x i8] c"  "
@.d62 = private constant [6 x i8] c"tools_"
@.d63 = private constant [0 x i8] c""
@.d64 = private constant [0 x i8] c""
@.d65 = private constant [0 x i8] c""
@.d66 = private constant [0 x i8] c""
@.d67 = private constant [6 x i8] c".olang"
@.d68 = private constant [0 x i8] c""
@.d69 = private constant [0 x i8] c""
@.d70 = private constant [0 x i8] c""
@.d71 = private constant [0 x i8] c""
@.d72 = private constant [5 x i8] c"build"
@.d73 = private constant [7 x i8] c"-output"
@.d74 = private constant [0 x i8] c""
@.d75 = private constant [23 x i8] c"olang: fix: cannot run "
@.d76 = private constant [1 x i8] c"\0A"
@.d77 = private constant [18 x i8] c"olang: fix: tools/"
@.d78 = private constant [23 x i8] c".olang does not build:\0A"
@.d79 = private constant [6 x i8] c".olang"
@.d80 = private constant [1 x i8] c"."
@.d81 = private constant [5 x i8] c"build"
@.d82 = private constant [0 x i8] c""
@.d83 = private constant [0 x i8] c""
@.d84 = private constant [0 x i8] c""
@.d85 = private constant [0 x i8] c""
@.d86 = private constant [6 x i8] c".olang"
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %v0, i32 %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hd4bdf3befe2f7a35847f168802c5df68(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_55e63acaa25cfd39_d0989827e133efd = external constant [0 x i8]
declare void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %v0, ptr %a0)
@olang_loc_26781d70abdd0d68_5f1bea27110e64cc = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %a0)
@olang_loc_e6a6422eb79d2443_db90500efc9fb0c7 = external constant [0 x i8]
declare { i64, ptr } @compiler_2ffetch_2eCacheDir(ptr %v0)
declare { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, { i64, ptr } %a5)
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
@olang_loc_aaa99c12ebecdcc2_f002f5bd4abfbc66 = external constant [0 x i8]
@olang_loc_d21c474f19498c95_d0832220e57344c1 = external constant [0 x i8]
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
@olang_loc_914b199b24af8e0b_cb2ee6ecbe673f47 = external constant [0 x i8]
declare { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
@olang_loc_80a1d4bb5db67df_9b65eebf7bc7956b = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_eb8a0402c99d9b5e_35ace7251e3366aa = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_f68d3ad0be646bb1_542defd6f5c5cce5 = external constant [0 x i8]
@olang_loc_553f258c1fa4e7a0_ff2b7e647292c5b4 = external constant [0 x i8]
@olang_loc_96d60822e5550738_7384588370384e4 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2ffilepath_2eDir(ptr %v0, { i64, ptr } %a0)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %a0)
@olang_loc_e6e24e0024ea2a04_be8f31c3c206f038 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %a0, i64 %a1)
@olang_loc_9e1364cb140a9a66_28aa9a3ffa2ccf1a = external constant [0 x i8]
declare { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v0, { i64, ptr } %a0)
@olang_loc_23f451298266bf5e_2593b028faf03d0a = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_8fcf87cfa7be21dd_bbd76dac3520f231 = external constant [0 x i8]
@olang_loc_9433da86f750b978_3ff5b65d50af9d4 = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
