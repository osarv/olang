; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/io:Writer" = type { i32, { i64, ptr }, i64, i32 }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
%"std/os:FileInfo" = type { i32, i64, i64 }
@G_2ecompiler_2ffix_2eBatch = constant <{ [8 x i8] }> <{ [8 x i8] c"\C8\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eDrivenArg = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eDrivenOpt = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eStdTool = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eTextTool = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eToolKinds = constant <{ [160 x i8] }> <{ [160 x i8] c"\01\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\03\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2ffix_2eToolNames = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k1, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k2, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k3, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k4, [8 x i8] c"\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k5, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k6, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k7, [8 x i8] c"\0C\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k8, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k9, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k10, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k11, [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k12, [8 x i8] c"\0C\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k13, [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k14, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k15, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k16, [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k17, [8 x i8] c"\0B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k18, [8 x i8] c"\0A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k19, [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffix_2eToolNames.k20 }>, align 64
@G_2ecompiler_2ffix_2eToolNames.k1 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\62\61\72\65\5F\74\79\70\65\76\61\72\73" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k2 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\70\65\72\6D\5F\6D\75\74" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k3 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\69\6E\74\5F\6C\69\74\65\72\61\6C\5F\69\36\34" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k4 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\65\72\72\6F\72\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k5 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\63\6C\69\5F\77\6F\72\64\73" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k6 = internal constant <{ [16 x i8] }> <{ [16 x i8] c"\64\6F\6E\65\66\61\69\6C\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k7 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\73\79\6E\74\61\78\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k8 = internal constant <{ [12 x i8] }> <{ [12 x i8] c"\6D\61\74\68\5F\6D\65\74\68\6F\64\73" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k9 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\61\72\72\61\79\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k10 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\72\65\73\75\6C\74\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k11 = internal constant <{ [16 x i8] }> <{ [16 x i8] c"\65\71\75\61\6C\69\74\79\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k12 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\68\65\6C\70\65\72\5F\72\65\6E\61\6D\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k13 = internal constant <{ [12 x i8] }> <{ [12 x i8] c"\6E\75\6C\6C\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k14 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\63\68\65\63\6B\65\72\72\6F\72\5F\72\65\6E\61\6D\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k15 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\73\74\75\74\74\65\72\5F\72\65\6E\61\6D\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k16 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\63\68\65\63\6B\65\64\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k17 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\63\6F\6E\74\72\61\63\74\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k18 = internal constant <{ [11 x i8] }> <{ [11 x i8] c"\74\72\79\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k19 = internal constant <{ [10 x i8] }> <{ [10 x i8] c"\61\73\5F\6D\69\67\72\61\74\65" }>, align 8
@G_2ecompiler_2ffix_2eToolNames.k20 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\65\72\72\6F\72\74\79\70\65\5F\6D\69\67\72\61\74\65" }>, align 8
define dso_local void @compiler_2ffix_2eBatch_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 200, ptr @G_2ecompiler_2ffix_2eBatch, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffix_2eDrivenArg_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 3, ptr @G_2ecompiler_2ffix_2eDrivenArg, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffix_2eDrivenOpt_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 2, ptr @G_2ecompiler_2ffix_2eDrivenOpt, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2ffix_2eFiles(ptr %v0, ptr %v1, ptr %v2, i1 %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca i1
  %l2 = alloca { i64, ptr }
  %l4 = alloca %"std/io:Writer"
  %l5 = alloca %"std/io:Writer"
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l30 = alloca %"std/os:Output"
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l42 = alloca %"std/io:Writer"
  %l43 = alloca %"std/io:Writer"
  %l45 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l47 = alloca { i64, ptr }
  %l48 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l56 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca i32
  %l71 = alloca i32
  %l82 = alloca { i64, ptr }
  %l84 = alloca i1
  %l92 = alloca i32
  %l96 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l100 = alloca i32
  %l109 = alloca i32
  %l113 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l131 = alloca i1
  %l137 = alloca { i64, ptr }
  %l144 = alloca i64
  %l147 = alloca i64
  %l165 = alloca { i64, ptr }
  %l166 = alloca i64
  %l172 = alloca i64
  %l173 = alloca i64
  %l178 = alloca %"std/os:Output"
  %l185 = alloca { i64, ptr }
  %l187 = alloca { i64, ptr }
  %l188 = alloca %"std/os:Output"
  %l189 = alloca i32
  %l201 = alloca i64
  %l204 = alloca i1
  %l214 = alloca i1
  %l217 = alloca { i64, ptr }
  %l234 = alloca i64
  %l237 = alloca i64
  %l255 = alloca { i64, ptr }
  %l256 = alloca { i64, ptr }
  %l259 = alloca { i64, ptr }
  %l260 = alloca i32
  %l263 = alloca { i64, ptr }
  %l266 = alloca { i64, ptr }
  %l267 = alloca i1
  %l271 = alloca { i64, ptr }
  %l278 = alloca { i64, ptr }
  %l280 = alloca { i64, ptr }
  %l283 = alloca { i64, ptr }
  %l285 = alloca i32
  %l289 = alloca { i64, ptr }
  %l299 = alloca i1
  %l304 = alloca { i64, ptr }
  %l312 = alloca i32
  %l317 = alloca i32
  %l325 = alloca i1
  %l328 = alloca i1
  %l331 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %rv = alloca i32
  store i1 %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %s0, i32 2, i64 65536)
  store %"std/io:Writer" %t1, ptr %l42
  br label %bb1
bb1:
  %t2 = load %"std/io:Writer", ptr %l42
  store %"std/io:Writer" %t2, ptr %l4
  %t3 = call %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %s0, i32 1, i64 65536)
  store %"std/io:Writer" %t3, ptr %l43
  br label %bb2
bb2:
  %t4 = load %"std/io:Writer", ptr %l43
  store %"std/io:Writer" %t4, ptr %l5
  %t7 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffix_2eexpand(ptr %v0, ptr %s0, { i64, ptr } %a1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l45
  br label %bb3
bb3:
  %t8 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l45
  %t9 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %t9
  %t11 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hd4bdf3befe2f7a35847f168802c5df68(ptr %s0, ptr %s0, ptr %t9)
  store { i64, ptr } %t11, ptr %l47
  br label %bb4
bb4:
  %t12 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t12, ptr %l6, !tbaa !27
  %t13 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l48
  br label %bb5
bb5:
  %t14 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l48
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, ptr %l7
  %t15 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t15, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  store i64 %t19, ptr %l10, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t21 = load i64, ptr %l9, !tbaa !24
  %t22 = load i64, ptr %l10, !tbaa !24
  %t25 = icmp slt i64 %t21, %t22
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb8:
  br label %bb9
bb9:
  %t29 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t29, ptr %l56, !tbaa !27
  %t30 = load i64, ptr %l9, !tbaa !24
  %t32 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr { i64, ptr }, ptr %t33, i64 %t30
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !37
  store { i64, ptr } %t35, ptr %l11, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t39 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s2, { i64, ptr } %t37)
  %t40 = extractvalue { i32, { i64, ptr } } %t39, 1
  %t41 = extractvalue { i32, { i64, ptr } } %t39, 0
  store i32 %t41, ptr %l62
  %t42 = icmp ne i32 %t41, 0
  br i1 %t42, label %bb11, label %ok.43
ok.43:
  store { i64, ptr } %t40, ptr %l61
  br label %bb10
bb10:
  %t44 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t44, ptr %l59, !tbaa !27
  br label %bb22
bb11:
  %t45 = load i32, ptr %l62, !tbaa !23
  %t46 = ashr i32 %t45, 16
  %t48 = icmp eq i32 %t46, 1
  br i1 %t48, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_55e63acaa25cfd39_d0989827e133efd)
  unreachable
bb14:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s3
  %t50 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t51 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t52 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t54 = extractvalue { i64, ptr } %t50, 1
  %t55 = extractvalue { i64, ptr } %t50, 0
  %t56 = add i64 %t52, %t55
  %t57 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t59 = add i64 %t56, %t58
  %t60 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t59)
  call void @olang_textcopy(ptr %t60, ptr %t51, i64 %t52)
  %t61 = getelementptr i8, ptr %t60, i64 %t52
  call void @olang_textcopy(ptr %t61, ptr %t54, i64 %t55)
  %t62 = getelementptr i8, ptr %t61, i64 %t55
  call void @olang_textcopy(ptr %t62, ptr %t57, i64 %t58)
  %t63 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t60, 1
  %t67 = extractvalue { i64, ptr } %t64, 0
  %t68 = extractvalue { i64, ptr } %t64, 1
  %t69 = mul i64 %t67, 1
  %t70 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t69)
  call void @llvm.memcpy.p0.p0.i64(ptr %t70, ptr %t68, i64 %t69, i1 false)
  %t71 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s3, ptr %l4, { i64, ptr } %t72)
  br label %bb15
bb15:
  %t76 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l4)
  store i32 %t76, ptr %l71
  %t77 = icmp ne i32 %t76, 0
  br i1 %t77, label %bb17, label %ok.78
ok.78:
  br label %bb16
bb16:
  br label %bb21
bb17:
  %t79 = load i32, ptr %l71, !tbaa !23
  %t80 = ashr i32 %t79, 16
  %t82 = icmp eq i32 %t80, 1
  br i1 %t82, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_26781d70abdd0d68_5f1bea27110e64cc)
  unreachable
bb20:
  call void @__olang_ert_req_clear()
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb22:
  %t85 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t85, 1
  %t89 = extractvalue { i64, ptr } %t85, 0
  %t90 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t89)
  call void @olang_textcopy(ptr %t90, ptr %t88, i64 %t89)
  %t91 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t90, 1
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t95 = extractvalue { i64, ptr } %t92, 1
  %t96 = mul i64 %t94, 1
  %t97 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t96)
  call void @llvm.memcpy.p0.p0.i64(ptr %t97, ptr %t95, i64 %t96, i1 false)
  %t98 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t97, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } %t99)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb24:
  %t102 = load i64, ptr %l9, !tbaa !24
  %t104 = add i64 %t102, 1
  store i64 %t104, ptr %l9, !tbaa !24
  br label %bb6
bb25:
  %t106 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t108 = call { i64, ptr } @compiler_2ffix_2eToolsDir(ptr %v1, ptr %s0, { i64, ptr } %t106)
  store { i64, ptr } %t108, ptr %l82
  br label %bb26
bb26:
  %t109 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t109, ptr %l13, !tbaa !27
  %t110 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t112 = call i1 @std_2fos_2eIsDir(ptr %s0, { i64, ptr } %t110)
  store i1 %t112, ptr %l84
  br label %bb27
bb27:
  %t113 = load i1, ptr %l84, !tbaa !21
  %t114 = xor i1 %t113, true
  br i1 %t114, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s8
  %t116 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t117 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t118 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t120 = extractvalue { i64, ptr } %t116, 1
  %t121 = extractvalue { i64, ptr } %t116, 0
  %t122 = add i64 %t118, %t121
  %t123 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t124 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t125 = add i64 %t122, %t124
  %t126 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t125)
  call void @olang_textcopy(ptr %t126, ptr %t117, i64 %t118)
  %t127 = getelementptr i8, ptr %t126, i64 %t118
  call void @olang_textcopy(ptr %t127, ptr %t120, i64 %t121)
  %t128 = getelementptr i8, ptr %t127, i64 %t121
  call void @olang_textcopy(ptr %t128, ptr %t123, i64 %t124)
  %t129 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t126, 1
  %t133 = extractvalue { i64, ptr } %t130, 0
  %t134 = extractvalue { i64, ptr } %t130, 1
  %t135 = mul i64 %t133, 1
  %t136 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t135)
  call void @llvm.memcpy.p0.p0.i64(ptr %t136, ptr %t134, i64 %t135, i1 false)
  %t137 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t136, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s8, ptr %l4, { i64, ptr } %t138)
  br label %bb30
bb29:
  br label %bb37
bb30:
  %t142 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l4)
  store i32 %t142, ptr %l92
  %t143 = icmp ne i32 %t142, 0
  br i1 %t143, label %bb32, label %ok.144
ok.144:
  br label %bb31
bb31:
  br label %bb36
bb32:
  %t145 = load i32, ptr %l92, !tbaa !23
  %t146 = ashr i32 %t145, 16
  %t148 = icmp eq i32 %t146, 1
  br i1 %t148, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_e6a6422eb79d2443_db90500efc9fb0c7)
  unreachable
bb35:
  call void @__olang_ert_req_clear()
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb37:
  %t151 = call { i64, ptr } @compiler_2ffetch_2eCacheDir(ptr %s0)
  store { i64, ptr } %t151, ptr %l96
  br label %bb38
bb38:
  %t152 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t153 = extractvalue { i64, ptr } %t152, 0
  %t154 = extractvalue { i64, ptr } %t152, 1
  %t155 = mul i64 %t153, 1
  %t156 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t155)
  call void @llvm.memcpy.p0.p0.i64(ptr %t156, ptr %t154, i64 %t155, i1 false)
  %t157 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t156, 1
  %t160 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t158, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d4, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d7, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store { i64, ptr } %t160, ptr %l98
  br label %bb39
bb39:
  %t161 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t161, ptr %l14, !tbaa !27
  %t162 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t164 = call i32 @std_2fos_2eMkDirAll(ptr %s0, { i64, ptr } %t162)
  store i32 %t164, ptr %l100
  %t165 = icmp ne i32 %t164, 0
  br i1 %t165, label %bb41, label %ok.166
ok.166:
  br label %bb40
bb40:
  br label %bb52
bb41:
  %t167 = load i32, ptr %l100, !tbaa !23
  %t168 = ashr i32 %t167, 16
  %t170 = icmp eq i32 %t168, 1
  br i1 %t170, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_aaa99c12ebecdcc2_f002f5bd4abfbc66)
  unreachable
bb44:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s11
  %t172 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t173 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t174 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t176 = extractvalue { i64, ptr } %t172, 1
  %t177 = extractvalue { i64, ptr } %t172, 0
  %t178 = add i64 %t174, %t177
  %t179 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t180 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t181 = add i64 %t178, %t180
  %t182 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t181)
  call void @olang_textcopy(ptr %t182, ptr %t173, i64 %t174)
  %t183 = getelementptr i8, ptr %t182, i64 %t174
  call void @olang_textcopy(ptr %t183, ptr %t176, i64 %t177)
  %t184 = getelementptr i8, ptr %t183, i64 %t177
  call void @olang_textcopy(ptr %t184, ptr %t179, i64 %t180)
  %t185 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t186 = insertvalue { i64, ptr } %t185, ptr %t182, 1
  %t189 = extractvalue { i64, ptr } %t186, 0
  %t190 = extractvalue { i64, ptr } %t186, 1
  %t191 = mul i64 %t189, 1
  %t192 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t191)
  call void @llvm.memcpy.p0.p0.i64(ptr %t192, ptr %t190, i64 %t191, i1 false)
  %t193 = insertvalue { i64, ptr } undef, i64 %t189, 0
  %t194 = insertvalue { i64, ptr } %t193, ptr %t192, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s11, ptr %l4, { i64, ptr } %t194)
  br label %bb45
bb45:
  %t198 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l4)
  store i32 %t198, ptr %l109
  %t199 = icmp ne i32 %t198, 0
  br i1 %t199, label %bb47, label %ok.200
ok.200:
  br label %bb46
bb46:
  br label %bb51
bb47:
  %t201 = load i32, ptr %l109, !tbaa !23
  %t202 = ashr i32 %t201, 16
  %t204 = icmp eq i32 %t202, 1
  br i1 %t204, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_d21c474f19498c95_d0832220e57344c1)
  unreachable
bb50:
  call void @__olang_ert_req_clear()
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb52:
  store i32 0, ptr %l15, !tbaa !23
  store i64 0, ptr %l16, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s14
  %t207 = call { i64, ptr } @compiler_2ffix_2eOrder(ptr %s14)
  store { i64, ptr } %t207, ptr %l113
  br label %bb53
bb53:
  %t208 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t209 = extractvalue { i64, ptr } %t208, 0
  %t210 = extractvalue { i64, ptr } %t208, 1
  %t211 = mul i64 %t209, 8
  %t212 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t211)
  call void @llvm.memcpy.p0.p0.i64(ptr %t212, ptr %t210, i64 %t211, i1 false)
  %t213 = insertvalue { i64, ptr } undef, i64 %t209, 0
  %t214 = insertvalue { i64, ptr } %t213, ptr %t212, 1
  store { i64, ptr } %t214, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t216 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t218 = extractvalue { i64, ptr } %t216, 0
  store i64 %t218, ptr %l19, !tbaa !24
  br label %bb54
bb54:
  store %olang.scope zeroinitializer, ptr %s15
  %t220 = load i64, ptr %l18, !tbaa !24
  %t221 = load i64, ptr %l19, !tbaa !24
  %t224 = icmp slt i64 %t220, %t221
  %t226 = xor i1 %t224, true
  br i1 %t226, label %bb55, label %bb56
bb55:
  call void @__olang_scope_close(ptr %s15)
  br label %bb110
bb56:
  br label %bb57
bb57:
  %t228 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t228, ptr %l121, !tbaa !27
  %t229 = load i64, ptr %l18, !tbaa !24
  %t231 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !27
  %t233 = getelementptr i64, ptr %t232, i64 %t229
  %t234 = load i64, ptr %t233, !tbaa !34
  store i64 %t234, ptr %l20, !tbaa !24
  %t236 = load i64, ptr %l20, !tbaa !24
  %t238 = getelementptr [20 x { i64, ptr }], ptr @G_2ecompiler_2ffix_2eToolNames, i64 0, i64 %t236
  %t239 = load { i64, ptr }, ptr %t238, !tbaa !37
  store { i64, ptr } %t239, ptr %l21, !tbaa !27
  %t241 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t242 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t243 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t244 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t245 = load ptr, ptr @__olang_prog_scope
  %t251 = call i1 @compiler_2ffix_2eensureBuilt(ptr %v1, ptr %s0, ptr %s0, ptr %t245, ptr %s0, { i64, ptr } %t241, { i64, ptr } %t242, { i64, ptr } %t243, { i64, ptr } %t244, ptr %l4)
  store i1 %t251, ptr %l131
  br label %bb58
bb58:
  %t252 = load i1, ptr %l131, !tbaa !21
  %t253 = xor i1 %t252, true
  br i1 %t253, label %bb59, label %bb60
bb59:
  store i32 2, ptr %l15, !tbaa !23
  call void @__olang_scope_close(ptr %s15)
  br label %bb110
bb60:
  br label %bb61
bb61:
  %t255 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t256 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t257 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t258 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t260 = extractvalue { i64, ptr } %t256, 1
  %t261 = extractvalue { i64, ptr } %t256, 0
  %t262 = add i64 %t258, %t261
  %t263 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t262)
  call void @olang_textcopy(ptr %t263, ptr %t257, i64 %t258)
  %t264 = getelementptr i8, ptr %t263, i64 %t258
  call void @olang_textcopy(ptr %t264, ptr %t260, i64 %t261)
  %t265 = insertvalue { i64, ptr } undef, i64 %t262, 0
  %t266 = insertvalue { i64, ptr } %t265, ptr %t263, 1
  %t268 = extractvalue { i64, ptr } %t266, 0
  %t269 = extractvalue { i64, ptr } %t266, 1
  %t270 = mul i64 %t268, 1
  %t271 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t270)
  call void @llvm.memcpy.p0.p0.i64(ptr %t271, ptr %t269, i64 %t270, i1 false)
  %t272 = insertvalue { i64, ptr } undef, i64 %t268, 0
  %t273 = insertvalue { i64, ptr } %t272, ptr %t271, 1
  %t276 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s15, ptr %s15, ptr %s15, ptr %s15, ptr %s15, ptr %s15, { i64, ptr } %t255, { i64, ptr } %t273, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d7, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store { i64, ptr } %t276, ptr %l137
  br label %bb62
bb62:
  %t277 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t277, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t278 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t280 = extractvalue { i64, ptr } %t278, 0
  store i64 %t280, ptr %l24, !tbaa !24
  %t282 = load i64, ptr @G_2ecompiler_2ffix_2eBatch, !tbaa !24
  store i64 %t282, ptr %l25, !tbaa !24
  %t284 = load i64, ptr %l24, !tbaa !24
  %t285 = load i64, ptr %l23, !tbaa !24
  %t288 = icmp sgt i64 %t284, %t285
  br i1 %t288, label %bb63, label %bb64
bb63:
  %t290 = load i64, ptr %l25, !tbaa !24
  %t292 = icmp sgt i64 %t290, 0
  br i1 %t292, label %bb65, label %bb66
bb64:
  store i64 0, ptr %l144, !tbaa !24
  br label %bb68
bb65:
  %t294 = load i64, ptr %l24, !tbaa !24
  %t295 = load i64, ptr %l23, !tbaa !24
  %t298 = sub i64 %t294, %t295
  %t299 = load i64, ptr %l25, !tbaa !24
  %t302 = add i64 %t298, %t299
  %t304 = sub i64 %t302, 1
  %t305 = load i64, ptr %l25, !tbaa !24
  %t308 = sdiv i64 %t304, %t305
  store i64 %t308, ptr %l147, !tbaa !24
  br label %bb67
bb66:
  store i64 0, ptr %l147, !tbaa !24
  br label %bb67
bb67:
  %t310 = load i64, ptr %l147, !tbaa !24
  store i64 %t310, ptr %l144, !tbaa !24
  br label %bb68
bb68:
  %t311 = load i64, ptr %l144, !tbaa !24
  store i64 %t311, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb69
bb69:
  store %olang.scope zeroinitializer, ptr %s19
  %t312 = load i64, ptr %l27, !tbaa !24
  %t313 = load i64, ptr %l26, !tbaa !24
  %t316 = icmp slt i64 %t312, %t313
  %t318 = xor i1 %t316, true
  br i1 %t318, label %bb70, label %bb71
bb70:
  call void @__olang_scope_close(ptr %s19)
  br label %bb105
bb71:
  br label %bb72
bb72:
  %t320 = load i64, ptr %l23, !tbaa !24
  %t321 = load i64, ptr %l27, !tbaa !24
  %t322 = load i64, ptr %l25, !tbaa !24
  %t325 = mul i64 %t321, %t322
  %t328 = add i64 %t320, %t325
  store i64 %t328, ptr %l28, !tbaa !24
  %t330 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t330, ptr %l165, !tbaa !27
  %t331 = load i64, ptr %l28, !tbaa !24
  store i64 %t331, ptr %l166, !tbaa !24
  %t332 = load i64, ptr %l28, !tbaa !24
  %t333 = load i64, ptr @G_2ecompiler_2ffix_2eBatch, !tbaa !24
  %t336 = add i64 %t332, %t333
  %t337 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t339 = extractvalue { i64, ptr } %t337, 0
  %t342 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t336, i64 %t339)
  store i64 %t342, ptr %l172
  br label %bb73
bb73:
  %t343 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t344 = extractvalue { i64, ptr } %t343, 0
  store i64 %t344, ptr %l173, !tbaa !24
  %t345 = load i64, ptr %l166, !tbaa !24
  %t346 = icmp sge i64 %t345, 0
  br i1 %t346, label %bb74, label %bb75
bb74:
  %t348 = load i64, ptr %l166, !tbaa !24
  %t349 = load i64, ptr %l172, !tbaa !24
  %t350 = icmp sle i64 %t348, %t349
  br i1 %t350, label %bb76, label %bb77
bb75:
  call void @__olang_check_failed(ptr @olang_loc_914b199b24af8e0b_cb2ee6ecbe673f47)
  unreachable
bb76:
  %t352 = load i64, ptr %l172, !tbaa !24
  %t353 = load i64, ptr %l173, !tbaa !24
  %t354 = icmp sle i64 %t352, %t353
  br i1 %t354, label %bb78, label %bb79
bb77:
  call void @__olang_check_failed(ptr @olang_loc_914b199b24af8e0b_cb2ee6ecbe673f47)
  unreachable
bb78:
  %t356 = getelementptr { i64, ptr }, ptr %l165, i32 0, i32 1
  %t357 = load ptr, ptr %t356, !tbaa !27
  %t358 = load i64, ptr %l166, !tbaa !24
  %t359 = load i64, ptr %l172, !tbaa !24
  %t360 = getelementptr { i64, ptr }, ptr %t357, i64 %t358
  %t361 = sub i64 %t359, %t358
  %t362 = insertvalue { i64, ptr } undef, i64 %t361, 0
  %t363 = insertvalue { i64, ptr } %t362, ptr %t360, 1
  %t365 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t366 = load i64, ptr %l20, !tbaa !24
  %t368 = getelementptr [20 x i64], ptr @G_2ecompiler_2ffix_2eToolKinds, i64 0, i64 %t366
  %t369 = load i64, ptr %t368, !tbaa !34
  %t370 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t378 = call { i64, ptr } @compiler_2ffix_2earguments(ptr %s15, ptr %v1, ptr %v2, ptr %s0, ptr %s19, { i64, ptr } %t365, i64 %t369, { i64, ptr } %t370, { i64, ptr } %a3, { i64, ptr } %t363)
  store { i64, ptr } %t378, ptr %l185
  br label %bb80
bb79:
  call void @__olang_check_failed(ptr @olang_loc_914b199b24af8e0b_cb2ee6ecbe673f47)
  unreachable
bb80:
  %t379 = load { i64, ptr }, ptr %l185, !tbaa !27
  %t380 = extractvalue { i64, ptr } %t379, 0
  %t381 = extractvalue { i64, ptr } %t379, 1
  %t382 = mul i64 %t380, 16
  %t383 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t382)
  call void @llvm.memcpy.p0.p0.i64(ptr %t383, ptr %t381, i64 %t382, i1 false)
  %t384 = insertvalue { i64, ptr } undef, i64 %t380, 0
  %t385 = insertvalue { i64, ptr } %t384, ptr %t383, 1
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr %l187, !tbaa !27
  %t387 = load { i64, ptr }, ptr %l187, !tbaa !27
  %t388 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s19, ptr %s19, ptr %s19, ptr %s19, { i64, ptr } %t385, { i64, ptr } %t387, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d13, i32 0, i32 1) })
  %t389 = extractvalue { i32, %"std/os:Output" } %t388, 1
  %t390 = extractvalue { i32, %"std/os:Output" } %t388, 0
  store i32 %t390, ptr %l189
  %t391 = icmp ne i32 %t390, 0
  br i1 %t391, label %bb82, label %ok.392
ok.392:
  store %"std/os:Output" %t389, ptr %l188
  br label %bb81
bb81:
  %t393 = load %"std/os:Output", ptr %l188
  store %"std/os:Output" %t393, ptr %l178
  br label %bb87
bb82:
  %t394 = load i32, ptr %l189, !tbaa !23
  %t395 = ashr i32 %t394, 16
  %t397 = icmp eq i32 %t395, 1
  br i1 %t397, label %bb83, label %bb84
bb83:
  br label %bb85
bb84:
  call void @__olang_check_failed(ptr @olang_loc_80a1d4bb5db67df_9b65eebf7bc7956b)
  unreachable
bb85:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s20
  %t399 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t400 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t401 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t403 = extractvalue { i64, ptr } %t399, 1
  %t404 = extractvalue { i64, ptr } %t399, 0
  %t405 = add i64 %t401, %t404
  %t406 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t407 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t408 = add i64 %t405, %t407
  %t409 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t408)
  call void @olang_textcopy(ptr %t409, ptr %t400, i64 %t401)
  %t410 = getelementptr i8, ptr %t409, i64 %t401
  call void @olang_textcopy(ptr %t410, ptr %t403, i64 %t404)
  %t411 = getelementptr i8, ptr %t410, i64 %t404
  call void @olang_textcopy(ptr %t411, ptr %t406, i64 %t407)
  %t412 = insertvalue { i64, ptr } undef, i64 %t408, 0
  %t413 = insertvalue { i64, ptr } %t412, ptr %t409, 1
  %t416 = extractvalue { i64, ptr } %t413, 0
  %t417 = extractvalue { i64, ptr } %t413, 1
  %t418 = mul i64 %t416, 1
  %t419 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t418)
  call void @llvm.memcpy.p0.p0.i64(ptr %t419, ptr %t417, i64 %t418, i1 false)
  %t420 = insertvalue { i64, ptr } undef, i64 %t416, 0
  %t421 = insertvalue { i64, ptr } %t420, ptr %t419, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s20, ptr %l4, { i64, ptr } %t421)
  br label %bb86
bb86:
  store i32 2, ptr %l15, !tbaa !23
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s19)
  br label %bb105
bb87:
  %t424 = load %"std/os:Output", ptr %l178
  store %"std/os:Output" %t424, ptr %l30
  %t425 = getelementptr %"std/os:Output", ptr %l30, i32 0, i32 1
  %t426 = load { i64, ptr }, ptr %t425, !tbaa !27
  %t427 = getelementptr %"std/os:Output", ptr %l30, i32 0, i32 2
  %t428 = load { i64, ptr }, ptr %t427, !tbaa !27
  %t430 = extractvalue { i64, ptr } %t426, 1
  %t431 = extractvalue { i64, ptr } %t426, 0
  %t433 = extractvalue { i64, ptr } %t428, 1
  %t434 = extractvalue { i64, ptr } %t428, 0
  %t435 = add i64 %t431, %t434
  %t436 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t435)
  call void @olang_textcopy(ptr %t436, ptr %t430, i64 %t431)
  %t437 = getelementptr i8, ptr %t436, i64 %t431
  call void @olang_textcopy(ptr %t437, ptr %t433, i64 %t434)
  %t438 = insertvalue { i64, ptr } undef, i64 %t435, 0
  %t439 = insertvalue { i64, ptr } %t438, ptr %t436, 1
  store { i64, ptr } %t439, ptr %l31, !tbaa !27
  %t441 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t443 = call i64 @compiler_2ffix_2ebyHand(ptr %s19, { i64, ptr } %t441)
  store i64 %t443, ptr %l201
  br label %bb88
bb88:
  %t444 = load i64, ptr %l201, !tbaa !24
  store i64 %t444, ptr %l32, !tbaa !24
  %t445 = getelementptr %"std/os:Output", ptr %l30, i32 0, i32 0
  %t446 = load i32, ptr %t445, !tbaa !23
  %t448 = icmp sgt i32 %t446, 1
  br i1 %t448, label %bb89, label %bb90
bb89:
  store i1 true, ptr %l204, !tbaa !21
  br label %bb91
bb90:
  %t450 = load i64, ptr %l32, !tbaa !24
  %t452 = icmp sgt i64 %t450, 0
  store i1 %t452, ptr %l204, !tbaa !21
  br label %bb91
bb91:
  %t454 = load i1, ptr %l204, !tbaa !21
  br i1 %t454, label %bb92, label %bb93
bb92:
  store %olang.scope zeroinitializer, ptr %s23
  %t455 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t456 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t458 = extractvalue { i64, ptr } %t455, 1
  %t459 = extractvalue { i64, ptr } %t455, 0
  %t460 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t461 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t462 = add i64 %t459, %t461
  %t464 = extractvalue { i64, ptr } %t456, 1
  %t465 = extractvalue { i64, ptr } %t456, 0
  %t466 = add i64 %t462, %t465
  %t467 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t466)
  call void @olang_textcopy(ptr %t467, ptr %t458, i64 %t459)
  %t468 = getelementptr i8, ptr %t467, i64 %t459
  call void @olang_textcopy(ptr %t468, ptr %t460, i64 %t461)
  %t469 = getelementptr i8, ptr %t468, i64 %t461
  call void @olang_textcopy(ptr %t469, ptr %t464, i64 %t465)
  %t470 = insertvalue { i64, ptr } undef, i64 %t466, 0
  %t471 = insertvalue { i64, ptr } %t470, ptr %t467, 1
  %t474 = extractvalue { i64, ptr } %t471, 0
  %t475 = extractvalue { i64, ptr } %t471, 1
  %t476 = mul i64 %t474, 1
  %t477 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t476)
  call void @llvm.memcpy.p0.p0.i64(ptr %t477, ptr %t475, i64 %t476, i1 false)
  %t478 = insertvalue { i64, ptr } undef, i64 %t474, 0
  %t479 = insertvalue { i64, ptr } %t478, ptr %t477, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s23, ptr %l4, { i64, ptr } %t479)
  br label %bb94
bb93:
  br label %bb100
bb94:
  %t482 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t484 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s19, ptr %s23, { i64, ptr } %t482, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store i1 %t484, ptr %l214
  br label %bb95
bb95:
  %t485 = load i1, ptr %l214, !tbaa !21
  %t486 = xor i1 %t485, true
  br i1 %t486, label %bb96, label %bb97
bb96:
  store %olang.scope zeroinitializer, ptr %s25
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l217, !tbaa !27
  %t489 = load { i64, ptr }, ptr %l217, !tbaa !27
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s25, ptr %l4, { i64, ptr } %t489)
  br label %bb98
bb97:
  br label %bb99
bb98:
  call void @__olang_scope_close(ptr %s25)
  br label %bb99
bb99:
  call void @__olang_scope_close(ptr %s23)
  br label %bb100
bb100:
  %t490 = load i64, ptr %l16, !tbaa !24
  %t491 = load i64, ptr %l32, !tbaa !24
  %t494 = add i64 %t490, %t491
  store i64 %t494, ptr %l16, !tbaa !24
  %t496 = getelementptr %"std/os:Output", ptr %l30, i32 0, i32 0
  %t497 = load i32, ptr %t496, !tbaa !23
  %t499 = icmp sgt i32 %t497, 1
  br i1 %t499, label %bb101, label %bb102
bb101:
  store i32 2, ptr %l15, !tbaa !23
  br label %bb103
bb102:
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s19)
  br label %bb104
bb104:
  %t501 = load i64, ptr %l27, !tbaa !24
  %t503 = add i64 %t501, 1
  store i64 %t503, ptr %l27, !tbaa !24
  br label %bb69
bb105:
  %t505 = load i32, ptr %l15, !tbaa !23
  %t507 = icmp ne i32 %t505, 0
  br i1 %t507, label %bb106, label %bb107
bb106:
  call void @__olang_scope_close(ptr %s15)
  br label %bb110
bb107:
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s15)
  br label %bb109
bb109:
  %t509 = load i64, ptr %l18, !tbaa !24
  %t511 = add i64 %t509, 1
  store i64 %t511, ptr %l18, !tbaa !24
  br label %bb54
bb110:
  call void @__olang_scope_close(ptr %s14)
  store i64 0, ptr %l33, !tbaa !24
  store i64 0, ptr %l34, !tbaa !24
  %t513 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t515 = extractvalue { i64, ptr } %t513, 0
  store i64 %t515, ptr %l35, !tbaa !24
  store i64 1, ptr %l36, !tbaa !24
  %t517 = load i64, ptr %l35, !tbaa !24
  %t518 = load i64, ptr %l34, !tbaa !24
  %t521 = icmp sgt i64 %t517, %t518
  br i1 %t521, label %bb111, label %bb112
bb111:
  %t523 = load i64, ptr %l36, !tbaa !24
  %t525 = icmp sgt i64 %t523, 0
  br i1 %t525, label %bb113, label %bb114
bb112:
  store i64 0, ptr %l234, !tbaa !24
  br label %bb116
bb113:
  %t527 = load i64, ptr %l35, !tbaa !24
  %t528 = load i64, ptr %l34, !tbaa !24
  %t531 = sub i64 %t527, %t528
  %t532 = load i64, ptr %l36, !tbaa !24
  %t535 = add i64 %t531, %t532
  %t537 = sub i64 %t535, 1
  %t538 = load i64, ptr %l36, !tbaa !24
  %t541 = sdiv i64 %t537, %t538
  store i64 %t541, ptr %l237, !tbaa !24
  br label %bb115
bb114:
  store i64 0, ptr %l237, !tbaa !24
  br label %bb115
bb115:
  %t543 = load i64, ptr %l237, !tbaa !24
  store i64 %t543, ptr %l234, !tbaa !24
  br label %bb116
bb116:
  %t544 = load i64, ptr %l234, !tbaa !24
  store i64 %t544, ptr %l37, !tbaa !24
  store i64 0, ptr %l38, !tbaa !24
  br label %bb117
bb117:
  store %olang.scope zeroinitializer, ptr %s31
  %t545 = load i64, ptr %l38, !tbaa !24
  %t546 = load i64, ptr %l37, !tbaa !24
  %t549 = icmp slt i64 %t545, %t546
  %t551 = xor i1 %t549, true
  br i1 %t551, label %bb118, label %bb119
bb118:
  call void @__olang_scope_close(ptr %s31)
  br label %bb145
bb119:
  br label %bb120
bb120:
  %t553 = load i64, ptr %l34, !tbaa !24
  %t554 = load i64, ptr %l38, !tbaa !24
  %t555 = load i64, ptr %l36, !tbaa !24
  %t558 = mul i64 %t554, %t555
  %t561 = add i64 %t553, %t558
  store i64 %t561, ptr %l39, !tbaa !24
  %t563 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t563, ptr %l256, !tbaa !27
  %t564 = load i64, ptr %l39, !tbaa !24
  %t566 = getelementptr { i64, ptr }, ptr %l256, i32 0, i32 1
  %t567 = load ptr, ptr %t566, !tbaa !27
  %t568 = getelementptr { i64, ptr }, ptr %t567, i64 %t564
  %t569 = load { i64, ptr }, ptr %t568, !tbaa !37
  %t571 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s31, { i64, ptr } %t569)
  %t572 = extractvalue { i32, { i64, ptr } } %t571, 1
  %t573 = extractvalue { i32, { i64, ptr } } %t571, 0
  store i32 %t573, ptr %l260
  %t574 = icmp ne i32 %t573, 0
  br i1 %t574, label %bb122, label %ok.575
ok.575:
  store { i64, ptr } %t572, ptr %l259
  br label %bb121
bb121:
  %t576 = load { i64, ptr }, ptr %l259, !tbaa !27
  store { i64, ptr } %t576, ptr %l255, !tbaa !27
  br label %bb126
bb122:
  %t577 = load i32, ptr %l260, !tbaa !23
  %t578 = ashr i32 %t577, 16
  %t580 = icmp eq i32 %t578, 1
  br i1 %t580, label %bb123, label %bb124
bb123:
  br label %bb125
bb124:
  call void @__olang_check_failed(ptr @olang_loc_eb8a0402c99d9b5e_35ace7251e3366aa)
  unreachable
bb125:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s31)
  br label %bb144
bb126:
  %t582 = load { i64, ptr }, ptr %l255, !tbaa !27
  store { i64, ptr } %t582, ptr %l263, !tbaa !27
  %t584 = load i64, ptr %l39, !tbaa !24
  %t587 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s0, ptr %l7, i64 %t584)
  store { i64, ptr } %t587, ptr %l266
  br label %bb127
bb127:
  %t588 = load { i64, ptr }, ptr %l263, !tbaa !27
  %t589 = load { i64, ptr }, ptr %l266, !tbaa !27
  %t590 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s31, ptr %s0, { i64, ptr } %t588, { i64, ptr } %t589)
  store i1 %t590, ptr %l267
  br label %bb128
bb128:
  %t591 = load i1, ptr %l267, !tbaa !21
  br i1 %t591, label %bb129, label %bb130
bb129:
  call void @__olang_scope_close(ptr %s31)
  br label %bb144
bb130:
  br label %bb131
bb131:
  %t592 = load i64, ptr %l33, !tbaa !24
  %t594 = add i64 %t592, 1
  store i64 %t594, ptr %l33, !tbaa !24
  %t596 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t596, ptr %l271, !tbaa !27
  %t597 = load i64, ptr %l39, !tbaa !24
  %t599 = getelementptr { i64, ptr }, ptr %l271, i32 0, i32 1
  %t600 = load ptr, ptr %t599, !tbaa !27
  %t601 = getelementptr { i64, ptr }, ptr %t600, i64 %t597
  %t602 = load { i64, ptr }, ptr %t601, !tbaa !37
  %t604 = extractvalue { i64, ptr } %t602, 1
  %t605 = extractvalue { i64, ptr } %t602, 0
  %t606 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t607 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t608 = add i64 %t605, %t607
  %t609 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t608)
  call void @olang_textcopy(ptr %t609, ptr %t604, i64 %t605)
  %t610 = getelementptr i8, ptr %t609, i64 %t605
  call void @olang_textcopy(ptr %t610, ptr %t606, i64 %t607)
  %t611 = insertvalue { i64, ptr } undef, i64 %t608, 0
  %t612 = insertvalue { i64, ptr } %t611, ptr %t609, 1
  %t615 = extractvalue { i64, ptr } %t612, 0
  %t616 = extractvalue { i64, ptr } %t612, 1
  %t617 = mul i64 %t615, 1
  %t618 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t617)
  call void @llvm.memcpy.p0.p0.i64(ptr %t618, ptr %t616, i64 %t617, i1 false)
  %t619 = insertvalue { i64, ptr } undef, i64 %t615, 0
  %t620 = insertvalue { i64, ptr } %t619, ptr %t618, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s31, ptr %l5, { i64, ptr } %t620)
  br label %bb132
bb132:
  %t623 = load i1, ptr %l0, !tbaa !21
  br i1 %t623, label %bb133, label %bb134
bb133:
  store %olang.scope zeroinitializer, ptr %s35
  %t625 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t625, ptr %l278, !tbaa !27
  %t626 = load i64, ptr %l39, !tbaa !24
  %t628 = getelementptr { i64, ptr }, ptr %l278, i32 0, i32 1
  %t629 = load ptr, ptr %t628, !tbaa !27
  %t630 = getelementptr { i64, ptr }, ptr %t629, i64 %t626
  %t631 = load { i64, ptr }, ptr %t630, !tbaa !37
  store { i64, ptr } %t631, ptr %l280, !tbaa !27
  %t632 = load i64, ptr %l39, !tbaa !24
  %t635 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s35, ptr %l7, i64 %t632)
  store { i64, ptr } %t635, ptr %l283
  br label %bb135
bb134:
  br label %bb143
bb135:
  %t636 = load { i64, ptr }, ptr %l283, !tbaa !27
  %t637 = load { i64, ptr }, ptr %l280, !tbaa !27
  %t639 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s35, { i64, ptr } %t637, { i64, ptr } %t636)
  store i32 %t639, ptr %l285
  %t640 = icmp ne i32 %t639, 0
  br i1 %t640, label %bb137, label %ok.641
ok.641:
  br label %bb136
bb136:
  br label %bb142
bb137:
  %t642 = load i32, ptr %l285, !tbaa !23
  %t643 = ashr i32 %t642, 16
  %t645 = icmp eq i32 %t643, 1
  br i1 %t645, label %bb138, label %bb139
bb138:
  br label %bb140
bb139:
  call void @__olang_check_failed(ptr @olang_loc_f68d3ad0be646bb1_542defd6f5c5cce5)
  unreachable
bb140:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s36
  %t647 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t647, ptr %l289, !tbaa !27
  %t648 = load i64, ptr %l39, !tbaa !24
  %t650 = getelementptr { i64, ptr }, ptr %l289, i32 0, i32 1
  %t651 = load ptr, ptr %t650, !tbaa !27
  %t652 = getelementptr { i64, ptr }, ptr %t651, i64 %t648
  %t653 = load { i64, ptr }, ptr %t652, !tbaa !37
  %t654 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t655 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t657 = extractvalue { i64, ptr } %t653, 1
  %t658 = extractvalue { i64, ptr } %t653, 0
  %t659 = add i64 %t655, %t658
  %t660 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t661 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t662 = add i64 %t659, %t661
  %t663 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t662)
  call void @olang_textcopy(ptr %t663, ptr %t654, i64 %t655)
  %t664 = getelementptr i8, ptr %t663, i64 %t655
  call void @olang_textcopy(ptr %t664, ptr %t657, i64 %t658)
  %t665 = getelementptr i8, ptr %t664, i64 %t658
  call void @olang_textcopy(ptr %t665, ptr %t660, i64 %t661)
  %t666 = insertvalue { i64, ptr } undef, i64 %t662, 0
  %t667 = insertvalue { i64, ptr } %t666, ptr %t663, 1
  %t670 = extractvalue { i64, ptr } %t667, 0
  %t671 = extractvalue { i64, ptr } %t667, 1
  %t672 = mul i64 %t670, 1
  %t673 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t672)
  call void @llvm.memcpy.p0.p0.i64(ptr %t673, ptr %t671, i64 %t672, i1 false)
  %t674 = insertvalue { i64, ptr } undef, i64 %t670, 0
  %t675 = insertvalue { i64, ptr } %t674, ptr %t673, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s36, ptr %l4, { i64, ptr } %t675)
  br label %bb141
bb141:
  call void @__olang_scope_close(ptr %s36)
  br label %bb142
bb142:
  call void @__olang_scope_close(ptr %s35)
  br label %bb143
bb143:
  call void @__olang_scope_close(ptr %s31)
  br label %bb144
bb144:
  %t678 = load i64, ptr %l38, !tbaa !24
  %t680 = add i64 %t678, 1
  store i64 %t680, ptr %l38, !tbaa !24
  br label %bb117
bb145:
  %t682 = load i64, ptr %l16, !tbaa !24
  %t684 = icmp sgt i64 %t682, 0
  br i1 %t684, label %bb146, label %bb147
bb146:
  %t686 = load i32, ptr %l15, !tbaa !23
  %t688 = icmp eq i32 %t686, 0
  store i1 %t688, ptr %l299, !tbaa !21
  br label %bb148
bb147:
  store i1 false, ptr %l299, !tbaa !21
  br label %bb148
bb148:
  %t690 = load i1, ptr %l299, !tbaa !21
  br i1 %t690, label %bb149, label %bb150
bb149:
  store %olang.scope zeroinitializer, ptr %s39
  %t691 = load i64, ptr %l16, !tbaa !24
  %t693 = icmp eq i64 %t691, 1
  br i1 %t693, label %bb151, label %bb152
bb150:
  br label %bb155
bb151:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l304, !tbaa !27
  br label %bb153
bb152:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l304, !tbaa !27
  br label %bb153
bb153:
  %t695 = load { i64, ptr }, ptr %l304, !tbaa !27
  %t696 = load i64, ptr %l16, !tbaa !24
  %t698 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t699 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t701 = call i64 @__olang_fmt_i64(ptr null, i64 %t696)
  %t702 = add i64 %t699, %t701
  %t703 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t704 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t705 = add i64 %t702, %t704
  %t707 = extractvalue { i64, ptr } %t695, 1
  %t708 = extractvalue { i64, ptr } %t695, 0
  %t709 = add i64 %t705, %t708
  %t710 = extractvalue { i64, ptr } { i64 89, ptr getelementptr inbounds (<{ i64, [89 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t711 = extractvalue { i64, ptr } { i64 89, ptr getelementptr inbounds (<{ i64, [89 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t712 = add i64 %t709, %t711
  %t713 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t712)
  call void @olang_textcopy(ptr %t713, ptr %t698, i64 %t699)
  %t714 = getelementptr i8, ptr %t713, i64 %t699
  %t715 = call i64 @__olang_fmt_i64(ptr %t714, i64 %t696)
  %t716 = getelementptr i8, ptr %t714, i64 %t701
  call void @olang_textcopy(ptr %t716, ptr %t703, i64 %t704)
  %t717 = getelementptr i8, ptr %t716, i64 %t704
  call void @olang_textcopy(ptr %t717, ptr %t707, i64 %t708)
  %t718 = getelementptr i8, ptr %t717, i64 %t708
  call void @olang_textcopy(ptr %t718, ptr %t710, i64 %t711)
  %t719 = insertvalue { i64, ptr } undef, i64 %t712, 0
  %t720 = insertvalue { i64, ptr } %t719, ptr %t713, 1
  %t723 = extractvalue { i64, ptr } %t720, 0
  %t724 = extractvalue { i64, ptr } %t720, 1
  %t725 = mul i64 %t723, 1
  %t726 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t725)
  call void @llvm.memcpy.p0.p0.i64(ptr %t726, ptr %t724, i64 %t725, i1 false)
  %t727 = insertvalue { i64, ptr } undef, i64 %t723, 0
  %t728 = insertvalue { i64, ptr } %t727, ptr %t726, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s39, ptr %l4, { i64, ptr } %t728)
  br label %bb154
bb154:
  call void @__olang_scope_close(ptr %s39)
  br label %bb155
bb155:
  %t732 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l5)
  store i32 %t732, ptr %l312
  %t733 = icmp ne i32 %t732, 0
  br i1 %t733, label %bb157, label %ok.734
ok.734:
  br label %bb156
bb156:
  br label %bb161
bb157:
  %t735 = load i32, ptr %l312, !tbaa !23
  %t736 = ashr i32 %t735, 16
  %t738 = icmp eq i32 %t736, 1
  br i1 %t738, label %bb158, label %bb159
bb158:
  br label %bb160
bb159:
  call void @__olang_check_failed(ptr @olang_loc_553f258c1fa4e7a0_ff2b7e647292c5b4)
  unreachable
bb160:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb161:
  %t742 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l4)
  store i32 %t742, ptr %l317
  %t743 = icmp ne i32 %t742, 0
  br i1 %t743, label %bb163, label %ok.744
ok.744:
  br label %bb162
bb162:
  br label %bb167
bb163:
  %t745 = load i32, ptr %l317, !tbaa !23
  %t746 = ashr i32 %t745, 16
  %t748 = icmp eq i32 %t746, 1
  br i1 %t748, label %bb164, label %bb165
bb164:
  br label %bb166
bb165:
  call void @__olang_check_failed(ptr @olang_loc_96d60822e5550738_7384588370384e4)
  unreachable
bb166:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb167:
  %t751 = load i32, ptr %l15, !tbaa !23
  %t753 = icmp ne i32 %t751, 0
  br i1 %t753, label %bb168, label %bb169
bb168:
  %t755 = load i32, ptr %l15, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t755, ptr %rv
  br label %ret
bb169:
  br label %bb170
bb170:
  %t757 = load i1, ptr %l0, !tbaa !21
  br i1 %t757, label %bb171, label %bb172
bb171:
  %t759 = load i64, ptr %l33, !tbaa !24
  %t761 = icmp sgt i64 %t759, 0
  store i1 %t761, ptr %l325, !tbaa !21
  br label %bb173
bb172:
  store i1 false, ptr %l325, !tbaa !21
  br label %bb173
bb173:
  %t763 = load i1, ptr %l325, !tbaa !21
  br i1 %t763, label %bb174, label %bb175
bb174:
  store i1 true, ptr %l328, !tbaa !21
  br label %bb176
bb175:
  %t764 = load i64, ptr %l16, !tbaa !24
  %t766 = icmp sgt i64 %t764, 0
  store i1 %t766, ptr %l328, !tbaa !21
  br label %bb176
bb176:
  %t768 = load i1, ptr %l328, !tbaa !21
  br i1 %t768, label %bb177, label %bb178
bb177:
  store i32 1, ptr %l331, !tbaa !23
  br label %bb179
bb178:
  store i32 0, ptr %l331, !tbaa !23
  br label %bb179
bb179:
  call void @__olang_scope_close(ptr %s0)
  %t769 = load i32, ptr %l331, !tbaa !23
  store i32 %t769, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ffix_2eOrder(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l23 = alloca [20 x { i64, ptr }]
  %l28 = alloca i64
  %l31 = alloca i64
  %l51 = alloca i1
  %l53 = alloca i1
  %l62 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l64 = alloca i64
  %l65 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t4 = insertvalue [2 x { i64, ptr }] %t3, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t6 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store [2 x { i64, ptr }] %t4, ptr %t6
  store ptr %t6, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t8 = load ptr, ptr %l1
  store i64 2, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t11 = load i64, ptr %l2, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb4:
  br label %bb5
bb5:
  %t19 = load ptr, ptr %l1
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = getelementptr [2 x { i64, ptr }], ptr %t19, i64 0, i64 %t20
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !37
  store { i64, ptr } %t24, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l23, ptr @G_2ecompiler_2ffix_2eToolNames, i64 320, i1 false)
  %t26 = load [20 x { i64, ptr }], ptr %l23
  store i64 20, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t28 = load i64, ptr %l6, !tbaa !24
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = icmp sgt i64 %t28, %t29
  br i1 %t32, label %bb6, label %bb7
bb6:
  %t34 = load i64, ptr %l7, !tbaa !24
  %t36 = icmp sgt i64 %t34, 0
  br i1 %t36, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb11
bb8:
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = sub i64 %t38, %t39
  %t43 = load i64, ptr %l7, !tbaa !24
  %t46 = add i64 %t42, %t43
  %t48 = sub i64 %t46, 1
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = sdiv i64 %t48, %t49
  store i64 %t52, ptr %l31, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb10
bb10:
  %t54 = load i64, ptr %l31, !tbaa !24
  store i64 %t54, ptr %l28, !tbaa !24
  br label %bb11
bb11:
  %t55 = load i64, ptr %l28, !tbaa !24
  store i64 %t55, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t56 = load i64, ptr %l9, !tbaa !24
  %t57 = load i64, ptr %l8, !tbaa !24
  %t60 = icmp slt i64 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb14:
  br label %bb15
bb15:
  %t64 = load i64, ptr %l5, !tbaa !24
  %t65 = load i64, ptr %l9, !tbaa !24
  %t66 = load i64, ptr %l7, !tbaa !24
  %t69 = mul i64 %t65, %t66
  %t72 = add i64 %t64, %t69
  store i64 %t72, ptr %l10, !tbaa !24
  %t74 = load i64, ptr %l10, !tbaa !24
  %t76 = getelementptr [20 x i64], ptr @G_2ecompiler_2ffix_2eToolKinds, i64 0, i64 %t74
  %t77 = load i64, ptr %t76, !tbaa !34
  %t79 = call i1 @compiler_2ffix_2edriven(i64 %t77)
  store i1 %t79, ptr %l51
  br label %bb16
bb16:
  %t80 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t81 = load ptr, ptr @__olang_prog_scope
  %t83 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t81, ptr %s4, { i64, ptr } %t80, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store i1 %t83, ptr %l53
  br label %bb17
bb17:
  %t84 = load i1, ptr %l51, !tbaa !21
  %t85 = load i1, ptr %l53, !tbaa !21
  %t86 = icmp eq i1 %t84, %t85
  br i1 %t86, label %bb18, label %bb19
bb18:
  %t88 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l0, i64 %t88)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb22:
  %t91 = load i64, ptr %l9, !tbaa !24
  %t93 = add i64 %t91, 1
  store i64 %t93, ptr %l9, !tbaa !24
  br label %bb12
bb23:
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb24:
  %t95 = load i64, ptr %l2, !tbaa !24
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l2, !tbaa !24
  br label %bb2
bb25:
  call void @__olang_scope_close(ptr %s1)
  %t100 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %v0, ptr %l0)
  store { i64, ptr } %t100, ptr %l62
  br label %bb26
bb26:
  %t101 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t101, ptr %l63, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 0
  store i64 %t103, ptr %l64, !tbaa !24
  %t104 = load i64, ptr %l64, !tbaa !24
  %t105 = mul i64 %t104, 8
  %t106 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t105)
  %t107 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  store { i64, ptr } %t108, ptr %l65, !tbaa !27
  %t109 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = load i64, ptr %l64, !tbaa !24
  %t114 = mul i64 %t113, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t110, ptr %t112, i64 %t114, i1 false)
  %t115 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t115, ptr %l63, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t116 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t116, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ffix_2eStdTool_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr @G_2ecompiler_2ffix_2eStdTool, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffix_2eTextTool_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr @G_2ecompiler_2ffix_2eTextTool, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffix_2eToolKinds_2einit() #0 {
entry:
  %l0 = alloca [20 x i64]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr [20 x i64], ptr %l0, i64 0, i64 0
  store i64 1, ptr %t1
  %t2 = getelementptr [20 x i64], ptr %l0, i64 0, i64 1
  store i64 2, ptr %t2
  %t3 = getelementptr [20 x i64], ptr %l0, i64 0, i64 2
  store i64 2, ptr %t3
  %t4 = getelementptr [20 x i64], ptr %l0, i64 0, i64 3
  store i64 3, ptr %t4
  %t5 = getelementptr [20 x i64], ptr %l0, i64 0, i64 4
  store i64 0, ptr %t5
  %t6 = getelementptr [20 x i64], ptr %l0, i64 0, i64 5
  store i64 0, ptr %t6
  %t7 = getelementptr [20 x i64], ptr %l0, i64 0, i64 6
  store i64 0, ptr %t7
  %t8 = getelementptr [20 x i64], ptr %l0, i64 0, i64 7
  store i64 0, ptr %t8
  %t9 = getelementptr [20 x i64], ptr %l0, i64 0, i64 8
  store i64 0, ptr %t9
  %t10 = getelementptr [20 x i64], ptr %l0, i64 0, i64 9
  store i64 0, ptr %t10
  %t11 = getelementptr [20 x i64], ptr %l0, i64 0, i64 10
  store i64 0, ptr %t11
  %t12 = getelementptr [20 x i64], ptr %l0, i64 0, i64 11
  store i64 0, ptr %t12
  %t13 = getelementptr [20 x i64], ptr %l0, i64 0, i64 12
  store i64 2, ptr %t13
  %t14 = getelementptr [20 x i64], ptr %l0, i64 0, i64 13
  store i64 0, ptr %t14
  %t15 = getelementptr [20 x i64], ptr %l0, i64 0, i64 14
  store i64 0, ptr %t15
  %t16 = getelementptr [20 x i64], ptr %l0, i64 0, i64 15
  store i64 0, ptr %t16
  %t17 = getelementptr [20 x i64], ptr %l0, i64 0, i64 16
  store i64 0, ptr %t17
  %t18 = getelementptr [20 x i64], ptr %l0, i64 0, i64 17
  store i64 0, ptr %t18
  %t19 = getelementptr [20 x i64], ptr %l0, i64 0, i64 18
  store i64 2, ptr %t19
  %t20 = getelementptr [20 x i64], ptr %l0, i64 0, i64 19
  store i64 0, ptr %t20
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2ffix_2eToolKinds, ptr %l0, i64 160, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffix_2eToolNames_2einit() #0 {
entry:
  %l0 = alloca [20 x { i64, ptr }]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr [20 x { i64, ptr }], ptr %l0, i64 0, i64 0
  store { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d30, i32 0, i32 1) }, ptr %t1
  %t2 = getelementptr [20 x { i64, ptr }], ptr %l0, i64 0, i64 1
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %t2
  %t3 = getelementptr [20 x { i64, ptr }], ptr %l0, i64 0, i64 2
  store { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d32, i32 0, i32 1) }, ptr %t3
  %t4 = getelementptr [20 x { i64, ptr }], ptr %l0, i64 0, i64 3
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d33, i32 0, i32 1) }, ptr %t4
  %t5 = getelementptr [20 x { i64, ptr }], ptr %l0, i64 0, i64 4
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d34, i32 0, i32 1) }, ptr %t5
  %t6 = getelementptr [20 x { i64, ptr }], ptr %l0, i64 0, i64 5
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d35, i32 0, i32 1) }, ptr %t6
  %t7 = getelementptr [20 x { i64, ptr }], ptr %l0, i64 0, i64 6
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d36, i32 0, i32 1) }, ptr %t7
  %t8 = getelementptr [20 x { i64, ptr }], ptr %l0, i64 0, i64 7
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d37, i32 0, i32 1) }, ptr %t8
  %t9 = getelementptr [20 x { i64, ptr }], ptr %l0, i64 0, i64 8
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %t9
  %t10 = getelementptr [20 x { i64, ptr }], ptr %l0, i64 0, i64 9
  store { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d39, i32 0, i32 1) }, ptr %t10
  %t11 = getelementptr [20 x { i64, ptr }], ptr %l0, i64 0, i64 10
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %t11
  %t12 = getelementptr [20 x { i64, ptr }], ptr %l0, i64 0, i64 11
  store { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d41, i32 0, i32 1) }, ptr %t12
  %t13 = getelementptr [20 x { i64, ptr }], ptr %l0, i64 0, i64 12
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d42, i32 0, i32 1) }, ptr %t13
  %t14 = getelementptr [20 x { i64, ptr }], ptr %l0, i64 0, i64 13
  store { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d43, i32 0, i32 1) }, ptr %t14
  %t15 = getelementptr [20 x { i64, ptr }], ptr %l0, i64 0, i64 14
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d44, i32 0, i32 1) }, ptr %t15
  %t16 = getelementptr [20 x { i64, ptr }], ptr %l0, i64 0, i64 15
  store { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d45, i32 0, i32 1) }, ptr %t16
  %t17 = getelementptr [20 x { i64, ptr }], ptr %l0, i64 0, i64 16
  store { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d46, i32 0, i32 1) }, ptr %t17
  %t18 = getelementptr [20 x { i64, ptr }], ptr %l0, i64 0, i64 17
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d47, i32 0, i32 1) }, ptr %t18
  %t19 = getelementptr [20 x { i64, ptr }], ptr %l0, i64 0, i64 18
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %t19
  %t20 = getelementptr [20 x { i64, ptr }], ptr %l0, i64 0, i64 19
  store { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d49, i32 0, i32 1) }, ptr %t20
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2ffix_2eToolNames, ptr %l0, i64 320, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ffix_2eToolsDir(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l9 = alloca i1
  %l14 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d50, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l4
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  store { i64, ptr } %t2, ptr %l3
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d51, i32 0, i32 1) }, ptr %l5, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t10 = extractvalue { i64, ptr } %t7, 1
  %t11 = mul i64 %t9, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t10, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  br label %bb4
bb4:
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t16, ptr %l1, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t17, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d52, i32 0, i32 1) })
  store i1 %t19, ptr %l9
  br label %bb5
bb5:
  %t20 = load i1, ptr %l9, !tbaa !21
  %t21 = xor i1 %t20, true
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = extractvalue { i64, ptr } %t23, 0
  %t27 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t25, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t29, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t33 = call { i64, ptr } @std_2ffilepath_2eDir(ptr %v0, { i64, ptr } %a0)
  store { i64, ptr } %t33, ptr %l14
  br label %bb9
bb9:
  %t34 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 1
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t37 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t39 = add i64 %t36, %t38
  %t40 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t39)
  call void @olang_textcopy(ptr %t40, ptr %t35, i64 %t36)
  %t41 = getelementptr i8, ptr %t40, i64 %t36
  call void @olang_textcopy(ptr %t41, ptr %t37, i64 %t38)
  %t42 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t40, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t43, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ffix_2earguments(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %lp5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l45 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca { i64, ptr }
  %s11 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v4)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 8, i64 8)
  store ptr %t2, ptr %lp5
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  %t4 = load ptr, ptr %lp5
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  %t5 = load ptr, ptr %lp5
  %t8 = extractvalue { i64, ptr } %a0, 1
  %t9 = extractvalue { i64, ptr } %a0, 0
  %t10 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t9)
  call void @olang_textcopy(ptr %t10, ptr %t8, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t15 = extractvalue { i64, ptr } %t12, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v4, ptr %v4, ptr %t5, { i64, ptr } %t19)
  br label %bb2
bb2:
  %t22 = load i64, ptr %l1, !tbaa !24
  %t23 = load i64, ptr @G_2ecompiler_2ffix_2eStdTool, !tbaa !24
  %t26 = icmp eq i64 %t22, %t23
  br i1 %t26, label %bb3, label %bb4
bb3:
  %t28 = load ptr, ptr %lp5
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v4, ptr %v4, ptr %t28, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d54, i32 0, i32 1) })
  br label %bb5
bb4:
  %t30 = load i64, ptr %l1, !tbaa !24
  %t31 = load i64, ptr @G_2ecompiler_2ffix_2eDrivenOpt, !tbaa !24
  %t34 = icmp eq i64 %t30, %t31
  br i1 %t34, label %bb7, label %bb8
bb5:
  %t36 = load ptr, ptr %lp5
  %t39 = extractvalue { i64, ptr } %a3, 1
  %t40 = extractvalue { i64, ptr } %a3, 0
  %t41 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t40)
  call void @olang_textcopy(ptr %t41, ptr %t39, i64 %t40)
  %t42 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t46 = extractvalue { i64, ptr } %t43, 1
  %t47 = mul i64 %t45, 1
  %t48 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t47)
  call void @llvm.memcpy.p0.p0.i64(ptr %t48, ptr %t46, i64 %t47, i1 false)
  %t49 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v4, ptr %v4, ptr %t36, { i64, ptr } %t50)
  br label %bb6
bb6:
  br label %bb16
bb7:
  %t53 = load ptr, ptr %lp5
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v4, ptr %v4, ptr %t53, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d55, i32 0, i32 1) })
  br label %bb9
bb8:
  %t55 = load i64, ptr %l1, !tbaa !24
  %t56 = load i64, ptr @G_2ecompiler_2ffix_2eDrivenArg, !tbaa !24
  %t59 = icmp eq i64 %t55, %t56
  br i1 %t59, label %bb11, label %bb12
bb9:
  %t61 = load ptr, ptr %lp5
  %t62 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t62, 1
  %t65 = extractvalue { i64, ptr } %t62, 0
  %t66 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t65)
  call void @olang_textcopy(ptr %t66, ptr %t64, i64 %t65)
  %t67 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t71 = extractvalue { i64, ptr } %t68, 1
  %t72 = mul i64 %t70, 1
  %t73 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t72)
  call void @llvm.memcpy.p0.p0.i64(ptr %t73, ptr %t71, i64 %t72, i1 false)
  %t74 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v4, ptr %v4, ptr %t61, { i64, ptr } %t75)
  br label %bb10
bb10:
  br label %bb15
bb11:
  %t78 = load ptr, ptr %lp5
  %t79 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t79, 1
  %t82 = extractvalue { i64, ptr } %t79, 0
  %t83 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t82)
  call void @olang_textcopy(ptr %t83, ptr %t81, i64 %t82)
  %t84 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t83, 1
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t88 = extractvalue { i64, ptr } %t85, 1
  %t89 = mul i64 %t87, 1
  %t90 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t89)
  call void @llvm.memcpy.p0.p0.i64(ptr %t90, ptr %t88, i64 %t89, i1 false)
  %t91 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t90, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v4, ptr %v4, ptr %t78, { i64, ptr } %t92)
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  store { i64, ptr } %a4, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t97 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  store i64 %t99, ptr %l8, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s11
  %t101 = load i64, ptr %l7, !tbaa !24
  %t102 = load i64, ptr %l8, !tbaa !24
  %t105 = icmp slt i64 %t101, %t102
  %t107 = xor i1 %t105, true
  br i1 %t107, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s11)
  br label %bb23
bb19:
  br label %bb20
bb20:
  %t109 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t109, ptr %l45, !tbaa !27
  %t110 = load i64, ptr %l7, !tbaa !24
  %t112 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr { i64, ptr }, ptr %t113, i64 %t110
  %t115 = load { i64, ptr }, ptr %t114, !tbaa !37
  %t117 = load ptr, ptr %lp5
  %t120 = extractvalue { i64, ptr } %t115, 1
  %t121 = extractvalue { i64, ptr } %t115, 0
  %t122 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t121)
  call void @olang_textcopy(ptr %t122, ptr %t120, i64 %t121)
  %t123 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  %t126 = extractvalue { i64, ptr } %t124, 0
  %t127 = extractvalue { i64, ptr } %t124, 1
  %t128 = mul i64 %t126, 1
  %t129 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t128)
  call void @llvm.memcpy.p0.p0.i64(ptr %t129, ptr %t127, i64 %t128, i1 false)
  %t130 = insertvalue { i64, ptr } undef, i64 %t126, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t129, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v4, ptr %v4, ptr %t117, { i64, ptr } %t131)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s11)
  br label %bb22
bb22:
  %t134 = load i64, ptr %l7, !tbaa !24
  %t136 = add i64 %t134, 1
  store i64 %t136, ptr %l7, !tbaa !24
  br label %bb17
bb23:
  %t138 = load ptr, ptr %lp5
  %t140 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hd4bdf3befe2f7a35847f168802c5df68(ptr %v4, ptr %v4, ptr %t138)
  store { i64, ptr } %t140, ptr %l55
  br label %bb24
bb24:
  %t141 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t141, ptr %l56, !tbaa !27
  %t142 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t142, 0
  store i64 %t143, ptr %l57, !tbaa !24
  %t144 = load i64, ptr %l57, !tbaa !24
  %t145 = mul i64 %t144, 16
  %t146 = call ptr @__olang_scope_alloc_zeroed(ptr %v4, i64 %t145)
  %t147 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  store { i64, ptr } %t148, ptr %l58, !tbaa !27
  %t149 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = load i64, ptr %l57, !tbaa !24
  %t154 = mul i64 %t153, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t150, ptr %t152, i64 %t154, i1 false)
  %t155 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t155, ptr %l56, !tbaa !27
  %t156 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t156, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ffix_2ebyHand(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca %"std/prelude/text:LineIter"
  %l4 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/text:LineIter"
  %l7 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l14 = alloca i1
  %l18 = alloca i1
  %l20 = alloca i1
  %l22 = alloca i1
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  store i1 false, ptr %l2, !tbaa !21
  %t3 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store %"std/prelude/text:LineIter" %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load %"std/prelude/text:LineIter", ptr %l6
  store %"std/prelude/text:LineIter" %t4, ptr %l3
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t6 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %l3)
  %t7 = extractvalue { i32, { i64, ptr } } %t6, 1
  %t8 = extractvalue { i32, { i64, ptr } } %t6, 0
  store i32 %t8, ptr %l10
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb4, label %ok.10
ok.10:
  store { i64, ptr } %t7, ptr %l9
  br label %bb3
bb3:
  %t11 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t11, ptr %l7, !tbaa !27
  br label %bb8
bb4:
  %t12 = load i32, ptr %l10, !tbaa !23
  %t13 = ashr i32 %t12, 16
  %t15 = icmp eq i32 %t13, 1
  br i1 %t15, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_e6e24e0024ea2a04_be8f31c3c206f038)
  unreachable
bb7:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb8:
  %t17 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t17, ptr %l4, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t20 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t18, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d56, i32 0, i32 1) })
  store i1 %t20, ptr %l14
  br label %bb9
bb9:
  %t21 = load i1, ptr %l14, !tbaa !21
  br i1 %t21, label %bb10, label %bb11
bb10:
  %t22 = load i64, ptr %l1, !tbaa !24
  %t24 = add i64 %t22, 1
  store i64 %t24, ptr %l1, !tbaa !24
  br label %bb23
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t26 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t28 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t26, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d57, i32 0, i32 1) })
  store i1 %t28, ptr %l18
  br label %bb12
bb12:
  %t29 = load i1, ptr %l18, !tbaa !21
  br i1 %t29, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb22
bb14:
  store %olang.scope zeroinitializer, ptr %s6
  %t30 = load i1, ptr %l2, !tbaa !21
  br i1 %t30, label %bb15, label %bb16
bb15:
  %t32 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t34 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s6, { i64, ptr } %t32, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d58, i32 0, i32 1) })
  store i1 %t34, ptr %l22
  br label %bb17
bb16:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb18
bb17:
  %t35 = load i1, ptr %l22, !tbaa !21
  store i1 %t35, ptr %l20, !tbaa !21
  br label %bb18
bb18:
  %t36 = load i1, ptr %l20, !tbaa !21
  br i1 %t36, label %bb19, label %bb20
bb19:
  %t37 = load i64, ptr %l1, !tbaa !24
  %t39 = add i64 %t37, 1
  store i64 %t39, ptr %l1, !tbaa !24
  br label %bb21
bb20:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s6)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb24:
  br label %bb2
bb25:
  %t41 = load i64, ptr %l1, !tbaa !24
  store i64 %t41, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffix_2edriven(i64 %a0) #0 {
entry:
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i64, ptr @G_2ecompiler_2ffix_2eDrivenOpt, !tbaa !24
  %t5 = icmp sge i64 %a0, %t2
  store i1 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffix_2eensureBuilt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/os:Output"
  %l11 = alloca { i64, ptr }
  %l13 = alloca i64
  %l15 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l21 = alloca %"std/os:Output"
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l33 = alloca %"std/os:Output"
  %l34 = alloca i32
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t3 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %t2, 1
  %t7 = extractvalue { i64, ptr } %t2, 0
  %t8 = add i64 %t4, %t7
  %t9 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t8)
  call void @olang_textcopy(ptr %t9, ptr %t3, i64 %t4)
  %t10 = getelementptr i8, ptr %t9, i64 %t4
  call void @olang_textcopy(ptr %t10, ptr %t6, i64 %t7)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t9, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t15 = extractvalue { i64, ptr } %t12, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  %t22 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %v2, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t1, { i64, ptr } %t19, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d7, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store { i64, ptr } %t22, ptr %l11
  br label %bb1
bb1:
  %t23 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t23, ptr %l5, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t26 = call i64 @compiler_2ffix_2emtime(ptr %s0, { i64, ptr } %t24)
  store i64 %t26, ptr %l13
  br label %bb2
bb2:
  %t27 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t29 = call i64 @compiler_2ffix_2emtime(ptr %v0, { i64, ptr } %t27)
  store i64 %t29, ptr %l15
  br label %bb3
bb3:
  %t30 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t32 = call i64 @compiler_2ffix_2enewest(ptr %v1, { i64, ptr } %t30)
  store i64 %t32, ptr %l17
  br label %bb4
bb4:
  %t33 = load i64, ptr %l15, !tbaa !24
  %t34 = load i64, ptr %l17, !tbaa !24
  %t35 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t33, i64 %t34)
  store i64 %t35, ptr %l18
  br label %bb5
bb5:
  %t36 = load i64, ptr %l13, !tbaa !24
  %t37 = load i64, ptr %l18, !tbaa !24
  %t38 = icmp sgt i64 %t36, %t37
  br i1 %t38, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t41 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t41, ptr %l22, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t42, ptr %l23, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 1
  %t47 = extractvalue { i64, ptr } %t44, 0
  %t48 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t50 = add i64 %t47, %t49
  %t51 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t50)
  call void @olang_textcopy(ptr %t51, ptr %t46, i64 %t47)
  %t52 = getelementptr i8, ptr %t51, i64 %t47
  call void @olang_textcopy(ptr %t52, ptr %t48, i64 %t49)
  %t53 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t51, 1
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t57 = extractvalue { i64, ptr } %t54, 1
  %t58 = mul i64 %t56, 1
  %t59 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t58)
  call void @llvm.memcpy.p0.p0.i64(ptr %t59, ptr %t57, i64 %t58, i1 false)
  %t60 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  %t64 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %v1, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t43, { i64, ptr } %t61, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d7, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store { i64, ptr } %t64, ptr %l28
  br label %bb9
bb9:
  %t65 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  %t67 = extractvalue { i64, ptr } %t65, 1
  %t68 = mul i64 %t66, 1
  %t69 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t68)
  call void @llvm.memcpy.p0.p0.i64(ptr %t69, ptr %t67, i64 %t68, i1 false)
  %t70 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  %t72 = mul i64 5, 16
  %t73 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 5, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  store { i64, ptr } %t75, ptr %l30, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t77 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %t78, i64 0
  store { i64, ptr } %t76, ptr %t79, !tbaa !37
  %t80 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr { i64, ptr }, ptr %t81, i64 1
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d61, i32 0, i32 1) }, ptr %t82, !tbaa !37
  %t83 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr { i64, ptr }, ptr %t84, i64 2
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d62, i32 0, i32 1) }, ptr %t85, !tbaa !37
  %t86 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t87 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr { i64, ptr }, ptr %t88, i64 3
  store { i64, ptr } %t86, ptr %t89, !tbaa !37
  %t91 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr { i64, ptr }, ptr %t92, i64 4
  store { i64, ptr } %t71, ptr %t93, !tbaa !37
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d63, i32 0, i32 1) }, ptr %l31, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t95 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t98 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s0, ptr %s0, ptr %v2, ptr %s0, { i64, ptr } %t95, { i64, ptr } %t96, i1 true, { i64, ptr } %t94)
  %t99 = extractvalue { i32, %"std/os:Output" } %t98, 1
  %t100 = extractvalue { i32, %"std/os:Output" } %t98, 0
  store i32 %t100, ptr %l34
  %t101 = icmp ne i32 %t100, 0
  br i1 %t101, label %bb11, label %ok.102
ok.102:
  store %"std/os:Output" %t99, ptr %l33
  br label %bb10
bb10:
  %t103 = load %"std/os:Output", ptr %l33
  store %"std/os:Output" %t103, ptr %l21
  br label %bb16
bb11:
  %t104 = load i32, ptr %l34, !tbaa !23
  %t105 = ashr i32 %t104, 16
  %t107 = icmp eq i32 %t105, 1
  br i1 %t107, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_9e1364cb140a9a66_28aa9a3ffa2ccf1a)
  unreachable
bb14:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s4
  %t109 = load ptr, ptr %l4, !tbaa !29
  %t110 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t111 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t112 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t114 = extractvalue { i64, ptr } %t110, 1
  %t115 = extractvalue { i64, ptr } %t110, 0
  %t116 = add i64 %t112, %t115
  %t117 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t118 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  %t119 = add i64 %t116, %t118
  %t120 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t119)
  call void @olang_textcopy(ptr %t120, ptr %t111, i64 %t112)
  %t121 = getelementptr i8, ptr %t120, i64 %t112
  call void @olang_textcopy(ptr %t121, ptr %t114, i64 %t115)
  %t122 = getelementptr i8, ptr %t121, i64 %t115
  call void @olang_textcopy(ptr %t122, ptr %t117, i64 %t118)
  %t123 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t120, 1
  %t127 = extractvalue { i64, ptr } %t124, 0
  %t128 = extractvalue { i64, ptr } %t124, 1
  %t129 = mul i64 %t127, 1
  %t130 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t129)
  call void @llvm.memcpy.p0.p0.i64(ptr %t130, ptr %t128, i64 %t129, i1 false)
  %t131 = insertvalue { i64, ptr } undef, i64 %t127, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v4, ptr %s4, ptr %t109, { i64, ptr } %t132)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb16:
  %t136 = load %"std/os:Output", ptr %l21
  store %"std/os:Output" %t136, ptr %l6
  %t137 = getelementptr %"std/os:Output", ptr %l6, i32 0, i32 0
  %t138 = load i32, ptr %t137, !tbaa !23
  %t140 = icmp ne i32 %t138, 0
  br i1 %t140, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  %t142 = load ptr, ptr %l4, !tbaa !29
  %t143 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t144 = getelementptr %"std/os:Output", ptr %l6, i32 0, i32 1
  %t145 = load { i64, ptr }, ptr %t144, !tbaa !27
  %t146 = getelementptr %"std/os:Output", ptr %l6, i32 0, i32 2
  %t147 = load { i64, ptr }, ptr %t146, !tbaa !27
  %t148 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t149 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t151 = extractvalue { i64, ptr } %t143, 1
  %t152 = extractvalue { i64, ptr } %t143, 0
  %t153 = add i64 %t149, %t152
  %t154 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t155 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t156 = add i64 %t153, %t155
  %t158 = extractvalue { i64, ptr } %t145, 1
  %t159 = extractvalue { i64, ptr } %t145, 0
  %t160 = add i64 %t156, %t159
  %t162 = extractvalue { i64, ptr } %t147, 1
  %t163 = extractvalue { i64, ptr } %t147, 0
  %t164 = add i64 %t160, %t163
  %t165 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t164)
  call void @olang_textcopy(ptr %t165, ptr %t148, i64 %t149)
  %t166 = getelementptr i8, ptr %t165, i64 %t149
  call void @olang_textcopy(ptr %t166, ptr %t151, i64 %t152)
  %t167 = getelementptr i8, ptr %t166, i64 %t152
  call void @olang_textcopy(ptr %t167, ptr %t154, i64 %t155)
  %t168 = getelementptr i8, ptr %t167, i64 %t155
  call void @olang_textcopy(ptr %t168, ptr %t158, i64 %t159)
  %t169 = getelementptr i8, ptr %t168, i64 %t159
  call void @olang_textcopy(ptr %t169, ptr %t162, i64 %t163)
  %t170 = insertvalue { i64, ptr } undef, i64 %t164, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t165, 1
  %t174 = extractvalue { i64, ptr } %t171, 0
  %t175 = extractvalue { i64, ptr } %t171, 1
  %t176 = mul i64 %t174, 1
  %t177 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t176)
  call void @llvm.memcpy.p0.p0.i64(ptr %t177, ptr %t175, i64 %t176, i1 false)
  %t178 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t177, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v4, ptr %s6, ptr %t142, { i64, ptr } %t179)
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb20:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffix_2eexpand(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %lp1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca { i64, ptr }
  %l18 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb4:
  br label %bb5
bb5:
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t19, ptr %l14, !tbaa !27
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %t23, i64 %t20
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !37
  store { i64, ptr } %t25, ptr %l5, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t29 = call i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %t27)
  store i1 %t29, ptr %l18
  br label %bb6
bb6:
  %t30 = load i1, ptr %l18, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  %t31 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t32 = load ptr, ptr %lp1
  call void @compiler_2ffix_2ewalk(ptr %v0, ptr %v1, { i64, ptr } %t31, ptr %t32)
  br label %bb9
bb8:
  %t35 = load ptr, ptr %lp1
  %t36 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 1
  %t39 = extractvalue { i64, ptr } %t36, 0
  %t40 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t39)
  call void @olang_textcopy(ptr %t40, ptr %t38, i64 %t39)
  %t41 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t45 = extractvalue { i64, ptr } %t42, 1
  %t46 = mul i64 %t44, 1
  %t47 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t46)
  call void @llvm.memcpy.p0.p0.i64(ptr %t47, ptr %t45, i64 %t46, i1 false)
  %t48 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t35, { i64, ptr } %t49)
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb12:
  %t52 = load i64, ptr %l3, !tbaa !24
  %t54 = add i64 %t52, 1
  store i64 %t54, ptr %l3, !tbaa !24
  br label %bb2
bb13:
  %t56 = load ptr, ptr %lp1
  %t57 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t56
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t57, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i64 @compiler_2ffix_2emtime(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/os:FileInfo"
  %l2 = alloca %"std/os:FileInfo"
  %l4 = alloca %"std/os:FileInfo"
  %l5 = alloca i32
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v0, { i64, ptr } %a0)
  %t4 = extractvalue { i32, %"std/os:FileInfo" } %t3, 1
  %t5 = extractvalue { i32, %"std/os:FileInfo" } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store %"std/os:FileInfo" %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load %"std/os:FileInfo", ptr %l4
  store %"std/os:FileInfo" %t8, ptr %l2
  br label %bb6
bb2:
  %t9 = load i32, ptr %l5, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  br i1 %t12, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_23f451298266bf5e_2593b028faf03d0a)
  unreachable
bb5:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %rv
  br label %ret
bb6:
  %t15 = load %"std/os:FileInfo", ptr %l2
  store %"std/os:FileInfo" %t15, ptr %l1
  %t16 = getelementptr %"std/os:FileInfo", ptr %l1, i32 0, i32 2
  %t17 = load i64, ptr %t16, !tbaa !24
  store i64 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ffix_2enewest(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l21 = alloca { i64, ptr }
  %l25 = alloca i1
  %l26 = alloca i64
  %l29 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %s0, { i64, ptr } %t1)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l10
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store { i64, ptr } %t4, ptr %l9
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t8, ptr %l7, !tbaa !27
  br label %bb8
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  %t9 = icmp sge i64 0, 0
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t11 = icmp sle i64 0, 576460752303423487
  br i1 %t11, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_8fcf87cfa7be21dd_bbd76dac3520f231)
  unreachable
bb6:
  %t13 = mul i64 0, 16
  %t14 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 0, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l7, !tbaa !27
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_8fcf87cfa7be21dd_bbd76dac3520f231)
  unreachable
bb8:
  %t18 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t18, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l5, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t25 = load i64, ptr %l4, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb11:
  br label %bb12
bb12:
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t33, ptr %l21, !tbaa !27
  %t34 = load i64, ptr %l4, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %t37, i64 %t34
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !37
  store { i64, ptr } %t39, ptr %l6, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t43 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s2, { i64, ptr } %t41, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d68, i32 0, i32 1) })
  store i1 %t43, ptr %l25
  br label %bb13
bb13:
  %t44 = load i1, ptr %l25, !tbaa !21
  br i1 %t44, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t45 = load i64, ptr %l1, !tbaa !24
  store i64 %t45, ptr %l26, !tbaa !24
  %t46 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t50 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %s0, ptr %s3, ptr %s3, ptr %s3, ptr %s3, ptr %s3, { i64, ptr } %t46, { i64, ptr } %t47, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d7, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store { i64, ptr } %t50, ptr %l29
  br label %bb16
bb15:
  br label %bb19
bb16:
  %t51 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t51, 0
  %t53 = extractvalue { i64, ptr } %t51, 1
  %t54 = mul i64 %t52, 1
  %t55 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t54)
  call void @llvm.memcpy.p0.p0.i64(ptr %t55, ptr %t53, i64 %t54, i1 false)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  %t59 = call i64 @compiler_2ffix_2emtime(ptr %s3, { i64, ptr } %t57)
  store i64 %t59, ptr %l31
  br label %bb17
bb17:
  %t60 = load i64, ptr %l26, !tbaa !24
  %t61 = load i64, ptr %l31, !tbaa !24
  %t62 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t60, i64 %t61)
  store i64 %t62, ptr %l32
  br label %bb18
bb18:
  %t63 = load i64, ptr %l32, !tbaa !24
  store i64 %t63, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  %t64 = load i64, ptr %l4, !tbaa !24
  %t66 = add i64 %t64, 1
  store i64 %t66, ptr %l4, !tbaa !24
  br label %bb9
bb21:
  %t68 = load i64, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t68, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffix_2ewalk(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i32
  %l22 = alloca { i64, ptr }
  %l26 = alloca i1
  %l27 = alloca i1
  %l29 = alloca i1
  %l32 = alloca { i64, ptr }
  %l34 = alloca i1
  %l38 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %s0, { i64, ptr } %t1)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l11
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store { i64, ptr } %t4, ptr %l10
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t8, ptr %l8, !tbaa !27
  br label %bb8
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  %t9 = icmp sge i64 0, 0
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t11 = icmp sle i64 0, 576460752303423487
  br i1 %t11, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_9433da86f750b978_3ff5b65d50af9d4)
  unreachable
bb6:
  %t13 = mul i64 0, 16
  %t14 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 0, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l8, !tbaa !27
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_9433da86f750b978_3ff5b65d50af9d4)
  unreachable
bb8:
  %t18 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t18, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l5, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t25 = load i64, ptr %l4, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb11:
  br label %bb12
bb12:
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t33, ptr %l22, !tbaa !27
  %t34 = load i64, ptr %l4, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %t37, i64 %t34
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !37
  store { i64, ptr } %t39, ptr %l6, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t43 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s2, { i64, ptr } %t41, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d69, i32 0, i32 1) })
  store i1 %t43, ptr %l26
  br label %bb13
bb13:
  %t44 = load i1, ptr %l26, !tbaa !21
  br i1 %t44, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb17
bb15:
  %t45 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t47 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s2, { i64, ptr } %t45, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d70, i32 0, i32 1) })
  store i1 %t47, ptr %l29
  br label %bb16
bb16:
  %t48 = load i1, ptr %l29, !tbaa !21
  store i1 %t48, ptr %l27, !tbaa !21
  br label %bb17
bb17:
  %t49 = load i1, ptr %l27, !tbaa !21
  br i1 %t49, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb19:
  br label %bb20
bb20:
  %t50 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t54 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %s0, ptr %s2, ptr %s2, ptr %s2, ptr %s2, ptr %s2, { i64, ptr } %t50, { i64, ptr } %t51, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d7, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store { i64, ptr } %t54, ptr %l32
  br label %bb21
bb21:
  %t55 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t55, ptr %l7, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t58 = call i1 @std_2fos_2eIsDir(ptr %s2, { i64, ptr } %t56)
  store i1 %t58, ptr %l34
  br label %bb22
bb22:
  %t59 = load i1, ptr %l34, !tbaa !21
  br i1 %t59, label %bb23, label %bb24
bb23:
  %t60 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t61 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ffix_2ewalk(ptr %s2, ptr %v1, { i64, ptr } %t60, ptr %t61)
  br label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t64 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t66 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s5, { i64, ptr } %t64, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d71, i32 0, i32 1) })
  store i1 %t66, ptr %l38
  br label %bb26
bb25:
  br label %bb31
bb26:
  %t67 = load i1, ptr %l38, !tbaa !21
  br i1 %t67, label %bb27, label %bb28
bb27:
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t69 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t69, 1
  %t72 = extractvalue { i64, ptr } %t69, 0
  %t73 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t72)
  call void @olang_textcopy(ptr %t73, ptr %t71, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  %t77 = extractvalue { i64, ptr } %t75, 0
  %t78 = extractvalue { i64, ptr } %t75, 1
  %t79 = mul i64 %t77, 1
  %t80 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t79)
  call void @llvm.memcpy.p0.p0.i64(ptr %t80, ptr %t78, i64 %t79, i1 false)
  %t81 = insertvalue { i64, ptr } undef, i64 %t77, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t80, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t68, { i64, ptr } %t82)
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb32:
  %t85 = load i64, ptr %l4, !tbaa !24
  %t87 = add i64 %t85, 1
  store i64 %t87, ptr %l4, !tbaa !24
  br label %bb9
bb33:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @olang_2einit_2ecompiler_2ffix() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2ffix_2eTextTool_2einit()
  br label %bb1
bb1:
  call void @compiler_2ffix_2eStdTool_2einit()
  br label %bb2
bb2:
  call void @compiler_2ffix_2eDrivenOpt_2einit()
  br label %bb3
bb3:
  call void @compiler_2ffix_2eDrivenArg_2einit()
  br label %bb4
bb4:
  call void @compiler_2ffix_2eToolNames_2einit()
  br label %bb5
bb5:
  call void @compiler_2ffix_2eToolKinds_2einit()
  br label %bb6
bb6:
  call void @compiler_2ffix_2eBatch_2einit()
  br label %bb7
bb7:
  br label %ret
ret:
  ret void
}

declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr)
declare void @__olang_ert_req_clear()
@.d0 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d1 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c": cannot be read\0A" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d2 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"olang: fix: no tools directory at " }>, align 8
@.d3 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c" (OLANG_TOOLS names another)\0A" }>, align 8
@.d4 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fix" }>, align 8
@.d5 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d6 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d7 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d9 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"olang: fix: cannot make " }>, align 8
@.d10 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d11 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"tools_" }>, align 8
@.d12 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d13 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d14 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"olang: fix: cannot run " }>, align 8
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d16 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c":\0A" }>, align 8
@.d17 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d18 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d19 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d20 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d21 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c": cannot be written\0A" }>, align 8
@.d22 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d23 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d24 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"olang fix: " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d25 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" place" }>, align 8
@.d26 = private constant <{ i64, [89 x i8] }> <{ i64 0, [89 x i8] c" above may mean something else in the language of today than when written - look at each\0A" }>, align 8
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d27 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"text" }>, align 8
@.d28 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"driven" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d29 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"driven" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d30 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"bare_typevars" }>, align 8
@.d31 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"perm_mut" }>, align 8
@.d32 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"int_literal_i64" }>, align 8
@.d33 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"errors_migrate" }>, align 8
@.d34 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"cli_words" }>, align 8
@.d35 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"donefail_migrate" }>, align 8
@.d36 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"syntax_migrate" }>, align 8
@.d37 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"math_methods" }>, align 8
@.d38 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"arrays_migrate" }>, align 8
@.d39 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"results_migrate" }>, align 8
@.d40 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"equality_migrate" }>, align 8
@.d41 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"helper_rename" }>, align 8
@.d42 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"null_migrate" }>, align 8
@.d43 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"checkerror_rename" }>, align 8
@.d44 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"stutter_rename" }>, align 8
@.d45 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"checked_migrate" }>, align 8
@.d46 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"contracts_migrate" }>, align 8
@.d47 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"try_migrate" }>, align 8
@.d48 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"as_migrate" }>, align 8
@.d49 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"errortype_migrate" }>, align 8
@.d50 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"OLANG_TOOLS" }>, align 8
@.d51 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d52 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d53 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"/../tools" }>, align 8
@.d54 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"--std" }>, align 8
@.d55 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"--olang" }>, align 8
@.d56 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"by hand:" }>, align 8
@.d57 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"for a person:" }>, align 8
@.d58 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d59 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"tools_" }>, align 8
@.d60 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@.d61 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"build" }>, align 8
@.d62 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"-output" }>, align 8
@.d63 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d64 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"olang: fix: cannot run " }>, align 8
@.d65 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d66 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"olang: fix: tools/" }>, align 8
@.d67 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c".olang does not build:\0A" }>, align 8
@.d68 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@.d69 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d70 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"build" }>, align 8
@.d71 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %v0, i32 %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hd4bdf3befe2f7a35847f168802c5df68(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_55e63acaa25cfd39_d0989827e133efd = external constant [0 x i8]
declare void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %v0, ptr %a0)
@olang_loc_26781d70abdd0d68_5f1bea27110e64cc = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %a0)
@olang_loc_e6a6422eb79d2443_db90500efc9fb0c7 = external constant [0 x i8]
declare { i64, ptr } @compiler_2ffetch_2eCacheDir(ptr %v0)
declare { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, { i64, ptr } %a5)
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
@olang_loc_aaa99c12ebecdcc2_f002f5bd4abfbc66 = external constant [0 x i8]
@olang_loc_d21c474f19498c95_d0832220e57344c1 = external constant [0 x i8]
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
@olang_loc_914b199b24af8e0b_cb2ee6ecbe673f47 = external constant [0 x i8]
declare { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
@olang_loc_80a1d4bb5db67df_9b65eebf7bc7956b = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_eb8a0402c99d9b5e_35ace7251e3366aa = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_f68d3ad0be646bb1_542defd6f5c5cce5 = external constant [0 x i8]
@olang_loc_553f258c1fa4e7a0_ff2b7e647292c5b4 = external constant [0 x i8]
@olang_loc_96d60822e5550738_7384588370384e4 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2ffilepath_2eDir(ptr %v0, { i64, ptr } %a0)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %a0)
@olang_loc_e6e24e0024ea2a04_be8f31c3c206f038 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %a0, i64 %a1)
@olang_loc_9e1364cb140a9a66_28aa9a3ffa2ccf1a = external constant [0 x i8]
declare { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v0, { i64, ptr } %a0)
@olang_loc_23f451298266bf5e_2593b028faf03d0a = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_8fcf87cfa7be21dd_bbd76dac3520f231 = external constant [0 x i8]
@olang_loc_9433da86f750b978_3ff5b65d50af9d4 = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
