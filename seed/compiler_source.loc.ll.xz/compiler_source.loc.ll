; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_145513a43f02c9c5_f2dc3aafee07adc1 = weak_odr constant [45 x i8] c"compiler/source.olang:57: assertion failed: \00"
@olang_loc_d8e20da8ac76c558_ce447159404cbf8c = weak_odr constant [54 x i8] c"compiler/source.olang:102: slice bounds out of range\0A\00"
@olang_loc_de064195a6d3d57e_27bd6cdd46c96b6a = weak_odr constant [53 x i8] c"compiler/source.olang:67: array length out of range\0A\00"
