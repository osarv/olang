; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_3e12648d50e8e960_6b353b2c0234fd24 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:53: slice bounds out of range\0A\00"
