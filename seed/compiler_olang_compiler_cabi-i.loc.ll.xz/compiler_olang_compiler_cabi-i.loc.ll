; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_a2558a8e68ced2d1_38c2b4da4df482d = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: array length out of range\0A\00"
