; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_40bb02b9899e9a43_e9136987b3c339f = weak_odr constant [55 x i8] c"std/prelude/list.olang:108: array length out of range\0A\00"
@olang_loc_5203369e428cd64d_290cca48f35f1189 = weak_odr constant [55 x i8] c"std/prelude/list.olang:114: array length out of range\0A\00"
@olang_loc_8c73de6bd384fe20_1dbc77e83584f63c = weak_odr constant [55 x i8] c"std/prelude/list.olang:110: array length out of range\0A\00"
@olang_loc_99ab86214237f64e_f63e9ff057b122ca = weak_odr constant [55 x i8] c"std/prelude/list.olang:103: array length out of range\0A\00"
@olang_loc_9f1014a68362aa71_3524188d17d64dbd = weak_odr constant [55 x i8] c"std/prelude/list.olang:517: slice bounds out of range\0A\00"
@olang_loc_bcc2d18a3d831f90_f2248ff193ba3ce4 = weak_odr constant [55 x i8] c"std/prelude/list.olang:510: slice bounds out of range\0A\00"
@olang_loc_e949d30f6ad60804_6d84cb87c53ba060 = weak_odr constant [55 x i8] c"std/prelude/list.olang:516: slice bounds out of range\0A\00"
