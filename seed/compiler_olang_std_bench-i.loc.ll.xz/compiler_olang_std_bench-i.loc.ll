; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_116038e9feb1c252_637445921524a59e = weak_odr constant [56 x i8] c"std/prelude/array.olang:480: slice bounds out of range\0A\00"
@olang_loc_38e7ae6a4dfa5ed7_93b9c1fe17d90083 = weak_odr constant [56 x i8] c"std/prelude/array.olang:275: array length out of range\0A\00"
@olang_loc_82d2bb85a934473a_ed7bcd288834efae = weak_odr constant [53 x i8] c"std/prelude/vec.olang:61: slice bounds out of range\0A\00"
@olang_loc_cb0ed79d8c403628_720333145237cbb4 = weak_odr constant [54 x i8] c"std/prelude/vec.olang:283: array length out of range\0A\00"
@olang_loc_d6da0aa3b22c4215_7f4d8dab08189c1 = weak_odr constant [54 x i8] c"std/prelude/vec.olang:282: array length out of range\0A\00"
