; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/scope:rel" = type { { i64, [2 x i64] }, { i64, [2 x i64] }, i1, %"compiler/source:Span", i64 }
%"compiler/scope:Scoper" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { ptr, ptr }, { ptr, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, i64, i1, %"compiler/typed:Plan", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [2 x i64] }, i1, %"compiler/source:Span", { i64, [2 x i64] }, i1, { i64, [2 x i64] }, i1, i1, i1, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [2 x i64] }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64, { i64, [2 x i64] }, i1, i1, i1, i64, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64, i32, i1, i1, i1, i1, i64, %"compiler/source:Span" }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1, i1 }
%"compiler/scope:Val" = type { i32, { i64, [2 x i64] } }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] } }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/scope:summary" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr } }
%"compiler/typed:Capture" = type { i32, ptr }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/scope:fnUse" = type { i64, %"compiler/source:Span", i64, i64, i32 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr } }
%"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" = type { ptr, i64, ptr, ptr }
%"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" = type { i64, ptr }
%"compiler/typed:BlockInfo" = type { i32, i32, %"compiler/source:Span" }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/scope:walked" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
@G_2ecompiler_2fscope_2eFailsBlock = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eFailsUnknown = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eFitDecl = constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eFitElem = constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eFitField = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eFitGlobal = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eFitLocal = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eFitOwn = constant <{ [8 x i8] }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eFitPayload = constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eFitReturn = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eFitValue = constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eFnCall = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eFnLambda = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eFnNamed = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eHolds = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eObliged = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eUseThru = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eUseView = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eWhyField = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eWhyHolds = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eWhyResult = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
define dso_local void @compiler_2fscope_2eFitPayload_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 5, ptr @G_2ecompiler_2fscope_2eFitPayload, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2eFitReturn_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 3, ptr @G_2ecompiler_2fscope_2eFitReturn, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2eFnLambda_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr @G_2ecompiler_2fscope_2eFnLambda, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2eFnNamed_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr @G_2ecompiler_2fscope_2eFnNamed, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecollectPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t6 = load ptr, ptr %l9, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l9, !tbaa !29
  %t10 = load i64, ptr %t9
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l10, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t20, ptr %t22)
  br label %bb9
bb9:
  br label %bb44
bb10:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t26 = load ptr, ptr %l18, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb11, label %bb12
bb11:
  %t29 = load ptr, ptr %l18, !tbaa !29
  %t30 = load i64, ptr %t29
  %t32 = icmp eq i64 %t30, 3
  store i1 %t32, ptr %l19, !tbaa !21
  br label %bb12
bb12:
  %t33 = load i1, ptr %l19, !tbaa !21
  br i1 %t33, label %bb13, label %bb14
bb13:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr { i64, [4 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t36, i32 0, i32 2
  %t38 = load ptr, ptr %t37
  store ptr %t38, ptr %l3, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectPlace(ptr %v0, ptr %v1, ptr %t40, ptr %t42)
  br label %bb16
bb16:
  br label %bb44
bb17:
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t46 = load ptr, ptr %l27, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb18, label %bb19
bb18:
  %t49 = load ptr, ptr %l27, !tbaa !29
  %t50 = load i64, ptr %t49
  %t52 = icmp eq i64 %t50, 4
  store i1 %t52, ptr %l28, !tbaa !21
  br label %bb19
bb19:
  %t53 = load i1, ptr %l28, !tbaa !21
  br i1 %t53, label %bb20, label %bb21
bb20:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr { i64, [4 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t56, i32 0, i32 2
  %t58 = load ptr, ptr %t57
  store ptr %t58, ptr %l4, !tbaa !29
  br label %bb22
bb21:
  br label %bb25
bb22:
  %t60 = load ptr, ptr %l4, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Elem", ptr %t60, i32 0, i32 0
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectPlace(ptr %v0, ptr %v1, ptr %t63, ptr %t65)
  br label %bb23
bb23:
  %t68 = load ptr, ptr %l4, !tbaa !29
  %t70 = getelementptr %"compiler/typed:Elem", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t71, ptr %t73)
  br label %bb24
bb24:
  br label %bb44
bb25:
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t77 = load ptr, ptr %l41, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb26, label %bb27
bb26:
  %t80 = load ptr, ptr %l41, !tbaa !29
  %t81 = load i64, ptr %t80
  %t83 = icmp eq i64 %t81, 5
  store i1 %t83, ptr %l42, !tbaa !21
  br label %bb27
bb27:
  %t84 = load i1, ptr %l42, !tbaa !21
  br i1 %t84, label %bb28, label %bb29
bb28:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr { i64, [4 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t87, i32 0, i32 2
  %t89 = load ptr, ptr %t88
  store ptr %t89, ptr %l5, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t91 = load ptr, ptr %l5, !tbaa !29
  %t93 = getelementptr %"compiler/typed:Payload", ptr %t91, i32 0, i32 0
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectPlace(ptr %v0, ptr %v1, ptr %t94, ptr %t96)
  br label %bb31
bb31:
  br label %bb44
bb32:
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t100 = load ptr, ptr %l51, !tbaa !29
  %t101 = icmp ne ptr %t100, null
  br i1 %t101, label %bb33, label %bb34
bb33:
  %t103 = load ptr, ptr %l51, !tbaa !29
  %t104 = load i64, ptr %t103
  %t106 = icmp eq i64 %t104, 6
  store i1 %t106, ptr %l52, !tbaa !21
  br label %bb34
bb34:
  %t107 = load i1, ptr %l52, !tbaa !21
  br i1 %t107, label %bb35, label %bb36
bb35:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr { i64, [4 x i64] }, ptr %t108, i32 0, i32 1
  %t111 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t110, i32 0, i32 2
  %t112 = load ptr, ptr %t111
  store ptr %t112, ptr %l6, !tbaa !29
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t114 = load ptr, ptr %l6, !tbaa !29
  %t116 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t114, ptr %t116)
  br label %bb38
bb38:
  br label %bb44
bb39:
  br i1 true, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_61be1b0fda526a24_254af50801a17418)
  unreachable
bb44:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eaddRel(ptr %v0, ptr %a0, %"compiler/scope:rel" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/scope:rel"
  %l5 = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/scope:rel" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 33
  %t4 = load %"compiler/scope:rel", ptr %l1
  %t7 = call i1 @compiler_2fscope_2ehasRel(ptr %v0, ptr %t3, %"compiler/scope:rel" %t4)
  store i1 %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load i1, ptr %l5, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 33
  %t14 = load %"compiler/scope:rel", ptr %l1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3arel_3e_2ePush_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t13, %"compiler/scope:rel" %t14)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eaddToSet(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i64
  %l29 = alloca i64
  %l32 = alloca i64
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l55 = alloca { i64, [2 x i64] }
  %l59 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l63 = alloca i32
  %l72 = alloca { i64, ptr }
  %l75 = alloca { i64, [2 x i64] }
  %l77 = alloca { i64, [2 x i64] }
  %l79 = alloca i1
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, [2 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l2
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 5
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t7 = getelementptr { i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l3, !tbaa !24
  br label %bb3
bb2:
  br label %bb20
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/scope:Scoper", ptr %t10, i32 0, i32 34
  %t13 = load i64, ptr %l3, !tbaa !24
  %t16 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t12, i64 %t13)
  store i64 %t16, ptr %l22
  br label %bb4
bb4:
  %t17 = load i64, ptr %l22, !tbaa !24
  store i64 %t17, ptr %l4, !tbaa !24
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esetEnd(ptr %v0, ptr %t18, i64 %t19)
  store i64 %t22, ptr %l25
  br label %bb5
bb5:
  %t23 = load i64, ptr %l25, !tbaa !24
  store i64 %t23, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l5, !tbaa !24
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = icmp sgt i64 %t24, %t25
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t30 = load i64, ptr %l6, !tbaa !24
  %t32 = icmp sgt i64 %t30, 0
  br i1 %t32, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb11
bb8:
  %t34 = load i64, ptr %l5, !tbaa !24
  %t35 = load i64, ptr %l4, !tbaa !24
  %t38 = sub i64 %t34, %t35
  %t39 = load i64, ptr %l6, !tbaa !24
  %t42 = add i64 %t38, %t39
  %t44 = sub i64 %t42, 1
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = sdiv i64 %t44, %t45
  store i64 %t48, ptr %l32, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb10
bb10:
  %t50 = load i64, ptr %l32, !tbaa !24
  store i64 %t50, ptr %l29, !tbaa !24
  br label %bb11
bb11:
  %t51 = load i64, ptr %l29, !tbaa !24
  store i64 %t51, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t52 = load i64, ptr %l8, !tbaa !24
  %t53 = load i64, ptr %l7, !tbaa !24
  %t56 = icmp slt i64 %t52, %t53
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb14:
  br label %bb15
bb15:
  %t60 = load i64, ptr %l4, !tbaa !24
  %t61 = load i64, ptr %l8, !tbaa !24
  %t62 = load i64, ptr %l6, !tbaa !24
  %t65 = mul i64 %t61, %t62
  %t68 = add i64 %t60, %t65
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l50, !tbaa !29
  %t71 = load ptr, ptr %l1, !tbaa !29
  store ptr %t71, ptr %l51, !tbaa !29
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/scope:Scoper", ptr %t72, i32 0, i32 35
  %t78 = call { i64, [2 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t74, i64 %t68)
  store { i64, [2 x i64] } %t78, ptr %l55
  br label %bb16
bb16:
  %t79 = load ptr, ptr %l50, !tbaa !29
  %t80 = load ptr, ptr %l51, !tbaa !29
  %t81 = load { i64, [2 x i64] }, ptr %l55
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eaddToSet(ptr %v0, ptr %v1, ptr %t79, ptr %t80, { i64, [2 x i64] } %t81)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb18:
  %t82 = load i64, ptr %l8, !tbaa !24
  %t84 = add i64 %t82, 1
  store i64 %t84, ptr %l8, !tbaa !24
  br label %bb12
bb19:
  br label %ret
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_ade2525ec560ecac_5eadaea182574e0)
  unreachable
bb25:
  %t86 = load ptr, ptr %l1, !tbaa !29
  store ptr %t86, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s7
  %t88 = load ptr, ptr %l10, !tbaa !29
  %t89 = load i64, ptr %l11, !tbaa !24
  %t92 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3aTerm_3e_2eRunFrom_3ccompiler_2fscope_3aTerm_3e(ptr %v1, ptr %t88, i64 %t89)
  %t93 = extractvalue { i32, { i64, ptr } } %t92, 1
  %t94 = extractvalue { i32, { i64, ptr } } %t92, 0
  store i32 %t94, ptr %l63
  %t95 = icmp ne i32 %t94, 0
  br i1 %t95, label %bb28, label %ok.96
ok.96:
  store { i64, ptr } %t93, ptr %l62
  br label %bb27
bb27:
  %t97 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t97, ptr %l59, !tbaa !27
  br label %bb32
bb28:
  %t98 = load i32, ptr %l63, !tbaa !23
  %t99 = ashr i32 %t98, 16
  %t101 = icmp eq i32 %t99, 1
  br i1 %t101, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_baaa81966d3c6f5d_90f2815c501f8f1)
  unreachable
bb31:
  call void @__olang_scope_close(ptr %s7)
  br label %bb44
bb32:
  %t103 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t103, ptr %l12, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t104, 0
  store i64 %t106, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s8
  %t108 = load i64, ptr %l14, !tbaa !24
  %t109 = load i64, ptr %l13, !tbaa !24
  %t112 = icmp slt i64 %t108, %t109
  %t114 = xor i1 %t112, true
  br i1 %t114, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s8)
  br label %bb42
bb35:
  br label %bb36
bb36:
  %t116 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t116, ptr %l72, !tbaa !27
  %t117 = load i64, ptr %l14, !tbaa !24
  %t119 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr { i64, [2 x i64] }, ptr %t120, i64 %t117
  %t122 = load { i64, [2 x i64] }, ptr %t121
  store { i64, [2 x i64] } %t122, ptr %l75
  %t125 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t125, ptr %l77
  %t128 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l75, ptr %l77)
  store i1 %t128, ptr %l79
  br label %bb37
bb37:
  %t129 = load i1, ptr %l79, !tbaa !21
  br i1 %t129, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s7)
  br label %ret
bb39:
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s8)
  br label %bb41
bb41:
  %t130 = load i64, ptr %l14, !tbaa !24
  %t132 = add i64 %t130, 1
  store i64 %t132, ptr %l14, !tbaa !24
  br label %bb33
bb42:
  %t134 = load i64, ptr %l11, !tbaa !24
  %t135 = load i64, ptr %l13, !tbaa !24
  %t138 = add i64 %t134, %t135
  store i64 %t138, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb43
bb43:
  br label %bb26
bb44:
  %t140 = load ptr, ptr %l1, !tbaa !29
  %t141 = load { i64, [2 x i64] }, ptr %l2
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3aTerm_3e_2ePush_3ccompiler_2fscope_3aTerm_3e(ptr %v1, ptr %t140, { i64, [2 x i64] } %t141)
  br label %bb45
bb45:
  br label %ret
ret:
  ret void
}

define dso_local { { i64, [2 x i64] }, i1, i1 } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eagreeStep(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i1 %a2, { i64, [2 x i64] } %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i1
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i1
  %l11 = alloca { i64, [2 x i64] }
  %l13 = alloca { i64, [2 x i64] }
  %l15 = alloca i1
  %l23 = alloca i1
  %l27 = alloca i64
  %l34 = alloca i1
  %l38 = alloca i64
  %l45 = alloca i1
  %l51 = alloca i64
  %l59 = alloca i64
  %l64 = alloca i1
  %l67 = alloca i1
  %rv = alloca { { i64, [2 x i64] }, i1, i1 }
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  store i1 %a2, ptr %l2
  store { i64, [2 x i64] } %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load { i64, [2 x i64] }, ptr %l3
  %t7 = load i1, ptr %l4, !tbaa !21
  %t9 = insertvalue { { i64, [2 x i64] }, i1, i1 } undef, { i64, [2 x i64] } %t6, 0
  %t11 = insertvalue { { i64, [2 x i64] }, i1, i1 } %t9, i1 %t7, 1
  %t12 = insertvalue { { i64, [2 x i64] }, i1, i1 } %t11, i1 true, 2
  store { { i64, [2 x i64] }, i1, i1 } %t12, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t14 = load { i64, [2 x i64] }, ptr %l3
  store { i64, [2 x i64] } %t14, ptr %l11
  %t15 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t15, ptr %l13
  %t18 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l11, ptr %l13)
  store i1 %t18, ptr %l15
  br label %bb4
bb4:
  %t19 = load i1, ptr %l15, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t20 = load { i64, [2 x i64] }, ptr %l1
  %t21 = load i1, ptr %l2, !tbaa !21
  %t23 = insertvalue { { i64, [2 x i64] }, i1, i1 } undef, { i64, [2 x i64] } %t20, 0
  %t25 = insertvalue { { i64, [2 x i64] }, i1, i1 } %t23, i1 %t21, 1
  %t26 = insertvalue { { i64, [2 x i64] }, i1, i1 } %t25, i1 true, 2
  store { { i64, [2 x i64] }, i1, i1 } %t26, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t28 = load i1, ptr %l4, !tbaa !21
  %t29 = load i1, ptr %l2, !tbaa !21
  %t32 = icmp ne i1 %t28, %t29
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = load i1, ptr %l2, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb9:
  br label %bb24
bb10:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load { i64, [2 x i64] }, ptr %l3
  %t38 = load { i64, [2 x i64] }, ptr %l1
  %t42 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eorder(ptr %v0, ptr %t36, { i64, [2 x i64] } %t37, { i64, [2 x i64] } %t38)
  store i64 %t42, ptr %l27
  br label %bb12
bb11:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb13
bb12:
  %t43 = load i64, ptr @G_2ecompiler_2fscope_2eHolds, !tbaa !24
  %t44 = load i64, ptr %l27, !tbaa !24
  %t46 = icmp eq i64 %t44, %t43
  store i1 %t46, ptr %l23, !tbaa !21
  br label %bb13
bb13:
  %t48 = load i1, ptr %l23, !tbaa !21
  br i1 %t48, label %bb14, label %bb15
bb14:
  %t49 = load { i64, [2 x i64] }, ptr %l1
  %t50 = load i1, ptr %l2, !tbaa !21
  %t52 = insertvalue { { i64, [2 x i64] }, i1, i1 } undef, { i64, [2 x i64] } %t49, 0
  %t54 = insertvalue { { i64, [2 x i64] }, i1, i1 } %t52, i1 %t50, 1
  %t55 = insertvalue { { i64, [2 x i64] }, i1, i1 } %t54, i1 true, 2
  store { { i64, [2 x i64] }, i1, i1 } %t55, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t57 = load i1, ptr %l4, !tbaa !21
  br i1 %t57, label %bb17, label %bb18
bb17:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load { i64, [2 x i64] }, ptr %l1
  %t61 = load { i64, [2 x i64] }, ptr %l3
  %t65 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eorder(ptr %v0, ptr %t59, { i64, [2 x i64] } %t60, { i64, [2 x i64] } %t61)
  store i64 %t65, ptr %l38
  br label %bb19
bb18:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb20
bb19:
  %t66 = load i64, ptr @G_2ecompiler_2fscope_2eHolds, !tbaa !24
  %t67 = load i64, ptr %l38, !tbaa !24
  %t69 = icmp eq i64 %t67, %t66
  store i1 %t69, ptr %l34, !tbaa !21
  br label %bb20
bb20:
  %t71 = load i1, ptr %l34, !tbaa !21
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load { i64, [2 x i64] }, ptr %l3
  %t74 = insertvalue { { i64, [2 x i64] }, i1, i1 } undef, { i64, [2 x i64] } %t72, 0
  %t75 = insertvalue { { i64, [2 x i64] }, i1, i1 } %t74, i1 true, 1
  %t76 = insertvalue { { i64, [2 x i64] }, i1, i1 } %t75, i1 true, 2
  store { { i64, [2 x i64] }, i1, i1 } %t76, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t78 = load i1, ptr %l2, !tbaa !21
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb25, label %bb26
bb25:
  %t82 = load i1, ptr %l4, !tbaa !21
  %t84 = xor i1 %t82, true
  store i1 %t84, ptr %l45, !tbaa !21
  br label %bb27
bb26:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb27
bb27:
  %t86 = load i1, ptr %l45, !tbaa !21
  br i1 %t86, label %bb28, label %bb29
bb28:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load { i64, [2 x i64] }, ptr %l1
  %t89 = load { i64, [2 x i64] }, ptr %l3
  %t93 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eorder(ptr %v0, ptr %t87, { i64, [2 x i64] } %t88, { i64, [2 x i64] } %t89)
  store i64 %t93, ptr %l51
  br label %bb30
bb29:
  br label %bb38
bb30:
  %t94 = load i64, ptr @G_2ecompiler_2fscope_2eHolds, !tbaa !24
  %t95 = load i64, ptr %l51, !tbaa !24
  %t97 = icmp eq i64 %t95, %t94
  br i1 %t97, label %bb31, label %bb32
bb31:
  %t99 = load { i64, [2 x i64] }, ptr %l3
  %t101 = insertvalue { { i64, [2 x i64] }, i1, i1 } undef, { i64, [2 x i64] } %t99, 0
  %t102 = insertvalue { { i64, [2 x i64] }, i1, i1 } %t101, i1 false, 1
  %t103 = insertvalue { { i64, [2 x i64] }, i1, i1 } %t102, i1 true, 2
  store { { i64, [2 x i64] }, i1, i1 } %t103, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load { i64, [2 x i64] }, ptr %l3
  %t107 = load { i64, [2 x i64] }, ptr %l1
  %t111 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eorder(ptr %v0, ptr %t105, { i64, [2 x i64] } %t106, { i64, [2 x i64] } %t107)
  store i64 %t111, ptr %l59
  br label %bb34
bb34:
  %t112 = load i64, ptr @G_2ecompiler_2fscope_2eHolds, !tbaa !24
  %t113 = load i64, ptr %l59, !tbaa !24
  %t115 = icmp eq i64 %t113, %t112
  br i1 %t115, label %bb35, label %bb36
bb35:
  %t117 = load { i64, [2 x i64] }, ptr %l1
  %t119 = insertvalue { { i64, [2 x i64] }, i1, i1 } undef, { i64, [2 x i64] } %t117, 0
  %t120 = insertvalue { { i64, [2 x i64] }, i1, i1 } %t119, i1 false, 1
  %t121 = insertvalue { { i64, [2 x i64] }, i1, i1 } %t120, i1 true, 2
  store { { i64, [2 x i64] }, i1, i1 } %t121, ptr %rv
  br label %ret
bb36:
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t123 = load { i64, [2 x i64] }, ptr %l3
  %t125 = extractvalue { i64, [2 x i64] } %t123, 0
  %t126 = icmp eq i64 %t125, 2
  br i1 %t126, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb51
bb41:
  %t128 = load { i64, [2 x i64] }, ptr %l1
  %t130 = extractvalue { i64, [2 x i64] } %t128, 0
  %t131 = icmp eq i64 %t130, 2
  br i1 %t131, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb50
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_75a473c9145829d0_168d550c974bebd4)
  unreachable
bb50:
  %t133 = load i1, ptr %l67, !tbaa !21
  store i1 %t133, ptr %l64, !tbaa !21
  br label %bb56
bb51:
  br i1 true, label %bb52, label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb55
bb54:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb56
bb55:
  call void @__olang_check_failed(ptr @olang_loc_2b3cb67345c2bf61_96483393ea0a8285)
  unreachable
bb56:
  %t134 = load i1, ptr %l64, !tbaa !21
  %t135 = load { i64, [2 x i64] }, ptr %l1
  %t136 = load i1, ptr %l2, !tbaa !21
  %t139 = insertvalue { { i64, [2 x i64] }, i1, i1 } undef, { i64, [2 x i64] } %t135, 0
  %t141 = insertvalue { { i64, [2 x i64] }, i1, i1 } %t139, i1 %t136, 1
  %t143 = insertvalue { { i64, [2 x i64] }, i1, i1 } %t141, i1 %t134, 2
  store { { i64, [2 x i64] }, i1, i1 } %t143, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, [2 x i64] }, i1, i1 }, ptr %rv
  ret { { i64, [2 x i64] }, i1, i1 } %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargLands(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l4 = alloca { i64, [2 x i64] }
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elandTerm(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
  store { i64, [2 x i64] } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, [2 x i64] }, ptr %l4
  %t8 = extractvalue { i64, [2 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 0
  %t11 = xor i1 %t9, true
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargOfVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l22 = alloca i32
  %l31 = alloca { i64, ptr }
  %l43 = alloca i64
  %l46 = alloca i64
  %l69 = alloca i64
  %l72 = alloca i64
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, [2 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 -1, ptr %l3, !tbaa !24
  %t1 = load { i64, [2 x i64] }, ptr %l2
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 2
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t7 = getelementptr { i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t10 = load i64, ptr %l4, !tbaa !24
  store i64 %t10, ptr %l3, !tbaa !24
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb8:
  call void @__olang_check_failed(ptr @olang_loc_85776ac018629bcc_231804c012e3a7c0)
  unreachable
bb9:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t17 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %t13, ptr %t14)
  store i32 %t17, ptr %l22
  br label %bb10
bb10:
  %t18 = load i32, ptr %l22, !tbaa !23
  store i32 %t18, ptr %l5, !tbaa !23
  %t19 = load i32, ptr %l5, !tbaa !23
  %t20 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t23 = icmp eq i32 %t19, %t20
  br i1 %t23, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/scope:Scoper", ptr %t26, i32 0, i32 0
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 2
  %t32 = load i32, ptr %l5, !tbaa !23
  %t35 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t31, i32 %t32)
  store { i64, ptr } %t35, ptr %l31
  br label %bb14
bb14:
  %t36 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t36, ptr %l6, !tbaa !27
  %t37 = load i64, ptr %l3, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t43 = icmp sge i64 %t37, %t40
  br i1 %t43, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  store i64 0, ptr %l7, !tbaa !24
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr %"compiler/typed:Call", ptr %t46, i32 0, i32 1
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t49, 0
  store i64 %t51, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t53 = load i64, ptr %l8, !tbaa !24
  %t54 = load i64, ptr %l7, !tbaa !24
  %t57 = icmp sgt i64 %t53, %t54
  br i1 %t57, label %bb18, label %bb19
bb18:
  %t59 = load i64, ptr %l9, !tbaa !24
  %t61 = icmp sgt i64 %t59, 0
  br i1 %t61, label %bb20, label %bb21
bb19:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb23
bb20:
  %t63 = load i64, ptr %l8, !tbaa !24
  %t64 = load i64, ptr %l7, !tbaa !24
  %t67 = sub i64 %t63, %t64
  %t68 = load i64, ptr %l9, !tbaa !24
  %t71 = add i64 %t67, %t68
  %t73 = sub i64 %t71, 1
  %t74 = load i64, ptr %l9, !tbaa !24
  %t77 = sdiv i64 %t73, %t74
  store i64 %t77, ptr %l46, !tbaa !24
  br label %bb22
bb21:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb22
bb22:
  %t79 = load i64, ptr %l46, !tbaa !24
  store i64 %t79, ptr %l43, !tbaa !24
  br label %bb23
bb23:
  %t80 = load i64, ptr %l43, !tbaa !24
  store i64 %t80, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s6
  %t81 = load i64, ptr %l11, !tbaa !24
  %t82 = load i64, ptr %l10, !tbaa !24
  %t85 = icmp slt i64 %t81, %t82
  %t87 = xor i1 %t85, true
  br i1 %t87, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s6)
  br label %bb36
bb26:
  br label %bb27
bb27:
  %t89 = load i64, ptr %l7, !tbaa !24
  %t90 = load i64, ptr %l11, !tbaa !24
  %t91 = load i64, ptr %l9, !tbaa !24
  %t94 = mul i64 %t90, %t91
  %t97 = add i64 %t89, %t94
  store i64 %t97, ptr %l12, !tbaa !24
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/scope:Scoper", ptr %t99, i32 0, i32 0
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = getelementptr %"compiler/generic:Program", ptr %t102, i32 0, i32 2
  %t105 = load i32, ptr %l5, !tbaa !23
  %t106 = load i64, ptr %l12, !tbaa !24
  %t110 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t104, i32 %t105, i64 %t106)
  store i64 %t110, ptr %l69
  br label %bb28
bb28:
  %t111 = load i64, ptr %l69, !tbaa !24
  store i64 %t111, ptr %l13, !tbaa !24
  %t112 = load i64, ptr %l13, !tbaa !24
  %t114 = icmp sge i64 %t112, 0
  br i1 %t114, label %bb29, label %bb30
bb29:
  %t116 = load i64, ptr %l13, !tbaa !24
  store i64 %t116, ptr %l72, !tbaa !24
  br label %bb31
bb30:
  %t118 = load i64, ptr %l12, !tbaa !24
  store i64 %t118, ptr %l72, !tbaa !24
  br label %bb31
bb31:
  %t120 = load i64, ptr %l72, !tbaa !24
  %t122 = load i64, ptr %l3, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr i64, ptr %t125, i64 %t122
  %t127 = load i64, ptr %t126, !tbaa !34
  %t130 = icmp eq i64 %t120, %t127
  br i1 %t130, label %bb32, label %bb33
bb32:
  %t132 = load i64, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store i64 %t132, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s6)
  br label %bb35
bb35:
  %t134 = load i64, ptr %l11, !tbaa !24
  %t136 = add i64 %t134, 1
  store i64 %t136, ptr %l11, !tbaa !24
  br label %bb24
bb36:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargRec(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l14 = alloca ptr
  %l18 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l26 = alloca ptr
  %l27 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l40 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t7 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %t2, ptr %a1)
  store ptr %t7, ptr %l9
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l5, !tbaa !29
  %t9 = load ptr, ptr %l9, !tbaa !29
  %t10 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunPromoted(ptr %v0, ptr %v1, ptr %t8, ptr %t9)
  store ptr %t10, ptr %l10
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l10, !tbaa !29
  store ptr %t11, ptr %l2, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t17 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallOf(ptr %v0, ptr %v1, ptr %t12, ptr %t13)
  store ptr %t17, ptr %l14
  br label %bb3
bb3:
  %t18 = load ptr, ptr %l14, !tbaa !29
  store ptr %t18, ptr %l3, !tbaa !29
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t21 = icmp eq ptr %t19, null
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb4, label %bb5
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/scope:Scoper", ptr %t25, i32 0, i32 44
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Call", ptr %t28, i32 0, i32 3
  %t31 = load i32, ptr %t30, !tbaa !23
  %t33 = sext i32 %t31 to i64
  %t36 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t27, i64 %t33)
  %t37 = extractvalue { i32, i64 } %t36, 1
  %t38 = extractvalue { i32, i64 } %t36, 0
  store i32 %t38, ptr %l25
  %t39 = icmp ne i32 %t38, 0
  br i1 %t39, label %bb7, label %ok.40
ok.40:
  store i64 %t37, ptr %l24
  br label %bb6
bb5:
  br label %bb10
bb6:
  %t41 = load i64, ptr %l24, !tbaa !24
  store i64 %t41, ptr %l18, !tbaa !24
  br label %bb9
bb7:
  br label %bb8
bb8:
  store i64 -1, ptr %l18, !tbaa !24
  br label %bb9
bb9:
  %t42 = load i64, ptr %l18, !tbaa !24
  store i64 %t42, ptr %rv
  br label %ret
bb10:
  %t43 = load ptr, ptr %l2, !tbaa !29
  store ptr %t43, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t44 = load ptr, ptr %l26, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb11, label %bb12
bb11:
  %t47 = load ptr, ptr %l26, !tbaa !29
  %t48 = load i64, ptr %t47
  %t50 = icmp eq i64 %t48, 2
  store i1 %t50, ptr %l27, !tbaa !21
  br label %bb12
bb12:
  %t51 = load i1, ptr %l27, !tbaa !21
  br i1 %t51, label %bb13, label %bb14
bb13:
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t54 = getelementptr { i64, [5 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t54, i32 0, i32 2
  %t56 = load ptr, ptr %t55
  store ptr %t56, ptr %l4, !tbaa !29
  br label %bb19
bb14:
  %t58 = load ptr, ptr %l2, !tbaa !29
  store ptr %t58, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t59 = load ptr, ptr %l32, !tbaa !29
  %t60 = icmp ne ptr %t59, null
  br i1 %t60, label %bb15, label %bb16
bb15:
  %t62 = load ptr, ptr %l32, !tbaa !29
  %t63 = load i64, ptr %t62
  %t65 = icmp eq i64 %t63, 3
  store i1 %t65, ptr %l33, !tbaa !21
  br label %bb16
bb16:
  %t66 = load i1, ptr %l33, !tbaa !21
  br i1 %t66, label %bb17, label %bb18
bb17:
  %t67 = load ptr, ptr %l2, !tbaa !29
  %t69 = getelementptr { i64, [5 x i64] }, ptr %t67, i32 0, i32 1
  %t70 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t69, i32 0, i32 2
  %t71 = load ptr, ptr %t70
  store ptr %t71, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load ptr, ptr %l4, !tbaa !29
  %t77 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erecOf(ptr %v0, ptr %v1, ptr %t73, ptr %t74)
  store i64 %t77, ptr %l40
  br label %bb20
bb20:
  %t78 = load i64, ptr %l40, !tbaa !24
  store i64 %t78, ptr %rv
  br label %ret
bb21:
  br i1 true, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  store i64 -1, ptr %rv
  br label %ret
bb25:
  call void @__olang_check_failed(ptr @olang_loc_2489ab739aea8b00_863e154a28bdb8e4)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2earm(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca %"compiler/scope:Val"
  %l13 = alloca i64
  %l14 = alloca %"compiler/scope:Val"
  %l17 = alloca %"compiler/scope:Val"
  %l18 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca { i64, ptr }
  %l35 = alloca %"compiler/scope:Val"
  %l44 = alloca { i64, ptr }
  %l52 = alloca %"compiler/scope:Val"
  %l57 = alloca ptr
  %l58 = alloca i64
  %l59 = alloca ptr
  %l68 = alloca %"compiler/typed:Local"
  %l70 = alloca { i64, [2 x i64] }
  %l73 = alloca i1
  %l74 = alloca i1
  %l78 = alloca { i64, [2 x i64] }
  %l80 = alloca { i64, [2 x i64] }
  %l82 = alloca i1
  %l84 = alloca i1
  %l88 = alloca { i64, [2 x i64] }
  %l92 = alloca i1
  %l97 = alloca ptr
  %l98 = alloca i64
  %l99 = alloca ptr
  %l103 = alloca { i64, [2 x i64] }
  %l105 = alloca { i64, [2 x i64] }
  %l108 = alloca i1
  %l124 = alloca %"compiler/scope:Val"
  %l125 = alloca %"compiler/scope:Val"
  %l131 = alloca ptr
  %l139 = alloca ptr
  %l151 = alloca %"compiler/scope:Val"
  %l152 = alloca i32
  %l155 = alloca i32
  %l156 = alloca i32
  %l161 = alloca %"compiler/scope:Val"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca %"compiler/scope:Val"
  %t41 = alloca { i64, [2 x i64] }, align 8
  %t79 = alloca { i64, [2 x i64] }, align 8
  %t223 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, [2 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call %"compiler/scope:Val" @compiler_2fscope_2eplain()
  store %"compiler/scope:Val" %t5, ptr %l17
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t6 = load %"compiler/scope:Val", ptr %l17
  store %"compiler/scope:Val" %t6, ptr %rv
  br label %ret
bb4:
  %t7 = load ptr, ptr @__olang_prog_scope
  %t8 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t7)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l18
  br label %bb5
bb5:
  %t9 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l18
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l3
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Arm", ptr %t10, i32 0, i32 1
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  store i64 %t17, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t19 = load i64, ptr %l5, !tbaa !24
  %t20 = load i64, ptr %l6, !tbaa !24
  %t23 = icmp slt i64 %t19, %t20
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb50
bb8:
  br label %bb9
bb9:
  %t27 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t27, ptr %l27, !tbaa !27
  %t28 = load i64, ptr %l5, !tbaa !24
  %t30 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr ptr, ptr %t31, i64 %t28
  %t33 = load ptr, ptr %t32, !tbaa !39
  store ptr %t33, ptr %l7, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l7, !tbaa !29
  %t38 = getelementptr %"compiler/typed:Alt", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t41
  %t42 = getelementptr { i64, [2 x i64] }, ptr %t41, i32 0, i32 0
  store i64 0, ptr %t42
  %t43 = load { i64, [2 x i64] }, ptr %t41
  %t47 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t35, ptr %t39, { i64, [2 x i64] } %t43)
  store %"compiler/scope:Val" %t47, ptr %l35
  br label %bb10
bb10:
  %t48 = load ptr, ptr %l7, !tbaa !29
  %t50 = getelementptr %"compiler/typed:Alt", ptr %t48, i32 0, i32 1
  %t51 = load { i64, ptr }, ptr %t50, !tbaa !27
  store { i64, ptr } %t51, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  store i64 %t55, ptr %l10, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s5
  %t57 = load i64, ptr %l9, !tbaa !24
  %t58 = load i64, ptr %l10, !tbaa !24
  %t61 = icmp slt i64 %t57, %t58
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s5)
  br label %bb48
bb13:
  br label %bb14
bb14:
  %t65 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t65, ptr %l44, !tbaa !27
  %t66 = load i64, ptr %l9, !tbaa !24
  %t68 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr ptr, ptr %t69, i64 %t66
  %t71 = load ptr, ptr %t70, !tbaa !39
  store ptr %t71, ptr %l11, !tbaa !29
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load ptr, ptr %l11, !tbaa !29
  %t76 = getelementptr %"compiler/typed:Bind", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t79
  %t80 = getelementptr { i64, [2 x i64] }, ptr %t79, i32 0, i32 0
  store i64 0, ptr %t80
  %t81 = load { i64, [2 x i64] }, ptr %t79
  %t85 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t73, ptr %t77, { i64, [2 x i64] } %t81)
  store %"compiler/scope:Val" %t85, ptr %l52
  br label %bb15
bb15:
  %t86 = load %"compiler/scope:Val", ptr %l52
  store %"compiler/scope:Val" %t86, ptr %l12
  %t87 = load ptr, ptr %l11, !tbaa !29
  %t89 = getelementptr %"compiler/typed:Bind", ptr %t87, i32 0, i32 0
  %t90 = load i32, ptr %t89, !tbaa !23
  %t92 = sext i32 %t90 to i64
  store i64 %t92, ptr %l13, !tbaa !24
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/scope:Scoper", ptr %t94, i32 0, i32 30
  store ptr %t96, ptr %l57, !tbaa !29
  %t97 = load i64, ptr %l13, !tbaa !24
  store i64 %t97, ptr %l58, !tbaa !24
  %t98 = load ptr, ptr %l0, !tbaa !29
  store ptr %t98, ptr %l59, !tbaa !29
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/scope:Scoper", ptr %t99, i32 0, i32 25
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = icmp eq ptr %t102, null
  br i1 %t104, label %bb16, label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_76dd643541c5999_442dc791771fad)
  unreachable
bb17:
  br label %bb18
bb18:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/scope:Scoper", ptr %t106, i32 0, i32 25
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t112 = getelementptr %"compiler/typed:Body", ptr %t109, i32 0, i32 7
  %t113 = load i64, ptr %l13, !tbaa !24
  %t116 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t112, i64 %t113)
  store %"compiler/typed:Local" %t116, ptr %l68
  br label %bb19
bb19:
  %t117 = getelementptr %"compiler/typed:Local", ptr %l68, i32 0, i32 3
  %t118 = load i32, ptr %t117, !tbaa !23
  %t119 = load ptr, ptr %l59, !tbaa !29
  %t121 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblockTerm(ptr %v0, ptr %t119, i32 %t118)
  store { i64, [2 x i64] } %t121, ptr %l70
  br label %bb20
bb20:
  %t122 = load ptr, ptr %l57, !tbaa !29
  %t123 = load i64, ptr %l58, !tbaa !24
  %t124 = load { i64, [2 x i64] }, ptr %l70
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t122, i64 %t123, { i64, [2 x i64] } %t124)
  br label %bb21
bb21:
  %t125 = load i64, ptr %l13, !tbaa !24
  %t128 = call i1 @compiler_2fscope_2eflHas(ptr %s0, ptr %l3, i64 %t125)
  store i1 %t128, ptr %l73
  br label %bb22
bb22:
  %t129 = load i1, ptr %l73, !tbaa !21
  br i1 %t129, label %bb23, label %bb24
bb23:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/scope:Scoper", ptr %t130, i32 0, i32 29
  %t133 = load i64, ptr %l13, !tbaa !24
  %t136 = call { i64, [2 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t132, i64 %t133)
  store { i64, [2 x i64] } %t136, ptr %l78
  br label %bb25
bb24:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb27
bb25:
  %t137 = getelementptr %"compiler/scope:Val", ptr %l12, i32 0, i32 1
  %t138 = load { i64, [2 x i64] }, ptr %t137
  store { i64, [2 x i64] } %t138, ptr %l80
  %t141 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l78, ptr %l80)
  store i1 %t141, ptr %l82
  br label %bb26
bb26:
  %t142 = load i1, ptr %l82, !tbaa !21
  %t143 = xor i1 %t142, true
  store i1 %t143, ptr %l74, !tbaa !21
  br label %bb27
bb27:
  %t145 = load i1, ptr %l74, !tbaa !21
  br i1 %t145, label %bb28, label %bb29
bb28:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/scope:Scoper", ptr %t146, i32 0, i32 29
  %t149 = load i64, ptr %l13, !tbaa !24
  %t152 = call { i64, [2 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t148, i64 %t149)
  store { i64, [2 x i64] } %t152, ptr %l88
  br label %bb30
bb29:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb31
bb30:
  %t153 = load { i64, [2 x i64] }, ptr %l88
  %t155 = extractvalue { i64, [2 x i64] } %t153, 0
  %t156 = icmp eq i64 %t155, 0
  %t158 = xor i1 %t156, true
  store i1 %t158, ptr %l84, !tbaa !21
  br label %bb31
bb31:
  %t160 = load i1, ptr %l84, !tbaa !21
  br i1 %t160, label %bb32, label %bb33
bb32:
  %t161 = getelementptr %"compiler/scope:Val", ptr %l12, i32 0, i32 1
  %t162 = load { i64, [2 x i64] }, ptr %t161
  %t164 = extractvalue { i64, [2 x i64] } %t162, 0
  %t165 = icmp eq i64 %t164, 0
  %t167 = xor i1 %t165, true
  store i1 %t167, ptr %l92, !tbaa !21
  br label %bb34
bb33:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb34
bb34:
  %t169 = load i1, ptr %l92, !tbaa !21
  br i1 %t169, label %bb35, label %bb36
bb35:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/scope:Scoper", ptr %t170, i32 0, i32 29
  store ptr %t172, ptr %l97, !tbaa !29
  %t173 = load i64, ptr %l13, !tbaa !24
  store i64 %t173, ptr %l98, !tbaa !24
  %t174 = load ptr, ptr %l0, !tbaa !29
  store ptr %t174, ptr %l99, !tbaa !29
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/scope:Scoper", ptr %t175, i32 0, i32 29
  %t178 = load i64, ptr %l13, !tbaa !24
  %t181 = call { i64, [2 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t177, i64 %t178)
  store { i64, [2 x i64] } %t181, ptr %l103
  br label %bb37
bb36:
  %t182 = load i64, ptr %l13, !tbaa !24
  %t185 = call i1 @compiler_2fscope_2eflHas(ptr %s0, ptr %l3, i64 %t182)
  store i1 %t185, ptr %l108
  br label %bb40
bb37:
  %t186 = getelementptr %"compiler/scope:Val", ptr %l12, i32 0, i32 1
  %t187 = load { i64, [2 x i64] }, ptr %t186
  %t188 = load ptr, ptr %l99, !tbaa !29
  %t189 = load { i64, [2 x i64] }, ptr %l103
  %t191 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esetOf(ptr %v0, ptr %t188, { i64, [2 x i64] } %t189, { i64, [2 x i64] } %t187)
  store { i64, [2 x i64] } %t191, ptr %l105
  br label %bb38
bb38:
  %t192 = load ptr, ptr %l97, !tbaa !29
  %t193 = load i64, ptr %l98, !tbaa !24
  %t194 = load { i64, [2 x i64] }, ptr %l105
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t192, i64 %t193, { i64, [2 x i64] } %t194)
  br label %bb39
bb39:
  br label %bb46
bb40:
  %t195 = load i1, ptr %l108, !tbaa !21
  %t196 = xor i1 %t195, true
  br i1 %t196, label %bb41, label %bb42
bb41:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/scope:Scoper", ptr %t198, i32 0, i32 29
  %t201 = load i64, ptr %l13, !tbaa !24
  %t202 = getelementptr %"compiler/scope:Val", ptr %l12, i32 0, i32 1
  %t203 = load { i64, [2 x i64] }, ptr %t202
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t200, i64 %t201, { i64, [2 x i64] } %t203)
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t207 = load i64, ptr %l13, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t207)
  br label %bb44
bb44:
  br label %bb45
bb45:
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s5)
  br label %bb47
bb47:
  %t210 = load i64, ptr %l9, !tbaa !24
  %t212 = add i64 %t210, 1
  store i64 %t212, ptr %l9, !tbaa !24
  br label %bb11
bb48:
  call void @__olang_scope_close(ptr %s3)
  br label %bb49
bb49:
  %t214 = load i64, ptr %l5, !tbaa !24
  %t216 = add i64 %t214, 1
  store i64 %t216, ptr %l5, !tbaa !24
  br label %bb6
bb50:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t219 = load ptr, ptr %l1, !tbaa !29
  %t221 = getelementptr %"compiler/typed:Arm", ptr %t219, i32 0, i32 2
  %t222 = load ptr, ptr %t221, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t223
  %t224 = getelementptr { i64, [2 x i64] }, ptr %t223, i32 0, i32 0
  store i64 0, ptr %t224
  %t225 = load { i64, [2 x i64] }, ptr %t223
  %t229 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t218, ptr %t222, { i64, [2 x i64] } %t225)
  store %"compiler/scope:Val" %t229, ptr %l124
  br label %bb51
bb51:
  %t230 = call %"compiler/scope:Val" @compiler_2fscope_2eplain()
  store %"compiler/scope:Val" %t230, ptr %l125
  br label %bb52
bb52:
  %t231 = load %"compiler/scope:Val", ptr %l125
  store %"compiler/scope:Val" %t231, ptr %l14
  %t232 = load ptr, ptr %l1, !tbaa !29
  %t234 = getelementptr %"compiler/typed:Arm", ptr %t232, i32 0, i32 3
  %t235 = load ptr, ptr %t234, !tbaa !29
  %t237 = icmp eq ptr %t235, null
  %t239 = xor i1 %t237, true
  br i1 %t239, label %bb53, label %bb54
bb53:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr %"compiler/scope:Scoper", ptr %t241, i32 0, i32 32
  store ptr %t243, ptr %l131, !tbaa !29
  %t244 = load ptr, ptr %l1, !tbaa !29
  %t246 = getelementptr %"compiler/typed:Arm", ptr %t244, i32 0, i32 3
  %t247 = load ptr, ptr %t246, !tbaa !29
  %t249 = icmp eq ptr %t247, null
  br i1 %t249, label %bb55, label %bb56
bb54:
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t252 = load ptr, ptr %l1, !tbaa !29
  %t254 = getelementptr %"compiler/typed:Arm", ptr %t252, i32 0, i32 4
  %t255 = load ptr, ptr %t254, !tbaa !29
  %t256 = load { i64, [2 x i64] }, ptr %l2
  %t260 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t251, ptr %t255, { i64, [2 x i64] } %t256)
  store %"compiler/scope:Val" %t260, ptr %l161
  br label %bb68
bb55:
  call void @__olang_check_failed(ptr @olang_loc_a61f6227542ac272_aba93d64b04206c6)
  unreachable
bb56:
  br label %bb57
bb57:
  %t261 = load ptr, ptr %l1, !tbaa !29
  %t263 = getelementptr %"compiler/typed:Arm", ptr %t261, i32 0, i32 3
  %t264 = load ptr, ptr %t263, !tbaa !29
  %t267 = getelementptr %"compiler/typed:Block", ptr %t264, i32 0, i32 0
  %t268 = load i32, ptr %t267, !tbaa !23
  %t269 = load ptr, ptr %l131, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockId_3e_2ePus_Hc98eca5dddbfee899ac629cbaebab24b(ptr %v0, ptr %t269, i32 %t268)
  br label %bb58
bb58:
  %t271 = load ptr, ptr %l0, !tbaa !29
  store ptr %t271, ptr %l139, !tbaa !29
  %t272 = load ptr, ptr %l1, !tbaa !29
  %t274 = getelementptr %"compiler/typed:Arm", ptr %t272, i32 0, i32 3
  %t275 = load ptr, ptr %t274, !tbaa !29
  %t277 = icmp eq ptr %t275, null
  br i1 %t277, label %bb59, label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_f34ecaa27a4fd2b3_7961e1dcca83cdb7)
  unreachable
bb60:
  br label %bb61
bb61:
  %t279 = load ptr, ptr %l1, !tbaa !29
  %t281 = getelementptr %"compiler/typed:Arm", ptr %t279, i32 0, i32 3
  %t282 = load ptr, ptr %t281, !tbaa !29
  %t285 = getelementptr %"compiler/typed:Block", ptr %t282, i32 0, i32 1
  %t286 = load { i64, ptr }, ptr %t285, !tbaa !27
  %t287 = load ptr, ptr %l139, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estmts(ptr %v0, ptr %v1, ptr %t287, { i64, ptr } %t286)
  br label %bb62
bb62:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t290 = load ptr, ptr %l1, !tbaa !29
  %t292 = getelementptr %"compiler/typed:Arm", ptr %t290, i32 0, i32 4
  %t293 = load ptr, ptr %t292, !tbaa !29
  %t294 = load { i64, [2 x i64] }, ptr %l2
  %t298 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t289, ptr %t293, { i64, [2 x i64] } %t294)
  store %"compiler/scope:Val" %t298, ptr %l151
  br label %bb63
bb63:
  %t299 = load %"compiler/scope:Val", ptr %l151
  store %"compiler/scope:Val" %t299, ptr %l14
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr %"compiler/scope:Scoper", ptr %t300, i32 0, i32 32
  %t304 = call { i32, i32 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockId_3e_2ePop_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t302)
  %t305 = extractvalue { i32, i32 } %t304, 1
  %t306 = extractvalue { i32, i32 } %t304, 0
  store i32 %t306, ptr %l156
  %t307 = icmp ne i32 %t306, 0
  br i1 %t307, label %bb65, label %ok.308
ok.308:
  store i32 %t305, ptr %l155
  br label %bb64
bb64:
  %t309 = load i32, ptr %l155, !tbaa !23
  store i32 %t309, ptr %l152, !tbaa !23
  br label %bb67
bb65:
  br label %bb66
bb66:
  br label %bb67
bb67:
  br label %bb69
bb68:
  %t310 = load %"compiler/scope:Val", ptr %l161
  store %"compiler/scope:Val" %t310, ptr %l14
  br label %bb69
bb69:
  %t311 = load %"compiler/scope:Val", ptr %l14
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/scope:Val" %t311, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scope:Val", ptr %rv
  ret %"compiler/scope:Val" %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebindLocal(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l21 = alloca %"compiler/typed:Local"
  %l26 = alloca i1
  %l30 = alloca i1
  %l37 = alloca i1
  %l50 = alloca i1
  %l56 = alloca i1
  %l61 = alloca i1
  %l62 = alloca i1
  %l67 = alloca i1
  %l69 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l74 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l75 = alloca i32
  %l77 = alloca ptr
  %l79 = alloca i64
  %l82 = alloca i64
  %l84 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l88 = alloca i32
  %l97 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l113 = alloca ptr
  %l115 = alloca ptr
  %l118 = alloca i1
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 25
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_b442aabc3e151319_4a7d8af854ba830d)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 25
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 7
  %t15 = load i32, ptr %l1, !tbaa !23
  %t17 = sext i32 %t15 to i64
  %t20 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t14, i64 %t17)
  store %"compiler/typed:Local" %t20, ptr %l21
  br label %bb4
bb4:
  %t21 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 4
  %t22 = load i32, ptr %t21
  store i32 %t22, ptr %l3
  %t24 = load i32, ptr %l3
  %t26 = trunc i64 1 to i32
  %t27 = icmp eq i32 %t24, %t26
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb5, label %bb6
bb5:
  %t31 = load i32, ptr %l3
  %t33 = trunc i64 3 to i32
  %t34 = icmp eq i32 %t31, %t33
  %t36 = xor i1 %t34, true
  store i1 %t36, ptr %l26, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb7
bb7:
  %t38 = load i1, ptr %l26, !tbaa !21
  br i1 %t38, label %bb8, label %bb9
bb8:
  %t39 = load i32, ptr %l3
  %t41 = trunc i64 6 to i32
  %t42 = icmp eq i32 %t39, %t41
  %t44 = xor i1 %t42, true
  store i1 %t44, ptr %l30, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb10
bb10:
  %t46 = load i1, ptr %l30, !tbaa !21
  br i1 %t46, label %bb11, label %bb12
bb11:
  br label %ret
bb12:
  br label %bb13
bb13:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i32, ptr %l1, !tbaa !23
  %t50 = sext i32 %t48 to i64
  %t53 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ereassigned(ptr %v0, ptr %t47, i64 %t50)
  store i1 %t53, ptr %l37
  br label %bb14
bb14:
  %t54 = load i1, ptr %l37, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i32, ptr %l1, !tbaa !23
  %t58 = sext i32 %t56 to i64
  %t59 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteLate(ptr %v0, ptr %v1, ptr %t55, i64 %t58, ptr %t59)
  br label %bb17
bb16:
  br label %bb59
bb17:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/scope:Scoper", ptr %t63, i32 0, i32 47
  %t66 = load i1, ptr %t65, !tbaa !21
  br i1 %t66, label %bb18, label %bb19
bb18:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/scope:Scoper", ptr %t68, i32 0, i32 50
  %t71 = load i32, ptr %l1, !tbaa !23
  %t73 = sext i32 %t71 to i64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t70, i64 %t73, i1 true)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/scope:Scoper", ptr %t76, i32 0, i32 47
  %t79 = load i1, ptr %t78, !tbaa !21
  br i1 %t79, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb24
bb23:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/scope:Scoper", ptr %t81, i32 0, i32 46
  %t84 = load i64, ptr %t83, !tbaa !24
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/scope:Scoper", ptr %t85, i32 0, i32 26
  %t88 = load i64, ptr %t87, !tbaa !24
  %t91 = icmp ne i64 %t84, %t88
  store i1 %t91, ptr %l50, !tbaa !21
  br label %bb24
bb24:
  %t93 = load i1, ptr %l50, !tbaa !21
  br i1 %t93, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb28
bb26:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/scope:Scoper", ptr %t94, i32 0, i32 49
  %t97 = load i32, ptr %l1, !tbaa !23
  %t99 = sext i32 %t97 to i64
  %t102 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t96, i64 %t99)
  store i1 %t102, ptr %l61
  br label %bb27
bb27:
  %t103 = load i1, ptr %l61, !tbaa !21
  store i1 %t103, ptr %l56, !tbaa !21
  br label %bb28
bb28:
  %t104 = load i1, ptr %l56, !tbaa !21
  br i1 %t104, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb32
bb30:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/scope:Scoper", ptr %t105, i32 0, i32 50
  %t108 = load i32, ptr %l1, !tbaa !23
  %t110 = sext i32 %t108 to i64
  %t113 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t107, i64 %t110)
  store i1 %t113, ptr %l67
  br label %bb31
bb31:
  %t114 = load i1, ptr %l67, !tbaa !21
  %t115 = xor i1 %t114, true
  store i1 %t115, ptr %l62, !tbaa !21
  br label %bb32
bb32:
  %t117 = load i1, ptr %l62, !tbaa !21
  br i1 %t117, label %bb33, label %bb34
bb33:
  br label %ret
bb34:
  br label %bb35
bb35:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/scope:Scoper", ptr %t118, i32 0, i32 48
  %t121 = load i32, ptr %l1, !tbaa !23
  %t123 = sext i32 %t121 to i64
  %t126 = call { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2flist_3aList_3_H94d5bd7878f72069b50ef5a607d7e16d(ptr %v0, ptr %v0, ptr %t120, i64 %t123)
  %t127 = extractvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t126, 1
  %t128 = extractvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t126, 0
  store i32 %t128, ptr %l75
  %t129 = icmp ne i32 %t128, 0
  br i1 %t129, label %bb37, label %ok.130
ok.130:
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t127, ptr %l74
  br label %bb36
bb36:
  %t131 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l74
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t131, ptr %l69
  br label %bb39
bb37:
  br label %bb38
bb38:
  br label %ret
bb39:
  %t132 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l69
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t132, ptr %l4
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/scope:Scoper", ptr %t133, i32 0, i32 41
  store ptr %t135, ptr %l77, !tbaa !29
  %t136 = load i32, ptr %l1, !tbaa !23
  %t138 = sext i32 %t136 to i64
  store i64 %t138, ptr %l79, !tbaa !24
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/scope:Scoper", ptr %t139, i32 0, i32 42
  %t143 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t141)
  store i64 %t143, ptr %l82
  br label %bb40
bb40:
  %t144 = load ptr, ptr %l77, !tbaa !29
  %t145 = load i64, ptr %l79, !tbaa !24
  %t146 = load i64, ptr %l82, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t144, i64 %t145, i64 %t146)
  br label %bb41
bb41:
  store ptr %l4, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb42
bb42:
  store %olang.scope zeroinitializer, ptr %s7
  %t148 = load ptr, ptr %l5, !tbaa !29
  %t149 = load i64, ptr %l6, !tbaa !24
  %t152 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3aTerm_3e_2eRunFrom_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t148, i64 %t149)
  %t153 = extractvalue { i32, { i64, ptr } } %t152, 1
  %t154 = extractvalue { i32, { i64, ptr } } %t152, 0
  store i32 %t154, ptr %l88
  %t155 = icmp ne i32 %t154, 0
  br i1 %t155, label %bb44, label %ok.156
ok.156:
  store { i64, ptr } %t153, ptr %l87
  br label %bb43
bb43:
  %t157 = load { i64, ptr }, ptr %l87, !tbaa !27
  store { i64, ptr } %t157, ptr %l84, !tbaa !27
  br label %bb48
bb44:
  %t158 = load i32, ptr %l88, !tbaa !23
  %t159 = ashr i32 %t158, 16
  %t161 = icmp eq i32 %t159, 1
  br i1 %t161, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_4273f8ce606e6d61_560529ef83d0fbe5)
  unreachable
bb47:
  call void @__olang_scope_close(ptr %s7)
  br label %bb58
bb48:
  %t163 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t163, ptr %l7, !tbaa !27
  %t164 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t166 = extractvalue { i64, ptr } %t164, 0
  store i64 %t166, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb49
bb49:
  store %olang.scope zeroinitializer, ptr %s8
  %t168 = load i64, ptr %l9, !tbaa !24
  %t169 = load i64, ptr %l8, !tbaa !24
  %t172 = icmp slt i64 %t168, %t169
  %t174 = xor i1 %t172, true
  br i1 %t174, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s8)
  br label %bb56
bb51:
  br label %bb52
bb52:
  %t176 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t176, ptr %l97, !tbaa !27
  %t177 = load i64, ptr %l9, !tbaa !24
  %t179 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !27
  %t181 = getelementptr { i64, [2 x i64] }, ptr %t180, i64 %t177
  %t182 = load { i64, [2 x i64] }, ptr %t181
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/scope:Scoper", ptr %t184, i32 0, i32 42
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3aTerm_3e_2ePush_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t186, { i64, [2 x i64] } %t182)
  br label %bb53
bb53:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t192 = getelementptr %"compiler/scope:Scoper", ptr %t190, i32 0, i32 43
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t192, i64 -1)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s8)
  br label %bb55
bb55:
  %t194 = load i64, ptr %l9, !tbaa !24
  %t196 = add i64 %t194, 1
  store i64 %t196, ptr %l9, !tbaa !24
  br label %bb49
bb56:
  %t198 = load i64, ptr %l6, !tbaa !24
  %t199 = load i64, ptr %l8, !tbaa !24
  %t202 = add i64 %t198, %t199
  store i64 %t202, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb57
bb57:
  br label %bb42
bb58:
  br label %ret
bb59:
  %t204 = load ptr, ptr %l0, !tbaa !29
  store ptr %t204, ptr %l110, !tbaa !29
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load ptr, ptr %l2, !tbaa !29
  %t209 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunPromoted(ptr %v0, ptr %v1, ptr %t205, ptr %t206)
  store ptr %t209, ptr %l113
  br label %bb60
bb60:
  %t210 = load ptr, ptr %l113, !tbaa !29
  %t211 = load ptr, ptr %l110, !tbaa !29
  %t213 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallOf(ptr %v0, ptr %v1, ptr %t211, ptr %t210)
  store ptr %t213, ptr %l115
  br label %bb61
bb61:
  %t214 = load ptr, ptr %l115, !tbaa !29
  store ptr %t214, ptr %l11, !tbaa !29
  %t215 = load ptr, ptr %l11, !tbaa !29
  %t217 = icmp eq ptr %t215, null
  br i1 %t217, label %bb62, label %bb63
bb62:
  store i1 true, ptr %l118, !tbaa !21
  br label %bb64
bb63:
  %t219 = load ptr, ptr %l11, !tbaa !29
  %t221 = getelementptr %"compiler/typed:Call", ptr %t219, i32 0, i32 3
  %t222 = load i32, ptr %t221, !tbaa !23
  %t224 = sext i32 %t222 to i64
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"compiler/scope:Scoper", ptr %t225, i32 0, i32 51
  %t228 = load i64, ptr %t227, !tbaa !24
  %t231 = icmp ne i64 %t224, %t228
  store i1 %t231, ptr %l118, !tbaa !21
  br label %bb64
bb64:
  %t233 = load i1, ptr %l118, !tbaa !21
  br i1 %t233, label %bb65, label %bb66
bb65:
  br label %ret
bb66:
  br label %bb67
bb67:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"compiler/scope:Scoper", ptr %t234, i32 0, i32 41
  %t237 = load i32, ptr %l1, !tbaa !23
  %t239 = sext i32 %t237 to i64
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = getelementptr %"compiler/scope:Scoper", ptr %t240, i32 0, i32 52
  %t243 = load i64, ptr %t242, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t236, i64 %t239, i64 %t243)
  br label %bb68
bb68:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsThrough(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, %"compiler/source:Span" %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l16 = alloca ptr
  %l19 = alloca i1
  %l23 = alloca ptr
  %l26 = alloca i1
  %l27 = alloca i64
  %l31 = alloca ptr
  %l34 = alloca i64
  %l39 = alloca i1
  %l40 = alloca i64
  %l44 = alloca ptr
  %l47 = alloca i64
  %l49 = alloca i1
  %l53 = alloca ptr
  %l57 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca { i64, [2 x i64] }
  %l63 = alloca %"compiler/source:Span"
  %l67 = alloca ptr
  %l71 = alloca i64
  %l75 = alloca ptr
  %l79 = alloca %"compiler/source:Span"
  %l80 = alloca ptr
  %l81 = alloca { i64, [2 x i64] }
  %l82 = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp sge i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp sge i64 %t5, 0
  store i1 %t7, ptr %l9, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/scope:Scoper", ptr %t10, i32 0, i32 6
  %t13 = load i64, ptr %l3, !tbaa !24
  %t16 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fscope_3asummary_26_H3a91daf058bf595e7b112751a30a6bbf(ptr %v0, ptr %v0, ptr %t12, i64 %t13)
  store ptr %t16, ptr %l16
  br label %bb6
bb5:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb11
bb6:
  %t17 = load ptr, ptr %l16, !tbaa !29
  %t19 = getelementptr %"compiler/scope:summary", ptr %t17, i32 0, i32 14
  %t20 = load i1, ptr %t19, !tbaa !21
  br i1 %t20, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb10
bb8:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/scope:Scoper", ptr %t22, i32 0, i32 6
  %t25 = load i64, ptr %l3, !tbaa !24
  %t28 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fscope_3asummary_26_H3a91daf058bf595e7b112751a30a6bbf(ptr %v0, ptr %v0, ptr %t24, i64 %t25)
  store ptr %t28, ptr %l23
  br label %bb9
bb9:
  %t29 = load ptr, ptr %l23, !tbaa !29
  %t31 = getelementptr %"compiler/scope:summary", ptr %t29, i32 0, i32 15
  %t32 = load i1, ptr %t31, !tbaa !21
  store i1 %t32, ptr %l19, !tbaa !21
  br label %bb10
bb10:
  %t34 = load i1, ptr %l19, !tbaa !21
  store i1 %t34, ptr %l12, !tbaa !21
  br label %bb11
bb11:
  %t35 = load i1, ptr %l12, !tbaa !21
  br i1 %t35, label %bb12, label %bb13
bb12:
  %t36 = load i64, ptr %l4, !tbaa !24
  store i64 %t36, ptr %l27, !tbaa !24
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/scope:Scoper", ptr %t37, i32 0, i32 6
  %t40 = load i64, ptr %l3, !tbaa !24
  %t43 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fscope_3asummary_26_H3a91daf058bf595e7b112751a30a6bbf(ptr %v0, ptr %v0, ptr %t39, i64 %t40)
  store ptr %t43, ptr %l31
  br label %bb14
bb13:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb16
bb14:
  %t44 = load ptr, ptr %l31, !tbaa !29
  %t46 = getelementptr %"compiler/scope:summary", ptr %t44, i32 0, i32 4
  %t48 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eLen_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t46)
  store i64 %t48, ptr %l34
  br label %bb15
bb15:
  %t49 = load i64, ptr %l27, !tbaa !24
  %t50 = load i64, ptr %l34, !tbaa !24
  %t51 = icmp slt i64 %t49, %t50
  store i1 %t51, ptr %l26, !tbaa !21
  br label %bb16
bb16:
  %t53 = load i1, ptr %l26, !tbaa !21
  store i1 %t53, ptr %l5, !tbaa !21
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/scope:Scoper", ptr %t54, i32 0, i32 58
  %t57 = load i1, ptr %t56, !tbaa !21
  store i1 %t57, ptr %l6, !tbaa !21
  %t59 = load i1, ptr %l5, !tbaa !21
  br i1 %t59, label %bb17, label %bb18
bb17:
  %t61 = load i64, ptr %l4, !tbaa !24
  store i64 %t61, ptr %l40, !tbaa !24
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/scope:Scoper", ptr %t62, i32 0, i32 6
  %t65 = load i64, ptr %l3, !tbaa !24
  %t68 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fscope_3asummary_26_H3a91daf058bf595e7b112751a30a6bbf(ptr %v0, ptr %v0, ptr %t64, i64 %t65)
  store ptr %t68, ptr %l44
  br label %bb19
bb18:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb21
bb19:
  %t69 = load ptr, ptr %l44, !tbaa !29
  %t71 = getelementptr %"compiler/scope:summary", ptr %t69, i32 0, i32 2
  %t73 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t71)
  store i64 %t73, ptr %l47
  br label %bb20
bb20:
  %t74 = load i64, ptr %l40, !tbaa !24
  %t75 = load i64, ptr %l47, !tbaa !24
  %t76 = icmp slt i64 %t74, %t75
  store i1 %t76, ptr %l39, !tbaa !21
  br label %bb21
bb21:
  %t78 = load i1, ptr %l39, !tbaa !21
  br i1 %t78, label %bb22, label %bb23
bb22:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/scope:Scoper", ptr %t79, i32 0, i32 6
  %t82 = load i64, ptr %l3, !tbaa !24
  %t85 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fscope_3asummary_26_H3a91daf058bf595e7b112751a30a6bbf(ptr %v0, ptr %v0, ptr %t81, i64 %t82)
  store ptr %t85, ptr %l53
  br label %bb24
bb23:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb26
bb24:
  %t86 = load ptr, ptr %l53, !tbaa !29
  %t88 = getelementptr %"compiler/scope:summary", ptr %t86, i32 0, i32 2
  %t89 = load i64, ptr %l4, !tbaa !24
  %t92 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t88, i64 %t89)
  store i1 %t92, ptr %l57
  br label %bb25
bb25:
  %t93 = load i1, ptr %l57, !tbaa !21
  %t94 = xor i1 %t93, true
  store i1 %t94, ptr %l49, !tbaa !21
  br label %bb26
bb26:
  %t96 = load i1, ptr %l49, !tbaa !21
  br i1 %t96, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/scope:Scoper", ptr %t97, i32 0, i32 58
  store i1 true, ptr %t99, !tbaa !21
  br label %bb29
bb28:
  br label %bb29
bb29:
  %t100 = load i1, ptr %l5, !tbaa !21
  br i1 %t100, label %bb30, label %bb31
bb30:
  %t102 = load ptr, ptr %l0, !tbaa !29
  store ptr %t102, ptr %l61, !tbaa !29
  %t103 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t103, ptr %l62
  %t104 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t104, ptr %l63
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/scope:Scoper", ptr %t105, i32 0, i32 6
  %t108 = load i64, ptr %l3, !tbaa !24
  %t111 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fscope_3asummary_26_H3a91daf058bf595e7b112751a30a6bbf(ptr %v0, ptr %v0, ptr %t107, i64 %t108)
  store ptr %t111, ptr %l67
  br label %bb32
bb31:
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l80, !tbaa !29
  %t113 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t113, ptr %l81
  %t114 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t114, ptr %l82
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/scope:Scoper", ptr %t115, i32 0, i32 25
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = icmp eq ptr %t118, null
  br i1 %t120, label %bb37, label %bb38
bb32:
  %t122 = load ptr, ptr %l67, !tbaa !29
  %t124 = getelementptr %"compiler/scope:summary", ptr %t122, i32 0, i32 3
  %t125 = load i64, ptr %l4, !tbaa !24
  %t128 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t124, i64 %t125)
  store i64 %t128, ptr %l71
  br label %bb33
bb33:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/scope:Scoper", ptr %t129, i32 0, i32 6
  %t132 = load i64, ptr %l3, !tbaa !24
  %t135 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fscope_3asummary_26_H3a91daf058bf595e7b112751a30a6bbf(ptr %v0, ptr %v0, ptr %t131, i64 %t132)
  store ptr %t135, ptr %l75
  br label %bb34
bb34:
  %t136 = load ptr, ptr %l75, !tbaa !29
  %t138 = getelementptr %"compiler/scope:summary", ptr %t136, i32 0, i32 4
  %t139 = load i64, ptr %l4, !tbaa !24
  %t142 = call %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t138, i64 %t139)
  store %"compiler/source:Span" %t142, ptr %l79
  br label %bb35
bb35:
  %t143 = load ptr, ptr %l61, !tbaa !29
  %t144 = load { i64, [2 x i64] }, ptr %l62
  %t145 = load %"compiler/source:Span", ptr %l63
  %t146 = load i64, ptr %l71, !tbaa !24
  %t147 = load %"compiler/source:Span", ptr %l79
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsInto(ptr %v0, ptr %t143, { i64, [2 x i64] } %t144, %"compiler/source:Span" %t145, i64 %t146, %"compiler/source:Span" %t147)
  br label %bb36
bb36:
  br label %bb41
bb37:
  call void @__olang_check_failed(ptr @olang_loc_43515980f8c6aee5_797864ac7e38a2e9)
  unreachable
bb38:
  br label %bb39
bb39:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/scope:Scoper", ptr %t148, i32 0, i32 25
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t154 = getelementptr %"compiler/typed:Body", ptr %t151, i32 0, i32 3
  %t155 = load i64, ptr %t154, !tbaa !24
  %t156 = load %"compiler/source:Span", ptr %l2
  %t157 = load ptr, ptr %l80, !tbaa !29
  %t158 = load { i64, [2 x i64] }, ptr %l81
  %t159 = load %"compiler/source:Span", ptr %l82
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsInto(ptr %v0, ptr %t157, { i64, [2 x i64] } %t158, %"compiler/source:Span" %t159, i64 %t155, %"compiler/source:Span" %t156)
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load i1, ptr %l6, !tbaa !21
  %t166 = getelementptr %"compiler/scope:Scoper", ptr %t162, i32 0, i32 58
  store i1 %t163, ptr %t166, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuiltOK(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca %"compiler/scope:rel"
  %l16 = alloca { i64, [2 x i64] }
  %l17 = alloca i64
  %l18 = alloca { i64, [2 x i64] }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca i1
  %l40 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l51 = alloca i1
  %l55 = alloca ptr
  %l61 = alloca i32
  %l65 = alloca i64
  %l68 = alloca i1
  %l71 = alloca i1
  %l76 = alloca i64
  %l84 = alloca { i64, ptr }
  %l88 = alloca ptr
  %l91 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l95 = alloca i32
  %l104 = alloca { i64, ptr }
  %l109 = alloca i1
  %l114 = alloca i1
  %l117 = alloca i1
  %l132 = alloca i64
  %l135 = alloca i64
  %l158 = alloca i64
  %l161 = alloca i64
  %l168 = alloca i1
  %l175 = alloca { i64, ptr }
  %l179 = alloca { i64, [2 x i64] }
  %l184 = alloca i1
  %l188 = alloca i1
  %l195 = alloca i64
  %l199 = alloca i1
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca i1
  %t210 = alloca { i64, [2 x i64] }, align 8
  %t343 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, [2 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t7 = load ptr, ptr %l31, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l31, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 2
  store i1 %t13, ptr %l32, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l32, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t17, i32 0, i32 2
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t23 = load { i64, [2 x i64] }, ptr %l2
  %t27 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartOK(ptr %v0, ptr %v1, ptr %t21, ptr %t22, { i64, [2 x i64] } %t23)
  store i1 %t27, ptr %l40
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load i1, ptr %l40, !tbaa !21
  store i1 %t28, ptr %rv
  br label %ret
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  store ptr %t29, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t30 = load ptr, ptr %l41, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb11, label %bb12
bb11:
  %t33 = load ptr, ptr %l41, !tbaa !29
  %t34 = load i64, ptr %t33
  %t36 = icmp eq i64 %t34, 17
  store i1 %t36, ptr %l42, !tbaa !21
  br label %bb12
bb12:
  %t37 = load i1, ptr %l42, !tbaa !21
  br i1 %t37, label %bb13, label %bb14
bb13:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr { i64, [5 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l4, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load ptr, ptr %l4, !tbaa !29
  %t47 = load { i64, [2 x i64] }, ptr %l2
  %t51 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuiltOK(ptr %v0, ptr %v1, ptr %t44, ptr %t45, { i64, [2 x i64] } %t47)
  store i1 %t51, ptr %l51
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s0)
  %t52 = load i1, ptr %l51, !tbaa !21
  store i1 %t52, ptr %rv
  br label %ret
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_51647c5149cfd088_fff8b53f00e80584)
  unreachable
bb22:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t58 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallOf(ptr %v0, ptr %v1, ptr %t53, ptr %t54)
  store ptr %t58, ptr %l55
  br label %bb23
bb23:
  %t59 = load ptr, ptr %l55, !tbaa !29
  store ptr %t59, ptr %l5, !tbaa !29
  %t60 = load ptr, ptr %l5, !tbaa !29
  %t62 = icmp eq ptr %t60, null
  br i1 %t62, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l5, !tbaa !29
  %t69 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %t65, ptr %t66)
  store i32 %t69, ptr %l61
  br label %bb27
bb27:
  %t70 = load i32, ptr %l61, !tbaa !23
  store i32 %t70, ptr %l6, !tbaa !23
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l5, !tbaa !29
  %t74 = getelementptr %"compiler/typed:Call", ptr %t72, i32 0, i32 0
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t78 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebodyOf(ptr %v0, ptr %v1, ptr %t71, ptr %t75)
  store i64 %t78, ptr %l65
  br label %bb28
bb28:
  %t79 = load i64, ptr %l65, !tbaa !24
  store i64 %t79, ptr %l7, !tbaa !24
  %t80 = load i64, ptr %l7, !tbaa !24
  %t82 = icmp slt i64 %t80, 0
  br i1 %t82, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l68, !tbaa !21
  br label %bb32
bb30:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i64, ptr %l7, !tbaa !24
  %t88 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esummed(ptr %v0, ptr %t84, i64 %t85)
  store i1 %t88, ptr %l71
  br label %bb31
bb31:
  %t89 = load i1, ptr %l71, !tbaa !21
  %t90 = xor i1 %t89, true
  store i1 %t90, ptr %l68, !tbaa !21
  br label %bb32
bb32:
  %t92 = load i1, ptr %l68, !tbaa !21
  br i1 %t92, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load i32, ptr %l6, !tbaa !23
  %t98 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eresultVarOf(ptr %v0, ptr %t94, i32 %t95)
  store i64 %t98, ptr %l76
  br label %bb36
bb36:
  %t99 = load i64, ptr %l76, !tbaa !24
  store i64 %t99, ptr %l8, !tbaa !24
  %t100 = load i64, ptr %l8, !tbaa !24
  %t102 = icmp slt i64 %t100, 0
  br i1 %t102, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/scope:Scoper", ptr %t105, i32 0, i32 0
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = getelementptr %"compiler/generic:Program", ptr %t108, i32 0, i32 2
  %t111 = load i32, ptr %l6, !tbaa !23
  %t114 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t110, i32 %t111)
  store { i64, ptr } %t114, ptr %l84
  br label %bb40
bb40:
  %t115 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t115, ptr %l9, !tbaa !27
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/scope:Scoper", ptr %t116, i32 0, i32 6
  %t119 = load i64, ptr %l7, !tbaa !24
  %t122 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fscope_3asummary_26_H3a91daf058bf595e7b112751a30a6bbf(ptr %v0, ptr %v0, ptr %t118, i64 %t119)
  store ptr %t122, ptr %l88
  br label %bb41
bb41:
  %t123 = load ptr, ptr %l88, !tbaa !29
  %t125 = getelementptr %"compiler/scope:summary", ptr %t123, i32 0, i32 0
  store ptr %t125, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb42
bb42:
  store %olang.scope zeroinitializer, ptr %s9
  %t127 = load ptr, ptr %l10, !tbaa !29
  %t128 = load i64, ptr %l11, !tbaa !24
  %t131 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3arel_3e_2eRunFrom_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t127, i64 %t128)
  %t132 = extractvalue { i32, { i64, ptr } } %t131, 1
  %t133 = extractvalue { i32, { i64, ptr } } %t131, 0
  store i32 %t133, ptr %l95
  %t134 = icmp ne i32 %t133, 0
  br i1 %t134, label %bb44, label %ok.135
ok.135:
  store { i64, ptr } %t132, ptr %l94
  br label %bb43
bb43:
  %t136 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t136, ptr %l91, !tbaa !27
  br label %bb48
bb44:
  %t137 = load i32, ptr %l95, !tbaa !23
  %t138 = ashr i32 %t137, 16
  %t140 = icmp eq i32 %t138, 1
  br i1 %t140, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_40698dacb4c14a59_3145716d01d07175)
  unreachable
bb47:
  call void @__olang_scope_close(ptr %s9)
  br label %bb121
bb48:
  %t142 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t142, ptr %l12, !tbaa !27
  %t143 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t143, 0
  store i64 %t145, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb49
bb49:
  store %olang.scope zeroinitializer, ptr %s10
  %t147 = load i64, ptr %l14, !tbaa !24
  %t148 = load i64, ptr %l13, !tbaa !24
  %t151 = icmp slt i64 %t147, %t148
  %t153 = xor i1 %t151, true
  br i1 %t153, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s10)
  br label %bb119
bb51:
  br label %bb52
bb52:
  %t155 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t155, ptr %l104, !tbaa !27
  %t156 = load i64, ptr %l14, !tbaa !24
  %t158 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !27
  %t160 = getelementptr %"compiler/scope:rel", ptr %t159, i64 %t156
  %t161 = load %"compiler/scope:rel", ptr %t160
  store %"compiler/scope:rel" %t161, ptr %l15
  %t163 = getelementptr %"compiler/scope:rel", ptr %l15, i32 0, i32 1
  %t164 = load { i64, [2 x i64] }, ptr %t163
  %t166 = extractvalue { i64, [2 x i64] } %t164, 0
  %t167 = icmp eq i64 %t166, 2
  br i1 %t167, label %bb53, label %bb54
bb53:
  %t169 = getelementptr %"compiler/scope:rel", ptr %l15, i32 0, i32 1
  %t170 = getelementptr { i64, [2 x i64] }, ptr %t169, i32 0, i32 1
  %t171 = getelementptr { i64 }, ptr %t170, i32 0, i32 0
  %t172 = load i64, ptr %t171
  %t173 = load i64, ptr %l8, !tbaa !24
  %t176 = icmp eq i64 %t172, %t173
  store i1 %t176, ptr %l109, !tbaa !21
  br label %bb55
bb54:
  store i1 false, ptr %l109, !tbaa !21
  br label %bb55
bb55:
  %t178 = load i1, ptr %l109, !tbaa !21
  %t179 = xor i1 %t178, true
  br i1 %t179, label %bb56, label %bb57
bb56:
  store i1 true, ptr %l114, !tbaa !21
  br label %bb61
bb57:
  %t181 = getelementptr %"compiler/scope:rel", ptr %l15, i32 0, i32 0
  %t182 = load { i64, [2 x i64] }, ptr %t181
  %t184 = extractvalue { i64, [2 x i64] } %t182, 0
  %t185 = icmp eq i64 %t184, 2
  br i1 %t185, label %bb58, label %bb59
bb58:
  %t187 = getelementptr %"compiler/scope:rel", ptr %l15, i32 0, i32 0
  %t188 = getelementptr { i64, [2 x i64] }, ptr %t187, i32 0, i32 1
  %t189 = getelementptr { i64 }, ptr %t188, i32 0, i32 0
  %t190 = load i64, ptr %t189
  %t191 = load i64, ptr %l8, !tbaa !24
  %t194 = icmp eq i64 %t190, %t191
  store i1 %t194, ptr %l117, !tbaa !21
  br label %bb60
bb59:
  store i1 false, ptr %l117, !tbaa !21
  br label %bb60
bb60:
  %t196 = load i1, ptr %l117, !tbaa !21
  store i1 %t196, ptr %l114, !tbaa !21
  br label %bb61
bb61:
  %t197 = load i1, ptr %l114, !tbaa !21
  br i1 %t197, label %bb62, label %bb63
bb62:
  call void @__olang_scope_close(ptr %s10)
  br label %bb118
bb63:
  br label %bb64
bb64:
  %t198 = getelementptr %"compiler/scope:rel", ptr %l15, i32 0, i32 0
  %t199 = load { i64, [2 x i64] }, ptr %t198
  store { i64, [2 x i64] } %t199, ptr %l16
  %t201 = load { i64, [2 x i64] }, ptr %l16
  %t203 = extractvalue { i64, [2 x i64] } %t201, 0
  %t204 = icmp eq i64 %t203, 2
  br i1 %t204, label %bb65, label %bb66
bb65:
  %t206 = getelementptr { i64, [2 x i64] }, ptr %l16, i32 0, i32 1
  %t207 = getelementptr { i64 }, ptr %t206, i32 0, i32 0
  %t208 = load i64, ptr %t207
  store i64 %t208, ptr %l17, !tbaa !24
  br label %bb67
bb66:
  br label %bb108
bb67:
  store { i64, [2 x i64] } zeroinitializer, ptr %t210
  %t211 = getelementptr { i64, [2 x i64] }, ptr %t210, i32 0, i32 0
  store i64 0, ptr %t211
  %t212 = load { i64, [2 x i64] }, ptr %t210
  store { i64, [2 x i64] } %t212, ptr %l18
  store i64 0, ptr %l19, !tbaa !24
  %t214 = load ptr, ptr %l5, !tbaa !29
  %t216 = getelementptr %"compiler/typed:Call", ptr %t214, i32 0, i32 1
  %t217 = load { i64, ptr }, ptr %t216, !tbaa !27
  %t219 = extractvalue { i64, ptr } %t217, 0
  store i64 %t219, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t221 = load i64, ptr %l20, !tbaa !24
  %t222 = load i64, ptr %l19, !tbaa !24
  %t225 = icmp sgt i64 %t221, %t222
  br i1 %t225, label %bb68, label %bb69
bb68:
  %t227 = load i64, ptr %l21, !tbaa !24
  %t229 = icmp sgt i64 %t227, 0
  br i1 %t229, label %bb70, label %bb71
bb69:
  store i64 0, ptr %l132, !tbaa !24
  br label %bb73
bb70:
  %t231 = load i64, ptr %l20, !tbaa !24
  %t232 = load i64, ptr %l19, !tbaa !24
  %t235 = sub i64 %t231, %t232
  %t236 = load i64, ptr %l21, !tbaa !24
  %t239 = add i64 %t235, %t236
  %t241 = sub i64 %t239, 1
  %t242 = load i64, ptr %l21, !tbaa !24
  %t245 = sdiv i64 %t241, %t242
  store i64 %t245, ptr %l135, !tbaa !24
  br label %bb72
bb71:
  store i64 0, ptr %l135, !tbaa !24
  br label %bb72
bb72:
  %t247 = load i64, ptr %l135, !tbaa !24
  store i64 %t247, ptr %l132, !tbaa !24
  br label %bb73
bb73:
  %t248 = load i64, ptr %l132, !tbaa !24
  store i64 %t248, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb74
bb74:
  store %olang.scope zeroinitializer, ptr %s14
  %t249 = load i64, ptr %l23, !tbaa !24
  %t250 = load i64, ptr %l22, !tbaa !24
  %t253 = icmp slt i64 %t249, %t250
  %t255 = xor i1 %t253, true
  br i1 %t255, label %bb75, label %bb76
bb75:
  call void @__olang_scope_close(ptr %s14)
  br label %bb90
bb76:
  br label %bb77
bb77:
  %t257 = load i64, ptr %l19, !tbaa !24
  %t258 = load i64, ptr %l23, !tbaa !24
  %t259 = load i64, ptr %l21, !tbaa !24
  %t262 = mul i64 %t258, %t259
  %t265 = add i64 %t257, %t262
  store i64 %t265, ptr %l24, !tbaa !24
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/scope:Scoper", ptr %t267, i32 0, i32 0
  %t270 = load ptr, ptr %t269, !tbaa !29
  %t272 = getelementptr %"compiler/generic:Program", ptr %t270, i32 0, i32 2
  %t273 = load i32, ptr %l6, !tbaa !23
  %t274 = load i64, ptr %l24, !tbaa !24
  %t278 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t272, i32 %t273, i64 %t274)
  store i64 %t278, ptr %l158
  br label %bb78
bb78:
  %t279 = load i64, ptr %l158, !tbaa !24
  store i64 %t279, ptr %l25, !tbaa !24
  %t280 = load i64, ptr %l25, !tbaa !24
  %t282 = icmp sge i64 %t280, 0
  br i1 %t282, label %bb79, label %bb80
bb79:
  %t284 = load i64, ptr %l25, !tbaa !24
  store i64 %t284, ptr %l161, !tbaa !24
  br label %bb81
bb80:
  %t286 = load i64, ptr %l24, !tbaa !24
  store i64 %t286, ptr %l161, !tbaa !24
  br label %bb81
bb81:
  %t288 = load i64, ptr %l161, !tbaa !24
  store i64 %t288, ptr %l26, !tbaa !24
  %t289 = load i64, ptr %l17, !tbaa !24
  %t290 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t292 = extractvalue { i64, ptr } %t290, 0
  %t295 = icmp slt i64 %t289, %t292
  br i1 %t295, label %bb82, label %bb83
bb82:
  %t297 = load i64, ptr %l17, !tbaa !24
  %t299 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t300 = load ptr, ptr %t299, !tbaa !27
  %t301 = getelementptr i64, ptr %t300, i64 %t297
  %t302 = load i64, ptr %t301, !tbaa !34
  %t303 = load i64, ptr %l26, !tbaa !24
  %t306 = icmp eq i64 %t302, %t303
  store i1 %t306, ptr %l168, !tbaa !21
  br label %bb84
bb83:
  store i1 false, ptr %l168, !tbaa !21
  br label %bb84
bb84:
  %t308 = load i1, ptr %l168, !tbaa !21
  br i1 %t308, label %bb85, label %bb86
bb85:
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t310 = load ptr, ptr %l5, !tbaa !29
  %t312 = getelementptr %"compiler/typed:Call", ptr %t310, i32 0, i32 1
  %t313 = load { i64, ptr }, ptr %t312, !tbaa !27
  store { i64, ptr } %t313, ptr %l175, !tbaa !27
  %t314 = load i64, ptr %l24, !tbaa !24
  %t316 = getelementptr { i64, ptr }, ptr %l175, i32 0, i32 1
  %t317 = load ptr, ptr %t316, !tbaa !27
  %t318 = getelementptr ptr, ptr %t317, i64 %t314
  %t319 = load ptr, ptr %t318, !tbaa !39
  %t323 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekTerm(ptr %v0, ptr %v1, ptr %t309, ptr %t319)
  store { i64, [2 x i64] } %t323, ptr %l179
  br label %bb87
bb86:
  br label %bb88
bb87:
  %t324 = load { i64, [2 x i64] }, ptr %l179
  store { i64, [2 x i64] } %t324, ptr %l18
  call void @__olang_scope_close(ptr %s14)
  br label %bb90
bb88:
  call void @__olang_scope_close(ptr %s14)
  br label %bb89
bb89:
  %t325 = load i64, ptr %l23, !tbaa !24
  %t327 = add i64 %t325, 1
  store i64 %t327, ptr %l23, !tbaa !24
  br label %bb74
bb90:
  %t329 = load { i64, [2 x i64] }, ptr %l18
  %t331 = extractvalue { i64, [2 x i64] } %t329, 0
  %t332 = icmp eq i64 %t331, 0
  br i1 %t332, label %bb91, label %bb92
bb91:
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t335 = load ptr, ptr %l5, !tbaa !29
  %t336 = load i64, ptr %l17, !tbaa !24
  %t340 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estaticVar(ptr %v0, ptr %v1, ptr %t334, ptr %t335, i64 %t336)
  store i1 %t340, ptr %l188
  br label %bb93
bb92:
  store i1 false, ptr %l184, !tbaa !21
  br label %bb94
bb93:
  %t341 = load i1, ptr %l188, !tbaa !21
  store i1 %t341, ptr %l184, !tbaa !21
  br label %bb94
bb94:
  %t342 = load i1, ptr %l184, !tbaa !21
  br i1 %t342, label %bb95, label %bb96
bb95:
  store { i64, [2 x i64] } zeroinitializer, ptr %t343
  %t344 = getelementptr { i64, [2 x i64] }, ptr %t343, i32 0, i32 0
  store i64 3, ptr %t344
  %t345 = load { i64, [2 x i64] }, ptr %t343
  store { i64, [2 x i64] } %t345, ptr %l18
  br label %bb97
bb96:
  br label %bb97
bb97:
  %t347 = load { i64, [2 x i64] }, ptr %l18
  %t349 = extractvalue { i64, [2 x i64] } %t347, 0
  %t350 = icmp eq i64 %t349, 0
  br i1 %t350, label %bb98, label %bb99
bb98:
  call void @__olang_scope_close(ptr %s10)
  br label %bb118
bb99:
  br label %bb100
bb100:
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t353 = load { i64, [2 x i64] }, ptr %l18
  %t354 = load { i64, [2 x i64] }, ptr %l2
  %t358 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eorder(ptr %v0, ptr %t352, { i64, [2 x i64] } %t353, { i64, [2 x i64] } %t354)
  store i64 %t358, ptr %l195
  br label %bb101
bb101:
  %t359 = load i64, ptr %l195, !tbaa !24
  store i64 %t359, ptr %l27, !tbaa !24
  %t360 = load i64, ptr %l27, !tbaa !24
  %t361 = load i64, ptr @G_2ecompiler_2fscope_2eHolds, !tbaa !24
  %t364 = icmp ne i64 %t360, %t361
  br i1 %t364, label %bb102, label %bb103
bb102:
  %t366 = load i64, ptr %l27, !tbaa !24
  %t367 = load i64, ptr @G_2ecompiler_2fscope_2eObliged, !tbaa !24
  %t370 = icmp ne i64 %t366, %t367
  store i1 %t370, ptr %l199, !tbaa !21
  br label %bb104
bb103:
  store i1 false, ptr %l199, !tbaa !21
  br label %bb104
bb104:
  %t372 = load i1, ptr %l199, !tbaa !21
  br i1 %t372, label %bb105, label %bb106
bb105:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb106:
  br label %bb107
bb107:
  br label %bb117
bb108:
  %t374 = load { i64, [2 x i64] }, ptr %l16
  %t376 = extractvalue { i64, [2 x i64] } %t374, 0
  %t377 = icmp eq i64 %t376, 3
  br i1 %t377, label %bb109, label %bb110
bb109:
  br label %bb111
bb110:
  br label %bb112
bb111:
  br label %bb117
bb112:
  br i1 true, label %bb113, label %bb114
bb113:
  br label %bb115
bb114:
  br label %bb116
bb115:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb116:
  call void @__olang_check_failed(ptr @olang_loc_83a782b953f03662_f9414c39571087be)
  unreachable
bb117:
  call void @__olang_scope_close(ptr %s10)
  br label %bb118
bb118:
  %t380 = load i64, ptr %l14, !tbaa !24
  %t382 = add i64 %t380, 1
  store i64 %t382, ptr %l14, !tbaa !24
  br label %bb49
bb119:
  %t384 = load i64, ptr %l11, !tbaa !24
  %t385 = load i64, ptr %l13, !tbaa !24
  %t388 = add i64 %t384, %t385
  store i64 %t388, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb120
bb120:
  br label %bb42
bb121:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i1
  %l18 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca i1
  %l28 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Call", ptr %a1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t7 = load ptr, ptr %l8, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l8, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l9, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [1 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { i32 }, ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t23 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 1
  %t24 = load i32, ptr %l3, !tbaa !23
  %t26 = sext i32 %t24 to i64
  %t29 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t23, i64 %t26)
  store ptr %t29, ptr %l18
  br label %bb6
bb6:
  %t30 = load ptr, ptr %l18, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Body", ptr %t30, i32 0, i32 2
  %t33 = load i32, ptr %t32, !tbaa !23
  store i32 %t33, ptr %l7, !tbaa !23
  br label %bb19
bb7:
  %t35 = load ptr, ptr %l2, !tbaa !29
  store ptr %t35, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t36 = load ptr, ptr %l21, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb8, label %bb9
bb8:
  %t39 = load ptr, ptr %l21, !tbaa !29
  %t40 = load i64, ptr %t39
  %t42 = icmp eq i64 %t40, 2
  store i1 %t42, ptr %l22, !tbaa !21
  br label %bb9
bb9:
  %t43 = load i1, ptr %l22, !tbaa !21
  br i1 %t43, label %bb10, label %bb11
bb10:
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t46 = getelementptr { i64, [1 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { ptr }, ptr %t46, i32 0, i32 0
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l4, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t52 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t50)
  store i32 %t52, ptr %l28
  br label %bb13
bb13:
  %t53 = load i32, ptr %l28, !tbaa !23
  store i32 %t53, ptr %l7, !tbaa !23
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t54 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t54, ptr %l7, !tbaa !23
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_fe18b6f8ffe1c828_d6769ee32e48c6ec)
  unreachable
bb19:
  %t56 = load i32, ptr %l7, !tbaa !23
  store i32 %t56, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallsItself(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l11 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l44 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 12
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t4)
  store i64 %t7, ptr %l11
  br label %bb1
bb1:
  %t8 = load i64, ptr %l11, !tbaa !24
  store i64 %t8, ptr %l2, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/scope:Scoper", ptr %t9, i32 0, i32 12
  %t12 = load i64, ptr %l1, !tbaa !24
  %t14 = add i64 %t12, 1
  %t17 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t11, i64 %t14)
  store i64 %t17, ptr %l16
  br label %bb2
bb2:
  %t18 = load i64, ptr %l16, !tbaa !24
  store i64 %t18, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = icmp sgt i64 %t19, %t20
  br i1 %t23, label %bb3, label %bb4
bb3:
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = icmp sgt i64 %t25, 0
  br i1 %t27, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb8
bb5:
  %t29 = load i64, ptr %l3, !tbaa !24
  %t30 = load i64, ptr %l2, !tbaa !24
  %t33 = sub i64 %t29, %t30
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = add i64 %t33, %t34
  %t39 = sub i64 %t37, 1
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = sdiv i64 %t39, %t40
  store i64 %t43, ptr %l23, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t45 = load i64, ptr %l23, !tbaa !24
  store i64 %t45, ptr %l20, !tbaa !24
  br label %bb8
bb8:
  %t46 = load i64, ptr %l20, !tbaa !24
  store i64 %t46, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l5, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb11:
  br label %bb12
bb12:
  %t55 = load i64, ptr %l2, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  %t57 = load i64, ptr %l4, !tbaa !24
  %t60 = mul i64 %t56, %t57
  %t63 = add i64 %t55, %t60
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/scope:Scoper", ptr %t65, i32 0, i32 13
  %t71 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t67, i64 %t63)
  store i64 %t71, ptr %l44
  br label %bb13
bb13:
  %t72 = load i64, ptr %l1, !tbaa !24
  %t73 = load i64, ptr %l44, !tbaa !24
  %t75 = icmp eq i64 %t73, %t72
  br i1 %t75, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  %t78 = load i64, ptr %l6, !tbaa !24
  %t80 = add i64 %t78, 1
  store i64 %t80, ptr %l6, !tbaa !24
  br label %bb9
bb18:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecapturingLambda(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l19 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l29 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 15
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb18
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t17 = load ptr, ptr %l11, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l11, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t27, i32 0, i32 1
  %t29 = load { i64, ptr }, ptr %t28
  store { i64, ptr } %t29, ptr %l3, !tbaa !27
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t35 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecapturesNothing(ptr %v0, ptr %v1, ptr %t31, { i64, ptr } %t32)
  store i1 %t35, ptr %l19
  br label %bb11
bb11:
  %t36 = load i1, ptr %l19, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %rv
  br label %ret
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_6e154fb23d94f618_2ee03e6b3f75e7ac)
  unreachable
bb17:
  br label %bb30
bb18:
  %t39 = load ptr, ptr %l1, !tbaa !29
  store ptr %t39, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t40 = load ptr, ptr %l21, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb19, label %bb20
bb19:
  %t43 = load ptr, ptr %l21, !tbaa !29
  %t44 = load i64, ptr %t43
  %t46 = icmp eq i64 %t44, 17
  store i1 %t46, ptr %l22, !tbaa !21
  br label %bb20
bb20:
  %t47 = load i1, ptr %l22, !tbaa !21
  br i1 %t47, label %bb21, label %bb22
bb21:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr { i64, [5 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t50, i32 0, i32 2
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l4, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t58 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecapturingLambda(ptr %v0, ptr %v1, ptr %t54, ptr %t55)
  store i1 %t58, ptr %l29
  br label %bb24
bb24:
  %t59 = load i1, ptr %l29, !tbaa !21
  store i1 %t59, ptr %rv
  br label %ret
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_e36c9ef691e1ece9_3ba86da2e7516a5d)
  unreachable
bb30:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca i64
  %l47 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca i1
  %l68 = alloca i1
  %l72 = alloca ptr
  %l73 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca i1
  %l102 = alloca ptr
  %l103 = alloca i1
  %l112 = alloca i1
  %l120 = alloca i64
  %l123 = alloca i64
  %l144 = alloca i1
  %l147 = alloca { i64, ptr }
  %l154 = alloca ptr
  %l155 = alloca i1
  %l168 = alloca { i64, ptr }
  %l177 = alloca ptr
  %l178 = alloca i1
  %l189 = alloca i1
  %l193 = alloca i1
  %l196 = alloca i1
  %l198 = alloca { i64, ptr }
  %l202 = alloca ptr
  %l203 = alloca i1
  %l217 = alloca ptr
  %l218 = alloca i1
  %l227 = alloca ptr
  %l228 = alloca i1
  %l241 = alloca { i64, ptr }
  %l254 = alloca ptr
  %l263 = alloca ptr
  %l264 = alloca i1
  %l281 = alloca { i64, ptr }
  %l292 = alloca { i64, ptr }
  %l303 = alloca ptr
  %l304 = alloca i1
  %l313 = alloca ptr
  %l314 = alloca i1
  %l319 = alloca ptr
  %l320 = alloca i1
  %l335 = alloca { i64, ptr }
  %l345 = alloca ptr
  %l346 = alloca i1
  %s10 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s38 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t6 = load ptr, ptr %l50, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l50, !tbaa !29
  %t10 = load i64, ptr %t9
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l51, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l51, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t16, i32 0, i32 1
  %t18 = load i32, ptr %t17
  store i32 %t18, ptr %l3, !tbaa !23
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [5 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t22, i32 0, i32 2
  %t24 = load ptr, ptr %t23
  store ptr %t24, ptr %l4, !tbaa !29
  br label %bb12
bb7:
  %t26 = load ptr, ptr %l1, !tbaa !29
  store ptr %t26, ptr %l58, !tbaa !29
  store i1 false, ptr %l59, !tbaa !21
  %t27 = load ptr, ptr %l58, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb8, label %bb9
bb8:
  %t30 = load ptr, ptr %l58, !tbaa !29
  %t31 = load i64, ptr %t30
  %t33 = icmp eq i64 %t31, 4
  store i1 %t33, ptr %l59, !tbaa !21
  br label %bb9
bb9:
  %t34 = load i1, ptr %l59, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb10:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr { i64, [5 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t37, i32 0, i32 1
  %t39 = load i32, ptr %t38
  store i32 %t39, ptr %l3, !tbaa !23
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr { i64, [5 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t43, i32 0, i32 2
  %t45 = load ptr, ptr %t44
  store ptr %t45, ptr %l4, !tbaa !29
  br label %bb12
bb11:
  br label %bb18
bb12:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i32, ptr %l3, !tbaa !23
  %t51 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t47, i32 %t48)
  store i1 %t51, ptr %l68
  br label %bb13
bb13:
  %t52 = load i1, ptr %l68, !tbaa !21
  br i1 %t52, label %bb14, label %bb15
bb14:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load ptr, ptr %l4, !tbaa !29
  %t55 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarriedPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t53, ptr %t54, ptr %t55)
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  br label %bb197
bb18:
  %t59 = load ptr, ptr %l1, !tbaa !29
  store ptr %t59, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t60 = load ptr, ptr %l72, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb19, label %bb20
bb19:
  %t63 = load ptr, ptr %l72, !tbaa !29
  %t64 = load i64, ptr %t63
  %t66 = icmp eq i64 %t64, 3
  store i1 %t66, ptr %l73, !tbaa !21
  br label %bb20
bb20:
  %t67 = load i1, ptr %l73, !tbaa !21
  br i1 %t67, label %bb21, label %bb22
bb21:
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [5 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t70, i32 0, i32 2
  %t72 = load ptr, ptr %t71
  store ptr %t72, ptr %l5, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load ptr, ptr %l5, !tbaa !29
  %t76 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarriedPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t74, ptr %t75, ptr %t76)
  br label %bb24
bb24:
  br label %bb197
bb25:
  %t80 = load ptr, ptr %l1, !tbaa !29
  store ptr %t80, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t81 = load ptr, ptr %l81, !tbaa !29
  %t82 = icmp ne ptr %t81, null
  br i1 %t82, label %bb26, label %bb27
bb26:
  %t84 = load ptr, ptr %l81, !tbaa !29
  %t85 = load i64, ptr %t84
  %t87 = icmp eq i64 %t85, 10
  store i1 %t87, ptr %l82, !tbaa !21
  br label %bb27
bb27:
  %t88 = load i1, ptr %l82, !tbaa !21
  br i1 %t88, label %bb28, label %bb29
bb28:
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr { i64, [5 x i64] }, ptr %t89, i32 0, i32 1
  %t92 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t91, i32 0, i32 2
  %t93 = load ptr, ptr %t92
  store ptr %t93, ptr %l6, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load ptr, ptr %l6, !tbaa !29
  %t98 = getelementptr %"compiler/typed:Slice", ptr %t96, i32 0, i32 0
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t100 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarriedPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t95, ptr %t99, ptr %t100)
  br label %bb31
bb31:
  br label %bb197
bb32:
  %t104 = load ptr, ptr %l1, !tbaa !29
  store ptr %t104, ptr %l91, !tbaa !29
  store i1 false, ptr %l92, !tbaa !21
  %t105 = load ptr, ptr %l91, !tbaa !29
  %t106 = icmp ne ptr %t105, null
  br i1 %t106, label %bb33, label %bb34
bb33:
  %t108 = load ptr, ptr %l91, !tbaa !29
  %t109 = load i64, ptr %t108
  %t111 = icmp eq i64 %t109, 5
  store i1 %t111, ptr %l92, !tbaa !21
  br label %bb34
bb34:
  %t112 = load i1, ptr %l92, !tbaa !21
  br i1 %t112, label %bb35, label %bb36
bb35:
  %t113 = load ptr, ptr %l1, !tbaa !29
  %t115 = getelementptr { i64, [5 x i64] }, ptr %t113, i32 0, i32 1
  %t116 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t115, i32 0, i32 2
  %t117 = load ptr, ptr %t116
  store ptr %t117, ptr %l7, !tbaa !29
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load ptr, ptr %l7, !tbaa !29
  %t122 = getelementptr %"compiler/typed:Promote", ptr %t120, i32 0, i32 0
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t119, ptr %t123, ptr %t125)
  br label %bb38
bb38:
  br label %bb197
bb39:
  %t129 = load ptr, ptr %l1, !tbaa !29
  store ptr %t129, ptr %l102, !tbaa !29
  store i1 false, ptr %l103, !tbaa !21
  %t130 = load ptr, ptr %l102, !tbaa !29
  %t131 = icmp ne ptr %t130, null
  br i1 %t131, label %bb40, label %bb41
bb40:
  %t133 = load ptr, ptr %l102, !tbaa !29
  %t134 = load i64, ptr %t133
  %t136 = icmp eq i64 %t134, 6
  store i1 %t136, ptr %l103, !tbaa !21
  br label %bb41
bb41:
  %t137 = load i1, ptr %l103, !tbaa !21
  br i1 %t137, label %bb42, label %bb43
bb42:
  %t138 = load ptr, ptr %l1, !tbaa !29
  %t140 = getelementptr { i64, [5 x i64] }, ptr %t138, i32 0, i32 1
  %t141 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t140, i32 0, i32 1
  %t142 = load i32, ptr %t141
  store i32 %t142, ptr %l8, !tbaa !23
  %t144 = load ptr, ptr %l1, !tbaa !29
  %t146 = getelementptr { i64, [5 x i64] }, ptr %t144, i32 0, i32 1
  %t147 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t146, i32 0, i32 2
  %t148 = load ptr, ptr %t147
  store ptr %t148, ptr %l9, !tbaa !29
  br label %bb44
bb43:
  br label %bb66
bb44:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load i32, ptr %l8, !tbaa !23
  %t154 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t150, i32 %t151)
  store i1 %t154, ptr %l112
  br label %bb45
bb45:
  %t155 = load i1, ptr %l112, !tbaa !21
  %t156 = xor i1 %t155, true
  br i1 %t156, label %bb46, label %bb47
bb46:
  br label %ret
bb47:
  br label %bb48
bb48:
  store i64 0, ptr %l10, !tbaa !24
  %t158 = load ptr, ptr %l9, !tbaa !29
  %t160 = getelementptr %"compiler/typed:Call", ptr %t158, i32 0, i32 1
  %t161 = load { i64, ptr }, ptr %t160, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t161, 0
  store i64 %t163, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t165 = load i64, ptr %l11, !tbaa !24
  %t166 = load i64, ptr %l10, !tbaa !24
  %t169 = icmp sgt i64 %t165, %t166
  br i1 %t169, label %bb49, label %bb50
bb49:
  %t171 = load i64, ptr %l12, !tbaa !24
  %t173 = icmp sgt i64 %t171, 0
  br i1 %t173, label %bb51, label %bb52
bb50:
  store i64 0, ptr %l120, !tbaa !24
  br label %bb54
bb51:
  %t175 = load i64, ptr %l11, !tbaa !24
  %t176 = load i64, ptr %l10, !tbaa !24
  %t179 = sub i64 %t175, %t176
  %t180 = load i64, ptr %l12, !tbaa !24
  %t183 = add i64 %t179, %t180
  %t185 = sub i64 %t183, 1
  %t186 = load i64, ptr %l12, !tbaa !24
  %t189 = sdiv i64 %t185, %t186
  store i64 %t189, ptr %l123, !tbaa !24
  br label %bb53
bb52:
  store i64 0, ptr %l123, !tbaa !24
  br label %bb53
bb53:
  %t191 = load i64, ptr %l123, !tbaa !24
  store i64 %t191, ptr %l120, !tbaa !24
  br label %bb54
bb54:
  %t192 = load i64, ptr %l120, !tbaa !24
  store i64 %t192, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb55
bb55:
  store %olang.scope zeroinitializer, ptr %s10
  %t193 = load i64, ptr %l14, !tbaa !24
  %t194 = load i64, ptr %l13, !tbaa !24
  %t197 = icmp slt i64 %t193, %t194
  %t199 = xor i1 %t197, true
  br i1 %t199, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s10)
  br label %bb65
bb57:
  br label %bb58
bb58:
  %t201 = load i64, ptr %l10, !tbaa !24
  %t202 = load i64, ptr %l14, !tbaa !24
  %t203 = load i64, ptr %l12, !tbaa !24
  %t206 = mul i64 %t202, %t203
  %t209 = add i64 %t201, %t206
  store i64 %t209, ptr %l15, !tbaa !24
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t212 = load ptr, ptr %l9, !tbaa !29
  %t213 = load i64, ptr %l15, !tbaa !24
  %t217 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecanKeep(ptr %v0, ptr %v1, ptr %t211, ptr %t212, i64 %t213)
  store i1 %t217, ptr %l144
  br label %bb59
bb59:
  %t218 = load i1, ptr %l144, !tbaa !21
  br i1 %t218, label %bb60, label %bb61
bb60:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load ptr, ptr %l9, !tbaa !29
  %t222 = getelementptr %"compiler/typed:Call", ptr %t220, i32 0, i32 1
  %t223 = load { i64, ptr }, ptr %t222, !tbaa !27
  store { i64, ptr } %t223, ptr %l147, !tbaa !27
  %t224 = load i64, ptr %l15, !tbaa !24
  %t226 = getelementptr { i64, ptr }, ptr %l147, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !27
  %t228 = getelementptr ptr, ptr %t227, i64 %t224
  %t229 = load ptr, ptr %t228, !tbaa !39
  %t231 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t219, ptr %t229, ptr %t231)
  br label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s10)
  br label %bb64
bb64:
  %t235 = load i64, ptr %l14, !tbaa !24
  %t237 = add i64 %t235, 1
  store i64 %t237, ptr %l14, !tbaa !24
  br label %bb55
bb65:
  br label %bb197
bb66:
  %t239 = load ptr, ptr %l1, !tbaa !29
  store ptr %t239, ptr %l154, !tbaa !29
  store i1 false, ptr %l155, !tbaa !21
  %t240 = load ptr, ptr %l154, !tbaa !29
  %t241 = icmp ne ptr %t240, null
  br i1 %t241, label %bb67, label %bb68
bb67:
  %t243 = load ptr, ptr %l154, !tbaa !29
  %t244 = load i64, ptr %t243
  %t246 = icmp eq i64 %t244, 7
  store i1 %t246, ptr %l155, !tbaa !21
  br label %bb68
bb68:
  %t247 = load i1, ptr %l155, !tbaa !21
  br i1 %t247, label %bb69, label %bb70
bb69:
  %t248 = load ptr, ptr %l1, !tbaa !29
  %t250 = getelementptr { i64, [5 x i64] }, ptr %t248, i32 0, i32 1
  %t251 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t250, i32 0, i32 2
  %t252 = load ptr, ptr %t251
  store ptr %t252, ptr %l16, !tbaa !29
  br label %bb71
bb70:
  br label %bb79
bb71:
  %t254 = load ptr, ptr %l16, !tbaa !29
  %t256 = getelementptr %"compiler/typed:Make", ptr %t254, i32 0, i32 2
  %t257 = load { i64, ptr }, ptr %t256, !tbaa !27
  store { i64, ptr } %t257, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t259 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t261 = extractvalue { i64, ptr } %t259, 0
  store i64 %t261, ptr %l19, !tbaa !24
  br label %bb72
bb72:
  store %olang.scope zeroinitializer, ptr %s15
  %t263 = load i64, ptr %l18, !tbaa !24
  %t264 = load i64, ptr %l19, !tbaa !24
  %t267 = icmp slt i64 %t263, %t264
  %t269 = xor i1 %t267, true
  br i1 %t269, label %bb73, label %bb74
bb73:
  call void @__olang_scope_close(ptr %s15)
  br label %bb78
bb74:
  br label %bb75
bb75:
  %t271 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t271, ptr %l168, !tbaa !27
  %t272 = load i64, ptr %l18, !tbaa !24
  %t274 = getelementptr { i64, ptr }, ptr %l168, i32 0, i32 1
  %t275 = load ptr, ptr %t274, !tbaa !27
  %t276 = getelementptr ptr, ptr %t275, i64 %t272
  %t277 = load ptr, ptr %t276, !tbaa !39
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t282 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t279, ptr %t277, ptr %t282)
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s15)
  br label %bb77
bb77:
  %t286 = load i64, ptr %l18, !tbaa !24
  %t288 = add i64 %t286, 1
  store i64 %t288, ptr %l18, !tbaa !24
  br label %bb72
bb78:
  br label %bb197
bb79:
  %t290 = load ptr, ptr %l1, !tbaa !29
  store ptr %t290, ptr %l177, !tbaa !29
  store i1 false, ptr %l178, !tbaa !21
  %t291 = load ptr, ptr %l177, !tbaa !29
  %t292 = icmp ne ptr %t291, null
  br i1 %t292, label %bb80, label %bb81
bb80:
  %t294 = load ptr, ptr %l177, !tbaa !29
  %t295 = load i64, ptr %t294
  %t297 = icmp eq i64 %t295, 9
  store i1 %t297, ptr %l178, !tbaa !21
  br label %bb81
bb81:
  %t298 = load i1, ptr %l178, !tbaa !21
  br i1 %t298, label %bb82, label %bb83
bb82:
  %t299 = load ptr, ptr %l1, !tbaa !29
  %t301 = getelementptr { i64, [5 x i64] }, ptr %t299, i32 0, i32 1
  %t302 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t301, i32 0, i32 1
  %t303 = load i32, ptr %t302
  store i32 %t303, ptr %l21, !tbaa !23
  %t305 = load ptr, ptr %l1, !tbaa !29
  %t307 = getelementptr { i64, [5 x i64] }, ptr %t305, i32 0, i32 1
  %t308 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t307, i32 0, i32 2
  %t309 = load i32, ptr %t308
  store i32 %t309, ptr %l22
  %t311 = load ptr, ptr %l1, !tbaa !29
  %t313 = getelementptr { i64, [5 x i64] }, ptr %t311, i32 0, i32 1
  %t314 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t313, i32 0, i32 4
  %t315 = load { i64, ptr }, ptr %t314
  store { i64, ptr } %t315, ptr %l23, !tbaa !27
  br label %bb84
bb83:
  br label %bb96
bb84:
  %t317 = load i32, ptr %l22
  %t319 = trunc i64 20 to i32
  %t320 = icmp eq i32 %t317, %t319
  br i1 %t320, label %bb85, label %bb86
bb85:
  %t322 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t324 = extractvalue { i64, ptr } %t322, 0
  %t326 = icmp sgt i64 %t324, 0
  store i1 %t326, ptr %l189, !tbaa !21
  br label %bb87
bb86:
  store i1 false, ptr %l189, !tbaa !21
  br label %bb87
bb87:
  %t328 = load i1, ptr %l189, !tbaa !21
  br i1 %t328, label %bb88, label %bb89
bb88:
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t330 = load i32, ptr %l21, !tbaa !23
  %t333 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t329, i32 %t330)
  store i1 %t333, ptr %l196
  br label %bb90
bb89:
  store i1 false, ptr %l193, !tbaa !21
  br label %bb91
bb90:
  %t334 = load i1, ptr %l196, !tbaa !21
  store i1 %t334, ptr %l193, !tbaa !21
  br label %bb91
bb91:
  %t335 = load i1, ptr %l193, !tbaa !21
  br i1 %t335, label %bb92, label %bb93
bb92:
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t337 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t337, ptr %l198, !tbaa !27
  %t338 = getelementptr { i64, ptr }, ptr %l198, i32 0, i32 1
  %t339 = load ptr, ptr %t338, !tbaa !27
  %t340 = getelementptr ptr, ptr %t339, i64 0
  %t341 = load ptr, ptr %t340, !tbaa !39
  %t343 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t336, ptr %t341, ptr %t343)
  br label %bb94
bb93:
  br label %bb95
bb94:
  br label %bb95
bb95:
  br label %bb197
bb96:
  %t347 = load ptr, ptr %l1, !tbaa !29
  store ptr %t347, ptr %l202, !tbaa !29
  store i1 false, ptr %l203, !tbaa !21
  %t348 = load ptr, ptr %l202, !tbaa !29
  %t349 = icmp ne ptr %t348, null
  br i1 %t349, label %bb97, label %bb98
bb97:
  %t351 = load ptr, ptr %l202, !tbaa !29
  %t352 = load i64, ptr %t351
  %t354 = icmp eq i64 %t352, 11
  store i1 %t354, ptr %l203, !tbaa !21
  br label %bb98
bb98:
  %t355 = load i1, ptr %l203, !tbaa !21
  br i1 %t355, label %bb99, label %bb100
bb99:
  %t356 = load ptr, ptr %l1, !tbaa !29
  %t358 = getelementptr { i64, [5 x i64] }, ptr %t356, i32 0, i32 1
  %t359 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t358, i32 0, i32 2
  %t360 = load ptr, ptr %t359
  store ptr %t360, ptr %l24, !tbaa !29
  br label %bb101
bb100:
  br label %bb104
bb101:
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t363 = load ptr, ptr %l24, !tbaa !29
  %t365 = getelementptr %"compiler/typed:Cond", ptr %t363, i32 0, i32 1
  %t366 = load ptr, ptr %t365, !tbaa !29
  %t367 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t362, ptr %t366, ptr %t367)
  br label %bb102
bb102:
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t372 = load ptr, ptr %l24, !tbaa !29
  %t374 = getelementptr %"compiler/typed:Cond", ptr %t372, i32 0, i32 2
  %t375 = load ptr, ptr %t374, !tbaa !29
  %t377 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t371, ptr %t375, ptr %t377)
  br label %bb103
bb103:
  br label %bb197
bb104:
  %t381 = load ptr, ptr %l1, !tbaa !29
  store ptr %t381, ptr %l217, !tbaa !29
  store i1 false, ptr %l218, !tbaa !21
  %t382 = load ptr, ptr %l217, !tbaa !29
  %t383 = icmp ne ptr %t382, null
  br i1 %t383, label %bb105, label %bb106
bb105:
  %t385 = load ptr, ptr %l217, !tbaa !29
  %t386 = load i64, ptr %t385
  %t388 = icmp eq i64 %t386, 12
  store i1 %t388, ptr %l218, !tbaa !21
  br label %bb106
bb106:
  %t389 = load i1, ptr %l218, !tbaa !21
  br i1 %t389, label %bb107, label %bb108
bb107:
  %t390 = load ptr, ptr %l1, !tbaa !29
  %t392 = getelementptr { i64, [5 x i64] }, ptr %t390, i32 0, i32 1
  %t393 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t392, i32 0, i32 2
  %t394 = load ptr, ptr %t393
  store ptr %t394, ptr %l25, !tbaa !29
  br label %bb109
bb108:
  br label %bb111
bb109:
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t397 = load ptr, ptr %l25, !tbaa !29
  %t399 = getelementptr %"compiler/typed:Seq", ptr %t397, i32 0, i32 1
  %t400 = load ptr, ptr %t399, !tbaa !29
  %t401 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t396, ptr %t400, ptr %t401)
  br label %bb110
bb110:
  br label %bb197
bb111:
  %t405 = load ptr, ptr %l1, !tbaa !29
  store ptr %t405, ptr %l227, !tbaa !29
  store i1 false, ptr %l228, !tbaa !21
  %t406 = load ptr, ptr %l227, !tbaa !29
  %t407 = icmp ne ptr %t406, null
  br i1 %t407, label %bb112, label %bb113
bb112:
  %t409 = load ptr, ptr %l227, !tbaa !29
  %t410 = load i64, ptr %t409
  %t412 = icmp eq i64 %t410, 13
  store i1 %t412, ptr %l228, !tbaa !21
  br label %bb113
bb113:
  %t413 = load i1, ptr %l228, !tbaa !21
  br i1 %t413, label %bb114, label %bb115
bb114:
  %t414 = load ptr, ptr %l1, !tbaa !29
  %t416 = getelementptr { i64, [5 x i64] }, ptr %t414, i32 0, i32 1
  %t417 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t416, i32 0, i32 2
  %t418 = load ptr, ptr %t417
  store ptr %t418, ptr %l26, !tbaa !29
  br label %bb116
bb115:
  br label %bb131
bb116:
  %t420 = load ptr, ptr %l26, !tbaa !29
  %t422 = getelementptr %"compiler/typed:Match", ptr %t420, i32 0, i32 1
  %t423 = load { i64, ptr }, ptr %t422, !tbaa !27
  store { i64, ptr } %t423, ptr %l27, !tbaa !27
  store i64 0, ptr %l28, !tbaa !24
  %t425 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t427 = extractvalue { i64, ptr } %t425, 0
  store i64 %t427, ptr %l29, !tbaa !24
  br label %bb117
bb117:
  store %olang.scope zeroinitializer, ptr %s23
  %t429 = load i64, ptr %l28, !tbaa !24
  %t430 = load i64, ptr %l29, !tbaa !24
  %t433 = icmp slt i64 %t429, %t430
  %t435 = xor i1 %t433, true
  br i1 %t435, label %bb118, label %bb119
bb118:
  call void @__olang_scope_close(ptr %s23)
  br label %bb123
bb119:
  br label %bb120
bb120:
  %t437 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t437, ptr %l241, !tbaa !27
  %t438 = load i64, ptr %l28, !tbaa !24
  %t440 = getelementptr { i64, ptr }, ptr %l241, i32 0, i32 1
  %t441 = load ptr, ptr %t440, !tbaa !27
  %t442 = getelementptr ptr, ptr %t441, i64 %t438
  %t443 = load ptr, ptr %t442, !tbaa !39
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t448 = getelementptr %"compiler/typed:Arm", ptr %t443, i32 0, i32 4
  %t449 = load ptr, ptr %t448, !tbaa !29
  %t450 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t445, ptr %t449, ptr %t450)
  br label %bb121
bb121:
  call void @__olang_scope_close(ptr %s23)
  br label %bb122
bb122:
  %t454 = load i64, ptr %l28, !tbaa !24
  %t456 = add i64 %t454, 1
  store i64 %t456, ptr %l28, !tbaa !24
  br label %bb117
bb123:
  %t458 = load ptr, ptr %l26, !tbaa !29
  %t460 = getelementptr %"compiler/typed:Match", ptr %t458, i32 0, i32 2
  %t461 = load ptr, ptr %t460, !tbaa !29
  %t463 = icmp eq ptr %t461, null
  %t465 = xor i1 %t463, true
  br i1 %t465, label %bb124, label %bb125
bb124:
  %t467 = load ptr, ptr %l0, !tbaa !29
  store ptr %t467, ptr %l254, !tbaa !29
  %t468 = load ptr, ptr %l26, !tbaa !29
  %t470 = getelementptr %"compiler/typed:Match", ptr %t468, i32 0, i32 2
  %t471 = load ptr, ptr %t470, !tbaa !29
  %t473 = icmp eq ptr %t471, null
  br i1 %t473, label %bb126, label %bb127
bb125:
  br label %bb130
bb126:
  call void @__olang_check_failed(ptr @olang_loc_9675e93c9f07526d_8a86ee267fb7b3d9)
  unreachable
bb127:
  br label %bb128
bb128:
  %t475 = load ptr, ptr %l26, !tbaa !29
  %t477 = getelementptr %"compiler/typed:Match", ptr %t475, i32 0, i32 2
  %t478 = load ptr, ptr %t477, !tbaa !29
  %t481 = getelementptr %"compiler/typed:Arm", ptr %t478, i32 0, i32 4
  %t482 = load ptr, ptr %t481, !tbaa !29
  %t483 = load ptr, ptr %l2, !tbaa !29
  %t484 = load ptr, ptr %l254, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t484, ptr %t482, ptr %t483)
  br label %bb129
bb129:
  br label %bb130
bb130:
  br label %bb197
bb131:
  %t487 = load ptr, ptr %l1, !tbaa !29
  store ptr %t487, ptr %l263, !tbaa !29
  store i1 false, ptr %l264, !tbaa !21
  %t488 = load ptr, ptr %l263, !tbaa !29
  %t489 = icmp ne ptr %t488, null
  br i1 %t489, label %bb132, label %bb133
bb132:
  %t491 = load ptr, ptr %l263, !tbaa !29
  %t492 = load i64, ptr %t491
  %t494 = icmp eq i64 %t492, 14
  store i1 %t494, ptr %l264, !tbaa !21
  br label %bb133
bb133:
  %t495 = load i1, ptr %l264, !tbaa !21
  br i1 %t495, label %bb134, label %bb135
bb134:
  %t496 = load ptr, ptr %l1, !tbaa !29
  %t498 = getelementptr { i64, [5 x i64] }, ptr %t496, i32 0, i32 1
  %t499 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t498, i32 0, i32 2
  %t500 = load ptr, ptr %t499
  store ptr %t500, ptr %l31, !tbaa !29
  br label %bb136
bb135:
  br label %bb151
bb136:
  %t502 = load ptr, ptr %l0, !tbaa !29
  %t503 = load ptr, ptr %l31, !tbaa !29
  %t505 = getelementptr %"compiler/typed:Try", ptr %t503, i32 0, i32 0
  %t506 = load ptr, ptr %t505, !tbaa !29
  %t507 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t502, ptr %t506, ptr %t507)
  br label %bb137
bb137:
  %t511 = load ptr, ptr %l31, !tbaa !29
  %t513 = getelementptr %"compiler/typed:Try", ptr %t511, i32 0, i32 1
  %t514 = load { i64, ptr }, ptr %t513, !tbaa !27
  store { i64, ptr } %t514, ptr %l32, !tbaa !27
  store i64 0, ptr %l33, !tbaa !24
  %t516 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t518 = extractvalue { i64, ptr } %t516, 0
  store i64 %t518, ptr %l34, !tbaa !24
  br label %bb138
bb138:
  store %olang.scope zeroinitializer, ptr %s28
  %t520 = load i64, ptr %l33, !tbaa !24
  %t521 = load i64, ptr %l34, !tbaa !24
  %t524 = icmp slt i64 %t520, %t521
  %t526 = xor i1 %t524, true
  br i1 %t526, label %bb139, label %bb140
bb139:
  call void @__olang_scope_close(ptr %s28)
  br label %bb150
bb140:
  br label %bb141
bb141:
  %t528 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t528, ptr %l281, !tbaa !27
  %t529 = load i64, ptr %l33, !tbaa !24
  %t531 = getelementptr { i64, ptr }, ptr %l281, i32 0, i32 1
  %t532 = load ptr, ptr %t531, !tbaa !27
  %t533 = getelementptr ptr, ptr %t532, i64 %t529
  %t534 = load ptr, ptr %t533, !tbaa !39
  %t538 = getelementptr %"compiler/typed:Clause", ptr %t534, i32 0, i32 4
  %t539 = load { i64, ptr }, ptr %t538, !tbaa !27
  store { i64, ptr } %t539, ptr %l36, !tbaa !27
  store i64 0, ptr %l37, !tbaa !24
  %t541 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t543 = extractvalue { i64, ptr } %t541, 0
  store i64 %t543, ptr %l38, !tbaa !24
  br label %bb142
bb142:
  store %olang.scope zeroinitializer, ptr %s30
  %t545 = load i64, ptr %l37, !tbaa !24
  %t546 = load i64, ptr %l38, !tbaa !24
  %t549 = icmp slt i64 %t545, %t546
  %t551 = xor i1 %t549, true
  br i1 %t551, label %bb143, label %bb144
bb143:
  call void @__olang_scope_close(ptr %s30)
  br label %bb148
bb144:
  br label %bb145
bb145:
  %t553 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t553, ptr %l292, !tbaa !27
  %t554 = load i64, ptr %l37, !tbaa !24
  %t556 = getelementptr { i64, ptr }, ptr %l292, i32 0, i32 1
  %t557 = load ptr, ptr %t556, !tbaa !27
  %t558 = getelementptr ptr, ptr %t557, i64 %t554
  %t559 = load ptr, ptr %t558, !tbaa !39
  %t561 = load ptr, ptr %l0, !tbaa !29
  %t564 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t561, ptr %t559, ptr %t564)
  br label %bb146
bb146:
  call void @__olang_scope_close(ptr %s30)
  br label %bb147
bb147:
  %t568 = load i64, ptr %l37, !tbaa !24
  %t570 = add i64 %t568, 1
  store i64 %t570, ptr %l37, !tbaa !24
  br label %bb142
bb148:
  call void @__olang_scope_close(ptr %s28)
  br label %bb149
bb149:
  %t572 = load i64, ptr %l33, !tbaa !24
  %t574 = add i64 %t572, 1
  store i64 %t574, ptr %l33, !tbaa !24
  br label %bb138
bb150:
  br label %bb197
bb151:
  %t576 = load ptr, ptr %l1, !tbaa !29
  store ptr %t576, ptr %l303, !tbaa !29
  store i1 false, ptr %l304, !tbaa !21
  %t577 = load ptr, ptr %l303, !tbaa !29
  %t578 = icmp ne ptr %t577, null
  br i1 %t578, label %bb152, label %bb153
bb152:
  %t580 = load ptr, ptr %l303, !tbaa !29
  %t581 = load i64, ptr %t580
  %t583 = icmp eq i64 %t581, 17
  store i1 %t583, ptr %l304, !tbaa !21
  br label %bb153
bb153:
  %t584 = load i1, ptr %l304, !tbaa !21
  br i1 %t584, label %bb154, label %bb155
bb154:
  %t585 = load ptr, ptr %l1, !tbaa !29
  %t587 = getelementptr { i64, [5 x i64] }, ptr %t585, i32 0, i32 1
  %t588 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t587, i32 0, i32 2
  %t589 = load ptr, ptr %t588
  store ptr %t589, ptr %l40, !tbaa !29
  br label %bb156
bb155:
  br label %bb158
bb156:
  %t591 = load ptr, ptr %l0, !tbaa !29
  %t592 = load ptr, ptr %l40, !tbaa !29
  %t594 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t591, ptr %t592, ptr %t594)
  br label %bb157
bb157:
  br label %bb197
bb158:
  %t598 = load ptr, ptr %l1, !tbaa !29
  store ptr %t598, ptr %l313, !tbaa !29
  store i1 false, ptr %l314, !tbaa !21
  %t599 = load ptr, ptr %l313, !tbaa !29
  %t600 = icmp ne ptr %t599, null
  br i1 %t600, label %bb159, label %bb160
bb159:
  %t602 = load ptr, ptr %l313, !tbaa !29
  %t603 = load i64, ptr %t602
  %t605 = icmp eq i64 %t603, 15
  store i1 %t605, ptr %l314, !tbaa !21
  br label %bb160
bb160:
  %t606 = load i1, ptr %l314, !tbaa !21
  br i1 %t606, label %bb161, label %bb162
bb161:
  %t607 = load ptr, ptr %l1, !tbaa !29
  %t609 = getelementptr { i64, [5 x i64] }, ptr %t607, i32 0, i32 1
  %t610 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t609, i32 0, i32 2
  %t611 = load ptr, ptr %t610
  store ptr %t611, ptr %l41, !tbaa !29
  br label %bb163
bb162:
  br label %bb192
bb163:
  %t613 = load ptr, ptr %l41, !tbaa !29
  store ptr %t613, ptr %l319, !tbaa !29
  store i1 false, ptr %l320, !tbaa !21
  %t614 = load ptr, ptr %l319, !tbaa !29
  %t615 = icmp ne ptr %t614, null
  br i1 %t615, label %bb164, label %bb165
bb164:
  %t617 = load ptr, ptr %l319, !tbaa !29
  %t618 = load i64, ptr %t617
  %t620 = icmp eq i64 %t618, 1
  store i1 %t620, ptr %l320, !tbaa !21
  br label %bb165
bb165:
  %t621 = load i1, ptr %l320, !tbaa !21
  br i1 %t621, label %bb166, label %bb167
bb166:
  %t622 = load ptr, ptr %l41, !tbaa !29
  %t624 = getelementptr { i64, [4 x i64] }, ptr %t622, i32 0, i32 1
  %t625 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t624, i32 0, i32 1
  %t626 = load { i64, ptr }, ptr %t625
  store { i64, ptr } %t626, ptr %l42, !tbaa !27
  br label %bb168
bb167:
  br label %bb179
bb168:
  %t628 = load ptr, ptr %l0, !tbaa !29
  %t630 = getelementptr %"compiler/scope:Scoper", ptr %t628, i32 0, i32 107
  %t631 = load i1, ptr %t630, !tbaa !21
  %t633 = xor i1 %t631, true
  br i1 %t633, label %bb169, label %bb170
bb169:
  br label %ret
bb170:
  br label %bb171
bb171:
  %t635 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t635, ptr %l43, !tbaa !27
  store i64 0, ptr %l44, !tbaa !24
  %t637 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t639 = extractvalue { i64, ptr } %t637, 0
  store i64 %t639, ptr %l45, !tbaa !24
  br label %bb172
bb172:
  store %olang.scope zeroinitializer, ptr %s38
  %t641 = load i64, ptr %l44, !tbaa !24
  %t642 = load i64, ptr %l45, !tbaa !24
  %t645 = icmp slt i64 %t641, %t642
  %t647 = xor i1 %t645, true
  br i1 %t647, label %bb173, label %bb174
bb173:
  call void @__olang_scope_close(ptr %s38)
  br label %bb178
bb174:
  br label %bb175
bb175:
  %t649 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t649, ptr %l335, !tbaa !27
  %t650 = load i64, ptr %l44, !tbaa !24
  %t652 = getelementptr { i64, ptr }, ptr %l335, i32 0, i32 1
  %t653 = load ptr, ptr %t652, !tbaa !27
  %t654 = getelementptr ptr, ptr %t653, i64 %t650
  %t655 = load ptr, ptr %t654, !tbaa !39
  %t657 = load ptr, ptr %l0, !tbaa !29
  %t660 = getelementptr %"compiler/typed:Capture", ptr %t655, i32 0, i32 1
  %t661 = load ptr, ptr %t660, !tbaa !29
  %t663 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t657, ptr %t661, ptr %t663)
  br label %bb176
bb176:
  call void @__olang_scope_close(ptr %s38)
  br label %bb177
bb177:
  %t667 = load i64, ptr %l44, !tbaa !24
  %t669 = add i64 %t667, 1
  store i64 %t669, ptr %l44, !tbaa !24
  br label %bb172
bb178:
  br label %bb191
bb179:
  %t671 = load ptr, ptr %l41, !tbaa !29
  store ptr %t671, ptr %l345, !tbaa !29
  store i1 false, ptr %l346, !tbaa !21
  %t672 = load ptr, ptr %l345, !tbaa !29
  %t673 = icmp ne ptr %t672, null
  br i1 %t673, label %bb180, label %bb181
bb180:
  %t675 = load ptr, ptr %l345, !tbaa !29
  %t676 = load i64, ptr %t675
  %t678 = icmp eq i64 %t676, 2
  store i1 %t678, ptr %l346, !tbaa !21
  br label %bb181
bb181:
  %t679 = load i1, ptr %l346, !tbaa !21
  br i1 %t679, label %bb182, label %bb183
bb182:
  %t680 = load ptr, ptr %l41, !tbaa !29
  %t682 = getelementptr { i64, [4 x i64] }, ptr %t680, i32 0, i32 1
  %t683 = getelementptr { i32, ptr, i32 }, ptr %t682, i32 0, i32 1
  %t684 = load ptr, ptr %t683
  store ptr %t684, ptr %l47, !tbaa !29
  br label %bb184
bb183:
  br label %bb186
bb184:
  %t686 = load ptr, ptr %l0, !tbaa !29
  %t687 = load ptr, ptr %l47, !tbaa !29
  %t689 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t686, ptr %t687, ptr %t689)
  br label %bb185
bb185:
  br label %bb191
bb186:
  br i1 true, label %bb187, label %bb188
bb187:
  br label %bb189
bb188:
  br label %bb190
bb189:
  br label %bb191
bb190:
  call void @__olang_check_failed(ptr @olang_loc_768f72a2579754c5_d91cee094dc07e21)
  unreachable
bb191:
  br label %bb197
bb192:
  br i1 true, label %bb193, label %bb194
bb193:
  br label %bb195
bb194:
  br label %bb196
bb195:
  br label %bb197
bb196:
  call void @__olang_check_failed(ptr @olang_loc_15f791c29ca5960e_c2f6ea53b6b5628a)
  unreachable
bb197:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2echoiceOfPlaces(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l17 = alloca i1
  %l19 = alloca i1
  %l24 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %l40 = alloca { i64, ptr }
  %l47 = alloca i1
  %l51 = alloca i1
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 11
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Cond", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t23 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %t16, ptr %t20)
  store i1 %t23, ptr %l17
  br label %bb6
bb6:
  %t24 = load i1, ptr %l17, !tbaa !21
  %t25 = xor i1 %t24, true
  br i1 %t25, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb10
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Cond", ptr %t28, i32 0, i32 2
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t35 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %t27, ptr %t31)
  store i1 %t35, ptr %l24
  br label %bb9
bb9:
  %t36 = load i1, ptr %l24, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %l19, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l19, !tbaa !21
  store i1 %t39, ptr %rv
  br label %ret
bb11:
  %t40 = load ptr, ptr %l1, !tbaa !29
  store ptr %t40, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t41 = load ptr, ptr %l26, !tbaa !29
  %t42 = icmp ne ptr %t41, null
  br i1 %t42, label %bb12, label %bb13
bb12:
  %t44 = load ptr, ptr %l26, !tbaa !29
  %t45 = load i64, ptr %t44
  %t47 = icmp eq i64 %t45, 13
  store i1 %t47, ptr %l27, !tbaa !21
  br label %bb13
bb13:
  %t48 = load i1, ptr %l27, !tbaa !21
  br i1 %t48, label %bb14, label %bb15
bb14:
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [5 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t51, i32 0, i32 2
  %t53 = load ptr, ptr %t52
  store ptr %t53, ptr %l3, !tbaa !29
  br label %bb16
bb15:
  br label %bb30
bb16:
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Match", ptr %t55, i32 0, i32 1
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  store { i64, ptr } %t58, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  store i64 %t62, ptr %l6, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t64 = load i64, ptr %l5, !tbaa !24
  %t65 = load i64, ptr %l6, !tbaa !24
  %t68 = icmp slt i64 %t64, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb29
bb19:
  br label %bb20
bb20:
  %t72 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t72, ptr %l40, !tbaa !27
  %t73 = load i64, ptr %l5, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr ptr, ptr %t76, i64 %t73
  %t78 = load ptr, ptr %t77, !tbaa !39
  store ptr %t78, ptr %l7, !tbaa !29
  %t80 = load ptr, ptr %l7, !tbaa !29
  %t82 = getelementptr %"compiler/typed:Arm", ptr %t80, i32 0, i32 4
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = icmp eq ptr %t83, null
  %t87 = xor i1 %t85, true
  br i1 %t87, label %bb21, label %bb22
bb21:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load ptr, ptr %l7, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Arm", ptr %t90, i32 0, i32 4
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t96 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %t89, ptr %t93)
  store i1 %t96, ptr %l51
  br label %bb23
bb22:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb24
bb23:
  %t97 = load i1, ptr %l51, !tbaa !21
  %t98 = xor i1 %t97, true
  store i1 %t98, ptr %l47, !tbaa !21
  br label %bb24
bb24:
  %t100 = load i1, ptr %l47, !tbaa !21
  br i1 %t100, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s4)
  store i1 true, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s4)
  br label %bb28
bb28:
  %t102 = load i64, ptr %l5, !tbaa !24
  %t104 = add i64 %t102, 1
  store i64 %t104, ptr %l5, !tbaa !24
  br label %bb17
bb29:
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_d9b9c9fdb1541cd0_611f76d9a930dfc4)
  unreachable
bb35:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2econstCopy(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2earenaValue(ptr %v0, ptr %t1, i32 %a2)
  store i1 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i1, ptr %l7, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t11 = load ptr, ptr %l10, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l10, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 2
  store i1 %t17, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l11, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l3, !tbaa !29
  br label %bb9
bb8:
  br label %bb22
bb9:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t30 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %t25, ptr %t26)
  store ptr %t30, ptr %l19
  br label %bb10
bb10:
  %t31 = load ptr, ptr %l19, !tbaa !29
  store ptr %t31, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t33 = load ptr, ptr %l21, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t36 = load ptr, ptr %l21, !tbaa !29
  %t37 = load i64, ptr %t36
  %t39 = icmp eq i64 %t37, 1
  store i1 %t39, ptr %l22, !tbaa !21
  br label %bb12
bb12:
  %t40 = load i1, ptr %l22, !tbaa !21
  br i1 %t40, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_fc2d23a56a9972c4_138c6d588cf96ab0)
  unreachable
bb21:
  %t41 = load i1, ptr %l20, !tbaa !21
  store i1 %t41, ptr %rv
  br label %ret
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  store i1 false, ptr %rv
  br label %ret
bb26:
  call void @__olang_check_failed(ptr @olang_loc_3c97826faaf501b5_26e177716b83aa41)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eelemAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca %"compiler/source:Span"
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca ptr
  %l17 = alloca i1
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l43 = alloca i32
  %l51 = alloca i64
  %l54 = alloca i64
  %l76 = alloca { i64, ptr }
  %l85 = alloca %"compiler/source:Span"
  %s1 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 0, i32 0)
  store %"compiler/source:Span" %t5, ptr %l13
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  %t6 = load %"compiler/source:Span", ptr %l13
  store %"compiler/source:Span" %t6, ptr %rv
  br label %ret
bb4:
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t7)
  store %"compiler/source:Span" %t9, ptr %l15
  br label %bb5
bb5:
  %t10 = load %"compiler/source:Span", ptr %l15
  store %"compiler/source:Span" %t10, ptr %l2
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t12 = load ptr, ptr %l16, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l16, !tbaa !29
  %t16 = load i64, ptr %t15
  %t18 = icmp eq i64 %t16, 14
  store i1 %t18, ptr %l17, !tbaa !21
  br label %bb7
bb7:
  %t19 = load i1, ptr %l17, !tbaa !21
  br i1 %t19, label %bb8, label %bb9
bb8:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [5 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t22, i32 0, i32 2
  %t24 = load ptr, ptr %t23
  store ptr %t24, ptr %l3, !tbaa !29
  br label %bb10
bb9:
  br label %bb18
bb10:
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t28 = getelementptr %"compiler/typed:Try", ptr %t26, i32 0, i32 0
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = icmp eq ptr %t29, null
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb11, label %bb12
bb11:
  %t35 = load ptr, ptr %l3, !tbaa !29
  %t37 = getelementptr %"compiler/typed:Try", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = icmp eq ptr %t38, null
  br i1 %t40, label %bb13, label %bb14
bb12:
  br label %bb17
bb13:
  call void @__olang_check_failed(ptr @olang_loc_f7f7e8cd8f874575_c4b9e23387941a21)
  unreachable
bb14:
  br label %bb15
bb15:
  %t42 = load ptr, ptr %l3, !tbaa !29
  %t44 = getelementptr %"compiler/typed:Try", ptr %t42, i32 0, i32 0
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t45)
  store %"compiler/source:Span" %t47, ptr %l31
  br label %bb16
bb16:
  %t48 = load %"compiler/source:Span", ptr %l31
  store %"compiler/source:Span" %t48, ptr %l2
  br label %bb17
bb17:
  br label %bb23
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_fdfd3ee9277a2fdd_9e10cfc7d92600f9)
  unreachable
bb23:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/scope:Scoper", ptr %t49, i32 0, i32 10
  store ptr %t51, ptr %l34, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/scope:Scoper", ptr %t52, i32 0, i32 25
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = icmp eq ptr %t55, null
  br i1 %t57, label %bb24, label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_933cba94e4afba7f_7f3963489057e55b)
  unreachable
bb25:
  br label %bb26
bb26:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/scope:Scoper", ptr %t59, i32 0, i32 25
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t65 = getelementptr %"compiler/typed:Body", ptr %t62, i32 0, i32 3
  %t66 = load i64, ptr %t65, !tbaa !24
  %t67 = load ptr, ptr %l34, !tbaa !29
  %t69 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v0, ptr %t67, i64 %t66)
  %t70 = extractvalue { i32, { i64, ptr } } %t69, 1
  %t71 = extractvalue { i32, { i64, ptr } } %t69, 0
  store i32 %t71, ptr %l43
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb28, label %ok.73
ok.73:
  store { i64, ptr } %t70, ptr %l42
  br label %bb27
bb27:
  %t74 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t74, ptr %l32, !tbaa !27
  br label %bb30
bb28:
  br label %bb29
bb29:
  store { i64, ptr } { i64 0, ptr @.d0 }, ptr %l32, !tbaa !27
  br label %bb30
bb30:
  %t75 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t75, ptr %l4, !tbaa !27
  %t76 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t77 = load i32, ptr %t76, !tbaa !23
  %t79 = sext i32 %t77 to i64
  store i64 %t79, ptr %l5, !tbaa !24
  %t81 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t82 = load i32, ptr %t81, !tbaa !23
  %t84 = sext i32 %t82 to i64
  store i64 %t84, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t86 = load i64, ptr %l6, !tbaa !24
  %t87 = load i64, ptr %l5, !tbaa !24
  %t90 = icmp sgt i64 %t86, %t87
  br i1 %t90, label %bb31, label %bb32
bb31:
  %t92 = load i64, ptr %l7, !tbaa !24
  %t94 = icmp sgt i64 %t92, 0
  br i1 %t94, label %bb33, label %bb34
bb32:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb36
bb33:
  %t96 = load i64, ptr %l6, !tbaa !24
  %t97 = load i64, ptr %l5, !tbaa !24
  %t100 = sub i64 %t96, %t97
  %t101 = load i64, ptr %l7, !tbaa !24
  %t104 = add i64 %t100, %t101
  %t106 = sub i64 %t104, 1
  %t107 = load i64, ptr %l7, !tbaa !24
  %t110 = sdiv i64 %t106, %t107
  store i64 %t110, ptr %l54, !tbaa !24
  br label %bb35
bb34:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb35
bb35:
  %t112 = load i64, ptr %l54, !tbaa !24
  store i64 %t112, ptr %l51, !tbaa !24
  br label %bb36
bb36:
  %t113 = load i64, ptr %l51, !tbaa !24
  store i64 %t113, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s6
  %t114 = load i64, ptr %l9, !tbaa !24
  %t115 = load i64, ptr %l8, !tbaa !24
  %t118 = icmp slt i64 %t114, %t115
  %t120 = xor i1 %t118, true
  br i1 %t120, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s6)
  br label %bb49
bb39:
  br label %bb40
bb40:
  %t122 = load i64, ptr %l5, !tbaa !24
  %t123 = load i64, ptr %l9, !tbaa !24
  %t124 = load i64, ptr %l7, !tbaa !24
  %t127 = mul i64 %t123, %t124
  %t130 = add i64 %t122, %t127
  store i64 %t130, ptr %l10, !tbaa !24
  %t132 = load i64, ptr %l10, !tbaa !24
  %t133 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t133, 0
  %t138 = icmp sge i64 %t132, %t135
  br i1 %t138, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s6)
  br label %bb49
bb42:
  br label %bb43
bb43:
  %t140 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t140, ptr %l76, !tbaa !27
  %t141 = load i64, ptr %l10, !tbaa !24
  %t143 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = getelementptr i8, ptr %t144, i64 %t141
  %t146 = load i8, ptr %t145, !tbaa !32
  %t148 = icmp eq i8 %t146, 91
  br i1 %t148, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s8
  %t150 = load i64, ptr %l10, !tbaa !24
  %t152 = trunc i64 %t150 to i32
  %t153 = load i64, ptr %l10, !tbaa !24
  %t155 = add i64 %t153, 1
  %t157 = trunc i64 %t155 to i32
  %t160 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s8, i32 %t152, i32 %t157)
  store %"compiler/source:Span" %t160, ptr %l85
  br label %bb46
bb45:
  br label %bb47
bb46:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s6)
  %t161 = load %"compiler/source:Span", ptr %l85
  store %"compiler/source:Span" %t161, ptr %rv
  br label %ret
bb47:
  call void @__olang_scope_close(ptr %s6)
  br label %bb48
bb48:
  %t162 = load i64, ptr %l9, !tbaa !24
  %t164 = add i64 %t162, 1
  store i64 %t164, ptr %l9, !tbaa !24
  br label %bb37
bb49:
  %t166 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t166, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efieldRec(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, [2 x i64] }
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca { i64, [2 x i64] }
  %l21 = alloca { i64, [2 x i64] }
  %l22 = alloca i64
  %l23 = alloca { i64, [1 x i64] }
  %l24 = alloca i32
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l33 = alloca i32
  %l36 = alloca i1
  %l43 = alloca i32
  %l46 = alloca ptr
  %l49 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l50 = alloca i1
  %l51 = alloca i1
  %l53 = alloca ptr
  %l55 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l56 = alloca i1
  %l60 = alloca i64
  %l64 = alloca { i64, [2 x i64] }
  %l71 = alloca i64
  %l74 = alloca i1
  %l77 = alloca i1
  %l80 = alloca i64
  %l83 = alloca i64
  %l91 = alloca i64
  %l92 = alloca i64
  %l96 = alloca i64
  %l97 = alloca i32
  %l100 = alloca i1
  %l103 = alloca i1
  %l105 = alloca i1
  %l106 = alloca i64
  %l110 = alloca ptr
  %l113 = alloca i64
  %l119 = alloca ptr
  %l123 = alloca i64
  %l130 = alloca ptr
  %l131 = alloca i64
  %l134 = alloca i64
  %l136 = alloca i64
  %l137 = alloca ptr
  %l139 = alloca ptr
  %l143 = alloca i32
  %l145 = alloca %"compiler/typed:Local"
  %l147 = alloca i64
  %l150 = alloca i1
  %l153 = alloca i64
  %l157 = alloca ptr
  %l160 = alloca i64
  %l165 = alloca i64
  %l170 = alloca i64
  %l173 = alloca i64
  %l194 = alloca ptr
  %l200 = alloca { i64, [2 x i64] }
  %l208 = alloca i64
  %l211 = alloca i64
  %l216 = alloca { i64, [1 x i64] }
  %l221 = alloca { i64, [2 x i64] }
  %l227 = alloca i64
  %l231 = alloca i64
  %l234 = alloca i64
  %l255 = alloca i32
  %l263 = alloca i1
  %l266 = alloca i1
  %l269 = alloca i64
  %l272 = alloca i64
  %l279 = alloca { i64, [2 x i64] }
  %s0 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %rv = alloca i64
  %t325 = alloca { i64, [2 x i64] }, align 8
  %t334 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t1)
  store i32 %t3, ptr %l33
  br label %bb1
bb1:
  %t4 = load i32, ptr %l33, !tbaa !23
  store i32 %t4, ptr %l3, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l3, !tbaa !23
  %t9 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisStruct(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l36
  br label %bb2
bb2:
  %t10 = load i1, ptr %l36, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/scope:Scoper", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 2
  %t20 = load i32, ptr %l3, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t19, i32 %t20)
  store i32 %t23, ptr %l43
  br label %bb6
bb6:
  %t24 = load i32, ptr %l43, !tbaa !23
  %t25 = sext i32 %t24 to i64
  store i64 %t25, ptr %l4, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/scope:Scoper", ptr %t27, i32 0, i32 45
  store ptr %t29, ptr %l46, !tbaa !29
  %t30 = load i64, ptr %l4, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t34 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t30, i64 %t31)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t34, ptr %l49
  br label %bb7
bb7:
  %t35 = load ptr, ptr %l46, !tbaa !29
  %t36 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l49
  %t37 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t35, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t36)
  store i1 %t37, ptr %l50
  br label %bb8
bb8:
  %t38 = load i1, ptr %l50, !tbaa !21
  br i1 %t38, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb13
bb10:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/scope:Scoper", ptr %t39, i32 0, i32 45
  store ptr %t41, ptr %l53, !tbaa !29
  %t42 = load i64, ptr %l4, !tbaa !24
  %t44 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t42, i64 -1)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t44, ptr %l55
  br label %bb11
bb11:
  %t45 = load ptr, ptr %l53, !tbaa !29
  %t46 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l55
  %t47 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t45, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t46)
  store i1 %t47, ptr %l56
  br label %bb12
bb12:
  %t48 = load i1, ptr %l56, !tbaa !21
  store i1 %t48, ptr %l51, !tbaa !21
  br label %bb13
bb13:
  %t49 = load i1, ptr %l51, !tbaa !21
  br i1 %t49, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t55 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erecOf(ptr %v0, ptr %v1, ptr %t51, ptr %t52)
  store i64 %t55, ptr %l60
  br label %bb17
bb17:
  %t56 = load i64, ptr %l60, !tbaa !24
  store i64 %t56, ptr %l5, !tbaa !24
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load i32, ptr %l3, !tbaa !23
  %t59 = load i64, ptr %l2, !tbaa !24
  %t63 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efieldMark(ptr %v0, ptr %t57, i32 %t58, i64 %t59)
  store { i64, [2 x i64] } %t63, ptr %l64
  br label %bb18
bb18:
  %t64 = load { i64, [2 x i64] }, ptr %l64
  store { i64, [2 x i64] } %t64, ptr %l6
  %t65 = load { i64, [2 x i64] }, ptr %l6
  %t67 = extractvalue { i64, [2 x i64] } %t65, 0
  %t68 = icmp eq i64 %t67, 2
  br i1 %t68, label %bb19, label %bb20
bb19:
  %t70 = getelementptr { i64, [2 x i64] }, ptr %l6, i32 0, i32 1
  %t71 = getelementptr { i32 }, ptr %t70, i32 0, i32 0
  %t72 = load i32, ptr %t71
  store i32 %t72, ptr %l7, !tbaa !23
  br label %bb21
bb20:
  br label %bb34
bb21:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i32, ptr %l3, !tbaa !23
  %t76 = load i32, ptr %l7, !tbaa !23
  %t80 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ectorParamIndex(ptr %v0, ptr %t74, i32 %t75, i32 %t76)
  store i64 %t80, ptr %l71
  br label %bb22
bb22:
  %t81 = load i64, ptr %l71, !tbaa !24
  store i64 %t81, ptr %l8, !tbaa !24
  %t82 = load i64, ptr %l5, !tbaa !24
  %t84 = icmp slt i64 %t82, 0
  br i1 %t84, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb25
bb24:
  %t86 = load i64, ptr %l8, !tbaa !24
  %t88 = icmp slt i64 %t86, 0
  store i1 %t88, ptr %l74, !tbaa !21
  br label %bb25
bb25:
  %t90 = load i1, ptr %l74, !tbaa !21
  br i1 %t90, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb29
bb27:
  %t91 = load i64, ptr %l5, !tbaa !24
  %t92 = load i64, ptr %l8, !tbaa !24
  %t95 = add i64 %t91, %t92
  store i64 %t95, ptr %l80, !tbaa !24
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/scope:Scoper", ptr %t96, i32 0, i32 43
  %t100 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t98)
  store i64 %t100, ptr %l83
  br label %bb28
bb28:
  %t101 = load i64, ptr %l80, !tbaa !24
  %t102 = load i64, ptr %l83, !tbaa !24
  %t103 = icmp sge i64 %t101, %t102
  store i1 %t103, ptr %l77, !tbaa !21
  br label %bb29
bb29:
  %t105 = load i1, ptr %l77, !tbaa !21
  br i1 %t105, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/scope:Scoper", ptr %t107, i32 0, i32 43
  %t110 = load i64, ptr %l5, !tbaa !24
  %t111 = load i64, ptr %l8, !tbaa !24
  %t114 = add i64 %t110, %t111
  %t117 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t109, i64 %t114)
  store i64 %t117, ptr %l91
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s0)
  %t118 = load i64, ptr %l91, !tbaa !24
  store i64 %t118, ptr %rv
  br label %ret
bb34:
  br i1 true, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_a845573c521645ec_3201dcbaaced68)
  unreachable
bb39:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/scope:Scoper", ptr %t119, i32 0, i32 7
  %t122 = load i32, ptr %l3, !tbaa !23
  %t125 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %t121, i32 %t122)
  %t126 = extractvalue { i32, i64 } %t125, 1
  %t127 = extractvalue { i32, i64 } %t125, 0
  store i32 %t127, ptr %l97
  %t128 = icmp ne i32 %t127, 0
  br i1 %t128, label %bb41, label %ok.129
ok.129:
  store i64 %t126, ptr %l96
  br label %bb40
bb40:
  %t130 = load i64, ptr %l96, !tbaa !24
  store i64 %t130, ptr %l92, !tbaa !24
  br label %bb43
bb41:
  br label %bb42
bb42:
  store i64 -1, ptr %l92, !tbaa !24
  br label %bb43
bb43:
  %t131 = load i64, ptr %l92, !tbaa !24
  store i64 %t131, ptr %l9, !tbaa !24
  %t132 = load i64, ptr %l9, !tbaa !24
  %t134 = icmp slt i64 %t132, 0
  br i1 %t134, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l100, !tbaa !21
  br label %bb47
bb45:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load i64, ptr %l9, !tbaa !24
  %t140 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esummed(ptr %v0, ptr %t136, i64 %t137)
  store i1 %t140, ptr %l103
  br label %bb46
bb46:
  %t141 = load i1, ptr %l103, !tbaa !21
  %t142 = xor i1 %t141, true
  store i1 %t142, ptr %l100, !tbaa !21
  br label %bb47
bb47:
  %t144 = load i1, ptr %l100, !tbaa !21
  br i1 %t144, label %bb48, label %bb49
bb48:
  store i1 true, ptr %l105, !tbaa !21
  br label %bb52
bb49:
  %t145 = load i64, ptr %l2, !tbaa !24
  store i64 %t145, ptr %l106, !tbaa !24
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/scope:Scoper", ptr %t146, i32 0, i32 6
  %t149 = load i64, ptr %l9, !tbaa !24
  %t152 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fscope_3asummary_26_H3a91daf058bf595e7b112751a30a6bbf(ptr %v0, ptr %v0, ptr %t148, i64 %t149)
  store ptr %t152, ptr %l110
  br label %bb50
bb50:
  %t153 = load ptr, ptr %l110, !tbaa !29
  %t155 = getelementptr %"compiler/scope:summary", ptr %t153, i32 0, i32 12
  %t157 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t155)
  store i64 %t157, ptr %l113
  br label %bb51
bb51:
  %t158 = load i64, ptr %l106, !tbaa !24
  %t159 = load i64, ptr %l113, !tbaa !24
  %t160 = icmp sge i64 %t158, %t159
  store i1 %t160, ptr %l105, !tbaa !21
  br label %bb52
bb52:
  %t162 = load i1, ptr %l105, !tbaa !21
  br i1 %t162, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb54:
  br label %bb55
bb55:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/scope:Scoper", ptr %t164, i32 0, i32 6
  %t167 = load i64, ptr %l9, !tbaa !24
  %t170 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fscope_3asummary_26_H3a91daf058bf595e7b112751a30a6bbf(ptr %v0, ptr %v0, ptr %t166, i64 %t167)
  store ptr %t170, ptr %l119
  br label %bb56
bb56:
  %t171 = load ptr, ptr %l119, !tbaa !29
  %t173 = getelementptr %"compiler/scope:summary", ptr %t171, i32 0, i32 12
  %t174 = load i64, ptr %l2, !tbaa !24
  %t177 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t173, i64 %t174)
  store i64 %t177, ptr %l123
  br label %bb57
bb57:
  %t178 = load i64, ptr %l123, !tbaa !24
  store i64 %t178, ptr %l10, !tbaa !24
  %t179 = load i64, ptr %l10, !tbaa !24
  %t181 = icmp slt i64 %t179, 0
  br i1 %t181, label %bb58, label %bb59
bb58:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb59:
  br label %bb60
bb60:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/scope:Scoper", ptr %t184, i32 0, i32 1
  %t187 = load i64, ptr %l9, !tbaa !24
  %t190 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t186, i64 %t187)
  store ptr %t190, ptr %l130
  br label %bb61
bb61:
  %t191 = load ptr, ptr %l130, !tbaa !29
  store ptr %t191, ptr %l11, !tbaa !29
  %t192 = load i64, ptr %l2, !tbaa !24
  store i64 %t192, ptr %l131, !tbaa !24
  %t193 = load ptr, ptr %l11, !tbaa !29
  %t195 = getelementptr %"compiler/typed:Body", ptr %t193, i32 0, i32 10
  %t197 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t195)
  store i64 %t197, ptr %l134
  br label %bb62
bb62:
  %t198 = load i64, ptr %l131, !tbaa !24
  %t199 = load i64, ptr %l134, !tbaa !24
  %t200 = icmp slt i64 %t198, %t199
  br i1 %t200, label %bb63, label %bb64
bb63:
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l137, !tbaa !29
  %t203 = load ptr, ptr %l11, !tbaa !29
  %t205 = getelementptr %"compiler/typed:Body", ptr %t203, i32 0, i32 7
  store ptr %t205, ptr %l139, !tbaa !29
  %t206 = load ptr, ptr %l11, !tbaa !29
  %t208 = getelementptr %"compiler/typed:Body", ptr %t206, i32 0, i32 10
  %t209 = load i64, ptr %l2, !tbaa !24
  %t212 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t208, i64 %t209)
  store i32 %t212, ptr %l143
  br label %bb65
bb64:
  store i64 0, ptr %l136, !tbaa !24
  br label %bb68
bb65:
  %t213 = load i32, ptr %l143, !tbaa !23
  %t214 = sext i32 %t213 to i64
  %t215 = load ptr, ptr %l139, !tbaa !29
  %t217 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t215, i64 %t214)
  store %"compiler/typed:Local" %t217, ptr %l145
  br label %bb66
bb66:
  %t218 = getelementptr %"compiler/typed:Local", ptr %l145, i32 0, i32 2
  %t219 = load i32, ptr %t218, !tbaa !23
  %t220 = load ptr, ptr %l137, !tbaa !29
  %t222 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ectorParams(ptr %v0, ptr %t220, i32 %t219)
  store i64 %t222, ptr %l147
  br label %bb67
bb67:
  %t223 = load i64, ptr %l147, !tbaa !24
  store i64 %t223, ptr %l136, !tbaa !24
  br label %bb68
bb68:
  %t224 = load i64, ptr %l136, !tbaa !24
  store i64 %t224, ptr %l12, !tbaa !24
  %t225 = load i64, ptr %l12, !tbaa !24
  %t227 = icmp eq i64 %t225, 0
  br i1 %t227, label %bb69, label %bb70
bb69:
  store i1 true, ptr %l150, !tbaa !21
  br label %bb73
bb70:
  %t229 = load i64, ptr %l10, !tbaa !24
  %t230 = load i64, ptr %l12, !tbaa !24
  %t233 = add i64 %t229, %t230
  store i64 %t233, ptr %l153, !tbaa !24
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"compiler/scope:Scoper", ptr %t234, i32 0, i32 6
  %t237 = load i64, ptr %l9, !tbaa !24
  %t240 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fscope_3asummary_26_H3a91daf058bf595e7b112751a30a6bbf(ptr %v0, ptr %v0, ptr %t236, i64 %t237)
  store ptr %t240, ptr %l157
  br label %bb71
bb71:
  %t241 = load ptr, ptr %l157, !tbaa !29
  %t243 = getelementptr %"compiler/scope:summary", ptr %t241, i32 0, i32 13
  %t245 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t243)
  store i64 %t245, ptr %l160
  br label %bb72
bb72:
  %t246 = load i64, ptr %l153, !tbaa !24
  %t247 = load i64, ptr %l160, !tbaa !24
  %t248 = icmp sgt i64 %t246, %t247
  store i1 %t248, ptr %l150, !tbaa !21
  br label %bb73
bb73:
  %t250 = load i1, ptr %l150, !tbaa !21
  br i1 %t250, label %bb74, label %bb75
bb74:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb75:
  br label %bb76
bb76:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr %"compiler/scope:Scoper", ptr %t252, i32 0, i32 42
  %t256 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t254)
  store i64 %t256, ptr %l165
  br label %bb77
bb77:
  %t257 = load i64, ptr %l165, !tbaa !24
  store i64 %t257, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  %t258 = load i64, ptr %l12, !tbaa !24
  store i64 %t258, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t260 = load i64, ptr %l15, !tbaa !24
  %t261 = load i64, ptr %l14, !tbaa !24
  %t264 = icmp sgt i64 %t260, %t261
  br i1 %t264, label %bb78, label %bb79
bb78:
  %t266 = load i64, ptr %l16, !tbaa !24
  %t268 = icmp sgt i64 %t266, 0
  br i1 %t268, label %bb80, label %bb81
bb79:
  store i64 0, ptr %l170, !tbaa !24
  br label %bb83
bb80:
  %t270 = load i64, ptr %l15, !tbaa !24
  %t271 = load i64, ptr %l14, !tbaa !24
  %t274 = sub i64 %t270, %t271
  %t275 = load i64, ptr %l16, !tbaa !24
  %t278 = add i64 %t274, %t275
  %t280 = sub i64 %t278, 1
  %t281 = load i64, ptr %l16, !tbaa !24
  %t284 = sdiv i64 %t280, %t281
  store i64 %t284, ptr %l173, !tbaa !24
  br label %bb82
bb81:
  store i64 0, ptr %l173, !tbaa !24
  br label %bb82
bb82:
  %t286 = load i64, ptr %l173, !tbaa !24
  store i64 %t286, ptr %l170, !tbaa !24
  br label %bb83
bb83:
  %t287 = load i64, ptr %l170, !tbaa !24
  store i64 %t287, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb84
bb84:
  store %olang.scope zeroinitializer, ptr %s10
  %t288 = load i64, ptr %l18, !tbaa !24
  %t289 = load i64, ptr %l17, !tbaa !24
  %t292 = icmp slt i64 %t288, %t289
  %t294 = xor i1 %t292, true
  br i1 %t294, label %bb85, label %bb86
bb85:
  call void @__olang_scope_close(ptr %s10)
  br label %bb153
bb86:
  br label %bb87
bb87:
  %t296 = load i64, ptr %l14, !tbaa !24
  %t297 = load i64, ptr %l18, !tbaa !24
  %t298 = load i64, ptr %l16, !tbaa !24
  %t301 = mul i64 %t297, %t298
  %t304 = add i64 %t296, %t301
  store i64 %t304, ptr %l19, !tbaa !24
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t308 = getelementptr %"compiler/scope:Scoper", ptr %t306, i32 0, i32 6
  %t309 = load i64, ptr %l9, !tbaa !24
  %t312 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fscope_3asummary_26_H3a91daf058bf595e7b112751a30a6bbf(ptr %v0, ptr %v0, ptr %t308, i64 %t309)
  store ptr %t312, ptr %l194
  br label %bb88
bb88:
  %t313 = load ptr, ptr %l194, !tbaa !29
  %t315 = getelementptr %"compiler/scope:summary", ptr %t313, i32 0, i32 13
  %t316 = load i64, ptr %l10, !tbaa !24
  %t317 = load i64, ptr %l19, !tbaa !24
  %t320 = add i64 %t316, %t317
  %t323 = call { i64, [2 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t315, i64 %t320)
  store { i64, [2 x i64] } %t323, ptr %l200
  br label %bb89
bb89:
  %t324 = load { i64, [2 x i64] }, ptr %l200
  store { i64, [2 x i64] } %t324, ptr %l20
  store { i64, [2 x i64] } zeroinitializer, ptr %t325
  %t326 = getelementptr { i64, [2 x i64] }, ptr %t325, i32 0, i32 0
  store i64 6, ptr %t326
  %t327 = load { i64, [2 x i64] }, ptr %t325
  store { i64, [2 x i64] } %t327, ptr %l21
  %t329 = load { i64, [2 x i64] }, ptr %l20
  %t331 = extractvalue { i64, [2 x i64] } %t329, 0
  %t332 = icmp eq i64 %t331, 3
  br i1 %t332, label %bb90, label %bb91
bb90:
  br label %bb92
bb91:
  br label %bb93
bb92:
  store { i64, [2 x i64] } zeroinitializer, ptr %t334
  %t335 = getelementptr { i64, [2 x i64] }, ptr %t334, i32 0, i32 0
  store i64 3, ptr %t335
  %t336 = load { i64, [2 x i64] }, ptr %t334
  store { i64, [2 x i64] } %t336, ptr %l21
  br label %bb149
bb93:
  %t338 = load { i64, [2 x i64] }, ptr %l20
  %t340 = extractvalue { i64, [2 x i64] } %t338, 0
  %t341 = icmp eq i64 %t340, 2
  br i1 %t341, label %bb94, label %bb95
bb94:
  %t343 = getelementptr { i64, [2 x i64] }, ptr %l20, i32 0, i32 1
  %t344 = getelementptr { i64 }, ptr %t343, i32 0, i32 0
  %t345 = load i64, ptr %t344
  store i64 %t345, ptr %l22, !tbaa !24
  br label %bb96
bb95:
  br label %bb144
bb96:
  %t347 = load i64, ptr %l22, !tbaa !24
  store i64 %t347, ptr %l208, !tbaa !24
  %t348 = load ptr, ptr %l11, !tbaa !29
  %t350 = getelementptr %"compiler/typed:Body", ptr %t348, i32 0, i32 6
  %t352 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2eLe_H729d11b3a9b9a6787781d29df4918101(ptr %v0, ptr %t350)
  store i64 %t352, ptr %l211
  br label %bb97
bb97:
  %t353 = load i64, ptr %l208, !tbaa !24
  %t354 = load i64, ptr %l211, !tbaa !24
  %t355 = icmp slt i64 %t353, %t354
  br i1 %t355, label %bb98, label %bb99
bb98:
  %t357 = load ptr, ptr %l11, !tbaa !29
  %t359 = getelementptr %"compiler/typed:Body", ptr %t357, i32 0, i32 6
  %t360 = load i64, ptr %l22, !tbaa !24
  %t363 = call { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_H9c4972d30d76581e4f8a183d5194d431(ptr %v0, ptr %t359, i64 %t360)
  store { i64, [1 x i64] } %t363, ptr %l216
  br label %bb100
bb99:
  br label %bb143
bb100:
  %t364 = load { i64, [1 x i64] }, ptr %l216
  store { i64, [1 x i64] } %t364, ptr %l23
  %t365 = load { i64, [1 x i64] }, ptr %l23
  %t367 = extractvalue { i64, [1 x i64] } %t365, 0
  %t368 = icmp eq i64 %t367, 2
  br i1 %t368, label %bb101, label %bb102
bb101:
  br label %bb103
bb102:
  br label %bb105
bb103:
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t371 = load ptr, ptr %l1, !tbaa !29
  %t374 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekPlace(ptr %v0, ptr %v1, ptr %t370, ptr %t371, i1 true)
  store { i64, [2 x i64] } %t374, ptr %l221
  br label %bb104
bb104:
  %t375 = load { i64, [2 x i64] }, ptr %l221
  store { i64, [2 x i64] } %t375, ptr %l21
  br label %bb142
bb105:
  %t376 = load { i64, [1 x i64] }, ptr %l23
  %t378 = extractvalue { i64, [1 x i64] } %t376, 0
  %t379 = icmp eq i64 %t378, 0
  br i1 %t379, label %bb106, label %bb107
bb106:
  %t381 = getelementptr { i64, [1 x i64] }, ptr %l23, i32 0, i32 1
  %t382 = getelementptr { i32 }, ptr %t381, i32 0, i32 0
  %t383 = load i32, ptr %t382
  store i32 %t383, ptr %l24, !tbaa !23
  br label %bb108
bb107:
  br label %bb137
bb108:
  store i64 -1, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  %t385 = load ptr, ptr %l11, !tbaa !29
  %t387 = getelementptr %"compiler/typed:Body", ptr %t385, i32 0, i32 5
  %t389 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t387)
  store i64 %t389, ptr %l227
  br label %bb109
bb109:
  %t390 = load i64, ptr %l227, !tbaa !24
  store i64 %t390, ptr %l27, !tbaa !24
  store i64 1, ptr %l28, !tbaa !24
  %t391 = load i64, ptr %l27, !tbaa !24
  %t392 = load i64, ptr %l26, !tbaa !24
  %t395 = icmp sgt i64 %t391, %t392
  br i1 %t395, label %bb110, label %bb111
bb110:
  %t397 = load i64, ptr %l28, !tbaa !24
  %t399 = icmp sgt i64 %t397, 0
  br i1 %t399, label %bb112, label %bb113
bb111:
  store i64 0, ptr %l231, !tbaa !24
  br label %bb115
bb112:
  %t401 = load i64, ptr %l27, !tbaa !24
  %t402 = load i64, ptr %l26, !tbaa !24
  %t405 = sub i64 %t401, %t402
  %t406 = load i64, ptr %l28, !tbaa !24
  %t409 = add i64 %t405, %t406
  %t411 = sub i64 %t409, 1
  %t412 = load i64, ptr %l28, !tbaa !24
  %t415 = sdiv i64 %t411, %t412
  store i64 %t415, ptr %l234, !tbaa !24
  br label %bb114
bb113:
  store i64 0, ptr %l234, !tbaa !24
  br label %bb114
bb114:
  %t417 = load i64, ptr %l234, !tbaa !24
  store i64 %t417, ptr %l231, !tbaa !24
  br label %bb115
bb115:
  %t418 = load i64, ptr %l231, !tbaa !24
  store i64 %t418, ptr %l29, !tbaa !24
  store i64 0, ptr %l30, !tbaa !24
  br label %bb116
bb116:
  store %olang.scope zeroinitializer, ptr %s17
  %t419 = load i64, ptr %l30, !tbaa !24
  %t420 = load i64, ptr %l29, !tbaa !24
  %t423 = icmp slt i64 %t419, %t420
  %t425 = xor i1 %t423, true
  br i1 %t425, label %bb117, label %bb118
bb117:
  call void @__olang_scope_close(ptr %s17)
  br label %bb125
bb118:
  br label %bb119
bb119:
  %t427 = load i64, ptr %l26, !tbaa !24
  %t428 = load i64, ptr %l30, !tbaa !24
  %t429 = load i64, ptr %l28, !tbaa !24
  %t432 = mul i64 %t428, %t429
  %t435 = add i64 %t427, %t432
  store i64 %t435, ptr %l31, !tbaa !24
  %t437 = load ptr, ptr %l11, !tbaa !29
  %t439 = getelementptr %"compiler/typed:Body", ptr %t437, i32 0, i32 5
  %t440 = load i64, ptr %l31, !tbaa !24
  %t443 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t439, i64 %t440)
  store i32 %t443, ptr %l255
  br label %bb120
bb120:
  %t444 = load i32, ptr %l24, !tbaa !23
  %t445 = load i32, ptr %l255, !tbaa !23
  %t447 = icmp eq i32 %t445, %t444
  br i1 %t447, label %bb121, label %bb122
bb121:
  %t449 = load i64, ptr %l31, !tbaa !24
  store i64 %t449, ptr %l25, !tbaa !24
  br label %bb123
bb122:
  br label %bb123
bb123:
  call void @__olang_scope_close(ptr %s17)
  br label %bb124
bb124:
  %t451 = load i64, ptr %l30, !tbaa !24
  %t453 = add i64 %t451, 1
  store i64 %t453, ptr %l30, !tbaa !24
  br label %bb116
bb125:
  %t455 = load i64, ptr %l5, !tbaa !24
  %t457 = icmp sge i64 %t455, 0
  br i1 %t457, label %bb126, label %bb127
bb126:
  %t459 = load i64, ptr %l25, !tbaa !24
  %t461 = icmp sge i64 %t459, 0
  store i1 %t461, ptr %l263, !tbaa !21
  br label %bb128
bb127:
  store i1 false, ptr %l263, !tbaa !21
  br label %bb128
bb128:
  %t463 = load i1, ptr %l263, !tbaa !21
  br i1 %t463, label %bb129, label %bb130
bb129:
  %t464 = load i64, ptr %l5, !tbaa !24
  %t465 = load i64, ptr %l25, !tbaa !24
  %t468 = add i64 %t464, %t465
  store i64 %t468, ptr %l269, !tbaa !24
  %t469 = load ptr, ptr %l0, !tbaa !29
  %t471 = getelementptr %"compiler/scope:Scoper", ptr %t469, i32 0, i32 42
  %t473 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t471)
  store i64 %t473, ptr %l272
  br label %bb131
bb130:
  store i1 false, ptr %l266, !tbaa !21
  br label %bb132
bb131:
  %t474 = load i64, ptr %l269, !tbaa !24
  %t475 = load i64, ptr %l272, !tbaa !24
  %t476 = icmp slt i64 %t474, %t475
  store i1 %t476, ptr %l266, !tbaa !21
  br label %bb132
bb132:
  %t478 = load i1, ptr %l266, !tbaa !21
  br i1 %t478, label %bb133, label %bb134
bb133:
  %t479 = load ptr, ptr %l0, !tbaa !29
  %t481 = getelementptr %"compiler/scope:Scoper", ptr %t479, i32 0, i32 42
  %t482 = load i64, ptr %l5, !tbaa !24
  %t483 = load i64, ptr %l25, !tbaa !24
  %t486 = add i64 %t482, %t483
  %t489 = call { i64, [2 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t481, i64 %t486)
  store { i64, [2 x i64] } %t489, ptr %l279
  br label %bb135
bb134:
  br label %bb136
bb135:
  %t490 = load { i64, [2 x i64] }, ptr %l279
  store { i64, [2 x i64] } %t490, ptr %l21
  br label %bb136
bb136:
  br label %bb142
bb137:
  br i1 true, label %bb138, label %bb139
bb138:
  br label %bb140
bb139:
  br label %bb141
bb140:
  br label %bb142
bb141:
  call void @__olang_check_failed(ptr @olang_loc_1acba385e9948a9d_2fa01f36b12cdd39)
  unreachable
bb142:
  br label %bb143
bb143:
  br label %bb149
bb144:
  br i1 true, label %bb145, label %bb146
bb145:
  br label %bb147
bb146:
  br label %bb148
bb147:
  br label %bb149
bb148:
  call void @__olang_check_failed(ptr @olang_loc_c629952a85fc4586_8463807efabcbcc2)
  unreachable
bb149:
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t493 = getelementptr %"compiler/scope:Scoper", ptr %t491, i32 0, i32 42
  %t494 = load { i64, [2 x i64] }, ptr %l21
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3aTerm_3e_2ePush_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t493, { i64, [2 x i64] } %t494)
  br label %bb150
bb150:
  %t497 = load ptr, ptr %l0, !tbaa !29
  %t499 = getelementptr %"compiler/scope:Scoper", ptr %t497, i32 0, i32 43
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t499, i64 -1)
  br label %bb151
bb151:
  call void @__olang_scope_close(ptr %s10)
  br label %bb152
bb152:
  %t501 = load i64, ptr %l18, !tbaa !24
  %t503 = add i64 %t501, 1
  store i64 %t503, ptr %l18, !tbaa !24
  br label %bb84
bb153:
  %t505 = load i64, ptr %l13, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t505, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efieldTerm(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l10 = alloca i32
  %l13 = alloca i1
  %l17 = alloca { i64, [2 x i64] }
  %l24 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca i1
  %l32 = alloca i64
  %l35 = alloca i1
  %l44 = alloca %"compiler/typed:Local"
  %l49 = alloca i64
  %l52 = alloca ptr
  %l55 = alloca i64
  %l57 = alloca { i64, [2 x i64] }
  %l61 = alloca ptr
  %l64 = alloca i64
  %l66 = alloca { i64, [2 x i64] }
  %l68 = alloca ptr
  %l71 = alloca { i64, [2 x i64] }
  %l73 = alloca ptr
  %l75 = alloca i1
  %l78 = alloca i64
  %l84 = alloca { i64, [2 x i64] }
  %rv = alloca { i64, [2 x i64] }
  %t90 = alloca { i64, [2 x i64] }, align 8
  %t155 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t1)
  store i32 %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load i32, ptr %l10, !tbaa !23
  store i32 %t4, ptr %l3, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l3, !tbaa !23
  %t9 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisStruct(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l13
  br label %bb2
bb2:
  %t10 = load i1, ptr %l13, !tbaa !21
  br i1 %t10, label %bb3, label %bb4
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l3, !tbaa !23
  %t17 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efieldMark(ptr %v0, ptr %t11, i32 %t12, i64 %a2)
  store { i64, [2 x i64] } %t17, ptr %l17
  br label %bb5
bb4:
  br label %bb51
bb5:
  %t18 = load { i64, [2 x i64] }, ptr %l17
  store { i64, [2 x i64] } %t18, ptr %l4
  %t19 = load { i64, [2 x i64] }, ptr %l4
  %t21 = extractvalue { i64, [2 x i64] } %t19, 0
  %t22 = icmp eq i64 %t21, 2
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t25 = getelementptr { i32 }, ptr %t24, i32 0, i32 0
  %t26 = load i32, ptr %t25
  store i32 %t26, ptr %l5, !tbaa !23
  br label %bb8
bb7:
  br label %bb45
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l3, !tbaa !23
  %t30 = load i32, ptr %l5, !tbaa !23
  %t34 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ectorParamIndex(ptr %v0, ptr %t28, i32 %t29, i32 %t30)
  store i64 %t34, ptr %l24
  br label %bb9
bb9:
  %t35 = load i64, ptr %l24, !tbaa !24
  store i64 %t35, ptr %l6, !tbaa !24
  %t36 = load ptr, ptr %l1, !tbaa !29
  store ptr %t36, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t37 = load ptr, ptr %l25, !tbaa !29
  %t38 = icmp ne ptr %t37, null
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t40 = load ptr, ptr %l25, !tbaa !29
  %t41 = load i64, ptr %t40
  %t43 = icmp eq i64 %t41, 2
  store i1 %t43, ptr %l26, !tbaa !21
  br label %bb11
bb11:
  %t44 = load i1, ptr %l26, !tbaa !21
  br i1 %t44, label %bb12, label %bb13
bb12:
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr { i64, [4 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t47, i32 0, i32 2
  %t49 = load ptr, ptr %t48
  store ptr %t49, ptr %l7, !tbaa !29
  br label %bb14
bb13:
  br label %bb27
bb14:
  %t51 = load ptr, ptr %l7, !tbaa !29
  %t53 = call i64 @compiler_2fscope_2eregionLocal(ptr %v1, ptr %t51)
  store i64 %t53, ptr %l32
  br label %bb15
bb15:
  %t54 = load i64, ptr %l32, !tbaa !24
  store i64 %t54, ptr %l8, !tbaa !24
  %t55 = load i64, ptr %l8, !tbaa !24
  %t57 = icmp sge i64 %t55, 0
  br i1 %t57, label %bb16, label %bb17
bb16:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/scope:Scoper", ptr %t59, i32 0, i32 25
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = icmp eq ptr %t62, null
  br i1 %t64, label %bb18, label %bb19
bb17:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb22
bb18:
  call void @__olang_check_failed(ptr @olang_loc_fb66d6a098581c09_2fd4002f8136e06d)
  unreachable
bb19:
  br label %bb20
bb20:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/scope:Scoper", ptr %t66, i32 0, i32 25
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Body", ptr %t69, i32 0, i32 7
  %t73 = load i64, ptr %l8, !tbaa !24
  %t76 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t72, i64 %t73)
  store %"compiler/typed:Local" %t76, ptr %l44
  br label %bb21
bb21:
  %t77 = getelementptr %"compiler/typed:Local", ptr %l44, i32 0, i32 4
  %t78 = load i32, ptr %t77
  %t80 = trunc i64 0 to i32
  %t81 = icmp eq i32 %t78, %t80
  store i1 %t81, ptr %l35, !tbaa !21
  br label %bb22
bb22:
  %t83 = load i1, ptr %l35, !tbaa !21
  br i1 %t83, label %bb23, label %bb24
bb23:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i64, ptr %l8, !tbaa !24
  %t88 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparamIndex(ptr %v0, ptr %t84, i64 %t85)
  store i64 %t88, ptr %l49
  br label %bb25
bb24:
  br label %bb26
bb25:
  %t89 = load i64, ptr %l6, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t90
  %t91 = getelementptr { i64, [2 x i64] }, ptr %t90, i32 0, i32 0
  store i64 4, ptr %t91
  %t92 = load i64, ptr %l49, !tbaa !24
  %t93 = insertvalue { i64, i64 } undef, i64 %t92, 0
  %t95 = insertvalue { i64, i64 } %t93, i64 %t89, 1
  %t96 = getelementptr { i64, [2 x i64] }, ptr %t90, i32 0, i32 1
  store { i64, i64 } %t95, ptr %t96
  %t97 = load { i64, [2 x i64] }, ptr %t90
  store { i64, [2 x i64] } %t97, ptr %rv
  br label %ret
bb26:
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_cd1d16db8329fc51_df7e5714e2c1cec5)
  unreachable
bb32:
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l52, !tbaa !29
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t104 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erecOf(ptr %v0, ptr %v1, ptr %t100, ptr %t101)
  store i64 %t104, ptr %l55
  br label %bb33
bb33:
  %t105 = load i64, ptr %l6, !tbaa !24
  %t106 = load ptr, ptr %l52, !tbaa !29
  %t107 = load i64, ptr %l55, !tbaa !24
  %t109 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erecAt(ptr %v0, ptr %t106, i64 %t107, i64 %t105)
  store { i64, [2 x i64] } %t109, ptr %l57
  br label %bb34
bb34:
  %t110 = load { i64, [2 x i64] }, ptr %l57
  %t112 = extractvalue { i64, [2 x i64] } %t110, 0
  %t113 = icmp eq i64 %t112, 0
  %t115 = xor i1 %t113, true
  br i1 %t115, label %bb35, label %bb36
bb35:
  %t117 = load ptr, ptr %l0, !tbaa !29
  store ptr %t117, ptr %l61, !tbaa !29
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load ptr, ptr %l1, !tbaa !29
  %t122 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erecOf(ptr %v0, ptr %v1, ptr %t118, ptr %t119)
  store i64 %t122, ptr %l64
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t123 = load i64, ptr %l6, !tbaa !24
  %t124 = load ptr, ptr %l61, !tbaa !29
  %t125 = load i64, ptr %l64, !tbaa !24
  %t127 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erecAt(ptr %v0, ptr %t124, i64 %t125, i64 %t123)
  store { i64, [2 x i64] } %t127, ptr %l66
  br label %bb38
bb38:
  %t128 = load { i64, [2 x i64] }, ptr %l66
  store { i64, [2 x i64] } %t128, ptr %rv
  br label %ret
bb39:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/scope:Scoper", ptr %t129, i32 0, i32 80
  store ptr %t131, ptr %l68, !tbaa !29
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load ptr, ptr %l1, !tbaa !29
  %t136 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartsTerm(ptr %v0, ptr %v1, ptr %t132, ptr %t133)
  store { i64, [2 x i64] } %t136, ptr %l71
  br label %bb40
bb40:
  %t137 = load ptr, ptr %l68, !tbaa !29
  %t138 = load { i64, [2 x i64] }, ptr %l71
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3aTerm_3e_2ePush_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t137, { i64, [2 x i64] } %t138)
  br label %bb41
bb41:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/scope:Scoper", ptr %t139, i32 0, i32 81
  store ptr %t141, ptr %l73, !tbaa !29
  %t142 = load ptr, ptr %l1, !tbaa !29
  %t144 = call i1 @compiler_2fscope_2ethroughElem(ptr %v1, ptr %t142)
  store i1 %t144, ptr %l75
  br label %bb42
bb42:
  %t145 = load ptr, ptr %l73, !tbaa !29
  %t146 = load i1, ptr %l75, !tbaa !21
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t145, i1 %t146)
  br label %bb43
bb43:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/scope:Scoper", ptr %t147, i32 0, i32 80
  %t151 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t149)
  store i64 %t151, ptr %l78
  br label %bb44
bb44:
  %t152 = load i64, ptr %l78, !tbaa !24
  %t153 = sub i64 0, %t152
  %t154 = load i64, ptr %l6, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t155
  %t156 = getelementptr { i64, [2 x i64] }, ptr %t155, i32 0, i32 0
  store i64 4, ptr %t156
  %t158 = insertvalue { i64, i64 } undef, i64 %t153, 0
  %t160 = insertvalue { i64, i64 } %t158, i64 %t154, 1
  %t161 = getelementptr { i64, [2 x i64] }, ptr %t155, i32 0, i32 1
  store { i64, i64 } %t160, ptr %t161
  %t162 = load { i64, [2 x i64] }, ptr %t155
  store { i64, [2 x i64] } %t162, ptr %rv
  br label %ret
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_4a18cd046f6561ba_7ee6763527d0100e)
  unreachable
bb50:
  br label %bb51
bb51:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load ptr, ptr %l1, !tbaa !29
  %t168 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartsTerm(ptr %v0, ptr %v1, ptr %t164, ptr %t165)
  store { i64, [2 x i64] } %t168, ptr %l84
  br label %bb52
bb52:
  %t169 = load { i64, [2 x i64] }, ptr %l84
  store { i64, [2 x i64] } %t169, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efitErrorAt(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca %"compiler/msgs:Msg"
  %l7 = alloca i1
  %l9 = alloca { i64, [2 x i64] }
  %l12 = alloca { i64, [2 x i64] }
  %l14 = alloca i1
  %l15 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l20 = alloca %"compiler/msgs:Msg"
  %l21 = alloca %"compiler/msgs:Msg"
  %l22 = alloca %"compiler/msgs:Msg"
  %l23 = alloca i64
  %l24 = alloca %"compiler/msgs:Msg"
  %l29 = alloca i1
  %l32 = alloca i1
  %l36 = alloca %"compiler/msgs:Msg"
  %l40 = alloca %"compiler/msgs:Msg"
  %l44 = alloca %"compiler/msgs:Msg"
  %l48 = alloca %"compiler/msgs:Msg"
  %l53 = alloca %"compiler/msgs:Msg"
  %l54 = alloca %"compiler/msgs:Msg"
  %l55 = alloca %"compiler/msgs:Msg"
  %l59 = alloca %"compiler/msgs:Msg"
  %l63 = alloca %"compiler/msgs:Msg"
  %l67 = alloca %"compiler/msgs:Msg"
  %l71 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 67
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/scope:Scoper", ptr %t6, i32 0, i32 71
  %t9 = load { i64, [2 x i64] }, ptr %t8
  store { i64, [2 x i64] } %t9, ptr %l9
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/scope:Scoper", ptr %t10, i32 0, i32 69
  %t13 = load { i64, [2 x i64] }, ptr %t12
  store { i64, [2 x i64] } %t13, ptr %l12
  %t16 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l9, ptr %l12)
  store i1 %t16, ptr %l14
  br label %bb3
bb2:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb4
bb3:
  %t17 = load i1, ptr %l14, !tbaa !21
  store i1 %t17, ptr %l7, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l7, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l15, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/scope:Scoper", ptr %t20, i32 0, i32 68
  %t23 = load %"compiler/source:Span", ptr %t22
  store %"compiler/source:Span" %t23, ptr %l17
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/scope:Scoper", ptr %t24, i32 0, i32 70
  %t27 = load i1, ptr %t26, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb6:
  br label %bb13
bb7:
  %t29 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnFuncTooShort(ptr %s1)
  store %"compiler/msgs:Msg" %t29, ptr %l21
  br label %bb9
bb8:
  %t30 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnArgHoldsShort(ptr %s1)
  store %"compiler/msgs:Msg" %t30, ptr %l22
  br label %bb10
bb9:
  %t31 = load %"compiler/msgs:Msg", ptr %l21
  store %"compiler/msgs:Msg" %t31, ptr %l20
  br label %bb11
bb10:
  %t32 = load %"compiler/msgs:Msg", ptr %l22
  store %"compiler/msgs:Msg" %t32, ptr %l20
  br label %bb11
bb11:
  %t33 = load ptr, ptr %l15, !tbaa !29
  %t34 = load %"compiler/source:Span", ptr %l17
  %t35 = load %"compiler/msgs:Msg", ptr %l20
  %t36 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s1, ptr %t33, %"compiler/source:Span" %t34, %"compiler/msgs:Msg" %t35)
  store i64 %t36, ptr %l23
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t37 = load i64, ptr %l23, !tbaa !24
  store i64 %t37, ptr %rv
  br label %ret
bb13:
  %t38 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeMayNotOutlive(ptr %s0)
  store %"compiler/msgs:Msg" %t38, ptr %l24
  br label %bb14
bb14:
  %t39 = load %"compiler/msgs:Msg", ptr %l24
  store %"compiler/msgs:Msg" %t39, ptr %l4
  %t40 = load i64, ptr %l2, !tbaa !24
  %t41 = load i64, ptr @G_2ecompiler_2fscope_2eFitLocal, !tbaa !24
  %t44 = icmp eq i64 %t40, %t41
  br i1 %t44, label %bb15, label %bb16
bb15:
  %t46 = load i1, ptr %l3, !tbaa !21
  br i1 %t46, label %bb17, label %bb18
bb16:
  %t48 = load i64, ptr %l2, !tbaa !24
  %t49 = load i64, ptr @G_2ecompiler_2fscope_2eFitPayload, !tbaa !24
  %t52 = icmp eq i64 %t48, %t49
  br i1 %t52, label %bb27, label %bb28
bb17:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/scope:Scoper", ptr %t54, i32 0, i32 72
  %t57 = load i1, ptr %t56, !tbaa !21
  br i1 %t57, label %bb19, label %bb20
bb18:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb22
bb19:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb21
bb20:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/scope:Scoper", ptr %t59, i32 0, i32 73
  %t62 = load i1, ptr %t61, !tbaa !21
  %t64 = xor i1 %t62, true
  store i1 %t64, ptr %l32, !tbaa !21
  br label %bb21
bb21:
  %t66 = load i1, ptr %l32, !tbaa !21
  store i1 %t66, ptr %l29, !tbaa !21
  br label %bb22
bb22:
  %t67 = load i1, ptr %l29, !tbaa !21
  br i1 %t67, label %bb23, label %bb24
bb23:
  %t68 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReferenceNarrowed(ptr %s0)
  store %"compiler/msgs:Msg" %t68, ptr %l36
  br label %bb25
bb24:
  br label %bb26
bb25:
  %t69 = load %"compiler/msgs:Msg", ptr %l36
  store %"compiler/msgs:Msg" %t69, ptr %l4
  br label %bb26
bb26:
  br label %bb59
bb27:
  %t70 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2ePayloadOutlived(ptr %s0)
  store %"compiler/msgs:Msg" %t70, ptr %l40
  br label %bb29
bb28:
  %t71 = load i64, ptr %l2, !tbaa !24
  %t72 = load i64, ptr @G_2ecompiler_2fscope_2eFitOwn, !tbaa !24
  %t75 = icmp eq i64 %t71, %t72
  br i1 %t75, label %bb30, label %bb31
bb29:
  %t77 = load %"compiler/msgs:Msg", ptr %l40
  store %"compiler/msgs:Msg" %t77, ptr %l4
  br label %bb58
bb30:
  %t78 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOwnCannotOutlive(ptr %s0)
  store %"compiler/msgs:Msg" %t78, ptr %l44
  br label %bb32
bb31:
  %t79 = load i64, ptr %l2, !tbaa !24
  %t80 = load i64, ptr @G_2ecompiler_2fscope_2eFitField, !tbaa !24
  %t83 = icmp eq i64 %t79, %t80
  br i1 %t83, label %bb33, label %bb34
bb32:
  %t85 = load %"compiler/msgs:Msg", ptr %l44
  store %"compiler/msgs:Msg" %t85, ptr %l4
  br label %bb57
bb33:
  %t86 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eStoredRefOutlived(ptr %s0)
  store %"compiler/msgs:Msg" %t86, ptr %l48
  br label %bb35
bb34:
  %t87 = load i64, ptr %l2, !tbaa !24
  %t88 = load i64, ptr @G_2ecompiler_2fscope_2eFitElem, !tbaa !24
  %t91 = icmp eq i64 %t87, %t88
  br i1 %t91, label %bb36, label %bb37
bb35:
  %t93 = load %"compiler/msgs:Msg", ptr %l48
  store %"compiler/msgs:Msg" %t93, ptr %l4
  br label %bb56
bb36:
  %t94 = load i1, ptr %l3, !tbaa !21
  br i1 %t94, label %bb38, label %bb39
bb37:
  %t96 = load i64, ptr %l2, !tbaa !24
  %t97 = load i64, ptr @G_2ecompiler_2fscope_2eFitGlobal, !tbaa !24
  %t100 = icmp eq i64 %t96, %t97
  br i1 %t100, label %bb43, label %bb44
bb38:
  %t102 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eElemNotInArrayScope(ptr %s0)
  store %"compiler/msgs:Msg" %t102, ptr %l54
  br label %bb40
bb39:
  %t103 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eElemOutlived(ptr %s0)
  store %"compiler/msgs:Msg" %t103, ptr %l55
  br label %bb41
bb40:
  %t104 = load %"compiler/msgs:Msg", ptr %l54
  store %"compiler/msgs:Msg" %t104, ptr %l53
  br label %bb42
bb41:
  %t105 = load %"compiler/msgs:Msg", ptr %l55
  store %"compiler/msgs:Msg" %t105, ptr %l53
  br label %bb42
bb42:
  %t106 = load %"compiler/msgs:Msg", ptr %l53
  store %"compiler/msgs:Msg" %t106, ptr %l4
  br label %bb55
bb43:
  %t107 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eGlobalHoldsShorter(ptr %s0)
  store %"compiler/msgs:Msg" %t107, ptr %l59
  br label %bb45
bb44:
  %t108 = load i64, ptr %l2, !tbaa !24
  %t109 = load i64, ptr @G_2ecompiler_2fscope_2eFitReturn, !tbaa !24
  %t112 = icmp eq i64 %t108, %t109
  br i1 %t112, label %bb46, label %bb47
bb45:
  %t114 = load %"compiler/msgs:Msg", ptr %l59
  store %"compiler/msgs:Msg" %t114, ptr %l4
  br label %bb54
bb46:
  %t115 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnOwnStorage(ptr %s0)
  store %"compiler/msgs:Msg" %t115, ptr %l63
  br label %bb48
bb47:
  %t116 = load i64, ptr %l2, !tbaa !24
  %t117 = load i64, ptr @G_2ecompiler_2fscope_2eFitValue, !tbaa !24
  %t120 = icmp eq i64 %t116, %t117
  br i1 %t120, label %bb49, label %bb50
bb48:
  %t122 = load %"compiler/msgs:Msg", ptr %l63
  store %"compiler/msgs:Msg" %t122, ptr %l4
  br label %bb53
bb49:
  %t123 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eValueRefsOutlived(ptr %s0)
  store %"compiler/msgs:Msg" %t123, ptr %l67
  br label %bb51
bb50:
  br label %bb52
bb51:
  %t124 = load %"compiler/msgs:Msg", ptr %l67
  store %"compiler/msgs:Msg" %t124, ptr %l4
  br label %bb52
bb52:
  br label %bb53
bb53:
  br label %bb54
bb54:
  br label %bb55
bb55:
  br label %bb56
bb56:
  br label %bb57
bb57:
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = load %"compiler/msgs:Msg", ptr %l4
  %t131 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s0, ptr %t125, %"compiler/source:Span" %a1, %"compiler/msgs:Msg" %t127)
  store i64 %t131, ptr %l71
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s0)
  %t132 = load i64, ptr %l71, !tbaa !24
  store i64 %t132, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflBlockOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l16 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflStmt(ptr %v0, ptr %v1, ptr %a0, ptr %t28)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb9
bb9:
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb4
bb10:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l40 = alloca i1
  %l43 = alloca { i64, ptr }
  %l46 = alloca i64
  %l49 = alloca i1
  %l53 = alloca i1
  %l59 = alloca i64
  %l62 = alloca i64
  %l83 = alloca i1
  %l84 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l87 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l97 = alloca i32
  %l106 = alloca { i64, ptr }
  %l122 = alloca i64
  %l125 = alloca i64
  %l146 = alloca i1
  %l148 = alloca i1
  %l151 = alloca { i64, ptr }
  %l154 = alloca i1
  %l160 = alloca i64
  %l163 = alloca i64
  %l185 = alloca { i64, ptr }
  %l189 = alloca i64
  %l194 = alloca i1
  %l195 = alloca i1
  %l197 = alloca { i64, ptr }
  %l201 = alloca i1
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  store i64 %t6, ptr %l2, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t10 = icmp eq i64 %t8, 0
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/scope:Scoper", ptr %t12, i32 0, i32 104
  %t15 = load i64, ptr %t14, !tbaa !24
  %t17 = icmp eq i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t23 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisMethodCall(ptr %v0, ptr %v1, ptr %t19, ptr %t20)
  store i1 %t23, ptr %l40
  br label %bb6
bb5:
  br label %bb52
bb6:
  %t24 = load i1, ptr %l40, !tbaa !21
  %t25 = xor i1 %t24, true
  br i1 %t25, label %bb7, label %bb8
bb7:
  br label %ret
bb8:
  br label %bb9
bb9:
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Call", ptr %t27, i32 0, i32 1
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  store { i64, ptr } %t30, ptr %l43, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr ptr, ptr %t32, i64 0
  %t34 = load ptr, ptr %t33, !tbaa !39
  %t37 = call i64 @compiler_2fscope_2eflRootExpr(ptr %v1, ptr %t34)
  store i64 %t37, ptr %l46
  br label %bb10
bb10:
  %t38 = load i64, ptr %l46, !tbaa !24
  store i64 %t38, ptr %l3, !tbaa !24
  %t39 = load i64, ptr %l3, !tbaa !24
  %t41 = icmp slt i64 %t39, 0
  br i1 %t41, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb14
bb12:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/scope:Scoper", ptr %t43, i32 0, i32 101
  %t46 = load i64, ptr %l3, !tbaa !24
  %t49 = call i1 @compiler_2fscope_2eflHas(ptr %v0, ptr %t45, i64 %t46)
  store i1 %t49, ptr %l53
  br label %bb13
bb13:
  %t50 = load i1, ptr %l53, !tbaa !21
  %t51 = xor i1 %t50, true
  store i1 %t51, ptr %l49, !tbaa !21
  br label %bb14
bb14:
  %t53 = load i1, ptr %l49, !tbaa !21
  br i1 %t53, label %bb15, label %bb16
bb15:
  br label %ret
bb16:
  br label %bb17
bb17:
  store i64 1, ptr %l4, !tbaa !24
  %t54 = load i64, ptr %l2, !tbaa !24
  store i64 %t54, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t56 = load i64, ptr %l5, !tbaa !24
  %t57 = load i64, ptr %l4, !tbaa !24
  %t60 = icmp sgt i64 %t56, %t57
  br i1 %t60, label %bb18, label %bb19
bb18:
  %t62 = load i64, ptr %l6, !tbaa !24
  %t64 = icmp sgt i64 %t62, 0
  br i1 %t64, label %bb20, label %bb21
bb19:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb23
bb20:
  %t66 = load i64, ptr %l5, !tbaa !24
  %t67 = load i64, ptr %l4, !tbaa !24
  %t70 = sub i64 %t66, %t67
  %t71 = load i64, ptr %l6, !tbaa !24
  %t74 = add i64 %t70, %t71
  %t76 = sub i64 %t74, 1
  %t77 = load i64, ptr %l6, !tbaa !24
  %t80 = sdiv i64 %t76, %t77
  store i64 %t80, ptr %l62, !tbaa !24
  br label %bb22
bb21:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb22
bb22:
  %t82 = load i64, ptr %l62, !tbaa !24
  store i64 %t82, ptr %l59, !tbaa !24
  br label %bb23
bb23:
  %t83 = load i64, ptr %l59, !tbaa !24
  store i64 %t83, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s6
  %t84 = load i64, ptr %l8, !tbaa !24
  %t85 = load i64, ptr %l7, !tbaa !24
  %t88 = icmp slt i64 %t84, %t85
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s6)
  br label %bb51
bb26:
  br label %bb27
bb27:
  %t92 = load i64, ptr %l4, !tbaa !24
  %t93 = load i64, ptr %l8, !tbaa !24
  %t94 = load i64, ptr %l6, !tbaa !24
  %t97 = mul i64 %t93, %t94
  %t100 = add i64 %t92, %t97
  store i64 %t100, ptr %l9, !tbaa !24
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t104 = load i64, ptr %l9, !tbaa !24
  %t108 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecanKeep(ptr %v0, ptr %v1, ptr %t102, ptr %t103, i64 %t104)
  store i1 %t108, ptr %l83
  br label %bb28
bb28:
  %t109 = load i1, ptr %l83, !tbaa !21
  br i1 %t109, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s7
  %t110 = load ptr, ptr @__olang_prog_scope
  %t111 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t110)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t111, ptr %l84
  br label %bb31
bb30:
  br label %bb49
bb31:
  %t112 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l84
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t112, ptr %l10
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = getelementptr %"compiler/typed:Call", ptr %t114, i32 0, i32 1
  %t117 = load { i64, ptr }, ptr %t116, !tbaa !27
  store { i64, ptr } %t117, ptr %l87, !tbaa !27
  %t118 = load i64, ptr %l9, !tbaa !24
  %t120 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr ptr, ptr %t121, i64 %t118
  %t123 = load ptr, ptr %t122, !tbaa !39
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %s7, ptr %t113, ptr %t123, ptr %l10)
  br label %bb32
bb32:
  store ptr %l10, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s9
  %t129 = load ptr, ptr %l11, !tbaa !29
  %t130 = load i64, ptr %l12, !tbaa !24
  %t133 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s7, ptr %t129, i64 %t130)
  %t134 = extractvalue { i32, { i64, ptr } } %t133, 1
  %t135 = extractvalue { i32, { i64, ptr } } %t133, 0
  store i32 %t135, ptr %l97
  %t136 = icmp ne i32 %t135, 0
  br i1 %t136, label %bb35, label %ok.137
ok.137:
  store { i64, ptr } %t134, ptr %l96
  br label %bb34
bb34:
  %t138 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t138, ptr %l93, !tbaa !27
  br label %bb39
bb35:
  %t139 = load i32, ptr %l97, !tbaa !23
  %t140 = ashr i32 %t139, 16
  %t142 = icmp eq i32 %t140, 1
  br i1 %t142, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_af8af1914718e174_e172e38237f6e418)
  unreachable
bb38:
  call void @__olang_scope_close(ptr %s9)
  br label %bb48
bb39:
  %t144 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t144, ptr %l13, !tbaa !27
  %t145 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t145, 0
  store i64 %t147, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s10
  %t149 = load i64, ptr %l15, !tbaa !24
  %t150 = load i64, ptr %l14, !tbaa !24
  %t153 = icmp slt i64 %t149, %t150
  %t155 = xor i1 %t153, true
  br i1 %t155, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s10)
  br label %bb46
bb42:
  br label %bb43
bb43:
  %t157 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t157, ptr %l106, !tbaa !27
  %t158 = load i64, ptr %l15, !tbaa !24
  %t160 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !27
  %t162 = getelementptr i64, ptr %t161, i64 %t158
  %t163 = load i64, ptr %t162, !tbaa !34
  %t165 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflAdd(ptr %v0, ptr %t165, i64 %t163)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s10)
  br label %bb45
bb45:
  %t169 = load i64, ptr %l15, !tbaa !24
  %t171 = add i64 %t169, 1
  store i64 %t171, ptr %l15, !tbaa !24
  br label %bb40
bb46:
  %t173 = load i64, ptr %l12, !tbaa !24
  %t174 = load i64, ptr %l14, !tbaa !24
  %t177 = add i64 %t173, %t174
  store i64 %t177, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb47
bb47:
  br label %bb33
bb48:
  call void @__olang_scope_close(ptr %s7)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s6)
  br label %bb50
bb50:
  %t179 = load i64, ptr %l8, !tbaa !24
  %t181 = add i64 %t179, 1
  store i64 %t181, ptr %l8, !tbaa !24
  br label %bb24
bb51:
  br label %ret
bb52:
  store i64 0, ptr %l17, !tbaa !24
  %t183 = load i64, ptr %l2, !tbaa !24
  store i64 %t183, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t185 = load i64, ptr %l18, !tbaa !24
  %t186 = load i64, ptr %l17, !tbaa !24
  %t189 = icmp sgt i64 %t185, %t186
  br i1 %t189, label %bb53, label %bb54
bb53:
  %t191 = load i64, ptr %l19, !tbaa !24
  %t193 = icmp sgt i64 %t191, 0
  br i1 %t193, label %bb55, label %bb56
bb54:
  store i64 0, ptr %l122, !tbaa !24
  br label %bb58
bb55:
  %t195 = load i64, ptr %l18, !tbaa !24
  %t196 = load i64, ptr %l17, !tbaa !24
  %t199 = sub i64 %t195, %t196
  %t200 = load i64, ptr %l19, !tbaa !24
  %t203 = add i64 %t199, %t200
  %t205 = sub i64 %t203, 1
  %t206 = load i64, ptr %l19, !tbaa !24
  %t209 = sdiv i64 %t205, %t206
  store i64 %t209, ptr %l125, !tbaa !24
  br label %bb57
bb56:
  store i64 0, ptr %l125, !tbaa !24
  br label %bb57
bb57:
  %t211 = load i64, ptr %l125, !tbaa !24
  store i64 %t211, ptr %l122, !tbaa !24
  br label %bb58
bb58:
  %t212 = load i64, ptr %l122, !tbaa !24
  store i64 %t212, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb59
bb59:
  store %olang.scope zeroinitializer, ptr %s14
  %t213 = load i64, ptr %l21, !tbaa !24
  %t214 = load i64, ptr %l20, !tbaa !24
  %t217 = icmp slt i64 %t213, %t214
  %t219 = xor i1 %t217, true
  br i1 %t219, label %bb60, label %bb61
bb60:
  call void @__olang_scope_close(ptr %s14)
  br label %bb100
bb61:
  br label %bb62
bb62:
  %t221 = load i64, ptr %l17, !tbaa !24
  %t222 = load i64, ptr %l21, !tbaa !24
  %t223 = load i64, ptr %l19, !tbaa !24
  %t226 = mul i64 %t222, %t223
  %t229 = add i64 %t221, %t226
  store i64 %t229, ptr %l22, !tbaa !24
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t232 = load ptr, ptr %l1, !tbaa !29
  %t233 = load i64, ptr %l22, !tbaa !24
  %t237 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecanKeep(ptr %v0, ptr %v1, ptr %t231, ptr %t232, i64 %t233)
  store i1 %t237, ptr %l146
  br label %bb63
bb63:
  %t238 = load i1, ptr %l146, !tbaa !21
  %t239 = xor i1 %t238, true
  br i1 %t239, label %bb64, label %bb65
bb64:
  store i1 true, ptr %l148, !tbaa !21
  br label %bb67
bb65:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load ptr, ptr %l1, !tbaa !29
  %t244 = getelementptr %"compiler/typed:Call", ptr %t242, i32 0, i32 1
  %t245 = load { i64, ptr }, ptr %t244, !tbaa !27
  store { i64, ptr } %t245, ptr %l151, !tbaa !27
  %t246 = load i64, ptr %l22, !tbaa !24
  %t248 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !27
  %t250 = getelementptr ptr, ptr %t249, i64 %t246
  %t251 = load ptr, ptr %t250, !tbaa !39
  %t254 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarries(ptr %v0, ptr %v1, ptr %t241, ptr %t251)
  store i1 %t254, ptr %l154
  br label %bb66
bb66:
  %t255 = load i1, ptr %l154, !tbaa !21
  %t256 = xor i1 %t255, true
  store i1 %t256, ptr %l148, !tbaa !21
  br label %bb67
bb67:
  %t258 = load i1, ptr %l148, !tbaa !21
  br i1 %t258, label %bb68, label %bb69
bb68:
  call void @__olang_scope_close(ptr %s14)
  br label %bb99
bb69:
  br label %bb70
bb70:
  store i64 0, ptr %l23, !tbaa !24
  %t259 = load i64, ptr %l2, !tbaa !24
  store i64 %t259, ptr %l24, !tbaa !24
  store i64 1, ptr %l25, !tbaa !24
  %t261 = load i64, ptr %l24, !tbaa !24
  %t262 = load i64, ptr %l23, !tbaa !24
  %t265 = icmp sgt i64 %t261, %t262
  br i1 %t265, label %bb71, label %bb72
bb71:
  %t267 = load i64, ptr %l25, !tbaa !24
  %t269 = icmp sgt i64 %t267, 0
  br i1 %t269, label %bb73, label %bb74
bb72:
  store i64 0, ptr %l160, !tbaa !24
  br label %bb76
bb73:
  %t271 = load i64, ptr %l24, !tbaa !24
  %t272 = load i64, ptr %l23, !tbaa !24
  %t275 = sub i64 %t271, %t272
  %t276 = load i64, ptr %l25, !tbaa !24
  %t279 = add i64 %t275, %t276
  %t281 = sub i64 %t279, 1
  %t282 = load i64, ptr %l25, !tbaa !24
  %t285 = sdiv i64 %t281, %t282
  store i64 %t285, ptr %l163, !tbaa !24
  br label %bb75
bb74:
  store i64 0, ptr %l163, !tbaa !24
  br label %bb75
bb75:
  %t287 = load i64, ptr %l163, !tbaa !24
  store i64 %t287, ptr %l160, !tbaa !24
  br label %bb76
bb76:
  %t288 = load i64, ptr %l160, !tbaa !24
  store i64 %t288, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb77
bb77:
  store %olang.scope zeroinitializer, ptr %s17
  %t289 = load i64, ptr %l27, !tbaa !24
  %t290 = load i64, ptr %l26, !tbaa !24
  %t293 = icmp slt i64 %t289, %t290
  %t295 = xor i1 %t293, true
  br i1 %t295, label %bb78, label %bb79
bb78:
  call void @__olang_scope_close(ptr %s17)
  br label %bb98
bb79:
  br label %bb80
bb80:
  %t297 = load i64, ptr %l23, !tbaa !24
  %t298 = load i64, ptr %l27, !tbaa !24
  %t299 = load i64, ptr %l25, !tbaa !24
  %t302 = mul i64 %t298, %t299
  %t305 = add i64 %t297, %t302
  store i64 %t305, ptr %l28, !tbaa !24
  %t307 = load i64, ptr %l28, !tbaa !24
  %t308 = load i64, ptr %l22, !tbaa !24
  %t311 = icmp eq i64 %t307, %t308
  br i1 %t311, label %bb81, label %bb82
bb81:
  call void @__olang_scope_close(ptr %s17)
  br label %bb97
bb82:
  br label %bb83
bb83:
  %t313 = load ptr, ptr %l1, !tbaa !29
  %t315 = getelementptr %"compiler/typed:Call", ptr %t313, i32 0, i32 1
  %t316 = load { i64, ptr }, ptr %t315, !tbaa !27
  store { i64, ptr } %t316, ptr %l185, !tbaa !27
  %t317 = load i64, ptr %l28, !tbaa !24
  %t319 = getelementptr { i64, ptr }, ptr %l185, i32 0, i32 1
  %t320 = load ptr, ptr %t319, !tbaa !27
  %t321 = getelementptr ptr, ptr %t320, i64 %t317
  %t322 = load ptr, ptr %t321, !tbaa !39
  %t325 = call i64 @compiler_2fscope_2eflRootExpr(ptr %v1, ptr %t322)
  store i64 %t325, ptr %l189
  br label %bb84
bb84:
  %t326 = load i64, ptr %l189, !tbaa !24
  store i64 %t326, ptr %l29, !tbaa !24
  %t327 = load i64, ptr %l29, !tbaa !24
  %t329 = icmp slt i64 %t327, 0
  br i1 %t329, label %bb85, label %bb86
bb85:
  call void @__olang_scope_close(ptr %s17)
  br label %bb97
bb86:
  br label %bb87
bb87:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t332 = load i64, ptr %l29, !tbaa !24
  %t335 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eoutside(ptr %v0, ptr %t331, i64 %t332)
  store i1 %t335, ptr %l194
  br label %bb88
bb88:
  %t336 = load i1, ptr %l194, !tbaa !21
  br i1 %t336, label %bb89, label %bb90
bb89:
  store i1 true, ptr %l195, !tbaa !21
  br label %bb92
bb90:
  %t337 = load ptr, ptr %l1, !tbaa !29
  %t339 = getelementptr %"compiler/typed:Call", ptr %t337, i32 0, i32 1
  %t340 = load { i64, ptr }, ptr %t339, !tbaa !27
  store { i64, ptr } %t340, ptr %l197, !tbaa !27
  %t341 = load i64, ptr %l28, !tbaa !24
  %t343 = getelementptr { i64, ptr }, ptr %l197, i32 0, i32 1
  %t344 = load ptr, ptr %t343, !tbaa !27
  %t345 = getelementptr ptr, ptr %t344, i64 %t341
  %t346 = load ptr, ptr %t345, !tbaa !39
  %t349 = call i1 @compiler_2fscope_2eflThroughRefExpr(ptr %v1, ptr %t346)
  store i1 %t349, ptr %l201
  br label %bb91
bb91:
  %t350 = load i1, ptr %l201, !tbaa !21
  store i1 %t350, ptr %l195, !tbaa !21
  br label %bb92
bb92:
  %t351 = load i1, ptr %l195, !tbaa !21
  br i1 %t351, label %bb93, label %bb94
bb93:
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t354 = getelementptr %"compiler/scope:Scoper", ptr %t352, i32 0, i32 103
  store i1 true, ptr %t354, !tbaa !21
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s14)
  br label %ret
bb94:
  br label %bb95
bb95:
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t356 = load i64, ptr %l29, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflAdd(ptr %v0, ptr %t355, i64 %t356)
  br label %bb96
bb96:
  call void @__olang_scope_close(ptr %s17)
  br label %bb97
bb97:
  %t359 = load i64, ptr %l27, !tbaa !24
  %t361 = add i64 %t359, 1
  store i64 %t361, ptr %l27, !tbaa !24
  br label %bb77
bb98:
  call void @__olang_scope_close(ptr %s14)
  br label %bb99
bb99:
  %t363 = load i64, ptr %l21, !tbaa !24
  %t365 = add i64 %t363, 1
  store i64 %t365, ptr %l21, !tbaa !24
  br label %bb59
bb100:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efnValues(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca %"compiler/scope:fnUse"
  %l7 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca { i64, [3 x i64] }
  %l9 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca %"compiler/scope:rel"
  %l21 = alloca { i64, [2 x i64] }
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca %"compiler/scope:rel"
  %l29 = alloca { i64, [2 x i64] }
  %l30 = alloca i64
  %l31 = alloca { i64, [1 x i64] }
  %l32 = alloca i32
  %l35 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca i32
  %l48 = alloca { i64, ptr }
  %l54 = alloca ptr
  %l58 = alloca i64
  %l72 = alloca i1
  %l77 = alloca i32
  %l82 = alloca i32
  %l87 = alloca i32
  %l90 = alloca { i64, ptr }
  %l94 = alloca ptr
  %l97 = alloca ptr
  %l102 = alloca i32
  %l103 = alloca i32
  %l104 = alloca { i64, ptr }
  %l108 = alloca ptr
  %l109 = alloca { i64, [3 x i64] }
  %l111 = alloca %"compiler/msgs:Msg"
  %l112 = alloca i64
  %l116 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l121 = alloca i32
  %l125 = alloca ptr
  %l126 = alloca { i64, [3 x i64] }
  %l132 = alloca { i64, ptr }
  %l133 = alloca { i64, ptr }
  %l135 = alloca i64
  %l137 = alloca i64
  %l138 = alloca i64
  %l143 = alloca %"compiler/msgs:Msg"
  %l144 = alloca i64
  %l145 = alloca { i64, ptr }
  %l146 = alloca { i64, ptr }
  %l147 = alloca i64
  %l148 = alloca { i64, ptr }
  %l152 = alloca ptr
  %l158 = alloca i64
  %l162 = alloca { i64, ptr }
  %l165 = alloca { i64, ptr }
  %l166 = alloca i32
  %l175 = alloca { i64, ptr }
  %l183 = alloca i1
  %l187 = alloca { i64, [1 x i64] }
  %l197 = alloca { i64, ptr }
  %l200 = alloca { i64, ptr }
  %l201 = alloca i32
  %l210 = alloca { i64, ptr }
  %l220 = alloca { i64, [1 x i64] }
  %l225 = alloca i1
  %l229 = alloca ptr
  %l234 = alloca %"compiler/typed:Local"
  %l236 = alloca { i64, ptr }
  %l237 = alloca { i64, ptr }
  %l239 = alloca i64
  %l241 = alloca i64
  %l242 = alloca { i64, ptr }
  %l251 = alloca ptr
  %l252 = alloca { i64, [3 x i64] }
  %l254 = alloca i1
  %l256 = alloca %"compiler/msgs:Msg"
  %l258 = alloca %"compiler/msgs:Msg"
  %l259 = alloca %"compiler/msgs:Msg"
  %l260 = alloca i64
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %t71 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 76
  store ptr %t3, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3afnUse_3e_2eRunFrom_3ccompiler_2fscope_3afnUse_3e(ptr %v0, ptr %t5, i64 %t6)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l39
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13
ok.13:
  store { i64, ptr } %t10, ptr %l38
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t14, ptr %l35, !tbaa !27
  br label %bb7
bb3:
  %t15 = load i32, ptr %l39, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_bd29661a2aabb9c8_be78a85688d9755c)
  unreachable
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb142
bb7:
  %t20 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load i64, ptr %l5, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb140
bb10:
  br label %bb11
bb11:
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t33, ptr %l48, !tbaa !27
  %t34 = load i64, ptr %l5, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr %"compiler/scope:fnUse", ptr %t37, i64 %t34
  %t39 = load %"compiler/scope:fnUse", ptr %t38
  store %"compiler/scope:fnUse" %t39, ptr %l6
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/scope:Scoper", ptr %t41, i32 0, i32 6
  %t44 = getelementptr %"compiler/scope:fnUse", ptr %l6, i32 0, i32 2
  %t45 = load i64, ptr %t44, !tbaa !24
  %t48 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fscope_3asummary_26_H3a91daf058bf595e7b112751a30a6bbf(ptr %v0, ptr %v0, ptr %t43, i64 %t45)
  store ptr %t48, ptr %l54
  br label %bb12
bb12:
  %t49 = load ptr, ptr %l54, !tbaa !29
  %t51 = getelementptr %"compiler/scope:summary", ptr %t49, i32 0, i32 0
  %t52 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t51
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t52, ptr %l7
  %t55 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %l7)
  store i64 %t55, ptr %l58
  br label %bb13
bb13:
  %t56 = load i64, ptr %l58, !tbaa !24
  %t57 = icmp eq i64 %t56, 0
  br i1 %t57, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb139
bb15:
  br label %bb16
bb16:
  %t59 = getelementptr %"compiler/scope:fnUse", ptr %l6, i32 0, i32 0
  %t60 = load i64, ptr %t59, !tbaa !24
  %t61 = getelementptr %"compiler/scope:fnUse", ptr %l6, i32 0, i32 1
  %t62 = getelementptr %"compiler/source:Span", ptr %t61, i32 0, i32 0
  %t63 = load i32, ptr %t62, !tbaa !23
  %t65 = sext i32 %t63 to i64
  %t66 = getelementptr %"compiler/scope:fnUse", ptr %l6, i32 0, i32 1
  %t67 = getelementptr %"compiler/source:Span", ptr %t66, i32 0, i32 1
  %t68 = load i32, ptr %t67, !tbaa !23
  %t70 = sext i32 %t68 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t71
  %t72 = getelementptr { i64, [3 x i64] }, ptr %t71, i32 0, i32 0
  store i64 3, ptr %t72
  %t74 = insertvalue { i64, i64, i64 } undef, i64 %t60, 0
  %t76 = insertvalue { i64, i64, i64 } %t74, i64 %t65, 1
  %t78 = insertvalue { i64, i64, i64 } %t76, i64 %t70, 2
  %t79 = getelementptr { i64, [3 x i64] }, ptr %t71, i32 0, i32 1
  store { i64, i64, i64 } %t78, ptr %t79
  %t80 = load { i64, [3 x i64] }, ptr %t71
  store { i64, [3 x i64] } %t80, ptr %l8
  %t82 = getelementptr %"compiler/scope:fnUse", ptr %l6, i32 0, i32 3
  %t83 = load i64, ptr %t82, !tbaa !24
  %t84 = load i64, ptr @G_2ecompiler_2fscope_2eFnCall, !tbaa !24
  %t87 = icmp eq i64 %t83, %t84
  br i1 %t87, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  %t89 = getelementptr %"compiler/scope:fnUse", ptr %l6, i32 0, i32 4
  %t90 = load i32, ptr %t89, !tbaa !23
  store i32 %t90, ptr %l9, !tbaa !23
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load i32, ptr %l9, !tbaa !23
  %t96 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t92, i32 %t93)
  store i1 %t96, ptr %l72
  br label %bb19
bb18:
  %t97 = getelementptr %"compiler/scope:fnUse", ptr %l6, i32 0, i32 3
  %t98 = load i64, ptr %t97, !tbaa !24
  %t99 = load i64, ptr @G_2ecompiler_2fscope_2eFnNamed, !tbaa !24
  %t102 = icmp eq i64 %t98, %t99
  br i1 %t102, label %bb34, label %bb35
bb19:
  %t104 = load i1, ptr %l72, !tbaa !21
  br i1 %t104, label %bb20, label %bb21
bb20:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/scope:Scoper", ptr %t105, i32 0, i32 0
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = getelementptr %"compiler/generic:Program", ptr %t108, i32 0, i32 2
  %t111 = load i32, ptr %l9, !tbaa !23
  %t114 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t110, i32 %t111)
  store i32 %t114, ptr %l77
  br label %bb22
bb21:
  br label %bb23
bb22:
  %t115 = load i32, ptr %l77, !tbaa !23
  store i32 %t115, ptr %l9, !tbaa !23
  br label %bb23
bb23:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/scope:Scoper", ptr %t116, i32 0, i32 0
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t121 = getelementptr %"compiler/generic:Program", ptr %t119, i32 0, i32 2
  %t122 = load i32, ptr %l9, !tbaa !23
  %t125 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t121, i32 %t122)
  store i32 %t125, ptr %l82
  br label %bb24
bb24:
  %t126 = load i32, ptr %l82, !tbaa !23
  store i32 %t126, ptr %l9, !tbaa !23
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/scope:Scoper", ptr %t127, i32 0, i32 0
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t132 = getelementptr %"compiler/generic:Program", ptr %t130, i32 0, i32 2
  %t133 = load i32, ptr %l9, !tbaa !23
  %t136 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t132, i32 %t133)
  store i32 %t136, ptr %l87
  br label %bb25
bb25:
  %t137 = load i32, ptr %l87
  %t139 = trunc i64 18 to i32
  %t140 = icmp eq i32 %t137, %t139
  br i1 %t140, label %bb26, label %bb27
bb26:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/scope:Scoper", ptr %t142, i32 0, i32 0
  %t145 = load ptr, ptr %t144, !tbaa !29
  %t147 = getelementptr %"compiler/generic:Program", ptr %t145, i32 0, i32 0
  %t148 = load ptr, ptr %t147, !tbaa !29
  %t150 = getelementptr %"compiler/load:Loader", ptr %t148, i32 0, i32 3
  %t151 = load ptr, ptr %t150, !tbaa !29
  store ptr %t151, ptr %l94, !tbaa !29
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/scope:Scoper", ptr %t152, i32 0, i32 0
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t157 = getelementptr %"compiler/generic:Program", ptr %t155, i32 0, i32 2
  store ptr %t157, ptr %l97, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/scope:Scoper", ptr %t158, i32 0, i32 0
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = getelementptr %"compiler/generic:Program", ptr %t161, i32 0, i32 2
  %t164 = load i32, ptr %l9, !tbaa !23
  %t167 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t163, i32 %t164)
  store i32 %t167, ptr %l102
  br label %bb28
bb27:
  store { i64, ptr } { i64 0, ptr @.d1 }, ptr %l90, !tbaa !27
  br label %bb31
bb28:
  %t168 = load ptr, ptr %l97, !tbaa !29
  %t169 = load i32, ptr %l102, !tbaa !23
  %t170 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t168, i32 %t169)
  store i32 %t170, ptr %l103
  br label %bb29
bb29:
  %t171 = load ptr, ptr %l94, !tbaa !29
  %t172 = load i32, ptr %l103, !tbaa !23
  %t173 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t171, i32 %t172)
  store { i64, ptr } %t173, ptr %l104
  br label %bb30
bb30:
  %t174 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t174, ptr %l90, !tbaa !27
  br label %bb31
bb31:
  %t175 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/scope:Scoper", ptr %t176, i32 0, i32 0
  %t179 = load ptr, ptr %t178, !tbaa !29
  %t181 = getelementptr %"compiler/generic:Program", ptr %t179, i32 0, i32 0
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t184 = getelementptr %"compiler/load:Loader", ptr %t182, i32 0, i32 4
  %t185 = load ptr, ptr %t184, !tbaa !29
  store ptr %t185, ptr %l108, !tbaa !29
  %t186 = load { i64, [3 x i64] }, ptr %l8
  store { i64, [3 x i64] } %t186, ptr %l109
  %t189 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCallValueObligations(ptr %v0, ptr %s5, { i64, ptr } %t175)
  store %"compiler/msgs:Msg" %t189, ptr %l111
  br label %bb32
bb32:
  %t190 = load ptr, ptr %l108, !tbaa !29
  %t191 = load { i64, [3 x i64] }, ptr %l109
  %t192 = load %"compiler/msgs:Msg", ptr %l111
  %t193 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s5, ptr %t190, { i64, [3 x i64] } %t191, %"compiler/msgs:Msg" %t192)
  store i64 %t193, ptr %l112
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s5)
  br label %bb138
bb34:
  store %olang.scope zeroinitializer, ptr %s8
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/scope:Scoper", ptr %t194, i32 0, i32 10
  %t197 = getelementptr %"compiler/scope:fnUse", ptr %l6, i32 0, i32 0
  %t198 = load i64, ptr %t197, !tbaa !24
  %t201 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v0, ptr %t196, i64 %t198)
  %t202 = extractvalue { i32, { i64, ptr } } %t201, 1
  %t203 = extractvalue { i32, { i64, ptr } } %t201, 0
  store i32 %t203, ptr %l121
  %t204 = icmp ne i32 %t203, 0
  br i1 %t204, label %bb37, label %ok.205
ok.205:
  store { i64, ptr } %t202, ptr %l120
  br label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s9
  store { i64, ptr } { i64 0, ptr @.d2 }, ptr %l145, !tbaa !27
  %t206 = load { i64, ptr }, ptr %l145, !tbaa !27
  store { i64, ptr } %t206, ptr %l146, !tbaa !27
  %t207 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t207, 0
  store i64 %t208, ptr %l147, !tbaa !24
  %t209 = load i64, ptr %l147, !tbaa !24
  %t210 = mul i64 %t209, 1
  %t211 = call ptr @__olang_scope_alloc_zeroed(ptr %s9, i64 %t210)
  %t212 = insertvalue { i64, ptr } undef, i64 %t209, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %t211, 1
  store { i64, ptr } %t213, ptr %l148, !tbaa !27
  %t214 = getelementptr { i64, ptr }, ptr %l148, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr { i64, ptr }, ptr %l146, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = load i64, ptr %l147, !tbaa !24
  %t219 = mul i64 %t218, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t215, ptr %t217, i64 %t219, i1 false)
  %t220 = load { i64, ptr }, ptr %l148, !tbaa !27
  store { i64, ptr } %t220, ptr %l12, !tbaa !27
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/scope:Scoper", ptr %t221, i32 0, i32 1
  %t224 = getelementptr %"compiler/scope:fnUse", ptr %l6, i32 0, i32 2
  %t225 = load i64, ptr %t224, !tbaa !24
  %t228 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t223, i64 %t225)
  store ptr %t228, ptr %l152
  br label %bb51
bb36:
  %t229 = load { i64, ptr }, ptr %l120, !tbaa !27
  store { i64, ptr } %t229, ptr %l116, !tbaa !27
  br label %bb39
bb37:
  br label %bb38
bb38:
  store { i64, ptr } { i64 0, ptr @.d3 }, ptr %l116, !tbaa !27
  br label %bb39
bb39:
  %t230 = load { i64, ptr }, ptr %l116, !tbaa !27
  store { i64, ptr } %t230, ptr %l11, !tbaa !27
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr %"compiler/scope:Scoper", ptr %t231, i32 0, i32 0
  %t234 = load ptr, ptr %t233, !tbaa !29
  %t236 = getelementptr %"compiler/generic:Program", ptr %t234, i32 0, i32 0
  %t237 = load ptr, ptr %t236, !tbaa !29
  %t239 = getelementptr %"compiler/load:Loader", ptr %t237, i32 0, i32 4
  %t240 = load ptr, ptr %t239, !tbaa !29
  store ptr %t240, ptr %l125, !tbaa !29
  %t241 = load { i64, [3 x i64] }, ptr %l8
  store { i64, [3 x i64] } %t241, ptr %l126
  %t242 = getelementptr %"compiler/scope:fnUse", ptr %l6, i32 0, i32 1
  %t243 = getelementptr %"compiler/source:Span", ptr %t242, i32 0, i32 1
  %t244 = load i32, ptr %t243, !tbaa !23
  %t246 = sext i32 %t244 to i64
  %t247 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t249 = extractvalue { i64, ptr } %t247, 0
  %t252 = icmp sle i64 %t246, %t249
  br i1 %t252, label %bb40, label %bb41
bb40:
  %t254 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t254, ptr %l133, !tbaa !27
  %t255 = getelementptr %"compiler/scope:fnUse", ptr %l6, i32 0, i32 1
  %t256 = getelementptr %"compiler/source:Span", ptr %t255, i32 0, i32 0
  %t257 = load i32, ptr %t256, !tbaa !23
  %t259 = sext i32 %t257 to i64
  store i64 %t259, ptr %l135, !tbaa !24
  %t260 = getelementptr %"compiler/scope:fnUse", ptr %l6, i32 0, i32 1
  %t261 = getelementptr %"compiler/source:Span", ptr %t260, i32 0, i32 1
  %t262 = load i32, ptr %t261, !tbaa !23
  %t264 = sext i32 %t262 to i64
  store i64 %t264, ptr %l137, !tbaa !24
  %t265 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t266 = extractvalue { i64, ptr } %t265, 0
  store i64 %t266, ptr %l138, !tbaa !24
  %t267 = load i64, ptr %l135, !tbaa !24
  %t268 = icmp sge i64 %t267, 0
  br i1 %t268, label %bb42, label %bb43
bb41:
  store { i64, ptr } { i64 0, ptr @.d4 }, ptr %l132, !tbaa !27
  br label %bb48
bb42:
  %t270 = load i64, ptr %l135, !tbaa !24
  %t271 = load i64, ptr %l137, !tbaa !24
  %t272 = icmp sle i64 %t270, %t271
  br i1 %t272, label %bb44, label %bb45
bb43:
  call void @__olang_check_failed(ptr @olang_loc_a6d9af0a83312252_fc535c4d1a274576)
  unreachable
bb44:
  %t274 = load i64, ptr %l137, !tbaa !24
  %t275 = load i64, ptr %l138, !tbaa !24
  %t276 = icmp sle i64 %t274, %t275
  br i1 %t276, label %bb46, label %bb47
bb45:
  call void @__olang_check_failed(ptr @olang_loc_a6d9af0a83312252_fc535c4d1a274576)
  unreachable
bb46:
  %t278 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = load i64, ptr %l135, !tbaa !24
  %t281 = load i64, ptr %l137, !tbaa !24
  %t282 = getelementptr i8, ptr %t279, i64 %t280
  %t283 = sub i64 %t281, %t280
  %t284 = insertvalue { i64, ptr } undef, i64 %t283, 0
  %t285 = insertvalue { i64, ptr } %t284, ptr %t282, 1
  store { i64, ptr } %t285, ptr %l132, !tbaa !27
  br label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_a6d9af0a83312252_fc535c4d1a274576)
  unreachable
bb48:
  %t287 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t288 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eFuncValueObligations(ptr %v0, ptr %s8, { i64, ptr } %t287)
  store %"compiler/msgs:Msg" %t288, ptr %l143
  br label %bb49
bb49:
  %t289 = load ptr, ptr %l125, !tbaa !29
  %t290 = load { i64, [3 x i64] }, ptr %l126
  %t291 = load %"compiler/msgs:Msg", ptr %l143
  %t292 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s8, ptr %t289, { i64, [3 x i64] } %t290, %"compiler/msgs:Msg" %t291)
  store i64 %t292, ptr %l144
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s8)
  br label %bb137
bb51:
  %t293 = load ptr, ptr %l152, !tbaa !29
  store ptr %t293, ptr %l13, !tbaa !29
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t296 = getelementptr %"compiler/scope:Scoper", ptr %t294, i32 0, i32 0
  %t297 = load ptr, ptr %t296, !tbaa !29
  %t299 = getelementptr %"compiler/generic:Program", ptr %t297, i32 0, i32 2
  %t300 = load ptr, ptr %l13, !tbaa !29
  %t302 = getelementptr %"compiler/typed:Body", ptr %t300, i32 0, i32 2
  %t303 = load i32, ptr %t302, !tbaa !23
  %t306 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t299, i32 %t303, i64 0)
  store i64 %t306, ptr %l158
  br label %bb52
bb52:
  %t307 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  %t308 = load i64, ptr %l158, !tbaa !24
  %t310 = icmp eq i64 %t308, %t307
  br i1 %t310, label %bb53, label %bb54
bb53:
  store i1 true, ptr %l14, !tbaa !21
  store ptr %l7, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb55
bb54:
  br label %bb86
bb55:
  store %olang.scope zeroinitializer, ptr %s12
  %t313 = load ptr, ptr %l15, !tbaa !29
  %t314 = load i64, ptr %l16, !tbaa !24
  %t317 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3arel_3e_2eRunFrom_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t313, i64 %t314)
  %t318 = extractvalue { i32, { i64, ptr } } %t317, 1
  %t319 = extractvalue { i32, { i64, ptr } } %t317, 0
  store i32 %t319, ptr %l166
  %t320 = icmp ne i32 %t319, 0
  br i1 %t320, label %bb57, label %ok.321
ok.321:
  store { i64, ptr } %t318, ptr %l165
  br label %bb56
bb56:
  %t322 = load { i64, ptr }, ptr %l165, !tbaa !27
  store { i64, ptr } %t322, ptr %l162, !tbaa !27
  br label %bb61
bb57:
  %t323 = load i32, ptr %l166, !tbaa !23
  %t324 = ashr i32 %t323, 16
  %t326 = icmp eq i32 %t324, 1
  br i1 %t326, label %bb58, label %bb59
bb58:
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_fc32950df7c04da2_11eedb932326b4f6)
  unreachable
bb60:
  call void @__olang_scope_close(ptr %s12)
  br label %bb82
bb61:
  %t328 = load { i64, ptr }, ptr %l162, !tbaa !27
  store { i64, ptr } %t328, ptr %l17, !tbaa !27
  %t329 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t331 = extractvalue { i64, ptr } %t329, 0
  store i64 %t331, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb62
bb62:
  store %olang.scope zeroinitializer, ptr %s13
  %t333 = load i64, ptr %l19, !tbaa !24
  %t334 = load i64, ptr %l18, !tbaa !24
  %t337 = icmp slt i64 %t333, %t334
  %t339 = xor i1 %t337, true
  br i1 %t339, label %bb63, label %bb64
bb63:
  call void @__olang_scope_close(ptr %s13)
  br label %bb80
bb64:
  br label %bb65
bb65:
  %t341 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t341, ptr %l175, !tbaa !27
  %t342 = load i64, ptr %l19, !tbaa !24
  %t344 = getelementptr { i64, ptr }, ptr %l175, i32 0, i32 1
  %t345 = load ptr, ptr %t344, !tbaa !27
  %t346 = getelementptr %"compiler/scope:rel", ptr %t345, i64 %t342
  %t347 = load %"compiler/scope:rel", ptr %t346
  store %"compiler/scope:rel" %t347, ptr %l20
  %t349 = getelementptr %"compiler/scope:rel", ptr %l20, i32 0, i32 1
  %t350 = load { i64, [2 x i64] }, ptr %t349
  store { i64, [2 x i64] } %t350, ptr %l21
  %t352 = load { i64, [2 x i64] }, ptr %l21
  %t354 = extractvalue { i64, [2 x i64] } %t352, 0
  %t355 = icmp eq i64 %t354, 2
  br i1 %t355, label %bb66, label %bb67
bb66:
  %t357 = getelementptr { i64, [2 x i64] }, ptr %l21, i32 0, i32 1
  %t358 = getelementptr { i64 }, ptr %t357, i32 0, i32 0
  %t359 = load i64, ptr %t358
  store i64 %t359, ptr %l22, !tbaa !24
  br label %bb68
bb67:
  br label %bb73
bb68:
  %t361 = load i1, ptr %l14, !tbaa !21
  br i1 %t361, label %bb69, label %bb70
bb69:
  %t363 = load ptr, ptr %l13, !tbaa !29
  %t365 = getelementptr %"compiler/typed:Body", ptr %t363, i32 0, i32 6
  %t366 = load i64, ptr %l22, !tbaa !24
  %t369 = call { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_H9c4972d30d76581e4f8a183d5194d431(ptr %v0, ptr %t365, i64 %t366)
  store { i64, [1 x i64] } %t369, ptr %l187
  br label %bb71
bb70:
  store i1 false, ptr %l183, !tbaa !21
  br label %bb72
bb71:
  %t370 = load { i64, [1 x i64] }, ptr %l187
  %t372 = extractvalue { i64, [1 x i64] } %t370, 0
  %t373 = icmp eq i64 %t372, 1
  store i1 %t373, ptr %l183, !tbaa !21
  br label %bb72
bb72:
  %t375 = load i1, ptr %l183, !tbaa !21
  store i1 %t375, ptr %l14, !tbaa !21
  br label %bb78
bb73:
  br i1 true, label %bb74, label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb77
bb76:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb78
bb77:
  call void @__olang_check_failed(ptr @olang_loc_af9ca28b921c6ea3_fa663a0c518bad97)
  unreachable
bb78:
  call void @__olang_scope_close(ptr %s13)
  br label %bb79
bb79:
  %t376 = load i64, ptr %l19, !tbaa !24
  %t378 = add i64 %t376, 1
  store i64 %t378, ptr %l19, !tbaa !24
  br label %bb62
bb80:
  %t380 = load i64, ptr %l16, !tbaa !24
  %t381 = load i64, ptr %l18, !tbaa !24
  %t384 = add i64 %t380, %t381
  store i64 %t384, ptr %l16, !tbaa !24
  call void @__olang_scope_close(ptr %s12)
  br label %bb81
bb81:
  br label %bb55
bb82:
  %t386 = load i1, ptr %l14, !tbaa !21
  br i1 %t386, label %bb83, label %bb84
bb83:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s3)
  br label %bb139
bb84:
  br label %bb85
bb85:
  br label %bb86
bb86:
  store ptr %l7, ptr %l23, !tbaa !29
  store i64 0, ptr %l24, !tbaa !24
  br label %bb87
bb87:
  store %olang.scope zeroinitializer, ptr %s19
  %t389 = load ptr, ptr %l23, !tbaa !29
  %t390 = load i64, ptr %l24, !tbaa !24
  %t393 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3arel_3e_2eRunFrom_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t389, i64 %t390)
  %t394 = extractvalue { i32, { i64, ptr } } %t393, 1
  %t395 = extractvalue { i32, { i64, ptr } } %t393, 0
  store i32 %t395, ptr %l201
  %t396 = icmp ne i32 %t395, 0
  br i1 %t396, label %bb89, label %ok.397
ok.397:
  store { i64, ptr } %t394, ptr %l200
  br label %bb88
bb88:
  %t398 = load { i64, ptr }, ptr %l200, !tbaa !27
  store { i64, ptr } %t398, ptr %l197, !tbaa !27
  br label %bb93
bb89:
  %t399 = load i32, ptr %l201, !tbaa !23
  %t400 = ashr i32 %t399, 16
  %t402 = icmp eq i32 %t400, 1
  br i1 %t402, label %bb90, label %bb91
bb90:
  br label %bb92
bb91:
  call void @__olang_check_failed(ptr @olang_loc_357527e8194aec84_988fed079319ef80)
  unreachable
bb92:
  call void @__olang_scope_close(ptr %s19)
  br label %bb129
bb93:
  %t404 = load { i64, ptr }, ptr %l197, !tbaa !27
  store { i64, ptr } %t404, ptr %l25, !tbaa !27
  %t405 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t407 = extractvalue { i64, ptr } %t405, 0
  store i64 %t407, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb94
bb94:
  store %olang.scope zeroinitializer, ptr %s20
  %t409 = load i64, ptr %l27, !tbaa !24
  %t410 = load i64, ptr %l26, !tbaa !24
  %t413 = icmp slt i64 %t409, %t410
  %t415 = xor i1 %t413, true
  br i1 %t415, label %bb95, label %bb96
bb95:
  call void @__olang_scope_close(ptr %s20)
  br label %bb127
bb96:
  br label %bb97
bb97:
  %t417 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t417, ptr %l210, !tbaa !27
  %t418 = load i64, ptr %l27, !tbaa !24
  %t420 = getelementptr { i64, ptr }, ptr %l210, i32 0, i32 1
  %t421 = load ptr, ptr %t420, !tbaa !27
  %t422 = getelementptr %"compiler/scope:rel", ptr %t421, i64 %t418
  %t423 = load %"compiler/scope:rel", ptr %t422
  store %"compiler/scope:rel" %t423, ptr %l28
  %t425 = getelementptr %"compiler/scope:rel", ptr %l28, i32 0, i32 0
  %t426 = load { i64, [2 x i64] }, ptr %t425
  store { i64, [2 x i64] } %t426, ptr %l29
  %t428 = load { i64, [2 x i64] }, ptr %l29
  %t430 = extractvalue { i64, [2 x i64] } %t428, 0
  %t431 = icmp eq i64 %t430, 2
  br i1 %t431, label %bb98, label %bb99
bb98:
  %t433 = getelementptr { i64, [2 x i64] }, ptr %l29, i32 0, i32 1
  %t434 = getelementptr { i64 }, ptr %t433, i32 0, i32 0
  %t435 = load i64, ptr %t434
  store i64 %t435, ptr %l30, !tbaa !24
  br label %bb100
bb99:
  br label %bb120
bb100:
  %t437 = load ptr, ptr %l13, !tbaa !29
  %t439 = getelementptr %"compiler/typed:Body", ptr %t437, i32 0, i32 6
  %t440 = load i64, ptr %l30, !tbaa !24
  %t443 = call { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_H9c4972d30d76581e4f8a183d5194d431(ptr %v0, ptr %t439, i64 %t440)
  store { i64, [1 x i64] } %t443, ptr %l220
  br label %bb101
bb101:
  %t444 = load { i64, [1 x i64] }, ptr %l220
  store { i64, [1 x i64] } %t444, ptr %l31
  %t445 = load { i64, [1 x i64] }, ptr %l31
  %t447 = extractvalue { i64, [1 x i64] } %t445, 0
  %t448 = icmp eq i64 %t447, 0
  br i1 %t448, label %bb102, label %bb103
bb102:
  %t450 = getelementptr { i64, [1 x i64] }, ptr %l31, i32 0, i32 1
  %t451 = getelementptr { i32 }, ptr %t450, i32 0, i32 0
  %t452 = load i32, ptr %t451
  store i32 %t452, ptr %l32, !tbaa !23
  br label %bb104
bb103:
  br label %bb114
bb104:
  store %olang.scope zeroinitializer, ptr %s22
  %t454 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t456 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s9, ptr %s22, { i64, ptr } %t454, { i64, ptr } { i64 0, ptr @.d5 })
  store i1 %t456, ptr %l225
  br label %bb105
bb105:
  %t457 = load i1, ptr %l225, !tbaa !21
  br i1 %t457, label %bb106, label %bb107
bb106:
  %t458 = load ptr, ptr %l0, !tbaa !29
  %t460 = getelementptr %"compiler/scope:Scoper", ptr %t458, i32 0, i32 0
  %t461 = load ptr, ptr %t460, !tbaa !29
  %t463 = getelementptr %"compiler/generic:Program", ptr %t461, i32 0, i32 0
  %t464 = load ptr, ptr %t463, !tbaa !29
  %t466 = getelementptr %"compiler/load:Loader", ptr %t464, i32 0, i32 3
  %t467 = load ptr, ptr %t466, !tbaa !29
  store ptr %t467, ptr %l229, !tbaa !29
  %t468 = load ptr, ptr %l13, !tbaa !29
  %t470 = getelementptr %"compiler/typed:Body", ptr %t468, i32 0, i32 7
  %t471 = load i32, ptr %l32, !tbaa !23
  %t473 = sext i32 %t471 to i64
  %t476 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t470, i64 %t473)
  store %"compiler/typed:Local" %t476, ptr %l234
  br label %bb108
bb107:
  br label %bb113
bb108:
  %t477 = getelementptr %"compiler/typed:Local", ptr %l234, i32 0, i32 0
  %t478 = load i32, ptr %t477, !tbaa !23
  %t479 = load ptr, ptr %l229, !tbaa !29
  %t481 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t479, i32 %t478)
  store { i64, ptr } %t481, ptr %l236
  br label %bb109
bb109:
  %t482 = load { i64, ptr }, ptr %l236, !tbaa !27
  store { i64, ptr } %t482, ptr %l237, !tbaa !27
  %t483 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t484 = extractvalue { i64, ptr } %t483, 0
  %t485 = load { i64, ptr }, ptr %l237, !tbaa !27
  %t486 = extractvalue { i64, ptr } %t485, 0
  store i64 %t486, ptr %l239, !tbaa !24
  %t488 = load i64, ptr %l239, !tbaa !24
  %t489 = icmp eq i64 %t484, %t488
  br i1 %t489, label %bb110, label %bb111
bb110:
  %t491 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t492 = load ptr, ptr %t491, !tbaa !27
  %t493 = getelementptr { i64, ptr }, ptr %l237, i32 0, i32 1
  %t494 = load ptr, ptr %t493, !tbaa !27
  %t495 = load i64, ptr %l239, !tbaa !24
  %t496 = mul i64 %t495, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t492, ptr %t494, i64 %t496, i1 false)
  br label %bb112
bb111:
  %t497 = load { i64, ptr }, ptr %l237, !tbaa !27
  %t498 = extractvalue { i64, ptr } %t497, 0
  store i64 %t498, ptr %l241, !tbaa !24
  %t499 = load i64, ptr %l241, !tbaa !24
  %t500 = mul i64 %t499, 1
  %t501 = call ptr @__olang_scope_alloc_zeroed(ptr %s9, i64 %t500)
  %t502 = insertvalue { i64, ptr } undef, i64 %t499, 0
  %t503 = insertvalue { i64, ptr } %t502, ptr %t501, 1
  store { i64, ptr } %t503, ptr %l242, !tbaa !27
  %t504 = getelementptr { i64, ptr }, ptr %l242, i32 0, i32 1
  %t505 = load ptr, ptr %t504, !tbaa !27
  %t506 = getelementptr { i64, ptr }, ptr %l237, i32 0, i32 1
  %t507 = load ptr, ptr %t506, !tbaa !27
  %t508 = load i64, ptr %l241, !tbaa !24
  %t509 = mul i64 %t508, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t505, ptr %t507, i64 %t509, i1 false)
  %t510 = load { i64, ptr }, ptr %l242, !tbaa !27
  store { i64, ptr } %t510, ptr %l12, !tbaa !27
  br label %bb112
bb112:
  br label %bb113
bb113:
  call void @__olang_scope_close(ptr %s22)
  br label %bb119
bb114:
  br i1 true, label %bb115, label %bb116
bb115:
  br label %bb117
bb116:
  br label %bb118
bb117:
  br label %bb119
bb118:
  call void @__olang_check_failed(ptr @olang_loc_66c1e4161a335875_1a8748292bb4d011)
  unreachable
bb119:
  br label %bb125
bb120:
  br i1 true, label %bb121, label %bb122
bb121:
  br label %bb123
bb122:
  br label %bb124
bb123:
  br label %bb125
bb124:
  call void @__olang_check_failed(ptr @olang_loc_2ebdbee26f736ebe_e8fbd5d45318ee7a)
  unreachable
bb125:
  call void @__olang_scope_close(ptr %s20)
  br label %bb126
bb126:
  %t511 = load i64, ptr %l27, !tbaa !24
  %t513 = add i64 %t511, 1
  store i64 %t513, ptr %l27, !tbaa !24
  br label %bb94
bb127:
  %t515 = load i64, ptr %l24, !tbaa !24
  %t516 = load i64, ptr %l26, !tbaa !24
  %t519 = add i64 %t515, %t516
  store i64 %t519, ptr %l24, !tbaa !24
  call void @__olang_scope_close(ptr %s19)
  br label %bb128
bb128:
  br label %bb87
bb129:
  %t521 = load ptr, ptr %l0, !tbaa !29
  %t523 = getelementptr %"compiler/scope:Scoper", ptr %t521, i32 0, i32 0
  %t524 = load ptr, ptr %t523, !tbaa !29
  %t526 = getelementptr %"compiler/generic:Program", ptr %t524, i32 0, i32 0
  %t527 = load ptr, ptr %t526, !tbaa !29
  %t529 = getelementptr %"compiler/load:Loader", ptr %t527, i32 0, i32 4
  %t530 = load ptr, ptr %t529, !tbaa !29
  store ptr %t530, ptr %l251, !tbaa !29
  %t531 = load { i64, [3 x i64] }, ptr %l8
  store { i64, [3 x i64] } %t531, ptr %l252
  %t532 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t534 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s9, ptr %s9, { i64, ptr } %t532, { i64, ptr } { i64 0, ptr @.d6 })
  store i1 %t534, ptr %l254
  br label %bb130
bb130:
  %t535 = load i1, ptr %l254, !tbaa !21
  %t536 = xor i1 %t535, true
  br i1 %t536, label %bb131, label %bb132
bb131:
  %t538 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t540 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaValueObligations(ptr %s9, ptr %s9, { i64, ptr } %t538)
  store %"compiler/msgs:Msg" %t540, ptr %l258
  br label %bb133
bb132:
  %t541 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaValueRelates(ptr %s9)
  store %"compiler/msgs:Msg" %t541, ptr %l259
  br label %bb134
bb133:
  %t542 = load %"compiler/msgs:Msg", ptr %l258
  store %"compiler/msgs:Msg" %t542, ptr %l256
  br label %bb135
bb134:
  %t543 = load %"compiler/msgs:Msg", ptr %l259
  store %"compiler/msgs:Msg" %t543, ptr %l256
  br label %bb135
bb135:
  %t544 = load ptr, ptr %l251, !tbaa !29
  %t545 = load { i64, [3 x i64] }, ptr %l252
  %t546 = load %"compiler/msgs:Msg", ptr %l256
  %t547 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s9, ptr %t544, { i64, [3 x i64] } %t545, %"compiler/msgs:Msg" %t546)
  store i64 %t547, ptr %l260
  br label %bb136
bb136:
  call void @__olang_scope_close(ptr %s9)
  br label %bb137
bb137:
  br label %bb138
bb138:
  call void @__olang_scope_close(ptr %s3)
  br label %bb139
bb139:
  %t548 = load i64, ptr %l5, !tbaa !24
  %t550 = add i64 %t548, 1
  store i64 %t550, ptr %l5, !tbaa !24
  br label %bb8
bb140:
  %t552 = load i64, ptr %l2, !tbaa !24
  %t553 = load i64, ptr %l4, !tbaa !24
  %t556 = add i64 %t552, %t553
  store i64 %t556, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb141
bb141:
  br label %bb1
bb142:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eheldPart(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca i64
  %l13 = alloca i1
  %l15 = alloca i1
  %l17 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca i32
  %l26 = alloca i1
  %l30 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_3451003dd1e97df4_bcd12f7be62952d8)
  unreachable
bb11:
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = call i64 @compiler_2fscope_2eflRoot(ptr %v1, ptr %t11)
  store i64 %t13, ptr %l10
  br label %bb12
bb12:
  %t14 = load i64, ptr %l10, !tbaa !24
  store i64 %t14, ptr %l2, !tbaa !24
  %t15 = load i64, ptr %l2, !tbaa !24
  %t17 = icmp slt i64 %t15, 0
  br i1 %t17, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb16
bb14:
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = call i1 @compiler_2fscope_2eflThroughRef(ptr %v1, ptr %t19)
  store i1 %t21, ptr %l15
  br label %bb15
bb15:
  %t22 = load i1, ptr %l15, !tbaa !21
  store i1 %t22, ptr %l13, !tbaa !21
  br label %bb16
bb16:
  %t23 = load i1, ptr %l13, !tbaa !21
  br i1 %t23, label %bb17, label %bb18
bb17:
  store i1 false, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/scope:Scoper", ptr %t25, i32 0, i32 38
  %t28 = load i64, ptr %l2, !tbaa !24
  %t31 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v0, ptr %t27, i64 %t28)
  %t32 = extractvalue { i32, ptr } %t31, 1
  %t33 = extractvalue { i32, ptr } %t31, 0
  store i32 %t33, ptr %l22
  %t34 = icmp ne i32 %t33, 0
  br i1 %t34, label %bb21, label %ok.35
ok.35:
  store ptr %t32, ptr %l21
  br label %bb20
bb20:
  %t36 = load ptr, ptr %l21, !tbaa !29
  store ptr %t36, ptr %l17, !tbaa !29
  br label %bb23
bb21:
  br label %bb22
bb22:
  store ptr null, ptr %l17, !tbaa !29
  br label %bb23
bb23:
  %t37 = load ptr, ptr %l17, !tbaa !29
  store ptr %t37, ptr %l3, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = icmp eq ptr %t38, null
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb24, label %bb25
bb24:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t49 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeHere(ptr %v0, ptr %v0, ptr %t44, ptr %t45)
  store i1 %t49, ptr %l30
  br label %bb26
bb25:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb27
bb26:
  %t50 = load i1, ptr %l30, !tbaa !21
  store i1 %t50, ptr %l26, !tbaa !21
  br label %bb27
bb27:
  %t51 = load i1, ptr %l26, !tbaa !21
  store i1 %t51, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehere(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca ptr
  %l5 = alloca ptr
  %l8 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i32
  %rv = alloca { i64, [2 x i64] }
  %t55 = alloca { i64, [2 x i64] }, align 8
  %t72 = alloca { i64, [2 x i64] }, align 8
  %t77 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/scope:Scoper", ptr %t2, i32 0, i32 32
  store ptr %t4, ptr %l5, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/scope:Scoper", ptr %t5, i32 0, i32 32
  %t9 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l8
  br label %bb1
bb1:
  %t10 = load i64, ptr %l8, !tbaa !24
  %t11 = sub i64 %t10, 1
  %t12 = load ptr, ptr %l5, !tbaa !29
  %t14 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t12, i64 %t11)
  store i32 %t14, ptr %l10
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l3, !tbaa !29
  %t16 = load i32, ptr %l10, !tbaa !23
  %t17 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elift(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t17, ptr %l11
  br label %bb3
bb3:
  %t18 = load i32, ptr %l11, !tbaa !23
  store i32 %t18, ptr %l1, !tbaa !23
  %t19 = load i32, ptr %l1, !tbaa !23
  %t21 = icmp eq i32 %t19, 0
  br i1 %t21, label %bb4, label %bb5
bb4:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/scope:Scoper", ptr %t23, i32 0, i32 25
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = icmp eq ptr %t26, null
  br i1 %t28, label %bb6, label %bb7
bb5:
  br label %bb27
bb6:
  call void @__olang_check_failed(ptr @olang_loc_c4815f8d08aa5069_e0d3df7c014ad4fd)
  unreachable
bb7:
  br label %bb8
bb8:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/scope:Scoper", ptr %t30, i32 0, i32 25
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Body", ptr %t33, i32 0, i32 1
  %t37 = load { i64, [2 x i64] }, ptr %t36
  store { i64, [2 x i64] } %t37, ptr %l2
  %t39 = load { i64, [2 x i64] }, ptr %l2
  %t41 = extractvalue { i64, [2 x i64] } %t39, 0
  %t42 = icmp eq i64 %t41, 1
  br i1 %t42, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb15
bb11:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/scope:Scoper", ptr %t44, i32 0, i32 37
  %t47 = load i64, ptr %t46, !tbaa !24
  %t49 = icmp sge i64 %t47, 0
  br i1 %t49, label %bb12, label %bb13
bb12:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/scope:Scoper", ptr %t51, i32 0, i32 37
  %t54 = load i64, ptr %t53, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t55
  %t56 = getelementptr { i64, [2 x i64] }, ptr %t55, i32 0, i32 0
  store i64 2, ptr %t56
  %t58 = insertvalue { i64 } undef, i64 %t54, 0
  %t59 = getelementptr { i64, [2 x i64] }, ptr %t55, i32 0, i32 1
  store { i64 } %t58, ptr %t59
  %t60 = load { i64, [2 x i64] }, ptr %t55
  store { i64, [2 x i64] } %t60, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  br label %bb26
bb15:
  %t62 = load { i64, [2 x i64] }, ptr %l2
  %t64 = extractvalue { i64, [2 x i64] } %t62, 0
  %t65 = icmp eq i64 %t64, 6
  br i1 %t65, label %bb16, label %bb17
bb16:
  br label %bb20
bb17:
  %t67 = load { i64, [2 x i64] }, ptr %l2
  %t69 = extractvalue { i64, [2 x i64] } %t67, 0
  %t70 = icmp eq i64 %t69, 7
  br i1 %t70, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store { i64, [2 x i64] } zeroinitializer, ptr %t72
  %t73 = getelementptr { i64, [2 x i64] }, ptr %t72, i32 0, i32 0
  store i64 3, ptr %t73
  %t74 = load { i64, [2 x i64] }, ptr %t72
  store { i64, [2 x i64] } %t74, ptr %rv
  br label %ret
bb21:
  br i1 true, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_f2ff34bd09efe7b1_f9738b06cf9c6415)
  unreachable
bb26:
  br label %bb27
bb27:
  %t76 = load i32, ptr %l1, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t77
  %t78 = getelementptr { i64, [2 x i64] }, ptr %t77, i32 0, i32 0
  store i64 1, ptr %t78
  %t80 = insertvalue { i32 } undef, i32 %t76, 0
  %t81 = getelementptr { i64, [2 x i64] }, ptr %t77, i32 0, i32 1
  store { i32 } %t80, ptr %t81
  %t82 = load { i64, [2 x i64] }, ptr %t77
  store { i64, [2 x i64] } %t82, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t6, i32 %a1)
  store i1 %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = load i1, ptr %l6, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2einstanceArgs(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i1
  %l11 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2einstanceOf(ptr %v0, ptr %t1, i64 %a1)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 2
  store ptr %t16, ptr %l11, !tbaa !29
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/scope:Scoper", ptr %t17, i32 0, i32 0
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t20, i64 %t21)
  store i32 %t24, ptr %l15
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb6
bb4:
  %t25 = load ptr, ptr %l11, !tbaa !29
  %t26 = load i32, ptr %l15, !tbaa !23
  %t27 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t25, i32 %t26)
  store { i64, ptr } %t27, ptr %l16
  br label %bb5
bb5:
  %t28 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  %t31 = icmp sgt i64 %t29, 0
  store i1 %t31, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t33 = load i1, ptr %l8, !tbaa !21
  store i1 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2einstanceOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca i64
  %l10 = alloca i32
  %l14 = alloca i64
  %l17 = alloca i64
  %l38 = alloca ptr
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  store i64 64, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t1 = load i64, ptr %l3, !tbaa !24
  %t2 = load i64, ptr %l2, !tbaa !24
  %t5 = icmp sgt i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp sgt i64 %t7, 0
  br i1 %t9, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l2, !tbaa !24
  %t15 = sub i64 %t11, %t12
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = add i64 %t15, %t16
  %t21 = sub i64 %t19, 1
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = sdiv i64 %t21, %t22
  store i64 %t25, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t27 = load i64, ptr %l17, !tbaa !24
  store i64 %t27, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t28 = load i64, ptr %l14, !tbaa !24
  store i64 %t28, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t29 = load i64, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb9:
  br label %bb10
bb10:
  %t37 = load i64, ptr %l2, !tbaa !24
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = load i64, ptr %l4, !tbaa !24
  %t42 = mul i64 %t38, %t39
  %t45 = add i64 %t37, %t42
  store i64 %t45, ptr %l7, !tbaa !24
  %t49 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 1
  %t50 = load i64, ptr %l1, !tbaa !24
  %t53 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t49, i64 %t50)
  store ptr %t53, ptr %l38
  br label %bb11
bb11:
  %t54 = load ptr, ptr %l38, !tbaa !29
  %t56 = getelementptr %"compiler/typed:Body", ptr %t54, i32 0, i32 1
  %t57 = load { i64, [2 x i64] }, ptr %t56
  store { i64, [2 x i64] } %t57, ptr %l8
  %t59 = load { i64, [2 x i64] }, ptr %l8
  %t61 = extractvalue { i64, [2 x i64] } %t59, 0
  %t62 = icmp eq i64 %t61, 0
  br i1 %t62, label %bb12, label %bb13
bb12:
  %t64 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t65 = getelementptr { i64 }, ptr %t64, i32 0, i32 0
  %t66 = load i64, ptr %t65
  store i64 %t66, ptr %l9, !tbaa !24
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t68 = load i64, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  store i64 %t68, ptr %rv
  br label %ret
bb15:
  %t70 = load { i64, [2 x i64] }, ptr %l8
  %t72 = extractvalue { i64, [2 x i64] } %t70, 0
  %t73 = icmp eq i64 %t72, 4
  br i1 %t73, label %bb16, label %bb17
bb16:
  %t75 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t76 = getelementptr { i32 }, ptr %t75, i32 0, i32 0
  %t77 = load i32, ptr %t76
  store i32 %t77, ptr %l10, !tbaa !23
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t79 = load i32, ptr %l10, !tbaa !23
  %t81 = sext i32 %t79 to i64
  store i64 %t81, ptr %l1, !tbaa !24
  br label %bb24
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  call void @__olang_scope_close(ptr %s2)
  store i64 -1, ptr %rv
  br label %ret
bb23:
  call void @__olang_check_failed(ptr @olang_loc_e2ea0fea769db7e4_aa8c1e0e7de89fc8)
  unreachable
bb24:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb25:
  %t84 = load i64, ptr %l6, !tbaa !24
  %t86 = add i64 %t84, 1
  store i64 %t86, ptr %l6, !tbaa !24
  br label %bb7
bb26:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2einstanceRel(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca { i64, [2 x i64] }
  %l17 = alloca i1
  %l20 = alloca i1
  %l25 = alloca i1
  %l28 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  store { i64, [2 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 25
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_4421e2d51127c851_53479ba5c20af2ad)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 25
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 1
  %t15 = load { i64, [2 x i64] }, ptr %t14
  %t19 = extractvalue { i64, [2 x i64] } %t15, 0
  %t20 = icmp eq i64 %t19, 1
  br i1 %t20, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 false, ptr %rv
  br label %ret
bb11:
  call void @__olang_check_failed(ptr @olang_loc_ba8e38ed7d6b48a9_35acc5c55c21205)
  unreachable
bb12:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/scope:Scoper", ptr %t23, i32 0, i32 37
  %t26 = load i64, ptr %t25, !tbaa !24
  %t28 = icmp sge i64 %t26, 0
  br i1 %t28, label %bb13, label %bb14
bb13:
  %t30 = load { i64, [2 x i64] }, ptr %l1
  %t32 = extractvalue { i64, [2 x i64] } %t30, 0
  %t33 = icmp eq i64 %t32, 2
  br i1 %t33, label %bb15, label %bb16
bb14:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb24
bb15:
  %t35 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t36 = getelementptr { i64 }, ptr %t35, i32 0, i32 0
  %t37 = load i64, ptr %t36
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/scope:Scoper", ptr %t38, i32 0, i32 37
  %t41 = load i64, ptr %t40, !tbaa !24
  %t44 = icmp eq i64 %t37, %t41
  store i1 %t44, ptr %l20, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb17
bb17:
  %t46 = load i1, ptr %l20, !tbaa !21
  br i1 %t46, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb23
bb19:
  %t47 = load { i64, [2 x i64] }, ptr %l2
  %t49 = extractvalue { i64, [2 x i64] } %t47, 0
  %t50 = icmp eq i64 %t49, 2
  br i1 %t50, label %bb20, label %bb21
bb20:
  %t52 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t53 = getelementptr { i64 }, ptr %t52, i32 0, i32 0
  %t54 = load i64, ptr %t53
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/scope:Scoper", ptr %t55, i32 0, i32 37
  %t58 = load i64, ptr %t57, !tbaa !24
  %t61 = icmp eq i64 %t54, %t58
  store i1 %t61, ptr %l28, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb22
bb22:
  %t63 = load i1, ptr %l28, !tbaa !21
  store i1 %t63, ptr %l25, !tbaa !21
  br label %bb23
bb23:
  %t64 = load i1, ptr %l25, !tbaa !21
  store i1 %t64, ptr %l17, !tbaa !21
  br label %bb24
bb24:
  %t65 = load i1, ptr %l17, !tbaa !21
  store i1 %t65, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisCtor(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l9 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 25
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_d38420f770b56a25_293628bae4d10df9)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 25
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 1
  %t15 = load { i64, [2 x i64] }, ptr %t14
  %t19 = extractvalue { i64, [2 x i64] } %t15, 0
  %t20 = icmp eq i64 %t19, 1
  br i1 %t20, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb7
bb6:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_7d2ed71f654b640d_ba09ac545853f0c1)
  unreachable
bb12:
  %t22 = load i1, ptr %l9, !tbaa !21
  store i1 %t22, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFunc(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = load i32, ptr %l6
  %t13 = trunc i64 21 to i32
  %t14 = icmp eq i32 %t11, %t13
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisHandle(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l5 = alloca i1
  %l10 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l24 = alloca i1
  %l27 = alloca { i64, [2 x i64] }
  %l31 = alloca { i64, ptr }
  %l33 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisStruct(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i1, ptr %l5, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/scope:Scoper", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  store ptr %t15, ptr %l10, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/scope:Scoper", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l1, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l15
  br label %bb5
bb5:
  %t26 = load ptr, ptr %l10, !tbaa !29
  %t27 = load i32, ptr %l15, !tbaa !23
  %t28 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t26, i32 %t27)
  store { i64, ptr } %t28, ptr %l16
  br label %bb6
bb6:
  %t29 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t29, ptr %l2, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  %t34 = icmp ne i64 %t32, 1
  br i1 %t34, label %bb7, label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t38, ptr %l22, !tbaa !27
  %t39 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr i32, ptr %t40, i64 0
  %t42 = load i32, ptr %t41, !tbaa !33
  %t45 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t37, i32 %t42)
  store i1 %t45, ptr %l24
  br label %bb10
bb10:
  %t46 = load i1, ptr %l24, !tbaa !21
  br i1 %t46, label %bb11, label %bb12
bb11:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i32, ptr %l1, !tbaa !23
  %t51 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efieldMark(ptr %v0, ptr %t47, i32 %t48, i64 0)
  store { i64, [2 x i64] } %t51, ptr %l27
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t52 = load { i64, [2 x i64] }, ptr %l27
  %t54 = extractvalue { i64, [2 x i64] } %t52, 0
  %t55 = icmp eq i64 %t54, 1
  store i1 %t55, ptr %rv
  br label %ret
bb14:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t58, ptr %l31, !tbaa !27
  %t59 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i32, ptr %t60, i64 0
  %t62 = load i32, ptr %t61, !tbaa !33
  %t65 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisHandle(ptr %v0, ptr %t57, i32 %t62)
  store i1 %t65, ptr %l33
  br label %bb15
bb15:
  %t66 = load i1, ptr %l33, !tbaa !21
  store i1 %t66, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisNullLit(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i1
  %l11 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %a0, i32 %t17)
  store i1 %t20, ptr %l11
  br label %bb6
bb6:
  %t21 = load i1, ptr %l11, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 false, ptr %rv
  br label %ret
bb11:
  call void @__olang_check_failed(ptr @olang_loc_4d20f13e93e5e00_8edf44d94b0465ac)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisNumberLike(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l6 = alloca i1
  %l7 = alloca i1
  %l12 = alloca i32
  %l20 = alloca i32
  %l23 = alloca i1
  %l28 = alloca i1
  %l29 = alloca i1
  %l32 = alloca ptr
  %l37 = alloca i32
  %l38 = alloca i32
  %l41 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = load i1, ptr %l6, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb5
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/scope:Scoper", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %l1, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l12
  br label %bb4
bb4:
  %t22 = load i32, ptr %l12
  %t24 = trunc i64 2 to i32
  %t25 = icmp eq i32 %t22, %t24
  store i1 %t25, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t27 = load i1, ptr %l7, !tbaa !21
  br i1 %t27, label %bb6, label %bb7
bb6:
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/scope:Scoper", ptr %t29, i32 0, i32 0
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load i32, ptr %l1, !tbaa !23
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t38, ptr %l20
  br label %bb9
bb9:
  %t39 = load i32, ptr %l20
  %t41 = trunc i64 18 to i32
  %t42 = icmp eq i32 %t39, %t41
  br i1 %t42, label %bb10, label %bb11
bb10:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/scope:Scoper", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  %t50 = load i32, ptr %l1, !tbaa !23
  %t53 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t49, i32 %t50)
  store i1 %t53, ptr %l28
  br label %bb12
bb11:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb13
bb12:
  %t54 = load i1, ptr %l28, !tbaa !21
  store i1 %t54, ptr %l23, !tbaa !21
  br label %bb13
bb13:
  %t55 = load i1, ptr %l23, !tbaa !21
  br i1 %t55, label %bb14, label %bb15
bb14:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/scope:Scoper", ptr %t56, i32 0, i32 0
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  store ptr %t61, ptr %l32, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/scope:Scoper", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l1, !tbaa !23
  %t71 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t67, i32 %t68)
  store i32 %t71, ptr %l37
  br label %bb16
bb15:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb18
bb16:
  %t72 = load ptr, ptr %l32, !tbaa !29
  %t73 = load i32, ptr %l37, !tbaa !23
  %t74 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t72, i32 %t73)
  store i32 %t74, ptr %l38
  br label %bb17
bb17:
  %t75 = load i32, ptr %l38
  %t77 = trunc i64 4 to i32
  %t78 = icmp eq i32 %t75, %t77
  store i1 %t78, ptr %l29, !tbaa !21
  br label %bb18
bb18:
  %t80 = load i1, ptr %l29, !tbaa !21
  br i1 %t80, label %bb19, label %bb20
bb19:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l41, !tbaa !29
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/scope:Scoper", ptr %t82, i32 0, i32 0
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/generic:Program", ptr %t85, i32 0, i32 2
  %t88 = load i32, ptr %l1, !tbaa !23
  %t91 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t87, i32 %t88)
  store i32 %t91, ptr %l46
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t92 = load ptr, ptr %l41, !tbaa !29
  %t93 = load i32, ptr %l46, !tbaa !23
  %t94 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisNumberLike(ptr %v0, ptr %t92, i32 %t93)
  store i1 %t94, ptr %l47
  br label %bb22
bb22:
  %t95 = load i1, ptr %l47, !tbaa !21
  store i1 %t95, ptr %rv
  br label %ret
bb23:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisParamVar(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, [1 x i64] } %a1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_f39b1bd504b33948_8115a077853ab66c)
  unreachable
bb9:
  %t6 = load i1, ptr %l2, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekeepParam(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i1
  %l14 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i1
  %l23 = alloca i64
  %l26 = alloca i64
  %l28 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i1
  %l33 = alloca ptr
  %l42 = alloca %"compiler/typed:Local"
  %l44 = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp sge i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l5, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/scope:Scoper", ptr %t6, i32 0, i32 91
  %t10 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l8
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb4
bb3:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  store i1 %t13, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l4, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/scope:Scoper", ptr %t16, i32 0, i32 91
  %t19 = load i64, ptr %l1, !tbaa !24
  %t22 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t18, i64 %t19)
  store i64 %t22, ptr %l14
  br label %bb7
bb6:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb8
bb7:
  %t23 = load i64, ptr %l14, !tbaa !24
  %t24 = icmp sge i64 %t23, 0
  store i1 %t24, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l10, !tbaa !21
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/scope:Scoper", ptr %t27, i32 0, i32 91
  %t30 = load i64, ptr %l1, !tbaa !24
  %t33 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t29, i64 %t30)
  store i64 %t33, ptr %l19
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t34 = load i64, ptr %l19, !tbaa !24
  store i64 %t34, ptr %l1, !tbaa !24
  br label %bb12
bb12:
  %t35 = load i64, ptr %l1, !tbaa !24
  %t37 = icmp sge i64 %t35, 0
  br i1 %t37, label %bb13, label %bb14
bb13:
  %t39 = load i64, ptr %l1, !tbaa !24
  store i64 %t39, ptr %l23, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/scope:Scoper", ptr %t40, i32 0, i32 77
  %t44 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t42)
  store i64 %t44, ptr %l26
  br label %bb15
bb14:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb16
bb15:
  %t45 = load i64, ptr %l23, !tbaa !24
  %t46 = load i64, ptr %l26, !tbaa !24
  %t47 = icmp slt i64 %t45, %t46
  store i1 %t47, ptr %l22, !tbaa !21
  br label %bb16
bb16:
  %t49 = load i1, ptr %l22, !tbaa !21
  br i1 %t49, label %bb17, label %bb18
bb17:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load i64, ptr %l1, !tbaa !24
  %t54 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eregionKind(ptr %v0, ptr %t50, i64 %t51)
  store i1 %t54, ptr %l31
  br label %bb19
bb18:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb20
bb19:
  %t55 = load i1, ptr %l31, !tbaa !21
  store i1 %t55, ptr %l28, !tbaa !21
  br label %bb20
bb20:
  %t56 = load i1, ptr %l28, !tbaa !21
  br i1 %t56, label %bb21, label %bb22
bb21:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l33, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/scope:Scoper", ptr %t58, i32 0, i32 25
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = icmp eq ptr %t61, null
  br i1 %t63, label %bb23, label %bb24
bb22:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb28
bb23:
  call void @__olang_check_failed(ptr @olang_loc_707f747640e7de9_bc077dc74ca6c70d)
  unreachable
bb24:
  br label %bb25
bb25:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/scope:Scoper", ptr %t65, i32 0, i32 25
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t71 = getelementptr %"compiler/typed:Body", ptr %t68, i32 0, i32 7
  %t72 = load i64, ptr %l1, !tbaa !24
  %t75 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t71, i64 %t72)
  store %"compiler/typed:Local" %t75, ptr %l42
  br label %bb26
bb26:
  %t76 = getelementptr %"compiler/typed:Local", ptr %l42, i32 0, i32 2
  %t77 = load i32, ptr %t76, !tbaa !23
  %t78 = load ptr, ptr %l33, !tbaa !29
  %t80 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t78, i32 %t77)
  store i1 %t80, ptr %l44
  br label %bb27
bb27:
  %t81 = load i1, ptr %l44, !tbaa !21
  store i1 %t81, ptr %l32, !tbaa !21
  br label %bb28
bb28:
  %t82 = load i1, ptr %l32, !tbaa !21
  br i1 %t82, label %bb29, label %bb30
bb29:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/scope:Scoper", ptr %t83, i32 0, i32 77
  %t86 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t85, i64 %t86, i1 true)
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb32
bb32:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca i1
  %l29 = alloca i1
  %l37 = alloca i32
  %l41 = alloca { i64, ptr }
  %l44 = alloca ptr
  %l49 = alloca i32
  %l50 = alloca { i64, ptr }
  %l57 = alloca i64
  %l60 = alloca i64
  %l79 = alloca { i64, ptr }
  %l84 = alloca i64
  %l90 = alloca ptr
  %l93 = alloca i64
  %l96 = alloca i1
  %l99 = alloca i1
  %l100 = alloca i1
  %l101 = alloca ptr
  %l103 = alloca i32
  %l104 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca i1
  %l115 = alloca i1
  %l117 = alloca { i64, ptr }
  %l120 = alloca i1
  %l126 = alloca i1
  %l127 = alloca ptr
  %l128 = alloca i64
  %l132 = alloca i1
  %l135 = alloca i1
  %l138 = alloca i1
  %l139 = alloca i1
  %l140 = alloca ptr
  %l142 = alloca i32
  %l143 = alloca i1
  %l145 = alloca i1
  %l146 = alloca ptr
  %l148 = alloca i32
  %l149 = alloca i1
  %l152 = alloca ptr
  %l153 = alloca i1
  %l160 = alloca i1
  %l161 = alloca i1
  %l162 = alloca ptr
  %l166 = alloca i64
  %l168 = alloca i1
  %l178 = alloca i1
  %l182 = alloca i1
  %l189 = alloca ptr
  %l190 = alloca i1
  %l197 = alloca i1
  %l199 = alloca { i64, ptr }
  %l202 = alloca i1
  %l208 = alloca i1
  %l209 = alloca ptr
  %l210 = alloca i64
  %l214 = alloca i1
  %l218 = alloca i1
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t7 = load ptr, ptr %l21, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l21, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 2
  store i1 %t13, ptr %l22, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l22, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [1 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { ptr }, ptr %t17, i32 0, i32 0
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t25 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecapturingLambda(ptr %v0, ptr %v1, ptr %t21, ptr %t22)
  store i1 %t25, ptr %l29
  br label %bb6
bb6:
  %t26 = load i1, ptr %l29, !tbaa !21
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/scope:Scoper", ptr %t27, i32 0, i32 108
  store i1 true, ptr %t29, !tbaa !21
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwExpr(ptr %v0, ptr %v1, ptr %t30, ptr %t31, i1 false)
  br label %bb10
bb10:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/scope:Scoper", ptr %t35, i32 0, i32 108
  store i1 false, ptr %t37, !tbaa !21
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_c0ef91a3e2c3a370_7d348321302c732c)
  unreachable
bb16:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t42 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %t38, ptr %t39)
  store i32 %t42, ptr %l37
  br label %bb17
bb17:
  %t43 = load i32, ptr %l37, !tbaa !23
  store i32 %t43, ptr %l4, !tbaa !23
  %t44 = load i32, ptr %l4, !tbaa !23
  %t45 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t48 = icmp ne i32 %t44, %t45
  br i1 %t48, label %bb18, label %bb19
bb18:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/scope:Scoper", ptr %t50, i32 0, i32 0
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  store ptr %t55, ptr %l44, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/scope:Scoper", ptr %t56, i32 0, i32 0
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  %t62 = load i32, ptr %l4, !tbaa !23
  %t65 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t61, i32 %t62)
  store i32 %t65, ptr %l49
  br label %bb20
bb19:
  store { i64, ptr } { i64 0, ptr @.d7 }, ptr %l41, !tbaa !27
  br label %bb22
bb20:
  %t66 = load ptr, ptr %l44, !tbaa !29
  %t67 = load i32, ptr %l49, !tbaa !23
  %t68 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t66, i32 %t67)
  store { i64, ptr } %t68, ptr %l50
  br label %bb21
bb21:
  %t69 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t69, ptr %l41, !tbaa !27
  br label %bb22
bb22:
  %t70 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t70, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr %"compiler/typed:Call", ptr %t71, i32 0, i32 1
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t74, 0
  store i64 %t76, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t78 = load i64, ptr %l7, !tbaa !24
  %t79 = load i64, ptr %l6, !tbaa !24
  %t82 = icmp sgt i64 %t78, %t79
  br i1 %t82, label %bb23, label %bb24
bb23:
  %t84 = load i64, ptr %l8, !tbaa !24
  %t86 = icmp sgt i64 %t84, 0
  br i1 %t86, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb28
bb25:
  %t88 = load i64, ptr %l7, !tbaa !24
  %t89 = load i64, ptr %l6, !tbaa !24
  %t92 = sub i64 %t88, %t89
  %t93 = load i64, ptr %l8, !tbaa !24
  %t96 = add i64 %t92, %t93
  %t98 = sub i64 %t96, 1
  %t99 = load i64, ptr %l8, !tbaa !24
  %t102 = sdiv i64 %t98, %t99
  store i64 %t102, ptr %l60, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l60, !tbaa !24
  br label %bb27
bb27:
  %t104 = load i64, ptr %l60, !tbaa !24
  store i64 %t104, ptr %l57, !tbaa !24
  br label %bb28
bb28:
  %t105 = load i64, ptr %l57, !tbaa !24
  store i64 %t105, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s5
  %t106 = load i64, ptr %l10, !tbaa !24
  %t107 = load i64, ptr %l9, !tbaa !24
  %t110 = icmp slt i64 %t106, %t107
  %t112 = xor i1 %t110, true
  br i1 %t112, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb157
bb31:
  br label %bb32
bb32:
  %t114 = load i64, ptr %l6, !tbaa !24
  %t115 = load i64, ptr %l10, !tbaa !24
  %t116 = load i64, ptr %l8, !tbaa !24
  %t119 = mul i64 %t115, %t116
  %t122 = add i64 %t114, %t119
  store i64 %t122, ptr %l11, !tbaa !24
  %t124 = load ptr, ptr %l1, !tbaa !29
  %t126 = getelementptr %"compiler/typed:Call", ptr %t124, i32 0, i32 1
  %t127 = load { i64, ptr }, ptr %t126, !tbaa !27
  store { i64, ptr } %t127, ptr %l79, !tbaa !27
  %t128 = load i64, ptr %l11, !tbaa !24
  %t130 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr ptr, ptr %t131, i64 %t128
  %t133 = load ptr, ptr %t132, !tbaa !39
  store ptr %t133, ptr %l12, !tbaa !29
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load ptr, ptr %l12, !tbaa !29
  %t139 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehandedRegion(ptr %v0, ptr %v1, ptr %t135, ptr %t136)
  store i64 %t139, ptr %l84
  br label %bb33
bb33:
  %t140 = load i64, ptr %l84, !tbaa !24
  store i64 %t140, ptr %l13, !tbaa !24
  %t141 = load i64, ptr %l13, !tbaa !24
  %t143 = icmp slt i64 %t141, 0
  br i1 %t143, label %bb34, label %bb35
bb34:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load ptr, ptr %l12, !tbaa !29
  %t150 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %t145, ptr %t146)
  store ptr %t150, ptr %l90
  br label %bb36
bb35:
  br label %bb114
bb36:
  %t151 = load ptr, ptr %l90, !tbaa !29
  store ptr %t151, ptr %l14, !tbaa !29
  %t152 = load ptr, ptr %l14, !tbaa !29
  %t155 = call i64 @compiler_2fscope_2eflRootExpr(ptr %v1, ptr %t152)
  store i64 %t155, ptr %l93
  br label %bb37
bb37:
  %t156 = load i64, ptr %l93, !tbaa !24
  store i64 %t156, ptr %l15, !tbaa !24
  %t157 = load i64, ptr %l15, !tbaa !24
  %t159 = icmp sge i64 %t157, 0
  br i1 %t159, label %bb38, label %bb39
bb38:
  %t161 = load ptr, ptr %l14, !tbaa !29
  %t164 = call i1 @compiler_2fscope_2eflThroughRefExpr(ptr %v1, ptr %t161)
  store i1 %t164, ptr %l99
  br label %bb40
bb39:
  store i1 false, ptr %l96, !tbaa !21
  br label %bb41
bb40:
  %t165 = load i1, ptr %l99, !tbaa !21
  store i1 %t165, ptr %l96, !tbaa !21
  br label %bb41
bb41:
  %t166 = load i1, ptr %l96, !tbaa !21
  br i1 %t166, label %bb42, label %bb43
bb42:
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l101, !tbaa !29
  %t168 = load ptr, ptr %l14, !tbaa !29
  %t170 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t168)
  store i32 %t170, ptr %l103
  br label %bb44
bb43:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb46
bb44:
  %t171 = load ptr, ptr %l101, !tbaa !29
  %t172 = load i32, ptr %l103, !tbaa !23
  %t173 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t171, i32 %t172)
  store i1 %t173, ptr %l104
  br label %bb45
bb45:
  %t174 = load i1, ptr %l104, !tbaa !21
  store i1 %t174, ptr %l100, !tbaa !21
  br label %bb46
bb46:
  %t175 = load i1, ptr %l100, !tbaa !21
  br i1 %t175, label %bb47, label %bb48
bb47:
  %t176 = load ptr, ptr %l1, !tbaa !29
  %t178 = getelementptr %"compiler/typed:Call", ptr %t176, i32 0, i32 0
  %t179 = load ptr, ptr %t178, !tbaa !29
  store ptr %t179, ptr %l107, !tbaa !29
  store i1 false, ptr %l108, !tbaa !21
  %t182 = load ptr, ptr %l107, !tbaa !29
  %t183 = icmp ne ptr %t182, null
  br i1 %t183, label %bb49, label %bb50
bb48:
  br label %bb74
bb49:
  %t185 = load ptr, ptr %l107, !tbaa !29
  %t186 = load i64, ptr %t185
  %t188 = icmp eq i64 %t186, 2
  store i1 %t188, ptr %l108, !tbaa !21
  br label %bb50
bb50:
  %t189 = load i1, ptr %l108, !tbaa !21
  br i1 %t189, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb62
bb53:
  %t190 = load i64, ptr %l11, !tbaa !24
  %t191 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t191, 0
  %t196 = icmp slt i64 %t190, %t193
  br i1 %t196, label %bb54, label %bb55
bb54:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t199 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t199, ptr %l117, !tbaa !27
  %t200 = load i64, ptr %l11, !tbaa !24
  %t202 = getelementptr { i64, ptr }, ptr %l117, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !27
  %t204 = getelementptr i32, ptr %t203, i64 %t200
  %t205 = load i32, ptr %t204, !tbaa !33
  %t208 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreThrough(ptr %v0, ptr %t198, i32 %t205)
  store i1 %t208, ptr %l120
  br label %bb56
bb55:
  store i1 false, ptr %l115, !tbaa !21
  br label %bb57
bb56:
  %t209 = load i1, ptr %l120, !tbaa !21
  store i1 %t209, ptr %l115, !tbaa !21
  br label %bb57
bb57:
  %t210 = load i1, ptr %l115, !tbaa !21
  br i1 %t210, label %bb58, label %bb59
bb58:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t212 = load i64, ptr %l15, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreParam(ptr %v0, ptr %t211, i64 %t212, i1 true)
  br label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb61
bb61:
  br label %bb73
bb62:
  br i1 true, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb72
bb65:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load ptr, ptr %l1, !tbaa !29
  %t217 = load i64, ptr %l11, !tbaa !24
  %t221 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeStoresArg(ptr %v0, ptr %v1, ptr %t215, ptr %t216, i64 %t217)
  store i1 %t221, ptr %l126
  br label %bb66
bb66:
  %t222 = load i1, ptr %l126, !tbaa !21
  br i1 %t222, label %bb67, label %bb68
bb67:
  %t223 = load ptr, ptr %l0, !tbaa !29
  store ptr %t223, ptr %l127, !tbaa !29
  %t224 = load i64, ptr %l15, !tbaa !24
  store i64 %t224, ptr %l128, !tbaa !24
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load ptr, ptr %l1, !tbaa !29
  %t227 = load i64, ptr %l11, !tbaa !24
  %t231 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleePutsArg(ptr %v0, ptr %v1, ptr %t225, ptr %t226, i64 %t227)
  store i1 %t231, ptr %l132
  br label %bb69
bb68:
  br label %bb71
bb69:
  %t232 = load ptr, ptr %l127, !tbaa !29
  %t233 = load i64, ptr %l128, !tbaa !24
  %t234 = load i1, ptr %l132, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreParam(ptr %v0, ptr %t232, i64 %t233, i1 %t234)
  br label %bb70
bb70:
  br label %bb71
bb71:
  br label %bb73
bb72:
  call void @__olang_check_failed(ptr @olang_loc_bf024f3f8d6f4701_89fcb258d807f5dd)
  unreachable
bb73:
  br label %bb74
bb74:
  %t235 = load i64, ptr %l15, !tbaa !24
  %t237 = icmp sge i64 %t235, 0
  br i1 %t237, label %bb75, label %bb76
bb75:
  %t239 = load ptr, ptr %l14, !tbaa !29
  %t242 = call i1 @compiler_2fscope_2eflThroughRefExpr(ptr %v1, ptr %t239)
  store i1 %t242, ptr %l138
  br label %bb77
bb76:
  store i1 false, ptr %l135, !tbaa !21
  br label %bb78
bb77:
  %t243 = load i1, ptr %l138, !tbaa !21
  store i1 %t243, ptr %l135, !tbaa !21
  br label %bb78
bb78:
  %t244 = load i1, ptr %l135, !tbaa !21
  br i1 %t244, label %bb79, label %bb80
bb79:
  %t245 = load ptr, ptr %l0, !tbaa !29
  store ptr %t245, ptr %l140, !tbaa !29
  %t246 = load ptr, ptr %l14, !tbaa !29
  %t248 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t246)
  store i32 %t248, ptr %l142
  br label %bb81
bb80:
  store i1 false, ptr %l139, !tbaa !21
  br label %bb83
bb81:
  %t249 = load ptr, ptr %l140, !tbaa !29
  %t250 = load i32, ptr %l142, !tbaa !23
  %t251 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t249, i32 %t250)
  store i1 %t251, ptr %l143
  br label %bb82
bb82:
  %t252 = load i1, ptr %l143, !tbaa !21
  %t253 = xor i1 %t252, true
  store i1 %t253, ptr %l139, !tbaa !21
  br label %bb83
bb83:
  %t255 = load i1, ptr %l139, !tbaa !21
  br i1 %t255, label %bb84, label %bb85
bb84:
  %t256 = load ptr, ptr %l0, !tbaa !29
  store ptr %t256, ptr %l146, !tbaa !29
  %t257 = load ptr, ptr %l14, !tbaa !29
  %t259 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t257)
  store i32 %t259, ptr %l148
  br label %bb86
bb85:
  store i1 false, ptr %l145, !tbaa !21
  br label %bb88
bb86:
  %t260 = load ptr, ptr %l146, !tbaa !29
  %t261 = load i32, ptr %l148, !tbaa !23
  %t262 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreThrough(ptr %v0, ptr %t260, i32 %t261)
  store i1 %t262, ptr %l149
  br label %bb87
bb87:
  %t263 = load i1, ptr %l149, !tbaa !21
  store i1 %t263, ptr %l145, !tbaa !21
  br label %bb88
bb88:
  %t264 = load i1, ptr %l145, !tbaa !21
  br i1 %t264, label %bb89, label %bb90
bb89:
  %t265 = load ptr, ptr %l1, !tbaa !29
  %t267 = getelementptr %"compiler/typed:Call", ptr %t265, i32 0, i32 0
  %t268 = load ptr, ptr %t267, !tbaa !29
  store ptr %t268, ptr %l152, !tbaa !29
  store i1 false, ptr %l153, !tbaa !21
  %t271 = load ptr, ptr %l152, !tbaa !29
  %t272 = icmp ne ptr %t271, null
  br i1 %t272, label %bb91, label %bb92
bb90:
  br label %bb103
bb91:
  %t274 = load ptr, ptr %l152, !tbaa !29
  %t275 = load i64, ptr %t274
  %t277 = icmp eq i64 %t275, 2
  store i1 %t277, ptr %l153, !tbaa !21
  br label %bb92
bb92:
  %t278 = load i1, ptr %l153, !tbaa !21
  br i1 %t278, label %bb93, label %bb94
bb93:
  br label %bb95
bb94:
  br label %bb97
bb95:
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t280 = load i64, ptr %l15, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreParam(ptr %v0, ptr %t279, i64 %t280, i1 true)
  br label %bb96
bb96:
  br label %bb102
bb97:
  br i1 true, label %bb98, label %bb99
bb98:
  br label %bb100
bb99:
  br label %bb101
bb100:
  br label %bb102
bb101:
  call void @__olang_check_failed(ptr @olang_loc_791e790d87101aea_cc84b762fb4c0ac6)
  unreachable
bb102:
  br label %bb103
bb103:
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t284 = load ptr, ptr %l12, !tbaa !29
  %t287 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecapturingLambda(ptr %v0, ptr %v1, ptr %t283, ptr %t284)
  store i1 %t287, ptr %l160
  br label %bb104
bb104:
  %t288 = load i1, ptr %l160, !tbaa !21
  br i1 %t288, label %bb105, label %bb106
bb105:
  %t289 = load ptr, ptr %l0, !tbaa !29
  store ptr %t289, ptr %l162, !tbaa !29
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t291 = load ptr, ptr %l1, !tbaa !29
  %t293 = getelementptr %"compiler/typed:Call", ptr %t291, i32 0, i32 0
  %t294 = load ptr, ptr %t293, !tbaa !29
  %t297 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebodyOf(ptr %v0, ptr %v1, ptr %t290, ptr %t294)
  store i64 %t297, ptr %l166
  br label %bb107
bb106:
  store i1 false, ptr %l161, !tbaa !21
  br label %bb109
bb107:
  %t298 = load i64, ptr %l11, !tbaa !24
  %t299 = load ptr, ptr %l162, !tbaa !29
  %t300 = load i64, ptr %l166, !tbaa !24
  %t302 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etransient(ptr %v0, ptr %t299, i64 %t300, i64 %t298)
  store i1 %t302, ptr %l168
  br label %bb108
bb108:
  %t303 = load i1, ptr %l168, !tbaa !21
  store i1 %t303, ptr %l161, !tbaa !21
  br label %bb109
bb109:
  %t304 = load i1, ptr %l161, !tbaa !21
  br i1 %t304, label %bb110, label %bb111
bb110:
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t307 = getelementptr %"compiler/scope:Scoper", ptr %t305, i32 0, i32 108
  store i1 true, ptr %t307, !tbaa !21
  br label %bb112
bb111:
  br label %bb112
bb112:
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t309 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwExpr(ptr %v0, ptr %v1, ptr %t308, ptr %t309, i1 false)
  br label %bb113
bb113:
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t315 = getelementptr %"compiler/scope:Scoper", ptr %t313, i32 0, i32 108
  store i1 false, ptr %t315, !tbaa !21
  call void @__olang_scope_close(ptr %s5)
  br label %bb156
bb114:
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t317 = load ptr, ptr %l1, !tbaa !29
  %t318 = load i64, ptr %l11, !tbaa !24
  %t319 = load ptr, ptr %l12, !tbaa !29
  %t324 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehandleLent(ptr %v0, ptr %v1, ptr %v1, ptr %t316, ptr %t317, i64 %t318, ptr %t319)
  store i1 %t324, ptr %l178
  br label %bb115
bb115:
  %t325 = load i1, ptr %l178, !tbaa !21
  br i1 %t325, label %bb116, label %bb117
bb116:
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t327 = load ptr, ptr %l1, !tbaa !29
  %t328 = load i64, ptr %l11, !tbaa !24
  %t332 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleePutsArg(ptr %v0, ptr %v1, ptr %t326, ptr %t327, i64 %t328)
  store i1 %t332, ptr %l182
  br label %bb118
bb117:
  br label %bb124
bb118:
  %t333 = load i1, ptr %l182, !tbaa !21
  br i1 %t333, label %bb119, label %bb120
bb119:
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t335 = load i64, ptr %l13, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreParam(ptr %v0, ptr %t334, i64 %t335, i1 true)
  br label %bb121
bb120:
  br label %bb122
bb121:
  br label %bb122
bb122:
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t339 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwHanded(ptr %v0, ptr %v1, ptr %t338, ptr %t339)
  br label %bb123
bb123:
  call void @__olang_scope_close(ptr %s5)
  br label %bb156
bb124:
  %t342 = load ptr, ptr %l1, !tbaa !29
  %t344 = getelementptr %"compiler/typed:Call", ptr %t342, i32 0, i32 0
  %t345 = load ptr, ptr %t344, !tbaa !29
  store ptr %t345, ptr %l189, !tbaa !29
  store i1 false, ptr %l190, !tbaa !21
  %t348 = load ptr, ptr %l189, !tbaa !29
  %t349 = icmp ne ptr %t348, null
  br i1 %t349, label %bb125, label %bb126
bb125:
  %t351 = load ptr, ptr %l189, !tbaa !29
  %t352 = load i64, ptr %t351
  %t354 = icmp eq i64 %t352, 2
  store i1 %t354, ptr %l190, !tbaa !21
  br label %bb126
bb126:
  %t355 = load i1, ptr %l190, !tbaa !21
  br i1 %t355, label %bb127, label %bb128
bb127:
  br label %bb129
bb128:
  br label %bb138
bb129:
  %t356 = load i64, ptr %l11, !tbaa !24
  %t357 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t359 = extractvalue { i64, ptr } %t357, 0
  %t362 = icmp slt i64 %t356, %t359
  br i1 %t362, label %bb130, label %bb131
bb130:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t365 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t365, ptr %l199, !tbaa !27
  %t366 = load i64, ptr %l11, !tbaa !24
  %t368 = getelementptr { i64, ptr }, ptr %l199, i32 0, i32 1
  %t369 = load ptr, ptr %t368, !tbaa !27
  %t370 = getelementptr i32, ptr %t369, i64 %t366
  %t371 = load i32, ptr %t370, !tbaa !33
  %t374 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreThrough(ptr %v0, ptr %t364, i32 %t371)
  store i1 %t374, ptr %l202
  br label %bb132
bb131:
  store i1 false, ptr %l197, !tbaa !21
  br label %bb133
bb132:
  %t375 = load i1, ptr %l202, !tbaa !21
  store i1 %t375, ptr %l197, !tbaa !21
  br label %bb133
bb133:
  %t376 = load i1, ptr %l197, !tbaa !21
  br i1 %t376, label %bb134, label %bb135
bb134:
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t378 = load i64, ptr %l13, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreParam(ptr %v0, ptr %t377, i64 %t378, i1 true)
  br label %bb136
bb135:
  br label %bb137
bb136:
  br label %bb137
bb137:
  br label %bb154
bb138:
  br i1 true, label %bb139, label %bb140
bb139:
  br label %bb141
bb140:
  br label %bb153
bb141:
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t382 = load ptr, ptr %l1, !tbaa !29
  %t383 = load i64, ptr %l11, !tbaa !24
  %t387 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeStoresArg(ptr %v0, ptr %v1, ptr %t381, ptr %t382, i64 %t383)
  store i1 %t387, ptr %l208
  br label %bb142
bb142:
  %t388 = load i1, ptr %l208, !tbaa !21
  br i1 %t388, label %bb143, label %bb144
bb143:
  %t389 = load ptr, ptr %l0, !tbaa !29
  store ptr %t389, ptr %l209, !tbaa !29
  %t390 = load i64, ptr %l13, !tbaa !24
  store i64 %t390, ptr %l210, !tbaa !24
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t392 = load ptr, ptr %l1, !tbaa !29
  %t393 = load i64, ptr %l11, !tbaa !24
  %t397 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleePutsArg(ptr %v0, ptr %v1, ptr %t391, ptr %t392, i64 %t393)
  store i1 %t397, ptr %l214
  br label %bb145
bb144:
  %t398 = load ptr, ptr %l0, !tbaa !29
  %t399 = load ptr, ptr %l1, !tbaa !29
  %t400 = load i64, ptr %l11, !tbaa !24
  %t404 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeKeepsArg(ptr %v0, ptr %v1, ptr %t398, ptr %t399, i64 %t400)
  store i1 %t404, ptr %l218
  br label %bb147
bb145:
  %t405 = load ptr, ptr %l209, !tbaa !29
  %t406 = load i64, ptr %l210, !tbaa !24
  %t407 = load i1, ptr %l214, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreParam(ptr %v0, ptr %t405, i64 %t406, i1 %t407)
  br label %bb146
bb146:
  br label %bb152
bb147:
  %t408 = load i1, ptr %l218, !tbaa !21
  br i1 %t408, label %bb148, label %bb149
bb148:
  %t409 = load ptr, ptr %l0, !tbaa !29
  %t410 = load i64, ptr %l13, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekeepParam(ptr %v0, ptr %t409, i64 %t410)
  br label %bb150
bb149:
  br label %bb151
bb150:
  br label %bb151
bb151:
  br label %bb152
bb152:
  br label %bb154
bb153:
  call void @__olang_check_failed(ptr @olang_loc_21c4adf4625d97ab_9350e01b86c380a7)
  unreachable
bb154:
  %t413 = load ptr, ptr %l0, !tbaa !29
  %t414 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwHanded(ptr %v0, ptr %v1, ptr %t413, ptr %t414)
  br label %bb155
bb155:
  call void @__olang_scope_close(ptr %s5)
  br label %bb156
bb156:
  %t417 = load i64, ptr %l10, !tbaa !24
  %t419 = add i64 %t417, 1
  store i64 %t419, ptr %l10, !tbaa !24
  br label %bb29
bb157:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwHanded(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t6 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %t1, ptr %a1)
  store ptr %t6, ptr %l8
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l8, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t8 = load ptr, ptr %l2, !tbaa !29
  store ptr %t8, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t9 = load ptr, ptr %l9, !tbaa !29
  %t10 = icmp ne ptr %t9, null
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l9, !tbaa !29
  %t13 = load i64, ptr %t12
  %t15 = icmp eq i64 %t13, 3
  store i1 %t15, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l10, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr { i64, [5 x i64] }, ptr %t17, i32 0, i32 1
  %t20 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t19, i32 0, i32 2
  %t21 = load ptr, ptr %t20
  store ptr %t21, ptr %l3, !tbaa !29
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwPlace(ptr %v0, ptr %v1, ptr %t23, ptr %t24)
  br label %bb7
bb7:
  br label %bb22
bb8:
  %t27 = load ptr, ptr %l2, !tbaa !29
  store ptr %t27, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t28 = load ptr, ptr %l17, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t31 = load ptr, ptr %l17, !tbaa !29
  %t32 = load i64, ptr %t31
  %t34 = icmp eq i64 %t32, 10
  store i1 %t34, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t35 = load i1, ptr %l18, !tbaa !21
  br i1 %t35, label %bb11, label %bb12
bb11:
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t38, i32 0, i32 2
  %t40 = load ptr, ptr %t39
  store ptr %t40, ptr %l4, !tbaa !29
  br label %bb13
bb12:
  br label %bb17
bb13:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l4, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Slice", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwPlace(ptr %v0, ptr %v1, ptr %t42, ptr %t46)
  br label %bb14
bb14:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t52 = getelementptr %"compiler/typed:Slice", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwExpr(ptr %v0, ptr %v1, ptr %t49, ptr %t53, i1 true)
  br label %bb15
bb15:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l4, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Slice", ptr %t58, i32 0, i32 2
  %t61 = load ptr, ptr %t60, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwExpr(ptr %v0, ptr %v1, ptr %t57, ptr %t61, i1 true)
  br label %bb16
bb16:
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_4f09217bbbe73e28_17ebc948c6ad3e44)
  unreachable
bb22:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elandHeld(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce"
  %l2 = alloca %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78"
  %l5 = alloca %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce"
  %l6 = alloca %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78"
  %l8 = alloca %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78"
  %l9 = alloca i32
  %l12 = alloca ptr
  %l14 = alloca ptr
  %l16 = alloca { i64, [2 x i64] }
  %l17 = alloca %"compiler/scope:Val"
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 38
  %t5 = call %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H7e82b4dbdb79c77bc51fdaf9d4704834(ptr %v0, ptr %v0, ptr %t3)
  store %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce", ptr %l5
  store %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" %t6, ptr %l1
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = call { i32, %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cI64_2c_20compiler_2ftyped_3aExpr_2_H4ea279ff901448a8d94a2f42aa119fd2(ptr %v0, ptr %v0, ptr %l1)
  %t9 = extractvalue { i32, %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" } %t8, 1
  %t10 = extractvalue { i32, %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" } %t8, 0
  store i32 %t10, ptr %l9
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb4, label %ok.12
ok.12:
  store %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" %t9, ptr %l8
  br label %bb3
bb3:
  %t13 = load %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78", ptr %l8
  store %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" %t13, ptr %l6
  br label %bb8
bb4:
  %t14 = load i32, ptr %l9, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  br i1 %t17, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_de693c9ff8852c0_d1c91c603b4bfa64)
  unreachable
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb8:
  %t19 = load %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78", ptr %l6
  store %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" %t19, ptr %l2
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l12, !tbaa !29
  %t21 = getelementptr %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78", ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  store ptr %t22, ptr %l14, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehere(ptr %v0, ptr %t24)
  store { i64, [2 x i64] } %t26, ptr %l16
  br label %bb9
bb9:
  %t27 = load ptr, ptr %l12, !tbaa !29
  %t28 = load ptr, ptr %l14, !tbaa !29
  %t29 = load { i64, [2 x i64] }, ptr %l16
  %t30 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v0, ptr %t27, ptr %t28, { i64, [2 x i64] } %t29)
  store %"compiler/scope:Val" %t30, ptr %l17
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  br label %bb2
bb12:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elentLoopCopy(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l24 = alloca i1
  %l25 = alloca i1
  %l26 = alloca ptr
  %l36 = alloca %"compiler/typed:Local"
  %l38 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t6 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %t1, ptr %a1)
  store ptr %t6, ptr %l8
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l8, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t8 = load ptr, ptr %l2, !tbaa !29
  store ptr %t8, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t9 = load ptr, ptr %l9, !tbaa !29
  %t10 = icmp ne ptr %t9, null
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l9, !tbaa !29
  %t13 = load i64, ptr %t12
  %t15 = icmp eq i64 %t13, 3
  store i1 %t15, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l10, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr { i64, [5 x i64] }, ptr %t17, i32 0, i32 1
  %t20 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t19, i32 0, i32 2
  %t21 = load ptr, ptr %t20
  store ptr %t21, ptr %l3, !tbaa !29
  br label %bb6
bb5:
  br label %bb27
bb6:
  %t23 = load ptr, ptr %l3, !tbaa !29
  store ptr %t23, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t24 = load ptr, ptr %l15, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb7, label %bb8
bb7:
  %t27 = load ptr, ptr %l15, !tbaa !29
  %t28 = load i64, ptr %t27
  %t30 = icmp eq i64 %t28, 0
  store i1 %t30, ptr %l16, !tbaa !21
  br label %bb8
bb8:
  %t31 = load i1, ptr %l16, !tbaa !21
  br i1 %t31, label %bb9, label %bb10
bb9:
  %t32 = load ptr, ptr %l3, !tbaa !29
  %t34 = getelementptr { i64, [4 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t34, i32 0, i32 2
  %t36 = load i32, ptr %t35
  store i32 %t36, ptr %l4, !tbaa !23
  br label %bb11
bb10:
  br label %bb21
bb11:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i32, ptr %l4, !tbaa !23
  %t41 = sext i32 %t39 to i64
  %t44 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eloopElement(ptr %v0, ptr %t38, i64 %t41)
  store i1 %t44, ptr %l24
  br label %bb12
bb12:
  %t45 = load i1, ptr %l24, !tbaa !21
  br i1 %t45, label %bb13, label %bb14
bb13:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l26, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/scope:Scoper", ptr %t47, i32 0, i32 25
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = icmp eq ptr %t50, null
  br i1 %t52, label %bb15, label %bb16
bb14:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb20
bb15:
  call void @__olang_check_failed(ptr @olang_loc_42ddfa07d54a3511_7eb6b931dfed5aa5)
  unreachable
bb16:
  br label %bb17
bb17:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/scope:Scoper", ptr %t54, i32 0, i32 25
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Body", ptr %t57, i32 0, i32 7
  %t61 = load i32, ptr %l4, !tbaa !23
  %t63 = sext i32 %t61 to i64
  %t66 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t60, i64 %t63)
  store %"compiler/typed:Local" %t66, ptr %l36
  br label %bb18
bb18:
  %t67 = getelementptr %"compiler/typed:Local", ptr %l36, i32 0, i32 2
  %t68 = load i32, ptr %t67, !tbaa !23
  %t69 = load ptr, ptr %l26, !tbaa !29
  %t71 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t69, i32 %t68)
  store i1 %t71, ptr %l38
  br label %bb19
bb19:
  %t72 = load i1, ptr %l38, !tbaa !21
  %t73 = xor i1 %t72, true
  store i1 %t73, ptr %l25, !tbaa !21
  br label %bb20
bb20:
  %t75 = load i1, ptr %l25, !tbaa !21
  store i1 %t75, ptr %rv
  br label %ret
bb21:
  br i1 true, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_133169b3f1711469_c566838c26ef218d)
  unreachable
bb26:
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_31030507f1509b32_81bbcae78c23c7f6)
  unreachable
bb32:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eloopElement(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/typed:Local"
  %l3 = alloca %"compiler/typed:BlockInfo"
  %l12 = alloca %"compiler/typed:Local"
  %l16 = alloca i1
  %l20 = alloca i1
  %l22 = alloca i64
  %l30 = alloca i64
  %l42 = alloca %"compiler/typed:BlockInfo"
  %l45 = alloca i1
  %l49 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 25
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_406ffa91c23643d5_a8a413026b137651)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 25
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 7
  %t18 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t14, i64 %a1)
  store %"compiler/typed:Local" %t18, ptr %l12
  br label %bb4
bb4:
  %t19 = load %"compiler/typed:Local", ptr %l12
  store %"compiler/typed:Local" %t19, ptr %l2
  %t20 = getelementptr %"compiler/typed:Local", ptr %l2, i32 0, i32 4
  %t21 = load i32, ptr %t20
  %t23 = trunc i64 1 to i32
  %t24 = icmp eq i32 %t21, %t23
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb7
bb6:
  %t28 = getelementptr %"compiler/typed:Local", ptr %l2, i32 0, i32 3
  %t29 = load i32, ptr %t28, !tbaa !23
  %t31 = sext i32 %t29 to i64
  %t33 = icmp sle i64 %t31, 0
  store i1 %t33, ptr %l16, !tbaa !21
  br label %bb7
bb7:
  %t35 = load i1, ptr %l16, !tbaa !21
  br i1 %t35, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb14
bb9:
  %t36 = getelementptr %"compiler/typed:Local", ptr %l2, i32 0, i32 3
  %t37 = load i32, ptr %t36, !tbaa !23
  %t39 = sext i32 %t37 to i64
  store i64 %t39, ptr %l22, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/scope:Scoper", ptr %t40, i32 0, i32 25
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = icmp eq ptr %t43, null
  br i1 %t45, label %bb10, label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_a53dc1127e8f642e_8cd05a2a2a6c7d4a)
  unreachable
bb11:
  br label %bb12
bb12:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/scope:Scoper", ptr %t47, i32 0, i32 25
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t53 = getelementptr %"compiler/typed:Body", ptr %t50, i32 0, i32 8
  %t55 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e_2eL_H5b8a0bc03aecb48440b685dbbc0b269c(ptr %v0, ptr %t53)
  store i64 %t55, ptr %l30
  br label %bb13
bb13:
  %t56 = load i64, ptr %l22, !tbaa !24
  %t57 = load i64, ptr %l30, !tbaa !24
  %t58 = icmp sge i64 %t56, %t57
  store i1 %t58, ptr %l20, !tbaa !21
  br label %bb14
bb14:
  %t60 = load i1, ptr %l20, !tbaa !21
  br i1 %t60, label %bb15, label %bb16
bb15:
  store i1 false, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/scope:Scoper", ptr %t62, i32 0, i32 25
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = icmp eq ptr %t65, null
  br i1 %t67, label %bb18, label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_ce604c7c8d78c55f_37d65431cab9ef4b)
  unreachable
bb19:
  br label %bb20
bb20:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/scope:Scoper", ptr %t69, i32 0, i32 25
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t75 = getelementptr %"compiler/typed:Body", ptr %t72, i32 0, i32 8
  %t76 = getelementptr %"compiler/typed:Local", ptr %l2, i32 0, i32 3
  %t77 = load i32, ptr %t76, !tbaa !23
  %t79 = sext i32 %t77 to i64
  %t82 = call %"compiler/typed:BlockInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e_2eA_Hdb91c1ab6f912bb6141763aa02d0b766(ptr %v0, ptr %t75, i64 %t79)
  store %"compiler/typed:BlockInfo" %t82, ptr %l42
  br label %bb21
bb21:
  %t83 = load %"compiler/typed:BlockInfo", ptr %l42
  store %"compiler/typed:BlockInfo" %t83, ptr %l3
  %t84 = getelementptr %"compiler/typed:BlockInfo", ptr %l3, i32 0, i32 1
  %t85 = load i32, ptr %t84
  %t87 = trunc i64 2 to i32
  %t88 = icmp eq i32 %t85, %t87
  br i1 %t88, label %bb22, label %bb23
bb22:
  %t90 = getelementptr %"compiler/typed:BlockInfo", ptr %l3, i32 0, i32 2
  %t91 = getelementptr %"compiler/source:Span", ptr %t90, i32 0, i32 0
  %t92 = load i32, ptr %t91, !tbaa !23
  %t93 = getelementptr %"compiler/typed:Local", ptr %l2, i32 0, i32 1
  %t94 = getelementptr %"compiler/source:Span", ptr %t93, i32 0, i32 0
  %t95 = load i32, ptr %t94, !tbaa !23
  %t98 = icmp eq i32 %t92, %t95
  store i1 %t98, ptr %l45, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb24
bb24:
  %t100 = load i1, ptr %l45, !tbaa !21
  br i1 %t100, label %bb25, label %bb26
bb25:
  %t101 = getelementptr %"compiler/typed:BlockInfo", ptr %l3, i32 0, i32 2
  %t102 = getelementptr %"compiler/source:Span", ptr %t101, i32 0, i32 1
  %t103 = load i32, ptr %t102, !tbaa !23
  %t104 = getelementptr %"compiler/typed:Local", ptr %l2, i32 0, i32 1
  %t105 = getelementptr %"compiler/source:Span", ptr %t104, i32 0, i32 1
  %t106 = load i32, ptr %t105, !tbaa !23
  %t109 = icmp eq i32 %t103, %t106
  store i1 %t109, ptr %l49, !tbaa !21
  br label %bb27
bb26:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb27
bb27:
  %t111 = load i1, ptr %l49, !tbaa !21
  store i1 %t111, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ematchMadeHere(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l25 = alloca i1
  %l29 = alloca i1
  %l42 = alloca i1
  %l43 = alloca ptr
  %l51 = alloca i1
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Match", ptr %t1, i32 0, i32 3
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Match", ptr %t9, i32 0, i32 1
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  store { i64, ptr } %t12, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  store i64 %t16, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t18 = load i64, ptr %l3, !tbaa !24
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = icmp slt i64 %t18, %t19
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb6:
  br label %bb7
bb7:
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l18, !tbaa !27
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr ptr, ptr %t30, i64 %t27
  %t32 = load ptr, ptr %t31, !tbaa !39
  store ptr %t32, ptr %l5, !tbaa !29
  %t34 = load ptr, ptr %l5, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Arm", ptr %t34, i32 0, i32 4
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb8, label %bb9
bb8:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l5, !tbaa !29
  %t46 = getelementptr %"compiler/typed:Arm", ptr %t44, i32 0, i32 4
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t50 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeHere(ptr %v0, ptr %v1, ptr %t43, ptr %t47)
  store i1 %t50, ptr %l29
  br label %bb10
bb9:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb11
bb10:
  %t51 = load i1, ptr %l29, !tbaa !21
  %t52 = xor i1 %t51, true
  store i1 %t52, ptr %l25, !tbaa !21
  br label %bb11
bb11:
  %t54 = load i1, ptr %l25, !tbaa !21
  br i1 %t54, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  store i1 false, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  %t56 = load i64, ptr %l3, !tbaa !24
  %t58 = add i64 %t56, 1
  store i64 %t58, ptr %l3, !tbaa !24
  br label %bb4
bb16:
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Match", ptr %t60, i32 0, i32 2
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = icmp eq ptr %t63, null
  br i1 %t65, label %bb17, label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_bfbb893df1c35f5d_ebb7b8931b043491)
  unreachable
bb18:
  br label %bb19
bb19:
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t69 = getelementptr %"compiler/typed:Match", ptr %t67, i32 0, i32 2
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t73 = getelementptr %"compiler/typed:Arm", ptr %t70, i32 0, i32 4
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = icmp eq ptr %t74, null
  br i1 %t76, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb26
bb21:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l43, !tbaa !29
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Match", ptr %t79, i32 0, i32 2
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = icmp eq ptr %t82, null
  br i1 %t84, label %bb22, label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_bfbb893df1c35f5d_ebb7b8931b043491)
  unreachable
bb23:
  br label %bb24
bb24:
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr %"compiler/typed:Match", ptr %t86, i32 0, i32 2
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Arm", ptr %t89, i32 0, i32 4
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t94 = load ptr, ptr %l43, !tbaa !29
  %t96 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeHere(ptr %v0, ptr %v1, ptr %t94, ptr %t93)
  store i1 %t96, ptr %l51
  br label %bb25
bb25:
  %t97 = load i1, ptr %l51, !tbaa !21
  store i1 %t97, ptr %l42, !tbaa !21
  br label %bb26
bb26:
  %t98 = load i1, ptr %l42, !tbaa !21
  store i1 %t98, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enewOrConst(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l10 = alloca i1
  %l11 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i1
  %l20 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l34 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l44 = alloca i1
  %l45 = alloca i1
  %l50 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t11 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %t6, ptr %t7)
  store i1 %t11, ptr %l10
  br label %bb4
bb4:
  %t12 = load i1, ptr %l10, !tbaa !21
  br i1 %t12, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb8
bb6:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t17 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisNullLit(ptr %v0, ptr %v1, ptr %t13, ptr %t14)
  store i1 %t17, ptr %l14
  br label %bb7
bb7:
  %t18 = load i1, ptr %l14, !tbaa !21
  store i1 %t18, ptr %l11, !tbaa !21
  br label %bb8
bb8:
  %t19 = load i1, ptr %l11, !tbaa !21
  br i1 %t19, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb12
bb10:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t24 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estaticLiteral(ptr %v0, ptr %v1, ptr %t20, ptr %t21)
  store i1 %t24, ptr %l18
  br label %bb11
bb11:
  %t25 = load i1, ptr %l18, !tbaa !21
  store i1 %t25, ptr %l15, !tbaa !21
  br label %bb12
bb12:
  %t26 = load i1, ptr %l15, !tbaa !21
  br i1 %t26, label %bb13, label %bb14
bb13:
  store i1 true, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t29 = load ptr, ptr %l21, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb16, label %bb17
bb16:
  %t32 = load ptr, ptr %l21, !tbaa !29
  %t33 = load i64, ptr %t32
  %t35 = icmp eq i64 %t33, 1
  store i1 %t35, ptr %l22, !tbaa !21
  br label %bb17
bb17:
  %t36 = load i1, ptr %l22, !tbaa !21
  br i1 %t36, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb44
bb21:
  %t37 = load ptr, ptr %l1, !tbaa !29
  store ptr %t37, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t38 = load ptr, ptr %l25, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb22, label %bb23
bb22:
  %t41 = load ptr, ptr %l25, !tbaa !29
  %t42 = load i64, ptr %t41
  %t44 = icmp eq i64 %t42, 17
  store i1 %t44, ptr %l26, !tbaa !21
  br label %bb23
bb23:
  %t45 = load i1, ptr %l26, !tbaa !21
  br i1 %t45, label %bb24, label %bb25
bb24:
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr { i64, [5 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t48, i32 0, i32 2
  %t50 = load ptr, ptr %t49
  store ptr %t50, ptr %l2, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t57 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enewOrConst(ptr %v0, ptr %v1, ptr %t52, ptr %t53)
  store i1 %t57, ptr %l34
  br label %bb27
bb27:
  %t58 = load i1, ptr %l34, !tbaa !21
  store i1 %t58, ptr %l20, !tbaa !21
  br label %bb44
bb28:
  %t59 = load ptr, ptr %l1, !tbaa !29
  store ptr %t59, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t60 = load ptr, ptr %l35, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb29, label %bb30
bb29:
  %t63 = load ptr, ptr %l35, !tbaa !29
  %t64 = load i64, ptr %t63
  %t66 = icmp eq i64 %t64, 11
  store i1 %t66, ptr %l36, !tbaa !21
  br label %bb30
bb30:
  %t67 = load i1, ptr %l36, !tbaa !21
  br i1 %t67, label %bb31, label %bb32
bb31:
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [5 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t70, i32 0, i32 2
  %t72 = load ptr, ptr %t71
  store ptr %t72, ptr %l3, !tbaa !29
  br label %bb33
bb32:
  br label %bb39
bb33:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load ptr, ptr %l3, !tbaa !29
  %t77 = getelementptr %"compiler/typed:Cond", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t81 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enewOrConst(ptr %v0, ptr %v1, ptr %t74, ptr %t78)
  store i1 %t81, ptr %l44
  br label %bb34
bb34:
  %t82 = load i1, ptr %l44, !tbaa !21
  br i1 %t82, label %bb35, label %bb36
bb35:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l3, !tbaa !29
  %t86 = getelementptr %"compiler/typed:Cond", ptr %t84, i32 0, i32 2
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t91 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enewOrConst(ptr %v0, ptr %v1, ptr %t83, ptr %t87)
  store i1 %t91, ptr %l50
  br label %bb37
bb36:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb38
bb37:
  %t92 = load i1, ptr %l50, !tbaa !21
  store i1 %t92, ptr %l45, !tbaa !21
  br label %bb38
bb38:
  %t93 = load i1, ptr %l45, !tbaa !21
  store i1 %t93, ptr %l20, !tbaa !21
  br label %bb44
bb39:
  br i1 true, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_13609328335a5af4_71f6842a5be0a9a0)
  unreachable
bb44:
  %t94 = load i1, ptr %l20, !tbaa !21
  store i1 %t94, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteMadeNamed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, i64 %a3, { i64, ptr } %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca %"compiler/typed:Local"
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l23 = alloca %"compiler/source:Span"
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l28 = alloca i1
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i32
  %l32 = alloca i64
  %l34 = alloca { i64, ptr }
  %l37 = alloca i1
  %l43 = alloca ptr
  %l47 = alloca i64
  %l50 = alloca i64
  %l68 = alloca ptr
  %l69 = alloca i1
  %l78 = alloca ptr
  %l79 = alloca ptr
  %l80 = alloca i1
  %l87 = alloca ptr
  %l88 = alloca i1
  %l93 = alloca ptr
  %l94 = alloca i1
  %l102 = alloca ptr
  %l108 = alloca ptr
  %l112 = alloca i1
  %l115 = alloca ptr
  %l118 = alloca i32
  %l119 = alloca i64
  %l122 = alloca i1
  %l129 = alloca i1
  %l133 = alloca i64
  %l136 = alloca i1
  %l148 = alloca %"compiler/typed:Local"
  %l151 = alloca i1
  %l154 = alloca i1
  %l165 = alloca { i64, ptr }
  %l169 = alloca %"compiler/source:Span"
  %l170 = alloca ptr
  %l174 = alloca ptr
  %l175 = alloca i32
  %l179 = alloca ptr
  %l183 = alloca ptr
  %l187 = alloca i1
  %l190 = alloca ptr
  %l193 = alloca i32
  %l194 = alloca i64
  %l203 = alloca i1
  %l206 = alloca i1
  %l207 = alloca i1
  %l210 = alloca i1
  %l213 = alloca { i64, ptr }
  %l216 = alloca i1
  %l222 = alloca i1
  %l224 = alloca i1
  %l225 = alloca ptr
  %l228 = alloca i32
  %l229 = alloca i64
  %l231 = alloca ptr
  %l232 = alloca i64
  %l239 = alloca i64
  %l240 = alloca %"compiler/source:Span"
  %l245 = alloca %"compiler/msgs:Msg"
  %l251 = alloca i32
  %l254 = alloca i1
  %l256 = alloca i1
  %l259 = alloca i1
  %l261 = alloca i1
  %l265 = alloca i1
  %l274 = alloca i1
  %l275 = alloca i32
  %l280 = alloca i32
  %l285 = alloca i64
  %l288 = alloca i1
  %l291 = alloca ptr
  %l295 = alloca i32
  %l296 = alloca { i64, ptr }
  %l300 = alloca ptr
  %l301 = alloca i32
  %l305 = alloca i64
  %l306 = alloca i64
  %l310 = alloca i32
  %l311 = alloca i32
  %l322 = alloca i1
  %l323 = alloca i1
  %l328 = alloca i64
  %l333 = alloca i1
  %l336 = alloca i1
  %l338 = alloca { i64, ptr }
  %l342 = alloca { i64, ptr }
  %l344 = alloca ptr
  %l345 = alloca i64
  %l352 = alloca i64
  %l353 = alloca %"compiler/source:Span"
  %l359 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s22 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l5, !tbaa !24
  %t3 = icmp sgt i64 %t1, 8
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  store i1 %t7, ptr %l37, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l37, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  br label %bb6
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t15 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %t10, ptr %t11)
  store ptr %t15, ptr %l43
  br label %bb7
bb7:
  %t16 = load ptr, ptr %l43, !tbaa !29
  store ptr %t16, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  store i64 16, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t17 = load i64, ptr %l8, !tbaa !24
  %t18 = load i64, ptr %l7, !tbaa !24
  %t21 = icmp sgt i64 %t17, %t18
  br i1 %t21, label %bb8, label %bb9
bb8:
  %t23 = load i64, ptr %l9, !tbaa !24
  %t25 = icmp sgt i64 %t23, 0
  br i1 %t25, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb13
bb10:
  %t27 = load i64, ptr %l8, !tbaa !24
  %t28 = load i64, ptr %l7, !tbaa !24
  %t31 = sub i64 %t27, %t28
  %t32 = load i64, ptr %l9, !tbaa !24
  %t35 = add i64 %t31, %t32
  %t37 = sub i64 %t35, 1
  %t38 = load i64, ptr %l9, !tbaa !24
  %t41 = sdiv i64 %t37, %t38
  store i64 %t41, ptr %l50, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l50, !tbaa !24
  br label %bb12
bb12:
  %t43 = load i64, ptr %l50, !tbaa !24
  store i64 %t43, ptr %l47, !tbaa !24
  br label %bb13
bb13:
  %t44 = load i64, ptr %l47, !tbaa !24
  store i64 %t44, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t45 = load i64, ptr %l11, !tbaa !24
  %t46 = load i64, ptr %l10, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb60
bb16:
  br label %bb17
bb17:
  %t53 = load i64, ptr %l7, !tbaa !24
  %t54 = load i64, ptr %l11, !tbaa !24
  %t55 = load i64, ptr %l9, !tbaa !24
  %t58 = mul i64 %t54, %t55
  %t61 = add i64 %t53, %t58
  store i64 %t61, ptr %l12, !tbaa !24
  %t63 = load ptr, ptr %l6, !tbaa !29
  store ptr %t63, ptr %l68, !tbaa !29
  store i1 false, ptr %l69, !tbaa !21
  %t64 = load ptr, ptr %l68, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb18, label %bb19
bb18:
  %t67 = load ptr, ptr %l68, !tbaa !29
  %t68 = load i64, ptr %t67
  %t70 = icmp eq i64 %t68, 5
  store i1 %t70, ptr %l69, !tbaa !21
  br label %bb19
bb19:
  %t71 = load i1, ptr %l69, !tbaa !21
  br i1 %t71, label %bb20, label %bb21
bb20:
  %t72 = load ptr, ptr %l6, !tbaa !29
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 2
  %t76 = load ptr, ptr %t75
  store ptr %t76, ptr %l13, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load ptr, ptr %l13, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Promote", ptr %t79, i32 0, i32 0
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t86 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %t78, ptr %t82)
  store ptr %t86, ptr %l78
  br label %bb23
bb23:
  %t87 = load ptr, ptr %l78, !tbaa !29
  store ptr %t87, ptr %l6, !tbaa !29
  br label %bb58
bb24:
  %t88 = load ptr, ptr %l6, !tbaa !29
  store ptr %t88, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t89 = load ptr, ptr %l79, !tbaa !29
  %t90 = icmp ne ptr %t89, null
  br i1 %t90, label %bb25, label %bb26
bb25:
  %t92 = load ptr, ptr %l79, !tbaa !29
  %t93 = load i64, ptr %t92
  %t95 = icmp eq i64 %t93, 2
  store i1 %t95, ptr %l80, !tbaa !21
  br label %bb26
bb26:
  %t96 = load i1, ptr %l80, !tbaa !21
  br i1 %t96, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l6, !tbaa !29
  %t99 = getelementptr { i64, [5 x i64] }, ptr %t97, i32 0, i32 1
  %t100 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t99, i32 0, i32 1
  %t101 = load i32, ptr %t100
  store i32 %t101, ptr %l14, !tbaa !23
  %t103 = load ptr, ptr %l6, !tbaa !29
  %t105 = getelementptr { i64, [5 x i64] }, ptr %t103, i32 0, i32 1
  %t106 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t105, i32 0, i32 2
  %t107 = load ptr, ptr %t106
  store ptr %t107, ptr %l15, !tbaa !29
  br label %bb29
bb28:
  br label %bb53
bb29:
  %t109 = load ptr, ptr %l15, !tbaa !29
  store ptr %t109, ptr %l87, !tbaa !29
  store i1 false, ptr %l88, !tbaa !21
  %t110 = load ptr, ptr %l87, !tbaa !29
  %t111 = icmp ne ptr %t110, null
  br i1 %t111, label %bb30, label %bb31
bb30:
  %t113 = load ptr, ptr %l87, !tbaa !29
  %t114 = load i64, ptr %t113
  %t116 = icmp eq i64 %t114, 3
  store i1 %t116, ptr %l88, !tbaa !21
  br label %bb31
bb31:
  %t117 = load i1, ptr %l88, !tbaa !21
  br i1 %t117, label %bb32, label %bb33
bb32:
  %t118 = load ptr, ptr %l15, !tbaa !29
  %t120 = getelementptr { i64, [4 x i64] }, ptr %t118, i32 0, i32 1
  %t121 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t120, i32 0, i32 2
  %t122 = load ptr, ptr %t121
  store ptr %t122, ptr %l16, !tbaa !29
  br label %bb34
bb33:
  br label %bb47
bb34:
  %t124 = load ptr, ptr %l16, !tbaa !29
  store ptr %t124, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t125 = load ptr, ptr %l93, !tbaa !29
  %t126 = icmp ne ptr %t125, null
  br i1 %t126, label %bb35, label %bb36
bb35:
  %t128 = load ptr, ptr %l93, !tbaa !29
  %t129 = load i64, ptr %t128
  %t131 = icmp eq i64 %t129, 6
  store i1 %t131, ptr %l94, !tbaa !21
  br label %bb36
bb36:
  %t132 = load i1, ptr %l94, !tbaa !21
  br i1 %t132, label %bb37, label %bb38
bb37:
  %t133 = load ptr, ptr %l16, !tbaa !29
  %t135 = getelementptr { i64, [4 x i64] }, ptr %t133, i32 0, i32 1
  %t136 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t135, i32 0, i32 2
  %t137 = load ptr, ptr %t136
  store ptr %t137, ptr %l17, !tbaa !29
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load ptr, ptr %l17, !tbaa !29
  %t144 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %t139, ptr %t140)
  store ptr %t144, ptr %l102
  br label %bb40
bb40:
  %t145 = load ptr, ptr %l102, !tbaa !29
  store ptr %t145, ptr %l6, !tbaa !29
  br label %bb46
bb41:
  br i1 true, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  call void @__olang_scope_close(ptr %s3)
  br label %bb60
bb45:
  call void @__olang_check_failed(ptr @olang_loc_2a83bf20490fb4f0_b79be661c23cb1e4)
  unreachable
bb46:
  br label %bb52
bb47:
  br i1 true, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb51
bb50:
  call void @__olang_scope_close(ptr %s3)
  br label %bb60
bb51:
  call void @__olang_check_failed(ptr @olang_loc_28967cbbf3bb5881_fc5c9419ee26cbd5)
  unreachable
bb52:
  br label %bb58
bb53:
  br i1 true, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb57
bb56:
  call void @__olang_scope_close(ptr %s3)
  br label %bb60
bb57:
  call void @__olang_check_failed(ptr @olang_loc_e2b2a689ed5c2c6a_2e02b8bd326f399e)
  unreachable
bb58:
  call void @__olang_scope_close(ptr %s3)
  br label %bb59
bb59:
  %t146 = load i64, ptr %l11, !tbaa !24
  %t148 = add i64 %t146, 1
  store i64 %t148, ptr %l11, !tbaa !24
  br label %bb14
bb60:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load ptr, ptr %l6, !tbaa !29
  %t155 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallOf(ptr %v0, ptr %v1, ptr %t150, ptr %t151)
  store ptr %t155, ptr %l108
  br label %bb61
bb61:
  %t156 = load ptr, ptr %l108, !tbaa !29
  store ptr %t156, ptr %l18, !tbaa !29
  %t157 = load ptr, ptr %l18, !tbaa !29
  %t159 = icmp eq ptr %t157, null
  %t161 = xor i1 %t159, true
  br i1 %t161, label %bb62, label %bb63
bb62:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/scope:Scoper", ptr %t163, i32 0, i32 0
  %t166 = load ptr, ptr %t165, !tbaa !29
  %t168 = getelementptr %"compiler/generic:Program", ptr %t166, i32 0, i32 2
  store ptr %t168, ptr %l115, !tbaa !29
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load ptr, ptr %l18, !tbaa !29
  %t173 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %t169, ptr %t170)
  store i32 %t173, ptr %l118
  br label %bb64
bb63:
  store i1 false, ptr %l112, !tbaa !21
  br label %bb66
bb64:
  %t174 = load ptr, ptr %l115, !tbaa !29
  %t175 = load i32, ptr %l118, !tbaa !23
  %t176 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t174, i32 %t175)
  store i64 %t176, ptr %l119
  br label %bb65
bb65:
  %t177 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t178 = load i64, ptr %l119, !tbaa !24
  %t180 = icmp ne i64 %t178, %t177
  store i1 %t180, ptr %l112, !tbaa !21
  br label %bb66
bb66:
  %t182 = load i1, ptr %l112, !tbaa !21
  br i1 %t182, label %bb67, label %bb68
bb67:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load i64, ptr %l1, !tbaa !24
  %t185 = load ptr, ptr %l18, !tbaa !29
  %t186 = load i64, ptr %l3, !tbaa !24
  %t187 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t188 = load i64, ptr %l5, !tbaa !24
  %t195 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteThroughResult(ptr %v0, ptr %v1, ptr %v2, ptr %t183, i64 %t184, ptr %t185, i64 %t186, { i64, ptr } %t187, i64 %t188)
  store i1 %t195, ptr %l129
  br label %bb69
bb68:
  store i1 false, ptr %l122, !tbaa !21
  br label %bb70
bb69:
  %t196 = load i1, ptr %l129, !tbaa !21
  store i1 %t196, ptr %l122, !tbaa !21
  br label %bb70
bb70:
  %t197 = load i1, ptr %l122, !tbaa !21
  br i1 %t197, label %bb71, label %bb72
bb71:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb72:
  br label %bb73
bb73:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t199 = load ptr, ptr %l2, !tbaa !29
  %t203 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeLocal(ptr %v0, ptr %v1, ptr %t198, ptr %t199, i64 0)
  store i64 %t203, ptr %l133
  br label %bb74
bb74:
  %t204 = load i64, ptr %l133, !tbaa !24
  store i64 %t204, ptr %l19, !tbaa !24
  %t205 = load i64, ptr %l19, !tbaa !24
  %t207 = icmp slt i64 %t205, 0
  br i1 %t207, label %bb75, label %bb76
bb75:
  store i1 true, ptr %l136, !tbaa !21
  br label %bb77
bb76:
  %t209 = load i64, ptr %l19, !tbaa !24
  %t210 = load i64, ptr %l3, !tbaa !24
  %t213 = icmp eq i64 %t209, %t210
  store i1 %t213, ptr %l136, !tbaa !21
  br label %bb77
bb77:
  %t215 = load i1, ptr %l136, !tbaa !21
  br i1 %t215, label %bb78, label %bb79
bb78:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb79:
  br label %bb80
bb80:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/scope:Scoper", ptr %t216, i32 0, i32 25
  %t219 = load ptr, ptr %t218, !tbaa !29
  %t221 = icmp eq ptr %t219, null
  br i1 %t221, label %bb81, label %bb82
bb81:
  call void @__olang_check_failed(ptr @olang_loc_9f5a8ccf03b4db04_630c918a623736e8)
  unreachable
bb82:
  br label %bb83
bb83:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/scope:Scoper", ptr %t223, i32 0, i32 25
  %t226 = load ptr, ptr %t225, !tbaa !29
  %t229 = getelementptr %"compiler/typed:Body", ptr %t226, i32 0, i32 7
  %t230 = load i64, ptr %l19, !tbaa !24
  %t233 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t229, i64 %t230)
  store %"compiler/typed:Local" %t233, ptr %l148
  br label %bb84
bb84:
  %t234 = load %"compiler/typed:Local", ptr %l148
  store %"compiler/typed:Local" %t234, ptr %l20
  %t235 = getelementptr %"compiler/typed:Local", ptr %l20, i32 0, i32 0
  %t236 = load i32, ptr %t235, !tbaa !23
  %t238 = icmp eq i32 %t236, 0
  br i1 %t238, label %bb85, label %bb86
bb85:
  store i1 true, ptr %l151, !tbaa !21
  br label %bb88
bb86:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load i64, ptr %l19, !tbaa !24
  %t244 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eloopElement(ptr %v0, ptr %t240, i64 %t241)
  store i1 %t244, ptr %l154
  br label %bb87
bb87:
  %t245 = load i1, ptr %l154, !tbaa !21
  store i1 %t245, ptr %l151, !tbaa !21
  br label %bb88
bb88:
  %t246 = load i1, ptr %l151, !tbaa !21
  br i1 %t246, label %bb89, label %bb90
bb89:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb90:
  br label %bb91
bb91:
  %t247 = getelementptr %"compiler/typed:Local", ptr %l20, i32 0, i32 4
  %t248 = load i32, ptr %t247
  store i32 %t248, ptr %l21
  %t250 = load i32, ptr %l21
  %t252 = trunc i64 1 to i32
  %t253 = icmp eq i32 %t250, %t252
  br i1 %t253, label %bb92, label %bb93
bb92:
  br label %bb96
bb93:
  %t255 = load i32, ptr %l21
  %t257 = trunc i64 4 to i32
  %t258 = icmp eq i32 %t255, %t257
  br i1 %t258, label %bb94, label %bb95
bb94:
  br label %bb96
bb95:
  br label %bb97
bb96:
  br label %bb102
bb97:
  br i1 true, label %bb98, label %bb99
bb98:
  br label %bb100
bb99:
  br label %bb101
bb100:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb101:
  call void @__olang_check_failed(ptr @olang_loc_f8891e21139a6c8c_91dd882c9f718fa8)
  unreachable
bb102:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t262 = getelementptr %"compiler/scope:Scoper", ptr %t260, i32 0, i32 0
  %t263 = load ptr, ptr %t262, !tbaa !29
  %t265 = getelementptr %"compiler/generic:Program", ptr %t263, i32 0, i32 0
  %t266 = load ptr, ptr %t265, !tbaa !29
  %t268 = getelementptr %"compiler/load:Loader", ptr %t266, i32 0, i32 3
  %t269 = load ptr, ptr %t268, !tbaa !29
  %t270 = getelementptr %"compiler/typed:Local", ptr %l20, i32 0, i32 0
  %t271 = load i32, ptr %t270, !tbaa !23
  %t274 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t269, i32 %t271)
  store { i64, ptr } %t274, ptr %l165
  br label %bb103
bb103:
  %t275 = load { i64, ptr }, ptr %l165, !tbaa !27
  store { i64, ptr } %t275, ptr %l22, !tbaa !27
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t277 = getelementptr %"compiler/typed:Local", ptr %l20, i32 0, i32 1
  %t278 = load %"compiler/source:Span", ptr %t277
  %t279 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t283 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewordAt(ptr %v0, ptr %v0, ptr %t276, %"compiler/source:Span" %t278, { i64, ptr } %t279)
  store %"compiler/source:Span" %t283, ptr %l169
  br label %bb104
bb104:
  %t284 = load %"compiler/source:Span", ptr %l169
  store %"compiler/source:Span" %t284, ptr %l23
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t287 = getelementptr %"compiler/scope:Scoper", ptr %t285, i32 0, i32 40
  %t288 = load i64, ptr %l19, !tbaa !24
  %t291 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v0, ptr %t287, i64 %t288)
  %t292 = extractvalue { i32, ptr } %t291, 1
  %t293 = extractvalue { i32, ptr } %t291, 0
  store i32 %t293, ptr %l175
  %t294 = icmp ne i32 %t293, 0
  br i1 %t294, label %bb106, label %ok.295
ok.295:
  store ptr %t292, ptr %l174
  br label %bb105
bb105:
  %t296 = load ptr, ptr %l174, !tbaa !29
  store ptr %t296, ptr %l170, !tbaa !29
  br label %bb108
bb106:
  br label %bb107
bb107:
  store ptr null, ptr %l170, !tbaa !29
  br label %bb108
bb108:
  %t297 = load ptr, ptr %l170, !tbaa !29
  store ptr %t297, ptr %l24, !tbaa !29
  %t298 = load ptr, ptr %l24, !tbaa !29
  %t300 = icmp eq ptr %t298, null
  %t302 = xor i1 %t300, true
  br i1 %t302, label %bb109, label %bb110
bb109:
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t305 = load ptr, ptr %l24, !tbaa !29
  %t309 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallOf(ptr %v0, ptr %v0, ptr %t304, ptr %t305)
  store ptr %t309, ptr %l183
  br label %bb111
bb110:
  store ptr null, ptr %l179, !tbaa !29
  br label %bb112
bb111:
  %t310 = load ptr, ptr %l183, !tbaa !29
  store ptr %t310, ptr %l179, !tbaa !29
  br label %bb112
bb112:
  %t311 = load ptr, ptr %l179, !tbaa !29
  store ptr %t311, ptr %l25, !tbaa !29
  %t312 = load ptr, ptr %l25, !tbaa !29
  %t314 = icmp eq ptr %t312, null
  %t316 = xor i1 %t314, true
  br i1 %t316, label %bb113, label %bb114
bb113:
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t320 = getelementptr %"compiler/scope:Scoper", ptr %t318, i32 0, i32 0
  %t321 = load ptr, ptr %t320, !tbaa !29
  %t323 = getelementptr %"compiler/generic:Program", ptr %t321, i32 0, i32 2
  store ptr %t323, ptr %l190, !tbaa !29
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t325 = load ptr, ptr %l25, !tbaa !29
  %t328 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v0, ptr %t324, ptr %t325)
  store i32 %t328, ptr %l193
  br label %bb115
bb114:
  store i1 false, ptr %l187, !tbaa !21
  br label %bb117
bb115:
  %t329 = load ptr, ptr %l190, !tbaa !29
  %t330 = load i32, ptr %l193, !tbaa !23
  %t331 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t329, i32 %t330)
  store i64 %t331, ptr %l194
  br label %bb116
bb116:
  %t332 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t333 = load i64, ptr %l194, !tbaa !24
  %t335 = icmp ne i64 %t333, %t332
  store i1 %t335, ptr %l187, !tbaa !21
  br label %bb117
bb117:
  %t337 = load i1, ptr %l187, !tbaa !21
  br i1 %t337, label %bb118, label %bb119
bb118:
  store %olang.scope zeroinitializer, ptr %s17
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t339 = load i64, ptr %l1, !tbaa !24
  %t340 = load ptr, ptr %l25, !tbaa !29
  %t341 = load i64, ptr %l3, !tbaa !24
  %t342 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t343 = load i64, ptr %l5, !tbaa !24
  %t350 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteThroughResult(ptr %v0, ptr %v0, ptr %v2, ptr %t338, i64 %t339, ptr %t340, i64 %t341, { i64, ptr } %t342, i64 %t343)
  store i1 %t350, ptr %l203
  br label %bb120
bb119:
  br label %bb158
bb120:
  %t351 = load i1, ptr %l203, !tbaa !21
  br i1 %t351, label %bb121, label %bb122
bb121:
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb122:
  br label %bb123
bb123:
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t353 = load ptr, ptr %l25, !tbaa !29
  %t356 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisMethodCall(ptr %v0, ptr %v0, ptr %t352, ptr %t353)
  store i1 %t356, ptr %l206
  br label %bb124
bb124:
  %t357 = load i1, ptr %l206, !tbaa !21
  br i1 %t357, label %bb125, label %bb126
bb125:
  store i1 true, ptr %l207, !tbaa !21
  br label %bb128
bb126:
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t359 = load ptr, ptr %l25, !tbaa !29
  %t362 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eindexCall(ptr %v0, ptr %v0, ptr %t358, ptr %t359)
  store i1 %t362, ptr %l210
  br label %bb127
bb127:
  %t363 = load i1, ptr %l210, !tbaa !21
  store i1 %t363, ptr %l207, !tbaa !21
  br label %bb128
bb128:
  %t364 = load i1, ptr %l207, !tbaa !21
  br i1 %t364, label %bb129, label %bb130
bb129:
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb130:
  br label %bb131
bb131:
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t366 = load ptr, ptr %l25, !tbaa !29
  %t369 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeName(ptr %v0, ptr %v0, ptr %s17, ptr %t365, ptr %t366)
  store { i64, ptr } %t369, ptr %l213
  br label %bb132
bb132:
  %t370 = load { i64, ptr }, ptr %l213, !tbaa !27
  store { i64, ptr } %t370, ptr %l26, !tbaa !27
  %t371 = load ptr, ptr %l25, !tbaa !29
  %t373 = getelementptr %"compiler/typed:Call", ptr %t371, i32 0, i32 2
  %t374 = load { i64, [2 x i64] }, ptr %t373
  %t378 = extractvalue { i64, [2 x i64] } %t374, 0
  %t379 = icmp eq i64 %t378, 0
  br i1 %t379, label %bb133, label %bb134
bb133:
  br label %bb135
bb134:
  br label %bb136
bb135:
  store i1 true, ptr %l216, !tbaa !21
  br label %bb141
bb136:
  br i1 true, label %bb137, label %bb138
bb137:
  br label %bb139
bb138:
  br label %bb140
bb139:
  store i1 false, ptr %l216, !tbaa !21
  br label %bb141
bb140:
  call void @__olang_check_failed(ptr @olang_loc_ae3c5a3c06bd23bd_8aa883e19e734e79)
  unreachable
bb141:
  %t381 = load i1, ptr %l216, !tbaa !21
  store i1 %t381, ptr %l28, !tbaa !21
  %t382 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t384 = extractvalue { i64, ptr } %t382, 0
  %t386 = icmp sgt i64 %t384, 0
  br i1 %t386, label %bb142, label %bb143
bb142:
  %t388 = load i1, ptr %l28, !tbaa !21
  store i1 %t388, ptr %l222, !tbaa !21
  br label %bb144
bb143:
  store i1 false, ptr %l222, !tbaa !21
  br label %bb144
bb144:
  %t390 = load i1, ptr %l222, !tbaa !21
  br i1 %t390, label %bb145, label %bb146
bb145:
  %t391 = load ptr, ptr %l0, !tbaa !29
  store ptr %t391, ptr %l225, !tbaa !29
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t393 = load ptr, ptr %l25, !tbaa !29
  %t396 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v0, ptr %t392, ptr %t393)
  store i32 %t396, ptr %l228
  br label %bb147
bb146:
  store i1 false, ptr %l224, !tbaa !21
  br label %bb149
bb147:
  %t397 = load ptr, ptr %l225, !tbaa !29
  %t398 = load i32, ptr %l228, !tbaa !23
  %t399 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eresultVarOf(ptr %v0, ptr %t397, i32 %t398)
  store i64 %t399, ptr %l229
  br label %bb148
bb148:
  %t400 = load i64, ptr %l229, !tbaa !24
  %t401 = icmp sge i64 %t400, 0
  store i1 %t401, ptr %l224, !tbaa !21
  br label %bb149
bb149:
  %t403 = load i1, ptr %l224, !tbaa !21
  br i1 %t403, label %bb150, label %bb151
bb150:
  store %olang.scope zeroinitializer, ptr %s22
  %t404 = load ptr, ptr %l0, !tbaa !29
  store ptr %t404, ptr %l231, !tbaa !29
  %t405 = load i64, ptr %l1, !tbaa !24
  store i64 %t405, ptr %l232, !tbaa !24
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t408 = getelementptr %"compiler/scope:Scoper", ptr %t406, i32 0, i32 25
  %t409 = load ptr, ptr %t408, !tbaa !29
  %t411 = icmp eq ptr %t409, null
  br i1 %t411, label %bb152, label %bb153
bb151:
  br label %bb157
bb152:
  call void @__olang_check_failed(ptr @olang_loc_a5d7ffc0375a2adf_b8092e4cba9985db)
  unreachable
bb153:
  br label %bb154
bb154:
  %t413 = load ptr, ptr %l0, !tbaa !29
  %t415 = getelementptr %"compiler/scope:Scoper", ptr %t413, i32 0, i32 25
  %t416 = load ptr, ptr %t415, !tbaa !29
  %t419 = getelementptr %"compiler/typed:Body", ptr %t416, i32 0, i32 3
  %t420 = load i64, ptr %t419, !tbaa !24
  store i64 %t420, ptr %l239, !tbaa !24
  %t421 = load %"compiler/source:Span", ptr %l23
  store %"compiler/source:Span" %t421, ptr %l240
  %t422 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t423 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t424 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t425 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t430 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteMakeWhere(ptr %v0, ptr %v2, ptr %s17, ptr %v2, ptr %s22, { i64, ptr } %t422, { i64, ptr } %t423, { i64, ptr } %t424, { i64, ptr } %t425)
  store %"compiler/msgs:Msg" %t430, ptr %l245
  br label %bb155
bb155:
  %t431 = load ptr, ptr %l231, !tbaa !29
  %t432 = load i64, ptr %l232, !tbaa !24
  %t433 = load i64, ptr %l239, !tbaa !24
  %t434 = load %"compiler/source:Span", ptr %l240
  %t435 = load %"compiler/msgs:Msg", ptr %l245
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enote(ptr %v0, ptr %s22, ptr %t431, i64 %t432, i64 %t433, %"compiler/source:Span" %t434, %"compiler/msgs:Msg" %t435)
  br label %bb156
bb156:
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb157:
  call void @__olang_scope_close(ptr %s17)
  br label %bb158
bb158:
  %t436 = getelementptr %"compiler/typed:Local", ptr %l20, i32 0, i32 2
  %t437 = load i32, ptr %t436, !tbaa !23
  store i32 %t437, ptr %l29, !tbaa !23
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t441 = getelementptr %"compiler/scope:Scoper", ptr %t439, i32 0, i32 0
  %t442 = load ptr, ptr %t441, !tbaa !29
  %t444 = getelementptr %"compiler/generic:Program", ptr %t442, i32 0, i32 2
  %t445 = load i32, ptr %l29, !tbaa !23
  %t448 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t444, i32 %t445)
  store i32 %t448, ptr %l251
  br label %bb159
bb159:
  %t449 = load i32, ptr %l251
  store i32 %t449, ptr %l30
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t451 = load i32, ptr %l29, !tbaa !23
  %t454 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t450, i32 %t451)
  store i1 %t454, ptr %l254
  br label %bb160
bb160:
  %t455 = load i1, ptr %l254, !tbaa !21
  %t456 = xor i1 %t455, true
  br i1 %t456, label %bb161, label %bb162
bb161:
  %t458 = load ptr, ptr %l0, !tbaa !29
  %t459 = load i32, ptr %l29, !tbaa !23
  %t462 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t458, i32 %t459)
  store i1 %t462, ptr %l259
  br label %bb163
bb162:
  store i1 false, ptr %l256, !tbaa !21
  br label %bb164
bb163:
  %t463 = load i1, ptr %l259, !tbaa !21
  %t464 = xor i1 %t463, true
  store i1 %t464, ptr %l256, !tbaa !21
  br label %bb164
bb164:
  %t466 = load i1, ptr %l256, !tbaa !21
  br i1 %t466, label %bb165, label %bb166
bb165:
  %t467 = load i32, ptr %l30
  %t469 = trunc i64 19 to i32
  %t470 = icmp eq i32 %t467, %t469
  %t472 = xor i1 %t470, true
  store i1 %t472, ptr %l261, !tbaa !21
  br label %bb167
bb166:
  store i1 false, ptr %l261, !tbaa !21
  br label %bb167
bb167:
  %t474 = load i1, ptr %l261, !tbaa !21
  br i1 %t474, label %bb168, label %bb169
bb168:
  %t475 = load i32, ptr %l30
  %t477 = trunc i64 18 to i32
  %t478 = icmp eq i32 %t475, %t477
  %t480 = xor i1 %t478, true
  store i1 %t480, ptr %l265, !tbaa !21
  br label %bb170
bb169:
  store i1 false, ptr %l265, !tbaa !21
  br label %bb170
bb170:
  %t482 = load i1, ptr %l265, !tbaa !21
  br i1 %t482, label %bb171, label %bb172
bb171:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb172:
  br label %bb173
bb173:
  %t483 = load ptr, ptr %l0, !tbaa !29
  %t485 = getelementptr %"compiler/scope:Scoper", ptr %t483, i32 0, i32 5
  %t486 = load { ptr, ptr }, ptr %t485
  %t488 = extractvalue { ptr, ptr } %t486, 0
  %t489 = extractvalue { ptr, ptr } zeroinitializer, 0
  %t490 = icmp eq ptr %t488, %t489
  %t491 = extractvalue { ptr, ptr } %t486, 1
  %t492 = extractvalue { ptr, ptr } zeroinitializer, 1
  %t493 = icmp eq ptr %t491, %t492
  %t494 = and i1 %t490, %t493
  br i1 %t494, label %bb174, label %bb175
bb174:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb175:
  br label %bb176
bb176:
  %t496 = load ptr, ptr %l0, !tbaa !29
  %t497 = load i32, ptr %l29, !tbaa !23
  %t500 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t496, i32 %t497)
  store i1 %t500, ptr %l274
  br label %bb177
bb177:
  %t501 = load i1, ptr %l274, !tbaa !21
  br i1 %t501, label %bb178, label %bb179
bb178:
  %t502 = load ptr, ptr %l0, !tbaa !29
  %t504 = getelementptr %"compiler/scope:Scoper", ptr %t502, i32 0, i32 0
  %t505 = load ptr, ptr %t504, !tbaa !29
  %t507 = getelementptr %"compiler/generic:Program", ptr %t505, i32 0, i32 2
  %t508 = load i32, ptr %l29, !tbaa !23
  %t511 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t507, i32 %t508)
  store i32 %t511, ptr %l280
  br label %bb180
bb179:
  %t512 = load i32, ptr %l29, !tbaa !23
  store i32 %t512, ptr %l275, !tbaa !23
  br label %bb181
bb180:
  %t514 = load i32, ptr %l280, !tbaa !23
  store i32 %t514, ptr %l275, !tbaa !23
  br label %bb181
bb181:
  %t515 = load i32, ptr %l275, !tbaa !23
  store i32 %t515, ptr %l31, !tbaa !23
  %t516 = load ptr, ptr %l0, !tbaa !29
  %t517 = load ptr, ptr %l0, !tbaa !29
  %t519 = getelementptr %"compiler/scope:Scoper", ptr %t517, i32 0, i32 26
  %t520 = load i64, ptr %t519, !tbaa !24
  %t523 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2einstanceOf(ptr %v0, ptr %t516, i64 %t520)
  store i64 %t523, ptr %l285
  br label %bb182
bb182:
  %t524 = load i64, ptr %l285, !tbaa !24
  store i64 %t524, ptr %l32, !tbaa !24
  %t525 = load i64, ptr %l32, !tbaa !24
  %t527 = icmp sge i64 %t525, 0
  br i1 %t527, label %bb183, label %bb184
bb183:
  %t529 = load ptr, ptr %l0, !tbaa !29
  %t531 = getelementptr %"compiler/scope:Scoper", ptr %t529, i32 0, i32 0
  %t532 = load ptr, ptr %t531, !tbaa !29
  %t534 = getelementptr %"compiler/generic:Program", ptr %t532, i32 0, i32 2
  store ptr %t534, ptr %l291, !tbaa !29
  %t535 = load ptr, ptr %l0, !tbaa !29
  %t537 = getelementptr %"compiler/scope:Scoper", ptr %t535, i32 0, i32 0
  %t538 = load ptr, ptr %t537, !tbaa !29
  %t539 = load i64, ptr %l32, !tbaa !24
  %t542 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t538, i64 %t539)
  store i32 %t542, ptr %l295
  br label %bb185
bb184:
  store i1 false, ptr %l288, !tbaa !21
  br label %bb187
bb185:
  %t543 = load ptr, ptr %l291, !tbaa !29
  %t544 = load i32, ptr %l295, !tbaa !23
  %t545 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t543, i32 %t544)
  store { i64, ptr } %t545, ptr %l296
  br label %bb186
bb186:
  %t546 = load { i64, ptr }, ptr %l296, !tbaa !27
  %t547 = extractvalue { i64, ptr } %t546, 0
  %t549 = icmp sgt i64 %t547, 0
  store i1 %t549, ptr %l288, !tbaa !21
  br label %bb187
bb187:
  %t551 = load i1, ptr %l288, !tbaa !21
  br i1 %t551, label %bb188, label %bb189
bb188:
  %t552 = load ptr, ptr %l0, !tbaa !29
  %t554 = getelementptr %"compiler/scope:Scoper", ptr %t552, i32 0, i32 0
  %t555 = load ptr, ptr %t554, !tbaa !29
  store ptr %t555, ptr %l300, !tbaa !29
  %t556 = load i32, ptr %l31, !tbaa !23
  store i32 %t556, ptr %l301, !tbaa !23
  %t557 = load ptr, ptr %l0, !tbaa !29
  %t559 = getelementptr %"compiler/scope:Scoper", ptr %t557, i32 0, i32 0
  %t560 = load ptr, ptr %t559, !tbaa !29
  %t561 = load i64, ptr %l32, !tbaa !24
  %t564 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t560, i64 %t561)
  store i64 %t564, ptr %l305
  br label %bb190
bb189:
  br label %bb198
bb190:
  %t565 = load i64, ptr %l305, !tbaa !24
  %t566 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t565)
  store i64 %t566, ptr %l306
  br label %bb191
bb191:
  %t567 = load ptr, ptr %l0, !tbaa !29
  %t569 = getelementptr %"compiler/scope:Scoper", ptr %t567, i32 0, i32 0
  %t570 = load ptr, ptr %t569, !tbaa !29
  %t571 = load i64, ptr %l32, !tbaa !24
  %t574 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t570, i64 %t571)
  store i32 %t574, ptr %l310
  br label %bb192
bb192:
  %t575 = load ptr, ptr %l300, !tbaa !29
  %t576 = load i32, ptr %l301, !tbaa !23
  %t577 = load i64, ptr %l306, !tbaa !24
  %t578 = load i32, ptr %l310, !tbaa !23
  %t579 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnsubst(ptr %v0, ptr %t575, i32 %t576, i64 %t577, i32 %t578)
  store i32 %t579, ptr %l311
  br label %bb193
bb193:
  %t580 = load i32, ptr %l311, !tbaa !23
  store i32 %t580, ptr %l31, !tbaa !23
  %t581 = load i32, ptr %l31, !tbaa !23
  %t582 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t585 = icmp eq i32 %t581, %t582
  br i1 %t585, label %bb194, label %bb195
bb194:
  %t587 = load ptr, ptr %l0, !tbaa !29
  %t589 = getelementptr %"compiler/scope:Scoper", ptr %t587, i32 0, i32 0
  %t590 = load ptr, ptr %t589, !tbaa !29
  %t592 = getelementptr %"compiler/generic:Program", ptr %t590, i32 0, i32 0
  %t593 = load ptr, ptr %t592, !tbaa !29
  %t595 = getelementptr %"compiler/load:Loader", ptr %t593, i32 0, i32 4
  %t596 = load ptr, ptr %t595, !tbaa !29
  %t597 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eYield(ptr %v0, ptr %t596, i64 %t597)
  br label %bb196
bb195:
  br label %bb197
bb196:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb197:
  br label %bb198
bb198:
  %t600 = load ptr, ptr %l0, !tbaa !29
  %t601 = load i32, ptr %l29, !tbaa !23
  %t604 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t600, i32 %t601)
  store i1 %t604, ptr %l322
  br label %bb199
bb199:
  %t605 = load i1, ptr %l322, !tbaa !21
  br i1 %t605, label %bb200, label %bb201
bb200:
  %t606 = load ptr, ptr %l0, !tbaa !29
  %t608 = getelementptr %"compiler/scope:Scoper", ptr %t606, i32 0, i32 0
  %t609 = load ptr, ptr %t608, !tbaa !29
  %t611 = getelementptr %"compiler/generic:Program", ptr %t609, i32 0, i32 2
  %t612 = load i32, ptr %l29, !tbaa !23
  %t615 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t611, i32 %t612)
  store i64 %t615, ptr %l328
  br label %bb202
bb201:
  store i1 true, ptr %l323, !tbaa !21
  br label %bb203
bb202:
  %t616 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t617 = load i64, ptr %l328, !tbaa !24
  %t619 = and i64 %t617, %t616
  %t621 = icmp ne i64 %t619, 0
  store i1 %t621, ptr %l323, !tbaa !21
  br label %bb203
bb203:
  %t623 = load i1, ptr %l323, !tbaa !21
  br i1 %t623, label %bb204, label %bb205
bb204:
  %t626 = load ptr, ptr %l0, !tbaa !29
  %t627 = load i32, ptr %l31, !tbaa !23
  %t630 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFunc(ptr %v0, ptr %t626, i32 %t627)
  store i1 %t630, ptr %l336
  br label %bb206
bb205:
  store i1 false, ptr %l333, !tbaa !21
  br label %bb207
bb206:
  %t631 = load i1, ptr %l336, !tbaa !21
  %t632 = xor i1 %t631, true
  store i1 %t632, ptr %l333, !tbaa !21
  br label %bb207
bb207:
  %t634 = load i1, ptr %l333, !tbaa !21
  br i1 %t634, label %bb208, label %bb209
bb208:
  store { i64, ptr } { i64 4, ptr @.d8 }, ptr %l338, !tbaa !27
  br label %bb210
bb209:
  store { i64, ptr } { i64 0, ptr @.d9 }, ptr %l338, !tbaa !27
  br label %bb210
bb210:
  %t635 = load ptr, ptr %l0, !tbaa !29
  %t637 = getelementptr %"compiler/scope:Scoper", ptr %t635, i32 0, i32 5
  %t638 = load { ptr, ptr }, ptr %t637
  %t639 = load i32, ptr %l31, !tbaa !23
  %t641 = extractvalue { ptr, ptr } %t638, 0
  %t642 = extractvalue { ptr, ptr } %t638, 1
  %t644 = call { i64, ptr } %t641(ptr %t642, ptr %s0, i32 %t639)
  store { i64, ptr } %t644, ptr %l342
  br label %bb211
bb211:
  %t645 = load { i64, ptr }, ptr %l338, !tbaa !27
  %t646 = extractvalue { i64, ptr } %t645, 1
  %t647 = extractvalue { i64, ptr } %t645, 0
  %t648 = load { i64, ptr }, ptr %l342, !tbaa !27
  %t649 = extractvalue { i64, ptr } %t648, 1
  %t650 = extractvalue { i64, ptr } %t648, 0
  %t651 = add i64 %t647, %t650
  %t652 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t651)
  call void @olang_textcopy(ptr %t652, ptr %t646, i64 %t647)
  %t653 = getelementptr i8, ptr %t652, i64 %t647
  call void @olang_textcopy(ptr %t653, ptr %t649, i64 %t650)
  %t654 = insertvalue { i64, ptr } undef, i64 %t651, 0
  %t655 = insertvalue { i64, ptr } %t654, ptr %t652, 1
  store { i64, ptr } %t655, ptr %l34, !tbaa !27
  %t657 = load ptr, ptr %l0, !tbaa !29
  store ptr %t657, ptr %l344, !tbaa !29
  %t658 = load i64, ptr %l1, !tbaa !24
  store i64 %t658, ptr %l345, !tbaa !24
  %t659 = load ptr, ptr %l0, !tbaa !29
  %t661 = getelementptr %"compiler/scope:Scoper", ptr %t659, i32 0, i32 25
  %t662 = load ptr, ptr %t661, !tbaa !29
  %t664 = icmp eq ptr %t662, null
  br i1 %t664, label %bb212, label %bb213
bb212:
  call void @__olang_check_failed(ptr @olang_loc_b5bb9adcdc2b0f40_ee4aa96e819ebaec)
  unreachable
bb213:
  br label %bb214
bb214:
  %t666 = load ptr, ptr %l0, !tbaa !29
  %t668 = getelementptr %"compiler/scope:Scoper", ptr %t666, i32 0, i32 25
  %t669 = load ptr, ptr %t668, !tbaa !29
  %t672 = getelementptr %"compiler/typed:Body", ptr %t669, i32 0, i32 3
  %t673 = load i64, ptr %t672, !tbaa !24
  store i64 %t673, ptr %l352, !tbaa !24
  %t674 = load %"compiler/source:Span", ptr %l23
  store %"compiler/source:Span" %t674, ptr %l353
  %t675 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t676 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t677 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t678 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t679 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t685 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDeclareWhere(ptr %v0, ptr %v2, ptr %v0, ptr %s0, ptr %v2, ptr %s0, { i64, ptr } %t675, { i64, ptr } %t676, { i64, ptr } %t677, { i64, ptr } %t678, { i64, ptr } %t679)
  store %"compiler/msgs:Msg" %t685, ptr %l359
  br label %bb215
bb215:
  %t686 = load ptr, ptr %l344, !tbaa !29
  %t687 = load i64, ptr %l345, !tbaa !24
  %t688 = load i64, ptr %l352, !tbaa !24
  %t689 = load %"compiler/source:Span", ptr %l353
  %t690 = load %"compiler/msgs:Msg", ptr %l359
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enote(ptr %v0, ptr %s0, ptr %t686, i64 %t687, i64 %t688, %"compiler/source:Span" %t689, %"compiler/msgs:Msg" %t690)
  br label %bb216
bb216:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eoblige(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i1
  %l4 = alloca i64
  %l7 = alloca { i64, [2 x i64] }
  %l13 = alloca { i64, [2 x i64] }
  %l16 = alloca { i64, [2 x i64] }
  %l22 = alloca { i64, [2 x i64] }
  %l27 = alloca i1
  %l31 = alloca i1
  %l33 = alloca ptr
  %l40 = alloca %"compiler/scope:rel"
  %l42 = alloca ptr
  %l49 = alloca %"compiler/scope:rel"
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  store { i64, [2 x i64] } %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load { i64, [2 x i64] }, ptr %l1
  %t5 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efloorOf(ptr %v0, ptr %t1, { i64, [2 x i64] } %t2)
  store { i64, [2 x i64] } %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load { i64, [2 x i64] }, ptr %l7
  %t8 = extractvalue { i64, [2 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 0
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load { i64, [2 x i64] }, ptr %l1
  %t17 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efloorOf(ptr %v0, ptr %t13, { i64, [2 x i64] } %t14)
  store { i64, [2 x i64] } %t17, ptr %l13
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t18 = load { i64, [2 x i64] }, ptr %l13
  store { i64, [2 x i64] } %t18, ptr %l1
  br label %bb5
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load { i64, [2 x i64] }, ptr %l2
  %t23 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efloorOf(ptr %v0, ptr %t19, { i64, [2 x i64] } %t20)
  store { i64, [2 x i64] } %t23, ptr %l16
  br label %bb6
bb6:
  %t24 = load { i64, [2 x i64] }, ptr %l16
  %t26 = extractvalue { i64, [2 x i64] } %t24, 0
  %t27 = icmp eq i64 %t26, 0
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb7, label %bb8
bb7:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load { i64, [2 x i64] }, ptr %l2
  %t35 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efloorOf(ptr %v0, ptr %t31, { i64, [2 x i64] } %t32)
  store { i64, [2 x i64] } %t35, ptr %l22
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t36 = load { i64, [2 x i64] }, ptr %l22
  store { i64, [2 x i64] } %t36, ptr %l2
  br label %bb10
bb10:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/scope:Scoper", ptr %t37, i32 0, i32 93
  %t40 = load i64, ptr %t39, !tbaa !24
  store i64 %t40, ptr %l4, !tbaa !24
  %t42 = load i64, ptr %l4, !tbaa !24
  %t44 = icmp eq i64 %t42, 0
  br i1 %t44, label %bb11, label %bb12
bb11:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load { i64, [2 x i64] }, ptr %l1
  %t48 = load { i64, [2 x i64] }, ptr %l2
  %t52 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2einstanceRel(ptr %v0, ptr %t46, { i64, [2 x i64] } %t47, { i64, [2 x i64] } %t48)
  store i1 %t52, ptr %l31
  br label %bb13
bb12:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb14
bb13:
  %t53 = load i1, ptr %l31, !tbaa !21
  store i1 %t53, ptr %l27, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l27, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load i64, ptr @G_2ecompiler_2fscope_2eWhyHolds, !tbaa !24
  store i64 %t55, ptr %l4, !tbaa !24
  br label %bb17
bb16:
  br label %bb17
bb17:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l33, !tbaa !29
  %t58 = load { i64, [2 x i64] }, ptr %l1
  %t59 = load { i64, [2 x i64] }, ptr %l2
  %t60 = load i1, ptr %l3, !tbaa !21
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/scope:Scoper", ptr %t61, i32 0, i32 36
  %t64 = load %"compiler/source:Span", ptr %t63
  %t65 = load i64, ptr %l4, !tbaa !24
  %t71 = call %"compiler/scope:rel" @compiler_2fscope_3arel_2ector(ptr %s0, { i64, [2 x i64] } %t58, { i64, [2 x i64] } %t59, i1 %t60, %"compiler/source:Span" %t64, i64 %t65)
  store %"compiler/scope:rel" %t71, ptr %l40
  br label %bb18
bb18:
  %t72 = load ptr, ptr %l33, !tbaa !29
  %t73 = load %"compiler/scope:rel", ptr %l40
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eaddRel(ptr %v0, ptr %t72, %"compiler/scope:rel" %t73)
  br label %bb19
bb19:
  %t74 = load i1, ptr %l3, !tbaa !21
  br i1 %t74, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s4
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l42, !tbaa !29
  %t77 = load { i64, [2 x i64] }, ptr %l2
  %t78 = load { i64, [2 x i64] }, ptr %l1
  %t79 = load i1, ptr %l3, !tbaa !21
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/scope:Scoper", ptr %t80, i32 0, i32 36
  %t83 = load %"compiler/source:Span", ptr %t82
  %t84 = load i64, ptr %l4, !tbaa !24
  %t90 = call %"compiler/scope:rel" @compiler_2fscope_3arel_2ector(ptr %s4, { i64, [2 x i64] } %t77, { i64, [2 x i64] } %t78, i1 %t79, %"compiler/source:Span" %t83, i64 %t84)
  store %"compiler/scope:rel" %t90, ptr %l49
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t91 = load ptr, ptr %l42, !tbaa !29
  %t92 = load %"compiler/scope:rel", ptr %l49
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eaddRel(ptr %v0, ptr %t91, %"compiler/scope:rel" %t92)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s4)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eocExprs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2, i1 %a3) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l15 = alloca { i64, ptr }
  %l23 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l6, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l6, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t15, ptr %l15, !tbaa !27
  %t16 = load i64, ptr %l5, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  %t32 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eocExpr(ptr %v0, ptr %v1, ptr %a0, ptr %t21, i64 %a2, i1 %a3)
  store i1 %t32, ptr %l23
  br label %bb5
bb5:
  %t33 = load i1, ptr %l23, !tbaa !21
  %t34 = xor i1 %t33, true
  br i1 %t34, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb9:
  %t37 = load i64, ptr %l5, !tbaa !24
  %t39 = add i64 %t37, 1
  store i64 %t39, ptr %l5, !tbaa !24
  br label %bb1
bb10:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eoldValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l6 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l24 = alloca ptr
  %l26 = alloca ptr
  %l29 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca i32
  %l33 = alloca i1
  %l35 = alloca i1
  %l36 = alloca ptr
  %l38 = alloca ptr
  %l41 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 55
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2eLe_H7b92c806358c31ec0113c885295670e0(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t15 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %t10, ptr %a1)
  store ptr %t15, ptr %l12
  br label %bb5
bb5:
  %t16 = load ptr, ptr %l12, !tbaa !29
  store ptr %t16, ptr %l2, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  store ptr %t17, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t18 = load ptr, ptr %l13, !tbaa !29
  %t19 = icmp ne ptr %t18, null
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %l13, !tbaa !29
  %t22 = load i64, ptr %t21
  %t24 = icmp eq i64 %t22, 2
  store i1 %t24, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t25 = load i1, ptr %l14, !tbaa !21
  br i1 %t25, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = getelementptr { i64, [5 x i64] }, ptr %t26, i32 0, i32 1
  %t29 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t28, i32 0, i32 2
  %t30 = load ptr, ptr %t29
  store ptr %t30, ptr %l3, !tbaa !29
  br label %bb10
bb9:
  br label %bb31
bb10:
  %t32 = load ptr, ptr %l3, !tbaa !29
  store ptr %t32, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t33 = load ptr, ptr %l19, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t36 = load ptr, ptr %l19, !tbaa !29
  %t37 = load i64, ptr %t36
  %t39 = icmp eq i64 %t37, 7
  store i1 %t39, ptr %l20, !tbaa !21
  br label %bb12
bb12:
  %t40 = load i1, ptr %l20, !tbaa !21
  br i1 %t40, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i1 true, ptr %rv
  br label %ret
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb30
bb19:
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l24, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/scope:Scoper", ptr %t43, i32 0, i32 55
  store ptr %t45, ptr %l26, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/scope:Scoper", ptr %t46, i32 0, i32 55
  %t50 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2eLe_H7b92c806358c31ec0113c885295670e0(ptr %v0, ptr %t48)
  store i64 %t50, ptr %l29
  br label %bb20
bb20:
  %t51 = load i64, ptr %l29, !tbaa !24
  %t52 = sub i64 %t51, 1
  %t53 = load ptr, ptr %l26, !tbaa !29
  %t55 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2eAt_H163e317dccec3ace9fb31d96922af4c2(ptr %v0, ptr %v0, ptr %t53, i64 %t52)
  store ptr %t55, ptr %l31
  br label %bb21
bb21:
  %t56 = load ptr, ptr %l31, !tbaa !29
  %t57 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %t56)
  store i32 %t57, ptr %l32
  br label %bb22
bb22:
  %t58 = load ptr, ptr %l24, !tbaa !29
  %t59 = load i32, ptr %l32, !tbaa !23
  %t60 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t58, i32 %t59)
  store i1 %t60, ptr %l33
  br label %bb23
bb23:
  %t61 = load i1, ptr %l33, !tbaa !21
  %t62 = xor i1 %t61, true
  br i1 %t62, label %bb24, label %bb25
bb24:
  %t64 = load ptr, ptr %l3, !tbaa !29
  store ptr %t64, ptr %l36, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/scope:Scoper", ptr %t65, i32 0, i32 55
  store ptr %t67, ptr %l38, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/scope:Scoper", ptr %t68, i32 0, i32 55
  %t72 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2eLe_H7b92c806358c31ec0113c885295670e0(ptr %v0, ptr %t70)
  store i64 %t72, ptr %l41
  br label %bb26
bb25:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb29
bb26:
  %t73 = load i64, ptr %l41, !tbaa !24
  %t74 = sub i64 %t73, 1
  %t75 = load ptr, ptr %l38, !tbaa !29
  %t77 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2eAt_H163e317dccec3ace9fb31d96922af4c2(ptr %v0, ptr %v0, ptr %t75, i64 %t74)
  store ptr %t77, ptr %l43
  br label %bb27
bb27:
  %t78 = load ptr, ptr %l36, !tbaa !29
  %t79 = load ptr, ptr %l43, !tbaa !29
  %t80 = call i1 @compiler_2fscope_2ewithin(ptr %v1, ptr %v0, ptr %t78, ptr %t79)
  store i1 %t80, ptr %l44
  br label %bb28
bb28:
  %t81 = load i1, ptr %l44, !tbaa !21
  store i1 %t81, ptr %l35, !tbaa !21
  br label %bb29
bb29:
  %t82 = load i1, ptr %l35, !tbaa !21
  store i1 %t82, ptr %rv
  br label %ret
bb30:
  call void @__olang_check_failed(ptr @olang_loc_40b97f37a7371750_40728193df6350fc)
  unreachable
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_f651c1e1d8a1ace1_d593723da6a130ad)
  unreachable
bb36:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eownerAt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l17 = alloca i64
  %l20 = alloca i64
  %l42 = alloca i1
  %l43 = alloca { i64, ptr }
  %l48 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l53 = alloca %"compiler/source:Span"
  %l54 = alloca %"compiler/source:Span"
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l5, !tbaa !24
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  store i64 %t6, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t8 = load i64, ptr %l6, !tbaa !24
  %t9 = load i64, ptr %l5, !tbaa !24
  %t12 = icmp sgt i64 %t8, %t9
  br i1 %t12, label %bb1, label %bb2
bb1:
  %t14 = load i64, ptr %l7, !tbaa !24
  %t16 = icmp sgt i64 %t14, 0
  br i1 %t16, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb3:
  %t18 = load i64, ptr %l6, !tbaa !24
  %t19 = load i64, ptr %l5, !tbaa !24
  %t22 = sub i64 %t18, %t19
  %t23 = load i64, ptr %l7, !tbaa !24
  %t26 = add i64 %t22, %t23
  %t28 = sub i64 %t26, 1
  %t29 = load i64, ptr %l7, !tbaa !24
  %t32 = sdiv i64 %t28, %t29
  store i64 %t32, ptr %l20, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb5
bb5:
  %t34 = load i64, ptr %l20, !tbaa !24
  store i64 %t34, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l17, !tbaa !24
  store i64 %t35, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load i64, ptr %l9, !tbaa !24
  %t37 = load i64, ptr %l8, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb9:
  br label %bb10
bb10:
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l9, !tbaa !24
  %t46 = load i64, ptr %l7, !tbaa !24
  %t49 = mul i64 %t45, %t46
  %t52 = add i64 %t44, %t49
  store i64 %t52, ptr %l10, !tbaa !24
  %t54 = load i64, ptr %l10, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 0
  %t60 = icmp slt i64 %t54, %t57
  br i1 %t60, label %bb11, label %bb12
bb11:
  %t62 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t62, ptr %l43, !tbaa !27
  %t63 = load i64, ptr %l10, !tbaa !24
  %t65 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr i64, ptr %t66, i64 %t63
  %t68 = load i64, ptr %t67, !tbaa !34
  %t72 = icmp eq i64 %t68, %a3
  store i1 %t72, ptr %l42, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb13
bb13:
  %t74 = load i1, ptr %l42, !tbaa !21
  br i1 %t74, label %bb14, label %bb15
bb14:
  store ptr %a0, ptr %l48, !tbaa !29
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr %"compiler/typed:Call", ptr %t76, i32 0, i32 1
  %t79 = load { i64, ptr }, ptr %t78, !tbaa !27
  store { i64, ptr } %t79, ptr %l50, !tbaa !27
  %t80 = load i64, ptr %l10, !tbaa !24
  %t82 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr ptr, ptr %t83, i64 %t80
  %t85 = load ptr, ptr %t84, !tbaa !39
  %t87 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t85)
  store %"compiler/source:Span" %t87, ptr %l53
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t88 = load ptr, ptr %l48, !tbaa !29
  %t89 = load %"compiler/source:Span", ptr %l53
  %t90 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elastName(ptr %v0, ptr %t88, %"compiler/source:Span" %t89)
  store %"compiler/source:Span" %t90, ptr %l54
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  %t91 = load %"compiler/source:Span", ptr %l54
  store %"compiler/source:Span" %t91, ptr %rv
  br label %ret
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t92 = load i64, ptr %l9, !tbaa !24
  %t94 = add i64 %t92, 1
  store i64 %t94, ptr %l9, !tbaa !24
  br label %bb7
bb20:
  store %"compiler/source:Span" %a4, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparamBinding(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i32
  %l25 = alloca { i64, ptr }
  %l31 = alloca i64
  %l34 = alloca i64
  %l42 = alloca i64
  %l45 = alloca i64
  %l67 = alloca i1
  %l72 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, [2 x i64] }
  %t13 = alloca { i64, [2 x i64] }, align 8
  %t132 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %t1, ptr %a1)
  store i32 %t5, ptr %l16
  br label %bb1
bb1:
  %t6 = load i32, ptr %l16, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  %t7 = load i32, ptr %l4, !tbaa !23
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t11 = icmp eq i32 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  store { i64, [2 x i64] } zeroinitializer, ptr %t13
  %t14 = getelementptr { i64, [2 x i64] }, ptr %t13, i32 0, i32 0
  store i64 0, ptr %t14
  %t15 = load { i64, [2 x i64] }, ptr %t13
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t15, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/scope:Scoper", ptr %t17, i32 0, i32 0
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 2
  %t23 = load i32, ptr %l4, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t22, i32 %t23)
  store { i64, ptr } %t26, ptr %l25
  br label %bb5
bb5:
  %t27 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t27, ptr %l5, !tbaa !27
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/scope:Scoper", ptr %t28, i32 0, i32 0
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  %t34 = load i32, ptr %l4, !tbaa !23
  %t35 = load i64, ptr %l2, !tbaa !24
  %t39 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t33, i32 %t34, i64 %t35)
  store i64 %t39, ptr %l31
  br label %bb6
bb6:
  %t40 = load i64, ptr %l31, !tbaa !24
  store i64 %t40, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l6, !tbaa !24
  %t43 = icmp sge i64 %t41, 0
  br i1 %t43, label %bb7, label %bb8
bb7:
  %t45 = load i64, ptr %l6, !tbaa !24
  store i64 %t45, ptr %l34, !tbaa !24
  br label %bb9
bb8:
  %t47 = load i64, ptr %l2, !tbaa !24
  store i64 %t47, ptr %l34, !tbaa !24
  br label %bb9
bb9:
  %t49 = load i64, ptr %l34, !tbaa !24
  store i64 %t49, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t50 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t50, 0
  store i64 %t52, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t54 = load i64, ptr %l9, !tbaa !24
  %t55 = load i64, ptr %l8, !tbaa !24
  %t58 = icmp sgt i64 %t54, %t55
  br i1 %t58, label %bb10, label %bb11
bb10:
  %t60 = load i64, ptr %l10, !tbaa !24
  %t62 = icmp sgt i64 %t60, 0
  br i1 %t62, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb15
bb12:
  %t64 = load i64, ptr %l9, !tbaa !24
  %t65 = load i64, ptr %l8, !tbaa !24
  %t68 = sub i64 %t64, %t65
  %t69 = load i64, ptr %l10, !tbaa !24
  %t72 = add i64 %t68, %t69
  %t74 = sub i64 %t72, 1
  %t75 = load i64, ptr %l10, !tbaa !24
  %t78 = sdiv i64 %t74, %t75
  store i64 %t78, ptr %l45, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb14
bb14:
  %t80 = load i64, ptr %l45, !tbaa !24
  store i64 %t80, ptr %l42, !tbaa !24
  br label %bb15
bb15:
  %t81 = load i64, ptr %l42, !tbaa !24
  store i64 %t81, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t82 = load i64, ptr %l12, !tbaa !24
  %t83 = load i64, ptr %l11, !tbaa !24
  %t86 = icmp slt i64 %t82, %t83
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb27
bb18:
  br label %bb19
bb19:
  %t90 = load i64, ptr %l8, !tbaa !24
  %t91 = load i64, ptr %l12, !tbaa !24
  %t92 = load i64, ptr %l10, !tbaa !24
  %t95 = mul i64 %t91, %t92
  %t98 = add i64 %t90, %t95
  store i64 %t98, ptr %l13, !tbaa !24
  %t100 = load i64, ptr %l13, !tbaa !24
  %t102 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr i64, ptr %t103, i64 %t100
  %t105 = load i64, ptr %t104, !tbaa !34
  %t106 = load i64, ptr %l7, !tbaa !24
  %t109 = icmp eq i64 %t105, %t106
  br i1 %t109, label %bb20, label %bb21
bb20:
  %t111 = load i64, ptr %l13, !tbaa !24
  %t112 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t112, 0
  %t117 = icmp slt i64 %t111, %t114
  store i1 %t117, ptr %l67, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb22
bb22:
  %t119 = load i1, ptr %l67, !tbaa !21
  br i1 %t119, label %bb23, label %bb24
bb23:
  %t120 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t120, ptr %l72, !tbaa !27
  %t121 = load i64, ptr %l13, !tbaa !24
  %t123 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = getelementptr { i64, [2 x i64] }, ptr %t124, i64 %t121
  %t126 = load { i64, [2 x i64] }, ptr %t125
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t126, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s3)
  br label %bb26
bb26:
  %t128 = load i64, ptr %l12, !tbaa !24
  %t130 = add i64 %t128, 1
  store i64 %t130, ptr %l12, !tbaa !24
  br label %bb16
bb27:
  store { i64, [2 x i64] } zeroinitializer, ptr %t132
  %t133 = getelementptr { i64, [2 x i64] }, ptr %t132, i32 0, i32 0
  store i64 0, ptr %t133
  %t134 = load { i64, [2 x i64] }, ptr %t132
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t134, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparamOfTerm(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i64
  %l3 = alloca { i64, [1 x i64] }
  %l4 = alloca i32
  %l8 = alloca i64
  %l16 = alloca i64
  %l26 = alloca { i64, [1 x i64] }
  %l39 = alloca %"compiler/typed:Local"
  %l42 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 2
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l2, !tbaa !24
  br label %bb3
bb2:
  br label %bb31
bb3:
  %t10 = load i64, ptr %l2, !tbaa !24
  store i64 %t10, ptr %l8, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 25
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = icmp eq ptr %t14, null
  br i1 %t16, label %bb4, label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_77d8df1bd6b52079_f0229fa895aca615)
  unreachable
bb5:
  br label %bb6
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/scope:Scoper", ptr %t18, i32 0, i32 25
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Body", ptr %t21, i32 0, i32 6
  %t26 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2eLe_H729d11b3a9b9a6787781d29df4918101(ptr %v0, ptr %t24)
  store i64 %t26, ptr %l16
  br label %bb7
bb7:
  %t27 = load i64, ptr %l8, !tbaa !24
  %t28 = load i64, ptr %l16, !tbaa !24
  %t29 = icmp slt i64 %t27, %t28
  br i1 %t29, label %bb8, label %bb9
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/scope:Scoper", ptr %t31, i32 0, i32 25
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = icmp eq ptr %t34, null
  br i1 %t36, label %bb10, label %bb11
bb9:
  br label %bb30
bb10:
  call void @__olang_check_failed(ptr @olang_loc_bfd80b0298b19652_e537c33c4d886a6e)
  unreachable
bb11:
  br label %bb12
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/scope:Scoper", ptr %t38, i32 0, i32 25
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t44 = getelementptr %"compiler/typed:Body", ptr %t41, i32 0, i32 6
  %t45 = load i64, ptr %l2, !tbaa !24
  %t48 = call { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_H9c4972d30d76581e4f8a183d5194d431(ptr %v0, ptr %t44, i64 %t45)
  store { i64, [1 x i64] } %t48, ptr %l26
  br label %bb13
bb13:
  %t49 = load { i64, [1 x i64] }, ptr %l26
  store { i64, [1 x i64] } %t49, ptr %l3
  %t50 = load { i64, [1 x i64] }, ptr %l3
  %t52 = extractvalue { i64, [1 x i64] } %t50, 0
  %t53 = icmp eq i64 %t52, 0
  br i1 %t53, label %bb14, label %bb15
bb14:
  %t55 = getelementptr { i64, [1 x i64] }, ptr %l3, i32 0, i32 1
  %t56 = getelementptr { i32 }, ptr %t55, i32 0, i32 0
  %t57 = load i32, ptr %t56
  store i32 %t57, ptr %l4, !tbaa !23
  br label %bb16
bb15:
  br label %bb24
bb16:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/scope:Scoper", ptr %t59, i32 0, i32 25
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = icmp eq ptr %t62, null
  br i1 %t64, label %bb17, label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_b1757fdcabe82f93_e12b45afd85e1a9f)
  unreachable
bb18:
  br label %bb19
bb19:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/scope:Scoper", ptr %t66, i32 0, i32 25
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Body", ptr %t69, i32 0, i32 7
  %t73 = load i32, ptr %l4, !tbaa !23
  %t75 = sext i32 %t73 to i64
  %t78 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t72, i64 %t75)
  store %"compiler/typed:Local" %t78, ptr %l39
  br label %bb20
bb20:
  %t79 = getelementptr %"compiler/typed:Local", ptr %l39, i32 0, i32 0
  %t80 = load i32, ptr %t79, !tbaa !23
  %t82 = icmp ne i32 %t80, 0
  br i1 %t82, label %bb21, label %bb22
bb21:
  %t84 = load i32, ptr %l4, !tbaa !23
  %t86 = sext i32 %t84 to i64
  store i64 %t86, ptr %l42, !tbaa !24
  br label %bb23
bb22:
  store i64 -1, ptr %l42, !tbaa !24
  br label %bb23
bb23:
  %t88 = load i64, ptr %l42, !tbaa !24
  store i64 %t88, ptr %rv
  br label %ret
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_a9000624b37114eb_4f5d8570083b5047)
  unreachable
bb29:
  br label %bb30
bb30:
  br label %bb36
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_6cb6018c48b7e44c_30fb4d691284a4b0)
  unreachable
bb36:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparamVar(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, [1 x i64] }
  %l12 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca i64
  %l20 = alloca i64
  %l26 = alloca i32
  %l29 = alloca i64
  %l33 = alloca i64
  %l36 = alloca i64
  %l57 = alloca { i64, [1 x i64] }
  %s3 = alloca %olang.scope
  %rv = alloca i64
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 1
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l16
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l16, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t9 = load i64, ptr %l2, !tbaa !24
  store i64 %t9, ptr %l17, !tbaa !24
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Body", ptr %t10, i32 0, i32 5
  %t14 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l20
  br label %bb2
bb2:
  %t15 = load i64, ptr %l17, !tbaa !24
  %t16 = load i64, ptr %l20, !tbaa !24
  %t17 = icmp sge i64 %t15, %t16
  br i1 %t17, label %bb3, label %bb4
bb3:
  store i64 -1, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t20 = load ptr, ptr %l3, !tbaa !29
  %t22 = getelementptr %"compiler/typed:Body", ptr %t20, i32 0, i32 5
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t22, i64 %t23)
  store i32 %t26, ptr %l26
  br label %bb6
bb6:
  %t27 = load i32, ptr %l26, !tbaa !23
  store i32 %t27, ptr %l4, !tbaa !23
  store i64 0, ptr %l5, !tbaa !24
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Body", ptr %t28, i32 0, i32 6
  %t32 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2eLe_H729d11b3a9b9a6787781d29df4918101(ptr %v0, ptr %t30)
  store i64 %t32, ptr %l29
  br label %bb7
bb7:
  %t33 = load i64, ptr %l29, !tbaa !24
  store i64 %t33, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t34 = load i64, ptr %l6, !tbaa !24
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = icmp sgt i64 %t34, %t35
  br i1 %t38, label %bb8, label %bb9
bb8:
  %t40 = load i64, ptr %l7, !tbaa !24
  %t42 = icmp sgt i64 %t40, 0
  br i1 %t42, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb13
bb10:
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = sub i64 %t44, %t45
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = add i64 %t48, %t49
  %t54 = sub i64 %t52, 1
  %t55 = load i64, ptr %l7, !tbaa !24
  %t58 = sdiv i64 %t54, %t55
  store i64 %t58, ptr %l36, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb12
bb12:
  %t60 = load i64, ptr %l36, !tbaa !24
  store i64 %t60, ptr %l33, !tbaa !24
  br label %bb13
bb13:
  %t61 = load i64, ptr %l33, !tbaa !24
  store i64 %t61, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t62 = load i64, ptr %l9, !tbaa !24
  %t63 = load i64, ptr %l8, !tbaa !24
  %t66 = icmp slt i64 %t62, %t63
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb32
bb16:
  br label %bb17
bb17:
  %t70 = load i64, ptr %l5, !tbaa !24
  %t71 = load i64, ptr %l9, !tbaa !24
  %t72 = load i64, ptr %l7, !tbaa !24
  %t75 = mul i64 %t71, %t72
  %t78 = add i64 %t70, %t75
  store i64 %t78, ptr %l10, !tbaa !24
  %t80 = load ptr, ptr %l3, !tbaa !29
  %t82 = getelementptr %"compiler/typed:Body", ptr %t80, i32 0, i32 6
  %t83 = load i64, ptr %l10, !tbaa !24
  %t86 = call { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_H9c4972d30d76581e4f8a183d5194d431(ptr %v0, ptr %t82, i64 %t83)
  store { i64, [1 x i64] } %t86, ptr %l57
  br label %bb18
bb18:
  %t87 = load { i64, [1 x i64] }, ptr %l57
  store { i64, [1 x i64] } %t87, ptr %l11
  %t88 = load { i64, [1 x i64] }, ptr %l11
  %t90 = extractvalue { i64, [1 x i64] } %t88, 0
  %t91 = icmp eq i64 %t90, 0
  br i1 %t91, label %bb19, label %bb20
bb19:
  %t93 = getelementptr { i64, [1 x i64] }, ptr %l11, i32 0, i32 1
  %t94 = getelementptr { i32 }, ptr %t93, i32 0, i32 0
  %t95 = load i32, ptr %t94
  store i32 %t95, ptr %l12, !tbaa !23
  br label %bb21
bb20:
  br label %bb25
bb21:
  %t97 = load i32, ptr %l12, !tbaa !23
  %t98 = load i32, ptr %l4, !tbaa !23
  %t101 = icmp eq i32 %t97, %t98
  br i1 %t101, label %bb22, label %bb23
bb22:
  %t103 = load i64, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  store i64 %t103, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  br label %bb30
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_50c5af6b9a55d13c_b172bff682b06040)
  unreachable
bb30:
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb31:
  %t105 = load i64, ptr %l9, !tbaa !24
  %t107 = add i64 %t105, 1
  store i64 %t107, ptr %l9, !tbaa !24
  br label %bb14
bb32:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparts(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %lp2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i32
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l33 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l38 = alloca i32
  %l45 = alloca i1
  %l50 = alloca ptr
  %l55 = alloca i32
  %l56 = alloca i32
  %l61 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l85 = alloca ptr
  %l90 = alloca i32
  %l91 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l105 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l107 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l111 = alloca i32
  %l120 = alloca { i64, ptr }
  %l134 = alloca ptr
  %l139 = alloca i32
  %l142 = alloca ptr
  %l147 = alloca i32
  %l154 = alloca ptr
  %l159 = alloca i32
  %l160 = alloca { i64, ptr }
  %l167 = alloca { i64, ptr }
  %l178 = alloca ptr
  %l183 = alloca i32
  %l184 = alloca { i64, ptr }
  %l191 = alloca { i64, ptr }
  %l198 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l200 = alloca { i64, ptr }
  %l203 = alloca { i64, ptr }
  %l204 = alloca i32
  %l213 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l33
  br label %bb1
bb1:
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t3, ptr %lp2
  %t4 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l33
  %t5 = load ptr, ptr %lp2
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %t5
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/scope:Scoper", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 2
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l38
  br label %bb2
bb2:
  %t16 = load i32, ptr %l38
  store i32 %t16, ptr %l3
  %t17 = load i32, ptr %l3
  %t19 = trunc i64 18 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb64
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/scope:Scoper", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l1, !tbaa !23
  %t31 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t27, i32 %t28)
  store i1 %t31, ptr %l45
  br label %bb6
bb6:
  %t32 = load i1, ptr %l45, !tbaa !21
  %t33 = xor i1 %t32, true
  br i1 %t33, label %bb7, label %bb8
bb7:
  %t35 = load ptr, ptr %lp2
  %t36 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t35
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t36, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/scope:Scoper", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 2
  store ptr %t43, ptr %l50, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/scope:Scoper", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  %t50 = load i32, ptr %l1, !tbaa !23
  %t53 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t53, ptr %l55
  br label %bb10
bb10:
  %t54 = load ptr, ptr %l50, !tbaa !29
  %t55 = load i32, ptr %l55, !tbaa !23
  %t56 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t54, i32 %t55)
  store i32 %t56, ptr %l56
  br label %bb11
bb11:
  %t57 = load i32, ptr %l56
  store i32 %t57, ptr %l4
  %t58 = load i32, ptr %l4
  %t60 = trunc i64 0 to i32
  %t61 = icmp eq i32 %t58, %t60
  br i1 %t61, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb24
bb14:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/scope:Scoper", ptr %t63, i32 0, i32 0
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  store ptr %t68, ptr %l61, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/scope:Scoper", ptr %t69, i32 0, i32 0
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/generic:Program", ptr %t72, i32 0, i32 2
  %t75 = load i32, ptr %l1, !tbaa !23
  %t78 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t74, i32 %t75)
  store i32 %t78, ptr %l66
  br label %bb15
bb15:
  %t79 = load ptr, ptr %l61, !tbaa !29
  %t80 = load i32, ptr %l66, !tbaa !23
  %t81 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t79, i32 %t80)
  store { i64, ptr } %t81, ptr %l67
  br label %bb16
bb16:
  %t82 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t82, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t83 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t83, 0
  store i64 %t85, ptr %l7, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  %t87 = load i64, ptr %l6, !tbaa !24
  %t88 = load i64, ptr %l7, !tbaa !24
  %t91 = icmp slt i64 %t87, %t88
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s5)
  br label %bb23
bb19:
  br label %bb20
bb20:
  %t95 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t95, ptr %l74, !tbaa !27
  %t96 = load i64, ptr %l6, !tbaa !24
  %t98 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr i32, ptr %t99, i64 %t96
  %t101 = load i32, ptr %t100, !tbaa !33
  %t103 = load ptr, ptr %lp2
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t103, i32 %t101)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s5)
  br label %bb22
bb22:
  %t107 = load i64, ptr %l6, !tbaa !24
  %t109 = add i64 %t107, 1
  store i64 %t109, ptr %l6, !tbaa !24
  br label %bb17
bb23:
  br label %bb63
bb24:
  %t111 = load i32, ptr %l4
  %t113 = trunc i64 1 to i32
  %t114 = icmp eq i32 %t111, %t113
  br i1 %t114, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb56
bb27:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/scope:Scoper", ptr %t116, i32 0, i32 0
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t121 = getelementptr %"compiler/generic:Program", ptr %t119, i32 0, i32 2
  store ptr %t121, ptr %l85, !tbaa !29
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/scope:Scoper", ptr %t122, i32 0, i32 0
  %t125 = load ptr, ptr %t124, !tbaa !29
  %t127 = getelementptr %"compiler/generic:Program", ptr %t125, i32 0, i32 2
  %t128 = load i32, ptr %l1, !tbaa !23
  %t131 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t127, i32 %t128)
  store i32 %t131, ptr %l90
  br label %bb28
bb28:
  %t132 = load ptr, ptr %l85, !tbaa !29
  %t133 = load i32, ptr %l90, !tbaa !23
  %t134 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t132, i32 %t133)
  store { i64, ptr } %t134, ptr %l91
  br label %bb29
bb29:
  %t135 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t135, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t136 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t136, 0
  store i64 %t138, ptr %l11, !tbaa !24
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s9
  %t140 = load i64, ptr %l10, !tbaa !24
  %t141 = load i64, ptr %l11, !tbaa !24
  %t144 = icmp slt i64 %t140, %t141
  %t146 = xor i1 %t144, true
  br i1 %t146, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s9)
  br label %bb55
bb32:
  br label %bb33
bb33:
  %t148 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t148, ptr %l98, !tbaa !27
  %t149 = load i64, ptr %l10, !tbaa !24
  %t151 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr i32, ptr %t152, i64 %t149
  %t154 = load i32, ptr %t153, !tbaa !33
  store i32 %t154, ptr %l12, !tbaa !23
  %t156 = load i32, ptr %l12, !tbaa !23
  %t158 = icmp ne i32 %t156, 0
  br i1 %t158, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s11
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load i32, ptr %l12, !tbaa !23
  %t164 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparts(ptr %v0, ptr %s11, ptr %t160, i32 %t161)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t164, ptr %l105
  br label %bb36
bb35:
  br label %bb53
bb36:
  %t165 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l105
  %t166 = call ptr @__olang_scope_alloc_a(ptr %s11, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t165, ptr %t166
  store ptr %t166, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s12
  %t168 = load ptr, ptr %l13, !tbaa !29
  %t169 = load i64, ptr %l14, !tbaa !24
  %t172 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %s11, ptr %t168, i64 %t169)
  %t173 = extractvalue { i32, { i64, ptr } } %t172, 1
  %t174 = extractvalue { i32, { i64, ptr } } %t172, 0
  store i32 %t174, ptr %l111
  %t175 = icmp ne i32 %t174, 0
  br i1 %t175, label %bb39, label %ok.176
ok.176:
  store { i64, ptr } %t173, ptr %l110
  br label %bb38
bb38:
  %t177 = load { i64, ptr }, ptr %l110, !tbaa !27
  store { i64, ptr } %t177, ptr %l107, !tbaa !27
  br label %bb43
bb39:
  %t178 = load i32, ptr %l111, !tbaa !23
  %t179 = ashr i32 %t178, 16
  %t181 = icmp eq i32 %t179, 1
  br i1 %t181, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_74d9849f1cf072e4_d95edc215f7aa198)
  unreachable
bb42:
  call void @__olang_scope_close(ptr %s12)
  br label %bb52
bb43:
  %t183 = load { i64, ptr }, ptr %l107, !tbaa !27
  store { i64, ptr } %t183, ptr %l15, !tbaa !27
  %t184 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t184, 0
  store i64 %t186, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s13
  %t188 = load i64, ptr %l17, !tbaa !24
  %t189 = load i64, ptr %l16, !tbaa !24
  %t192 = icmp slt i64 %t188, %t189
  %t194 = xor i1 %t192, true
  br i1 %t194, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s13)
  br label %bb50
bb46:
  br label %bb47
bb47:
  %t196 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t196, ptr %l120, !tbaa !27
  %t197 = load i64, ptr %l17, !tbaa !24
  %t199 = getelementptr { i64, ptr }, ptr %l120, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !27
  %t201 = getelementptr i32, ptr %t200, i64 %t197
  %t202 = load i32, ptr %t201, !tbaa !33
  %t204 = load ptr, ptr %lp2
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t204, i32 %t202)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s13)
  br label %bb49
bb49:
  %t208 = load i64, ptr %l17, !tbaa !24
  %t210 = add i64 %t208, 1
  store i64 %t210, ptr %l17, !tbaa !24
  br label %bb44
bb50:
  %t212 = load i64, ptr %l14, !tbaa !24
  %t213 = load i64, ptr %l16, !tbaa !24
  %t216 = add i64 %t212, %t213
  store i64 %t216, ptr %l14, !tbaa !24
  call void @__olang_scope_close(ptr %s12)
  br label %bb51
bb51:
  br label %bb37
bb52:
  call void @__olang_scope_close(ptr %s11)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s9)
  br label %bb54
bb54:
  %t218 = load i64, ptr %l10, !tbaa !24
  %t220 = add i64 %t218, 1
  store i64 %t220, ptr %l10, !tbaa !24
  br label %bb30
bb55:
  br label %bb63
bb56:
  %t222 = load i32, ptr %l4
  %t224 = trunc i64 4 to i32
  %t225 = icmp eq i32 %t222, %t224
  br i1 %t225, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb62
bb59:
  %t227 = load ptr, ptr %lp2
  store ptr %t227, ptr %l134, !tbaa !29
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/scope:Scoper", ptr %t228, i32 0, i32 0
  %t231 = load ptr, ptr %t230, !tbaa !29
  %t233 = getelementptr %"compiler/generic:Program", ptr %t231, i32 0, i32 2
  %t234 = load i32, ptr %l1, !tbaa !23
  %t237 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t233, i32 %t234)
  store i32 %t237, ptr %l139
  br label %bb60
bb60:
  %t238 = load ptr, ptr %l134, !tbaa !29
  %t239 = load i32, ptr %l139, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t238, i32 %t239)
  br label %bb61
bb61:
  br label %bb63
bb62:
  br label %bb63
bb63:
  br label %bb118
bb64:
  %t240 = load i32, ptr %l3
  %t242 = trunc i64 19 to i32
  %t243 = icmp eq i32 %t240, %t242
  br i1 %t243, label %bb65, label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb70
bb67:
  %t245 = load ptr, ptr %lp2
  store ptr %t245, ptr %l142, !tbaa !29
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t248 = getelementptr %"compiler/scope:Scoper", ptr %t246, i32 0, i32 0
  %t249 = load ptr, ptr %t248, !tbaa !29
  %t251 = getelementptr %"compiler/generic:Program", ptr %t249, i32 0, i32 2
  %t252 = load i32, ptr %l1, !tbaa !23
  %t255 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t251, i32 %t252)
  store i32 %t255, ptr %l147
  br label %bb68
bb68:
  %t256 = load ptr, ptr %l142, !tbaa !29
  %t257 = load i32, ptr %l147, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t256, i32 %t257)
  br label %bb69
bb69:
  br label %bb118
bb70:
  %t258 = load i32, ptr %l3
  %t260 = trunc i64 22 to i32
  %t261 = icmp eq i32 %t258, %t260
  br i1 %t261, label %bb71, label %bb72
bb71:
  br label %bb75
bb72:
  %t263 = load i32, ptr %l3
  %t265 = trunc i64 23 to i32
  %t266 = icmp eq i32 %t263, %t265
  br i1 %t266, label %bb73, label %bb74
bb73:
  br label %bb75
bb74:
  br label %bb85
bb75:
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = getelementptr %"compiler/scope:Scoper", ptr %t268, i32 0, i32 0
  %t271 = load ptr, ptr %t270, !tbaa !29
  %t273 = getelementptr %"compiler/generic:Program", ptr %t271, i32 0, i32 2
  store ptr %t273, ptr %l154, !tbaa !29
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/scope:Scoper", ptr %t274, i32 0, i32 0
  %t277 = load ptr, ptr %t276, !tbaa !29
  %t279 = getelementptr %"compiler/generic:Program", ptr %t277, i32 0, i32 2
  %t280 = load i32, ptr %l1, !tbaa !23
  %t283 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t279, i32 %t280)
  store i32 %t283, ptr %l159
  br label %bb76
bb76:
  %t284 = load ptr, ptr %l154, !tbaa !29
  %t285 = load i32, ptr %l159, !tbaa !23
  %t286 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t284, i32 %t285)
  store { i64, ptr } %t286, ptr %l160
  br label %bb77
bb77:
  %t287 = load { i64, ptr }, ptr %l160, !tbaa !27
  store { i64, ptr } %t287, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t288 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t290 = extractvalue { i64, ptr } %t288, 0
  store i64 %t290, ptr %l21, !tbaa !24
  br label %bb78
bb78:
  store %olang.scope zeroinitializer, ptr %s21
  %t292 = load i64, ptr %l20, !tbaa !24
  %t293 = load i64, ptr %l21, !tbaa !24
  %t296 = icmp slt i64 %t292, %t293
  %t298 = xor i1 %t296, true
  br i1 %t298, label %bb79, label %bb80
bb79:
  call void @__olang_scope_close(ptr %s21)
  br label %bb84
bb80:
  br label %bb81
bb81:
  %t300 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t300, ptr %l167, !tbaa !27
  %t301 = load i64, ptr %l20, !tbaa !24
  %t303 = getelementptr { i64, ptr }, ptr %l167, i32 0, i32 1
  %t304 = load ptr, ptr %t303, !tbaa !27
  %t305 = getelementptr i32, ptr %t304, i64 %t301
  %t306 = load i32, ptr %t305, !tbaa !33
  %t308 = load ptr, ptr %lp2
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t308, i32 %t306)
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s21)
  br label %bb83
bb83:
  %t312 = load i64, ptr %l20, !tbaa !24
  %t314 = add i64 %t312, 1
  store i64 %t314, ptr %l20, !tbaa !24
  br label %bb78
bb84:
  br label %bb118
bb85:
  %t316 = load i32, ptr %l3
  %t318 = trunc i64 24 to i32
  %t319 = icmp eq i32 %t316, %t318
  br i1 %t319, label %bb86, label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb117
bb88:
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t323 = getelementptr %"compiler/scope:Scoper", ptr %t321, i32 0, i32 0
  %t324 = load ptr, ptr %t323, !tbaa !29
  %t326 = getelementptr %"compiler/generic:Program", ptr %t324, i32 0, i32 2
  store ptr %t326, ptr %l178, !tbaa !29
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t329 = getelementptr %"compiler/scope:Scoper", ptr %t327, i32 0, i32 0
  %t330 = load ptr, ptr %t329, !tbaa !29
  %t332 = getelementptr %"compiler/generic:Program", ptr %t330, i32 0, i32 2
  %t333 = load i32, ptr %l1, !tbaa !23
  %t336 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t332, i32 %t333)
  store i32 %t336, ptr %l183
  br label %bb89
bb89:
  %t337 = load ptr, ptr %l178, !tbaa !29
  %t338 = load i32, ptr %l183, !tbaa !23
  %t339 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t337, i32 %t338)
  store { i64, ptr } %t339, ptr %l184
  br label %bb90
bb90:
  %t340 = load { i64, ptr }, ptr %l184, !tbaa !27
  store { i64, ptr } %t340, ptr %l23, !tbaa !27
  store i64 0, ptr %l24, !tbaa !24
  %t341 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t343 = extractvalue { i64, ptr } %t341, 0
  store i64 %t343, ptr %l25, !tbaa !24
  br label %bb91
bb91:
  store %olang.scope zeroinitializer, ptr %s25
  %t345 = load i64, ptr %l24, !tbaa !24
  %t346 = load i64, ptr %l25, !tbaa !24
  %t349 = icmp slt i64 %t345, %t346
  %t351 = xor i1 %t349, true
  br i1 %t351, label %bb92, label %bb93
bb92:
  call void @__olang_scope_close(ptr %s25)
  br label %bb116
bb93:
  br label %bb94
bb94:
  %t353 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t353, ptr %l191, !tbaa !27
  %t354 = load i64, ptr %l24, !tbaa !24
  %t356 = getelementptr { i64, ptr }, ptr %l191, i32 0, i32 1
  %t357 = load ptr, ptr %t356, !tbaa !27
  %t358 = getelementptr i32, ptr %t357, i64 %t354
  %t359 = load i32, ptr %t358, !tbaa !33
  store i32 %t359, ptr %l26, !tbaa !23
  %t361 = load i32, ptr %l26, !tbaa !23
  %t363 = icmp ne i32 %t361, 0
  br i1 %t363, label %bb95, label %bb96
bb95:
  store %olang.scope zeroinitializer, ptr %s27
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t366 = load i32, ptr %l26, !tbaa !23
  %t369 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparts(ptr %v0, ptr %s27, ptr %t365, i32 %t366)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t369, ptr %l198
  br label %bb97
bb96:
  br label %bb114
bb97:
  %t370 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l198
  %t371 = call ptr @__olang_scope_alloc_a(ptr %s27, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t370, ptr %t371
  store ptr %t371, ptr %l27, !tbaa !29
  store i64 0, ptr %l28, !tbaa !24
  br label %bb98
bb98:
  store %olang.scope zeroinitializer, ptr %s28
  %t373 = load ptr, ptr %l27, !tbaa !29
  %t374 = load i64, ptr %l28, !tbaa !24
  %t377 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %s27, ptr %t373, i64 %t374)
  %t378 = extractvalue { i32, { i64, ptr } } %t377, 1
  %t379 = extractvalue { i32, { i64, ptr } } %t377, 0
  store i32 %t379, ptr %l204
  %t380 = icmp ne i32 %t379, 0
  br i1 %t380, label %bb100, label %ok.381
ok.381:
  store { i64, ptr } %t378, ptr %l203
  br label %bb99
bb99:
  %t382 = load { i64, ptr }, ptr %l203, !tbaa !27
  store { i64, ptr } %t382, ptr %l200, !tbaa !27
  br label %bb104
bb100:
  %t383 = load i32, ptr %l204, !tbaa !23
  %t384 = ashr i32 %t383, 16
  %t386 = icmp eq i32 %t384, 1
  br i1 %t386, label %bb101, label %bb102
bb101:
  br label %bb103
bb102:
  call void @__olang_check_failed(ptr @olang_loc_b99a325748da8cd5_4eb62b65b3c79869)
  unreachable
bb103:
  call void @__olang_scope_close(ptr %s28)
  br label %bb113
bb104:
  %t388 = load { i64, ptr }, ptr %l200, !tbaa !27
  store { i64, ptr } %t388, ptr %l29, !tbaa !27
  %t389 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t391 = extractvalue { i64, ptr } %t389, 0
  store i64 %t391, ptr %l30, !tbaa !24
  store i64 0, ptr %l31, !tbaa !24
  br label %bb105
bb105:
  store %olang.scope zeroinitializer, ptr %s29
  %t393 = load i64, ptr %l31, !tbaa !24
  %t394 = load i64, ptr %l30, !tbaa !24
  %t397 = icmp slt i64 %t393, %t394
  %t399 = xor i1 %t397, true
  br i1 %t399, label %bb106, label %bb107
bb106:
  call void @__olang_scope_close(ptr %s29)
  br label %bb111
bb107:
  br label %bb108
bb108:
  %t401 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t401, ptr %l213, !tbaa !27
  %t402 = load i64, ptr %l31, !tbaa !24
  %t404 = getelementptr { i64, ptr }, ptr %l213, i32 0, i32 1
  %t405 = load ptr, ptr %t404, !tbaa !27
  %t406 = getelementptr i32, ptr %t405, i64 %t402
  %t407 = load i32, ptr %t406, !tbaa !33
  %t409 = load ptr, ptr %lp2
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t409, i32 %t407)
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s29)
  br label %bb110
bb110:
  %t413 = load i64, ptr %l31, !tbaa !24
  %t415 = add i64 %t413, 1
  store i64 %t415, ptr %l31, !tbaa !24
  br label %bb105
bb111:
  %t417 = load i64, ptr %l28, !tbaa !24
  %t418 = load i64, ptr %l30, !tbaa !24
  %t421 = add i64 %t417, %t418
  store i64 %t421, ptr %l28, !tbaa !24
  call void @__olang_scope_close(ptr %s28)
  br label %bb112
bb112:
  br label %bb98
bb113:
  call void @__olang_scope_close(ptr %s27)
  br label %bb114
bb114:
  call void @__olang_scope_close(ptr %s25)
  br label %bb115
bb115:
  %t423 = load i64, ptr %l24, !tbaa !24
  %t425 = add i64 %t423, 1
  store i64 %t425, ptr %l24, !tbaa !24
  br label %bb91
bb116:
  br label %bb118
bb117:
  br label %bb118
bb118:
  %t427 = load ptr, ptr %lp2
  %t428 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t427
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t428, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epayloadAgree(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i32
  %l14 = alloca { { i64, [2 x i64] }, i1, i1 }
  %l15 = alloca { i64, [2 x i64] }
  %l16 = alloca i1
  %l26 = alloca i64
  %l29 = alloca i64
  %l47 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l55 = alloca i1
  %l56 = alloca { i64, ptr }
  %l59 = alloca i1
  %l61 = alloca i1
  %l62 = alloca ptr
  %l64 = alloca i32
  %l65 = alloca i1
  %l68 = alloca i32
  %l71 = alloca i1
  %l72 = alloca i1
  %l75 = alloca i1
  %l78 = alloca i1
  %l82 = alloca { i64, ptr }
  %l86 = alloca { { i64, [2 x i64] }, i1, i1 }
  %l92 = alloca ptr
  %l95 = alloca %"compiler/source:Span"
  %l96 = alloca %"compiler/msgs:Msg"
  %l97 = alloca i64
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i1
  %t1 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store { i64, [2 x i64] } zeroinitializer, ptr %t1
  %t2 = getelementptr { i64, [2 x i64] }, ptr %t1, i32 0, i32 0
  store i64 0, ptr %t2
  %t3 = load { i64, [2 x i64] }, ptr %t1
  store { i64, [2 x i64] } %t3, ptr %l3
  store i1 false, ptr %l4, !tbaa !21
  store i64 0, ptr %l5, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i64, ptr %l7, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb6
bb3:
  %t19 = load i64, ptr %l6, !tbaa !24
  %t20 = load i64, ptr %l5, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l7, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l7, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l29, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb5
bb5:
  %t35 = load i64, ptr %l29, !tbaa !24
  store i64 %t35, ptr %l26, !tbaa !24
  br label %bb6
bb6:
  %t36 = load i64, ptr %l26, !tbaa !24
  store i64 %t36, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load i64, ptr %l9, !tbaa !24
  %t38 = load i64, ptr %l8, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb38
bb9:
  br label %bb10
bb10:
  %t45 = load i64, ptr %l5, !tbaa !24
  %t46 = load i64, ptr %l9, !tbaa !24
  %t47 = load i64, ptr %l7, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l10, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t55, ptr %l47, !tbaa !27
  %t56 = load i64, ptr %l10, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr ptr, ptr %t59, i64 %t56
  %t61 = load ptr, ptr %t60, !tbaa !39
  store ptr %t61, ptr %l11, !tbaa !29
  %t63 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t63, ptr %l50, !tbaa !27
  %t64 = load i64, ptr %l10, !tbaa !24
  %t66 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr %"compiler/scope:Val", ptr %t67, i64 %t64
  %t69 = getelementptr %"compiler/scope:Val", ptr %t68, i32 0, i32 0
  %t70 = load i32, ptr %t69
  %t72 = trunc i64 3 to i32
  %t73 = icmp eq i32 %t70, %t72
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l55, !tbaa !21
  br label %bb14
bb12:
  %t77 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t77, ptr %l56, !tbaa !27
  %t78 = load i64, ptr %l10, !tbaa !24
  %t80 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr %"compiler/scope:Val", ptr %t81, i64 %t78
  %t83 = getelementptr %"compiler/scope:Val", ptr %t82, i32 0, i32 1
  %t84 = load { i64, [2 x i64] }, ptr %t83
  %t86 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t84)
  store i1 %t86, ptr %l59
  br label %bb13
bb13:
  %t87 = load i1, ptr %l59, !tbaa !21
  %t88 = xor i1 %t87, true
  store i1 %t88, ptr %l55, !tbaa !21
  br label %bb14
bb14:
  %t90 = load i1, ptr %l55, !tbaa !21
  br i1 %t90, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l61, !tbaa !21
  br label %bb19
bb16:
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l62, !tbaa !29
  %t92 = load ptr, ptr %l11, !tbaa !29
  %t94 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t92)
  store i32 %t94, ptr %l64
  br label %bb17
bb17:
  %t95 = load ptr, ptr %l62, !tbaa !29
  %t96 = load i32, ptr %l64, !tbaa !23
  %t97 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t95, i32 %t96)
  store i1 %t97, ptr %l65
  br label %bb18
bb18:
  %t98 = load i1, ptr %l65, !tbaa !21
  %t99 = xor i1 %t98, true
  store i1 %t99, ptr %l61, !tbaa !21
  br label %bb19
bb19:
  %t101 = load i1, ptr %l61, !tbaa !21
  br i1 %t101, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s2)
  br label %bb37
bb21:
  br label %bb22
bb22:
  %t102 = load ptr, ptr %l11, !tbaa !29
  %t104 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t102)
  store i32 %t104, ptr %l68
  br label %bb23
bb23:
  %t105 = load i32, ptr %l68, !tbaa !23
  store i32 %t105, ptr %l12, !tbaa !23
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i32, ptr %l12, !tbaa !23
  %t110 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t106, i32 %t107)
  store i1 %t110, ptr %l71
  br label %bb24
bb24:
  %t111 = load i1, ptr %l71, !tbaa !21
  br i1 %t111, label %bb25, label %bb26
bb25:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load i32, ptr %l12, !tbaa !23
  %t116 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eadmitsStores(ptr %v0, ptr %t112, i32 %t113)
  store i1 %t116, ptr %l75
  br label %bb27
bb26:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i32, ptr %l12, !tbaa !23
  %t121 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evalueAdmits(ptr %v0, ptr %t117, i32 %t118)
  store i1 %t121, ptr %l78
  br label %bb28
bb27:
  %t122 = load i1, ptr %l75, !tbaa !21
  store i1 %t122, ptr %l72, !tbaa !21
  br label %bb29
bb28:
  %t123 = load i1, ptr %l78, !tbaa !21
  store i1 %t123, ptr %l72, !tbaa !21
  br label %bb29
bb29:
  %t124 = load i1, ptr %l72, !tbaa !21
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load { i64, [2 x i64] }, ptr %l3
  %t127 = load i1, ptr %l4, !tbaa !21
  %t128 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t128, ptr %l82, !tbaa !27
  %t129 = load i64, ptr %l10, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr %"compiler/scope:Val", ptr %t132, i64 %t129
  %t134 = getelementptr %"compiler/scope:Val", ptr %t133, i32 0, i32 1
  %t135 = load { i64, [2 x i64] }, ptr %t134
  %t142 = call { { i64, [2 x i64] }, i1, i1 } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eagreeStep(ptr %v0, ptr %t125, { i64, [2 x i64] } %t126, i1 %t127, { i64, [2 x i64] } %t135, i1 %t124)
  store { { i64, [2 x i64] }, i1, i1 } %t142, ptr %l86
  br label %bb30
bb30:
  %t143 = load { { i64, [2 x i64] }, i1, i1 }, ptr %l86
  store { { i64, [2 x i64] }, i1, i1 } %t143, ptr %l14
  %t144 = getelementptr { { i64, [2 x i64] }, i1, i1 }, ptr %l14, i32 0, i32 0
  %t145 = load { i64, [2 x i64] }, ptr %t144
  store { i64, [2 x i64] } %t145, ptr %l15
  %t147 = getelementptr { { i64, [2 x i64] }, i1, i1 }, ptr %l14, i32 0, i32 1
  %t148 = load i1, ptr %t147, !tbaa !21
  store i1 %t148, ptr %l16, !tbaa !21
  %t150 = getelementptr { { i64, [2 x i64] }, i1, i1 }, ptr %l14, i32 0, i32 2
  %t151 = load i1, ptr %t150, !tbaa !21
  %t155 = xor i1 %t151, true
  br i1 %t155, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s4
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l92, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load ptr, ptr %l11, !tbaa !29
  %t162 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargAt(ptr %v0, ptr %v1, ptr %t158, ptr %t159)
  store %"compiler/source:Span" %t162, ptr %l95
  br label %bb33
bb32:
  br label %bb36
bb33:
  %t163 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2ePayloadScopesDisagree(ptr %s4)
  store %"compiler/msgs:Msg" %t163, ptr %l96
  br label %bb34
bb34:
  %t164 = load ptr, ptr %l92, !tbaa !29
  %t165 = load %"compiler/source:Span", ptr %l95
  %t166 = load %"compiler/msgs:Msg", ptr %l96
  %t167 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s4, ptr %t164, %"compiler/source:Span" %t165, %"compiler/msgs:Msg" %t166)
  store i64 %t167, ptr %l97
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb36:
  %t169 = load { i64, [2 x i64] }, ptr %l15
  %t171 = load i1, ptr %l16, !tbaa !21
  store { i64, [2 x i64] } %t169, ptr %l3
  store i1 %t171, ptr %l4, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb37
bb37:
  %t177 = load i64, ptr %l9, !tbaa !24
  %t179 = add i64 %t177, 1
  store i64 %t179, ptr %l9, !tbaa !24
  br label %bb7
bb38:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekBorrow(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca { i64, [2 x i64] }
  %l18 = alloca { i64, [2 x i64] }
  %l19 = alloca i32
  %l25 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca i1
  %l31 = alloca { i64, [2 x i64] }
  %l35 = alloca { i64, [2 x i64] }
  %rv = alloca { i64, [2 x i64] }
  %t36 = alloca { i64, [2 x i64] }, align 8
  %t64 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t18, i32 0, i32 3
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb19
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/scope:Scoper", ptr %t22, i32 0, i32 82
  %t25 = load i32, ptr %l3, !tbaa !23
  %t27 = sext i32 %t25 to i64
  %t30 = call { i32, { i64, [2 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_H65b4b9a6d1679f5b3ddedaa5b2e336bd(ptr %v0, ptr %t24, i64 %t27)
  %t31 = extractvalue { i32, { i64, [2 x i64] } } %t30, 1
  %t32 = extractvalue { i32, { i64, [2 x i64] } } %t30, 0
  store i32 %t32, ptr %l19
  %t33 = icmp ne i32 %t32, 0
  br i1 %t33, label %bb7, label %ok.34
ok.34:
  store { i64, [2 x i64] } %t31, ptr %l18
  br label %bb6
bb6:
  %t35 = load { i64, [2 x i64] }, ptr %l18
  store { i64, [2 x i64] } %t35, ptr %l13
  br label %bb9
bb7:
  br label %bb8
bb8:
  store { i64, [2 x i64] } zeroinitializer, ptr %t36
  %t37 = getelementptr { i64, [2 x i64] }, ptr %t36, i32 0, i32 0
  store i64 0, ptr %t37
  %t38 = load { i64, [2 x i64] }, ptr %t36
  store { i64, [2 x i64] } %t38, ptr %l13
  br label %bb9
bb9:
  %t40 = load { i64, [2 x i64] }, ptr %l13
  store { i64, [2 x i64] } %t40, ptr %l4
  %t41 = load { i64, [2 x i64] }, ptr %l4
  %t43 = extractvalue { i64, [2 x i64] } %t41, 0
  %t44 = icmp eq i64 %t43, 0
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load { i64, [2 x i64] }, ptr %l4
  store { i64, [2 x i64] } %t48, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l25, !tbaa !29
  %t51 = load ptr, ptr %l2, !tbaa !29
  %t53 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t51)
  store i32 %t53, ptr %l27
  br label %bb13
bb13:
  %t54 = load ptr, ptr %l25, !tbaa !29
  %t55 = load i32, ptr %l27, !tbaa !23
  %t56 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisHandle(ptr %v0, ptr %t54, i32 %t55)
  store i1 %t56, ptr %l28
  br label %bb14
bb14:
  %t57 = load i1, ptr %l28, !tbaa !21
  br i1 %t57, label %bb15, label %bb16
bb15:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load ptr, ptr %l2, !tbaa !29
  %t62 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elandTerm(ptr %v0, ptr %v1, ptr %t58, ptr %t59)
  store { i64, [2 x i64] } %t62, ptr %l31
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t63 = load { i64, [2 x i64] }, ptr %l31
  store { i64, [2 x i64] } %t63, ptr %rv
  br label %ret
bb18:
  store { i64, [2 x i64] } zeroinitializer, ptr %t64
  %t65 = getelementptr { i64, [2 x i64] }, ptr %t64, i32 0, i32 0
  store i64 0, ptr %t65
  %t66 = load { i64, [2 x i64] }, ptr %t64
  store { i64, [2 x i64] } %t66, ptr %rv
  br label %ret
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t72 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekPlace(ptr %v0, ptr %v1, ptr %t68, ptr %t69, i1 false)
  store { i64, [2 x i64] } %t72, ptr %l35
  br label %bb23
bb23:
  %t73 = load { i64, [2 x i64] }, ptr %l35
  store { i64, [2 x i64] } %t73, ptr %rv
  br label %ret
bb24:
  call void @__olang_check_failed(ptr @olang_loc_a696eb2979219c3c_c9efb41471de78f8)
  unreachable
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca ptr
  %l11 = alloca i1
  %l17 = alloca { i64, [2 x i64] }
  %l20 = alloca { i64, [2 x i64] }
  %l25 = alloca { i64, [2 x i64] }
  %l26 = alloca ptr
  %l27 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l40 = alloca { i64, [2 x i64] }
  %l41 = alloca ptr
  %l42 = alloca i1
  %l51 = alloca { i64, [2 x i64] }
  %l52 = alloca ptr
  %l53 = alloca i1
  %l58 = alloca ptr
  %l60 = alloca ptr
  %l62 = alloca i1
  %l63 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca i1
  %l68 = alloca { i64, [2 x i64] }
  %l69 = alloca ptr
  %l70 = alloca i1
  %l78 = alloca { i64, [2 x i64] }
  %l79 = alloca ptr
  %l80 = alloca i1
  %l86 = alloca { i64, [2 x i64] }
  %l87 = alloca { i64, [2 x i64] }
  %l92 = alloca { i64, [2 x i64] }
  %l93 = alloca i32
  %rv = alloca { i64, [2 x i64] }
  %t44 = alloca { i64, [2 x i64] }, align 8
  %t187 = alloca { i64, [2 x i64] }, align 8
  %t192 = alloca { i64, [2 x i64] }, align 8
  %t198 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l10, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t16 = load i1, ptr %l2, !tbaa !21
  br i1 %t16, label %bb6, label %bb7
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l3, !tbaa !23
  %t22 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewhereLives(ptr %v0, ptr %t18, i32 %t19)
  store { i64, [2 x i64] } %t22, ptr %l20
  br label %bb8
bb7:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/scope:Scoper", ptr %t23, i32 0, i32 30
  %t26 = load i32, ptr %l3, !tbaa !23
  %t28 = sext i32 %t26 to i64
  %t31 = call { i64, [2 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t25, i64 %t28)
  store { i64, [2 x i64] } %t31, ptr %l25
  br label %bb9
bb8:
  %t32 = load { i64, [2 x i64] }, ptr %l20
  store { i64, [2 x i64] } %t32, ptr %l17
  br label %bb10
bb9:
  %t33 = load { i64, [2 x i64] }, ptr %l25
  store { i64, [2 x i64] } %t33, ptr %l17
  br label %bb10
bb10:
  %t34 = load { i64, [2 x i64] }, ptr %l17
  store { i64, [2 x i64] } %t34, ptr %l9
  br label %bb68
bb11:
  %t35 = load ptr, ptr %l1, !tbaa !29
  store ptr %t35, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t36 = load ptr, ptr %l26, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t39 = load ptr, ptr %l26, !tbaa !29
  %t40 = load i64, ptr %t39
  %t42 = icmp eq i64 %t40, 1
  store i1 %t42, ptr %l27, !tbaa !21
  br label %bb13
bb13:
  %t43 = load i1, ptr %l27, !tbaa !21
  br i1 %t43, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store { i64, [2 x i64] } zeroinitializer, ptr %t44
  %t45 = getelementptr { i64, [2 x i64] }, ptr %t44, i32 0, i32 0
  store i64 3, ptr %t45
  %t46 = load { i64, [2 x i64] }, ptr %t44
  store { i64, [2 x i64] } %t46, ptr %l9
  br label %bb68
bb17:
  %t48 = load ptr, ptr %l1, !tbaa !29
  store ptr %t48, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t49 = load ptr, ptr %l31, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb18, label %bb19
bb18:
  %t52 = load ptr, ptr %l31, !tbaa !29
  %t53 = load i64, ptr %t52
  %t55 = icmp eq i64 %t53, 3
  store i1 %t55, ptr %l32, !tbaa !21
  br label %bb19
bb19:
  %t56 = load i1, ptr %l32, !tbaa !21
  br i1 %t56, label %bb20, label %bb21
bb20:
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr { i64, [4 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t59, i32 0, i32 2
  %t61 = load ptr, ptr %t60
  store ptr %t61, ptr %l4, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load ptr, ptr %l4, !tbaa !29
  %t65 = load i1, ptr %l2, !tbaa !21
  %t69 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekPlace(ptr %v0, ptr %v1, ptr %t63, ptr %t64, i1 %t65)
  store { i64, [2 x i64] } %t69, ptr %l40
  br label %bb23
bb23:
  %t70 = load { i64, [2 x i64] }, ptr %l40
  store { i64, [2 x i64] } %t70, ptr %l9
  br label %bb68
bb24:
  %t71 = load ptr, ptr %l1, !tbaa !29
  store ptr %t71, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t72 = load ptr, ptr %l41, !tbaa !29
  %t73 = icmp ne ptr %t72, null
  br i1 %t73, label %bb25, label %bb26
bb25:
  %t75 = load ptr, ptr %l41, !tbaa !29
  %t76 = load i64, ptr %t75
  %t78 = icmp eq i64 %t76, 5
  store i1 %t78, ptr %l42, !tbaa !21
  br label %bb26
bb26:
  %t79 = load i1, ptr %l42, !tbaa !21
  br i1 %t79, label %bb27, label %bb28
bb27:
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t82 = getelementptr { i64, [4 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t82, i32 0, i32 2
  %t84 = load ptr, ptr %t83
  store ptr %t84, ptr %l5, !tbaa !29
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load ptr, ptr %l5, !tbaa !29
  %t89 = getelementptr %"compiler/typed:Payload", ptr %t87, i32 0, i32 0
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t91 = load i1, ptr %l2, !tbaa !21
  %t95 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekPlace(ptr %v0, ptr %v1, ptr %t86, ptr %t90, i1 %t91)
  store { i64, [2 x i64] } %t95, ptr %l51
  br label %bb30
bb30:
  %t96 = load { i64, [2 x i64] }, ptr %l51
  store { i64, [2 x i64] } %t96, ptr %l9
  br label %bb68
bb31:
  %t97 = load ptr, ptr %l1, !tbaa !29
  store ptr %t97, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t98 = load ptr, ptr %l52, !tbaa !29
  %t99 = icmp ne ptr %t98, null
  br i1 %t99, label %bb32, label %bb33
bb32:
  %t101 = load ptr, ptr %l52, !tbaa !29
  %t102 = load i64, ptr %t101
  %t104 = icmp eq i64 %t102, 4
  store i1 %t104, ptr %l53, !tbaa !21
  br label %bb33
bb33:
  %t105 = load i1, ptr %l53, !tbaa !21
  br i1 %t105, label %bb34, label %bb35
bb34:
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr { i64, [4 x i64] }, ptr %t106, i32 0, i32 1
  %t109 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t108, i32 0, i32 2
  %t110 = load ptr, ptr %t109
  store ptr %t110, ptr %l6, !tbaa !29
  br label %bb36
bb35:
  br label %bb43
bb36:
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l58, !tbaa !29
  %t113 = load ptr, ptr %l6, !tbaa !29
  %t115 = getelementptr %"compiler/typed:Elem", ptr %t113, i32 0, i32 0
  %t116 = load ptr, ptr %t115, !tbaa !29
  store ptr %t116, ptr %l60, !tbaa !29
  %t117 = load i1, ptr %l2, !tbaa !21
  br i1 %t117, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb41
bb38:
  %t119 = load ptr, ptr %l0, !tbaa !29
  store ptr %t119, ptr %l63, !tbaa !29
  %t120 = load ptr, ptr %l6, !tbaa !29
  %t122 = getelementptr %"compiler/typed:Elem", ptr %t120, i32 0, i32 0
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t123)
  store i32 %t125, ptr %l66
  br label %bb39
bb39:
  %t126 = load ptr, ptr %l63, !tbaa !29
  %t127 = load i32, ptr %l66, !tbaa !23
  %t128 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erunLength(ptr %v0, ptr %t126, i32 %t127)
  store i1 %t128, ptr %l67
  br label %bb40
bb40:
  %t129 = load i1, ptr %l67, !tbaa !21
  store i1 %t129, ptr %l62, !tbaa !21
  br label %bb41
bb41:
  %t130 = load ptr, ptr %l58, !tbaa !29
  %t131 = load ptr, ptr %l60, !tbaa !29
  %t132 = load i1, ptr %l62, !tbaa !21
  %t133 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekPlace(ptr %v0, ptr %v1, ptr %t130, ptr %t131, i1 %t132)
  store { i64, [2 x i64] } %t133, ptr %l68
  br label %bb42
bb42:
  %t134 = load { i64, [2 x i64] }, ptr %l68
  store { i64, [2 x i64] } %t134, ptr %l9
  br label %bb68
bb43:
  %t135 = load ptr, ptr %l1, !tbaa !29
  store ptr %t135, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t136 = load ptr, ptr %l69, !tbaa !29
  %t137 = icmp ne ptr %t136, null
  br i1 %t137, label %bb44, label %bb45
bb44:
  %t139 = load ptr, ptr %l69, !tbaa !29
  %t140 = load i64, ptr %t139
  %t142 = icmp eq i64 %t140, 2
  store i1 %t142, ptr %l70, !tbaa !21
  br label %bb45
bb45:
  %t143 = load i1, ptr %l70, !tbaa !21
  br i1 %t143, label %bb46, label %bb47
bb46:
  %t144 = load ptr, ptr %l1, !tbaa !29
  %t146 = getelementptr { i64, [4 x i64] }, ptr %t144, i32 0, i32 1
  %t147 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t146, i32 0, i32 2
  %t148 = load ptr, ptr %t147
  store ptr %t148, ptr %l7, !tbaa !29
  br label %bb48
bb47:
  br label %bb50
bb48:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load ptr, ptr %l7, !tbaa !29
  %t155 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekTerm(ptr %v0, ptr %v1, ptr %t150, ptr %t151)
  store { i64, [2 x i64] } %t155, ptr %l78
  br label %bb49
bb49:
  %t156 = load { i64, [2 x i64] }, ptr %l78
  store { i64, [2 x i64] } %t156, ptr %l9
  br label %bb68
bb50:
  %t157 = load ptr, ptr %l1, !tbaa !29
  store ptr %t157, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t158 = load ptr, ptr %l79, !tbaa !29
  %t159 = icmp ne ptr %t158, null
  br i1 %t159, label %bb51, label %bb52
bb51:
  %t161 = load ptr, ptr %l79, !tbaa !29
  %t162 = load i64, ptr %t161
  %t164 = icmp eq i64 %t162, 6
  store i1 %t164, ptr %l80, !tbaa !21
  br label %bb52
bb52:
  %t165 = load i1, ptr %l80, !tbaa !21
  br i1 %t165, label %bb53, label %bb54
bb53:
  %t166 = load ptr, ptr %l1, !tbaa !29
  %t168 = getelementptr { i64, [4 x i64] }, ptr %t166, i32 0, i32 1
  %t169 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t168, i32 0, i32 3
  %t170 = load i32, ptr %t169
  store i32 %t170, ptr %l8, !tbaa !23
  br label %bb55
bb54:
  br label %bb63
bb55:
  %t172 = load i1, ptr %l2, !tbaa !21
  br i1 %t172, label %bb56, label %bb57
bb56:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/scope:Scoper", ptr %t174, i32 0, i32 82
  %t177 = load i32, ptr %l8, !tbaa !23
  %t179 = sext i32 %t177 to i64
  %t182 = call { i32, { i64, [2 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_H65b4b9a6d1679f5b3ddedaa5b2e336bd(ptr %v0, ptr %t176, i64 %t179)
  %t183 = extractvalue { i32, { i64, [2 x i64] } } %t182, 1
  %t184 = extractvalue { i32, { i64, [2 x i64] } } %t182, 0
  store i32 %t184, ptr %l93
  %t185 = icmp ne i32 %t184, 0
  br i1 %t185, label %bb59, label %ok.186
ok.186:
  store { i64, [2 x i64] } %t183, ptr %l92
  br label %bb58
bb57:
  store { i64, [2 x i64] } zeroinitializer, ptr %t187
  %t188 = getelementptr { i64, [2 x i64] }, ptr %t187, i32 0, i32 0
  store i64 0, ptr %t188
  %t189 = load { i64, [2 x i64] }, ptr %t187
  store { i64, [2 x i64] } %t189, ptr %l86
  br label %bb62
bb58:
  %t191 = load { i64, [2 x i64] }, ptr %l92
  store { i64, [2 x i64] } %t191, ptr %l87
  br label %bb61
bb59:
  br label %bb60
bb60:
  store { i64, [2 x i64] } zeroinitializer, ptr %t192
  %t193 = getelementptr { i64, [2 x i64] }, ptr %t192, i32 0, i32 0
  store i64 0, ptr %t193
  %t194 = load { i64, [2 x i64] }, ptr %t192
  store { i64, [2 x i64] } %t194, ptr %l87
  br label %bb61
bb61:
  %t196 = load { i64, [2 x i64] }, ptr %l87
  store { i64, [2 x i64] } %t196, ptr %l86
  br label %bb62
bb62:
  %t197 = load { i64, [2 x i64] }, ptr %l86
  store { i64, [2 x i64] } %t197, ptr %l9
  br label %bb68
bb63:
  br i1 true, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb67
bb66:
  store { i64, [2 x i64] } zeroinitializer, ptr %t198
  %t199 = getelementptr { i64, [2 x i64] }, ptr %t198, i32 0, i32 0
  store i64 0, ptr %t199
  %t200 = load { i64, [2 x i64] }, ptr %t198
  store { i64, [2 x i64] } %t200, ptr %l9
  br label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_7a4f424795892e70_52f604b9bdf9a7cc)
  unreachable
bb68:
  %t202 = load { i64, [2 x i64] }, ptr %l9
  store { i64, [2 x i64] } %t202, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eplaceCallOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca i1
  %l45 = alloca i1
  %l46 = alloca ptr
  %l50 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eplaceCallOf(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store ptr %t20, ptr %l15
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l15, !tbaa !29
  store ptr %t21, ptr %l6, !tbaa !29
  br label %bb37
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t23 = load ptr, ptr %l16, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l16, !tbaa !29
  %t27 = load i64, ptr %t26
  %t29 = icmp eq i64 %t27, 4
  store i1 %t29, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l17, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Elem", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t44 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eplaceCallOf(ptr %v0, ptr %v1, ptr %t37, ptr %t41)
  store ptr %t44, ptr %l25
  br label %bb13
bb13:
  %t45 = load ptr, ptr %l25, !tbaa !29
  store ptr %t45, ptr %l6, !tbaa !29
  br label %bb37
bb14:
  %t46 = load ptr, ptr %l1, !tbaa !29
  store ptr %t46, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t47 = load ptr, ptr %l26, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb15, label %bb16
bb15:
  %t50 = load ptr, ptr %l26, !tbaa !29
  %t51 = load i64, ptr %t50
  %t53 = icmp eq i64 %t51, 5
  store i1 %t53, ptr %l27, !tbaa !21
  br label %bb16
bb16:
  %t54 = load i1, ptr %l27, !tbaa !21
  br i1 %t54, label %bb17, label %bb18
bb17:
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t57, i32 0, i32 2
  %t59 = load ptr, ptr %t58
  store ptr %t59, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Payload", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t68 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eplaceCallOf(ptr %v0, ptr %v1, ptr %t61, ptr %t65)
  store ptr %t68, ptr %l35
  br label %bb20
bb20:
  %t69 = load ptr, ptr %l35, !tbaa !29
  store ptr %t69, ptr %l6, !tbaa !29
  br label %bb37
bb21:
  %t70 = load ptr, ptr %l1, !tbaa !29
  store ptr %t70, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t71 = load ptr, ptr %l36, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb22, label %bb23
bb22:
  %t74 = load ptr, ptr %l36, !tbaa !29
  %t75 = load i64, ptr %t74
  %t77 = icmp eq i64 %t75, 6
  store i1 %t77, ptr %l37, !tbaa !21
  br label %bb23
bb23:
  %t78 = load i1, ptr %l37, !tbaa !21
  br i1 %t78, label %bb24, label %bb25
bb24:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr { i64, [4 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t81, i32 0, i32 2
  %t83 = load ptr, ptr %t82
  store ptr %t83, ptr %l5, !tbaa !29
  br label %bb26
bb25:
  br label %bb32
bb26:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load ptr, ptr %l5, !tbaa !29
  %t90 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %t85, ptr %t86)
  store i1 %t90, ptr %l45
  br label %bb27
bb27:
  %t91 = load i1, ptr %l45, !tbaa !21
  br i1 %t91, label %bb28, label %bb29
bb28:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l5, !tbaa !29
  %t97 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallOf(ptr %v0, ptr %v1, ptr %t92, ptr %t93)
  store ptr %t97, ptr %l50
  br label %bb30
bb29:
  store ptr null, ptr %l46, !tbaa !29
  br label %bb31
bb30:
  %t98 = load ptr, ptr %l50, !tbaa !29
  store ptr %t98, ptr %l46, !tbaa !29
  br label %bb31
bb31:
  %t99 = load ptr, ptr %l46, !tbaa !29
  store ptr %t99, ptr %l6, !tbaa !29
  br label %bb37
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store ptr null, ptr %l6, !tbaa !29
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_da1486de58138450_28784370eb22bac)
  unreachable
bb37:
  %t100 = load ptr, ptr %l6, !tbaa !29
  store ptr %t100, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2equalifiesMove(ptr %v0, ptr %v1, ptr %a0, %"compiler/typed:Local" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/typed:Local"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca { i64, [2 x i64] }
  %l6 = alloca i32
  %l10 = alloca i1
  %l14 = alloca i1
  %l24 = alloca i1
  %l25 = alloca i1
  %l28 = alloca i1
  %l29 = alloca i1
  %l32 = alloca i1
  %l33 = alloca i1
  %l36 = alloca i1
  %l46 = alloca i1
  %l51 = alloca i1
  %l57 = alloca i32
  %l60 = alloca i1
  %l63 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/typed:Local" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/typed:Local", ptr %l1, i32 0, i32 2
  %t2 = load i32, ptr %t1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t5 = load i32, ptr %l3, !tbaa !23
  %t8 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFunc(ptr %v0, ptr %t4, i32 %t5)
  store i1 %t8, ptr %l10
  br label %bb1
bb1:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l3, !tbaa !23
  %t15 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t11, i32 %t12)
  store i1 %t15, ptr %l14
  br label %bb5
bb5:
  %t16 = load i1, ptr %l14, !tbaa !21
  br i1 %t16, label %bb6, label %bb7
bb6:
  %t17 = getelementptr %"compiler/typed:Local", ptr %l1, i32 0, i32 5
  %t18 = load { i64, [2 x i64] }, ptr %t17
  store { i64, [2 x i64] } %t18, ptr %l4
  %t20 = load { i64, [2 x i64] }, ptr %l4
  %t22 = extractvalue { i64, [2 x i64] } %t20, 0
  %t23 = icmp eq i64 %t22, 1
  br i1 %t23, label %bb8, label %bb9
bb7:
  br label %bb32
bb8:
  br label %bb12
bb9:
  %t25 = load { i64, [2 x i64] }, ptr %l4
  %t27 = extractvalue { i64, [2 x i64] } %t25, 0
  %t28 = icmp eq i64 %t27, 5
  br i1 %t28, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 false, ptr %rv
  br label %ret
bb17:
  call void @__olang_check_failed(ptr @olang_loc_554265ba1528b3d8_d73d8ae267adc184)
  unreachable
bb18:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t36 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %t31, ptr %t32)
  store i1 %t36, ptr %l24
  br label %bb19
bb19:
  %t37 = load i1, ptr %l24, !tbaa !21
  br i1 %t37, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb23
bb21:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load ptr, ptr %l2, !tbaa !29
  %t42 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisNullLit(ptr %v0, ptr %v1, ptr %t38, ptr %t39)
  store i1 %t42, ptr %l28
  br label %bb22
bb22:
  %t43 = load i1, ptr %l28, !tbaa !21
  store i1 %t43, ptr %l25, !tbaa !21
  br label %bb23
bb23:
  %t44 = load i1, ptr %l25, !tbaa !21
  br i1 %t44, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb27
bb25:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t49 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisData(ptr %v0, ptr %v1, ptr %t45, ptr %t46)
  store i1 %t49, ptr %l32
  br label %bb26
bb26:
  %t50 = load i1, ptr %l32, !tbaa !21
  store i1 %t50, ptr %l29, !tbaa !21
  br label %bb27
bb27:
  %t51 = load i1, ptr %l29, !tbaa !21
  br i1 %t51, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb31
bb29:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t56 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estaticLiteral(ptr %v0, ptr %v1, ptr %t52, ptr %t53)
  store i1 %t56, ptr %l36
  br label %bb30
bb30:
  %t57 = load i1, ptr %l36, !tbaa !21
  store i1 %t57, ptr %l33, !tbaa !21
  br label %bb31
bb31:
  %t58 = load i1, ptr %l33, !tbaa !21
  store i1 %t58, ptr %rv
  br label %ret
bb32:
  %t59 = getelementptr %"compiler/typed:Local", ptr %l1, i32 0, i32 5
  %t60 = load { i64, [2 x i64] }, ptr %t59
  store { i64, [2 x i64] } %t60, ptr %l5
  %t62 = load { i64, [2 x i64] }, ptr %l5
  %t64 = extractvalue { i64, [2 x i64] } %t62, 0
  %t65 = icmp eq i64 %t64, 0
  br i1 %t65, label %bb33, label %bb34
bb33:
  br label %bb37
bb34:
  %t67 = load { i64, [2 x i64] }, ptr %l5
  %t69 = extractvalue { i64, [2 x i64] } %t67, 0
  %t70 = icmp eq i64 %t69, 5
  br i1 %t70, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb43
bb38:
  br i1 true, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store i1 false, ptr %rv
  br label %ret
bb42:
  call void @__olang_check_failed(ptr @olang_loc_c484f993348186a9_88a471068962d75)
  unreachable
bb43:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load ptr, ptr %l2, !tbaa !29
  %t78 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeHere(ptr %v0, ptr %v1, ptr %t73, ptr %t74)
  store i1 %t78, ptr %l46
  br label %bb44
bb44:
  %t79 = load i1, ptr %l46, !tbaa !21
  %t80 = xor i1 %t79, true
  br i1 %t80, label %bb45, label %bb46
bb45:
  store i1 false, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i32, ptr %l3, !tbaa !23
  %t87 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t83, i32 %t84)
  store i1 %t87, ptr %l51
  br label %bb48
bb48:
  %t88 = load i1, ptr %l51, !tbaa !21
  br i1 %t88, label %bb49, label %bb50
bb49:
  store i1 true, ptr %rv
  br label %ret
bb50:
  br label %bb51
bb51:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/scope:Scoper", ptr %t90, i32 0, i32 0
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Program", ptr %t93, i32 0, i32 2
  %t96 = load i32, ptr %l3, !tbaa !23
  %t99 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t95, i32 %t96)
  store i32 %t99, ptr %l57
  br label %bb52
bb52:
  %t100 = load i32, ptr %l57
  store i32 %t100, ptr %l6
  %t101 = load i32, ptr %l6
  %t103 = trunc i64 19 to i32
  %t104 = icmp eq i32 %t101, %t103
  br i1 %t104, label %bb53, label %bb54
bb53:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb55
bb54:
  %t106 = load i32, ptr %l6
  %t108 = trunc i64 18 to i32
  %t109 = icmp eq i32 %t106, %t108
  store i1 %t109, ptr %l60, !tbaa !21
  br label %bb55
bb55:
  %t111 = load i1, ptr %l60, !tbaa !21
  br i1 %t111, label %bb56, label %bb57
bb56:
  store i1 true, ptr %l63, !tbaa !21
  br label %bb58
bb57:
  %t112 = load i32, ptr %l6
  %t114 = trunc i64 22 to i32
  %t115 = icmp eq i32 %t112, %t114
  store i1 %t115, ptr %l63, !tbaa !21
  br label %bb58
bb58:
  %t117 = load i1, ptr %l63, !tbaa !21
  store i1 %t117, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ereadOnlyAsBuilt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l5 = alloca i32
  %l8 = alloca i1
  %l10 = alloca i1
  %l15 = alloca i64
  %l20 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca i64
  %l28 = alloca i1
  %l32 = alloca ptr
  %l35 = alloca %"compiler/source:Span"
  %l36 = alloca %"compiler/msgs:Msg"
  %l37 = alloca i64
  %l38 = alloca ptr
  %l41 = alloca %"compiler/source:Span"
  %l43 = alloca { ptr, ptr }
  %l48 = alloca i32
  %l49 = alloca { i64, ptr }
  %l53 = alloca ptr
  %l62 = alloca %"compiler/typed:Local"
  %l64 = alloca { i64, ptr }
  %l67 = alloca %"compiler/msgs:Msg"
  %l68 = alloca i64
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t1)
  store i32 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i32, ptr %l5, !tbaa !23
  store i32 %t4, ptr %l2, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l2, !tbaa !23
  %t9 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load i1, ptr %l8, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb6
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/scope:Scoper", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l2, !tbaa !23
  %t22 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t18, i32 %t19)
  store i64 %t22, ptr %l15
  br label %bb5
bb5:
  %t23 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t24 = load i64, ptr %l15, !tbaa !24
  %t26 = and i64 %t24, %t23
  %t28 = icmp ne i64 %t26, 0
  store i1 %t28, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t30 = load i1, ptr %l10, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l20, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t38 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %t33, ptr %t34)
  store ptr %t38, ptr %l24
  br label %bb10
bb10:
  %t39 = load ptr, ptr %l20, !tbaa !29
  %t40 = load ptr, ptr %l24, !tbaa !29
  %t41 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparamRoot(ptr %v0, ptr %v1, ptr %t39, ptr %t40)
  store i64 %t41, ptr %l25
  br label %bb11
bb11:
  %t42 = load i64, ptr %l25, !tbaa !24
  store i64 %t42, ptr %l3, !tbaa !24
  %t43 = load i64, ptr %l3, !tbaa !24
  %t45 = icmp slt i64 %t43, 0
  br i1 %t45, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb14
bb13:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/scope:Scoper", ptr %t47, i32 0, i32 5
  %t50 = load { ptr, ptr }, ptr %t49
  %t52 = extractvalue { ptr, ptr } %t50, 0
  %t53 = extractvalue { ptr, ptr } zeroinitializer, 0
  %t54 = icmp eq ptr %t52, %t53
  %t55 = extractvalue { ptr, ptr } %t50, 1
  %t56 = extractvalue { ptr, ptr } zeroinitializer, 1
  %t57 = icmp eq ptr %t55, %t56
  %t58 = and i1 %t54, %t57
  store i1 %t58, ptr %l28, !tbaa !21
  br label %bb14
bb14:
  %t60 = load i1, ptr %l28, !tbaa !21
  br i1 %t60, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l32, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t66 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eopTok(ptr %v0, ptr %v1, ptr %t62, ptr %t63)
  store %"compiler/source:Span" %t66, ptr %l35
  br label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l38, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t72 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eopTok(ptr %v0, ptr %v1, ptr %t68, ptr %t69)
  store %"compiler/source:Span" %t72, ptr %l41
  br label %bb20
bb17:
  %t73 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyToBuiltResultNo(ptr %s2)
  store %"compiler/msgs:Msg" %t73, ptr %l36
  br label %bb18
bb18:
  %t74 = load ptr, ptr %l32, !tbaa !29
  %t75 = load %"compiler/source:Span", ptr %l35
  %t76 = load %"compiler/msgs:Msg", ptr %l36
  %t77 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s2, ptr %t74, %"compiler/source:Span" %t75, %"compiler/msgs:Msg" %t76)
  store i64 %t77, ptr %l37
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb20:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/scope:Scoper", ptr %t78, i32 0, i32 5
  %t81 = load { ptr, ptr }, ptr %t80
  store { ptr, ptr } %t81, ptr %l43
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/scope:Scoper", ptr %t82, i32 0, i32 0
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/generic:Program", ptr %t85, i32 0, i32 2
  %t88 = load i32, ptr %l2, !tbaa !23
  %t91 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t87, i32 %t88)
  store i32 %t91, ptr %l48
  br label %bb21
bb21:
  %t92 = load { ptr, ptr }, ptr %l43
  %t93 = extractvalue { ptr, ptr } %t92, 0
  %t94 = extractvalue { ptr, ptr } %t92, 1
  %t95 = load i32, ptr %l48, !tbaa !23
  %t96 = call { i64, ptr } %t93(ptr %t94, ptr %s3, i32 %t95)
  store { i64, ptr } %t96, ptr %l49
  br label %bb22
bb22:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/scope:Scoper", ptr %t97, i32 0, i32 0
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 0
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = getelementptr %"compiler/load:Loader", ptr %t103, i32 0, i32 3
  %t106 = load ptr, ptr %t105, !tbaa !29
  store ptr %t106, ptr %l53, !tbaa !29
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/scope:Scoper", ptr %t107, i32 0, i32 25
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = icmp eq ptr %t110, null
  br i1 %t112, label %bb23, label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_86025ef78c18fd61_51e54585f4e29a5d)
  unreachable
bb24:
  br label %bb25
bb25:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/scope:Scoper", ptr %t114, i32 0, i32 25
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t120 = getelementptr %"compiler/typed:Body", ptr %t117, i32 0, i32 7
  %t121 = load i64, ptr %l3, !tbaa !24
  %t124 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t120, i64 %t121)
  store %"compiler/typed:Local" %t124, ptr %l62
  br label %bb26
bb26:
  %t125 = getelementptr %"compiler/typed:Local", ptr %l62, i32 0, i32 0
  %t126 = load i32, ptr %t125, !tbaa !23
  %t127 = load ptr, ptr %l53, !tbaa !29
  %t129 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t127, i32 %t126)
  store { i64, ptr } %t129, ptr %l64
  br label %bb27
bb27:
  %t130 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 1
  %t132 = extractvalue { i64, ptr } %t130, 0
  %t133 = extractvalue { i64, ptr } { i64 1, ptr @.d10 }, 1
  %t134 = extractvalue { i64, ptr } { i64 1, ptr @.d10 }, 0
  %t135 = add i64 %t132, %t134
  %t136 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 1
  %t138 = extractvalue { i64, ptr } %t136, 0
  %t139 = add i64 %t135, %t138
  %t140 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t139)
  call void @olang_textcopy(ptr %t140, ptr %t131, i64 %t132)
  %t141 = getelementptr i8, ptr %t140, i64 %t132
  call void @olang_textcopy(ptr %t141, ptr %t133, i64 %t134)
  %t142 = getelementptr i8, ptr %t141, i64 %t134
  call void @olang_textcopy(ptr %t142, ptr %t137, i64 %t138)
  %t143 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t140, 1
  %t146 = extractvalue { i64, ptr } %t144, 0
  %t147 = extractvalue { i64, ptr } %t144, 1
  %t148 = mul i64 %t146, 1
  %t149 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t148)
  call void @llvm.memcpy.p0.p0.i64(ptr %t149, ptr %t147, i64 %t148, i1 false)
  %t150 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  %t153 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyToBuiltResult(ptr %s3, ptr %s3, { i64, ptr } %t151)
  store %"compiler/msgs:Msg" %t153, ptr %l67
  br label %bb28
bb28:
  %t154 = load ptr, ptr %l38, !tbaa !29
  %t155 = load %"compiler/source:Span", ptr %l41
  %t156 = load %"compiler/msgs:Msg", ptr %l67
  %t157 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s3, ptr %t154, %"compiler/source:Span" %t155, %"compiler/msgs:Msg" %t156)
  store i64 %t157, ptr %l68
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb30:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eregionKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l11 = alloca %"compiler/typed:Local"
  %l15 = alloca i1
  %l18 = alloca i1
  %l19 = alloca ptr
  %l25 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 25
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_ef7f9cdde83b319d_c7773e471ac0d6b1)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 25
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 7
  %t18 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t14, i64 %a1)
  store %"compiler/typed:Local" %t18, ptr %l11
  br label %bb4
bb4:
  %t19 = getelementptr %"compiler/typed:Local", ptr %l11, i32 0, i32 4
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l2
  %t22 = load i32, ptr %l2
  %t24 = trunc i64 0 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb14
bb6:
  %t27 = load i32, ptr %l2
  %t29 = trunc i64 5 to i32
  %t30 = icmp eq i32 %t27, %t29
  br i1 %t30, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l19, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/scope:Scoper", ptr %t33, i32 0, i32 25
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = icmp eq ptr %t36, null
  br i1 %t38, label %bb9, label %bb10
bb8:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb13
bb9:
  call void @__olang_check_failed(ptr @olang_loc_2a41cd82eb4d8236_be11ba524906eaaa)
  unreachable
bb10:
  br label %bb11
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/scope:Scoper", ptr %t40, i32 0, i32 25
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t44 = load ptr, ptr %l19, !tbaa !29
  %t46 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisLambda(ptr %v0, ptr %v0, ptr %t44, ptr %t43)
  store i1 %t46, ptr %l25
  br label %bb12
bb12:
  %t47 = load i1, ptr %l25, !tbaa !21
  store i1 %t47, ptr %l18, !tbaa !21
  br label %bb13
bb13:
  %t48 = load i1, ptr %l18, !tbaa !21
  store i1 %t48, ptr %l15, !tbaa !21
  br label %bb14
bb14:
  %t49 = load i1, ptr %l15, !tbaa !21
  store i1 %t49, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eslotKind(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca i1
  %l29 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca i1
  %l39 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t10 = load i64, ptr @G_2ecompiler_2fscope_2eFitGlobal, !tbaa !24
  store i64 %t10, ptr %l5, !tbaa !24
  br label %bb38
bb6:
  %t12 = load ptr, ptr %l1, !tbaa !29
  store ptr %t12, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t13 = load ptr, ptr %l11, !tbaa !29
  %t14 = icmp ne ptr %t13, null
  br i1 %t14, label %bb7, label %bb8
bb7:
  %t16 = load ptr, ptr %l11, !tbaa !29
  %t17 = load i64, ptr %t16
  %t19 = icmp eq i64 %t17, 3
  store i1 %t19, ptr %l12, !tbaa !21
  br label %bb8
bb8:
  %t20 = load i1, ptr %l12, !tbaa !21
  br i1 %t20, label %bb9, label %bb10
bb9:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [4 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t23, i32 0, i32 2
  %t25 = load ptr, ptr %t24
  store ptr %t25, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t31 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eslotKind(ptr %v0, ptr %v1, ptr %t27, ptr %t28)
  store i64 %t31, ptr %l19
  br label %bb12
bb12:
  %t32 = load i64, ptr %l19, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  br label %bb38
bb13:
  %t33 = load ptr, ptr %l1, !tbaa !29
  store ptr %t33, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t34 = load ptr, ptr %l20, !tbaa !29
  %t35 = icmp ne ptr %t34, null
  br i1 %t35, label %bb14, label %bb15
bb14:
  %t37 = load ptr, ptr %l20, !tbaa !29
  %t38 = load i64, ptr %t37
  %t40 = icmp eq i64 %t38, 4
  store i1 %t40, ptr %l21, !tbaa !21
  br label %bb15
bb15:
  %t41 = load i1, ptr %l21, !tbaa !21
  br i1 %t41, label %bb16, label %bb17
bb16:
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = getelementptr { i64, [4 x i64] }, ptr %t42, i32 0, i32 1
  %t45 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t44, i32 0, i32 2
  %t46 = load ptr, ptr %t45
  store ptr %t46, ptr %l3, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t51 = getelementptr %"compiler/typed:Elem", ptr %t49, i32 0, i32 0
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t55 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eslotKind(ptr %v0, ptr %v1, ptr %t48, ptr %t52)
  store i64 %t55, ptr %l29
  br label %bb19
bb19:
  %t56 = load i64, ptr %l29, !tbaa !24
  store i64 %t56, ptr %l5, !tbaa !24
  br label %bb38
bb20:
  %t57 = load ptr, ptr %l1, !tbaa !29
  store ptr %t57, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t58 = load ptr, ptr %l30, !tbaa !29
  %t59 = icmp ne ptr %t58, null
  br i1 %t59, label %bb21, label %bb22
bb21:
  %t61 = load ptr, ptr %l30, !tbaa !29
  %t62 = load i64, ptr %t61
  %t64 = icmp eq i64 %t62, 5
  store i1 %t64, ptr %l31, !tbaa !21
  br label %bb22
bb22:
  %t65 = load i1, ptr %l31, !tbaa !21
  br i1 %t65, label %bb23, label %bb24
bb23:
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr { i64, [4 x i64] }, ptr %t66, i32 0, i32 1
  %t69 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t68, i32 0, i32 2
  %t70 = load ptr, ptr %t69
  store ptr %t70, ptr %l4, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load ptr, ptr %l4, !tbaa !29
  %t75 = getelementptr %"compiler/typed:Payload", ptr %t73, i32 0, i32 0
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t79 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eslotKind(ptr %v0, ptr %v1, ptr %t72, ptr %t76)
  store i64 %t79, ptr %l39
  br label %bb26
bb26:
  %t80 = load i64, ptr %l39, !tbaa !24
  store i64 %t80, ptr %l5, !tbaa !24
  br label %bb38
bb27:
  %t81 = load ptr, ptr %l1, !tbaa !29
  store ptr %t81, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t82 = load ptr, ptr %l40, !tbaa !29
  %t83 = icmp ne ptr %t82, null
  br i1 %t83, label %bb28, label %bb29
bb28:
  %t85 = load ptr, ptr %l40, !tbaa !29
  %t86 = load i64, ptr %t85
  %t88 = icmp eq i64 %t86, 0
  store i1 %t88, ptr %l41, !tbaa !21
  br label %bb29
bb29:
  %t89 = load i1, ptr %l41, !tbaa !21
  br i1 %t89, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  %t90 = load i64, ptr @G_2ecompiler_2fscope_2eFitValue, !tbaa !24
  store i64 %t90, ptr %l5, !tbaa !24
  br label %bb38
bb33:
  br i1 true, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  %t92 = load i64, ptr @G_2ecompiler_2fscope_2eFitField, !tbaa !24
  store i64 %t92, ptr %l5, !tbaa !24
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_b810a17036e0b04c_ef2bb18623cc9e48)
  unreachable
bb38:
  %t94 = load i64, ptr %l5, !tbaa !24
  store i64 %t94, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esplitRefs(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l12 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i1
  %l17 = alloca i1
  %l19 = alloca i1
  %l23 = alloca { i64, [2 x i64] }
  %l24 = alloca ptr
  %l25 = alloca i1
  %l34 = alloca i1
  %l39 = alloca { i64, ptr }
  %l41 = alloca { i64, [2 x i64] }
  %l42 = alloca ptr
  %l43 = alloca i1
  %l50 = alloca { i64, [2 x i64] }
  %rv = alloca { i64, [2 x i64] }
  %t31 = alloca { i64, [2 x i64] }, align 8
  %t105 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l12, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t17)
  store i32 %t19, ptr %l14
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t21 = load i32, ptr %l14, !tbaa !23
  %t22 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t20, i32 %t21)
  store i1 %t22, ptr %l15
  br label %bb7
bb7:
  %t23 = load i1, ptr %l15, !tbaa !21
  %t24 = xor i1 %t23, true
  br i1 %t24, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb11
bb9:
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = call i1 @compiler_2fscope_2eflThroughRef(ptr %v1, ptr %t26)
  store i1 %t28, ptr %l19
  br label %bb10
bb10:
  %t29 = load i1, ptr %l19, !tbaa !21
  store i1 %t29, ptr %l17, !tbaa !21
  br label %bb11
bb11:
  %t30 = load i1, ptr %l17, !tbaa !21
  br i1 %t30, label %bb12, label %bb13
bb12:
  store { i64, [2 x i64] } zeroinitializer, ptr %t31
  %t32 = getelementptr { i64, [2 x i64] }, ptr %t31, i32 0, i32 0
  store i64 0, ptr %t32
  %t33 = load { i64, [2 x i64] }, ptr %t31
  store { i64, [2 x i64] } %t33, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t39 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekPlace(ptr %v0, ptr %v1, ptr %t35, ptr %t36, i1 true)
  store { i64, [2 x i64] } %t39, ptr %l23
  br label %bb15
bb15:
  %t40 = load { i64, [2 x i64] }, ptr %l23
  store { i64, [2 x i64] } %t40, ptr %rv
  br label %ret
bb16:
  %t41 = load ptr, ptr %l1, !tbaa !29
  store ptr %t41, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t42 = load ptr, ptr %l24, !tbaa !29
  %t43 = icmp ne ptr %t42, null
  br i1 %t43, label %bb17, label %bb18
bb17:
  %t45 = load ptr, ptr %l24, !tbaa !29
  %t46 = load i64, ptr %t45
  %t48 = icmp eq i64 %t46, 9
  store i1 %t48, ptr %l25, !tbaa !21
  br label %bb18
bb18:
  %t49 = load i1, ptr %l25, !tbaa !21
  br i1 %t49, label %bb19, label %bb20
bb19:
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr { i64, [5 x i64] }, ptr %t50, i32 0, i32 1
  %t53 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t52, i32 0, i32 2
  %t54 = load i32, ptr %t53
  store i32 %t54, ptr %l3
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t58 = getelementptr { i64, [5 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t58, i32 0, i32 4
  %t60 = load { i64, ptr }, ptr %t59
  store { i64, ptr } %t60, ptr %l4, !tbaa !27
  br label %bb21
bb20:
  br label %bb29
bb21:
  %t62 = load i32, ptr %l3
  %t64 = trunc i64 20 to i32
  %t65 = icmp eq i32 %t62, %t64
  br i1 %t65, label %bb22, label %bb23
bb22:
  %t67 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t71 = icmp sgt i64 %t69, 0
  store i1 %t71, ptr %l34, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb24
bb24:
  %t73 = load i1, ptr %l34, !tbaa !21
  br i1 %t73, label %bb25, label %bb26
bb25:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t75, ptr %l39, !tbaa !27
  %t76 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr ptr, ptr %t77, i64 0
  %t79 = load ptr, ptr %t78, !tbaa !39
  %t82 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esplitRefs(ptr %v0, ptr %v1, ptr %t74, ptr %t79)
  store { i64, [2 x i64] } %t82, ptr %l41
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t83 = load { i64, [2 x i64] }, ptr %l41
  store { i64, [2 x i64] } %t83, ptr %rv
  br label %ret
bb28:
  br label %bb41
bb29:
  %t84 = load ptr, ptr %l1, !tbaa !29
  store ptr %t84, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t85 = load ptr, ptr %l42, !tbaa !29
  %t86 = icmp ne ptr %t85, null
  br i1 %t86, label %bb30, label %bb31
bb30:
  %t88 = load ptr, ptr %l42, !tbaa !29
  %t89 = load i64, ptr %t88
  %t91 = icmp eq i64 %t89, 17
  store i1 %t91, ptr %l43, !tbaa !21
  br label %bb31
bb31:
  %t92 = load i1, ptr %l43, !tbaa !21
  br i1 %t92, label %bb32, label %bb33
bb32:
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t95 = getelementptr { i64, [5 x i64] }, ptr %t93, i32 0, i32 1
  %t96 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t95, i32 0, i32 2
  %t97 = load ptr, ptr %t96
  store ptr %t97, ptr %l5, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load ptr, ptr %l5, !tbaa !29
  %t103 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esplitRefs(ptr %v0, ptr %v1, ptr %t99, ptr %t100)
  store { i64, [2 x i64] } %t103, ptr %l50
  br label %bb35
bb35:
  %t104 = load { i64, [2 x i64] }, ptr %l50
  store { i64, [2 x i64] } %t104, ptr %rv
  br label %ret
bb36:
  br i1 true, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_9da86a51b48ec4c_4c8b634b3e5eba18)
  unreachable
bb41:
  store { i64, [2 x i64] } zeroinitializer, ptr %t105
  %t106 = getelementptr { i64, [2 x i64] }, ptr %t105, i32 0, i32 0
  store i64 0, ptr %t106
  %t107 = load { i64, [2 x i64] }, ptr %t105
  store { i64, [2 x i64] } %t107, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l32 = alloca ptr
  %l34 = alloca %"compiler/source:Span"
  %l35 = alloca ptr
  %l36 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca i1
  %l74 = alloca %"compiler/scope:Val"
  %l75 = alloca ptr
  %l76 = alloca i1
  %l86 = alloca %"compiler/scope:Val"
  %l94 = alloca ptr
  %l95 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca i1
  %l111 = alloca ptr
  %l112 = alloca i1
  %l122 = alloca ptr
  %l123 = alloca i1
  %l126 = alloca ptr
  %l127 = alloca i1
  %l135 = alloca %"compiler/scope:Val"
  %l136 = alloca ptr
  %l137 = alloca i1
  %l148 = alloca %"compiler/scope:Val"
  %l152 = alloca %"compiler/scope:Val"
  %l153 = alloca ptr
  %l154 = alloca i1
  %l161 = alloca i1
  %l163 = alloca ptr
  %l166 = alloca i64
  %l167 = alloca ptr
  %l169 = alloca ptr
  %l172 = alloca i64
  %l174 = alloca i32
  %l175 = alloca i32
  %l180 = alloca ptr
  %l181 = alloca i1
  %l189 = alloca ptr
  %l190 = alloca i1
  %l204 = alloca i32
  %l207 = alloca i32
  %l208 = alloca i32
  %l217 = alloca { i64, ptr }
  %l225 = alloca ptr
  %l226 = alloca i1
  %l236 = alloca ptr
  %l237 = alloca i1
  %l242 = alloca ptr
  %l244 = alloca ptr
  %l246 = alloca { i64, [2 x i64] }
  %l247 = alloca %"compiler/scope:Val"
  %s18 = alloca %olang.scope
  %t106 = alloca { i64, [2 x i64] }, align 8
  %t134 = alloca { i64, [2 x i64] }, align 8
  %t248 = alloca { i64, [2 x i64] }, align 8
  %t279 = alloca { i64, [2 x i64] }, align 8
  %t288 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/scope:Scoper", ptr %t5, i32 0, i32 36
  %t8 = load %"compiler/source:Span", ptr %t7
  store %"compiler/source:Span" %t8, ptr %l2
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l32, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aStmt_2eSpan(ptr %v1, ptr %t11)
  store %"compiler/source:Span" %t13, ptr %l34
  br label %bb4
bb4:
  %t14 = load %"compiler/source:Span", ptr %l34
  %t15 = load ptr, ptr %l32, !tbaa !29
  %t16 = getelementptr %"compiler/scope:Scoper", ptr %t15, i32 0, i32 36
  store %"compiler/source:Span" %t14, ptr %t16
  %t17 = load ptr, ptr %l1, !tbaa !29
  store ptr %t17, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t18 = load ptr, ptr %l35, !tbaa !29
  %t19 = icmp ne ptr %t18, null
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t21 = load ptr, ptr %l35, !tbaa !29
  %t22 = load i64, ptr %t21
  %t24 = icmp eq i64 %t22, 0
  store i1 %t24, ptr %l36, !tbaa !21
  br label %bb6
bb6:
  %t25 = load i1, ptr %l36, !tbaa !21
  br i1 %t25, label %bb7, label %bb8
bb7:
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr { i64, [3 x i64] }, ptr %t26, i32 0, i32 1
  %t29 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t28, i32 0, i32 0
  %t30 = load %"compiler/source:Span", ptr %t29
  store %"compiler/source:Span" %t30, ptr %l3
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr { i64, [3 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t34, i32 0, i32 1
  %t36 = load i32, ptr %t35
  store i32 %t36, ptr %l4, !tbaa !23
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr { i64, [3 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l5, !tbaa !29
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load %"compiler/source:Span", ptr %l3
  %t46 = load i32, ptr %l4, !tbaa !23
  %t47 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elet(ptr %v0, ptr %v1, ptr %t44, %"compiler/source:Span" %t45, i32 %t46, ptr %t47)
  br label %bb10
bb10:
  br label %bb133
bb11:
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t54 = load ptr, ptr %l50, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb12, label %bb13
bb12:
  %t57 = load ptr, ptr %l50, !tbaa !29
  %t58 = load i64, ptr %t57
  %t60 = icmp eq i64 %t58, 1
  store i1 %t60, ptr %l51, !tbaa !21
  br label %bb13
bb13:
  %t61 = load i1, ptr %l51, !tbaa !21
  br i1 %t61, label %bb14, label %bb15
bb14:
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr { i64, [3 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t64, i32 0, i32 0
  %t66 = load %"compiler/source:Span", ptr %t65
  store %"compiler/source:Span" %t66, ptr %l6
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [3 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t70, i32 0, i32 1
  %t72 = load ptr, ptr %t71
  store ptr %t72, ptr %l7, !tbaa !29
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [3 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t76, i32 0, i32 2
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l8, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load %"compiler/source:Span", ptr %l6
  %t82 = load ptr, ptr %l7, !tbaa !29
  %t83 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eassign(ptr %v0, ptr %v1, ptr %v1, ptr %t80, %"compiler/source:Span" %t81, ptr %t82, ptr %t83)
  br label %bb17
bb17:
  br label %bb133
bb18:
  %t88 = load ptr, ptr %l1, !tbaa !29
  store ptr %t88, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t89 = load ptr, ptr %l64, !tbaa !29
  %t90 = icmp ne ptr %t89, null
  br i1 %t90, label %bb19, label %bb20
bb19:
  %t92 = load ptr, ptr %l64, !tbaa !29
  %t93 = load i64, ptr %t92
  %t95 = icmp eq i64 %t93, 2
  store i1 %t95, ptr %l65, !tbaa !21
  br label %bb20
bb20:
  %t96 = load i1, ptr %l65, !tbaa !21
  br i1 %t96, label %bb21, label %bb22
bb21:
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr { i64, [3 x i64] }, ptr %t97, i32 0, i32 1
  %t100 = getelementptr { %"compiler/source:Span", ptr }, ptr %t99, i32 0, i32 1
  %t101 = load ptr, ptr %t100
  store ptr %t101, ptr %l9, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load ptr, ptr %l9, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t106
  %t107 = getelementptr { i64, [2 x i64] }, ptr %t106, i32 0, i32 0
  store i64 0, ptr %t107
  %t108 = load { i64, [2 x i64] }, ptr %t106
  %t112 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t103, ptr %t104, { i64, [2 x i64] } %t108)
  store %"compiler/scope:Val" %t112, ptr %l74
  br label %bb24
bb24:
  br label %bb133
bb25:
  %t113 = load ptr, ptr %l1, !tbaa !29
  store ptr %t113, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t114 = load ptr, ptr %l75, !tbaa !29
  %t115 = icmp ne ptr %t114, null
  br i1 %t115, label %bb26, label %bb27
bb26:
  %t117 = load ptr, ptr %l75, !tbaa !29
  %t118 = load i64, ptr %t117
  %t120 = icmp eq i64 %t118, 3
  store i1 %t120, ptr %l76, !tbaa !21
  br label %bb27
bb27:
  %t121 = load i1, ptr %l76, !tbaa !21
  br i1 %t121, label %bb28, label %bb29
bb28:
  %t122 = load ptr, ptr %l1, !tbaa !29
  %t124 = getelementptr { i64, [3 x i64] }, ptr %t122, i32 0, i32 1
  %t125 = getelementptr { %"compiler/source:Span", ptr }, ptr %t124, i32 0, i32 1
  %t126 = load ptr, ptr %t125
  store ptr %t126, ptr %l10, !tbaa !29
  br label %bb30
bb29:
  br label %bb34
bb30:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load ptr, ptr %l10, !tbaa !29
  %t131 = getelementptr %"compiler/typed:If", ptr %t129, i32 0, i32 0
  %t132 = load ptr, ptr %t131, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t134
  %t135 = getelementptr { i64, [2 x i64] }, ptr %t134, i32 0, i32 0
  store i64 0, ptr %t135
  %t136 = load { i64, [2 x i64] }, ptr %t134
  %t140 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t128, ptr %t132, { i64, [2 x i64] } %t136)
  store %"compiler/scope:Val" %t140, ptr %l86
  br label %bb31
bb31:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load ptr, ptr %l10, !tbaa !29
  %t144 = getelementptr %"compiler/typed:If", ptr %t142, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblock(ptr %v0, ptr %v1, ptr %t141, ptr %t145)
  br label %bb32
bb32:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load ptr, ptr %l10, !tbaa !29
  %t152 = getelementptr %"compiler/typed:If", ptr %t150, i32 0, i32 2
  %t153 = load ptr, ptr %t152, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblock(ptr %v0, ptr %v1, ptr %t149, ptr %t153)
  br label %bb33
bb33:
  br label %bb133
bb34:
  %t156 = load ptr, ptr %l1, !tbaa !29
  store ptr %t156, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t157 = load ptr, ptr %l94, !tbaa !29
  %t158 = icmp ne ptr %t157, null
  br i1 %t158, label %bb35, label %bb36
bb35:
  %t160 = load ptr, ptr %l94, !tbaa !29
  %t161 = load i64, ptr %t160
  %t163 = icmp eq i64 %t161, 4
  store i1 %t163, ptr %l95, !tbaa !21
  br label %bb36
bb36:
  %t164 = load i1, ptr %l95, !tbaa !21
  br i1 %t164, label %bb37, label %bb38
bb37:
  %t165 = load ptr, ptr %l1, !tbaa !29
  %t167 = getelementptr { i64, [3 x i64] }, ptr %t165, i32 0, i32 1
  %t168 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t167, i32 0, i32 1
  %t169 = load ptr, ptr %t168
  store ptr %t169, ptr %l11, !tbaa !29
  %t171 = load ptr, ptr %l1, !tbaa !29
  %t173 = getelementptr { i64, [3 x i64] }, ptr %t171, i32 0, i32 1
  %t174 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t173, i32 0, i32 2
  %t175 = load ptr, ptr %t174
  store ptr %t175, ptr %l12, !tbaa !29
  br label %bb39
bb38:
  br label %bb42
bb39:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblock(ptr %v0, ptr %v1, ptr %t177, ptr %t178)
  br label %bb40
bb40:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblock(ptr %v0, ptr %v1, ptr %t182, ptr %t183)
  br label %bb41
bb41:
  br label %bb133
bb42:
  %t186 = load ptr, ptr %l1, !tbaa !29
  store ptr %t186, ptr %l107, !tbaa !29
  store i1 false, ptr %l108, !tbaa !21
  %t187 = load ptr, ptr %l107, !tbaa !29
  %t188 = icmp ne ptr %t187, null
  br i1 %t188, label %bb43, label %bb44
bb43:
  %t190 = load ptr, ptr %l107, !tbaa !29
  %t191 = load i64, ptr %t190
  %t193 = icmp eq i64 %t191, 5
  store i1 %t193, ptr %l108, !tbaa !21
  br label %bb44
bb44:
  %t194 = load i1, ptr %l108, !tbaa !21
  br i1 %t194, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb133
bb48:
  %t195 = load ptr, ptr %l1, !tbaa !29
  store ptr %t195, ptr %l111, !tbaa !29
  store i1 false, ptr %l112, !tbaa !21
  %t196 = load ptr, ptr %l111, !tbaa !29
  %t197 = icmp ne ptr %t196, null
  br i1 %t197, label %bb49, label %bb50
bb49:
  %t199 = load ptr, ptr %l111, !tbaa !29
  %t200 = load i64, ptr %t199
  %t202 = icmp eq i64 %t200, 6
  store i1 %t202, ptr %l112, !tbaa !21
  br label %bb50
bb50:
  %t203 = load i1, ptr %l112, !tbaa !21
  br i1 %t203, label %bb51, label %bb52
bb51:
  %t204 = load ptr, ptr %l1, !tbaa !29
  %t206 = getelementptr { i64, [3 x i64] }, ptr %t204, i32 0, i32 1
  %t207 = getelementptr { %"compiler/source:Span", ptr }, ptr %t206, i32 0, i32 0
  %t208 = load %"compiler/source:Span", ptr %t207
  store %"compiler/source:Span" %t208, ptr %l13
  %t210 = load ptr, ptr %l1, !tbaa !29
  %t212 = getelementptr { i64, [3 x i64] }, ptr %t210, i32 0, i32 1
  %t213 = getelementptr { %"compiler/source:Span", ptr }, ptr %t212, i32 0, i32 1
  %t214 = load ptr, ptr %t213
  store ptr %t214, ptr %l14, !tbaa !29
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load %"compiler/source:Span", ptr %l13
  %t218 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eret(ptr %v0, ptr %v1, ptr %t216, %"compiler/source:Span" %t217, ptr %t218)
  br label %bb54
bb54:
  br label %bb133
bb55:
  %t222 = load ptr, ptr %l1, !tbaa !29
  store ptr %t222, ptr %l122, !tbaa !29
  store i1 false, ptr %l123, !tbaa !21
  %t223 = load ptr, ptr %l122, !tbaa !29
  %t224 = icmp ne ptr %t223, null
  br i1 %t224, label %bb56, label %bb57
bb56:
  %t226 = load ptr, ptr %l122, !tbaa !29
  %t227 = load i64, ptr %t226
  %t229 = icmp eq i64 %t227, 7
  store i1 %t229, ptr %l123, !tbaa !21
  br label %bb57
bb57:
  %t230 = load i1, ptr %l123, !tbaa !21
  br i1 %t230, label %bb58, label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb133
bb61:
  %t231 = load ptr, ptr %l1, !tbaa !29
  store ptr %t231, ptr %l126, !tbaa !29
  store i1 false, ptr %l127, !tbaa !21
  %t232 = load ptr, ptr %l126, !tbaa !29
  %t233 = icmp ne ptr %t232, null
  br i1 %t233, label %bb62, label %bb63
bb62:
  %t235 = load ptr, ptr %l126, !tbaa !29
  %t236 = load i64, ptr %t235
  %t238 = icmp eq i64 %t236, 8
  store i1 %t238, ptr %l127, !tbaa !21
  br label %bb63
bb63:
  %t239 = load i1, ptr %l127, !tbaa !21
  br i1 %t239, label %bb64, label %bb65
bb64:
  %t240 = load ptr, ptr %l1, !tbaa !29
  %t242 = getelementptr { i64, [3 x i64] }, ptr %t240, i32 0, i32 1
  %t243 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t242, i32 0, i32 2
  %t244 = load ptr, ptr %t243
  store ptr %t244, ptr %l15, !tbaa !29
  br label %bb66
bb65:
  br label %bb68
bb66:
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t247 = load ptr, ptr %l15, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t248
  %t249 = getelementptr { i64, [2 x i64] }, ptr %t248, i32 0, i32 0
  store i64 0, ptr %t249
  %t250 = load { i64, [2 x i64] }, ptr %t248
  %t254 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t246, ptr %t247, { i64, [2 x i64] } %t250)
  store %"compiler/scope:Val" %t254, ptr %l135
  br label %bb67
bb67:
  br label %bb133
bb68:
  %t255 = load ptr, ptr %l1, !tbaa !29
  store ptr %t255, ptr %l136, !tbaa !29
  store i1 false, ptr %l137, !tbaa !21
  %t256 = load ptr, ptr %l136, !tbaa !29
  %t257 = icmp ne ptr %t256, null
  br i1 %t257, label %bb69, label %bb70
bb69:
  %t259 = load ptr, ptr %l136, !tbaa !29
  %t260 = load i64, ptr %t259
  %t262 = icmp eq i64 %t260, 9
  store i1 %t262, ptr %l137, !tbaa !21
  br label %bb70
bb70:
  %t263 = load i1, ptr %l137, !tbaa !21
  br i1 %t263, label %bb71, label %bb72
bb71:
  %t264 = load ptr, ptr %l1, !tbaa !29
  %t266 = getelementptr { i64, [3 x i64] }, ptr %t264, i32 0, i32 1
  %t267 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t266, i32 0, i32 1
  %t268 = load ptr, ptr %t267
  store ptr %t268, ptr %l16, !tbaa !29
  %t270 = load ptr, ptr %l1, !tbaa !29
  %t272 = getelementptr { i64, [3 x i64] }, ptr %t270, i32 0, i32 1
  %t273 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t272, i32 0, i32 2
  %t274 = load ptr, ptr %t273
  store ptr %t274, ptr %l17, !tbaa !29
  br label %bb73
bb72:
  br label %bb76
bb73:
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t277 = load ptr, ptr %l16, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t279
  %t280 = getelementptr { i64, [2 x i64] }, ptr %t279, i32 0, i32 0
  store i64 0, ptr %t280
  %t281 = load { i64, [2 x i64] }, ptr %t279
  %t285 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t276, ptr %t277, { i64, [2 x i64] } %t281)
  store %"compiler/scope:Val" %t285, ptr %l148
  br label %bb74
bb74:
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t287 = load ptr, ptr %l17, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t288
  %t289 = getelementptr { i64, [2 x i64] }, ptr %t288, i32 0, i32 0
  store i64 0, ptr %t289
  %t290 = load { i64, [2 x i64] }, ptr %t288
  %t294 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t286, ptr %t287, { i64, [2 x i64] } %t290)
  store %"compiler/scope:Val" %t294, ptr %l152
  br label %bb75
bb75:
  br label %bb133
bb76:
  %t295 = load ptr, ptr %l1, !tbaa !29
  store ptr %t295, ptr %l153, !tbaa !29
  store i1 false, ptr %l154, !tbaa !21
  %t296 = load ptr, ptr %l153, !tbaa !29
  %t297 = icmp ne ptr %t296, null
  br i1 %t297, label %bb77, label %bb78
bb77:
  %t299 = load ptr, ptr %l153, !tbaa !29
  %t300 = load i64, ptr %t299
  %t302 = icmp eq i64 %t300, 10
  store i1 %t302, ptr %l154, !tbaa !21
  br label %bb78
bb78:
  %t303 = load i1, ptr %l154, !tbaa !21
  br i1 %t303, label %bb79, label %bb80
bb79:
  %t304 = load ptr, ptr %l1, !tbaa !29
  %t306 = getelementptr { i64, [3 x i64] }, ptr %t304, i32 0, i32 1
  %t307 = getelementptr { %"compiler/source:Span", ptr }, ptr %t306, i32 0, i32 1
  %t308 = load ptr, ptr %t307
  store ptr %t308, ptr %l18, !tbaa !29
  br label %bb81
bb80:
  br label %bb91
bb81:
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t311 = load ptr, ptr %l18, !tbaa !29
  %t314 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eforWrap(ptr %v0, ptr %v1, ptr %t310, ptr %t311)
  store i1 %t314, ptr %l161
  br label %bb82
bb82:
  %t315 = load i1, ptr %l161, !tbaa !21
  br i1 %t315, label %bb83, label %bb84
bb83:
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t318 = getelementptr %"compiler/scope:Scoper", ptr %t316, i32 0, i32 85
  store ptr %t318, ptr %l163, !tbaa !29
  %t319 = load ptr, ptr %l18, !tbaa !29
  %t321 = getelementptr %"compiler/typed:Block", ptr %t319, i32 0, i32 0
  %t322 = load i32, ptr %t321, !tbaa !23
  %t324 = sext i32 %t322 to i64
  store i64 %t324, ptr %l166, !tbaa !24
  %t325 = load ptr, ptr %l0, !tbaa !29
  store ptr %t325, ptr %l167, !tbaa !29
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t328 = getelementptr %"compiler/scope:Scoper", ptr %t326, i32 0, i32 32
  store ptr %t328, ptr %l169, !tbaa !29
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t331 = getelementptr %"compiler/scope:Scoper", ptr %t329, i32 0, i32 32
  %t333 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t331)
  store i64 %t333, ptr %l172
  br label %bb85
bb84:
  br label %bb89
bb85:
  %t334 = load i64, ptr %l172, !tbaa !24
  %t335 = sub i64 %t334, 1
  %t336 = load ptr, ptr %l169, !tbaa !29
  %t338 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t336, i64 %t335)
  store i32 %t338, ptr %l174
  br label %bb86
bb86:
  %t339 = load ptr, ptr %l167, !tbaa !29
  %t340 = load i32, ptr %l174, !tbaa !23
  %t341 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elift(ptr %v0, ptr %t339, i32 %t340)
  store i32 %t341, ptr %l175
  br label %bb87
bb87:
  %t342 = load i32, ptr %l175, !tbaa !23
  %t343 = sext i32 %t342 to i64
  %t344 = load ptr, ptr %l163, !tbaa !29
  %t345 = load i64, ptr %l166, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t344, i64 %t345, i64 %t343)
  br label %bb88
bb88:
  br label %bb89
bb89:
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t348 = load ptr, ptr %l18, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblock(ptr %v0, ptr %v1, ptr %t347, ptr %t348)
  br label %bb90
bb90:
  br label %bb133
bb91:
  %t352 = load ptr, ptr %l1, !tbaa !29
  store ptr %t352, ptr %l180, !tbaa !29
  store i1 false, ptr %l181, !tbaa !21
  %t353 = load ptr, ptr %l180, !tbaa !29
  %t354 = icmp ne ptr %t353, null
  br i1 %t354, label %bb92, label %bb93
bb92:
  %t356 = load ptr, ptr %l180, !tbaa !29
  %t357 = load i64, ptr %t356
  %t359 = icmp eq i64 %t357, 11
  store i1 %t359, ptr %l181, !tbaa !21
  br label %bb93
bb93:
  %t360 = load i1, ptr %l181, !tbaa !21
  br i1 %t360, label %bb94, label %bb95
bb94:
  %t361 = load ptr, ptr %l1, !tbaa !29
  %t363 = getelementptr { i64, [3 x i64] }, ptr %t361, i32 0, i32 1
  %t364 = getelementptr { %"compiler/source:Span", ptr }, ptr %t363, i32 0, i32 1
  %t365 = load ptr, ptr %t364
  store ptr %t365, ptr %l19, !tbaa !29
  br label %bb96
bb95:
  br label %bb98
bb96:
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t368 = load ptr, ptr %l19, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblock(ptr %v0, ptr %v1, ptr %t367, ptr %t368)
  br label %bb97
bb97:
  br label %bb133
bb98:
  %t372 = load ptr, ptr %l1, !tbaa !29
  store ptr %t372, ptr %l189, !tbaa !29
  store i1 false, ptr %l190, !tbaa !21
  %t373 = load ptr, ptr %l189, !tbaa !29
  %t374 = icmp ne ptr %t373, null
  br i1 %t374, label %bb99, label %bb100
bb99:
  %t376 = load ptr, ptr %l189, !tbaa !29
  %t377 = load i64, ptr %t376
  %t379 = icmp eq i64 %t377, 12
  store i1 %t379, ptr %l190, !tbaa !21
  br label %bb100
bb100:
  %t380 = load i1, ptr %l190, !tbaa !21
  br i1 %t380, label %bb101, label %bb102
bb101:
  %t381 = load ptr, ptr %l1, !tbaa !29
  %t383 = getelementptr { i64, [3 x i64] }, ptr %t381, i32 0, i32 1
  %t384 = getelementptr { %"compiler/source:Span", ptr }, ptr %t383, i32 0, i32 1
  %t385 = load ptr, ptr %t384
  store ptr %t385, ptr %l20, !tbaa !29
  br label %bb103
bb102:
  br label %bb117
bb103:
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t389 = getelementptr %"compiler/scope:Scoper", ptr %t387, i32 0, i32 65
  %t390 = load ptr, ptr %l20, !tbaa !29
  %t392 = getelementptr %"compiler/typed:Join", ptr %t390, i32 0, i32 0
  %t393 = load ptr, ptr %t392, !tbaa !29
  %t395 = getelementptr %"compiler/typed:Block", ptr %t393, i32 0, i32 0
  %t396 = load i32, ptr %t395, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockId_3e_2ePus_Hc98eca5dddbfee899ac629cbaebab24b(ptr %v0, ptr %t389, i32 %t396)
  br label %bb104
bb104:
  %t399 = load ptr, ptr %l0, !tbaa !29
  %t400 = load ptr, ptr %l20, !tbaa !29
  %t402 = getelementptr %"compiler/typed:Join", ptr %t400, i32 0, i32 0
  %t403 = load ptr, ptr %t402, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblock(ptr %v0, ptr %v1, ptr %t399, ptr %t403)
  br label %bb105
bb105:
  %t407 = load ptr, ptr %l0, !tbaa !29
  %t409 = getelementptr %"compiler/scope:Scoper", ptr %t407, i32 0, i32 65
  %t411 = call { i32, i32 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockId_3e_2ePop_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t409)
  %t412 = extractvalue { i32, i32 } %t411, 1
  %t413 = extractvalue { i32, i32 } %t411, 0
  store i32 %t413, ptr %l208
  %t414 = icmp ne i32 %t413, 0
  br i1 %t414, label %bb107, label %ok.415
ok.415:
  store i32 %t412, ptr %l207
  br label %bb106
bb106:
  %t416 = load i32, ptr %l207, !tbaa !23
  store i32 %t416, ptr %l204, !tbaa !23
  br label %bb109
bb107:
  br label %bb108
bb108:
  br label %bb109
bb109:
  %t417 = load ptr, ptr %l20, !tbaa !29
  %t419 = getelementptr %"compiler/typed:Join", ptr %t417, i32 0, i32 2
  %t420 = load { i64, ptr }, ptr %t419, !tbaa !27
  store { i64, ptr } %t420, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t422 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t424 = extractvalue { i64, ptr } %t422, 0
  store i64 %t424, ptr %l23, !tbaa !24
  br label %bb110
bb110:
  store %olang.scope zeroinitializer, ptr %s18
  %t426 = load i64, ptr %l22, !tbaa !24
  %t427 = load i64, ptr %l23, !tbaa !24
  %t430 = icmp slt i64 %t426, %t427
  %t432 = xor i1 %t430, true
  br i1 %t432, label %bb111, label %bb112
bb111:
  call void @__olang_scope_close(ptr %s18)
  br label %bb116
bb112:
  br label %bb113
bb113:
  %t434 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t434, ptr %l217, !tbaa !27
  %t435 = load i64, ptr %l22, !tbaa !24
  %t437 = getelementptr { i64, ptr }, ptr %l217, i32 0, i32 1
  %t438 = load ptr, ptr %t437, !tbaa !27
  %t439 = getelementptr ptr, ptr %t438, i64 %t435
  %t440 = load ptr, ptr %t439, !tbaa !39
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t445 = getelementptr %"compiler/typed:Clause", ptr %t440, i32 0, i32 3
  %t446 = load ptr, ptr %t445, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblock(ptr %v0, ptr %v1, ptr %t442, ptr %t446)
  br label %bb114
bb114:
  call void @__olang_scope_close(ptr %s18)
  br label %bb115
bb115:
  %t449 = load i64, ptr %l22, !tbaa !24
  %t451 = add i64 %t449, 1
  store i64 %t451, ptr %l22, !tbaa !24
  br label %bb110
bb116:
  br label %bb133
bb117:
  %t453 = load ptr, ptr %l1, !tbaa !29
  store ptr %t453, ptr %l225, !tbaa !29
  store i1 false, ptr %l226, !tbaa !21
  %t454 = load ptr, ptr %l225, !tbaa !29
  %t455 = icmp ne ptr %t454, null
  br i1 %t455, label %bb118, label %bb119
bb118:
  %t457 = load ptr, ptr %l225, !tbaa !29
  %t458 = load i64, ptr %t457
  %t460 = icmp eq i64 %t458, 13
  store i1 %t460, ptr %l226, !tbaa !21
  br label %bb119
bb119:
  %t461 = load i1, ptr %l226, !tbaa !21
  br i1 %t461, label %bb120, label %bb121
bb120:
  %t462 = load ptr, ptr %l1, !tbaa !29
  %t464 = getelementptr { i64, [3 x i64] }, ptr %t462, i32 0, i32 1
  %t465 = getelementptr { %"compiler/source:Span", ptr }, ptr %t464, i32 0, i32 0
  %t466 = load %"compiler/source:Span", ptr %t465
  store %"compiler/source:Span" %t466, ptr %l25
  %t468 = load ptr, ptr %l1, !tbaa !29
  %t470 = getelementptr { i64, [3 x i64] }, ptr %t468, i32 0, i32 1
  %t471 = getelementptr { %"compiler/source:Span", ptr }, ptr %t470, i32 0, i32 1
  %t472 = load ptr, ptr %t471
  store ptr %t472, ptr %l26, !tbaa !29
  br label %bb122
bb121:
  br label %bb124
bb122:
  %t474 = load ptr, ptr %l0, !tbaa !29
  %t475 = load %"compiler/source:Span", ptr %l25
  %t476 = load ptr, ptr %l26, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2espawn(ptr %v0, ptr %v1, ptr %t474, %"compiler/source:Span" %t475, ptr %t476)
  br label %bb123
bb123:
  br label %bb133
bb124:
  %t480 = load ptr, ptr %l1, !tbaa !29
  store ptr %t480, ptr %l236, !tbaa !29
  store i1 false, ptr %l237, !tbaa !21
  %t481 = load ptr, ptr %l236, !tbaa !29
  %t482 = icmp ne ptr %t481, null
  br i1 %t482, label %bb125, label %bb126
bb125:
  %t484 = load ptr, ptr %l236, !tbaa !29
  %t485 = load i64, ptr %t484
  %t487 = icmp eq i64 %t485, 14
  store i1 %t487, ptr %l237, !tbaa !21
  br label %bb126
bb126:
  %t488 = load i1, ptr %l237, !tbaa !21
  br i1 %t488, label %bb127, label %bb128
bb127:
  %t489 = load ptr, ptr %l1, !tbaa !29
  %t491 = getelementptr { i64, [3 x i64] }, ptr %t489, i32 0, i32 1
  %t492 = getelementptr { %"compiler/source:Span", ptr }, ptr %t491, i32 0, i32 1
  %t493 = load ptr, ptr %t492
  store ptr %t493, ptr %l27, !tbaa !29
  br label %bb129
bb128:
  br label %bb132
bb129:
  %t495 = load ptr, ptr %l0, !tbaa !29
  store ptr %t495, ptr %l242, !tbaa !29
  %t496 = load ptr, ptr %l27, !tbaa !29
  store ptr %t496, ptr %l244, !tbaa !29
  %t498 = load ptr, ptr %l0, !tbaa !29
  %t500 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehere(ptr %v0, ptr %t498)
  store { i64, [2 x i64] } %t500, ptr %l246
  br label %bb130
bb130:
  %t501 = load ptr, ptr %l242, !tbaa !29
  %t502 = load ptr, ptr %l244, !tbaa !29
  %t503 = load { i64, [2 x i64] }, ptr %l246
  %t504 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t501, ptr %t502, { i64, [2 x i64] } %t503)
  store %"compiler/scope:Val" %t504, ptr %l247
  br label %bb131
bb131:
  br label %bb133
bb132:
  call void @__olang_check_failed(ptr @olang_loc_e68fbdb964820230_ed59a3d360e211c)
  unreachable
bb133:
  %t505 = load ptr, ptr %l0, !tbaa !29
  %t506 = load %"compiler/source:Span", ptr %l2
  %t509 = getelementptr %"compiler/scope:Scoper", ptr %t505, i32 0, i32 36
  store %"compiler/source:Span" %t506, ptr %t509
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreParam(ptr %v0, ptr %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i1
  %l9 = alloca i64
  %l12 = alloca i64
  %l14 = alloca i1
  %l17 = alloca i1
  %l18 = alloca i1
  %l19 = alloca ptr
  %l28 = alloca %"compiler/typed:Local"
  %l30 = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eregionParam(ptr %v0, ptr %t1, i64 %t2)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l1, !tbaa !24
  %t7 = load i64, ptr %l1, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l1, !tbaa !24
  store i64 %t11, ptr %l9, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/scope:Scoper", ptr %t12, i32 0, i32 77
  %t16 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l12
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb5
bb4:
  %t17 = load i64, ptr %l9, !tbaa !24
  %t18 = load i64, ptr %l12, !tbaa !24
  %t19 = icmp slt i64 %t17, %t18
  store i1 %t19, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t21 = load i1, ptr %l8, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i64, ptr %l1, !tbaa !24
  %t26 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eregionKind(ptr %v0, ptr %t22, i64 %t23)
  store i1 %t26, ptr %l17
  br label %bb8
bb7:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb9
bb8:
  %t27 = load i1, ptr %l17, !tbaa !21
  store i1 %t27, ptr %l14, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l14, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l19, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/scope:Scoper", ptr %t30, i32 0, i32 25
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = icmp eq ptr %t33, null
  br i1 %t35, label %bb12, label %bb13
bb11:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb17
bb12:
  call void @__olang_check_failed(ptr @olang_loc_d10963641a9b1fed_5d8116c763841fe1)
  unreachable
bb13:
  br label %bb14
bb14:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/scope:Scoper", ptr %t37, i32 0, i32 25
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t43 = getelementptr %"compiler/typed:Body", ptr %t40, i32 0, i32 7
  %t44 = load i64, ptr %l1, !tbaa !24
  %t47 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t43, i64 %t44)
  store %"compiler/typed:Local" %t47, ptr %l28
  br label %bb15
bb15:
  %t48 = getelementptr %"compiler/typed:Local", ptr %l28, i32 0, i32 2
  %t49 = load i32, ptr %t48, !tbaa !23
  %t50 = load ptr, ptr %l19, !tbaa !29
  %t52 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t50, i32 %t49)
  store i1 %t52, ptr %l30
  br label %bb16
bb16:
  %t53 = load i1, ptr %l30, !tbaa !21
  store i1 %t53, ptr %l18, !tbaa !21
  br label %bb17
bb17:
  %t54 = load i1, ptr %l18, !tbaa !21
  br i1 %t54, label %bb18, label %bb19
bb18:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/scope:Scoper", ptr %t55, i32 0, i32 77
  %t58 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t57, i64 %t58, i1 true)
  br label %bb20
bb19:
  br label %bb26
bb20:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/scope:Scoper", ptr %t61, i32 0, i32 78
  %t64 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t63, i64 %t64, i1 true)
  br label %bb21
bb21:
  br i1 %a2, label %bb22, label %bb23
bb22:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/scope:Scoper", ptr %t69, i32 0, i32 79
  %t72 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t71, i64 %t72, i1 true)
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreThrough(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l15 = alloca i32
  %l22 = alloca i64
  %l27 = alloca ptr
  %l32 = alloca i32
  %l33 = alloca i1
  %l48 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i32
  %l63 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l65 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l69 = alloca i32
  %l78 = alloca { i64, ptr }
  %l83 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca i32
  %l93 = alloca i64
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l15
  br label %bb1
bb1:
  %t11 = load i32, ptr %l15
  store i32 %t11, ptr %l2
  %t12 = load i32, ptr %l2
  %t14 = trunc i64 20 to i32
  %t15 = icmp eq i32 %t12, %t14
  br i1 %t15, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb11
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/scope:Scoper", ptr %t17, i32 0, i32 0
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 2
  %t23 = load i32, ptr %l1, !tbaa !23
  %t26 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t22, i32 %t23)
  store i64 %t26, ptr %l22
  br label %bb5
bb5:
  %t27 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t28 = load i64, ptr %l22, !tbaa !24
  %t30 = and i64 %t28, %t27
  %t32 = icmp eq i64 %t30, 0
  br i1 %t32, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l27, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/scope:Scoper", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = getelementptr %"compiler/generic:Program", ptr %t39, i32 0, i32 2
  %t42 = load i32, ptr %l1, !tbaa !23
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l32
  br label %bb9
bb9:
  %t46 = load ptr, ptr %l27, !tbaa !29
  %t47 = load i32, ptr %l32, !tbaa !23
  %t48 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eassignableHolds(ptr %v0, ptr %t46, i32 %t47)
  store i1 %t48, ptr %l33
  br label %bb10
bb10:
  %t49 = load i1, ptr %l33, !tbaa !21
  store i1 %t49, ptr %rv
  br label %ret
bb11:
  %t50 = load i32, ptr %l2
  %t52 = trunc i64 21 to i32
  %t53 = icmp eq i32 %t50, %t52
  br i1 %t53, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i1 false, ptr %rv
  br label %ret
bb15:
  %t56 = load i32, ptr %l2
  %t58 = trunc i64 18 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb16, label %bb17
bb16:
  br label %bb26
bb17:
  %t61 = load i32, ptr %l2
  %t63 = trunc i64 22 to i32
  %t64 = icmp eq i32 %t61, %t63
  br i1 %t64, label %bb18, label %bb19
bb18:
  br label %bb26
bb19:
  %t66 = load i32, ptr %l2
  %t68 = trunc i64 23 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb20, label %bb21
bb20:
  br label %bb26
bb21:
  %t71 = load i32, ptr %l2
  %t73 = trunc i64 19 to i32
  %t74 = icmp eq i32 %t71, %t73
  br i1 %t74, label %bb22, label %bb23
bb22:
  br label %bb26
bb23:
  %t76 = load i32, ptr %l2
  %t78 = trunc i64 24 to i32
  %t79 = icmp eq i32 %t76, %t78
  br i1 %t79, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store i1 false, ptr %rv
  br label %ret
bb28:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/scope:Scoper", ptr %t82, i32 0, i32 8
  %t85 = load i32, ptr %l1, !tbaa !23
  %t88 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %t84, i32 %t85)
  %t89 = extractvalue { i32, i64 } %t88, 1
  %t90 = extractvalue { i32, i64 } %t88, 0
  store i32 %t90, ptr %l53
  %t91 = icmp ne i32 %t90, 0
  br i1 %t91, label %bb30, label %ok.92
ok.92:
  store i64 %t89, ptr %l52
  br label %bb29
bb29:
  %t93 = load i64, ptr %l52, !tbaa !24
  store i64 %t93, ptr %l48, !tbaa !24
  br label %bb32
bb30:
  br label %bb31
bb31:
  store i64 0, ptr %l48, !tbaa !24
  br label %bb32
bb32:
  %t94 = load i64, ptr %l48, !tbaa !24
  store i64 %t94, ptr %l3, !tbaa !24
  %t95 = load i64, ptr %l3, !tbaa !24
  %t97 = icmp ne i64 %t95, 0
  br i1 %t97, label %bb33, label %bb34
bb33:
  %t99 = load i64, ptr %l3, !tbaa !24
  %t101 = icmp eq i64 %t99, 3
  store i1 %t101, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/scope:Scoper", ptr %t103, i32 0, i32 8
  %t106 = load i32, ptr %l1, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %t105, i32 %t106, i64 1)
  br label %bb36
bb36:
  store i1 false, ptr %l4, !tbaa !21
  store %olang.scope zeroinitializer, ptr %s7
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load i32, ptr %l1, !tbaa !23
  %t113 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparts(ptr %v0, ptr %s7, ptr %t109, i32 %t110)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t113, ptr %l63
  br label %bb37
bb37:
  %t114 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l63
  %t115 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t114, ptr %t115
  store ptr %t115, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s8
  %t117 = load ptr, ptr %l5, !tbaa !29
  %t118 = load i64, ptr %l6, !tbaa !24
  %t121 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %s7, ptr %t117, i64 %t118)
  %t122 = extractvalue { i32, { i64, ptr } } %t121, 1
  %t123 = extractvalue { i32, { i64, ptr } } %t121, 0
  store i32 %t123, ptr %l69
  %t124 = icmp ne i32 %t123, 0
  br i1 %t124, label %bb40, label %ok.125
ok.125:
  store { i64, ptr } %t122, ptr %l68
  br label %bb39
bb39:
  %t126 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t126, ptr %l65, !tbaa !27
  br label %bb44
bb40:
  %t127 = load i32, ptr %l69, !tbaa !23
  %t128 = ashr i32 %t127, 16
  %t130 = icmp eq i32 %t128, 1
  br i1 %t130, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_fab9d5262c098304_b0d84a3f5fe3aa00)
  unreachable
bb43:
  call void @__olang_scope_close(ptr %s8)
  br label %bb56
bb44:
  %t132 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t132, ptr %l7, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t133, 0
  store i64 %t135, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb45
bb45:
  store %olang.scope zeroinitializer, ptr %s9
  %t137 = load i64, ptr %l9, !tbaa !24
  %t138 = load i64, ptr %l8, !tbaa !24
  %t141 = icmp slt i64 %t137, %t138
  %t143 = xor i1 %t141, true
  br i1 %t143, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s9)
  br label %bb54
bb47:
  br label %bb48
bb48:
  %t145 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t145, ptr %l78, !tbaa !27
  %t146 = load i64, ptr %l9, !tbaa !24
  %t148 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !27
  %t150 = getelementptr i32, ptr %t149, i64 %t146
  %t151 = load i32, ptr %t150, !tbaa !33
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t157 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreThrough(ptr %v0, ptr %t153, i32 %t151)
  store i1 %t157, ptr %l83
  br label %bb49
bb49:
  %t158 = load i1, ptr %l83, !tbaa !21
  br i1 %t158, label %bb50, label %bb51
bb50:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb52
bb51:
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s9)
  br label %bb53
bb53:
  %t159 = load i64, ptr %l9, !tbaa !24
  %t161 = add i64 %t159, 1
  store i64 %t161, ptr %l9, !tbaa !24
  br label %bb45
bb54:
  %t163 = load i64, ptr %l6, !tbaa !24
  %t164 = load i64, ptr %l8, !tbaa !24
  %t167 = add i64 %t163, %t164
  store i64 %t167, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb55
bb55:
  br label %bb38
bb56:
  call void @__olang_scope_close(ptr %s7)
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/scope:Scoper", ptr %t169, i32 0, i32 8
  store ptr %t171, ptr %l90, !tbaa !29
  %t172 = load i32, ptr %l1, !tbaa !23
  store i32 %t172, ptr %l91, !tbaa !23
  %t173 = load i1, ptr %l4, !tbaa !21
  br i1 %t173, label %bb57, label %bb58
bb57:
  store i64 3, ptr %l93, !tbaa !24
  br label %bb59
bb58:
  store i64 2, ptr %l93, !tbaa !24
  br label %bb59
bb59:
  %t175 = load ptr, ptr %l90, !tbaa !29
  %t176 = load i32, ptr %l91, !tbaa !23
  %t177 = load i64, ptr %l93, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %t175, i32 %t176, i64 %t177)
  br label %bb60
bb60:
  %t178 = load i1, ptr %l4, !tbaa !21
  store i1 %t178, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estrReceiver(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca %"compiler/scope:rel"
  %l7 = alloca i1
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l20 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i32
  %l33 = alloca { i64, ptr }
  %l40 = alloca i64
  %l43 = alloca i64
  %l45 = alloca i1
  %l49 = alloca i1
  %l50 = alloca i1
  %l51 = alloca { i64, [2 x i64] }
  %l53 = alloca { i64, [2 x i64] }
  %l55 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca ptr
  %l73 = alloca %"compiler/source:Span"
  %l74 = alloca %"compiler/msgs:Msg"
  %l75 = alloca i64
  %l83 = alloca i64
  %l87 = alloca i64
  %l90 = alloca i64
  %l111 = alloca i1
  %l113 = alloca i1
  %l117 = alloca i1
  %l119 = alloca ptr
  %l123 = alloca %"compiler/source:Span"
  %l124 = alloca %"compiler/msgs:Msg"
  %l125 = alloca i64
  %l129 = alloca i64
  %l138 = alloca i1
  %l142 = alloca %"compiler/source:Span"
  %l143 = alloca i32
  %l147 = alloca %"compiler/source:Span"
  %l150 = alloca ptr
  %l151 = alloca i64
  %l155 = alloca i64
  %l159 = alloca %"compiler/source:Span"
  %l160 = alloca %"compiler/msgs:Msg"
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 33
  store ptr %t3, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3arel_3e_2eRunFrom_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t5, i64 %t6)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l24
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13
ok.13:
  store { i64, ptr } %t10, ptr %l23
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t14, ptr %l20, !tbaa !27
  br label %bb7
bb3:
  %t15 = load i32, ptr %l24, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_678543b1c51fd044_bcff5a6e112a6af8)
  unreachable
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb46
bb7:
  %t20 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load i64, ptr %l5, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb44
bb10:
  br label %bb11
bb11:
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t33, ptr %l33, !tbaa !27
  %t34 = load i64, ptr %l5, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr %"compiler/scope:rel", ptr %t37, i64 %t34
  %t39 = load %"compiler/scope:rel", ptr %t38
  store %"compiler/scope:rel" %t39, ptr %l6
  store i1 false, ptr %l7, !tbaa !21
  %t41 = getelementptr %"compiler/scope:rel", ptr %l6, i32 0, i32 1
  %t42 = load { i64, [2 x i64] }, ptr %t41
  store { i64, [2 x i64] } %t42, ptr %l8
  %t44 = load { i64, [2 x i64] }, ptr %l8
  %t46 = extractvalue { i64, [2 x i64] } %t44, 0
  %t47 = icmp eq i64 %t46, 2
  br i1 %t47, label %bb12, label %bb13
bb12:
  %t49 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t50 = getelementptr { i64 }, ptr %t49, i32 0, i32 0
  %t51 = load i64, ptr %t50
  store i64 %t51, ptr %l9, !tbaa !24
  br label %bb14
bb13:
  br label %bb24
bb14:
  %t53 = load i64, ptr %l9, !tbaa !24
  store i64 %t53, ptr %l40, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/scope:Scoper", ptr %t54, i32 0, i32 62
  %t58 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t56)
  store i64 %t58, ptr %l43
  br label %bb15
bb15:
  %t59 = load i64, ptr %l40, !tbaa !24
  %t60 = load i64, ptr %l43, !tbaa !24
  %t61 = icmp slt i64 %t59, %t60
  br i1 %t61, label %bb16, label %bb17
bb16:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/scope:Scoper", ptr %t63, i32 0, i32 62
  %t66 = load i64, ptr %l9, !tbaa !24
  %t69 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t65, i64 %t66)
  store i1 %t69, ptr %l49
  br label %bb18
bb17:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb19
bb18:
  %t70 = load i1, ptr %l49, !tbaa !21
  store i1 %t70, ptr %l45, !tbaa !21
  br label %bb19
bb19:
  %t71 = load i1, ptr %l45, !tbaa !21
  br i1 %t71, label %bb20, label %bb21
bb20:
  %t72 = getelementptr %"compiler/scope:rel", ptr %l6, i32 0, i32 0
  %t73 = load { i64, [2 x i64] }, ptr %t72
  store { i64, [2 x i64] } %t73, ptr %l51
  %t74 = getelementptr %"compiler/scope:rel", ptr %l6, i32 0, i32 1
  %t75 = load { i64, [2 x i64] }, ptr %t74
  store { i64, [2 x i64] } %t75, ptr %l53
  %t78 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l51, ptr %l53)
  store i1 %t78, ptr %l55
  br label %bb22
bb21:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb23
bb22:
  %t79 = load i1, ptr %l55, !tbaa !21
  %t80 = xor i1 %t79, true
  store i1 %t80, ptr %l50, !tbaa !21
  br label %bb23
bb23:
  %t82 = load i1, ptr %l50, !tbaa !21
  store i1 %t82, ptr %l7, !tbaa !21
  br label %bb33
bb24:
  %t83 = load { i64, [2 x i64] }, ptr %l8
  %t85 = extractvalue { i64, [2 x i64] } %t83, 0
  %t86 = icmp eq i64 %t85, 4
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t88 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t89 = getelementptr { i64, i64 }, ptr %t88, i32 0, i32 0
  %t90 = load i64, ptr %t89
  store i64 %t90, ptr %l10, !tbaa !24
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t92 = load i64, ptr %l10, !tbaa !24
  %t94 = icmp sge i64 %t92, 0
  store i1 %t94, ptr %l7, !tbaa !21
  br label %bb33
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_a7efa27c057b5f35_b77d9a3a5db915c9)
  unreachable
bb33:
  %t96 = load i1, ptr %l7, !tbaa !21
  br i1 %t96, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s7
  %t98 = load ptr, ptr %l0, !tbaa !29
  store ptr %t98, ptr %l63, !tbaa !29
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l64, !tbaa !29
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/scope:Scoper", ptr %t100, i32 0, i32 25
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = icmp eq ptr %t103, null
  br i1 %t105, label %bb36, label %bb37
bb35:
  br label %bb42
bb36:
  call void @__olang_check_failed(ptr @olang_loc_a7a579971a154b67_66936e5e8b24a2eb)
  unreachable
bb37:
  br label %bb38
bb38:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/scope:Scoper", ptr %t107, i32 0, i32 25
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t113 = getelementptr %"compiler/typed:Body", ptr %t110, i32 0, i32 3
  %t114 = load i64, ptr %t113, !tbaa !24
  %t115 = getelementptr %"compiler/scope:rel", ptr %l6, i32 0, i32 3
  %t116 = load %"compiler/source:Span", ptr %t115
  %t117 = load ptr, ptr %l64, !tbaa !29
  %t120 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efirstToken(ptr %v0, ptr %t117, i64 %t114, %"compiler/source:Span" %t116)
  store %"compiler/source:Span" %t120, ptr %l73
  br label %bb39
bb39:
  %t121 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eStrStoresInReceiver(ptr %s7)
  store %"compiler/msgs:Msg" %t121, ptr %l74
  br label %bb40
bb40:
  %t122 = load ptr, ptr %l63, !tbaa !29
  %t123 = load %"compiler/source:Span", ptr %l73
  %t124 = load %"compiler/msgs:Msg", ptr %l74
  %t125 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s7, ptr %t122, %"compiler/source:Span" %t123, %"compiler/msgs:Msg" %t124)
  store i64 %t125, ptr %l75
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb42:
  call void @__olang_scope_close(ptr %s3)
  br label %bb43
bb43:
  %t126 = load i64, ptr %l5, !tbaa !24
  %t128 = add i64 %t126, 1
  store i64 %t128, ptr %l5, !tbaa !24
  br label %bb8
bb44:
  %t130 = load i64, ptr %l2, !tbaa !24
  %t131 = load i64, ptr %l4, !tbaa !24
  %t134 = add i64 %t130, %t131
  store i64 %t134, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb45
bb45:
  br label %bb1
bb46:
  store i64 0, ptr %l11, !tbaa !24
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/scope:Scoper", ptr %t136, i32 0, i32 62
  %t140 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t138)
  store i64 %t140, ptr %l83
  br label %bb47
bb47:
  %t141 = load i64, ptr %l83, !tbaa !24
  store i64 %t141, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t142 = load i64, ptr %l12, !tbaa !24
  %t143 = load i64, ptr %l11, !tbaa !24
  %t146 = icmp sgt i64 %t142, %t143
  br i1 %t146, label %bb48, label %bb49
bb48:
  %t148 = load i64, ptr %l13, !tbaa !24
  %t150 = icmp sgt i64 %t148, 0
  br i1 %t150, label %bb50, label %bb51
bb49:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb53
bb50:
  %t152 = load i64, ptr %l12, !tbaa !24
  %t153 = load i64, ptr %l11, !tbaa !24
  %t156 = sub i64 %t152, %t153
  %t157 = load i64, ptr %l13, !tbaa !24
  %t160 = add i64 %t156, %t157
  %t162 = sub i64 %t160, 1
  %t163 = load i64, ptr %l13, !tbaa !24
  %t166 = sdiv i64 %t162, %t163
  store i64 %t166, ptr %l90, !tbaa !24
  br label %bb52
bb51:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb52
bb52:
  %t168 = load i64, ptr %l90, !tbaa !24
  store i64 %t168, ptr %l87, !tbaa !24
  br label %bb53
bb53:
  %t169 = load i64, ptr %l87, !tbaa !24
  store i64 %t169, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb54
bb54:
  store %olang.scope zeroinitializer, ptr %s10
  %t170 = load i64, ptr %l15, !tbaa !24
  %t171 = load i64, ptr %l14, !tbaa !24
  %t174 = icmp slt i64 %t170, %t171
  %t176 = xor i1 %t174, true
  br i1 %t176, label %bb55, label %bb56
bb55:
  call void @__olang_scope_close(ptr %s10)
  br label %bb86
bb56:
  br label %bb57
bb57:
  %t178 = load i64, ptr %l11, !tbaa !24
  %t179 = load i64, ptr %l15, !tbaa !24
  %t180 = load i64, ptr %l13, !tbaa !24
  %t183 = mul i64 %t179, %t180
  %t186 = add i64 %t178, %t183
  store i64 %t186, ptr %l16, !tbaa !24
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/scope:Scoper", ptr %t188, i32 0, i32 62
  %t191 = load i64, ptr %l16, !tbaa !24
  %t194 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t190, i64 %t191)
  store i1 %t194, ptr %l111
  br label %bb58
bb58:
  %t195 = load i1, ptr %l111, !tbaa !21
  %t196 = xor i1 %t195, true
  br i1 %t196, label %bb59, label %bb60
bb59:
  store i1 true, ptr %l113, !tbaa !21
  br label %bb62
bb60:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/scope:Scoper", ptr %t198, i32 0, i32 56
  %t201 = load i64, ptr %l16, !tbaa !24
  %t204 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t200, i64 %t201)
  store i1 %t204, ptr %l117
  br label %bb61
bb61:
  %t205 = load i1, ptr %l117, !tbaa !21
  %t206 = xor i1 %t205, true
  store i1 %t206, ptr %l113, !tbaa !21
  br label %bb62
bb62:
  %t208 = load i1, ptr %l113, !tbaa !21
  br i1 %t208, label %bb63, label %bb64
bb63:
  call void @__olang_scope_close(ptr %s10)
  br label %bb85
bb64:
  br label %bb65
bb65:
  %t209 = load ptr, ptr %l0, !tbaa !29
  store ptr %t209, ptr %l119, !tbaa !29
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t212 = getelementptr %"compiler/scope:Scoper", ptr %t210, i32 0, i32 59
  %t213 = load i64, ptr %l16, !tbaa !24
  %t216 = call %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t212, i64 %t213)
  store %"compiler/source:Span" %t216, ptr %l123
  br label %bb66
bb66:
  %t217 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eStrStoresInReceiver(ptr %s10)
  store %"compiler/msgs:Msg" %t217, ptr %l124
  br label %bb67
bb67:
  %t218 = load ptr, ptr %l119, !tbaa !29
  %t219 = load %"compiler/source:Span", ptr %l123
  %t220 = load %"compiler/msgs:Msg", ptr %l124
  %t221 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s10, ptr %t218, %"compiler/source:Span" %t219, %"compiler/msgs:Msg" %t220)
  store i64 %t221, ptr %l125
  br label %bb68
bb68:
  %t222 = load i64, ptr %l125, !tbaa !24
  store i64 %t222, ptr %l17, !tbaa !24
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/scope:Scoper", ptr %t223, i32 0, i32 60
  %t226 = load i64, ptr %l16, !tbaa !24
  %t229 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t225, i64 %t226)
  store i64 %t229, ptr %l129
  br label %bb69
bb69:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t232 = getelementptr %"compiler/scope:Scoper", ptr %t230, i32 0, i32 25
  %t233 = load ptr, ptr %t232, !tbaa !29
  %t235 = icmp eq ptr %t233, null
  br i1 %t235, label %bb70, label %bb71
bb70:
  call void @__olang_check_failed(ptr @olang_loc_4a5227c5c4b52748_edf443988575737c)
  unreachable
bb71:
  br label %bb72
bb72:
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = getelementptr %"compiler/scope:Scoper", ptr %t237, i32 0, i32 25
  %t240 = load ptr, ptr %t239, !tbaa !29
  %t243 = getelementptr %"compiler/typed:Body", ptr %t240, i32 0, i32 3
  %t244 = load i64, ptr %t243, !tbaa !24
  %t245 = load i64, ptr %l129, !tbaa !24
  %t247 = icmp ne i64 %t245, %t244
  br i1 %t247, label %bb73, label %bb74
bb73:
  store i1 true, ptr %l138, !tbaa !21
  br label %bb77
bb74:
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t251 = getelementptr %"compiler/scope:Scoper", ptr %t249, i32 0, i32 61
  %t252 = load i64, ptr %l16, !tbaa !24
  %t255 = call %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t251, i64 %t252)
  store %"compiler/source:Span" %t255, ptr %l142
  br label %bb75
bb75:
  %t256 = getelementptr %"compiler/source:Span", ptr %l142, i32 0, i32 0
  %t257 = load i32, ptr %t256, !tbaa !23
  store i32 %t257, ptr %l143, !tbaa !23
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t260 = getelementptr %"compiler/scope:Scoper", ptr %t258, i32 0, i32 59
  %t261 = load i64, ptr %l16, !tbaa !24
  %t264 = call %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t260, i64 %t261)
  store %"compiler/source:Span" %t264, ptr %l147
  br label %bb76
bb76:
  %t265 = getelementptr %"compiler/source:Span", ptr %l147, i32 0, i32 0
  %t266 = load i32, ptr %t265, !tbaa !23
  %t267 = load i32, ptr %l143, !tbaa !23
  %t269 = icmp ne i32 %t267, %t266
  store i1 %t269, ptr %l138, !tbaa !21
  br label %bb77
bb77:
  %t271 = load i1, ptr %l138, !tbaa !21
  br i1 %t271, label %bb78, label %bb79
bb78:
  store %olang.scope zeroinitializer, ptr %s12
  %t272 = load ptr, ptr %l0, !tbaa !29
  store ptr %t272, ptr %l150, !tbaa !29
  %t273 = load i64, ptr %l17, !tbaa !24
  store i64 %t273, ptr %l151, !tbaa !24
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/scope:Scoper", ptr %t274, i32 0, i32 60
  %t277 = load i64, ptr %l16, !tbaa !24
  %t280 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t276, i64 %t277)
  store i64 %t280, ptr %l155
  br label %bb80
bb79:
  br label %bb84
bb80:
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t283 = getelementptr %"compiler/scope:Scoper", ptr %t281, i32 0, i32 61
  %t284 = load i64, ptr %l16, !tbaa !24
  %t287 = call %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t283, i64 %t284)
  store %"compiler/source:Span" %t287, ptr %l159
  br label %bb81
bb81:
  %t288 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteStrBuildsHere(ptr %s12)
  store %"compiler/msgs:Msg" %t288, ptr %l160
  br label %bb82
bb82:
  %t289 = load ptr, ptr %l150, !tbaa !29
  %t290 = load i64, ptr %l151, !tbaa !24
  %t291 = load i64, ptr %l155, !tbaa !24
  %t292 = load %"compiler/source:Span", ptr %l159
  %t293 = load %"compiler/msgs:Msg", ptr %l160
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enote(ptr %v0, ptr %s12, ptr %t289, i64 %t290, i64 %t291, %"compiler/source:Span" %t292, %"compiler/msgs:Msg" %t293)
  br label %bb83
bb83:
  call void @__olang_scope_close(ptr %s12)
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s10)
  br label %ret
bb85:
  %t294 = load i64, ptr %l15, !tbaa !24
  %t296 = add i64 %t294, 1
  store i64 %t296, ptr %l15, !tbaa !24
  br label %bb54
bb86:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esumBuilds(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca ptr
  %l10 = alloca i64
  %l12 = alloca i64
  %l14 = alloca i1
  %l17 = alloca i1
  %rv = alloca i1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 6
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fscope_3asummary_26_H3a91daf058bf595e7b112751a30a6bbf(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l7, !tbaa !29
  %t10 = getelementptr %"compiler/scope:summary", ptr %t8, i32 0, i32 1
  %t11 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t10
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l3
  %t13 = load i64, ptr %l2, !tbaa !24
  store i64 %t13, ptr %l10, !tbaa !24
  %t15 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %l3)
  store i64 %t15, ptr %l12
  br label %bb2
bb2:
  %t16 = load i64, ptr %l10, !tbaa !24
  %t17 = load i64, ptr %l12, !tbaa !24
  %t18 = icmp sge i64 %t16, %t17
  br i1 %t18, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb6
bb4:
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %l3, i64 %t20)
  store i1 %t23, ptr %l17
  br label %bb5
bb5:
  %t24 = load i1, ptr %l17, !tbaa !21
  store i1 %t24, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t25 = load i1, ptr %l14, !tbaa !21
  store i1 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ethroughDerived(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i1
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l28 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l38 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l48 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ethroughDerivedExpr(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i1 %t20, ptr %l15
  br label %bb6
bb6:
  %t21 = load i1, ptr %l15, !tbaa !21
  br i1 %t21, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb10
bb8:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t26 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ederivedRead(ptr %v0, ptr %v1, ptr %t22, ptr %t23)
  store i1 %t26, ptr %l19
  br label %bb9
bb9:
  %t27 = load i1, ptr %l19, !tbaa !21
  store i1 %t27, ptr %l16, !tbaa !21
  br label %bb10
bb10:
  %t28 = load i1, ptr %l16, !tbaa !21
  store i1 %t28, ptr %l6, !tbaa !21
  br label %bb37
bb11:
  %t29 = load ptr, ptr %l1, !tbaa !29
  store ptr %t29, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t30 = load ptr, ptr %l20, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb12, label %bb13
bb12:
  %t33 = load ptr, ptr %l20, !tbaa !29
  %t34 = load i64, ptr %t33
  %t36 = icmp eq i64 %t34, 3
  store i1 %t36, ptr %l21, !tbaa !21
  br label %bb13
bb13:
  %t37 = load i1, ptr %l21, !tbaa !21
  br i1 %t37, label %bb14, label %bb15
bb14:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l3, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t48 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ethroughDerived(ptr %v0, ptr %v1, ptr %t44, ptr %t45)
  store i1 %t48, ptr %l28
  br label %bb17
bb17:
  %t49 = load i1, ptr %l28, !tbaa !21
  store i1 %t49, ptr %l6, !tbaa !21
  br label %bb37
bb18:
  %t50 = load ptr, ptr %l1, !tbaa !29
  store ptr %t50, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t51 = load ptr, ptr %l29, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb19, label %bb20
bb19:
  %t54 = load ptr, ptr %l29, !tbaa !29
  %t55 = load i64, ptr %t54
  %t57 = icmp eq i64 %t55, 4
  store i1 %t57, ptr %l30, !tbaa !21
  br label %bb20
bb20:
  %t58 = load i1, ptr %l30, !tbaa !21
  br i1 %t58, label %bb21, label %bb22
bb21:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t61, i32 0, i32 2
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l4, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l4, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Elem", ptr %t66, i32 0, i32 0
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t72 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ethroughDerived(ptr %v0, ptr %v1, ptr %t65, ptr %t69)
  store i1 %t72, ptr %l38
  br label %bb24
bb24:
  %t73 = load i1, ptr %l38, !tbaa !21
  store i1 %t73, ptr %l6, !tbaa !21
  br label %bb37
bb25:
  %t74 = load ptr, ptr %l1, !tbaa !29
  store ptr %t74, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t75 = load ptr, ptr %l39, !tbaa !29
  %t76 = icmp ne ptr %t75, null
  br i1 %t76, label %bb26, label %bb27
bb26:
  %t78 = load ptr, ptr %l39, !tbaa !29
  %t79 = load i64, ptr %t78
  %t81 = icmp eq i64 %t79, 5
  store i1 %t81, ptr %l40, !tbaa !21
  br label %bb27
bb27:
  %t82 = load i1, ptr %l40, !tbaa !21
  br i1 %t82, label %bb28, label %bb29
bb28:
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t85 = getelementptr { i64, [4 x i64] }, ptr %t83, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t85, i32 0, i32 2
  %t87 = load ptr, ptr %t86
  store ptr %t87, ptr %l5, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load ptr, ptr %l5, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Payload", ptr %t90, i32 0, i32 0
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t96 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ethroughDerived(ptr %v0, ptr %v1, ptr %t89, ptr %t93)
  store i1 %t96, ptr %l48
  br label %bb31
bb31:
  %t97 = load i1, ptr %l48, !tbaa !21
  store i1 %t97, ptr %l6, !tbaa !21
  br label %bb37
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_7f73b55f7a2eb5e4_273c44187eceff80)
  unreachable
bb37:
  %t98 = load i1, ptr %l6, !tbaa !21
  store i1 %t98, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etransient(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l4 = alloca i64
  %l5 = alloca i1
  %l11 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l12 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l28 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l33 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load i64, ptr %l1, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t10 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t6, i64 %t7)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t10, ptr %l11
  br label %bb4
bb4:
  %t11 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l11
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t11, ptr %l3
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/scope:Scoper", ptr %t12, i32 0, i32 86
  %t15 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l3
  %t18 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t14, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t15)
  %t19 = extractvalue { i32, i64 } %t18, 1
  %t20 = extractvalue { i32, i64 } %t18, 0
  store i32 %t20, ptr %l17
  %t21 = icmp ne i32 %t20, 0
  br i1 %t21, label %bb6, label %ok.22
ok.22:
  store i64 %t19, ptr %l16
  br label %bb5
bb5:
  %t23 = load i64, ptr %l16, !tbaa !24
  store i64 %t23, ptr %l12, !tbaa !24
  br label %bb8
bb6:
  br label %bb7
bb7:
  store i64 0, ptr %l12, !tbaa !24
  br label %bb8
bb8:
  %t24 = load i64, ptr %l12, !tbaa !24
  store i64 %t24, ptr %l4, !tbaa !24
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = icmp ne i64 %t25, 0
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t29 = load i64, ptr %l4, !tbaa !24
  %t31 = icmp eq i64 %t29, 3
  call void @__olang_scope_close(ptr %s0)
  store i1 %t31, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/scope:Scoper", ptr %t33, i32 0, i32 86
  %t36 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l3
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %t35, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t36, i64 1)
  br label %bb12
bb12:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i64, ptr %l1, !tbaa !24
  %t41 = load i64, ptr %l2, !tbaa !24
  %t45 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etransientNow(ptr %v0, ptr %t39, i64 %t40, i64 %t41)
  store i1 %t45, ptr %l28
  br label %bb13
bb13:
  %t46 = load i1, ptr %l28, !tbaa !21
  store i1 %t46, ptr %l5, !tbaa !21
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/scope:Scoper", ptr %t47, i32 0, i32 86
  store ptr %t49, ptr %l30, !tbaa !29
  %t50 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l3
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t50, ptr %l31
  %t51 = load i1, ptr %l5, !tbaa !21
  br i1 %t51, label %bb14, label %bb15
bb14:
  store i64 3, ptr %l33, !tbaa !24
  br label %bb16
bb15:
  store i64 2, ptr %l33, !tbaa !24
  br label %bb16
bb16:
  %t53 = load ptr, ptr %l30, !tbaa !29
  %t54 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l31
  %t55 = load i64, ptr %l33, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %t53, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t54, i64 %t55)
  br label %bb17
bb17:
  %t56 = load i1, ptr %l5, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  store i1 %t56, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etransientNow(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca %"compiler/scope:rel"
  %l22 = alloca { i64, [2 x i64] }
  %l23 = alloca i64
  %l24 = alloca { i64, [2 x i64] }
  %l25 = alloca i64
  %l26 = alloca i32
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l44 = alloca ptr
  %l53 = alloca i1
  %l57 = alloca i1
  %l59 = alloca i1
  %l63 = alloca ptr
  %l67 = alloca i1
  %l68 = alloca i64
  %l71 = alloca i64
  %l81 = alloca i64
  %l84 = alloca i64
  %l91 = alloca { i64, ptr }
  %l97 = alloca i64
  %l100 = alloca i64
  %l131 = alloca ptr
  %l134 = alloca { i64, ptr }
  %l137 = alloca { i64, ptr }
  %l138 = alloca i32
  %l147 = alloca { i64, ptr }
  %l152 = alloca i1
  %l156 = alloca i1
  %l159 = alloca i1
  %l189 = alloca i32
  %l194 = alloca i32
  %l197 = alloca i64
  %l200 = alloca ptr
  %l205 = alloca i32
  %l206 = alloca { i64, ptr }
  %l212 = alloca i64
  %l215 = alloca i64
  %l238 = alloca i64
  %l246 = alloca i64
  %l250 = alloca i64
  %l253 = alloca i64
  %l274 = alloca i1
  %l280 = alloca i64
  %l283 = alloca i1
  %l287 = alloca i1
  %l296 = alloca i32
  %l298 = alloca ptr
  %l302 = alloca %"compiler/typed:Local"
  %l304 = alloca i1
  %l311 = alloca i1
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l44
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l44, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 1
  %t12 = load { i64, [2 x i64] }, ptr %t11
  %t16 = extractvalue { i64, [2 x i64] } %t12, 0
  %t17 = icmp eq i64 %t16, 0
  br i1 %t17, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb9:
  call void @__olang_check_failed(ptr @olang_loc_a99f843f7bf434a0_94e1f929e5b915f4)
  unreachable
bb10:
  %t20 = load ptr, ptr %l3, !tbaa !29
  %t22 = getelementptr %"compiler/typed:Body", ptr %t20, i32 0, i32 11
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  br i1 %t25, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb14
bb12:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/scope:Scoper", ptr %t27, i32 0, i32 11
  %t30 = load i64, ptr %l1, !tbaa !24
  %t33 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t29, i64 %t30)
  store i1 %t33, ptr %l57
  br label %bb13
bb13:
  %t34 = load i1, ptr %l57, !tbaa !21
  %t35 = xor i1 %t34, true
  store i1 %t35, ptr %l53, !tbaa !21
  br label %bb14
bb14:
  %t37 = load i1, ptr %l53, !tbaa !21
  br i1 %t37, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l59, !tbaa !21
  br label %bb18
bb16:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/scope:Scoper", ptr %t38, i32 0, i32 6
  %t41 = load i64, ptr %l1, !tbaa !24
  %t44 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fscope_3asummary_26_H3a91daf058bf595e7b112751a30a6bbf(ptr %v0, ptr %v0, ptr %t40, i64 %t41)
  store ptr %t44, ptr %l63
  br label %bb17
bb17:
  %t45 = load ptr, ptr %l63, !tbaa !29
  %t47 = getelementptr %"compiler/scope:summary", ptr %t45, i32 0, i32 14
  %t48 = load i1, ptr %t47, !tbaa !21
  %t50 = xor i1 %t48, true
  store i1 %t50, ptr %l59, !tbaa !21
  br label %bb18
bb18:
  %t52 = load i1, ptr %l59, !tbaa !21
  br i1 %t52, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb22
bb20:
  %t53 = load i64, ptr %l2, !tbaa !24
  store i64 %t53, ptr %l68, !tbaa !24
  %t54 = load ptr, ptr %l3, !tbaa !29
  %t56 = getelementptr %"compiler/typed:Body", ptr %t54, i32 0, i32 5
  %t58 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t56)
  store i64 %t58, ptr %l71
  br label %bb21
bb21:
  %t59 = load i64, ptr %l68, !tbaa !24
  %t60 = load i64, ptr %l71, !tbaa !24
  %t61 = icmp sge i64 %t59, %t60
  store i1 %t61, ptr %l67, !tbaa !21
  br label %bb22
bb22:
  %t63 = load i1, ptr %l67, !tbaa !21
  br i1 %t63, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t65 = load ptr, ptr %l3, !tbaa !29
  %t67 = getelementptr %"compiler/typed:Body", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %t67, !tbaa !23
  store i32 %t68, ptr %l5, !tbaa !23
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/scope:Scoper", ptr %t70, i32 0, i32 0
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/generic:Program", ptr %t73, i32 0, i32 2
  %t76 = load i32, ptr %l5, !tbaa !23
  %t77 = load i64, ptr %l2, !tbaa !24
  %t81 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t75, i32 %t76, i64 %t77)
  store i64 %t81, ptr %l81
  br label %bb26
bb26:
  %t82 = load i64, ptr %l81, !tbaa !24
  store i64 %t82, ptr %l6, !tbaa !24
  %t83 = load i64, ptr %l6, !tbaa !24
  %t85 = icmp sge i64 %t83, 0
  br i1 %t85, label %bb27, label %bb28
bb27:
  %t87 = load i64, ptr %l6, !tbaa !24
  store i64 %t87, ptr %l84, !tbaa !24
  br label %bb29
bb28:
  %t89 = load i64, ptr %l2, !tbaa !24
  store i64 %t89, ptr %l84, !tbaa !24
  br label %bb29
bb29:
  %t91 = load i64, ptr %l84, !tbaa !24
  store i64 %t91, ptr %l7, !tbaa !24
  store i64 -1, ptr %l8, !tbaa !24
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/scope:Scoper", ptr %t92, i32 0, i32 0
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = getelementptr %"compiler/generic:Program", ptr %t95, i32 0, i32 2
  %t98 = load i32, ptr %l5, !tbaa !23
  %t101 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t97, i32 %t98)
  store { i64, ptr } %t101, ptr %l91
  br label %bb30
bb30:
  %t102 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t102, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t103 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t103, 0
  store i64 %t105, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t107 = load i64, ptr %l11, !tbaa !24
  %t108 = load i64, ptr %l10, !tbaa !24
  %t111 = icmp sgt i64 %t107, %t108
  br i1 %t111, label %bb31, label %bb32
bb31:
  %t113 = load i64, ptr %l12, !tbaa !24
  %t115 = icmp sgt i64 %t113, 0
  br i1 %t115, label %bb33, label %bb34
bb32:
  store i64 0, ptr %l97, !tbaa !24
  br label %bb36
bb33:
  %t117 = load i64, ptr %l11, !tbaa !24
  %t118 = load i64, ptr %l10, !tbaa !24
  %t121 = sub i64 %t117, %t118
  %t122 = load i64, ptr %l12, !tbaa !24
  %t125 = add i64 %t121, %t122
  %t127 = sub i64 %t125, 1
  %t128 = load i64, ptr %l12, !tbaa !24
  %t131 = sdiv i64 %t127, %t128
  store i64 %t131, ptr %l100, !tbaa !24
  br label %bb35
bb34:
  store i64 0, ptr %l100, !tbaa !24
  br label %bb35
bb35:
  %t133 = load i64, ptr %l100, !tbaa !24
  store i64 %t133, ptr %l97, !tbaa !24
  br label %bb36
bb36:
  %t134 = load i64, ptr %l97, !tbaa !24
  store i64 %t134, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s5
  %t135 = load i64, ptr %l14, !tbaa !24
  %t136 = load i64, ptr %l13, !tbaa !24
  %t139 = icmp slt i64 %t135, %t136
  %t141 = xor i1 %t139, true
  br i1 %t141, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s5)
  br label %bb45
bb39:
  br label %bb40
bb40:
  %t143 = load i64, ptr %l10, !tbaa !24
  %t144 = load i64, ptr %l14, !tbaa !24
  %t145 = load i64, ptr %l12, !tbaa !24
  %t148 = mul i64 %t144, %t145
  %t151 = add i64 %t143, %t148
  store i64 %t151, ptr %l15, !tbaa !24
  %t153 = load i64, ptr %l15, !tbaa !24
  %t155 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !27
  %t157 = getelementptr i64, ptr %t156, i64 %t153
  %t158 = load i64, ptr %t157, !tbaa !34
  %t159 = load i64, ptr %l7, !tbaa !24
  %t162 = icmp eq i64 %t158, %t159
  br i1 %t162, label %bb41, label %bb42
bb41:
  %t164 = load i64, ptr %l15, !tbaa !24
  store i64 %t164, ptr %l8, !tbaa !24
  br label %bb43
bb42:
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s5)
  br label %bb44
bb44:
  %t166 = load i64, ptr %l14, !tbaa !24
  %t168 = add i64 %t166, 1
  store i64 %t168, ptr %l14, !tbaa !24
  br label %bb37
bb45:
  %t170 = load i64, ptr %l8, !tbaa !24
  %t172 = icmp slt i64 %t170, 0
  br i1 %t172, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/scope:Scoper", ptr %t175, i32 0, i32 6
  %t178 = load i64, ptr %l1, !tbaa !24
  %t181 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fscope_3asummary_26_H3a91daf058bf595e7b112751a30a6bbf(ptr %v0, ptr %v0, ptr %t177, i64 %t178)
  store ptr %t181, ptr %l131
  br label %bb49
bb49:
  %t182 = load ptr, ptr %l131, !tbaa !29
  %t184 = getelementptr %"compiler/scope:summary", ptr %t182, i32 0, i32 0
  store ptr %t184, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s10
  %t186 = load ptr, ptr %l16, !tbaa !29
  %t187 = load i64, ptr %l17, !tbaa !24
  %t190 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3arel_3e_2eRunFrom_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t186, i64 %t187)
  %t191 = extractvalue { i32, { i64, ptr } } %t190, 1
  %t192 = extractvalue { i32, { i64, ptr } } %t190, 0
  store i32 %t192, ptr %l138
  %t193 = icmp ne i32 %t192, 0
  br i1 %t193, label %bb52, label %ok.194
ok.194:
  store { i64, ptr } %t191, ptr %l137
  br label %bb51
bb51:
  %t195 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t195, ptr %l134, !tbaa !27
  br label %bb56
bb52:
  %t196 = load i32, ptr %l138, !tbaa !23
  %t197 = ashr i32 %t196, 16
  %t199 = icmp eq i32 %t197, 1
  br i1 %t199, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_4aed99841ab3b8b1_8d3edbdcac983025)
  unreachable
bb55:
  call void @__olang_scope_close(ptr %s10)
  br label %bb100
bb56:
  %t201 = load { i64, ptr }, ptr %l134, !tbaa !27
  store { i64, ptr } %t201, ptr %l18, !tbaa !27
  %t202 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t202, 0
  store i64 %t204, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb57
bb57:
  store %olang.scope zeroinitializer, ptr %s11
  %t206 = load i64, ptr %l20, !tbaa !24
  %t207 = load i64, ptr %l19, !tbaa !24
  %t210 = icmp slt i64 %t206, %t207
  %t212 = xor i1 %t210, true
  br i1 %t212, label %bb58, label %bb59
bb58:
  call void @__olang_scope_close(ptr %s11)
  br label %bb98
bb59:
  br label %bb60
bb60:
  %t214 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t214, ptr %l147, !tbaa !27
  %t215 = load i64, ptr %l20, !tbaa !24
  %t217 = getelementptr { i64, ptr }, ptr %l147, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !27
  %t219 = getelementptr %"compiler/scope:rel", ptr %t218, i64 %t215
  %t220 = load %"compiler/scope:rel", ptr %t219
  store %"compiler/scope:rel" %t220, ptr %l21
  %t222 = getelementptr %"compiler/scope:rel", ptr %l21, i32 0, i32 0
  %t223 = load { i64, [2 x i64] }, ptr %t222
  %t225 = extractvalue { i64, [2 x i64] } %t223, 0
  %t226 = icmp eq i64 %t225, 2
  br i1 %t226, label %bb61, label %bb62
bb61:
  %t228 = getelementptr %"compiler/scope:rel", ptr %l21, i32 0, i32 0
  %t229 = getelementptr { i64, [2 x i64] }, ptr %t228, i32 0, i32 1
  %t230 = getelementptr { i64 }, ptr %t229, i32 0, i32 0
  %t231 = load i64, ptr %t230
  %t232 = load i64, ptr %l8, !tbaa !24
  %t235 = icmp eq i64 %t231, %t232
  store i1 %t235, ptr %l152, !tbaa !21
  br label %bb63
bb62:
  store i1 false, ptr %l152, !tbaa !21
  br label %bb63
bb63:
  %t237 = load i1, ptr %l152, !tbaa !21
  br i1 %t237, label %bb64, label %bb65
bb64:
  store i1 true, ptr %l156, !tbaa !21
  br label %bb69
bb65:
  %t238 = getelementptr %"compiler/scope:rel", ptr %l21, i32 0, i32 1
  %t239 = load { i64, [2 x i64] }, ptr %t238
  %t241 = extractvalue { i64, [2 x i64] } %t239, 0
  %t242 = icmp eq i64 %t241, 2
  br i1 %t242, label %bb66, label %bb67
bb66:
  %t244 = getelementptr %"compiler/scope:rel", ptr %l21, i32 0, i32 1
  %t245 = getelementptr { i64, [2 x i64] }, ptr %t244, i32 0, i32 1
  %t246 = getelementptr { i64 }, ptr %t245, i32 0, i32 0
  %t247 = load i64, ptr %t246
  %t248 = load i64, ptr %l8, !tbaa !24
  %t251 = icmp eq i64 %t247, %t248
  store i1 %t251, ptr %l159, !tbaa !21
  br label %bb68
bb67:
  store i1 false, ptr %l159, !tbaa !21
  br label %bb68
bb68:
  %t253 = load i1, ptr %l159, !tbaa !21
  store i1 %t253, ptr %l156, !tbaa !21
  br label %bb69
bb69:
  %t254 = load i1, ptr %l156, !tbaa !21
  br i1 %t254, label %bb70, label %bb71
bb70:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb71:
  br label %bb72
bb72:
  %t256 = getelementptr %"compiler/scope:rel", ptr %l21, i32 0, i32 0
  %t257 = load { i64, [2 x i64] }, ptr %t256
  store { i64, [2 x i64] } %t257, ptr %l22
  %t259 = load { i64, [2 x i64] }, ptr %l22
  %t261 = extractvalue { i64, [2 x i64] } %t259, 0
  %t262 = icmp eq i64 %t261, 4
  br i1 %t262, label %bb73, label %bb74
bb73:
  %t264 = getelementptr { i64, [2 x i64] }, ptr %l22, i32 0, i32 1
  %t265 = getelementptr { i64, i64 }, ptr %t264, i32 0, i32 0
  %t266 = load i64, ptr %t265
  store i64 %t266, ptr %l23, !tbaa !24
  br label %bb75
bb74:
  br label %bb79
bb75:
  %t268 = load i64, ptr %l23, !tbaa !24
  %t269 = load i64, ptr %l2, !tbaa !24
  %t272 = icmp eq i64 %t268, %t269
  br i1 %t272, label %bb76, label %bb77
bb76:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb77:
  br label %bb78
bb78:
  br label %bb84
bb79:
  br i1 true, label %bb80, label %bb81
bb80:
  br label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb84
bb83:
  call void @__olang_check_failed(ptr @olang_loc_c7fdd76f48c1d89a_56d68a9de61a546e)
  unreachable
bb84:
  %t275 = getelementptr %"compiler/scope:rel", ptr %l21, i32 0, i32 1
  %t276 = load { i64, [2 x i64] }, ptr %t275
  store { i64, [2 x i64] } %t276, ptr %l24
  %t278 = load { i64, [2 x i64] }, ptr %l24
  %t280 = extractvalue { i64, [2 x i64] } %t278, 0
  %t281 = icmp eq i64 %t280, 4
  br i1 %t281, label %bb85, label %bb86
bb85:
  %t283 = getelementptr { i64, [2 x i64] }, ptr %l24, i32 0, i32 1
  %t284 = getelementptr { i64, i64 }, ptr %t283, i32 0, i32 0
  %t285 = load i64, ptr %t284
  store i64 %t285, ptr %l25, !tbaa !24
  br label %bb87
bb86:
  br label %bb91
bb87:
  %t287 = load i64, ptr %l25, !tbaa !24
  %t288 = load i64, ptr %l2, !tbaa !24
  %t291 = icmp eq i64 %t287, %t288
  br i1 %t291, label %bb88, label %bb89
bb88:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb89:
  br label %bb90
bb90:
  br label %bb96
bb91:
  br i1 true, label %bb92, label %bb93
bb92:
  br label %bb94
bb93:
  br label %bb95
bb94:
  br label %bb96
bb95:
  call void @__olang_check_failed(ptr @olang_loc_480fa549fbef29b_cc88b49cbb5bf52f)
  unreachable
bb96:
  call void @__olang_scope_close(ptr %s11)
  br label %bb97
bb97:
  %t294 = load i64, ptr %l20, !tbaa !24
  %t296 = add i64 %t294, 1
  store i64 %t296, ptr %l20, !tbaa !24
  br label %bb57
bb98:
  %t298 = load i64, ptr %l17, !tbaa !24
  %t299 = load i64, ptr %l19, !tbaa !24
  %t302 = add i64 %t298, %t299
  store i64 %t302, ptr %l17, !tbaa !24
  call void @__olang_scope_close(ptr %s10)
  br label %bb99
bb99:
  br label %bb50
bb100:
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t306 = getelementptr %"compiler/scope:Scoper", ptr %t304, i32 0, i32 0
  %t307 = load ptr, ptr %t306, !tbaa !29
  %t309 = getelementptr %"compiler/generic:Program", ptr %t307, i32 0, i32 2
  %t310 = load i32, ptr %l5, !tbaa !23
  %t313 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t309, i32 %t310)
  store i32 %t313, ptr %l189
  br label %bb101
bb101:
  %t314 = load i32, ptr %l189, !tbaa !23
  store i32 %t314, ptr %l26, !tbaa !23
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr %"compiler/scope:Scoper", ptr %t315, i32 0, i32 0
  %t318 = load ptr, ptr %t317, !tbaa !29
  %t320 = getelementptr %"compiler/generic:Program", ptr %t318, i32 0, i32 2
  %t321 = load i32, ptr %l26, !tbaa !23
  %t324 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t320, i32 %t321)
  store i32 %t324, ptr %l194
  br label %bb102
bb102:
  %t325 = load i32, ptr %l194
  %t327 = trunc i64 22 to i32
  %t328 = icmp eq i32 %t325, %t327
  br i1 %t328, label %bb103, label %bb104
bb103:
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t332 = getelementptr %"compiler/scope:Scoper", ptr %t330, i32 0, i32 0
  %t333 = load ptr, ptr %t332, !tbaa !29
  %t335 = getelementptr %"compiler/generic:Program", ptr %t333, i32 0, i32 2
  store ptr %t335, ptr %l200, !tbaa !29
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t338 = getelementptr %"compiler/scope:Scoper", ptr %t336, i32 0, i32 0
  %t339 = load ptr, ptr %t338, !tbaa !29
  %t341 = getelementptr %"compiler/generic:Program", ptr %t339, i32 0, i32 2
  %t342 = load i32, ptr %l26, !tbaa !23
  %t345 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t341, i32 %t342)
  store i32 %t345, ptr %l205
  br label %bb105
bb104:
  store i64 1, ptr %l197, !tbaa !24
  br label %bb107
bb105:
  %t346 = load ptr, ptr %l200, !tbaa !29
  %t347 = load i32, ptr %l205, !tbaa !23
  %t348 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t346, i32 %t347)
  store { i64, ptr } %t348, ptr %l206
  br label %bb106
bb106:
  %t349 = load { i64, ptr }, ptr %l206, !tbaa !27
  %t350 = extractvalue { i64, ptr } %t349, 0
  store i64 %t350, ptr %l197, !tbaa !24
  br label %bb107
bb107:
  %t352 = load i64, ptr %l197, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  store i64 %t352, ptr %l29, !tbaa !24
  store i64 1, ptr %l30, !tbaa !24
  %t355 = load i64, ptr %l29, !tbaa !24
  %t356 = load i64, ptr %l28, !tbaa !24
  %t359 = icmp sgt i64 %t355, %t356
  br i1 %t359, label %bb108, label %bb109
bb108:
  %t361 = load i64, ptr %l30, !tbaa !24
  %t363 = icmp sgt i64 %t361, 0
  br i1 %t363, label %bb110, label %bb111
bb109:
  store i64 0, ptr %l212, !tbaa !24
  br label %bb113
bb110:
  %t365 = load i64, ptr %l29, !tbaa !24
  %t366 = load i64, ptr %l28, !tbaa !24
  %t369 = sub i64 %t365, %t366
  %t370 = load i64, ptr %l30, !tbaa !24
  %t373 = add i64 %t369, %t370
  %t375 = sub i64 %t373, 1
  %t376 = load i64, ptr %l30, !tbaa !24
  %t379 = sdiv i64 %t375, %t376
  store i64 %t379, ptr %l215, !tbaa !24
  br label %bb112
bb111:
  store i64 0, ptr %l215, !tbaa !24
  br label %bb112
bb112:
  %t381 = load i64, ptr %l215, !tbaa !24
  store i64 %t381, ptr %l212, !tbaa !24
  br label %bb113
bb113:
  %t382 = load i64, ptr %l212, !tbaa !24
  store i64 %t382, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  br label %bb114
bb114:
  store %olang.scope zeroinitializer, ptr %s21
  %t383 = load i64, ptr %l32, !tbaa !24
  %t384 = load i64, ptr %l31, !tbaa !24
  %t387 = icmp slt i64 %t383, %t384
  %t389 = xor i1 %t387, true
  br i1 %t389, label %bb115, label %bb116
bb115:
  call void @__olang_scope_close(ptr %s21)
  br label %bb123
bb116:
  br label %bb117
bb117:
  %t391 = load i64, ptr %l28, !tbaa !24
  %t392 = load i64, ptr %l32, !tbaa !24
  %t393 = load i64, ptr %l30, !tbaa !24
  %t396 = mul i64 %t392, %t393
  %t399 = add i64 %t391, %t396
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t403 = getelementptr %"compiler/scope:Scoper", ptr %t401, i32 0, i32 0
  %t404 = load ptr, ptr %t403, !tbaa !29
  %t406 = getelementptr %"compiler/generic:Program", ptr %t404, i32 0, i32 2
  %t407 = load i32, ptr %l5, !tbaa !23
  %t412 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t406, i32 %t407, i64 %t399)
  store i64 %t412, ptr %l238
  br label %bb118
bb118:
  %t413 = load i64, ptr %l7, !tbaa !24
  %t414 = load i64, ptr %l238, !tbaa !24
  %t416 = icmp eq i64 %t414, %t413
  br i1 %t416, label %bb119, label %bb120
bb119:
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb120:
  br label %bb121
bb121:
  call void @__olang_scope_close(ptr %s21)
  br label %bb122
bb122:
  %t419 = load i64, ptr %l32, !tbaa !24
  %t421 = add i64 %t419, 1
  store i64 %t421, ptr %l32, !tbaa !24
  br label %bb114
bb123:
  store i64 0, ptr %l34, !tbaa !24
  %t423 = load ptr, ptr %l3, !tbaa !29
  %t425 = getelementptr %"compiler/typed:Body", ptr %t423, i32 0, i32 5
  %t427 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t425)
  store i64 %t427, ptr %l246
  br label %bb124
bb124:
  %t428 = load i64, ptr %l246, !tbaa !24
  store i64 %t428, ptr %l35, !tbaa !24
  store i64 1, ptr %l36, !tbaa !24
  %t429 = load i64, ptr %l35, !tbaa !24
  %t430 = load i64, ptr %l34, !tbaa !24
  %t433 = icmp sgt i64 %t429, %t430
  br i1 %t433, label %bb125, label %bb126
bb125:
  %t435 = load i64, ptr %l36, !tbaa !24
  %t437 = icmp sgt i64 %t435, 0
  br i1 %t437, label %bb127, label %bb128
bb126:
  store i64 0, ptr %l250, !tbaa !24
  br label %bb130
bb127:
  %t439 = load i64, ptr %l35, !tbaa !24
  %t440 = load i64, ptr %l34, !tbaa !24
  %t443 = sub i64 %t439, %t440
  %t444 = load i64, ptr %l36, !tbaa !24
  %t447 = add i64 %t443, %t444
  %t449 = sub i64 %t447, 1
  %t450 = load i64, ptr %l36, !tbaa !24
  %t453 = sdiv i64 %t449, %t450
  store i64 %t453, ptr %l253, !tbaa !24
  br label %bb129
bb128:
  store i64 0, ptr %l253, !tbaa !24
  br label %bb129
bb129:
  %t455 = load i64, ptr %l253, !tbaa !24
  store i64 %t455, ptr %l250, !tbaa !24
  br label %bb130
bb130:
  %t456 = load i64, ptr %l250, !tbaa !24
  store i64 %t456, ptr %l37, !tbaa !24
  store i64 0, ptr %l38, !tbaa !24
  br label %bb131
bb131:
  store %olang.scope zeroinitializer, ptr %s25
  %t457 = load i64, ptr %l38, !tbaa !24
  %t458 = load i64, ptr %l37, !tbaa !24
  %t461 = icmp slt i64 %t457, %t458
  %t463 = xor i1 %t461, true
  br i1 %t463, label %bb132, label %bb133
bb132:
  call void @__olang_scope_close(ptr %s25)
  br label %bb149
bb133:
  br label %bb134
bb134:
  %t465 = load i64, ptr %l34, !tbaa !24
  %t466 = load i64, ptr %l38, !tbaa !24
  %t467 = load i64, ptr %l36, !tbaa !24
  %t470 = mul i64 %t466, %t467
  %t473 = add i64 %t465, %t470
  store i64 %t473, ptr %l39, !tbaa !24
  %t475 = load i64, ptr %l39, !tbaa !24
  %t476 = load i64, ptr %l2, !tbaa !24
  %t479 = icmp ne i64 %t475, %t476
  br i1 %t479, label %bb135, label %bb136
bb135:
  %t481 = load ptr, ptr %l0, !tbaa !29
  %t483 = getelementptr %"compiler/scope:Scoper", ptr %t481, i32 0, i32 0
  %t484 = load ptr, ptr %t483, !tbaa !29
  %t486 = getelementptr %"compiler/generic:Program", ptr %t484, i32 0, i32 2
  %t487 = load i32, ptr %l5, !tbaa !23
  %t488 = load i64, ptr %l39, !tbaa !24
  %t492 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t486, i32 %t487, i64 %t488)
  store i64 %t492, ptr %l280
  br label %bb137
bb136:
  store i1 false, ptr %l274, !tbaa !21
  br label %bb144
bb137:
  %t493 = load i64, ptr %l7, !tbaa !24
  %t494 = load i64, ptr %l280, !tbaa !24
  %t496 = icmp eq i64 %t494, %t493
  br i1 %t496, label %bb138, label %bb139
bb138:
  store i1 true, ptr %l283, !tbaa !21
  br label %bb143
bb139:
  %t498 = load i64, ptr %l39, !tbaa !24
  %t499 = load i64, ptr %l7, !tbaa !24
  %t502 = icmp eq i64 %t498, %t499
  br i1 %t502, label %bb140, label %bb141
bb140:
  %t504 = load i64, ptr %l6, !tbaa !24
  %t506 = icmp sge i64 %t504, 0
  store i1 %t506, ptr %l287, !tbaa !21
  br label %bb142
bb141:
  store i1 false, ptr %l287, !tbaa !21
  br label %bb142
bb142:
  %t508 = load i1, ptr %l287, !tbaa !21
  store i1 %t508, ptr %l283, !tbaa !21
  br label %bb143
bb143:
  %t509 = load i1, ptr %l283, !tbaa !21
  store i1 %t509, ptr %l274, !tbaa !21
  br label %bb144
bb144:
  %t510 = load i1, ptr %l274, !tbaa !21
  br i1 %t510, label %bb145, label %bb146
bb145:
  call void @__olang_scope_close(ptr %s25)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb146:
  br label %bb147
bb147:
  call void @__olang_scope_close(ptr %s25)
  br label %bb148
bb148:
  %t512 = load i64, ptr %l38, !tbaa !24
  %t514 = add i64 %t512, 1
  store i64 %t514, ptr %l38, !tbaa !24
  br label %bb131
bb149:
  %t516 = load ptr, ptr %l3, !tbaa !29
  %t518 = getelementptr %"compiler/typed:Body", ptr %t516, i32 0, i32 5
  %t519 = load i64, ptr %l2, !tbaa !24
  %t522 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t518, i64 %t519)
  store i32 %t522, ptr %l296
  br label %bb150
bb150:
  %t523 = load i32, ptr %l296, !tbaa !23
  %t524 = sext i32 %t523 to i64
  store i64 %t524, ptr %l40, !tbaa !24
  %t526 = load ptr, ptr %l0, !tbaa !29
  store ptr %t526, ptr %l298, !tbaa !29
  %t527 = load ptr, ptr %l3, !tbaa !29
  %t529 = getelementptr %"compiler/typed:Body", ptr %t527, i32 0, i32 7
  %t530 = load i64, ptr %l40, !tbaa !24
  %t533 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t529, i64 %t530)
  store %"compiler/typed:Local" %t533, ptr %l302
  br label %bb151
bb151:
  %t534 = getelementptr %"compiler/typed:Local", ptr %l302, i32 0, i32 2
  %t535 = load i32, ptr %t534, !tbaa !23
  %t536 = load ptr, ptr %l298, !tbaa !29
  %t538 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFunc(ptr %v0, ptr %t536, i32 %t535)
  store i1 %t538, ptr %l304
  br label %bb152
bb152:
  %t539 = load i1, ptr %l304, !tbaa !21
  %t540 = xor i1 %t539, true
  br i1 %t540, label %bb153, label %bb154
bb153:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb154:
  br label %bb155
bb155:
  %t543 = load ptr, ptr %l0, !tbaa !29
  %t544 = load ptr, ptr %l3, !tbaa !29
  %t546 = getelementptr %"compiler/typed:Body", ptr %t544, i32 0, i32 11
  %t547 = load ptr, ptr %t546, !tbaa !29
  %t548 = load i64, ptr %l40, !tbaa !24
  %t552 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eocBlock(ptr %v0, ptr %v0, ptr %t543, ptr %t547, i64 %t548, i1 true)
  store i1 %t552, ptr %l311
  br label %bb156
bb156:
  call void @__olang_scope_close(ptr %s0)
  %t553 = load i1, ptr %l311, !tbaa !21
  store i1 %t553, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etryDefault(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i1
  %l21 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 14
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb15
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Try", ptr %t16, i32 0, i32 1
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  store { i64, ptr } %t19, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l5, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load i64, ptr %l4, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb8:
  br label %bb9
bb9:
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t33, ptr %l21, !tbaa !27
  %t34 = load i64, ptr %l4, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr ptr, ptr %t37, i64 %t34
  %t39 = load ptr, ptr %t38, !tbaa !39
  %t43 = getelementptr %"compiler/typed:Clause", ptr %t39, i32 0, i32 4
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t48 = icmp sgt i64 %t46, 0
  br i1 %t48, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb13:
  %t51 = load i64, ptr %l4, !tbaa !24
  %t53 = add i64 %t51, 1
  store i64 %t53, ptr %l4, !tbaa !24
  br label %bb6
bb14:
  br label %bb20
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_3af8b11586f6b4c8_66242c1d15d5a764)
  unreachable
bb20:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExprs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l16 = alloca { i64, ptr }
  %l25 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a2, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l7, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l7, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t15, ptr %l16, !tbaa !27
  %t16 = load i64, ptr %l6, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  %t34 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %t21, i64 %a3, i64 %a4)
  store i1 %t34, ptr %l25
  br label %bb5
bb5:
  %t35 = load i1, ptr %l25, !tbaa !21
  %t36 = xor i1 %t35, true
  br i1 %t36, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb9:
  %t39 = load i64, ptr %l6, !tbaa !24
  %t41 = add i64 %t39, 1
  store i64 %t41, ptr %l6, !tbaa !24
  br label %bb1
bb10:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evarName(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, [1 x i64] } %a2, ptr %a3) #0 {
entry:
  %l2 = alloca { i64, [1 x i64] }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store { i64, [1 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [1 x i64] }, ptr %l2
  %t3 = extractvalue { i64, [1 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [1 x i64] }, ptr %l2, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l4, !tbaa !23
  br label %bb5
bb2:
  %t10 = load { i64, [1 x i64] }, ptr %l2
  %t12 = extractvalue { i64, [1 x i64] } %t10, 0
  %t13 = icmp eq i64 %t12, 4
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = getelementptr { i64, [1 x i64] }, ptr %l2, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  store i32 %t17, ptr %l4, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t21 = load i32, ptr %l4, !tbaa !23
  %t27 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elocalName(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i32 %t21, ptr %a3)
  store { i64, ptr } %t27, ptr %l16
  br label %bb6
bb6:
  %t28 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t28, ptr %l5, !tbaa !27
  br label %bb20
bb7:
  %t29 = load { i64, [1 x i64] }, ptr %l2
  %t31 = extractvalue { i64, [1 x i64] } %t29, 0
  %t32 = icmp eq i64 %t31, 1
  br i1 %t32, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store { i64, ptr } { i64 6, ptr @.d11 }, ptr %l19, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t34, ptr %l5, !tbaa !27
  br label %bb20
bb11:
  %t36 = load { i64, [1 x i64] }, ptr %l2
  %t38 = extractvalue { i64, [1 x i64] } %t36, 0
  %t39 = icmp eq i64 %t38, 2
  br i1 %t39, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store { i64, ptr } { i64 12, ptr @.d12 }, ptr %l23, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t41, ptr %l5, !tbaa !27
  br label %bb20
bb15:
  %t43 = load { i64, [1 x i64] }, ptr %l2
  %t45 = extractvalue { i64, [1 x i64] } %t43, 0
  %t46 = icmp eq i64 %t45, 3
  br i1 %t46, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  store { i64, ptr } { i64 17, ptr @.d13 }, ptr %l27, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t48, ptr %l5, !tbaa !27
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_33e8f6984fda8b38_987c5f6a5f702884)
  unreachable
bb20:
  %t50 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t50, 0
  store i64 %t51, ptr %l29, !tbaa !24
  %t52 = load i64, ptr %l29, !tbaa !24
  %t53 = mul i64 %t52, 1
  %t54 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t53)
  %t55 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t54, 1
  store { i64, ptr } %t56, ptr %l30, !tbaa !27
  %t57 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = load i64, ptr %l29, !tbaa !24
  %t62 = mul i64 %t61, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t58, ptr %t60, i64 %t62, i1 false)
  %t63 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t63, ptr %l5, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t64, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewhereLives(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, [2 x i64] }
  %l7 = alloca { i64, [2 x i64] }
  %l16 = alloca { i64, [2 x i64] }
  %rv = alloca { i64, [2 x i64] }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 29
  %t4 = load i32, ptr %l1, !tbaa !23
  %t6 = sext i32 %t4 to i64
  %t9 = call { i64, [2 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t3, i64 %t6)
  store { i64, [2 x i64] } %t9, ptr %l7
  br label %bb1
bb1:
  %t10 = load { i64, [2 x i64] }, ptr %l7
  store { i64, [2 x i64] } %t10, ptr %l2
  %t11 = load { i64, [2 x i64] }, ptr %l2
  %t13 = extractvalue { i64, [2 x i64] } %t11, 0
  %t14 = icmp eq i64 %t13, 0
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t18, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/scope:Scoper", ptr %t20, i32 0, i32 30
  %t23 = load i32, ptr %l1, !tbaa !23
  %t25 = sext i32 %t23 to i64
  %t28 = call { i64, [2 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t22, i64 %t25)
  store { i64, [2 x i64] } %t28, ptr %l16
  br label %bb5
bb5:
  %t29 = load { i64, [2 x i64] }, ptr %l16
  store { i64, [2 x i64] } %t29, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewrittenCopy(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i1 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca %"compiler/source:Span"
  %l22 = alloca { i64, ptr }
  %l27 = alloca %"compiler/source:Span"
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca i1
  %l42 = alloca ptr
  %l46 = alloca i1
  %l49 = alloca i1
  %l50 = alloca i1
  %l53 = alloca i1
  %l55 = alloca i32
  %l59 = alloca %"compiler/source:Span"
  %l60 = alloca ptr
  %l61 = alloca i1
  %l67 = alloca ptr
  %l74 = alloca i1
  %l77 = alloca i1
  %l78 = alloca i1
  %l81 = alloca i1
  %l83 = alloca i32
  %l84 = alloca ptr
  %l85 = alloca i1
  %l90 = alloca %"compiler/source:Span"
  %l91 = alloca ptr
  %l93 = alloca %"compiler/source:Span"
  %l94 = alloca %"compiler/source:Span"
  %l97 = alloca i1
  %l99 = alloca i1
  %l101 = alloca i1
  %l106 = alloca %"compiler/source:Span"
  %l113 = alloca ptr
  %l114 = alloca i1
  %l120 = alloca i1
  %l126 = alloca i1
  %l129 = alloca i1
  %l132 = alloca i1
  %l135 = alloca i1
  %l136 = alloca i1
  %l142 = alloca i1
  %l143 = alloca ptr
  %l144 = alloca %"compiler/source:Span"
  %l146 = alloca i1
  %l148 = alloca i1
  %l151 = alloca %"compiler/msgs:Msg"
  %l152 = alloca %"compiler/msgs:Msg"
  %l153 = alloca %"compiler/msgs:Msg"
  %l154 = alloca i64
  %l157 = alloca i1
  %l160 = alloca i1
  %l163 = alloca i1
  %l166 = alloca i1
  %l169 = alloca ptr
  %l170 = alloca i1
  %l175 = alloca %"compiler/source:Span"
  %l177 = alloca ptr
  %l184 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l185 = alloca %"compiler/source:Span"
  %l186 = alloca i32
  %l187 = alloca %"compiler/source:Span"
  %l190 = alloca ptr
  %l191 = alloca i64
  %l196 = alloca ptr
  %l198 = alloca i64
  %l199 = alloca %"compiler/source:Span"
  %l200 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l22, !tbaa !27
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr ptr, ptr %t8, i64 %t5
  %t10 = load ptr, ptr %t9, !tbaa !39
  store ptr %t10, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  %t12 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t12, ptr %l7, !tbaa !23
  %t14 = load ptr, ptr %l5, !tbaa !29
  %t16 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t14)
  store %"compiler/source:Span" %t16, ptr %l27
  br label %bb1
bb1:
  %t17 = load %"compiler/source:Span", ptr %l27
  store %"compiler/source:Span" %t17, ptr %l8
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load ptr, ptr %l5, !tbaa !29
  %t23 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %t18, ptr %t19)
  store ptr %t23, ptr %l31
  br label %bb2
bb2:
  %t24 = load ptr, ptr %l31, !tbaa !29
  store ptr %t24, ptr %l9, !tbaa !29
  %t25 = load ptr, ptr %l9, !tbaa !29
  store ptr %t25, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t26 = load ptr, ptr %l32, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb3, label %bb4
bb3:
  %t29 = load ptr, ptr %l32, !tbaa !29
  %t30 = load i64, ptr %t29
  %t32 = icmp eq i64 %t30, 5
  store i1 %t32, ptr %l33, !tbaa !21
  br label %bb4
bb4:
  %t33 = load i1, ptr %l33, !tbaa !21
  br i1 %t33, label %bb5, label %bb6
bb5:
  %t34 = load ptr, ptr %l9, !tbaa !29
  %t36 = getelementptr { i64, [5 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t36, i32 0, i32 2
  %t38 = load ptr, ptr %t37
  store ptr %t38, ptr %l10, !tbaa !29
  br label %bb7
bb6:
  br label %bb23
bb7:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load ptr, ptr %l10, !tbaa !29
  %t43 = getelementptr %"compiler/typed:Promote", ptr %t41, i32 0, i32 0
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t48 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %t40, ptr %t44)
  store ptr %t48, ptr %l42
  br label %bb8
bb8:
  %t49 = load ptr, ptr %l42, !tbaa !29
  store ptr %t49, ptr %l11, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load ptr, ptr %l11, !tbaa !29
  %t55 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eatCall(ptr %v0, ptr %v1, ptr %t50, ptr %t51)
  store i1 %t55, ptr %l46
  br label %bb9
bb9:
  %t56 = load i1, ptr %l46, !tbaa !21
  br i1 %t56, label %bb10, label %bb11
bb10:
  store i64 1, ptr %l6, !tbaa !24
  br label %bb20
bb11:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l11, !tbaa !29
  %t61 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etryDefault(ptr %v0, ptr %v1, ptr %t57, ptr %t58)
  store i1 %t61, ptr %l49
  br label %bb12
bb12:
  %t62 = load i1, ptr %l49, !tbaa !21
  br i1 %t62, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb16
bb14:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load ptr, ptr %l11, !tbaa !29
  %t67 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2echoiceOfPlaces(ptr %v0, ptr %v1, ptr %t63, ptr %t64)
  store i1 %t67, ptr %l53
  br label %bb15
bb15:
  %t68 = load i1, ptr %l53, !tbaa !21
  store i1 %t68, ptr %l50, !tbaa !21
  br label %bb16
bb16:
  %t69 = load i1, ptr %l50, !tbaa !21
  br i1 %t69, label %bb17, label %bb18
bb17:
  store i64 2, ptr %l6, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t70 = load ptr, ptr %l11, !tbaa !29
  %t72 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t70)
  store i32 %t72, ptr %l55
  br label %bb21
bb21:
  %t73 = load i32, ptr %l55, !tbaa !23
  store i32 %t73, ptr %l7, !tbaa !23
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load ptr, ptr %l11, !tbaa !29
  %t79 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eelemAt(ptr %v0, ptr %v1, ptr %t74, ptr %t75)
  store %"compiler/source:Span" %t79, ptr %l59
  br label %bb22
bb22:
  %t80 = load %"compiler/source:Span", ptr %l59
  store %"compiler/source:Span" %t80, ptr %l8
  br label %bb65
bb23:
  %t81 = load ptr, ptr %l9, !tbaa !29
  store ptr %t81, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t82 = load ptr, ptr %l60, !tbaa !29
  %t83 = icmp ne ptr %t82, null
  br i1 %t83, label %bb24, label %bb25
bb24:
  %t85 = load ptr, ptr %l60, !tbaa !29
  %t86 = load i64, ptr %t85
  %t88 = icmp eq i64 %t86, 3
  store i1 %t88, ptr %l61, !tbaa !21
  br label %bb25
bb25:
  %t89 = load i1, ptr %l61, !tbaa !21
  br i1 %t89, label %bb26, label %bb27
bb26:
  %t90 = load ptr, ptr %l9, !tbaa !29
  %t92 = getelementptr { i64, [5 x i64] }, ptr %t90, i32 0, i32 1
  %t93 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t92, i32 0, i32 2
  %t94 = load ptr, ptr %t93
  store ptr %t94, ptr %l12, !tbaa !29
  br label %bb28
bb27:
  br label %bb60
bb28:
  %t96 = load ptr, ptr %l12, !tbaa !29
  %t98 = call ptr @compiler_2fscope_2etempOf(ptr %v1, ptr %t96)
  store ptr %t98, ptr %l67
  br label %bb29
bb29:
  %t99 = load ptr, ptr %l67, !tbaa !29
  store ptr %t99, ptr %l13, !tbaa !29
  %t100 = load ptr, ptr %l13, !tbaa !29
  %t102 = icmp eq ptr %t100, null
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb30, label %bb31
bb30:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load ptr, ptr %l13, !tbaa !29
  %t111 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eatCall(ptr %v0, ptr %v1, ptr %t106, ptr %t107)
  store i1 %t111, ptr %l74
  br label %bb32
bb31:
  br label %bb44
bb32:
  %t112 = load i1, ptr %l74, !tbaa !21
  br i1 %t112, label %bb33, label %bb34
bb33:
  store i64 1, ptr %l6, !tbaa !24
  br label %bb43
bb34:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load ptr, ptr %l13, !tbaa !29
  %t117 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etryDefault(ptr %v0, ptr %v1, ptr %t113, ptr %t114)
  store i1 %t117, ptr %l77
  br label %bb35
bb35:
  %t118 = load i1, ptr %l77, !tbaa !21
  br i1 %t118, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l78, !tbaa !21
  br label %bb39
bb37:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load ptr, ptr %l13, !tbaa !29
  %t123 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2echoiceOfPlaces(ptr %v0, ptr %v1, ptr %t119, ptr %t120)
  store i1 %t123, ptr %l81
  br label %bb38
bb38:
  %t124 = load i1, ptr %l81, !tbaa !21
  store i1 %t124, ptr %l78, !tbaa !21
  br label %bb39
bb39:
  %t125 = load i1, ptr %l78, !tbaa !21
  br i1 %t125, label %bb40, label %bb41
bb40:
  store i64 2, ptr %l6, !tbaa !24
  br label %bb42
bb41:
  br label %bb42
bb42:
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t126 = load ptr, ptr %l12, !tbaa !29
  %t128 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t126)
  store i32 %t128, ptr %l83
  br label %bb45
bb45:
  %t129 = load i32, ptr %l83, !tbaa !23
  store i32 %t129, ptr %l7, !tbaa !23
  %t130 = load ptr, ptr %l12, !tbaa !29
  store ptr %t130, ptr %l84, !tbaa !29
  store i1 false, ptr %l85, !tbaa !21
  %t131 = load ptr, ptr %l84, !tbaa !29
  %t132 = icmp ne ptr %t131, null
  br i1 %t132, label %bb46, label %bb47
bb46:
  %t134 = load ptr, ptr %l84, !tbaa !29
  %t135 = load i64, ptr %t134
  %t137 = icmp eq i64 %t135, 6
  store i1 %t137, ptr %l85, !tbaa !21
  br label %bb47
bb47:
  %t138 = load i1, ptr %l85, !tbaa !21
  br i1 %t138, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load ptr, ptr %l13, !tbaa !29
  %t143 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eelemAt(ptr %v0, ptr %v1, ptr %t139, ptr %t140)
  store %"compiler/source:Span" %t143, ptr %l90
  br label %bb51
bb51:
  %t144 = load %"compiler/source:Span", ptr %l90
  store %"compiler/source:Span" %t144, ptr %l8
  br label %bb59
bb52:
  br i1 true, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb58
bb55:
  %t145 = load ptr, ptr %l0, !tbaa !29
  store ptr %t145, ptr %l91, !tbaa !29
  %t146 = load ptr, ptr %l12, !tbaa !29
  %t148 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eSpan(ptr %v1, ptr %t146)
  store %"compiler/source:Span" %t148, ptr %l93
  br label %bb56
bb56:
  %t149 = load ptr, ptr %l91, !tbaa !29
  %t150 = load %"compiler/source:Span", ptr %l93
  %t151 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elastName(ptr %v0, ptr %t149, %"compiler/source:Span" %t150)
  store %"compiler/source:Span" %t151, ptr %l94
  br label %bb57
bb57:
  %t152 = load %"compiler/source:Span", ptr %l94
  store %"compiler/source:Span" %t152, ptr %l8
  br label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_dd80a499a713524_336e9d155656b240)
  unreachable
bb59:
  br label %bb65
bb60:
  br i1 true, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb65
bb64:
  call void @__olang_check_failed(ptr @olang_loc_56e16192221ba415_394443c36fbf1ad1)
  unreachable
bb65:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load i32, ptr %l7, !tbaa !23
  %t157 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisHandle(ptr %v0, ptr %t153, i32 %t154)
  store i1 %t157, ptr %l97
  br label %bb66
bb66:
  %t158 = load i1, ptr %l97, !tbaa !21
  store i1 %t158, ptr %l14, !tbaa !21
  %t159 = load i1, ptr %l3, !tbaa !21
  br i1 %t159, label %bb67, label %bb68
bb67:
  %t161 = load i1, ptr %l14, !tbaa !21
  store i1 %t161, ptr %l99, !tbaa !21
  br label %bb69
bb68:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb69
bb69:
  %t163 = load i1, ptr %l99, !tbaa !21
  br i1 %t163, label %bb70, label %bb71
bb70:
  %t164 = load i64, ptr %l6, !tbaa !24
  %t166 = icmp eq i64 %t164, 1
  store i1 %t166, ptr %l101, !tbaa !21
  br label %bb72
bb71:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb72
bb72:
  %t168 = load i1, ptr %l101, !tbaa !21
  br i1 %t168, label %bb73, label %bb74
bb73:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t173 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enameSpan(ptr %v0, ptr %t169, %"compiler/source:Span" %a4)
  store %"compiler/source:Span" %t173, ptr %l106
  br label %bb75
bb74:
  br label %bb76
bb75:
  %t174 = load %"compiler/source:Span", ptr %l106
  store %"compiler/source:Span" %t174, ptr %l8
  br label %bb76
bb76:
  %t175 = load i64, ptr %l6, !tbaa !24
  %t177 = icmp eq i64 %t175, 0
  br i1 %t177, label %bb77, label %bb78
bb77:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb78:
  br label %bb79
bb79:
  %t179 = load i1, ptr %l3, !tbaa !21
  %t181 = xor i1 %t179, true
  br i1 %t181, label %bb80, label %bb81
bb80:
  %t183 = load ptr, ptr %l1, !tbaa !29
  %t185 = getelementptr %"compiler/typed:Call", ptr %t183, i32 0, i32 0
  %t186 = load ptr, ptr %t185, !tbaa !29
  store ptr %t186, ptr %l15, !tbaa !29
  %t188 = load ptr, ptr %l15, !tbaa !29
  store ptr %t188, ptr %l113, !tbaa !29
  store i1 false, ptr %l114, !tbaa !21
  %t189 = load ptr, ptr %l113, !tbaa !29
  %t190 = icmp ne ptr %t189, null
  br i1 %t190, label %bb82, label %bb83
bb81:
  br label %bb114
bb82:
  %t192 = load ptr, ptr %l113, !tbaa !29
  %t193 = load i64, ptr %t192
  %t195 = icmp eq i64 %t193, 0
  store i1 %t195, ptr %l114, !tbaa !21
  br label %bb83
bb83:
  %t196 = load i1, ptr %l114, !tbaa !21
  br i1 %t196, label %bb84, label %bb85
bb84:
  %t197 = load ptr, ptr %l15, !tbaa !29
  %t199 = getelementptr { i64, [1 x i64] }, ptr %t197, i32 0, i32 1
  %t200 = getelementptr { i32 }, ptr %t199, i32 0, i32 0
  %t201 = load i32, ptr %t200
  store i32 %t201, ptr %l16, !tbaa !23
  br label %bb86
bb85:
  br label %bb108
bb86:
  %t203 = load i1, ptr %l14, !tbaa !21
  br i1 %t203, label %bb87, label %bb88
bb87:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load i32, ptr %l16, !tbaa !23
  %t208 = sext i32 %t206 to i64
  %t209 = load i64, ptr %l2, !tbaa !24
  %t210 = load i64, ptr @G_2ecompiler_2fscope_2eUseThru, !tbaa !24
  %t215 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2euses(ptr %v0, ptr %t205, i64 %t208, i64 %t209, i64 %t210)
  store i1 %t215, ptr %l126
  br label %bb89
bb88:
  store i1 false, ptr %l120, !tbaa !21
  br label %bb90
bb89:
  %t216 = load i1, ptr %l126, !tbaa !21
  store i1 %t216, ptr %l120, !tbaa !21
  br label %bb90
bb90:
  %t217 = load i1, ptr %l120, !tbaa !21
  br i1 %t217, label %bb91, label %bb92
bb91:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb92:
  br label %bb93
bb93:
  %t218 = load i64, ptr %l6, !tbaa !24
  %t220 = icmp eq i64 %t218, 1
  br i1 %t220, label %bb94, label %bb95
bb94:
  %t222 = load i1, ptr %l14, !tbaa !21
  %t224 = xor i1 %t222, true
  store i1 %t224, ptr %l129, !tbaa !21
  br label %bb96
bb95:
  store i1 false, ptr %l129, !tbaa !21
  br label %bb96
bb96:
  %t226 = load i1, ptr %l129, !tbaa !21
  br i1 %t226, label %bb97, label %bb98
bb97:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load i32, ptr %l7, !tbaa !23
  %t231 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisStruct(ptr %v0, ptr %t227, i32 %t228)
  store i1 %t231, ptr %l135
  br label %bb99
bb98:
  store i1 false, ptr %l132, !tbaa !21
  br label %bb100
bb99:
  %t232 = load i1, ptr %l135, !tbaa !21
  store i1 %t232, ptr %l132, !tbaa !21
  br label %bb100
bb100:
  %t233 = load i1, ptr %l132, !tbaa !21
  br i1 %t233, label %bb101, label %bb102
bb101:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load i32, ptr %l16, !tbaa !23
  %t237 = sext i32 %t235 to i64
  %t238 = load i64, ptr %l2, !tbaa !24
  %t239 = load i64, ptr @G_2ecompiler_2fscope_2eUseView, !tbaa !24
  %t244 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2euses(ptr %v0, ptr %t234, i64 %t237, i64 %t238, i64 %t239)
  store i1 %t244, ptr %l142
  br label %bb103
bb102:
  store i1 false, ptr %l136, !tbaa !21
  br label %bb104
bb103:
  %t245 = load i1, ptr %l142, !tbaa !21
  store i1 %t245, ptr %l136, !tbaa !21
  br label %bb104
bb104:
  %t246 = load i1, ptr %l136, !tbaa !21
  br i1 %t246, label %bb105, label %bb106
bb105:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb106:
  br label %bb107
bb107:
  br label %bb113
bb108:
  br i1 true, label %bb109, label %bb110
bb109:
  br label %bb111
bb110:
  br label %bb112
bb111:
  br label %bb113
bb112:
  call void @__olang_check_failed(ptr @olang_loc_704f1e45d26fb2de_b63ff9ec5bfa803a)
  unreachable
bb113:
  br label %bb114
bb114:
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l143, !tbaa !29
  %t248 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t248, ptr %l144
  %t249 = load i1, ptr %l3, !tbaa !21
  br i1 %t249, label %bb115, label %bb116
bb115:
  %t251 = load i1, ptr %l14, !tbaa !21
  store i1 %t251, ptr %l146, !tbaa !21
  br label %bb117
bb116:
  store i1 false, ptr %l146, !tbaa !21
  br label %bb117
bb117:
  %t253 = load i1, ptr %l146, !tbaa !21
  br i1 %t253, label %bb118, label %bb119
bb118:
  %t254 = load i64, ptr %l6, !tbaa !24
  %t256 = icmp eq i64 %t254, 1
  store i1 %t256, ptr %l148, !tbaa !21
  br label %bb120
bb119:
  store i1 false, ptr %l148, !tbaa !21
  br label %bb120
bb120:
  %t258 = load i1, ptr %l148, !tbaa !21
  br i1 %t258, label %bb121, label %bb122
bb121:
  %t259 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnAtElement(ptr %s0)
  store %"compiler/msgs:Msg" %t259, ptr %l152
  br label %bb123
bb122:
  %t260 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eWriteThroughAtCall(ptr %s0)
  store %"compiler/msgs:Msg" %t260, ptr %l153
  br label %bb124
bb123:
  %t261 = load %"compiler/msgs:Msg", ptr %l152
  store %"compiler/msgs:Msg" %t261, ptr %l151
  br label %bb125
bb124:
  %t262 = load %"compiler/msgs:Msg", ptr %l153
  store %"compiler/msgs:Msg" %t262, ptr %l151
  br label %bb125
bb125:
  %t263 = load ptr, ptr %l143, !tbaa !29
  %t264 = load %"compiler/source:Span", ptr %l144
  %t265 = load %"compiler/msgs:Msg", ptr %l151
  %t266 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s0, ptr %t263, %"compiler/source:Span" %t264, %"compiler/msgs:Msg" %t265)
  store i64 %t266, ptr %l154
  br label %bb126
bb126:
  %t267 = load i64, ptr %l154, !tbaa !24
  store i64 %t267, ptr %l17, !tbaa !24
  %t268 = load i1, ptr %l3, !tbaa !21
  %t270 = xor i1 %t268, true
  br i1 %t270, label %bb127, label %bb128
bb127:
  %t272 = load i64, ptr %l6, !tbaa !24
  %t274 = icmp eq i64 %t272, 1
  store i1 %t274, ptr %l157, !tbaa !21
  br label %bb129
bb128:
  store i1 false, ptr %l157, !tbaa !21
  br label %bb129
bb129:
  %t276 = load i1, ptr %l157, !tbaa !21
  br i1 %t276, label %bb130, label %bb131
bb130:
  %t277 = load i1, ptr %l14, !tbaa !21
  %t279 = xor i1 %t277, true
  store i1 %t279, ptr %l160, !tbaa !21
  br label %bb132
bb131:
  store i1 false, ptr %l160, !tbaa !21
  br label %bb132
bb132:
  %t281 = load i1, ptr %l160, !tbaa !21
  br i1 %t281, label %bb133, label %bb134
bb133:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t283 = load i32, ptr %l7, !tbaa !23
  %t286 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisStruct(ptr %v0, ptr %t282, i32 %t283)
  store i1 %t286, ptr %l166
  br label %bb135
bb134:
  store i1 false, ptr %l163, !tbaa !21
  br label %bb136
bb135:
  %t287 = load i1, ptr %l166, !tbaa !21
  store i1 %t287, ptr %l163, !tbaa !21
  br label %bb136
bb136:
  %t288 = load i1, ptr %l163, !tbaa !21
  br i1 %t288, label %bb137, label %bb138
bb137:
  %t289 = load ptr, ptr %l1, !tbaa !29
  %t291 = getelementptr %"compiler/typed:Call", ptr %t289, i32 0, i32 0
  %t292 = load ptr, ptr %t291, !tbaa !29
  store ptr %t292, ptr %l18, !tbaa !29
  %t294 = load ptr, ptr %l18, !tbaa !29
  store ptr %t294, ptr %l169, !tbaa !29
  store i1 false, ptr %l170, !tbaa !21
  %t295 = load ptr, ptr %l169, !tbaa !29
  %t296 = icmp ne ptr %t295, null
  br i1 %t296, label %bb139, label %bb140
bb138:
  br label %bb162
bb139:
  %t298 = load ptr, ptr %l169, !tbaa !29
  %t299 = load i64, ptr %t298
  %t301 = icmp eq i64 %t299, 0
  store i1 %t301, ptr %l170, !tbaa !21
  br label %bb140
bb140:
  %t302 = load i1, ptr %l170, !tbaa !21
  br i1 %t302, label %bb141, label %bb142
bb141:
  %t303 = load ptr, ptr %l18, !tbaa !29
  %t305 = getelementptr { i64, [1 x i64] }, ptr %t303, i32 0, i32 1
  %t306 = getelementptr { i32 }, ptr %t305, i32 0, i32 0
  %t307 = load i32, ptr %t306
  store i32 %t307, ptr %l19, !tbaa !23
  br label %bb143
bb142:
  br label %bb156
bb143:
  store %olang.scope zeroinitializer, ptr %s21
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t311 = getelementptr %"compiler/scope:Scoper", ptr %t309, i32 0, i32 88
  store ptr %t311, ptr %l177, !tbaa !29
  %t312 = load i32, ptr %l19, !tbaa !23
  %t314 = sext i32 %t312 to i64
  %t316 = mul i64 %t314, 4
  %t317 = load i64, ptr @G_2ecompiler_2fscope_2eUseView, !tbaa !24
  %t320 = add i64 %t316, %t317
  %t321 = load i64, ptr %l2, !tbaa !24
  %t324 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s21, i64 %t320, i64 %t321)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t324, ptr %l184
  br label %bb144
bb144:
  %t325 = load ptr, ptr %l177, !tbaa !29
  %t326 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l184
  %t327 = call { i32, %"compiler/source:Span" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H7d5384a5030fc995e793b3fe1f57e776(ptr %v0, ptr %t325, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t326)
  %t328 = extractvalue { i32, %"compiler/source:Span" } %t327, 1
  %t329 = extractvalue { i32, %"compiler/source:Span" } %t327, 0
  store i32 %t329, ptr %l186
  %t330 = icmp ne i32 %t329, 0
  br i1 %t330, label %bb146, label %ok.331
ok.331:
  store %"compiler/source:Span" %t328, ptr %l185
  br label %bb145
bb145:
  %t332 = load %"compiler/source:Span", ptr %l185
  store %"compiler/source:Span" %t332, ptr %l175
  br label %bb149
bb146:
  br label %bb147
bb147:
  %t333 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s21, i32 0, i32 0)
  store %"compiler/source:Span" %t333, ptr %l187
  br label %bb148
bb148:
  %t334 = load %"compiler/source:Span", ptr %l187
  store %"compiler/source:Span" %t334, ptr %l175
  br label %bb149
bb149:
  %t335 = load %"compiler/source:Span", ptr %l175
  store %"compiler/source:Span" %t335, ptr %l20
  %t336 = getelementptr %"compiler/source:Span", ptr %l20, i32 0, i32 1
  %t337 = load i32, ptr %t336, !tbaa !23
  %t339 = icmp sgt i32 %t337, 0
  br i1 %t339, label %bb150, label %bb151
bb150:
  store %olang.scope zeroinitializer, ptr %s22
  %t341 = load ptr, ptr %l0, !tbaa !29
  store ptr %t341, ptr %l190, !tbaa !29
  %t342 = load i64, ptr %l17, !tbaa !24
  store i64 %t342, ptr %l191, !tbaa !24
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t345 = getelementptr %"compiler/scope:Scoper", ptr %t343, i32 0, i32 1
  %t346 = load i32, ptr %l19, !tbaa !23
  %t348 = sext i32 %t346 to i64
  %t351 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t345, i64 %t348)
  store ptr %t351, ptr %l196
  br label %bb152
bb151:
  br label %bb155
bb152:
  %t352 = load ptr, ptr %l196, !tbaa !29
  %t354 = getelementptr %"compiler/typed:Body", ptr %t352, i32 0, i32 3
  %t355 = load i64, ptr %t354, !tbaa !24
  store i64 %t355, ptr %l198, !tbaa !24
  %t356 = load %"compiler/source:Span", ptr %l20
  store %"compiler/source:Span" %t356, ptr %l199
  %t357 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteViewRefusedBy(ptr %s22)
  store %"compiler/msgs:Msg" %t357, ptr %l200
  br label %bb153
bb153:
  %t358 = load ptr, ptr %l190, !tbaa !29
  %t359 = load i64, ptr %l191, !tbaa !24
  %t360 = load i64, ptr %l198, !tbaa !24
  %t361 = load %"compiler/source:Span", ptr %l199
  %t362 = load %"compiler/msgs:Msg", ptr %l200
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enote(ptr %v0, ptr %s22, ptr %t358, i64 %t359, i64 %t360, %"compiler/source:Span" %t361, %"compiler/msgs:Msg" %t362)
  br label %bb154
bb154:
  call void @__olang_scope_close(ptr %s22)
  br label %bb155
bb155:
  call void @__olang_scope_close(ptr %s21)
  br label %bb161
bb156:
  br i1 true, label %bb157, label %bb158
bb157:
  br label %bb159
bb158:
  br label %bb160
bb159:
  br label %bb161
bb160:
  call void @__olang_check_failed(ptr @olang_loc_8ccf378ebead7f5f_f5ae40f475d40cbb)
  unreachable
bb161:
  br label %bb162
bb162:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRelatable({ i64, [2 x i64] } %a0) #0 {
entry:
  %l0 = alloca { i64, [2 x i64] }
  %l1 = alloca i1
  %rv = alloca i1
  store { i64, [2 x i64] } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l0
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 2
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb7
bb2:
  %t6 = load { i64, [2 x i64] }, ptr %l0
  %t8 = extractvalue { i64, [2 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 4
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb7
bb4:
  %t11 = load { i64, [2 x i64] }, ptr %l0
  %t13 = extractvalue { i64, [2 x i64] } %t11, 0
  %t14 = icmp eq i64 %t13, 3
  br i1 %t14, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb13
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_df7e42d0d720f8e0_ba1485f60a37606c)
  unreachable
bb13:
  %t16 = load i1, ptr %l1, !tbaa !21
  store i1 %t16, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %a0) #0 {
entry:
  %l0 = alloca { i64, [2 x i64] }
  %l1 = alloca i1
  %rv = alloca i1
  store { i64, [2 x i64] } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l0
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb7
bb2:
  %t6 = load { i64, [2 x i64] }, ptr %l0
  %t8 = extractvalue { i64, [2 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 2
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb7
bb4:
  %t11 = load { i64, [2 x i64] }, ptr %l0
  %t13 = extractvalue { i64, [2 x i64] } %t11, 0
  %t14 = icmp eq i64 %t13, 3
  br i1 %t14, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb13
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_29ab6d94cb2a37cc_d7a08cac8eb9a0a8)
  unreachable
bb13:
  %t16 = load i1, ptr %l1, !tbaa !21
  store i1 %t16, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fscope_2ecountTrue(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l9 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i32
  %l22 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  store ptr %a0, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i64, ptr %l3, !tbaa !24
  %t7 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eRunFrom_3cBool_3e(ptr %v0, ptr %t3, i64 %t4)
  %t8 = extractvalue { i32, { i64, ptr } } %t7, 1
  %t9 = extractvalue { i32, { i64, ptr } } %t7, 0
  store i32 %t9, ptr %l13
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb3, label %ok.11
ok.11:
  store { i64, ptr } %t8, ptr %l12
  br label %bb2
bb2:
  %t12 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t12, ptr %l9, !tbaa !27
  br label %bb7
bb3:
  %t13 = load i32, ptr %l13, !tbaa !23
  %t14 = ashr i32 %t13, 16
  %t16 = icmp eq i32 %t14, 1
  br i1 %t16, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_1bd0f6fdaea7b0c0_ba6d95304dde346c)
  unreachable
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb7:
  %t18 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t18, ptr %l4, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  store i64 %t21, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t23 = load i64, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = icmp slt i64 %t23, %t24
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb10:
  br label %bb11
bb11:
  %t31 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t31, ptr %l22, !tbaa !27
  %t32 = load i64, ptr %l6, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr i1, ptr %t35, i64 %t32
  %t37 = load i1, ptr %t36, !tbaa !31
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t41 = load i64, ptr %l1, !tbaa !24
  %t43 = add i64 %t41, 1
  store i64 %t43, ptr %l1, !tbaa !24
  br label %bb14
bb13:
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  %t45 = load i64, ptr %l6, !tbaa !24
  %t47 = add i64 %t45, 1
  store i64 %t47, ptr %l6, !tbaa !24
  br label %bb8
bb16:
  %t49 = load i64, ptr %l3, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  %t53 = add i64 %t49, %t50
  store i64 %t53, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  br label %bb1
bb18:
  %t55 = load i64, ptr %l1, !tbaa !24
  store i64 %t55, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/scope:Val" @compiler_2fscope_2eexisting({ i64, [2 x i64] } %a0) #0 {
entry:
  %l3 = alloca %"compiler/scope:Val"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/scope:Val"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t4 = call %"compiler/scope:Val" @compiler_2fscope_3aVal_2ector(ptr %s0, i32 3, { i64, [2 x i64] } %a0)
  store %"compiler/scope:Val" %t4, ptr %l3
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t5 = load %"compiler/scope:Val", ptr %l3
  store %"compiler/scope:Val" %t5, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scope:Val", ptr %rv
  ret %"compiler/scope:Val" %rr
}

define dso_local i64 @compiler_2fscope_2eflRootExpr(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca i1
  %l35 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t7 = load ptr, ptr %l7, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l7, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 2
  store i1 %t13, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l8, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t17, i32 0, i32 2
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l1, !tbaa !29
  br label %bb16
bb7:
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t22 = load ptr, ptr %l13, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t26 = load i64, ptr %t25
  %t28 = icmp eq i64 %t26, 3
  store i1 %t28, ptr %l14, !tbaa !21
  br label %bb9
bb9:
  %t29 = load i1, ptr %l14, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr { i64, [5 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t32, i32 0, i32 2
  %t34 = load ptr, ptr %t33
  store ptr %t34, ptr %l1, !tbaa !29
  br label %bb16
bb11:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t37 = load ptr, ptr %l19, !tbaa !29
  %t38 = icmp ne ptr %t37, null
  br i1 %t38, label %bb12, label %bb13
bb12:
  %t40 = load ptr, ptr %l19, !tbaa !29
  %t41 = load i64, ptr %t40
  %t43 = icmp eq i64 %t41, 4
  store i1 %t43, ptr %l20, !tbaa !21
  br label %bb13
bb13:
  %t44 = load i1, ptr %l20, !tbaa !21
  br i1 %t44, label %bb14, label %bb15
bb14:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [5 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t47, i32 0, i32 2
  %t49 = load ptr, ptr %t48
  store ptr %t49, ptr %l1, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = call i64 @compiler_2fscope_2eflRoot(ptr %v0, ptr %t51)
  store i64 %t53, ptr %l26
  br label %bb17
bb17:
  %t54 = load i64, ptr %l26, !tbaa !24
  store i64 %t54, ptr %l6, !tbaa !24
  br label %bb30
bb18:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t56 = load ptr, ptr %l27, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb19, label %bb20
bb19:
  %t59 = load ptr, ptr %l27, !tbaa !29
  %t60 = load i64, ptr %t59
  %t62 = icmp eq i64 %t60, 17
  store i1 %t62, ptr %l28, !tbaa !21
  br label %bb20
bb20:
  %t63 = load i1, ptr %l28, !tbaa !21
  br i1 %t63, label %bb21, label %bb22
bb21:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr { i64, [5 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t66, i32 0, i32 2
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l2, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t70 = load ptr, ptr %l2, !tbaa !29
  %t73 = call i64 @compiler_2fscope_2eflRootExpr(ptr %v0, ptr %t70)
  store i64 %t73, ptr %l35
  br label %bb24
bb24:
  %t74 = load i64, ptr %l35, !tbaa !24
  store i64 %t74, ptr %l6, !tbaa !24
  br label %bb30
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  store i64 -1, ptr %l6, !tbaa !24
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_e9d57cf77a66352c_e30832457df38478)
  unreachable
bb30:
  %t75 = load i64, ptr %l6, !tbaa !24
  store i64 %t75, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fscope_2eregionLocal(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t17 = load ptr, ptr %l9, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l9, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l10, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l10, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t27, i32 0, i32 2
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l2, !tbaa !23
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t31 = load i32, ptr %l2, !tbaa !23
  %t33 = sext i32 %t31 to i64
  store i64 %t33, ptr %rv
  br label %ret
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_926310a74149af64_7456b8629edeed00)
  unreachable
bb16:
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_d723be5f6d33c955_f64e13843779cd91)
  unreachable
bb22:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fscope_2ethroughTemp(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %l16 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l25 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %l34 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb32
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t11 = load ptr, ptr %l9, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l9, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 3
  store i1 %t17, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l10, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l1, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = call i1 @compiler_2fscope_2ethroughTemp(ptr %v0, ptr %t25)
  store i1 %t27, ptr %l16
  br label %bb12
bb12:
  %t28 = load i1, ptr %l16, !tbaa !21
  store i1 %t28, ptr %l4, !tbaa !21
  br label %bb32
bb13:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t30 = load ptr, ptr %l17, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb14, label %bb15
bb14:
  %t33 = load ptr, ptr %l17, !tbaa !29
  %t34 = load i64, ptr %t33
  %t36 = icmp eq i64 %t34, 4
  store i1 %t36, ptr %l18, !tbaa !21
  br label %bb15
bb15:
  %t37 = load i1, ptr %l18, !tbaa !21
  br i1 %t37, label %bb16, label %bb17
bb16:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l2, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t46 = getelementptr %"compiler/typed:Elem", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = call i1 @compiler_2fscope_2ethroughTemp(ptr %v0, ptr %t47)
  store i1 %t49, ptr %l25
  br label %bb19
bb19:
  %t50 = load i1, ptr %l25, !tbaa !21
  store i1 %t50, ptr %l4, !tbaa !21
  br label %bb32
bb20:
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t52 = load ptr, ptr %l26, !tbaa !29
  %t53 = icmp ne ptr %t52, null
  br i1 %t53, label %bb21, label %bb22
bb21:
  %t55 = load ptr, ptr %l26, !tbaa !29
  %t56 = load i64, ptr %t55
  %t58 = icmp eq i64 %t56, 5
  store i1 %t58, ptr %l27, !tbaa !21
  br label %bb22
bb22:
  %t59 = load i1, ptr %l27, !tbaa !21
  br i1 %t59, label %bb23, label %bb24
bb23:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr { i64, [4 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t62, i32 0, i32 2
  %t64 = load ptr, ptr %t63
  store ptr %t64, ptr %l3, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t66 = load ptr, ptr %l3, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Payload", ptr %t66, i32 0, i32 0
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = call i1 @compiler_2fscope_2ethroughTemp(ptr %v0, ptr %t69)
  store i1 %t71, ptr %l34
  br label %bb26
bb26:
  %t72 = load i1, ptr %l34, !tbaa !21
  store i1 %t72, ptr %l4, !tbaa !21
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_30366b1ce1cb05a4_de371b7365ebcc00)
  unreachable
bb32:
  %t73 = load i1, ptr %l4, !tbaa !21
  store i1 %t73, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fscope_2eunWidened(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i1
  %l14 = alloca i1
  %l18 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l21 = alloca i1
  %l24 = alloca { i64, ptr }
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 9
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l1
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t18, i32 0, i32 4
  %t20 = load { i64, ptr }, ptr %t19
  store { i64, ptr } %t20, ptr %l2, !tbaa !27
  br label %bb5
bb4:
  br label %bb23
bb5:
  %t22 = load i32, ptr %l1
  %t24 = trunc i64 20 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t31 = icmp eq i64 %t29, 1
  store i1 %t31, ptr %l14, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l14, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t34 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t34, ptr %l18, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr ptr, ptr %t36, i64 0
  %t38 = load ptr, ptr %t37, !tbaa !39
  store ptr %t38, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t41 = load ptr, ptr %l20, !tbaa !29
  %t42 = icmp ne ptr %t41, null
  br i1 %t42, label %bb11, label %bb12
bb10:
  br label %bb22
bb11:
  %t44 = load ptr, ptr %l20, !tbaa !29
  %t45 = load i64, ptr %t44
  %t47 = icmp eq i64 %t45, 10
  store i1 %t47, ptr %l21, !tbaa !21
  br label %bb12
bb12:
  %t48 = load i1, ptr %l21, !tbaa !21
  br i1 %t48, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t49 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t49, ptr %l24, !tbaa !27
  %t50 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr ptr, ptr %t51, i64 0
  %t53 = load ptr, ptr %t52, !tbaa !39
  store ptr %t53, ptr %rv
  br label %ret
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_c76fb05b477ad754_aaa77e81edb6bb58)
  unreachable
bb21:
  br label %bb22
bb22:
  br label %bb28
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_472a8ee29a396e05_19ea125b0d0f8e29)
  unreachable
bb28:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/scope:walked" @compiler_2fscope_2ewalkBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/scope:walked"
  %l8 = alloca ptr
  %rv = alloca %"compiler/scope:walked"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"compiler/scope:walked" @olang_2eHelperKind_2eZero_2ecompiler_2fscope_3awalked(ptr %t1)
  store %"compiler/scope:walked" %t2, ptr %l4
  br label %bb1
bb1:
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 56, i64 8)
  store ptr %t3, ptr %lp2
  %t4 = load %"compiler/scope:walked", ptr %l4
  %t5 = load ptr, ptr %lp2
  store %"compiler/scope:walked" %t4, ptr %t5
  %t8 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 1
  %t12 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t8, i64 %a1)
  store ptr %t12, ptr %l8
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l8, !tbaa !29
  store ptr %t13, ptr %l3, !tbaa !29
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t16 = getelementptr %"compiler/typed:Body", ptr %t14, i32 0, i32 11
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = icmp eq ptr %t17, null
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb3, label %bb4
bb3:
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t25 = getelementptr %"compiler/typed:Body", ptr %t23, i32 0, i32 11
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t27 = load ptr, ptr %lp2
  call void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %v1, ptr %t26, ptr %t27)
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb6
bb6:
  %t30 = load ptr, ptr %lp2
  %t31 = load %"compiler/scope:walked", ptr %t30
  store %"compiler/scope:walked" %t31, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scope:walked", ptr %rv
  ret %"compiler/scope:walked" %rr
}

define dso_local void @compiler_2fscope_3aScoper_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca { ptr, ptr }
  %l7 = alloca { ptr, ptr }
  %l8 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l17 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l21 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l23 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca i64
  %l25 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l26 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca i1
  %l30 = alloca %"compiler/typed:Plan"
  %l31 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l32 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l33 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l34 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l35 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l36 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l37 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l38 = alloca %"compiler/source:Span"
  %l39 = alloca i64
  %l40 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l41 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l42 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l43 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l44 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l45 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l46 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l47 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l48 = alloca i64
  %l49 = alloca i1
  %l50 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l51 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l52 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l56 = alloca i1
  %l57 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l58 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l59 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l60 = alloca i1
  %l61 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l62 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l63 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l64 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l65 = alloca i1
  %l66 = alloca i1
  %l67 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l68 = alloca { i64, [2 x i64] }
  %l69 = alloca i1
  %l70 = alloca %"compiler/source:Span"
  %l71 = alloca { i64, [2 x i64] }
  %l72 = alloca i1
  %l73 = alloca { i64, [2 x i64] }
  %l74 = alloca i1
  %l75 = alloca i1
  %l76 = alloca i1
  %l77 = alloca %"compiler/source:Span"
  %l78 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l79 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l80 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l81 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l82 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l83 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l84 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l85 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l86 = alloca { i64, [2 x i64] }
  %l87 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l88 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l89 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l90 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l91 = alloca %"compiler/source:Span"
  %l92 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l93 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l94 = alloca i1
  %l95 = alloca i64
  %l96 = alloca { i64, [2 x i64] }
  %l97 = alloca i1
  %l98 = alloca i1
  %l99 = alloca i1
  %l100 = alloca i64
  %l101 = alloca i1
  %l102 = alloca i1
  %l103 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l104 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l105 = alloca i1
  %l106 = alloca i64
  %l107 = alloca i32
  %l108 = alloca i1
  %l109 = alloca i1
  %l110 = alloca i1
  %l111 = alloca i1
  %l112 = alloca i64
  %l116 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l117 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l118 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l119 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l120 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l121 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l122 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l123 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l124 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l125 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l126 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l127 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l128 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l129 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l130 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l131 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l132 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l133 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l134 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l135 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l136 = alloca %"compiler/typed:Plan"
  %l137 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l138 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l139 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l140 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l141 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l142 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l143 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l144 = alloca %"compiler/source:Span"
  %l145 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l146 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l147 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l148 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l149 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l150 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l151 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l152 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l153 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l154 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l155 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l156 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l157 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l158 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l159 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l160 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l161 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l162 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l163 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l164 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l166 = alloca %"compiler/source:Span"
  %l169 = alloca %"compiler/source:Span"
  %l170 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l171 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l172 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l173 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l174 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l175 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l176 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l177 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l179 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l180 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l181 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l182 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l183 = alloca %"compiler/source:Span"
  %l184 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l185 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l187 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l188 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l189 = alloca %"compiler/source:Span"
  %l190 = alloca %"compiler/scope:Scoper"
  %t150 = alloca { i64, [2 x i64] }, align 8
  %t156 = alloca { i64, [2 x i64] }, align 8
  %t160 = alloca { i64, [2 x i64] }, align 8
  %t190 = alloca { i64, [2 x i64] }, align 8
  %t214 = alloca { i64, [2 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, ptr %l3
  %t5 = load ptr, ptr @__olang_prog_scope
  %t6 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e(ptr %t5)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l116
  br label %bb1
bb1:
  %t7 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l116
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l4
  %t8 = load ptr, ptr @__olang_prog_scope
  %t9 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3aGap_3e(ptr %t8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l117
  br label %bb2
bb2:
  %t10 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l117
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l5
  store { ptr, ptr } zeroinitializer, ptr %l6
  store { ptr, ptr } zeroinitializer, ptr %l7
  %t11 = load ptr, ptr @__olang_prog_scope
  %t12 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fscope_3asummary_26_3e(ptr %t11)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l118
  br label %bb3
bb3:
  %t13 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l118
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l8
  %t14 = load ptr, ptr @__olang_prog_scope
  %t15 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %t14)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %l119
  br label %bb4
bb4:
  %t16 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l119
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l9
  %t17 = load ptr, ptr @__olang_prog_scope
  %t18 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %t17)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t18, ptr %l120
  br label %bb5
bb5:
  %t19 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l120
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, ptr %l10
  %t20 = load ptr, ptr @__olang_prog_scope
  %t21 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e(ptr %t20)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, ptr %l121
  br label %bb6
bb6:
  %t22 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l121
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l11
  %t23 = load ptr, ptr @__olang_prog_scope
  %t24 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e(ptr %t23)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l122
  br label %bb7
bb7:
  %t25 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l122
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l12
  %t26 = load ptr, ptr @__olang_prog_scope
  %t27 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %t26)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t27, ptr %l123
  br label %bb8
bb8:
  %t28 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l123
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, ptr %l13
  %t29 = load ptr, ptr @__olang_prog_scope
  %t30 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t29)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t30, ptr %l124
  br label %bb9
bb9:
  %t31 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l124
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t31, ptr %l14
  %t32 = load ptr, ptr @__olang_prog_scope
  %t33 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t32)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t33, ptr %l125
  br label %bb10
bb10:
  %t34 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l125
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t34, ptr %l15
  %t35 = load ptr, ptr @__olang_prog_scope
  %t36 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t35)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t36, ptr %l126
  br label %bb11
bb11:
  %t37 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l126
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t37, ptr %l16
  %t38 = load ptr, ptr @__olang_prog_scope
  %t39 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t38)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t39, ptr %l127
  br label %bb12
bb12:
  %t40 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l127
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, ptr %l17
  %t41 = load ptr, ptr @__olang_prog_scope
  %t42 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t41)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t42, ptr %l128
  br label %bb13
bb13:
  %t43 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l128
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t43, ptr %l18
  %t44 = load ptr, ptr @__olang_prog_scope
  %t45 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t44)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t45, ptr %l129
  br label %bb14
bb14:
  %t46 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l129
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t46, ptr %l19
  %t47 = load ptr, ptr @__olang_prog_scope
  %t48 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t47)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t48, ptr %l130
  br label %bb15
bb15:
  %t49 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l130
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t49, ptr %l20
  %t50 = load ptr, ptr @__olang_prog_scope
  %t51 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t50)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t51, ptr %l131
  br label %bb16
bb16:
  %t52 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l131
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t52, ptr %l21
  %t53 = load ptr, ptr @__olang_prog_scope
  %t54 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %t53)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t54, ptr %l132
  br label %bb17
bb17:
  %t55 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l132
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t55, ptr %l22
  %t56 = load ptr, ptr @__olang_prog_scope
  %t57 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t56)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t57, ptr %l133
  br label %bb18
bb18:
  %t58 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l133
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t58, ptr %l23
  store i64 0, ptr %l24, !tbaa !24
  %t59 = load ptr, ptr @__olang_prog_scope
  %t60 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t59)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t60, ptr %l134
  br label %bb19
bb19:
  %t61 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l134
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t61, ptr %l25
  %t62 = load ptr, ptr @__olang_prog_scope
  %t63 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t62)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t63, ptr %l135
  br label %bb20
bb20:
  %t64 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l135
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t64, ptr %l26
  store ptr null, ptr %l27, !tbaa !29
  store i64 -1, ptr %l28, !tbaa !24
  store i1 false, ptr %l29, !tbaa !21
  %t65 = call %"compiler/typed:Plan" @compiler_2ftyped_3aPlan_2ector(ptr %v2, i64 0, i64 0, i64 0)
  store %"compiler/typed:Plan" %t65, ptr %l136
  br label %bb21
bb21:
  %t66 = load %"compiler/typed:Plan", ptr %l136
  store %"compiler/typed:Plan" %t66, ptr %l30
  %t67 = load ptr, ptr @__olang_prog_scope
  %t68 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3aTerm_3e(ptr %t67)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t68, ptr %l137
  br label %bb22
bb22:
  %t69 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l137
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t69, ptr %l31
  %t70 = load ptr, ptr @__olang_prog_scope
  %t71 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3aTerm_3e(ptr %t70)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t71, ptr %l138
  br label %bb23
bb23:
  %t72 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l138
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t72, ptr %l32
  %t73 = load ptr, ptr @__olang_prog_scope
  %t74 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t73)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t74, ptr %l139
  br label %bb24
bb24:
  %t75 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l139
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t75, ptr %l33
  %t76 = load ptr, ptr @__olang_prog_scope
  %t77 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockId_3e(ptr %t76)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t77, ptr %l140
  br label %bb25
bb25:
  %t78 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l140
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t78, ptr %l34
  %t79 = load ptr, ptr @__olang_prog_scope
  %t80 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3arel_3e(ptr %t79)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t80, ptr %l141
  br label %bb26
bb26:
  %t81 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l141
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t81, ptr %l35
  %t82 = load ptr, ptr @__olang_prog_scope
  %t83 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t82)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t83, ptr %l142
  br label %bb27
bb27:
  %t84 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l142
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t84, ptr %l36
  %t85 = load ptr, ptr @__olang_prog_scope
  %t86 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3aTerm_3e(ptr %t85)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t86, ptr %l143
  br label %bb28
bb28:
  %t87 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l143
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t87, ptr %l37
  %t88 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v2, i32 0, i32 0)
  store %"compiler/source:Span" %t88, ptr %l144
  br label %bb29
bb29:
  %t89 = load %"compiler/source:Span", ptr %l144
  store %"compiler/source:Span" %t89, ptr %l38
  store i64 -1, ptr %l39, !tbaa !24
  %t90 = load ptr, ptr @__olang_prog_scope
  %t91 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e(ptr %t90)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t91, ptr %l145
  br label %bb30
bb30:
  %t92 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l145
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t92, ptr %l40
  %t93 = load ptr, ptr @__olang_prog_scope
  %t94 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e(ptr %t93)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t94, ptr %l146
  br label %bb31
bb31:
  %t95 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l146
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t95, ptr %l41
  %t96 = load ptr, ptr @__olang_prog_scope
  %t97 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e(ptr %t96)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t97, ptr %l147
  br label %bb32
bb32:
  %t98 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l147
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t98, ptr %l42
  %t99 = load ptr, ptr @__olang_prog_scope
  %t100 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t99)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t100, ptr %l148
  br label %bb33
bb33:
  %t101 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l148
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t101, ptr %l43
  %t102 = load ptr, ptr @__olang_prog_scope
  %t103 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3aTerm_3e(ptr %t102)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t103, ptr %l149
  br label %bb34
bb34:
  %t104 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l149
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t104, ptr %l44
  %t105 = load ptr, ptr @__olang_prog_scope
  %t106 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t105)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t106, ptr %l150
  br label %bb35
bb35:
  %t107 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l150
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t107, ptr %l45
  %t108 = load ptr, ptr @__olang_prog_scope
  %t109 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t108)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t109, ptr %l151
  br label %bb36
bb36:
  %t110 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l151
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t110, ptr %l46
  %t111 = load ptr, ptr @__olang_prog_scope
  %t112 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %t111)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t112, ptr %l152
  br label %bb37
bb37:
  %t113 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l152
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t113, ptr %l47
  store i64 -1, ptr %l48, !tbaa !24
  store i1 false, ptr %l49, !tbaa !21
  %t114 = load ptr, ptr @__olang_prog_scope
  %t115 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2flist_3a_Hdfd399a8559b0071638a5a5740a64f1e(ptr %t114)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t115, ptr %l153
  br label %bb38
bb38:
  %t116 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l153
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t116, ptr %l50
  %t117 = load ptr, ptr @__olang_prog_scope
  %t118 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t117)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t118, ptr %l154
  br label %bb39
bb39:
  %t119 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l154
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t119, ptr %l51
  %t120 = load ptr, ptr @__olang_prog_scope
  %t121 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t120)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t121, ptr %l155
  br label %bb40
bb40:
  %t122 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l155
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t122, ptr %l52
  store i64 -1, ptr %l53, !tbaa !24
  store i64 0, ptr %l54, !tbaa !24
  %t123 = load ptr, ptr @__olang_prog_scope
  %t124 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3aTerm_3e(ptr %t123)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t124, ptr %l156
  br label %bb41
bb41:
  %t125 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l156
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t125, ptr %l55
  store i1 false, ptr %l56, !tbaa !21
  %t126 = load ptr, ptr @__olang_prog_scope
  %t127 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e(ptr %t126)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t127, ptr %l157
  br label %bb42
bb42:
  %t128 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l157
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t128, ptr %l57
  %t129 = load ptr, ptr @__olang_prog_scope
  %t130 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %t129)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t130, ptr %l158
  br label %bb43
bb43:
  %t131 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l158
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t131, ptr %l58
  %t132 = load ptr, ptr @__olang_prog_scope
  %t133 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %t132)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t133, ptr %l159
  br label %bb44
bb44:
  %t134 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l159
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t134, ptr %l59
  store i1 false, ptr %l60, !tbaa !21
  %t135 = load ptr, ptr @__olang_prog_scope
  %t136 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e(ptr %t135)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t136, ptr %l160
  br label %bb45
bb45:
  %t137 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l160
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t137, ptr %l61
  %t138 = load ptr, ptr @__olang_prog_scope
  %t139 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t138)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t139, ptr %l161
  br label %bb46
bb46:
  %t140 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l161
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t140, ptr %l62
  %t141 = load ptr, ptr @__olang_prog_scope
  %t142 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e(ptr %t141)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t142, ptr %l162
  br label %bb47
bb47:
  %t143 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l162
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t143, ptr %l63
  %t144 = load ptr, ptr @__olang_prog_scope
  %t145 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %t144)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t145, ptr %l163
  br label %bb48
bb48:
  %t146 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l163
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t146, ptr %l64
  store i1 false, ptr %l65, !tbaa !21
  store i1 false, ptr %l66, !tbaa !21
  %t147 = load ptr, ptr @__olang_prog_scope
  %t148 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockId_3e(ptr %t147)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t148, ptr %l164
  br label %bb49
bb49:
  %t149 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l164
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t149, ptr %l67
  store { i64, [2 x i64] } zeroinitializer, ptr %t150
  %t151 = getelementptr { i64, [2 x i64] }, ptr %t150, i32 0, i32 0
  store i64 0, ptr %t151
  %t152 = load { i64, [2 x i64] }, ptr %t150
  store { i64, [2 x i64] } %t152, ptr %l68
  store i1 false, ptr %l69, !tbaa !21
  %t154 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v2, i32 0, i32 0)
  store %"compiler/source:Span" %t154, ptr %l166
  br label %bb50
bb50:
  %t155 = load %"compiler/source:Span", ptr %l166
  store %"compiler/source:Span" %t155, ptr %l70
  store { i64, [2 x i64] } zeroinitializer, ptr %t156
  %t157 = getelementptr { i64, [2 x i64] }, ptr %t156, i32 0, i32 0
  store i64 0, ptr %t157
  %t158 = load { i64, [2 x i64] }, ptr %t156
  store { i64, [2 x i64] } %t158, ptr %l71
  store i1 false, ptr %l72, !tbaa !21
  store { i64, [2 x i64] } zeroinitializer, ptr %t160
  %t161 = getelementptr { i64, [2 x i64] }, ptr %t160, i32 0, i32 0
  store i64 0, ptr %t161
  %t162 = load { i64, [2 x i64] }, ptr %t160
  store { i64, [2 x i64] } %t162, ptr %l73
  store i1 false, ptr %l74, !tbaa !21
  store i1 false, ptr %l75, !tbaa !21
  store i1 false, ptr %l76, !tbaa !21
  %t164 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v2, i32 0, i32 0)
  store %"compiler/source:Span" %t164, ptr %l169
  br label %bb51
bb51:
  %t165 = load %"compiler/source:Span", ptr %l169
  store %"compiler/source:Span" %t165, ptr %l77
  %t166 = load ptr, ptr @__olang_prog_scope
  %t167 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3afnUse_3e(ptr %t166)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t167, ptr %l170
  br label %bb52
bb52:
  %t168 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l170
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t168, ptr %l78
  %t169 = load ptr, ptr @__olang_prog_scope
  %t170 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %t169)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t170, ptr %l171
  br label %bb53
bb53:
  %t171 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l171
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t171, ptr %l79
  %t172 = load ptr, ptr @__olang_prog_scope
  %t173 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %t172)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t173, ptr %l172
  br label %bb54
bb54:
  %t174 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l172
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t174, ptr %l80
  %t175 = load ptr, ptr @__olang_prog_scope
  %t176 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %t175)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t176, ptr %l173
  br label %bb55
bb55:
  %t177 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l173
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t177, ptr %l81
  %t178 = load ptr, ptr @__olang_prog_scope
  %t179 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3aTerm_3e(ptr %t178)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t179, ptr %l174
  br label %bb56
bb56:
  %t180 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l174
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t180, ptr %l82
  %t181 = load ptr, ptr @__olang_prog_scope
  %t182 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %t181)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t182, ptr %l175
  br label %bb57
bb57:
  %t183 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l175
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t183, ptr %l83
  %t184 = load ptr, ptr @__olang_prog_scope
  %t185 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e(ptr %t184)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t185, ptr %l176
  br label %bb58
bb58:
  %t186 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l176
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t186, ptr %l84
  %t187 = load ptr, ptr @__olang_prog_scope
  %t188 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e(ptr %t187)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t188, ptr %l177
  br label %bb59
bb59:
  %t189 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l177
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t189, ptr %l85
  store { i64, [2 x i64] } zeroinitializer, ptr %t190
  %t191 = getelementptr { i64, [2 x i64] }, ptr %t190, i32 0, i32 0
  store i64 0, ptr %t191
  %t192 = load { i64, [2 x i64] }, ptr %t190
  store { i64, [2 x i64] } %t192, ptr %l86
  %t194 = load ptr, ptr @__olang_prog_scope
  %t195 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t194)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t195, ptr %l179
  br label %bb60
bb60:
  %t196 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l179
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t196, ptr %l87
  %t197 = load ptr, ptr @__olang_prog_scope
  %t198 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e(ptr %t197)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t198, ptr %l180
  br label %bb61
bb61:
  %t199 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l180
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t199, ptr %l88
  %t200 = load ptr, ptr @__olang_prog_scope
  %t201 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e(ptr %t200)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t201, ptr %l181
  br label %bb62
bb62:
  %t202 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l181
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t202, ptr %l89
  %t203 = load ptr, ptr @__olang_prog_scope
  %t204 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_H01b6fb75b9cc96416bdc55b4e10a9a4d(ptr %t203)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t204, ptr %l182
  br label %bb63
bb63:
  %t205 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l182
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t205, ptr %l90
  %t206 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v2, i32 0, i32 0)
  store %"compiler/source:Span" %t206, ptr %l183
  br label %bb64
bb64:
  %t207 = load %"compiler/source:Span", ptr %l183
  store %"compiler/source:Span" %t207, ptr %l91
  %t208 = load ptr, ptr @__olang_prog_scope
  %t209 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t208)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t209, ptr %l184
  br label %bb65
bb65:
  %t210 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l184
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t210, ptr %l92
  %t211 = load ptr, ptr @__olang_prog_scope
  %t212 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t211)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t212, ptr %l185
  br label %bb66
bb66:
  %t213 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l185
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t213, ptr %l93
  store i1 false, ptr %l94, !tbaa !21
  store i64 0, ptr %l95, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t214
  %t215 = getelementptr { i64, [2 x i64] }, ptr %t214, i32 0, i32 0
  store i64 0, ptr %t215
  %t216 = load { i64, [2 x i64] }, ptr %t214
  store { i64, [2 x i64] } %t216, ptr %l96
  store i1 false, ptr %l97, !tbaa !21
  store i1 false, ptr %l98, !tbaa !21
  store i1 false, ptr %l99, !tbaa !21
  store i64 -1, ptr %l100, !tbaa !24
  store i1 false, ptr %l101, !tbaa !21
  store i1 false, ptr %l102, !tbaa !21
  %t218 = load ptr, ptr @__olang_prog_scope
  %t219 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t218)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t219, ptr %l187
  br label %bb67
bb67:
  %t220 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l187
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t220, ptr %l103
  %t221 = load ptr, ptr @__olang_prog_scope
  %t222 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t221)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t222, ptr %l188
  br label %bb68
bb68:
  %t223 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l188
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t223, ptr %l104
  store i1 false, ptr %l105, !tbaa !21
  store i64 0, ptr %l106, !tbaa !24
  store i32 0, ptr %l107, !tbaa !23
  store i1 false, ptr %l108, !tbaa !21
  store i1 true, ptr %l109, !tbaa !21
  store i1 false, ptr %l110, !tbaa !21
  store i1 false, ptr %l111, !tbaa !21
  store i64 -1, ptr %l112, !tbaa !24
  %t224 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v2, i32 0, i32 0)
  store %"compiler/source:Span" %t224, ptr %l189
  br label %bb69
bb69:
  %t225 = load %"compiler/source:Span", ptr %l189
  %t226 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 0
  %t227 = load ptr, ptr %l2, !tbaa !29
  store ptr %t227, ptr %t226, !tbaa !29
  %t228 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 1
  %t229 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t229, ptr %t228
  %t230 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 2
  %t231 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t231, ptr %t230
  %t232 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 3
  %t233 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t233, ptr %t232
  %t234 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 4
  %t235 = load { ptr, ptr }, ptr %l6
  store { ptr, ptr } %t235, ptr %t234
  %t236 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 5
  %t237 = load { ptr, ptr }, ptr %l7
  store { ptr, ptr } %t237, ptr %t236
  %t238 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 6
  %t239 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t239, ptr %t238
  %t240 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 7
  %t241 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t241, ptr %t240
  %t242 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 8
  %t243 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t243, ptr %t242
  %t244 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 9
  %t245 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t245, ptr %t244
  %t246 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 10
  %t247 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t247, ptr %t246
  %t248 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 11
  %t249 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t249, ptr %t248
  %t250 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 12
  %t251 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l14
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t251, ptr %t250
  %t252 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 13
  %t253 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l15
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t253, ptr %t252
  %t254 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 14
  %t255 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t255, ptr %t254
  %t256 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 15
  %t257 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l17
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t257, ptr %t256
  %t258 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 16
  %t259 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l18
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t259, ptr %t258
  %t260 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 17
  %t261 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t261, ptr %t260
  %t262 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 18
  %t263 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t263, ptr %t262
  %t264 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 19
  %t265 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l21
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t265, ptr %t264
  %t266 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 20
  %t267 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l22
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t267, ptr %t266
  %t268 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 21
  %t269 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l23
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t269, ptr %t268
  %t270 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 22
  %t271 = load i64, ptr %l24, !tbaa !24
  store i64 %t271, ptr %t270, !tbaa !24
  %t272 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 23
  %t273 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l25
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t273, ptr %t272
  %t274 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 24
  %t275 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l26
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t275, ptr %t274
  %t276 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 25
  %t277 = load ptr, ptr %l27, !tbaa !29
  store ptr %t277, ptr %t276, !tbaa !29
  %t278 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 26
  %t279 = load i64, ptr %l28, !tbaa !24
  store i64 %t279, ptr %t278, !tbaa !24
  %t280 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 27
  %t281 = load i1, ptr %l29, !tbaa !21
  store i1 %t281, ptr %t280, !tbaa !21
  %t282 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 28
  %t283 = load %"compiler/typed:Plan", ptr %l30
  store %"compiler/typed:Plan" %t283, ptr %t282
  %t284 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 29
  %t285 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l31
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t285, ptr %t284
  %t286 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 30
  %t287 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l32
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t287, ptr %t286
  %t288 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 31
  %t289 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l33
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t289, ptr %t288
  %t290 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 32
  %t291 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l34
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t291, ptr %t290
  %t292 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 33
  %t293 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l35
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t293, ptr %t292
  %t294 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 34
  %t295 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l36
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t295, ptr %t294
  %t296 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 35
  %t297 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l37
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t297, ptr %t296
  %t298 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 36
  %t299 = load %"compiler/source:Span", ptr %l38
  store %"compiler/source:Span" %t299, ptr %t298
  %t300 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 37
  %t301 = load i64, ptr %l39, !tbaa !24
  store i64 %t301, ptr %t300, !tbaa !24
  %t302 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 38
  %t303 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l40
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t303, ptr %t302
  %t304 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 39
  %t305 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l41
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t305, ptr %t304
  %t306 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 40
  %t307 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l42
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t307, ptr %t306
  %t308 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 41
  %t309 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l43
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t309, ptr %t308
  %t310 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 42
  %t311 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l44
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t311, ptr %t310
  %t312 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 43
  %t313 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l45
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t313, ptr %t312
  %t314 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 44
  %t315 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l46
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t315, ptr %t314
  %t316 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 45
  %t317 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l47
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t317, ptr %t316
  %t318 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 46
  %t319 = load i64, ptr %l48, !tbaa !24
  store i64 %t319, ptr %t318, !tbaa !24
  %t320 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 47
  %t321 = load i1, ptr %l49, !tbaa !21
  store i1 %t321, ptr %t320, !tbaa !21
  %t322 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 48
  %t323 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l50
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t323, ptr %t322
  %t324 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 49
  %t325 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l51
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t325, ptr %t324
  %t326 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 50
  %t327 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l52
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t327, ptr %t326
  %t328 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 51
  %t329 = load i64, ptr %l53, !tbaa !24
  store i64 %t329, ptr %t328, !tbaa !24
  %t330 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 52
  %t331 = load i64, ptr %l54, !tbaa !24
  store i64 %t331, ptr %t330, !tbaa !24
  %t332 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 53
  %t333 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l55
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t333, ptr %t332
  %t334 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 54
  %t335 = load i1, ptr %l56, !tbaa !21
  store i1 %t335, ptr %t334, !tbaa !21
  %t336 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 55
  %t337 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l57
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t337, ptr %t336
  %t338 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 56
  %t339 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l58
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t339, ptr %t338
  %t340 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 57
  %t341 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l59
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t341, ptr %t340
  %t342 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 58
  %t343 = load i1, ptr %l60, !tbaa !21
  store i1 %t343, ptr %t342, !tbaa !21
  %t344 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 59
  %t345 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l61
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t345, ptr %t344
  %t346 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 60
  %t347 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l62
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t347, ptr %t346
  %t348 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 61
  %t349 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l63
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t349, ptr %t348
  %t350 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 62
  %t351 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l64
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t351, ptr %t350
  %t352 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 63
  %t353 = load i1, ptr %l65, !tbaa !21
  store i1 %t353, ptr %t352, !tbaa !21
  %t354 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 64
  %t355 = load i1, ptr %l66, !tbaa !21
  store i1 %t355, ptr %t354, !tbaa !21
  %t356 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 65
  %t357 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l67
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t357, ptr %t356
  %t358 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 66
  %t359 = load { i64, [2 x i64] }, ptr %l68
  store { i64, [2 x i64] } %t359, ptr %t358
  %t360 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 67
  %t361 = load i1, ptr %l69, !tbaa !21
  store i1 %t361, ptr %t360, !tbaa !21
  %t362 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 68
  %t363 = load %"compiler/source:Span", ptr %l70
  store %"compiler/source:Span" %t363, ptr %t362
  %t364 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 69
  %t365 = load { i64, [2 x i64] }, ptr %l71
  store { i64, [2 x i64] } %t365, ptr %t364
  %t366 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 70
  %t367 = load i1, ptr %l72, !tbaa !21
  store i1 %t367, ptr %t366, !tbaa !21
  %t368 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 71
  %t369 = load { i64, [2 x i64] }, ptr %l73
  store { i64, [2 x i64] } %t369, ptr %t368
  %t370 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 72
  %t371 = load i1, ptr %l74, !tbaa !21
  store i1 %t371, ptr %t370, !tbaa !21
  %t372 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 73
  %t373 = load i1, ptr %l75, !tbaa !21
  store i1 %t373, ptr %t372, !tbaa !21
  %t374 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 74
  %t375 = load i1, ptr %l76, !tbaa !21
  store i1 %t375, ptr %t374, !tbaa !21
  %t376 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 75
  %t377 = load %"compiler/source:Span", ptr %l77
  store %"compiler/source:Span" %t377, ptr %t376
  %t378 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 76
  %t379 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l78
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t379, ptr %t378
  %t380 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 77
  %t381 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l79
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t381, ptr %t380
  %t382 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 78
  %t383 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l80
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t383, ptr %t382
  %t384 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 79
  %t385 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l81
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t385, ptr %t384
  %t386 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 80
  %t387 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l82
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t387, ptr %t386
  %t388 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 81
  %t389 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l83
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t389, ptr %t388
  %t390 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 82
  %t391 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l84
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t391, ptr %t390
  %t392 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 83
  %t393 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l85
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t393, ptr %t392
  %t394 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 84
  %t395 = load { i64, [2 x i64] }, ptr %l86
  store { i64, [2 x i64] } %t395, ptr %t394
  %t396 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 85
  %t397 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l87
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t397, ptr %t396
  %t398 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 86
  %t399 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l88
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t399, ptr %t398
  %t400 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 87
  %t401 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l89
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t401, ptr %t400
  %t402 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 88
  %t403 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l90
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t403, ptr %t402
  %t404 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 89
  %t405 = load %"compiler/source:Span", ptr %l91
  store %"compiler/source:Span" %t405, ptr %t404
  %t406 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 90
  %t407 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l92
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t407, ptr %t406
  %t408 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 91
  %t409 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l93
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t409, ptr %t408
  %t410 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 92
  %t411 = load i1, ptr %l94, !tbaa !21
  store i1 %t411, ptr %t410, !tbaa !21
  %t412 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 93
  %t413 = load i64, ptr %l95, !tbaa !24
  store i64 %t413, ptr %t412, !tbaa !24
  %t414 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 94
  %t415 = load { i64, [2 x i64] }, ptr %l96
  store { i64, [2 x i64] } %t415, ptr %t414
  %t416 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 95
  %t417 = load i1, ptr %l97, !tbaa !21
  store i1 %t417, ptr %t416, !tbaa !21
  %t418 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 96
  %t419 = load i1, ptr %l98, !tbaa !21
  store i1 %t419, ptr %t418, !tbaa !21
  %t420 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 97
  %t421 = load i1, ptr %l99, !tbaa !21
  store i1 %t421, ptr %t420, !tbaa !21
  %t422 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 98
  %t423 = load i64, ptr %l100, !tbaa !24
  store i64 %t423, ptr %t422, !tbaa !24
  %t424 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 99
  %t425 = load i1, ptr %l101, !tbaa !21
  store i1 %t425, ptr %t424, !tbaa !21
  %t426 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 100
  %t427 = load i1, ptr %l102, !tbaa !21
  store i1 %t427, ptr %t426, !tbaa !21
  %t428 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 101
  %t429 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l103
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t429, ptr %t428
  %t430 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 102
  %t431 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l104
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t431, ptr %t430
  %t432 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 103
  %t433 = load i1, ptr %l105, !tbaa !21
  store i1 %t433, ptr %t432, !tbaa !21
  %t434 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 104
  %t435 = load i64, ptr %l106, !tbaa !24
  store i64 %t435, ptr %t434, !tbaa !24
  %t436 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 105
  %t437 = load i32, ptr %l107, !tbaa !23
  store i32 %t437, ptr %t436, !tbaa !23
  %t438 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 106
  %t439 = load i1, ptr %l108, !tbaa !21
  store i1 %t439, ptr %t438, !tbaa !21
  %t440 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 107
  %t441 = load i1, ptr %l109, !tbaa !21
  store i1 %t441, ptr %t440, !tbaa !21
  %t442 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 108
  %t443 = load i1, ptr %l110, !tbaa !21
  store i1 %t443, ptr %t442, !tbaa !21
  %t444 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 109
  %t445 = load i1, ptr %l111, !tbaa !21
  store i1 %t445, ptr %t444, !tbaa !21
  %t446 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 110
  %t447 = load i64, ptr %l112, !tbaa !24
  store i64 %t447, ptr %t446, !tbaa !24
  %t448 = getelementptr %"compiler/scope:Scoper", ptr %l190, i32 0, i32 111
  store %"compiler/source:Span" %t225, ptr %t448
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l190, i64 992, i1 false)
  br label %ret
ret:
  ret void
}

declare void @__olang_check_failed(ptr)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb13
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 i64 4, label %bb6 i64 5, label %bb7 ]
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [2 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  %t20 = icmp eq i32 %t13, %t17
  br i1 %t20, label %bb8, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb9, label %bb1
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [2 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i64, i64 }, ptr %t35, i32 0, i32 0
  %t37 = load i64, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [2 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i64, i64 }, ptr %t39, i32 0, i32 0
  %t41 = load i64, ptr %t40
  %t44 = icmp eq i64 %t37, %t41
  br i1 %t44, label %bb10, label %bb1
bb7:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [2 x i64] }, ptr %t46, i32 0, i32 1
  %t48 = getelementptr { i64 }, ptr %t47, i32 0, i32 0
  %t49 = load i64, ptr %t48
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [2 x i64] }, ptr %t50, i32 0, i32 1
  %t52 = getelementptr { i64 }, ptr %t51, i32 0, i32 0
  %t53 = load i64, ptr %t52
  %t56 = icmp eq i64 %t49, %t53
  br i1 %t56, label %bb12, label %bb1
bb8:
  br label %bb3
bb9:
  br label %bb3
bb10:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr { i64, [2 x i64] }, ptr %t58, i32 0, i32 1
  %t60 = getelementptr { i64, i64 }, ptr %t59, i32 0, i32 1
  %t61 = load i64, ptr %t60
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr { i64, [2 x i64] }, ptr %t62, i32 0, i32 1
  %t64 = getelementptr { i64, i64 }, ptr %t63, i32 0, i32 1
  %t65 = load i64, ptr %t64
  %t68 = icmp eq i64 %t61, %t65
  br i1 %t68, label %bb11, label %bb1
bb11:
  br label %bb3
bb12:
  br label %bb3
bb13:
  %t70 = load i1, ptr %l2, !tbaa !21
  store i1 %t70, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d0 = private constant [0 x i8] c""
@.d1 = private constant [0 x i8] c""
@.d2 = private constant [0 x i8] c""
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d3 = private constant [0 x i8] c""
@.d4 = private constant [0 x i8] c""
@.d5 = private constant [0 x i8] c""
@.d6 = private constant [0 x i8] c""
@.d7 = private constant [0 x i32] []
@.d8 = private constant [4 x i8] c"mut "
@.d9 = private constant [0 x i8] c""
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.d10 = private constant [1 x i8] c"&"
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d11 = private constant [6 x i8] c"return"
@.d12 = private constant [12 x i8] c"the instance"
@.d13 = private constant [17 x i8] c"the closing scope"
define linkonce_odr %"compiler/scope:walked" @olang_2eHelperKind_2eZero_2ecompiler_2fscope_3awalked(ptr %v0) #0 {
entry:
  %l0 = alloca %"compiler/scope:walked"
  %rv = alloca %"compiler/scope:walked"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"compiler/scope:walked" @compiler_2fscope_3awalked_2ector(ptr %t1)
  store %"compiler/scope:walked" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"compiler/scope:walked", ptr %l0
  store %"compiler/scope:walked" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scope:walked", ptr %rv
  ret %"compiler/scope:walked" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3aGap_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fscope_3aGap_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fscope_3asummary_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cmut_20compiler_2fscope_3asummary_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cBool_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3aTerm_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fscope_3aTerm_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3arel_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fscope_3arel_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2flist_3a_Hdfd399a8559b0071638a5a5740a64f1e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2flist_3aList_3ccompiler_2fscope_3aTerm_3e_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3afnUse_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fscope_3afnUse_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_H01b6fb75b9cc96416bdc55b4e10a9a4d(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fsource_3aSpan_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_61be1b0fda526a24_254af50801a17418 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ehasRel(ptr %v0, ptr %a0, %"compiler/scope:rel" %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3arel_3e_2ePush_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %a0, %"compiler/scope:rel" %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esetEnd(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [2 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_ade2525ec560ecac_5eadaea182574e0 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3aTerm_3e_2eRunFrom_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_baaa81966d3c6f5d_90f2815c501f8f1 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3aTerm_3e_2ePush_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eorder(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2)
@olang_loc_75a473c9145829d0_168d550c974bebd4 = external constant [0 x i8]
@olang_loc_2b3cb67345c2bf61_96483393ea0a8285 = external constant [0 x i8]
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elandTerm(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_85776ac018629bcc_231804c012e3a7c0 = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunPromoted(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erecOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_2489ab739aea8b00_863e154a28bdb8e4 = external constant [0 x i8]
declare %"compiler/scope:Val" @compiler_2fscope_2eplain()
declare %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2)
@olang_loc_76dd643541c5999_442dc791771fad = external constant [0 x i8]
declare %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblockTerm(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0, i64 %a1, { i64, [2 x i64] } %a2)
declare i1 @compiler_2fscope_2eflHas(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esetOf(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_a61f6227542ac272_aba93d64b04206c6 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockId_3e_2ePus_Hc98eca5dddbfee899ac629cbaebab24b(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_f34ecaa27a4fd2b3_7961e1dcca83cdb7 = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estmts(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, i32 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockId_3e_2ePop_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0)
@olang_loc_b442aabc3e151319_4a7d8af854ba830d = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ereassigned(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteLate(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2flist_3aList_3_H94d5bd7878f72069b50ef5a607d7e16d(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_4273f8ce606e6d61_560529ef83d0fbe5 = external constant [0 x i8]
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fscope_3asummary_26_H3a91daf058bf595e7b112751a30a6bbf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eLen_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsInto(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, %"compiler/source:Span" %a2, i64 %a3, %"compiler/source:Span" %a4)
@olang_loc_43515980f8c6aee5_797864ac7e38a2e9 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartOK(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2)
@olang_loc_51647c5149cfd088_fff8b53f00e80584 = external constant [0 x i8]
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebodyOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esummed(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eresultVarOf(ptr %v0, ptr %a0, i32 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3arel_3e_2eRunFrom_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_40698dacb4c14a59_3145716d01d07175 = external constant [0 x i8]
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekTerm(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estaticVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
@olang_loc_83a782b953f03662_f9414c39571087be = external constant [0 x i8]
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
@olang_loc_fe18b6f8ffe1c828_d6769ee32e48c6ec = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecapturesNothing(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_6e154fb23d94f618_2ee03e6b3f75e7ac = external constant [0 x i8]
@olang_loc_e36c9ef691e1ece9_3ba86da2e7516a5d = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarriedPlace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecanKeep(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
@olang_loc_9675e93c9f07526d_8a86ee267fb7b3d9 = external constant [0 x i8]
@olang_loc_768f72a2579754c5_d91cee094dc07e21 = external constant [0 x i8]
@olang_loc_15f791c29ca5960e_c2f6ea53b6b5628a = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_d9b9c9fdb1541cd0_611f76d9a930dfc4 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2earenaValue(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_fc2d23a56a9972c4_138c6d588cf96ab0 = external constant [0 x i8]
@olang_loc_3c97826faaf501b5_26e177716b83aa41 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
@olang_loc_f7f7e8cd8f874575_c4b9e23387941a21 = external constant [0 x i8]
@olang_loc_fdfd3ee9277a2fdd_9e10cfc7d92600f9 = external constant [0 x i8]
@olang_loc_933cba94e4afba7f_7f3963489057e55b = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %a0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisStruct(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efieldMark(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ectorParamIndex(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_a845573c521645ec_3201dcbaaced68 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ectorParams(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2eLe_H729d11b3a9b9a6787781d29df4918101(ptr %v0, ptr %a0)
declare { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_H9c4972d30d76581e4f8a183d5194d431(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_1acba385e9948a9d_2fa01f36b12cdd39 = external constant [0 x i8]
@olang_loc_c629952a85fc4586_8463807efabcbcc2 = external constant [0 x i8]
@olang_loc_fb66d6a098581c09_2fd4002f8136e06d = external constant [0 x i8]
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparamIndex(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_cd1d16db8329fc51_df7e5714e2c1cec5 = external constant [0 x i8]
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erecAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartsTerm(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fscope_2ethroughElem(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
@olang_loc_4a18cd046f6561ba_7ee6763527d0100e = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnFuncTooShort(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnArgHoldsShort(ptr %v0)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/msgs:Msg" %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeMayNotOutlive(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReferenceNarrowed(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2ePayloadOutlived(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOwnCannotOutlive(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eStoredRefOutlived(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eElemNotInArrayScope(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eElemOutlived(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eGlobalHoldsShorter(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnOwnStorage(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eValueRefsOutlived(ptr %v0)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisMethodCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_af8af1914718e174_e172e38237f6e418 = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflAdd(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarries(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eoutside(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fscope_2eflThroughRefExpr(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3afnUse_3e_2eRunFrom_3ccompiler_2fscope_3afnUse_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_bd29661a2aabb9c8_be78a85688d9755c = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCallValueObligations(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
@olang_loc_a6d9af0a83312252_fc535c4d1a274576 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eFuncValueObligations(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eFromTypeVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@olang_loc_fc32950df7c04da2_11eedb932326b4f6 = external constant [0 x i8]
@olang_loc_af9ca28b921c6ea3_fa663a0c518bad97 = external constant [0 x i8]
@olang_loc_357527e8194aec84_988fed079319ef80 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_66c1e4161a335875_1a8748292bb4d011 = external constant [0 x i8]
@olang_loc_2ebdbee26f736ebe_e8fbd5d45318ee7a = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaValueObligations(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaValueRelates(ptr %v0)
@olang_loc_3451003dd1e97df4_bcd12f7be62952d8 = external constant [0 x i8]
declare i64 @compiler_2fscope_2eflRoot(ptr %v0, ptr %a0)
declare i1 @compiler_2fscope_2eflThroughRef(ptr %v0, ptr %a0)
declare { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeHere(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elift(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_c4815f8d08aa5069_e0d3df7c014ad4fd = external constant [0 x i8]
@olang_loc_f2ff34bd09efe7b1_f9738b06cf9c6415 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_e2ea0fea769db7e4_aa8c1e0e7de89fc8 = external constant [0 x i8]
@olang_loc_4421e2d51127c851_53479ba5c20af2ad = external constant [0 x i8]
@olang_loc_ba8e38ed7d6b48a9_35acc5c55c21205 = external constant [0 x i8]
@olang_loc_d38420f770b56a25_293628bae4d10df9 = external constant [0 x i8]
@olang_loc_7d2ed71f654b640d_ba09ac545853f0c1 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_4d20f13e93e5e00_8edf44d94b0465ac = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_f39b1bd504b33948_8115a077853ab66c = external constant [0 x i8]
@olang_loc_707f747640e7de9_bc077dc74ca6c70d = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
@olang_loc_c0ef91a3e2c3a370_7d348321302c732c = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehandedRegion(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeStoresArg(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleePutsArg(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
@olang_loc_bf024f3f8d6f4701_89fcb258d807f5dd = external constant [0 x i8]
@olang_loc_791e790d87101aea_cc84b762fb4c0ac6 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehandleLent(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, ptr %a3)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeKeepsArg(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
@olang_loc_21c4adf4625d97ab_9350e01b86c380a7 = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_4f09217bbbe73e28_17ebc948c6ad3e44 = external constant [0 x i8]
declare %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H7e82b4dbdb79c77bc51fdaf9d4704834(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cI64_2c_20compiler_2ftyped_3aExpr_2_H4ea279ff901448a8d94a2f42aa119fd2(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_de693c9ff8852c0_d1c91c603b4bfa64 = external constant [0 x i8]
@olang_loc_42ddfa07d54a3511_7eb6b931dfed5aa5 = external constant [0 x i8]
@olang_loc_133169b3f1711469_c566838c26ef218d = external constant [0 x i8]
@olang_loc_31030507f1509b32_81bbcae78c23c7f6 = external constant [0 x i8]
@olang_loc_406ffa91c23643d5_a8a413026b137651 = external constant [0 x i8]
@olang_loc_a53dc1127e8f642e_8cd05a2a2a6c7d4a = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e_2eL_H5b8a0bc03aecb48440b685dbbc0b269c(ptr %v0, ptr %a0)
@olang_loc_ce604c7c8d78c55f_37d65431cab9ef4b = external constant [0 x i8]
declare %"compiler/typed:BlockInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e_2eA_Hdb91c1ab6f912bb6141763aa02d0b766(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_bfbb893df1c35f5d_ebb7b8931b043491 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estaticLiteral(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_13609328335a5af4_71f6842a5be0a9a0 = external constant [0 x i8]
@olang_loc_2a83bf20490fb4f0_b79be661c23cb1e4 = external constant [0 x i8]
@olang_loc_28967cbbf3bb5881_fc5c9419ee26cbd5 = external constant [0 x i8]
@olang_loc_e2b2a689ed5c2c6a_2e02b8bd326f399e = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eRoleCtor = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteThroughResult(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, i64 %a3, { i64, ptr } %a4, i64 %a5)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
@olang_loc_9f5a8ccf03b4db04_630c918a623736e8 = external constant [0 x i8]
@olang_loc_f8891e21139a6c8c_91dd882c9f718fa8 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewordAt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eindexCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeName(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@olang_loc_ae3c5a3c06bd23bd_8aa883e19e734e79 = external constant [0 x i8]
@olang_loc_a5d7ffc0375a2adf_b8092e4cba9985db = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteMakeWhere(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, %"compiler/msgs:Msg" %a4)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnsubst(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i32 %a3)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eYield(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@olang_loc_b5bb9adcdc2b0f40_ee4aa96e819ebaec = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDeclareWhere(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efloorOf(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare %"compiler/scope:rel" @compiler_2fscope_3arel_2ector(ptr %v0, { i64, [2 x i64] } %a0, { i64, [2 x i64] } %a1, i1 %a2, %"compiler/source:Span" %a3, i64 %a4)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eocExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i1 %a3)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2eLe_H7b92c806358c31ec0113c885295670e0(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2eAt_H163e317dccec3ace9fb31d96922af4c2(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fscope_2ewithin(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_40b97f37a7371750_40728193df6350fc = external constant [0 x i8]
@olang_loc_f651c1e1d8a1ace1_d593723da6a130ad = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elastName(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
@olang_loc_77d8df1bd6b52079_f0229fa895aca615 = external constant [0 x i8]
@olang_loc_bfd80b0298b19652_e537c33c4d886a6e = external constant [0 x i8]
@olang_loc_b1757fdcabe82f93_e12b45afd85e1a9f = external constant [0 x i8]
@olang_loc_a9000624b37114eb_4f5d8570083b5047 = external constant [0 x i8]
@olang_loc_6cb6018c48b7e44c_30fb4d691284a4b0 = external constant [0 x i8]
@olang_loc_50c5af6b9a55d13c_b172bff682b06040 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_74d9849f1cf072e4_d95edc215f7aa198 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_b99a325748da8cd5_4eb62b65b3c79869 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eadmitsStores(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evalueAdmits(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2ePayloadScopesDisagree(ptr %v0)
declare { i32, { i64, [2 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_H65b4b9a6d1679f5b3ddedaa5b2e336bd(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_a696eb2979219c3c_c9efb41471de78f8 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erunLength(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_7a4f424795892e70_52f604b9bdf9a7cc = external constant [0 x i8]
@olang_loc_da1486de58138450_28784370eb22bac = external constant [0 x i8]
@olang_loc_554265ba1528b3d8_d73d8ae267adc184 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisData(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_c484f993348186a9_88a471068962d75 = external constant [0 x i8]
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparamRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eopTok(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyToBuiltResultNo(ptr %v0)
@olang_loc_86025ef78c18fd61_51e54585f4e29a5d = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyToBuiltResult(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_ef7f9cdde83b319d_c7773e471ac0d6b1 = external constant [0 x i8]
@olang_loc_2a41cd82eb4d8236_be11ba524906eaaa = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisLambda(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_b810a17036e0b04c_ef2bb18623cc9e48 = external constant [0 x i8]
@olang_loc_9da86a51b48ec4c_4c8b634b3e5eba18 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aStmt_2eSpan(ptr %v0, ptr %a0)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elet(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eassign(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eret(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eforWrap(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2espawn(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
@olang_loc_e68fbdb964820230_ed59a3d360e211c = external constant [0 x i8]
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eregionParam(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_d10963641a9b1fed_5d8116c763841fe1 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eassignableHolds(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_fab9d5262c098304_b0d84a3f5fe3aa00 = external constant [0 x i8]
@olang_loc_678543b1c51fd044_bcff5a6e112a6af8 = external constant [0 x i8]
@olang_loc_a7efa27c057b5f35_b77d9a3a5db915c9 = external constant [0 x i8]
@olang_loc_a7a579971a154b67_66936e5e8b24a2eb = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efirstToken(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eStrStoresInReceiver(ptr %v0)
@olang_loc_4a5227c5c4b52748_edf443988575737c = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteStrBuildsHere(ptr %v0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ethroughDerivedExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ederivedRead(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_7f73b55f7a2eb5e4_273c44187eceff80 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i64 %a2)
@olang_loc_a99f843f7bf434a0_94e1f929e5b915f4 = external constant [0 x i8]
@olang_loc_4aed99841ab3b8b1_8d3edbdcac983025 = external constant [0 x i8]
@olang_loc_c7fdd76f48c1d89a_56d68a9de61a546e = external constant [0 x i8]
@olang_loc_480fa549fbef29b_cc88b49cbb5bf52f = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eocBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i1 %a3)
@olang_loc_3af8b11586f6b4c8_66242c1d15d5a764 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4)
declare { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elocalName(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i32 %a2, ptr %a3)
@olang_loc_33e8f6984fda8b38_987c5f6a5f702884 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eatCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fscope_2etempOf(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eSpan(ptr %v0, ptr %a0)
@olang_loc_dd80a499a713524_336e9d155656b240 = external constant [0 x i8]
@olang_loc_56e16192221ba415_394443c36fbf1ad1 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enameSpan(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2euses(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3)
@olang_loc_704f1e45d26fb2de_b63ff9ec5bfa803a = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnAtElement(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eWriteThroughAtCall(ptr %v0)
declare { i32, %"compiler/source:Span" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H7d5384a5030fc995e793b3fe1f57e776(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteViewRefusedBy(ptr %v0)
@olang_loc_8ccf378ebead7f5f_f5ae40f475d40cbb = external constant [0 x i8]
@olang_loc_df7e42d0d720f8e0_ba1485f60a37606c = external constant [0 x i8]
@olang_loc_29ab6d94cb2a37cc_d7a08cac8eb9a0a8 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eRunFrom_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_1bd0f6fdaea7b0c0_ba6d95304dde346c = external constant [0 x i8]
declare %"compiler/scope:Val" @compiler_2fscope_3aVal_2ector(ptr %v0, i32 %a0, { i64, [2 x i64] } %a1)
@olang_loc_e9d57cf77a66352c_e30832457df38478 = external constant [0 x i8]
@olang_loc_926310a74149af64_7456b8629edeed00 = external constant [0 x i8]
@olang_loc_d723be5f6d33c955_f64e13843779cd91 = external constant [0 x i8]
@olang_loc_30366b1ce1cb05a4_de371b7365ebcc00 = external constant [0 x i8]
@olang_loc_c76fb05b477ad754_aaa77e81edb6bb58 = external constant [0 x i8]
@olang_loc_472a8ee29a396e05_19ea125b0d0f8e29 = external constant [0 x i8]
declare void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/typed:Plan" @compiler_2ftyped_3aPlan_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
declare %"compiler/scope:walked" @compiler_2fscope_3awalked_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fscope_3aGap_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cmut_20compiler_2fscope_3asummary_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cBool_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fscope_3aTerm_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fscope_3arel_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2flist_3aList_3ccompiler_2fscope_3aTerm_3e_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fscope_3afnUse_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fsource_3aSpan_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
