; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/scope:Scoper" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { ptr, ptr }, { ptr, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, i64, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/typed:Plan", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [2 x i64] }, i1, i1, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [2 x i64] }, i1, %"compiler/source:Span", { i64, [2 x i64] }, i1, { i64, [2 x i64] }, i1, i1, i1, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [2 x i64] }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64, { i64, [2 x i64] }, i1, i1, i1, i64, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64, i64, i1, i32, i1, i1, i1, i1, i64, %"compiler/source:Span" }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/scope:rel" = type { { i64, [2 x i64] }, { i64, [2 x i64] }, i1, %"compiler/source:Span", i64 }
%"compiler/scope:agreeAt" = type { { i64, [2 x i64] }, i1 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1, i1 }
%"compiler/scope:Val" = type { i32, { i64, [2 x i64] } }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] }, i1 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i32, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/scope:summary" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Capture" = type { i32, ptr }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/scope:fnUse" = type { i64, %"compiler/source:Span", i64, i64, i32 }
%"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" = type { ptr, i64, ptr, ptr }
%"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" = type { i64, ptr }
%"compiler/typed:BlockInfo" = type { i32, i32, %"compiler/source:Span" }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1 }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"compiler/scope:walked" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
@G_2ecompiler_2fscope_2eFailsBlock = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eFailsUnknown = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eFitAnyCopy = constant <{ [8 x i8] }> <{ [8 x i8] c"\09\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eFitDecl = constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eFitElem = constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eFitField = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eFitGlobal = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eFitLocal = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eFitOwn = constant <{ [8 x i8] }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eFitPayload = constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eFitReturn = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eFitValue = constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eFnCall = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eFnLambda = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eFnNamed = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eHolds = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eObliged = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eUseThru = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eUseView = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eWhyField = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eWhyHolds = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eWhyResult = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
define dso_local void @compiler_2fscope_2ecollectPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t6 = load ptr, ptr %l9, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l9, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 8}
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l10, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t20, ptr %t22)
  br label %bb9
bb9:
  br label %bb44
bb10:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t26 = load ptr, ptr %l18, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb11, label %bb12
bb11:
  %t29 = load ptr, ptr %l18, !tbaa !29
  %t30 = load i64, ptr %t29, !range !{i64 0, i64 8}
  %t32 = icmp eq i64 %t30, 3
  store i1 %t32, ptr %l19, !tbaa !21
  br label %bb12
bb12:
  %t33 = load i1, ptr %l19, !tbaa !21
  br i1 %t33, label %bb13, label %bb14
bb13:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr { i64, [4 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t36, i32 0, i32 2
  %t38 = load ptr, ptr %t37
  store ptr %t38, ptr %l3, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectPlace(ptr %v0, ptr %v1, ptr %t40, ptr %t42)
  br label %bb16
bb16:
  br label %bb44
bb17:
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t46 = load ptr, ptr %l27, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb18, label %bb19
bb18:
  %t49 = load ptr, ptr %l27, !tbaa !29
  %t50 = load i64, ptr %t49, !range !{i64 0, i64 8}
  %t52 = icmp eq i64 %t50, 4
  store i1 %t52, ptr %l28, !tbaa !21
  br label %bb19
bb19:
  %t53 = load i1, ptr %l28, !tbaa !21
  br i1 %t53, label %bb20, label %bb21
bb20:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr { i64, [4 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t56, i32 0, i32 2
  %t58 = load ptr, ptr %t57
  store ptr %t58, ptr %l4, !tbaa !29
  br label %bb22
bb21:
  br label %bb25
bb22:
  %t60 = load ptr, ptr %l4, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Elem", ptr %t60, i32 0, i32 0
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectPlace(ptr %v0, ptr %v1, ptr %t63, ptr %t65)
  br label %bb23
bb23:
  %t68 = load ptr, ptr %l4, !tbaa !29
  %t70 = getelementptr %"compiler/typed:Elem", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t71, ptr %t73)
  br label %bb24
bb24:
  br label %bb44
bb25:
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t77 = load ptr, ptr %l41, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb26, label %bb27
bb26:
  %t80 = load ptr, ptr %l41, !tbaa !29
  %t81 = load i64, ptr %t80, !range !{i64 0, i64 8}
  %t83 = icmp eq i64 %t81, 5
  store i1 %t83, ptr %l42, !tbaa !21
  br label %bb27
bb27:
  %t84 = load i1, ptr %l42, !tbaa !21
  br i1 %t84, label %bb28, label %bb29
bb28:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr { i64, [4 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t87, i32 0, i32 2
  %t89 = load ptr, ptr %t88
  store ptr %t89, ptr %l5, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t91 = load ptr, ptr %l5, !tbaa !29
  %t93 = getelementptr %"compiler/typed:Payload", ptr %t91, i32 0, i32 0
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectPlace(ptr %v0, ptr %v1, ptr %t94, ptr %t96)
  br label %bb31
bb31:
  br label %bb44
bb32:
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t100 = load ptr, ptr %l51, !tbaa !29
  %t101 = icmp ne ptr %t100, null
  br i1 %t101, label %bb33, label %bb34
bb33:
  %t103 = load ptr, ptr %l51, !tbaa !29
  %t104 = load i64, ptr %t103, !range !{i64 0, i64 8}
  %t106 = icmp eq i64 %t104, 6
  store i1 %t106, ptr %l52, !tbaa !21
  br label %bb34
bb34:
  %t107 = load i1, ptr %l52, !tbaa !21
  br i1 %t107, label %bb35, label %bb36
bb35:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr { i64, [4 x i64] }, ptr %t108, i32 0, i32 1
  %t111 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t110, i32 0, i32 2
  %t112 = load ptr, ptr %t111
  store ptr %t112, ptr %l6, !tbaa !29
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t114 = load ptr, ptr %l6, !tbaa !29
  %t116 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t114, ptr %t116)
  br label %bb38
bb38:
  br label %bb44
bb39:
  br i1 true, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_61be1b0fda526a24_254af50801a17418)
  unreachable
bb44:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eCalleesOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %lp2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i1
  %l13 = alloca i64
  %l16 = alloca i64
  %l25 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l39 = alloca i64
  %l42 = alloca i64
  %l60 = alloca i64
  %l62 = alloca ptr
  %l66 = alloca i64
  %l69 = alloca i64
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = add i64 %t5, 1
  store i64 %t7, ptr %l13, !tbaa !24
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 12
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l16
  br label %bb3
bb3:
  %t13 = load i64, ptr %l13, !tbaa !24
  %t14 = load i64, ptr %l16, !tbaa !24
  %t15 = icmp sge i64 %t13, %t14
  store i1 %t15, ptr %l11, !tbaa !21
  br label %bb4
bb4:
  %t17 = load i1, ptr %l11, !tbaa !21
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t18 = icmp sge i64 0, 0
  br i1 %t18, label %bb7, label %bb8
bb6:
  br label %bb11
bb7:
  %t20 = icmp sle i64 0, 1152921504606846975
  br i1 %t20, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_43341c2c50c8e99b_9adf33b0078f612f)
  unreachable
bb9:
  %t22 = mul i64 0, 8
  %t23 = insertvalue { i64, ptr } undef, i64 0, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t24, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_43341c2c50c8e99b_9adf33b0078f612f)
  unreachable
bb11:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/scope:Scoper", ptr %t26, i32 0, i32 12
  %t29 = load i64, ptr %l1, !tbaa !24
  %t31 = add i64 %t29, 1
  %t34 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t28, i64 %t31)
  store i64 %t34, ptr %l25
  br label %bb12
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/scope:Scoper", ptr %t35, i32 0, i32 12
  %t38 = load i64, ptr %l1, !tbaa !24
  %t41 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t37, i64 %t38)
  store i64 %t41, ptr %l29
  br label %bb13
bb13:
  %t42 = load i64, ptr %l25, !tbaa !24
  %t43 = load i64, ptr %l29, !tbaa !24
  %t44 = sub i64 %t42, %t43
  store i64 %t44, ptr %l30, !tbaa !24
  %t45 = load i64, ptr %l30, !tbaa !24
  %t46 = icmp sge i64 %t45, 0
  br i1 %t46, label %bb14, label %bb15
bb14:
  %t48 = load i64, ptr %l30, !tbaa !24
  %t49 = icmp sle i64 %t48, 1152921504606846975
  br i1 %t49, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_f704225c3a4a2006_7f75d15fe5a9495a)
  unreachable
bb16:
  %t51 = load i64, ptr %l30, !tbaa !24
  %t52 = mul i64 %t51, 8
  %t53 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t52)
  %t54 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  %t56 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t56, ptr %lp2
  %t58 = load ptr, ptr %lp2
  store { i64, ptr } %t55, ptr %t58, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t59 = load ptr, ptr %lp2
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  store i64 %t62, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t64 = load i64, ptr %l4, !tbaa !24
  %t65 = load i64, ptr %l3, !tbaa !24
  %t68 = icmp sgt i64 %t64, %t65
  br i1 %t68, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_f704225c3a4a2006_7f75d15fe5a9495a)
  unreachable
bb18:
  %t70 = load i64, ptr %l5, !tbaa !24
  %t72 = icmp sgt i64 %t70, 0
  br i1 %t72, label %bb20, label %bb21
bb19:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb23
bb20:
  %t74 = load i64, ptr %l4, !tbaa !24
  %t75 = load i64, ptr %l3, !tbaa !24
  %t78 = sub i64 %t74, %t75
  %t79 = load i64, ptr %l5, !tbaa !24
  %t82 = add i64 %t78, %t79
  %t84 = sub i64 %t82, 1
  %t85 = load i64, ptr %l5, !tbaa !24
  %t88 = sdiv i64 %t84, %t85
  store i64 %t88, ptr %l42, !tbaa !24
  br label %bb22
bb21:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb22
bb22:
  %t90 = load i64, ptr %l42, !tbaa !24
  store i64 %t90, ptr %l39, !tbaa !24
  br label %bb23
bb23:
  %t91 = load i64, ptr %l39, !tbaa !24
  store i64 %t91, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb24
bb24:
  %t92 = load i64, ptr %l7, !tbaa !24
  %t93 = load i64, ptr %l6, !tbaa !24
  %t96 = icmp slt i64 %t92, %t93
  %t98 = xor i1 %t96, true
  br i1 %t98, label %bb25, label %bb26
bb25:
  br label %bb31
bb26:
  br label %bb27
bb27:
  %t100 = load i64, ptr %l3, !tbaa !24
  %t101 = load i64, ptr %l7, !tbaa !24
  %t102 = load i64, ptr %l5, !tbaa !24
  %t105 = mul i64 %t101, %t102
  %t108 = add i64 %t100, %t105
  store i64 %t108, ptr %l8, !tbaa !24
  %t110 = load i64, ptr %l8, !tbaa !24
  store i64 %t110, ptr %l60, !tbaa !24
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/scope:Scoper", ptr %t111, i32 0, i32 13
  store ptr %t113, ptr %l62, !tbaa !29
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/scope:Scoper", ptr %t114, i32 0, i32 12
  %t117 = load i64, ptr %l1, !tbaa !24
  %t120 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t116, i64 %t117)
  store i64 %t120, ptr %l66
  br label %bb28
bb28:
  %t121 = load i64, ptr %l8, !tbaa !24
  %t122 = load i64, ptr %l66, !tbaa !24
  %t124 = add i64 %t122, %t121
  %t125 = load ptr, ptr %l62, !tbaa !29
  %t127 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t125, i64 %t124)
  store i64 %t127, ptr %l69
  br label %bb29
bb29:
  %t128 = load i64, ptr %l69, !tbaa !24
  %t129 = load ptr, ptr %lp2
  %t130 = load i64, ptr %l60, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %t129, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr i64, ptr %t132, i64 %t130
  store i64 %t128, ptr %t133, !tbaa !34
  br label %bb30
bb30:
  %t134 = load i64, ptr %l7, !tbaa !24
  %t136 = add i64 %t134, 1
  store i64 %t136, ptr %l7, !tbaa !24
  br label %bb24
bb31:
  %t138 = load ptr, ptr %lp2
  %t139 = load { i64, ptr }, ptr %t138, !tbaa !27
  store { i64, ptr } %t139, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eaddRel(ptr %v0, ptr %a0, %"compiler/scope:rel" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/scope:rel"
  %l5 = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/scope:rel" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 35
  %t4 = load %"compiler/scope:rel", ptr %l1
  %t7 = call i1 @compiler_2fscope_2ehasRel(ptr %v0, ptr %t3, %"compiler/scope:rel" %t4)
  store i1 %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load i1, ptr %l5, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 35
  %t14 = load %"compiler/scope:rel", ptr %l1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2ePush_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t13, %"compiler/scope:rel" %t14)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eaddToSet(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l47 = alloca ptr
  %l48 = alloca ptr
  %l52 = alloca { i64, [2 x i64] }
  %l56 = alloca i64
  %l58 = alloca i64
  %l63 = alloca { i64, [2 x i64] }
  %l64 = alloca { i64, [2 x i64] }
  %l66 = alloca { i64, [2 x i64] }
  %l68 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, [2 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l2
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 5
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t7 = getelementptr { i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l3, !tbaa !24
  br label %bb3
bb2:
  br label %bb20
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/scope:Scoper", ptr %t10, i32 0, i32 36
  %t13 = load i64, ptr %l3, !tbaa !24
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t12, i64 %t13)
  store i64 %t16, ptr %l19
  br label %bb4
bb4:
  %t17 = load i64, ptr %l19, !tbaa !24
  store i64 %t17, ptr %l4, !tbaa !24
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esetEnd(ptr %v0, ptr %t18, i64 %t19)
  store i64 %t22, ptr %l22
  br label %bb5
bb5:
  %t23 = load i64, ptr %l22, !tbaa !24
  store i64 %t23, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l5, !tbaa !24
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = icmp sgt i64 %t24, %t25
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t30 = load i64, ptr %l6, !tbaa !24
  %t32 = icmp sgt i64 %t30, 0
  br i1 %t32, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb11
bb8:
  %t34 = load i64, ptr %l5, !tbaa !24
  %t35 = load i64, ptr %l4, !tbaa !24
  %t38 = sub i64 %t34, %t35
  %t39 = load i64, ptr %l6, !tbaa !24
  %t42 = add i64 %t38, %t39
  %t44 = sub i64 %t42, 1
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = sdiv i64 %t44, %t45
  store i64 %t48, ptr %l29, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb10
bb10:
  %t50 = load i64, ptr %l29, !tbaa !24
  store i64 %t50, ptr %l26, !tbaa !24
  br label %bb11
bb11:
  %t51 = load i64, ptr %l26, !tbaa !24
  store i64 %t51, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb12
bb12:
  %t52 = load i64, ptr %l8, !tbaa !24
  %t53 = load i64, ptr %l7, !tbaa !24
  %t56 = icmp slt i64 %t52, %t53
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb13, label %bb14
bb13:
  br label %bb19
bb14:
  br label %bb15
bb15:
  %t60 = load i64, ptr %l4, !tbaa !24
  %t61 = load i64, ptr %l8, !tbaa !24
  %t62 = load i64, ptr %l6, !tbaa !24
  %t65 = mul i64 %t61, %t62
  %t68 = add i64 %t60, %t65
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l47, !tbaa !29
  %t71 = load ptr, ptr %l1, !tbaa !29
  store ptr %t71, ptr %l48, !tbaa !29
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/scope:Scoper", ptr %t72, i32 0, i32 37
  %t78 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t74, i64 %t68)
  store { i64, [2 x i64] } %t78, ptr %l52
  br label %bb16
bb16:
  %t79 = load ptr, ptr %l47, !tbaa !29
  %t80 = load ptr, ptr %l48, !tbaa !29
  %t81 = load { i64, [2 x i64] }, ptr %l52
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eaddToSet(ptr %v0, ptr %v1, ptr %t79, ptr %t80, { i64, [2 x i64] } %t81)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t82 = load i64, ptr %l8, !tbaa !24
  %t84 = add i64 %t82, 1
  store i64 %t84, ptr %l8, !tbaa !24
  br label %bb12
bb19:
  br label %ret
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_ade2525ec560ecac_5eadaea182574e0)
  unreachable
bb25:
  %t86 = load ptr, ptr %l1, !tbaa !29
  store ptr %t86, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb26
bb26:
  %t88 = load i64, ptr %l11, !tbaa !24
  store i64 %t88, ptr %l56, !tbaa !24
  %t89 = load ptr, ptr %l10, !tbaa !29
  %t91 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %v1, ptr %t89)
  store i64 %t91, ptr %l58
  br label %bb27
bb27:
  %t92 = load i64, ptr %l56, !tbaa !24
  %t93 = load i64, ptr %l58, !tbaa !24
  %t94 = icmp slt i64 %t92, %t93
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb28, label %bb29
bb28:
  br label %bb37
bb29:
  br label %bb30
bb30:
  %t98 = load ptr, ptr %l10, !tbaa !29
  %t99 = load i64, ptr %l11, !tbaa !24
  %t102 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v1, ptr %t98, i64 %t99)
  store { i64, [2 x i64] } %t102, ptr %l63
  br label %bb31
bb31:
  %t103 = load { i64, [2 x i64] }, ptr %l63
  store { i64, [2 x i64] } %t103, ptr %l64
  %t105 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t105, ptr %l66
  %t108 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l64, ptr %l66)
  store i1 %t108, ptr %l68
  br label %bb32
bb32:
  %t109 = load i1, ptr %l68, !tbaa !21
  br i1 %t109, label %bb33, label %bb34
bb33:
  br label %ret
bb34:
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t110 = load i64, ptr %l11, !tbaa !24
  %t112 = add i64 %t110, 1
  store i64 %t112, ptr %l11, !tbaa !24
  br label %bb26
bb37:
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t115 = load { i64, [2 x i64] }, ptr %l2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ePush_3ccompiler_2fscope_3aTerm_3e(ptr %v1, ptr %t114, { i64, [2 x i64] } %t115)
  br label %bb38
bb38:
  br label %ret
ret:
  ret void
}

define dso_local { i32, %"compiler/scope:agreeAt" } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eagreeStep(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i1 %a2, { i64, [2 x i64] } %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i1
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i1
  %l10 = alloca %"compiler/scope:agreeAt"
  %l11 = alloca { i64, [2 x i64] }
  %l13 = alloca { i64, [2 x i64] }
  %l15 = alloca i1
  %l18 = alloca %"compiler/scope:agreeAt"
  %l23 = alloca i1
  %l27 = alloca i64
  %l32 = alloca %"compiler/scope:agreeAt"
  %l34 = alloca i1
  %l38 = alloca i64
  %l42 = alloca %"compiler/scope:agreeAt"
  %l45 = alloca i1
  %l51 = alloca i64
  %l55 = alloca %"compiler/scope:agreeAt"
  %l59 = alloca i64
  %l63 = alloca %"compiler/scope:agreeAt"
  %l64 = alloca i1
  %l67 = alloca i1
  %l75 = alloca %"compiler/scope:agreeAt"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/scope:agreeAt" }
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  store i1 %a2, ptr %l2
  store { i64, [2 x i64] } %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t6 = load { i64, [2 x i64] }, ptr %l3
  %t7 = load i1, ptr %l4, !tbaa !21
  %t10 = call %"compiler/scope:agreeAt" @compiler_2fscope_3aagreeAt_2ector(ptr %s1, { i64, [2 x i64] } %t6, i1 %t7)
  store %"compiler/scope:agreeAt" %t10, ptr %l10
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t11 = load %"compiler/scope:agreeAt", ptr %l10
  %t12 = insertvalue { i32, %"compiler/scope:agreeAt" } zeroinitializer, %"compiler/scope:agreeAt" %t11, 1
  store { i32, %"compiler/scope:agreeAt" } %t12, ptr %rv
  br label %ret
bb4:
  %t13 = load { i64, [2 x i64] }, ptr %l3
  store { i64, [2 x i64] } %t13, ptr %l11
  %t14 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t14, ptr %l13
  %t17 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l11, ptr %l13)
  store i1 %t17, ptr %l15
  br label %bb5
bb5:
  %t18 = load i1, ptr %l15, !tbaa !21
  br i1 %t18, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t19 = load { i64, [2 x i64] }, ptr %l1
  %t20 = load i1, ptr %l2, !tbaa !21
  %t23 = call %"compiler/scope:agreeAt" @compiler_2fscope_3aagreeAt_2ector(ptr %s2, { i64, [2 x i64] } %t19, i1 %t20)
  store %"compiler/scope:agreeAt" %t23, ptr %l18
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t24 = load %"compiler/scope:agreeAt", ptr %l18
  %t25 = insertvalue { i32, %"compiler/scope:agreeAt" } zeroinitializer, %"compiler/scope:agreeAt" %t24, 1
  store { i32, %"compiler/scope:agreeAt" } %t25, ptr %rv
  br label %ret
bb9:
  %t26 = load i1, ptr %l4, !tbaa !21
  %t27 = load i1, ptr %l2, !tbaa !21
  %t30 = icmp ne i1 %t26, %t27
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t32 = load i1, ptr %l2, !tbaa !21
  br i1 %t32, label %bb12, label %bb13
bb11:
  br label %bb28
bb12:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load { i64, [2 x i64] }, ptr %l3
  %t36 = load { i64, [2 x i64] }, ptr %l1
  %t40 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eorder(ptr %v0, ptr %t34, { i64, [2 x i64] } %t35, { i64, [2 x i64] } %t36)
  store i64 %t40, ptr %l27
  br label %bb14
bb13:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb15
bb14:
  %t41 = load i64, ptr @G_2ecompiler_2fscope_2eHolds, !tbaa !24
  %t42 = load i64, ptr %l27, !tbaa !24
  %t44 = icmp eq i64 %t42, %t41
  store i1 %t44, ptr %l23, !tbaa !21
  br label %bb15
bb15:
  %t46 = load i1, ptr %l23, !tbaa !21
  br i1 %t46, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  %t47 = load { i64, [2 x i64] }, ptr %l1
  %t48 = load i1, ptr %l2, !tbaa !21
  %t51 = call %"compiler/scope:agreeAt" @compiler_2fscope_3aagreeAt_2ector(ptr %s4, { i64, [2 x i64] } %t47, i1 %t48)
  store %"compiler/scope:agreeAt" %t51, ptr %l32
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t52 = load %"compiler/scope:agreeAt", ptr %l32
  %t53 = insertvalue { i32, %"compiler/scope:agreeAt" } zeroinitializer, %"compiler/scope:agreeAt" %t52, 1
  store { i32, %"compiler/scope:agreeAt" } %t53, ptr %rv
  br label %ret
bb19:
  %t54 = load i1, ptr %l4, !tbaa !21
  br i1 %t54, label %bb20, label %bb21
bb20:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load { i64, [2 x i64] }, ptr %l1
  %t58 = load { i64, [2 x i64] }, ptr %l3
  %t62 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eorder(ptr %v0, ptr %t56, { i64, [2 x i64] } %t57, { i64, [2 x i64] } %t58)
  store i64 %t62, ptr %l38
  br label %bb22
bb21:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb23
bb22:
  %t63 = load i64, ptr @G_2ecompiler_2fscope_2eHolds, !tbaa !24
  %t64 = load i64, ptr %l38, !tbaa !24
  %t66 = icmp eq i64 %t64, %t63
  store i1 %t66, ptr %l34, !tbaa !21
  br label %bb23
bb23:
  %t68 = load i1, ptr %l34, !tbaa !21
  br i1 %t68, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t69 = load { i64, [2 x i64] }, ptr %l3
  %t71 = call %"compiler/scope:agreeAt" @compiler_2fscope_3aagreeAt_2ector(ptr %s5, { i64, [2 x i64] } %t69, i1 true)
  store %"compiler/scope:agreeAt" %t71, ptr %l42
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t72 = load %"compiler/scope:agreeAt", ptr %l42
  %t73 = insertvalue { i32, %"compiler/scope:agreeAt" } zeroinitializer, %"compiler/scope:agreeAt" %t72, 1
  store { i32, %"compiler/scope:agreeAt" } %t73, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t74 = load i1, ptr %l2, !tbaa !21
  %t76 = xor i1 %t74, true
  br i1 %t76, label %bb29, label %bb30
bb29:
  %t78 = load i1, ptr %l4, !tbaa !21
  %t80 = xor i1 %t78, true
  store i1 %t80, ptr %l45, !tbaa !21
  br label %bb31
bb30:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb31
bb31:
  %t82 = load i1, ptr %l45, !tbaa !21
  br i1 %t82, label %bb32, label %bb33
bb32:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load { i64, [2 x i64] }, ptr %l1
  %t85 = load { i64, [2 x i64] }, ptr %l3
  %t89 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eorder(ptr %v0, ptr %t83, { i64, [2 x i64] } %t84, { i64, [2 x i64] } %t85)
  store i64 %t89, ptr %l51
  br label %bb34
bb33:
  br label %bb44
bb34:
  %t90 = load i64, ptr @G_2ecompiler_2fscope_2eHolds, !tbaa !24
  %t91 = load i64, ptr %l51, !tbaa !24
  %t93 = icmp eq i64 %t91, %t90
  br i1 %t93, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s7
  %t95 = load { i64, [2 x i64] }, ptr %l3
  %t97 = call %"compiler/scope:agreeAt" @compiler_2fscope_3aagreeAt_2ector(ptr %s7, { i64, [2 x i64] } %t95, i1 false)
  store %"compiler/scope:agreeAt" %t97, ptr %l55
  br label %bb37
bb36:
  br label %bb38
bb37:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t98 = load %"compiler/scope:agreeAt", ptr %l55
  %t99 = insertvalue { i32, %"compiler/scope:agreeAt" } zeroinitializer, %"compiler/scope:agreeAt" %t98, 1
  store { i32, %"compiler/scope:agreeAt" } %t99, ptr %rv
  br label %ret
bb38:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load { i64, [2 x i64] }, ptr %l3
  %t102 = load { i64, [2 x i64] }, ptr %l1
  %t106 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eorder(ptr %v0, ptr %t100, { i64, [2 x i64] } %t101, { i64, [2 x i64] } %t102)
  store i64 %t106, ptr %l59
  br label %bb39
bb39:
  %t107 = load i64, ptr @G_2ecompiler_2fscope_2eHolds, !tbaa !24
  %t108 = load i64, ptr %l59, !tbaa !24
  %t110 = icmp eq i64 %t108, %t107
  br i1 %t110, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s8
  %t112 = load { i64, [2 x i64] }, ptr %l1
  %t114 = call %"compiler/scope:agreeAt" @compiler_2fscope_3aagreeAt_2ector(ptr %s8, { i64, [2 x i64] } %t112, i1 false)
  store %"compiler/scope:agreeAt" %t114, ptr %l63
  br label %bb42
bb41:
  br label %bb43
bb42:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t115 = load %"compiler/scope:agreeAt", ptr %l63
  %t116 = insertvalue { i32, %"compiler/scope:agreeAt" } zeroinitializer, %"compiler/scope:agreeAt" %t115, 1
  store { i32, %"compiler/scope:agreeAt" } %t116, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  %t117 = load { i64, [2 x i64] }, ptr %l3
  %t119 = extractvalue { i64, [2 x i64] } %t117, 0
  %t120 = icmp eq i64 %t119, 2
  br i1 %t120, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb57
bb47:
  %t122 = load { i64, [2 x i64] }, ptr %l1
  %t124 = extractvalue { i64, [2 x i64] } %t122, 0
  %t125 = icmp eq i64 %t124, 2
  br i1 %t125, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb51
bb50:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb56
bb51:
  br i1 true, label %bb52, label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb55
bb54:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb56
bb55:
  call void @__olang_check_failed(ptr @olang_loc_75a473c9145829d0_168d550c974bebd4)
  unreachable
bb56:
  %t127 = load i1, ptr %l67, !tbaa !21
  store i1 %t127, ptr %l64, !tbaa !21
  br label %bb62
bb57:
  br i1 true, label %bb58, label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb61
bb60:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb62
bb61:
  call void @__olang_check_failed(ptr @olang_loc_2b3cb67345c2bf61_96483393ea0a8285)
  unreachable
bb62:
  %t128 = load i1, ptr %l64, !tbaa !21
  %t131 = xor i1 %t128, true
  br i1 %t131, label %bb63, label %bb64
bb63:
  call void @__olang_scope_close(ptr %s0)
  %t134 = insertvalue { i32, %"compiler/scope:agreeAt" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/scope:agreeAt" } %t134, ptr %rv
  br label %ret
bb64:
  br label %bb65
bb65:
  %t135 = load { i64, [2 x i64] }, ptr %l1
  %t136 = load i1, ptr %l2, !tbaa !21
  %t139 = call %"compiler/scope:agreeAt" @compiler_2fscope_3aagreeAt_2ector(ptr %s0, { i64, [2 x i64] } %t135, i1 %t136)
  store %"compiler/scope:agreeAt" %t139, ptr %l75
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s0)
  %t140 = load %"compiler/scope:agreeAt", ptr %l75
  %t141 = insertvalue { i32, %"compiler/scope:agreeAt" } zeroinitializer, %"compiler/scope:agreeAt" %t140, 1
  store { i32, %"compiler/scope:agreeAt" } %t141, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/scope:agreeAt" }, ptr %rv
  ret { i32, %"compiler/scope:agreeAt" } %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargLands(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l4 = alloca { i64, [2 x i64] }
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elandTerm(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
  store { i64, [2 x i64] } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, [2 x i64] }, ptr %l4
  %t8 = extractvalue { i64, [2 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 0
  %t11 = xor i1 %t9, true
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargOfVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l22 = alloca i32
  %l31 = alloca { i64, ptr }
  %l43 = alloca i64
  %l46 = alloca i64
  %l69 = alloca i64
  %l72 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, [2 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 -1, ptr %l3, !tbaa !24
  %t1 = load { i64, [2 x i64] }, ptr %l2
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 2
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t7 = getelementptr { i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t10 = load i64, ptr %l4, !tbaa !24
  store i64 %t10, ptr %l3, !tbaa !24
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb8:
  call void @__olang_check_failed(ptr @olang_loc_85776ac018629bcc_231804c012e3a7c0)
  unreachable
bb9:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t17 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %t13, ptr %t14)
  store i32 %t17, ptr %l22
  br label %bb10
bb10:
  %t18 = load i32, ptr %l22, !tbaa !23
  store i32 %t18, ptr %l5, !tbaa !23
  %t19 = load i32, ptr %l5, !tbaa !23
  %t20 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t23 = icmp eq i32 %t19, %t20
  br i1 %t23, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/scope:Scoper", ptr %t26, i32 0, i32 0
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 2
  %t32 = load i32, ptr %l5, !tbaa !23
  %t35 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t31, i32 %t32)
  store { i64, ptr } %t35, ptr %l31
  br label %bb14
bb14:
  %t36 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t36, ptr %l6, !tbaa !27
  %t37 = load i64, ptr %l3, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t43 = icmp sge i64 %t37, %t40
  br i1 %t43, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  store i64 0, ptr %l7, !tbaa !24
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr %"compiler/typed:Call", ptr %t46, i32 0, i32 1
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t49, 0
  store i64 %t51, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t53 = load i64, ptr %l8, !tbaa !24
  %t54 = load i64, ptr %l7, !tbaa !24
  %t57 = icmp sgt i64 %t53, %t54
  br i1 %t57, label %bb18, label %bb19
bb18:
  %t59 = load i64, ptr %l9, !tbaa !24
  %t61 = icmp sgt i64 %t59, 0
  br i1 %t61, label %bb20, label %bb21
bb19:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb23
bb20:
  %t63 = load i64, ptr %l8, !tbaa !24
  %t64 = load i64, ptr %l7, !tbaa !24
  %t67 = sub i64 %t63, %t64
  %t68 = load i64, ptr %l9, !tbaa !24
  %t71 = add i64 %t67, %t68
  %t73 = sub i64 %t71, 1
  %t74 = load i64, ptr %l9, !tbaa !24
  %t77 = sdiv i64 %t73, %t74
  store i64 %t77, ptr %l46, !tbaa !24
  br label %bb22
bb21:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb22
bb22:
  %t79 = load i64, ptr %l46, !tbaa !24
  store i64 %t79, ptr %l43, !tbaa !24
  br label %bb23
bb23:
  %t80 = load i64, ptr %l43, !tbaa !24
  store i64 %t80, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb24
bb24:
  %t81 = load i64, ptr %l11, !tbaa !24
  %t82 = load i64, ptr %l10, !tbaa !24
  %t85 = icmp slt i64 %t81, %t82
  %t87 = xor i1 %t85, true
  br i1 %t87, label %bb25, label %bb26
bb25:
  br label %bb36
bb26:
  br label %bb27
bb27:
  %t89 = load i64, ptr %l7, !tbaa !24
  %t90 = load i64, ptr %l11, !tbaa !24
  %t91 = load i64, ptr %l9, !tbaa !24
  %t94 = mul i64 %t90, %t91
  %t97 = add i64 %t89, %t94
  store i64 %t97, ptr %l12, !tbaa !24
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/scope:Scoper", ptr %t99, i32 0, i32 0
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = getelementptr %"compiler/generic:Program", ptr %t102, i32 0, i32 2
  %t105 = load i32, ptr %l5, !tbaa !23
  %t106 = load i64, ptr %l12, !tbaa !24
  %t110 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t104, i32 %t105, i64 %t106)
  store i64 %t110, ptr %l69
  br label %bb28
bb28:
  %t111 = load i64, ptr %l69, !tbaa !24
  store i64 %t111, ptr %l13, !tbaa !24
  %t112 = load i64, ptr %l13, !tbaa !24
  %t114 = icmp sge i64 %t112, 0
  br i1 %t114, label %bb29, label %bb30
bb29:
  %t116 = load i64, ptr %l13, !tbaa !24
  store i64 %t116, ptr %l72, !tbaa !24
  br label %bb31
bb30:
  %t118 = load i64, ptr %l12, !tbaa !24
  store i64 %t118, ptr %l72, !tbaa !24
  br label %bb31
bb31:
  %t120 = load i64, ptr %l72, !tbaa !24
  %t122 = load i64, ptr %l3, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr i64, ptr %t125, i64 %t122
  %t127 = load i64, ptr %t126, !tbaa !34
  %t130 = icmp eq i64 %t120, %t127
  br i1 %t130, label %bb32, label %bb33
bb32:
  %t132 = load i64, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t132, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t134 = load i64, ptr %l11, !tbaa !24
  %t136 = add i64 %t134, 1
  store i64 %t136, ptr %l11, !tbaa !24
  br label %bb24
bb36:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargRec(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l14 = alloca ptr
  %l18 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l26 = alloca ptr
  %l27 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l40 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t7 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %t2, ptr %a1)
  store ptr %t7, ptr %l9
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l5, !tbaa !29
  %t9 = load ptr, ptr %l9, !tbaa !29
  %t10 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunPromoted(ptr %v0, ptr %v1, ptr %t8, ptr %t9)
  store ptr %t10, ptr %l10
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l10, !tbaa !29
  store ptr %t11, ptr %l2, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t17 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallOf(ptr %v0, ptr %v1, ptr %t12, ptr %t13)
  store ptr %t17, ptr %l14
  br label %bb3
bb3:
  %t18 = load ptr, ptr %l14, !tbaa !29
  store ptr %t18, ptr %l3, !tbaa !29
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t21 = icmp eq ptr %t19, null
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb4, label %bb5
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/scope:Scoper", ptr %t25, i32 0, i32 46
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Call", ptr %t28, i32 0, i32 3
  %t31 = load i32, ptr %t30, !tbaa !23
  %t33 = sext i32 %t31 to i64
  %t36 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t27, i64 %t33)
  %t37 = extractvalue { i32, i64 } %t36, 1
  %t38 = extractvalue { i32, i64 } %t36, 0
  store i32 %t38, ptr %l25
  %t39 = icmp ne i32 %t38, 0
  br i1 %t39, label %bb7, label %ok.40, !prof !99
ok.40:
  store i64 %t37, ptr %l24
  br label %bb6
bb5:
  br label %bb10
bb6:
  %t41 = load i64, ptr %l24, !tbaa !24
  store i64 %t41, ptr %l18, !tbaa !24
  br label %bb9
bb7:
  br label %bb8
bb8:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l18, !tbaa !24
  br label %bb9
bb9:
  %t42 = load i64, ptr %l18, !tbaa !24
  store i64 %t42, ptr %rv
  br label %ret
bb10:
  %t43 = load ptr, ptr %l2, !tbaa !29
  store ptr %t43, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t44 = load ptr, ptr %l26, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb11, label %bb12
bb11:
  %t47 = load ptr, ptr %l26, !tbaa !29
  %t48 = load i64, ptr %t47, !range !{i64 0, i64 18}
  %t50 = icmp eq i64 %t48, 2
  store i1 %t50, ptr %l27, !tbaa !21
  br label %bb12
bb12:
  %t51 = load i1, ptr %l27, !tbaa !21
  br i1 %t51, label %bb13, label %bb14
bb13:
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t54 = getelementptr { i64, [5 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t54, i32 0, i32 2
  %t56 = load ptr, ptr %t55
  store ptr %t56, ptr %l4, !tbaa !29
  br label %bb19
bb14:
  %t58 = load ptr, ptr %l2, !tbaa !29
  store ptr %t58, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t59 = load ptr, ptr %l32, !tbaa !29
  %t60 = icmp ne ptr %t59, null
  br i1 %t60, label %bb15, label %bb16
bb15:
  %t62 = load ptr, ptr %l32, !tbaa !29
  %t63 = load i64, ptr %t62, !range !{i64 0, i64 18}
  %t65 = icmp eq i64 %t63, 3
  store i1 %t65, ptr %l33, !tbaa !21
  br label %bb16
bb16:
  %t66 = load i1, ptr %l33, !tbaa !21
  br i1 %t66, label %bb17, label %bb18
bb17:
  %t67 = load ptr, ptr %l2, !tbaa !29
  %t69 = getelementptr { i64, [5 x i64] }, ptr %t67, i32 0, i32 1
  %t70 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t69, i32 0, i32 2
  %t71 = load ptr, ptr %t70
  store ptr %t71, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load ptr, ptr %l4, !tbaa !29
  %t77 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erecOf(ptr %v0, ptr %v1, ptr %t73, ptr %t74)
  store i64 %t77, ptr %l40
  br label %bb20
bb20:
  %t78 = load i64, ptr %l40, !tbaa !24
  store i64 %t78, ptr %rv
  br label %ret
bb21:
  br i1 true, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  store i64 -1, ptr %rv
  br label %ret
bb25:
  call void @__olang_check_failed(ptr @olang_loc_2489ab739aea8b00_863e154a28bdb8e4)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2earm(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca %"compiler/scope:Val"
  %l13 = alloca i64
  %l14 = alloca %"compiler/scope:Val"
  %l17 = alloca %"compiler/scope:Val"
  %l18 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca { i64, ptr }
  %l35 = alloca %"compiler/scope:Val"
  %l44 = alloca { i64, ptr }
  %l52 = alloca %"compiler/scope:Val"
  %l57 = alloca ptr
  %l58 = alloca i64
  %l59 = alloca ptr
  %l68 = alloca %"compiler/typed:Local"
  %l70 = alloca { i64, [2 x i64] }
  %l73 = alloca i1
  %l74 = alloca i1
  %l78 = alloca { i64, [2 x i64] }
  %l80 = alloca { i64, [2 x i64] }
  %l82 = alloca i1
  %l84 = alloca i1
  %l88 = alloca { i64, [2 x i64] }
  %l92 = alloca i1
  %l97 = alloca ptr
  %l98 = alloca i64
  %l99 = alloca ptr
  %l103 = alloca { i64, [2 x i64] }
  %l105 = alloca { i64, [2 x i64] }
  %l108 = alloca i1
  %l124 = alloca %"compiler/scope:Val"
  %l125 = alloca %"compiler/scope:Val"
  %l131 = alloca ptr
  %l139 = alloca ptr
  %l151 = alloca %"compiler/scope:Val"
  %l152 = alloca i32
  %l155 = alloca i32
  %l156 = alloca i32
  %l161 = alloca %"compiler/scope:Val"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/scope:Val"
  %t40 = alloca { i64, [2 x i64] }, align 8
  %t78 = alloca { i64, [2 x i64] }, align 8
  %t222 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, [2 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call %"compiler/scope:Val" @compiler_2fscope_2eplain()
  store %"compiler/scope:Val" %t5, ptr %l17
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t6 = load %"compiler/scope:Val", ptr %l17
  store %"compiler/scope:Val" %t6, ptr %rv
  br label %ret
bb4:
  %t7 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l18
  br label %bb5
bb5:
  %t8 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l18
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l3
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Arm", ptr %t9, i32 0, i32 1
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  store { i64, ptr } %t12, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  store i64 %t16, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  %t18 = load i64, ptr %l5, !tbaa !24
  %t19 = load i64, ptr %l6, !tbaa !24
  %t22 = icmp slt i64 %t18, %t19
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb7, label %bb8
bb7:
  br label %bb50
bb8:
  br label %bb9
bb9:
  %t26 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t26, ptr %l27, !tbaa !27
  %t27 = load i64, ptr %l5, !tbaa !24
  %t29 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr ptr, ptr %t30, i64 %t27
  %t32 = load ptr, ptr %t31, !tbaa !39
  store ptr %t32, ptr %l7, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load ptr, ptr %l7, !tbaa !29
  %t37 = getelementptr %"compiler/typed:Alt", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t40
  %t41 = getelementptr { i64, [2 x i64] }, ptr %t40, i32 0, i32 0
  store i64 0, ptr %t41
  %t42 = load { i64, [2 x i64] }, ptr %t40
  %t46 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t34, ptr %t38, { i64, [2 x i64] } %t42)
  store %"compiler/scope:Val" %t46, ptr %l35
  br label %bb10
bb10:
  %t47 = load ptr, ptr %l7, !tbaa !29
  %t49 = getelementptr %"compiler/typed:Alt", ptr %t47, i32 0, i32 1
  %t50 = load { i64, ptr }, ptr %t49, !tbaa !27
  store { i64, ptr } %t50, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t52 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t52, 0
  store i64 %t54, ptr %l10, !tbaa !24
  br label %bb11
bb11:
  %t56 = load i64, ptr %l9, !tbaa !24
  %t57 = load i64, ptr %l10, !tbaa !24
  %t60 = icmp slt i64 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb12, label %bb13
bb12:
  br label %bb48
bb13:
  br label %bb14
bb14:
  %t64 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t64, ptr %l44, !tbaa !27
  %t65 = load i64, ptr %l9, !tbaa !24
  %t67 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr ptr, ptr %t68, i64 %t65
  %t70 = load ptr, ptr %t69, !tbaa !39
  store ptr %t70, ptr %l11, !tbaa !29
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load ptr, ptr %l11, !tbaa !29
  %t75 = getelementptr %"compiler/typed:Bind", ptr %t73, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t78
  %t79 = getelementptr { i64, [2 x i64] }, ptr %t78, i32 0, i32 0
  store i64 0, ptr %t79
  %t80 = load { i64, [2 x i64] }, ptr %t78
  %t84 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t72, ptr %t76, { i64, [2 x i64] } %t80)
  store %"compiler/scope:Val" %t84, ptr %l52
  br label %bb15
bb15:
  %t85 = load %"compiler/scope:Val", ptr %l52
  store %"compiler/scope:Val" %t85, ptr %l12
  %t86 = load ptr, ptr %l11, !tbaa !29
  %t88 = getelementptr %"compiler/typed:Bind", ptr %t86, i32 0, i32 0
  %t89 = load i32, ptr %t88, !tbaa !23
  %t91 = sext i32 %t89 to i64
  store i64 %t91, ptr %l13, !tbaa !24
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/scope:Scoper", ptr %t93, i32 0, i32 32
  store ptr %t95, ptr %l57, !tbaa !29
  %t96 = load i64, ptr %l13, !tbaa !24
  store i64 %t96, ptr %l58, !tbaa !24
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l59, !tbaa !29
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/scope:Scoper", ptr %t98, i32 0, i32 25
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = icmp eq ptr %t101, null
  br i1 %t103, label %bb16, label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_76dd643541c5999_442dc791771fad)
  unreachable
bb17:
  br label %bb18
bb18:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/scope:Scoper", ptr %t105, i32 0, i32 25
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t111 = getelementptr %"compiler/typed:Body", ptr %t108, i32 0, i32 7
  %t112 = load i64, ptr %l13, !tbaa !24
  %t115 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t111, i64 %t112)
  store %"compiler/typed:Local" %t115, ptr %l68
  br label %bb19
bb19:
  %t116 = getelementptr %"compiler/typed:Local", ptr %l68, i32 0, i32 3
  %t117 = load i32, ptr %t116, !tbaa !23
  %t118 = load ptr, ptr %l59, !tbaa !29
  %t120 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblockTerm(ptr %v0, ptr %t118, i32 %t117)
  store { i64, [2 x i64] } %t120, ptr %l70
  br label %bb20
bb20:
  %t121 = load ptr, ptr %l57, !tbaa !29
  %t122 = load i64, ptr %l58, !tbaa !24
  %t123 = load { i64, [2 x i64] }, ptr %l70
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t121, i64 %t122, { i64, [2 x i64] } %t123)
  br label %bb21
bb21:
  %t124 = load i64, ptr %l13, !tbaa !24
  %t127 = call i1 @compiler_2fscope_2eflHas(ptr %s0, ptr %l3, i64 %t124)
  store i1 %t127, ptr %l73
  br label %bb22
bb22:
  %t128 = load i1, ptr %l73, !tbaa !21
  br i1 %t128, label %bb23, label %bb24
bb23:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/scope:Scoper", ptr %t129, i32 0, i32 31
  %t132 = load i64, ptr %l13, !tbaa !24
  %t135 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t131, i64 %t132)
  store { i64, [2 x i64] } %t135, ptr %l78
  br label %bb25
bb24:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb27
bb25:
  %t136 = getelementptr %"compiler/scope:Val", ptr %l12, i32 0, i32 1
  %t137 = load { i64, [2 x i64] }, ptr %t136
  store { i64, [2 x i64] } %t137, ptr %l80
  %t140 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l78, ptr %l80)
  store i1 %t140, ptr %l82
  br label %bb26
bb26:
  %t141 = load i1, ptr %l82, !tbaa !21
  %t142 = xor i1 %t141, true
  store i1 %t142, ptr %l74, !tbaa !21
  br label %bb27
bb27:
  %t144 = load i1, ptr %l74, !tbaa !21
  br i1 %t144, label %bb28, label %bb29
bb28:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/scope:Scoper", ptr %t145, i32 0, i32 31
  %t148 = load i64, ptr %l13, !tbaa !24
  %t151 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t147, i64 %t148)
  store { i64, [2 x i64] } %t151, ptr %l88
  br label %bb30
bb29:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb31
bb30:
  %t152 = load { i64, [2 x i64] }, ptr %l88
  %t154 = extractvalue { i64, [2 x i64] } %t152, 0
  %t155 = icmp eq i64 %t154, 0
  %t157 = xor i1 %t155, true
  store i1 %t157, ptr %l84, !tbaa !21
  br label %bb31
bb31:
  %t159 = load i1, ptr %l84, !tbaa !21
  br i1 %t159, label %bb32, label %bb33
bb32:
  %t160 = getelementptr %"compiler/scope:Val", ptr %l12, i32 0, i32 1
  %t161 = load { i64, [2 x i64] }, ptr %t160
  %t163 = extractvalue { i64, [2 x i64] } %t161, 0
  %t164 = icmp eq i64 %t163, 0
  %t166 = xor i1 %t164, true
  store i1 %t166, ptr %l92, !tbaa !21
  br label %bb34
bb33:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb34
bb34:
  %t168 = load i1, ptr %l92, !tbaa !21
  br i1 %t168, label %bb35, label %bb36
bb35:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/scope:Scoper", ptr %t169, i32 0, i32 31
  store ptr %t171, ptr %l97, !tbaa !29
  %t172 = load i64, ptr %l13, !tbaa !24
  store i64 %t172, ptr %l98, !tbaa !24
  %t173 = load ptr, ptr %l0, !tbaa !29
  store ptr %t173, ptr %l99, !tbaa !29
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/scope:Scoper", ptr %t174, i32 0, i32 31
  %t177 = load i64, ptr %l13, !tbaa !24
  %t180 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t176, i64 %t177)
  store { i64, [2 x i64] } %t180, ptr %l103
  br label %bb37
bb36:
  %t181 = load i64, ptr %l13, !tbaa !24
  %t184 = call i1 @compiler_2fscope_2eflHas(ptr %s0, ptr %l3, i64 %t181)
  store i1 %t184, ptr %l108
  br label %bb40
bb37:
  %t185 = getelementptr %"compiler/scope:Val", ptr %l12, i32 0, i32 1
  %t186 = load { i64, [2 x i64] }, ptr %t185
  %t187 = load ptr, ptr %l99, !tbaa !29
  %t188 = load { i64, [2 x i64] }, ptr %l103
  %t190 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esetOf(ptr %v0, ptr %t187, { i64, [2 x i64] } %t188, { i64, [2 x i64] } %t186)
  store { i64, [2 x i64] } %t190, ptr %l105
  br label %bb38
bb38:
  %t191 = load ptr, ptr %l97, !tbaa !29
  %t192 = load i64, ptr %l98, !tbaa !24
  %t193 = load { i64, [2 x i64] }, ptr %l105
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t191, i64 %t192, { i64, [2 x i64] } %t193)
  br label %bb39
bb39:
  br label %bb46
bb40:
  %t194 = load i1, ptr %l108, !tbaa !21
  %t195 = xor i1 %t194, true
  br i1 %t195, label %bb41, label %bb42
bb41:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/scope:Scoper", ptr %t197, i32 0, i32 31
  %t200 = load i64, ptr %l13, !tbaa !24
  %t201 = getelementptr %"compiler/scope:Val", ptr %l12, i32 0, i32 1
  %t202 = load { i64, [2 x i64] }, ptr %t201
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t199, i64 %t200, { i64, [2 x i64] } %t202)
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t206 = load i64, ptr %l13, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t206)
  br label %bb44
bb44:
  br label %bb45
bb45:
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t209 = load i64, ptr %l9, !tbaa !24
  %t211 = add i64 %t209, 1
  store i64 %t211, ptr %l9, !tbaa !24
  br label %bb11
bb48:
  br label %bb49
bb49:
  %t213 = load i64, ptr %l5, !tbaa !24
  %t215 = add i64 %t213, 1
  store i64 %t215, ptr %l5, !tbaa !24
  br label %bb6
bb50:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = getelementptr %"compiler/typed:Arm", ptr %t218, i32 0, i32 2
  %t221 = load ptr, ptr %t220, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t222
  %t223 = getelementptr { i64, [2 x i64] }, ptr %t222, i32 0, i32 0
  store i64 0, ptr %t223
  %t224 = load { i64, [2 x i64] }, ptr %t222
  %t228 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t217, ptr %t221, { i64, [2 x i64] } %t224)
  store %"compiler/scope:Val" %t228, ptr %l124
  br label %bb51
bb51:
  %t229 = call %"compiler/scope:Val" @compiler_2fscope_2eplain()
  store %"compiler/scope:Val" %t229, ptr %l125
  br label %bb52
bb52:
  %t230 = load %"compiler/scope:Val", ptr %l125
  store %"compiler/scope:Val" %t230, ptr %l14
  %t231 = load ptr, ptr %l1, !tbaa !29
  %t233 = getelementptr %"compiler/typed:Arm", ptr %t231, i32 0, i32 3
  %t234 = load ptr, ptr %t233, !tbaa !29
  %t236 = icmp eq ptr %t234, null
  %t238 = xor i1 %t236, true
  br i1 %t238, label %bb53, label %bb54
bb53:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = getelementptr %"compiler/scope:Scoper", ptr %t240, i32 0, i32 34
  store ptr %t242, ptr %l131, !tbaa !29
  %t243 = load ptr, ptr %l1, !tbaa !29
  %t245 = getelementptr %"compiler/typed:Arm", ptr %t243, i32 0, i32 3
  %t246 = load ptr, ptr %t245, !tbaa !29
  %t248 = icmp eq ptr %t246, null
  br i1 %t248, label %bb55, label %bb56
bb54:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load ptr, ptr %l1, !tbaa !29
  %t253 = getelementptr %"compiler/typed:Arm", ptr %t251, i32 0, i32 4
  %t254 = load ptr, ptr %t253, !tbaa !29
  %t255 = load { i64, [2 x i64] }, ptr %l2
  %t259 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t250, ptr %t254, { i64, [2 x i64] } %t255)
  store %"compiler/scope:Val" %t259, ptr %l161
  br label %bb68
bb55:
  call void @__olang_check_failed(ptr @olang_loc_a61f6227542ac272_aba93d64b04206c6)
  unreachable
bb56:
  br label %bb57
bb57:
  %t260 = load ptr, ptr %l1, !tbaa !29
  %t262 = getelementptr %"compiler/typed:Arm", ptr %t260, i32 0, i32 3
  %t263 = load ptr, ptr %t262, !tbaa !29
  %t266 = getelementptr %"compiler/typed:Block", ptr %t263, i32 0, i32 0
  %t267 = load i32, ptr %t266, !tbaa !23
  %t268 = load ptr, ptr %l131, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t268, i32 %t267)
  br label %bb58
bb58:
  %t270 = load ptr, ptr %l0, !tbaa !29
  store ptr %t270, ptr %l139, !tbaa !29
  %t271 = load ptr, ptr %l1, !tbaa !29
  %t273 = getelementptr %"compiler/typed:Arm", ptr %t271, i32 0, i32 3
  %t274 = load ptr, ptr %t273, !tbaa !29
  %t276 = icmp eq ptr %t274, null
  br i1 %t276, label %bb59, label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_f34ecaa27a4fd2b3_7961e1dcca83cdb7)
  unreachable
bb60:
  br label %bb61
bb61:
  %t278 = load ptr, ptr %l1, !tbaa !29
  %t280 = getelementptr %"compiler/typed:Arm", ptr %t278, i32 0, i32 3
  %t281 = load ptr, ptr %t280, !tbaa !29
  %t284 = getelementptr %"compiler/typed:Block", ptr %t281, i32 0, i32 1
  %t285 = load { i64, ptr }, ptr %t284, !tbaa !27
  %t286 = load ptr, ptr %l139, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estmts(ptr %v0, ptr %v1, ptr %t286, { i64, ptr } %t285)
  br label %bb62
bb62:
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t289 = load ptr, ptr %l1, !tbaa !29
  %t291 = getelementptr %"compiler/typed:Arm", ptr %t289, i32 0, i32 4
  %t292 = load ptr, ptr %t291, !tbaa !29
  %t293 = load { i64, [2 x i64] }, ptr %l2
  %t297 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t288, ptr %t292, { i64, [2 x i64] } %t293)
  store %"compiler/scope:Val" %t297, ptr %l151
  br label %bb63
bb63:
  %t298 = load %"compiler/scope:Val", ptr %l151
  store %"compiler/scope:Val" %t298, ptr %l14
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t301 = getelementptr %"compiler/scope:Scoper", ptr %t299, i32 0, i32 34
  %t303 = call { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePop_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t301)
  %t304 = extractvalue { i32, i32 } %t303, 1
  %t305 = extractvalue { i32, i32 } %t303, 0
  store i32 %t305, ptr %l156
  %t306 = icmp ne i32 %t305, 0
  br i1 %t306, label %bb65, label %ok.307, !prof !99
ok.307:
  store i32 %t304, ptr %l155
  br label %bb64
bb64:
  %t308 = load i32, ptr %l155, !tbaa !23
  store i32 %t308, ptr %l152, !tbaa !23
  br label %bb67
bb65:
  br label %bb66
bb66:
  call void @__olang_ert_req_clear()
  br label %bb67
bb67:
  br label %bb69
bb68:
  %t309 = load %"compiler/scope:Val", ptr %l161
  store %"compiler/scope:Val" %t309, ptr %l14
  br label %bb69
bb69:
  %t310 = load %"compiler/scope:Val", ptr %l14
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/scope:Val" %t310, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scope:Val", ptr %rv
  ret %"compiler/scope:Val" %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebindLocal(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l8 = alloca ptr
  %l18 = alloca %"compiler/typed:Local"
  %l23 = alloca i1
  %l27 = alloca i1
  %l34 = alloca i1
  %l47 = alloca i1
  %l53 = alloca i1
  %l58 = alloca i1
  %l59 = alloca i1
  %l64 = alloca i1
  %l66 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l71 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l72 = alloca i32
  %l74 = alloca ptr
  %l76 = alloca i64
  %l79 = alloca i64
  %l81 = alloca i64
  %l83 = alloca i64
  %l88 = alloca { i64, [2 x i64] }
  %l96 = alloca ptr
  %l99 = alloca ptr
  %l101 = alloca ptr
  %l104 = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 25
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_b442aabc3e151319_4a7d8af854ba830d)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 25
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 7
  %t15 = load i32, ptr %l1, !tbaa !23
  %t17 = sext i32 %t15 to i64
  %t20 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t14, i64 %t17)
  store %"compiler/typed:Local" %t20, ptr %l18
  br label %bb4
bb4:
  %t21 = getelementptr %"compiler/typed:Local", ptr %l18, i32 0, i32 4
  %t22 = load i32, ptr %t21, !range !{i32 0, i32 7}
  store i32 %t22, ptr %l3
  %t24 = load i32, ptr %l3, !range !{i32 0, i32 7}
  %t26 = trunc i64 1 to i32
  %t27 = icmp eq i32 %t24, %t26
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb5, label %bb6
bb5:
  %t31 = load i32, ptr %l3, !range !{i32 0, i32 7}
  %t33 = trunc i64 3 to i32
  %t34 = icmp eq i32 %t31, %t33
  %t36 = xor i1 %t34, true
  store i1 %t36, ptr %l23, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb7
bb7:
  %t38 = load i1, ptr %l23, !tbaa !21
  br i1 %t38, label %bb8, label %bb9
bb8:
  %t39 = load i32, ptr %l3, !range !{i32 0, i32 7}
  %t41 = trunc i64 6 to i32
  %t42 = icmp eq i32 %t39, %t41
  %t44 = xor i1 %t42, true
  store i1 %t44, ptr %l27, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb10
bb10:
  %t46 = load i1, ptr %l27, !tbaa !21
  br i1 %t46, label %bb11, label %bb12
bb11:
  br label %ret
bb12:
  br label %bb13
bb13:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i32, ptr %l1, !tbaa !23
  %t50 = sext i32 %t48 to i64
  %t53 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ereassigned(ptr %v0, ptr %t47, i64 %t50)
  store i1 %t53, ptr %l34
  br label %bb14
bb14:
  %t54 = load i1, ptr %l34, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i32, ptr %l1, !tbaa !23
  %t58 = sext i32 %t56 to i64
  %t59 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteLate(ptr %v0, ptr %v1, ptr %t55, i64 %t58, ptr %t59)
  br label %bb17
bb16:
  br label %bb52
bb17:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/scope:Scoper", ptr %t63, i32 0, i32 49
  %t66 = load i1, ptr %t65, !tbaa !21
  br i1 %t66, label %bb18, label %bb19
bb18:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/scope:Scoper", ptr %t68, i32 0, i32 52
  %t71 = load i32, ptr %l1, !tbaa !23
  %t73 = sext i32 %t71 to i64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t70, i64 %t73, i1 true)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/scope:Scoper", ptr %t76, i32 0, i32 49
  %t79 = load i1, ptr %t78, !tbaa !21
  br i1 %t79, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb24
bb23:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/scope:Scoper", ptr %t81, i32 0, i32 48
  %t84 = load i64, ptr %t83, !tbaa !24
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/scope:Scoper", ptr %t85, i32 0, i32 26
  %t88 = load i64, ptr %t87, !tbaa !24
  %t91 = icmp ne i64 %t84, %t88
  store i1 %t91, ptr %l47, !tbaa !21
  br label %bb24
bb24:
  %t93 = load i1, ptr %l47, !tbaa !21
  br i1 %t93, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb28
bb26:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/scope:Scoper", ptr %t94, i32 0, i32 51
  %t97 = load i32, ptr %l1, !tbaa !23
  %t99 = sext i32 %t97 to i64
  %t102 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t96, i64 %t99)
  store i1 %t102, ptr %l58
  br label %bb27
bb27:
  %t103 = load i1, ptr %l58, !tbaa !21
  store i1 %t103, ptr %l53, !tbaa !21
  br label %bb28
bb28:
  %t104 = load i1, ptr %l53, !tbaa !21
  br i1 %t104, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l59, !tbaa !21
  br label %bb32
bb30:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/scope:Scoper", ptr %t105, i32 0, i32 52
  %t108 = load i32, ptr %l1, !tbaa !23
  %t110 = sext i32 %t108 to i64
  %t113 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t107, i64 %t110)
  store i1 %t113, ptr %l64
  br label %bb31
bb31:
  %t114 = load i1, ptr %l64, !tbaa !21
  %t115 = xor i1 %t114, true
  store i1 %t115, ptr %l59, !tbaa !21
  br label %bb32
bb32:
  %t117 = load i1, ptr %l59, !tbaa !21
  br i1 %t117, label %bb33, label %bb34
bb33:
  br label %ret
bb34:
  br label %bb35
bb35:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/scope:Scoper", ptr %t118, i32 0, i32 50
  %t121 = load i32, ptr %l1, !tbaa !23
  %t123 = sext i32 %t121 to i64
  %t126 = call { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hb676fcc2696545b94a8186e92757a5eb(ptr %v0, ptr %v0, ptr %t120, i64 %t123)
  %t127 = extractvalue { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %t126, 1
  %t128 = extractvalue { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %t126, 0
  store i32 %t128, ptr %l72
  %t129 = icmp ne i32 %t128, 0
  br i1 %t129, label %bb37, label %ok.130, !prof !99
ok.130:
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t127, ptr %l71
  br label %bb36
bb36:
  %t131 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l71
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t131, ptr %l66
  br label %bb39
bb37:
  br label %bb38
bb38:
  call void @__olang_ert_req_clear()
  br label %ret
bb39:
  %t132 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l66
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t132, ptr %l4
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/scope:Scoper", ptr %t133, i32 0, i32 43
  store ptr %t135, ptr %l74, !tbaa !29
  %t136 = load i32, ptr %l1, !tbaa !23
  %t138 = sext i32 %t136 to i64
  store i64 %t138, ptr %l76, !tbaa !24
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/scope:Scoper", ptr %t139, i32 0, i32 44
  %t143 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t141)
  store i64 %t143, ptr %l79
  br label %bb40
bb40:
  %t144 = load ptr, ptr %l74, !tbaa !29
  %t145 = load i64, ptr %l76, !tbaa !24
  %t146 = load i64, ptr %l79, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t144, i64 %t145, i64 %t146)
  br label %bb41
bb41:
  store ptr %l4, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb42
bb42:
  %t148 = load i64, ptr %l6, !tbaa !24
  store i64 %t148, ptr %l81, !tbaa !24
  %t149 = load ptr, ptr %l5, !tbaa !29
  %t151 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t149)
  store i64 %t151, ptr %l83
  br label %bb43
bb43:
  %t152 = load i64, ptr %l81, !tbaa !24
  %t153 = load i64, ptr %l83, !tbaa !24
  %t154 = icmp slt i64 %t152, %t153
  %t156 = xor i1 %t154, true
  br i1 %t156, label %bb44, label %bb45
bb44:
  br label %bb51
bb45:
  br label %bb46
bb46:
  %t158 = load ptr, ptr %l5, !tbaa !29
  %t159 = load i64, ptr %l6, !tbaa !24
  %t162 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t158, i64 %t159)
  store { i64, [2 x i64] } %t162, ptr %l88
  br label %bb47
bb47:
  %t163 = load { i64, [2 x i64] }, ptr %l88
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/scope:Scoper", ptr %t164, i32 0, i32 44
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ePush_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t166, { i64, [2 x i64] } %t163)
  br label %bb48
bb48:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/scope:Scoper", ptr %t170, i32 0, i32 45
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t172, i64 -1)
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t174 = load i64, ptr %l6, !tbaa !24
  %t176 = add i64 %t174, 1
  store i64 %t176, ptr %l6, !tbaa !24
  br label %bb42
bb51:
  br label %ret
bb52:
  %t178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t178, ptr %l96, !tbaa !29
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load ptr, ptr %l2, !tbaa !29
  %t183 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunPromoted(ptr %v0, ptr %v1, ptr %t179, ptr %t180)
  store ptr %t183, ptr %l99
  br label %bb53
bb53:
  %t184 = load ptr, ptr %l99, !tbaa !29
  %t185 = load ptr, ptr %l96, !tbaa !29
  %t187 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallOf(ptr %v0, ptr %v1, ptr %t185, ptr %t184)
  store ptr %t187, ptr %l101
  br label %bb54
bb54:
  %t188 = load ptr, ptr %l101, !tbaa !29
  store ptr %t188, ptr %l8, !tbaa !29
  %t189 = load ptr, ptr %l8, !tbaa !29
  %t191 = icmp eq ptr %t189, null
  br i1 %t191, label %bb55, label %bb56
bb55:
  store i1 true, ptr %l104, !tbaa !21
  br label %bb57
bb56:
  %t193 = load ptr, ptr %l8, !tbaa !29
  %t195 = getelementptr %"compiler/typed:Call", ptr %t193, i32 0, i32 3
  %t196 = load i32, ptr %t195, !tbaa !23
  %t198 = sext i32 %t196 to i64
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr %"compiler/scope:Scoper", ptr %t199, i32 0, i32 53
  %t202 = load i64, ptr %t201, !tbaa !24
  %t205 = icmp ne i64 %t198, %t202
  store i1 %t205, ptr %l104, !tbaa !21
  br label %bb57
bb57:
  %t207 = load i1, ptr %l104, !tbaa !21
  br i1 %t207, label %bb58, label %bb59
bb58:
  br label %ret
bb59:
  br label %bb60
bb60:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/scope:Scoper", ptr %t208, i32 0, i32 43
  %t211 = load i32, ptr %l1, !tbaa !23
  %t213 = sext i32 %t211 to i64
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/scope:Scoper", ptr %t214, i32 0, i32 54
  %t217 = load i64, ptr %t216, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t210, i64 %t213, i64 %t217)
  br label %bb61
bb61:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsThrough(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, %"compiler/source:Span" %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l16 = alloca ptr
  %l19 = alloca i1
  %l23 = alloca ptr
  %l26 = alloca i1
  %l27 = alloca i64
  %l31 = alloca ptr
  %l34 = alloca i64
  %l39 = alloca i1
  %l40 = alloca i64
  %l44 = alloca ptr
  %l47 = alloca i64
  %l49 = alloca i1
  %l53 = alloca ptr
  %l57 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca { i64, [2 x i64] }
  %l63 = alloca %"compiler/source:Span"
  %l67 = alloca ptr
  %l71 = alloca i64
  %l75 = alloca ptr
  %l79 = alloca %"compiler/source:Span"
  %l80 = alloca ptr
  %l81 = alloca { i64, [2 x i64] }
  %l82 = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp sge i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp sge i64 %t5, 0
  store i1 %t7, ptr %l9, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/scope:Scoper", ptr %t10, i32 0, i32 6
  %t13 = load i64, ptr %l3, !tbaa !24
  %t16 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t12, i64 %t13)
  store ptr %t16, ptr %l16
  br label %bb6
bb5:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb11
bb6:
  %t17 = load ptr, ptr %l16, !tbaa !29
  %t19 = getelementptr %"compiler/scope:summary", ptr %t17, i32 0, i32 14
  %t20 = load i1, ptr %t19, !tbaa !21
  br i1 %t20, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb10
bb8:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/scope:Scoper", ptr %t22, i32 0, i32 6
  %t25 = load i64, ptr %l3, !tbaa !24
  %t28 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t24, i64 %t25)
  store ptr %t28, ptr %l23
  br label %bb9
bb9:
  %t29 = load ptr, ptr %l23, !tbaa !29
  %t31 = getelementptr %"compiler/scope:summary", ptr %t29, i32 0, i32 15
  %t32 = load i1, ptr %t31, !tbaa !21
  store i1 %t32, ptr %l19, !tbaa !21
  br label %bb10
bb10:
  %t34 = load i1, ptr %l19, !tbaa !21
  store i1 %t34, ptr %l12, !tbaa !21
  br label %bb11
bb11:
  %t35 = load i1, ptr %l12, !tbaa !21
  br i1 %t35, label %bb12, label %bb13
bb12:
  %t36 = load i64, ptr %l4, !tbaa !24
  store i64 %t36, ptr %l27, !tbaa !24
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/scope:Scoper", ptr %t37, i32 0, i32 6
  %t40 = load i64, ptr %l3, !tbaa !24
  %t43 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t39, i64 %t40)
  store ptr %t43, ptr %l31
  br label %bb14
bb13:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb16
bb14:
  %t44 = load ptr, ptr %l31, !tbaa !29
  %t46 = getelementptr %"compiler/scope:summary", ptr %t44, i32 0, i32 4
  %t48 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eLen_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t46)
  store i64 %t48, ptr %l34
  br label %bb15
bb15:
  %t49 = load i64, ptr %l27, !tbaa !24
  %t50 = load i64, ptr %l34, !tbaa !24
  %t51 = icmp slt i64 %t49, %t50
  store i1 %t51, ptr %l26, !tbaa !21
  br label %bb16
bb16:
  %t53 = load i1, ptr %l26, !tbaa !21
  store i1 %t53, ptr %l5, !tbaa !21
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/scope:Scoper", ptr %t54, i32 0, i32 60
  %t57 = load i1, ptr %t56, !tbaa !21
  store i1 %t57, ptr %l6, !tbaa !21
  %t59 = load i1, ptr %l5, !tbaa !21
  br i1 %t59, label %bb17, label %bb18
bb17:
  %t61 = load i64, ptr %l4, !tbaa !24
  store i64 %t61, ptr %l40, !tbaa !24
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/scope:Scoper", ptr %t62, i32 0, i32 6
  %t65 = load i64, ptr %l3, !tbaa !24
  %t68 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t64, i64 %t65)
  store ptr %t68, ptr %l44
  br label %bb19
bb18:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb21
bb19:
  %t69 = load ptr, ptr %l44, !tbaa !29
  %t71 = getelementptr %"compiler/scope:summary", ptr %t69, i32 0, i32 2
  %t73 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t71)
  store i64 %t73, ptr %l47
  br label %bb20
bb20:
  %t74 = load i64, ptr %l40, !tbaa !24
  %t75 = load i64, ptr %l47, !tbaa !24
  %t76 = icmp slt i64 %t74, %t75
  store i1 %t76, ptr %l39, !tbaa !21
  br label %bb21
bb21:
  %t78 = load i1, ptr %l39, !tbaa !21
  br i1 %t78, label %bb22, label %bb23
bb22:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/scope:Scoper", ptr %t79, i32 0, i32 6
  %t82 = load i64, ptr %l3, !tbaa !24
  %t85 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t81, i64 %t82)
  store ptr %t85, ptr %l53
  br label %bb24
bb23:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb26
bb24:
  %t86 = load ptr, ptr %l53, !tbaa !29
  %t88 = getelementptr %"compiler/scope:summary", ptr %t86, i32 0, i32 2
  %t89 = load i64, ptr %l4, !tbaa !24
  %t92 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t88, i64 %t89)
  store i1 %t92, ptr %l57
  br label %bb25
bb25:
  %t93 = load i1, ptr %l57, !tbaa !21
  %t94 = xor i1 %t93, true
  store i1 %t94, ptr %l49, !tbaa !21
  br label %bb26
bb26:
  %t96 = load i1, ptr %l49, !tbaa !21
  br i1 %t96, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/scope:Scoper", ptr %t97, i32 0, i32 60
  store i1 true, ptr %t99, !tbaa !21
  br label %bb29
bb28:
  br label %bb29
bb29:
  %t100 = load i1, ptr %l5, !tbaa !21
  br i1 %t100, label %bb30, label %bb31
bb30:
  %t102 = load ptr, ptr %l0, !tbaa !29
  store ptr %t102, ptr %l61, !tbaa !29
  %t103 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t103, ptr %l62
  %t104 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t104, ptr %l63
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/scope:Scoper", ptr %t105, i32 0, i32 6
  %t108 = load i64, ptr %l3, !tbaa !24
  %t111 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t107, i64 %t108)
  store ptr %t111, ptr %l67
  br label %bb32
bb31:
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l80, !tbaa !29
  %t113 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t113, ptr %l81
  %t114 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t114, ptr %l82
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/scope:Scoper", ptr %t115, i32 0, i32 25
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = icmp eq ptr %t118, null
  br i1 %t120, label %bb37, label %bb38
bb32:
  %t122 = load ptr, ptr %l67, !tbaa !29
  %t124 = getelementptr %"compiler/scope:summary", ptr %t122, i32 0, i32 3
  %t125 = load i64, ptr %l4, !tbaa !24
  %t128 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t124, i64 %t125)
  store i64 %t128, ptr %l71
  br label %bb33
bb33:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/scope:Scoper", ptr %t129, i32 0, i32 6
  %t132 = load i64, ptr %l3, !tbaa !24
  %t135 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t131, i64 %t132)
  store ptr %t135, ptr %l75
  br label %bb34
bb34:
  %t136 = load ptr, ptr %l75, !tbaa !29
  %t138 = getelementptr %"compiler/scope:summary", ptr %t136, i32 0, i32 4
  %t139 = load i64, ptr %l4, !tbaa !24
  %t142 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t138, i64 %t139)
  store %"compiler/source:Span" %t142, ptr %l79
  br label %bb35
bb35:
  %t143 = load ptr, ptr %l61, !tbaa !29
  %t144 = load { i64, [2 x i64] }, ptr %l62
  %t145 = load %"compiler/source:Span", ptr %l63
  %t146 = load i64, ptr %l71, !tbaa !24
  %t147 = load %"compiler/source:Span", ptr %l79
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsInto(ptr %v0, ptr %t143, { i64, [2 x i64] } %t144, %"compiler/source:Span" %t145, i64 %t146, %"compiler/source:Span" %t147)
  br label %bb36
bb36:
  br label %bb41
bb37:
  call void @__olang_check_failed(ptr @olang_loc_43515980f8c6aee5_797864ac7e38a2e9)
  unreachable
bb38:
  br label %bb39
bb39:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/scope:Scoper", ptr %t148, i32 0, i32 25
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t154 = getelementptr %"compiler/typed:Body", ptr %t151, i32 0, i32 3
  %t155 = load i64, ptr %t154, !tbaa !24
  %t156 = load %"compiler/source:Span", ptr %l2
  %t157 = load ptr, ptr %l80, !tbaa !29
  %t158 = load { i64, [2 x i64] }, ptr %l81
  %t159 = load %"compiler/source:Span", ptr %l82
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsInto(ptr %v0, ptr %t157, { i64, [2 x i64] } %t158, %"compiler/source:Span" %t159, i64 %t155, %"compiler/source:Span" %t156)
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load i1, ptr %l6, !tbaa !21
  %t166 = getelementptr %"compiler/scope:Scoper", ptr %t162, i32 0, i32 60
  store i1 %t163, ptr %t166, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuiltOK(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca %"compiler/scope:rel"
  %l13 = alloca { i64, [2 x i64] }
  %l14 = alloca i64
  %l15 = alloca { i64, [2 x i64] }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca i1
  %l37 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l48 = alloca i1
  %l52 = alloca ptr
  %l58 = alloca i32
  %l62 = alloca i64
  %l65 = alloca i1
  %l68 = alloca i1
  %l73 = alloca i64
  %l81 = alloca { i64, ptr }
  %l85 = alloca ptr
  %l88 = alloca i64
  %l90 = alloca i64
  %l95 = alloca %"compiler/scope:rel"
  %l98 = alloca i1
  %l103 = alloca i1
  %l106 = alloca i1
  %l121 = alloca i64
  %l124 = alloca i64
  %l147 = alloca i64
  %l150 = alloca i64
  %l157 = alloca i1
  %l164 = alloca { i64, ptr }
  %l168 = alloca { i64, [2 x i64] }
  %l173 = alloca i1
  %l177 = alloca i1
  %l184 = alloca i64
  %l188 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  %t190 = alloca { i64, [2 x i64] }, align 8
  %t323 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, [2 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t7 = load ptr, ptr %l28, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l28, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 2
  store i1 %t13, ptr %l29, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l29, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t17, i32 0, i32 2
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t23 = load { i64, [2 x i64] }, ptr %l2
  %t27 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartOK(ptr %v0, ptr %v1, ptr %t21, ptr %t22, { i64, [2 x i64] } %t23)
  store i1 %t27, ptr %l37
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load i1, ptr %l37, !tbaa !21
  store i1 %t28, ptr %rv
  br label %ret
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  store ptr %t29, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t30 = load ptr, ptr %l38, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb11, label %bb12
bb11:
  %t33 = load ptr, ptr %l38, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 18}
  %t36 = icmp eq i64 %t34, 17
  store i1 %t36, ptr %l39, !tbaa !21
  br label %bb12
bb12:
  %t37 = load i1, ptr %l39, !tbaa !21
  br i1 %t37, label %bb13, label %bb14
bb13:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr { i64, [5 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l4, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load ptr, ptr %l4, !tbaa !29
  %t47 = load { i64, [2 x i64] }, ptr %l2
  %t51 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuiltOK(ptr %v0, ptr %v1, ptr %t44, ptr %t45, { i64, [2 x i64] } %t47)
  store i1 %t51, ptr %l48
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s0)
  %t52 = load i1, ptr %l48, !tbaa !21
  store i1 %t52, ptr %rv
  br label %ret
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_51647c5149cfd088_fff8b53f00e80584)
  unreachable
bb22:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t58 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallOf(ptr %v0, ptr %v1, ptr %t53, ptr %t54)
  store ptr %t58, ptr %l52
  br label %bb23
bb23:
  %t59 = load ptr, ptr %l52, !tbaa !29
  store ptr %t59, ptr %l5, !tbaa !29
  %t60 = load ptr, ptr %l5, !tbaa !29
  %t62 = icmp eq ptr %t60, null
  br i1 %t62, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l5, !tbaa !29
  %t69 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %t65, ptr %t66)
  store i32 %t69, ptr %l58
  br label %bb27
bb27:
  %t70 = load i32, ptr %l58, !tbaa !23
  store i32 %t70, ptr %l6, !tbaa !23
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l5, !tbaa !29
  %t74 = getelementptr %"compiler/typed:Call", ptr %t72, i32 0, i32 0
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t78 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebodyOf(ptr %v0, ptr %v1, ptr %t71, ptr %t75)
  store i64 %t78, ptr %l62
  br label %bb28
bb28:
  %t79 = load i64, ptr %l62, !tbaa !24
  store i64 %t79, ptr %l7, !tbaa !24
  %t80 = load i64, ptr %l7, !tbaa !24
  %t82 = icmp slt i64 %t80, 0
  br i1 %t82, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb32
bb30:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i64, ptr %l7, !tbaa !24
  %t88 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esummed(ptr %v0, ptr %t84, i64 %t85)
  store i1 %t88, ptr %l68
  br label %bb31
bb31:
  %t89 = load i1, ptr %l68, !tbaa !21
  %t90 = xor i1 %t89, true
  store i1 %t90, ptr %l65, !tbaa !21
  br label %bb32
bb32:
  %t92 = load i1, ptr %l65, !tbaa !21
  br i1 %t92, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load i32, ptr %l6, !tbaa !23
  %t98 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eresultVarOf(ptr %v0, ptr %t94, i32 %t95)
  store i64 %t98, ptr %l73
  br label %bb36
bb36:
  %t99 = load i64, ptr %l73, !tbaa !24
  store i64 %t99, ptr %l8, !tbaa !24
  %t100 = load i64, ptr %l8, !tbaa !24
  %t102 = icmp slt i64 %t100, 0
  br i1 %t102, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/scope:Scoper", ptr %t105, i32 0, i32 0
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = getelementptr %"compiler/generic:Program", ptr %t108, i32 0, i32 2
  %t111 = load i32, ptr %l6, !tbaa !23
  %t114 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t110, i32 %t111)
  store { i64, ptr } %t114, ptr %l81
  br label %bb40
bb40:
  %t115 = load { i64, ptr }, ptr %l81, !tbaa !27
  store { i64, ptr } %t115, ptr %l9, !tbaa !27
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/scope:Scoper", ptr %t116, i32 0, i32 6
  %t119 = load i64, ptr %l7, !tbaa !24
  %t122 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t118, i64 %t119)
  store ptr %t122, ptr %l85
  br label %bb41
bb41:
  %t123 = load ptr, ptr %l85, !tbaa !29
  %t125 = getelementptr %"compiler/scope:summary", ptr %t123, i32 0, i32 0
  store ptr %t125, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb42
bb42:
  %t127 = load i64, ptr %l11, !tbaa !24
  store i64 %t127, ptr %l88, !tbaa !24
  %t128 = load ptr, ptr %l10, !tbaa !29
  %t130 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t128)
  store i64 %t130, ptr %l90
  br label %bb43
bb43:
  %t131 = load i64, ptr %l88, !tbaa !24
  %t132 = load i64, ptr %l90, !tbaa !24
  %t133 = icmp slt i64 %t131, %t132
  %t135 = xor i1 %t133, true
  br i1 %t135, label %bb44, label %bb45
bb44:
  br label %bb114
bb45:
  br label %bb46
bb46:
  %t137 = load ptr, ptr %l10, !tbaa !29
  %t138 = load i64, ptr %l11, !tbaa !24
  %t141 = call %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t137, i64 %t138)
  store %"compiler/scope:rel" %t141, ptr %l95
  br label %bb47
bb47:
  %t142 = load %"compiler/scope:rel", ptr %l95
  store %"compiler/scope:rel" %t142, ptr %l12
  %t143 = getelementptr %"compiler/scope:rel", ptr %l12, i32 0, i32 1
  %t144 = load { i64, [2 x i64] }, ptr %t143
  %t146 = extractvalue { i64, [2 x i64] } %t144, 0
  %t147 = icmp eq i64 %t146, 2
  br i1 %t147, label %bb48, label %bb49
bb48:
  %t149 = getelementptr %"compiler/scope:rel", ptr %l12, i32 0, i32 1
  %t150 = getelementptr { i64, [2 x i64] }, ptr %t149, i32 0, i32 1
  %t151 = getelementptr { i64 }, ptr %t150, i32 0, i32 0
  %t152 = load i64, ptr %t151
  %t153 = load i64, ptr %l8, !tbaa !24
  %t156 = icmp eq i64 %t152, %t153
  store i1 %t156, ptr %l98, !tbaa !21
  br label %bb50
bb49:
  store i1 false, ptr %l98, !tbaa !21
  br label %bb50
bb50:
  %t158 = load i1, ptr %l98, !tbaa !21
  %t159 = xor i1 %t158, true
  br i1 %t159, label %bb51, label %bb52
bb51:
  store i1 true, ptr %l103, !tbaa !21
  br label %bb56
bb52:
  %t161 = getelementptr %"compiler/scope:rel", ptr %l12, i32 0, i32 0
  %t162 = load { i64, [2 x i64] }, ptr %t161
  %t164 = extractvalue { i64, [2 x i64] } %t162, 0
  %t165 = icmp eq i64 %t164, 2
  br i1 %t165, label %bb53, label %bb54
bb53:
  %t167 = getelementptr %"compiler/scope:rel", ptr %l12, i32 0, i32 0
  %t168 = getelementptr { i64, [2 x i64] }, ptr %t167, i32 0, i32 1
  %t169 = getelementptr { i64 }, ptr %t168, i32 0, i32 0
  %t170 = load i64, ptr %t169
  %t171 = load i64, ptr %l8, !tbaa !24
  %t174 = icmp eq i64 %t170, %t171
  store i1 %t174, ptr %l106, !tbaa !21
  br label %bb55
bb54:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb55
bb55:
  %t176 = load i1, ptr %l106, !tbaa !21
  store i1 %t176, ptr %l103, !tbaa !21
  br label %bb56
bb56:
  %t177 = load i1, ptr %l103, !tbaa !21
  br i1 %t177, label %bb57, label %bb58
bb57:
  br label %bb113
bb58:
  br label %bb59
bb59:
  %t178 = getelementptr %"compiler/scope:rel", ptr %l12, i32 0, i32 0
  %t179 = load { i64, [2 x i64] }, ptr %t178
  store { i64, [2 x i64] } %t179, ptr %l13
  %t181 = load { i64, [2 x i64] }, ptr %l13
  %t183 = extractvalue { i64, [2 x i64] } %t181, 0
  %t184 = icmp eq i64 %t183, 2
  br i1 %t184, label %bb60, label %bb61
bb60:
  %t186 = getelementptr { i64, [2 x i64] }, ptr %l13, i32 0, i32 1
  %t187 = getelementptr { i64 }, ptr %t186, i32 0, i32 0
  %t188 = load i64, ptr %t187
  store i64 %t188, ptr %l14, !tbaa !24
  br label %bb62
bb61:
  br label %bb103
bb62:
  store { i64, [2 x i64] } zeroinitializer, ptr %t190
  %t191 = getelementptr { i64, [2 x i64] }, ptr %t190, i32 0, i32 0
  store i64 0, ptr %t191
  %t192 = load { i64, [2 x i64] }, ptr %t190
  store { i64, [2 x i64] } %t192, ptr %l15
  store i64 0, ptr %l16, !tbaa !24
  %t194 = load ptr, ptr %l5, !tbaa !29
  %t196 = getelementptr %"compiler/typed:Call", ptr %t194, i32 0, i32 1
  %t197 = load { i64, ptr }, ptr %t196, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t197, 0
  store i64 %t199, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t201 = load i64, ptr %l17, !tbaa !24
  %t202 = load i64, ptr %l16, !tbaa !24
  %t205 = icmp sgt i64 %t201, %t202
  br i1 %t205, label %bb63, label %bb64
bb63:
  %t207 = load i64, ptr %l18, !tbaa !24
  %t209 = icmp sgt i64 %t207, 0
  br i1 %t209, label %bb65, label %bb66
bb64:
  store i64 0, ptr %l121, !tbaa !24
  br label %bb68
bb65:
  %t211 = load i64, ptr %l17, !tbaa !24
  %t212 = load i64, ptr %l16, !tbaa !24
  %t215 = sub i64 %t211, %t212
  %t216 = load i64, ptr %l18, !tbaa !24
  %t219 = add i64 %t215, %t216
  %t221 = sub i64 %t219, 1
  %t222 = load i64, ptr %l18, !tbaa !24
  %t225 = sdiv i64 %t221, %t222
  store i64 %t225, ptr %l124, !tbaa !24
  br label %bb67
bb66:
  store i64 0, ptr %l124, !tbaa !24
  br label %bb67
bb67:
  %t227 = load i64, ptr %l124, !tbaa !24
  store i64 %t227, ptr %l121, !tbaa !24
  br label %bb68
bb68:
  %t228 = load i64, ptr %l121, !tbaa !24
  store i64 %t228, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb69
bb69:
  %t229 = load i64, ptr %l20, !tbaa !24
  %t230 = load i64, ptr %l19, !tbaa !24
  %t233 = icmp slt i64 %t229, %t230
  %t235 = xor i1 %t233, true
  br i1 %t235, label %bb70, label %bb71
bb70:
  br label %bb85
bb71:
  br label %bb72
bb72:
  %t237 = load i64, ptr %l16, !tbaa !24
  %t238 = load i64, ptr %l20, !tbaa !24
  %t239 = load i64, ptr %l18, !tbaa !24
  %t242 = mul i64 %t238, %t239
  %t245 = add i64 %t237, %t242
  store i64 %t245, ptr %l21, !tbaa !24
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t249 = getelementptr %"compiler/scope:Scoper", ptr %t247, i32 0, i32 0
  %t250 = load ptr, ptr %t249, !tbaa !29
  %t252 = getelementptr %"compiler/generic:Program", ptr %t250, i32 0, i32 2
  %t253 = load i32, ptr %l6, !tbaa !23
  %t254 = load i64, ptr %l21, !tbaa !24
  %t258 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t252, i32 %t253, i64 %t254)
  store i64 %t258, ptr %l147
  br label %bb73
bb73:
  %t259 = load i64, ptr %l147, !tbaa !24
  store i64 %t259, ptr %l22, !tbaa !24
  %t260 = load i64, ptr %l22, !tbaa !24
  %t262 = icmp sge i64 %t260, 0
  br i1 %t262, label %bb74, label %bb75
bb74:
  %t264 = load i64, ptr %l22, !tbaa !24
  store i64 %t264, ptr %l150, !tbaa !24
  br label %bb76
bb75:
  %t266 = load i64, ptr %l21, !tbaa !24
  store i64 %t266, ptr %l150, !tbaa !24
  br label %bb76
bb76:
  %t268 = load i64, ptr %l150, !tbaa !24
  store i64 %t268, ptr %l23, !tbaa !24
  %t269 = load i64, ptr %l14, !tbaa !24
  %t270 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t272 = extractvalue { i64, ptr } %t270, 0
  %t275 = icmp slt i64 %t269, %t272
  br i1 %t275, label %bb77, label %bb78
bb77:
  %t277 = load i64, ptr %l14, !tbaa !24
  %t279 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t280 = load ptr, ptr %t279, !tbaa !27
  %t281 = getelementptr i64, ptr %t280, i64 %t277
  %t282 = load i64, ptr %t281, !tbaa !34
  %t283 = load i64, ptr %l23, !tbaa !24
  %t286 = icmp eq i64 %t282, %t283
  store i1 %t286, ptr %l157, !tbaa !21
  br label %bb79
bb78:
  store i1 false, ptr %l157, !tbaa !21
  br label %bb79
bb79:
  %t288 = load i1, ptr %l157, !tbaa !21
  br i1 %t288, label %bb80, label %bb81
bb80:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t290 = load ptr, ptr %l5, !tbaa !29
  %t292 = getelementptr %"compiler/typed:Call", ptr %t290, i32 0, i32 1
  %t293 = load { i64, ptr }, ptr %t292, !tbaa !27
  store { i64, ptr } %t293, ptr %l164, !tbaa !27
  %t294 = load i64, ptr %l21, !tbaa !24
  %t296 = getelementptr { i64, ptr }, ptr %l164, i32 0, i32 1
  %t297 = load ptr, ptr %t296, !tbaa !27
  %t298 = getelementptr ptr, ptr %t297, i64 %t294
  %t299 = load ptr, ptr %t298, !tbaa !39
  %t303 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekTerm(ptr %v0, ptr %v1, ptr %t289, ptr %t299)
  store { i64, [2 x i64] } %t303, ptr %l168
  br label %bb82
bb81:
  br label %bb83
bb82:
  %t304 = load { i64, [2 x i64] }, ptr %l168
  store { i64, [2 x i64] } %t304, ptr %l15
  br label %bb85
bb83:
  br label %bb84
bb84:
  %t305 = load i64, ptr %l20, !tbaa !24
  %t307 = add i64 %t305, 1
  store i64 %t307, ptr %l20, !tbaa !24
  br label %bb69
bb85:
  %t309 = load { i64, [2 x i64] }, ptr %l15
  %t311 = extractvalue { i64, [2 x i64] } %t309, 0
  %t312 = icmp eq i64 %t311, 0
  br i1 %t312, label %bb86, label %bb87
bb86:
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t315 = load ptr, ptr %l5, !tbaa !29
  %t316 = load i64, ptr %l14, !tbaa !24
  %t320 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estaticVar(ptr %v0, ptr %v1, ptr %t314, ptr %t315, i64 %t316)
  store i1 %t320, ptr %l177
  br label %bb88
bb87:
  store i1 false, ptr %l173, !tbaa !21
  br label %bb89
bb88:
  %t321 = load i1, ptr %l177, !tbaa !21
  store i1 %t321, ptr %l173, !tbaa !21
  br label %bb89
bb89:
  %t322 = load i1, ptr %l173, !tbaa !21
  br i1 %t322, label %bb90, label %bb91
bb90:
  store { i64, [2 x i64] } zeroinitializer, ptr %t323
  %t324 = getelementptr { i64, [2 x i64] }, ptr %t323, i32 0, i32 0
  store i64 3, ptr %t324
  %t325 = load { i64, [2 x i64] }, ptr %t323
  store { i64, [2 x i64] } %t325, ptr %l15
  br label %bb92
bb91:
  br label %bb92
bb92:
  %t327 = load { i64, [2 x i64] }, ptr %l15
  %t329 = extractvalue { i64, [2 x i64] } %t327, 0
  %t330 = icmp eq i64 %t329, 0
  br i1 %t330, label %bb93, label %bb94
bb93:
  br label %bb113
bb94:
  br label %bb95
bb95:
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t333 = load { i64, [2 x i64] }, ptr %l15
  %t334 = load { i64, [2 x i64] }, ptr %l2
  %t338 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eorder(ptr %v0, ptr %t332, { i64, [2 x i64] } %t333, { i64, [2 x i64] } %t334)
  store i64 %t338, ptr %l184
  br label %bb96
bb96:
  %t339 = load i64, ptr %l184, !tbaa !24
  store i64 %t339, ptr %l24, !tbaa !24
  %t340 = load i64, ptr %l24, !tbaa !24
  %t341 = load i64, ptr @G_2ecompiler_2fscope_2eHolds, !tbaa !24
  %t344 = icmp ne i64 %t340, %t341
  br i1 %t344, label %bb97, label %bb98
bb97:
  %t346 = load i64, ptr %l24, !tbaa !24
  %t347 = load i64, ptr @G_2ecompiler_2fscope_2eObliged, !tbaa !24
  %t350 = icmp ne i64 %t346, %t347
  store i1 %t350, ptr %l188, !tbaa !21
  br label %bb99
bb98:
  store i1 false, ptr %l188, !tbaa !21
  br label %bb99
bb99:
  %t352 = load i1, ptr %l188, !tbaa !21
  br i1 %t352, label %bb100, label %bb101
bb100:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb101:
  br label %bb102
bb102:
  br label %bb112
bb103:
  %t354 = load { i64, [2 x i64] }, ptr %l13
  %t356 = extractvalue { i64, [2 x i64] } %t354, 0
  %t357 = icmp eq i64 %t356, 3
  br i1 %t357, label %bb104, label %bb105
bb104:
  br label %bb106
bb105:
  br label %bb107
bb106:
  br label %bb112
bb107:
  br i1 true, label %bb108, label %bb109
bb108:
  br label %bb110
bb109:
  br label %bb111
bb110:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb111:
  call void @__olang_check_failed(ptr @olang_loc_40698dacb4c14a59_3145716d01d07175)
  unreachable
bb112:
  br label %bb113
bb113:
  %t360 = load i64, ptr %l11, !tbaa !24
  %t362 = add i64 %t360, 1
  store i64 %t362, ptr %l11, !tbaa !24
  br label %bb42
bb114:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i1
  %l19 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i1
  %l29 = alloca i32
  %l30 = alloca ptr
  %l31 = alloca i1
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Call", ptr %a1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t7 = load ptr, ptr %l9, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l9, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l10, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { i32 }, ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t23 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 1
  %t24 = load i32, ptr %l3, !tbaa !23
  %t26 = sext i32 %t24 to i64
  %t29 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t23, i64 %t26)
  store ptr %t29, ptr %l19
  br label %bb6
bb6:
  %t30 = load ptr, ptr %l19, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Body", ptr %t30, i32 0, i32 2
  %t33 = load i32, ptr %t32, !tbaa !23
  store i32 %t33, ptr %l8, !tbaa !23
  br label %bb25
bb7:
  %t35 = load ptr, ptr %l2, !tbaa !29
  store ptr %t35, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t36 = load ptr, ptr %l22, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb8, label %bb9
bb8:
  %t39 = load ptr, ptr %l22, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 5}
  %t42 = icmp eq i64 %t40, 2
  store i1 %t42, ptr %l23, !tbaa !21
  br label %bb9
bb9:
  %t43 = load i1, ptr %l23, !tbaa !21
  br i1 %t43, label %bb10, label %bb11
bb10:
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t46 = getelementptr { i64, [3 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { ptr }, ptr %t46, i32 0, i32 0
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l4, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t52 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t50)
  store i32 %t52, ptr %l29
  br label %bb13
bb13:
  %t53 = load i32, ptr %l29, !tbaa !23
  store i32 %t53, ptr %l8, !tbaa !23
  br label %bb25
bb14:
  %t54 = load ptr, ptr %l2, !tbaa !29
  store ptr %t54, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t55 = load ptr, ptr %l30, !tbaa !29
  %t56 = icmp ne ptr %t55, null
  br i1 %t56, label %bb15, label %bb16
bb15:
  %t58 = load ptr, ptr %l30, !tbaa !29
  %t59 = load i64, ptr %t58, !range !{i64 0, i64 5}
  %t61 = icmp eq i64 %t59, 3
  store i1 %t61, ptr %l31, !tbaa !21
  br label %bb16
bb16:
  %t62 = load i1, ptr %l31, !tbaa !21
  br i1 %t62, label %bb17, label %bb18
bb17:
  %t63 = load ptr, ptr %l2, !tbaa !29
  %t65 = getelementptr { i64, [3 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { i32, i64, i32 }, ptr %t65, i32 0, i32 2
  %t67 = load i32, ptr %t66
  store i32 %t67, ptr %l5, !tbaa !23
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t69 = load i32, ptr %l5, !tbaa !23
  store i32 %t69, ptr %l8, !tbaa !23
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  %t71 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t71, ptr %l8, !tbaa !23
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_fe18b6f8ffe1c828_d6769ee32e48c6ec)
  unreachable
bb25:
  %t73 = load i32, ptr %l8, !tbaa !23
  store i32 %t73, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallsItself(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l11 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l44 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 12
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t4)
  store i64 %t7, ptr %l11
  br label %bb1
bb1:
  %t8 = load i64, ptr %l11, !tbaa !24
  store i64 %t8, ptr %l2, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/scope:Scoper", ptr %t9, i32 0, i32 12
  %t12 = load i64, ptr %l1, !tbaa !24
  %t14 = add i64 %t12, 1
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t11, i64 %t14)
  store i64 %t17, ptr %l16
  br label %bb2
bb2:
  %t18 = load i64, ptr %l16, !tbaa !24
  store i64 %t18, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = icmp sgt i64 %t19, %t20
  br i1 %t23, label %bb3, label %bb4
bb3:
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = icmp sgt i64 %t25, 0
  br i1 %t27, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb8
bb5:
  %t29 = load i64, ptr %l3, !tbaa !24
  %t30 = load i64, ptr %l2, !tbaa !24
  %t33 = sub i64 %t29, %t30
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = add i64 %t33, %t34
  %t39 = sub i64 %t37, 1
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = sdiv i64 %t39, %t40
  store i64 %t43, ptr %l23, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t45 = load i64, ptr %l23, !tbaa !24
  store i64 %t45, ptr %l20, !tbaa !24
  br label %bb8
bb8:
  %t46 = load i64, ptr %l20, !tbaa !24
  store i64 %t46, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l5, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb10, label %bb11
bb10:
  br label %bb18
bb11:
  br label %bb12
bb12:
  %t55 = load i64, ptr %l2, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  %t57 = load i64, ptr %l4, !tbaa !24
  %t60 = mul i64 %t56, %t57
  %t63 = add i64 %t55, %t60
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/scope:Scoper", ptr %t65, i32 0, i32 13
  %t71 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t67, i64 %t63)
  store i64 %t71, ptr %l44
  br label %bb13
bb13:
  %t72 = load i64, ptr %l1, !tbaa !24
  %t73 = load i64, ptr %l44, !tbaa !24
  %t75 = icmp eq i64 %t73, %t72
  br i1 %t75, label %bb14, label %bb15
bb14:
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t78 = load i64, ptr %l6, !tbaa !24
  %t80 = add i64 %t78, 1
  store i64 %t80, ptr %l6, !tbaa !24
  br label %bb9
bb18:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecapturingLambda(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l19 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l29 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 15
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb18
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t17 = load ptr, ptr %l11, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l11, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 3}
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t27, i32 0, i32 1
  %t29 = load { i64, ptr }, ptr %t28
  store { i64, ptr } %t29, ptr %l3, !tbaa !27
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t35 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecapturesNothing(ptr %v0, ptr %v1, ptr %t31, { i64, ptr } %t32)
  store i1 %t35, ptr %l19
  br label %bb11
bb11:
  %t36 = load i1, ptr %l19, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %rv
  br label %ret
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_6e154fb23d94f618_2ee03e6b3f75e7ac)
  unreachable
bb17:
  br label %bb30
bb18:
  %t39 = load ptr, ptr %l1, !tbaa !29
  store ptr %t39, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t40 = load ptr, ptr %l21, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb19, label %bb20
bb19:
  %t43 = load ptr, ptr %l21, !tbaa !29
  %t44 = load i64, ptr %t43, !range !{i64 0, i64 18}
  %t46 = icmp eq i64 %t44, 17
  store i1 %t46, ptr %l22, !tbaa !21
  br label %bb20
bb20:
  %t47 = load i1, ptr %l22, !tbaa !21
  br i1 %t47, label %bb21, label %bb22
bb21:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr { i64, [5 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t50, i32 0, i32 2
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l4, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t58 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecapturingLambda(ptr %v0, ptr %v1, ptr %t54, ptr %t55)
  store i1 %t58, ptr %l29
  br label %bb24
bb24:
  %t59 = load i1, ptr %l29, !tbaa !21
  store i1 %t59, ptr %rv
  br label %ret
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_e36c9ef691e1ece9_3ba86da2e7516a5d)
  unreachable
bb30:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca i64
  %l47 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca i1
  %l68 = alloca i1
  %l72 = alloca ptr
  %l73 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca i1
  %l102 = alloca ptr
  %l103 = alloca i1
  %l112 = alloca i1
  %l120 = alloca i64
  %l123 = alloca i64
  %l144 = alloca i1
  %l147 = alloca { i64, ptr }
  %l154 = alloca ptr
  %l155 = alloca i1
  %l168 = alloca { i64, ptr }
  %l177 = alloca ptr
  %l178 = alloca i1
  %l188 = alloca i1
  %l189 = alloca i1
  %l193 = alloca i1
  %l196 = alloca i1
  %l198 = alloca { i64, ptr }
  %l202 = alloca ptr
  %l203 = alloca i1
  %l217 = alloca ptr
  %l218 = alloca i1
  %l227 = alloca ptr
  %l228 = alloca i1
  %l241 = alloca { i64, ptr }
  %l254 = alloca ptr
  %l263 = alloca ptr
  %l264 = alloca i1
  %l281 = alloca { i64, ptr }
  %l292 = alloca { i64, ptr }
  %l303 = alloca ptr
  %l304 = alloca i1
  %l313 = alloca ptr
  %l314 = alloca i1
  %l319 = alloca ptr
  %l320 = alloca i1
  %l335 = alloca { i64, ptr }
  %l345 = alloca ptr
  %l346 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t6 = load ptr, ptr %l50, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l50, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l51, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l51, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t16, i32 0, i32 1
  %t18 = load i32, ptr %t17
  store i32 %t18, ptr %l3, !tbaa !23
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [5 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t22, i32 0, i32 2
  %t24 = load ptr, ptr %t23
  store ptr %t24, ptr %l4, !tbaa !29
  br label %bb12
bb7:
  %t26 = load ptr, ptr %l1, !tbaa !29
  store ptr %t26, ptr %l58, !tbaa !29
  store i1 false, ptr %l59, !tbaa !21
  %t27 = load ptr, ptr %l58, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb8, label %bb9
bb8:
  %t30 = load ptr, ptr %l58, !tbaa !29
  %t31 = load i64, ptr %t30, !range !{i64 0, i64 18}
  %t33 = icmp eq i64 %t31, 4
  store i1 %t33, ptr %l59, !tbaa !21
  br label %bb9
bb9:
  %t34 = load i1, ptr %l59, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb10:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr { i64, [5 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t37, i32 0, i32 1
  %t39 = load i32, ptr %t38
  store i32 %t39, ptr %l3, !tbaa !23
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr { i64, [5 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t43, i32 0, i32 2
  %t45 = load ptr, ptr %t44
  store ptr %t45, ptr %l4, !tbaa !29
  br label %bb12
bb11:
  br label %bb18
bb12:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i32, ptr %l3, !tbaa !23
  %t51 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t47, i32 %t48)
  store i1 %t51, ptr %l68
  br label %bb13
bb13:
  %t52 = load i1, ptr %l68, !tbaa !21
  br i1 %t52, label %bb14, label %bb15
bb14:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load ptr, ptr %l4, !tbaa !29
  %t55 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarriedPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t53, ptr %t54, ptr %t55)
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  br label %bb198
bb18:
  %t59 = load ptr, ptr %l1, !tbaa !29
  store ptr %t59, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t60 = load ptr, ptr %l72, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb19, label %bb20
bb19:
  %t63 = load ptr, ptr %l72, !tbaa !29
  %t64 = load i64, ptr %t63, !range !{i64 0, i64 18}
  %t66 = icmp eq i64 %t64, 3
  store i1 %t66, ptr %l73, !tbaa !21
  br label %bb20
bb20:
  %t67 = load i1, ptr %l73, !tbaa !21
  br i1 %t67, label %bb21, label %bb22
bb21:
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [5 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t70, i32 0, i32 2
  %t72 = load ptr, ptr %t71
  store ptr %t72, ptr %l5, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load ptr, ptr %l5, !tbaa !29
  %t76 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarriedPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t74, ptr %t75, ptr %t76)
  br label %bb24
bb24:
  br label %bb198
bb25:
  %t80 = load ptr, ptr %l1, !tbaa !29
  store ptr %t80, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t81 = load ptr, ptr %l81, !tbaa !29
  %t82 = icmp ne ptr %t81, null
  br i1 %t82, label %bb26, label %bb27
bb26:
  %t84 = load ptr, ptr %l81, !tbaa !29
  %t85 = load i64, ptr %t84, !range !{i64 0, i64 18}
  %t87 = icmp eq i64 %t85, 10
  store i1 %t87, ptr %l82, !tbaa !21
  br label %bb27
bb27:
  %t88 = load i1, ptr %l82, !tbaa !21
  br i1 %t88, label %bb28, label %bb29
bb28:
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr { i64, [5 x i64] }, ptr %t89, i32 0, i32 1
  %t92 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t91, i32 0, i32 2
  %t93 = load ptr, ptr %t92
  store ptr %t93, ptr %l6, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load ptr, ptr %l6, !tbaa !29
  %t98 = getelementptr %"compiler/typed:Slice", ptr %t96, i32 0, i32 0
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t100 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarriedPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t95, ptr %t99, ptr %t100)
  br label %bb31
bb31:
  br label %bb198
bb32:
  %t104 = load ptr, ptr %l1, !tbaa !29
  store ptr %t104, ptr %l91, !tbaa !29
  store i1 false, ptr %l92, !tbaa !21
  %t105 = load ptr, ptr %l91, !tbaa !29
  %t106 = icmp ne ptr %t105, null
  br i1 %t106, label %bb33, label %bb34
bb33:
  %t108 = load ptr, ptr %l91, !tbaa !29
  %t109 = load i64, ptr %t108, !range !{i64 0, i64 18}
  %t111 = icmp eq i64 %t109, 5
  store i1 %t111, ptr %l92, !tbaa !21
  br label %bb34
bb34:
  %t112 = load i1, ptr %l92, !tbaa !21
  br i1 %t112, label %bb35, label %bb36
bb35:
  %t113 = load ptr, ptr %l1, !tbaa !29
  %t115 = getelementptr { i64, [5 x i64] }, ptr %t113, i32 0, i32 1
  %t116 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t115, i32 0, i32 2
  %t117 = load ptr, ptr %t116
  store ptr %t117, ptr %l7, !tbaa !29
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load ptr, ptr %l7, !tbaa !29
  %t122 = getelementptr %"compiler/typed:Promote", ptr %t120, i32 0, i32 0
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t119, ptr %t123, ptr %t125)
  br label %bb38
bb38:
  br label %bb198
bb39:
  %t129 = load ptr, ptr %l1, !tbaa !29
  store ptr %t129, ptr %l102, !tbaa !29
  store i1 false, ptr %l103, !tbaa !21
  %t130 = load ptr, ptr %l102, !tbaa !29
  %t131 = icmp ne ptr %t130, null
  br i1 %t131, label %bb40, label %bb41
bb40:
  %t133 = load ptr, ptr %l102, !tbaa !29
  %t134 = load i64, ptr %t133, !range !{i64 0, i64 18}
  %t136 = icmp eq i64 %t134, 6
  store i1 %t136, ptr %l103, !tbaa !21
  br label %bb41
bb41:
  %t137 = load i1, ptr %l103, !tbaa !21
  br i1 %t137, label %bb42, label %bb43
bb42:
  %t138 = load ptr, ptr %l1, !tbaa !29
  %t140 = getelementptr { i64, [5 x i64] }, ptr %t138, i32 0, i32 1
  %t141 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t140, i32 0, i32 1
  %t142 = load i32, ptr %t141
  store i32 %t142, ptr %l8, !tbaa !23
  %t144 = load ptr, ptr %l1, !tbaa !29
  %t146 = getelementptr { i64, [5 x i64] }, ptr %t144, i32 0, i32 1
  %t147 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t146, i32 0, i32 2
  %t148 = load ptr, ptr %t147
  store ptr %t148, ptr %l9, !tbaa !29
  br label %bb44
bb43:
  br label %bb66
bb44:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load i32, ptr %l8, !tbaa !23
  %t154 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t150, i32 %t151)
  store i1 %t154, ptr %l112
  br label %bb45
bb45:
  %t155 = load i1, ptr %l112, !tbaa !21
  %t156 = xor i1 %t155, true
  br i1 %t156, label %bb46, label %bb47
bb46:
  br label %ret
bb47:
  br label %bb48
bb48:
  store i64 0, ptr %l10, !tbaa !24
  %t158 = load ptr, ptr %l9, !tbaa !29
  %t160 = getelementptr %"compiler/typed:Call", ptr %t158, i32 0, i32 1
  %t161 = load { i64, ptr }, ptr %t160, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t161, 0
  store i64 %t163, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t165 = load i64, ptr %l11, !tbaa !24
  %t166 = load i64, ptr %l10, !tbaa !24
  %t169 = icmp sgt i64 %t165, %t166
  br i1 %t169, label %bb49, label %bb50
bb49:
  %t171 = load i64, ptr %l12, !tbaa !24
  %t173 = icmp sgt i64 %t171, 0
  br i1 %t173, label %bb51, label %bb52
bb50:
  store i64 0, ptr %l120, !tbaa !24
  br label %bb54
bb51:
  %t175 = load i64, ptr %l11, !tbaa !24
  %t176 = load i64, ptr %l10, !tbaa !24
  %t179 = sub i64 %t175, %t176
  %t180 = load i64, ptr %l12, !tbaa !24
  %t183 = add i64 %t179, %t180
  %t185 = sub i64 %t183, 1
  %t186 = load i64, ptr %l12, !tbaa !24
  %t189 = sdiv i64 %t185, %t186
  store i64 %t189, ptr %l123, !tbaa !24
  br label %bb53
bb52:
  store i64 0, ptr %l123, !tbaa !24
  br label %bb53
bb53:
  %t191 = load i64, ptr %l123, !tbaa !24
  store i64 %t191, ptr %l120, !tbaa !24
  br label %bb54
bb54:
  %t192 = load i64, ptr %l120, !tbaa !24
  store i64 %t192, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb55
bb55:
  %t193 = load i64, ptr %l14, !tbaa !24
  %t194 = load i64, ptr %l13, !tbaa !24
  %t197 = icmp slt i64 %t193, %t194
  %t199 = xor i1 %t197, true
  br i1 %t199, label %bb56, label %bb57
bb56:
  br label %bb65
bb57:
  br label %bb58
bb58:
  %t201 = load i64, ptr %l10, !tbaa !24
  %t202 = load i64, ptr %l14, !tbaa !24
  %t203 = load i64, ptr %l12, !tbaa !24
  %t206 = mul i64 %t202, %t203
  %t209 = add i64 %t201, %t206
  store i64 %t209, ptr %l15, !tbaa !24
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t212 = load ptr, ptr %l9, !tbaa !29
  %t213 = load i64, ptr %l15, !tbaa !24
  %t217 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecanKeep(ptr %v0, ptr %v1, ptr %t211, ptr %t212, i64 %t213)
  store i1 %t217, ptr %l144
  br label %bb59
bb59:
  %t218 = load i1, ptr %l144, !tbaa !21
  br i1 %t218, label %bb60, label %bb61
bb60:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load ptr, ptr %l9, !tbaa !29
  %t222 = getelementptr %"compiler/typed:Call", ptr %t220, i32 0, i32 1
  %t223 = load { i64, ptr }, ptr %t222, !tbaa !27
  store { i64, ptr } %t223, ptr %l147, !tbaa !27
  %t224 = load i64, ptr %l15, !tbaa !24
  %t226 = getelementptr { i64, ptr }, ptr %l147, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !27
  %t228 = getelementptr ptr, ptr %t227, i64 %t224
  %t229 = load ptr, ptr %t228, !tbaa !39
  %t231 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t219, ptr %t229, ptr %t231)
  br label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb63
bb63:
  br label %bb64
bb64:
  %t235 = load i64, ptr %l14, !tbaa !24
  %t237 = add i64 %t235, 1
  store i64 %t237, ptr %l14, !tbaa !24
  br label %bb55
bb65:
  br label %bb198
bb66:
  %t239 = load ptr, ptr %l1, !tbaa !29
  store ptr %t239, ptr %l154, !tbaa !29
  store i1 false, ptr %l155, !tbaa !21
  %t240 = load ptr, ptr %l154, !tbaa !29
  %t241 = icmp ne ptr %t240, null
  br i1 %t241, label %bb67, label %bb68
bb67:
  %t243 = load ptr, ptr %l154, !tbaa !29
  %t244 = load i64, ptr %t243, !range !{i64 0, i64 18}
  %t246 = icmp eq i64 %t244, 7
  store i1 %t246, ptr %l155, !tbaa !21
  br label %bb68
bb68:
  %t247 = load i1, ptr %l155, !tbaa !21
  br i1 %t247, label %bb69, label %bb70
bb69:
  %t248 = load ptr, ptr %l1, !tbaa !29
  %t250 = getelementptr { i64, [5 x i64] }, ptr %t248, i32 0, i32 1
  %t251 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t250, i32 0, i32 2
  %t252 = load ptr, ptr %t251
  store ptr %t252, ptr %l16, !tbaa !29
  br label %bb71
bb70:
  br label %bb79
bb71:
  %t254 = load ptr, ptr %l16, !tbaa !29
  %t256 = getelementptr %"compiler/typed:Make", ptr %t254, i32 0, i32 2
  %t257 = load { i64, ptr }, ptr %t256, !tbaa !27
  store { i64, ptr } %t257, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t259 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t261 = extractvalue { i64, ptr } %t259, 0
  store i64 %t261, ptr %l19, !tbaa !24
  br label %bb72
bb72:
  %t263 = load i64, ptr %l18, !tbaa !24
  %t264 = load i64, ptr %l19, !tbaa !24
  %t267 = icmp slt i64 %t263, %t264
  %t269 = xor i1 %t267, true
  br i1 %t269, label %bb73, label %bb74
bb73:
  br label %bb78
bb74:
  br label %bb75
bb75:
  %t271 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t271, ptr %l168, !tbaa !27
  %t272 = load i64, ptr %l18, !tbaa !24
  %t274 = getelementptr { i64, ptr }, ptr %l168, i32 0, i32 1
  %t275 = load ptr, ptr %t274, !tbaa !27
  %t276 = getelementptr ptr, ptr %t275, i64 %t272
  %t277 = load ptr, ptr %t276, !tbaa !39
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t282 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t279, ptr %t277, ptr %t282)
  br label %bb76
bb76:
  br label %bb77
bb77:
  %t286 = load i64, ptr %l18, !tbaa !24
  %t288 = add i64 %t286, 1
  store i64 %t288, ptr %l18, !tbaa !24
  br label %bb72
bb78:
  br label %bb198
bb79:
  %t290 = load ptr, ptr %l1, !tbaa !29
  store ptr %t290, ptr %l177, !tbaa !29
  store i1 false, ptr %l178, !tbaa !21
  %t291 = load ptr, ptr %l177, !tbaa !29
  %t292 = icmp ne ptr %t291, null
  br i1 %t292, label %bb80, label %bb81
bb80:
  %t294 = load ptr, ptr %l177, !tbaa !29
  %t295 = load i64, ptr %t294, !range !{i64 0, i64 18}
  %t297 = icmp eq i64 %t295, 9
  store i1 %t297, ptr %l178, !tbaa !21
  br label %bb81
bb81:
  %t298 = load i1, ptr %l178, !tbaa !21
  br i1 %t298, label %bb82, label %bb83
bb82:
  %t299 = load ptr, ptr %l1, !tbaa !29
  %t301 = getelementptr { i64, [5 x i64] }, ptr %t299, i32 0, i32 1
  %t302 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t301, i32 0, i32 1
  %t303 = load i32, ptr %t302
  store i32 %t303, ptr %l21, !tbaa !23
  %t305 = load ptr, ptr %l1, !tbaa !29
  %t307 = getelementptr { i64, [5 x i64] }, ptr %t305, i32 0, i32 1
  %t308 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t307, i32 0, i32 2
  %t309 = load i32, ptr %t308, !range !{i32 0, i32 43}
  store i32 %t309, ptr %l22
  %t311 = load ptr, ptr %l1, !tbaa !29
  %t313 = getelementptr { i64, [5 x i64] }, ptr %t311, i32 0, i32 1
  %t314 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t313, i32 0, i32 4
  %t315 = load { i64, ptr }, ptr %t314
  store { i64, ptr } %t315, ptr %l23, !tbaa !27
  br label %bb84
bb83:
  br label %bb97
bb84:
  %t317 = load i32, ptr %l22, !range !{i32 0, i32 43}
  %t319 = call i1 @compiler_2ftyped_2ePassesRefs(i32 %t317)
  store i1 %t319, ptr %l188
  br label %bb85
bb85:
  %t320 = load i1, ptr %l188, !tbaa !21
  br i1 %t320, label %bb86, label %bb87
bb86:
  %t321 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t323 = extractvalue { i64, ptr } %t321, 0
  %t325 = icmp sgt i64 %t323, 0
  store i1 %t325, ptr %l189, !tbaa !21
  br label %bb88
bb87:
  store i1 false, ptr %l189, !tbaa !21
  br label %bb88
bb88:
  %t327 = load i1, ptr %l189, !tbaa !21
  br i1 %t327, label %bb89, label %bb90
bb89:
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t329 = load i32, ptr %l21, !tbaa !23
  %t332 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t328, i32 %t329)
  store i1 %t332, ptr %l196
  br label %bb91
bb90:
  store i1 false, ptr %l193, !tbaa !21
  br label %bb92
bb91:
  %t333 = load i1, ptr %l196, !tbaa !21
  store i1 %t333, ptr %l193, !tbaa !21
  br label %bb92
bb92:
  %t334 = load i1, ptr %l193, !tbaa !21
  br i1 %t334, label %bb93, label %bb94
bb93:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t336 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t336, ptr %l198, !tbaa !27
  %t337 = getelementptr { i64, ptr }, ptr %l198, i32 0, i32 1
  %t338 = load ptr, ptr %t337, !tbaa !27
  %t339 = getelementptr ptr, ptr %t338, i64 0
  %t340 = load ptr, ptr %t339, !tbaa !39
  %t342 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t335, ptr %t340, ptr %t342)
  br label %bb95
bb94:
  br label %bb96
bb95:
  br label %bb96
bb96:
  br label %bb198
bb97:
  %t346 = load ptr, ptr %l1, !tbaa !29
  store ptr %t346, ptr %l202, !tbaa !29
  store i1 false, ptr %l203, !tbaa !21
  %t347 = load ptr, ptr %l202, !tbaa !29
  %t348 = icmp ne ptr %t347, null
  br i1 %t348, label %bb98, label %bb99
bb98:
  %t350 = load ptr, ptr %l202, !tbaa !29
  %t351 = load i64, ptr %t350, !range !{i64 0, i64 18}
  %t353 = icmp eq i64 %t351, 11
  store i1 %t353, ptr %l203, !tbaa !21
  br label %bb99
bb99:
  %t354 = load i1, ptr %l203, !tbaa !21
  br i1 %t354, label %bb100, label %bb101
bb100:
  %t355 = load ptr, ptr %l1, !tbaa !29
  %t357 = getelementptr { i64, [5 x i64] }, ptr %t355, i32 0, i32 1
  %t358 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t357, i32 0, i32 2
  %t359 = load ptr, ptr %t358
  store ptr %t359, ptr %l24, !tbaa !29
  br label %bb102
bb101:
  br label %bb105
bb102:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load ptr, ptr %l24, !tbaa !29
  %t364 = getelementptr %"compiler/typed:Cond", ptr %t362, i32 0, i32 1
  %t365 = load ptr, ptr %t364, !tbaa !29
  %t366 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t361, ptr %t365, ptr %t366)
  br label %bb103
bb103:
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t371 = load ptr, ptr %l24, !tbaa !29
  %t373 = getelementptr %"compiler/typed:Cond", ptr %t371, i32 0, i32 2
  %t374 = load ptr, ptr %t373, !tbaa !29
  %t376 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t370, ptr %t374, ptr %t376)
  br label %bb104
bb104:
  br label %bb198
bb105:
  %t380 = load ptr, ptr %l1, !tbaa !29
  store ptr %t380, ptr %l217, !tbaa !29
  store i1 false, ptr %l218, !tbaa !21
  %t381 = load ptr, ptr %l217, !tbaa !29
  %t382 = icmp ne ptr %t381, null
  br i1 %t382, label %bb106, label %bb107
bb106:
  %t384 = load ptr, ptr %l217, !tbaa !29
  %t385 = load i64, ptr %t384, !range !{i64 0, i64 18}
  %t387 = icmp eq i64 %t385, 12
  store i1 %t387, ptr %l218, !tbaa !21
  br label %bb107
bb107:
  %t388 = load i1, ptr %l218, !tbaa !21
  br i1 %t388, label %bb108, label %bb109
bb108:
  %t389 = load ptr, ptr %l1, !tbaa !29
  %t391 = getelementptr { i64, [5 x i64] }, ptr %t389, i32 0, i32 1
  %t392 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t391, i32 0, i32 2
  %t393 = load ptr, ptr %t392
  store ptr %t393, ptr %l25, !tbaa !29
  br label %bb110
bb109:
  br label %bb112
bb110:
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t396 = load ptr, ptr %l25, !tbaa !29
  %t398 = getelementptr %"compiler/typed:Seq", ptr %t396, i32 0, i32 1
  %t399 = load ptr, ptr %t398, !tbaa !29
  %t400 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t395, ptr %t399, ptr %t400)
  br label %bb111
bb111:
  br label %bb198
bb112:
  %t404 = load ptr, ptr %l1, !tbaa !29
  store ptr %t404, ptr %l227, !tbaa !29
  store i1 false, ptr %l228, !tbaa !21
  %t405 = load ptr, ptr %l227, !tbaa !29
  %t406 = icmp ne ptr %t405, null
  br i1 %t406, label %bb113, label %bb114
bb113:
  %t408 = load ptr, ptr %l227, !tbaa !29
  %t409 = load i64, ptr %t408, !range !{i64 0, i64 18}
  %t411 = icmp eq i64 %t409, 13
  store i1 %t411, ptr %l228, !tbaa !21
  br label %bb114
bb114:
  %t412 = load i1, ptr %l228, !tbaa !21
  br i1 %t412, label %bb115, label %bb116
bb115:
  %t413 = load ptr, ptr %l1, !tbaa !29
  %t415 = getelementptr { i64, [5 x i64] }, ptr %t413, i32 0, i32 1
  %t416 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t415, i32 0, i32 2
  %t417 = load ptr, ptr %t416
  store ptr %t417, ptr %l26, !tbaa !29
  br label %bb117
bb116:
  br label %bb132
bb117:
  %t419 = load ptr, ptr %l26, !tbaa !29
  %t421 = getelementptr %"compiler/typed:Match", ptr %t419, i32 0, i32 1
  %t422 = load { i64, ptr }, ptr %t421, !tbaa !27
  store { i64, ptr } %t422, ptr %l27, !tbaa !27
  store i64 0, ptr %l28, !tbaa !24
  %t424 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t426 = extractvalue { i64, ptr } %t424, 0
  store i64 %t426, ptr %l29, !tbaa !24
  br label %bb118
bb118:
  %t428 = load i64, ptr %l28, !tbaa !24
  %t429 = load i64, ptr %l29, !tbaa !24
  %t432 = icmp slt i64 %t428, %t429
  %t434 = xor i1 %t432, true
  br i1 %t434, label %bb119, label %bb120
bb119:
  br label %bb124
bb120:
  br label %bb121
bb121:
  %t436 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t436, ptr %l241, !tbaa !27
  %t437 = load i64, ptr %l28, !tbaa !24
  %t439 = getelementptr { i64, ptr }, ptr %l241, i32 0, i32 1
  %t440 = load ptr, ptr %t439, !tbaa !27
  %t441 = getelementptr ptr, ptr %t440, i64 %t437
  %t442 = load ptr, ptr %t441, !tbaa !39
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t447 = getelementptr %"compiler/typed:Arm", ptr %t442, i32 0, i32 4
  %t448 = load ptr, ptr %t447, !tbaa !29
  %t449 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t444, ptr %t448, ptr %t449)
  br label %bb122
bb122:
  br label %bb123
bb123:
  %t453 = load i64, ptr %l28, !tbaa !24
  %t455 = add i64 %t453, 1
  store i64 %t455, ptr %l28, !tbaa !24
  br label %bb118
bb124:
  %t457 = load ptr, ptr %l26, !tbaa !29
  %t459 = getelementptr %"compiler/typed:Match", ptr %t457, i32 0, i32 2
  %t460 = load ptr, ptr %t459, !tbaa !29
  %t462 = icmp eq ptr %t460, null
  %t464 = xor i1 %t462, true
  br i1 %t464, label %bb125, label %bb126
bb125:
  %t466 = load ptr, ptr %l0, !tbaa !29
  store ptr %t466, ptr %l254, !tbaa !29
  %t467 = load ptr, ptr %l26, !tbaa !29
  %t469 = getelementptr %"compiler/typed:Match", ptr %t467, i32 0, i32 2
  %t470 = load ptr, ptr %t469, !tbaa !29
  %t472 = icmp eq ptr %t470, null
  br i1 %t472, label %bb127, label %bb128
bb126:
  br label %bb131
bb127:
  call void @__olang_check_failed(ptr @olang_loc_9675e93c9f07526d_8a86ee267fb7b3d9)
  unreachable
bb128:
  br label %bb129
bb129:
  %t474 = load ptr, ptr %l26, !tbaa !29
  %t476 = getelementptr %"compiler/typed:Match", ptr %t474, i32 0, i32 2
  %t477 = load ptr, ptr %t476, !tbaa !29
  %t480 = getelementptr %"compiler/typed:Arm", ptr %t477, i32 0, i32 4
  %t481 = load ptr, ptr %t480, !tbaa !29
  %t482 = load ptr, ptr %l2, !tbaa !29
  %t483 = load ptr, ptr %l254, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t483, ptr %t481, ptr %t482)
  br label %bb130
bb130:
  br label %bb131
bb131:
  br label %bb198
bb132:
  %t486 = load ptr, ptr %l1, !tbaa !29
  store ptr %t486, ptr %l263, !tbaa !29
  store i1 false, ptr %l264, !tbaa !21
  %t487 = load ptr, ptr %l263, !tbaa !29
  %t488 = icmp ne ptr %t487, null
  br i1 %t488, label %bb133, label %bb134
bb133:
  %t490 = load ptr, ptr %l263, !tbaa !29
  %t491 = load i64, ptr %t490, !range !{i64 0, i64 18}
  %t493 = icmp eq i64 %t491, 14
  store i1 %t493, ptr %l264, !tbaa !21
  br label %bb134
bb134:
  %t494 = load i1, ptr %l264, !tbaa !21
  br i1 %t494, label %bb135, label %bb136
bb135:
  %t495 = load ptr, ptr %l1, !tbaa !29
  %t497 = getelementptr { i64, [5 x i64] }, ptr %t495, i32 0, i32 1
  %t498 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t497, i32 0, i32 2
  %t499 = load ptr, ptr %t498
  store ptr %t499, ptr %l31, !tbaa !29
  br label %bb137
bb136:
  br label %bb152
bb137:
  %t501 = load ptr, ptr %l0, !tbaa !29
  %t502 = load ptr, ptr %l31, !tbaa !29
  %t504 = getelementptr %"compiler/typed:Try", ptr %t502, i32 0, i32 0
  %t505 = load ptr, ptr %t504, !tbaa !29
  %t506 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t501, ptr %t505, ptr %t506)
  br label %bb138
bb138:
  %t510 = load ptr, ptr %l31, !tbaa !29
  %t512 = getelementptr %"compiler/typed:Try", ptr %t510, i32 0, i32 1
  %t513 = load { i64, ptr }, ptr %t512, !tbaa !27
  store { i64, ptr } %t513, ptr %l32, !tbaa !27
  store i64 0, ptr %l33, !tbaa !24
  %t515 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t517 = extractvalue { i64, ptr } %t515, 0
  store i64 %t517, ptr %l34, !tbaa !24
  br label %bb139
bb139:
  %t519 = load i64, ptr %l33, !tbaa !24
  %t520 = load i64, ptr %l34, !tbaa !24
  %t523 = icmp slt i64 %t519, %t520
  %t525 = xor i1 %t523, true
  br i1 %t525, label %bb140, label %bb141
bb140:
  br label %bb151
bb141:
  br label %bb142
bb142:
  %t527 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t527, ptr %l281, !tbaa !27
  %t528 = load i64, ptr %l33, !tbaa !24
  %t530 = getelementptr { i64, ptr }, ptr %l281, i32 0, i32 1
  %t531 = load ptr, ptr %t530, !tbaa !27
  %t532 = getelementptr ptr, ptr %t531, i64 %t528
  %t533 = load ptr, ptr %t532, !tbaa !39
  %t537 = getelementptr %"compiler/typed:Clause", ptr %t533, i32 0, i32 4
  %t538 = load { i64, ptr }, ptr %t537, !tbaa !27
  store { i64, ptr } %t538, ptr %l36, !tbaa !27
  store i64 0, ptr %l37, !tbaa !24
  %t540 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t542 = extractvalue { i64, ptr } %t540, 0
  store i64 %t542, ptr %l38, !tbaa !24
  br label %bb143
bb143:
  %t544 = load i64, ptr %l37, !tbaa !24
  %t545 = load i64, ptr %l38, !tbaa !24
  %t548 = icmp slt i64 %t544, %t545
  %t550 = xor i1 %t548, true
  br i1 %t550, label %bb144, label %bb145
bb144:
  br label %bb149
bb145:
  br label %bb146
bb146:
  %t552 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t552, ptr %l292, !tbaa !27
  %t553 = load i64, ptr %l37, !tbaa !24
  %t555 = getelementptr { i64, ptr }, ptr %l292, i32 0, i32 1
  %t556 = load ptr, ptr %t555, !tbaa !27
  %t557 = getelementptr ptr, ptr %t556, i64 %t553
  %t558 = load ptr, ptr %t557, !tbaa !39
  %t560 = load ptr, ptr %l0, !tbaa !29
  %t563 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t560, ptr %t558, ptr %t563)
  br label %bb147
bb147:
  br label %bb148
bb148:
  %t567 = load i64, ptr %l37, !tbaa !24
  %t569 = add i64 %t567, 1
  store i64 %t569, ptr %l37, !tbaa !24
  br label %bb143
bb149:
  br label %bb150
bb150:
  %t571 = load i64, ptr %l33, !tbaa !24
  %t573 = add i64 %t571, 1
  store i64 %t573, ptr %l33, !tbaa !24
  br label %bb139
bb151:
  br label %bb198
bb152:
  %t575 = load ptr, ptr %l1, !tbaa !29
  store ptr %t575, ptr %l303, !tbaa !29
  store i1 false, ptr %l304, !tbaa !21
  %t576 = load ptr, ptr %l303, !tbaa !29
  %t577 = icmp ne ptr %t576, null
  br i1 %t577, label %bb153, label %bb154
bb153:
  %t579 = load ptr, ptr %l303, !tbaa !29
  %t580 = load i64, ptr %t579, !range !{i64 0, i64 18}
  %t582 = icmp eq i64 %t580, 17
  store i1 %t582, ptr %l304, !tbaa !21
  br label %bb154
bb154:
  %t583 = load i1, ptr %l304, !tbaa !21
  br i1 %t583, label %bb155, label %bb156
bb155:
  %t584 = load ptr, ptr %l1, !tbaa !29
  %t586 = getelementptr { i64, [5 x i64] }, ptr %t584, i32 0, i32 1
  %t587 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t586, i32 0, i32 2
  %t588 = load ptr, ptr %t587
  store ptr %t588, ptr %l40, !tbaa !29
  br label %bb157
bb156:
  br label %bb159
bb157:
  %t590 = load ptr, ptr %l0, !tbaa !29
  %t591 = load ptr, ptr %l40, !tbaa !29
  %t593 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t590, ptr %t591, ptr %t593)
  br label %bb158
bb158:
  br label %bb198
bb159:
  %t597 = load ptr, ptr %l1, !tbaa !29
  store ptr %t597, ptr %l313, !tbaa !29
  store i1 false, ptr %l314, !tbaa !21
  %t598 = load ptr, ptr %l313, !tbaa !29
  %t599 = icmp ne ptr %t598, null
  br i1 %t599, label %bb160, label %bb161
bb160:
  %t601 = load ptr, ptr %l313, !tbaa !29
  %t602 = load i64, ptr %t601, !range !{i64 0, i64 18}
  %t604 = icmp eq i64 %t602, 15
  store i1 %t604, ptr %l314, !tbaa !21
  br label %bb161
bb161:
  %t605 = load i1, ptr %l314, !tbaa !21
  br i1 %t605, label %bb162, label %bb163
bb162:
  %t606 = load ptr, ptr %l1, !tbaa !29
  %t608 = getelementptr { i64, [5 x i64] }, ptr %t606, i32 0, i32 1
  %t609 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t608, i32 0, i32 2
  %t610 = load ptr, ptr %t609
  store ptr %t610, ptr %l41, !tbaa !29
  br label %bb164
bb163:
  br label %bb193
bb164:
  %t612 = load ptr, ptr %l41, !tbaa !29
  store ptr %t612, ptr %l319, !tbaa !29
  store i1 false, ptr %l320, !tbaa !21
  %t613 = load ptr, ptr %l319, !tbaa !29
  %t614 = icmp ne ptr %t613, null
  br i1 %t614, label %bb165, label %bb166
bb165:
  %t616 = load ptr, ptr %l319, !tbaa !29
  %t617 = load i64, ptr %t616, !range !{i64 0, i64 3}
  %t619 = icmp eq i64 %t617, 1
  store i1 %t619, ptr %l320, !tbaa !21
  br label %bb166
bb166:
  %t620 = load i1, ptr %l320, !tbaa !21
  br i1 %t620, label %bb167, label %bb168
bb167:
  %t621 = load ptr, ptr %l41, !tbaa !29
  %t623 = getelementptr { i64, [4 x i64] }, ptr %t621, i32 0, i32 1
  %t624 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t623, i32 0, i32 1
  %t625 = load { i64, ptr }, ptr %t624
  store { i64, ptr } %t625, ptr %l42, !tbaa !27
  br label %bb169
bb168:
  br label %bb180
bb169:
  %t627 = load ptr, ptr %l0, !tbaa !29
  %t629 = getelementptr %"compiler/scope:Scoper", ptr %t627, i32 0, i32 116
  %t630 = load i1, ptr %t629, !tbaa !21
  %t632 = xor i1 %t630, true
  br i1 %t632, label %bb170, label %bb171
bb170:
  br label %ret
bb171:
  br label %bb172
bb172:
  %t634 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t634, ptr %l43, !tbaa !27
  store i64 0, ptr %l44, !tbaa !24
  %t636 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t638 = extractvalue { i64, ptr } %t636, 0
  store i64 %t638, ptr %l45, !tbaa !24
  br label %bb173
bb173:
  %t640 = load i64, ptr %l44, !tbaa !24
  %t641 = load i64, ptr %l45, !tbaa !24
  %t644 = icmp slt i64 %t640, %t641
  %t646 = xor i1 %t644, true
  br i1 %t646, label %bb174, label %bb175
bb174:
  br label %bb179
bb175:
  br label %bb176
bb176:
  %t648 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t648, ptr %l335, !tbaa !27
  %t649 = load i64, ptr %l44, !tbaa !24
  %t651 = getelementptr { i64, ptr }, ptr %l335, i32 0, i32 1
  %t652 = load ptr, ptr %t651, !tbaa !27
  %t653 = getelementptr ptr, ptr %t652, i64 %t649
  %t654 = load ptr, ptr %t653, !tbaa !39
  %t656 = load ptr, ptr %l0, !tbaa !29
  %t659 = getelementptr %"compiler/typed:Capture", ptr %t654, i32 0, i32 1
  %t660 = load ptr, ptr %t659, !tbaa !29
  %t662 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t656, ptr %t660, ptr %t662)
  br label %bb177
bb177:
  br label %bb178
bb178:
  %t666 = load i64, ptr %l44, !tbaa !24
  %t668 = add i64 %t666, 1
  store i64 %t668, ptr %l44, !tbaa !24
  br label %bb173
bb179:
  br label %bb192
bb180:
  %t670 = load ptr, ptr %l41, !tbaa !29
  store ptr %t670, ptr %l345, !tbaa !29
  store i1 false, ptr %l346, !tbaa !21
  %t671 = load ptr, ptr %l345, !tbaa !29
  %t672 = icmp ne ptr %t671, null
  br i1 %t672, label %bb181, label %bb182
bb181:
  %t674 = load ptr, ptr %l345, !tbaa !29
  %t675 = load i64, ptr %t674, !range !{i64 0, i64 3}
  %t677 = icmp eq i64 %t675, 2
  store i1 %t677, ptr %l346, !tbaa !21
  br label %bb182
bb182:
  %t678 = load i1, ptr %l346, !tbaa !21
  br i1 %t678, label %bb183, label %bb184
bb183:
  %t679 = load ptr, ptr %l41, !tbaa !29
  %t681 = getelementptr { i64, [4 x i64] }, ptr %t679, i32 0, i32 1
  %t682 = getelementptr { i32, ptr, i32 }, ptr %t681, i32 0, i32 1
  %t683 = load ptr, ptr %t682
  store ptr %t683, ptr %l47, !tbaa !29
  br label %bb185
bb184:
  br label %bb187
bb185:
  %t685 = load ptr, ptr %l0, !tbaa !29
  %t686 = load ptr, ptr %l47, !tbaa !29
  %t688 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t685, ptr %t686, ptr %t688)
  br label %bb186
bb186:
  br label %bb192
bb187:
  br i1 true, label %bb188, label %bb189
bb188:
  br label %bb190
bb189:
  br label %bb191
bb190:
  br label %bb192
bb191:
  call void @__olang_check_failed(ptr @olang_loc_768f72a2579754c5_d91cee094dc07e21)
  unreachable
bb192:
  br label %bb198
bb193:
  br i1 true, label %bb194, label %bb195
bb194:
  br label %bb196
bb195:
  br label %bb197
bb196:
  br label %bb198
bb197:
  call void @__olang_check_failed(ptr @olang_loc_15f791c29ca5960e_c2f6ea53b6b5628a)
  unreachable
bb198:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2echoiceOfPlaces(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l17 = alloca i1
  %l19 = alloca i1
  %l24 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %l40 = alloca { i64, ptr }
  %l47 = alloca i1
  %l51 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 11
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Cond", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t23 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %t16, ptr %t20)
  store i1 %t23, ptr %l17
  br label %bb6
bb6:
  %t24 = load i1, ptr %l17, !tbaa !21
  %t25 = xor i1 %t24, true
  br i1 %t25, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb10
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Cond", ptr %t28, i32 0, i32 2
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t35 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %t27, ptr %t31)
  store i1 %t35, ptr %l24
  br label %bb9
bb9:
  %t36 = load i1, ptr %l24, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %l19, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l19, !tbaa !21
  store i1 %t39, ptr %rv
  br label %ret
bb11:
  %t40 = load ptr, ptr %l1, !tbaa !29
  store ptr %t40, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t41 = load ptr, ptr %l26, !tbaa !29
  %t42 = icmp ne ptr %t41, null
  br i1 %t42, label %bb12, label %bb13
bb12:
  %t44 = load ptr, ptr %l26, !tbaa !29
  %t45 = load i64, ptr %t44, !range !{i64 0, i64 18}
  %t47 = icmp eq i64 %t45, 13
  store i1 %t47, ptr %l27, !tbaa !21
  br label %bb13
bb13:
  %t48 = load i1, ptr %l27, !tbaa !21
  br i1 %t48, label %bb14, label %bb15
bb14:
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [5 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t51, i32 0, i32 2
  %t53 = load ptr, ptr %t52
  store ptr %t53, ptr %l3, !tbaa !29
  br label %bb16
bb15:
  br label %bb30
bb16:
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Match", ptr %t55, i32 0, i32 1
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  store { i64, ptr } %t58, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  store i64 %t62, ptr %l6, !tbaa !24
  br label %bb17
bb17:
  %t64 = load i64, ptr %l5, !tbaa !24
  %t65 = load i64, ptr %l6, !tbaa !24
  %t68 = icmp slt i64 %t64, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb18, label %bb19
bb18:
  br label %bb29
bb19:
  br label %bb20
bb20:
  %t72 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t72, ptr %l40, !tbaa !27
  %t73 = load i64, ptr %l5, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr ptr, ptr %t76, i64 %t73
  %t78 = load ptr, ptr %t77, !tbaa !39
  store ptr %t78, ptr %l7, !tbaa !29
  %t80 = load ptr, ptr %l7, !tbaa !29
  %t82 = getelementptr %"compiler/typed:Arm", ptr %t80, i32 0, i32 4
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = icmp eq ptr %t83, null
  %t87 = xor i1 %t85, true
  br i1 %t87, label %bb21, label %bb22
bb21:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load ptr, ptr %l7, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Arm", ptr %t90, i32 0, i32 4
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t96 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %t89, ptr %t93)
  store i1 %t96, ptr %l51
  br label %bb23
bb22:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb24
bb23:
  %t97 = load i1, ptr %l51, !tbaa !21
  %t98 = xor i1 %t97, true
  store i1 %t98, ptr %l47, !tbaa !21
  br label %bb24
bb24:
  %t100 = load i1, ptr %l47, !tbaa !21
  br i1 %t100, label %bb25, label %bb26
bb25:
  store i1 true, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t102 = load i64, ptr %l5, !tbaa !24
  %t104 = add i64 %t102, 1
  store i64 %t104, ptr %l5, !tbaa !24
  br label %bb17
bb29:
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_d9b9c9fdb1541cd0_611f76d9a930dfc4)
  unreachable
bb35:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2econstCopy(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2earenaValue(ptr %v0, ptr %t1, i32 %a2)
  store i1 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i1, ptr %l7, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t11 = load ptr, ptr %l10, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l10, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 2
  store i1 %t17, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l11, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l3, !tbaa !29
  br label %bb9
bb8:
  br label %bb22
bb9:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t30 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %t25, ptr %t26)
  store ptr %t30, ptr %l19
  br label %bb10
bb10:
  %t31 = load ptr, ptr %l19, !tbaa !29
  store ptr %t31, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t33 = load ptr, ptr %l21, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t36 = load ptr, ptr %l21, !tbaa !29
  %t37 = load i64, ptr %t36, !range !{i64 0, i64 18}
  %t39 = icmp eq i64 %t37, 1
  store i1 %t39, ptr %l22, !tbaa !21
  br label %bb12
bb12:
  %t40 = load i1, ptr %l22, !tbaa !21
  br i1 %t40, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_fc2d23a56a9972c4_138c6d588cf96ab0)
  unreachable
bb21:
  %t41 = load i1, ptr %l20, !tbaa !21
  store i1 %t41, ptr %rv
  br label %ret
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  store i1 false, ptr %rv
  br label %ret
bb26:
  call void @__olang_check_failed(ptr @olang_loc_3c97826faaf501b5_26e177716b83aa41)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edestructsAt(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l7 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i1
  %l26 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load i32, ptr %l7, !tbaa !23
  store i32 %t11, ptr %l2, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/scope:Scoper", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %l2, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l12
  br label %bb2
bb2:
  %t22 = load i32, ptr %l12, !range !{i32 0, i32 33}
  %t24 = trunc i64 18 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb3, label %bb4
bb3:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/scope:Scoper", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/generic:Program", ptr %t30, i32 0, i32 2
  %t33 = load i32, ptr %l2, !tbaa !23
  %t36 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t32, i32 %t33)
  store i1 %t36, ptr %l20
  br label %bb5
bb4:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb6
bb5:
  %t37 = load i1, ptr %l20, !tbaa !21
  store i1 %t37, ptr %l15, !tbaa !21
  br label %bb6
bb6:
  %t38 = load i1, ptr %l15, !tbaa !21
  br i1 %t38, label %bb7, label %bb8
bb7:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/scope:Scoper", ptr %t39, i32 0, i32 0
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/generic:Program", ptr %t42, i32 0, i32 2
  %t45 = load i32, ptr %l2, !tbaa !23
  %t48 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t44, i32 %t45)
  store i1 %t48, ptr %l26
  br label %bb9
bb8:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb10
bb9:
  %t49 = load i1, ptr %l26, !tbaa !21
  store i1 %t49, ptr %l21, !tbaa !21
  br label %bb10
bb10:
  %t50 = load i1, ptr %l21, !tbaa !21
  store i1 %t50, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eelemAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca %"compiler/source:Span"
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca ptr
  %l17 = alloca i1
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l43 = alloca i32
  %l51 = alloca i64
  %l54 = alloca i64
  %l76 = alloca { i64, ptr }
  %l85 = alloca %"compiler/source:Span"
  %s1 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 0, i32 0)
  store %"compiler/source:Span" %t5, ptr %l13
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  %t6 = load %"compiler/source:Span", ptr %l13
  store %"compiler/source:Span" %t6, ptr %rv
  br label %ret
bb4:
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t7)
  store %"compiler/source:Span" %t9, ptr %l15
  br label %bb5
bb5:
  %t10 = load %"compiler/source:Span", ptr %l15
  store %"compiler/source:Span" %t10, ptr %l2
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t12 = load ptr, ptr %l16, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l16, !tbaa !29
  %t16 = load i64, ptr %t15, !range !{i64 0, i64 18}
  %t18 = icmp eq i64 %t16, 14
  store i1 %t18, ptr %l17, !tbaa !21
  br label %bb7
bb7:
  %t19 = load i1, ptr %l17, !tbaa !21
  br i1 %t19, label %bb8, label %bb9
bb8:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [5 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t22, i32 0, i32 2
  %t24 = load ptr, ptr %t23
  store ptr %t24, ptr %l3, !tbaa !29
  br label %bb10
bb9:
  br label %bb18
bb10:
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t28 = getelementptr %"compiler/typed:Try", ptr %t26, i32 0, i32 0
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = icmp eq ptr %t29, null
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb11, label %bb12
bb11:
  %t35 = load ptr, ptr %l3, !tbaa !29
  %t37 = getelementptr %"compiler/typed:Try", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = icmp eq ptr %t38, null
  br i1 %t40, label %bb13, label %bb14
bb12:
  br label %bb17
bb13:
  call void @__olang_check_failed(ptr @olang_loc_f7f7e8cd8f874575_c4b9e23387941a21)
  unreachable
bb14:
  br label %bb15
bb15:
  %t42 = load ptr, ptr %l3, !tbaa !29
  %t44 = getelementptr %"compiler/typed:Try", ptr %t42, i32 0, i32 0
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t45)
  store %"compiler/source:Span" %t47, ptr %l31
  br label %bb16
bb16:
  %t48 = load %"compiler/source:Span", ptr %l31
  store %"compiler/source:Span" %t48, ptr %l2
  br label %bb17
bb17:
  br label %bb23
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_fdfd3ee9277a2fdd_9e10cfc7d92600f9)
  unreachable
bb23:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/scope:Scoper", ptr %t49, i32 0, i32 10
  store ptr %t51, ptr %l34, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/scope:Scoper", ptr %t52, i32 0, i32 25
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = icmp eq ptr %t55, null
  br i1 %t57, label %bb24, label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_933cba94e4afba7f_7f3963489057e55b)
  unreachable
bb25:
  br label %bb26
bb26:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/scope:Scoper", ptr %t59, i32 0, i32 25
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t65 = getelementptr %"compiler/typed:Body", ptr %t62, i32 0, i32 3
  %t66 = load i64, ptr %t65, !tbaa !24
  %t67 = load ptr, ptr %l34, !tbaa !29
  %t69 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v0, ptr %t67, i64 %t66)
  %t70 = extractvalue { i32, { i64, ptr } } %t69, 1
  %t71 = extractvalue { i32, { i64, ptr } } %t69, 0
  store i32 %t71, ptr %l43
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb28, label %ok.73, !prof !99
ok.73:
  store { i64, ptr } %t70, ptr %l42
  br label %bb27
bb27:
  %t74 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t74, ptr %l32, !tbaa !27
  br label %bb30
bb28:
  br label %bb29
bb29:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %l32, !tbaa !27
  br label %bb30
bb30:
  %t75 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t75, ptr %l4, !tbaa !27
  %t76 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t77 = load i32, ptr %t76, !tbaa !23
  %t79 = sext i32 %t77 to i64
  store i64 %t79, ptr %l5, !tbaa !24
  %t81 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t82 = load i32, ptr %t81, !tbaa !23
  %t84 = sext i32 %t82 to i64
  store i64 %t84, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t86 = load i64, ptr %l6, !tbaa !24
  %t87 = load i64, ptr %l5, !tbaa !24
  %t90 = icmp sgt i64 %t86, %t87
  br i1 %t90, label %bb31, label %bb32
bb31:
  %t92 = load i64, ptr %l7, !tbaa !24
  %t94 = icmp sgt i64 %t92, 0
  br i1 %t94, label %bb33, label %bb34
bb32:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb36
bb33:
  %t96 = load i64, ptr %l6, !tbaa !24
  %t97 = load i64, ptr %l5, !tbaa !24
  %t100 = sub i64 %t96, %t97
  %t101 = load i64, ptr %l7, !tbaa !24
  %t104 = add i64 %t100, %t101
  %t106 = sub i64 %t104, 1
  %t107 = load i64, ptr %l7, !tbaa !24
  %t110 = sdiv i64 %t106, %t107
  store i64 %t110, ptr %l54, !tbaa !24
  br label %bb35
bb34:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb35
bb35:
  %t112 = load i64, ptr %l54, !tbaa !24
  store i64 %t112, ptr %l51, !tbaa !24
  br label %bb36
bb36:
  %t113 = load i64, ptr %l51, !tbaa !24
  store i64 %t113, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb37
bb37:
  %t114 = load i64, ptr %l9, !tbaa !24
  %t115 = load i64, ptr %l8, !tbaa !24
  %t118 = icmp slt i64 %t114, %t115
  %t120 = xor i1 %t118, true
  br i1 %t120, label %bb38, label %bb39
bb38:
  br label %bb49
bb39:
  br label %bb40
bb40:
  %t122 = load i64, ptr %l5, !tbaa !24
  %t123 = load i64, ptr %l9, !tbaa !24
  %t124 = load i64, ptr %l7, !tbaa !24
  %t127 = mul i64 %t123, %t124
  %t130 = add i64 %t122, %t127
  store i64 %t130, ptr %l10, !tbaa !24
  %t132 = load i64, ptr %l10, !tbaa !24
  %t133 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t133, 0
  %t138 = icmp sge i64 %t132, %t135
  br i1 %t138, label %bb41, label %bb42
bb41:
  br label %bb49
bb42:
  br label %bb43
bb43:
  %t140 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t140, ptr %l76, !tbaa !27
  %t141 = load i64, ptr %l10, !tbaa !24
  %t143 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = getelementptr i8, ptr %t144, i64 %t141
  %t146 = load i8, ptr %t145, !tbaa !32
  %t148 = icmp eq i8 %t146, 91
  br i1 %t148, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s8
  %t150 = load i64, ptr %l10, !tbaa !24
  %t152 = trunc i64 %t150 to i32
  %t153 = load i64, ptr %l10, !tbaa !24
  %t155 = add i64 %t153, 1
  %t157 = trunc i64 %t155 to i32
  %t160 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s8, i32 %t152, i32 %t157)
  store %"compiler/source:Span" %t160, ptr %l85
  br label %bb46
bb45:
  br label %bb47
bb46:
  call void @__olang_scope_close(ptr %s8)
  %t161 = load %"compiler/source:Span", ptr %l85
  store %"compiler/source:Span" %t161, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t162 = load i64, ptr %l9, !tbaa !24
  %t164 = add i64 %t162, 1
  store i64 %t164, ptr %l9, !tbaa !24
  br label %bb37
bb49:
  %t166 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t166, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efieldRec(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, [2 x i64] }
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca { i64, [2 x i64] }
  %l21 = alloca { i64, [2 x i64] }
  %l22 = alloca i64
  %l23 = alloca { i64, [1 x i64] }
  %l24 = alloca i32
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l33 = alloca i32
  %l36 = alloca i1
  %l43 = alloca i32
  %l46 = alloca ptr
  %l49 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l50 = alloca i1
  %l51 = alloca i1
  %l53 = alloca ptr
  %l55 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l56 = alloca i1
  %l60 = alloca i64
  %l64 = alloca { i64, [2 x i64] }
  %l71 = alloca i64
  %l74 = alloca i1
  %l77 = alloca i1
  %l80 = alloca i64
  %l83 = alloca i64
  %l91 = alloca i64
  %l92 = alloca i64
  %l96 = alloca i64
  %l97 = alloca i32
  %l100 = alloca i1
  %l103 = alloca i1
  %l105 = alloca i1
  %l106 = alloca i64
  %l110 = alloca ptr
  %l113 = alloca i64
  %l119 = alloca ptr
  %l123 = alloca i64
  %l130 = alloca ptr
  %l131 = alloca i64
  %l134 = alloca i64
  %l136 = alloca i64
  %l137 = alloca ptr
  %l139 = alloca ptr
  %l143 = alloca i32
  %l145 = alloca %"compiler/typed:Local"
  %l147 = alloca i64
  %l150 = alloca i1
  %l153 = alloca i64
  %l157 = alloca ptr
  %l160 = alloca i64
  %l165 = alloca i64
  %l170 = alloca i64
  %l173 = alloca i64
  %l194 = alloca ptr
  %l200 = alloca { i64, [2 x i64] }
  %l208 = alloca i64
  %l211 = alloca i64
  %l216 = alloca { i64, [1 x i64] }
  %l221 = alloca { i64, [2 x i64] }
  %l227 = alloca i64
  %l231 = alloca i64
  %l234 = alloca i64
  %l255 = alloca i32
  %l263 = alloca i1
  %l266 = alloca i1
  %l269 = alloca i64
  %l272 = alloca i64
  %l279 = alloca { i64, [2 x i64] }
  %s0 = alloca %olang.scope
  %rv = alloca i64
  %t325 = alloca { i64, [2 x i64] }, align 8
  %t334 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t1)
  store i32 %t3, ptr %l33
  br label %bb1
bb1:
  %t4 = load i32, ptr %l33, !tbaa !23
  store i32 %t4, ptr %l3, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l3, !tbaa !23
  %t9 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisStruct(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l36
  br label %bb2
bb2:
  %t10 = load i1, ptr %l36, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/scope:Scoper", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 2
  %t20 = load i32, ptr %l3, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t19, i32 %t20)
  store i32 %t23, ptr %l43
  br label %bb6
bb6:
  %t24 = load i32, ptr %l43, !tbaa !23
  %t25 = sext i32 %t24 to i64
  store i64 %t25, ptr %l4, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/scope:Scoper", ptr %t27, i32 0, i32 47
  store ptr %t29, ptr %l46, !tbaa !29
  %t30 = load i64, ptr %l4, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t34 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t30, i64 %t31)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t34, ptr %l49
  br label %bb7
bb7:
  %t35 = load ptr, ptr %l46, !tbaa !29
  %t36 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l49
  %t37 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t35, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t36)
  store i1 %t37, ptr %l50
  br label %bb8
bb8:
  %t38 = load i1, ptr %l50, !tbaa !21
  br i1 %t38, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb13
bb10:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/scope:Scoper", ptr %t39, i32 0, i32 47
  store ptr %t41, ptr %l53, !tbaa !29
  %t42 = load i64, ptr %l4, !tbaa !24
  %t44 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t42, i64 -1)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t44, ptr %l55
  br label %bb11
bb11:
  %t45 = load ptr, ptr %l53, !tbaa !29
  %t46 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l55
  %t47 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t45, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t46)
  store i1 %t47, ptr %l56
  br label %bb12
bb12:
  %t48 = load i1, ptr %l56, !tbaa !21
  store i1 %t48, ptr %l51, !tbaa !21
  br label %bb13
bb13:
  %t49 = load i1, ptr %l51, !tbaa !21
  br i1 %t49, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t55 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erecOf(ptr %v0, ptr %v1, ptr %t51, ptr %t52)
  store i64 %t55, ptr %l60
  br label %bb17
bb17:
  %t56 = load i64, ptr %l60, !tbaa !24
  store i64 %t56, ptr %l5, !tbaa !24
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load i32, ptr %l3, !tbaa !23
  %t59 = load i64, ptr %l2, !tbaa !24
  %t63 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efieldMark(ptr %v0, ptr %t57, i32 %t58, i64 %t59)
  store { i64, [2 x i64] } %t63, ptr %l64
  br label %bb18
bb18:
  %t64 = load { i64, [2 x i64] }, ptr %l64
  store { i64, [2 x i64] } %t64, ptr %l6
  %t65 = load { i64, [2 x i64] }, ptr %l6
  %t67 = extractvalue { i64, [2 x i64] } %t65, 0
  %t68 = icmp eq i64 %t67, 2
  br i1 %t68, label %bb19, label %bb20
bb19:
  %t70 = getelementptr { i64, [2 x i64] }, ptr %l6, i32 0, i32 1
  %t71 = getelementptr { i32 }, ptr %t70, i32 0, i32 0
  %t72 = load i32, ptr %t71
  store i32 %t72, ptr %l7, !tbaa !23
  br label %bb21
bb20:
  br label %bb34
bb21:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i32, ptr %l3, !tbaa !23
  %t76 = load i32, ptr %l7, !tbaa !23
  %t80 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ectorParamIndex(ptr %v0, ptr %t74, i32 %t75, i32 %t76)
  store i64 %t80, ptr %l71
  br label %bb22
bb22:
  %t81 = load i64, ptr %l71, !tbaa !24
  store i64 %t81, ptr %l8, !tbaa !24
  %t82 = load i64, ptr %l5, !tbaa !24
  %t84 = icmp slt i64 %t82, 0
  br i1 %t84, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb25
bb24:
  %t86 = load i64, ptr %l8, !tbaa !24
  %t88 = icmp slt i64 %t86, 0
  store i1 %t88, ptr %l74, !tbaa !21
  br label %bb25
bb25:
  %t90 = load i1, ptr %l74, !tbaa !21
  br i1 %t90, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb29
bb27:
  %t91 = load i64, ptr %l5, !tbaa !24
  %t92 = load i64, ptr %l8, !tbaa !24
  %t95 = add i64 %t91, %t92
  store i64 %t95, ptr %l80, !tbaa !24
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/scope:Scoper", ptr %t96, i32 0, i32 45
  %t100 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t98)
  store i64 %t100, ptr %l83
  br label %bb28
bb28:
  %t101 = load i64, ptr %l80, !tbaa !24
  %t102 = load i64, ptr %l83, !tbaa !24
  %t103 = icmp sge i64 %t101, %t102
  store i1 %t103, ptr %l77, !tbaa !21
  br label %bb29
bb29:
  %t105 = load i1, ptr %l77, !tbaa !21
  br i1 %t105, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/scope:Scoper", ptr %t107, i32 0, i32 45
  %t110 = load i64, ptr %l5, !tbaa !24
  %t111 = load i64, ptr %l8, !tbaa !24
  %t114 = add i64 %t110, %t111
  %t117 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t109, i64 %t114)
  store i64 %t117, ptr %l91
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s0)
  %t118 = load i64, ptr %l91, !tbaa !24
  store i64 %t118, ptr %rv
  br label %ret
bb34:
  br i1 true, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_a845573c521645ec_3201dcbaaced68)
  unreachable
bb39:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/scope:Scoper", ptr %t119, i32 0, i32 7
  %t122 = load i32, ptr %l3, !tbaa !23
  %t125 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %t121, i32 %t122)
  %t126 = extractvalue { i32, i64 } %t125, 1
  %t127 = extractvalue { i32, i64 } %t125, 0
  store i32 %t127, ptr %l97
  %t128 = icmp ne i32 %t127, 0
  br i1 %t128, label %bb41, label %ok.129, !prof !99
ok.129:
  store i64 %t126, ptr %l96
  br label %bb40
bb40:
  %t130 = load i64, ptr %l96, !tbaa !24
  store i64 %t130, ptr %l92, !tbaa !24
  br label %bb43
bb41:
  br label %bb42
bb42:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l92, !tbaa !24
  br label %bb43
bb43:
  %t131 = load i64, ptr %l92, !tbaa !24
  store i64 %t131, ptr %l9, !tbaa !24
  %t132 = load i64, ptr %l9, !tbaa !24
  %t134 = icmp slt i64 %t132, 0
  br i1 %t134, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l100, !tbaa !21
  br label %bb47
bb45:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load i64, ptr %l9, !tbaa !24
  %t140 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esummed(ptr %v0, ptr %t136, i64 %t137)
  store i1 %t140, ptr %l103
  br label %bb46
bb46:
  %t141 = load i1, ptr %l103, !tbaa !21
  %t142 = xor i1 %t141, true
  store i1 %t142, ptr %l100, !tbaa !21
  br label %bb47
bb47:
  %t144 = load i1, ptr %l100, !tbaa !21
  br i1 %t144, label %bb48, label %bb49
bb48:
  store i1 true, ptr %l105, !tbaa !21
  br label %bb52
bb49:
  %t145 = load i64, ptr %l2, !tbaa !24
  store i64 %t145, ptr %l106, !tbaa !24
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/scope:Scoper", ptr %t146, i32 0, i32 6
  %t149 = load i64, ptr %l9, !tbaa !24
  %t152 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t148, i64 %t149)
  store ptr %t152, ptr %l110
  br label %bb50
bb50:
  %t153 = load ptr, ptr %l110, !tbaa !29
  %t155 = getelementptr %"compiler/scope:summary", ptr %t153, i32 0, i32 12
  %t157 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t155)
  store i64 %t157, ptr %l113
  br label %bb51
bb51:
  %t158 = load i64, ptr %l106, !tbaa !24
  %t159 = load i64, ptr %l113, !tbaa !24
  %t160 = icmp sge i64 %t158, %t159
  store i1 %t160, ptr %l105, !tbaa !21
  br label %bb52
bb52:
  %t162 = load i1, ptr %l105, !tbaa !21
  br i1 %t162, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb54:
  br label %bb55
bb55:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/scope:Scoper", ptr %t164, i32 0, i32 6
  %t167 = load i64, ptr %l9, !tbaa !24
  %t170 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t166, i64 %t167)
  store ptr %t170, ptr %l119
  br label %bb56
bb56:
  %t171 = load ptr, ptr %l119, !tbaa !29
  %t173 = getelementptr %"compiler/scope:summary", ptr %t171, i32 0, i32 12
  %t174 = load i64, ptr %l2, !tbaa !24
  %t177 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t173, i64 %t174)
  store i64 %t177, ptr %l123
  br label %bb57
bb57:
  %t178 = load i64, ptr %l123, !tbaa !24
  store i64 %t178, ptr %l10, !tbaa !24
  %t179 = load i64, ptr %l10, !tbaa !24
  %t181 = icmp slt i64 %t179, 0
  br i1 %t181, label %bb58, label %bb59
bb58:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb59:
  br label %bb60
bb60:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/scope:Scoper", ptr %t184, i32 0, i32 1
  %t187 = load i64, ptr %l9, !tbaa !24
  %t190 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t186, i64 %t187)
  store ptr %t190, ptr %l130
  br label %bb61
bb61:
  %t191 = load ptr, ptr %l130, !tbaa !29
  store ptr %t191, ptr %l11, !tbaa !29
  %t192 = load i64, ptr %l2, !tbaa !24
  store i64 %t192, ptr %l131, !tbaa !24
  %t193 = load ptr, ptr %l11, !tbaa !29
  %t195 = getelementptr %"compiler/typed:Body", ptr %t193, i32 0, i32 10
  %t197 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t195)
  store i64 %t197, ptr %l134
  br label %bb62
bb62:
  %t198 = load i64, ptr %l131, !tbaa !24
  %t199 = load i64, ptr %l134, !tbaa !24
  %t200 = icmp slt i64 %t198, %t199
  br i1 %t200, label %bb63, label %bb64
bb63:
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l137, !tbaa !29
  %t203 = load ptr, ptr %l11, !tbaa !29
  %t205 = getelementptr %"compiler/typed:Body", ptr %t203, i32 0, i32 7
  store ptr %t205, ptr %l139, !tbaa !29
  %t206 = load ptr, ptr %l11, !tbaa !29
  %t208 = getelementptr %"compiler/typed:Body", ptr %t206, i32 0, i32 10
  %t209 = load i64, ptr %l2, !tbaa !24
  %t212 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t208, i64 %t209)
  store i32 %t212, ptr %l143
  br label %bb65
bb64:
  store i64 0, ptr %l136, !tbaa !24
  br label %bb68
bb65:
  %t213 = load i32, ptr %l143, !tbaa !23
  %t214 = sext i32 %t213 to i64
  %t215 = load ptr, ptr %l139, !tbaa !29
  %t217 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t215, i64 %t214)
  store %"compiler/typed:Local" %t217, ptr %l145
  br label %bb66
bb66:
  %t218 = getelementptr %"compiler/typed:Local", ptr %l145, i32 0, i32 2
  %t219 = load i32, ptr %t218, !tbaa !23
  %t220 = load ptr, ptr %l137, !tbaa !29
  %t222 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ectorParams(ptr %v0, ptr %t220, i32 %t219)
  store i64 %t222, ptr %l147
  br label %bb67
bb67:
  %t223 = load i64, ptr %l147, !tbaa !24
  store i64 %t223, ptr %l136, !tbaa !24
  br label %bb68
bb68:
  %t224 = load i64, ptr %l136, !tbaa !24
  store i64 %t224, ptr %l12, !tbaa !24
  %t225 = load i64, ptr %l12, !tbaa !24
  %t227 = icmp eq i64 %t225, 0
  br i1 %t227, label %bb69, label %bb70
bb69:
  store i1 true, ptr %l150, !tbaa !21
  br label %bb73
bb70:
  %t229 = load i64, ptr %l10, !tbaa !24
  %t230 = load i64, ptr %l12, !tbaa !24
  %t233 = add i64 %t229, %t230
  store i64 %t233, ptr %l153, !tbaa !24
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"compiler/scope:Scoper", ptr %t234, i32 0, i32 6
  %t237 = load i64, ptr %l9, !tbaa !24
  %t240 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t236, i64 %t237)
  store ptr %t240, ptr %l157
  br label %bb71
bb71:
  %t241 = load ptr, ptr %l157, !tbaa !29
  %t243 = getelementptr %"compiler/scope:summary", ptr %t241, i32 0, i32 13
  %t245 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t243)
  store i64 %t245, ptr %l160
  br label %bb72
bb72:
  %t246 = load i64, ptr %l153, !tbaa !24
  %t247 = load i64, ptr %l160, !tbaa !24
  %t248 = icmp sgt i64 %t246, %t247
  store i1 %t248, ptr %l150, !tbaa !21
  br label %bb73
bb73:
  %t250 = load i1, ptr %l150, !tbaa !21
  br i1 %t250, label %bb74, label %bb75
bb74:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb75:
  br label %bb76
bb76:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr %"compiler/scope:Scoper", ptr %t252, i32 0, i32 44
  %t256 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t254)
  store i64 %t256, ptr %l165
  br label %bb77
bb77:
  %t257 = load i64, ptr %l165, !tbaa !24
  store i64 %t257, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  %t258 = load i64, ptr %l12, !tbaa !24
  store i64 %t258, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t260 = load i64, ptr %l15, !tbaa !24
  %t261 = load i64, ptr %l14, !tbaa !24
  %t264 = icmp sgt i64 %t260, %t261
  br i1 %t264, label %bb78, label %bb79
bb78:
  %t266 = load i64, ptr %l16, !tbaa !24
  %t268 = icmp sgt i64 %t266, 0
  br i1 %t268, label %bb80, label %bb81
bb79:
  store i64 0, ptr %l170, !tbaa !24
  br label %bb83
bb80:
  %t270 = load i64, ptr %l15, !tbaa !24
  %t271 = load i64, ptr %l14, !tbaa !24
  %t274 = sub i64 %t270, %t271
  %t275 = load i64, ptr %l16, !tbaa !24
  %t278 = add i64 %t274, %t275
  %t280 = sub i64 %t278, 1
  %t281 = load i64, ptr %l16, !tbaa !24
  %t284 = sdiv i64 %t280, %t281
  store i64 %t284, ptr %l173, !tbaa !24
  br label %bb82
bb81:
  store i64 0, ptr %l173, !tbaa !24
  br label %bb82
bb82:
  %t286 = load i64, ptr %l173, !tbaa !24
  store i64 %t286, ptr %l170, !tbaa !24
  br label %bb83
bb83:
  %t287 = load i64, ptr %l170, !tbaa !24
  store i64 %t287, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb84
bb84:
  %t288 = load i64, ptr %l18, !tbaa !24
  %t289 = load i64, ptr %l17, !tbaa !24
  %t292 = icmp slt i64 %t288, %t289
  %t294 = xor i1 %t292, true
  br i1 %t294, label %bb85, label %bb86
bb85:
  br label %bb153
bb86:
  br label %bb87
bb87:
  %t296 = load i64, ptr %l14, !tbaa !24
  %t297 = load i64, ptr %l18, !tbaa !24
  %t298 = load i64, ptr %l16, !tbaa !24
  %t301 = mul i64 %t297, %t298
  %t304 = add i64 %t296, %t301
  store i64 %t304, ptr %l19, !tbaa !24
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t308 = getelementptr %"compiler/scope:Scoper", ptr %t306, i32 0, i32 6
  %t309 = load i64, ptr %l9, !tbaa !24
  %t312 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t308, i64 %t309)
  store ptr %t312, ptr %l194
  br label %bb88
bb88:
  %t313 = load ptr, ptr %l194, !tbaa !29
  %t315 = getelementptr %"compiler/scope:summary", ptr %t313, i32 0, i32 13
  %t316 = load i64, ptr %l10, !tbaa !24
  %t317 = load i64, ptr %l19, !tbaa !24
  %t320 = add i64 %t316, %t317
  %t323 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t315, i64 %t320)
  store { i64, [2 x i64] } %t323, ptr %l200
  br label %bb89
bb89:
  %t324 = load { i64, [2 x i64] }, ptr %l200
  store { i64, [2 x i64] } %t324, ptr %l20
  store { i64, [2 x i64] } zeroinitializer, ptr %t325
  %t326 = getelementptr { i64, [2 x i64] }, ptr %t325, i32 0, i32 0
  store i64 6, ptr %t326
  %t327 = load { i64, [2 x i64] }, ptr %t325
  store { i64, [2 x i64] } %t327, ptr %l21
  %t329 = load { i64, [2 x i64] }, ptr %l20
  %t331 = extractvalue { i64, [2 x i64] } %t329, 0
  %t332 = icmp eq i64 %t331, 3
  br i1 %t332, label %bb90, label %bb91
bb90:
  br label %bb92
bb91:
  br label %bb93
bb92:
  store { i64, [2 x i64] } zeroinitializer, ptr %t334
  %t335 = getelementptr { i64, [2 x i64] }, ptr %t334, i32 0, i32 0
  store i64 3, ptr %t335
  %t336 = load { i64, [2 x i64] }, ptr %t334
  store { i64, [2 x i64] } %t336, ptr %l21
  br label %bb149
bb93:
  %t338 = load { i64, [2 x i64] }, ptr %l20
  %t340 = extractvalue { i64, [2 x i64] } %t338, 0
  %t341 = icmp eq i64 %t340, 2
  br i1 %t341, label %bb94, label %bb95
bb94:
  %t343 = getelementptr { i64, [2 x i64] }, ptr %l20, i32 0, i32 1
  %t344 = getelementptr { i64 }, ptr %t343, i32 0, i32 0
  %t345 = load i64, ptr %t344
  store i64 %t345, ptr %l22, !tbaa !24
  br label %bb96
bb95:
  br label %bb144
bb96:
  %t347 = load i64, ptr %l22, !tbaa !24
  store i64 %t347, ptr %l208, !tbaa !24
  %t348 = load ptr, ptr %l11, !tbaa !29
  %t350 = getelementptr %"compiler/typed:Body", ptr %t348, i32 0, i32 6
  %t352 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t350)
  store i64 %t352, ptr %l211
  br label %bb97
bb97:
  %t353 = load i64, ptr %l208, !tbaa !24
  %t354 = load i64, ptr %l211, !tbaa !24
  %t355 = icmp slt i64 %t353, %t354
  br i1 %t355, label %bb98, label %bb99
bb98:
  %t357 = load ptr, ptr %l11, !tbaa !29
  %t359 = getelementptr %"compiler/typed:Body", ptr %t357, i32 0, i32 6
  %t360 = load i64, ptr %l22, !tbaa !24
  %t363 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t359, i64 %t360)
  store { i64, [1 x i64] } %t363, ptr %l216
  br label %bb100
bb99:
  br label %bb143
bb100:
  %t364 = load { i64, [1 x i64] }, ptr %l216
  store { i64, [1 x i64] } %t364, ptr %l23
  %t365 = load { i64, [1 x i64] }, ptr %l23
  %t367 = extractvalue { i64, [1 x i64] } %t365, 0
  %t368 = icmp eq i64 %t367, 2
  br i1 %t368, label %bb101, label %bb102
bb101:
  br label %bb103
bb102:
  br label %bb105
bb103:
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t371 = load ptr, ptr %l1, !tbaa !29
  %t374 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekPlace(ptr %v0, ptr %v1, ptr %t370, ptr %t371, i1 true)
  store { i64, [2 x i64] } %t374, ptr %l221
  br label %bb104
bb104:
  %t375 = load { i64, [2 x i64] }, ptr %l221
  store { i64, [2 x i64] } %t375, ptr %l21
  br label %bb142
bb105:
  %t376 = load { i64, [1 x i64] }, ptr %l23
  %t378 = extractvalue { i64, [1 x i64] } %t376, 0
  %t379 = icmp eq i64 %t378, 0
  br i1 %t379, label %bb106, label %bb107
bb106:
  %t381 = getelementptr { i64, [1 x i64] }, ptr %l23, i32 0, i32 1
  %t382 = getelementptr { i32 }, ptr %t381, i32 0, i32 0
  %t383 = load i32, ptr %t382
  store i32 %t383, ptr %l24, !tbaa !23
  br label %bb108
bb107:
  br label %bb137
bb108:
  store i64 -1, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  %t385 = load ptr, ptr %l11, !tbaa !29
  %t387 = getelementptr %"compiler/typed:Body", ptr %t385, i32 0, i32 5
  %t389 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t387)
  store i64 %t389, ptr %l227
  br label %bb109
bb109:
  %t390 = load i64, ptr %l227, !tbaa !24
  store i64 %t390, ptr %l27, !tbaa !24
  store i64 1, ptr %l28, !tbaa !24
  %t391 = load i64, ptr %l27, !tbaa !24
  %t392 = load i64, ptr %l26, !tbaa !24
  %t395 = icmp sgt i64 %t391, %t392
  br i1 %t395, label %bb110, label %bb111
bb110:
  %t397 = load i64, ptr %l28, !tbaa !24
  %t399 = icmp sgt i64 %t397, 0
  br i1 %t399, label %bb112, label %bb113
bb111:
  store i64 0, ptr %l231, !tbaa !24
  br label %bb115
bb112:
  %t401 = load i64, ptr %l27, !tbaa !24
  %t402 = load i64, ptr %l26, !tbaa !24
  %t405 = sub i64 %t401, %t402
  %t406 = load i64, ptr %l28, !tbaa !24
  %t409 = add i64 %t405, %t406
  %t411 = sub i64 %t409, 1
  %t412 = load i64, ptr %l28, !tbaa !24
  %t415 = sdiv i64 %t411, %t412
  store i64 %t415, ptr %l234, !tbaa !24
  br label %bb114
bb113:
  store i64 0, ptr %l234, !tbaa !24
  br label %bb114
bb114:
  %t417 = load i64, ptr %l234, !tbaa !24
  store i64 %t417, ptr %l231, !tbaa !24
  br label %bb115
bb115:
  %t418 = load i64, ptr %l231, !tbaa !24
  store i64 %t418, ptr %l29, !tbaa !24
  store i64 0, ptr %l30, !tbaa !24
  br label %bb116
bb116:
  %t419 = load i64, ptr %l30, !tbaa !24
  %t420 = load i64, ptr %l29, !tbaa !24
  %t423 = icmp slt i64 %t419, %t420
  %t425 = xor i1 %t423, true
  br i1 %t425, label %bb117, label %bb118
bb117:
  br label %bb125
bb118:
  br label %bb119
bb119:
  %t427 = load i64, ptr %l26, !tbaa !24
  %t428 = load i64, ptr %l30, !tbaa !24
  %t429 = load i64, ptr %l28, !tbaa !24
  %t432 = mul i64 %t428, %t429
  %t435 = add i64 %t427, %t432
  store i64 %t435, ptr %l31, !tbaa !24
  %t437 = load ptr, ptr %l11, !tbaa !29
  %t439 = getelementptr %"compiler/typed:Body", ptr %t437, i32 0, i32 5
  %t440 = load i64, ptr %l31, !tbaa !24
  %t443 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t439, i64 %t440)
  store i32 %t443, ptr %l255
  br label %bb120
bb120:
  %t444 = load i32, ptr %l24, !tbaa !23
  %t445 = load i32, ptr %l255, !tbaa !23
  %t447 = icmp eq i32 %t445, %t444
  br i1 %t447, label %bb121, label %bb122
bb121:
  %t449 = load i64, ptr %l31, !tbaa !24
  store i64 %t449, ptr %l25, !tbaa !24
  br label %bb123
bb122:
  br label %bb123
bb123:
  br label %bb124
bb124:
  %t451 = load i64, ptr %l30, !tbaa !24
  %t453 = add i64 %t451, 1
  store i64 %t453, ptr %l30, !tbaa !24
  br label %bb116
bb125:
  %t455 = load i64, ptr %l5, !tbaa !24
  %t457 = icmp sge i64 %t455, 0
  br i1 %t457, label %bb126, label %bb127
bb126:
  %t459 = load i64, ptr %l25, !tbaa !24
  %t461 = icmp sge i64 %t459, 0
  store i1 %t461, ptr %l263, !tbaa !21
  br label %bb128
bb127:
  store i1 false, ptr %l263, !tbaa !21
  br label %bb128
bb128:
  %t463 = load i1, ptr %l263, !tbaa !21
  br i1 %t463, label %bb129, label %bb130
bb129:
  %t464 = load i64, ptr %l5, !tbaa !24
  %t465 = load i64, ptr %l25, !tbaa !24
  %t468 = add i64 %t464, %t465
  store i64 %t468, ptr %l269, !tbaa !24
  %t469 = load ptr, ptr %l0, !tbaa !29
  %t471 = getelementptr %"compiler/scope:Scoper", ptr %t469, i32 0, i32 44
  %t473 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t471)
  store i64 %t473, ptr %l272
  br label %bb131
bb130:
  store i1 false, ptr %l266, !tbaa !21
  br label %bb132
bb131:
  %t474 = load i64, ptr %l269, !tbaa !24
  %t475 = load i64, ptr %l272, !tbaa !24
  %t476 = icmp slt i64 %t474, %t475
  store i1 %t476, ptr %l266, !tbaa !21
  br label %bb132
bb132:
  %t478 = load i1, ptr %l266, !tbaa !21
  br i1 %t478, label %bb133, label %bb134
bb133:
  %t479 = load ptr, ptr %l0, !tbaa !29
  %t481 = getelementptr %"compiler/scope:Scoper", ptr %t479, i32 0, i32 44
  %t482 = load i64, ptr %l5, !tbaa !24
  %t483 = load i64, ptr %l25, !tbaa !24
  %t486 = add i64 %t482, %t483
  %t489 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t481, i64 %t486)
  store { i64, [2 x i64] } %t489, ptr %l279
  br label %bb135
bb134:
  br label %bb136
bb135:
  %t490 = load { i64, [2 x i64] }, ptr %l279
  store { i64, [2 x i64] } %t490, ptr %l21
  br label %bb136
bb136:
  br label %bb142
bb137:
  br i1 true, label %bb138, label %bb139
bb138:
  br label %bb140
bb139:
  br label %bb141
bb140:
  br label %bb142
bb141:
  call void @__olang_check_failed(ptr @olang_loc_1acba385e9948a9d_2fa01f36b12cdd39)
  unreachable
bb142:
  br label %bb143
bb143:
  br label %bb149
bb144:
  br i1 true, label %bb145, label %bb146
bb145:
  br label %bb147
bb146:
  br label %bb148
bb147:
  br label %bb149
bb148:
  call void @__olang_check_failed(ptr @olang_loc_c629952a85fc4586_8463807efabcbcc2)
  unreachable
bb149:
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t493 = getelementptr %"compiler/scope:Scoper", ptr %t491, i32 0, i32 44
  %t494 = load { i64, [2 x i64] }, ptr %l21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ePush_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t493, { i64, [2 x i64] } %t494)
  br label %bb150
bb150:
  %t497 = load ptr, ptr %l0, !tbaa !29
  %t499 = getelementptr %"compiler/scope:Scoper", ptr %t497, i32 0, i32 45
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t499, i64 -1)
  br label %bb151
bb151:
  br label %bb152
bb152:
  %t501 = load i64, ptr %l18, !tbaa !24
  %t503 = add i64 %t501, 1
  store i64 %t503, ptr %l18, !tbaa !24
  br label %bb84
bb153:
  %t505 = load i64, ptr %l13, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t505, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efieldTerm(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l10 = alloca i32
  %l13 = alloca i1
  %l17 = alloca { i64, [2 x i64] }
  %l24 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca i1
  %l32 = alloca i64
  %l35 = alloca i1
  %l44 = alloca %"compiler/typed:Local"
  %l49 = alloca i64
  %l52 = alloca ptr
  %l55 = alloca i64
  %l57 = alloca { i64, [2 x i64] }
  %l61 = alloca ptr
  %l64 = alloca i64
  %l66 = alloca { i64, [2 x i64] }
  %l68 = alloca ptr
  %l71 = alloca { i64, [2 x i64] }
  %l73 = alloca ptr
  %l75 = alloca i1
  %l78 = alloca i64
  %l84 = alloca { i64, [2 x i64] }
  %rv = alloca { i64, [2 x i64] }
  %t90 = alloca { i64, [2 x i64] }, align 8
  %t155 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t1)
  store i32 %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load i32, ptr %l10, !tbaa !23
  store i32 %t4, ptr %l3, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l3, !tbaa !23
  %t9 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisStruct(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l13
  br label %bb2
bb2:
  %t10 = load i1, ptr %l13, !tbaa !21
  br i1 %t10, label %bb3, label %bb4
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l3, !tbaa !23
  %t17 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efieldMark(ptr %v0, ptr %t11, i32 %t12, i64 %a2)
  store { i64, [2 x i64] } %t17, ptr %l17
  br label %bb5
bb4:
  br label %bb51
bb5:
  %t18 = load { i64, [2 x i64] }, ptr %l17
  store { i64, [2 x i64] } %t18, ptr %l4
  %t19 = load { i64, [2 x i64] }, ptr %l4
  %t21 = extractvalue { i64, [2 x i64] } %t19, 0
  %t22 = icmp eq i64 %t21, 2
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t25 = getelementptr { i32 }, ptr %t24, i32 0, i32 0
  %t26 = load i32, ptr %t25
  store i32 %t26, ptr %l5, !tbaa !23
  br label %bb8
bb7:
  br label %bb45
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l3, !tbaa !23
  %t30 = load i32, ptr %l5, !tbaa !23
  %t34 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ectorParamIndex(ptr %v0, ptr %t28, i32 %t29, i32 %t30)
  store i64 %t34, ptr %l24
  br label %bb9
bb9:
  %t35 = load i64, ptr %l24, !tbaa !24
  store i64 %t35, ptr %l6, !tbaa !24
  %t36 = load ptr, ptr %l1, !tbaa !29
  store ptr %t36, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t37 = load ptr, ptr %l25, !tbaa !29
  %t38 = icmp ne ptr %t37, null
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t40 = load ptr, ptr %l25, !tbaa !29
  %t41 = load i64, ptr %t40, !range !{i64 0, i64 8}
  %t43 = icmp eq i64 %t41, 2
  store i1 %t43, ptr %l26, !tbaa !21
  br label %bb11
bb11:
  %t44 = load i1, ptr %l26, !tbaa !21
  br i1 %t44, label %bb12, label %bb13
bb12:
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr { i64, [4 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t47, i32 0, i32 2
  %t49 = load ptr, ptr %t48
  store ptr %t49, ptr %l7, !tbaa !29
  br label %bb14
bb13:
  br label %bb27
bb14:
  %t51 = load ptr, ptr %l7, !tbaa !29
  %t53 = call i64 @compiler_2fscope_2eregionLocal(ptr %v1, ptr %t51)
  store i64 %t53, ptr %l32
  br label %bb15
bb15:
  %t54 = load i64, ptr %l32, !tbaa !24
  store i64 %t54, ptr %l8, !tbaa !24
  %t55 = load i64, ptr %l8, !tbaa !24
  %t57 = icmp sge i64 %t55, 0
  br i1 %t57, label %bb16, label %bb17
bb16:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/scope:Scoper", ptr %t59, i32 0, i32 25
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = icmp eq ptr %t62, null
  br i1 %t64, label %bb18, label %bb19
bb17:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb22
bb18:
  call void @__olang_check_failed(ptr @olang_loc_fb66d6a098581c09_2fd4002f8136e06d)
  unreachable
bb19:
  br label %bb20
bb20:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/scope:Scoper", ptr %t66, i32 0, i32 25
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Body", ptr %t69, i32 0, i32 7
  %t73 = load i64, ptr %l8, !tbaa !24
  %t76 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t72, i64 %t73)
  store %"compiler/typed:Local" %t76, ptr %l44
  br label %bb21
bb21:
  %t77 = getelementptr %"compiler/typed:Local", ptr %l44, i32 0, i32 4
  %t78 = load i32, ptr %t77, !range !{i32 0, i32 7}
  %t80 = trunc i64 0 to i32
  %t81 = icmp eq i32 %t78, %t80
  store i1 %t81, ptr %l35, !tbaa !21
  br label %bb22
bb22:
  %t83 = load i1, ptr %l35, !tbaa !21
  br i1 %t83, label %bb23, label %bb24
bb23:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i64, ptr %l8, !tbaa !24
  %t88 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparamIndex(ptr %v0, ptr %t84, i64 %t85)
  store i64 %t88, ptr %l49
  br label %bb25
bb24:
  br label %bb26
bb25:
  %t89 = load i64, ptr %l6, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t90
  %t91 = getelementptr { i64, [2 x i64] }, ptr %t90, i32 0, i32 0
  store i64 4, ptr %t91
  %t92 = load i64, ptr %l49, !tbaa !24
  %t93 = insertvalue { i64, i64 } undef, i64 %t92, 0
  %t95 = insertvalue { i64, i64 } %t93, i64 %t89, 1
  %t96 = getelementptr { i64, [2 x i64] }, ptr %t90, i32 0, i32 1
  store { i64, i64 } %t95, ptr %t96
  %t97 = load { i64, [2 x i64] }, ptr %t90
  store { i64, [2 x i64] } %t97, ptr %rv
  br label %ret
bb26:
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_cd1d16db8329fc51_df7e5714e2c1cec5)
  unreachable
bb32:
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l52, !tbaa !29
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t104 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erecOf(ptr %v0, ptr %v1, ptr %t100, ptr %t101)
  store i64 %t104, ptr %l55
  br label %bb33
bb33:
  %t105 = load i64, ptr %l6, !tbaa !24
  %t106 = load ptr, ptr %l52, !tbaa !29
  %t107 = load i64, ptr %l55, !tbaa !24
  %t109 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erecAt(ptr %v0, ptr %t106, i64 %t107, i64 %t105)
  store { i64, [2 x i64] } %t109, ptr %l57
  br label %bb34
bb34:
  %t110 = load { i64, [2 x i64] }, ptr %l57
  %t112 = extractvalue { i64, [2 x i64] } %t110, 0
  %t113 = icmp eq i64 %t112, 0
  %t115 = xor i1 %t113, true
  br i1 %t115, label %bb35, label %bb36
bb35:
  %t117 = load ptr, ptr %l0, !tbaa !29
  store ptr %t117, ptr %l61, !tbaa !29
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load ptr, ptr %l1, !tbaa !29
  %t122 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erecOf(ptr %v0, ptr %v1, ptr %t118, ptr %t119)
  store i64 %t122, ptr %l64
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t123 = load i64, ptr %l6, !tbaa !24
  %t124 = load ptr, ptr %l61, !tbaa !29
  %t125 = load i64, ptr %l64, !tbaa !24
  %t127 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erecAt(ptr %v0, ptr %t124, i64 %t125, i64 %t123)
  store { i64, [2 x i64] } %t127, ptr %l66
  br label %bb38
bb38:
  %t128 = load { i64, [2 x i64] }, ptr %l66
  store { i64, [2 x i64] } %t128, ptr %rv
  br label %ret
bb39:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/scope:Scoper", ptr %t129, i32 0, i32 87
  store ptr %t131, ptr %l68, !tbaa !29
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load ptr, ptr %l1, !tbaa !29
  %t136 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartsTerm(ptr %v0, ptr %v1, ptr %t132, ptr %t133)
  store { i64, [2 x i64] } %t136, ptr %l71
  br label %bb40
bb40:
  %t137 = load ptr, ptr %l68, !tbaa !29
  %t138 = load { i64, [2 x i64] }, ptr %l71
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ePush_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t137, { i64, [2 x i64] } %t138)
  br label %bb41
bb41:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/scope:Scoper", ptr %t139, i32 0, i32 88
  store ptr %t141, ptr %l73, !tbaa !29
  %t142 = load ptr, ptr %l1, !tbaa !29
  %t144 = call i1 @compiler_2fscope_2ethroughElem(ptr %v1, ptr %t142)
  store i1 %t144, ptr %l75
  br label %bb42
bb42:
  %t145 = load ptr, ptr %l73, !tbaa !29
  %t146 = load i1, ptr %l75, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t145, i1 %t146)
  br label %bb43
bb43:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/scope:Scoper", ptr %t147, i32 0, i32 87
  %t151 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t149)
  store i64 %t151, ptr %l78
  br label %bb44
bb44:
  %t152 = load i64, ptr %l78, !tbaa !24
  %t153 = sub i64 0, %t152
  %t154 = load i64, ptr %l6, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t155
  %t156 = getelementptr { i64, [2 x i64] }, ptr %t155, i32 0, i32 0
  store i64 4, ptr %t156
  %t158 = insertvalue { i64, i64 } undef, i64 %t153, 0
  %t160 = insertvalue { i64, i64 } %t158, i64 %t154, 1
  %t161 = getelementptr { i64, [2 x i64] }, ptr %t155, i32 0, i32 1
  store { i64, i64 } %t160, ptr %t161
  %t162 = load { i64, [2 x i64] }, ptr %t155
  store { i64, [2 x i64] } %t162, ptr %rv
  br label %ret
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_4a18cd046f6561ba_7ee6763527d0100e)
  unreachable
bb50:
  br label %bb51
bb51:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load ptr, ptr %l1, !tbaa !29
  %t168 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartsTerm(ptr %v0, ptr %v1, ptr %t164, ptr %t165)
  store { i64, [2 x i64] } %t168, ptr %l84
  br label %bb52
bb52:
  %t169 = load { i64, [2 x i64] }, ptr %l84
  store { i64, [2 x i64] } %t169, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efitErrorAt(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca %"compiler/msgs:Msg"
  %l5 = alloca { i64, ptr }
  %l8 = alloca i1
  %l10 = alloca { i64, [2 x i64] }
  %l13 = alloca { i64, [2 x i64] }
  %l15 = alloca i1
  %l16 = alloca ptr
  %l18 = alloca %"compiler/source:Span"
  %l21 = alloca %"compiler/msgs:Msg"
  %l22 = alloca %"compiler/msgs:Msg"
  %l23 = alloca %"compiler/msgs:Msg"
  %l24 = alloca i64
  %l25 = alloca %"compiler/msgs:Msg"
  %l30 = alloca i1
  %l33 = alloca i1
  %l37 = alloca %"compiler/msgs:Msg"
  %l41 = alloca %"compiler/msgs:Msg"
  %l45 = alloca i1
  %l49 = alloca i1
  %l52 = alloca i1
  %l54 = alloca { i64, [2 x i64] }
  %l58 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l60 = alloca [24 x i8]
  %l74 = alloca ptr
  %l81 = alloca ptr
  %l90 = alloca %"compiler/typed:Local"
  %l92 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l95 = alloca i64
  %l98 = alloca %"compiler/msgs:Msg"
  %l102 = alloca %"compiler/msgs:Msg"
  %l106 = alloca %"compiler/msgs:Msg"
  %l111 = alloca %"compiler/msgs:Msg"
  %l112 = alloca %"compiler/msgs:Msg"
  %l113 = alloca %"compiler/msgs:Msg"
  %l117 = alloca %"compiler/msgs:Msg"
  %l121 = alloca %"compiler/msgs:Msg"
  %l132 = alloca %"compiler/msgs:Msg"
  %l133 = alloca %"compiler/msgs:Msg"
  %l134 = alloca %"compiler/msgs:Msg"
  %l138 = alloca %"compiler/msgs:Msg"
  %l142 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 74
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/scope:Scoper", ptr %t6, i32 0, i32 78
  %t9 = load { i64, [2 x i64] }, ptr %t8
  store { i64, [2 x i64] } %t9, ptr %l10
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/scope:Scoper", ptr %t10, i32 0, i32 76
  %t13 = load { i64, [2 x i64] }, ptr %t12
  store { i64, [2 x i64] } %t13, ptr %l13
  %t16 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l10, ptr %l13)
  store i1 %t16, ptr %l15
  br label %bb3
bb2:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb4
bb3:
  %t17 = load i1, ptr %l15, !tbaa !21
  store i1 %t17, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l8, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l16, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/scope:Scoper", ptr %t20, i32 0, i32 75
  %t23 = load %"compiler/source:Span", ptr %t22
  store %"compiler/source:Span" %t23, ptr %l18
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/scope:Scoper", ptr %t24, i32 0, i32 77
  %t27 = load i1, ptr %t26, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb6:
  br label %bb13
bb7:
  %t29 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnFuncTooShort(ptr %s1)
  store %"compiler/msgs:Msg" %t29, ptr %l22
  br label %bb9
bb8:
  %t30 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnArgHoldsShort(ptr %s1)
  store %"compiler/msgs:Msg" %t30, ptr %l23
  br label %bb10
bb9:
  %t31 = load %"compiler/msgs:Msg", ptr %l22
  store %"compiler/msgs:Msg" %t31, ptr %l21
  br label %bb11
bb10:
  %t32 = load %"compiler/msgs:Msg", ptr %l23
  store %"compiler/msgs:Msg" %t32, ptr %l21
  br label %bb11
bb11:
  %t33 = load ptr, ptr %l16, !tbaa !29
  %t34 = load %"compiler/source:Span", ptr %l18
  %t35 = load %"compiler/msgs:Msg", ptr %l21
  %t36 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s1, ptr %t33, %"compiler/source:Span" %t34, %"compiler/msgs:Msg" %t35)
  store i64 %t36, ptr %l24
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t37 = load i64, ptr %l24, !tbaa !24
  store i64 %t37, ptr %rv
  br label %ret
bb13:
  %t38 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeMayNotOutlive(ptr %s0)
  store %"compiler/msgs:Msg" %t38, ptr %l25
  br label %bb14
bb14:
  %t39 = load %"compiler/msgs:Msg", ptr %l25
  store %"compiler/msgs:Msg" %t39, ptr %l4
  %t40 = load i64, ptr %l2, !tbaa !24
  %t41 = load i64, ptr @G_2ecompiler_2fscope_2eFitLocal, !tbaa !24
  %t44 = icmp eq i64 %t40, %t41
  br i1 %t44, label %bb15, label %bb16
bb15:
  %t46 = load i1, ptr %l3, !tbaa !21
  br i1 %t46, label %bb17, label %bb18
bb16:
  %t48 = load i64, ptr %l2, !tbaa !24
  %t49 = load i64, ptr @G_2ecompiler_2fscope_2eFitPayload, !tbaa !24
  %t52 = icmp eq i64 %t48, %t49
  br i1 %t52, label %bb27, label %bb28
bb17:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/scope:Scoper", ptr %t54, i32 0, i32 79
  %t57 = load i1, ptr %t56, !tbaa !21
  br i1 %t57, label %bb19, label %bb20
bb18:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb22
bb19:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb21
bb20:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/scope:Scoper", ptr %t59, i32 0, i32 80
  %t62 = load i1, ptr %t61, !tbaa !21
  %t64 = xor i1 %t62, true
  store i1 %t64, ptr %l33, !tbaa !21
  br label %bb21
bb21:
  %t66 = load i1, ptr %l33, !tbaa !21
  store i1 %t66, ptr %l30, !tbaa !21
  br label %bb22
bb22:
  %t67 = load i1, ptr %l30, !tbaa !21
  br i1 %t67, label %bb23, label %bb24
bb23:
  %t68 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReferenceNarrowed(ptr %s0)
  store %"compiler/msgs:Msg" %t68, ptr %l37
  br label %bb25
bb24:
  br label %bb26
bb25:
  %t69 = load %"compiler/msgs:Msg", ptr %l37
  store %"compiler/msgs:Msg" %t69, ptr %l4
  br label %bb26
bb26:
  br label %bb101
bb27:
  %t70 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2ePayloadOutlived(ptr %s0)
  store %"compiler/msgs:Msg" %t70, ptr %l41
  br label %bb29
bb28:
  %t71 = load i64, ptr %l2, !tbaa !24
  %t72 = load i64, ptr @G_2ecompiler_2fscope_2eFitOwn, !tbaa !24
  %t75 = icmp eq i64 %t71, %t72
  br i1 %t75, label %bb30, label %bb31
bb29:
  %t77 = load %"compiler/msgs:Msg", ptr %l41
  store %"compiler/msgs:Msg" %t77, ptr %l4
  br label %bb100
bb30:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb32
bb31:
  %t78 = load i64, ptr %l2, !tbaa !24
  %t79 = load i64, ptr @G_2ecompiler_2fscope_2eFitReturn, !tbaa !24
  %t82 = icmp eq i64 %t78, %t79
  store i1 %t82, ptr %l45, !tbaa !21
  br label %bb32
bb32:
  %t84 = load i1, ptr %l45, !tbaa !21
  br i1 %t84, label %bb33, label %bb34
bb33:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/scope:Scoper", ptr %t85, i32 0, i32 107
  %t88 = load i1, ptr %t87, !tbaa !21
  store i1 %t88, ptr %l49, !tbaa !21
  br label %bb35
bb34:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb35
bb35:
  %t90 = load i1, ptr %l49, !tbaa !21
  br i1 %t90, label %bb36, label %bb37
bb36:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egenElemTerm(ptr %v0, ptr %t91)
  store { i64, [2 x i64] } %t93, ptr %l54
  br label %bb38
bb37:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb39
bb38:
  %t94 = load { i64, [2 x i64] }, ptr %l54
  %t96 = extractvalue { i64, [2 x i64] } %t94, 0
  %t97 = icmp eq i64 %t96, 0
  %t99 = xor i1 %t97, true
  store i1 %t99, ptr %l52, !tbaa !21
  br label %bb39
bb39:
  %t101 = load i1, ptr %l52, !tbaa !21
  br i1 %t101, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s7
  store { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l58, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t102, ptr %l59, !tbaa !27
  %t103 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = mul i64 24, 1
  call void @llvm.memmove.p0.p0.i64(ptr %l60, ptr %t104, i64 %t105, i1 false)
  %t107 = insertvalue { i64, ptr } undef, i64 24, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %l60, 1
  store { i64, ptr } %t108, ptr %l5, !tbaa !27
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/scope:Scoper", ptr %t110, i32 0, i32 25
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = icmp eq ptr %t113, null
  br i1 %t115, label %bb42, label %bb43
bb41:
  %t117 = load i64, ptr %l2, !tbaa !24
  %t118 = load i64, ptr @G_2ecompiler_2fscope_2eFitOwn, !tbaa !24
  %t121 = icmp eq i64 %t117, %t118
  br i1 %t121, label %bb60, label %bb61
bb42:
  call void @__olang_check_failed(ptr @olang_loc_12677068e04dfe45_ab703d1ad408b711)
  unreachable
bb43:
  br label %bb44
bb44:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/scope:Scoper", ptr %t123, i32 0, i32 25
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t129 = getelementptr %"compiler/typed:Body", ptr %t126, i32 0, i32 17
  %t130 = load i1, ptr %t129, !tbaa !21
  %t132 = xor i1 %t130, true
  br i1 %t132, label %bb45, label %bb46
bb45:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/scope:Scoper", ptr %t134, i32 0, i32 0
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t139 = getelementptr %"compiler/generic:Program", ptr %t137, i32 0, i32 0
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t142 = getelementptr %"compiler/load:Loader", ptr %t140, i32 0, i32 3
  %t143 = load ptr, ptr %t142, !tbaa !29
  store ptr %t143, ptr %l74, !tbaa !29
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/scope:Scoper", ptr %t144, i32 0, i32 25
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t149 = icmp eq ptr %t147, null
  br i1 %t149, label %bb47, label %bb48
bb46:
  br label %bb58
bb47:
  call void @__olang_check_failed(ptr @olang_loc_bf00db29bdc1b99e_9dc03d0b43789e0a)
  unreachable
bb48:
  br label %bb49
bb49:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/scope:Scoper", ptr %t151, i32 0, i32 25
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t157 = getelementptr %"compiler/typed:Body", ptr %t154, i32 0, i32 7
  store ptr %t157, ptr %l81, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/scope:Scoper", ptr %t158, i32 0, i32 25
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = icmp eq ptr %t161, null
  br i1 %t163, label %bb50, label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_bf00db29bdc1b99e_9dc03d0b43789e0a)
  unreachable
bb51:
  br label %bb52
bb52:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/scope:Scoper", ptr %t165, i32 0, i32 25
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t171 = getelementptr %"compiler/typed:Body", ptr %t168, i32 0, i32 16
  %t172 = load i32, ptr %t171, !tbaa !23
  %t174 = sext i32 %t172 to i64
  %t175 = load ptr, ptr %l81, !tbaa !29
  %t177 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t175, i64 %t174)
  store %"compiler/typed:Local" %t177, ptr %l90
  br label %bb53
bb53:
  %t178 = getelementptr %"compiler/typed:Local", ptr %l90, i32 0, i32 0
  %t179 = load i32, ptr %t178, !tbaa !23
  %t180 = load ptr, ptr %l74, !tbaa !29
  %t182 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t180, i32 %t179)
  store { i64, ptr } %t182, ptr %l92
  br label %bb54
bb54:
  %t183 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t184 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t185 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t185, 1
  %t187 = extractvalue { i64, ptr } %t185, 0
  %t188 = add i64 %t184, %t187
  %t189 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t190 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t191 = add i64 %t188, %t190
  %t192 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t191)
  call void @olang_textcopy(ptr %t192, ptr %t183, i64 %t184)
  %t193 = getelementptr i8, ptr %t192, i64 %t184
  call void @olang_textcopy(ptr %t193, ptr %t186, i64 %t187)
  %t194 = getelementptr i8, ptr %t193, i64 %t187
  call void @olang_textcopy(ptr %t194, ptr %t189, i64 %t190)
  %t195 = insertvalue { i64, ptr } undef, i64 %t191, 0
  %t196 = insertvalue { i64, ptr } %t195, ptr %t192, 1
  store { i64, ptr } %t196, ptr %l93, !tbaa !27
  %t197 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t197, 0
  %t199 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t200 = extractvalue { i64, ptr } %t199, 0
  store i64 %t200, ptr %l95, !tbaa !24
  %t202 = load i64, ptr %l95, !tbaa !24
  %t203 = icmp eq i64 %t198, %t202
  br i1 %t203, label %bb55, label %bb56
bb55:
  %t205 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !27
  %t207 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = load i64, ptr %l95, !tbaa !24
  %t210 = mul i64 %t209, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t206, ptr %t208, i64 %t210, i1 false)
  br label %bb57
bb56:
  %t211 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t211, ptr %l5, !tbaa !27
  br label %bb57
bb57:
  br label %bb58
bb58:
  %t212 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t214 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenYieldShorter(ptr %s7, ptr %s0, { i64, ptr } %t212)
  store %"compiler/msgs:Msg" %t214, ptr %l98
  br label %bb59
bb59:
  %t215 = load %"compiler/msgs:Msg", ptr %l98
  store %"compiler/msgs:Msg" %t215, ptr %l4
  call void @__olang_scope_close(ptr %s7)
  br label %bb99
bb60:
  %t216 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOwnCannotOutlive(ptr %s0)
  store %"compiler/msgs:Msg" %t216, ptr %l102
  br label %bb62
bb61:
  %t217 = load i64, ptr %l2, !tbaa !24
  %t218 = load i64, ptr @G_2ecompiler_2fscope_2eFitField, !tbaa !24
  %t221 = icmp eq i64 %t217, %t218
  br i1 %t221, label %bb63, label %bb64
bb62:
  %t223 = load %"compiler/msgs:Msg", ptr %l102
  store %"compiler/msgs:Msg" %t223, ptr %l4
  br label %bb98
bb63:
  %t224 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eStoredRefOutlived(ptr %s0)
  store %"compiler/msgs:Msg" %t224, ptr %l106
  br label %bb65
bb64:
  %t225 = load i64, ptr %l2, !tbaa !24
  %t226 = load i64, ptr @G_2ecompiler_2fscope_2eFitElem, !tbaa !24
  %t229 = icmp eq i64 %t225, %t226
  br i1 %t229, label %bb66, label %bb67
bb65:
  %t231 = load %"compiler/msgs:Msg", ptr %l106
  store %"compiler/msgs:Msg" %t231, ptr %l4
  br label %bb97
bb66:
  %t232 = load i1, ptr %l3, !tbaa !21
  br i1 %t232, label %bb68, label %bb69
bb67:
  %t234 = load i64, ptr %l2, !tbaa !24
  %t235 = load i64, ptr @G_2ecompiler_2fscope_2eFitAnyCopy, !tbaa !24
  %t238 = icmp eq i64 %t234, %t235
  br i1 %t238, label %bb73, label %bb74
bb68:
  %t240 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eElemNotInArrayScope(ptr %s0)
  store %"compiler/msgs:Msg" %t240, ptr %l112
  br label %bb70
bb69:
  %t241 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eElemOutlived(ptr %s0)
  store %"compiler/msgs:Msg" %t241, ptr %l113
  br label %bb71
bb70:
  %t242 = load %"compiler/msgs:Msg", ptr %l112
  store %"compiler/msgs:Msg" %t242, ptr %l111
  br label %bb72
bb71:
  %t243 = load %"compiler/msgs:Msg", ptr %l113
  store %"compiler/msgs:Msg" %t243, ptr %l111
  br label %bb72
bb72:
  %t244 = load %"compiler/msgs:Msg", ptr %l111
  store %"compiler/msgs:Msg" %t244, ptr %l4
  br label %bb96
bb73:
  %t245 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyCopyOutlived(ptr %s0)
  store %"compiler/msgs:Msg" %t245, ptr %l117
  br label %bb75
bb74:
  %t246 = load i64, ptr %l2, !tbaa !24
  %t247 = load i64, ptr @G_2ecompiler_2fscope_2eFitGlobal, !tbaa !24
  %t250 = icmp eq i64 %t246, %t247
  br i1 %t250, label %bb76, label %bb77
bb75:
  %t252 = load %"compiler/msgs:Msg", ptr %l117
  store %"compiler/msgs:Msg" %t252, ptr %l4
  br label %bb95
bb76:
  %t253 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eGlobalHoldsShorter(ptr %s0)
  store %"compiler/msgs:Msg" %t253, ptr %l121
  br label %bb78
bb77:
  %t254 = load i64, ptr %l2, !tbaa !24
  %t255 = load i64, ptr @G_2ecompiler_2fscope_2eFitReturn, !tbaa !24
  %t258 = icmp eq i64 %t254, %t255
  br i1 %t258, label %bb79, label %bb80
bb78:
  %t260 = load %"compiler/msgs:Msg", ptr %l121
  store %"compiler/msgs:Msg" %t260, ptr %l4
  br label %bb94
bb79:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/scope:Scoper", ptr %t261, i32 0, i32 25
  %t264 = load ptr, ptr %t263, !tbaa !29
  %t266 = icmp eq ptr %t264, null
  br i1 %t266, label %bb81, label %bb82
bb80:
  %t268 = load i64, ptr %l2, !tbaa !24
  %t269 = load i64, ptr @G_2ecompiler_2fscope_2eFitValue, !tbaa !24
  %t272 = icmp eq i64 %t268, %t269
  br i1 %t272, label %bb89, label %bb90
bb81:
  call void @__olang_check_failed(ptr @olang_loc_2de0ba6211cb93cf_481b942389356f0b)
  unreachable
bb82:
  br label %bb83
bb83:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/scope:Scoper", ptr %t274, i32 0, i32 25
  %t277 = load ptr, ptr %t276, !tbaa !29
  %t280 = getelementptr %"compiler/typed:Body", ptr %t277, i32 0, i32 15
  %t281 = load i1, ptr %t280, !tbaa !21
  br i1 %t281, label %bb84, label %bb85
bb84:
  %t283 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eYieldOwnStorage(ptr %s0)
  store %"compiler/msgs:Msg" %t283, ptr %l133
  br label %bb86
bb85:
  %t284 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnOwnStorage(ptr %s0)
  store %"compiler/msgs:Msg" %t284, ptr %l134
  br label %bb87
bb86:
  %t285 = load %"compiler/msgs:Msg", ptr %l133
  store %"compiler/msgs:Msg" %t285, ptr %l132
  br label %bb88
bb87:
  %t286 = load %"compiler/msgs:Msg", ptr %l134
  store %"compiler/msgs:Msg" %t286, ptr %l132
  br label %bb88
bb88:
  %t287 = load %"compiler/msgs:Msg", ptr %l132
  store %"compiler/msgs:Msg" %t287, ptr %l4
  br label %bb93
bb89:
  %t288 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eValueRefsOutlived(ptr %s0)
  store %"compiler/msgs:Msg" %t288, ptr %l138
  br label %bb91
bb90:
  br label %bb92
bb91:
  %t289 = load %"compiler/msgs:Msg", ptr %l138
  store %"compiler/msgs:Msg" %t289, ptr %l4
  br label %bb92
bb92:
  br label %bb93
bb93:
  br label %bb94
bb94:
  br label %bb95
bb95:
  br label %bb96
bb96:
  br label %bb97
bb97:
  br label %bb98
bb98:
  br label %bb99
bb99:
  br label %bb100
bb100:
  br label %bb101
bb101:
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t292 = load %"compiler/msgs:Msg", ptr %l4
  %t296 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s0, ptr %t290, %"compiler/source:Span" %a1, %"compiler/msgs:Msg" %t292)
  store i64 %t296, ptr %l142
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s0)
  %t297 = load i64, ptr %l142, !tbaa !24
  store i64 %t297, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflBlockOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l16 = alloca { i64, ptr }
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflStmt(ptr %v0, ptr %v1, ptr %a0, ptr %t28)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb4
bb10:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca ptr
  %l12 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l37 = alloca i1
  %l40 = alloca { i64, ptr }
  %l43 = alloca i64
  %l46 = alloca i1
  %l50 = alloca i1
  %l56 = alloca i64
  %l59 = alloca i64
  %l80 = alloca i1
  %l81 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l84 = alloca { i64, ptr }
  %l90 = alloca i64
  %l92 = alloca i64
  %l97 = alloca i64
  %l108 = alloca i64
  %l111 = alloca i64
  %l132 = alloca i1
  %l134 = alloca i1
  %l137 = alloca { i64, ptr }
  %l140 = alloca i1
  %l146 = alloca i64
  %l149 = alloca i64
  %l171 = alloca { i64, ptr }
  %l175 = alloca i64
  %l180 = alloca i1
  %l181 = alloca i1
  %l183 = alloca { i64, ptr }
  %l187 = alloca i1
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  store i64 %t6, ptr %l2, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t10 = icmp eq i64 %t8, 0
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/scope:Scoper", ptr %t12, i32 0, i32 111
  %t15 = load i64, ptr %t14, !tbaa !24
  %t17 = icmp eq i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t23 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisMethodCall(ptr %v0, ptr %v1, ptr %t19, ptr %t20)
  store i1 %t23, ptr %l37
  br label %bb6
bb5:
  br label %bb45
bb6:
  %t24 = load i1, ptr %l37, !tbaa !21
  %t25 = xor i1 %t24, true
  br i1 %t25, label %bb7, label %bb8
bb7:
  br label %ret
bb8:
  br label %bb9
bb9:
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Call", ptr %t27, i32 0, i32 1
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  store { i64, ptr } %t30, ptr %l40, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr ptr, ptr %t32, i64 0
  %t34 = load ptr, ptr %t33, !tbaa !39
  %t37 = call i64 @compiler_2fscope_2eflRootExpr(ptr %v1, ptr %t34)
  store i64 %t37, ptr %l43
  br label %bb10
bb10:
  %t38 = load i64, ptr %l43, !tbaa !24
  store i64 %t38, ptr %l3, !tbaa !24
  %t39 = load i64, ptr %l3, !tbaa !24
  %t41 = icmp slt i64 %t39, 0
  br i1 %t41, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb14
bb12:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/scope:Scoper", ptr %t43, i32 0, i32 108
  %t46 = load i64, ptr %l3, !tbaa !24
  %t49 = call i1 @compiler_2fscope_2eflHas(ptr %v0, ptr %t45, i64 %t46)
  store i1 %t49, ptr %l50
  br label %bb13
bb13:
  %t50 = load i1, ptr %l50, !tbaa !21
  %t51 = xor i1 %t50, true
  store i1 %t51, ptr %l46, !tbaa !21
  br label %bb14
bb14:
  %t53 = load i1, ptr %l46, !tbaa !21
  br i1 %t53, label %bb15, label %bb16
bb15:
  br label %ret
bb16:
  br label %bb17
bb17:
  store i64 1, ptr %l4, !tbaa !24
  %t54 = load i64, ptr %l2, !tbaa !24
  store i64 %t54, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t56 = load i64, ptr %l5, !tbaa !24
  %t57 = load i64, ptr %l4, !tbaa !24
  %t60 = icmp sgt i64 %t56, %t57
  br i1 %t60, label %bb18, label %bb19
bb18:
  %t62 = load i64, ptr %l6, !tbaa !24
  %t64 = icmp sgt i64 %t62, 0
  br i1 %t64, label %bb20, label %bb21
bb19:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb23
bb20:
  %t66 = load i64, ptr %l5, !tbaa !24
  %t67 = load i64, ptr %l4, !tbaa !24
  %t70 = sub i64 %t66, %t67
  %t71 = load i64, ptr %l6, !tbaa !24
  %t74 = add i64 %t70, %t71
  %t76 = sub i64 %t74, 1
  %t77 = load i64, ptr %l6, !tbaa !24
  %t80 = sdiv i64 %t76, %t77
  store i64 %t80, ptr %l59, !tbaa !24
  br label %bb22
bb21:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb22
bb22:
  %t82 = load i64, ptr %l59, !tbaa !24
  store i64 %t82, ptr %l56, !tbaa !24
  br label %bb23
bb23:
  %t83 = load i64, ptr %l56, !tbaa !24
  store i64 %t83, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb24
bb24:
  %t84 = load i64, ptr %l8, !tbaa !24
  %t85 = load i64, ptr %l7, !tbaa !24
  %t88 = icmp slt i64 %t84, %t85
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb25, label %bb26
bb25:
  br label %bb44
bb26:
  br label %bb27
bb27:
  %t92 = load i64, ptr %l4, !tbaa !24
  %t93 = load i64, ptr %l8, !tbaa !24
  %t94 = load i64, ptr %l6, !tbaa !24
  %t97 = mul i64 %t93, %t94
  %t100 = add i64 %t92, %t97
  store i64 %t100, ptr %l9, !tbaa !24
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t104 = load i64, ptr %l9, !tbaa !24
  %t108 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecanKeep(ptr %v0, ptr %v1, ptr %t102, ptr %t103, i64 %t104)
  store i1 %t108, ptr %l80
  br label %bb28
bb28:
  %t109 = load i1, ptr %l80, !tbaa !21
  br i1 %t109, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s7
  %t110 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s7, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t110, ptr %l81
  br label %bb31
bb30:
  br label %bb42
bb31:
  %t111 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l81
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t111, ptr %l10
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load ptr, ptr %l1, !tbaa !29
  %t115 = getelementptr %"compiler/typed:Call", ptr %t113, i32 0, i32 1
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  store { i64, ptr } %t116, ptr %l84, !tbaa !27
  %t117 = load i64, ptr %l9, !tbaa !24
  %t119 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr ptr, ptr %t120, i64 %t117
  %t122 = load ptr, ptr %t121, !tbaa !39
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %s7, ptr %t112, ptr %t122, ptr %l10)
  br label %bb32
bb32:
  store ptr %l10, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb33
bb33:
  %t128 = load i64, ptr %l12, !tbaa !24
  store i64 %t128, ptr %l90, !tbaa !24
  %t129 = load ptr, ptr %l11, !tbaa !29
  %t131 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s7, ptr %t129)
  store i64 %t131, ptr %l92
  br label %bb34
bb34:
  %t132 = load i64, ptr %l90, !tbaa !24
  %t133 = load i64, ptr %l92, !tbaa !24
  %t134 = icmp slt i64 %t132, %t133
  %t136 = xor i1 %t134, true
  br i1 %t136, label %bb35, label %bb36
bb35:
  br label %bb41
bb36:
  br label %bb37
bb37:
  %t138 = load ptr, ptr %l11, !tbaa !29
  %t139 = load i64, ptr %l12, !tbaa !24
  %t142 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s7, ptr %t138, i64 %t139)
  store i64 %t142, ptr %l97
  br label %bb38
bb38:
  %t143 = load i64, ptr %l97, !tbaa !24
  %t144 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflAdd(ptr %v0, ptr %t144, i64 %t143)
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t148 = load i64, ptr %l12, !tbaa !24
  %t150 = add i64 %t148, 1
  store i64 %t150, ptr %l12, !tbaa !24
  br label %bb33
bb41:
  call void @__olang_scope_close(ptr %s7)
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t152 = load i64, ptr %l8, !tbaa !24
  %t154 = add i64 %t152, 1
  store i64 %t154, ptr %l8, !tbaa !24
  br label %bb24
bb44:
  br label %ret
bb45:
  store i64 0, ptr %l14, !tbaa !24
  %t156 = load i64, ptr %l2, !tbaa !24
  store i64 %t156, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t158 = load i64, ptr %l15, !tbaa !24
  %t159 = load i64, ptr %l14, !tbaa !24
  %t162 = icmp sgt i64 %t158, %t159
  br i1 %t162, label %bb46, label %bb47
bb46:
  %t164 = load i64, ptr %l16, !tbaa !24
  %t166 = icmp sgt i64 %t164, 0
  br i1 %t166, label %bb48, label %bb49
bb47:
  store i64 0, ptr %l108, !tbaa !24
  br label %bb51
bb48:
  %t168 = load i64, ptr %l15, !tbaa !24
  %t169 = load i64, ptr %l14, !tbaa !24
  %t172 = sub i64 %t168, %t169
  %t173 = load i64, ptr %l16, !tbaa !24
  %t176 = add i64 %t172, %t173
  %t178 = sub i64 %t176, 1
  %t179 = load i64, ptr %l16, !tbaa !24
  %t182 = sdiv i64 %t178, %t179
  store i64 %t182, ptr %l111, !tbaa !24
  br label %bb50
bb49:
  store i64 0, ptr %l111, !tbaa !24
  br label %bb50
bb50:
  %t184 = load i64, ptr %l111, !tbaa !24
  store i64 %t184, ptr %l108, !tbaa !24
  br label %bb51
bb51:
  %t185 = load i64, ptr %l108, !tbaa !24
  store i64 %t185, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb52
bb52:
  %t186 = load i64, ptr %l18, !tbaa !24
  %t187 = load i64, ptr %l17, !tbaa !24
  %t190 = icmp slt i64 %t186, %t187
  %t192 = xor i1 %t190, true
  br i1 %t192, label %bb53, label %bb54
bb53:
  br label %bb93
bb54:
  br label %bb55
bb55:
  %t194 = load i64, ptr %l14, !tbaa !24
  %t195 = load i64, ptr %l18, !tbaa !24
  %t196 = load i64, ptr %l16, !tbaa !24
  %t199 = mul i64 %t195, %t196
  %t202 = add i64 %t194, %t199
  store i64 %t202, ptr %l19, !tbaa !24
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load ptr, ptr %l1, !tbaa !29
  %t206 = load i64, ptr %l19, !tbaa !24
  %t210 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecanKeep(ptr %v0, ptr %v1, ptr %t204, ptr %t205, i64 %t206)
  store i1 %t210, ptr %l132
  br label %bb56
bb56:
  %t211 = load i1, ptr %l132, !tbaa !21
  %t212 = xor i1 %t211, true
  br i1 %t212, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l134, !tbaa !21
  br label %bb60
bb58:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load ptr, ptr %l1, !tbaa !29
  %t217 = getelementptr %"compiler/typed:Call", ptr %t215, i32 0, i32 1
  %t218 = load { i64, ptr }, ptr %t217, !tbaa !27
  store { i64, ptr } %t218, ptr %l137, !tbaa !27
  %t219 = load i64, ptr %l19, !tbaa !24
  %t221 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t222 = load ptr, ptr %t221, !tbaa !27
  %t223 = getelementptr ptr, ptr %t222, i64 %t219
  %t224 = load ptr, ptr %t223, !tbaa !39
  %t227 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarries(ptr %v0, ptr %v1, ptr %t214, ptr %t224)
  store i1 %t227, ptr %l140
  br label %bb59
bb59:
  %t228 = load i1, ptr %l140, !tbaa !21
  %t229 = xor i1 %t228, true
  store i1 %t229, ptr %l134, !tbaa !21
  br label %bb60
bb60:
  %t231 = load i1, ptr %l134, !tbaa !21
  br i1 %t231, label %bb61, label %bb62
bb61:
  br label %bb92
bb62:
  br label %bb63
bb63:
  store i64 0, ptr %l20, !tbaa !24
  %t232 = load i64, ptr %l2, !tbaa !24
  store i64 %t232, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t234 = load i64, ptr %l21, !tbaa !24
  %t235 = load i64, ptr %l20, !tbaa !24
  %t238 = icmp sgt i64 %t234, %t235
  br i1 %t238, label %bb64, label %bb65
bb64:
  %t240 = load i64, ptr %l22, !tbaa !24
  %t242 = icmp sgt i64 %t240, 0
  br i1 %t242, label %bb66, label %bb67
bb65:
  store i64 0, ptr %l146, !tbaa !24
  br label %bb69
bb66:
  %t244 = load i64, ptr %l21, !tbaa !24
  %t245 = load i64, ptr %l20, !tbaa !24
  %t248 = sub i64 %t244, %t245
  %t249 = load i64, ptr %l22, !tbaa !24
  %t252 = add i64 %t248, %t249
  %t254 = sub i64 %t252, 1
  %t255 = load i64, ptr %l22, !tbaa !24
  %t258 = sdiv i64 %t254, %t255
  store i64 %t258, ptr %l149, !tbaa !24
  br label %bb68
bb67:
  store i64 0, ptr %l149, !tbaa !24
  br label %bb68
bb68:
  %t260 = load i64, ptr %l149, !tbaa !24
  store i64 %t260, ptr %l146, !tbaa !24
  br label %bb69
bb69:
  %t261 = load i64, ptr %l146, !tbaa !24
  store i64 %t261, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb70
bb70:
  %t262 = load i64, ptr %l24, !tbaa !24
  %t263 = load i64, ptr %l23, !tbaa !24
  %t266 = icmp slt i64 %t262, %t263
  %t268 = xor i1 %t266, true
  br i1 %t268, label %bb71, label %bb72
bb71:
  br label %bb91
bb72:
  br label %bb73
bb73:
  %t270 = load i64, ptr %l20, !tbaa !24
  %t271 = load i64, ptr %l24, !tbaa !24
  %t272 = load i64, ptr %l22, !tbaa !24
  %t275 = mul i64 %t271, %t272
  %t278 = add i64 %t270, %t275
  store i64 %t278, ptr %l25, !tbaa !24
  %t280 = load i64, ptr %l25, !tbaa !24
  %t281 = load i64, ptr %l19, !tbaa !24
  %t284 = icmp eq i64 %t280, %t281
  br i1 %t284, label %bb74, label %bb75
bb74:
  br label %bb90
bb75:
  br label %bb76
bb76:
  %t286 = load ptr, ptr %l1, !tbaa !29
  %t288 = getelementptr %"compiler/typed:Call", ptr %t286, i32 0, i32 1
  %t289 = load { i64, ptr }, ptr %t288, !tbaa !27
  store { i64, ptr } %t289, ptr %l171, !tbaa !27
  %t290 = load i64, ptr %l25, !tbaa !24
  %t292 = getelementptr { i64, ptr }, ptr %l171, i32 0, i32 1
  %t293 = load ptr, ptr %t292, !tbaa !27
  %t294 = getelementptr ptr, ptr %t293, i64 %t290
  %t295 = load ptr, ptr %t294, !tbaa !39
  %t298 = call i64 @compiler_2fscope_2eflRootExpr(ptr %v1, ptr %t295)
  store i64 %t298, ptr %l175
  br label %bb77
bb77:
  %t299 = load i64, ptr %l175, !tbaa !24
  store i64 %t299, ptr %l26, !tbaa !24
  %t300 = load i64, ptr %l26, !tbaa !24
  %t302 = icmp slt i64 %t300, 0
  br i1 %t302, label %bb78, label %bb79
bb78:
  br label %bb90
bb79:
  br label %bb80
bb80:
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t305 = load i64, ptr %l26, !tbaa !24
  %t308 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eoutside(ptr %v0, ptr %t304, i64 %t305)
  store i1 %t308, ptr %l180
  br label %bb81
bb81:
  %t309 = load i1, ptr %l180, !tbaa !21
  br i1 %t309, label %bb82, label %bb83
bb82:
  store i1 true, ptr %l181, !tbaa !21
  br label %bb85
bb83:
  %t310 = load ptr, ptr %l1, !tbaa !29
  %t312 = getelementptr %"compiler/typed:Call", ptr %t310, i32 0, i32 1
  %t313 = load { i64, ptr }, ptr %t312, !tbaa !27
  store { i64, ptr } %t313, ptr %l183, !tbaa !27
  %t314 = load i64, ptr %l25, !tbaa !24
  %t316 = getelementptr { i64, ptr }, ptr %l183, i32 0, i32 1
  %t317 = load ptr, ptr %t316, !tbaa !27
  %t318 = getelementptr ptr, ptr %t317, i64 %t314
  %t319 = load ptr, ptr %t318, !tbaa !39
  %t322 = call i1 @compiler_2fscope_2eflThroughRefExpr(ptr %v1, ptr %t319)
  store i1 %t322, ptr %l187
  br label %bb84
bb84:
  %t323 = load i1, ptr %l187, !tbaa !21
  store i1 %t323, ptr %l181, !tbaa !21
  br label %bb85
bb85:
  %t324 = load i1, ptr %l181, !tbaa !21
  br i1 %t324, label %bb86, label %bb87
bb86:
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t327 = getelementptr %"compiler/scope:Scoper", ptr %t325, i32 0, i32 110
  store i1 true, ptr %t327, !tbaa !21
  br label %ret
bb87:
  br label %bb88
bb88:
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t329 = load i64, ptr %l26, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflAdd(ptr %v0, ptr %t328, i64 %t329)
  br label %bb89
bb89:
  br label %bb90
bb90:
  %t332 = load i64, ptr %l24, !tbaa !24
  %t334 = add i64 %t332, 1
  store i64 %t334, ptr %l24, !tbaa !24
  br label %bb70
bb91:
  br label %bb92
bb92:
  %t336 = load i64, ptr %l18, !tbaa !24
  %t338 = add i64 %t336, 1
  store i64 %t338, ptr %l18, !tbaa !24
  br label %bb52
bb93:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efnValues(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/scope:fnUse"
  %l4 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca { i64, [3 x i64] }
  %l6 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca %"compiler/scope:rel"
  %l15 = alloca { i64, [2 x i64] }
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca %"compiler/scope:rel"
  %l20 = alloca { i64, [2 x i64] }
  %l21 = alloca i64
  %l22 = alloca { i64, [1 x i64] }
  %l23 = alloca i32
  %l24 = alloca i32
  %l27 = alloca i64
  %l29 = alloca i64
  %l34 = alloca %"compiler/scope:fnUse"
  %l38 = alloca ptr
  %l42 = alloca i64
  %l56 = alloca i1
  %l61 = alloca i32
  %l66 = alloca i32
  %l71 = alloca i32
  %l74 = alloca { i64, ptr }
  %l78 = alloca ptr
  %l81 = alloca ptr
  %l86 = alloca i32
  %l87 = alloca i32
  %l88 = alloca { i64, ptr }
  %l92 = alloca ptr
  %l93 = alloca { i64, [3 x i64] }
  %l95 = alloca %"compiler/msgs:Msg"
  %l96 = alloca i64
  %l100 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l105 = alloca i32
  %l109 = alloca ptr
  %l110 = alloca { i64, [3 x i64] }
  %l116 = alloca { i64, ptr }
  %l117 = alloca { i64, ptr }
  %l119 = alloca i64
  %l121 = alloca i64
  %l122 = alloca i64
  %l127 = alloca %"compiler/msgs:Msg"
  %l128 = alloca i64
  %l129 = alloca { i64, ptr }
  %l130 = alloca { i64, ptr }
  %l131 = alloca i64
  %l132 = alloca { i64, ptr }
  %l136 = alloca ptr
  %l142 = alloca i64
  %l146 = alloca i64
  %l148 = alloca i64
  %l153 = alloca %"compiler/scope:rel"
  %l159 = alloca i1
  %l163 = alloca { i64, [1 x i64] }
  %l170 = alloca i64
  %l172 = alloca i64
  %l177 = alloca %"compiler/scope:rel"
  %l185 = alloca { i64, [1 x i64] }
  %l190 = alloca i1
  %l194 = alloca ptr
  %l199 = alloca %"compiler/typed:Local"
  %l201 = alloca { i64, ptr }
  %l202 = alloca { i64, ptr }
  %l204 = alloca i64
  %l206 = alloca i64
  %l207 = alloca { i64, ptr }
  %l212 = alloca i1
  %l213 = alloca i1
  %l219 = alloca ptr
  %l224 = alloca %"compiler/typed:Local"
  %l226 = alloca { i64, ptr }
  %l227 = alloca { i64, ptr }
  %l229 = alloca i64
  %l231 = alloca i64
  %l232 = alloca { i64, ptr }
  %l242 = alloca ptr
  %l243 = alloca { i64, [3 x i64] }
  %l245 = alloca %"compiler/msgs:Msg"
  %l246 = alloca i64
  %l250 = alloca ptr
  %l251 = alloca { i64, [3 x i64] }
  %l253 = alloca i1
  %l255 = alloca %"compiler/msgs:Msg"
  %l257 = alloca %"compiler/msgs:Msg"
  %l258 = alloca %"compiler/msgs:Msg"
  %l259 = alloca i64
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %t51 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 83
  store ptr %t3, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l27, !tbaa !24
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnUse_3e_2eLen_3ccompiler_2fscope_3afnUse_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l29
  br label %bb2
bb2:
  %t9 = load i64, ptr %l27, !tbaa !24
  %t10 = load i64, ptr %l29, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb145
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = call %"compiler/scope:fnUse" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnUse_3e_2eAt_3ccompiler_2fscope_3afnUse_3e(ptr %v0, ptr %t15, i64 %t16)
  store %"compiler/scope:fnUse" %t19, ptr %l34
  br label %bb6
bb6:
  %t20 = load %"compiler/scope:fnUse", ptr %l34
  store %"compiler/scope:fnUse" %t20, ptr %l3
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/scope:Scoper", ptr %t21, i32 0, i32 6
  %t24 = getelementptr %"compiler/scope:fnUse", ptr %l3, i32 0, i32 2
  %t25 = load i64, ptr %t24, !tbaa !24
  %t28 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t23, i64 %t25)
  store ptr %t28, ptr %l38
  br label %bb7
bb7:
  %t29 = load ptr, ptr %l38, !tbaa !29
  %t31 = getelementptr %"compiler/scope:summary", ptr %t29, i32 0, i32 0
  %t32 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t31
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %l4
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %l4)
  store i64 %t35, ptr %l42
  br label %bb8
bb8:
  %t36 = load i64, ptr %l42, !tbaa !24
  %t37 = icmp eq i64 %t36, 0
  br i1 %t37, label %bb9, label %bb10
bb9:
  br label %bb144
bb10:
  br label %bb11
bb11:
  %t39 = getelementptr %"compiler/scope:fnUse", ptr %l3, i32 0, i32 0
  %t40 = load i64, ptr %t39, !tbaa !24
  %t41 = getelementptr %"compiler/scope:fnUse", ptr %l3, i32 0, i32 1
  %t42 = getelementptr %"compiler/source:Span", ptr %t41, i32 0, i32 0
  %t43 = load i32, ptr %t42, !tbaa !23
  %t45 = sext i32 %t43 to i64
  %t46 = getelementptr %"compiler/scope:fnUse", ptr %l3, i32 0, i32 1
  %t47 = getelementptr %"compiler/source:Span", ptr %t46, i32 0, i32 1
  %t48 = load i32, ptr %t47, !tbaa !23
  %t50 = sext i32 %t48 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t51
  %t52 = getelementptr { i64, [3 x i64] }, ptr %t51, i32 0, i32 0
  store i64 3, ptr %t52
  %t54 = insertvalue { i64, i64, i64 } undef, i64 %t40, 0
  %t56 = insertvalue { i64, i64, i64 } %t54, i64 %t45, 1
  %t58 = insertvalue { i64, i64, i64 } %t56, i64 %t50, 2
  %t59 = getelementptr { i64, [3 x i64] }, ptr %t51, i32 0, i32 1
  store { i64, i64, i64 } %t58, ptr %t59
  %t60 = load { i64, [3 x i64] }, ptr %t51
  store { i64, [3 x i64] } %t60, ptr %l5
  %t62 = getelementptr %"compiler/scope:fnUse", ptr %l3, i32 0, i32 3
  %t63 = load i64, ptr %t62, !tbaa !24
  %t64 = load i64, ptr @G_2ecompiler_2fscope_2eFnCall, !tbaa !24
  %t67 = icmp eq i64 %t63, %t64
  br i1 %t67, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t69 = getelementptr %"compiler/scope:fnUse", ptr %l3, i32 0, i32 4
  %t70 = load i32, ptr %t69, !tbaa !23
  store i32 %t70, ptr %l6, !tbaa !23
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i32, ptr %l6, !tbaa !23
  %t76 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t72, i32 %t73)
  store i1 %t76, ptr %l56
  br label %bb14
bb13:
  %t77 = getelementptr %"compiler/scope:fnUse", ptr %l3, i32 0, i32 3
  %t78 = load i64, ptr %t77, !tbaa !24
  %t79 = load i64, ptr @G_2ecompiler_2fscope_2eFnNamed, !tbaa !24
  %t82 = icmp eq i64 %t78, %t79
  br i1 %t82, label %bb29, label %bb30
bb14:
  %t84 = load i1, ptr %l56, !tbaa !21
  br i1 %t84, label %bb15, label %bb16
bb15:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/scope:Scoper", ptr %t85, i32 0, i32 0
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Program", ptr %t88, i32 0, i32 2
  %t91 = load i32, ptr %l6, !tbaa !23
  %t94 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t90, i32 %t91)
  store i32 %t94, ptr %l61
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t95 = load i32, ptr %l61, !tbaa !23
  store i32 %t95, ptr %l6, !tbaa !23
  br label %bb18
bb18:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/scope:Scoper", ptr %t96, i32 0, i32 0
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/generic:Program", ptr %t99, i32 0, i32 2
  %t102 = load i32, ptr %l6, !tbaa !23
  %t105 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t101, i32 %t102)
  store i32 %t105, ptr %l66
  br label %bb19
bb19:
  %t106 = load i32, ptr %l66, !tbaa !23
  store i32 %t106, ptr %l6, !tbaa !23
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/scope:Scoper", ptr %t107, i32 0, i32 0
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/generic:Program", ptr %t110, i32 0, i32 2
  %t113 = load i32, ptr %l6, !tbaa !23
  %t116 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t112, i32 %t113)
  store i32 %t116, ptr %l71
  br label %bb20
bb20:
  %t117 = load i32, ptr %l71, !range !{i32 0, i32 33}
  %t119 = trunc i64 18 to i32
  %t120 = icmp eq i32 %t117, %t119
  br i1 %t120, label %bb21, label %bb22
bb21:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/scope:Scoper", ptr %t122, i32 0, i32 0
  %t125 = load ptr, ptr %t124, !tbaa !29
  %t127 = getelementptr %"compiler/generic:Program", ptr %t125, i32 0, i32 0
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t130 = getelementptr %"compiler/load:Loader", ptr %t128, i32 0, i32 3
  %t131 = load ptr, ptr %t130, !tbaa !29
  store ptr %t131, ptr %l78, !tbaa !29
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/scope:Scoper", ptr %t132, i32 0, i32 0
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t137 = getelementptr %"compiler/generic:Program", ptr %t135, i32 0, i32 2
  store ptr %t137, ptr %l81, !tbaa !29
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/scope:Scoper", ptr %t138, i32 0, i32 0
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t143 = getelementptr %"compiler/generic:Program", ptr %t141, i32 0, i32 2
  %t144 = load i32, ptr %l6, !tbaa !23
  %t147 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t143, i32 %t144)
  store i32 %t147, ptr %l86
  br label %bb23
bb22:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l74, !tbaa !27
  br label %bb26
bb23:
  %t148 = load ptr, ptr %l81, !tbaa !29
  %t149 = load i32, ptr %l86, !tbaa !23
  %t150 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t148, i32 %t149)
  store i32 %t150, ptr %l87
  br label %bb24
bb24:
  %t151 = load ptr, ptr %l78, !tbaa !29
  %t152 = load i32, ptr %l87, !tbaa !23
  %t153 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t151, i32 %t152)
  store { i64, ptr } %t153, ptr %l88
  br label %bb25
bb25:
  %t154 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t154, ptr %l74, !tbaa !27
  br label %bb26
bb26:
  %t155 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/scope:Scoper", ptr %t156, i32 0, i32 0
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t161 = getelementptr %"compiler/generic:Program", ptr %t159, i32 0, i32 0
  %t162 = load ptr, ptr %t161, !tbaa !29
  %t164 = getelementptr %"compiler/load:Loader", ptr %t162, i32 0, i32 4
  %t165 = load ptr, ptr %t164, !tbaa !29
  store ptr %t165, ptr %l92, !tbaa !29
  %t166 = load { i64, [3 x i64] }, ptr %l5
  store { i64, [3 x i64] } %t166, ptr %l93
  %t169 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCallValueObligations(ptr %v0, ptr %s4, { i64, ptr } %t155)
  store %"compiler/msgs:Msg" %t169, ptr %l95
  br label %bb27
bb27:
  %t170 = load ptr, ptr %l92, !tbaa !29
  %t171 = load { i64, [3 x i64] }, ptr %l93
  %t172 = load %"compiler/msgs:Msg", ptr %l95
  %t173 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s4, ptr %t170, { i64, [3 x i64] } %t171, %"compiler/msgs:Msg" %t172)
  store i64 %t173, ptr %l96
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s4)
  br label %bb143
bb29:
  store %olang.scope zeroinitializer, ptr %s7
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/scope:Scoper", ptr %t174, i32 0, i32 10
  %t177 = getelementptr %"compiler/scope:fnUse", ptr %l3, i32 0, i32 0
  %t178 = load i64, ptr %t177, !tbaa !24
  %t181 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v0, ptr %t176, i64 %t178)
  %t182 = extractvalue { i32, { i64, ptr } } %t181, 1
  %t183 = extractvalue { i32, { i64, ptr } } %t181, 0
  store i32 %t183, ptr %l105
  %t184 = icmp ne i32 %t183, 0
  br i1 %t184, label %bb32, label %ok.185, !prof !99
ok.185:
  store { i64, ptr } %t182, ptr %l104
  br label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s8
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l129, !tbaa !27
  %t186 = load { i64, ptr }, ptr %l129, !tbaa !27
  store { i64, ptr } %t186, ptr %l130, !tbaa !27
  %t187 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t187, 0
  store i64 %t188, ptr %l131, !tbaa !24
  %t189 = load i64, ptr %l131, !tbaa !24
  %t190 = mul i64 %t189, 1
  %t191 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t190)
  %t192 = insertvalue { i64, ptr } undef, i64 %t189, 0
  %t193 = insertvalue { i64, ptr } %t192, ptr %t191, 1
  store { i64, ptr } %t193, ptr %l132, !tbaa !27
  %t194 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !27
  %t196 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !27
  %t198 = load i64, ptr %l131, !tbaa !24
  %t199 = mul i64 %t198, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t195, ptr %t197, i64 %t199, i1 false)
  %t200 = load { i64, ptr }, ptr %l132, !tbaa !27
  store { i64, ptr } %t200, ptr %l9, !tbaa !27
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/scope:Scoper", ptr %t201, i32 0, i32 1
  %t204 = getelementptr %"compiler/scope:fnUse", ptr %l3, i32 0, i32 2
  %t205 = load i64, ptr %t204, !tbaa !24
  %t208 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t203, i64 %t205)
  store ptr %t208, ptr %l136
  br label %bb46
bb31:
  %t209 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t209, ptr %l100, !tbaa !27
  br label %bb34
bb32:
  br label %bb33
bb33:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %l100, !tbaa !27
  br label %bb34
bb34:
  %t210 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t210, ptr %l8, !tbaa !27
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/scope:Scoper", ptr %t211, i32 0, i32 0
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t216 = getelementptr %"compiler/generic:Program", ptr %t214, i32 0, i32 0
  %t217 = load ptr, ptr %t216, !tbaa !29
  %t219 = getelementptr %"compiler/load:Loader", ptr %t217, i32 0, i32 4
  %t220 = load ptr, ptr %t219, !tbaa !29
  store ptr %t220, ptr %l109, !tbaa !29
  %t221 = load { i64, [3 x i64] }, ptr %l5
  store { i64, [3 x i64] } %t221, ptr %l110
  %t222 = getelementptr %"compiler/scope:fnUse", ptr %l3, i32 0, i32 1
  %t223 = getelementptr %"compiler/source:Span", ptr %t222, i32 0, i32 1
  %t224 = load i32, ptr %t223, !tbaa !23
  %t226 = sext i32 %t224 to i64
  %t227 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t229 = extractvalue { i64, ptr } %t227, 0
  %t232 = icmp sle i64 %t226, %t229
  br i1 %t232, label %bb35, label %bb36
bb35:
  %t234 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t234, ptr %l117, !tbaa !27
  %t235 = getelementptr %"compiler/scope:fnUse", ptr %l3, i32 0, i32 1
  %t236 = getelementptr %"compiler/source:Span", ptr %t235, i32 0, i32 0
  %t237 = load i32, ptr %t236, !tbaa !23
  %t239 = sext i32 %t237 to i64
  store i64 %t239, ptr %l119, !tbaa !24
  %t240 = getelementptr %"compiler/scope:fnUse", ptr %l3, i32 0, i32 1
  %t241 = getelementptr %"compiler/source:Span", ptr %t240, i32 0, i32 1
  %t242 = load i32, ptr %t241, !tbaa !23
  %t244 = sext i32 %t242 to i64
  store i64 %t244, ptr %l121, !tbaa !24
  %t245 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t246 = extractvalue { i64, ptr } %t245, 0
  store i64 %t246, ptr %l122, !tbaa !24
  %t247 = load i64, ptr %l119, !tbaa !24
  %t248 = icmp sge i64 %t247, 0
  br i1 %t248, label %bb37, label %bb38
bb36:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l116, !tbaa !27
  br label %bb43
bb37:
  %t250 = load i64, ptr %l119, !tbaa !24
  %t251 = load i64, ptr %l121, !tbaa !24
  %t252 = icmp sle i64 %t250, %t251
  br i1 %t252, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_27754b85c0c4924f_acb66791c9f4f5d3)
  unreachable
bb39:
  %t254 = load i64, ptr %l121, !tbaa !24
  %t255 = load i64, ptr %l122, !tbaa !24
  %t256 = icmp sle i64 %t254, %t255
  br i1 %t256, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_27754b85c0c4924f_acb66791c9f4f5d3)
  unreachable
bb41:
  %t258 = getelementptr { i64, ptr }, ptr %l117, i32 0, i32 1
  %t259 = load ptr, ptr %t258, !tbaa !27
  %t260 = load i64, ptr %l119, !tbaa !24
  %t261 = load i64, ptr %l121, !tbaa !24
  %t262 = getelementptr i8, ptr %t259, i64 %t260
  %t263 = sub i64 %t261, %t260
  %t264 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t265 = insertvalue { i64, ptr } %t264, ptr %t262, 1
  store { i64, ptr } %t265, ptr %l116, !tbaa !27
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_27754b85c0c4924f_acb66791c9f4f5d3)
  unreachable
bb43:
  %t267 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t268 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eFuncValueObligations(ptr %v0, ptr %s7, { i64, ptr } %t267)
  store %"compiler/msgs:Msg" %t268, ptr %l127
  br label %bb44
bb44:
  %t269 = load ptr, ptr %l109, !tbaa !29
  %t270 = load { i64, [3 x i64] }, ptr %l110
  %t271 = load %"compiler/msgs:Msg", ptr %l127
  %t272 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s7, ptr %t269, { i64, [3 x i64] } %t270, %"compiler/msgs:Msg" %t271)
  store i64 %t272, ptr %l128
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s7)
  br label %bb142
bb46:
  %t273 = load ptr, ptr %l136, !tbaa !29
  store ptr %t273, ptr %l10, !tbaa !29
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/scope:Scoper", ptr %t274, i32 0, i32 0
  %t277 = load ptr, ptr %t276, !tbaa !29
  %t279 = getelementptr %"compiler/generic:Program", ptr %t277, i32 0, i32 2
  %t280 = load ptr, ptr %l10, !tbaa !29
  %t282 = getelementptr %"compiler/typed:Body", ptr %t280, i32 0, i32 2
  %t283 = load i32, ptr %t282, !tbaa !23
  %t286 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t279, i32 %t283, i64 0)
  store i64 %t286, ptr %l142
  br label %bb47
bb47:
  %t287 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  %t288 = load i64, ptr %l142, !tbaa !24
  %t290 = icmp eq i64 %t288, %t287
  br i1 %t290, label %bb48, label %bb49
bb48:
  store i1 true, ptr %l11, !tbaa !21
  store ptr %l4, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb50
bb49:
  br label %bb74
bb50:
  %t293 = load i64, ptr %l13, !tbaa !24
  store i64 %t293, ptr %l146, !tbaa !24
  %t294 = load ptr, ptr %l12, !tbaa !29
  %t296 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t294)
  store i64 %t296, ptr %l148
  br label %bb51
bb51:
  %t297 = load i64, ptr %l146, !tbaa !24
  %t298 = load i64, ptr %l148, !tbaa !24
  %t299 = icmp slt i64 %t297, %t298
  %t301 = xor i1 %t299, true
  br i1 %t301, label %bb52, label %bb53
bb52:
  br label %bb70
bb53:
  br label %bb54
bb54:
  %t303 = load ptr, ptr %l12, !tbaa !29
  %t304 = load i64, ptr %l13, !tbaa !24
  %t307 = call %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t303, i64 %t304)
  store %"compiler/scope:rel" %t307, ptr %l153
  br label %bb55
bb55:
  %t308 = load %"compiler/scope:rel", ptr %l153
  store %"compiler/scope:rel" %t308, ptr %l14
  %t309 = getelementptr %"compiler/scope:rel", ptr %l14, i32 0, i32 1
  %t310 = load { i64, [2 x i64] }, ptr %t309
  store { i64, [2 x i64] } %t310, ptr %l15
  %t312 = load { i64, [2 x i64] }, ptr %l15
  %t314 = extractvalue { i64, [2 x i64] } %t312, 0
  %t315 = icmp eq i64 %t314, 2
  br i1 %t315, label %bb56, label %bb57
bb56:
  %t317 = getelementptr { i64, [2 x i64] }, ptr %l15, i32 0, i32 1
  %t318 = getelementptr { i64 }, ptr %t317, i32 0, i32 0
  %t319 = load i64, ptr %t318
  store i64 %t319, ptr %l16, !tbaa !24
  br label %bb58
bb57:
  br label %bb63
bb58:
  %t321 = load i1, ptr %l11, !tbaa !21
  br i1 %t321, label %bb59, label %bb60
bb59:
  %t323 = load ptr, ptr %l10, !tbaa !29
  %t325 = getelementptr %"compiler/typed:Body", ptr %t323, i32 0, i32 6
  %t326 = load i64, ptr %l16, !tbaa !24
  %t329 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t325, i64 %t326)
  store { i64, [1 x i64] } %t329, ptr %l163
  br label %bb61
bb60:
  store i1 false, ptr %l159, !tbaa !21
  br label %bb62
bb61:
  %t330 = load { i64, [1 x i64] }, ptr %l163
  %t332 = extractvalue { i64, [1 x i64] } %t330, 0
  %t333 = icmp eq i64 %t332, 1
  store i1 %t333, ptr %l159, !tbaa !21
  br label %bb62
bb62:
  %t335 = load i1, ptr %l159, !tbaa !21
  store i1 %t335, ptr %l11, !tbaa !21
  br label %bb68
bb63:
  br i1 true, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb67
bb66:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_932a31ce6b630e99_55999437bdf20e8d)
  unreachable
bb68:
  br label %bb69
bb69:
  %t336 = load i64, ptr %l13, !tbaa !24
  %t338 = add i64 %t336, 1
  store i64 %t338, ptr %l13, !tbaa !24
  br label %bb50
bb70:
  %t340 = load i1, ptr %l11, !tbaa !21
  br i1 %t340, label %bb71, label %bb72
bb71:
  call void @__olang_scope_close(ptr %s8)
  br label %bb144
bb72:
  br label %bb73
bb73:
  br label %bb74
bb74:
  store ptr %l4, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb75
bb75:
  %t343 = load i64, ptr %l18, !tbaa !24
  store i64 %t343, ptr %l170, !tbaa !24
  %t344 = load ptr, ptr %l17, !tbaa !29
  %t346 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t344)
  store i64 %t346, ptr %l172
  br label %bb76
bb76:
  %t347 = load i64, ptr %l170, !tbaa !24
  %t348 = load i64, ptr %l172, !tbaa !24
  %t349 = icmp slt i64 %t347, %t348
  %t351 = xor i1 %t349, true
  br i1 %t351, label %bb77, label %bb78
bb77:
  br label %bb126
bb78:
  br label %bb79
bb79:
  %t353 = load ptr, ptr %l17, !tbaa !29
  %t354 = load i64, ptr %l18, !tbaa !24
  %t357 = call %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t353, i64 %t354)
  store %"compiler/scope:rel" %t357, ptr %l177
  br label %bb80
bb80:
  %t358 = load %"compiler/scope:rel", ptr %l177
  store %"compiler/scope:rel" %t358, ptr %l19
  %t359 = getelementptr %"compiler/scope:rel", ptr %l19, i32 0, i32 0
  %t360 = load { i64, [2 x i64] }, ptr %t359
  store { i64, [2 x i64] } %t360, ptr %l20
  %t362 = load { i64, [2 x i64] }, ptr %l20
  %t364 = extractvalue { i64, [2 x i64] } %t362, 0
  %t365 = icmp eq i64 %t364, 2
  br i1 %t365, label %bb81, label %bb82
bb81:
  %t367 = getelementptr { i64, [2 x i64] }, ptr %l20, i32 0, i32 1
  %t368 = getelementptr { i64 }, ptr %t367, i32 0, i32 0
  %t369 = load i64, ptr %t368
  store i64 %t369, ptr %l21, !tbaa !24
  br label %bb83
bb82:
  br label %bb119
bb83:
  %t371 = load ptr, ptr %l10, !tbaa !29
  %t373 = getelementptr %"compiler/typed:Body", ptr %t371, i32 0, i32 6
  %t374 = load i64, ptr %l21, !tbaa !24
  %t377 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t373, i64 %t374)
  store { i64, [1 x i64] } %t377, ptr %l185
  br label %bb84
bb84:
  %t378 = load { i64, [1 x i64] }, ptr %l185
  store { i64, [1 x i64] } %t378, ptr %l22
  %t379 = load { i64, [1 x i64] }, ptr %l22
  %t381 = extractvalue { i64, [1 x i64] } %t379, 0
  %t382 = icmp eq i64 %t381, 0
  br i1 %t382, label %bb85, label %bb86
bb85:
  %t384 = getelementptr { i64, [1 x i64] }, ptr %l22, i32 0, i32 1
  %t385 = getelementptr { i32 }, ptr %t384, i32 0, i32 0
  %t386 = load i32, ptr %t385
  store i32 %t386, ptr %l23, !tbaa !23
  br label %bb87
bb86:
  br label %bb97
bb87:
  store %olang.scope zeroinitializer, ptr %s19
  %t388 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t390 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s8, ptr %s19, { i64, ptr } %t388, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i1 %t390, ptr %l190
  br label %bb88
bb88:
  %t391 = load i1, ptr %l190, !tbaa !21
  br i1 %t391, label %bb89, label %bb90
bb89:
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t394 = getelementptr %"compiler/scope:Scoper", ptr %t392, i32 0, i32 0
  %t395 = load ptr, ptr %t394, !tbaa !29
  %t397 = getelementptr %"compiler/generic:Program", ptr %t395, i32 0, i32 0
  %t398 = load ptr, ptr %t397, !tbaa !29
  %t400 = getelementptr %"compiler/load:Loader", ptr %t398, i32 0, i32 3
  %t401 = load ptr, ptr %t400, !tbaa !29
  store ptr %t401, ptr %l194, !tbaa !29
  %t402 = load ptr, ptr %l10, !tbaa !29
  %t404 = getelementptr %"compiler/typed:Body", ptr %t402, i32 0, i32 7
  %t405 = load i32, ptr %l23, !tbaa !23
  %t407 = sext i32 %t405 to i64
  %t410 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t404, i64 %t407)
  store %"compiler/typed:Local" %t410, ptr %l199
  br label %bb91
bb90:
  br label %bb96
bb91:
  %t411 = getelementptr %"compiler/typed:Local", ptr %l199, i32 0, i32 0
  %t412 = load i32, ptr %t411, !tbaa !23
  %t413 = load ptr, ptr %l194, !tbaa !29
  %t415 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t413, i32 %t412)
  store { i64, ptr } %t415, ptr %l201
  br label %bb92
bb92:
  %t416 = load { i64, ptr }, ptr %l201, !tbaa !27
  store { i64, ptr } %t416, ptr %l202, !tbaa !27
  %t417 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t418 = extractvalue { i64, ptr } %t417, 0
  %t419 = load { i64, ptr }, ptr %l202, !tbaa !27
  %t420 = extractvalue { i64, ptr } %t419, 0
  store i64 %t420, ptr %l204, !tbaa !24
  %t422 = load i64, ptr %l204, !tbaa !24
  %t423 = icmp eq i64 %t418, %t422
  br i1 %t423, label %bb93, label %bb94
bb93:
  %t425 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t426 = load ptr, ptr %t425, !tbaa !27
  %t427 = getelementptr { i64, ptr }, ptr %l202, i32 0, i32 1
  %t428 = load ptr, ptr %t427, !tbaa !27
  %t429 = load i64, ptr %l204, !tbaa !24
  %t430 = mul i64 %t429, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t426, ptr %t428, i64 %t430, i1 false)
  br label %bb95
bb94:
  %t431 = load { i64, ptr }, ptr %l202, !tbaa !27
  %t432 = extractvalue { i64, ptr } %t431, 0
  store i64 %t432, ptr %l206, !tbaa !24
  %t433 = load i64, ptr %l206, !tbaa !24
  %t434 = mul i64 %t433, 1
  %t435 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t434)
  %t436 = insertvalue { i64, ptr } undef, i64 %t433, 0
  %t437 = insertvalue { i64, ptr } %t436, ptr %t435, 1
  store { i64, ptr } %t437, ptr %l207, !tbaa !27
  %t438 = getelementptr { i64, ptr }, ptr %l207, i32 0, i32 1
  %t439 = load ptr, ptr %t438, !tbaa !27
  %t440 = getelementptr { i64, ptr }, ptr %l202, i32 0, i32 1
  %t441 = load ptr, ptr %t440, !tbaa !27
  %t442 = load i64, ptr %l206, !tbaa !24
  %t443 = mul i64 %t442, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t439, ptr %t441, i64 %t443, i1 false)
  %t444 = load { i64, ptr }, ptr %l207, !tbaa !27
  store { i64, ptr } %t444, ptr %l9, !tbaa !27
  br label %bb95
bb95:
  br label %bb96
bb96:
  call void @__olang_scope_close(ptr %s19)
  br label %bb118
bb97:
  %t445 = load { i64, [1 x i64] }, ptr %l22
  %t447 = extractvalue { i64, [1 x i64] } %t445, 0
  %t448 = icmp eq i64 %t447, 4
  br i1 %t448, label %bb98, label %bb99
bb98:
  %t450 = getelementptr { i64, [1 x i64] }, ptr %l22, i32 0, i32 1
  %t451 = getelementptr { i32 }, ptr %t450, i32 0, i32 0
  %t452 = load i32, ptr %t451
  store i32 %t452, ptr %l24, !tbaa !23
  br label %bb100
bb99:
  br label %bb113
bb100:
  store %olang.scope zeroinitializer, ptr %s21
  %t454 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t456 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s8, ptr %s21, { i64, ptr } %t454, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store i1 %t456, ptr %l212
  br label %bb101
bb101:
  %t457 = load i1, ptr %l212, !tbaa !21
  br i1 %t457, label %bb102, label %bb103
bb102:
  %t458 = load ptr, ptr %l10, !tbaa !29
  %t460 = getelementptr %"compiler/typed:Body", ptr %t458, i32 0, i32 15
  %t461 = load i1, ptr %t460, !tbaa !21
  store i1 %t461, ptr %l213, !tbaa !21
  br label %bb104
bb103:
  store i1 false, ptr %l213, !tbaa !21
  br label %bb104
bb104:
  %t463 = load i1, ptr %l213, !tbaa !21
  br i1 %t463, label %bb105, label %bb106
bb105:
  %t464 = load ptr, ptr %l0, !tbaa !29
  %t466 = getelementptr %"compiler/scope:Scoper", ptr %t464, i32 0, i32 0
  %t467 = load ptr, ptr %t466, !tbaa !29
  %t469 = getelementptr %"compiler/generic:Program", ptr %t467, i32 0, i32 0
  %t470 = load ptr, ptr %t469, !tbaa !29
  %t472 = getelementptr %"compiler/load:Loader", ptr %t470, i32 0, i32 3
  %t473 = load ptr, ptr %t472, !tbaa !29
  store ptr %t473, ptr %l219, !tbaa !29
  %t474 = load ptr, ptr %l10, !tbaa !29
  %t476 = getelementptr %"compiler/typed:Body", ptr %t474, i32 0, i32 7
  %t477 = load i32, ptr %l24, !tbaa !23
  %t479 = sext i32 %t477 to i64
  %t482 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t476, i64 %t479)
  store %"compiler/typed:Local" %t482, ptr %l224
  br label %bb107
bb106:
  br label %bb112
bb107:
  %t483 = getelementptr %"compiler/typed:Local", ptr %l224, i32 0, i32 0
  %t484 = load i32, ptr %t483, !tbaa !23
  %t485 = load ptr, ptr %l219, !tbaa !29
  %t487 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t485, i32 %t484)
  store { i64, ptr } %t487, ptr %l226
  br label %bb108
bb108:
  %t488 = load { i64, ptr }, ptr %l226, !tbaa !27
  store { i64, ptr } %t488, ptr %l227, !tbaa !27
  %t489 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t490 = extractvalue { i64, ptr } %t489, 0
  %t491 = load { i64, ptr }, ptr %l227, !tbaa !27
  %t492 = extractvalue { i64, ptr } %t491, 0
  store i64 %t492, ptr %l229, !tbaa !24
  %t494 = load i64, ptr %l229, !tbaa !24
  %t495 = icmp eq i64 %t490, %t494
  br i1 %t495, label %bb109, label %bb110
bb109:
  %t497 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t498 = load ptr, ptr %t497, !tbaa !27
  %t499 = getelementptr { i64, ptr }, ptr %l227, i32 0, i32 1
  %t500 = load ptr, ptr %t499, !tbaa !27
  %t501 = load i64, ptr %l229, !tbaa !24
  %t502 = mul i64 %t501, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t498, ptr %t500, i64 %t502, i1 false)
  br label %bb111
bb110:
  %t503 = load { i64, ptr }, ptr %l227, !tbaa !27
  %t504 = extractvalue { i64, ptr } %t503, 0
  store i64 %t504, ptr %l231, !tbaa !24
  %t505 = load i64, ptr %l231, !tbaa !24
  %t506 = mul i64 %t505, 1
  %t507 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t506)
  %t508 = insertvalue { i64, ptr } undef, i64 %t505, 0
  %t509 = insertvalue { i64, ptr } %t508, ptr %t507, 1
  store { i64, ptr } %t509, ptr %l232, !tbaa !27
  %t510 = getelementptr { i64, ptr }, ptr %l232, i32 0, i32 1
  %t511 = load ptr, ptr %t510, !tbaa !27
  %t512 = getelementptr { i64, ptr }, ptr %l227, i32 0, i32 1
  %t513 = load ptr, ptr %t512, !tbaa !27
  %t514 = load i64, ptr %l231, !tbaa !24
  %t515 = mul i64 %t514, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t511, ptr %t513, i64 %t515, i1 false)
  %t516 = load { i64, ptr }, ptr %l232, !tbaa !27
  store { i64, ptr } %t516, ptr %l9, !tbaa !27
  br label %bb111
bb111:
  br label %bb112
bb112:
  call void @__olang_scope_close(ptr %s21)
  br label %bb118
bb113:
  br i1 true, label %bb114, label %bb115
bb114:
  br label %bb116
bb115:
  br label %bb117
bb116:
  br label %bb118
bb117:
  call void @__olang_check_failed(ptr @olang_loc_fc32950df7c04da2_11eedb932326b4f6)
  unreachable
bb118:
  br label %bb124
bb119:
  br i1 true, label %bb120, label %bb121
bb120:
  br label %bb122
bb121:
  br label %bb123
bb122:
  br label %bb124
bb123:
  call void @__olang_check_failed(ptr @olang_loc_af9ca28b921c6ea3_fa663a0c518bad97)
  unreachable
bb124:
  br label %bb125
bb125:
  %t517 = load i64, ptr %l18, !tbaa !24
  %t519 = add i64 %t517, 1
  store i64 %t519, ptr %l18, !tbaa !24
  br label %bb75
bb126:
  %t521 = load ptr, ptr %l10, !tbaa !29
  %t523 = getelementptr %"compiler/typed:Body", ptr %t521, i32 0, i32 15
  %t524 = load i1, ptr %t523, !tbaa !21
  br i1 %t524, label %bb127, label %bb128
bb127:
  store %olang.scope zeroinitializer, ptr %s26
  %t526 = load ptr, ptr %l10, !tbaa !29
  %t528 = getelementptr %"compiler/typed:Body", ptr %t526, i32 0, i32 18
  %t529 = load i1, ptr %t528, !tbaa !21
  br i1 %t529, label %bb129, label %bb130
bb128:
  br label %bb134
bb129:
  call void @__olang_scope_close(ptr %s26)
  call void @__olang_scope_close(ptr %s8)
  br label %bb144
bb130:
  br label %bb131
bb131:
  %t531 = load ptr, ptr %l0, !tbaa !29
  %t533 = getelementptr %"compiler/scope:Scoper", ptr %t531, i32 0, i32 0
  %t534 = load ptr, ptr %t533, !tbaa !29
  %t536 = getelementptr %"compiler/generic:Program", ptr %t534, i32 0, i32 0
  %t537 = load ptr, ptr %t536, !tbaa !29
  %t539 = getelementptr %"compiler/load:Loader", ptr %t537, i32 0, i32 4
  %t540 = load ptr, ptr %t539, !tbaa !29
  store ptr %t540, ptr %l242, !tbaa !29
  %t541 = load { i64, [3 x i64] }, ptr %l5
  store { i64, [3 x i64] } %t541, ptr %l243
  %t542 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t544 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenYieldsBorrow(ptr %s8, ptr %s26, { i64, ptr } %t542)
  store %"compiler/msgs:Msg" %t544, ptr %l245
  br label %bb132
bb132:
  %t545 = load ptr, ptr %l242, !tbaa !29
  %t546 = load { i64, [3 x i64] }, ptr %l243
  %t547 = load %"compiler/msgs:Msg", ptr %l245
  %t548 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s26, ptr %t545, { i64, [3 x i64] } %t546, %"compiler/msgs:Msg" %t547)
  store i64 %t548, ptr %l246
  br label %bb133
bb133:
  call void @__olang_scope_close(ptr %s26)
  call void @__olang_scope_close(ptr %s8)
  br label %bb144
bb134:
  %t549 = load ptr, ptr %l0, !tbaa !29
  %t551 = getelementptr %"compiler/scope:Scoper", ptr %t549, i32 0, i32 0
  %t552 = load ptr, ptr %t551, !tbaa !29
  %t554 = getelementptr %"compiler/generic:Program", ptr %t552, i32 0, i32 0
  %t555 = load ptr, ptr %t554, !tbaa !29
  %t557 = getelementptr %"compiler/load:Loader", ptr %t555, i32 0, i32 4
  %t558 = load ptr, ptr %t557, !tbaa !29
  store ptr %t558, ptr %l250, !tbaa !29
  %t559 = load { i64, [3 x i64] }, ptr %l5
  store { i64, [3 x i64] } %t559, ptr %l251
  %t560 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t562 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s8, ptr %s8, { i64, ptr } %t560, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i1 %t562, ptr %l253
  br label %bb135
bb135:
  %t563 = load i1, ptr %l253, !tbaa !21
  %t564 = xor i1 %t563, true
  br i1 %t564, label %bb136, label %bb137
bb136:
  %t566 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t568 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaValueObligations(ptr %s8, ptr %s8, { i64, ptr } %t566)
  store %"compiler/msgs:Msg" %t568, ptr %l257
  br label %bb138
bb137:
  %t569 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaValueRelates(ptr %s8)
  store %"compiler/msgs:Msg" %t569, ptr %l258
  br label %bb139
bb138:
  %t570 = load %"compiler/msgs:Msg", ptr %l257
  store %"compiler/msgs:Msg" %t570, ptr %l255
  br label %bb140
bb139:
  %t571 = load %"compiler/msgs:Msg", ptr %l258
  store %"compiler/msgs:Msg" %t571, ptr %l255
  br label %bb140
bb140:
  %t572 = load ptr, ptr %l250, !tbaa !29
  %t573 = load { i64, [3 x i64] }, ptr %l251
  %t574 = load %"compiler/msgs:Msg", ptr %l255
  %t575 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s8, ptr %t572, { i64, [3 x i64] } %t573, %"compiler/msgs:Msg" %t574)
  store i64 %t575, ptr %l259
  br label %bb141
bb141:
  call void @__olang_scope_close(ptr %s8)
  br label %bb142
bb142:
  br label %bb143
bb143:
  br label %bb144
bb144:
  %t576 = load i64, ptr %l2, !tbaa !24
  %t578 = add i64 %t576, 1
  store i64 %t578, ptr %l2, !tbaa !24
  br label %bb1
bb145:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egivenRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l10 = alloca i1
  %l14 = alloca { i64, [2 x i64] }
  %l15 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t6 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %t1, ptr %a1)
  store ptr %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t8 = call i64 @compiler_2fscope_2elocalRead(ptr %v1, ptr %t7)
  store i64 %t8, ptr %l7
  br label %bb2
bb2:
  %t9 = load i64, ptr %l7, !tbaa !24
  store i64 %t9, ptr %l2, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp sge i64 %t10, 0
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/scope:Scoper", ptr %t14, i32 0, i32 31
  %t17 = load i64, ptr %l2, !tbaa !24
  %t20 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t16, i64 %t17)
  store { i64, [2 x i64] } %t20, ptr %l14
  br label %bb5
bb4:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb7
bb5:
  %t21 = load { i64, [2 x i64] }, ptr %l14
  %t22 = call i1 @compiler_2fscope_2etermGiven({ i64, [2 x i64] } %t21)
  store i1 %t22, ptr %l15
  br label %bb6
bb6:
  %t23 = load i1, ptr %l15, !tbaa !21
  store i1 %t23, ptr %l10, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l10, !tbaa !21
  store i1 %t24, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eheldPart(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca i64
  %l13 = alloca i1
  %l15 = alloca i1
  %l17 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca i32
  %l26 = alloca i1
  %l30 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_3451003dd1e97df4_bcd12f7be62952d8)
  unreachable
bb11:
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = call i64 @compiler_2fscope_2eflRoot(ptr %v1, ptr %t11)
  store i64 %t13, ptr %l10
  br label %bb12
bb12:
  %t14 = load i64, ptr %l10, !tbaa !24
  store i64 %t14, ptr %l2, !tbaa !24
  %t15 = load i64, ptr %l2, !tbaa !24
  %t17 = icmp slt i64 %t15, 0
  br i1 %t17, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb16
bb14:
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = call i1 @compiler_2fscope_2eflThroughRef(ptr %v1, ptr %t19)
  store i1 %t21, ptr %l15
  br label %bb15
bb15:
  %t22 = load i1, ptr %l15, !tbaa !21
  store i1 %t22, ptr %l13, !tbaa !21
  br label %bb16
bb16:
  %t23 = load i1, ptr %l13, !tbaa !21
  br i1 %t23, label %bb17, label %bb18
bb17:
  store i1 false, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/scope:Scoper", ptr %t25, i32 0, i32 40
  %t28 = load i64, ptr %l2, !tbaa !24
  %t31 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v0, ptr %t27, i64 %t28)
  %t32 = extractvalue { i32, ptr } %t31, 1
  %t33 = extractvalue { i32, ptr } %t31, 0
  store i32 %t33, ptr %l22
  %t34 = icmp ne i32 %t33, 0
  br i1 %t34, label %bb21, label %ok.35, !prof !99
ok.35:
  store ptr %t32, ptr %l21
  br label %bb20
bb20:
  %t36 = load ptr, ptr %l21, !tbaa !29
  store ptr %t36, ptr %l17, !tbaa !29
  br label %bb23
bb21:
  br label %bb22
bb22:
  call void @__olang_ert_req_clear()
  store ptr null, ptr %l17, !tbaa !29
  br label %bb23
bb23:
  %t37 = load ptr, ptr %l17, !tbaa !29
  store ptr %t37, ptr %l3, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = icmp eq ptr %t38, null
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb24, label %bb25
bb24:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t49 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeHere(ptr %v0, ptr %v0, ptr %t44, ptr %t45)
  store i1 %t49, ptr %l30
  br label %bb26
bb25:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb27
bb26:
  %t50 = load i1, ptr %l30, !tbaa !21
  store i1 %t50, ptr %l26, !tbaa !21
  br label %bb27
bb27:
  %t51 = load i1, ptr %l26, !tbaa !21
  store i1 %t51, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehere(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca ptr
  %l5 = alloca ptr
  %l8 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i32
  %rv = alloca { i64, [2 x i64] }
  %t55 = alloca { i64, [2 x i64] }, align 8
  %t72 = alloca { i64, [2 x i64] }, align 8
  %t77 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/scope:Scoper", ptr %t2, i32 0, i32 34
  store ptr %t4, ptr %l5, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/scope:Scoper", ptr %t5, i32 0, i32 34
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l8
  br label %bb1
bb1:
  %t10 = load i64, ptr %l8, !tbaa !24
  %t11 = sub i64 %t10, 1
  %t12 = load ptr, ptr %l5, !tbaa !29
  %t14 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t12, i64 %t11)
  store i32 %t14, ptr %l10
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l3, !tbaa !29
  %t16 = load i32, ptr %l10, !tbaa !23
  %t17 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elift(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t17, ptr %l11
  br label %bb3
bb3:
  %t18 = load i32, ptr %l11, !tbaa !23
  store i32 %t18, ptr %l1, !tbaa !23
  %t19 = load i32, ptr %l1, !tbaa !23
  %t21 = icmp eq i32 %t19, 0
  br i1 %t21, label %bb4, label %bb5
bb4:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/scope:Scoper", ptr %t23, i32 0, i32 25
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = icmp eq ptr %t26, null
  br i1 %t28, label %bb6, label %bb7
bb5:
  br label %bb27
bb6:
  call void @__olang_check_failed(ptr @olang_loc_c4815f8d08aa5069_e0d3df7c014ad4fd)
  unreachable
bb7:
  br label %bb8
bb8:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/scope:Scoper", ptr %t30, i32 0, i32 25
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Body", ptr %t33, i32 0, i32 1
  %t37 = load { i64, [2 x i64] }, ptr %t36
  store { i64, [2 x i64] } %t37, ptr %l2
  %t39 = load { i64, [2 x i64] }, ptr %l2
  %t41 = extractvalue { i64, [2 x i64] } %t39, 0
  %t42 = icmp eq i64 %t41, 1
  br i1 %t42, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb15
bb11:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/scope:Scoper", ptr %t44, i32 0, i32 39
  %t47 = load i64, ptr %t46, !tbaa !24
  %t49 = icmp sge i64 %t47, 0
  br i1 %t49, label %bb12, label %bb13
bb12:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/scope:Scoper", ptr %t51, i32 0, i32 39
  %t54 = load i64, ptr %t53, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t55
  %t56 = getelementptr { i64, [2 x i64] }, ptr %t55, i32 0, i32 0
  store i64 2, ptr %t56
  %t58 = insertvalue { i64 } undef, i64 %t54, 0
  %t59 = getelementptr { i64, [2 x i64] }, ptr %t55, i32 0, i32 1
  store { i64 } %t58, ptr %t59
  %t60 = load { i64, [2 x i64] }, ptr %t55
  store { i64, [2 x i64] } %t60, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  br label %bb26
bb15:
  %t62 = load { i64, [2 x i64] }, ptr %l2
  %t64 = extractvalue { i64, [2 x i64] } %t62, 0
  %t65 = icmp eq i64 %t64, 6
  br i1 %t65, label %bb16, label %bb17
bb16:
  br label %bb20
bb17:
  %t67 = load { i64, [2 x i64] }, ptr %l2
  %t69 = extractvalue { i64, [2 x i64] } %t67, 0
  %t70 = icmp eq i64 %t69, 7
  br i1 %t70, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store { i64, [2 x i64] } zeroinitializer, ptr %t72
  %t73 = getelementptr { i64, [2 x i64] }, ptr %t72, i32 0, i32 0
  store i64 3, ptr %t73
  %t74 = load { i64, [2 x i64] }, ptr %t72
  store { i64, [2 x i64] } %t74, ptr %rv
  br label %ret
bb21:
  br i1 true, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_f2ff34bd09efe7b1_f9738b06cf9c6415)
  unreachable
bb26:
  br label %bb27
bb27:
  %t76 = load i32, ptr %l1, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t77
  %t78 = getelementptr { i64, [2 x i64] }, ptr %t77, i32 0, i32 0
  store i64 1, ptr %t78
  %t80 = insertvalue { i32 } undef, i32 %t76, 0
  %t81 = getelementptr { i64, [2 x i64] }, ptr %t77, i32 0, i32 1
  store { i32 } %t80, ptr %t81
  %t82 = load { i64, [2 x i64] }, ptr %t77
  store { i64, [2 x i64] } %t82, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t6, i32 %a1)
  store i1 %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = load i1, ptr %l6, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2einstanceArgs(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i1
  %l11 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2einstanceOf(ptr %v0, ptr %t1, i64 %a1)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 2
  store ptr %t16, ptr %l11, !tbaa !29
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/scope:Scoper", ptr %t17, i32 0, i32 0
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t20, i64 %t21)
  store i32 %t24, ptr %l15
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb6
bb4:
  %t25 = load ptr, ptr %l11, !tbaa !29
  %t26 = load i32, ptr %l15, !tbaa !23
  %t27 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t25, i32 %t26)
  store { i64, ptr } %t27, ptr %l16
  br label %bb5
bb5:
  %t28 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  %t31 = icmp sgt i64 %t29, 0
  store i1 %t31, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t33 = load i1, ptr %l8, !tbaa !21
  store i1 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2einstanceOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca i64
  %l10 = alloca i32
  %l14 = alloca i64
  %l17 = alloca i64
  %l38 = alloca ptr
  %rv = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  store i64 64, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t1 = load i64, ptr %l3, !tbaa !24
  %t2 = load i64, ptr %l2, !tbaa !24
  %t5 = icmp sgt i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp sgt i64 %t7, 0
  br i1 %t9, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l2, !tbaa !24
  %t15 = sub i64 %t11, %t12
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = add i64 %t15, %t16
  %t21 = sub i64 %t19, 1
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = sdiv i64 %t21, %t22
  store i64 %t25, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t27 = load i64, ptr %l17, !tbaa !24
  store i64 %t27, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t28 = load i64, ptr %l14, !tbaa !24
  store i64 %t28, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  %t29 = load i64, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb8, label %bb9
bb8:
  br label %bb26
bb9:
  br label %bb10
bb10:
  %t37 = load i64, ptr %l2, !tbaa !24
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = load i64, ptr %l4, !tbaa !24
  %t42 = mul i64 %t38, %t39
  %t45 = add i64 %t37, %t42
  store i64 %t45, ptr %l7, !tbaa !24
  %t49 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 1
  %t50 = load i64, ptr %l1, !tbaa !24
  %t53 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t49, i64 %t50)
  store ptr %t53, ptr %l38
  br label %bb11
bb11:
  %t54 = load ptr, ptr %l38, !tbaa !29
  %t56 = getelementptr %"compiler/typed:Body", ptr %t54, i32 0, i32 1
  %t57 = load { i64, [2 x i64] }, ptr %t56
  store { i64, [2 x i64] } %t57, ptr %l8
  %t59 = load { i64, [2 x i64] }, ptr %l8
  %t61 = extractvalue { i64, [2 x i64] } %t59, 0
  %t62 = icmp eq i64 %t61, 0
  br i1 %t62, label %bb12, label %bb13
bb12:
  %t64 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t65 = getelementptr { i64 }, ptr %t64, i32 0, i32 0
  %t66 = load i64, ptr %t65
  store i64 %t66, ptr %l9, !tbaa !24
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t68 = load i64, ptr %l9, !tbaa !24
  store i64 %t68, ptr %rv
  br label %ret
bb15:
  %t70 = load { i64, [2 x i64] }, ptr %l8
  %t72 = extractvalue { i64, [2 x i64] } %t70, 0
  %t73 = icmp eq i64 %t72, 4
  br i1 %t73, label %bb16, label %bb17
bb16:
  %t75 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t76 = getelementptr { i32 }, ptr %t75, i32 0, i32 0
  %t77 = load i32, ptr %t76
  store i32 %t77, ptr %l10, !tbaa !23
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t79 = load i32, ptr %l10, !tbaa !23
  %t81 = sext i32 %t79 to i64
  store i64 %t81, ptr %l1, !tbaa !24
  br label %bb24
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  store i64 -1, ptr %rv
  br label %ret
bb23:
  call void @__olang_check_failed(ptr @olang_loc_e2ea0fea769db7e4_aa8c1e0e7de89fc8)
  unreachable
bb24:
  br label %bb25
bb25:
  %t84 = load i64, ptr %l6, !tbaa !24
  %t86 = add i64 %t84, 1
  store i64 %t86, ptr %l6, !tbaa !24
  br label %bb7
bb26:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2einstanceRel(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca { i64, [2 x i64] }
  %l17 = alloca i1
  %l20 = alloca i1
  %l25 = alloca i1
  %l28 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  store { i64, [2 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 25
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_4421e2d51127c851_53479ba5c20af2ad)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 25
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 1
  %t15 = load { i64, [2 x i64] }, ptr %t14
  %t19 = extractvalue { i64, [2 x i64] } %t15, 0
  %t20 = icmp eq i64 %t19, 1
  br i1 %t20, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 false, ptr %rv
  br label %ret
bb11:
  call void @__olang_check_failed(ptr @olang_loc_ba8e38ed7d6b48a9_35acc5c55c21205)
  unreachable
bb12:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/scope:Scoper", ptr %t23, i32 0, i32 39
  %t26 = load i64, ptr %t25, !tbaa !24
  %t28 = icmp sge i64 %t26, 0
  br i1 %t28, label %bb13, label %bb14
bb13:
  %t30 = load { i64, [2 x i64] }, ptr %l1
  %t32 = extractvalue { i64, [2 x i64] } %t30, 0
  %t33 = icmp eq i64 %t32, 2
  br i1 %t33, label %bb15, label %bb16
bb14:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb24
bb15:
  %t35 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t36 = getelementptr { i64 }, ptr %t35, i32 0, i32 0
  %t37 = load i64, ptr %t36
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/scope:Scoper", ptr %t38, i32 0, i32 39
  %t41 = load i64, ptr %t40, !tbaa !24
  %t44 = icmp eq i64 %t37, %t41
  store i1 %t44, ptr %l20, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb17
bb17:
  %t46 = load i1, ptr %l20, !tbaa !21
  br i1 %t46, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb23
bb19:
  %t47 = load { i64, [2 x i64] }, ptr %l2
  %t49 = extractvalue { i64, [2 x i64] } %t47, 0
  %t50 = icmp eq i64 %t49, 2
  br i1 %t50, label %bb20, label %bb21
bb20:
  %t52 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t53 = getelementptr { i64 }, ptr %t52, i32 0, i32 0
  %t54 = load i64, ptr %t53
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/scope:Scoper", ptr %t55, i32 0, i32 39
  %t58 = load i64, ptr %t57, !tbaa !24
  %t61 = icmp eq i64 %t54, %t58
  store i1 %t61, ptr %l28, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb22
bb22:
  %t63 = load i1, ptr %l28, !tbaa !21
  store i1 %t63, ptr %l25, !tbaa !21
  br label %bb23
bb23:
  %t64 = load i1, ptr %l25, !tbaa !21
  store i1 %t64, ptr %l17, !tbaa !21
  br label %bb24
bb24:
  %t65 = load i1, ptr %l17, !tbaa !21
  store i1 %t65, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisCtor(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l9 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 25
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_d38420f770b56a25_293628bae4d10df9)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 25
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 1
  %t15 = load { i64, [2 x i64] }, ptr %t14
  %t19 = extractvalue { i64, [2 x i64] } %t15, 0
  %t20 = icmp eq i64 %t19, 1
  br i1 %t20, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb7
bb6:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_7d2ed71f654b640d_ba09ac545853f0c1)
  unreachable
bb12:
  %t22 = load i1, ptr %l9, !tbaa !21
  store i1 %t22, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFunc(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t13 = trunc i64 21 to i32
  %t14 = icmp eq i32 %t11, %t13
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisHandle(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l5 = alloca i1
  %l10 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l24 = alloca i1
  %l27 = alloca { i64, [2 x i64] }
  %l31 = alloca { i64, ptr }
  %l33 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisStruct(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i1, ptr %l5, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/scope:Scoper", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  store ptr %t15, ptr %l10, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/scope:Scoper", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l1, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l15
  br label %bb5
bb5:
  %t26 = load ptr, ptr %l10, !tbaa !29
  %t27 = load i32, ptr %l15, !tbaa !23
  %t28 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t26, i32 %t27)
  store { i64, ptr } %t28, ptr %l16
  br label %bb6
bb6:
  %t29 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t29, ptr %l2, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  %t34 = icmp ne i64 %t32, 1
  br i1 %t34, label %bb7, label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t38, ptr %l22, !tbaa !27
  %t39 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr i32, ptr %t40, i64 0
  %t42 = load i32, ptr %t41, !tbaa !33
  %t45 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t37, i32 %t42)
  store i1 %t45, ptr %l24
  br label %bb10
bb10:
  %t46 = load i1, ptr %l24, !tbaa !21
  br i1 %t46, label %bb11, label %bb12
bb11:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i32, ptr %l1, !tbaa !23
  %t51 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efieldMark(ptr %v0, ptr %t47, i32 %t48, i64 0)
  store { i64, [2 x i64] } %t51, ptr %l27
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t52 = load { i64, [2 x i64] }, ptr %l27
  %t54 = extractvalue { i64, [2 x i64] } %t52, 0
  %t55 = icmp eq i64 %t54, 1
  store i1 %t55, ptr %rv
  br label %ret
bb14:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t58, ptr %l31, !tbaa !27
  %t59 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i32, ptr %t60, i64 0
  %t62 = load i32, ptr %t61, !tbaa !33
  %t65 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisHandle(ptr %v0, ptr %t57, i32 %t62)
  store i1 %t65, ptr %l33
  br label %bb15
bb15:
  %t66 = load i1, ptr %l33, !tbaa !21
  store i1 %t66, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisNullLit(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i1
  %l11 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %a0, i32 %t17)
  store i1 %t20, ptr %l11
  br label %bb6
bb6:
  %t21 = load i1, ptr %l11, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 false, ptr %rv
  br label %ret
bb11:
  call void @__olang_check_failed(ptr @olang_loc_4d20f13e93e5e00_8edf44d94b0465ac)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisNumberLike(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l6 = alloca i1
  %l7 = alloca i1
  %l12 = alloca i32
  %l20 = alloca i32
  %l23 = alloca i1
  %l28 = alloca i1
  %l29 = alloca i1
  %l32 = alloca ptr
  %l37 = alloca i32
  %l38 = alloca i32
  %l41 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = load i1, ptr %l6, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb5
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/scope:Scoper", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %l1, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l12
  br label %bb4
bb4:
  %t22 = load i32, ptr %l12, !range !{i32 0, i32 33}
  %t24 = trunc i64 2 to i32
  %t25 = icmp eq i32 %t22, %t24
  store i1 %t25, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t27 = load i1, ptr %l7, !tbaa !21
  br i1 %t27, label %bb6, label %bb7
bb6:
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/scope:Scoper", ptr %t29, i32 0, i32 0
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load i32, ptr %l1, !tbaa !23
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t38, ptr %l20
  br label %bb9
bb9:
  %t39 = load i32, ptr %l20, !range !{i32 0, i32 33}
  %t41 = trunc i64 18 to i32
  %t42 = icmp eq i32 %t39, %t41
  br i1 %t42, label %bb10, label %bb11
bb10:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/scope:Scoper", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  %t50 = load i32, ptr %l1, !tbaa !23
  %t53 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t49, i32 %t50)
  store i1 %t53, ptr %l28
  br label %bb12
bb11:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb13
bb12:
  %t54 = load i1, ptr %l28, !tbaa !21
  store i1 %t54, ptr %l23, !tbaa !21
  br label %bb13
bb13:
  %t55 = load i1, ptr %l23, !tbaa !21
  br i1 %t55, label %bb14, label %bb15
bb14:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/scope:Scoper", ptr %t56, i32 0, i32 0
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  store ptr %t61, ptr %l32, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/scope:Scoper", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l1, !tbaa !23
  %t71 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t67, i32 %t68)
  store i32 %t71, ptr %l37
  br label %bb16
bb15:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb18
bb16:
  %t72 = load ptr, ptr %l32, !tbaa !29
  %t73 = load i32, ptr %l37, !tbaa !23
  %t74 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t72, i32 %t73)
  store i32 %t74, ptr %l38
  br label %bb17
bb17:
  %t75 = load i32, ptr %l38, !range !{i32 0, i32 6}
  %t77 = trunc i64 4 to i32
  %t78 = icmp eq i32 %t75, %t77
  store i1 %t78, ptr %l29, !tbaa !21
  br label %bb18
bb18:
  %t80 = load i1, ptr %l29, !tbaa !21
  br i1 %t80, label %bb19, label %bb20
bb19:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l41, !tbaa !29
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/scope:Scoper", ptr %t82, i32 0, i32 0
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/generic:Program", ptr %t85, i32 0, i32 2
  %t88 = load i32, ptr %l1, !tbaa !23
  %t91 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t87, i32 %t88)
  store i32 %t91, ptr %l46
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t92 = load ptr, ptr %l41, !tbaa !29
  %t93 = load i32, ptr %l46, !tbaa !23
  %t94 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisNumberLike(ptr %v0, ptr %t92, i32 %t93)
  store i1 %t94, ptr %l47
  br label %bb22
bb22:
  %t95 = load i1, ptr %l47, !tbaa !21
  store i1 %t95, ptr %rv
  br label %ret
bb23:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisParamVar(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, [1 x i64] } %a1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_f39b1bd504b33948_8115a077853ab66c)
  unreachable
bb9:
  %t6 = load i1, ptr %l2, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekeepParam(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i1
  %l14 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i1
  %l23 = alloca i64
  %l26 = alloca i64
  %l28 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i1
  %l33 = alloca ptr
  %l42 = alloca %"compiler/typed:Local"
  %l44 = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp sge i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l5, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/scope:Scoper", ptr %t6, i32 0, i32 98
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l8
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb4
bb3:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  store i1 %t13, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l4, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/scope:Scoper", ptr %t16, i32 0, i32 98
  %t19 = load i64, ptr %l1, !tbaa !24
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t18, i64 %t19)
  store i64 %t22, ptr %l14
  br label %bb7
bb6:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb8
bb7:
  %t23 = load i64, ptr %l14, !tbaa !24
  %t24 = icmp sge i64 %t23, 0
  store i1 %t24, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l10, !tbaa !21
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/scope:Scoper", ptr %t27, i32 0, i32 98
  %t30 = load i64, ptr %l1, !tbaa !24
  %t33 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t29, i64 %t30)
  store i64 %t33, ptr %l19
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t34 = load i64, ptr %l19, !tbaa !24
  store i64 %t34, ptr %l1, !tbaa !24
  br label %bb12
bb12:
  %t35 = load i64, ptr %l1, !tbaa !24
  %t37 = icmp sge i64 %t35, 0
  br i1 %t37, label %bb13, label %bb14
bb13:
  %t39 = load i64, ptr %l1, !tbaa !24
  store i64 %t39, ptr %l23, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/scope:Scoper", ptr %t40, i32 0, i32 84
  %t44 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t42)
  store i64 %t44, ptr %l26
  br label %bb15
bb14:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb16
bb15:
  %t45 = load i64, ptr %l23, !tbaa !24
  %t46 = load i64, ptr %l26, !tbaa !24
  %t47 = icmp slt i64 %t45, %t46
  store i1 %t47, ptr %l22, !tbaa !21
  br label %bb16
bb16:
  %t49 = load i1, ptr %l22, !tbaa !21
  br i1 %t49, label %bb17, label %bb18
bb17:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load i64, ptr %l1, !tbaa !24
  %t54 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eregionKind(ptr %v0, ptr %t50, i64 %t51)
  store i1 %t54, ptr %l31
  br label %bb19
bb18:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb20
bb19:
  %t55 = load i1, ptr %l31, !tbaa !21
  store i1 %t55, ptr %l28, !tbaa !21
  br label %bb20
bb20:
  %t56 = load i1, ptr %l28, !tbaa !21
  br i1 %t56, label %bb21, label %bb22
bb21:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l33, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/scope:Scoper", ptr %t58, i32 0, i32 25
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = icmp eq ptr %t61, null
  br i1 %t63, label %bb23, label %bb24
bb22:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb28
bb23:
  call void @__olang_check_failed(ptr @olang_loc_707f747640e7de9_bc077dc74ca6c70d)
  unreachable
bb24:
  br label %bb25
bb25:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/scope:Scoper", ptr %t65, i32 0, i32 25
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t71 = getelementptr %"compiler/typed:Body", ptr %t68, i32 0, i32 7
  %t72 = load i64, ptr %l1, !tbaa !24
  %t75 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t71, i64 %t72)
  store %"compiler/typed:Local" %t75, ptr %l42
  br label %bb26
bb26:
  %t76 = getelementptr %"compiler/typed:Local", ptr %l42, i32 0, i32 2
  %t77 = load i32, ptr %t76, !tbaa !23
  %t78 = load ptr, ptr %l33, !tbaa !29
  %t80 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t78, i32 %t77)
  store i1 %t80, ptr %l44
  br label %bb27
bb27:
  %t81 = load i1, ptr %l44, !tbaa !21
  store i1 %t81, ptr %l32, !tbaa !21
  br label %bb28
bb28:
  %t82 = load i1, ptr %l32, !tbaa !21
  br i1 %t82, label %bb29, label %bb30
bb29:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/scope:Scoper", ptr %t83, i32 0, i32 84
  %t86 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t85, i64 %t86, i1 true)
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb32
bb32:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca i1
  %l29 = alloca i1
  %l37 = alloca i32
  %l41 = alloca { i64, ptr }
  %l44 = alloca ptr
  %l49 = alloca i32
  %l50 = alloca { i64, ptr }
  %l57 = alloca i64
  %l60 = alloca i64
  %l79 = alloca { i64, ptr }
  %l84 = alloca i64
  %l90 = alloca ptr
  %l93 = alloca i64
  %l96 = alloca i1
  %l99 = alloca i1
  %l100 = alloca i1
  %l101 = alloca ptr
  %l103 = alloca i32
  %l104 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca i1
  %l115 = alloca i1
  %l117 = alloca { i64, ptr }
  %l120 = alloca i1
  %l126 = alloca i1
  %l127 = alloca ptr
  %l128 = alloca i64
  %l132 = alloca i1
  %l135 = alloca i1
  %l138 = alloca i1
  %l139 = alloca i1
  %l140 = alloca ptr
  %l142 = alloca i32
  %l143 = alloca i1
  %l145 = alloca i1
  %l146 = alloca ptr
  %l148 = alloca i32
  %l149 = alloca i1
  %l152 = alloca ptr
  %l153 = alloca i1
  %l160 = alloca i1
  %l161 = alloca i1
  %l162 = alloca ptr
  %l166 = alloca i64
  %l168 = alloca i1
  %l178 = alloca i1
  %l182 = alloca i1
  %l189 = alloca ptr
  %l190 = alloca i1
  %l197 = alloca i1
  %l199 = alloca { i64, ptr }
  %l202 = alloca i1
  %l208 = alloca i1
  %l209 = alloca ptr
  %l210 = alloca i64
  %l214 = alloca i1
  %l218 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t7 = load ptr, ptr %l21, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l21, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 2
  store i1 %t13, ptr %l22, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l22, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { ptr }, ptr %t17, i32 0, i32 0
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t25 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecapturingLambda(ptr %v0, ptr %v1, ptr %t21, ptr %t22)
  store i1 %t25, ptr %l29
  br label %bb6
bb6:
  %t26 = load i1, ptr %l29, !tbaa !21
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/scope:Scoper", ptr %t27, i32 0, i32 117
  store i1 true, ptr %t29, !tbaa !21
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwExpr(ptr %v0, ptr %v1, ptr %t30, ptr %t31, i1 false)
  br label %bb10
bb10:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/scope:Scoper", ptr %t35, i32 0, i32 117
  store i1 false, ptr %t37, !tbaa !21
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_c0ef91a3e2c3a370_7d348321302c732c)
  unreachable
bb16:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t42 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %t38, ptr %t39)
  store i32 %t42, ptr %l37
  br label %bb17
bb17:
  %t43 = load i32, ptr %l37, !tbaa !23
  store i32 %t43, ptr %l4, !tbaa !23
  %t44 = load i32, ptr %l4, !tbaa !23
  %t45 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t48 = icmp ne i32 %t44, %t45
  br i1 %t48, label %bb18, label %bb19
bb18:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/scope:Scoper", ptr %t50, i32 0, i32 0
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  store ptr %t55, ptr %l44, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/scope:Scoper", ptr %t56, i32 0, i32 0
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  %t62 = load i32, ptr %l4, !tbaa !23
  %t65 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t61, i32 %t62)
  store i32 %t65, ptr %l49
  br label %bb20
bb19:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i32] }>, ptr @.d11, i32 0, i32 1) }, ptr %l41, !tbaa !27
  br label %bb22
bb20:
  %t66 = load ptr, ptr %l44, !tbaa !29
  %t67 = load i32, ptr %l49, !tbaa !23
  %t68 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t66, i32 %t67)
  store { i64, ptr } %t68, ptr %l50
  br label %bb21
bb21:
  %t69 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t69, ptr %l41, !tbaa !27
  br label %bb22
bb22:
  %t70 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t70, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr %"compiler/typed:Call", ptr %t71, i32 0, i32 1
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t74, 0
  store i64 %t76, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t78 = load i64, ptr %l7, !tbaa !24
  %t79 = load i64, ptr %l6, !tbaa !24
  %t82 = icmp sgt i64 %t78, %t79
  br i1 %t82, label %bb23, label %bb24
bb23:
  %t84 = load i64, ptr %l8, !tbaa !24
  %t86 = icmp sgt i64 %t84, 0
  br i1 %t86, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb28
bb25:
  %t88 = load i64, ptr %l7, !tbaa !24
  %t89 = load i64, ptr %l6, !tbaa !24
  %t92 = sub i64 %t88, %t89
  %t93 = load i64, ptr %l8, !tbaa !24
  %t96 = add i64 %t92, %t93
  %t98 = sub i64 %t96, 1
  %t99 = load i64, ptr %l8, !tbaa !24
  %t102 = sdiv i64 %t98, %t99
  store i64 %t102, ptr %l60, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l60, !tbaa !24
  br label %bb27
bb27:
  %t104 = load i64, ptr %l60, !tbaa !24
  store i64 %t104, ptr %l57, !tbaa !24
  br label %bb28
bb28:
  %t105 = load i64, ptr %l57, !tbaa !24
  store i64 %t105, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb29
bb29:
  %t106 = load i64, ptr %l10, !tbaa !24
  %t107 = load i64, ptr %l9, !tbaa !24
  %t110 = icmp slt i64 %t106, %t107
  %t112 = xor i1 %t110, true
  br i1 %t112, label %bb30, label %bb31
bb30:
  br label %bb157
bb31:
  br label %bb32
bb32:
  %t114 = load i64, ptr %l6, !tbaa !24
  %t115 = load i64, ptr %l10, !tbaa !24
  %t116 = load i64, ptr %l8, !tbaa !24
  %t119 = mul i64 %t115, %t116
  %t122 = add i64 %t114, %t119
  store i64 %t122, ptr %l11, !tbaa !24
  %t124 = load ptr, ptr %l1, !tbaa !29
  %t126 = getelementptr %"compiler/typed:Call", ptr %t124, i32 0, i32 1
  %t127 = load { i64, ptr }, ptr %t126, !tbaa !27
  store { i64, ptr } %t127, ptr %l79, !tbaa !27
  %t128 = load i64, ptr %l11, !tbaa !24
  %t130 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr ptr, ptr %t131, i64 %t128
  %t133 = load ptr, ptr %t132, !tbaa !39
  store ptr %t133, ptr %l12, !tbaa !29
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load ptr, ptr %l12, !tbaa !29
  %t139 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehandedRegion(ptr %v0, ptr %v1, ptr %t135, ptr %t136)
  store i64 %t139, ptr %l84
  br label %bb33
bb33:
  %t140 = load i64, ptr %l84, !tbaa !24
  store i64 %t140, ptr %l13, !tbaa !24
  %t141 = load i64, ptr %l13, !tbaa !24
  %t143 = icmp slt i64 %t141, 0
  br i1 %t143, label %bb34, label %bb35
bb34:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load ptr, ptr %l12, !tbaa !29
  %t150 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %t145, ptr %t146)
  store ptr %t150, ptr %l90
  br label %bb36
bb35:
  br label %bb114
bb36:
  %t151 = load ptr, ptr %l90, !tbaa !29
  store ptr %t151, ptr %l14, !tbaa !29
  %t152 = load ptr, ptr %l14, !tbaa !29
  %t155 = call i64 @compiler_2fscope_2eflRootExpr(ptr %v1, ptr %t152)
  store i64 %t155, ptr %l93
  br label %bb37
bb37:
  %t156 = load i64, ptr %l93, !tbaa !24
  store i64 %t156, ptr %l15, !tbaa !24
  %t157 = load i64, ptr %l15, !tbaa !24
  %t159 = icmp sge i64 %t157, 0
  br i1 %t159, label %bb38, label %bb39
bb38:
  %t161 = load ptr, ptr %l14, !tbaa !29
  %t164 = call i1 @compiler_2fscope_2eflThroughRefExpr(ptr %v1, ptr %t161)
  store i1 %t164, ptr %l99
  br label %bb40
bb39:
  store i1 false, ptr %l96, !tbaa !21
  br label %bb41
bb40:
  %t165 = load i1, ptr %l99, !tbaa !21
  store i1 %t165, ptr %l96, !tbaa !21
  br label %bb41
bb41:
  %t166 = load i1, ptr %l96, !tbaa !21
  br i1 %t166, label %bb42, label %bb43
bb42:
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l101, !tbaa !29
  %t168 = load ptr, ptr %l14, !tbaa !29
  %t170 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t168)
  store i32 %t170, ptr %l103
  br label %bb44
bb43:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb46
bb44:
  %t171 = load ptr, ptr %l101, !tbaa !29
  %t172 = load i32, ptr %l103, !tbaa !23
  %t173 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t171, i32 %t172)
  store i1 %t173, ptr %l104
  br label %bb45
bb45:
  %t174 = load i1, ptr %l104, !tbaa !21
  store i1 %t174, ptr %l100, !tbaa !21
  br label %bb46
bb46:
  %t175 = load i1, ptr %l100, !tbaa !21
  br i1 %t175, label %bb47, label %bb48
bb47:
  %t176 = load ptr, ptr %l1, !tbaa !29
  %t178 = getelementptr %"compiler/typed:Call", ptr %t176, i32 0, i32 0
  %t179 = load ptr, ptr %t178, !tbaa !29
  store ptr %t179, ptr %l107, !tbaa !29
  store i1 false, ptr %l108, !tbaa !21
  %t182 = load ptr, ptr %l107, !tbaa !29
  %t183 = icmp ne ptr %t182, null
  br i1 %t183, label %bb49, label %bb50
bb48:
  br label %bb74
bb49:
  %t185 = load ptr, ptr %l107, !tbaa !29
  %t186 = load i64, ptr %t185, !range !{i64 0, i64 5}
  %t188 = icmp eq i64 %t186, 2
  store i1 %t188, ptr %l108, !tbaa !21
  br label %bb50
bb50:
  %t189 = load i1, ptr %l108, !tbaa !21
  br i1 %t189, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb62
bb53:
  %t190 = load i64, ptr %l11, !tbaa !24
  %t191 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t191, 0
  %t196 = icmp slt i64 %t190, %t193
  br i1 %t196, label %bb54, label %bb55
bb54:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t199 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t199, ptr %l117, !tbaa !27
  %t200 = load i64, ptr %l11, !tbaa !24
  %t202 = getelementptr { i64, ptr }, ptr %l117, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !27
  %t204 = getelementptr i32, ptr %t203, i64 %t200
  %t205 = load i32, ptr %t204, !tbaa !33
  %t208 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreThrough(ptr %v0, ptr %t198, i32 %t205)
  store i1 %t208, ptr %l120
  br label %bb56
bb55:
  store i1 false, ptr %l115, !tbaa !21
  br label %bb57
bb56:
  %t209 = load i1, ptr %l120, !tbaa !21
  store i1 %t209, ptr %l115, !tbaa !21
  br label %bb57
bb57:
  %t210 = load i1, ptr %l115, !tbaa !21
  br i1 %t210, label %bb58, label %bb59
bb58:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t212 = load i64, ptr %l15, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreParam(ptr %v0, ptr %t211, i64 %t212, i1 true)
  br label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb61
bb61:
  br label %bb73
bb62:
  br i1 true, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb72
bb65:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load ptr, ptr %l1, !tbaa !29
  %t217 = load i64, ptr %l11, !tbaa !24
  %t221 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeStoresArg(ptr %v0, ptr %v1, ptr %t215, ptr %t216, i64 %t217)
  store i1 %t221, ptr %l126
  br label %bb66
bb66:
  %t222 = load i1, ptr %l126, !tbaa !21
  br i1 %t222, label %bb67, label %bb68
bb67:
  %t223 = load ptr, ptr %l0, !tbaa !29
  store ptr %t223, ptr %l127, !tbaa !29
  %t224 = load i64, ptr %l15, !tbaa !24
  store i64 %t224, ptr %l128, !tbaa !24
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load ptr, ptr %l1, !tbaa !29
  %t227 = load i64, ptr %l11, !tbaa !24
  %t231 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleePutsArg(ptr %v0, ptr %v1, ptr %t225, ptr %t226, i64 %t227)
  store i1 %t231, ptr %l132
  br label %bb69
bb68:
  br label %bb71
bb69:
  %t232 = load ptr, ptr %l127, !tbaa !29
  %t233 = load i64, ptr %l128, !tbaa !24
  %t234 = load i1, ptr %l132, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreParam(ptr %v0, ptr %t232, i64 %t233, i1 %t234)
  br label %bb70
bb70:
  br label %bb71
bb71:
  br label %bb73
bb72:
  call void @__olang_check_failed(ptr @olang_loc_bf024f3f8d6f4701_89fcb258d807f5dd)
  unreachable
bb73:
  br label %bb74
bb74:
  %t235 = load i64, ptr %l15, !tbaa !24
  %t237 = icmp sge i64 %t235, 0
  br i1 %t237, label %bb75, label %bb76
bb75:
  %t239 = load ptr, ptr %l14, !tbaa !29
  %t242 = call i1 @compiler_2fscope_2eflThroughRefExpr(ptr %v1, ptr %t239)
  store i1 %t242, ptr %l138
  br label %bb77
bb76:
  store i1 false, ptr %l135, !tbaa !21
  br label %bb78
bb77:
  %t243 = load i1, ptr %l138, !tbaa !21
  store i1 %t243, ptr %l135, !tbaa !21
  br label %bb78
bb78:
  %t244 = load i1, ptr %l135, !tbaa !21
  br i1 %t244, label %bb79, label %bb80
bb79:
  %t245 = load ptr, ptr %l0, !tbaa !29
  store ptr %t245, ptr %l140, !tbaa !29
  %t246 = load ptr, ptr %l14, !tbaa !29
  %t248 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t246)
  store i32 %t248, ptr %l142
  br label %bb81
bb80:
  store i1 false, ptr %l139, !tbaa !21
  br label %bb83
bb81:
  %t249 = load ptr, ptr %l140, !tbaa !29
  %t250 = load i32, ptr %l142, !tbaa !23
  %t251 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t249, i32 %t250)
  store i1 %t251, ptr %l143
  br label %bb82
bb82:
  %t252 = load i1, ptr %l143, !tbaa !21
  %t253 = xor i1 %t252, true
  store i1 %t253, ptr %l139, !tbaa !21
  br label %bb83
bb83:
  %t255 = load i1, ptr %l139, !tbaa !21
  br i1 %t255, label %bb84, label %bb85
bb84:
  %t256 = load ptr, ptr %l0, !tbaa !29
  store ptr %t256, ptr %l146, !tbaa !29
  %t257 = load ptr, ptr %l14, !tbaa !29
  %t259 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t257)
  store i32 %t259, ptr %l148
  br label %bb86
bb85:
  store i1 false, ptr %l145, !tbaa !21
  br label %bb88
bb86:
  %t260 = load ptr, ptr %l146, !tbaa !29
  %t261 = load i32, ptr %l148, !tbaa !23
  %t262 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreThrough(ptr %v0, ptr %t260, i32 %t261)
  store i1 %t262, ptr %l149
  br label %bb87
bb87:
  %t263 = load i1, ptr %l149, !tbaa !21
  store i1 %t263, ptr %l145, !tbaa !21
  br label %bb88
bb88:
  %t264 = load i1, ptr %l145, !tbaa !21
  br i1 %t264, label %bb89, label %bb90
bb89:
  %t265 = load ptr, ptr %l1, !tbaa !29
  %t267 = getelementptr %"compiler/typed:Call", ptr %t265, i32 0, i32 0
  %t268 = load ptr, ptr %t267, !tbaa !29
  store ptr %t268, ptr %l152, !tbaa !29
  store i1 false, ptr %l153, !tbaa !21
  %t271 = load ptr, ptr %l152, !tbaa !29
  %t272 = icmp ne ptr %t271, null
  br i1 %t272, label %bb91, label %bb92
bb90:
  br label %bb103
bb91:
  %t274 = load ptr, ptr %l152, !tbaa !29
  %t275 = load i64, ptr %t274, !range !{i64 0, i64 5}
  %t277 = icmp eq i64 %t275, 2
  store i1 %t277, ptr %l153, !tbaa !21
  br label %bb92
bb92:
  %t278 = load i1, ptr %l153, !tbaa !21
  br i1 %t278, label %bb93, label %bb94
bb93:
  br label %bb95
bb94:
  br label %bb97
bb95:
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t280 = load i64, ptr %l15, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreParam(ptr %v0, ptr %t279, i64 %t280, i1 true)
  br label %bb96
bb96:
  br label %bb102
bb97:
  br i1 true, label %bb98, label %bb99
bb98:
  br label %bb100
bb99:
  br label %bb101
bb100:
  br label %bb102
bb101:
  call void @__olang_check_failed(ptr @olang_loc_791e790d87101aea_cc84b762fb4c0ac6)
  unreachable
bb102:
  br label %bb103
bb103:
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t284 = load ptr, ptr %l12, !tbaa !29
  %t287 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecapturingLambda(ptr %v0, ptr %v1, ptr %t283, ptr %t284)
  store i1 %t287, ptr %l160
  br label %bb104
bb104:
  %t288 = load i1, ptr %l160, !tbaa !21
  br i1 %t288, label %bb105, label %bb106
bb105:
  %t289 = load ptr, ptr %l0, !tbaa !29
  store ptr %t289, ptr %l162, !tbaa !29
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t291 = load ptr, ptr %l1, !tbaa !29
  %t293 = getelementptr %"compiler/typed:Call", ptr %t291, i32 0, i32 0
  %t294 = load ptr, ptr %t293, !tbaa !29
  %t297 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebodyOf(ptr %v0, ptr %v1, ptr %t290, ptr %t294)
  store i64 %t297, ptr %l166
  br label %bb107
bb106:
  store i1 false, ptr %l161, !tbaa !21
  br label %bb109
bb107:
  %t298 = load i64, ptr %l11, !tbaa !24
  %t299 = load ptr, ptr %l162, !tbaa !29
  %t300 = load i64, ptr %l166, !tbaa !24
  %t302 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etransient(ptr %v0, ptr %t299, i64 %t300, i64 %t298)
  store i1 %t302, ptr %l168
  br label %bb108
bb108:
  %t303 = load i1, ptr %l168, !tbaa !21
  store i1 %t303, ptr %l161, !tbaa !21
  br label %bb109
bb109:
  %t304 = load i1, ptr %l161, !tbaa !21
  br i1 %t304, label %bb110, label %bb111
bb110:
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t307 = getelementptr %"compiler/scope:Scoper", ptr %t305, i32 0, i32 117
  store i1 true, ptr %t307, !tbaa !21
  br label %bb112
bb111:
  br label %bb112
bb112:
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t309 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwExpr(ptr %v0, ptr %v1, ptr %t308, ptr %t309, i1 false)
  br label %bb113
bb113:
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t315 = getelementptr %"compiler/scope:Scoper", ptr %t313, i32 0, i32 117
  store i1 false, ptr %t315, !tbaa !21
  br label %bb156
bb114:
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t317 = load ptr, ptr %l1, !tbaa !29
  %t318 = load i64, ptr %l11, !tbaa !24
  %t319 = load ptr, ptr %l12, !tbaa !29
  %t324 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehandleLent(ptr %v0, ptr %v1, ptr %v1, ptr %t316, ptr %t317, i64 %t318, ptr %t319)
  store i1 %t324, ptr %l178
  br label %bb115
bb115:
  %t325 = load i1, ptr %l178, !tbaa !21
  br i1 %t325, label %bb116, label %bb117
bb116:
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t327 = load ptr, ptr %l1, !tbaa !29
  %t328 = load i64, ptr %l11, !tbaa !24
  %t332 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleePutsArg(ptr %v0, ptr %v1, ptr %t326, ptr %t327, i64 %t328)
  store i1 %t332, ptr %l182
  br label %bb118
bb117:
  br label %bb124
bb118:
  %t333 = load i1, ptr %l182, !tbaa !21
  br i1 %t333, label %bb119, label %bb120
bb119:
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t335 = load i64, ptr %l13, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreParam(ptr %v0, ptr %t334, i64 %t335, i1 true)
  br label %bb121
bb120:
  br label %bb122
bb121:
  br label %bb122
bb122:
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t339 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwHanded(ptr %v0, ptr %v1, ptr %t338, ptr %t339)
  br label %bb123
bb123:
  br label %bb156
bb124:
  %t342 = load ptr, ptr %l1, !tbaa !29
  %t344 = getelementptr %"compiler/typed:Call", ptr %t342, i32 0, i32 0
  %t345 = load ptr, ptr %t344, !tbaa !29
  store ptr %t345, ptr %l189, !tbaa !29
  store i1 false, ptr %l190, !tbaa !21
  %t348 = load ptr, ptr %l189, !tbaa !29
  %t349 = icmp ne ptr %t348, null
  br i1 %t349, label %bb125, label %bb126
bb125:
  %t351 = load ptr, ptr %l189, !tbaa !29
  %t352 = load i64, ptr %t351, !range !{i64 0, i64 5}
  %t354 = icmp eq i64 %t352, 2
  store i1 %t354, ptr %l190, !tbaa !21
  br label %bb126
bb126:
  %t355 = load i1, ptr %l190, !tbaa !21
  br i1 %t355, label %bb127, label %bb128
bb127:
  br label %bb129
bb128:
  br label %bb138
bb129:
  %t356 = load i64, ptr %l11, !tbaa !24
  %t357 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t359 = extractvalue { i64, ptr } %t357, 0
  %t362 = icmp slt i64 %t356, %t359
  br i1 %t362, label %bb130, label %bb131
bb130:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t365 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t365, ptr %l199, !tbaa !27
  %t366 = load i64, ptr %l11, !tbaa !24
  %t368 = getelementptr { i64, ptr }, ptr %l199, i32 0, i32 1
  %t369 = load ptr, ptr %t368, !tbaa !27
  %t370 = getelementptr i32, ptr %t369, i64 %t366
  %t371 = load i32, ptr %t370, !tbaa !33
  %t374 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreThrough(ptr %v0, ptr %t364, i32 %t371)
  store i1 %t374, ptr %l202
  br label %bb132
bb131:
  store i1 false, ptr %l197, !tbaa !21
  br label %bb133
bb132:
  %t375 = load i1, ptr %l202, !tbaa !21
  store i1 %t375, ptr %l197, !tbaa !21
  br label %bb133
bb133:
  %t376 = load i1, ptr %l197, !tbaa !21
  br i1 %t376, label %bb134, label %bb135
bb134:
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t378 = load i64, ptr %l13, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreParam(ptr %v0, ptr %t377, i64 %t378, i1 true)
  br label %bb136
bb135:
  br label %bb137
bb136:
  br label %bb137
bb137:
  br label %bb154
bb138:
  br i1 true, label %bb139, label %bb140
bb139:
  br label %bb141
bb140:
  br label %bb153
bb141:
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t382 = load ptr, ptr %l1, !tbaa !29
  %t383 = load i64, ptr %l11, !tbaa !24
  %t387 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeStoresArg(ptr %v0, ptr %v1, ptr %t381, ptr %t382, i64 %t383)
  store i1 %t387, ptr %l208
  br label %bb142
bb142:
  %t388 = load i1, ptr %l208, !tbaa !21
  br i1 %t388, label %bb143, label %bb144
bb143:
  %t389 = load ptr, ptr %l0, !tbaa !29
  store ptr %t389, ptr %l209, !tbaa !29
  %t390 = load i64, ptr %l13, !tbaa !24
  store i64 %t390, ptr %l210, !tbaa !24
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t392 = load ptr, ptr %l1, !tbaa !29
  %t393 = load i64, ptr %l11, !tbaa !24
  %t397 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleePutsArg(ptr %v0, ptr %v1, ptr %t391, ptr %t392, i64 %t393)
  store i1 %t397, ptr %l214
  br label %bb145
bb144:
  %t398 = load ptr, ptr %l0, !tbaa !29
  %t399 = load ptr, ptr %l1, !tbaa !29
  %t400 = load i64, ptr %l11, !tbaa !24
  %t404 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeKeepsArg(ptr %v0, ptr %v1, ptr %t398, ptr %t399, i64 %t400)
  store i1 %t404, ptr %l218
  br label %bb147
bb145:
  %t405 = load ptr, ptr %l209, !tbaa !29
  %t406 = load i64, ptr %l210, !tbaa !24
  %t407 = load i1, ptr %l214, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreParam(ptr %v0, ptr %t405, i64 %t406, i1 %t407)
  br label %bb146
bb146:
  br label %bb152
bb147:
  %t408 = load i1, ptr %l218, !tbaa !21
  br i1 %t408, label %bb148, label %bb149
bb148:
  %t409 = load ptr, ptr %l0, !tbaa !29
  %t410 = load i64, ptr %l13, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekeepParam(ptr %v0, ptr %t409, i64 %t410)
  br label %bb150
bb149:
  br label %bb151
bb150:
  br label %bb151
bb151:
  br label %bb152
bb152:
  br label %bb154
bb153:
  call void @__olang_check_failed(ptr @olang_loc_21c4adf4625d97ab_9350e01b86c380a7)
  unreachable
bb154:
  %t413 = load ptr, ptr %l0, !tbaa !29
  %t414 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwHanded(ptr %v0, ptr %v1, ptr %t413, ptr %t414)
  br label %bb155
bb155:
  br label %bb156
bb156:
  %t417 = load i64, ptr %l10, !tbaa !24
  %t419 = add i64 %t417, 1
  store i64 %t419, ptr %l10, !tbaa !24
  br label %bb29
bb157:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwHanded(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t6 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %t1, ptr %a1)
  store ptr %t6, ptr %l8
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l8, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t8 = load ptr, ptr %l2, !tbaa !29
  store ptr %t8, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t9 = load ptr, ptr %l9, !tbaa !29
  %t10 = icmp ne ptr %t9, null
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l9, !tbaa !29
  %t13 = load i64, ptr %t12, !range !{i64 0, i64 18}
  %t15 = icmp eq i64 %t13, 3
  store i1 %t15, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l10, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr { i64, [5 x i64] }, ptr %t17, i32 0, i32 1
  %t20 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t19, i32 0, i32 2
  %t21 = load ptr, ptr %t20
  store ptr %t21, ptr %l3, !tbaa !29
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwPlace(ptr %v0, ptr %v1, ptr %t23, ptr %t24)
  br label %bb7
bb7:
  br label %bb22
bb8:
  %t27 = load ptr, ptr %l2, !tbaa !29
  store ptr %t27, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t28 = load ptr, ptr %l17, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t31 = load ptr, ptr %l17, !tbaa !29
  %t32 = load i64, ptr %t31, !range !{i64 0, i64 18}
  %t34 = icmp eq i64 %t32, 10
  store i1 %t34, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t35 = load i1, ptr %l18, !tbaa !21
  br i1 %t35, label %bb11, label %bb12
bb11:
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t38, i32 0, i32 2
  %t40 = load ptr, ptr %t39
  store ptr %t40, ptr %l4, !tbaa !29
  br label %bb13
bb12:
  br label %bb17
bb13:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l4, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Slice", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwPlace(ptr %v0, ptr %v1, ptr %t42, ptr %t46)
  br label %bb14
bb14:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t52 = getelementptr %"compiler/typed:Slice", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwExpr(ptr %v0, ptr %v1, ptr %t49, ptr %t53, i1 true)
  br label %bb15
bb15:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l4, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Slice", ptr %t58, i32 0, i32 2
  %t61 = load ptr, ptr %t60, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwExpr(ptr %v0, ptr %v1, ptr %t57, ptr %t61, i1 true)
  br label %bb16
bb16:
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_4f09217bbbe73e28_17ebc948c6ad3e44)
  unreachable
bb22:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elandHeld(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce"
  %l2 = alloca %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78"
  %l5 = alloca %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce"
  %l6 = alloca %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78"
  %l8 = alloca %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78"
  %l9 = alloca i32
  %l11 = alloca i1
  %l12 = alloca ptr
  %l14 = alloca ptr
  %l16 = alloca { i64, [2 x i64] }
  %l17 = alloca %"compiler/scope:Val"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 40
  %t5 = call %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H7e82b4dbdb79c77bc51fdaf9d4704834(ptr %v0, ptr %v0, ptr %t3)
  store %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce", ptr %l5
  store %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" %t6, ptr %l1
  br label %bb2
bb2:
  %t8 = call { i32, %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cI64_2c_20compiler_2ftyped_3aExpr_2_H4ea279ff901448a8d94a2f42aa119fd2(ptr %v0, ptr %v0, ptr %l1)
  %t9 = extractvalue { i32, %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" } %t8, 1
  %t10 = extractvalue { i32, %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" } %t8, 0
  store i32 %t10, ptr %l9
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb4, label %ok.12, !prof !99
ok.12:
  store %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" %t9, ptr %l8
  br label %bb3
bb3:
  %t13 = load %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78", ptr %l8
  store %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" %t13, ptr %l6
  br label %bb6
bb4:
  %t14 = load i32, ptr %l9, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  store i1 %t17, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  call void @__olang_ert_req_clear()
  br label %bb10
bb6:
  %t18 = load %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78", ptr %l6
  store %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" %t18, ptr %l2
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l12, !tbaa !29
  %t20 = getelementptr %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78", ptr %l2, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  store ptr %t21, ptr %l14, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehere(ptr %v0, ptr %t23)
  store { i64, [2 x i64] } %t25, ptr %l16
  br label %bb7
bb7:
  %t26 = load ptr, ptr %l12, !tbaa !29
  %t27 = load ptr, ptr %l14, !tbaa !29
  %t28 = load { i64, [2 x i64] }, ptr %l16
  %t29 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v0, ptr %t26, ptr %t27, { i64, [2 x i64] } %t28)
  store %"compiler/scope:Val" %t29, ptr %l17
  br label %bb8
bb8:
  br label %bb9
bb9:
  br label %bb2
bb10:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elentLoopCopy(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l24 = alloca i1
  %l25 = alloca i1
  %l26 = alloca ptr
  %l36 = alloca %"compiler/typed:Local"
  %l38 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t6 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %t1, ptr %a1)
  store ptr %t6, ptr %l8
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l8, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t8 = load ptr, ptr %l2, !tbaa !29
  store ptr %t8, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t9 = load ptr, ptr %l9, !tbaa !29
  %t10 = icmp ne ptr %t9, null
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l9, !tbaa !29
  %t13 = load i64, ptr %t12, !range !{i64 0, i64 18}
  %t15 = icmp eq i64 %t13, 3
  store i1 %t15, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l10, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr { i64, [5 x i64] }, ptr %t17, i32 0, i32 1
  %t20 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t19, i32 0, i32 2
  %t21 = load ptr, ptr %t20
  store ptr %t21, ptr %l3, !tbaa !29
  br label %bb6
bb5:
  br label %bb27
bb6:
  %t23 = load ptr, ptr %l3, !tbaa !29
  store ptr %t23, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t24 = load ptr, ptr %l15, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb7, label %bb8
bb7:
  %t27 = load ptr, ptr %l15, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 8}
  %t30 = icmp eq i64 %t28, 0
  store i1 %t30, ptr %l16, !tbaa !21
  br label %bb8
bb8:
  %t31 = load i1, ptr %l16, !tbaa !21
  br i1 %t31, label %bb9, label %bb10
bb9:
  %t32 = load ptr, ptr %l3, !tbaa !29
  %t34 = getelementptr { i64, [4 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t34, i32 0, i32 2
  %t36 = load i32, ptr %t35
  store i32 %t36, ptr %l4, !tbaa !23
  br label %bb11
bb10:
  br label %bb21
bb11:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i32, ptr %l4, !tbaa !23
  %t41 = sext i32 %t39 to i64
  %t44 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eloopElement(ptr %v0, ptr %t38, i64 %t41)
  store i1 %t44, ptr %l24
  br label %bb12
bb12:
  %t45 = load i1, ptr %l24, !tbaa !21
  br i1 %t45, label %bb13, label %bb14
bb13:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l26, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/scope:Scoper", ptr %t47, i32 0, i32 25
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = icmp eq ptr %t50, null
  br i1 %t52, label %bb15, label %bb16
bb14:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb20
bb15:
  call void @__olang_check_failed(ptr @olang_loc_42ddfa07d54a3511_7eb6b931dfed5aa5)
  unreachable
bb16:
  br label %bb17
bb17:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/scope:Scoper", ptr %t54, i32 0, i32 25
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Body", ptr %t57, i32 0, i32 7
  %t61 = load i32, ptr %l4, !tbaa !23
  %t63 = sext i32 %t61 to i64
  %t66 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t60, i64 %t63)
  store %"compiler/typed:Local" %t66, ptr %l36
  br label %bb18
bb18:
  %t67 = getelementptr %"compiler/typed:Local", ptr %l36, i32 0, i32 2
  %t68 = load i32, ptr %t67, !tbaa !23
  %t69 = load ptr, ptr %l26, !tbaa !29
  %t71 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t69, i32 %t68)
  store i1 %t71, ptr %l38
  br label %bb19
bb19:
  %t72 = load i1, ptr %l38, !tbaa !21
  %t73 = xor i1 %t72, true
  store i1 %t73, ptr %l25, !tbaa !21
  br label %bb20
bb20:
  %t75 = load i1, ptr %l25, !tbaa !21
  store i1 %t75, ptr %rv
  br label %ret
bb21:
  br i1 true, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_133169b3f1711469_c566838c26ef218d)
  unreachable
bb26:
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_31030507f1509b32_81bbcae78c23c7f6)
  unreachable
bb32:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eloopElement(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/typed:Local"
  %l3 = alloca %"compiler/typed:BlockInfo"
  %l12 = alloca %"compiler/typed:Local"
  %l16 = alloca i1
  %l20 = alloca i1
  %l22 = alloca i64
  %l30 = alloca i64
  %l42 = alloca %"compiler/typed:BlockInfo"
  %l45 = alloca i1
  %l49 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 25
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_406ffa91c23643d5_a8a413026b137651)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 25
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 7
  %t18 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t14, i64 %a1)
  store %"compiler/typed:Local" %t18, ptr %l12
  br label %bb4
bb4:
  %t19 = load %"compiler/typed:Local", ptr %l12
  store %"compiler/typed:Local" %t19, ptr %l2
  %t20 = getelementptr %"compiler/typed:Local", ptr %l2, i32 0, i32 4
  %t21 = load i32, ptr %t20, !range !{i32 0, i32 7}
  %t23 = trunc i64 1 to i32
  %t24 = icmp eq i32 %t21, %t23
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb7
bb6:
  %t28 = getelementptr %"compiler/typed:Local", ptr %l2, i32 0, i32 3
  %t29 = load i32, ptr %t28, !tbaa !23
  %t31 = sext i32 %t29 to i64
  %t33 = icmp sle i64 %t31, 0
  store i1 %t33, ptr %l16, !tbaa !21
  br label %bb7
bb7:
  %t35 = load i1, ptr %l16, !tbaa !21
  br i1 %t35, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb14
bb9:
  %t36 = getelementptr %"compiler/typed:Local", ptr %l2, i32 0, i32 3
  %t37 = load i32, ptr %t36, !tbaa !23
  %t39 = sext i32 %t37 to i64
  store i64 %t39, ptr %l22, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/scope:Scoper", ptr %t40, i32 0, i32 25
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = icmp eq ptr %t43, null
  br i1 %t45, label %bb10, label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_a53dc1127e8f642e_8cd05a2a2a6c7d4a)
  unreachable
bb11:
  br label %bb12
bb12:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/scope:Scoper", ptr %t47, i32 0, i32 25
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t53 = getelementptr %"compiler/typed:Body", ptr %t50, i32 0, i32 8
  %t55 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eLen__Hdc799a0fe091f8e84d50200d058b631d(ptr %v0, ptr %t53)
  store i64 %t55, ptr %l30
  br label %bb13
bb13:
  %t56 = load i64, ptr %l22, !tbaa !24
  %t57 = load i64, ptr %l30, !tbaa !24
  %t58 = icmp sge i64 %t56, %t57
  store i1 %t58, ptr %l20, !tbaa !21
  br label %bb14
bb14:
  %t60 = load i1, ptr %l20, !tbaa !21
  br i1 %t60, label %bb15, label %bb16
bb15:
  store i1 false, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/scope:Scoper", ptr %t62, i32 0, i32 25
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = icmp eq ptr %t65, null
  br i1 %t67, label %bb18, label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_ce604c7c8d78c55f_37d65431cab9ef4b)
  unreachable
bb19:
  br label %bb20
bb20:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/scope:Scoper", ptr %t69, i32 0, i32 25
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t75 = getelementptr %"compiler/typed:Body", ptr %t72, i32 0, i32 8
  %t76 = getelementptr %"compiler/typed:Local", ptr %l2, i32 0, i32 3
  %t77 = load i32, ptr %t76, !tbaa !23
  %t79 = sext i32 %t77 to i64
  %t82 = call %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %t75, i64 %t79)
  store %"compiler/typed:BlockInfo" %t82, ptr %l42
  br label %bb21
bb21:
  %t83 = load %"compiler/typed:BlockInfo", ptr %l42
  store %"compiler/typed:BlockInfo" %t83, ptr %l3
  %t84 = getelementptr %"compiler/typed:BlockInfo", ptr %l3, i32 0, i32 1
  %t85 = load i32, ptr %t84, !range !{i32 0, i32 9}
  %t87 = trunc i64 2 to i32
  %t88 = icmp eq i32 %t85, %t87
  br i1 %t88, label %bb22, label %bb23
bb22:
  %t90 = getelementptr %"compiler/typed:BlockInfo", ptr %l3, i32 0, i32 2
  %t91 = getelementptr %"compiler/source:Span", ptr %t90, i32 0, i32 0
  %t92 = load i32, ptr %t91, !tbaa !23
  %t93 = getelementptr %"compiler/typed:Local", ptr %l2, i32 0, i32 1
  %t94 = getelementptr %"compiler/source:Span", ptr %t93, i32 0, i32 0
  %t95 = load i32, ptr %t94, !tbaa !23
  %t98 = icmp eq i32 %t92, %t95
  store i1 %t98, ptr %l45, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb24
bb24:
  %t100 = load i1, ptr %l45, !tbaa !21
  br i1 %t100, label %bb25, label %bb26
bb25:
  %t101 = getelementptr %"compiler/typed:BlockInfo", ptr %l3, i32 0, i32 2
  %t102 = getelementptr %"compiler/source:Span", ptr %t101, i32 0, i32 1
  %t103 = load i32, ptr %t102, !tbaa !23
  %t104 = getelementptr %"compiler/typed:Local", ptr %l2, i32 0, i32 1
  %t105 = getelementptr %"compiler/source:Span", ptr %t104, i32 0, i32 1
  %t106 = load i32, ptr %t105, !tbaa !23
  %t109 = icmp eq i32 %t103, %t106
  store i1 %t109, ptr %l49, !tbaa !21
  br label %bb27
bb26:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb27
bb27:
  %t111 = load i1, ptr %l49, !tbaa !21
  store i1 %t111, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ematchMadeHere(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l25 = alloca i1
  %l29 = alloca i1
  %l42 = alloca i1
  %l43 = alloca ptr
  %l51 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Match", ptr %t1, i32 0, i32 3
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Match", ptr %t9, i32 0, i32 1
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  store { i64, ptr } %t12, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  store i64 %t16, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t18 = load i64, ptr %l3, !tbaa !24
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = icmp slt i64 %t18, %t19
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb5, label %bb6
bb5:
  br label %bb16
bb6:
  br label %bb7
bb7:
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l18, !tbaa !27
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr ptr, ptr %t30, i64 %t27
  %t32 = load ptr, ptr %t31, !tbaa !39
  store ptr %t32, ptr %l5, !tbaa !29
  %t34 = load ptr, ptr %l5, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Arm", ptr %t34, i32 0, i32 4
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb8, label %bb9
bb8:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l5, !tbaa !29
  %t46 = getelementptr %"compiler/typed:Arm", ptr %t44, i32 0, i32 4
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t50 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeHere(ptr %v0, ptr %v1, ptr %t43, ptr %t47)
  store i1 %t50, ptr %l29
  br label %bb10
bb9:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb11
bb10:
  %t51 = load i1, ptr %l29, !tbaa !21
  %t52 = xor i1 %t51, true
  store i1 %t52, ptr %l25, !tbaa !21
  br label %bb11
bb11:
  %t54 = load i1, ptr %l25, !tbaa !21
  br i1 %t54, label %bb12, label %bb13
bb12:
  store i1 false, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t56 = load i64, ptr %l3, !tbaa !24
  %t58 = add i64 %t56, 1
  store i64 %t58, ptr %l3, !tbaa !24
  br label %bb4
bb16:
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Match", ptr %t60, i32 0, i32 2
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = icmp eq ptr %t63, null
  br i1 %t65, label %bb17, label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_bfbb893df1c35f5d_ebb7b8931b043491)
  unreachable
bb18:
  br label %bb19
bb19:
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t69 = getelementptr %"compiler/typed:Match", ptr %t67, i32 0, i32 2
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t73 = getelementptr %"compiler/typed:Arm", ptr %t70, i32 0, i32 4
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = icmp eq ptr %t74, null
  br i1 %t76, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb26
bb21:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l43, !tbaa !29
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Match", ptr %t79, i32 0, i32 2
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = icmp eq ptr %t82, null
  br i1 %t84, label %bb22, label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_bfbb893df1c35f5d_ebb7b8931b043491)
  unreachable
bb23:
  br label %bb24
bb24:
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr %"compiler/typed:Match", ptr %t86, i32 0, i32 2
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Arm", ptr %t89, i32 0, i32 4
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t94 = load ptr, ptr %l43, !tbaa !29
  %t96 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeHere(ptr %v0, ptr %v1, ptr %t94, ptr %t93)
  store i1 %t96, ptr %l51
  br label %bb25
bb25:
  %t97 = load i1, ptr %l51, !tbaa !21
  store i1 %t97, ptr %l42, !tbaa !21
  br label %bb26
bb26:
  %t98 = load i1, ptr %l42, !tbaa !21
  store i1 %t98, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enewOrConst(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l10 = alloca i1
  %l11 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i1
  %l20 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l34 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l44 = alloca i1
  %l45 = alloca i1
  %l50 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t11 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %t6, ptr %t7)
  store i1 %t11, ptr %l10
  br label %bb4
bb4:
  %t12 = load i1, ptr %l10, !tbaa !21
  br i1 %t12, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb8
bb6:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t17 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisNullLit(ptr %v0, ptr %v1, ptr %t13, ptr %t14)
  store i1 %t17, ptr %l14
  br label %bb7
bb7:
  %t18 = load i1, ptr %l14, !tbaa !21
  store i1 %t18, ptr %l11, !tbaa !21
  br label %bb8
bb8:
  %t19 = load i1, ptr %l11, !tbaa !21
  br i1 %t19, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb12
bb10:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t24 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estaticLiteral(ptr %v0, ptr %v1, ptr %t20, ptr %t21)
  store i1 %t24, ptr %l18
  br label %bb11
bb11:
  %t25 = load i1, ptr %l18, !tbaa !21
  store i1 %t25, ptr %l15, !tbaa !21
  br label %bb12
bb12:
  %t26 = load i1, ptr %l15, !tbaa !21
  br i1 %t26, label %bb13, label %bb14
bb13:
  store i1 true, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t29 = load ptr, ptr %l21, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb16, label %bb17
bb16:
  %t32 = load ptr, ptr %l21, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 18}
  %t35 = icmp eq i64 %t33, 1
  store i1 %t35, ptr %l22, !tbaa !21
  br label %bb17
bb17:
  %t36 = load i1, ptr %l22, !tbaa !21
  br i1 %t36, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb44
bb21:
  %t37 = load ptr, ptr %l1, !tbaa !29
  store ptr %t37, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t38 = load ptr, ptr %l25, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb22, label %bb23
bb22:
  %t41 = load ptr, ptr %l25, !tbaa !29
  %t42 = load i64, ptr %t41, !range !{i64 0, i64 18}
  %t44 = icmp eq i64 %t42, 17
  store i1 %t44, ptr %l26, !tbaa !21
  br label %bb23
bb23:
  %t45 = load i1, ptr %l26, !tbaa !21
  br i1 %t45, label %bb24, label %bb25
bb24:
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr { i64, [5 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t48, i32 0, i32 2
  %t50 = load ptr, ptr %t49
  store ptr %t50, ptr %l2, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t57 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enewOrConst(ptr %v0, ptr %v1, ptr %t52, ptr %t53)
  store i1 %t57, ptr %l34
  br label %bb27
bb27:
  %t58 = load i1, ptr %l34, !tbaa !21
  store i1 %t58, ptr %l20, !tbaa !21
  br label %bb44
bb28:
  %t59 = load ptr, ptr %l1, !tbaa !29
  store ptr %t59, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t60 = load ptr, ptr %l35, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb29, label %bb30
bb29:
  %t63 = load ptr, ptr %l35, !tbaa !29
  %t64 = load i64, ptr %t63, !range !{i64 0, i64 18}
  %t66 = icmp eq i64 %t64, 11
  store i1 %t66, ptr %l36, !tbaa !21
  br label %bb30
bb30:
  %t67 = load i1, ptr %l36, !tbaa !21
  br i1 %t67, label %bb31, label %bb32
bb31:
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [5 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t70, i32 0, i32 2
  %t72 = load ptr, ptr %t71
  store ptr %t72, ptr %l3, !tbaa !29
  br label %bb33
bb32:
  br label %bb39
bb33:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load ptr, ptr %l3, !tbaa !29
  %t77 = getelementptr %"compiler/typed:Cond", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t81 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enewOrConst(ptr %v0, ptr %v1, ptr %t74, ptr %t78)
  store i1 %t81, ptr %l44
  br label %bb34
bb34:
  %t82 = load i1, ptr %l44, !tbaa !21
  br i1 %t82, label %bb35, label %bb36
bb35:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l3, !tbaa !29
  %t86 = getelementptr %"compiler/typed:Cond", ptr %t84, i32 0, i32 2
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t91 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enewOrConst(ptr %v0, ptr %v1, ptr %t83, ptr %t87)
  store i1 %t91, ptr %l50
  br label %bb37
bb36:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb38
bb37:
  %t92 = load i1, ptr %l50, !tbaa !21
  store i1 %t92, ptr %l45, !tbaa !21
  br label %bb38
bb38:
  %t93 = load i1, ptr %l45, !tbaa !21
  store i1 %t93, ptr %l20, !tbaa !21
  br label %bb44
bb39:
  br i1 true, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_13609328335a5af4_71f6842a5be0a9a0)
  unreachable
bb44:
  %t94 = load i1, ptr %l20, !tbaa !21
  store i1 %t94, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteMadeNamed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, i64 %a3, { i64, ptr } %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca %"compiler/typed:Local"
  %l20 = alloca i32
  %l21 = alloca { i64, ptr }
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca i64
  %l31 = alloca { i64, ptr }
  %l34 = alloca i1
  %l40 = alloca ptr
  %l44 = alloca i64
  %l47 = alloca i64
  %l65 = alloca ptr
  %l66 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca ptr
  %l77 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i1
  %l88 = alloca ptr
  %l89 = alloca i1
  %l97 = alloca ptr
  %l103 = alloca ptr
  %l107 = alloca i1
  %l110 = alloca ptr
  %l113 = alloca i32
  %l114 = alloca i64
  %l117 = alloca i1
  %l124 = alloca i1
  %l128 = alloca i64
  %l131 = alloca i1
  %l143 = alloca %"compiler/typed:Local"
  %l146 = alloca i1
  %l149 = alloca i1
  %l160 = alloca { i64, ptr }
  %l164 = alloca %"compiler/source:Span"
  %l167 = alloca ptr
  %l168 = alloca i64
  %l175 = alloca i64
  %l176 = alloca %"compiler/source:Span"
  %l179 = alloca %"compiler/msgs:Msg"
  %l180 = alloca ptr
  %l184 = alloca ptr
  %l185 = alloca i32
  %l189 = alloca ptr
  %l193 = alloca ptr
  %l197 = alloca i1
  %l200 = alloca ptr
  %l203 = alloca i32
  %l204 = alloca i64
  %l213 = alloca i1
  %l216 = alloca i1
  %l217 = alloca i1
  %l220 = alloca i1
  %l223 = alloca { i64, ptr }
  %l227 = alloca i1
  %l228 = alloca ptr
  %l231 = alloca i32
  %l232 = alloca i64
  %l234 = alloca ptr
  %l235 = alloca i64
  %l242 = alloca i64
  %l243 = alloca %"compiler/source:Span"
  %l248 = alloca %"compiler/msgs:Msg"
  %l254 = alloca i32
  %l257 = alloca i1
  %l259 = alloca i1
  %l262 = alloca i1
  %l264 = alloca i1
  %l268 = alloca i1
  %l277 = alloca i1
  %l278 = alloca i32
  %l283 = alloca i32
  %l288 = alloca i64
  %l291 = alloca i1
  %l294 = alloca ptr
  %l298 = alloca i32
  %l299 = alloca { i64, ptr }
  %l303 = alloca ptr
  %l304 = alloca i32
  %l308 = alloca i64
  %l309 = alloca i64
  %l313 = alloca i32
  %l314 = alloca i32
  %l325 = alloca i1
  %l326 = alloca i1
  %l331 = alloca i64
  %l336 = alloca i1
  %l339 = alloca i1
  %l341 = alloca { i64, ptr }
  %l345 = alloca { i64, ptr }
  %l347 = alloca ptr
  %l348 = alloca i64
  %l355 = alloca i64
  %l356 = alloca %"compiler/source:Span"
  %l362 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s21 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l5, !tbaa !24
  %t3 = icmp sgt i64 %t1, 8
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  store i1 %t7, ptr %l34, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l34, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  br label %bb6
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t15 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %t10, ptr %t11)
  store ptr %t15, ptr %l40
  br label %bb7
bb7:
  %t16 = load ptr, ptr %l40, !tbaa !29
  store ptr %t16, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  store i64 16, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t17 = load i64, ptr %l8, !tbaa !24
  %t18 = load i64, ptr %l7, !tbaa !24
  %t21 = icmp sgt i64 %t17, %t18
  br i1 %t21, label %bb8, label %bb9
bb8:
  %t23 = load i64, ptr %l9, !tbaa !24
  %t25 = icmp sgt i64 %t23, 0
  br i1 %t25, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb13
bb10:
  %t27 = load i64, ptr %l8, !tbaa !24
  %t28 = load i64, ptr %l7, !tbaa !24
  %t31 = sub i64 %t27, %t28
  %t32 = load i64, ptr %l9, !tbaa !24
  %t35 = add i64 %t31, %t32
  %t37 = sub i64 %t35, 1
  %t38 = load i64, ptr %l9, !tbaa !24
  %t41 = sdiv i64 %t37, %t38
  store i64 %t41, ptr %l47, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb12
bb12:
  %t43 = load i64, ptr %l47, !tbaa !24
  store i64 %t43, ptr %l44, !tbaa !24
  br label %bb13
bb13:
  %t44 = load i64, ptr %l44, !tbaa !24
  store i64 %t44, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb14
bb14:
  %t45 = load i64, ptr %l11, !tbaa !24
  %t46 = load i64, ptr %l10, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb15, label %bb16
bb15:
  br label %bb60
bb16:
  br label %bb17
bb17:
  %t53 = load i64, ptr %l7, !tbaa !24
  %t54 = load i64, ptr %l11, !tbaa !24
  %t55 = load i64, ptr %l9, !tbaa !24
  %t58 = mul i64 %t54, %t55
  %t61 = add i64 %t53, %t58
  store i64 %t61, ptr %l12, !tbaa !24
  %t63 = load ptr, ptr %l6, !tbaa !29
  store ptr %t63, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t64 = load ptr, ptr %l65, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb18, label %bb19
bb18:
  %t67 = load ptr, ptr %l65, !tbaa !29
  %t68 = load i64, ptr %t67, !range !{i64 0, i64 18}
  %t70 = icmp eq i64 %t68, 5
  store i1 %t70, ptr %l66, !tbaa !21
  br label %bb19
bb19:
  %t71 = load i1, ptr %l66, !tbaa !21
  br i1 %t71, label %bb20, label %bb21
bb20:
  %t72 = load ptr, ptr %l6, !tbaa !29
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 2
  %t76 = load ptr, ptr %t75
  store ptr %t76, ptr %l13, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load ptr, ptr %l13, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Promote", ptr %t79, i32 0, i32 0
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t86 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %t78, ptr %t82)
  store ptr %t86, ptr %l75
  br label %bb23
bb23:
  %t87 = load ptr, ptr %l75, !tbaa !29
  store ptr %t87, ptr %l6, !tbaa !29
  br label %bb58
bb24:
  %t88 = load ptr, ptr %l6, !tbaa !29
  store ptr %t88, ptr %l76, !tbaa !29
  store i1 false, ptr %l77, !tbaa !21
  %t89 = load ptr, ptr %l76, !tbaa !29
  %t90 = icmp ne ptr %t89, null
  br i1 %t90, label %bb25, label %bb26
bb25:
  %t92 = load ptr, ptr %l76, !tbaa !29
  %t93 = load i64, ptr %t92, !range !{i64 0, i64 18}
  %t95 = icmp eq i64 %t93, 2
  store i1 %t95, ptr %l77, !tbaa !21
  br label %bb26
bb26:
  %t96 = load i1, ptr %l77, !tbaa !21
  br i1 %t96, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l6, !tbaa !29
  %t99 = getelementptr { i64, [5 x i64] }, ptr %t97, i32 0, i32 1
  %t100 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t99, i32 0, i32 2
  %t101 = load ptr, ptr %t100
  store ptr %t101, ptr %l14, !tbaa !29
  br label %bb29
bb28:
  br label %bb53
bb29:
  %t103 = load ptr, ptr %l14, !tbaa !29
  store ptr %t103, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t104 = load ptr, ptr %l82, !tbaa !29
  %t105 = icmp ne ptr %t104, null
  br i1 %t105, label %bb30, label %bb31
bb30:
  %t107 = load ptr, ptr %l82, !tbaa !29
  %t108 = load i64, ptr %t107, !range !{i64 0, i64 8}
  %t110 = icmp eq i64 %t108, 3
  store i1 %t110, ptr %l83, !tbaa !21
  br label %bb31
bb31:
  %t111 = load i1, ptr %l83, !tbaa !21
  br i1 %t111, label %bb32, label %bb33
bb32:
  %t112 = load ptr, ptr %l14, !tbaa !29
  %t114 = getelementptr { i64, [4 x i64] }, ptr %t112, i32 0, i32 1
  %t115 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t114, i32 0, i32 2
  %t116 = load ptr, ptr %t115
  store ptr %t116, ptr %l15, !tbaa !29
  br label %bb34
bb33:
  br label %bb47
bb34:
  %t118 = load ptr, ptr %l15, !tbaa !29
  store ptr %t118, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t119 = load ptr, ptr %l88, !tbaa !29
  %t120 = icmp ne ptr %t119, null
  br i1 %t120, label %bb35, label %bb36
bb35:
  %t122 = load ptr, ptr %l88, !tbaa !29
  %t123 = load i64, ptr %t122, !range !{i64 0, i64 8}
  %t125 = icmp eq i64 %t123, 6
  store i1 %t125, ptr %l89, !tbaa !21
  br label %bb36
bb36:
  %t126 = load i1, ptr %l89, !tbaa !21
  br i1 %t126, label %bb37, label %bb38
bb37:
  %t127 = load ptr, ptr %l15, !tbaa !29
  %t129 = getelementptr { i64, [4 x i64] }, ptr %t127, i32 0, i32 1
  %t130 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t129, i32 0, i32 2
  %t131 = load ptr, ptr %t130
  store ptr %t131, ptr %l16, !tbaa !29
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load ptr, ptr %l16, !tbaa !29
  %t138 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %t133, ptr %t134)
  store ptr %t138, ptr %l97
  br label %bb40
bb40:
  %t139 = load ptr, ptr %l97, !tbaa !29
  store ptr %t139, ptr %l6, !tbaa !29
  br label %bb46
bb41:
  br i1 true, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb60
bb45:
  call void @__olang_check_failed(ptr @olang_loc_2a83bf20490fb4f0_b79be661c23cb1e4)
  unreachable
bb46:
  br label %bb52
bb47:
  br i1 true, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb60
bb51:
  call void @__olang_check_failed(ptr @olang_loc_28967cbbf3bb5881_fc5c9419ee26cbd5)
  unreachable
bb52:
  br label %bb58
bb53:
  br i1 true, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb60
bb57:
  call void @__olang_check_failed(ptr @olang_loc_e2b2a689ed5c2c6a_2e02b8bd326f399e)
  unreachable
bb58:
  br label %bb59
bb59:
  %t140 = load i64, ptr %l11, !tbaa !24
  %t142 = add i64 %t140, 1
  store i64 %t142, ptr %l11, !tbaa !24
  br label %bb14
bb60:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load ptr, ptr %l6, !tbaa !29
  %t149 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallOf(ptr %v0, ptr %v1, ptr %t144, ptr %t145)
  store ptr %t149, ptr %l103
  br label %bb61
bb61:
  %t150 = load ptr, ptr %l103, !tbaa !29
  store ptr %t150, ptr %l17, !tbaa !29
  %t151 = load ptr, ptr %l17, !tbaa !29
  %t153 = icmp eq ptr %t151, null
  %t155 = xor i1 %t153, true
  br i1 %t155, label %bb62, label %bb63
bb62:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/scope:Scoper", ptr %t157, i32 0, i32 0
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t162 = getelementptr %"compiler/generic:Program", ptr %t160, i32 0, i32 2
  store ptr %t162, ptr %l110, !tbaa !29
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load ptr, ptr %l17, !tbaa !29
  %t167 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %t163, ptr %t164)
  store i32 %t167, ptr %l113
  br label %bb64
bb63:
  store i1 false, ptr %l107, !tbaa !21
  br label %bb66
bb64:
  %t168 = load ptr, ptr %l110, !tbaa !29
  %t169 = load i32, ptr %l113, !tbaa !23
  %t170 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t168, i32 %t169)
  store i64 %t170, ptr %l114
  br label %bb65
bb65:
  %t171 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t172 = load i64, ptr %l114, !tbaa !24
  %t174 = icmp ne i64 %t172, %t171
  store i1 %t174, ptr %l107, !tbaa !21
  br label %bb66
bb66:
  %t176 = load i1, ptr %l107, !tbaa !21
  br i1 %t176, label %bb67, label %bb68
bb67:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load i64, ptr %l1, !tbaa !24
  %t179 = load ptr, ptr %l17, !tbaa !29
  %t180 = load i64, ptr %l3, !tbaa !24
  %t181 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t182 = load i64, ptr %l5, !tbaa !24
  %t189 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteThroughResult(ptr %v0, ptr %v1, ptr %v2, ptr %t177, i64 %t178, ptr %t179, i64 %t180, { i64, ptr } %t181, i64 %t182)
  store i1 %t189, ptr %l124
  br label %bb69
bb68:
  store i1 false, ptr %l117, !tbaa !21
  br label %bb70
bb69:
  %t190 = load i1, ptr %l124, !tbaa !21
  store i1 %t190, ptr %l117, !tbaa !21
  br label %bb70
bb70:
  %t191 = load i1, ptr %l117, !tbaa !21
  br i1 %t191, label %bb71, label %bb72
bb71:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb72:
  br label %bb73
bb73:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t193 = load ptr, ptr %l2, !tbaa !29
  %t197 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeLocal(ptr %v0, ptr %v1, ptr %t192, ptr %t193, i64 0)
  store i64 %t197, ptr %l128
  br label %bb74
bb74:
  %t198 = load i64, ptr %l128, !tbaa !24
  store i64 %t198, ptr %l18, !tbaa !24
  %t199 = load i64, ptr %l18, !tbaa !24
  %t201 = icmp slt i64 %t199, 0
  br i1 %t201, label %bb75, label %bb76
bb75:
  store i1 true, ptr %l131, !tbaa !21
  br label %bb77
bb76:
  %t203 = load i64, ptr %l18, !tbaa !24
  %t204 = load i64, ptr %l3, !tbaa !24
  %t207 = icmp eq i64 %t203, %t204
  store i1 %t207, ptr %l131, !tbaa !21
  br label %bb77
bb77:
  %t209 = load i1, ptr %l131, !tbaa !21
  br i1 %t209, label %bb78, label %bb79
bb78:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb79:
  br label %bb80
bb80:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t212 = getelementptr %"compiler/scope:Scoper", ptr %t210, i32 0, i32 25
  %t213 = load ptr, ptr %t212, !tbaa !29
  %t215 = icmp eq ptr %t213, null
  br i1 %t215, label %bb81, label %bb82
bb81:
  call void @__olang_check_failed(ptr @olang_loc_9f5a8ccf03b4db04_630c918a623736e8)
  unreachable
bb82:
  br label %bb83
bb83:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t219 = getelementptr %"compiler/scope:Scoper", ptr %t217, i32 0, i32 25
  %t220 = load ptr, ptr %t219, !tbaa !29
  %t223 = getelementptr %"compiler/typed:Body", ptr %t220, i32 0, i32 7
  %t224 = load i64, ptr %l18, !tbaa !24
  %t227 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t223, i64 %t224)
  store %"compiler/typed:Local" %t227, ptr %l143
  br label %bb84
bb84:
  %t228 = load %"compiler/typed:Local", ptr %l143
  store %"compiler/typed:Local" %t228, ptr %l19
  %t229 = getelementptr %"compiler/typed:Local", ptr %l19, i32 0, i32 0
  %t230 = load i32, ptr %t229, !tbaa !23
  %t232 = icmp eq i32 %t230, 0
  br i1 %t232, label %bb85, label %bb86
bb85:
  store i1 true, ptr %l146, !tbaa !21
  br label %bb88
bb86:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load i64, ptr %l18, !tbaa !24
  %t238 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eloopElement(ptr %v0, ptr %t234, i64 %t235)
  store i1 %t238, ptr %l149
  br label %bb87
bb87:
  %t239 = load i1, ptr %l149, !tbaa !21
  store i1 %t239, ptr %l146, !tbaa !21
  br label %bb88
bb88:
  %t240 = load i1, ptr %l146, !tbaa !21
  br i1 %t240, label %bb89, label %bb90
bb89:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb90:
  br label %bb91
bb91:
  %t241 = getelementptr %"compiler/typed:Local", ptr %l19, i32 0, i32 4
  %t242 = load i32, ptr %t241, !range !{i32 0, i32 7}
  store i32 %t242, ptr %l20
  %t244 = load i32, ptr %l20, !range !{i32 0, i32 7}
  %t246 = trunc i64 1 to i32
  %t247 = icmp eq i32 %t244, %t246
  br i1 %t247, label %bb92, label %bb93
bb92:
  br label %bb96
bb93:
  %t249 = load i32, ptr %l20, !range !{i32 0, i32 7}
  %t251 = trunc i64 4 to i32
  %t252 = icmp eq i32 %t249, %t251
  br i1 %t252, label %bb94, label %bb95
bb94:
  br label %bb96
bb95:
  br label %bb97
bb96:
  br label %bb102
bb97:
  br i1 true, label %bb98, label %bb99
bb98:
  br label %bb100
bb99:
  br label %bb101
bb100:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb101:
  call void @__olang_check_failed(ptr @olang_loc_f8891e21139a6c8c_91dd882c9f718fa8)
  unreachable
bb102:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = getelementptr %"compiler/scope:Scoper", ptr %t254, i32 0, i32 0
  %t257 = load ptr, ptr %t256, !tbaa !29
  %t259 = getelementptr %"compiler/generic:Program", ptr %t257, i32 0, i32 0
  %t260 = load ptr, ptr %t259, !tbaa !29
  %t262 = getelementptr %"compiler/load:Loader", ptr %t260, i32 0, i32 3
  %t263 = load ptr, ptr %t262, !tbaa !29
  %t264 = getelementptr %"compiler/typed:Local", ptr %l19, i32 0, i32 0
  %t265 = load i32, ptr %t264, !tbaa !23
  %t268 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t263, i32 %t265)
  store { i64, ptr } %t268, ptr %l160
  br label %bb103
bb103:
  %t269 = load { i64, ptr }, ptr %l160, !tbaa !27
  store { i64, ptr } %t269, ptr %l21, !tbaa !27
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"compiler/typed:Local", ptr %l19, i32 0, i32 1
  %t272 = load %"compiler/source:Span", ptr %t271
  %t273 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t277 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewordAt(ptr %v0, ptr %v0, ptr %t270, %"compiler/source:Span" %t272, { i64, ptr } %t273)
  store %"compiler/source:Span" %t277, ptr %l164
  br label %bb104
bb104:
  %t278 = load %"compiler/source:Span", ptr %l164
  store %"compiler/source:Span" %t278, ptr %l22
  %t279 = getelementptr %"compiler/typed:Local", ptr %l19, i32 0, i32 4
  %t280 = load i32, ptr %t279, !range !{i32 0, i32 7}
  %t282 = trunc i64 4 to i32
  %t283 = icmp eq i32 %t280, %t282
  br i1 %t283, label %bb105, label %bb106
bb105:
  store %olang.scope zeroinitializer, ptr %s17
  %t285 = load ptr, ptr %l0, !tbaa !29
  store ptr %t285, ptr %l167, !tbaa !29
  %t286 = load i64, ptr %l1, !tbaa !24
  store i64 %t286, ptr %l168, !tbaa !24
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t289 = getelementptr %"compiler/scope:Scoper", ptr %t287, i32 0, i32 25
  %t290 = load ptr, ptr %t289, !tbaa !29
  %t292 = icmp eq ptr %t290, null
  br i1 %t292, label %bb107, label %bb108
bb106:
  br label %bb112
bb107:
  call void @__olang_check_failed(ptr @olang_loc_7cb574562870c9ae_44cb25218e79651a)
  unreachable
bb108:
  br label %bb109
bb109:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t296 = getelementptr %"compiler/scope:Scoper", ptr %t294, i32 0, i32 25
  %t297 = load ptr, ptr %t296, !tbaa !29
  %t300 = getelementptr %"compiler/typed:Body", ptr %t297, i32 0, i32 3
  %t301 = load i64, ptr %t300, !tbaa !24
  store i64 %t301, ptr %l175, !tbaa !24
  %t302 = load %"compiler/source:Span", ptr %l22
  store %"compiler/source:Span" %t302, ptr %l176
  %t303 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t304 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t307 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteBindingWhere(ptr %v0, ptr %v2, ptr %s17, { i64, ptr } %t303, { i64, ptr } %t304)
  store %"compiler/msgs:Msg" %t307, ptr %l179
  br label %bb110
bb110:
  %t308 = load ptr, ptr %l167, !tbaa !29
  %t309 = load i64, ptr %l168, !tbaa !24
  %t310 = load i64, ptr %l175, !tbaa !24
  %t311 = load %"compiler/source:Span", ptr %l176
  %t312 = load %"compiler/msgs:Msg", ptr %l179
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enote(ptr %v0, ptr %s17, ptr %t308, i64 %t309, i64 %t310, %"compiler/source:Span" %t311, %"compiler/msgs:Msg" %t312)
  br label %bb111
bb111:
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb112:
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t315 = getelementptr %"compiler/scope:Scoper", ptr %t313, i32 0, i32 42
  %t316 = load i64, ptr %l18, !tbaa !24
  %t319 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v0, ptr %t315, i64 %t316)
  %t320 = extractvalue { i32, ptr } %t319, 1
  %t321 = extractvalue { i32, ptr } %t319, 0
  store i32 %t321, ptr %l185
  %t322 = icmp ne i32 %t321, 0
  br i1 %t322, label %bb114, label %ok.323, !prof !99
ok.323:
  store ptr %t320, ptr %l184
  br label %bb113
bb113:
  %t324 = load ptr, ptr %l184, !tbaa !29
  store ptr %t324, ptr %l180, !tbaa !29
  br label %bb116
bb114:
  br label %bb115
bb115:
  call void @__olang_ert_req_clear()
  store ptr null, ptr %l180, !tbaa !29
  br label %bb116
bb116:
  %t325 = load ptr, ptr %l180, !tbaa !29
  store ptr %t325, ptr %l23, !tbaa !29
  %t326 = load ptr, ptr %l23, !tbaa !29
  %t328 = icmp eq ptr %t326, null
  %t330 = xor i1 %t328, true
  br i1 %t330, label %bb117, label %bb118
bb117:
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t333 = load ptr, ptr %l23, !tbaa !29
  %t337 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallOf(ptr %v0, ptr %v0, ptr %t332, ptr %t333)
  store ptr %t337, ptr %l193
  br label %bb119
bb118:
  store ptr null, ptr %l189, !tbaa !29
  br label %bb120
bb119:
  %t338 = load ptr, ptr %l193, !tbaa !29
  store ptr %t338, ptr %l189, !tbaa !29
  br label %bb120
bb120:
  %t339 = load ptr, ptr %l189, !tbaa !29
  store ptr %t339, ptr %l24, !tbaa !29
  %t340 = load ptr, ptr %l24, !tbaa !29
  %t342 = icmp eq ptr %t340, null
  %t344 = xor i1 %t342, true
  br i1 %t344, label %bb121, label %bb122
bb121:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t348 = getelementptr %"compiler/scope:Scoper", ptr %t346, i32 0, i32 0
  %t349 = load ptr, ptr %t348, !tbaa !29
  %t351 = getelementptr %"compiler/generic:Program", ptr %t349, i32 0, i32 2
  store ptr %t351, ptr %l200, !tbaa !29
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t353 = load ptr, ptr %l24, !tbaa !29
  %t356 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v0, ptr %t352, ptr %t353)
  store i32 %t356, ptr %l203
  br label %bb123
bb122:
  store i1 false, ptr %l197, !tbaa !21
  br label %bb125
bb123:
  %t357 = load ptr, ptr %l200, !tbaa !29
  %t358 = load i32, ptr %l203, !tbaa !23
  %t359 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t357, i32 %t358)
  store i64 %t359, ptr %l204
  br label %bb124
bb124:
  %t360 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t361 = load i64, ptr %l204, !tbaa !24
  %t363 = icmp ne i64 %t361, %t360
  store i1 %t363, ptr %l197, !tbaa !21
  br label %bb125
bb125:
  %t365 = load i1, ptr %l197, !tbaa !21
  br i1 %t365, label %bb126, label %bb127
bb126:
  store %olang.scope zeroinitializer, ptr %s18
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t367 = load i64, ptr %l1, !tbaa !24
  %t368 = load ptr, ptr %l24, !tbaa !29
  %t369 = load i64, ptr %l3, !tbaa !24
  %t370 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t371 = load i64, ptr %l5, !tbaa !24
  %t378 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteThroughResult(ptr %v0, ptr %v0, ptr %v2, ptr %t366, i64 %t367, ptr %t368, i64 %t369, { i64, ptr } %t370, i64 %t371)
  store i1 %t378, ptr %l213
  br label %bb128
bb127:
  br label %bb154
bb128:
  %t379 = load i1, ptr %l213, !tbaa !21
  br i1 %t379, label %bb129, label %bb130
bb129:
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb130:
  br label %bb131
bb131:
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t381 = load ptr, ptr %l24, !tbaa !29
  %t384 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisMethodCall(ptr %v0, ptr %v0, ptr %t380, ptr %t381)
  store i1 %t384, ptr %l216
  br label %bb132
bb132:
  %t385 = load i1, ptr %l216, !tbaa !21
  br i1 %t385, label %bb133, label %bb134
bb133:
  store i1 true, ptr %l217, !tbaa !21
  br label %bb136
bb134:
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t387 = load ptr, ptr %l24, !tbaa !29
  %t390 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eindexCall(ptr %v0, ptr %v0, ptr %t386, ptr %t387)
  store i1 %t390, ptr %l220
  br label %bb135
bb135:
  %t391 = load i1, ptr %l220, !tbaa !21
  store i1 %t391, ptr %l217, !tbaa !21
  br label %bb136
bb136:
  %t392 = load i1, ptr %l217, !tbaa !21
  br i1 %t392, label %bb137, label %bb138
bb137:
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb138:
  br label %bb139
bb139:
  %t393 = load ptr, ptr %l0, !tbaa !29
  %t394 = load ptr, ptr %l24, !tbaa !29
  %t397 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeName(ptr %v0, ptr %v0, ptr %s18, ptr %t393, ptr %t394)
  store { i64, ptr } %t397, ptr %l223
  br label %bb140
bb140:
  %t398 = load { i64, ptr }, ptr %l223, !tbaa !27
  store { i64, ptr } %t398, ptr %l25, !tbaa !27
  %t399 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t401 = extractvalue { i64, ptr } %t399, 0
  %t403 = icmp sgt i64 %t401, 0
  br i1 %t403, label %bb141, label %bb142
bb141:
  %t405 = load ptr, ptr %l0, !tbaa !29
  store ptr %t405, ptr %l228, !tbaa !29
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t407 = load ptr, ptr %l24, !tbaa !29
  %t410 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v0, ptr %t406, ptr %t407)
  store i32 %t410, ptr %l231
  br label %bb143
bb142:
  store i1 false, ptr %l227, !tbaa !21
  br label %bb145
bb143:
  %t411 = load ptr, ptr %l228, !tbaa !29
  %t412 = load i32, ptr %l231, !tbaa !23
  %t413 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eresultVarOf(ptr %v0, ptr %t411, i32 %t412)
  store i64 %t413, ptr %l232
  br label %bb144
bb144:
  %t414 = load i64, ptr %l232, !tbaa !24
  %t415 = icmp sge i64 %t414, 0
  store i1 %t415, ptr %l227, !tbaa !21
  br label %bb145
bb145:
  %t417 = load i1, ptr %l227, !tbaa !21
  br i1 %t417, label %bb146, label %bb147
bb146:
  store %olang.scope zeroinitializer, ptr %s21
  %t418 = load ptr, ptr %l0, !tbaa !29
  store ptr %t418, ptr %l234, !tbaa !29
  %t419 = load i64, ptr %l1, !tbaa !24
  store i64 %t419, ptr %l235, !tbaa !24
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t422 = getelementptr %"compiler/scope:Scoper", ptr %t420, i32 0, i32 25
  %t423 = load ptr, ptr %t422, !tbaa !29
  %t425 = icmp eq ptr %t423, null
  br i1 %t425, label %bb148, label %bb149
bb147:
  br label %bb153
bb148:
  call void @__olang_check_failed(ptr @olang_loc_a5d7ffc0375a2adf_b8092e4cba9985db)
  unreachable
bb149:
  br label %bb150
bb150:
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t429 = getelementptr %"compiler/scope:Scoper", ptr %t427, i32 0, i32 25
  %t430 = load ptr, ptr %t429, !tbaa !29
  %t433 = getelementptr %"compiler/typed:Body", ptr %t430, i32 0, i32 3
  %t434 = load i64, ptr %t433, !tbaa !24
  store i64 %t434, ptr %l242, !tbaa !24
  %t435 = load %"compiler/source:Span", ptr %l22
  store %"compiler/source:Span" %t435, ptr %l243
  %t436 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t437 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t438 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t439 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t444 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteMakeWhere(ptr %v0, ptr %v2, ptr %s18, ptr %v2, ptr %s21, { i64, ptr } %t436, { i64, ptr } %t437, { i64, ptr } %t438, { i64, ptr } %t439)
  store %"compiler/msgs:Msg" %t444, ptr %l248
  br label %bb151
bb151:
  %t445 = load ptr, ptr %l234, !tbaa !29
  %t446 = load i64, ptr %l235, !tbaa !24
  %t447 = load i64, ptr %l242, !tbaa !24
  %t448 = load %"compiler/source:Span", ptr %l243
  %t449 = load %"compiler/msgs:Msg", ptr %l248
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enote(ptr %v0, ptr %s21, ptr %t445, i64 %t446, i64 %t447, %"compiler/source:Span" %t448, %"compiler/msgs:Msg" %t449)
  br label %bb152
bb152:
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb153:
  call void @__olang_scope_close(ptr %s18)
  br label %bb154
bb154:
  %t450 = getelementptr %"compiler/typed:Local", ptr %l19, i32 0, i32 2
  %t451 = load i32, ptr %t450, !tbaa !23
  store i32 %t451, ptr %l26, !tbaa !23
  %t453 = load ptr, ptr %l0, !tbaa !29
  %t455 = getelementptr %"compiler/scope:Scoper", ptr %t453, i32 0, i32 0
  %t456 = load ptr, ptr %t455, !tbaa !29
  %t458 = getelementptr %"compiler/generic:Program", ptr %t456, i32 0, i32 2
  %t459 = load i32, ptr %l26, !tbaa !23
  %t462 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t458, i32 %t459)
  store i32 %t462, ptr %l254
  br label %bb155
bb155:
  %t463 = load i32, ptr %l254, !range !{i32 0, i32 33}
  store i32 %t463, ptr %l27
  %t464 = load ptr, ptr %l0, !tbaa !29
  %t465 = load i32, ptr %l26, !tbaa !23
  %t468 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t464, i32 %t465)
  store i1 %t468, ptr %l257
  br label %bb156
bb156:
  %t469 = load i1, ptr %l257, !tbaa !21
  %t470 = xor i1 %t469, true
  br i1 %t470, label %bb157, label %bb158
bb157:
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t473 = load i32, ptr %l26, !tbaa !23
  %t476 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t472, i32 %t473)
  store i1 %t476, ptr %l262
  br label %bb159
bb158:
  store i1 false, ptr %l259, !tbaa !21
  br label %bb160
bb159:
  %t477 = load i1, ptr %l262, !tbaa !21
  %t478 = xor i1 %t477, true
  store i1 %t478, ptr %l259, !tbaa !21
  br label %bb160
bb160:
  %t480 = load i1, ptr %l259, !tbaa !21
  br i1 %t480, label %bb161, label %bb162
bb161:
  %t481 = load i32, ptr %l27, !range !{i32 0, i32 33}
  %t483 = trunc i64 19 to i32
  %t484 = icmp eq i32 %t481, %t483
  %t486 = xor i1 %t484, true
  store i1 %t486, ptr %l264, !tbaa !21
  br label %bb163
bb162:
  store i1 false, ptr %l264, !tbaa !21
  br label %bb163
bb163:
  %t488 = load i1, ptr %l264, !tbaa !21
  br i1 %t488, label %bb164, label %bb165
bb164:
  %t489 = load i32, ptr %l27, !range !{i32 0, i32 33}
  %t491 = trunc i64 18 to i32
  %t492 = icmp eq i32 %t489, %t491
  %t494 = xor i1 %t492, true
  store i1 %t494, ptr %l268, !tbaa !21
  br label %bb166
bb165:
  store i1 false, ptr %l268, !tbaa !21
  br label %bb166
bb166:
  %t496 = load i1, ptr %l268, !tbaa !21
  br i1 %t496, label %bb167, label %bb168
bb167:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb168:
  br label %bb169
bb169:
  %t497 = load ptr, ptr %l0, !tbaa !29
  %t499 = getelementptr %"compiler/scope:Scoper", ptr %t497, i32 0, i32 5
  %t500 = load { ptr, ptr }, ptr %t499
  %t502 = extractvalue { ptr, ptr } %t500, 0
  %t503 = extractvalue { ptr, ptr } zeroinitializer, 0
  %t504 = icmp eq ptr %t502, %t503
  %t505 = extractvalue { ptr, ptr } %t500, 1
  %t506 = extractvalue { ptr, ptr } zeroinitializer, 1
  %t507 = icmp eq ptr %t505, %t506
  %t508 = and i1 %t504, %t507
  br i1 %t508, label %bb170, label %bb171
bb170:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb171:
  br label %bb172
bb172:
  %t510 = load ptr, ptr %l0, !tbaa !29
  %t511 = load i32, ptr %l26, !tbaa !23
  %t514 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t510, i32 %t511)
  store i1 %t514, ptr %l277
  br label %bb173
bb173:
  %t515 = load i1, ptr %l277, !tbaa !21
  br i1 %t515, label %bb174, label %bb175
bb174:
  %t516 = load ptr, ptr %l0, !tbaa !29
  %t518 = getelementptr %"compiler/scope:Scoper", ptr %t516, i32 0, i32 0
  %t519 = load ptr, ptr %t518, !tbaa !29
  %t521 = getelementptr %"compiler/generic:Program", ptr %t519, i32 0, i32 2
  %t522 = load i32, ptr %l26, !tbaa !23
  %t525 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t521, i32 %t522)
  store i32 %t525, ptr %l283
  br label %bb176
bb175:
  %t526 = load i32, ptr %l26, !tbaa !23
  store i32 %t526, ptr %l278, !tbaa !23
  br label %bb177
bb176:
  %t528 = load i32, ptr %l283, !tbaa !23
  store i32 %t528, ptr %l278, !tbaa !23
  br label %bb177
bb177:
  %t529 = load i32, ptr %l278, !tbaa !23
  store i32 %t529, ptr %l28, !tbaa !23
  %t530 = load ptr, ptr %l0, !tbaa !29
  %t531 = load ptr, ptr %l0, !tbaa !29
  %t533 = getelementptr %"compiler/scope:Scoper", ptr %t531, i32 0, i32 26
  %t534 = load i64, ptr %t533, !tbaa !24
  %t537 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2einstanceOf(ptr %v0, ptr %t530, i64 %t534)
  store i64 %t537, ptr %l288
  br label %bb178
bb178:
  %t538 = load i64, ptr %l288, !tbaa !24
  store i64 %t538, ptr %l29, !tbaa !24
  %t539 = load i64, ptr %l29, !tbaa !24
  %t541 = icmp sge i64 %t539, 0
  br i1 %t541, label %bb179, label %bb180
bb179:
  %t543 = load ptr, ptr %l0, !tbaa !29
  %t545 = getelementptr %"compiler/scope:Scoper", ptr %t543, i32 0, i32 0
  %t546 = load ptr, ptr %t545, !tbaa !29
  %t548 = getelementptr %"compiler/generic:Program", ptr %t546, i32 0, i32 2
  store ptr %t548, ptr %l294, !tbaa !29
  %t549 = load ptr, ptr %l0, !tbaa !29
  %t551 = getelementptr %"compiler/scope:Scoper", ptr %t549, i32 0, i32 0
  %t552 = load ptr, ptr %t551, !tbaa !29
  %t553 = load i64, ptr %l29, !tbaa !24
  %t556 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t552, i64 %t553)
  store i32 %t556, ptr %l298
  br label %bb181
bb180:
  store i1 false, ptr %l291, !tbaa !21
  br label %bb183
bb181:
  %t557 = load ptr, ptr %l294, !tbaa !29
  %t558 = load i32, ptr %l298, !tbaa !23
  %t559 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t557, i32 %t558)
  store { i64, ptr } %t559, ptr %l299
  br label %bb182
bb182:
  %t560 = load { i64, ptr }, ptr %l299, !tbaa !27
  %t561 = extractvalue { i64, ptr } %t560, 0
  %t563 = icmp sgt i64 %t561, 0
  store i1 %t563, ptr %l291, !tbaa !21
  br label %bb183
bb183:
  %t565 = load i1, ptr %l291, !tbaa !21
  br i1 %t565, label %bb184, label %bb185
bb184:
  %t566 = load ptr, ptr %l0, !tbaa !29
  %t568 = getelementptr %"compiler/scope:Scoper", ptr %t566, i32 0, i32 0
  %t569 = load ptr, ptr %t568, !tbaa !29
  store ptr %t569, ptr %l303, !tbaa !29
  %t570 = load i32, ptr %l28, !tbaa !23
  store i32 %t570, ptr %l304, !tbaa !23
  %t571 = load ptr, ptr %l0, !tbaa !29
  %t573 = getelementptr %"compiler/scope:Scoper", ptr %t571, i32 0, i32 0
  %t574 = load ptr, ptr %t573, !tbaa !29
  %t575 = load i64, ptr %l29, !tbaa !24
  %t578 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t574, i64 %t575)
  store i64 %t578, ptr %l308
  br label %bb186
bb185:
  br label %bb194
bb186:
  %t579 = load i64, ptr %l308, !tbaa !24
  %t580 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t579)
  store i64 %t580, ptr %l309
  br label %bb187
bb187:
  %t581 = load ptr, ptr %l0, !tbaa !29
  %t583 = getelementptr %"compiler/scope:Scoper", ptr %t581, i32 0, i32 0
  %t584 = load ptr, ptr %t583, !tbaa !29
  %t585 = load i64, ptr %l29, !tbaa !24
  %t588 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t584, i64 %t585)
  store i32 %t588, ptr %l313
  br label %bb188
bb188:
  %t589 = load ptr, ptr %l303, !tbaa !29
  %t590 = load i32, ptr %l304, !tbaa !23
  %t591 = load i64, ptr %l309, !tbaa !24
  %t592 = load i32, ptr %l313, !tbaa !23
  %t593 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnsubst(ptr %v0, ptr %t589, i32 %t590, i64 %t591, i32 %t592)
  store i32 %t593, ptr %l314
  br label %bb189
bb189:
  %t594 = load i32, ptr %l314, !tbaa !23
  store i32 %t594, ptr %l28, !tbaa !23
  %t595 = load i32, ptr %l28, !tbaa !23
  %t596 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t599 = icmp eq i32 %t595, %t596
  br i1 %t599, label %bb190, label %bb191
bb190:
  %t601 = load ptr, ptr %l0, !tbaa !29
  %t603 = getelementptr %"compiler/scope:Scoper", ptr %t601, i32 0, i32 0
  %t604 = load ptr, ptr %t603, !tbaa !29
  %t606 = getelementptr %"compiler/generic:Program", ptr %t604, i32 0, i32 0
  %t607 = load ptr, ptr %t606, !tbaa !29
  %t609 = getelementptr %"compiler/load:Loader", ptr %t607, i32 0, i32 4
  %t610 = load ptr, ptr %t609, !tbaa !29
  %t611 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eYield(ptr %v0, ptr %t610, i64 %t611)
  br label %bb192
bb191:
  br label %bb193
bb192:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb193:
  br label %bb194
bb194:
  %t614 = load ptr, ptr %l0, !tbaa !29
  %t615 = load i32, ptr %l26, !tbaa !23
  %t618 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t614, i32 %t615)
  store i1 %t618, ptr %l325
  br label %bb195
bb195:
  %t619 = load i1, ptr %l325, !tbaa !21
  br i1 %t619, label %bb196, label %bb197
bb196:
  %t620 = load ptr, ptr %l0, !tbaa !29
  %t622 = getelementptr %"compiler/scope:Scoper", ptr %t620, i32 0, i32 0
  %t623 = load ptr, ptr %t622, !tbaa !29
  %t625 = getelementptr %"compiler/generic:Program", ptr %t623, i32 0, i32 2
  %t626 = load i32, ptr %l26, !tbaa !23
  %t629 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t625, i32 %t626)
  store i64 %t629, ptr %l331
  br label %bb198
bb197:
  store i1 true, ptr %l326, !tbaa !21
  br label %bb199
bb198:
  %t630 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t631 = load i64, ptr %l331, !tbaa !24
  %t633 = and i64 %t631, %t630
  %t635 = icmp ne i64 %t633, 0
  store i1 %t635, ptr %l326, !tbaa !21
  br label %bb199
bb199:
  %t637 = load i1, ptr %l326, !tbaa !21
  br i1 %t637, label %bb200, label %bb201
bb200:
  %t640 = load ptr, ptr %l0, !tbaa !29
  %t641 = load i32, ptr %l28, !tbaa !23
  %t644 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFunc(ptr %v0, ptr %t640, i32 %t641)
  store i1 %t644, ptr %l339
  br label %bb202
bb201:
  store i1 false, ptr %l336, !tbaa !21
  br label %bb203
bb202:
  %t645 = load i1, ptr %l339, !tbaa !21
  %t646 = xor i1 %t645, true
  store i1 %t646, ptr %l336, !tbaa !21
  br label %bb203
bb203:
  %t648 = load i1, ptr %l336, !tbaa !21
  br i1 %t648, label %bb204, label %bb205
bb204:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr %l341, !tbaa !27
  br label %bb206
bb205:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d13, i32 0, i32 1) }, ptr %l341, !tbaa !27
  br label %bb206
bb206:
  %t649 = load ptr, ptr %l0, !tbaa !29
  %t651 = getelementptr %"compiler/scope:Scoper", ptr %t649, i32 0, i32 5
  %t652 = load { ptr, ptr }, ptr %t651
  %t653 = load i32, ptr %l28, !tbaa !23
  %t655 = extractvalue { ptr, ptr } %t652, 0
  %t656 = extractvalue { ptr, ptr } %t652, 1
  %t658 = call { i64, ptr } %t655(ptr %t656, ptr %s0, i32 %t653)
  store { i64, ptr } %t658, ptr %l345
  br label %bb207
bb207:
  %t659 = load { i64, ptr }, ptr %l341, !tbaa !27
  %t660 = extractvalue { i64, ptr } %t659, 1
  %t661 = extractvalue { i64, ptr } %t659, 0
  %t662 = load { i64, ptr }, ptr %l345, !tbaa !27
  %t663 = extractvalue { i64, ptr } %t662, 1
  %t664 = extractvalue { i64, ptr } %t662, 0
  %t665 = add i64 %t661, %t664
  %t666 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t665)
  call void @olang_textcopy(ptr %t666, ptr %t660, i64 %t661)
  %t667 = getelementptr i8, ptr %t666, i64 %t661
  call void @olang_textcopy(ptr %t667, ptr %t663, i64 %t664)
  %t668 = insertvalue { i64, ptr } undef, i64 %t665, 0
  %t669 = insertvalue { i64, ptr } %t668, ptr %t666, 1
  store { i64, ptr } %t669, ptr %l31, !tbaa !27
  %t671 = load ptr, ptr %l0, !tbaa !29
  store ptr %t671, ptr %l347, !tbaa !29
  %t672 = load i64, ptr %l1, !tbaa !24
  store i64 %t672, ptr %l348, !tbaa !24
  %t673 = load ptr, ptr %l0, !tbaa !29
  %t675 = getelementptr %"compiler/scope:Scoper", ptr %t673, i32 0, i32 25
  %t676 = load ptr, ptr %t675, !tbaa !29
  %t678 = icmp eq ptr %t676, null
  br i1 %t678, label %bb208, label %bb209
bb208:
  call void @__olang_check_failed(ptr @olang_loc_b5bb9adcdc2b0f40_ee4aa96e819ebaec)
  unreachable
bb209:
  br label %bb210
bb210:
  %t680 = load ptr, ptr %l0, !tbaa !29
  %t682 = getelementptr %"compiler/scope:Scoper", ptr %t680, i32 0, i32 25
  %t683 = load ptr, ptr %t682, !tbaa !29
  %t686 = getelementptr %"compiler/typed:Body", ptr %t683, i32 0, i32 3
  %t687 = load i64, ptr %t686, !tbaa !24
  store i64 %t687, ptr %l355, !tbaa !24
  %t688 = load %"compiler/source:Span", ptr %l22
  store %"compiler/source:Span" %t688, ptr %l356
  %t689 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t690 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t691 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t692 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t693 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t699 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDeclareWhere(ptr %v0, ptr %v2, ptr %v0, ptr %s0, ptr %v2, ptr %s0, { i64, ptr } %t689, { i64, ptr } %t690, { i64, ptr } %t691, { i64, ptr } %t692, { i64, ptr } %t693)
  store %"compiler/msgs:Msg" %t699, ptr %l362
  br label %bb211
bb211:
  %t700 = load ptr, ptr %l347, !tbaa !29
  %t701 = load i64, ptr %l348, !tbaa !24
  %t702 = load i64, ptr %l355, !tbaa !24
  %t703 = load %"compiler/source:Span", ptr %l356
  %t704 = load %"compiler/msgs:Msg", ptr %l362
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enote(ptr %v0, ptr %s0, ptr %t700, i64 %t701, i64 %t702, %"compiler/source:Span" %t703, %"compiler/msgs:Msg" %t704)
  br label %bb212
bb212:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eoblige(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i1
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca { i64, [2 x i64] }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca { i64, [2 x i64] }
  %l20 = alloca i64
  %l23 = alloca { i64, [2 x i64] }
  %l29 = alloca { i64, [2 x i64] }
  %l32 = alloca { i64, [2 x i64] }
  %l38 = alloca { i64, [2 x i64] }
  %l45 = alloca i64
  %l48 = alloca i64
  %l52 = alloca i64
  %l55 = alloca i64
  %l76 = alloca { i64, [2 x i64] }
  %l80 = alloca i64
  %l95 = alloca i64
  %l98 = alloca i64
  %l102 = alloca i64
  %l105 = alloca i64
  %l126 = alloca { i64, [2 x i64] }
  %l130 = alloca i64
  %l143 = alloca i1
  %l147 = alloca i1
  %l149 = alloca ptr
  %l156 = alloca %"compiler/scope:rel"
  %l158 = alloca ptr
  %l165 = alloca %"compiler/scope:rel"
  %s0 = alloca %olang.scope
  %s16 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  store { i64, [2 x i64] } %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load { i64, [2 x i64] }, ptr %l1
  %t5 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efloorOf(ptr %v0, ptr %t1, { i64, [2 x i64] } %t2)
  store { i64, [2 x i64] } %t5, ptr %l23
  br label %bb1
bb1:
  %t6 = load { i64, [2 x i64] }, ptr %l23
  %t8 = extractvalue { i64, [2 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 0
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load { i64, [2 x i64] }, ptr %l1
  %t17 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efloorOf(ptr %v0, ptr %t13, { i64, [2 x i64] } %t14)
  store { i64, [2 x i64] } %t17, ptr %l29
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t18 = load { i64, [2 x i64] }, ptr %l29
  store { i64, [2 x i64] } %t18, ptr %l1
  br label %bb5
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load { i64, [2 x i64] }, ptr %l2
  %t23 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efloorOf(ptr %v0, ptr %t19, { i64, [2 x i64] } %t20)
  store { i64, [2 x i64] } %t23, ptr %l32
  br label %bb6
bb6:
  %t24 = load { i64, [2 x i64] }, ptr %l32
  %t26 = extractvalue { i64, [2 x i64] } %t24, 0
  %t27 = icmp eq i64 %t26, 0
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb7, label %bb8
bb7:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load { i64, [2 x i64] }, ptr %l2
  %t35 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efloorOf(ptr %v0, ptr %t31, { i64, [2 x i64] } %t32)
  store { i64, [2 x i64] } %t35, ptr %l38
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t36 = load { i64, [2 x i64] }, ptr %l38
  store { i64, [2 x i64] } %t36, ptr %l2
  br label %bb10
bb10:
  %t37 = load { i64, [2 x i64] }, ptr %l1
  %t39 = extractvalue { i64, [2 x i64] } %t37, 0
  %t40 = icmp eq i64 %t39, 5
  br i1 %t40, label %bb11, label %bb12
bb11:
  %t42 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t43 = getelementptr { i64 }, ptr %t42, i32 0, i32 0
  %t44 = load i64, ptr %t43
  store i64 %t44, ptr %l4, !tbaa !24
  br label %bb13
bb12:
  br label %bb34
bb13:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/scope:Scoper", ptr %t46, i32 0, i32 36
  %t49 = load i64, ptr %l4, !tbaa !24
  %t52 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t48, i64 %t49)
  store i64 %t52, ptr %l45
  br label %bb14
bb14:
  %t53 = load i64, ptr %l45, !tbaa !24
  store i64 %t53, ptr %l5, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i64, ptr %l4, !tbaa !24
  %t58 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esetEnd(ptr %v0, ptr %t54, i64 %t55)
  store i64 %t58, ptr %l48
  br label %bb15
bb15:
  %t59 = load i64, ptr %l48, !tbaa !24
  store i64 %t59, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t60 = load i64, ptr %l6, !tbaa !24
  %t61 = load i64, ptr %l5, !tbaa !24
  %t64 = icmp sgt i64 %t60, %t61
  br i1 %t64, label %bb16, label %bb17
bb16:
  %t66 = load i64, ptr %l7, !tbaa !24
  %t68 = icmp sgt i64 %t66, 0
  br i1 %t68, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb21
bb18:
  %t70 = load i64, ptr %l6, !tbaa !24
  %t71 = load i64, ptr %l5, !tbaa !24
  %t74 = sub i64 %t70, %t71
  %t75 = load i64, ptr %l7, !tbaa !24
  %t78 = add i64 %t74, %t75
  %t80 = sub i64 %t78, 1
  %t81 = load i64, ptr %l7, !tbaa !24
  %t84 = sdiv i64 %t80, %t81
  store i64 %t84, ptr %l55, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb20
bb20:
  %t86 = load i64, ptr %l55, !tbaa !24
  store i64 %t86, ptr %l52, !tbaa !24
  br label %bb21
bb21:
  %t87 = load i64, ptr %l52, !tbaa !24
  store i64 %t87, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb22
bb22:
  %t88 = load i64, ptr %l9, !tbaa !24
  %t89 = load i64, ptr %l8, !tbaa !24
  %t92 = icmp slt i64 %t88, %t89
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb23, label %bb24
bb23:
  br label %bb33
bb24:
  br label %bb25
bb25:
  %t96 = load i64, ptr %l5, !tbaa !24
  %t97 = load i64, ptr %l9, !tbaa !24
  %t98 = load i64, ptr %l7, !tbaa !24
  %t101 = mul i64 %t97, %t98
  %t104 = add i64 %t96, %t101
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/scope:Scoper", ptr %t106, i32 0, i32 37
  %t112 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t108, i64 %t104)
  store { i64, [2 x i64] } %t112, ptr %l76
  br label %bb26
bb26:
  %t113 = load { i64, [2 x i64] }, ptr %l76
  store { i64, [2 x i64] } %t113, ptr %l11
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load { i64, [2 x i64] }, ptr %l11
  %t116 = load { i64, [2 x i64] }, ptr %l2
  %t120 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eorder(ptr %v0, ptr %t114, { i64, [2 x i64] } %t115, { i64, [2 x i64] } %t116)
  store i64 %t120, ptr %l80
  br label %bb27
bb27:
  %t121 = load i64, ptr @G_2ecompiler_2fscope_2eObliged, !tbaa !24
  %t122 = load i64, ptr %l80, !tbaa !24
  %t124 = icmp eq i64 %t122, %t121
  br i1 %t124, label %bb28, label %bb29
bb28:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load { i64, [2 x i64] }, ptr %l11
  %t128 = load { i64, [2 x i64] }, ptr %l2
  %t129 = load i1, ptr %l3, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eoblige(ptr %v0, ptr %t126, { i64, [2 x i64] } %t127, { i64, [2 x i64] } %t128, i1 %t129)
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t134 = load i64, ptr %l9, !tbaa !24
  %t136 = add i64 %t134, 1
  store i64 %t136, ptr %l9, !tbaa !24
  br label %bb22
bb33:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb34:
  br i1 true, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_322b5045d3cabfc4_8f4e43b4ddbaa588)
  unreachable
bb39:
  %t138 = load { i64, [2 x i64] }, ptr %l2
  %t140 = extractvalue { i64, [2 x i64] } %t138, 0
  %t141 = icmp eq i64 %t140, 5
  br i1 %t141, label %bb40, label %bb41
bb40:
  %t143 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t144 = getelementptr { i64 }, ptr %t143, i32 0, i32 0
  %t145 = load i64, ptr %t144
  store i64 %t145, ptr %l12, !tbaa !24
  br label %bb42
bb41:
  br label %bb63
bb42:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/scope:Scoper", ptr %t147, i32 0, i32 36
  %t150 = load i64, ptr %l12, !tbaa !24
  %t153 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t149, i64 %t150)
  store i64 %t153, ptr %l95
  br label %bb43
bb43:
  %t154 = load i64, ptr %l95, !tbaa !24
  store i64 %t154, ptr %l13, !tbaa !24
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load i64, ptr %l12, !tbaa !24
  %t159 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esetEnd(ptr %v0, ptr %t155, i64 %t156)
  store i64 %t159, ptr %l98
  br label %bb44
bb44:
  %t160 = load i64, ptr %l98, !tbaa !24
  store i64 %t160, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t161 = load i64, ptr %l14, !tbaa !24
  %t162 = load i64, ptr %l13, !tbaa !24
  %t165 = icmp sgt i64 %t161, %t162
  br i1 %t165, label %bb45, label %bb46
bb45:
  %t167 = load i64, ptr %l15, !tbaa !24
  %t169 = icmp sgt i64 %t167, 0
  br i1 %t169, label %bb47, label %bb48
bb46:
  store i64 0, ptr %l102, !tbaa !24
  br label %bb50
bb47:
  %t171 = load i64, ptr %l14, !tbaa !24
  %t172 = load i64, ptr %l13, !tbaa !24
  %t175 = sub i64 %t171, %t172
  %t176 = load i64, ptr %l15, !tbaa !24
  %t179 = add i64 %t175, %t176
  %t181 = sub i64 %t179, 1
  %t182 = load i64, ptr %l15, !tbaa !24
  %t185 = sdiv i64 %t181, %t182
  store i64 %t185, ptr %l105, !tbaa !24
  br label %bb49
bb48:
  store i64 0, ptr %l105, !tbaa !24
  br label %bb49
bb49:
  %t187 = load i64, ptr %l105, !tbaa !24
  store i64 %t187, ptr %l102, !tbaa !24
  br label %bb50
bb50:
  %t188 = load i64, ptr %l102, !tbaa !24
  store i64 %t188, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb51
bb51:
  %t189 = load i64, ptr %l17, !tbaa !24
  %t190 = load i64, ptr %l16, !tbaa !24
  %t193 = icmp slt i64 %t189, %t190
  %t195 = xor i1 %t193, true
  br i1 %t195, label %bb52, label %bb53
bb52:
  br label %bb62
bb53:
  br label %bb54
bb54:
  %t197 = load i64, ptr %l13, !tbaa !24
  %t198 = load i64, ptr %l17, !tbaa !24
  %t199 = load i64, ptr %l15, !tbaa !24
  %t202 = mul i64 %t198, %t199
  %t205 = add i64 %t197, %t202
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t209 = getelementptr %"compiler/scope:Scoper", ptr %t207, i32 0, i32 37
  %t213 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t209, i64 %t205)
  store { i64, [2 x i64] } %t213, ptr %l126
  br label %bb55
bb55:
  %t214 = load { i64, [2 x i64] }, ptr %l126
  store { i64, [2 x i64] } %t214, ptr %l19
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load { i64, [2 x i64] }, ptr %l1
  %t217 = load { i64, [2 x i64] }, ptr %l19
  %t221 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eorder(ptr %v0, ptr %t215, { i64, [2 x i64] } %t216, { i64, [2 x i64] } %t217)
  store i64 %t221, ptr %l130
  br label %bb56
bb56:
  %t222 = load i64, ptr @G_2ecompiler_2fscope_2eObliged, !tbaa !24
  %t223 = load i64, ptr %l130, !tbaa !24
  %t225 = icmp eq i64 %t223, %t222
  br i1 %t225, label %bb57, label %bb58
bb57:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load { i64, [2 x i64] }, ptr %l1
  %t229 = load { i64, [2 x i64] }, ptr %l19
  %t230 = load i1, ptr %l3, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eoblige(ptr %v0, ptr %t227, { i64, [2 x i64] } %t228, { i64, [2 x i64] } %t229, i1 %t230)
  br label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t235 = load i64, ptr %l17, !tbaa !24
  %t237 = add i64 %t235, 1
  store i64 %t237, ptr %l17, !tbaa !24
  br label %bb51
bb62:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb63:
  br i1 true, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_7295af1014264eb5_7e53551048ac1f59)
  unreachable
bb68:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/scope:Scoper", ptr %t239, i32 0, i32 100
  %t242 = load i64, ptr %t241, !tbaa !24
  store i64 %t242, ptr %l20, !tbaa !24
  %t244 = load i64, ptr %l20, !tbaa !24
  %t246 = icmp eq i64 %t244, 0
  br i1 %t246, label %bb69, label %bb70
bb69:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load { i64, [2 x i64] }, ptr %l1
  %t250 = load { i64, [2 x i64] }, ptr %l2
  %t254 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2einstanceRel(ptr %v0, ptr %t248, { i64, [2 x i64] } %t249, { i64, [2 x i64] } %t250)
  store i1 %t254, ptr %l147
  br label %bb71
bb70:
  store i1 false, ptr %l143, !tbaa !21
  br label %bb72
bb71:
  %t255 = load i1, ptr %l147, !tbaa !21
  store i1 %t255, ptr %l143, !tbaa !21
  br label %bb72
bb72:
  %t256 = load i1, ptr %l143, !tbaa !21
  br i1 %t256, label %bb73, label %bb74
bb73:
  %t257 = load i64, ptr @G_2ecompiler_2fscope_2eWhyHolds, !tbaa !24
  store i64 %t257, ptr %l20, !tbaa !24
  br label %bb75
bb74:
  br label %bb75
bb75:
  %t259 = load ptr, ptr %l0, !tbaa !29
  store ptr %t259, ptr %l149, !tbaa !29
  %t260 = load { i64, [2 x i64] }, ptr %l1
  %t261 = load { i64, [2 x i64] }, ptr %l2
  %t262 = load i1, ptr %l3, !tbaa !21
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = getelementptr %"compiler/scope:Scoper", ptr %t263, i32 0, i32 38
  %t266 = load %"compiler/source:Span", ptr %t265
  %t267 = load i64, ptr %l20, !tbaa !24
  %t273 = call %"compiler/scope:rel" @compiler_2fscope_3arel_2ector(ptr %s0, { i64, [2 x i64] } %t260, { i64, [2 x i64] } %t261, i1 %t262, %"compiler/source:Span" %t266, i64 %t267)
  store %"compiler/scope:rel" %t273, ptr %l156
  br label %bb76
bb76:
  %t274 = load ptr, ptr %l149, !tbaa !29
  %t275 = load %"compiler/scope:rel", ptr %l156
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eaddRel(ptr %v0, ptr %t274, %"compiler/scope:rel" %t275)
  br label %bb77
bb77:
  %t276 = load i1, ptr %l3, !tbaa !21
  br i1 %t276, label %bb78, label %bb79
bb78:
  store %olang.scope zeroinitializer, ptr %s16
  %t278 = load ptr, ptr %l0, !tbaa !29
  store ptr %t278, ptr %l158, !tbaa !29
  %t279 = load { i64, [2 x i64] }, ptr %l2
  %t280 = load { i64, [2 x i64] }, ptr %l1
  %t281 = load i1, ptr %l3, !tbaa !21
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t284 = getelementptr %"compiler/scope:Scoper", ptr %t282, i32 0, i32 38
  %t285 = load %"compiler/source:Span", ptr %t284
  %t286 = load i64, ptr %l20, !tbaa !24
  %t292 = call %"compiler/scope:rel" @compiler_2fscope_3arel_2ector(ptr %s16, { i64, [2 x i64] } %t279, { i64, [2 x i64] } %t280, i1 %t281, %"compiler/source:Span" %t285, i64 %t286)
  store %"compiler/scope:rel" %t292, ptr %l165
  br label %bb80
bb79:
  br label %bb82
bb80:
  %t293 = load ptr, ptr %l158, !tbaa !29
  %t294 = load %"compiler/scope:rel", ptr %l165
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eaddRel(ptr %v0, ptr %t293, %"compiler/scope:rel" %t294)
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s16)
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eocExprs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2, i1 %a3) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l15 = alloca { i64, ptr }
  %l23 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l6, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l6, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t15, ptr %l15, !tbaa !27
  %t16 = load i64, ptr %l5, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  %t32 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eocExpr(ptr %v0, ptr %v1, ptr %a0, ptr %t21, i64 %a2, i1 %a3)
  store i1 %t32, ptr %l23
  br label %bb5
bb5:
  %t33 = load i1, ptr %l23, !tbaa !21
  %t34 = xor i1 %t33, true
  br i1 %t34, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t37 = load i64, ptr %l5, !tbaa !24
  %t39 = add i64 %t37, 1
  store i64 %t39, ptr %l5, !tbaa !24
  br label %bb1
bb10:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eoldValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l6 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l24 = alloca ptr
  %l26 = alloca ptr
  %l29 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca i32
  %l33 = alloca i1
  %l35 = alloca i1
  %l36 = alloca ptr
  %l38 = alloca ptr
  %l41 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 57
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eLen__H22c160154c8542d83ffe3c77c98973d0(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t15 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %t10, ptr %a1)
  store ptr %t15, ptr %l12
  br label %bb5
bb5:
  %t16 = load ptr, ptr %l12, !tbaa !29
  store ptr %t16, ptr %l2, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  store ptr %t17, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t18 = load ptr, ptr %l13, !tbaa !29
  %t19 = icmp ne ptr %t18, null
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %l13, !tbaa !29
  %t22 = load i64, ptr %t21, !range !{i64 0, i64 18}
  %t24 = icmp eq i64 %t22, 2
  store i1 %t24, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t25 = load i1, ptr %l14, !tbaa !21
  br i1 %t25, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = getelementptr { i64, [5 x i64] }, ptr %t26, i32 0, i32 1
  %t29 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t28, i32 0, i32 2
  %t30 = load ptr, ptr %t29
  store ptr %t30, ptr %l3, !tbaa !29
  br label %bb10
bb9:
  br label %bb31
bb10:
  %t32 = load ptr, ptr %l3, !tbaa !29
  store ptr %t32, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t33 = load ptr, ptr %l19, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t36 = load ptr, ptr %l19, !tbaa !29
  %t37 = load i64, ptr %t36, !range !{i64 0, i64 8}
  %t39 = icmp eq i64 %t37, 7
  store i1 %t39, ptr %l20, !tbaa !21
  br label %bb12
bb12:
  %t40 = load i1, ptr %l20, !tbaa !21
  br i1 %t40, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i1 true, ptr %rv
  br label %ret
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb30
bb19:
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l24, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/scope:Scoper", ptr %t43, i32 0, i32 57
  store ptr %t45, ptr %l26, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/scope:Scoper", ptr %t46, i32 0, i32 57
  %t50 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eLen__H22c160154c8542d83ffe3c77c98973d0(ptr %v0, ptr %t48)
  store i64 %t50, ptr %l29
  br label %bb20
bb20:
  %t51 = load i64, ptr %l29, !tbaa !24
  %t52 = sub i64 %t51, 1
  %t53 = load ptr, ptr %l26, !tbaa !29
  %t55 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eAt_3ccompiler_2ftyped_3aLvalue_26_3e(ptr %v0, ptr %v0, ptr %t53, i64 %t52)
  store ptr %t55, ptr %l31
  br label %bb21
bb21:
  %t56 = load ptr, ptr %l31, !tbaa !29
  %t57 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %t56)
  store i32 %t57, ptr %l32
  br label %bb22
bb22:
  %t58 = load ptr, ptr %l24, !tbaa !29
  %t59 = load i32, ptr %l32, !tbaa !23
  %t60 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t58, i32 %t59)
  store i1 %t60, ptr %l33
  br label %bb23
bb23:
  %t61 = load i1, ptr %l33, !tbaa !21
  %t62 = xor i1 %t61, true
  br i1 %t62, label %bb24, label %bb25
bb24:
  %t64 = load ptr, ptr %l3, !tbaa !29
  store ptr %t64, ptr %l36, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/scope:Scoper", ptr %t65, i32 0, i32 57
  store ptr %t67, ptr %l38, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/scope:Scoper", ptr %t68, i32 0, i32 57
  %t72 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eLen__H22c160154c8542d83ffe3c77c98973d0(ptr %v0, ptr %t70)
  store i64 %t72, ptr %l41
  br label %bb26
bb25:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb29
bb26:
  %t73 = load i64, ptr %l41, !tbaa !24
  %t74 = sub i64 %t73, 1
  %t75 = load ptr, ptr %l38, !tbaa !29
  %t77 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eAt_3ccompiler_2ftyped_3aLvalue_26_3e(ptr %v0, ptr %v0, ptr %t75, i64 %t74)
  store ptr %t77, ptr %l43
  br label %bb27
bb27:
  %t78 = load ptr, ptr %l36, !tbaa !29
  %t79 = load ptr, ptr %l43, !tbaa !29
  %t80 = call i1 @compiler_2fscope_2ewithin(ptr %v1, ptr %v0, ptr %t78, ptr %t79)
  store i1 %t80, ptr %l44
  br label %bb28
bb28:
  %t81 = load i1, ptr %l44, !tbaa !21
  store i1 %t81, ptr %l35, !tbaa !21
  br label %bb29
bb29:
  %t82 = load i1, ptr %l35, !tbaa !21
  store i1 %t82, ptr %rv
  br label %ret
bb30:
  call void @__olang_check_failed(ptr @olang_loc_40b97f37a7371750_40728193df6350fc)
  unreachable
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_f651c1e1d8a1ace1_d593723da6a130ad)
  unreachable
bb36:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eownerAt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l17 = alloca i64
  %l20 = alloca i64
  %l42 = alloca i1
  %l43 = alloca { i64, ptr }
  %l48 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l53 = alloca %"compiler/source:Span"
  %l54 = alloca %"compiler/source:Span"
  %rv = alloca %"compiler/source:Span"
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l5, !tbaa !24
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  store i64 %t6, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t8 = load i64, ptr %l6, !tbaa !24
  %t9 = load i64, ptr %l5, !tbaa !24
  %t12 = icmp sgt i64 %t8, %t9
  br i1 %t12, label %bb1, label %bb2
bb1:
  %t14 = load i64, ptr %l7, !tbaa !24
  %t16 = icmp sgt i64 %t14, 0
  br i1 %t16, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb3:
  %t18 = load i64, ptr %l6, !tbaa !24
  %t19 = load i64, ptr %l5, !tbaa !24
  %t22 = sub i64 %t18, %t19
  %t23 = load i64, ptr %l7, !tbaa !24
  %t26 = add i64 %t22, %t23
  %t28 = sub i64 %t26, 1
  %t29 = load i64, ptr %l7, !tbaa !24
  %t32 = sdiv i64 %t28, %t29
  store i64 %t32, ptr %l20, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb5
bb5:
  %t34 = load i64, ptr %l20, !tbaa !24
  store i64 %t34, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l17, !tbaa !24
  store i64 %t35, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l9, !tbaa !24
  %t37 = load i64, ptr %l8, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb8, label %bb9
bb8:
  br label %bb20
bb9:
  br label %bb10
bb10:
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l9, !tbaa !24
  %t46 = load i64, ptr %l7, !tbaa !24
  %t49 = mul i64 %t45, %t46
  %t52 = add i64 %t44, %t49
  store i64 %t52, ptr %l10, !tbaa !24
  %t54 = load i64, ptr %l10, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 0
  %t60 = icmp slt i64 %t54, %t57
  br i1 %t60, label %bb11, label %bb12
bb11:
  %t62 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t62, ptr %l43, !tbaa !27
  %t63 = load i64, ptr %l10, !tbaa !24
  %t65 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr i64, ptr %t66, i64 %t63
  %t68 = load i64, ptr %t67, !tbaa !34
  %t72 = icmp eq i64 %t68, %a3
  store i1 %t72, ptr %l42, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb13
bb13:
  %t74 = load i1, ptr %l42, !tbaa !21
  br i1 %t74, label %bb14, label %bb15
bb14:
  store ptr %a0, ptr %l48, !tbaa !29
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr %"compiler/typed:Call", ptr %t76, i32 0, i32 1
  %t79 = load { i64, ptr }, ptr %t78, !tbaa !27
  store { i64, ptr } %t79, ptr %l50, !tbaa !27
  %t80 = load i64, ptr %l10, !tbaa !24
  %t82 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr ptr, ptr %t83, i64 %t80
  %t85 = load ptr, ptr %t84, !tbaa !39
  %t87 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t85)
  store %"compiler/source:Span" %t87, ptr %l53
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t88 = load ptr, ptr %l48, !tbaa !29
  %t89 = load %"compiler/source:Span", ptr %l53
  %t90 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elastName(ptr %v0, ptr %t88, %"compiler/source:Span" %t89)
  store %"compiler/source:Span" %t90, ptr %l54
  br label %bb17
bb17:
  %t91 = load %"compiler/source:Span", ptr %l54
  store %"compiler/source:Span" %t91, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t92 = load i64, ptr %l9, !tbaa !24
  %t94 = add i64 %t92, 1
  store i64 %t94, ptr %l9, !tbaa !24
  br label %bb7
bb20:
  store %"compiler/source:Span" %a4, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparamBinding(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i32
  %l25 = alloca { i64, ptr }
  %l31 = alloca i64
  %l34 = alloca i64
  %l42 = alloca i64
  %l45 = alloca i64
  %l67 = alloca i1
  %l72 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [2 x i64] }
  %t13 = alloca { i64, [2 x i64] }, align 8
  %t132 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %t1, ptr %a1)
  store i32 %t5, ptr %l16
  br label %bb1
bb1:
  %t6 = load i32, ptr %l16, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  %t7 = load i32, ptr %l4, !tbaa !23
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t11 = icmp eq i32 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  store { i64, [2 x i64] } zeroinitializer, ptr %t13
  %t14 = getelementptr { i64, [2 x i64] }, ptr %t13, i32 0, i32 0
  store i64 0, ptr %t14
  %t15 = load { i64, [2 x i64] }, ptr %t13
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t15, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/scope:Scoper", ptr %t17, i32 0, i32 0
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 2
  %t23 = load i32, ptr %l4, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t22, i32 %t23)
  store { i64, ptr } %t26, ptr %l25
  br label %bb5
bb5:
  %t27 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t27, ptr %l5, !tbaa !27
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/scope:Scoper", ptr %t28, i32 0, i32 0
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  %t34 = load i32, ptr %l4, !tbaa !23
  %t35 = load i64, ptr %l2, !tbaa !24
  %t39 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t33, i32 %t34, i64 %t35)
  store i64 %t39, ptr %l31
  br label %bb6
bb6:
  %t40 = load i64, ptr %l31, !tbaa !24
  store i64 %t40, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l6, !tbaa !24
  %t43 = icmp sge i64 %t41, 0
  br i1 %t43, label %bb7, label %bb8
bb7:
  %t45 = load i64, ptr %l6, !tbaa !24
  store i64 %t45, ptr %l34, !tbaa !24
  br label %bb9
bb8:
  %t47 = load i64, ptr %l2, !tbaa !24
  store i64 %t47, ptr %l34, !tbaa !24
  br label %bb9
bb9:
  %t49 = load i64, ptr %l34, !tbaa !24
  store i64 %t49, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t50 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t50, 0
  store i64 %t52, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t54 = load i64, ptr %l9, !tbaa !24
  %t55 = load i64, ptr %l8, !tbaa !24
  %t58 = icmp sgt i64 %t54, %t55
  br i1 %t58, label %bb10, label %bb11
bb10:
  %t60 = load i64, ptr %l10, !tbaa !24
  %t62 = icmp sgt i64 %t60, 0
  br i1 %t62, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb15
bb12:
  %t64 = load i64, ptr %l9, !tbaa !24
  %t65 = load i64, ptr %l8, !tbaa !24
  %t68 = sub i64 %t64, %t65
  %t69 = load i64, ptr %l10, !tbaa !24
  %t72 = add i64 %t68, %t69
  %t74 = sub i64 %t72, 1
  %t75 = load i64, ptr %l10, !tbaa !24
  %t78 = sdiv i64 %t74, %t75
  store i64 %t78, ptr %l45, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb14
bb14:
  %t80 = load i64, ptr %l45, !tbaa !24
  store i64 %t80, ptr %l42, !tbaa !24
  br label %bb15
bb15:
  %t81 = load i64, ptr %l42, !tbaa !24
  store i64 %t81, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb16
bb16:
  %t82 = load i64, ptr %l12, !tbaa !24
  %t83 = load i64, ptr %l11, !tbaa !24
  %t86 = icmp slt i64 %t82, %t83
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb17, label %bb18
bb17:
  br label %bb27
bb18:
  br label %bb19
bb19:
  %t90 = load i64, ptr %l8, !tbaa !24
  %t91 = load i64, ptr %l12, !tbaa !24
  %t92 = load i64, ptr %l10, !tbaa !24
  %t95 = mul i64 %t91, %t92
  %t98 = add i64 %t90, %t95
  store i64 %t98, ptr %l13, !tbaa !24
  %t100 = load i64, ptr %l13, !tbaa !24
  %t102 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr i64, ptr %t103, i64 %t100
  %t105 = load i64, ptr %t104, !tbaa !34
  %t106 = load i64, ptr %l7, !tbaa !24
  %t109 = icmp eq i64 %t105, %t106
  br i1 %t109, label %bb20, label %bb21
bb20:
  %t111 = load i64, ptr %l13, !tbaa !24
  %t112 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t112, 0
  %t117 = icmp slt i64 %t111, %t114
  store i1 %t117, ptr %l67, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb22
bb22:
  %t119 = load i1, ptr %l67, !tbaa !21
  br i1 %t119, label %bb23, label %bb24
bb23:
  %t120 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t120, ptr %l72, !tbaa !27
  %t121 = load i64, ptr %l13, !tbaa !24
  %t123 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = getelementptr { i64, [2 x i64] }, ptr %t124, i64 %t121
  %t126 = load { i64, [2 x i64] }, ptr %t125
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t126, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t128 = load i64, ptr %l12, !tbaa !24
  %t130 = add i64 %t128, 1
  store i64 %t130, ptr %l12, !tbaa !24
  br label %bb16
bb27:
  store { i64, [2 x i64] } zeroinitializer, ptr %t132
  %t133 = getelementptr { i64, [2 x i64] }, ptr %t132, i32 0, i32 0
  store i64 0, ptr %t133
  %t134 = load { i64, [2 x i64] }, ptr %t132
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t134, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparamOfTerm(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i64
  %l3 = alloca { i64, [1 x i64] }
  %l4 = alloca i32
  %l8 = alloca i64
  %l16 = alloca i64
  %l26 = alloca { i64, [1 x i64] }
  %l39 = alloca %"compiler/typed:Local"
  %l42 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 2
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l2, !tbaa !24
  br label %bb3
bb2:
  br label %bb31
bb3:
  %t10 = load i64, ptr %l2, !tbaa !24
  store i64 %t10, ptr %l8, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 25
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = icmp eq ptr %t14, null
  br i1 %t16, label %bb4, label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_77d8df1bd6b52079_f0229fa895aca615)
  unreachable
bb5:
  br label %bb6
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/scope:Scoper", ptr %t18, i32 0, i32 25
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Body", ptr %t21, i32 0, i32 6
  %t26 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t24)
  store i64 %t26, ptr %l16
  br label %bb7
bb7:
  %t27 = load i64, ptr %l8, !tbaa !24
  %t28 = load i64, ptr %l16, !tbaa !24
  %t29 = icmp slt i64 %t27, %t28
  br i1 %t29, label %bb8, label %bb9
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/scope:Scoper", ptr %t31, i32 0, i32 25
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = icmp eq ptr %t34, null
  br i1 %t36, label %bb10, label %bb11
bb9:
  br label %bb30
bb10:
  call void @__olang_check_failed(ptr @olang_loc_bfd80b0298b19652_e537c33c4d886a6e)
  unreachable
bb11:
  br label %bb12
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/scope:Scoper", ptr %t38, i32 0, i32 25
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t44 = getelementptr %"compiler/typed:Body", ptr %t41, i32 0, i32 6
  %t45 = load i64, ptr %l2, !tbaa !24
  %t48 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t44, i64 %t45)
  store { i64, [1 x i64] } %t48, ptr %l26
  br label %bb13
bb13:
  %t49 = load { i64, [1 x i64] }, ptr %l26
  store { i64, [1 x i64] } %t49, ptr %l3
  %t50 = load { i64, [1 x i64] }, ptr %l3
  %t52 = extractvalue { i64, [1 x i64] } %t50, 0
  %t53 = icmp eq i64 %t52, 0
  br i1 %t53, label %bb14, label %bb15
bb14:
  %t55 = getelementptr { i64, [1 x i64] }, ptr %l3, i32 0, i32 1
  %t56 = getelementptr { i32 }, ptr %t55, i32 0, i32 0
  %t57 = load i32, ptr %t56
  store i32 %t57, ptr %l4, !tbaa !23
  br label %bb16
bb15:
  br label %bb24
bb16:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/scope:Scoper", ptr %t59, i32 0, i32 25
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = icmp eq ptr %t62, null
  br i1 %t64, label %bb17, label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_b1757fdcabe82f93_e12b45afd85e1a9f)
  unreachable
bb18:
  br label %bb19
bb19:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/scope:Scoper", ptr %t66, i32 0, i32 25
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Body", ptr %t69, i32 0, i32 7
  %t73 = load i32, ptr %l4, !tbaa !23
  %t75 = sext i32 %t73 to i64
  %t78 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t72, i64 %t75)
  store %"compiler/typed:Local" %t78, ptr %l39
  br label %bb20
bb20:
  %t79 = getelementptr %"compiler/typed:Local", ptr %l39, i32 0, i32 0
  %t80 = load i32, ptr %t79, !tbaa !23
  %t82 = icmp ne i32 %t80, 0
  br i1 %t82, label %bb21, label %bb22
bb21:
  %t84 = load i32, ptr %l4, !tbaa !23
  %t86 = sext i32 %t84 to i64
  store i64 %t86, ptr %l42, !tbaa !24
  br label %bb23
bb22:
  store i64 -1, ptr %l42, !tbaa !24
  br label %bb23
bb23:
  %t88 = load i64, ptr %l42, !tbaa !24
  store i64 %t88, ptr %rv
  br label %ret
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_a9000624b37114eb_4f5d8570083b5047)
  unreachable
bb29:
  br label %bb30
bb30:
  br label %bb36
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_6cb6018c48b7e44c_30fb4d691284a4b0)
  unreachable
bb36:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparamVar(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, [1 x i64] }
  %l12 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca i64
  %l20 = alloca i64
  %l26 = alloca i32
  %l29 = alloca i64
  %l33 = alloca i64
  %l36 = alloca i64
  %l57 = alloca { i64, [1 x i64] }
  %rv = alloca i64
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 1
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l16
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l16, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t9 = load i64, ptr %l2, !tbaa !24
  store i64 %t9, ptr %l17, !tbaa !24
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Body", ptr %t10, i32 0, i32 5
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l20
  br label %bb2
bb2:
  %t15 = load i64, ptr %l17, !tbaa !24
  %t16 = load i64, ptr %l20, !tbaa !24
  %t17 = icmp sge i64 %t15, %t16
  br i1 %t17, label %bb3, label %bb4
bb3:
  store i64 -1, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t20 = load ptr, ptr %l3, !tbaa !29
  %t22 = getelementptr %"compiler/typed:Body", ptr %t20, i32 0, i32 5
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t22, i64 %t23)
  store i32 %t26, ptr %l26
  br label %bb6
bb6:
  %t27 = load i32, ptr %l26, !tbaa !23
  store i32 %t27, ptr %l4, !tbaa !23
  store i64 0, ptr %l5, !tbaa !24
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Body", ptr %t28, i32 0, i32 6
  %t32 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t30)
  store i64 %t32, ptr %l29
  br label %bb7
bb7:
  %t33 = load i64, ptr %l29, !tbaa !24
  store i64 %t33, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t34 = load i64, ptr %l6, !tbaa !24
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = icmp sgt i64 %t34, %t35
  br i1 %t38, label %bb8, label %bb9
bb8:
  %t40 = load i64, ptr %l7, !tbaa !24
  %t42 = icmp sgt i64 %t40, 0
  br i1 %t42, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb13
bb10:
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = sub i64 %t44, %t45
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = add i64 %t48, %t49
  %t54 = sub i64 %t52, 1
  %t55 = load i64, ptr %l7, !tbaa !24
  %t58 = sdiv i64 %t54, %t55
  store i64 %t58, ptr %l36, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb12
bb12:
  %t60 = load i64, ptr %l36, !tbaa !24
  store i64 %t60, ptr %l33, !tbaa !24
  br label %bb13
bb13:
  %t61 = load i64, ptr %l33, !tbaa !24
  store i64 %t61, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb14
bb14:
  %t62 = load i64, ptr %l9, !tbaa !24
  %t63 = load i64, ptr %l8, !tbaa !24
  %t66 = icmp slt i64 %t62, %t63
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb15, label %bb16
bb15:
  br label %bb32
bb16:
  br label %bb17
bb17:
  %t70 = load i64, ptr %l5, !tbaa !24
  %t71 = load i64, ptr %l9, !tbaa !24
  %t72 = load i64, ptr %l7, !tbaa !24
  %t75 = mul i64 %t71, %t72
  %t78 = add i64 %t70, %t75
  store i64 %t78, ptr %l10, !tbaa !24
  %t80 = load ptr, ptr %l3, !tbaa !29
  %t82 = getelementptr %"compiler/typed:Body", ptr %t80, i32 0, i32 6
  %t83 = load i64, ptr %l10, !tbaa !24
  %t86 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t82, i64 %t83)
  store { i64, [1 x i64] } %t86, ptr %l57
  br label %bb18
bb18:
  %t87 = load { i64, [1 x i64] }, ptr %l57
  store { i64, [1 x i64] } %t87, ptr %l11
  %t88 = load { i64, [1 x i64] }, ptr %l11
  %t90 = extractvalue { i64, [1 x i64] } %t88, 0
  %t91 = icmp eq i64 %t90, 0
  br i1 %t91, label %bb19, label %bb20
bb19:
  %t93 = getelementptr { i64, [1 x i64] }, ptr %l11, i32 0, i32 1
  %t94 = getelementptr { i32 }, ptr %t93, i32 0, i32 0
  %t95 = load i32, ptr %t94
  store i32 %t95, ptr %l12, !tbaa !23
  br label %bb21
bb20:
  br label %bb25
bb21:
  %t97 = load i32, ptr %l12, !tbaa !23
  %t98 = load i32, ptr %l4, !tbaa !23
  %t101 = icmp eq i32 %t97, %t98
  br i1 %t101, label %bb22, label %bb23
bb22:
  %t103 = load i64, ptr %l10, !tbaa !24
  store i64 %t103, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  br label %bb30
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_50c5af6b9a55d13c_b172bff682b06040)
  unreachable
bb30:
  br label %bb31
bb31:
  %t105 = load i64, ptr %l9, !tbaa !24
  %t107 = add i64 %t105, 1
  store i64 %t107, ptr %l9, !tbaa !24
  br label %bb14
bb32:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparts(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %lp2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i32
  %l24 = alloca ptr
  %l25 = alloca i64
  %l27 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l32 = alloca i32
  %l39 = alloca i1
  %l44 = alloca ptr
  %l49 = alloca i32
  %l50 = alloca i32
  %l55 = alloca ptr
  %l60 = alloca i32
  %l61 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l79 = alloca ptr
  %l84 = alloca i32
  %l85 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l99 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l101 = alloca i64
  %l103 = alloca i64
  %l108 = alloca i32
  %l117 = alloca ptr
  %l122 = alloca i32
  %l125 = alloca ptr
  %l130 = alloca i32
  %l137 = alloca ptr
  %l142 = alloca i32
  %l143 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l161 = alloca ptr
  %l166 = alloca i32
  %l167 = alloca { i64, ptr }
  %l174 = alloca { i64, ptr }
  %l181 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l183 = alloca i64
  %l185 = alloca i64
  %l190 = alloca i32
  %s11 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l27
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l27
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/scope:Scoper", ptr %t5, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/generic:Program", ptr %t8, i32 0, i32 2
  %t11 = load i32, ptr %l1, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t10, i32 %t11)
  store i32 %t14, ptr %l32
  br label %bb2
bb2:
  %t15 = load i32, ptr %l32, !range !{i32 0, i32 33}
  store i32 %t15, ptr %l3
  %t16 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t18 = trunc i64 18 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb61
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/scope:Scoper", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 2
  %t27 = load i32, ptr %l1, !tbaa !23
  %t30 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t26, i32 %t27)
  store i1 %t30, ptr %l39
  br label %bb6
bb6:
  %t31 = load i1, ptr %l39, !tbaa !21
  %t32 = xor i1 %t31, true
  br i1 %t32, label %bb7, label %bb8
bb7:
  %t34 = load ptr, ptr %lp2
  %t35 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t34
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t35, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/scope:Scoper", ptr %t37, i32 0, i32 0
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 2
  store ptr %t42, ptr %l44, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/scope:Scoper", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 2
  %t49 = load i32, ptr %l1, !tbaa !23
  %t52 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t48, i32 %t49)
  store i32 %t52, ptr %l49
  br label %bb10
bb10:
  %t53 = load ptr, ptr %l44, !tbaa !29
  %t54 = load i32, ptr %l49, !tbaa !23
  %t55 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t53, i32 %t54)
  store i32 %t55, ptr %l50
  br label %bb11
bb11:
  %t56 = load i32, ptr %l50, !range !{i32 0, i32 6}
  store i32 %t56, ptr %l4
  %t57 = load i32, ptr %l4, !range !{i32 0, i32 6}
  %t59 = trunc i64 0 to i32
  %t60 = icmp eq i32 %t57, %t59
  br i1 %t60, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb24
bb14:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/scope:Scoper", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  store ptr %t67, ptr %l55, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/scope:Scoper", ptr %t68, i32 0, i32 0
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/generic:Program", ptr %t71, i32 0, i32 2
  %t74 = load i32, ptr %l1, !tbaa !23
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t73, i32 %t74)
  store i32 %t77, ptr %l60
  br label %bb15
bb15:
  %t78 = load ptr, ptr %l55, !tbaa !29
  %t79 = load i32, ptr %l60, !tbaa !23
  %t80 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t78, i32 %t79)
  store { i64, ptr } %t80, ptr %l61
  br label %bb16
bb16:
  %t81 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t81, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t82 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t82, 0
  store i64 %t84, ptr %l7, !tbaa !24
  br label %bb17
bb17:
  %t86 = load i64, ptr %l6, !tbaa !24
  %t87 = load i64, ptr %l7, !tbaa !24
  %t90 = icmp slt i64 %t86, %t87
  %t92 = xor i1 %t90, true
  br i1 %t92, label %bb18, label %bb19
bb18:
  br label %bb23
bb19:
  br label %bb20
bb20:
  %t94 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t94, ptr %l68, !tbaa !27
  %t95 = load i64, ptr %l6, !tbaa !24
  %t97 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr i32, ptr %t98, i64 %t95
  %t100 = load i32, ptr %t99, !tbaa !33
  %t102 = load ptr, ptr %lp2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t102, i32 %t100)
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t106 = load i64, ptr %l6, !tbaa !24
  %t108 = add i64 %t106, 1
  store i64 %t108, ptr %l6, !tbaa !24
  br label %bb17
bb23:
  br label %bb60
bb24:
  %t110 = load i32, ptr %l4, !range !{i32 0, i32 6}
  %t112 = trunc i64 1 to i32
  %t113 = icmp eq i32 %t110, %t112
  br i1 %t113, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb49
bb27:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/scope:Scoper", ptr %t115, i32 0, i32 0
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = getelementptr %"compiler/generic:Program", ptr %t118, i32 0, i32 2
  store ptr %t120, ptr %l79, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/scope:Scoper", ptr %t121, i32 0, i32 0
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t126 = getelementptr %"compiler/generic:Program", ptr %t124, i32 0, i32 2
  %t127 = load i32, ptr %l1, !tbaa !23
  %t130 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t126, i32 %t127)
  store i32 %t130, ptr %l84
  br label %bb28
bb28:
  %t131 = load ptr, ptr %l79, !tbaa !29
  %t132 = load i32, ptr %l84, !tbaa !23
  %t133 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t131, i32 %t132)
  store { i64, ptr } %t133, ptr %l85
  br label %bb29
bb29:
  %t134 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t134, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t135 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t135, 0
  store i64 %t137, ptr %l11, !tbaa !24
  br label %bb30
bb30:
  %t139 = load i64, ptr %l10, !tbaa !24
  %t140 = load i64, ptr %l11, !tbaa !24
  %t143 = icmp slt i64 %t139, %t140
  %t145 = xor i1 %t143, true
  br i1 %t145, label %bb31, label %bb32
bb31:
  br label %bb48
bb32:
  br label %bb33
bb33:
  %t147 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t147, ptr %l92, !tbaa !27
  %t148 = load i64, ptr %l10, !tbaa !24
  %t150 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr i32, ptr %t151, i64 %t148
  %t153 = load i32, ptr %t152, !tbaa !33
  store i32 %t153, ptr %l12, !tbaa !23
  %t155 = load i32, ptr %l12, !tbaa !23
  %t157 = icmp ne i32 %t155, 0
  br i1 %t157, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s11
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load i32, ptr %l12, !tbaa !23
  %t163 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparts(ptr %v0, ptr %s11, ptr %t159, i32 %t160)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t163, ptr %l99
  br label %bb36
bb35:
  br label %bb46
bb36:
  %t164 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l99
  %t165 = call ptr @__olang_scope_alloc_a(ptr %s11, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t164, ptr %t165
  store ptr %t165, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb37
bb37:
  %t167 = load i64, ptr %l14, !tbaa !24
  store i64 %t167, ptr %l101, !tbaa !24
  %t168 = load ptr, ptr %l13, !tbaa !29
  %t170 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s11, ptr %t168)
  store i64 %t170, ptr %l103
  br label %bb38
bb38:
  %t171 = load i64, ptr %l101, !tbaa !24
  %t172 = load i64, ptr %l103, !tbaa !24
  %t173 = icmp slt i64 %t171, %t172
  %t175 = xor i1 %t173, true
  br i1 %t175, label %bb39, label %bb40
bb39:
  br label %bb45
bb40:
  br label %bb41
bb41:
  %t177 = load ptr, ptr %l13, !tbaa !29
  %t178 = load i64, ptr %l14, !tbaa !24
  %t181 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s11, ptr %t177, i64 %t178)
  store i32 %t181, ptr %l108
  br label %bb42
bb42:
  %t182 = load i32, ptr %l108, !tbaa !23
  %t183 = load ptr, ptr %lp2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t183, i32 %t182)
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t187 = load i64, ptr %l14, !tbaa !24
  %t189 = add i64 %t187, 1
  store i64 %t189, ptr %l14, !tbaa !24
  br label %bb37
bb45:
  call void @__olang_scope_close(ptr %s11)
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t191 = load i64, ptr %l10, !tbaa !24
  %t193 = add i64 %t191, 1
  store i64 %t193, ptr %l10, !tbaa !24
  br label %bb30
bb48:
  br label %bb60
bb49:
  %t195 = load i32, ptr %l4, !range !{i32 0, i32 6}
  %t197 = trunc i64 4 to i32
  %t198 = icmp eq i32 %t195, %t197
  br i1 %t198, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb55
bb52:
  %t200 = load ptr, ptr %lp2
  store ptr %t200, ptr %l117, !tbaa !29
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/scope:Scoper", ptr %t201, i32 0, i32 0
  %t204 = load ptr, ptr %t203, !tbaa !29
  %t206 = getelementptr %"compiler/generic:Program", ptr %t204, i32 0, i32 2
  %t207 = load i32, ptr %l1, !tbaa !23
  %t210 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t206, i32 %t207)
  store i32 %t210, ptr %l122
  br label %bb53
bb53:
  %t211 = load ptr, ptr %l117, !tbaa !29
  %t212 = load i32, ptr %l122, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t211, i32 %t212)
  br label %bb54
bb54:
  br label %bb60
bb55:
  br i1 true, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_74d9849f1cf072e4_d95edc215f7aa198)
  unreachable
bb60:
  br label %bb112
bb61:
  %t213 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t215 = trunc i64 19 to i32
  %t216 = icmp eq i32 %t213, %t215
  br i1 %t216, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb67
bb64:
  %t218 = load ptr, ptr %lp2
  store ptr %t218, ptr %l125, !tbaa !29
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t221 = getelementptr %"compiler/scope:Scoper", ptr %t219, i32 0, i32 0
  %t222 = load ptr, ptr %t221, !tbaa !29
  %t224 = getelementptr %"compiler/generic:Program", ptr %t222, i32 0, i32 2
  %t225 = load i32, ptr %l1, !tbaa !23
  %t228 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t224, i32 %t225)
  store i32 %t228, ptr %l130
  br label %bb65
bb65:
  %t229 = load ptr, ptr %l125, !tbaa !29
  %t230 = load i32, ptr %l130, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t229, i32 %t230)
  br label %bb66
bb66:
  br label %bb112
bb67:
  %t231 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t233 = trunc i64 22 to i32
  %t234 = icmp eq i32 %t231, %t233
  br i1 %t234, label %bb68, label %bb69
bb68:
  br label %bb72
bb69:
  %t236 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t238 = trunc i64 23 to i32
  %t239 = icmp eq i32 %t236, %t238
  br i1 %t239, label %bb70, label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb82
bb72:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr %"compiler/scope:Scoper", ptr %t241, i32 0, i32 0
  %t244 = load ptr, ptr %t243, !tbaa !29
  %t246 = getelementptr %"compiler/generic:Program", ptr %t244, i32 0, i32 2
  store ptr %t246, ptr %l137, !tbaa !29
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t249 = getelementptr %"compiler/scope:Scoper", ptr %t247, i32 0, i32 0
  %t250 = load ptr, ptr %t249, !tbaa !29
  %t252 = getelementptr %"compiler/generic:Program", ptr %t250, i32 0, i32 2
  %t253 = load i32, ptr %l1, !tbaa !23
  %t256 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t252, i32 %t253)
  store i32 %t256, ptr %l142
  br label %bb73
bb73:
  %t257 = load ptr, ptr %l137, !tbaa !29
  %t258 = load i32, ptr %l142, !tbaa !23
  %t259 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t257, i32 %t258)
  store { i64, ptr } %t259, ptr %l143
  br label %bb74
bb74:
  %t260 = load { i64, ptr }, ptr %l143, !tbaa !27
  store { i64, ptr } %t260, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t261 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t263 = extractvalue { i64, ptr } %t261, 0
  store i64 %t263, ptr %l18, !tbaa !24
  br label %bb75
bb75:
  %t265 = load i64, ptr %l17, !tbaa !24
  %t266 = load i64, ptr %l18, !tbaa !24
  %t269 = icmp slt i64 %t265, %t266
  %t271 = xor i1 %t269, true
  br i1 %t271, label %bb76, label %bb77
bb76:
  br label %bb81
bb77:
  br label %bb78
bb78:
  %t273 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t273, ptr %l150, !tbaa !27
  %t274 = load i64, ptr %l17, !tbaa !24
  %t276 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !27
  %t278 = getelementptr i32, ptr %t277, i64 %t274
  %t279 = load i32, ptr %t278, !tbaa !33
  %t281 = load ptr, ptr %lp2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t281, i32 %t279)
  br label %bb79
bb79:
  br label %bb80
bb80:
  %t285 = load i64, ptr %l17, !tbaa !24
  %t287 = add i64 %t285, 1
  store i64 %t287, ptr %l17, !tbaa !24
  br label %bb75
bb81:
  br label %bb112
bb82:
  %t289 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t291 = trunc i64 24 to i32
  %t292 = icmp eq i32 %t289, %t291
  br i1 %t292, label %bb83, label %bb84
bb83:
  br label %bb85
bb84:
  br label %bb107
bb85:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t296 = getelementptr %"compiler/scope:Scoper", ptr %t294, i32 0, i32 0
  %t297 = load ptr, ptr %t296, !tbaa !29
  %t299 = getelementptr %"compiler/generic:Program", ptr %t297, i32 0, i32 2
  store ptr %t299, ptr %l161, !tbaa !29
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr %"compiler/scope:Scoper", ptr %t300, i32 0, i32 0
  %t303 = load ptr, ptr %t302, !tbaa !29
  %t305 = getelementptr %"compiler/generic:Program", ptr %t303, i32 0, i32 2
  %t306 = load i32, ptr %l1, !tbaa !23
  %t309 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t305, i32 %t306)
  store i32 %t309, ptr %l166
  br label %bb86
bb86:
  %t310 = load ptr, ptr %l161, !tbaa !29
  %t311 = load i32, ptr %l166, !tbaa !23
  %t312 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t310, i32 %t311)
  store { i64, ptr } %t312, ptr %l167
  br label %bb87
bb87:
  %t313 = load { i64, ptr }, ptr %l167, !tbaa !27
  store { i64, ptr } %t313, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t314 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t316 = extractvalue { i64, ptr } %t314, 0
  store i64 %t316, ptr %l22, !tbaa !24
  br label %bb88
bb88:
  %t318 = load i64, ptr %l21, !tbaa !24
  %t319 = load i64, ptr %l22, !tbaa !24
  %t322 = icmp slt i64 %t318, %t319
  %t324 = xor i1 %t322, true
  br i1 %t324, label %bb89, label %bb90
bb89:
  br label %bb106
bb90:
  br label %bb91
bb91:
  %t326 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t326, ptr %l174, !tbaa !27
  %t327 = load i64, ptr %l21, !tbaa !24
  %t329 = getelementptr { i64, ptr }, ptr %l174, i32 0, i32 1
  %t330 = load ptr, ptr %t329, !tbaa !27
  %t331 = getelementptr i32, ptr %t330, i64 %t327
  %t332 = load i32, ptr %t331, !tbaa !33
  store i32 %t332, ptr %l23, !tbaa !23
  %t334 = load i32, ptr %l23, !tbaa !23
  %t336 = icmp ne i32 %t334, 0
  br i1 %t336, label %bb92, label %bb93
bb92:
  store %olang.scope zeroinitializer, ptr %s26
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t339 = load i32, ptr %l23, !tbaa !23
  %t342 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparts(ptr %v0, ptr %s26, ptr %t338, i32 %t339)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t342, ptr %l181
  br label %bb94
bb93:
  br label %bb104
bb94:
  %t343 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l181
  %t344 = call ptr @__olang_scope_alloc_a(ptr %s26, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t343, ptr %t344
  store ptr %t344, ptr %l24, !tbaa !29
  store i64 0, ptr %l25, !tbaa !24
  br label %bb95
bb95:
  %t346 = load i64, ptr %l25, !tbaa !24
  store i64 %t346, ptr %l183, !tbaa !24
  %t347 = load ptr, ptr %l24, !tbaa !29
  %t349 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s26, ptr %t347)
  store i64 %t349, ptr %l185
  br label %bb96
bb96:
  %t350 = load i64, ptr %l183, !tbaa !24
  %t351 = load i64, ptr %l185, !tbaa !24
  %t352 = icmp slt i64 %t350, %t351
  %t354 = xor i1 %t352, true
  br i1 %t354, label %bb97, label %bb98
bb97:
  br label %bb103
bb98:
  br label %bb99
bb99:
  %t356 = load ptr, ptr %l24, !tbaa !29
  %t357 = load i64, ptr %l25, !tbaa !24
  %t360 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s26, ptr %t356, i64 %t357)
  store i32 %t360, ptr %l190
  br label %bb100
bb100:
  %t361 = load i32, ptr %l190, !tbaa !23
  %t362 = load ptr, ptr %lp2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t362, i32 %t361)
  br label %bb101
bb101:
  br label %bb102
bb102:
  %t366 = load i64, ptr %l25, !tbaa !24
  %t368 = add i64 %t366, 1
  store i64 %t368, ptr %l25, !tbaa !24
  br label %bb95
bb103:
  call void @__olang_scope_close(ptr %s26)
  br label %bb104
bb104:
  br label %bb105
bb105:
  %t370 = load i64, ptr %l21, !tbaa !24
  %t372 = add i64 %t370, 1
  store i64 %t372, ptr %l21, !tbaa !24
  br label %bb88
bb106:
  br label %bb112
bb107:
  br i1 true, label %bb108, label %bb109
bb108:
  br label %bb110
bb109:
  br label %bb111
bb110:
  br label %bb112
bb111:
  call void @__olang_check_failed(ptr @olang_loc_b99a325748da8cd5_4eb62b65b3c79869)
  unreachable
bb112:
  %t374 = load ptr, ptr %lp2
  %t375 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t374
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t375, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epayloadAgree(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i32
  %l14 = alloca %"compiler/scope:agreeAt"
  %l23 = alloca i64
  %l26 = alloca i64
  %l44 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l52 = alloca i1
  %l53 = alloca { i64, ptr }
  %l56 = alloca i1
  %l58 = alloca i1
  %l59 = alloca ptr
  %l61 = alloca i32
  %l62 = alloca i1
  %l65 = alloca i32
  %l68 = alloca i1
  %l69 = alloca i1
  %l72 = alloca i1
  %l75 = alloca i1
  %l76 = alloca %"compiler/scope:agreeAt"
  %l80 = alloca { i64, ptr }
  %l84 = alloca %"compiler/scope:agreeAt"
  %l85 = alloca i32
  %l86 = alloca ptr
  %l89 = alloca %"compiler/source:Span"
  %l90 = alloca %"compiler/msgs:Msg"
  %l91 = alloca i64
  %s4 = alloca %olang.scope
  %rv = alloca i1
  %t1 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store { i64, [2 x i64] } zeroinitializer, ptr %t1
  %t2 = getelementptr { i64, [2 x i64] }, ptr %t1, i32 0, i32 0
  store i64 0, ptr %t2
  %t3 = load { i64, [2 x i64] }, ptr %t1
  store { i64, [2 x i64] } %t3, ptr %l3
  store i1 false, ptr %l4, !tbaa !21
  store i64 0, ptr %l5, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i64, ptr %l7, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb6
bb3:
  %t19 = load i64, ptr %l6, !tbaa !24
  %t20 = load i64, ptr %l5, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l7, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l7, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l26, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb5
bb5:
  %t35 = load i64, ptr %l26, !tbaa !24
  store i64 %t35, ptr %l23, !tbaa !24
  br label %bb6
bb6:
  %t36 = load i64, ptr %l23, !tbaa !24
  store i64 %t36, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb7
bb7:
  %t37 = load i64, ptr %l9, !tbaa !24
  %t38 = load i64, ptr %l8, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb8, label %bb9
bb8:
  br label %bb38
bb9:
  br label %bb10
bb10:
  %t45 = load i64, ptr %l5, !tbaa !24
  %t46 = load i64, ptr %l9, !tbaa !24
  %t47 = load i64, ptr %l7, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l10, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t55, ptr %l44, !tbaa !27
  %t56 = load i64, ptr %l10, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr ptr, ptr %t59, i64 %t56
  %t61 = load ptr, ptr %t60, !tbaa !39
  store ptr %t61, ptr %l11, !tbaa !29
  %t63 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t63, ptr %l47, !tbaa !27
  %t64 = load i64, ptr %l10, !tbaa !24
  %t66 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr %"compiler/scope:Val", ptr %t67, i64 %t64
  %t69 = getelementptr %"compiler/scope:Val", ptr %t68, i32 0, i32 0
  %t70 = load i32, ptr %t69, !range !{i32 0, i32 5}
  %t72 = trunc i64 3 to i32
  %t73 = icmp eq i32 %t70, %t72
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb14
bb12:
  %t77 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t77, ptr %l53, !tbaa !27
  %t78 = load i64, ptr %l10, !tbaa !24
  %t80 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr %"compiler/scope:Val", ptr %t81, i64 %t78
  %t83 = getelementptr %"compiler/scope:Val", ptr %t82, i32 0, i32 1
  %t84 = load { i64, [2 x i64] }, ptr %t83
  %t86 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t84)
  store i1 %t86, ptr %l56
  br label %bb13
bb13:
  %t87 = load i1, ptr %l56, !tbaa !21
  %t88 = xor i1 %t87, true
  store i1 %t88, ptr %l52, !tbaa !21
  br label %bb14
bb14:
  %t90 = load i1, ptr %l52, !tbaa !21
  br i1 %t90, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l58, !tbaa !21
  br label %bb19
bb16:
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l59, !tbaa !29
  %t92 = load ptr, ptr %l11, !tbaa !29
  %t94 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t92)
  store i32 %t94, ptr %l61
  br label %bb17
bb17:
  %t95 = load ptr, ptr %l59, !tbaa !29
  %t96 = load i32, ptr %l61, !tbaa !23
  %t97 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t95, i32 %t96)
  store i1 %t97, ptr %l62
  br label %bb18
bb18:
  %t98 = load i1, ptr %l62, !tbaa !21
  %t99 = xor i1 %t98, true
  store i1 %t99, ptr %l58, !tbaa !21
  br label %bb19
bb19:
  %t101 = load i1, ptr %l58, !tbaa !21
  br i1 %t101, label %bb20, label %bb21
bb20:
  br label %bb37
bb21:
  br label %bb22
bb22:
  %t102 = load ptr, ptr %l11, !tbaa !29
  %t104 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t102)
  store i32 %t104, ptr %l65
  br label %bb23
bb23:
  %t105 = load i32, ptr %l65, !tbaa !23
  store i32 %t105, ptr %l12, !tbaa !23
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i32, ptr %l12, !tbaa !23
  %t110 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t106, i32 %t107)
  store i1 %t110, ptr %l68
  br label %bb24
bb24:
  %t111 = load i1, ptr %l68, !tbaa !21
  br i1 %t111, label %bb25, label %bb26
bb25:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load i32, ptr %l12, !tbaa !23
  %t116 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eadmitsStores(ptr %v0, ptr %t112, i32 %t113)
  store i1 %t116, ptr %l72
  br label %bb27
bb26:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i32, ptr %l12, !tbaa !23
  %t121 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evalueAdmits(ptr %v0, ptr %t117, i32 %t118)
  store i1 %t121, ptr %l75
  br label %bb28
bb27:
  %t122 = load i1, ptr %l72, !tbaa !21
  store i1 %t122, ptr %l69, !tbaa !21
  br label %bb29
bb28:
  %t123 = load i1, ptr %l75, !tbaa !21
  store i1 %t123, ptr %l69, !tbaa !21
  br label %bb29
bb29:
  %t124 = load i1, ptr %l69, !tbaa !21
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load { i64, [2 x i64] }, ptr %l3
  %t127 = load i1, ptr %l4, !tbaa !21
  %t128 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t128, ptr %l80, !tbaa !27
  %t129 = load i64, ptr %l10, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr %"compiler/scope:Val", ptr %t132, i64 %t129
  %t134 = getelementptr %"compiler/scope:Val", ptr %t133, i32 0, i32 1
  %t135 = load { i64, [2 x i64] }, ptr %t134
  %t142 = call { i32, %"compiler/scope:agreeAt" } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eagreeStep(ptr %v0, ptr %t125, { i64, [2 x i64] } %t126, i1 %t127, { i64, [2 x i64] } %t135, i1 %t124)
  %t143 = extractvalue { i32, %"compiler/scope:agreeAt" } %t142, 1
  %t144 = extractvalue { i32, %"compiler/scope:agreeAt" } %t142, 0
  store i32 %t144, ptr %l85
  %t145 = icmp ne i32 %t144, 0
  br i1 %t145, label %bb31, label %ok.146, !prof !99
ok.146:
  store %"compiler/scope:agreeAt" %t143, ptr %l84
  br label %bb30
bb30:
  %t147 = load %"compiler/scope:agreeAt", ptr %l84
  store %"compiler/scope:agreeAt" %t147, ptr %l76
  br label %bb36
bb31:
  br label %bb32
bb32:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s4
  %t148 = load ptr, ptr %l0, !tbaa !29
  store ptr %t148, ptr %l86, !tbaa !29
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load ptr, ptr %l11, !tbaa !29
  %t153 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargAt(ptr %v0, ptr %v1, ptr %t149, ptr %t150)
  store %"compiler/source:Span" %t153, ptr %l89
  br label %bb33
bb33:
  %t154 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2ePayloadScopesDisagree(ptr %s4)
  store %"compiler/msgs:Msg" %t154, ptr %l90
  br label %bb34
bb34:
  %t155 = load ptr, ptr %l86, !tbaa !29
  %t156 = load %"compiler/source:Span", ptr %l89
  %t157 = load %"compiler/msgs:Msg", ptr %l90
  %t158 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s4, ptr %t155, %"compiler/source:Span" %t156, %"compiler/msgs:Msg" %t157)
  store i64 %t158, ptr %l91
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s4)
  store i1 false, ptr %rv
  br label %ret
bb36:
  %t160 = load %"compiler/scope:agreeAt", ptr %l76
  store %"compiler/scope:agreeAt" %t160, ptr %l14
  %t161 = getelementptr %"compiler/scope:agreeAt", ptr %l14, i32 0, i32 0
  %t162 = load { i64, [2 x i64] }, ptr %t161
  %t164 = getelementptr %"compiler/scope:agreeAt", ptr %l14, i32 0, i32 1
  %t165 = load i1, ptr %t164, !tbaa !21
  store { i64, [2 x i64] } %t162, ptr %l3
  store i1 %t165, ptr %l4, !tbaa !21
  br label %bb37
bb37:
  %t171 = load i64, ptr %l9, !tbaa !24
  %t173 = add i64 %t171, 1
  store i64 %t173, ptr %l9, !tbaa !24
  br label %bb7
bb38:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekBorrow(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca { i64, [2 x i64] }
  %l18 = alloca { i64, [2 x i64] }
  %l19 = alloca i32
  %l25 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca i1
  %l31 = alloca { i64, [2 x i64] }
  %l35 = alloca { i64, [2 x i64] }
  %rv = alloca { i64, [2 x i64] }
  %t36 = alloca { i64, [2 x i64] }, align 8
  %t64 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t18, i32 0, i32 3
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb19
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/scope:Scoper", ptr %t22, i32 0, i32 89
  %t25 = load i32, ptr %l3, !tbaa !23
  %t27 = sext i32 %t25 to i64
  %t30 = call { i32, { i64, [2 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_H65b4b9a6d1679f5b3ddedaa5b2e336bd(ptr %v0, ptr %t24, i64 %t27)
  %t31 = extractvalue { i32, { i64, [2 x i64] } } %t30, 1
  %t32 = extractvalue { i32, { i64, [2 x i64] } } %t30, 0
  store i32 %t32, ptr %l19
  %t33 = icmp ne i32 %t32, 0
  br i1 %t33, label %bb7, label %ok.34, !prof !99
ok.34:
  store { i64, [2 x i64] } %t31, ptr %l18
  br label %bb6
bb6:
  %t35 = load { i64, [2 x i64] }, ptr %l18
  store { i64, [2 x i64] } %t35, ptr %l13
  br label %bb9
bb7:
  br label %bb8
bb8:
  call void @__olang_ert_req_clear()
  store { i64, [2 x i64] } zeroinitializer, ptr %t36
  %t37 = getelementptr { i64, [2 x i64] }, ptr %t36, i32 0, i32 0
  store i64 0, ptr %t37
  %t38 = load { i64, [2 x i64] }, ptr %t36
  store { i64, [2 x i64] } %t38, ptr %l13
  br label %bb9
bb9:
  %t40 = load { i64, [2 x i64] }, ptr %l13
  store { i64, [2 x i64] } %t40, ptr %l4
  %t41 = load { i64, [2 x i64] }, ptr %l4
  %t43 = extractvalue { i64, [2 x i64] } %t41, 0
  %t44 = icmp eq i64 %t43, 0
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load { i64, [2 x i64] }, ptr %l4
  store { i64, [2 x i64] } %t48, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l25, !tbaa !29
  %t51 = load ptr, ptr %l2, !tbaa !29
  %t53 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t51)
  store i32 %t53, ptr %l27
  br label %bb13
bb13:
  %t54 = load ptr, ptr %l25, !tbaa !29
  %t55 = load i32, ptr %l27, !tbaa !23
  %t56 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisHandle(ptr %v0, ptr %t54, i32 %t55)
  store i1 %t56, ptr %l28
  br label %bb14
bb14:
  %t57 = load i1, ptr %l28, !tbaa !21
  br i1 %t57, label %bb15, label %bb16
bb15:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load ptr, ptr %l2, !tbaa !29
  %t62 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elandTerm(ptr %v0, ptr %v1, ptr %t58, ptr %t59)
  store { i64, [2 x i64] } %t62, ptr %l31
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t63 = load { i64, [2 x i64] }, ptr %l31
  store { i64, [2 x i64] } %t63, ptr %rv
  br label %ret
bb18:
  store { i64, [2 x i64] } zeroinitializer, ptr %t64
  %t65 = getelementptr { i64, [2 x i64] }, ptr %t64, i32 0, i32 0
  store i64 0, ptr %t65
  %t66 = load { i64, [2 x i64] }, ptr %t64
  store { i64, [2 x i64] } %t66, ptr %rv
  br label %ret
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t72 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekPlace(ptr %v0, ptr %v1, ptr %t68, ptr %t69, i1 false)
  store { i64, [2 x i64] } %t72, ptr %l35
  br label %bb23
bb23:
  %t73 = load { i64, [2 x i64] }, ptr %l35
  store { i64, [2 x i64] } %t73, ptr %rv
  br label %ret
bb24:
  call void @__olang_check_failed(ptr @olang_loc_a696eb2979219c3c_c9efb41471de78f8)
  unreachable
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca ptr
  %l11 = alloca i1
  %l17 = alloca { i64, [2 x i64] }
  %l20 = alloca { i64, [2 x i64] }
  %l25 = alloca { i64, [2 x i64] }
  %l26 = alloca ptr
  %l27 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l40 = alloca { i64, [2 x i64] }
  %l41 = alloca ptr
  %l42 = alloca i1
  %l51 = alloca { i64, [2 x i64] }
  %l52 = alloca ptr
  %l53 = alloca i1
  %l58 = alloca ptr
  %l60 = alloca ptr
  %l62 = alloca i1
  %l63 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca i1
  %l68 = alloca { i64, [2 x i64] }
  %l69 = alloca ptr
  %l70 = alloca i1
  %l78 = alloca { i64, [2 x i64] }
  %l79 = alloca ptr
  %l80 = alloca i1
  %l86 = alloca { i64, [2 x i64] }
  %l87 = alloca { i64, [2 x i64] }
  %l92 = alloca { i64, [2 x i64] }
  %l93 = alloca i32
  %rv = alloca { i64, [2 x i64] }
  %t44 = alloca { i64, [2 x i64] }, align 8
  %t187 = alloca { i64, [2 x i64] }, align 8
  %t192 = alloca { i64, [2 x i64] }, align 8
  %t198 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l10, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t16 = load i1, ptr %l2, !tbaa !21
  br i1 %t16, label %bb6, label %bb7
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l3, !tbaa !23
  %t22 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewhereLives(ptr %v0, ptr %t18, i32 %t19)
  store { i64, [2 x i64] } %t22, ptr %l20
  br label %bb8
bb7:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/scope:Scoper", ptr %t23, i32 0, i32 32
  %t26 = load i32, ptr %l3, !tbaa !23
  %t28 = sext i32 %t26 to i64
  %t31 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t25, i64 %t28)
  store { i64, [2 x i64] } %t31, ptr %l25
  br label %bb9
bb8:
  %t32 = load { i64, [2 x i64] }, ptr %l20
  store { i64, [2 x i64] } %t32, ptr %l17
  br label %bb10
bb9:
  %t33 = load { i64, [2 x i64] }, ptr %l25
  store { i64, [2 x i64] } %t33, ptr %l17
  br label %bb10
bb10:
  %t34 = load { i64, [2 x i64] }, ptr %l17
  store { i64, [2 x i64] } %t34, ptr %l9
  br label %bb68
bb11:
  %t35 = load ptr, ptr %l1, !tbaa !29
  store ptr %t35, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t36 = load ptr, ptr %l26, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t39 = load ptr, ptr %l26, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 8}
  %t42 = icmp eq i64 %t40, 1
  store i1 %t42, ptr %l27, !tbaa !21
  br label %bb13
bb13:
  %t43 = load i1, ptr %l27, !tbaa !21
  br i1 %t43, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store { i64, [2 x i64] } zeroinitializer, ptr %t44
  %t45 = getelementptr { i64, [2 x i64] }, ptr %t44, i32 0, i32 0
  store i64 3, ptr %t45
  %t46 = load { i64, [2 x i64] }, ptr %t44
  store { i64, [2 x i64] } %t46, ptr %l9
  br label %bb68
bb17:
  %t48 = load ptr, ptr %l1, !tbaa !29
  store ptr %t48, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t49 = load ptr, ptr %l31, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb18, label %bb19
bb18:
  %t52 = load ptr, ptr %l31, !tbaa !29
  %t53 = load i64, ptr %t52, !range !{i64 0, i64 8}
  %t55 = icmp eq i64 %t53, 3
  store i1 %t55, ptr %l32, !tbaa !21
  br label %bb19
bb19:
  %t56 = load i1, ptr %l32, !tbaa !21
  br i1 %t56, label %bb20, label %bb21
bb20:
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr { i64, [4 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t59, i32 0, i32 2
  %t61 = load ptr, ptr %t60
  store ptr %t61, ptr %l4, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load ptr, ptr %l4, !tbaa !29
  %t65 = load i1, ptr %l2, !tbaa !21
  %t69 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekPlace(ptr %v0, ptr %v1, ptr %t63, ptr %t64, i1 %t65)
  store { i64, [2 x i64] } %t69, ptr %l40
  br label %bb23
bb23:
  %t70 = load { i64, [2 x i64] }, ptr %l40
  store { i64, [2 x i64] } %t70, ptr %l9
  br label %bb68
bb24:
  %t71 = load ptr, ptr %l1, !tbaa !29
  store ptr %t71, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t72 = load ptr, ptr %l41, !tbaa !29
  %t73 = icmp ne ptr %t72, null
  br i1 %t73, label %bb25, label %bb26
bb25:
  %t75 = load ptr, ptr %l41, !tbaa !29
  %t76 = load i64, ptr %t75, !range !{i64 0, i64 8}
  %t78 = icmp eq i64 %t76, 5
  store i1 %t78, ptr %l42, !tbaa !21
  br label %bb26
bb26:
  %t79 = load i1, ptr %l42, !tbaa !21
  br i1 %t79, label %bb27, label %bb28
bb27:
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t82 = getelementptr { i64, [4 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t82, i32 0, i32 2
  %t84 = load ptr, ptr %t83
  store ptr %t84, ptr %l5, !tbaa !29
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load ptr, ptr %l5, !tbaa !29
  %t89 = getelementptr %"compiler/typed:Payload", ptr %t87, i32 0, i32 0
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t91 = load i1, ptr %l2, !tbaa !21
  %t95 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekPlace(ptr %v0, ptr %v1, ptr %t86, ptr %t90, i1 %t91)
  store { i64, [2 x i64] } %t95, ptr %l51
  br label %bb30
bb30:
  %t96 = load { i64, [2 x i64] }, ptr %l51
  store { i64, [2 x i64] } %t96, ptr %l9
  br label %bb68
bb31:
  %t97 = load ptr, ptr %l1, !tbaa !29
  store ptr %t97, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t98 = load ptr, ptr %l52, !tbaa !29
  %t99 = icmp ne ptr %t98, null
  br i1 %t99, label %bb32, label %bb33
bb32:
  %t101 = load ptr, ptr %l52, !tbaa !29
  %t102 = load i64, ptr %t101, !range !{i64 0, i64 8}
  %t104 = icmp eq i64 %t102, 4
  store i1 %t104, ptr %l53, !tbaa !21
  br label %bb33
bb33:
  %t105 = load i1, ptr %l53, !tbaa !21
  br i1 %t105, label %bb34, label %bb35
bb34:
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr { i64, [4 x i64] }, ptr %t106, i32 0, i32 1
  %t109 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t108, i32 0, i32 2
  %t110 = load ptr, ptr %t109
  store ptr %t110, ptr %l6, !tbaa !29
  br label %bb36
bb35:
  br label %bb43
bb36:
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l58, !tbaa !29
  %t113 = load ptr, ptr %l6, !tbaa !29
  %t115 = getelementptr %"compiler/typed:Elem", ptr %t113, i32 0, i32 0
  %t116 = load ptr, ptr %t115, !tbaa !29
  store ptr %t116, ptr %l60, !tbaa !29
  %t117 = load i1, ptr %l2, !tbaa !21
  br i1 %t117, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb41
bb38:
  %t119 = load ptr, ptr %l0, !tbaa !29
  store ptr %t119, ptr %l63, !tbaa !29
  %t120 = load ptr, ptr %l6, !tbaa !29
  %t122 = getelementptr %"compiler/typed:Elem", ptr %t120, i32 0, i32 0
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t123)
  store i32 %t125, ptr %l66
  br label %bb39
bb39:
  %t126 = load ptr, ptr %l63, !tbaa !29
  %t127 = load i32, ptr %l66, !tbaa !23
  %t128 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erunLength(ptr %v0, ptr %t126, i32 %t127)
  store i1 %t128, ptr %l67
  br label %bb40
bb40:
  %t129 = load i1, ptr %l67, !tbaa !21
  store i1 %t129, ptr %l62, !tbaa !21
  br label %bb41
bb41:
  %t130 = load ptr, ptr %l58, !tbaa !29
  %t131 = load ptr, ptr %l60, !tbaa !29
  %t132 = load i1, ptr %l62, !tbaa !21
  %t133 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekPlace(ptr %v0, ptr %v1, ptr %t130, ptr %t131, i1 %t132)
  store { i64, [2 x i64] } %t133, ptr %l68
  br label %bb42
bb42:
  %t134 = load { i64, [2 x i64] }, ptr %l68
  store { i64, [2 x i64] } %t134, ptr %l9
  br label %bb68
bb43:
  %t135 = load ptr, ptr %l1, !tbaa !29
  store ptr %t135, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t136 = load ptr, ptr %l69, !tbaa !29
  %t137 = icmp ne ptr %t136, null
  br i1 %t137, label %bb44, label %bb45
bb44:
  %t139 = load ptr, ptr %l69, !tbaa !29
  %t140 = load i64, ptr %t139, !range !{i64 0, i64 8}
  %t142 = icmp eq i64 %t140, 2
  store i1 %t142, ptr %l70, !tbaa !21
  br label %bb45
bb45:
  %t143 = load i1, ptr %l70, !tbaa !21
  br i1 %t143, label %bb46, label %bb47
bb46:
  %t144 = load ptr, ptr %l1, !tbaa !29
  %t146 = getelementptr { i64, [4 x i64] }, ptr %t144, i32 0, i32 1
  %t147 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t146, i32 0, i32 2
  %t148 = load ptr, ptr %t147
  store ptr %t148, ptr %l7, !tbaa !29
  br label %bb48
bb47:
  br label %bb50
bb48:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load ptr, ptr %l7, !tbaa !29
  %t155 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekTerm(ptr %v0, ptr %v1, ptr %t150, ptr %t151)
  store { i64, [2 x i64] } %t155, ptr %l78
  br label %bb49
bb49:
  %t156 = load { i64, [2 x i64] }, ptr %l78
  store { i64, [2 x i64] } %t156, ptr %l9
  br label %bb68
bb50:
  %t157 = load ptr, ptr %l1, !tbaa !29
  store ptr %t157, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t158 = load ptr, ptr %l79, !tbaa !29
  %t159 = icmp ne ptr %t158, null
  br i1 %t159, label %bb51, label %bb52
bb51:
  %t161 = load ptr, ptr %l79, !tbaa !29
  %t162 = load i64, ptr %t161, !range !{i64 0, i64 8}
  %t164 = icmp eq i64 %t162, 6
  store i1 %t164, ptr %l80, !tbaa !21
  br label %bb52
bb52:
  %t165 = load i1, ptr %l80, !tbaa !21
  br i1 %t165, label %bb53, label %bb54
bb53:
  %t166 = load ptr, ptr %l1, !tbaa !29
  %t168 = getelementptr { i64, [4 x i64] }, ptr %t166, i32 0, i32 1
  %t169 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t168, i32 0, i32 3
  %t170 = load i32, ptr %t169
  store i32 %t170, ptr %l8, !tbaa !23
  br label %bb55
bb54:
  br label %bb63
bb55:
  %t172 = load i1, ptr %l2, !tbaa !21
  br i1 %t172, label %bb56, label %bb57
bb56:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/scope:Scoper", ptr %t174, i32 0, i32 89
  %t177 = load i32, ptr %l8, !tbaa !23
  %t179 = sext i32 %t177 to i64
  %t182 = call { i32, { i64, [2 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_H65b4b9a6d1679f5b3ddedaa5b2e336bd(ptr %v0, ptr %t176, i64 %t179)
  %t183 = extractvalue { i32, { i64, [2 x i64] } } %t182, 1
  %t184 = extractvalue { i32, { i64, [2 x i64] } } %t182, 0
  store i32 %t184, ptr %l93
  %t185 = icmp ne i32 %t184, 0
  br i1 %t185, label %bb59, label %ok.186, !prof !99
ok.186:
  store { i64, [2 x i64] } %t183, ptr %l92
  br label %bb58
bb57:
  store { i64, [2 x i64] } zeroinitializer, ptr %t187
  %t188 = getelementptr { i64, [2 x i64] }, ptr %t187, i32 0, i32 0
  store i64 0, ptr %t188
  %t189 = load { i64, [2 x i64] }, ptr %t187
  store { i64, [2 x i64] } %t189, ptr %l86
  br label %bb62
bb58:
  %t191 = load { i64, [2 x i64] }, ptr %l92
  store { i64, [2 x i64] } %t191, ptr %l87
  br label %bb61
bb59:
  br label %bb60
bb60:
  call void @__olang_ert_req_clear()
  store { i64, [2 x i64] } zeroinitializer, ptr %t192
  %t193 = getelementptr { i64, [2 x i64] }, ptr %t192, i32 0, i32 0
  store i64 0, ptr %t193
  %t194 = load { i64, [2 x i64] }, ptr %t192
  store { i64, [2 x i64] } %t194, ptr %l87
  br label %bb61
bb61:
  %t196 = load { i64, [2 x i64] }, ptr %l87
  store { i64, [2 x i64] } %t196, ptr %l86
  br label %bb62
bb62:
  %t197 = load { i64, [2 x i64] }, ptr %l86
  store { i64, [2 x i64] } %t197, ptr %l9
  br label %bb68
bb63:
  br i1 true, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb67
bb66:
  store { i64, [2 x i64] } zeroinitializer, ptr %t198
  %t199 = getelementptr { i64, [2 x i64] }, ptr %t198, i32 0, i32 0
  store i64 0, ptr %t199
  %t200 = load { i64, [2 x i64] }, ptr %t198
  store { i64, [2 x i64] } %t200, ptr %l9
  br label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_7a4f424795892e70_52f604b9bdf9a7cc)
  unreachable
bb68:
  %t202 = load { i64, [2 x i64] }, ptr %l9
  store { i64, [2 x i64] } %t202, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eplaceCallOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca i1
  %l45 = alloca i1
  %l46 = alloca ptr
  %l50 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eplaceCallOf(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store ptr %t20, ptr %l15
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l15, !tbaa !29
  store ptr %t21, ptr %l6, !tbaa !29
  br label %bb37
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t23 = load ptr, ptr %l16, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l16, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 8}
  %t29 = icmp eq i64 %t27, 4
  store i1 %t29, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l17, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Elem", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t44 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eplaceCallOf(ptr %v0, ptr %v1, ptr %t37, ptr %t41)
  store ptr %t44, ptr %l25
  br label %bb13
bb13:
  %t45 = load ptr, ptr %l25, !tbaa !29
  store ptr %t45, ptr %l6, !tbaa !29
  br label %bb37
bb14:
  %t46 = load ptr, ptr %l1, !tbaa !29
  store ptr %t46, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t47 = load ptr, ptr %l26, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb15, label %bb16
bb15:
  %t50 = load ptr, ptr %l26, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 8}
  %t53 = icmp eq i64 %t51, 5
  store i1 %t53, ptr %l27, !tbaa !21
  br label %bb16
bb16:
  %t54 = load i1, ptr %l27, !tbaa !21
  br i1 %t54, label %bb17, label %bb18
bb17:
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t57, i32 0, i32 2
  %t59 = load ptr, ptr %t58
  store ptr %t59, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Payload", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t68 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eplaceCallOf(ptr %v0, ptr %v1, ptr %t61, ptr %t65)
  store ptr %t68, ptr %l35
  br label %bb20
bb20:
  %t69 = load ptr, ptr %l35, !tbaa !29
  store ptr %t69, ptr %l6, !tbaa !29
  br label %bb37
bb21:
  %t70 = load ptr, ptr %l1, !tbaa !29
  store ptr %t70, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t71 = load ptr, ptr %l36, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb22, label %bb23
bb22:
  %t74 = load ptr, ptr %l36, !tbaa !29
  %t75 = load i64, ptr %t74, !range !{i64 0, i64 8}
  %t77 = icmp eq i64 %t75, 6
  store i1 %t77, ptr %l37, !tbaa !21
  br label %bb23
bb23:
  %t78 = load i1, ptr %l37, !tbaa !21
  br i1 %t78, label %bb24, label %bb25
bb24:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr { i64, [4 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t81, i32 0, i32 2
  %t83 = load ptr, ptr %t82
  store ptr %t83, ptr %l5, !tbaa !29
  br label %bb26
bb25:
  br label %bb32
bb26:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load ptr, ptr %l5, !tbaa !29
  %t90 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %t85, ptr %t86)
  store i1 %t90, ptr %l45
  br label %bb27
bb27:
  %t91 = load i1, ptr %l45, !tbaa !21
  br i1 %t91, label %bb28, label %bb29
bb28:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l5, !tbaa !29
  %t97 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallOf(ptr %v0, ptr %v1, ptr %t92, ptr %t93)
  store ptr %t97, ptr %l50
  br label %bb30
bb29:
  store ptr null, ptr %l46, !tbaa !29
  br label %bb31
bb30:
  %t98 = load ptr, ptr %l50, !tbaa !29
  store ptr %t98, ptr %l46, !tbaa !29
  br label %bb31
bb31:
  %t99 = load ptr, ptr %l46, !tbaa !29
  store ptr %t99, ptr %l6, !tbaa !29
  br label %bb37
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store ptr null, ptr %l6, !tbaa !29
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_da1486de58138450_28784370eb22bac)
  unreachable
bb37:
  %t100 = load ptr, ptr %l6, !tbaa !29
  store ptr %t100, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2equalifiesMove(ptr %v0, ptr %v1, ptr %a0, %"compiler/typed:Local" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/typed:Local"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca { i64, [2 x i64] }
  %l6 = alloca i32
  %l10 = alloca i1
  %l14 = alloca i1
  %l24 = alloca i1
  %l25 = alloca i1
  %l28 = alloca i1
  %l29 = alloca i1
  %l32 = alloca i1
  %l33 = alloca i1
  %l36 = alloca i1
  %l46 = alloca i1
  %l51 = alloca i1
  %l57 = alloca i32
  %l60 = alloca i1
  %l63 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/typed:Local" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/typed:Local", ptr %l1, i32 0, i32 2
  %t2 = load i32, ptr %t1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t5 = load i32, ptr %l3, !tbaa !23
  %t8 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFunc(ptr %v0, ptr %t4, i32 %t5)
  store i1 %t8, ptr %l10
  br label %bb1
bb1:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l3, !tbaa !23
  %t15 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t11, i32 %t12)
  store i1 %t15, ptr %l14
  br label %bb5
bb5:
  %t16 = load i1, ptr %l14, !tbaa !21
  br i1 %t16, label %bb6, label %bb7
bb6:
  %t17 = getelementptr %"compiler/typed:Local", ptr %l1, i32 0, i32 5
  %t18 = load { i64, [2 x i64] }, ptr %t17
  store { i64, [2 x i64] } %t18, ptr %l4
  %t20 = load { i64, [2 x i64] }, ptr %l4
  %t22 = extractvalue { i64, [2 x i64] } %t20, 0
  %t23 = icmp eq i64 %t22, 1
  br i1 %t23, label %bb8, label %bb9
bb7:
  br label %bb32
bb8:
  br label %bb12
bb9:
  %t25 = load { i64, [2 x i64] }, ptr %l4
  %t27 = extractvalue { i64, [2 x i64] } %t25, 0
  %t28 = icmp eq i64 %t27, 5
  br i1 %t28, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 false, ptr %rv
  br label %ret
bb17:
  call void @__olang_check_failed(ptr @olang_loc_554265ba1528b3d8_d73d8ae267adc184)
  unreachable
bb18:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t36 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %t31, ptr %t32)
  store i1 %t36, ptr %l24
  br label %bb19
bb19:
  %t37 = load i1, ptr %l24, !tbaa !21
  br i1 %t37, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb23
bb21:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load ptr, ptr %l2, !tbaa !29
  %t42 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisNullLit(ptr %v0, ptr %v1, ptr %t38, ptr %t39)
  store i1 %t42, ptr %l28
  br label %bb22
bb22:
  %t43 = load i1, ptr %l28, !tbaa !21
  store i1 %t43, ptr %l25, !tbaa !21
  br label %bb23
bb23:
  %t44 = load i1, ptr %l25, !tbaa !21
  br i1 %t44, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb27
bb25:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t49 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisData(ptr %v0, ptr %v1, ptr %t45, ptr %t46)
  store i1 %t49, ptr %l32
  br label %bb26
bb26:
  %t50 = load i1, ptr %l32, !tbaa !21
  store i1 %t50, ptr %l29, !tbaa !21
  br label %bb27
bb27:
  %t51 = load i1, ptr %l29, !tbaa !21
  br i1 %t51, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb31
bb29:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t56 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estaticLiteral(ptr %v0, ptr %v1, ptr %t52, ptr %t53)
  store i1 %t56, ptr %l36
  br label %bb30
bb30:
  %t57 = load i1, ptr %l36, !tbaa !21
  store i1 %t57, ptr %l33, !tbaa !21
  br label %bb31
bb31:
  %t58 = load i1, ptr %l33, !tbaa !21
  store i1 %t58, ptr %rv
  br label %ret
bb32:
  %t59 = getelementptr %"compiler/typed:Local", ptr %l1, i32 0, i32 5
  %t60 = load { i64, [2 x i64] }, ptr %t59
  store { i64, [2 x i64] } %t60, ptr %l5
  %t62 = load { i64, [2 x i64] }, ptr %l5
  %t64 = extractvalue { i64, [2 x i64] } %t62, 0
  %t65 = icmp eq i64 %t64, 0
  br i1 %t65, label %bb33, label %bb34
bb33:
  br label %bb37
bb34:
  %t67 = load { i64, [2 x i64] }, ptr %l5
  %t69 = extractvalue { i64, [2 x i64] } %t67, 0
  %t70 = icmp eq i64 %t69, 5
  br i1 %t70, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb43
bb38:
  br i1 true, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store i1 false, ptr %rv
  br label %ret
bb42:
  call void @__olang_check_failed(ptr @olang_loc_c484f993348186a9_88a471068962d75)
  unreachable
bb43:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load ptr, ptr %l2, !tbaa !29
  %t78 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeHere(ptr %v0, ptr %v1, ptr %t73, ptr %t74)
  store i1 %t78, ptr %l46
  br label %bb44
bb44:
  %t79 = load i1, ptr %l46, !tbaa !21
  %t80 = xor i1 %t79, true
  br i1 %t80, label %bb45, label %bb46
bb45:
  store i1 false, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i32, ptr %l3, !tbaa !23
  %t87 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t83, i32 %t84)
  store i1 %t87, ptr %l51
  br label %bb48
bb48:
  %t88 = load i1, ptr %l51, !tbaa !21
  br i1 %t88, label %bb49, label %bb50
bb49:
  store i1 true, ptr %rv
  br label %ret
bb50:
  br label %bb51
bb51:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/scope:Scoper", ptr %t90, i32 0, i32 0
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Program", ptr %t93, i32 0, i32 2
  %t96 = load i32, ptr %l3, !tbaa !23
  %t99 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t95, i32 %t96)
  store i32 %t99, ptr %l57
  br label %bb52
bb52:
  %t100 = load i32, ptr %l57, !range !{i32 0, i32 33}
  store i32 %t100, ptr %l6
  %t101 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t103 = trunc i64 19 to i32
  %t104 = icmp eq i32 %t101, %t103
  br i1 %t104, label %bb53, label %bb54
bb53:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb55
bb54:
  %t106 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t108 = trunc i64 18 to i32
  %t109 = icmp eq i32 %t106, %t108
  store i1 %t109, ptr %l60, !tbaa !21
  br label %bb55
bb55:
  %t111 = load i1, ptr %l60, !tbaa !21
  br i1 %t111, label %bb56, label %bb57
bb56:
  store i1 true, ptr %l63, !tbaa !21
  br label %bb58
bb57:
  %t112 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t114 = trunc i64 22 to i32
  %t115 = icmp eq i32 %t112, %t114
  store i1 %t115, ptr %l63, !tbaa !21
  br label %bb58
bb58:
  %t117 = load i1, ptr %l63, !tbaa !21
  store i1 %t117, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ereadOnlyAsBuilt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l5 = alloca i32
  %l8 = alloca i1
  %l10 = alloca i1
  %l15 = alloca i64
  %l20 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca i64
  %l28 = alloca i1
  %l32 = alloca ptr
  %l35 = alloca %"compiler/source:Span"
  %l36 = alloca %"compiler/msgs:Msg"
  %l37 = alloca i64
  %l38 = alloca ptr
  %l41 = alloca %"compiler/source:Span"
  %l43 = alloca { ptr, ptr }
  %l48 = alloca i32
  %l49 = alloca { i64, ptr }
  %l53 = alloca ptr
  %l62 = alloca %"compiler/typed:Local"
  %l64 = alloca { i64, ptr }
  %l67 = alloca %"compiler/msgs:Msg"
  %l68 = alloca i64
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t1)
  store i32 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i32, ptr %l5, !tbaa !23
  store i32 %t4, ptr %l2, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l2, !tbaa !23
  %t9 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load i1, ptr %l8, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb6
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/scope:Scoper", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l2, !tbaa !23
  %t22 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t18, i32 %t19)
  store i64 %t22, ptr %l15
  br label %bb5
bb5:
  %t23 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t24 = load i64, ptr %l15, !tbaa !24
  %t26 = and i64 %t24, %t23
  %t28 = icmp ne i64 %t26, 0
  store i1 %t28, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t30 = load i1, ptr %l10, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l20, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t38 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %t33, ptr %t34)
  store ptr %t38, ptr %l24
  br label %bb10
bb10:
  %t39 = load ptr, ptr %l20, !tbaa !29
  %t40 = load ptr, ptr %l24, !tbaa !29
  %t41 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparamRoot(ptr %v0, ptr %v1, ptr %t39, ptr %t40)
  store i64 %t41, ptr %l25
  br label %bb11
bb11:
  %t42 = load i64, ptr %l25, !tbaa !24
  store i64 %t42, ptr %l3, !tbaa !24
  %t43 = load i64, ptr %l3, !tbaa !24
  %t45 = icmp slt i64 %t43, 0
  br i1 %t45, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb14
bb13:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/scope:Scoper", ptr %t47, i32 0, i32 5
  %t50 = load { ptr, ptr }, ptr %t49
  %t52 = extractvalue { ptr, ptr } %t50, 0
  %t53 = extractvalue { ptr, ptr } zeroinitializer, 0
  %t54 = icmp eq ptr %t52, %t53
  %t55 = extractvalue { ptr, ptr } %t50, 1
  %t56 = extractvalue { ptr, ptr } zeroinitializer, 1
  %t57 = icmp eq ptr %t55, %t56
  %t58 = and i1 %t54, %t57
  store i1 %t58, ptr %l28, !tbaa !21
  br label %bb14
bb14:
  %t60 = load i1, ptr %l28, !tbaa !21
  br i1 %t60, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l32, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t66 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eopTok(ptr %v0, ptr %v1, ptr %t62, ptr %t63)
  store %"compiler/source:Span" %t66, ptr %l35
  br label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l38, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t72 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eopTok(ptr %v0, ptr %v1, ptr %t68, ptr %t69)
  store %"compiler/source:Span" %t72, ptr %l41
  br label %bb20
bb17:
  %t73 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyToBuiltResultNo(ptr %s2)
  store %"compiler/msgs:Msg" %t73, ptr %l36
  br label %bb18
bb18:
  %t74 = load ptr, ptr %l32, !tbaa !29
  %t75 = load %"compiler/source:Span", ptr %l35
  %t76 = load %"compiler/msgs:Msg", ptr %l36
  %t77 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s2, ptr %t74, %"compiler/source:Span" %t75, %"compiler/msgs:Msg" %t76)
  store i64 %t77, ptr %l37
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb20:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/scope:Scoper", ptr %t78, i32 0, i32 5
  %t81 = load { ptr, ptr }, ptr %t80
  store { ptr, ptr } %t81, ptr %l43
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/scope:Scoper", ptr %t82, i32 0, i32 0
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/generic:Program", ptr %t85, i32 0, i32 2
  %t88 = load i32, ptr %l2, !tbaa !23
  %t91 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t87, i32 %t88)
  store i32 %t91, ptr %l48
  br label %bb21
bb21:
  %t92 = load { ptr, ptr }, ptr %l43
  %t93 = extractvalue { ptr, ptr } %t92, 0
  %t94 = extractvalue { ptr, ptr } %t92, 1
  %t95 = load i32, ptr %l48, !tbaa !23
  %t96 = call { i64, ptr } %t93(ptr %t94, ptr %s3, i32 %t95)
  store { i64, ptr } %t96, ptr %l49
  br label %bb22
bb22:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/scope:Scoper", ptr %t97, i32 0, i32 0
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 0
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = getelementptr %"compiler/load:Loader", ptr %t103, i32 0, i32 3
  %t106 = load ptr, ptr %t105, !tbaa !29
  store ptr %t106, ptr %l53, !tbaa !29
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/scope:Scoper", ptr %t107, i32 0, i32 25
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = icmp eq ptr %t110, null
  br i1 %t112, label %bb23, label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_86025ef78c18fd61_51e54585f4e29a5d)
  unreachable
bb24:
  br label %bb25
bb25:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/scope:Scoper", ptr %t114, i32 0, i32 25
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t120 = getelementptr %"compiler/typed:Body", ptr %t117, i32 0, i32 7
  %t121 = load i64, ptr %l3, !tbaa !24
  %t124 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t120, i64 %t121)
  store %"compiler/typed:Local" %t124, ptr %l62
  br label %bb26
bb26:
  %t125 = getelementptr %"compiler/typed:Local", ptr %l62, i32 0, i32 0
  %t126 = load i32, ptr %t125, !tbaa !23
  %t127 = load ptr, ptr %l53, !tbaa !29
  %t129 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t127, i32 %t126)
  store { i64, ptr } %t129, ptr %l64
  br label %bb27
bb27:
  %t130 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 1
  %t132 = extractvalue { i64, ptr } %t130, 0
  %t133 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t134 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t135 = add i64 %t132, %t134
  %t136 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 1
  %t138 = extractvalue { i64, ptr } %t136, 0
  %t139 = add i64 %t135, %t138
  %t140 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t139)
  call void @olang_textcopy(ptr %t140, ptr %t131, i64 %t132)
  %t141 = getelementptr i8, ptr %t140, i64 %t132
  call void @olang_textcopy(ptr %t141, ptr %t133, i64 %t134)
  %t142 = getelementptr i8, ptr %t141, i64 %t134
  call void @olang_textcopy(ptr %t142, ptr %t137, i64 %t138)
  %t143 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t140, 1
  %t146 = extractvalue { i64, ptr } %t144, 0
  %t147 = extractvalue { i64, ptr } %t144, 1
  %t148 = mul i64 %t146, 1
  %t149 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t148)
  call void @llvm.memcpy.p0.p0.i64(ptr %t149, ptr %t147, i64 %t148, i1 false)
  %t150 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  %t153 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyToBuiltResult(ptr %s3, ptr %s3, { i64, ptr } %t151)
  store %"compiler/msgs:Msg" %t153, ptr %l67
  br label %bb28
bb28:
  %t154 = load ptr, ptr %l38, !tbaa !29
  %t155 = load %"compiler/source:Span", ptr %l41
  %t156 = load %"compiler/msgs:Msg", ptr %l67
  %t157 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s3, ptr %t154, %"compiler/source:Span" %t155, %"compiler/msgs:Msg" %t156)
  store i64 %t157, ptr %l68
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb30:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eregionKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l11 = alloca %"compiler/typed:Local"
  %l15 = alloca i1
  %l18 = alloca i1
  %l19 = alloca ptr
  %l25 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 25
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_ef7f9cdde83b319d_c7773e471ac0d6b1)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 25
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 7
  %t18 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t14, i64 %a1)
  store %"compiler/typed:Local" %t18, ptr %l11
  br label %bb4
bb4:
  %t19 = getelementptr %"compiler/typed:Local", ptr %l11, i32 0, i32 4
  %t20 = load i32, ptr %t19, !range !{i32 0, i32 7}
  store i32 %t20, ptr %l2
  %t22 = load i32, ptr %l2, !range !{i32 0, i32 7}
  %t24 = trunc i64 0 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb14
bb6:
  %t27 = load i32, ptr %l2, !range !{i32 0, i32 7}
  %t29 = trunc i64 5 to i32
  %t30 = icmp eq i32 %t27, %t29
  br i1 %t30, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l19, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/scope:Scoper", ptr %t33, i32 0, i32 25
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = icmp eq ptr %t36, null
  br i1 %t38, label %bb9, label %bb10
bb8:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb13
bb9:
  call void @__olang_check_failed(ptr @olang_loc_2a41cd82eb4d8236_be11ba524906eaaa)
  unreachable
bb10:
  br label %bb11
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/scope:Scoper", ptr %t40, i32 0, i32 25
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t44 = load ptr, ptr %l19, !tbaa !29
  %t46 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisLambda(ptr %v0, ptr %v0, ptr %t44, ptr %t43)
  store i1 %t46, ptr %l25
  br label %bb12
bb12:
  %t47 = load i1, ptr %l25, !tbaa !21
  store i1 %t47, ptr %l18, !tbaa !21
  br label %bb13
bb13:
  %t48 = load i1, ptr %l18, !tbaa !21
  store i1 %t48, ptr %l15, !tbaa !21
  br label %bb14
bb14:
  %t49 = load i1, ptr %l15, !tbaa !21
  store i1 %t49, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eslotKind(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca i1
  %l29 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca i1
  %l39 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t10 = load i64, ptr @G_2ecompiler_2fscope_2eFitGlobal, !tbaa !24
  store i64 %t10, ptr %l5, !tbaa !24
  br label %bb38
bb6:
  %t12 = load ptr, ptr %l1, !tbaa !29
  store ptr %t12, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t13 = load ptr, ptr %l11, !tbaa !29
  %t14 = icmp ne ptr %t13, null
  br i1 %t14, label %bb7, label %bb8
bb7:
  %t16 = load ptr, ptr %l11, !tbaa !29
  %t17 = load i64, ptr %t16, !range !{i64 0, i64 8}
  %t19 = icmp eq i64 %t17, 3
  store i1 %t19, ptr %l12, !tbaa !21
  br label %bb8
bb8:
  %t20 = load i1, ptr %l12, !tbaa !21
  br i1 %t20, label %bb9, label %bb10
bb9:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [4 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t23, i32 0, i32 2
  %t25 = load ptr, ptr %t24
  store ptr %t25, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t31 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eslotKind(ptr %v0, ptr %v1, ptr %t27, ptr %t28)
  store i64 %t31, ptr %l19
  br label %bb12
bb12:
  %t32 = load i64, ptr %l19, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  br label %bb38
bb13:
  %t33 = load ptr, ptr %l1, !tbaa !29
  store ptr %t33, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t34 = load ptr, ptr %l20, !tbaa !29
  %t35 = icmp ne ptr %t34, null
  br i1 %t35, label %bb14, label %bb15
bb14:
  %t37 = load ptr, ptr %l20, !tbaa !29
  %t38 = load i64, ptr %t37, !range !{i64 0, i64 8}
  %t40 = icmp eq i64 %t38, 4
  store i1 %t40, ptr %l21, !tbaa !21
  br label %bb15
bb15:
  %t41 = load i1, ptr %l21, !tbaa !21
  br i1 %t41, label %bb16, label %bb17
bb16:
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = getelementptr { i64, [4 x i64] }, ptr %t42, i32 0, i32 1
  %t45 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t44, i32 0, i32 2
  %t46 = load ptr, ptr %t45
  store ptr %t46, ptr %l3, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t51 = getelementptr %"compiler/typed:Elem", ptr %t49, i32 0, i32 0
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t55 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eslotKind(ptr %v0, ptr %v1, ptr %t48, ptr %t52)
  store i64 %t55, ptr %l29
  br label %bb19
bb19:
  %t56 = load i64, ptr %l29, !tbaa !24
  store i64 %t56, ptr %l5, !tbaa !24
  br label %bb38
bb20:
  %t57 = load ptr, ptr %l1, !tbaa !29
  store ptr %t57, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t58 = load ptr, ptr %l30, !tbaa !29
  %t59 = icmp ne ptr %t58, null
  br i1 %t59, label %bb21, label %bb22
bb21:
  %t61 = load ptr, ptr %l30, !tbaa !29
  %t62 = load i64, ptr %t61, !range !{i64 0, i64 8}
  %t64 = icmp eq i64 %t62, 5
  store i1 %t64, ptr %l31, !tbaa !21
  br label %bb22
bb22:
  %t65 = load i1, ptr %l31, !tbaa !21
  br i1 %t65, label %bb23, label %bb24
bb23:
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr { i64, [4 x i64] }, ptr %t66, i32 0, i32 1
  %t69 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t68, i32 0, i32 2
  %t70 = load ptr, ptr %t69
  store ptr %t70, ptr %l4, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load ptr, ptr %l4, !tbaa !29
  %t75 = getelementptr %"compiler/typed:Payload", ptr %t73, i32 0, i32 0
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t79 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eslotKind(ptr %v0, ptr %v1, ptr %t72, ptr %t76)
  store i64 %t79, ptr %l39
  br label %bb26
bb26:
  %t80 = load i64, ptr %l39, !tbaa !24
  store i64 %t80, ptr %l5, !tbaa !24
  br label %bb38
bb27:
  %t81 = load ptr, ptr %l1, !tbaa !29
  store ptr %t81, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t82 = load ptr, ptr %l40, !tbaa !29
  %t83 = icmp ne ptr %t82, null
  br i1 %t83, label %bb28, label %bb29
bb28:
  %t85 = load ptr, ptr %l40, !tbaa !29
  %t86 = load i64, ptr %t85, !range !{i64 0, i64 8}
  %t88 = icmp eq i64 %t86, 0
  store i1 %t88, ptr %l41, !tbaa !21
  br label %bb29
bb29:
  %t89 = load i1, ptr %l41, !tbaa !21
  br i1 %t89, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  %t90 = load i64, ptr @G_2ecompiler_2fscope_2eFitValue, !tbaa !24
  store i64 %t90, ptr %l5, !tbaa !24
  br label %bb38
bb33:
  br i1 true, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  %t92 = load i64, ptr @G_2ecompiler_2fscope_2eFitField, !tbaa !24
  store i64 %t92, ptr %l5, !tbaa !24
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_b810a17036e0b04c_ef2bb18623cc9e48)
  unreachable
bb38:
  %t94 = load i64, ptr %l5, !tbaa !24
  store i64 %t94, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleArray(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l41 = alloca { i64, ptr }
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 112
  store i64 %a1, ptr %t5, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/scope:Scoper", ptr %t6, i32 0, i32 113
  store i1 false, ptr %t8, !tbaa !21
  store i64 %a3, ptr %l4, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = icmp sgt i64 %t15, %t16
  br i1 %t19, label %bb1, label %bb2
bb1:
  %t21 = load i64, ptr %l6, !tbaa !24
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb6
bb3:
  %t25 = load i64, ptr %l5, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sub i64 %t25, %t26
  %t30 = load i64, ptr %l6, !tbaa !24
  %t33 = add i64 %t29, %t30
  %t35 = sub i64 %t33, 1
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = sdiv i64 %t35, %t36
  store i64 %t39, ptr %l22, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb5
bb5:
  %t41 = load i64, ptr %l22, !tbaa !24
  store i64 %t41, ptr %l19, !tbaa !24
  br label %bb6
bb6:
  %t42 = load i64, ptr %l19, !tbaa !24
  store i64 %t42, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb7
bb7:
  %t43 = load i64, ptr %l8, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb8, label %bb9
bb8:
  br label %bb13
bb9:
  br label %bb10
bb10:
  %t51 = load i64, ptr %l4, !tbaa !24
  %t52 = load i64, ptr %l8, !tbaa !24
  %t53 = load i64, ptr %l6, !tbaa !24
  %t56 = mul i64 %t52, %t53
  %t59 = add i64 %t51, %t56
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t62, ptr %l41, !tbaa !27
  %t65 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr ptr, ptr %t66, i64 %t59
  %t68 = load ptr, ptr %t67, !tbaa !39
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleStmt(ptr %v0, ptr %v1, ptr %t61, ptr %t68)
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t72 = load i64, ptr %l8, !tbaa !24
  %t74 = add i64 %t72, 1
  store i64 %t74, ptr %l8, !tbaa !24
  br label %bb7
bb13:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/scope:Scoper", ptr %t76, i32 0, i32 113
  %t79 = load i1, ptr %t78, !tbaa !21
  %t81 = xor i1 %t79, true
  store i1 %t81, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l16 = alloca { i64, ptr }
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleStmt(ptr %v0, ptr %v1, ptr %a0, ptr %t28)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb4
bb10:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca i64
  %l44 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca i64
  %l53 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i64
  %l59 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca { i64, ptr }
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l66 = alloca ptr
  %l69 = alloca i1
  %l72 = alloca ptr
  %l73 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca i1
  %l80 = alloca ptr
  %l81 = alloca i1
  %l87 = alloca i1
  %l90 = alloca i1
  %l95 = alloca ptr
  %l96 = alloca i1
  %l101 = alloca ptr
  %l102 = alloca i1
  %l109 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca i1
  %l123 = alloca i1
  %l139 = alloca ptr
  %l140 = alloca i1
  %l150 = alloca ptr
  %l151 = alloca i1
  %l158 = alloca ptr
  %l159 = alloca i1
  %l174 = alloca i64
  %l177 = alloca i64
  %l196 = alloca { i64, ptr }
  %l201 = alloca i1
  %l204 = alloca i1
  %l208 = alloca i1
  %l216 = alloca ptr
  %l217 = alloca i1
  %l234 = alloca { i64, ptr }
  %l243 = alloca ptr
  %l244 = alloca i1
  %l262 = alloca ptr
  %l263 = alloca i1
  %l277 = alloca { i64, ptr }
  %l282 = alloca i1
  %l284 = alloca i1
  %l286 = alloca i1
  %l289 = alloca i1
  %l296 = alloca ptr
  %l297 = alloca i1
  %l316 = alloca ptr
  %l317 = alloca i1
  %l330 = alloca { i64, ptr }
  %l346 = alloca ptr
  %l347 = alloca i1
  %l360 = alloca { i64, ptr }
  %l380 = alloca { i64, ptr }
  %l393 = alloca ptr
  %l394 = alloca i1
  %l411 = alloca { i64, ptr }
  %l429 = alloca { i64, ptr }
  %l440 = alloca ptr
  %l441 = alloca i1
  %l446 = alloca ptr
  %l447 = alloca i1
  %l459 = alloca { i64, ptr }
  %l468 = alloca ptr
  %l469 = alloca i1
  %l477 = alloca ptr
  %l478 = alloca i1
  %l491 = alloca { i64, ptr }
  %l494 = alloca ptr
  %l495 = alloca i1
  %l501 = alloca i1
  %l504 = alloca i1
  %l512 = alloca ptr
  %l513 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l69, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/scope:Scoper", ptr %t5, i32 0, i32 113
  %t8 = load i1, ptr %t7, !tbaa !21
  store i1 %t8, ptr %l69, !tbaa !21
  br label %bb3
bb3:
  %t10 = load i1, ptr %l69, !tbaa !21
  br i1 %t10, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t12 = load ptr, ptr %l72, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l72, !tbaa !29
  %t16 = load i64, ptr %t15, !range !{i64 0, i64 18}
  %t18 = icmp eq i64 %t16, 0
  store i1 %t18, ptr %l73, !tbaa !21
  br label %bb8
bb8:
  %t19 = load i1, ptr %l73, !tbaa !21
  br i1 %t19, label %bb9, label %bb10
bb9:
  br label %bb15
bb10:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l76, !tbaa !29
  store i1 false, ptr %l77, !tbaa !21
  %t21 = load ptr, ptr %l76, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb11, label %bb12
bb11:
  %t24 = load ptr, ptr %l76, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 18}
  %t27 = icmp eq i64 %t25, 1
  store i1 %t27, ptr %l77, !tbaa !21
  br label %bb12
bb12:
  %t28 = load i1, ptr %l77, !tbaa !21
  br i1 %t28, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb308
bb16:
  %t29 = load ptr, ptr %l1, !tbaa !29
  store ptr %t29, ptr %l80, !tbaa !29
  store i1 false, ptr %l81, !tbaa !21
  %t30 = load ptr, ptr %l80, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb17, label %bb18
bb17:
  %t33 = load ptr, ptr %l80, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 18}
  %t36 = icmp eq i64 %t34, 2
  store i1 %t36, ptr %l81, !tbaa !21
  br label %bb18
bb18:
  %t37 = load i1, ptr %l81, !tbaa !21
  br i1 %t37, label %bb19, label %bb20
bb19:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr { i64, [5 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l3, !tbaa !29
  br label %bb21
bb20:
  br label %bb30
bb21:
  %t44 = load i1, ptr %l2, !tbaa !21
  br i1 %t44, label %bb22, label %bb23
bb22:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %l3, !tbaa !29
  %t50 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleRooted(ptr %v0, ptr %v1, ptr %t46, ptr %t47)
  store i1 %t50, ptr %l90
  br label %bb24
bb23:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb25
bb24:
  %t51 = load i1, ptr %l90, !tbaa !21
  store i1 %t51, ptr %l87, !tbaa !21
  br label %bb25
bb25:
  %t52 = load i1, ptr %l87, !tbaa !21
  br i1 %t52, label %bb26, label %bb27
bb26:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/scope:Scoper", ptr %t53, i32 0, i32 113
  store i1 true, ptr %t55, !tbaa !21
  br label %ret
bb27:
  br label %bb28
bb28:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load ptr, ptr %l3, !tbaa !29
  %t58 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esolePlace(ptr %v0, ptr %v1, ptr %t56, ptr %t57, i1 %t58)
  br label %bb29
bb29:
  br label %bb308
bb30:
  %t62 = load ptr, ptr %l1, !tbaa !29
  store ptr %t62, ptr %l95, !tbaa !29
  store i1 false, ptr %l96, !tbaa !21
  %t63 = load ptr, ptr %l95, !tbaa !29
  %t64 = icmp ne ptr %t63, null
  br i1 %t64, label %bb31, label %bb32
bb31:
  %t66 = load ptr, ptr %l95, !tbaa !29
  %t67 = load i64, ptr %t66, !range !{i64 0, i64 18}
  %t69 = icmp eq i64 %t67, 3
  store i1 %t69, ptr %l96, !tbaa !21
  br label %bb32
bb32:
  %t70 = load i1, ptr %l96, !tbaa !21
  br i1 %t70, label %bb33, label %bb34
bb33:
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr { i64, [5 x i64] }, ptr %t71, i32 0, i32 1
  %t74 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t73, i32 0, i32 2
  %t75 = load ptr, ptr %t74
  store ptr %t75, ptr %l4, !tbaa !29
  br label %bb39
bb34:
  %t77 = load ptr, ptr %l1, !tbaa !29
  store ptr %t77, ptr %l101, !tbaa !29
  store i1 false, ptr %l102, !tbaa !21
  %t78 = load ptr, ptr %l101, !tbaa !29
  %t79 = icmp ne ptr %t78, null
  br i1 %t79, label %bb35, label %bb36
bb35:
  %t81 = load ptr, ptr %l101, !tbaa !29
  %t82 = load i64, ptr %t81, !range !{i64 0, i64 18}
  %t84 = icmp eq i64 %t82, 4
  store i1 %t84, ptr %l102, !tbaa !21
  br label %bb36
bb36:
  %t85 = load i1, ptr %l102, !tbaa !21
  br i1 %t85, label %bb37, label %bb38
bb37:
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr { i64, [5 x i64] }, ptr %t86, i32 0, i32 1
  %t89 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t88, i32 0, i32 2
  %t90 = load ptr, ptr %t89
  store ptr %t90, ptr %l4, !tbaa !29
  br label %bb39
bb38:
  br label %bb45
bb39:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l4, !tbaa !29
  %t96 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleRooted(ptr %v0, ptr %v1, ptr %t92, ptr %t93)
  store i1 %t96, ptr %l109
  br label %bb40
bb40:
  %t97 = load i1, ptr %l109, !tbaa !21
  br i1 %t97, label %bb41, label %bb42
bb41:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/scope:Scoper", ptr %t98, i32 0, i32 113
  store i1 true, ptr %t100, !tbaa !21
  br label %ret
bb42:
  br label %bb43
bb43:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load ptr, ptr %l4, !tbaa !29
  %t103 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esolePlace(ptr %v0, ptr %v1, ptr %t101, ptr %t102, i1 %t103)
  br label %bb44
bb44:
  br label %bb308
bb45:
  %t107 = load ptr, ptr %l1, !tbaa !29
  store ptr %t107, ptr %l114, !tbaa !29
  store i1 false, ptr %l115, !tbaa !21
  %t108 = load ptr, ptr %l114, !tbaa !29
  %t109 = icmp ne ptr %t108, null
  br i1 %t109, label %bb46, label %bb47
bb46:
  %t111 = load ptr, ptr %l114, !tbaa !29
  %t112 = load i64, ptr %t111, !range !{i64 0, i64 18}
  %t114 = icmp eq i64 %t112, 10
  store i1 %t114, ptr %l115, !tbaa !21
  br label %bb47
bb47:
  %t115 = load i1, ptr %l115, !tbaa !21
  br i1 %t115, label %bb48, label %bb49
bb48:
  %t116 = load ptr, ptr %l1, !tbaa !29
  %t118 = getelementptr { i64, [5 x i64] }, ptr %t116, i32 0, i32 1
  %t119 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t118, i32 0, i32 2
  %t120 = load ptr, ptr %t119
  store ptr %t120, ptr %l5, !tbaa !29
  br label %bb50
bb49:
  br label %bb58
bb50:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load ptr, ptr %l5, !tbaa !29
  %t125 = getelementptr %"compiler/typed:Slice", ptr %t123, i32 0, i32 0
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t129 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleRooted(ptr %v0, ptr %v1, ptr %t122, ptr %t126)
  store i1 %t129, ptr %l123
  br label %bb51
bb51:
  %t130 = load i1, ptr %l123, !tbaa !21
  br i1 %t130, label %bb52, label %bb53
bb52:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/scope:Scoper", ptr %t131, i32 0, i32 113
  store i1 true, ptr %t133, !tbaa !21
  br label %ret
bb53:
  br label %bb54
bb54:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load ptr, ptr %l5, !tbaa !29
  %t137 = getelementptr %"compiler/typed:Slice", ptr %t135, i32 0, i32 0
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t139 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esolePlace(ptr %v0, ptr %v1, ptr %t134, ptr %t138, i1 %t139)
  br label %bb55
bb55:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load ptr, ptr %l5, !tbaa !29
  %t146 = getelementptr %"compiler/typed:Slice", ptr %t144, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t149 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t143, ptr %t147, i1 %t149)
  br label %bb56
bb56:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load ptr, ptr %l5, !tbaa !29
  %t156 = getelementptr %"compiler/typed:Slice", ptr %t154, i32 0, i32 2
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t153, ptr %t157, i1 %t159)
  br label %bb57
bb57:
  br label %bb308
bb58:
  %t163 = load ptr, ptr %l1, !tbaa !29
  store ptr %t163, ptr %l139, !tbaa !29
  store i1 false, ptr %l140, !tbaa !21
  %t164 = load ptr, ptr %l139, !tbaa !29
  %t165 = icmp ne ptr %t164, null
  br i1 %t165, label %bb59, label %bb60
bb59:
  %t167 = load ptr, ptr %l139, !tbaa !29
  %t168 = load i64, ptr %t167, !range !{i64 0, i64 18}
  %t170 = icmp eq i64 %t168, 5
  store i1 %t170, ptr %l140, !tbaa !21
  br label %bb60
bb60:
  %t171 = load i1, ptr %l140, !tbaa !21
  br i1 %t171, label %bb61, label %bb62
bb61:
  %t172 = load ptr, ptr %l1, !tbaa !29
  %t174 = getelementptr { i64, [5 x i64] }, ptr %t172, i32 0, i32 1
  %t175 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t174, i32 0, i32 2
  %t176 = load ptr, ptr %t175
  store ptr %t176, ptr %l6, !tbaa !29
  br label %bb63
bb62:
  br label %bb65
bb63:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load ptr, ptr %l6, !tbaa !29
  %t181 = getelementptr %"compiler/typed:Promote", ptr %t179, i32 0, i32 0
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t184 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t178, ptr %t182, i1 %t184)
  br label %bb64
bb64:
  br label %bb308
bb65:
  %t188 = load ptr, ptr %l1, !tbaa !29
  store ptr %t188, ptr %l150, !tbaa !29
  store i1 false, ptr %l151, !tbaa !21
  %t189 = load ptr, ptr %l150, !tbaa !29
  %t190 = icmp ne ptr %t189, null
  br i1 %t190, label %bb66, label %bb67
bb66:
  %t192 = load ptr, ptr %l150, !tbaa !29
  %t193 = load i64, ptr %t192, !range !{i64 0, i64 18}
  %t195 = icmp eq i64 %t193, 6
  store i1 %t195, ptr %l151, !tbaa !21
  br label %bb67
bb67:
  %t196 = load i1, ptr %l151, !tbaa !21
  br i1 %t196, label %bb68, label %bb69
bb68:
  %t197 = load ptr, ptr %l1, !tbaa !29
  %t199 = getelementptr { i64, [5 x i64] }, ptr %t197, i32 0, i32 1
  %t200 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t199, i32 0, i32 2
  %t201 = load ptr, ptr %t200
  store ptr %t201, ptr %l7, !tbaa !29
  br label %bb70
bb69:
  br label %bb107
bb70:
  %t203 = load ptr, ptr %l7, !tbaa !29
  %t205 = getelementptr %"compiler/typed:Call", ptr %t203, i32 0, i32 0
  %t206 = load ptr, ptr %t205, !tbaa !29
  store ptr %t206, ptr %l8, !tbaa !29
  %t208 = load ptr, ptr %l8, !tbaa !29
  store ptr %t208, ptr %l158, !tbaa !29
  store i1 false, ptr %l159, !tbaa !21
  %t209 = load ptr, ptr %l158, !tbaa !29
  %t210 = icmp ne ptr %t209, null
  br i1 %t210, label %bb71, label %bb72
bb71:
  %t212 = load ptr, ptr %l158, !tbaa !29
  %t213 = load i64, ptr %t212, !range !{i64 0, i64 5}
  %t215 = icmp eq i64 %t213, 2
  store i1 %t215, ptr %l159, !tbaa !21
  br label %bb72
bb72:
  %t216 = load i1, ptr %l159, !tbaa !21
  br i1 %t216, label %bb73, label %bb74
bb73:
  %t217 = load ptr, ptr %l8, !tbaa !29
  %t219 = getelementptr { i64, [3 x i64] }, ptr %t217, i32 0, i32 1
  %t220 = getelementptr { ptr }, ptr %t219, i32 0, i32 0
  %t221 = load ptr, ptr %t220
  store ptr %t221, ptr %l9, !tbaa !29
  br label %bb75
bb74:
  br label %bb77
bb75:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t224 = load ptr, ptr %l9, !tbaa !29
  %t226 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t223, ptr %t224, i1 %t226)
  br label %bb76
bb76:
  br label %bb82
bb77:
  br i1 true, label %bb78, label %bb79
bb78:
  br label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb82
bb81:
  call void @__olang_check_failed(ptr @olang_loc_df5619edc5954020_95eed2e83037cdb4)
  unreachable
bb82:
  store i64 0, ptr %l10, !tbaa !24
  %t230 = load ptr, ptr %l7, !tbaa !29
  %t232 = getelementptr %"compiler/typed:Call", ptr %t230, i32 0, i32 1
  %t233 = load { i64, ptr }, ptr %t232, !tbaa !27
  %t235 = extractvalue { i64, ptr } %t233, 0
  store i64 %t235, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t237 = load i64, ptr %l11, !tbaa !24
  %t238 = load i64, ptr %l10, !tbaa !24
  %t241 = icmp sgt i64 %t237, %t238
  br i1 %t241, label %bb83, label %bb84
bb83:
  %t243 = load i64, ptr %l12, !tbaa !24
  %t245 = icmp sgt i64 %t243, 0
  br i1 %t245, label %bb85, label %bb86
bb84:
  store i64 0, ptr %l174, !tbaa !24
  br label %bb88
bb85:
  %t247 = load i64, ptr %l11, !tbaa !24
  %t248 = load i64, ptr %l10, !tbaa !24
  %t251 = sub i64 %t247, %t248
  %t252 = load i64, ptr %l12, !tbaa !24
  %t255 = add i64 %t251, %t252
  %t257 = sub i64 %t255, 1
  %t258 = load i64, ptr %l12, !tbaa !24
  %t261 = sdiv i64 %t257, %t258
  store i64 %t261, ptr %l177, !tbaa !24
  br label %bb87
bb86:
  store i64 0, ptr %l177, !tbaa !24
  br label %bb87
bb87:
  %t263 = load i64, ptr %l177, !tbaa !24
  store i64 %t263, ptr %l174, !tbaa !24
  br label %bb88
bb88:
  %t264 = load i64, ptr %l174, !tbaa !24
  store i64 %t264, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb89
bb89:
  %t265 = load i64, ptr %l14, !tbaa !24
  %t266 = load i64, ptr %l13, !tbaa !24
  %t269 = icmp slt i64 %t265, %t266
  %t271 = xor i1 %t269, true
  br i1 %t271, label %bb90, label %bb91
bb90:
  br label %bb106
bb91:
  br label %bb92
bb92:
  %t273 = load i64, ptr %l10, !tbaa !24
  %t274 = load i64, ptr %l14, !tbaa !24
  %t275 = load i64, ptr %l12, !tbaa !24
  %t278 = mul i64 %t274, %t275
  %t281 = add i64 %t273, %t278
  store i64 %t281, ptr %l15, !tbaa !24
  %t283 = load ptr, ptr %l7, !tbaa !29
  %t285 = getelementptr %"compiler/typed:Call", ptr %t283, i32 0, i32 1
  %t286 = load { i64, ptr }, ptr %t285, !tbaa !27
  store { i64, ptr } %t286, ptr %l196, !tbaa !27
  %t287 = load i64, ptr %l15, !tbaa !24
  %t289 = getelementptr { i64, ptr }, ptr %l196, i32 0, i32 1
  %t290 = load ptr, ptr %t289, !tbaa !27
  %t291 = getelementptr ptr, ptr %t290, i64 %t287
  %t292 = load ptr, ptr %t291, !tbaa !39
  store ptr %t292, ptr %l16, !tbaa !29
  %t294 = load i1, ptr %l2, !tbaa !21
  %t296 = xor i1 %t294, true
  br i1 %t296, label %bb93, label %bb94
bb93:
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t299 = load ptr, ptr %l16, !tbaa !29
  %t302 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleBorrow(ptr %v0, ptr %v1, ptr %t298, ptr %t299)
  store i1 %t302, ptr %l204
  br label %bb95
bb94:
  store i1 false, ptr %l201, !tbaa !21
  br label %bb96
bb95:
  %t303 = load i1, ptr %l204, !tbaa !21
  store i1 %t303, ptr %l201, !tbaa !21
  br label %bb96
bb96:
  %t304 = load i1, ptr %l201, !tbaa !21
  br i1 %t304, label %bb97, label %bb98
bb97:
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t306 = load ptr, ptr %l7, !tbaa !29
  %t307 = load i64, ptr %l15, !tbaa !24
  %t311 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecanKeep(ptr %v0, ptr %v1, ptr %t305, ptr %t306, i64 %t307)
  store i1 %t311, ptr %l208
  br label %bb99
bb98:
  br label %bb103
bb99:
  %t312 = load i1, ptr %l208, !tbaa !21
  br i1 %t312, label %bb100, label %bb101
bb100:
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t315 = getelementptr %"compiler/scope:Scoper", ptr %t313, i32 0, i32 113
  store i1 true, ptr %t315, !tbaa !21
  br label %bb102
bb101:
  br label %bb102
bb102:
  br label %bb105
bb103:
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t317 = load ptr, ptr %l16, !tbaa !29
  %t319 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t316, ptr %t317, i1 %t319)
  br label %bb104
bb104:
  br label %bb105
bb105:
  %t323 = load i64, ptr %l14, !tbaa !24
  %t325 = add i64 %t323, 1
  store i64 %t325, ptr %l14, !tbaa !24
  br label %bb89
bb106:
  br label %bb308
bb107:
  %t327 = load ptr, ptr %l1, !tbaa !29
  store ptr %t327, ptr %l216, !tbaa !29
  store i1 false, ptr %l217, !tbaa !21
  %t328 = load ptr, ptr %l216, !tbaa !29
  %t329 = icmp ne ptr %t328, null
  br i1 %t329, label %bb108, label %bb109
bb108:
  %t331 = load ptr, ptr %l216, !tbaa !29
  %t332 = load i64, ptr %t331, !range !{i64 0, i64 18}
  %t334 = icmp eq i64 %t332, 7
  store i1 %t334, ptr %l217, !tbaa !21
  br label %bb109
bb109:
  %t335 = load i1, ptr %l217, !tbaa !21
  br i1 %t335, label %bb110, label %bb111
bb110:
  %t336 = load ptr, ptr %l1, !tbaa !29
  %t338 = getelementptr { i64, [5 x i64] }, ptr %t336, i32 0, i32 1
  %t339 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t338, i32 0, i32 2
  %t340 = load ptr, ptr %t339
  store ptr %t340, ptr %l17, !tbaa !29
  br label %bb112
bb111:
  br label %bb121
bb112:
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t343 = load ptr, ptr %l17, !tbaa !29
  %t345 = getelementptr %"compiler/typed:Make", ptr %t343, i32 0, i32 3
  %t346 = load ptr, ptr %t345, !tbaa !29
  %t347 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t342, ptr %t346, i1 %t347)
  br label %bb113
bb113:
  %t351 = load ptr, ptr %l17, !tbaa !29
  %t353 = getelementptr %"compiler/typed:Make", ptr %t351, i32 0, i32 2
  %t354 = load { i64, ptr }, ptr %t353, !tbaa !27
  store { i64, ptr } %t354, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t356 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t358 = extractvalue { i64, ptr } %t356, 0
  store i64 %t358, ptr %l20, !tbaa !24
  br label %bb114
bb114:
  %t360 = load i64, ptr %l19, !tbaa !24
  %t361 = load i64, ptr %l20, !tbaa !24
  %t364 = icmp slt i64 %t360, %t361
  %t366 = xor i1 %t364, true
  br i1 %t366, label %bb115, label %bb116
bb115:
  br label %bb120
bb116:
  br label %bb117
bb117:
  %t368 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t368, ptr %l234, !tbaa !27
  %t369 = load i64, ptr %l19, !tbaa !24
  %t371 = getelementptr { i64, ptr }, ptr %l234, i32 0, i32 1
  %t372 = load ptr, ptr %t371, !tbaa !27
  %t373 = getelementptr ptr, ptr %t372, i64 %t369
  %t374 = load ptr, ptr %t373, !tbaa !39
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t379 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t376, ptr %t374, i1 %t379)
  br label %bb118
bb118:
  br label %bb119
bb119:
  %t383 = load i64, ptr %l19, !tbaa !24
  %t385 = add i64 %t383, 1
  store i64 %t385, ptr %l19, !tbaa !24
  br label %bb114
bb120:
  br label %bb308
bb121:
  %t387 = load ptr, ptr %l1, !tbaa !29
  store ptr %t387, ptr %l243, !tbaa !29
  store i1 false, ptr %l244, !tbaa !21
  %t388 = load ptr, ptr %l243, !tbaa !29
  %t389 = icmp ne ptr %t388, null
  br i1 %t389, label %bb122, label %bb123
bb122:
  %t391 = load ptr, ptr %l243, !tbaa !29
  %t392 = load i64, ptr %t391, !range !{i64 0, i64 18}
  %t394 = icmp eq i64 %t392, 8
  store i1 %t394, ptr %l244, !tbaa !21
  br label %bb123
bb123:
  %t395 = load i1, ptr %l244, !tbaa !21
  br i1 %t395, label %bb124, label %bb125
bb124:
  %t396 = load ptr, ptr %l1, !tbaa !29
  %t398 = getelementptr { i64, [5 x i64] }, ptr %t396, i32 0, i32 1
  %t399 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t398, i32 0, i32 2
  %t400 = load ptr, ptr %t399
  store ptr %t400, ptr %l22, !tbaa !29
  br label %bb126
bb125:
  br label %bb133
bb126:
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t403 = load ptr, ptr %l22, !tbaa !29
  %t405 = getelementptr %"compiler/typed:Collect", ptr %t403, i32 0, i32 0
  %t406 = load ptr, ptr %t405, !tbaa !29
  %t407 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t402, ptr %t406, i1 %t407)
  br label %bb127
bb127:
  %t411 = load i1, ptr %l2, !tbaa !21
  br i1 %t411, label %bb128, label %bb129
bb128:
  %t413 = load ptr, ptr %l0, !tbaa !29
  %t414 = load ptr, ptr %l22, !tbaa !29
  %t416 = getelementptr %"compiler/typed:Collect", ptr %t414, i32 0, i32 1
  %t417 = load ptr, ptr %t416, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleStrictBlock(ptr %v0, ptr %v1, ptr %t413, ptr %t417)
  br label %bb130
bb129:
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t422 = load ptr, ptr %l22, !tbaa !29
  %t424 = getelementptr %"compiler/typed:Collect", ptr %t422, i32 0, i32 1
  %t425 = load ptr, ptr %t424, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleBlock(ptr %v0, ptr %v1, ptr %t421, ptr %t425)
  br label %bb131
bb130:
  br label %bb132
bb131:
  br label %bb132
bb132:
  br label %bb308
bb133:
  %t429 = load ptr, ptr %l1, !tbaa !29
  store ptr %t429, ptr %l262, !tbaa !29
  store i1 false, ptr %l263, !tbaa !21
  %t430 = load ptr, ptr %l262, !tbaa !29
  %t431 = icmp ne ptr %t430, null
  br i1 %t431, label %bb134, label %bb135
bb134:
  %t433 = load ptr, ptr %l262, !tbaa !29
  %t434 = load i64, ptr %t433, !range !{i64 0, i64 18}
  %t436 = icmp eq i64 %t434, 9
  store i1 %t436, ptr %l263, !tbaa !21
  br label %bb135
bb135:
  %t437 = load i1, ptr %l263, !tbaa !21
  br i1 %t437, label %bb136, label %bb137
bb136:
  %t438 = load ptr, ptr %l1, !tbaa !29
  %t440 = getelementptr { i64, [5 x i64] }, ptr %t438, i32 0, i32 1
  %t441 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t440, i32 0, i32 2
  %t442 = load i32, ptr %t441, !range !{i32 0, i32 43}
  store i32 %t442, ptr %l23
  %t444 = load ptr, ptr %l1, !tbaa !29
  %t446 = getelementptr { i64, [5 x i64] }, ptr %t444, i32 0, i32 1
  %t447 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t446, i32 0, i32 4
  %t448 = load { i64, ptr }, ptr %t447
  store { i64, ptr } %t448, ptr %l24, !tbaa !27
  br label %bb138
bb137:
  br label %bb157
bb138:
  %t450 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t450, ptr %l25, !tbaa !27
  store i64 0, ptr %l26, !tbaa !24
  %t452 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t454 = extractvalue { i64, ptr } %t452, 0
  store i64 %t454, ptr %l27, !tbaa !24
  br label %bb139
bb139:
  %t456 = load i64, ptr %l26, !tbaa !24
  %t457 = load i64, ptr %l27, !tbaa !24
  %t460 = icmp slt i64 %t456, %t457
  %t462 = xor i1 %t460, true
  br i1 %t462, label %bb140, label %bb141
bb140:
  br label %bb156
bb141:
  br label %bb142
bb142:
  %t464 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t464, ptr %l277, !tbaa !27
  %t465 = load i64, ptr %l26, !tbaa !24
  %t467 = getelementptr { i64, ptr }, ptr %l277, i32 0, i32 1
  %t468 = load ptr, ptr %t467, !tbaa !27
  %t469 = getelementptr ptr, ptr %t468, i64 %t465
  %t470 = load ptr, ptr %t469, !tbaa !39
  store ptr %t470, ptr %l28, !tbaa !29
  %t472 = load i1, ptr %l2, !tbaa !21
  %t474 = xor i1 %t472, true
  br i1 %t474, label %bb143, label %bb144
bb143:
  %t476 = load i32, ptr %l23, !range !{i32 0, i32 43}
  %t478 = call i1 @compiler_2ftyped_2ePassesRefs(i32 %t476)
  store i1 %t478, ptr %l284
  br label %bb145
bb144:
  store i1 false, ptr %l282, !tbaa !21
  br label %bb146
bb145:
  %t479 = load i1, ptr %l284, !tbaa !21
  %t480 = xor i1 %t479, true
  store i1 %t480, ptr %l282, !tbaa !21
  br label %bb146
bb146:
  %t482 = load i1, ptr %l282, !tbaa !21
  br i1 %t482, label %bb147, label %bb148
bb147:
  %t483 = load ptr, ptr %l0, !tbaa !29
  %t484 = load ptr, ptr %l28, !tbaa !29
  %t487 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleBorrow(ptr %v0, ptr %v1, ptr %t483, ptr %t484)
  store i1 %t487, ptr %l289
  br label %bb149
bb148:
  store i1 false, ptr %l286, !tbaa !21
  br label %bb150
bb149:
  %t488 = load i1, ptr %l289, !tbaa !21
  store i1 %t488, ptr %l286, !tbaa !21
  br label %bb150
bb150:
  %t489 = load i1, ptr %l286, !tbaa !21
  br i1 %t489, label %bb151, label %bb152
bb151:
  br label %bb155
bb152:
  br label %bb153
bb153:
  %t490 = load ptr, ptr %l0, !tbaa !29
  %t491 = load ptr, ptr %l28, !tbaa !29
  %t493 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t490, ptr %t491, i1 %t493)
  br label %bb154
bb154:
  br label %bb155
bb155:
  %t497 = load i64, ptr %l26, !tbaa !24
  %t499 = add i64 %t497, 1
  store i64 %t499, ptr %l26, !tbaa !24
  br label %bb139
bb156:
  br label %bb308
bb157:
  %t501 = load ptr, ptr %l1, !tbaa !29
  store ptr %t501, ptr %l296, !tbaa !29
  store i1 false, ptr %l297, !tbaa !21
  %t502 = load ptr, ptr %l296, !tbaa !29
  %t503 = icmp ne ptr %t502, null
  br i1 %t503, label %bb158, label %bb159
bb158:
  %t505 = load ptr, ptr %l296, !tbaa !29
  %t506 = load i64, ptr %t505, !range !{i64 0, i64 18}
  %t508 = icmp eq i64 %t506, 11
  store i1 %t508, ptr %l297, !tbaa !21
  br label %bb159
bb159:
  %t509 = load i1, ptr %l297, !tbaa !21
  br i1 %t509, label %bb160, label %bb161
bb160:
  %t510 = load ptr, ptr %l1, !tbaa !29
  %t512 = getelementptr { i64, [5 x i64] }, ptr %t510, i32 0, i32 1
  %t513 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t512, i32 0, i32 2
  %t514 = load ptr, ptr %t513
  store ptr %t514, ptr %l29, !tbaa !29
  br label %bb162
bb161:
  br label %bb166
bb162:
  %t516 = load ptr, ptr %l0, !tbaa !29
  %t517 = load ptr, ptr %l29, !tbaa !29
  %t519 = getelementptr %"compiler/typed:Cond", ptr %t517, i32 0, i32 0
  %t520 = load ptr, ptr %t519, !tbaa !29
  %t522 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t516, ptr %t520, i1 %t522)
  br label %bb163
bb163:
  %t526 = load ptr, ptr %l0, !tbaa !29
  %t527 = load ptr, ptr %l29, !tbaa !29
  %t529 = getelementptr %"compiler/typed:Cond", ptr %t527, i32 0, i32 1
  %t530 = load ptr, ptr %t529, !tbaa !29
  %t531 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t526, ptr %t530, i1 %t531)
  br label %bb164
bb164:
  %t535 = load ptr, ptr %l0, !tbaa !29
  %t536 = load ptr, ptr %l29, !tbaa !29
  %t538 = getelementptr %"compiler/typed:Cond", ptr %t536, i32 0, i32 2
  %t539 = load ptr, ptr %t538, !tbaa !29
  %t541 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t535, ptr %t539, i1 %t541)
  br label %bb165
bb165:
  br label %bb308
bb166:
  %t545 = load ptr, ptr %l1, !tbaa !29
  store ptr %t545, ptr %l316, !tbaa !29
  store i1 false, ptr %l317, !tbaa !21
  %t546 = load ptr, ptr %l316, !tbaa !29
  %t547 = icmp ne ptr %t546, null
  br i1 %t547, label %bb167, label %bb168
bb167:
  %t549 = load ptr, ptr %l316, !tbaa !29
  %t550 = load i64, ptr %t549, !range !{i64 0, i64 18}
  %t552 = icmp eq i64 %t550, 12
  store i1 %t552, ptr %l317, !tbaa !21
  br label %bb168
bb168:
  %t553 = load i1, ptr %l317, !tbaa !21
  br i1 %t553, label %bb169, label %bb170
bb169:
  %t554 = load ptr, ptr %l1, !tbaa !29
  %t556 = getelementptr { i64, [5 x i64] }, ptr %t554, i32 0, i32 1
  %t557 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t556, i32 0, i32 2
  %t558 = load ptr, ptr %t557
  store ptr %t558, ptr %l30, !tbaa !29
  br label %bb171
bb170:
  br label %bb184
bb171:
  %t560 = load ptr, ptr %l30, !tbaa !29
  %t562 = getelementptr %"compiler/typed:Seq", ptr %t560, i32 0, i32 0
  %t563 = load { i64, ptr }, ptr %t562, !tbaa !27
  store { i64, ptr } %t563, ptr %l31, !tbaa !27
  store i64 0, ptr %l32, !tbaa !24
  %t565 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t567 = extractvalue { i64, ptr } %t565, 0
  store i64 %t567, ptr %l33, !tbaa !24
  br label %bb172
bb172:
  %t569 = load i64, ptr %l32, !tbaa !24
  %t570 = load i64, ptr %l33, !tbaa !24
  %t573 = icmp slt i64 %t569, %t570
  %t575 = xor i1 %t573, true
  br i1 %t575, label %bb173, label %bb174
bb173:
  br label %bb182
bb174:
  br label %bb175
bb175:
  %t577 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t577, ptr %l330, !tbaa !27
  %t578 = load i64, ptr %l32, !tbaa !24
  %t580 = getelementptr { i64, ptr }, ptr %l330, i32 0, i32 1
  %t581 = load ptr, ptr %t580, !tbaa !27
  %t582 = getelementptr ptr, ptr %t581, i64 %t578
  %t583 = load ptr, ptr %t582, !tbaa !39
  store ptr %t583, ptr %l34, !tbaa !29
  %t585 = load i1, ptr %l2, !tbaa !21
  br i1 %t585, label %bb176, label %bb177
bb176:
  %t587 = load ptr, ptr %l0, !tbaa !29
  %t588 = load ptr, ptr %l34, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleStrictStmt(ptr %v0, ptr %v1, ptr %t587, ptr %t588)
  br label %bb178
bb177:
  %t592 = load ptr, ptr %l0, !tbaa !29
  %t593 = load ptr, ptr %l34, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleStmt(ptr %v0, ptr %v1, ptr %t592, ptr %t593)
  br label %bb179
bb178:
  br label %bb180
bb179:
  br label %bb180
bb180:
  br label %bb181
bb181:
  %t597 = load i64, ptr %l32, !tbaa !24
  %t599 = add i64 %t597, 1
  store i64 %t599, ptr %l32, !tbaa !24
  br label %bb172
bb182:
  %t601 = load ptr, ptr %l0, !tbaa !29
  %t602 = load ptr, ptr %l30, !tbaa !29
  %t604 = getelementptr %"compiler/typed:Seq", ptr %t602, i32 0, i32 1
  %t605 = load ptr, ptr %t604, !tbaa !29
  %t606 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t601, ptr %t605, i1 %t606)
  br label %bb183
bb183:
  br label %bb308
bb184:
  %t610 = load ptr, ptr %l1, !tbaa !29
  store ptr %t610, ptr %l346, !tbaa !29
  store i1 false, ptr %l347, !tbaa !21
  %t611 = load ptr, ptr %l346, !tbaa !29
  %t612 = icmp ne ptr %t611, null
  br i1 %t612, label %bb185, label %bb186
bb185:
  %t614 = load ptr, ptr %l346, !tbaa !29
  %t615 = load i64, ptr %t614, !range !{i64 0, i64 18}
  %t617 = icmp eq i64 %t615, 13
  store i1 %t617, ptr %l347, !tbaa !21
  br label %bb186
bb186:
  %t618 = load i1, ptr %l347, !tbaa !21
  br i1 %t618, label %bb187, label %bb188
bb187:
  %t619 = load ptr, ptr %l1, !tbaa !29
  %t621 = getelementptr { i64, [5 x i64] }, ptr %t619, i32 0, i32 1
  %t622 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t621, i32 0, i32 2
  %t623 = load ptr, ptr %t622
  store ptr %t623, ptr %l35, !tbaa !29
  br label %bb189
bb188:
  br label %bb209
bb189:
  %t625 = load ptr, ptr %l35, !tbaa !29
  %t627 = getelementptr %"compiler/typed:Match", ptr %t625, i32 0, i32 0
  %t628 = load { i64, ptr }, ptr %t627, !tbaa !27
  store { i64, ptr } %t628, ptr %l36, !tbaa !27
  store i64 0, ptr %l37, !tbaa !24
  %t630 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t632 = extractvalue { i64, ptr } %t630, 0
  store i64 %t632, ptr %l38, !tbaa !24
  br label %bb190
bb190:
  %t634 = load i64, ptr %l37, !tbaa !24
  %t635 = load i64, ptr %l38, !tbaa !24
  %t638 = icmp slt i64 %t634, %t635
  %t640 = xor i1 %t638, true
  br i1 %t640, label %bb191, label %bb192
bb191:
  br label %bb200
bb192:
  br label %bb193
bb193:
  %t642 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t642, ptr %l360, !tbaa !27
  %t643 = load i64, ptr %l37, !tbaa !24
  %t645 = getelementptr { i64, ptr }, ptr %l360, i32 0, i32 1
  %t646 = load ptr, ptr %t645, !tbaa !27
  %t647 = getelementptr ptr, ptr %t646, i64 %t643
  %t648 = load ptr, ptr %t647, !tbaa !39
  store ptr %t648, ptr %l39, !tbaa !29
  %t650 = load i1, ptr %l2, !tbaa !21
  br i1 %t650, label %bb194, label %bb195
bb194:
  %t652 = load ptr, ptr %l0, !tbaa !29
  %t653 = load ptr, ptr %l39, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleStrictStmt(ptr %v0, ptr %v1, ptr %t652, ptr %t653)
  br label %bb196
bb195:
  %t657 = load ptr, ptr %l0, !tbaa !29
  %t658 = load ptr, ptr %l39, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleStmt(ptr %v0, ptr %v1, ptr %t657, ptr %t658)
  br label %bb197
bb196:
  br label %bb198
bb197:
  br label %bb198
bb198:
  br label %bb199
bb199:
  %t662 = load i64, ptr %l37, !tbaa !24
  %t664 = add i64 %t662, 1
  store i64 %t664, ptr %l37, !tbaa !24
  br label %bb190
bb200:
  %t666 = load ptr, ptr %l35, !tbaa !29
  %t668 = getelementptr %"compiler/typed:Match", ptr %t666, i32 0, i32 1
  %t669 = load { i64, ptr }, ptr %t668, !tbaa !27
  store { i64, ptr } %t669, ptr %l40, !tbaa !27
  store i64 0, ptr %l41, !tbaa !24
  %t671 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t673 = extractvalue { i64, ptr } %t671, 0
  store i64 %t673, ptr %l42, !tbaa !24
  br label %bb201
bb201:
  %t675 = load i64, ptr %l41, !tbaa !24
  %t676 = load i64, ptr %l42, !tbaa !24
  %t679 = icmp slt i64 %t675, %t676
  %t681 = xor i1 %t679, true
  br i1 %t681, label %bb202, label %bb203
bb202:
  br label %bb207
bb203:
  br label %bb204
bb204:
  %t683 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t683, ptr %l380, !tbaa !27
  %t684 = load i64, ptr %l41, !tbaa !24
  %t686 = getelementptr { i64, ptr }, ptr %l380, i32 0, i32 1
  %t687 = load ptr, ptr %t686, !tbaa !27
  %t688 = getelementptr ptr, ptr %t687, i64 %t684
  %t689 = load ptr, ptr %t688, !tbaa !39
  %t691 = load ptr, ptr %l0, !tbaa !29
  %t694 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleArm(ptr %v0, ptr %v1, ptr %t691, ptr %t689, i1 %t694)
  br label %bb205
bb205:
  br label %bb206
bb206:
  %t698 = load i64, ptr %l41, !tbaa !24
  %t700 = add i64 %t698, 1
  store i64 %t700, ptr %l41, !tbaa !24
  br label %bb201
bb207:
  %t702 = load ptr, ptr %l0, !tbaa !29
  %t703 = load ptr, ptr %l35, !tbaa !29
  %t705 = getelementptr %"compiler/typed:Match", ptr %t703, i32 0, i32 2
  %t706 = load ptr, ptr %t705, !tbaa !29
  %t707 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleArm(ptr %v0, ptr %v1, ptr %t702, ptr %t706, i1 %t707)
  br label %bb208
bb208:
  br label %bb308
bb209:
  %t711 = load ptr, ptr %l1, !tbaa !29
  store ptr %t711, ptr %l393, !tbaa !29
  store i1 false, ptr %l394, !tbaa !21
  %t712 = load ptr, ptr %l393, !tbaa !29
  %t713 = icmp ne ptr %t712, null
  br i1 %t713, label %bb210, label %bb211
bb210:
  %t715 = load ptr, ptr %l393, !tbaa !29
  %t716 = load i64, ptr %t715, !range !{i64 0, i64 18}
  %t718 = icmp eq i64 %t716, 14
  store i1 %t718, ptr %l394, !tbaa !21
  br label %bb211
bb211:
  %t719 = load i1, ptr %l394, !tbaa !21
  br i1 %t719, label %bb212, label %bb213
bb212:
  %t720 = load ptr, ptr %l1, !tbaa !29
  %t722 = getelementptr { i64, [5 x i64] }, ptr %t720, i32 0, i32 1
  %t723 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t722, i32 0, i32 2
  %t724 = load ptr, ptr %t723
  store ptr %t724, ptr %l44, !tbaa !29
  br label %bb214
bb213:
  br label %bb234
bb214:
  %t726 = load ptr, ptr %l0, !tbaa !29
  %t727 = load ptr, ptr %l44, !tbaa !29
  %t729 = getelementptr %"compiler/typed:Try", ptr %t727, i32 0, i32 0
  %t730 = load ptr, ptr %t729, !tbaa !29
  %t731 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t726, ptr %t730, i1 %t731)
  br label %bb215
bb215:
  %t735 = load ptr, ptr %l44, !tbaa !29
  %t737 = getelementptr %"compiler/typed:Try", ptr %t735, i32 0, i32 1
  %t738 = load { i64, ptr }, ptr %t737, !tbaa !27
  store { i64, ptr } %t738, ptr %l45, !tbaa !27
  store i64 0, ptr %l46, !tbaa !24
  %t740 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t742 = extractvalue { i64, ptr } %t740, 0
  store i64 %t742, ptr %l47, !tbaa !24
  br label %bb216
bb216:
  %t744 = load i64, ptr %l46, !tbaa !24
  %t745 = load i64, ptr %l47, !tbaa !24
  %t748 = icmp slt i64 %t744, %t745
  %t750 = xor i1 %t748, true
  br i1 %t750, label %bb217, label %bb218
bb217:
  br label %bb233
bb218:
  br label %bb219
bb219:
  %t752 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t752, ptr %l411, !tbaa !27
  %t753 = load i64, ptr %l46, !tbaa !24
  %t755 = getelementptr { i64, ptr }, ptr %l411, i32 0, i32 1
  %t756 = load ptr, ptr %t755, !tbaa !27
  %t757 = getelementptr ptr, ptr %t756, i64 %t753
  %t758 = load ptr, ptr %t757, !tbaa !39
  store ptr %t758, ptr %l48, !tbaa !29
  %t760 = load i1, ptr %l2, !tbaa !21
  br i1 %t760, label %bb220, label %bb221
bb220:
  %t762 = load ptr, ptr %l0, !tbaa !29
  %t763 = load ptr, ptr %l48, !tbaa !29
  %t765 = getelementptr %"compiler/typed:Clause", ptr %t763, i32 0, i32 3
  %t766 = load ptr, ptr %t765, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleStrictBlock(ptr %v0, ptr %v1, ptr %t762, ptr %t766)
  br label %bb222
bb221:
  %t769 = load ptr, ptr %l0, !tbaa !29
  %t770 = load ptr, ptr %l48, !tbaa !29
  %t772 = getelementptr %"compiler/typed:Clause", ptr %t770, i32 0, i32 3
  %t773 = load ptr, ptr %t772, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleBlock(ptr %v0, ptr %v1, ptr %t769, ptr %t773)
  br label %bb223
bb222:
  br label %bb224
bb223:
  br label %bb224
bb224:
  %t776 = load ptr, ptr %l48, !tbaa !29
  %t778 = getelementptr %"compiler/typed:Clause", ptr %t776, i32 0, i32 4
  %t779 = load { i64, ptr }, ptr %t778, !tbaa !27
  store { i64, ptr } %t779, ptr %l49, !tbaa !27
  store i64 0, ptr %l50, !tbaa !24
  %t781 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t783 = extractvalue { i64, ptr } %t781, 0
  store i64 %t783, ptr %l51, !tbaa !24
  br label %bb225
bb225:
  %t785 = load i64, ptr %l50, !tbaa !24
  %t786 = load i64, ptr %l51, !tbaa !24
  %t789 = icmp slt i64 %t785, %t786
  %t791 = xor i1 %t789, true
  br i1 %t791, label %bb226, label %bb227
bb226:
  br label %bb231
bb227:
  br label %bb228
bb228:
  %t793 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t793, ptr %l429, !tbaa !27
  %t794 = load i64, ptr %l50, !tbaa !24
  %t796 = getelementptr { i64, ptr }, ptr %l429, i32 0, i32 1
  %t797 = load ptr, ptr %t796, !tbaa !27
  %t798 = getelementptr ptr, ptr %t797, i64 %t794
  %t799 = load ptr, ptr %t798, !tbaa !39
  %t801 = load ptr, ptr %l0, !tbaa !29
  %t804 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t801, ptr %t799, i1 %t804)
  br label %bb229
bb229:
  br label %bb230
bb230:
  %t808 = load i64, ptr %l50, !tbaa !24
  %t810 = add i64 %t808, 1
  store i64 %t810, ptr %l50, !tbaa !24
  br label %bb225
bb231:
  br label %bb232
bb232:
  %t812 = load i64, ptr %l46, !tbaa !24
  %t814 = add i64 %t812, 1
  store i64 %t814, ptr %l46, !tbaa !24
  br label %bb216
bb233:
  br label %bb308
bb234:
  %t816 = load ptr, ptr %l1, !tbaa !29
  store ptr %t816, ptr %l440, !tbaa !29
  store i1 false, ptr %l441, !tbaa !21
  %t817 = load ptr, ptr %l440, !tbaa !29
  %t818 = icmp ne ptr %t817, null
  br i1 %t818, label %bb235, label %bb236
bb235:
  %t820 = load ptr, ptr %l440, !tbaa !29
  %t821 = load i64, ptr %t820, !range !{i64 0, i64 18}
  %t823 = icmp eq i64 %t821, 15
  store i1 %t823, ptr %l441, !tbaa !21
  br label %bb236
bb236:
  %t824 = load i1, ptr %l441, !tbaa !21
  br i1 %t824, label %bb237, label %bb238
bb237:
  %t825 = load ptr, ptr %l1, !tbaa !29
  %t827 = getelementptr { i64, [5 x i64] }, ptr %t825, i32 0, i32 1
  %t828 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t827, i32 0, i32 2
  %t829 = load ptr, ptr %t828
  store ptr %t829, ptr %l53, !tbaa !29
  br label %bb239
bb238:
  br label %bb265
bb239:
  %t831 = load ptr, ptr %l53, !tbaa !29
  store ptr %t831, ptr %l446, !tbaa !29
  store i1 false, ptr %l447, !tbaa !21
  %t832 = load ptr, ptr %l446, !tbaa !29
  %t833 = icmp ne ptr %t832, null
  br i1 %t833, label %bb240, label %bb241
bb240:
  %t835 = load ptr, ptr %l446, !tbaa !29
  %t836 = load i64, ptr %t835, !range !{i64 0, i64 3}
  %t838 = icmp eq i64 %t836, 1
  store i1 %t838, ptr %l447, !tbaa !21
  br label %bb241
bb241:
  %t839 = load i1, ptr %l447, !tbaa !21
  br i1 %t839, label %bb242, label %bb243
bb242:
  %t840 = load ptr, ptr %l53, !tbaa !29
  %t842 = getelementptr { i64, [4 x i64] }, ptr %t840, i32 0, i32 1
  %t843 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t842, i32 0, i32 1
  %t844 = load { i64, ptr }, ptr %t843
  store { i64, ptr } %t844, ptr %l54, !tbaa !27
  br label %bb244
bb243:
  br label %bb252
bb244:
  %t846 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t846, ptr %l55, !tbaa !27
  store i64 0, ptr %l56, !tbaa !24
  %t848 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t850 = extractvalue { i64, ptr } %t848, 0
  store i64 %t850, ptr %l57, !tbaa !24
  br label %bb245
bb245:
  %t852 = load i64, ptr %l56, !tbaa !24
  %t853 = load i64, ptr %l57, !tbaa !24
  %t856 = icmp slt i64 %t852, %t853
  %t858 = xor i1 %t856, true
  br i1 %t858, label %bb246, label %bb247
bb246:
  br label %bb251
bb247:
  br label %bb248
bb248:
  %t860 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t860, ptr %l459, !tbaa !27
  %t861 = load i64, ptr %l56, !tbaa !24
  %t863 = getelementptr { i64, ptr }, ptr %l459, i32 0, i32 1
  %t864 = load ptr, ptr %t863, !tbaa !27
  %t865 = getelementptr ptr, ptr %t864, i64 %t861
  %t866 = load ptr, ptr %t865, !tbaa !39
  %t868 = load ptr, ptr %l0, !tbaa !29
  %t871 = getelementptr %"compiler/typed:Capture", ptr %t866, i32 0, i32 1
  %t872 = load ptr, ptr %t871, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t868, ptr %t872, i1 true)
  br label %bb249
bb249:
  br label %bb250
bb250:
  %t876 = load i64, ptr %l56, !tbaa !24
  %t878 = add i64 %t876, 1
  store i64 %t878, ptr %l56, !tbaa !24
  br label %bb245
bb251:
  br label %bb264
bb252:
  %t880 = load ptr, ptr %l53, !tbaa !29
  store ptr %t880, ptr %l468, !tbaa !29
  store i1 false, ptr %l469, !tbaa !21
  %t881 = load ptr, ptr %l468, !tbaa !29
  %t882 = icmp ne ptr %t881, null
  br i1 %t882, label %bb253, label %bb254
bb253:
  %t884 = load ptr, ptr %l468, !tbaa !29
  %t885 = load i64, ptr %t884, !range !{i64 0, i64 3}
  %t887 = icmp eq i64 %t885, 2
  store i1 %t887, ptr %l469, !tbaa !21
  br label %bb254
bb254:
  %t888 = load i1, ptr %l469, !tbaa !21
  br i1 %t888, label %bb255, label %bb256
bb255:
  %t889 = load ptr, ptr %l53, !tbaa !29
  %t891 = getelementptr { i64, [4 x i64] }, ptr %t889, i32 0, i32 1
  %t892 = getelementptr { i32, ptr, i32 }, ptr %t891, i32 0, i32 1
  %t893 = load ptr, ptr %t892
  store ptr %t893, ptr %l59, !tbaa !29
  br label %bb257
bb256:
  br label %bb259
bb257:
  %t895 = load ptr, ptr %l0, !tbaa !29
  %t896 = load ptr, ptr %l59, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t895, ptr %t896, i1 true)
  br label %bb258
bb258:
  br label %bb264
bb259:
  br i1 true, label %bb260, label %bb261
bb260:
  br label %bb262
bb261:
  br label %bb263
bb262:
  br label %bb264
bb263:
  call void @__olang_check_failed(ptr @olang_loc_80a42f326454c431_eaf1445ab36ad4e5)
  unreachable
bb264:
  br label %bb308
bb265:
  %t900 = load ptr, ptr %l1, !tbaa !29
  store ptr %t900, ptr %l477, !tbaa !29
  store i1 false, ptr %l478, !tbaa !21
  %t901 = load ptr, ptr %l477, !tbaa !29
  %t902 = icmp ne ptr %t901, null
  br i1 %t902, label %bb266, label %bb267
bb266:
  %t904 = load ptr, ptr %l477, !tbaa !29
  %t905 = load i64, ptr %t904, !range !{i64 0, i64 18}
  %t907 = icmp eq i64 %t905, 16
  store i1 %t907, ptr %l478, !tbaa !21
  br label %bb267
bb267:
  %t908 = load i1, ptr %l478, !tbaa !21
  br i1 %t908, label %bb268, label %bb269
bb268:
  %t909 = load ptr, ptr %l1, !tbaa !29
  %t911 = getelementptr { i64, [5 x i64] }, ptr %t909, i32 0, i32 1
  %t912 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t911, i32 0, i32 2
  %t913 = load ptr, ptr %t912
  store ptr %t913, ptr %l60, !tbaa !29
  br label %bb270
bb269:
  br label %bb296
bb270:
  %t915 = load ptr, ptr %l60, !tbaa !29
  %t917 = getelementptr %"compiler/typed:Text", ptr %t915, i32 0, i32 0
  %t918 = load { i64, ptr }, ptr %t917, !tbaa !27
  store { i64, ptr } %t918, ptr %l61, !tbaa !27
  store i64 0, ptr %l62, !tbaa !24
  %t920 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t922 = extractvalue { i64, ptr } %t920, 0
  store i64 %t922, ptr %l63, !tbaa !24
  br label %bb271
bb271:
  %t924 = load i64, ptr %l62, !tbaa !24
  %t925 = load i64, ptr %l63, !tbaa !24
  %t928 = icmp slt i64 %t924, %t925
  %t930 = xor i1 %t928, true
  br i1 %t930, label %bb272, label %bb273
bb272:
  br label %bb295
bb273:
  br label %bb274
bb274:
  %t932 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t932, ptr %l491, !tbaa !27
  %t933 = load i64, ptr %l62, !tbaa !24
  %t935 = getelementptr { i64, ptr }, ptr %l491, i32 0, i32 1
  %t936 = load ptr, ptr %t935, !tbaa !27
  %t937 = getelementptr ptr, ptr %t936, i64 %t933
  %t938 = load ptr, ptr %t937, !tbaa !39
  store ptr %t938, ptr %l64, !tbaa !29
  %t940 = load ptr, ptr %l64, !tbaa !29
  store ptr %t940, ptr %l494, !tbaa !29
  store i1 false, ptr %l495, !tbaa !21
  %t941 = load ptr, ptr %l494, !tbaa !29
  %t942 = icmp ne ptr %t941, null
  br i1 %t942, label %bb275, label %bb276
bb275:
  %t944 = load ptr, ptr %l494, !tbaa !29
  %t945 = load i64, ptr %t944, !range !{i64 0, i64 2}
  %t947 = icmp eq i64 %t945, 1
  store i1 %t947, ptr %l495, !tbaa !21
  br label %bb276
bb276:
  %t948 = load i1, ptr %l495, !tbaa !21
  br i1 %t948, label %bb277, label %bb278
bb277:
  %t949 = load ptr, ptr %l64, !tbaa !29
  %t951 = getelementptr { i64, [2 x i64] }, ptr %t949, i32 0, i32 1
  %t952 = getelementptr { ptr }, ptr %t951, i32 0, i32 0
  %t953 = load ptr, ptr %t952
  store ptr %t953, ptr %l65, !tbaa !29
  br label %bb279
bb278:
  br label %bb288
bb279:
  %t955 = load i1, ptr %l2, !tbaa !21
  br i1 %t955, label %bb280, label %bb281
bb280:
  store i1 true, ptr %l501, !tbaa !21
  br label %bb283
bb281:
  %t957 = load ptr, ptr %l0, !tbaa !29
  %t958 = load ptr, ptr %l65, !tbaa !29
  %t961 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleBorrow(ptr %v0, ptr %v1, ptr %t957, ptr %t958)
  store i1 %t961, ptr %l504
  br label %bb282
bb282:
  %t962 = load i1, ptr %l504, !tbaa !21
  %t963 = xor i1 %t962, true
  store i1 %t963, ptr %l501, !tbaa !21
  br label %bb283
bb283:
  %t965 = load i1, ptr %l501, !tbaa !21
  br i1 %t965, label %bb284, label %bb285
bb284:
  %t966 = load ptr, ptr %l0, !tbaa !29
  %t967 = load ptr, ptr %l65, !tbaa !29
  %t969 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t966, ptr %t967, i1 %t969)
  br label %bb286
bb285:
  br label %bb287
bb286:
  br label %bb287
bb287:
  br label %bb293
bb288:
  br i1 true, label %bb289, label %bb290
bb289:
  br label %bb291
bb290:
  br label %bb292
bb291:
  br label %bb293
bb292:
  call void @__olang_check_failed(ptr @olang_loc_fdb46d1d9262e41a_919c32215229332e)
  unreachable
bb293:
  br label %bb294
bb294:
  %t973 = load i64, ptr %l62, !tbaa !24
  %t975 = add i64 %t973, 1
  store i64 %t975, ptr %l62, !tbaa !24
  br label %bb271
bb295:
  br label %bb308
bb296:
  %t977 = load ptr, ptr %l1, !tbaa !29
  store ptr %t977, ptr %l512, !tbaa !29
  store i1 false, ptr %l513, !tbaa !21
  %t978 = load ptr, ptr %l512, !tbaa !29
  %t979 = icmp ne ptr %t978, null
  br i1 %t979, label %bb297, label %bb298
bb297:
  %t981 = load ptr, ptr %l512, !tbaa !29
  %t982 = load i64, ptr %t981, !range !{i64 0, i64 18}
  %t984 = icmp eq i64 %t982, 17
  store i1 %t984, ptr %l513, !tbaa !21
  br label %bb298
bb298:
  %t985 = load i1, ptr %l513, !tbaa !21
  br i1 %t985, label %bb299, label %bb300
bb299:
  %t986 = load ptr, ptr %l1, !tbaa !29
  %t988 = getelementptr { i64, [5 x i64] }, ptr %t986, i32 0, i32 1
  %t989 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t988, i32 0, i32 2
  %t990 = load ptr, ptr %t989
  store ptr %t990, ptr %l66, !tbaa !29
  br label %bb301
bb300:
  br label %bb303
bb301:
  %t992 = load ptr, ptr %l0, !tbaa !29
  %t993 = load ptr, ptr %l66, !tbaa !29
  %t995 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t992, ptr %t993, i1 %t995)
  br label %bb302
bb302:
  br label %bb308
bb303:
  br i1 true, label %bb304, label %bb305
bb304:
  br label %bb306
bb305:
  br label %bb307
bb306:
  %t999 = load ptr, ptr %l0, !tbaa !29
  %t1001 = getelementptr %"compiler/scope:Scoper", ptr %t999, i32 0, i32 113
  store i1 true, ptr %t1001, !tbaa !21
  br label %bb308
bb307:
  call void @__olang_check_failed(ptr @olang_loc_3a379002e95ffe1b_e75bb6252129afef)
  unreachable
bb308:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleStrictStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca ptr
  %l20 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l74 = alloca ptr
  %l75 = alloca i1
  %l87 = alloca ptr
  %l88 = alloca i1
  %l93 = alloca ptr
  %l94 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca i1
  %l120 = alloca ptr
  %l121 = alloca i1
  %l126 = alloca ptr
  %l127 = alloca i1
  %l135 = alloca ptr
  %l136 = alloca i1
  %l153 = alloca { i64, ptr }
  %l161 = alloca ptr
  %l162 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/scope:Scoper", ptr %t5, i32 0, i32 113
  %t8 = load i1, ptr %t7, !tbaa !21
  store i1 %t8, ptr %l20, !tbaa !21
  br label %bb3
bb3:
  %t10 = load i1, ptr %l20, !tbaa !21
  br i1 %t10, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t12 = load ptr, ptr %l23, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l23, !tbaa !29
  %t16 = load i64, ptr %t15, !range !{i64 0, i64 17}
  %t18 = icmp eq i64 %t16, 0
  store i1 %t18, ptr %l24, !tbaa !21
  br label %bb8
bb8:
  %t19 = load i1, ptr %l24, !tbaa !21
  br i1 %t19, label %bb9, label %bb10
bb9:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [3 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t22, i32 0, i32 2
  %t24 = load ptr, ptr %t23
  store ptr %t24, ptr %l2, !tbaa !29
  br label %bb19
bb10:
  %t26 = load ptr, ptr %l1, !tbaa !29
  store ptr %t26, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t27 = load ptr, ptr %l29, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb11, label %bb12
bb11:
  %t30 = load ptr, ptr %l29, !tbaa !29
  %t31 = load i64, ptr %t30, !range !{i64 0, i64 17}
  %t33 = icmp eq i64 %t31, 2
  store i1 %t33, ptr %l30, !tbaa !21
  br label %bb12
bb12:
  %t34 = load i1, ptr %l30, !tbaa !21
  br i1 %t34, label %bb13, label %bb14
bb13:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr { i64, [3 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { %"compiler/source:Span", ptr }, ptr %t37, i32 0, i32 1
  %t39 = load ptr, ptr %t38
  store ptr %t39, ptr %l2, !tbaa !29
  br label %bb19
bb14:
  %t41 = load ptr, ptr %l1, !tbaa !29
  store ptr %t41, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t42 = load ptr, ptr %l35, !tbaa !29
  %t43 = icmp ne ptr %t42, null
  br i1 %t43, label %bb15, label %bb16
bb15:
  %t45 = load ptr, ptr %l35, !tbaa !29
  %t46 = load i64, ptr %t45, !range !{i64 0, i64 17}
  %t48 = icmp eq i64 %t46, 15
  store i1 %t48, ptr %l36, !tbaa !21
  br label %bb16
bb16:
  %t49 = load i1, ptr %l36, !tbaa !21
  br i1 %t49, label %bb17, label %bb18
bb17:
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr { i64, [3 x i64] }, ptr %t50, i32 0, i32 1
  %t53 = getelementptr { %"compiler/source:Span", ptr }, ptr %t52, i32 0, i32 1
  %t54 = load ptr, ptr %t53
  store ptr %t54, ptr %l2, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t56, ptr %t57, i1 true)
  br label %bb20
bb20:
  br label %bb106
bb21:
  %t61 = load ptr, ptr %l1, !tbaa !29
  store ptr %t61, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t62 = load ptr, ptr %l44, !tbaa !29
  %t63 = icmp ne ptr %t62, null
  br i1 %t63, label %bb22, label %bb23
bb22:
  %t65 = load ptr, ptr %l44, !tbaa !29
  %t66 = load i64, ptr %t65, !range !{i64 0, i64 17}
  %t68 = icmp eq i64 %t66, 1
  store i1 %t68, ptr %l45, !tbaa !21
  br label %bb23
bb23:
  %t69 = load i1, ptr %l45, !tbaa !21
  br i1 %t69, label %bb24, label %bb25
bb24:
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr { i64, [3 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t72, i32 0, i32 1
  %t74 = load ptr, ptr %t73
  store ptr %t74, ptr %l3, !tbaa !29
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr { i64, [3 x i64] }, ptr %t76, i32 0, i32 1
  %t79 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t78, i32 0, i32 2
  %t80 = load ptr, ptr %t79
  store ptr %t80, ptr %l4, !tbaa !29
  br label %bb26
bb25:
  br label %bb29
bb26:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esolePlace(ptr %v0, ptr %v1, ptr %t82, ptr %t83, i1 true)
  br label %bb27
bb27:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t86, ptr %t87, i1 true)
  br label %bb28
bb28:
  br label %bb106
bb29:
  %t91 = load ptr, ptr %l1, !tbaa !29
  store ptr %t91, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t92 = load ptr, ptr %l57, !tbaa !29
  %t93 = icmp ne ptr %t92, null
  br i1 %t93, label %bb30, label %bb31
bb30:
  %t95 = load ptr, ptr %l57, !tbaa !29
  %t96 = load i64, ptr %t95, !range !{i64 0, i64 17}
  %t98 = icmp eq i64 %t96, 3
  store i1 %t98, ptr %l58, !tbaa !21
  br label %bb31
bb31:
  %t99 = load i1, ptr %l58, !tbaa !21
  br i1 %t99, label %bb32, label %bb33
bb32:
  %t100 = load ptr, ptr %l1, !tbaa !29
  %t102 = getelementptr { i64, [3 x i64] }, ptr %t100, i32 0, i32 1
  %t103 = getelementptr { %"compiler/source:Span", ptr }, ptr %t102, i32 0, i32 1
  %t104 = load ptr, ptr %t103
  store ptr %t104, ptr %l5, !tbaa !29
  br label %bb34
bb33:
  br label %bb38
bb34:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load ptr, ptr %l5, !tbaa !29
  %t109 = getelementptr %"compiler/typed:If", ptr %t107, i32 0, i32 0
  %t110 = load ptr, ptr %t109, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t106, ptr %t110, i1 true)
  br label %bb35
bb35:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load ptr, ptr %l5, !tbaa !29
  %t117 = getelementptr %"compiler/typed:If", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleStrictBlock(ptr %v0, ptr %v1, ptr %t114, ptr %t118)
  br label %bb36
bb36:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load ptr, ptr %l5, !tbaa !29
  %t125 = getelementptr %"compiler/typed:If", ptr %t123, i32 0, i32 2
  %t126 = load ptr, ptr %t125, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleStrictBlock(ptr %v0, ptr %v1, ptr %t122, ptr %t126)
  br label %bb37
bb37:
  br label %bb106
bb38:
  %t129 = load ptr, ptr %l1, !tbaa !29
  store ptr %t129, ptr %l74, !tbaa !29
  store i1 false, ptr %l75, !tbaa !21
  %t130 = load ptr, ptr %l74, !tbaa !29
  %t131 = icmp ne ptr %t130, null
  br i1 %t131, label %bb39, label %bb40
bb39:
  %t133 = load ptr, ptr %l74, !tbaa !29
  %t134 = load i64, ptr %t133, !range !{i64 0, i64 17}
  %t136 = icmp eq i64 %t134, 4
  store i1 %t136, ptr %l75, !tbaa !21
  br label %bb40
bb40:
  %t137 = load i1, ptr %l75, !tbaa !21
  br i1 %t137, label %bb41, label %bb42
bb41:
  %t138 = load ptr, ptr %l1, !tbaa !29
  %t140 = getelementptr { i64, [3 x i64] }, ptr %t138, i32 0, i32 1
  %t141 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t140, i32 0, i32 1
  %t142 = load ptr, ptr %t141
  store ptr %t142, ptr %l6, !tbaa !29
  %t144 = load ptr, ptr %l1, !tbaa !29
  %t146 = getelementptr { i64, [3 x i64] }, ptr %t144, i32 0, i32 1
  %t147 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t146, i32 0, i32 2
  %t148 = load ptr, ptr %t147
  store ptr %t148, ptr %l7, !tbaa !29
  br label %bb43
bb42:
  br label %bb46
bb43:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleStrictBlock(ptr %v0, ptr %v1, ptr %t150, ptr %t151)
  br label %bb44
bb44:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleStrictBlock(ptr %v0, ptr %v1, ptr %t155, ptr %t156)
  br label %bb45
bb45:
  br label %bb106
bb46:
  %t159 = load ptr, ptr %l1, !tbaa !29
  store ptr %t159, ptr %l87, !tbaa !29
  store i1 false, ptr %l88, !tbaa !21
  %t160 = load ptr, ptr %l87, !tbaa !29
  %t161 = icmp ne ptr %t160, null
  br i1 %t161, label %bb47, label %bb48
bb47:
  %t163 = load ptr, ptr %l87, !tbaa !29
  %t164 = load i64, ptr %t163, !range !{i64 0, i64 17}
  %t166 = icmp eq i64 %t164, 6
  store i1 %t166, ptr %l88, !tbaa !21
  br label %bb48
bb48:
  %t167 = load i1, ptr %l88, !tbaa !21
  br i1 %t167, label %bb49, label %bb50
bb49:
  %t168 = load ptr, ptr %l1, !tbaa !29
  %t170 = getelementptr { i64, [3 x i64] }, ptr %t168, i32 0, i32 1
  %t171 = getelementptr { %"compiler/source:Span", ptr }, ptr %t170, i32 0, i32 1
  %t172 = load ptr, ptr %t171
  store ptr %t172, ptr %l8, !tbaa !29
  br label %bb59
bb50:
  %t174 = load ptr, ptr %l1, !tbaa !29
  store ptr %t174, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t175 = load ptr, ptr %l93, !tbaa !29
  %t176 = icmp ne ptr %t175, null
  br i1 %t176, label %bb51, label %bb52
bb51:
  %t178 = load ptr, ptr %l93, !tbaa !29
  %t179 = load i64, ptr %t178, !range !{i64 0, i64 17}
  %t181 = icmp eq i64 %t179, 9
  store i1 %t181, ptr %l94, !tbaa !21
  br label %bb52
bb52:
  %t182 = load i1, ptr %l94, !tbaa !21
  br i1 %t182, label %bb53, label %bb54
bb53:
  %t183 = load ptr, ptr %l1, !tbaa !29
  %t185 = getelementptr { i64, [3 x i64] }, ptr %t183, i32 0, i32 1
  %t186 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t185, i32 0, i32 2
  %t187 = load ptr, ptr %t186
  store ptr %t187, ptr %l8, !tbaa !29
  br label %bb59
bb54:
  %t189 = load ptr, ptr %l1, !tbaa !29
  store ptr %t189, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t190 = load ptr, ptr %l99, !tbaa !29
  %t191 = icmp ne ptr %t190, null
  br i1 %t191, label %bb55, label %bb56
bb55:
  %t193 = load ptr, ptr %l99, !tbaa !29
  %t194 = load i64, ptr %t193, !range !{i64 0, i64 17}
  %t196 = icmp eq i64 %t194, 16
  store i1 %t196, ptr %l100, !tbaa !21
  br label %bb56
bb56:
  %t197 = load i1, ptr %l100, !tbaa !21
  br i1 %t197, label %bb57, label %bb58
bb57:
  %t198 = load ptr, ptr %l1, !tbaa !29
  %t200 = getelementptr { i64, [3 x i64] }, ptr %t198, i32 0, i32 1
  %t201 = getelementptr { %"compiler/source:Span", ptr }, ptr %t200, i32 0, i32 1
  %t202 = load ptr, ptr %t201
  store ptr %t202, ptr %l8, !tbaa !29
  br label %bb59
bb58:
  br label %bb61
bb59:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t204, ptr %t205, i1 true)
  br label %bb60
bb60:
  br label %bb106
bb61:
  %t208 = load ptr, ptr %l1, !tbaa !29
  store ptr %t208, ptr %l107, !tbaa !29
  store i1 false, ptr %l108, !tbaa !21
  %t209 = load ptr, ptr %l107, !tbaa !29
  %t210 = icmp ne ptr %t209, null
  br i1 %t210, label %bb62, label %bb63
bb62:
  %t212 = load ptr, ptr %l107, !tbaa !29
  %t213 = load i64, ptr %t212, !range !{i64 0, i64 17}
  %t215 = icmp eq i64 %t213, 10
  store i1 %t215, ptr %l108, !tbaa !21
  br label %bb63
bb63:
  %t216 = load i1, ptr %l108, !tbaa !21
  br i1 %t216, label %bb64, label %bb65
bb64:
  %t217 = load ptr, ptr %l1, !tbaa !29
  %t219 = getelementptr { i64, [3 x i64] }, ptr %t217, i32 0, i32 1
  %t220 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t219, i32 0, i32 1
  %t221 = load ptr, ptr %t220
  store ptr %t221, ptr %l9, !tbaa !29
  %t223 = load ptr, ptr %l1, !tbaa !29
  %t225 = getelementptr { i64, [3 x i64] }, ptr %t223, i32 0, i32 1
  %t226 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t225, i32 0, i32 2
  %t227 = load ptr, ptr %t226
  store ptr %t227, ptr %l10, !tbaa !29
  br label %bb66
bb65:
  br label %bb69
bb66:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t230 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t229, ptr %t230, i1 true)
  br label %bb67
bb67:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t234, ptr %t235, i1 true)
  br label %bb68
bb68:
  br label %bb106
bb69:
  %t238 = load ptr, ptr %l1, !tbaa !29
  store ptr %t238, ptr %l120, !tbaa !29
  store i1 false, ptr %l121, !tbaa !21
  %t239 = load ptr, ptr %l120, !tbaa !29
  %t240 = icmp ne ptr %t239, null
  br i1 %t240, label %bb70, label %bb71
bb70:
  %t242 = load ptr, ptr %l120, !tbaa !29
  %t243 = load i64, ptr %t242, !range !{i64 0, i64 17}
  %t245 = icmp eq i64 %t243, 11
  store i1 %t245, ptr %l121, !tbaa !21
  br label %bb71
bb71:
  %t246 = load i1, ptr %l121, !tbaa !21
  br i1 %t246, label %bb72, label %bb73
bb72:
  %t247 = load ptr, ptr %l1, !tbaa !29
  %t249 = getelementptr { i64, [3 x i64] }, ptr %t247, i32 0, i32 1
  %t250 = getelementptr { %"compiler/source:Span", ptr }, ptr %t249, i32 0, i32 1
  %t251 = load ptr, ptr %t250
  store ptr %t251, ptr %l11, !tbaa !29
  br label %bb78
bb73:
  %t253 = load ptr, ptr %l1, !tbaa !29
  store ptr %t253, ptr %l126, !tbaa !29
  store i1 false, ptr %l127, !tbaa !21
  %t254 = load ptr, ptr %l126, !tbaa !29
  %t255 = icmp ne ptr %t254, null
  br i1 %t255, label %bb74, label %bb75
bb74:
  %t257 = load ptr, ptr %l126, !tbaa !29
  %t258 = load i64, ptr %t257, !range !{i64 0, i64 17}
  %t260 = icmp eq i64 %t258, 12
  store i1 %t260, ptr %l127, !tbaa !21
  br label %bb75
bb75:
  %t261 = load i1, ptr %l127, !tbaa !21
  br i1 %t261, label %bb76, label %bb77
bb76:
  %t262 = load ptr, ptr %l1, !tbaa !29
  %t264 = getelementptr { i64, [3 x i64] }, ptr %t262, i32 0, i32 1
  %t265 = getelementptr { %"compiler/source:Span", ptr }, ptr %t264, i32 0, i32 1
  %t266 = load ptr, ptr %t265
  store ptr %t266, ptr %l11, !tbaa !29
  br label %bb78
bb77:
  br label %bb80
bb78:
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleStrictBlock(ptr %v0, ptr %v1, ptr %t268, ptr %t269)
  br label %bb79
bb79:
  br label %bb106
bb80:
  %t273 = load ptr, ptr %l1, !tbaa !29
  store ptr %t273, ptr %l135, !tbaa !29
  store i1 false, ptr %l136, !tbaa !21
  %t274 = load ptr, ptr %l135, !tbaa !29
  %t275 = icmp ne ptr %t274, null
  br i1 %t275, label %bb81, label %bb82
bb81:
  %t277 = load ptr, ptr %l135, !tbaa !29
  %t278 = load i64, ptr %t277, !range !{i64 0, i64 17}
  %t280 = icmp eq i64 %t278, 13
  store i1 %t280, ptr %l136, !tbaa !21
  br label %bb82
bb82:
  %t281 = load i1, ptr %l136, !tbaa !21
  br i1 %t281, label %bb83, label %bb84
bb83:
  %t282 = load ptr, ptr %l1, !tbaa !29
  %t284 = getelementptr { i64, [3 x i64] }, ptr %t282, i32 0, i32 1
  %t285 = getelementptr { %"compiler/source:Span", ptr }, ptr %t284, i32 0, i32 1
  %t286 = load ptr, ptr %t285
  store ptr %t286, ptr %l12, !tbaa !29
  br label %bb85
bb84:
  br label %bb94
bb85:
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t289 = load ptr, ptr %l12, !tbaa !29
  %t291 = getelementptr %"compiler/typed:Join", ptr %t289, i32 0, i32 0
  %t292 = load ptr, ptr %t291, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleStrictBlock(ptr %v0, ptr %v1, ptr %t288, ptr %t292)
  br label %bb86
bb86:
  %t296 = load ptr, ptr %l12, !tbaa !29
  %t298 = getelementptr %"compiler/typed:Join", ptr %t296, i32 0, i32 2
  %t299 = load { i64, ptr }, ptr %t298, !tbaa !27
  store { i64, ptr } %t299, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t301 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t303 = extractvalue { i64, ptr } %t301, 0
  store i64 %t303, ptr %l15, !tbaa !24
  br label %bb87
bb87:
  %t305 = load i64, ptr %l14, !tbaa !24
  %t306 = load i64, ptr %l15, !tbaa !24
  %t309 = icmp slt i64 %t305, %t306
  %t311 = xor i1 %t309, true
  br i1 %t311, label %bb88, label %bb89
bb88:
  br label %bb93
bb89:
  br label %bb90
bb90:
  %t313 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t313, ptr %l153, !tbaa !27
  %t314 = load i64, ptr %l14, !tbaa !24
  %t316 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t317 = load ptr, ptr %t316, !tbaa !27
  %t318 = getelementptr ptr, ptr %t317, i64 %t314
  %t319 = load ptr, ptr %t318, !tbaa !39
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t324 = getelementptr %"compiler/typed:Clause", ptr %t319, i32 0, i32 3
  %t325 = load ptr, ptr %t324, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleStrictBlock(ptr %v0, ptr %v1, ptr %t321, ptr %t325)
  br label %bb91
bb91:
  br label %bb92
bb92:
  %t328 = load i64, ptr %l14, !tbaa !24
  %t330 = add i64 %t328, 1
  store i64 %t330, ptr %l14, !tbaa !24
  br label %bb87
bb93:
  br label %bb106
bb94:
  %t332 = load ptr, ptr %l1, !tbaa !29
  store ptr %t332, ptr %l161, !tbaa !29
  store i1 false, ptr %l162, !tbaa !21
  %t333 = load ptr, ptr %l161, !tbaa !29
  %t334 = icmp ne ptr %t333, null
  br i1 %t334, label %bb95, label %bb96
bb95:
  %t336 = load ptr, ptr %l161, !tbaa !29
  %t337 = load i64, ptr %t336, !range !{i64 0, i64 17}
  %t339 = icmp eq i64 %t337, 14
  store i1 %t339, ptr %l162, !tbaa !21
  br label %bb96
bb96:
  %t340 = load i1, ptr %l162, !tbaa !21
  br i1 %t340, label %bb97, label %bb98
bb97:
  %t341 = load ptr, ptr %l1, !tbaa !29
  %t343 = getelementptr { i64, [3 x i64] }, ptr %t341, i32 0, i32 1
  %t344 = getelementptr { %"compiler/source:Span", ptr }, ptr %t343, i32 0, i32 1
  %t345 = load ptr, ptr %t344
  store ptr %t345, ptr %l17, !tbaa !29
  br label %bb99
bb98:
  br label %bb101
bb99:
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t348 = load ptr, ptr %l17, !tbaa !29
  %t350 = getelementptr %"compiler/typed:Spawn", ptr %t348, i32 0, i32 1
  %t351 = load ptr, ptr %t350, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t347, ptr %t351, i1 true)
  br label %bb100
bb100:
  br label %bb106
bb101:
  br i1 true, label %bb102, label %bb103
bb102:
  br label %bb104
bb103:
  br label %bb105
bb104:
  br label %bb106
bb105:
  call void @__olang_check_failed(ptr @olang_loc_ae81d4d244f6a670_8f3729da339b0a94)
  unreachable
bb106:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esplitRefs(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l12 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i1
  %l17 = alloca i1
  %l19 = alloca i1
  %l23 = alloca { i64, [2 x i64] }
  %l24 = alloca ptr
  %l25 = alloca i1
  %l33 = alloca i1
  %l34 = alloca i1
  %l39 = alloca { i64, ptr }
  %l41 = alloca { i64, [2 x i64] }
  %l42 = alloca ptr
  %l43 = alloca i1
  %l50 = alloca { i64, [2 x i64] }
  %rv = alloca { i64, [2 x i64] }
  %t31 = alloca { i64, [2 x i64] }, align 8
  %t104 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l12, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t17)
  store i32 %t19, ptr %l14
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t21 = load i32, ptr %l14, !tbaa !23
  %t22 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t20, i32 %t21)
  store i1 %t22, ptr %l15
  br label %bb7
bb7:
  %t23 = load i1, ptr %l15, !tbaa !21
  %t24 = xor i1 %t23, true
  br i1 %t24, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb11
bb9:
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = call i1 @compiler_2fscope_2eflThroughRef(ptr %v1, ptr %t26)
  store i1 %t28, ptr %l19
  br label %bb10
bb10:
  %t29 = load i1, ptr %l19, !tbaa !21
  store i1 %t29, ptr %l17, !tbaa !21
  br label %bb11
bb11:
  %t30 = load i1, ptr %l17, !tbaa !21
  br i1 %t30, label %bb12, label %bb13
bb12:
  store { i64, [2 x i64] } zeroinitializer, ptr %t31
  %t32 = getelementptr { i64, [2 x i64] }, ptr %t31, i32 0, i32 0
  store i64 0, ptr %t32
  %t33 = load { i64, [2 x i64] }, ptr %t31
  store { i64, [2 x i64] } %t33, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t39 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekPlace(ptr %v0, ptr %v1, ptr %t35, ptr %t36, i1 true)
  store { i64, [2 x i64] } %t39, ptr %l23
  br label %bb15
bb15:
  %t40 = load { i64, [2 x i64] }, ptr %l23
  store { i64, [2 x i64] } %t40, ptr %rv
  br label %ret
bb16:
  %t41 = load ptr, ptr %l1, !tbaa !29
  store ptr %t41, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t42 = load ptr, ptr %l24, !tbaa !29
  %t43 = icmp ne ptr %t42, null
  br i1 %t43, label %bb17, label %bb18
bb17:
  %t45 = load ptr, ptr %l24, !tbaa !29
  %t46 = load i64, ptr %t45, !range !{i64 0, i64 18}
  %t48 = icmp eq i64 %t46, 9
  store i1 %t48, ptr %l25, !tbaa !21
  br label %bb18
bb18:
  %t49 = load i1, ptr %l25, !tbaa !21
  br i1 %t49, label %bb19, label %bb20
bb19:
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr { i64, [5 x i64] }, ptr %t50, i32 0, i32 1
  %t53 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t52, i32 0, i32 2
  %t54 = load i32, ptr %t53, !range !{i32 0, i32 43}
  store i32 %t54, ptr %l3
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t58 = getelementptr { i64, [5 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t58, i32 0, i32 4
  %t60 = load { i64, ptr }, ptr %t59
  store { i64, ptr } %t60, ptr %l4, !tbaa !27
  br label %bb21
bb20:
  br label %bb30
bb21:
  %t62 = load i32, ptr %l3, !range !{i32 0, i32 43}
  %t64 = call i1 @compiler_2ftyped_2ePassesRefs(i32 %t62)
  store i1 %t64, ptr %l33
  br label %bb22
bb22:
  %t65 = load i1, ptr %l33, !tbaa !21
  br i1 %t65, label %bb23, label %bb24
bb23:
  %t66 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t66, 0
  %t70 = icmp sgt i64 %t68, 0
  store i1 %t70, ptr %l34, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb25
bb25:
  %t72 = load i1, ptr %l34, !tbaa !21
  br i1 %t72, label %bb26, label %bb27
bb26:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t74, ptr %l39, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr ptr, ptr %t76, i64 0
  %t78 = load ptr, ptr %t77, !tbaa !39
  %t81 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esplitRefs(ptr %v0, ptr %v1, ptr %t73, ptr %t78)
  store { i64, [2 x i64] } %t81, ptr %l41
  br label %bb28
bb27:
  br label %bb29
bb28:
  %t82 = load { i64, [2 x i64] }, ptr %l41
  store { i64, [2 x i64] } %t82, ptr %rv
  br label %ret
bb29:
  br label %bb42
bb30:
  %t83 = load ptr, ptr %l1, !tbaa !29
  store ptr %t83, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t84 = load ptr, ptr %l42, !tbaa !29
  %t85 = icmp ne ptr %t84, null
  br i1 %t85, label %bb31, label %bb32
bb31:
  %t87 = load ptr, ptr %l42, !tbaa !29
  %t88 = load i64, ptr %t87, !range !{i64 0, i64 18}
  %t90 = icmp eq i64 %t88, 17
  store i1 %t90, ptr %l43, !tbaa !21
  br label %bb32
bb32:
  %t91 = load i1, ptr %l43, !tbaa !21
  br i1 %t91, label %bb33, label %bb34
bb33:
  %t92 = load ptr, ptr %l1, !tbaa !29
  %t94 = getelementptr { i64, [5 x i64] }, ptr %t92, i32 0, i32 1
  %t95 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t94, i32 0, i32 2
  %t96 = load ptr, ptr %t95
  store ptr %t96, ptr %l5, !tbaa !29
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load ptr, ptr %l5, !tbaa !29
  %t102 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esplitRefs(ptr %v0, ptr %v1, ptr %t98, ptr %t99)
  store { i64, [2 x i64] } %t102, ptr %l50
  br label %bb36
bb36:
  %t103 = load { i64, [2 x i64] }, ptr %l50
  store { i64, [2 x i64] } %t103, ptr %rv
  br label %ret
bb37:
  br i1 true, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_9da86a51b48ec4c_4c8b634b3e5eba18)
  unreachable
bb42:
  store { i64, [2 x i64] } zeroinitializer, ptr %t104
  %t105 = getelementptr { i64, [2 x i64] }, ptr %t104, i32 0, i32 0
  store i64 0, ptr %t105
  %t106 = load { i64, [2 x i64] }, ptr %t104
  store { i64, [2 x i64] } %t106, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l26 = alloca %"compiler/source:Span"
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l33 = alloca ptr
  %l35 = alloca %"compiler/source:Span"
  %l36 = alloca ptr
  %l37 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i1
  %l75 = alloca %"compiler/scope:Val"
  %l76 = alloca ptr
  %l77 = alloca i1
  %l87 = alloca %"compiler/scope:Val"
  %l95 = alloca ptr
  %l96 = alloca i1
  %l108 = alloca ptr
  %l109 = alloca i1
  %l112 = alloca ptr
  %l113 = alloca i1
  %l120 = alloca ptr
  %l121 = alloca i1
  %l131 = alloca ptr
  %l132 = alloca i1
  %l135 = alloca ptr
  %l136 = alloca i1
  %l145 = alloca %"compiler/scope:Val"
  %l146 = alloca ptr
  %l147 = alloca i1
  %l155 = alloca %"compiler/scope:Val"
  %l156 = alloca ptr
  %l157 = alloca i1
  %l168 = alloca %"compiler/scope:Val"
  %l172 = alloca %"compiler/scope:Val"
  %l173 = alloca ptr
  %l174 = alloca i1
  %l181 = alloca i1
  %l183 = alloca ptr
  %l186 = alloca i64
  %l187 = alloca ptr
  %l189 = alloca ptr
  %l192 = alloca i64
  %l194 = alloca i32
  %l195 = alloca i32
  %l200 = alloca ptr
  %l201 = alloca i1
  %l209 = alloca ptr
  %l210 = alloca i1
  %l224 = alloca i32
  %l227 = alloca i32
  %l228 = alloca i32
  %l237 = alloca { i64, ptr }
  %l245 = alloca ptr
  %l246 = alloca i1
  %l256 = alloca ptr
  %l257 = alloca i1
  %l262 = alloca ptr
  %l264 = alloca ptr
  %l266 = alloca { i64, [2 x i64] }
  %l267 = alloca %"compiler/scope:Val"
  %t106 = alloca { i64, [2 x i64] }, align 8
  %t134 = alloca { i64, [2 x i64] }, align 8
  %t270 = alloca { i64, [2 x i64] }, align 8
  %t294 = alloca { i64, [2 x i64] }, align 8
  %t325 = alloca { i64, [2 x i64] }, align 8
  %t334 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/scope:Scoper", ptr %t5, i32 0, i32 38
  %t8 = load %"compiler/source:Span", ptr %t7
  store %"compiler/source:Span" %t8, ptr %l2
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l33, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aStmt_2eSpan(ptr %v1, ptr %t11)
  store %"compiler/source:Span" %t13, ptr %l35
  br label %bb4
bb4:
  %t14 = load %"compiler/source:Span", ptr %l35
  %t15 = load ptr, ptr %l33, !tbaa !29
  %t16 = getelementptr %"compiler/scope:Scoper", ptr %t15, i32 0, i32 38
  store %"compiler/source:Span" %t14, ptr %t16
  %t17 = load ptr, ptr %l1, !tbaa !29
  store ptr %t17, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t18 = load ptr, ptr %l36, !tbaa !29
  %t19 = icmp ne ptr %t18, null
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t21 = load ptr, ptr %l36, !tbaa !29
  %t22 = load i64, ptr %t21, !range !{i64 0, i64 17}
  %t24 = icmp eq i64 %t22, 0
  store i1 %t24, ptr %l37, !tbaa !21
  br label %bb6
bb6:
  %t25 = load i1, ptr %l37, !tbaa !21
  br i1 %t25, label %bb7, label %bb8
bb7:
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr { i64, [3 x i64] }, ptr %t26, i32 0, i32 1
  %t29 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t28, i32 0, i32 0
  %t30 = load %"compiler/source:Span", ptr %t29
  store %"compiler/source:Span" %t30, ptr %l3
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr { i64, [3 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t34, i32 0, i32 1
  %t36 = load i32, ptr %t35
  store i32 %t36, ptr %l4, !tbaa !23
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr { i64, [3 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l5, !tbaa !29
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load %"compiler/source:Span", ptr %l3
  %t46 = load i32, ptr %l4, !tbaa !23
  %t47 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elet(ptr %v0, ptr %v1, ptr %t44, %"compiler/source:Span" %t45, i32 %t46, ptr %t47)
  br label %bb10
bb10:
  br label %bb144
bb11:
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t54 = load ptr, ptr %l51, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb12, label %bb13
bb12:
  %t57 = load ptr, ptr %l51, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 17}
  %t60 = icmp eq i64 %t58, 1
  store i1 %t60, ptr %l52, !tbaa !21
  br label %bb13
bb13:
  %t61 = load i1, ptr %l52, !tbaa !21
  br i1 %t61, label %bb14, label %bb15
bb14:
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr { i64, [3 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t64, i32 0, i32 0
  %t66 = load %"compiler/source:Span", ptr %t65
  store %"compiler/source:Span" %t66, ptr %l6
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [3 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t70, i32 0, i32 1
  %t72 = load ptr, ptr %t71
  store ptr %t72, ptr %l7, !tbaa !29
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [3 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t76, i32 0, i32 2
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l8, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load %"compiler/source:Span", ptr %l6
  %t82 = load ptr, ptr %l7, !tbaa !29
  %t83 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eassign(ptr %v0, ptr %v1, ptr %v1, ptr %t80, %"compiler/source:Span" %t81, ptr %t82, ptr %t83)
  br label %bb17
bb17:
  br label %bb144
bb18:
  %t88 = load ptr, ptr %l1, !tbaa !29
  store ptr %t88, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t89 = load ptr, ptr %l65, !tbaa !29
  %t90 = icmp ne ptr %t89, null
  br i1 %t90, label %bb19, label %bb20
bb19:
  %t92 = load ptr, ptr %l65, !tbaa !29
  %t93 = load i64, ptr %t92, !range !{i64 0, i64 17}
  %t95 = icmp eq i64 %t93, 2
  store i1 %t95, ptr %l66, !tbaa !21
  br label %bb20
bb20:
  %t96 = load i1, ptr %l66, !tbaa !21
  br i1 %t96, label %bb21, label %bb22
bb21:
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr { i64, [3 x i64] }, ptr %t97, i32 0, i32 1
  %t100 = getelementptr { %"compiler/source:Span", ptr }, ptr %t99, i32 0, i32 1
  %t101 = load ptr, ptr %t100
  store ptr %t101, ptr %l9, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load ptr, ptr %l9, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t106
  %t107 = getelementptr { i64, [2 x i64] }, ptr %t106, i32 0, i32 0
  store i64 0, ptr %t107
  %t108 = load { i64, [2 x i64] }, ptr %t106
  %t112 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t103, ptr %t104, { i64, [2 x i64] } %t108)
  store %"compiler/scope:Val" %t112, ptr %l75
  br label %bb24
bb24:
  br label %bb144
bb25:
  %t113 = load ptr, ptr %l1, !tbaa !29
  store ptr %t113, ptr %l76, !tbaa !29
  store i1 false, ptr %l77, !tbaa !21
  %t114 = load ptr, ptr %l76, !tbaa !29
  %t115 = icmp ne ptr %t114, null
  br i1 %t115, label %bb26, label %bb27
bb26:
  %t117 = load ptr, ptr %l76, !tbaa !29
  %t118 = load i64, ptr %t117, !range !{i64 0, i64 17}
  %t120 = icmp eq i64 %t118, 3
  store i1 %t120, ptr %l77, !tbaa !21
  br label %bb27
bb27:
  %t121 = load i1, ptr %l77, !tbaa !21
  br i1 %t121, label %bb28, label %bb29
bb28:
  %t122 = load ptr, ptr %l1, !tbaa !29
  %t124 = getelementptr { i64, [3 x i64] }, ptr %t122, i32 0, i32 1
  %t125 = getelementptr { %"compiler/source:Span", ptr }, ptr %t124, i32 0, i32 1
  %t126 = load ptr, ptr %t125
  store ptr %t126, ptr %l10, !tbaa !29
  br label %bb30
bb29:
  br label %bb34
bb30:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load ptr, ptr %l10, !tbaa !29
  %t131 = getelementptr %"compiler/typed:If", ptr %t129, i32 0, i32 0
  %t132 = load ptr, ptr %t131, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t134
  %t135 = getelementptr { i64, [2 x i64] }, ptr %t134, i32 0, i32 0
  store i64 0, ptr %t135
  %t136 = load { i64, [2 x i64] }, ptr %t134
  %t140 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t128, ptr %t132, { i64, [2 x i64] } %t136)
  store %"compiler/scope:Val" %t140, ptr %l87
  br label %bb31
bb31:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load ptr, ptr %l10, !tbaa !29
  %t144 = getelementptr %"compiler/typed:If", ptr %t142, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblock(ptr %v0, ptr %v1, ptr %t141, ptr %t145)
  br label %bb32
bb32:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load ptr, ptr %l10, !tbaa !29
  %t152 = getelementptr %"compiler/typed:If", ptr %t150, i32 0, i32 2
  %t153 = load ptr, ptr %t152, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblock(ptr %v0, ptr %v1, ptr %t149, ptr %t153)
  br label %bb33
bb33:
  br label %bb144
bb34:
  %t156 = load ptr, ptr %l1, !tbaa !29
  store ptr %t156, ptr %l95, !tbaa !29
  store i1 false, ptr %l96, !tbaa !21
  %t157 = load ptr, ptr %l95, !tbaa !29
  %t158 = icmp ne ptr %t157, null
  br i1 %t158, label %bb35, label %bb36
bb35:
  %t160 = load ptr, ptr %l95, !tbaa !29
  %t161 = load i64, ptr %t160, !range !{i64 0, i64 17}
  %t163 = icmp eq i64 %t161, 4
  store i1 %t163, ptr %l96, !tbaa !21
  br label %bb36
bb36:
  %t164 = load i1, ptr %l96, !tbaa !21
  br i1 %t164, label %bb37, label %bb38
bb37:
  %t165 = load ptr, ptr %l1, !tbaa !29
  %t167 = getelementptr { i64, [3 x i64] }, ptr %t165, i32 0, i32 1
  %t168 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t167, i32 0, i32 1
  %t169 = load ptr, ptr %t168
  store ptr %t169, ptr %l11, !tbaa !29
  %t171 = load ptr, ptr %l1, !tbaa !29
  %t173 = getelementptr { i64, [3 x i64] }, ptr %t171, i32 0, i32 1
  %t174 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t173, i32 0, i32 2
  %t175 = load ptr, ptr %t174
  store ptr %t175, ptr %l12, !tbaa !29
  br label %bb39
bb38:
  br label %bb42
bb39:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblock(ptr %v0, ptr %v1, ptr %t177, ptr %t178)
  br label %bb40
bb40:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblock(ptr %v0, ptr %v1, ptr %t182, ptr %t183)
  br label %bb41
bb41:
  br label %bb144
bb42:
  %t186 = load ptr, ptr %l1, !tbaa !29
  store ptr %t186, ptr %l108, !tbaa !29
  store i1 false, ptr %l109, !tbaa !21
  %t187 = load ptr, ptr %l108, !tbaa !29
  %t188 = icmp ne ptr %t187, null
  br i1 %t188, label %bb43, label %bb44
bb43:
  %t190 = load ptr, ptr %l108, !tbaa !29
  %t191 = load i64, ptr %t190, !range !{i64 0, i64 17}
  %t193 = icmp eq i64 %t191, 5
  store i1 %t193, ptr %l109, !tbaa !21
  br label %bb44
bb44:
  %t194 = load i1, ptr %l109, !tbaa !21
  br i1 %t194, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb144
bb48:
  %t195 = load ptr, ptr %l1, !tbaa !29
  store ptr %t195, ptr %l112, !tbaa !29
  store i1 false, ptr %l113, !tbaa !21
  %t196 = load ptr, ptr %l112, !tbaa !29
  %t197 = icmp ne ptr %t196, null
  br i1 %t197, label %bb49, label %bb50
bb49:
  %t199 = load ptr, ptr %l112, !tbaa !29
  %t200 = load i64, ptr %t199, !range !{i64 0, i64 17}
  %t202 = icmp eq i64 %t200, 6
  store i1 %t202, ptr %l113, !tbaa !21
  br label %bb50
bb50:
  %t203 = load i1, ptr %l113, !tbaa !21
  br i1 %t203, label %bb51, label %bb52
bb51:
  %t204 = load ptr, ptr %l1, !tbaa !29
  %t206 = getelementptr { i64, [3 x i64] }, ptr %t204, i32 0, i32 1
  %t207 = getelementptr { %"compiler/source:Span", ptr }, ptr %t206, i32 0, i32 0
  %t208 = load %"compiler/source:Span", ptr %t207
  store %"compiler/source:Span" %t208, ptr %l13
  %t210 = load ptr, ptr %l1, !tbaa !29
  %t212 = getelementptr { i64, [3 x i64] }, ptr %t210, i32 0, i32 1
  %t213 = getelementptr { %"compiler/source:Span", ptr }, ptr %t212, i32 0, i32 1
  %t214 = load ptr, ptr %t213
  store ptr %t214, ptr %l14, !tbaa !29
  br label %bb57
bb52:
  %t216 = load ptr, ptr %l1, !tbaa !29
  store ptr %t216, ptr %l120, !tbaa !29
  store i1 false, ptr %l121, !tbaa !21
  %t217 = load ptr, ptr %l120, !tbaa !29
  %t218 = icmp ne ptr %t217, null
  br i1 %t218, label %bb53, label %bb54
bb53:
  %t220 = load ptr, ptr %l120, !tbaa !29
  %t221 = load i64, ptr %t220, !range !{i64 0, i64 17}
  %t223 = icmp eq i64 %t221, 16
  store i1 %t223, ptr %l121, !tbaa !21
  br label %bb54
bb54:
  %t224 = load i1, ptr %l121, !tbaa !21
  br i1 %t224, label %bb55, label %bb56
bb55:
  %t225 = load ptr, ptr %l1, !tbaa !29
  %t227 = getelementptr { i64, [3 x i64] }, ptr %t225, i32 0, i32 1
  %t228 = getelementptr { %"compiler/source:Span", ptr }, ptr %t227, i32 0, i32 0
  %t229 = load %"compiler/source:Span", ptr %t228
  store %"compiler/source:Span" %t229, ptr %l13
  %t231 = load ptr, ptr %l1, !tbaa !29
  %t233 = getelementptr { i64, [3 x i64] }, ptr %t231, i32 0, i32 1
  %t234 = getelementptr { %"compiler/source:Span", ptr }, ptr %t233, i32 0, i32 1
  %t235 = load ptr, ptr %t234
  store ptr %t235, ptr %l14, !tbaa !29
  br label %bb57
bb56:
  br label %bb59
bb57:
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t238 = load %"compiler/source:Span", ptr %l13
  %t239 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eret(ptr %v0, ptr %v1, ptr %t237, %"compiler/source:Span" %t238, ptr %t239)
  br label %bb58
bb58:
  br label %bb144
bb59:
  %t243 = load ptr, ptr %l1, !tbaa !29
  store ptr %t243, ptr %l131, !tbaa !29
  store i1 false, ptr %l132, !tbaa !21
  %t244 = load ptr, ptr %l131, !tbaa !29
  %t245 = icmp ne ptr %t244, null
  br i1 %t245, label %bb60, label %bb61
bb60:
  %t247 = load ptr, ptr %l131, !tbaa !29
  %t248 = load i64, ptr %t247, !range !{i64 0, i64 17}
  %t250 = icmp eq i64 %t248, 7
  store i1 %t250, ptr %l132, !tbaa !21
  br label %bb61
bb61:
  %t251 = load i1, ptr %l132, !tbaa !21
  br i1 %t251, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb144
bb65:
  %t252 = load ptr, ptr %l1, !tbaa !29
  store ptr %t252, ptr %l135, !tbaa !29
  store i1 false, ptr %l136, !tbaa !21
  %t253 = load ptr, ptr %l135, !tbaa !29
  %t254 = icmp ne ptr %t253, null
  br i1 %t254, label %bb66, label %bb67
bb66:
  %t256 = load ptr, ptr %l135, !tbaa !29
  %t257 = load i64, ptr %t256, !range !{i64 0, i64 17}
  %t259 = icmp eq i64 %t257, 8
  store i1 %t259, ptr %l136, !tbaa !21
  br label %bb67
bb67:
  %t260 = load i1, ptr %l136, !tbaa !21
  br i1 %t260, label %bb68, label %bb69
bb68:
  %t261 = load ptr, ptr %l1, !tbaa !29
  %t263 = getelementptr { i64, [3 x i64] }, ptr %t261, i32 0, i32 1
  %t264 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t263, i32 0, i32 1
  %t265 = load ptr, ptr %t264
  store ptr %t265, ptr %l15, !tbaa !29
  br label %bb70
bb69:
  br label %bb72
bb70:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t268 = load ptr, ptr %l15, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t270
  %t271 = getelementptr { i64, [2 x i64] }, ptr %t270, i32 0, i32 0
  store i64 0, ptr %t271
  %t272 = load { i64, [2 x i64] }, ptr %t270
  %t276 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t267, ptr %t268, { i64, [2 x i64] } %t272)
  store %"compiler/scope:Val" %t276, ptr %l145
  br label %bb71
bb71:
  br label %bb144
bb72:
  %t277 = load ptr, ptr %l1, !tbaa !29
  store ptr %t277, ptr %l146, !tbaa !29
  store i1 false, ptr %l147, !tbaa !21
  %t278 = load ptr, ptr %l146, !tbaa !29
  %t279 = icmp ne ptr %t278, null
  br i1 %t279, label %bb73, label %bb74
bb73:
  %t281 = load ptr, ptr %l146, !tbaa !29
  %t282 = load i64, ptr %t281, !range !{i64 0, i64 17}
  %t284 = icmp eq i64 %t282, 9
  store i1 %t284, ptr %l147, !tbaa !21
  br label %bb74
bb74:
  %t285 = load i1, ptr %l147, !tbaa !21
  br i1 %t285, label %bb75, label %bb76
bb75:
  %t286 = load ptr, ptr %l1, !tbaa !29
  %t288 = getelementptr { i64, [3 x i64] }, ptr %t286, i32 0, i32 1
  %t289 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t288, i32 0, i32 2
  %t290 = load ptr, ptr %t289
  store ptr %t290, ptr %l16, !tbaa !29
  br label %bb77
bb76:
  br label %bb79
bb77:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t293 = load ptr, ptr %l16, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t294
  %t295 = getelementptr { i64, [2 x i64] }, ptr %t294, i32 0, i32 0
  store i64 0, ptr %t295
  %t296 = load { i64, [2 x i64] }, ptr %t294
  %t300 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t292, ptr %t293, { i64, [2 x i64] } %t296)
  store %"compiler/scope:Val" %t300, ptr %l155
  br label %bb78
bb78:
  br label %bb144
bb79:
  %t301 = load ptr, ptr %l1, !tbaa !29
  store ptr %t301, ptr %l156, !tbaa !29
  store i1 false, ptr %l157, !tbaa !21
  %t302 = load ptr, ptr %l156, !tbaa !29
  %t303 = icmp ne ptr %t302, null
  br i1 %t303, label %bb80, label %bb81
bb80:
  %t305 = load ptr, ptr %l156, !tbaa !29
  %t306 = load i64, ptr %t305, !range !{i64 0, i64 17}
  %t308 = icmp eq i64 %t306, 10
  store i1 %t308, ptr %l157, !tbaa !21
  br label %bb81
bb81:
  %t309 = load i1, ptr %l157, !tbaa !21
  br i1 %t309, label %bb82, label %bb83
bb82:
  %t310 = load ptr, ptr %l1, !tbaa !29
  %t312 = getelementptr { i64, [3 x i64] }, ptr %t310, i32 0, i32 1
  %t313 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t312, i32 0, i32 1
  %t314 = load ptr, ptr %t313
  store ptr %t314, ptr %l17, !tbaa !29
  %t316 = load ptr, ptr %l1, !tbaa !29
  %t318 = getelementptr { i64, [3 x i64] }, ptr %t316, i32 0, i32 1
  %t319 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t318, i32 0, i32 2
  %t320 = load ptr, ptr %t319
  store ptr %t320, ptr %l18, !tbaa !29
  br label %bb84
bb83:
  br label %bb87
bb84:
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t323 = load ptr, ptr %l17, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t325
  %t326 = getelementptr { i64, [2 x i64] }, ptr %t325, i32 0, i32 0
  store i64 0, ptr %t326
  %t327 = load { i64, [2 x i64] }, ptr %t325
  %t331 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t322, ptr %t323, { i64, [2 x i64] } %t327)
  store %"compiler/scope:Val" %t331, ptr %l168
  br label %bb85
bb85:
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t333 = load ptr, ptr %l18, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t334
  %t335 = getelementptr { i64, [2 x i64] }, ptr %t334, i32 0, i32 0
  store i64 0, ptr %t335
  %t336 = load { i64, [2 x i64] }, ptr %t334
  %t340 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t332, ptr %t333, { i64, [2 x i64] } %t336)
  store %"compiler/scope:Val" %t340, ptr %l172
  br label %bb86
bb86:
  br label %bb144
bb87:
  %t341 = load ptr, ptr %l1, !tbaa !29
  store ptr %t341, ptr %l173, !tbaa !29
  store i1 false, ptr %l174, !tbaa !21
  %t342 = load ptr, ptr %l173, !tbaa !29
  %t343 = icmp ne ptr %t342, null
  br i1 %t343, label %bb88, label %bb89
bb88:
  %t345 = load ptr, ptr %l173, !tbaa !29
  %t346 = load i64, ptr %t345, !range !{i64 0, i64 17}
  %t348 = icmp eq i64 %t346, 11
  store i1 %t348, ptr %l174, !tbaa !21
  br label %bb89
bb89:
  %t349 = load i1, ptr %l174, !tbaa !21
  br i1 %t349, label %bb90, label %bb91
bb90:
  %t350 = load ptr, ptr %l1, !tbaa !29
  %t352 = getelementptr { i64, [3 x i64] }, ptr %t350, i32 0, i32 1
  %t353 = getelementptr { %"compiler/source:Span", ptr }, ptr %t352, i32 0, i32 1
  %t354 = load ptr, ptr %t353
  store ptr %t354, ptr %l19, !tbaa !29
  br label %bb92
bb91:
  br label %bb102
bb92:
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t357 = load ptr, ptr %l19, !tbaa !29
  %t360 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eforWrap(ptr %v0, ptr %v1, ptr %t356, ptr %t357)
  store i1 %t360, ptr %l181
  br label %bb93
bb93:
  %t361 = load i1, ptr %l181, !tbaa !21
  br i1 %t361, label %bb94, label %bb95
bb94:
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t364 = getelementptr %"compiler/scope:Scoper", ptr %t362, i32 0, i32 92
  store ptr %t364, ptr %l183, !tbaa !29
  %t365 = load ptr, ptr %l19, !tbaa !29
  %t367 = getelementptr %"compiler/typed:Block", ptr %t365, i32 0, i32 0
  %t368 = load i32, ptr %t367, !tbaa !23
  %t370 = sext i32 %t368 to i64
  store i64 %t370, ptr %l186, !tbaa !24
  %t371 = load ptr, ptr %l0, !tbaa !29
  store ptr %t371, ptr %l187, !tbaa !29
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t374 = getelementptr %"compiler/scope:Scoper", ptr %t372, i32 0, i32 34
  store ptr %t374, ptr %l189, !tbaa !29
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t377 = getelementptr %"compiler/scope:Scoper", ptr %t375, i32 0, i32 34
  %t379 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t377)
  store i64 %t379, ptr %l192
  br label %bb96
bb95:
  br label %bb100
bb96:
  %t380 = load i64, ptr %l192, !tbaa !24
  %t381 = sub i64 %t380, 1
  %t382 = load ptr, ptr %l189, !tbaa !29
  %t384 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t382, i64 %t381)
  store i32 %t384, ptr %l194
  br label %bb97
bb97:
  %t385 = load ptr, ptr %l187, !tbaa !29
  %t386 = load i32, ptr %l194, !tbaa !23
  %t387 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elift(ptr %v0, ptr %t385, i32 %t386)
  store i32 %t387, ptr %l195
  br label %bb98
bb98:
  %t388 = load i32, ptr %l195, !tbaa !23
  %t389 = sext i32 %t388 to i64
  %t390 = load ptr, ptr %l183, !tbaa !29
  %t391 = load i64, ptr %l186, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t390, i64 %t391, i64 %t389)
  br label %bb99
bb99:
  br label %bb100
bb100:
  %t393 = load ptr, ptr %l0, !tbaa !29
  %t394 = load ptr, ptr %l19, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblock(ptr %v0, ptr %v1, ptr %t393, ptr %t394)
  br label %bb101
bb101:
  br label %bb144
bb102:
  %t398 = load ptr, ptr %l1, !tbaa !29
  store ptr %t398, ptr %l200, !tbaa !29
  store i1 false, ptr %l201, !tbaa !21
  %t399 = load ptr, ptr %l200, !tbaa !29
  %t400 = icmp ne ptr %t399, null
  br i1 %t400, label %bb103, label %bb104
bb103:
  %t402 = load ptr, ptr %l200, !tbaa !29
  %t403 = load i64, ptr %t402, !range !{i64 0, i64 17}
  %t405 = icmp eq i64 %t403, 12
  store i1 %t405, ptr %l201, !tbaa !21
  br label %bb104
bb104:
  %t406 = load i1, ptr %l201, !tbaa !21
  br i1 %t406, label %bb105, label %bb106
bb105:
  %t407 = load ptr, ptr %l1, !tbaa !29
  %t409 = getelementptr { i64, [3 x i64] }, ptr %t407, i32 0, i32 1
  %t410 = getelementptr { %"compiler/source:Span", ptr }, ptr %t409, i32 0, i32 1
  %t411 = load ptr, ptr %t410
  store ptr %t411, ptr %l20, !tbaa !29
  br label %bb107
bb106:
  br label %bb109
bb107:
  %t413 = load ptr, ptr %l0, !tbaa !29
  %t414 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblock(ptr %v0, ptr %v1, ptr %t413, ptr %t414)
  br label %bb108
bb108:
  br label %bb144
bb109:
  %t418 = load ptr, ptr %l1, !tbaa !29
  store ptr %t418, ptr %l209, !tbaa !29
  store i1 false, ptr %l210, !tbaa !21
  %t419 = load ptr, ptr %l209, !tbaa !29
  %t420 = icmp ne ptr %t419, null
  br i1 %t420, label %bb110, label %bb111
bb110:
  %t422 = load ptr, ptr %l209, !tbaa !29
  %t423 = load i64, ptr %t422, !range !{i64 0, i64 17}
  %t425 = icmp eq i64 %t423, 13
  store i1 %t425, ptr %l210, !tbaa !21
  br label %bb111
bb111:
  %t426 = load i1, ptr %l210, !tbaa !21
  br i1 %t426, label %bb112, label %bb113
bb112:
  %t427 = load ptr, ptr %l1, !tbaa !29
  %t429 = getelementptr { i64, [3 x i64] }, ptr %t427, i32 0, i32 1
  %t430 = getelementptr { %"compiler/source:Span", ptr }, ptr %t429, i32 0, i32 1
  %t431 = load ptr, ptr %t430
  store ptr %t431, ptr %l21, !tbaa !29
  br label %bb114
bb113:
  br label %bb128
bb114:
  %t433 = load ptr, ptr %l0, !tbaa !29
  %t435 = getelementptr %"compiler/scope:Scoper", ptr %t433, i32 0, i32 72
  %t436 = load ptr, ptr %l21, !tbaa !29
  %t438 = getelementptr %"compiler/typed:Join", ptr %t436, i32 0, i32 0
  %t439 = load ptr, ptr %t438, !tbaa !29
  %t441 = getelementptr %"compiler/typed:Block", ptr %t439, i32 0, i32 0
  %t442 = load i32, ptr %t441, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t435, i32 %t442)
  br label %bb115
bb115:
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t446 = load ptr, ptr %l21, !tbaa !29
  %t448 = getelementptr %"compiler/typed:Join", ptr %t446, i32 0, i32 0
  %t449 = load ptr, ptr %t448, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblock(ptr %v0, ptr %v1, ptr %t445, ptr %t449)
  br label %bb116
bb116:
  %t453 = load ptr, ptr %l0, !tbaa !29
  %t455 = getelementptr %"compiler/scope:Scoper", ptr %t453, i32 0, i32 72
  %t457 = call { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePop_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t455)
  %t458 = extractvalue { i32, i32 } %t457, 1
  %t459 = extractvalue { i32, i32 } %t457, 0
  store i32 %t459, ptr %l228
  %t460 = icmp ne i32 %t459, 0
  br i1 %t460, label %bb118, label %ok.461, !prof !99
ok.461:
  store i32 %t458, ptr %l227
  br label %bb117
bb117:
  %t462 = load i32, ptr %l227, !tbaa !23
  store i32 %t462, ptr %l224, !tbaa !23
  br label %bb120
bb118:
  br label %bb119
bb119:
  call void @__olang_ert_req_clear()
  br label %bb120
bb120:
  %t463 = load ptr, ptr %l21, !tbaa !29
  %t465 = getelementptr %"compiler/typed:Join", ptr %t463, i32 0, i32 2
  %t466 = load { i64, ptr }, ptr %t465, !tbaa !27
  store { i64, ptr } %t466, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t468 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t470 = extractvalue { i64, ptr } %t468, 0
  store i64 %t470, ptr %l24, !tbaa !24
  br label %bb121
bb121:
  %t472 = load i64, ptr %l23, !tbaa !24
  %t473 = load i64, ptr %l24, !tbaa !24
  %t476 = icmp slt i64 %t472, %t473
  %t478 = xor i1 %t476, true
  br i1 %t478, label %bb122, label %bb123
bb122:
  br label %bb127
bb123:
  br label %bb124
bb124:
  %t480 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t480, ptr %l237, !tbaa !27
  %t481 = load i64, ptr %l23, !tbaa !24
  %t483 = getelementptr { i64, ptr }, ptr %l237, i32 0, i32 1
  %t484 = load ptr, ptr %t483, !tbaa !27
  %t485 = getelementptr ptr, ptr %t484, i64 %t481
  %t486 = load ptr, ptr %t485, !tbaa !39
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t491 = getelementptr %"compiler/typed:Clause", ptr %t486, i32 0, i32 3
  %t492 = load ptr, ptr %t491, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblock(ptr %v0, ptr %v1, ptr %t488, ptr %t492)
  br label %bb125
bb125:
  br label %bb126
bb126:
  %t495 = load i64, ptr %l23, !tbaa !24
  %t497 = add i64 %t495, 1
  store i64 %t497, ptr %l23, !tbaa !24
  br label %bb121
bb127:
  br label %bb144
bb128:
  %t499 = load ptr, ptr %l1, !tbaa !29
  store ptr %t499, ptr %l245, !tbaa !29
  store i1 false, ptr %l246, !tbaa !21
  %t500 = load ptr, ptr %l245, !tbaa !29
  %t501 = icmp ne ptr %t500, null
  br i1 %t501, label %bb129, label %bb130
bb129:
  %t503 = load ptr, ptr %l245, !tbaa !29
  %t504 = load i64, ptr %t503, !range !{i64 0, i64 17}
  %t506 = icmp eq i64 %t504, 14
  store i1 %t506, ptr %l246, !tbaa !21
  br label %bb130
bb130:
  %t507 = load i1, ptr %l246, !tbaa !21
  br i1 %t507, label %bb131, label %bb132
bb131:
  %t508 = load ptr, ptr %l1, !tbaa !29
  %t510 = getelementptr { i64, [3 x i64] }, ptr %t508, i32 0, i32 1
  %t511 = getelementptr { %"compiler/source:Span", ptr }, ptr %t510, i32 0, i32 0
  %t512 = load %"compiler/source:Span", ptr %t511
  store %"compiler/source:Span" %t512, ptr %l26
  %t514 = load ptr, ptr %l1, !tbaa !29
  %t516 = getelementptr { i64, [3 x i64] }, ptr %t514, i32 0, i32 1
  %t517 = getelementptr { %"compiler/source:Span", ptr }, ptr %t516, i32 0, i32 1
  %t518 = load ptr, ptr %t517
  store ptr %t518, ptr %l27, !tbaa !29
  br label %bb133
bb132:
  br label %bb135
bb133:
  %t520 = load ptr, ptr %l0, !tbaa !29
  %t521 = load %"compiler/source:Span", ptr %l26
  %t522 = load ptr, ptr %l27, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2espawn(ptr %v0, ptr %v1, ptr %t520, %"compiler/source:Span" %t521, ptr %t522)
  br label %bb134
bb134:
  br label %bb144
bb135:
  %t526 = load ptr, ptr %l1, !tbaa !29
  store ptr %t526, ptr %l256, !tbaa !29
  store i1 false, ptr %l257, !tbaa !21
  %t527 = load ptr, ptr %l256, !tbaa !29
  %t528 = icmp ne ptr %t527, null
  br i1 %t528, label %bb136, label %bb137
bb136:
  %t530 = load ptr, ptr %l256, !tbaa !29
  %t531 = load i64, ptr %t530, !range !{i64 0, i64 17}
  %t533 = icmp eq i64 %t531, 15
  store i1 %t533, ptr %l257, !tbaa !21
  br label %bb137
bb137:
  %t534 = load i1, ptr %l257, !tbaa !21
  br i1 %t534, label %bb138, label %bb139
bb138:
  %t535 = load ptr, ptr %l1, !tbaa !29
  %t537 = getelementptr { i64, [3 x i64] }, ptr %t535, i32 0, i32 1
  %t538 = getelementptr { %"compiler/source:Span", ptr }, ptr %t537, i32 0, i32 1
  %t539 = load ptr, ptr %t538
  store ptr %t539, ptr %l28, !tbaa !29
  br label %bb140
bb139:
  br label %bb143
bb140:
  %t541 = load ptr, ptr %l0, !tbaa !29
  store ptr %t541, ptr %l262, !tbaa !29
  %t542 = load ptr, ptr %l28, !tbaa !29
  store ptr %t542, ptr %l264, !tbaa !29
  %t544 = load ptr, ptr %l0, !tbaa !29
  %t546 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehere(ptr %v0, ptr %t544)
  store { i64, [2 x i64] } %t546, ptr %l266
  br label %bb141
bb141:
  %t547 = load ptr, ptr %l262, !tbaa !29
  %t548 = load ptr, ptr %l264, !tbaa !29
  %t549 = load { i64, [2 x i64] }, ptr %l266
  %t550 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t547, ptr %t548, { i64, [2 x i64] } %t549)
  store %"compiler/scope:Val" %t550, ptr %l267
  br label %bb142
bb142:
  br label %bb144
bb143:
  call void @__olang_check_failed(ptr @olang_loc_e68fbdb964820230_ed59a3d360e211c)
  unreachable
bb144:
  %t551 = load ptr, ptr %l0, !tbaa !29
  %t552 = load %"compiler/source:Span", ptr %l2
  %t555 = getelementptr %"compiler/scope:Scoper", ptr %t551, i32 0, i32 38
  store %"compiler/source:Span" %t552, ptr %t555
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreParam(ptr %v0, ptr %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i1
  %l9 = alloca i64
  %l12 = alloca i64
  %l14 = alloca i1
  %l17 = alloca i1
  %l18 = alloca i1
  %l19 = alloca ptr
  %l28 = alloca %"compiler/typed:Local"
  %l30 = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eregionParam(ptr %v0, ptr %t1, i64 %t2)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l1, !tbaa !24
  %t7 = load i64, ptr %l1, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l1, !tbaa !24
  store i64 %t11, ptr %l9, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/scope:Scoper", ptr %t12, i32 0, i32 84
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l12
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb5
bb4:
  %t17 = load i64, ptr %l9, !tbaa !24
  %t18 = load i64, ptr %l12, !tbaa !24
  %t19 = icmp slt i64 %t17, %t18
  store i1 %t19, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t21 = load i1, ptr %l8, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i64, ptr %l1, !tbaa !24
  %t26 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eregionKind(ptr %v0, ptr %t22, i64 %t23)
  store i1 %t26, ptr %l17
  br label %bb8
bb7:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb9
bb8:
  %t27 = load i1, ptr %l17, !tbaa !21
  store i1 %t27, ptr %l14, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l14, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l19, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/scope:Scoper", ptr %t30, i32 0, i32 25
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = icmp eq ptr %t33, null
  br i1 %t35, label %bb12, label %bb13
bb11:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb17
bb12:
  call void @__olang_check_failed(ptr @olang_loc_d10963641a9b1fed_5d8116c763841fe1)
  unreachable
bb13:
  br label %bb14
bb14:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/scope:Scoper", ptr %t37, i32 0, i32 25
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t43 = getelementptr %"compiler/typed:Body", ptr %t40, i32 0, i32 7
  %t44 = load i64, ptr %l1, !tbaa !24
  %t47 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t43, i64 %t44)
  store %"compiler/typed:Local" %t47, ptr %l28
  br label %bb15
bb15:
  %t48 = getelementptr %"compiler/typed:Local", ptr %l28, i32 0, i32 2
  %t49 = load i32, ptr %t48, !tbaa !23
  %t50 = load ptr, ptr %l19, !tbaa !29
  %t52 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t50, i32 %t49)
  store i1 %t52, ptr %l30
  br label %bb16
bb16:
  %t53 = load i1, ptr %l30, !tbaa !21
  store i1 %t53, ptr %l18, !tbaa !21
  br label %bb17
bb17:
  %t54 = load i1, ptr %l18, !tbaa !21
  br i1 %t54, label %bb18, label %bb19
bb18:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/scope:Scoper", ptr %t55, i32 0, i32 84
  %t58 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t57, i64 %t58, i1 true)
  br label %bb20
bb19:
  br label %bb26
bb20:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/scope:Scoper", ptr %t61, i32 0, i32 85
  %t64 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t63, i64 %t64, i1 true)
  br label %bb21
bb21:
  br i1 %a2, label %bb22, label %bb23
bb22:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/scope:Scoper", ptr %t69, i32 0, i32 86
  %t72 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t71, i64 %t72, i1 true)
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreThrough(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i64
  %l12 = alloca i32
  %l19 = alloca i64
  %l24 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca i1
  %l45 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i32
  %l60 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l62 = alloca i64
  %l64 = alloca i64
  %l69 = alloca i32
  %l72 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca i32
  %l79 = alloca i64
  %s7 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l12
  br label %bb1
bb1:
  %t11 = load i32, ptr %l12, !range !{i32 0, i32 33}
  store i32 %t11, ptr %l2
  %t12 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t14 = trunc i64 20 to i32
  %t15 = icmp eq i32 %t12, %t14
  br i1 %t15, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb11
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/scope:Scoper", ptr %t17, i32 0, i32 0
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 2
  %t23 = load i32, ptr %l1, !tbaa !23
  %t26 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t22, i32 %t23)
  store i64 %t26, ptr %l19
  br label %bb5
bb5:
  %t27 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t28 = load i64, ptr %l19, !tbaa !24
  %t30 = and i64 %t28, %t27
  %t32 = icmp eq i64 %t30, 0
  br i1 %t32, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l24, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/scope:Scoper", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = getelementptr %"compiler/generic:Program", ptr %t39, i32 0, i32 2
  %t42 = load i32, ptr %l1, !tbaa !23
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l29
  br label %bb9
bb9:
  %t46 = load ptr, ptr %l24, !tbaa !29
  %t47 = load i32, ptr %l29, !tbaa !23
  %t48 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eassignableHolds(ptr %v0, ptr %t46, i32 %t47)
  store i1 %t48, ptr %l30
  br label %bb10
bb10:
  %t49 = load i1, ptr %l30, !tbaa !21
  store i1 %t49, ptr %rv
  br label %ret
bb11:
  %t50 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t52 = trunc i64 21 to i32
  %t53 = icmp eq i32 %t50, %t52
  br i1 %t53, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i1 false, ptr %rv
  br label %ret
bb15:
  %t56 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t58 = trunc i64 18 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb16, label %bb17
bb16:
  br label %bb26
bb17:
  %t61 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t63 = trunc i64 22 to i32
  %t64 = icmp eq i32 %t61, %t63
  br i1 %t64, label %bb18, label %bb19
bb18:
  br label %bb26
bb19:
  %t66 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t68 = trunc i64 23 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb20, label %bb21
bb20:
  br label %bb26
bb21:
  %t71 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t73 = trunc i64 19 to i32
  %t74 = icmp eq i32 %t71, %t73
  br i1 %t74, label %bb22, label %bb23
bb22:
  br label %bb26
bb23:
  %t76 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t78 = trunc i64 24 to i32
  %t79 = icmp eq i32 %t76, %t78
  br i1 %t79, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  store i1 false, ptr %rv
  br label %ret
bb31:
  call void @__olang_check_failed(ptr @olang_loc_fab9d5262c098304_b0d84a3f5fe3aa00)
  unreachable
bb32:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/scope:Scoper", ptr %t82, i32 0, i32 8
  %t85 = load i32, ptr %l1, !tbaa !23
  %t88 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %t84, i32 %t85)
  %t89 = extractvalue { i32, i64 } %t88, 1
  %t90 = extractvalue { i32, i64 } %t88, 0
  store i32 %t90, ptr %l50
  %t91 = icmp ne i32 %t90, 0
  br i1 %t91, label %bb34, label %ok.92, !prof !99
ok.92:
  store i64 %t89, ptr %l49
  br label %bb33
bb33:
  %t93 = load i64, ptr %l49, !tbaa !24
  store i64 %t93, ptr %l45, !tbaa !24
  br label %bb36
bb34:
  br label %bb35
bb35:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l45, !tbaa !24
  br label %bb36
bb36:
  %t94 = load i64, ptr %l45, !tbaa !24
  store i64 %t94, ptr %l3, !tbaa !24
  %t95 = load i64, ptr %l3, !tbaa !24
  %t97 = icmp ne i64 %t95, 0
  br i1 %t97, label %bb37, label %bb38
bb37:
  %t99 = load i64, ptr %l3, !tbaa !24
  %t101 = icmp eq i64 %t99, 3
  store i1 %t101, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/scope:Scoper", ptr %t103, i32 0, i32 8
  %t106 = load i32, ptr %l1, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %t105, i32 %t106, i64 1)
  br label %bb40
bb40:
  store i1 false, ptr %l4, !tbaa !21
  store %olang.scope zeroinitializer, ptr %s7
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load i32, ptr %l1, !tbaa !23
  %t113 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparts(ptr %v0, ptr %s7, ptr %t109, i32 %t110)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t113, ptr %l60
  br label %bb41
bb41:
  %t114 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l60
  %t115 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t114, ptr %t115
  store ptr %t115, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb42
bb42:
  %t117 = load i64, ptr %l6, !tbaa !24
  store i64 %t117, ptr %l62, !tbaa !24
  %t118 = load ptr, ptr %l5, !tbaa !29
  %t120 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s7, ptr %t118)
  store i64 %t120, ptr %l64
  br label %bb43
bb43:
  %t121 = load i64, ptr %l62, !tbaa !24
  %t122 = load i64, ptr %l64, !tbaa !24
  %t123 = icmp slt i64 %t121, %t122
  %t125 = xor i1 %t123, true
  br i1 %t125, label %bb44, label %bb45
bb44:
  br label %bb53
bb45:
  br label %bb46
bb46:
  %t127 = load ptr, ptr %l5, !tbaa !29
  %t128 = load i64, ptr %l6, !tbaa !24
  %t131 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s7, ptr %t127, i64 %t128)
  store i32 %t131, ptr %l69
  br label %bb47
bb47:
  %t132 = load i32, ptr %l69, !tbaa !23
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t137 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreThrough(ptr %v0, ptr %t133, i32 %t132)
  store i1 %t137, ptr %l72
  br label %bb48
bb48:
  %t138 = load i1, ptr %l72, !tbaa !21
  br i1 %t138, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb51
bb50:
  br label %bb51
bb51:
  br label %bb52
bb52:
  %t139 = load i64, ptr %l6, !tbaa !24
  %t141 = add i64 %t139, 1
  store i64 %t141, ptr %l6, !tbaa !24
  br label %bb42
bb53:
  call void @__olang_scope_close(ptr %s7)
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/scope:Scoper", ptr %t143, i32 0, i32 8
  store ptr %t145, ptr %l76, !tbaa !29
  %t146 = load i32, ptr %l1, !tbaa !23
  store i32 %t146, ptr %l77, !tbaa !23
  %t147 = load i1, ptr %l4, !tbaa !21
  br i1 %t147, label %bb54, label %bb55
bb54:
  store i64 3, ptr %l79, !tbaa !24
  br label %bb56
bb55:
  store i64 2, ptr %l79, !tbaa !24
  br label %bb56
bb56:
  %t149 = load ptr, ptr %l76, !tbaa !29
  %t150 = load i32, ptr %l77, !tbaa !23
  %t151 = load i64, ptr %l79, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %t149, i32 %t150, i64 %t151)
  br label %bb57
bb57:
  %t152 = load i1, ptr %l4, !tbaa !21
  store i1 %t152, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estrReceiver(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/scope:rel"
  %l4 = alloca i1
  %l5 = alloca { i64, [2 x i64] }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l19 = alloca i64
  %l24 = alloca %"compiler/scope:rel"
  %l29 = alloca i64
  %l32 = alloca i64
  %l34 = alloca i1
  %l38 = alloca i1
  %l39 = alloca i1
  %l40 = alloca { i64, [2 x i64] }
  %l42 = alloca { i64, [2 x i64] }
  %l44 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca ptr
  %l62 = alloca %"compiler/source:Span"
  %l63 = alloca %"compiler/msgs:Msg"
  %l64 = alloca i64
  %l69 = alloca i64
  %l73 = alloca i64
  %l76 = alloca i64
  %l97 = alloca i1
  %l99 = alloca i1
  %l103 = alloca i1
  %l105 = alloca ptr
  %l109 = alloca %"compiler/source:Span"
  %l110 = alloca %"compiler/msgs:Msg"
  %l111 = alloca i64
  %l115 = alloca i64
  %l124 = alloca i1
  %l128 = alloca %"compiler/source:Span"
  %l129 = alloca i32
  %l133 = alloca %"compiler/source:Span"
  %l136 = alloca ptr
  %l137 = alloca i64
  %l141 = alloca i64
  %l145 = alloca %"compiler/source:Span"
  %l146 = alloca %"compiler/msgs:Msg"
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 35
  store ptr %t3, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l17, !tbaa !24
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l19
  br label %bb2
bb2:
  %t9 = load i64, ptr %l17, !tbaa !24
  %t10 = load i64, ptr %l19, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb39
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = call %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t15, i64 %t16)
  store %"compiler/scope:rel" %t19, ptr %l24
  br label %bb6
bb6:
  %t20 = load %"compiler/scope:rel", ptr %l24
  store %"compiler/scope:rel" %t20, ptr %l3
  store i1 false, ptr %l4, !tbaa !21
  %t21 = getelementptr %"compiler/scope:rel", ptr %l3, i32 0, i32 1
  %t22 = load { i64, [2 x i64] }, ptr %t21
  store { i64, [2 x i64] } %t22, ptr %l5
  %t24 = load { i64, [2 x i64] }, ptr %l5
  %t26 = extractvalue { i64, [2 x i64] } %t24, 0
  %t27 = icmp eq i64 %t26, 2
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t29 = getelementptr { i64, [2 x i64] }, ptr %l5, i32 0, i32 1
  %t30 = getelementptr { i64 }, ptr %t29, i32 0, i32 0
  %t31 = load i64, ptr %t30
  store i64 %t31, ptr %l6, !tbaa !24
  br label %bb9
bb8:
  br label %bb19
bb9:
  %t33 = load i64, ptr %l6, !tbaa !24
  store i64 %t33, ptr %l29, !tbaa !24
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/scope:Scoper", ptr %t34, i32 0, i32 64
  %t38 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t36)
  store i64 %t38, ptr %l32
  br label %bb10
bb10:
  %t39 = load i64, ptr %l29, !tbaa !24
  %t40 = load i64, ptr %l32, !tbaa !24
  %t41 = icmp slt i64 %t39, %t40
  br i1 %t41, label %bb11, label %bb12
bb11:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/scope:Scoper", ptr %t43, i32 0, i32 64
  %t46 = load i64, ptr %l6, !tbaa !24
  %t49 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t45, i64 %t46)
  store i1 %t49, ptr %l38
  br label %bb13
bb12:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb14
bb13:
  %t50 = load i1, ptr %l38, !tbaa !21
  store i1 %t50, ptr %l34, !tbaa !21
  br label %bb14
bb14:
  %t51 = load i1, ptr %l34, !tbaa !21
  br i1 %t51, label %bb15, label %bb16
bb15:
  %t52 = getelementptr %"compiler/scope:rel", ptr %l3, i32 0, i32 0
  %t53 = load { i64, [2 x i64] }, ptr %t52
  store { i64, [2 x i64] } %t53, ptr %l40
  %t54 = getelementptr %"compiler/scope:rel", ptr %l3, i32 0, i32 1
  %t55 = load { i64, [2 x i64] }, ptr %t54
  store { i64, [2 x i64] } %t55, ptr %l42
  %t58 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l40, ptr %l42)
  store i1 %t58, ptr %l44
  br label %bb17
bb16:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb18
bb17:
  %t59 = load i1, ptr %l44, !tbaa !21
  %t60 = xor i1 %t59, true
  store i1 %t60, ptr %l39, !tbaa !21
  br label %bb18
bb18:
  %t62 = load i1, ptr %l39, !tbaa !21
  store i1 %t62, ptr %l4, !tbaa !21
  br label %bb28
bb19:
  %t63 = load { i64, [2 x i64] }, ptr %l5
  %t65 = extractvalue { i64, [2 x i64] } %t63, 0
  %t66 = icmp eq i64 %t65, 4
  br i1 %t66, label %bb20, label %bb21
bb20:
  %t68 = getelementptr { i64, [2 x i64] }, ptr %l5, i32 0, i32 1
  %t69 = getelementptr { i64, i64 }, ptr %t68, i32 0, i32 0
  %t70 = load i64, ptr %t69
  store i64 %t70, ptr %l7, !tbaa !24
  br label %bb22
bb21:
  br label %bb23
bb22:
  %t72 = load i64, ptr %l7, !tbaa !24
  %t74 = icmp sge i64 %t72, 0
  store i1 %t74, ptr %l4, !tbaa !21
  br label %bb28
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_678543b1c51fd044_bcff5a6e112a6af8)
  unreachable
bb28:
  %t76 = load i1, ptr %l4, !tbaa !21
  br i1 %t76, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s6
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l52, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l53, !tbaa !29
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/scope:Scoper", ptr %t80, i32 0, i32 25
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = icmp eq ptr %t83, null
  br i1 %t85, label %bb31, label %bb32
bb30:
  br label %bb37
bb31:
  call void @__olang_check_failed(ptr @olang_loc_90a9d28716f9cb6_29834bc9108cc36a)
  unreachable
bb32:
  br label %bb33
bb33:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/scope:Scoper", ptr %t87, i32 0, i32 25
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t93 = getelementptr %"compiler/typed:Body", ptr %t90, i32 0, i32 3
  %t94 = load i64, ptr %t93, !tbaa !24
  %t95 = getelementptr %"compiler/scope:rel", ptr %l3, i32 0, i32 3
  %t96 = load %"compiler/source:Span", ptr %t95
  %t97 = load ptr, ptr %l53, !tbaa !29
  %t100 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efirstToken(ptr %v0, ptr %t97, i64 %t94, %"compiler/source:Span" %t96)
  store %"compiler/source:Span" %t100, ptr %l62
  br label %bb34
bb34:
  %t101 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eStrStoresInReceiver(ptr %s6)
  store %"compiler/msgs:Msg" %t101, ptr %l63
  br label %bb35
bb35:
  %t102 = load ptr, ptr %l52, !tbaa !29
  %t103 = load %"compiler/source:Span", ptr %l62
  %t104 = load %"compiler/msgs:Msg", ptr %l63
  %t105 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s6, ptr %t102, %"compiler/source:Span" %t103, %"compiler/msgs:Msg" %t104)
  store i64 %t105, ptr %l64
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s6)
  br label %ret
bb37:
  br label %bb38
bb38:
  %t106 = load i64, ptr %l2, !tbaa !24
  %t108 = add i64 %t106, 1
  store i64 %t108, ptr %l2, !tbaa !24
  br label %bb1
bb39:
  store i64 0, ptr %l8, !tbaa !24
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/scope:Scoper", ptr %t110, i32 0, i32 64
  %t114 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t112)
  store i64 %t114, ptr %l69
  br label %bb40
bb40:
  %t115 = load i64, ptr %l69, !tbaa !24
  store i64 %t115, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t116 = load i64, ptr %l9, !tbaa !24
  %t117 = load i64, ptr %l8, !tbaa !24
  %t120 = icmp sgt i64 %t116, %t117
  br i1 %t120, label %bb41, label %bb42
bb41:
  %t122 = load i64, ptr %l10, !tbaa !24
  %t124 = icmp sgt i64 %t122, 0
  br i1 %t124, label %bb43, label %bb44
bb42:
  store i64 0, ptr %l73, !tbaa !24
  br label %bb46
bb43:
  %t126 = load i64, ptr %l9, !tbaa !24
  %t127 = load i64, ptr %l8, !tbaa !24
  %t130 = sub i64 %t126, %t127
  %t131 = load i64, ptr %l10, !tbaa !24
  %t134 = add i64 %t130, %t131
  %t136 = sub i64 %t134, 1
  %t137 = load i64, ptr %l10, !tbaa !24
  %t140 = sdiv i64 %t136, %t137
  store i64 %t140, ptr %l76, !tbaa !24
  br label %bb45
bb44:
  store i64 0, ptr %l76, !tbaa !24
  br label %bb45
bb45:
  %t142 = load i64, ptr %l76, !tbaa !24
  store i64 %t142, ptr %l73, !tbaa !24
  br label %bb46
bb46:
  %t143 = load i64, ptr %l73, !tbaa !24
  store i64 %t143, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb47
bb47:
  store %olang.scope zeroinitializer, ptr %s9
  %t144 = load i64, ptr %l12, !tbaa !24
  %t145 = load i64, ptr %l11, !tbaa !24
  %t148 = icmp slt i64 %t144, %t145
  %t150 = xor i1 %t148, true
  br i1 %t150, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s9)
  br label %bb79
bb49:
  br label %bb50
bb50:
  %t152 = load i64, ptr %l8, !tbaa !24
  %t153 = load i64, ptr %l12, !tbaa !24
  %t154 = load i64, ptr %l10, !tbaa !24
  %t157 = mul i64 %t153, %t154
  %t160 = add i64 %t152, %t157
  store i64 %t160, ptr %l13, !tbaa !24
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/scope:Scoper", ptr %t162, i32 0, i32 64
  %t165 = load i64, ptr %l13, !tbaa !24
  %t168 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t164, i64 %t165)
  store i1 %t168, ptr %l97
  br label %bb51
bb51:
  %t169 = load i1, ptr %l97, !tbaa !21
  %t170 = xor i1 %t169, true
  br i1 %t170, label %bb52, label %bb53
bb52:
  store i1 true, ptr %l99, !tbaa !21
  br label %bb55
bb53:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"compiler/scope:Scoper", ptr %t172, i32 0, i32 58
  %t175 = load i64, ptr %l13, !tbaa !24
  %t178 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t174, i64 %t175)
  store i1 %t178, ptr %l103
  br label %bb54
bb54:
  %t179 = load i1, ptr %l103, !tbaa !21
  %t180 = xor i1 %t179, true
  store i1 %t180, ptr %l99, !tbaa !21
  br label %bb55
bb55:
  %t182 = load i1, ptr %l99, !tbaa !21
  br i1 %t182, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s9)
  br label %bb78
bb57:
  br label %bb58
bb58:
  %t183 = load ptr, ptr %l0, !tbaa !29
  store ptr %t183, ptr %l105, !tbaa !29
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/scope:Scoper", ptr %t184, i32 0, i32 61
  %t187 = load i64, ptr %l13, !tbaa !24
  %t190 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t186, i64 %t187)
  store %"compiler/source:Span" %t190, ptr %l109
  br label %bb59
bb59:
  %t191 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eStrStoresInReceiver(ptr %s9)
  store %"compiler/msgs:Msg" %t191, ptr %l110
  br label %bb60
bb60:
  %t192 = load ptr, ptr %l105, !tbaa !29
  %t193 = load %"compiler/source:Span", ptr %l109
  %t194 = load %"compiler/msgs:Msg", ptr %l110
  %t195 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s9, ptr %t192, %"compiler/source:Span" %t193, %"compiler/msgs:Msg" %t194)
  store i64 %t195, ptr %l111
  br label %bb61
bb61:
  %t196 = load i64, ptr %l111, !tbaa !24
  store i64 %t196, ptr %l14, !tbaa !24
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/scope:Scoper", ptr %t197, i32 0, i32 62
  %t200 = load i64, ptr %l13, !tbaa !24
  %t203 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t199, i64 %t200)
  store i64 %t203, ptr %l115
  br label %bb62
bb62:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/scope:Scoper", ptr %t204, i32 0, i32 25
  %t207 = load ptr, ptr %t206, !tbaa !29
  %t209 = icmp eq ptr %t207, null
  br i1 %t209, label %bb63, label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_a7a579971a154b67_66936e5e8b24a2eb)
  unreachable
bb64:
  br label %bb65
bb65:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/scope:Scoper", ptr %t211, i32 0, i32 25
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t217 = getelementptr %"compiler/typed:Body", ptr %t214, i32 0, i32 3
  %t218 = load i64, ptr %t217, !tbaa !24
  %t219 = load i64, ptr %l115, !tbaa !24
  %t221 = icmp ne i64 %t219, %t218
  br i1 %t221, label %bb66, label %bb67
bb66:
  store i1 true, ptr %l124, !tbaa !21
  br label %bb70
bb67:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/scope:Scoper", ptr %t223, i32 0, i32 63
  %t226 = load i64, ptr %l13, !tbaa !24
  %t229 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t225, i64 %t226)
  store %"compiler/source:Span" %t229, ptr %l128
  br label %bb68
bb68:
  %t230 = getelementptr %"compiler/source:Span", ptr %l128, i32 0, i32 0
  %t231 = load i32, ptr %t230, !tbaa !23
  store i32 %t231, ptr %l129, !tbaa !23
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr %"compiler/scope:Scoper", ptr %t232, i32 0, i32 61
  %t235 = load i64, ptr %l13, !tbaa !24
  %t238 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t234, i64 %t235)
  store %"compiler/source:Span" %t238, ptr %l133
  br label %bb69
bb69:
  %t239 = getelementptr %"compiler/source:Span", ptr %l133, i32 0, i32 0
  %t240 = load i32, ptr %t239, !tbaa !23
  %t241 = load i32, ptr %l129, !tbaa !23
  %t243 = icmp ne i32 %t241, %t240
  store i1 %t243, ptr %l124, !tbaa !21
  br label %bb70
bb70:
  %t245 = load i1, ptr %l124, !tbaa !21
  br i1 %t245, label %bb71, label %bb72
bb71:
  store %olang.scope zeroinitializer, ptr %s11
  %t246 = load ptr, ptr %l0, !tbaa !29
  store ptr %t246, ptr %l136, !tbaa !29
  %t247 = load i64, ptr %l14, !tbaa !24
  store i64 %t247, ptr %l137, !tbaa !24
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t250 = getelementptr %"compiler/scope:Scoper", ptr %t248, i32 0, i32 62
  %t251 = load i64, ptr %l13, !tbaa !24
  %t254 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t250, i64 %t251)
  store i64 %t254, ptr %l141
  br label %bb73
bb72:
  br label %bb77
bb73:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t257 = getelementptr %"compiler/scope:Scoper", ptr %t255, i32 0, i32 63
  %t258 = load i64, ptr %l13, !tbaa !24
  %t261 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t257, i64 %t258)
  store %"compiler/source:Span" %t261, ptr %l145
  br label %bb74
bb74:
  %t262 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteStrBuildsHere(ptr %s11)
  store %"compiler/msgs:Msg" %t262, ptr %l146
  br label %bb75
bb75:
  %t263 = load ptr, ptr %l136, !tbaa !29
  %t264 = load i64, ptr %l137, !tbaa !24
  %t265 = load i64, ptr %l141, !tbaa !24
  %t266 = load %"compiler/source:Span", ptr %l145
  %t267 = load %"compiler/msgs:Msg", ptr %l146
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enote(ptr %v0, ptr %s11, ptr %t263, i64 %t264, i64 %t265, %"compiler/source:Span" %t266, %"compiler/msgs:Msg" %t267)
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s11)
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s9)
  br label %ret
bb78:
  %t268 = load i64, ptr %l12, !tbaa !24
  %t270 = add i64 %t268, 1
  store i64 %t270, ptr %l12, !tbaa !24
  br label %bb47
bb79:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esumBuilds(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca ptr
  %l10 = alloca i64
  %l12 = alloca i64
  %l14 = alloca i1
  %l17 = alloca i1
  %rv = alloca i1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 6
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l7, !tbaa !29
  %t10 = getelementptr %"compiler/scope:summary", ptr %t8, i32 0, i32 1
  %t11 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t10
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l3
  %t13 = load i64, ptr %l2, !tbaa !24
  store i64 %t13, ptr %l10, !tbaa !24
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %l3)
  store i64 %t15, ptr %l12
  br label %bb2
bb2:
  %t16 = load i64, ptr %l10, !tbaa !24
  %t17 = load i64, ptr %l12, !tbaa !24
  %t18 = icmp sge i64 %t16, %t17
  br i1 %t18, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb6
bb4:
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %l3, i64 %t20)
  store i1 %t23, ptr %l17
  br label %bb5
bb5:
  %t24 = load i1, ptr %l17, !tbaa !21
  store i1 %t24, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t25 = load i1, ptr %l14, !tbaa !21
  store i1 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ethroughDerived(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i1
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l28 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l38 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l48 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ethroughDerivedExpr(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i1 %t20, ptr %l15
  br label %bb6
bb6:
  %t21 = load i1, ptr %l15, !tbaa !21
  br i1 %t21, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb10
bb8:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t26 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ederivedRead(ptr %v0, ptr %v1, ptr %t22, ptr %t23)
  store i1 %t26, ptr %l19
  br label %bb9
bb9:
  %t27 = load i1, ptr %l19, !tbaa !21
  store i1 %t27, ptr %l16, !tbaa !21
  br label %bb10
bb10:
  %t28 = load i1, ptr %l16, !tbaa !21
  store i1 %t28, ptr %l6, !tbaa !21
  br label %bb37
bb11:
  %t29 = load ptr, ptr %l1, !tbaa !29
  store ptr %t29, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t30 = load ptr, ptr %l20, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb12, label %bb13
bb12:
  %t33 = load ptr, ptr %l20, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 8}
  %t36 = icmp eq i64 %t34, 3
  store i1 %t36, ptr %l21, !tbaa !21
  br label %bb13
bb13:
  %t37 = load i1, ptr %l21, !tbaa !21
  br i1 %t37, label %bb14, label %bb15
bb14:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l3, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t48 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ethroughDerived(ptr %v0, ptr %v1, ptr %t44, ptr %t45)
  store i1 %t48, ptr %l28
  br label %bb17
bb17:
  %t49 = load i1, ptr %l28, !tbaa !21
  store i1 %t49, ptr %l6, !tbaa !21
  br label %bb37
bb18:
  %t50 = load ptr, ptr %l1, !tbaa !29
  store ptr %t50, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t51 = load ptr, ptr %l29, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb19, label %bb20
bb19:
  %t54 = load ptr, ptr %l29, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 8}
  %t57 = icmp eq i64 %t55, 4
  store i1 %t57, ptr %l30, !tbaa !21
  br label %bb20
bb20:
  %t58 = load i1, ptr %l30, !tbaa !21
  br i1 %t58, label %bb21, label %bb22
bb21:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t61, i32 0, i32 2
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l4, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l4, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Elem", ptr %t66, i32 0, i32 0
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t72 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ethroughDerived(ptr %v0, ptr %v1, ptr %t65, ptr %t69)
  store i1 %t72, ptr %l38
  br label %bb24
bb24:
  %t73 = load i1, ptr %l38, !tbaa !21
  store i1 %t73, ptr %l6, !tbaa !21
  br label %bb37
bb25:
  %t74 = load ptr, ptr %l1, !tbaa !29
  store ptr %t74, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t75 = load ptr, ptr %l39, !tbaa !29
  %t76 = icmp ne ptr %t75, null
  br i1 %t76, label %bb26, label %bb27
bb26:
  %t78 = load ptr, ptr %l39, !tbaa !29
  %t79 = load i64, ptr %t78, !range !{i64 0, i64 8}
  %t81 = icmp eq i64 %t79, 5
  store i1 %t81, ptr %l40, !tbaa !21
  br label %bb27
bb27:
  %t82 = load i1, ptr %l40, !tbaa !21
  br i1 %t82, label %bb28, label %bb29
bb28:
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t85 = getelementptr { i64, [4 x i64] }, ptr %t83, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t85, i32 0, i32 2
  %t87 = load ptr, ptr %t86
  store ptr %t87, ptr %l5, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load ptr, ptr %l5, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Payload", ptr %t90, i32 0, i32 0
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t96 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ethroughDerived(ptr %v0, ptr %v1, ptr %t89, ptr %t93)
  store i1 %t96, ptr %l48
  br label %bb31
bb31:
  %t97 = load i1, ptr %l48, !tbaa !21
  store i1 %t97, ptr %l6, !tbaa !21
  br label %bb37
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_7f73b55f7a2eb5e4_273c44187eceff80)
  unreachable
bb37:
  %t98 = load i1, ptr %l6, !tbaa !21
  store i1 %t98, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etransient(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l4 = alloca i64
  %l5 = alloca i1
  %l11 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l12 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l28 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l33 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load i64, ptr %l1, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t10 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t6, i64 %t7)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t10, ptr %l11
  br label %bb4
bb4:
  %t11 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l11
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t11, ptr %l3
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/scope:Scoper", ptr %t12, i32 0, i32 93
  %t15 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l3
  %t18 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t14, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t15)
  %t19 = extractvalue { i32, i64 } %t18, 1
  %t20 = extractvalue { i32, i64 } %t18, 0
  store i32 %t20, ptr %l17
  %t21 = icmp ne i32 %t20, 0
  br i1 %t21, label %bb6, label %ok.22, !prof !99
ok.22:
  store i64 %t19, ptr %l16
  br label %bb5
bb5:
  %t23 = load i64, ptr %l16, !tbaa !24
  store i64 %t23, ptr %l12, !tbaa !24
  br label %bb8
bb6:
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l12, !tbaa !24
  br label %bb8
bb8:
  %t24 = load i64, ptr %l12, !tbaa !24
  store i64 %t24, ptr %l4, !tbaa !24
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = icmp ne i64 %t25, 0
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t29 = load i64, ptr %l4, !tbaa !24
  %t31 = icmp eq i64 %t29, 3
  call void @__olang_scope_close(ptr %s0)
  store i1 %t31, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/scope:Scoper", ptr %t33, i32 0, i32 93
  %t36 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l3
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %t35, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t36, i64 1)
  br label %bb12
bb12:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i64, ptr %l1, !tbaa !24
  %t41 = load i64, ptr %l2, !tbaa !24
  %t45 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etransientNow(ptr %v0, ptr %t39, i64 %t40, i64 %t41)
  store i1 %t45, ptr %l28
  br label %bb13
bb13:
  %t46 = load i1, ptr %l28, !tbaa !21
  store i1 %t46, ptr %l5, !tbaa !21
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/scope:Scoper", ptr %t47, i32 0, i32 93
  store ptr %t49, ptr %l30, !tbaa !29
  %t50 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l3
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t50, ptr %l31
  %t51 = load i1, ptr %l5, !tbaa !21
  br i1 %t51, label %bb14, label %bb15
bb14:
  store i64 3, ptr %l33, !tbaa !24
  br label %bb16
bb15:
  store i64 2, ptr %l33, !tbaa !24
  br label %bb16
bb16:
  %t53 = load ptr, ptr %l30, !tbaa !29
  %t54 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l31
  %t55 = load i64, ptr %l33, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %t53, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t54, i64 %t55)
  br label %bb17
bb17:
  %t56 = load i1, ptr %l5, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  store i1 %t56, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etransientNow(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca %"compiler/scope:rel"
  %l19 = alloca { i64, [2 x i64] }
  %l20 = alloca i64
  %l21 = alloca { i64, [2 x i64] }
  %l22 = alloca i64
  %l23 = alloca i32
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l41 = alloca ptr
  %l50 = alloca i1
  %l54 = alloca i1
  %l56 = alloca i1
  %l60 = alloca ptr
  %l64 = alloca i1
  %l65 = alloca i64
  %l68 = alloca i64
  %l78 = alloca i64
  %l81 = alloca i64
  %l88 = alloca { i64, ptr }
  %l94 = alloca i64
  %l97 = alloca i64
  %l128 = alloca ptr
  %l131 = alloca i64
  %l133 = alloca i64
  %l138 = alloca %"compiler/scope:rel"
  %l141 = alloca i1
  %l145 = alloca i1
  %l148 = alloca i1
  %l175 = alloca i32
  %l180 = alloca i32
  %l183 = alloca i64
  %l186 = alloca ptr
  %l191 = alloca i32
  %l192 = alloca { i64, ptr }
  %l198 = alloca i64
  %l201 = alloca i64
  %l224 = alloca i64
  %l232 = alloca i64
  %l236 = alloca i64
  %l239 = alloca i64
  %l260 = alloca i1
  %l266 = alloca i64
  %l269 = alloca i1
  %l273 = alloca i1
  %l282 = alloca i32
  %l284 = alloca ptr
  %l288 = alloca %"compiler/typed:Local"
  %l290 = alloca i1
  %l297 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l41
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l41, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 1
  %t12 = load { i64, [2 x i64] }, ptr %t11
  %t16 = extractvalue { i64, [2 x i64] } %t12, 0
  %t17 = icmp eq i64 %t16, 0
  br i1 %t17, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb9:
  call void @__olang_check_failed(ptr @olang_loc_a99f843f7bf434a0_94e1f929e5b915f4)
  unreachable
bb10:
  %t20 = load ptr, ptr %l3, !tbaa !29
  %t22 = getelementptr %"compiler/typed:Body", ptr %t20, i32 0, i32 11
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  br i1 %t25, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb14
bb12:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/scope:Scoper", ptr %t27, i32 0, i32 11
  %t30 = load i64, ptr %l1, !tbaa !24
  %t33 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t29, i64 %t30)
  store i1 %t33, ptr %l54
  br label %bb13
bb13:
  %t34 = load i1, ptr %l54, !tbaa !21
  %t35 = xor i1 %t34, true
  store i1 %t35, ptr %l50, !tbaa !21
  br label %bb14
bb14:
  %t37 = load i1, ptr %l50, !tbaa !21
  br i1 %t37, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb18
bb16:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/scope:Scoper", ptr %t38, i32 0, i32 6
  %t41 = load i64, ptr %l1, !tbaa !24
  %t44 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t40, i64 %t41)
  store ptr %t44, ptr %l60
  br label %bb17
bb17:
  %t45 = load ptr, ptr %l60, !tbaa !29
  %t47 = getelementptr %"compiler/scope:summary", ptr %t45, i32 0, i32 14
  %t48 = load i1, ptr %t47, !tbaa !21
  %t50 = xor i1 %t48, true
  store i1 %t50, ptr %l56, !tbaa !21
  br label %bb18
bb18:
  %t52 = load i1, ptr %l56, !tbaa !21
  br i1 %t52, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l64, !tbaa !21
  br label %bb22
bb20:
  %t53 = load i64, ptr %l2, !tbaa !24
  store i64 %t53, ptr %l65, !tbaa !24
  %t54 = load ptr, ptr %l3, !tbaa !29
  %t56 = getelementptr %"compiler/typed:Body", ptr %t54, i32 0, i32 5
  %t58 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t56)
  store i64 %t58, ptr %l68
  br label %bb21
bb21:
  %t59 = load i64, ptr %l65, !tbaa !24
  %t60 = load i64, ptr %l68, !tbaa !24
  %t61 = icmp sge i64 %t59, %t60
  store i1 %t61, ptr %l64, !tbaa !21
  br label %bb22
bb22:
  %t63 = load i1, ptr %l64, !tbaa !21
  br i1 %t63, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t65 = load ptr, ptr %l3, !tbaa !29
  %t67 = getelementptr %"compiler/typed:Body", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %t67, !tbaa !23
  store i32 %t68, ptr %l5, !tbaa !23
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/scope:Scoper", ptr %t70, i32 0, i32 0
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/generic:Program", ptr %t73, i32 0, i32 2
  %t76 = load i32, ptr %l5, !tbaa !23
  %t77 = load i64, ptr %l2, !tbaa !24
  %t81 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t75, i32 %t76, i64 %t77)
  store i64 %t81, ptr %l78
  br label %bb26
bb26:
  %t82 = load i64, ptr %l78, !tbaa !24
  store i64 %t82, ptr %l6, !tbaa !24
  %t83 = load i64, ptr %l6, !tbaa !24
  %t85 = icmp sge i64 %t83, 0
  br i1 %t85, label %bb27, label %bb28
bb27:
  %t87 = load i64, ptr %l6, !tbaa !24
  store i64 %t87, ptr %l81, !tbaa !24
  br label %bb29
bb28:
  %t89 = load i64, ptr %l2, !tbaa !24
  store i64 %t89, ptr %l81, !tbaa !24
  br label %bb29
bb29:
  %t91 = load i64, ptr %l81, !tbaa !24
  store i64 %t91, ptr %l7, !tbaa !24
  store i64 -1, ptr %l8, !tbaa !24
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/scope:Scoper", ptr %t92, i32 0, i32 0
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = getelementptr %"compiler/generic:Program", ptr %t95, i32 0, i32 2
  %t98 = load i32, ptr %l5, !tbaa !23
  %t101 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t97, i32 %t98)
  store { i64, ptr } %t101, ptr %l88
  br label %bb30
bb30:
  %t102 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t102, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t103 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t103, 0
  store i64 %t105, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t107 = load i64, ptr %l11, !tbaa !24
  %t108 = load i64, ptr %l10, !tbaa !24
  %t111 = icmp sgt i64 %t107, %t108
  br i1 %t111, label %bb31, label %bb32
bb31:
  %t113 = load i64, ptr %l12, !tbaa !24
  %t115 = icmp sgt i64 %t113, 0
  br i1 %t115, label %bb33, label %bb34
bb32:
  store i64 0, ptr %l94, !tbaa !24
  br label %bb36
bb33:
  %t117 = load i64, ptr %l11, !tbaa !24
  %t118 = load i64, ptr %l10, !tbaa !24
  %t121 = sub i64 %t117, %t118
  %t122 = load i64, ptr %l12, !tbaa !24
  %t125 = add i64 %t121, %t122
  %t127 = sub i64 %t125, 1
  %t128 = load i64, ptr %l12, !tbaa !24
  %t131 = sdiv i64 %t127, %t128
  store i64 %t131, ptr %l97, !tbaa !24
  br label %bb35
bb34:
  store i64 0, ptr %l97, !tbaa !24
  br label %bb35
bb35:
  %t133 = load i64, ptr %l97, !tbaa !24
  store i64 %t133, ptr %l94, !tbaa !24
  br label %bb36
bb36:
  %t134 = load i64, ptr %l94, !tbaa !24
  store i64 %t134, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb37
bb37:
  %t135 = load i64, ptr %l14, !tbaa !24
  %t136 = load i64, ptr %l13, !tbaa !24
  %t139 = icmp slt i64 %t135, %t136
  %t141 = xor i1 %t139, true
  br i1 %t141, label %bb38, label %bb39
bb38:
  br label %bb45
bb39:
  br label %bb40
bb40:
  %t143 = load i64, ptr %l10, !tbaa !24
  %t144 = load i64, ptr %l14, !tbaa !24
  %t145 = load i64, ptr %l12, !tbaa !24
  %t148 = mul i64 %t144, %t145
  %t151 = add i64 %t143, %t148
  store i64 %t151, ptr %l15, !tbaa !24
  %t153 = load i64, ptr %l15, !tbaa !24
  %t155 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !27
  %t157 = getelementptr i64, ptr %t156, i64 %t153
  %t158 = load i64, ptr %t157, !tbaa !34
  %t159 = load i64, ptr %l7, !tbaa !24
  %t162 = icmp eq i64 %t158, %t159
  br i1 %t162, label %bb41, label %bb42
bb41:
  %t164 = load i64, ptr %l15, !tbaa !24
  store i64 %t164, ptr %l8, !tbaa !24
  br label %bb43
bb42:
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t166 = load i64, ptr %l14, !tbaa !24
  %t168 = add i64 %t166, 1
  store i64 %t168, ptr %l14, !tbaa !24
  br label %bb37
bb45:
  %t170 = load i64, ptr %l8, !tbaa !24
  %t172 = icmp slt i64 %t170, 0
  br i1 %t172, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/scope:Scoper", ptr %t175, i32 0, i32 6
  %t178 = load i64, ptr %l1, !tbaa !24
  %t181 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t177, i64 %t178)
  store ptr %t181, ptr %l128
  br label %bb49
bb49:
  %t182 = load ptr, ptr %l128, !tbaa !29
  %t184 = getelementptr %"compiler/scope:summary", ptr %t182, i32 0, i32 0
  store ptr %t184, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb50
bb50:
  %t186 = load i64, ptr %l17, !tbaa !24
  store i64 %t186, ptr %l131, !tbaa !24
  %t187 = load ptr, ptr %l16, !tbaa !29
  %t189 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t187)
  store i64 %t189, ptr %l133
  br label %bb51
bb51:
  %t190 = load i64, ptr %l131, !tbaa !24
  %t191 = load i64, ptr %l133, !tbaa !24
  %t192 = icmp slt i64 %t190, %t191
  %t194 = xor i1 %t192, true
  br i1 %t194, label %bb52, label %bb53
bb52:
  br label %bb93
bb53:
  br label %bb54
bb54:
  %t196 = load ptr, ptr %l16, !tbaa !29
  %t197 = load i64, ptr %l17, !tbaa !24
  %t200 = call %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t196, i64 %t197)
  store %"compiler/scope:rel" %t200, ptr %l138
  br label %bb55
bb55:
  %t201 = load %"compiler/scope:rel", ptr %l138
  store %"compiler/scope:rel" %t201, ptr %l18
  %t202 = getelementptr %"compiler/scope:rel", ptr %l18, i32 0, i32 0
  %t203 = load { i64, [2 x i64] }, ptr %t202
  %t205 = extractvalue { i64, [2 x i64] } %t203, 0
  %t206 = icmp eq i64 %t205, 2
  br i1 %t206, label %bb56, label %bb57
bb56:
  %t208 = getelementptr %"compiler/scope:rel", ptr %l18, i32 0, i32 0
  %t209 = getelementptr { i64, [2 x i64] }, ptr %t208, i32 0, i32 1
  %t210 = getelementptr { i64 }, ptr %t209, i32 0, i32 0
  %t211 = load i64, ptr %t210
  %t212 = load i64, ptr %l8, !tbaa !24
  %t215 = icmp eq i64 %t211, %t212
  store i1 %t215, ptr %l141, !tbaa !21
  br label %bb58
bb57:
  store i1 false, ptr %l141, !tbaa !21
  br label %bb58
bb58:
  %t217 = load i1, ptr %l141, !tbaa !21
  br i1 %t217, label %bb59, label %bb60
bb59:
  store i1 true, ptr %l145, !tbaa !21
  br label %bb64
bb60:
  %t218 = getelementptr %"compiler/scope:rel", ptr %l18, i32 0, i32 1
  %t219 = load { i64, [2 x i64] }, ptr %t218
  %t221 = extractvalue { i64, [2 x i64] } %t219, 0
  %t222 = icmp eq i64 %t221, 2
  br i1 %t222, label %bb61, label %bb62
bb61:
  %t224 = getelementptr %"compiler/scope:rel", ptr %l18, i32 0, i32 1
  %t225 = getelementptr { i64, [2 x i64] }, ptr %t224, i32 0, i32 1
  %t226 = getelementptr { i64 }, ptr %t225, i32 0, i32 0
  %t227 = load i64, ptr %t226
  %t228 = load i64, ptr %l8, !tbaa !24
  %t231 = icmp eq i64 %t227, %t228
  store i1 %t231, ptr %l148, !tbaa !21
  br label %bb63
bb62:
  store i1 false, ptr %l148, !tbaa !21
  br label %bb63
bb63:
  %t233 = load i1, ptr %l148, !tbaa !21
  store i1 %t233, ptr %l145, !tbaa !21
  br label %bb64
bb64:
  %t234 = load i1, ptr %l145, !tbaa !21
  br i1 %t234, label %bb65, label %bb66
bb65:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb66:
  br label %bb67
bb67:
  %t236 = getelementptr %"compiler/scope:rel", ptr %l18, i32 0, i32 0
  %t237 = load { i64, [2 x i64] }, ptr %t236
  store { i64, [2 x i64] } %t237, ptr %l19
  %t239 = load { i64, [2 x i64] }, ptr %l19
  %t241 = extractvalue { i64, [2 x i64] } %t239, 0
  %t242 = icmp eq i64 %t241, 4
  br i1 %t242, label %bb68, label %bb69
bb68:
  %t244 = getelementptr { i64, [2 x i64] }, ptr %l19, i32 0, i32 1
  %t245 = getelementptr { i64, i64 }, ptr %t244, i32 0, i32 0
  %t246 = load i64, ptr %t245
  store i64 %t246, ptr %l20, !tbaa !24
  br label %bb70
bb69:
  br label %bb74
bb70:
  %t248 = load i64, ptr %l20, !tbaa !24
  %t249 = load i64, ptr %l2, !tbaa !24
  %t252 = icmp eq i64 %t248, %t249
  br i1 %t252, label %bb71, label %bb72
bb71:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb72:
  br label %bb73
bb73:
  br label %bb79
bb74:
  br i1 true, label %bb75, label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb78
bb77:
  br label %bb79
bb78:
  call void @__olang_check_failed(ptr @olang_loc_4aed99841ab3b8b1_8d3edbdcac983025)
  unreachable
bb79:
  %t255 = getelementptr %"compiler/scope:rel", ptr %l18, i32 0, i32 1
  %t256 = load { i64, [2 x i64] }, ptr %t255
  store { i64, [2 x i64] } %t256, ptr %l21
  %t258 = load { i64, [2 x i64] }, ptr %l21
  %t260 = extractvalue { i64, [2 x i64] } %t258, 0
  %t261 = icmp eq i64 %t260, 4
  br i1 %t261, label %bb80, label %bb81
bb80:
  %t263 = getelementptr { i64, [2 x i64] }, ptr %l21, i32 0, i32 1
  %t264 = getelementptr { i64, i64 }, ptr %t263, i32 0, i32 0
  %t265 = load i64, ptr %t264
  store i64 %t265, ptr %l22, !tbaa !24
  br label %bb82
bb81:
  br label %bb86
bb82:
  %t267 = load i64, ptr %l22, !tbaa !24
  %t268 = load i64, ptr %l2, !tbaa !24
  %t271 = icmp eq i64 %t267, %t268
  br i1 %t271, label %bb83, label %bb84
bb83:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb84:
  br label %bb85
bb85:
  br label %bb91
bb86:
  br i1 true, label %bb87, label %bb88
bb87:
  br label %bb89
bb88:
  br label %bb90
bb89:
  br label %bb91
bb90:
  call void @__olang_check_failed(ptr @olang_loc_c7fdd76f48c1d89a_56d68a9de61a546e)
  unreachable
bb91:
  br label %bb92
bb92:
  %t274 = load i64, ptr %l17, !tbaa !24
  %t276 = add i64 %t274, 1
  store i64 %t276, ptr %l17, !tbaa !24
  br label %bb50
bb93:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr %"compiler/scope:Scoper", ptr %t278, i32 0, i32 0
  %t281 = load ptr, ptr %t280, !tbaa !29
  %t283 = getelementptr %"compiler/generic:Program", ptr %t281, i32 0, i32 2
  %t284 = load i32, ptr %l5, !tbaa !23
  %t287 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t283, i32 %t284)
  store i32 %t287, ptr %l175
  br label %bb94
bb94:
  %t288 = load i32, ptr %l175, !tbaa !23
  store i32 %t288, ptr %l23, !tbaa !23
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t291 = getelementptr %"compiler/scope:Scoper", ptr %t289, i32 0, i32 0
  %t292 = load ptr, ptr %t291, !tbaa !29
  %t294 = getelementptr %"compiler/generic:Program", ptr %t292, i32 0, i32 2
  %t295 = load i32, ptr %l23, !tbaa !23
  %t298 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t294, i32 %t295)
  store i32 %t298, ptr %l180
  br label %bb95
bb95:
  %t299 = load i32, ptr %l180, !range !{i32 0, i32 33}
  %t301 = trunc i64 22 to i32
  %t302 = icmp eq i32 %t299, %t301
  br i1 %t302, label %bb96, label %bb97
bb96:
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t306 = getelementptr %"compiler/scope:Scoper", ptr %t304, i32 0, i32 0
  %t307 = load ptr, ptr %t306, !tbaa !29
  %t309 = getelementptr %"compiler/generic:Program", ptr %t307, i32 0, i32 2
  store ptr %t309, ptr %l186, !tbaa !29
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t312 = getelementptr %"compiler/scope:Scoper", ptr %t310, i32 0, i32 0
  %t313 = load ptr, ptr %t312, !tbaa !29
  %t315 = getelementptr %"compiler/generic:Program", ptr %t313, i32 0, i32 2
  %t316 = load i32, ptr %l23, !tbaa !23
  %t319 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t315, i32 %t316)
  store i32 %t319, ptr %l191
  br label %bb98
bb97:
  store i64 1, ptr %l183, !tbaa !24
  br label %bb100
bb98:
  %t320 = load ptr, ptr %l186, !tbaa !29
  %t321 = load i32, ptr %l191, !tbaa !23
  %t322 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t320, i32 %t321)
  store { i64, ptr } %t322, ptr %l192
  br label %bb99
bb99:
  %t323 = load { i64, ptr }, ptr %l192, !tbaa !27
  %t324 = extractvalue { i64, ptr } %t323, 0
  store i64 %t324, ptr %l183, !tbaa !24
  br label %bb100
bb100:
  %t326 = load i64, ptr %l183, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  store i64 %t326, ptr %l26, !tbaa !24
  store i64 1, ptr %l27, !tbaa !24
  %t329 = load i64, ptr %l26, !tbaa !24
  %t330 = load i64, ptr %l25, !tbaa !24
  %t333 = icmp sgt i64 %t329, %t330
  br i1 %t333, label %bb101, label %bb102
bb101:
  %t335 = load i64, ptr %l27, !tbaa !24
  %t337 = icmp sgt i64 %t335, 0
  br i1 %t337, label %bb103, label %bb104
bb102:
  store i64 0, ptr %l198, !tbaa !24
  br label %bb106
bb103:
  %t339 = load i64, ptr %l26, !tbaa !24
  %t340 = load i64, ptr %l25, !tbaa !24
  %t343 = sub i64 %t339, %t340
  %t344 = load i64, ptr %l27, !tbaa !24
  %t347 = add i64 %t343, %t344
  %t349 = sub i64 %t347, 1
  %t350 = load i64, ptr %l27, !tbaa !24
  %t353 = sdiv i64 %t349, %t350
  store i64 %t353, ptr %l201, !tbaa !24
  br label %bb105
bb104:
  store i64 0, ptr %l201, !tbaa !24
  br label %bb105
bb105:
  %t355 = load i64, ptr %l201, !tbaa !24
  store i64 %t355, ptr %l198, !tbaa !24
  br label %bb106
bb106:
  %t356 = load i64, ptr %l198, !tbaa !24
  store i64 %t356, ptr %l28, !tbaa !24
  store i64 0, ptr %l29, !tbaa !24
  br label %bb107
bb107:
  %t357 = load i64, ptr %l29, !tbaa !24
  %t358 = load i64, ptr %l28, !tbaa !24
  %t361 = icmp slt i64 %t357, %t358
  %t363 = xor i1 %t361, true
  br i1 %t363, label %bb108, label %bb109
bb108:
  br label %bb116
bb109:
  br label %bb110
bb110:
  %t365 = load i64, ptr %l25, !tbaa !24
  %t366 = load i64, ptr %l29, !tbaa !24
  %t367 = load i64, ptr %l27, !tbaa !24
  %t370 = mul i64 %t366, %t367
  %t373 = add i64 %t365, %t370
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t377 = getelementptr %"compiler/scope:Scoper", ptr %t375, i32 0, i32 0
  %t378 = load ptr, ptr %t377, !tbaa !29
  %t380 = getelementptr %"compiler/generic:Program", ptr %t378, i32 0, i32 2
  %t381 = load i32, ptr %l5, !tbaa !23
  %t386 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t380, i32 %t381, i64 %t373)
  store i64 %t386, ptr %l224
  br label %bb111
bb111:
  %t387 = load i64, ptr %l7, !tbaa !24
  %t388 = load i64, ptr %l224, !tbaa !24
  %t390 = icmp eq i64 %t388, %t387
  br i1 %t390, label %bb112, label %bb113
bb112:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb113:
  br label %bb114
bb114:
  br label %bb115
bb115:
  %t393 = load i64, ptr %l29, !tbaa !24
  %t395 = add i64 %t393, 1
  store i64 %t395, ptr %l29, !tbaa !24
  br label %bb107
bb116:
  store i64 0, ptr %l31, !tbaa !24
  %t397 = load ptr, ptr %l3, !tbaa !29
  %t399 = getelementptr %"compiler/typed:Body", ptr %t397, i32 0, i32 5
  %t401 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t399)
  store i64 %t401, ptr %l232
  br label %bb117
bb117:
  %t402 = load i64, ptr %l232, !tbaa !24
  store i64 %t402, ptr %l32, !tbaa !24
  store i64 1, ptr %l33, !tbaa !24
  %t403 = load i64, ptr %l32, !tbaa !24
  %t404 = load i64, ptr %l31, !tbaa !24
  %t407 = icmp sgt i64 %t403, %t404
  br i1 %t407, label %bb118, label %bb119
bb118:
  %t409 = load i64, ptr %l33, !tbaa !24
  %t411 = icmp sgt i64 %t409, 0
  br i1 %t411, label %bb120, label %bb121
bb119:
  store i64 0, ptr %l236, !tbaa !24
  br label %bb123
bb120:
  %t413 = load i64, ptr %l32, !tbaa !24
  %t414 = load i64, ptr %l31, !tbaa !24
  %t417 = sub i64 %t413, %t414
  %t418 = load i64, ptr %l33, !tbaa !24
  %t421 = add i64 %t417, %t418
  %t423 = sub i64 %t421, 1
  %t424 = load i64, ptr %l33, !tbaa !24
  %t427 = sdiv i64 %t423, %t424
  store i64 %t427, ptr %l239, !tbaa !24
  br label %bb122
bb121:
  store i64 0, ptr %l239, !tbaa !24
  br label %bb122
bb122:
  %t429 = load i64, ptr %l239, !tbaa !24
  store i64 %t429, ptr %l236, !tbaa !24
  br label %bb123
bb123:
  %t430 = load i64, ptr %l236, !tbaa !24
  store i64 %t430, ptr %l34, !tbaa !24
  store i64 0, ptr %l35, !tbaa !24
  br label %bb124
bb124:
  %t431 = load i64, ptr %l35, !tbaa !24
  %t432 = load i64, ptr %l34, !tbaa !24
  %t435 = icmp slt i64 %t431, %t432
  %t437 = xor i1 %t435, true
  br i1 %t437, label %bb125, label %bb126
bb125:
  br label %bb142
bb126:
  br label %bb127
bb127:
  %t439 = load i64, ptr %l31, !tbaa !24
  %t440 = load i64, ptr %l35, !tbaa !24
  %t441 = load i64, ptr %l33, !tbaa !24
  %t444 = mul i64 %t440, %t441
  %t447 = add i64 %t439, %t444
  store i64 %t447, ptr %l36, !tbaa !24
  %t449 = load i64, ptr %l36, !tbaa !24
  %t450 = load i64, ptr %l2, !tbaa !24
  %t453 = icmp ne i64 %t449, %t450
  br i1 %t453, label %bb128, label %bb129
bb128:
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t457 = getelementptr %"compiler/scope:Scoper", ptr %t455, i32 0, i32 0
  %t458 = load ptr, ptr %t457, !tbaa !29
  %t460 = getelementptr %"compiler/generic:Program", ptr %t458, i32 0, i32 2
  %t461 = load i32, ptr %l5, !tbaa !23
  %t462 = load i64, ptr %l36, !tbaa !24
  %t466 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t460, i32 %t461, i64 %t462)
  store i64 %t466, ptr %l266
  br label %bb130
bb129:
  store i1 false, ptr %l260, !tbaa !21
  br label %bb137
bb130:
  %t467 = load i64, ptr %l7, !tbaa !24
  %t468 = load i64, ptr %l266, !tbaa !24
  %t470 = icmp eq i64 %t468, %t467
  br i1 %t470, label %bb131, label %bb132
bb131:
  store i1 true, ptr %l269, !tbaa !21
  br label %bb136
bb132:
  %t472 = load i64, ptr %l36, !tbaa !24
  %t473 = load i64, ptr %l7, !tbaa !24
  %t476 = icmp eq i64 %t472, %t473
  br i1 %t476, label %bb133, label %bb134
bb133:
  %t478 = load i64, ptr %l6, !tbaa !24
  %t480 = icmp sge i64 %t478, 0
  store i1 %t480, ptr %l273, !tbaa !21
  br label %bb135
bb134:
  store i1 false, ptr %l273, !tbaa !21
  br label %bb135
bb135:
  %t482 = load i1, ptr %l273, !tbaa !21
  store i1 %t482, ptr %l269, !tbaa !21
  br label %bb136
bb136:
  %t483 = load i1, ptr %l269, !tbaa !21
  store i1 %t483, ptr %l260, !tbaa !21
  br label %bb137
bb137:
  %t484 = load i1, ptr %l260, !tbaa !21
  br i1 %t484, label %bb138, label %bb139
bb138:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb139:
  br label %bb140
bb140:
  br label %bb141
bb141:
  %t486 = load i64, ptr %l35, !tbaa !24
  %t488 = add i64 %t486, 1
  store i64 %t488, ptr %l35, !tbaa !24
  br label %bb124
bb142:
  %t490 = load ptr, ptr %l3, !tbaa !29
  %t492 = getelementptr %"compiler/typed:Body", ptr %t490, i32 0, i32 5
  %t493 = load i64, ptr %l2, !tbaa !24
  %t496 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t492, i64 %t493)
  store i32 %t496, ptr %l282
  br label %bb143
bb143:
  %t497 = load i32, ptr %l282, !tbaa !23
  %t498 = sext i32 %t497 to i64
  store i64 %t498, ptr %l37, !tbaa !24
  %t500 = load ptr, ptr %l0, !tbaa !29
  store ptr %t500, ptr %l284, !tbaa !29
  %t501 = load ptr, ptr %l3, !tbaa !29
  %t503 = getelementptr %"compiler/typed:Body", ptr %t501, i32 0, i32 7
  %t504 = load i64, ptr %l37, !tbaa !24
  %t507 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t503, i64 %t504)
  store %"compiler/typed:Local" %t507, ptr %l288
  br label %bb144
bb144:
  %t508 = getelementptr %"compiler/typed:Local", ptr %l288, i32 0, i32 2
  %t509 = load i32, ptr %t508, !tbaa !23
  %t510 = load ptr, ptr %l284, !tbaa !29
  %t512 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFunc(ptr %v0, ptr %t510, i32 %t509)
  store i1 %t512, ptr %l290
  br label %bb145
bb145:
  %t513 = load i1, ptr %l290, !tbaa !21
  %t514 = xor i1 %t513, true
  br i1 %t514, label %bb146, label %bb147
bb146:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb147:
  br label %bb148
bb148:
  %t517 = load ptr, ptr %l0, !tbaa !29
  %t518 = load ptr, ptr %l3, !tbaa !29
  %t520 = getelementptr %"compiler/typed:Body", ptr %t518, i32 0, i32 11
  %t521 = load ptr, ptr %t520, !tbaa !29
  %t522 = load i64, ptr %l37, !tbaa !24
  %t526 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eocBlock(ptr %v0, ptr %v0, ptr %t517, ptr %t521, i64 %t522, i1 true)
  store i1 %t526, ptr %l297
  br label %bb149
bb149:
  call void @__olang_scope_close(ptr %s0)
  %t527 = load i1, ptr %l297, !tbaa !21
  store i1 %t527, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etryDefault(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i1
  %l21 = alloca { i64, ptr }
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 14
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb15
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Try", ptr %t16, i32 0, i32 1
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  store { i64, ptr } %t19, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l5, !tbaa !24
  br label %bb6
bb6:
  %t25 = load i64, ptr %l4, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb7, label %bb8
bb7:
  br label %bb14
bb8:
  br label %bb9
bb9:
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t33, ptr %l21, !tbaa !27
  %t34 = load i64, ptr %l4, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr ptr, ptr %t37, i64 %t34
  %t39 = load ptr, ptr %t38, !tbaa !39
  %t43 = getelementptr %"compiler/typed:Clause", ptr %t39, i32 0, i32 4
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t48 = icmp sgt i64 %t46, 0
  br i1 %t48, label %bb10, label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t51 = load i64, ptr %l4, !tbaa !24
  %t53 = add i64 %t51, 1
  store i64 %t53, ptr %l4, !tbaa !24
  br label %bb6
bb14:
  br label %bb20
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_3af8b11586f6b4c8_66242c1d15d5a764)
  unreachable
bb20:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExprs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l16 = alloca { i64, ptr }
  %l25 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a2, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l7, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l7, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t15, ptr %l16, !tbaa !27
  %t16 = load i64, ptr %l6, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  %t34 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %t21, i64 %a3, i64 %a4)
  store i1 %t34, ptr %l25
  br label %bb5
bb5:
  %t35 = load i1, ptr %l25, !tbaa !21
  %t36 = xor i1 %t35, true
  br i1 %t36, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l6, !tbaa !24
  %t41 = add i64 %t39, 1
  store i64 %t41, ptr %l6, !tbaa !24
  br label %bb1
bb10:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evarName(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, [1 x i64] } %a2, ptr %a3) #0 {
entry:
  %l2 = alloca { i64, [1 x i64] }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store { i64, [1 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [1 x i64] }, ptr %l2
  %t3 = extractvalue { i64, [1 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [1 x i64] }, ptr %l2, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l4, !tbaa !23
  br label %bb5
bb2:
  %t10 = load { i64, [1 x i64] }, ptr %l2
  %t12 = extractvalue { i64, [1 x i64] } %t10, 0
  %t13 = icmp eq i64 %t12, 4
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = getelementptr { i64, [1 x i64] }, ptr %l2, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  store i32 %t17, ptr %l4, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t21 = load i32, ptr %l4, !tbaa !23
  %t27 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elocalName(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i32 %t21, ptr %a3)
  store { i64, ptr } %t27, ptr %l16
  br label %bb6
bb6:
  %t28 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t28, ptr %l5, !tbaa !27
  br label %bb20
bb7:
  %t29 = load { i64, [1 x i64] }, ptr %l2
  %t31 = extractvalue { i64, [1 x i64] } %t29, 0
  %t32 = icmp eq i64 %t31, 1
  br i1 %t32, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %l19, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t34, ptr %l5, !tbaa !27
  br label %bb20
bb11:
  %t36 = load { i64, [1 x i64] }, ptr %l2
  %t38 = extractvalue { i64, [1 x i64] } %t36, 0
  %t39 = icmp eq i64 %t38, 2
  br i1 %t39, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l23, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t41, ptr %l5, !tbaa !27
  br label %bb20
bb15:
  %t43 = load { i64, [1 x i64] }, ptr %l2
  %t45 = extractvalue { i64, [1 x i64] } %t43, 0
  %t46 = icmp eq i64 %t45, 3
  br i1 %t46, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  store { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d17, i32 0, i32 1) }, ptr %l27, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t48, ptr %l5, !tbaa !27
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_33e8f6984fda8b38_987c5f6a5f702884)
  unreachable
bb20:
  %t50 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t50, 0
  store i64 %t51, ptr %l29, !tbaa !24
  %t52 = load i64, ptr %l29, !tbaa !24
  %t53 = mul i64 %t52, 1
  %t54 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t53)
  %t55 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t54, 1
  store { i64, ptr } %t56, ptr %l30, !tbaa !27
  %t57 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = load i64, ptr %l29, !tbaa !24
  %t62 = mul i64 %t61, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t58, ptr %t60, i64 %t62, i1 false)
  %t63 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t63, ptr %l5, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t64, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewhereLives(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, [2 x i64] }
  %l7 = alloca { i64, [2 x i64] }
  %l16 = alloca { i64, [2 x i64] }
  %rv = alloca { i64, [2 x i64] }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 31
  %t4 = load i32, ptr %l1, !tbaa !23
  %t6 = sext i32 %t4 to i64
  %t9 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t3, i64 %t6)
  store { i64, [2 x i64] } %t9, ptr %l7
  br label %bb1
bb1:
  %t10 = load { i64, [2 x i64] }, ptr %l7
  store { i64, [2 x i64] } %t10, ptr %l2
  %t11 = load { i64, [2 x i64] }, ptr %l2
  %t13 = extractvalue { i64, [2 x i64] } %t11, 0
  %t14 = icmp eq i64 %t13, 0
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t18, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/scope:Scoper", ptr %t20, i32 0, i32 32
  %t23 = load i32, ptr %l1, !tbaa !23
  %t25 = sext i32 %t23 to i64
  %t28 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t22, i64 %t25)
  store { i64, [2 x i64] } %t28, ptr %l16
  br label %bb5
bb5:
  %t29 = load { i64, [2 x i64] }, ptr %l16
  store { i64, [2 x i64] } %t29, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewrittenCopy(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i1 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca %"compiler/source:Span"
  %l22 = alloca { i64, ptr }
  %l27 = alloca %"compiler/source:Span"
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca i1
  %l42 = alloca ptr
  %l46 = alloca i1
  %l49 = alloca i1
  %l50 = alloca i1
  %l53 = alloca i1
  %l55 = alloca i32
  %l59 = alloca %"compiler/source:Span"
  %l60 = alloca ptr
  %l61 = alloca i1
  %l67 = alloca ptr
  %l74 = alloca i1
  %l77 = alloca i1
  %l78 = alloca i1
  %l81 = alloca i1
  %l83 = alloca i32
  %l84 = alloca ptr
  %l85 = alloca i1
  %l90 = alloca %"compiler/source:Span"
  %l91 = alloca ptr
  %l93 = alloca %"compiler/source:Span"
  %l94 = alloca %"compiler/source:Span"
  %l97 = alloca i1
  %l99 = alloca i1
  %l101 = alloca i1
  %l106 = alloca %"compiler/source:Span"
  %l113 = alloca ptr
  %l114 = alloca i1
  %l120 = alloca i1
  %l126 = alloca i1
  %l129 = alloca i1
  %l132 = alloca i1
  %l135 = alloca i1
  %l136 = alloca i1
  %l142 = alloca i1
  %l143 = alloca ptr
  %l144 = alloca %"compiler/source:Span"
  %l146 = alloca i1
  %l148 = alloca i1
  %l151 = alloca %"compiler/msgs:Msg"
  %l152 = alloca %"compiler/msgs:Msg"
  %l153 = alloca %"compiler/msgs:Msg"
  %l154 = alloca i64
  %l157 = alloca i1
  %l160 = alloca i1
  %l163 = alloca i1
  %l166 = alloca i1
  %l169 = alloca ptr
  %l170 = alloca i1
  %l175 = alloca %"compiler/source:Span"
  %l177 = alloca ptr
  %l184 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l185 = alloca %"compiler/source:Span"
  %l186 = alloca i32
  %l187 = alloca %"compiler/source:Span"
  %l190 = alloca ptr
  %l191 = alloca i64
  %l196 = alloca ptr
  %l198 = alloca i64
  %l199 = alloca %"compiler/source:Span"
  %l200 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l22, !tbaa !27
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr ptr, ptr %t8, i64 %t5
  %t10 = load ptr, ptr %t9, !tbaa !39
  store ptr %t10, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  %t12 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t12, ptr %l7, !tbaa !23
  %t14 = load ptr, ptr %l5, !tbaa !29
  %t16 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t14)
  store %"compiler/source:Span" %t16, ptr %l27
  br label %bb1
bb1:
  %t17 = load %"compiler/source:Span", ptr %l27
  store %"compiler/source:Span" %t17, ptr %l8
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load ptr, ptr %l5, !tbaa !29
  %t23 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %t18, ptr %t19)
  store ptr %t23, ptr %l31
  br label %bb2
bb2:
  %t24 = load ptr, ptr %l31, !tbaa !29
  store ptr %t24, ptr %l9, !tbaa !29
  %t25 = load ptr, ptr %l9, !tbaa !29
  store ptr %t25, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t26 = load ptr, ptr %l32, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb3, label %bb4
bb3:
  %t29 = load ptr, ptr %l32, !tbaa !29
  %t30 = load i64, ptr %t29, !range !{i64 0, i64 18}
  %t32 = icmp eq i64 %t30, 5
  store i1 %t32, ptr %l33, !tbaa !21
  br label %bb4
bb4:
  %t33 = load i1, ptr %l33, !tbaa !21
  br i1 %t33, label %bb5, label %bb6
bb5:
  %t34 = load ptr, ptr %l9, !tbaa !29
  %t36 = getelementptr { i64, [5 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t36, i32 0, i32 2
  %t38 = load ptr, ptr %t37
  store ptr %t38, ptr %l10, !tbaa !29
  br label %bb7
bb6:
  br label %bb23
bb7:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load ptr, ptr %l10, !tbaa !29
  %t43 = getelementptr %"compiler/typed:Promote", ptr %t41, i32 0, i32 0
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t48 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %t40, ptr %t44)
  store ptr %t48, ptr %l42
  br label %bb8
bb8:
  %t49 = load ptr, ptr %l42, !tbaa !29
  store ptr %t49, ptr %l11, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load ptr, ptr %l11, !tbaa !29
  %t55 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eatCall(ptr %v0, ptr %v1, ptr %t50, ptr %t51)
  store i1 %t55, ptr %l46
  br label %bb9
bb9:
  %t56 = load i1, ptr %l46, !tbaa !21
  br i1 %t56, label %bb10, label %bb11
bb10:
  store i64 1, ptr %l6, !tbaa !24
  br label %bb20
bb11:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l11, !tbaa !29
  %t61 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etryDefault(ptr %v0, ptr %v1, ptr %t57, ptr %t58)
  store i1 %t61, ptr %l49
  br label %bb12
bb12:
  %t62 = load i1, ptr %l49, !tbaa !21
  br i1 %t62, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb16
bb14:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load ptr, ptr %l11, !tbaa !29
  %t67 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2echoiceOfPlaces(ptr %v0, ptr %v1, ptr %t63, ptr %t64)
  store i1 %t67, ptr %l53
  br label %bb15
bb15:
  %t68 = load i1, ptr %l53, !tbaa !21
  store i1 %t68, ptr %l50, !tbaa !21
  br label %bb16
bb16:
  %t69 = load i1, ptr %l50, !tbaa !21
  br i1 %t69, label %bb17, label %bb18
bb17:
  store i64 2, ptr %l6, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t70 = load ptr, ptr %l11, !tbaa !29
  %t72 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t70)
  store i32 %t72, ptr %l55
  br label %bb21
bb21:
  %t73 = load i32, ptr %l55, !tbaa !23
  store i32 %t73, ptr %l7, !tbaa !23
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load ptr, ptr %l11, !tbaa !29
  %t79 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eelemAt(ptr %v0, ptr %v1, ptr %t74, ptr %t75)
  store %"compiler/source:Span" %t79, ptr %l59
  br label %bb22
bb22:
  %t80 = load %"compiler/source:Span", ptr %l59
  store %"compiler/source:Span" %t80, ptr %l8
  br label %bb65
bb23:
  %t81 = load ptr, ptr %l9, !tbaa !29
  store ptr %t81, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t82 = load ptr, ptr %l60, !tbaa !29
  %t83 = icmp ne ptr %t82, null
  br i1 %t83, label %bb24, label %bb25
bb24:
  %t85 = load ptr, ptr %l60, !tbaa !29
  %t86 = load i64, ptr %t85, !range !{i64 0, i64 18}
  %t88 = icmp eq i64 %t86, 3
  store i1 %t88, ptr %l61, !tbaa !21
  br label %bb25
bb25:
  %t89 = load i1, ptr %l61, !tbaa !21
  br i1 %t89, label %bb26, label %bb27
bb26:
  %t90 = load ptr, ptr %l9, !tbaa !29
  %t92 = getelementptr { i64, [5 x i64] }, ptr %t90, i32 0, i32 1
  %t93 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t92, i32 0, i32 2
  %t94 = load ptr, ptr %t93
  store ptr %t94, ptr %l12, !tbaa !29
  br label %bb28
bb27:
  br label %bb60
bb28:
  %t96 = load ptr, ptr %l12, !tbaa !29
  %t98 = call ptr @compiler_2fscope_2etempOf(ptr %v1, ptr %t96)
  store ptr %t98, ptr %l67
  br label %bb29
bb29:
  %t99 = load ptr, ptr %l67, !tbaa !29
  store ptr %t99, ptr %l13, !tbaa !29
  %t100 = load ptr, ptr %l13, !tbaa !29
  %t102 = icmp eq ptr %t100, null
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb30, label %bb31
bb30:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load ptr, ptr %l13, !tbaa !29
  %t111 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eatCall(ptr %v0, ptr %v1, ptr %t106, ptr %t107)
  store i1 %t111, ptr %l74
  br label %bb32
bb31:
  br label %bb44
bb32:
  %t112 = load i1, ptr %l74, !tbaa !21
  br i1 %t112, label %bb33, label %bb34
bb33:
  store i64 1, ptr %l6, !tbaa !24
  br label %bb43
bb34:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load ptr, ptr %l13, !tbaa !29
  %t117 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etryDefault(ptr %v0, ptr %v1, ptr %t113, ptr %t114)
  store i1 %t117, ptr %l77
  br label %bb35
bb35:
  %t118 = load i1, ptr %l77, !tbaa !21
  br i1 %t118, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l78, !tbaa !21
  br label %bb39
bb37:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load ptr, ptr %l13, !tbaa !29
  %t123 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2echoiceOfPlaces(ptr %v0, ptr %v1, ptr %t119, ptr %t120)
  store i1 %t123, ptr %l81
  br label %bb38
bb38:
  %t124 = load i1, ptr %l81, !tbaa !21
  store i1 %t124, ptr %l78, !tbaa !21
  br label %bb39
bb39:
  %t125 = load i1, ptr %l78, !tbaa !21
  br i1 %t125, label %bb40, label %bb41
bb40:
  store i64 2, ptr %l6, !tbaa !24
  br label %bb42
bb41:
  br label %bb42
bb42:
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t126 = load ptr, ptr %l12, !tbaa !29
  %t128 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t126)
  store i32 %t128, ptr %l83
  br label %bb45
bb45:
  %t129 = load i32, ptr %l83, !tbaa !23
  store i32 %t129, ptr %l7, !tbaa !23
  %t130 = load ptr, ptr %l12, !tbaa !29
  store ptr %t130, ptr %l84, !tbaa !29
  store i1 false, ptr %l85, !tbaa !21
  %t131 = load ptr, ptr %l84, !tbaa !29
  %t132 = icmp ne ptr %t131, null
  br i1 %t132, label %bb46, label %bb47
bb46:
  %t134 = load ptr, ptr %l84, !tbaa !29
  %t135 = load i64, ptr %t134, !range !{i64 0, i64 8}
  %t137 = icmp eq i64 %t135, 6
  store i1 %t137, ptr %l85, !tbaa !21
  br label %bb47
bb47:
  %t138 = load i1, ptr %l85, !tbaa !21
  br i1 %t138, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load ptr, ptr %l13, !tbaa !29
  %t143 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eelemAt(ptr %v0, ptr %v1, ptr %t139, ptr %t140)
  store %"compiler/source:Span" %t143, ptr %l90
  br label %bb51
bb51:
  %t144 = load %"compiler/source:Span", ptr %l90
  store %"compiler/source:Span" %t144, ptr %l8
  br label %bb59
bb52:
  br i1 true, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb58
bb55:
  %t145 = load ptr, ptr %l0, !tbaa !29
  store ptr %t145, ptr %l91, !tbaa !29
  %t146 = load ptr, ptr %l12, !tbaa !29
  %t148 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v1, ptr %t146)
  store %"compiler/source:Span" %t148, ptr %l93
  br label %bb56
bb56:
  %t149 = load ptr, ptr %l91, !tbaa !29
  %t150 = load %"compiler/source:Span", ptr %l93
  %t151 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elastName(ptr %v0, ptr %t149, %"compiler/source:Span" %t150)
  store %"compiler/source:Span" %t151, ptr %l94
  br label %bb57
bb57:
  %t152 = load %"compiler/source:Span", ptr %l94
  store %"compiler/source:Span" %t152, ptr %l8
  br label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_dd80a499a713524_336e9d155656b240)
  unreachable
bb59:
  br label %bb65
bb60:
  br i1 true, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb65
bb64:
  call void @__olang_check_failed(ptr @olang_loc_56e16192221ba415_394443c36fbf1ad1)
  unreachable
bb65:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load i32, ptr %l7, !tbaa !23
  %t157 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisHandle(ptr %v0, ptr %t153, i32 %t154)
  store i1 %t157, ptr %l97
  br label %bb66
bb66:
  %t158 = load i1, ptr %l97, !tbaa !21
  store i1 %t158, ptr %l14, !tbaa !21
  %t159 = load i1, ptr %l3, !tbaa !21
  br i1 %t159, label %bb67, label %bb68
bb67:
  %t161 = load i1, ptr %l14, !tbaa !21
  store i1 %t161, ptr %l99, !tbaa !21
  br label %bb69
bb68:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb69
bb69:
  %t163 = load i1, ptr %l99, !tbaa !21
  br i1 %t163, label %bb70, label %bb71
bb70:
  %t164 = load i64, ptr %l6, !tbaa !24
  %t166 = icmp eq i64 %t164, 1
  store i1 %t166, ptr %l101, !tbaa !21
  br label %bb72
bb71:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb72
bb72:
  %t168 = load i1, ptr %l101, !tbaa !21
  br i1 %t168, label %bb73, label %bb74
bb73:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t173 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enameSpan(ptr %v0, ptr %t169, %"compiler/source:Span" %a4)
  store %"compiler/source:Span" %t173, ptr %l106
  br label %bb75
bb74:
  br label %bb76
bb75:
  %t174 = load %"compiler/source:Span", ptr %l106
  store %"compiler/source:Span" %t174, ptr %l8
  br label %bb76
bb76:
  %t175 = load i64, ptr %l6, !tbaa !24
  %t177 = icmp eq i64 %t175, 0
  br i1 %t177, label %bb77, label %bb78
bb77:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb78:
  br label %bb79
bb79:
  %t179 = load i1, ptr %l3, !tbaa !21
  %t181 = xor i1 %t179, true
  br i1 %t181, label %bb80, label %bb81
bb80:
  %t183 = load ptr, ptr %l1, !tbaa !29
  %t185 = getelementptr %"compiler/typed:Call", ptr %t183, i32 0, i32 0
  %t186 = load ptr, ptr %t185, !tbaa !29
  store ptr %t186, ptr %l15, !tbaa !29
  %t188 = load ptr, ptr %l15, !tbaa !29
  store ptr %t188, ptr %l113, !tbaa !29
  store i1 false, ptr %l114, !tbaa !21
  %t189 = load ptr, ptr %l113, !tbaa !29
  %t190 = icmp ne ptr %t189, null
  br i1 %t190, label %bb82, label %bb83
bb81:
  br label %bb114
bb82:
  %t192 = load ptr, ptr %l113, !tbaa !29
  %t193 = load i64, ptr %t192, !range !{i64 0, i64 5}
  %t195 = icmp eq i64 %t193, 0
  store i1 %t195, ptr %l114, !tbaa !21
  br label %bb83
bb83:
  %t196 = load i1, ptr %l114, !tbaa !21
  br i1 %t196, label %bb84, label %bb85
bb84:
  %t197 = load ptr, ptr %l15, !tbaa !29
  %t199 = getelementptr { i64, [3 x i64] }, ptr %t197, i32 0, i32 1
  %t200 = getelementptr { i32 }, ptr %t199, i32 0, i32 0
  %t201 = load i32, ptr %t200
  store i32 %t201, ptr %l16, !tbaa !23
  br label %bb86
bb85:
  br label %bb108
bb86:
  %t203 = load i1, ptr %l14, !tbaa !21
  br i1 %t203, label %bb87, label %bb88
bb87:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load i32, ptr %l16, !tbaa !23
  %t208 = sext i32 %t206 to i64
  %t209 = load i64, ptr %l2, !tbaa !24
  %t210 = load i64, ptr @G_2ecompiler_2fscope_2eUseThru, !tbaa !24
  %t215 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2euses(ptr %v0, ptr %t205, i64 %t208, i64 %t209, i64 %t210)
  store i1 %t215, ptr %l126
  br label %bb89
bb88:
  store i1 false, ptr %l120, !tbaa !21
  br label %bb90
bb89:
  %t216 = load i1, ptr %l126, !tbaa !21
  store i1 %t216, ptr %l120, !tbaa !21
  br label %bb90
bb90:
  %t217 = load i1, ptr %l120, !tbaa !21
  br i1 %t217, label %bb91, label %bb92
bb91:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb92:
  br label %bb93
bb93:
  %t218 = load i64, ptr %l6, !tbaa !24
  %t220 = icmp eq i64 %t218, 1
  br i1 %t220, label %bb94, label %bb95
bb94:
  %t222 = load i1, ptr %l14, !tbaa !21
  %t224 = xor i1 %t222, true
  store i1 %t224, ptr %l129, !tbaa !21
  br label %bb96
bb95:
  store i1 false, ptr %l129, !tbaa !21
  br label %bb96
bb96:
  %t226 = load i1, ptr %l129, !tbaa !21
  br i1 %t226, label %bb97, label %bb98
bb97:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load i32, ptr %l7, !tbaa !23
  %t231 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisStruct(ptr %v0, ptr %t227, i32 %t228)
  store i1 %t231, ptr %l135
  br label %bb99
bb98:
  store i1 false, ptr %l132, !tbaa !21
  br label %bb100
bb99:
  %t232 = load i1, ptr %l135, !tbaa !21
  store i1 %t232, ptr %l132, !tbaa !21
  br label %bb100
bb100:
  %t233 = load i1, ptr %l132, !tbaa !21
  br i1 %t233, label %bb101, label %bb102
bb101:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load i32, ptr %l16, !tbaa !23
  %t237 = sext i32 %t235 to i64
  %t238 = load i64, ptr %l2, !tbaa !24
  %t239 = load i64, ptr @G_2ecompiler_2fscope_2eUseView, !tbaa !24
  %t244 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2euses(ptr %v0, ptr %t234, i64 %t237, i64 %t238, i64 %t239)
  store i1 %t244, ptr %l142
  br label %bb103
bb102:
  store i1 false, ptr %l136, !tbaa !21
  br label %bb104
bb103:
  %t245 = load i1, ptr %l142, !tbaa !21
  store i1 %t245, ptr %l136, !tbaa !21
  br label %bb104
bb104:
  %t246 = load i1, ptr %l136, !tbaa !21
  br i1 %t246, label %bb105, label %bb106
bb105:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb106:
  br label %bb107
bb107:
  br label %bb113
bb108:
  br i1 true, label %bb109, label %bb110
bb109:
  br label %bb111
bb110:
  br label %bb112
bb111:
  br label %bb113
bb112:
  call void @__olang_check_failed(ptr @olang_loc_704f1e45d26fb2de_b63ff9ec5bfa803a)
  unreachable
bb113:
  br label %bb114
bb114:
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l143, !tbaa !29
  %t248 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t248, ptr %l144
  %t249 = load i1, ptr %l3, !tbaa !21
  br i1 %t249, label %bb115, label %bb116
bb115:
  %t251 = load i1, ptr %l14, !tbaa !21
  store i1 %t251, ptr %l146, !tbaa !21
  br label %bb117
bb116:
  store i1 false, ptr %l146, !tbaa !21
  br label %bb117
bb117:
  %t253 = load i1, ptr %l146, !tbaa !21
  br i1 %t253, label %bb118, label %bb119
bb118:
  %t254 = load i64, ptr %l6, !tbaa !24
  %t256 = icmp eq i64 %t254, 1
  store i1 %t256, ptr %l148, !tbaa !21
  br label %bb120
bb119:
  store i1 false, ptr %l148, !tbaa !21
  br label %bb120
bb120:
  %t258 = load i1, ptr %l148, !tbaa !21
  br i1 %t258, label %bb121, label %bb122
bb121:
  %t259 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnAtElement(ptr %s0)
  store %"compiler/msgs:Msg" %t259, ptr %l152
  br label %bb123
bb122:
  %t260 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eWriteThroughAtCall(ptr %s0)
  store %"compiler/msgs:Msg" %t260, ptr %l153
  br label %bb124
bb123:
  %t261 = load %"compiler/msgs:Msg", ptr %l152
  store %"compiler/msgs:Msg" %t261, ptr %l151
  br label %bb125
bb124:
  %t262 = load %"compiler/msgs:Msg", ptr %l153
  store %"compiler/msgs:Msg" %t262, ptr %l151
  br label %bb125
bb125:
  %t263 = load ptr, ptr %l143, !tbaa !29
  %t264 = load %"compiler/source:Span", ptr %l144
  %t265 = load %"compiler/msgs:Msg", ptr %l151
  %t266 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s0, ptr %t263, %"compiler/source:Span" %t264, %"compiler/msgs:Msg" %t265)
  store i64 %t266, ptr %l154
  br label %bb126
bb126:
  %t267 = load i64, ptr %l154, !tbaa !24
  store i64 %t267, ptr %l17, !tbaa !24
  %t268 = load i1, ptr %l3, !tbaa !21
  %t270 = xor i1 %t268, true
  br i1 %t270, label %bb127, label %bb128
bb127:
  %t272 = load i64, ptr %l6, !tbaa !24
  %t274 = icmp eq i64 %t272, 1
  store i1 %t274, ptr %l157, !tbaa !21
  br label %bb129
bb128:
  store i1 false, ptr %l157, !tbaa !21
  br label %bb129
bb129:
  %t276 = load i1, ptr %l157, !tbaa !21
  br i1 %t276, label %bb130, label %bb131
bb130:
  %t277 = load i1, ptr %l14, !tbaa !21
  %t279 = xor i1 %t277, true
  store i1 %t279, ptr %l160, !tbaa !21
  br label %bb132
bb131:
  store i1 false, ptr %l160, !tbaa !21
  br label %bb132
bb132:
  %t281 = load i1, ptr %l160, !tbaa !21
  br i1 %t281, label %bb133, label %bb134
bb133:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t283 = load i32, ptr %l7, !tbaa !23
  %t286 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisStruct(ptr %v0, ptr %t282, i32 %t283)
  store i1 %t286, ptr %l166
  br label %bb135
bb134:
  store i1 false, ptr %l163, !tbaa !21
  br label %bb136
bb135:
  %t287 = load i1, ptr %l166, !tbaa !21
  store i1 %t287, ptr %l163, !tbaa !21
  br label %bb136
bb136:
  %t288 = load i1, ptr %l163, !tbaa !21
  br i1 %t288, label %bb137, label %bb138
bb137:
  %t289 = load ptr, ptr %l1, !tbaa !29
  %t291 = getelementptr %"compiler/typed:Call", ptr %t289, i32 0, i32 0
  %t292 = load ptr, ptr %t291, !tbaa !29
  store ptr %t292, ptr %l18, !tbaa !29
  %t294 = load ptr, ptr %l18, !tbaa !29
  store ptr %t294, ptr %l169, !tbaa !29
  store i1 false, ptr %l170, !tbaa !21
  %t295 = load ptr, ptr %l169, !tbaa !29
  %t296 = icmp ne ptr %t295, null
  br i1 %t296, label %bb139, label %bb140
bb138:
  br label %bb162
bb139:
  %t298 = load ptr, ptr %l169, !tbaa !29
  %t299 = load i64, ptr %t298, !range !{i64 0, i64 5}
  %t301 = icmp eq i64 %t299, 0
  store i1 %t301, ptr %l170, !tbaa !21
  br label %bb140
bb140:
  %t302 = load i1, ptr %l170, !tbaa !21
  br i1 %t302, label %bb141, label %bb142
bb141:
  %t303 = load ptr, ptr %l18, !tbaa !29
  %t305 = getelementptr { i64, [3 x i64] }, ptr %t303, i32 0, i32 1
  %t306 = getelementptr { i32 }, ptr %t305, i32 0, i32 0
  %t307 = load i32, ptr %t306
  store i32 %t307, ptr %l19, !tbaa !23
  br label %bb143
bb142:
  br label %bb156
bb143:
  store %olang.scope zeroinitializer, ptr %s21
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t311 = getelementptr %"compiler/scope:Scoper", ptr %t309, i32 0, i32 95
  store ptr %t311, ptr %l177, !tbaa !29
  %t312 = load i32, ptr %l19, !tbaa !23
  %t314 = sext i32 %t312 to i64
  %t316 = mul i64 %t314, 4
  %t317 = load i64, ptr @G_2ecompiler_2fscope_2eUseView, !tbaa !24
  %t320 = add i64 %t316, %t317
  %t321 = load i64, ptr %l2, !tbaa !24
  %t324 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s21, i64 %t320, i64 %t321)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t324, ptr %l184
  br label %bb144
bb144:
  %t325 = load ptr, ptr %l177, !tbaa !29
  %t326 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l184
  %t327 = call { i32, %"compiler/source:Span" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H7d5384a5030fc995e793b3fe1f57e776(ptr %v0, ptr %t325, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t326)
  %t328 = extractvalue { i32, %"compiler/source:Span" } %t327, 1
  %t329 = extractvalue { i32, %"compiler/source:Span" } %t327, 0
  store i32 %t329, ptr %l186
  %t330 = icmp ne i32 %t329, 0
  br i1 %t330, label %bb146, label %ok.331, !prof !99
ok.331:
  store %"compiler/source:Span" %t328, ptr %l185
  br label %bb145
bb145:
  %t332 = load %"compiler/source:Span", ptr %l185
  store %"compiler/source:Span" %t332, ptr %l175
  br label %bb149
bb146:
  br label %bb147
bb147:
  call void @__olang_ert_req_clear()
  %t333 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s21, i32 0, i32 0)
  store %"compiler/source:Span" %t333, ptr %l187
  br label %bb148
bb148:
  %t334 = load %"compiler/source:Span", ptr %l187
  store %"compiler/source:Span" %t334, ptr %l175
  br label %bb149
bb149:
  %t335 = load %"compiler/source:Span", ptr %l175
  store %"compiler/source:Span" %t335, ptr %l20
  %t336 = getelementptr %"compiler/source:Span", ptr %l20, i32 0, i32 1
  %t337 = load i32, ptr %t336, !tbaa !23
  %t339 = icmp sgt i32 %t337, 0
  br i1 %t339, label %bb150, label %bb151
bb150:
  store %olang.scope zeroinitializer, ptr %s22
  %t341 = load ptr, ptr %l0, !tbaa !29
  store ptr %t341, ptr %l190, !tbaa !29
  %t342 = load i64, ptr %l17, !tbaa !24
  store i64 %t342, ptr %l191, !tbaa !24
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t345 = getelementptr %"compiler/scope:Scoper", ptr %t343, i32 0, i32 1
  %t346 = load i32, ptr %l19, !tbaa !23
  %t348 = sext i32 %t346 to i64
  %t351 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t345, i64 %t348)
  store ptr %t351, ptr %l196
  br label %bb152
bb151:
  br label %bb155
bb152:
  %t352 = load ptr, ptr %l196, !tbaa !29
  %t354 = getelementptr %"compiler/typed:Body", ptr %t352, i32 0, i32 3
  %t355 = load i64, ptr %t354, !tbaa !24
  store i64 %t355, ptr %l198, !tbaa !24
  %t356 = load %"compiler/source:Span", ptr %l20
  store %"compiler/source:Span" %t356, ptr %l199
  %t357 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteViewRefusedBy(ptr %s22)
  store %"compiler/msgs:Msg" %t357, ptr %l200
  br label %bb153
bb153:
  %t358 = load ptr, ptr %l190, !tbaa !29
  %t359 = load i64, ptr %l191, !tbaa !24
  %t360 = load i64, ptr %l198, !tbaa !24
  %t361 = load %"compiler/source:Span", ptr %l199
  %t362 = load %"compiler/msgs:Msg", ptr %l200
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enote(ptr %v0, ptr %s22, ptr %t358, i64 %t359, i64 %t360, %"compiler/source:Span" %t361, %"compiler/msgs:Msg" %t362)
  br label %bb154
bb154:
  call void @__olang_scope_close(ptr %s22)
  br label %bb155
bb155:
  call void @__olang_scope_close(ptr %s21)
  br label %bb161
bb156:
  br i1 true, label %bb157, label %bb158
bb157:
  br label %bb159
bb158:
  br label %bb160
bb159:
  br label %bb161
bb160:
  call void @__olang_check_failed(ptr @olang_loc_8ccf378ebead7f5f_f5ae40f475d40cbb)
  unreachable
bb161:
  br label %bb162
bb162:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRelatable({ i64, [2 x i64] } %a0) #0 {
entry:
  %l0 = alloca { i64, [2 x i64] }
  %l1 = alloca i1
  %rv = alloca i1
  store { i64, [2 x i64] } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l0
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 2
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb7
bb2:
  %t6 = load { i64, [2 x i64] }, ptr %l0
  %t8 = extractvalue { i64, [2 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 4
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb7
bb4:
  %t11 = load { i64, [2 x i64] }, ptr %l0
  %t13 = extractvalue { i64, [2 x i64] } %t11, 0
  %t14 = icmp eq i64 %t13, 3
  br i1 %t14, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb13
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_df7e42d0d720f8e0_ba1485f60a37606c)
  unreachable
bb13:
  %t16 = load i1, ptr %l1, !tbaa !21
  store i1 %t16, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %a0) #0 {
entry:
  %l0 = alloca { i64, [2 x i64] }
  %l1 = alloca i1
  %rv = alloca i1
  store { i64, [2 x i64] } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l0
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb7
bb2:
  %t6 = load { i64, [2 x i64] }, ptr %l0
  %t8 = extractvalue { i64, [2 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 2
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb7
bb4:
  %t11 = load { i64, [2 x i64] }, ptr %l0
  %t13 = extractvalue { i64, [2 x i64] } %t11, 0
  %t14 = icmp eq i64 %t13, 3
  br i1 %t14, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb13
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_29ab6d94cb2a37cc_d7a08cac8eb9a0a8)
  unreachable
bb13:
  %t16 = load i1, ptr %l1, !tbaa !21
  store i1 %t16, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fscope_2ecountTrue(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i1
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  store ptr %a0, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l3, !tbaa !24
  store i64 %t3, ptr %l6, !tbaa !24
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t4)
  store i64 %t6, ptr %l8
  br label %bb2
bb2:
  %t7 = load i64, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l8, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t13, i64 %t14)
  store i1 %t17, ptr %l13
  br label %bb6
bb6:
  %t18 = load i1, ptr %l13, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = add i64 %t21, 1
  store i64 %t23, ptr %l1, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t25 = load i64, ptr %l3, !tbaa !24
  %t27 = add i64 %t25, 1
  store i64 %t27, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  %t29 = load i64, ptr %l1, !tbaa !24
  store i64 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/scope:Val" @compiler_2fscope_2eexisting({ i64, [2 x i64] } %a0) #0 {
entry:
  %l3 = alloca %"compiler/scope:Val"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/scope:Val"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t4 = call %"compiler/scope:Val" @compiler_2fscope_3aVal_2ector(ptr %s0, i32 3, { i64, [2 x i64] } %a0)
  store %"compiler/scope:Val" %t4, ptr %l3
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t5 = load %"compiler/scope:Val", ptr %l3
  store %"compiler/scope:Val" %t5, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scope:Val", ptr %rv
  ret %"compiler/scope:Val" %rr
}

define dso_local i64 @compiler_2fscope_2eflRootExpr(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca i1
  %l35 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t7 = load ptr, ptr %l7, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l7, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 2
  store i1 %t13, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l8, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t17, i32 0, i32 2
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l1, !tbaa !29
  br label %bb16
bb7:
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t22 = load ptr, ptr %l13, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t26 = load i64, ptr %t25, !range !{i64 0, i64 18}
  %t28 = icmp eq i64 %t26, 3
  store i1 %t28, ptr %l14, !tbaa !21
  br label %bb9
bb9:
  %t29 = load i1, ptr %l14, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr { i64, [5 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t32, i32 0, i32 2
  %t34 = load ptr, ptr %t33
  store ptr %t34, ptr %l1, !tbaa !29
  br label %bb16
bb11:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t37 = load ptr, ptr %l19, !tbaa !29
  %t38 = icmp ne ptr %t37, null
  br i1 %t38, label %bb12, label %bb13
bb12:
  %t40 = load ptr, ptr %l19, !tbaa !29
  %t41 = load i64, ptr %t40, !range !{i64 0, i64 18}
  %t43 = icmp eq i64 %t41, 4
  store i1 %t43, ptr %l20, !tbaa !21
  br label %bb13
bb13:
  %t44 = load i1, ptr %l20, !tbaa !21
  br i1 %t44, label %bb14, label %bb15
bb14:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [5 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t47, i32 0, i32 2
  %t49 = load ptr, ptr %t48
  store ptr %t49, ptr %l1, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = call i64 @compiler_2fscope_2eflRoot(ptr %v0, ptr %t51)
  store i64 %t53, ptr %l26
  br label %bb17
bb17:
  %t54 = load i64, ptr %l26, !tbaa !24
  store i64 %t54, ptr %l6, !tbaa !24
  br label %bb30
bb18:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t56 = load ptr, ptr %l27, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb19, label %bb20
bb19:
  %t59 = load ptr, ptr %l27, !tbaa !29
  %t60 = load i64, ptr %t59, !range !{i64 0, i64 18}
  %t62 = icmp eq i64 %t60, 17
  store i1 %t62, ptr %l28, !tbaa !21
  br label %bb20
bb20:
  %t63 = load i1, ptr %l28, !tbaa !21
  br i1 %t63, label %bb21, label %bb22
bb21:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr { i64, [5 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t66, i32 0, i32 2
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l2, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t70 = load ptr, ptr %l2, !tbaa !29
  %t73 = call i64 @compiler_2fscope_2eflRootExpr(ptr %v0, ptr %t70)
  store i64 %t73, ptr %l35
  br label %bb24
bb24:
  %t74 = load i64, ptr %l35, !tbaa !24
  store i64 %t74, ptr %l6, !tbaa !24
  br label %bb30
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  store i64 -1, ptr %l6, !tbaa !24
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_e9d57cf77a66352c_e30832457df38478)
  unreachable
bb30:
  %t75 = load i64, ptr %l6, !tbaa !24
  store i64 %t75, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fscope_2eisBlockTerm({ i64, [2 x i64] } %a0) #0 {
entry:
  %l1 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, [2 x i64] } %a0, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_f7b7284e8bdb42c_7d0460b025534e78)
  unreachable
bb9:
  %t6 = load i1, ptr %l1, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fscope_2elocalRead(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t17 = load ptr, ptr %l9, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l9, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l10, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l10, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t27, i32 0, i32 2
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l2, !tbaa !23
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t31 = load i32, ptr %l2, !tbaa !23
  %t33 = sext i32 %t31 to i64
  store i64 %t33, ptr %rv
  br label %ret
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i64 -1, ptr %rv
  br label %ret
bb15:
  call void @__olang_check_failed(ptr @olang_loc_1335909b8009e6b8_227574ff00a357c4)
  unreachable
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i64 -1, ptr %rv
  br label %ret
bb20:
  call void @__olang_check_failed(ptr @olang_loc_18ba62b867b30c89_62dfd3c940fee6b5)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fscope_2eregionLocal(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t17 = load ptr, ptr %l9, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l9, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l10, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l10, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t27, i32 0, i32 2
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l2, !tbaa !23
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t31 = load i32, ptr %l2, !tbaa !23
  %t33 = sext i32 %t31 to i64
  store i64 %t33, ptr %rv
  br label %ret
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_926310a74149af64_7456b8629edeed00)
  unreachable
bb16:
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_d723be5f6d33c955_f64e13843779cd91)
  unreachable
bb22:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fscope_2etermGiven({ i64, [2 x i64] } %a0) #0 {
entry:
  %l0 = alloca { i64, [2 x i64] }
  %l1 = alloca i1
  %rv = alloca i1
  store { i64, [2 x i64] } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l0
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb5
bb2:
  %t6 = load { i64, [2 x i64] }, ptr %l0
  %t8 = extractvalue { i64, [2 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 2
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_6421b9c211daea5c_85adafb275b4c978)
  unreachable
bb11:
  %t11 = load i1, ptr %l1, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ethroughTemp(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %l16 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l25 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %l34 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb32
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t11 = load ptr, ptr %l9, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l9, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 3
  store i1 %t17, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l10, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l1, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = call i1 @compiler_2fscope_2ethroughTemp(ptr %v0, ptr %t25)
  store i1 %t27, ptr %l16
  br label %bb12
bb12:
  %t28 = load i1, ptr %l16, !tbaa !21
  store i1 %t28, ptr %l4, !tbaa !21
  br label %bb32
bb13:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t30 = load ptr, ptr %l17, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb14, label %bb15
bb14:
  %t33 = load ptr, ptr %l17, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 8}
  %t36 = icmp eq i64 %t34, 4
  store i1 %t36, ptr %l18, !tbaa !21
  br label %bb15
bb15:
  %t37 = load i1, ptr %l18, !tbaa !21
  br i1 %t37, label %bb16, label %bb17
bb16:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l2, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t46 = getelementptr %"compiler/typed:Elem", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = call i1 @compiler_2fscope_2ethroughTemp(ptr %v0, ptr %t47)
  store i1 %t49, ptr %l25
  br label %bb19
bb19:
  %t50 = load i1, ptr %l25, !tbaa !21
  store i1 %t50, ptr %l4, !tbaa !21
  br label %bb32
bb20:
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t52 = load ptr, ptr %l26, !tbaa !29
  %t53 = icmp ne ptr %t52, null
  br i1 %t53, label %bb21, label %bb22
bb21:
  %t55 = load ptr, ptr %l26, !tbaa !29
  %t56 = load i64, ptr %t55, !range !{i64 0, i64 8}
  %t58 = icmp eq i64 %t56, 5
  store i1 %t58, ptr %l27, !tbaa !21
  br label %bb22
bb22:
  %t59 = load i1, ptr %l27, !tbaa !21
  br i1 %t59, label %bb23, label %bb24
bb23:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr { i64, [4 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t62, i32 0, i32 2
  %t64 = load ptr, ptr %t63
  store ptr %t64, ptr %l3, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t66 = load ptr, ptr %l3, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Payload", ptr %t66, i32 0, i32 0
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = call i1 @compiler_2fscope_2ethroughTemp(ptr %v0, ptr %t69)
  store i1 %t71, ptr %l34
  br label %bb26
bb26:
  %t72 = load i1, ptr %l34, !tbaa !21
  store i1 %t72, ptr %l4, !tbaa !21
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_30366b1ce1cb05a4_de371b7365ebcc00)
  unreachable
bb32:
  %t73 = load i1, ptr %l4, !tbaa !21
  store i1 %t73, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fscope_2eunWidened(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i1
  %l14 = alloca i1
  %l18 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l21 = alloca i1
  %l24 = alloca { i64, ptr }
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 9
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13, !range !{i32 0, i32 43}
  store i32 %t14, ptr %l1
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t18, i32 0, i32 4
  %t20 = load { i64, ptr }, ptr %t19
  store { i64, ptr } %t20, ptr %l2, !tbaa !27
  br label %bb5
bb4:
  br label %bb23
bb5:
  %t22 = load i32, ptr %l1, !range !{i32 0, i32 43}
  %t24 = trunc i64 20 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t31 = icmp eq i64 %t29, 1
  store i1 %t31, ptr %l14, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l14, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t34 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t34, ptr %l18, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr ptr, ptr %t36, i64 0
  %t38 = load ptr, ptr %t37, !tbaa !39
  store ptr %t38, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t41 = load ptr, ptr %l20, !tbaa !29
  %t42 = icmp ne ptr %t41, null
  br i1 %t42, label %bb11, label %bb12
bb10:
  br label %bb22
bb11:
  %t44 = load ptr, ptr %l20, !tbaa !29
  %t45 = load i64, ptr %t44, !range !{i64 0, i64 18}
  %t47 = icmp eq i64 %t45, 10
  store i1 %t47, ptr %l21, !tbaa !21
  br label %bb12
bb12:
  %t48 = load i1, ptr %l21, !tbaa !21
  br i1 %t48, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t49 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t49, ptr %l24, !tbaa !27
  %t50 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr ptr, ptr %t51, i64 0
  %t53 = load ptr, ptr %t52, !tbaa !39
  store ptr %t53, ptr %rv
  br label %ret
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_c76fb05b477ad754_aaa77e81edb6bb58)
  unreachable
bb21:
  br label %bb22
bb22:
  br label %bb28
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_472a8ee29a396e05_19ea125b0d0f8e29)
  unreachable
bb28:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/scope:walked" @compiler_2fscope_2ewalkBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/scope:walked"
  %l8 = alloca ptr
  %rv = alloca %"compiler/scope:walked"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"compiler/scope:walked" @olang_2eHelperKind_2eZero_2ecompiler_2fscope_3awalked(ptr %v1)
  store %"compiler/scope:walked" %t1, ptr %l4
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 56, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"compiler/scope:walked", ptr %l4
  %t4 = load ptr, ptr %lp2
  store %"compiler/scope:walked" %t3, ptr %t4
  %t7 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 1
  %t11 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t7, i64 %a1)
  store ptr %t11, ptr %l8
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l8, !tbaa !29
  store ptr %t12, ptr %l3, !tbaa !29
  %t13 = load ptr, ptr %l3, !tbaa !29
  %t15 = getelementptr %"compiler/typed:Body", ptr %t13, i32 0, i32 11
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = icmp eq ptr %t16, null
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Body", ptr %t22, i32 0, i32 11
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t26 = load ptr, ptr %lp2
  call void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %v1, ptr %t25, ptr %t26)
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb6
bb6:
  %t29 = load ptr, ptr %lp2
  %t30 = load %"compiler/scope:walked", ptr %t29
  store %"compiler/scope:walked" %t30, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scope:walked", ptr %rv
  ret %"compiler/scope:walked" %rr
}

define dso_local void @compiler_2fscope_3aScoper_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca { ptr, ptr }
  %l7 = alloca { ptr, ptr }
  %l8 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l17 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l21 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l23 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca i64
  %l25 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l26 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca i1
  %l30 = alloca %"compiler/source:Span"
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca %"compiler/typed:Plan"
  %l33 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l34 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l35 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l36 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l37 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l38 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l39 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l40 = alloca %"compiler/source:Span"
  %l41 = alloca i64
  %l42 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l43 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l44 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l45 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l46 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l47 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l48 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l49 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l50 = alloca i64
  %l51 = alloca i1
  %l52 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l53 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l54 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l58 = alloca i1
  %l59 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l60 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l61 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l62 = alloca i1
  %l63 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l64 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l65 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l66 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l67 = alloca i64
  %l68 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l69 = alloca { i64, [2 x i64] }
  %l70 = alloca i1
  %l71 = alloca i1
  %l72 = alloca i1
  %l73 = alloca i1
  %l74 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l75 = alloca { i64, [2 x i64] }
  %l76 = alloca i1
  %l77 = alloca %"compiler/source:Span"
  %l78 = alloca { i64, [2 x i64] }
  %l79 = alloca i1
  %l80 = alloca { i64, [2 x i64] }
  %l81 = alloca i1
  %l82 = alloca i1
  %l83 = alloca i1
  %l84 = alloca %"compiler/source:Span"
  %l85 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l86 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l87 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l88 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l89 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l90 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l91 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l92 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l93 = alloca { i64, [2 x i64] }
  %l94 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l95 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l96 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l97 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l98 = alloca %"compiler/source:Span"
  %l99 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l100 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l101 = alloca i1
  %l102 = alloca i64
  %l103 = alloca { i64, [2 x i64] }
  %l104 = alloca i1
  %l105 = alloca i1
  %l106 = alloca i1
  %l107 = alloca i64
  %l108 = alloca i1
  %l109 = alloca i1
  %l110 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l111 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l112 = alloca i1
  %l113 = alloca i64
  %l114 = alloca i64
  %l115 = alloca i1
  %l116 = alloca i32
  %l117 = alloca i1
  %l118 = alloca i1
  %l119 = alloca i1
  %l120 = alloca i1
  %l121 = alloca i64
  %l125 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l126 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l127 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l128 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l129 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l130 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l131 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l132 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l133 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l134 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l135 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l136 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l137 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l138 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l139 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l140 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l141 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l142 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l143 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l144 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l145 = alloca %"compiler/source:Span"
  %l146 = alloca %"compiler/source:Span"
  %l147 = alloca %"compiler/typed:Plan"
  %l148 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l149 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l150 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l151 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l152 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l153 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l154 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l155 = alloca %"compiler/source:Span"
  %l156 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l157 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l158 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l159 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l160 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l161 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l162 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l163 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l164 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l165 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l166 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l167 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l168 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l169 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l170 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l171 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l172 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l173 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l174 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l175 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l177 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l179 = alloca %"compiler/source:Span"
  %l182 = alloca %"compiler/source:Span"
  %l183 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l184 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l185 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l186 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l187 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l188 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l189 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l190 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l192 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l193 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l194 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l195 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l196 = alloca %"compiler/source:Span"
  %l197 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l198 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l200 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l201 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l202 = alloca %"compiler/source:Span"
  %l203 = alloca %"compiler/scope:Scoper"
  %t49 = alloca %"compiler/typed:Plan", align 8
  %t106 = alloca { i64, [2 x i64] }, align 8
  %t112 = alloca { i64, [2 x i64] }, align 8
  %t118 = alloca { i64, [2 x i64] }, align 8
  %t122 = alloca { i64, [2 x i64] }, align 8
  %t144 = alloca { i64, [2 x i64] }, align 8
  %t162 = alloca { i64, [2 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, ptr %l3
  %t5 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l125
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l125
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l4
  %t7 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l126
  br label %bb2
bb2:
  %t8 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l126
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l5
  store { ptr, ptr } zeroinitializer, ptr %l6
  store { ptr, ptr } zeroinitializer, ptr %l7
  %t9 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l127
  br label %bb3
bb3:
  %t10 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l127
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l8
  %t11 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l128
  br label %bb4
bb4:
  %t12 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l128
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l9
  %t13 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l129
  br label %bb5
bb5:
  %t14 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l129
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, ptr %l10
  %t15 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %l130
  br label %bb6
bb6:
  %t16 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l130
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l11
  %t17 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, ptr %l131
  br label %bb7
bb7:
  %t18 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l131
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t18, ptr %l12
  %t19 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, ptr %l132
  br label %bb8
bb8:
  %t20 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l132
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t20, ptr %l13
  %t21 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, ptr %l133
  br label %bb9
bb9:
  %t22 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l133
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l14
  %t23 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %l134
  br label %bb10
bb10:
  %t24 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l134
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l15
  %t25 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l135
  br label %bb11
bb11:
  %t26 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l135
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t26, ptr %l16
  %t27 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t27, ptr %l136
  br label %bb12
bb12:
  %t28 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l136
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, ptr %l17
  %t29 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t29, ptr %l137
  br label %bb13
bb13:
  %t30 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l137
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t30, ptr %l18
  %t31 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t31, ptr %l138
  br label %bb14
bb14:
  %t32 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l138
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %l19
  %t33 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t33, ptr %l139
  br label %bb15
bb15:
  %t34 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l139
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t34, ptr %l20
  %t35 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t35, ptr %l140
  br label %bb16
bb16:
  %t36 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l140
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t36, ptr %l21
  %t37 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t37, ptr %l141
  br label %bb17
bb17:
  %t38 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l141
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t38, ptr %l22
  %t39 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t39, ptr %l142
  br label %bb18
bb18:
  %t40 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l142
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, ptr %l23
  store i64 0, ptr %l24, !tbaa !24
  %t41 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t41, ptr %l143
  br label %bb19
bb19:
  %t42 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l143
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t42, ptr %l25
  %t43 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t43, ptr %l144
  br label %bb20
bb20:
  %t44 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l144
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t44, ptr %l26
  store ptr null, ptr %l27, !tbaa !29
  store i64 -1, ptr %l28, !tbaa !24
  store i1 false, ptr %l29, !tbaa !21
  %t45 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v2, i32 -1, i32 -1)
  store %"compiler/source:Span" %t45, ptr %l145
  br label %bb21
bb21:
  %t46 = load %"compiler/source:Span", ptr %l145
  store %"compiler/source:Span" %t46, ptr %l30
  %t47 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v2, i32 -1, i32 -1)
  store %"compiler/source:Span" %t47, ptr %l146
  br label %bb22
bb22:
  %t48 = load %"compiler/source:Span", ptr %l146
  store %"compiler/source:Span" %t48, ptr %l31
  call void @compiler_2ftyped_3aPlan_2ector(ptr %t49, ptr %v2, i64 0, i64 0, i64 0)
  call void @llvm.memmove.p0.p0.i64(ptr %l147, ptr %t49, i64 152, i1 false)
  br label %bb23
bb23:
  call void @llvm.memmove.p0.p0.i64(ptr %l32, ptr %l147, i64 152, i1 false)
  %t50 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t50, ptr %l148
  br label %bb24
bb24:
  %t51 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l148
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t51, ptr %l33
  %t52 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t52, ptr %l149
  br label %bb25
bb25:
  %t53 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l149
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t53, ptr %l34
  %t54 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t54, ptr %l150
  br label %bb26
bb26:
  %t55 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l150
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t55, ptr %l35
  %t56 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t56, ptr %l151
  br label %bb27
bb27:
  %t57 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l151
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t57, ptr %l36
  %t58 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t58, ptr %l152
  br label %bb28
bb28:
  %t59 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l152
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t59, ptr %l37
  %t60 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t60, ptr %l153
  br label %bb29
bb29:
  %t61 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l153
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t61, ptr %l38
  %t62 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t62, ptr %l154
  br label %bb30
bb30:
  %t63 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l154
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t63, ptr %l39
  %t64 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v2, i32 0, i32 0)
  store %"compiler/source:Span" %t64, ptr %l155
  br label %bb31
bb31:
  %t65 = load %"compiler/source:Span", ptr %l155
  store %"compiler/source:Span" %t65, ptr %l40
  store i64 -1, ptr %l41, !tbaa !24
  %t66 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t66, ptr %l156
  br label %bb32
bb32:
  %t67 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l156
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t67, ptr %l42
  %t68 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t68, ptr %l157
  br label %bb33
bb33:
  %t69 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l157
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t69, ptr %l43
  %t70 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t70, ptr %l158
  br label %bb34
bb34:
  %t71 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l158
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t71, ptr %l44
  %t72 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t72, ptr %l159
  br label %bb35
bb35:
  %t73 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l159
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t73, ptr %l45
  %t74 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t74, ptr %l160
  br label %bb36
bb36:
  %t75 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l160
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t75, ptr %l46
  %t76 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t76, ptr %l161
  br label %bb37
bb37:
  %t77 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l161
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t77, ptr %l47
  %t78 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t78, ptr %l162
  br label %bb38
bb38:
  %t79 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l162
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t79, ptr %l48
  %t80 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t80, ptr %l163
  br label %bb39
bb39:
  %t81 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l163
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t81, ptr %l49
  store i64 -1, ptr %l50, !tbaa !24
  store i1 false, ptr %l51, !tbaa !21
  %t82 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aV_H3bb336b48f9f9239e303a7a9a8cec160(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t82, ptr %l164
  br label %bb40
bb40:
  %t83 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l164
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t83, ptr %l52
  %t84 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t84, ptr %l165
  br label %bb41
bb41:
  %t85 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l165
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t85, ptr %l53
  %t86 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t86, ptr %l166
  br label %bb42
bb42:
  %t87 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l166
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t87, ptr %l54
  store i64 -1, ptr %l55, !tbaa !24
  store i64 0, ptr %l56, !tbaa !24
  %t88 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t88, ptr %l167
  br label %bb43
bb43:
  %t89 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l167
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t89, ptr %l57
  store i1 false, ptr %l58, !tbaa !21
  %t90 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t90, ptr %l168
  br label %bb44
bb44:
  %t91 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l168
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t91, ptr %l59
  %t92 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t92, ptr %l169
  br label %bb45
bb45:
  %t93 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l169
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t93, ptr %l60
  %t94 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t94, ptr %l170
  br label %bb46
bb46:
  %t95 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l170
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t95, ptr %l61
  store i1 false, ptr %l62, !tbaa !21
  %t96 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t96, ptr %l171
  br label %bb47
bb47:
  %t97 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l171
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t97, ptr %l63
  %t98 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t98, ptr %l172
  br label %bb48
bb48:
  %t99 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l172
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t99, ptr %l64
  %t100 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t100, ptr %l173
  br label %bb49
bb49:
  %t101 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l173
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t101, ptr %l65
  %t102 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t102, ptr %l174
  br label %bb50
bb50:
  %t103 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l174
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t103, ptr %l66
  store i64 -1, ptr %l67, !tbaa !24
  %t104 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t104, ptr %l175
  br label %bb51
bb51:
  %t105 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l175
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t105, ptr %l68
  store { i64, [2 x i64] } zeroinitializer, ptr %t106
  %t107 = getelementptr { i64, [2 x i64] }, ptr %t106, i32 0, i32 0
  store i64 0, ptr %t107
  %t108 = load { i64, [2 x i64] }, ptr %t106
  store { i64, [2 x i64] } %t108, ptr %l69
  store i1 false, ptr %l70, !tbaa !21
  store i1 false, ptr %l71, !tbaa !21
  store i1 false, ptr %l72, !tbaa !21
  store i1 false, ptr %l73, !tbaa !21
  %t110 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t110, ptr %l177
  br label %bb52
bb52:
  %t111 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l177
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t111, ptr %l74
  store { i64, [2 x i64] } zeroinitializer, ptr %t112
  %t113 = getelementptr { i64, [2 x i64] }, ptr %t112, i32 0, i32 0
  store i64 0, ptr %t113
  %t114 = load { i64, [2 x i64] }, ptr %t112
  store { i64, [2 x i64] } %t114, ptr %l75
  store i1 false, ptr %l76, !tbaa !21
  %t116 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v2, i32 0, i32 0)
  store %"compiler/source:Span" %t116, ptr %l179
  br label %bb53
bb53:
  %t117 = load %"compiler/source:Span", ptr %l179
  store %"compiler/source:Span" %t117, ptr %l77
  store { i64, [2 x i64] } zeroinitializer, ptr %t118
  %t119 = getelementptr { i64, [2 x i64] }, ptr %t118, i32 0, i32 0
  store i64 0, ptr %t119
  %t120 = load { i64, [2 x i64] }, ptr %t118
  store { i64, [2 x i64] } %t120, ptr %l78
  store i1 false, ptr %l79, !tbaa !21
  store { i64, [2 x i64] } zeroinitializer, ptr %t122
  %t123 = getelementptr { i64, [2 x i64] }, ptr %t122, i32 0, i32 0
  store i64 0, ptr %t123
  %t124 = load { i64, [2 x i64] }, ptr %t122
  store { i64, [2 x i64] } %t124, ptr %l80
  store i1 false, ptr %l81, !tbaa !21
  store i1 false, ptr %l82, !tbaa !21
  store i1 false, ptr %l83, !tbaa !21
  %t126 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v2, i32 0, i32 0)
  store %"compiler/source:Span" %t126, ptr %l182
  br label %bb54
bb54:
  %t127 = load %"compiler/source:Span", ptr %l182
  store %"compiler/source:Span" %t127, ptr %l84
  %t128 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnUse_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t128, ptr %l183
  br label %bb55
bb55:
  %t129 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l183
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t129, ptr %l85
  %t130 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t130, ptr %l184
  br label %bb56
bb56:
  %t131 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l184
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t131, ptr %l86
  %t132 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t132, ptr %l185
  br label %bb57
bb57:
  %t133 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l185
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t133, ptr %l87
  %t134 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t134, ptr %l186
  br label %bb58
bb58:
  %t135 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l186
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t135, ptr %l88
  %t136 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t136, ptr %l187
  br label %bb59
bb59:
  %t137 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l187
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t137, ptr %l89
  %t138 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t138, ptr %l188
  br label %bb60
bb60:
  %t139 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l188
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t139, ptr %l90
  %t140 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t140, ptr %l189
  br label %bb61
bb61:
  %t141 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l189
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t141, ptr %l91
  %t142 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t142, ptr %l190
  br label %bb62
bb62:
  %t143 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l190
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t143, ptr %l92
  store { i64, [2 x i64] } zeroinitializer, ptr %t144
  %t145 = getelementptr { i64, [2 x i64] }, ptr %t144, i32 0, i32 0
  store i64 0, ptr %t145
  %t146 = load { i64, [2 x i64] }, ptr %t144
  store { i64, [2 x i64] } %t146, ptr %l93
  %t148 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t148, ptr %l192
  br label %bb63
bb63:
  %t149 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l192
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t149, ptr %l94
  %t150 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t150, ptr %l193
  br label %bb64
bb64:
  %t151 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l193
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t151, ptr %l95
  %t152 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t152, ptr %l194
  br label %bb65
bb65:
  %t153 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l194
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t153, ptr %l96
  %t154 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_H01b6fb75b9cc96416bdc55b4e10a9a4d(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t154, ptr %l195
  br label %bb66
bb66:
  %t155 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l195
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t155, ptr %l97
  %t156 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v2, i32 0, i32 0)
  store %"compiler/source:Span" %t156, ptr %l196
  br label %bb67
bb67:
  %t157 = load %"compiler/source:Span", ptr %l196
  store %"compiler/source:Span" %t157, ptr %l98
  %t158 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t158, ptr %l197
  br label %bb68
bb68:
  %t159 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l197
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t159, ptr %l99
  %t160 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t160, ptr %l198
  br label %bb69
bb69:
  %t161 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l198
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t161, ptr %l100
  store i1 false, ptr %l101, !tbaa !21
  store i64 0, ptr %l102, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t162
  %t163 = getelementptr { i64, [2 x i64] }, ptr %t162, i32 0, i32 0
  store i64 0, ptr %t163
  %t164 = load { i64, [2 x i64] }, ptr %t162
  store { i64, [2 x i64] } %t164, ptr %l103
  store i1 false, ptr %l104, !tbaa !21
  store i1 false, ptr %l105, !tbaa !21
  store i1 false, ptr %l106, !tbaa !21
  store i64 -1, ptr %l107, !tbaa !24
  store i1 false, ptr %l108, !tbaa !21
  store i1 false, ptr %l109, !tbaa !21
  %t166 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t166, ptr %l200
  br label %bb70
bb70:
  %t167 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l200
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t167, ptr %l110
  %t168 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t168, ptr %l201
  br label %bb71
bb71:
  %t169 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l201
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t169, ptr %l111
  store i1 false, ptr %l112, !tbaa !21
  store i64 0, ptr %l113, !tbaa !24
  store i64 -1, ptr %l114, !tbaa !24
  store i1 false, ptr %l115, !tbaa !21
  store i32 0, ptr %l116, !tbaa !23
  store i1 false, ptr %l117, !tbaa !21
  store i1 true, ptr %l118, !tbaa !21
  store i1 false, ptr %l119, !tbaa !21
  store i1 false, ptr %l120, !tbaa !21
  store i64 -1, ptr %l121, !tbaa !24
  %t170 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v2, i32 0, i32 0)
  store %"compiler/source:Span" %t170, ptr %l202
  br label %bb72
bb72:
  %t171 = load %"compiler/source:Span", ptr %l202
  %t172 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 0
  %t173 = load ptr, ptr %l2, !tbaa !29
  store ptr %t173, ptr %t172, !tbaa !29
  %t174 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 1
  %t175 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t175, ptr %t174
  %t176 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 2
  %t177 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t177, ptr %t176
  %t178 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 3
  %t179 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t179, ptr %t178
  %t180 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 4
  %t181 = load { ptr, ptr }, ptr %l6
  store { ptr, ptr } %t181, ptr %t180
  %t182 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 5
  %t183 = load { ptr, ptr }, ptr %l7
  store { ptr, ptr } %t183, ptr %t182
  %t184 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 6
  %t185 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t185, ptr %t184
  %t186 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 7
  %t187 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t187, ptr %t186
  %t188 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 8
  %t189 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t189, ptr %t188
  %t190 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 9
  %t191 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t191, ptr %t190
  %t192 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 10
  %t193 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t193, ptr %t192
  %t194 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 11
  %t195 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t195, ptr %t194
  %t196 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 12
  %t197 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l14
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t197, ptr %t196
  %t198 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 13
  %t199 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l15
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t199, ptr %t198
  %t200 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 14
  %t201 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t201, ptr %t200
  %t202 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 15
  %t203 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l17
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t203, ptr %t202
  %t204 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 16
  %t205 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l18
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t205, ptr %t204
  %t206 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 17
  %t207 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t207, ptr %t206
  %t208 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 18
  %t209 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t209, ptr %t208
  %t210 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 19
  %t211 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l21
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t211, ptr %t210
  %t212 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 20
  %t213 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l22
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t213, ptr %t212
  %t214 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 21
  %t215 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l23
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t215, ptr %t214
  %t216 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 22
  %t217 = load i64, ptr %l24, !tbaa !24
  store i64 %t217, ptr %t216, !tbaa !24
  %t218 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 23
  %t219 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l25
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t219, ptr %t218
  %t220 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 24
  %t221 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l26
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t221, ptr %t220
  %t222 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 25
  %t223 = load ptr, ptr %l27, !tbaa !29
  store ptr %t223, ptr %t222, !tbaa !29
  %t224 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 26
  %t225 = load i64, ptr %l28, !tbaa !24
  store i64 %t225, ptr %t224, !tbaa !24
  %t226 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 27
  %t227 = load i1, ptr %l29, !tbaa !21
  store i1 %t227, ptr %t226, !tbaa !21
  %t228 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 28
  %t229 = load %"compiler/source:Span", ptr %l30
  store %"compiler/source:Span" %t229, ptr %t228
  %t230 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 29
  %t231 = load %"compiler/source:Span", ptr %l31
  store %"compiler/source:Span" %t231, ptr %t230
  %t232 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 30
  call void @llvm.memmove.p0.p0.i64(ptr %t232, ptr %l32, i64 152, i1 false)
  %t233 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 31
  %t234 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l33
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t234, ptr %t233
  %t235 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 32
  %t236 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l34
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t236, ptr %t235
  %t237 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 33
  %t238 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l35
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t238, ptr %t237
  %t239 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 34
  %t240 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l36
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t240, ptr %t239
  %t241 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 35
  %t242 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l37
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t242, ptr %t241
  %t243 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 36
  %t244 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l38
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t244, ptr %t243
  %t245 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 37
  %t246 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l39
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t246, ptr %t245
  %t247 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 38
  %t248 = load %"compiler/source:Span", ptr %l40
  store %"compiler/source:Span" %t248, ptr %t247
  %t249 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 39
  %t250 = load i64, ptr %l41, !tbaa !24
  store i64 %t250, ptr %t249, !tbaa !24
  %t251 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 40
  %t252 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l42
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t252, ptr %t251
  %t253 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 41
  %t254 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l43
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t254, ptr %t253
  %t255 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 42
  %t256 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l44
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t256, ptr %t255
  %t257 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 43
  %t258 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l45
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t258, ptr %t257
  %t259 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 44
  %t260 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l46
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t260, ptr %t259
  %t261 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 45
  %t262 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l47
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t262, ptr %t261
  %t263 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 46
  %t264 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l48
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t264, ptr %t263
  %t265 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 47
  %t266 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l49
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t266, ptr %t265
  %t267 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 48
  %t268 = load i64, ptr %l50, !tbaa !24
  store i64 %t268, ptr %t267, !tbaa !24
  %t269 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 49
  %t270 = load i1, ptr %l51, !tbaa !21
  store i1 %t270, ptr %t269, !tbaa !21
  %t271 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 50
  %t272 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l52
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t272, ptr %t271
  %t273 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 51
  %t274 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l53
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t274, ptr %t273
  %t275 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 52
  %t276 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l54
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t276, ptr %t275
  %t277 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 53
  %t278 = load i64, ptr %l55, !tbaa !24
  store i64 %t278, ptr %t277, !tbaa !24
  %t279 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 54
  %t280 = load i64, ptr %l56, !tbaa !24
  store i64 %t280, ptr %t279, !tbaa !24
  %t281 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 55
  %t282 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l57
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t282, ptr %t281
  %t283 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 56
  %t284 = load i1, ptr %l58, !tbaa !21
  store i1 %t284, ptr %t283, !tbaa !21
  %t285 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 57
  %t286 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l59
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t286, ptr %t285
  %t287 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 58
  %t288 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l60
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t288, ptr %t287
  %t289 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 59
  %t290 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l61
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t290, ptr %t289
  %t291 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 60
  %t292 = load i1, ptr %l62, !tbaa !21
  store i1 %t292, ptr %t291, !tbaa !21
  %t293 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 61
  %t294 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l63
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t294, ptr %t293
  %t295 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 62
  %t296 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l64
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t296, ptr %t295
  %t297 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 63
  %t298 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l65
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t298, ptr %t297
  %t299 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 64
  %t300 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l66
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t300, ptr %t299
  %t301 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 65
  %t302 = load i64, ptr %l67, !tbaa !24
  store i64 %t302, ptr %t301, !tbaa !24
  %t303 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 66
  %t304 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l68
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t304, ptr %t303
  %t305 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 67
  %t306 = load { i64, [2 x i64] }, ptr %l69
  store { i64, [2 x i64] } %t306, ptr %t305
  %t307 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 68
  %t308 = load i1, ptr %l70, !tbaa !21
  store i1 %t308, ptr %t307, !tbaa !21
  %t309 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 69
  %t310 = load i1, ptr %l71, !tbaa !21
  store i1 %t310, ptr %t309, !tbaa !21
  %t311 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 70
  %t312 = load i1, ptr %l72, !tbaa !21
  store i1 %t312, ptr %t311, !tbaa !21
  %t313 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 71
  %t314 = load i1, ptr %l73, !tbaa !21
  store i1 %t314, ptr %t313, !tbaa !21
  %t315 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 72
  %t316 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l74
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t316, ptr %t315
  %t317 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 73
  %t318 = load { i64, [2 x i64] }, ptr %l75
  store { i64, [2 x i64] } %t318, ptr %t317
  %t319 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 74
  %t320 = load i1, ptr %l76, !tbaa !21
  store i1 %t320, ptr %t319, !tbaa !21
  %t321 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 75
  %t322 = load %"compiler/source:Span", ptr %l77
  store %"compiler/source:Span" %t322, ptr %t321
  %t323 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 76
  %t324 = load { i64, [2 x i64] }, ptr %l78
  store { i64, [2 x i64] } %t324, ptr %t323
  %t325 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 77
  %t326 = load i1, ptr %l79, !tbaa !21
  store i1 %t326, ptr %t325, !tbaa !21
  %t327 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 78
  %t328 = load { i64, [2 x i64] }, ptr %l80
  store { i64, [2 x i64] } %t328, ptr %t327
  %t329 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 79
  %t330 = load i1, ptr %l81, !tbaa !21
  store i1 %t330, ptr %t329, !tbaa !21
  %t331 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 80
  %t332 = load i1, ptr %l82, !tbaa !21
  store i1 %t332, ptr %t331, !tbaa !21
  %t333 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 81
  %t334 = load i1, ptr %l83, !tbaa !21
  store i1 %t334, ptr %t333, !tbaa !21
  %t335 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 82
  %t336 = load %"compiler/source:Span", ptr %l84
  store %"compiler/source:Span" %t336, ptr %t335
  %t337 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 83
  %t338 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l85
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t338, ptr %t337
  %t339 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 84
  %t340 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l86
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t340, ptr %t339
  %t341 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 85
  %t342 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l87
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t342, ptr %t341
  %t343 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 86
  %t344 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l88
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t344, ptr %t343
  %t345 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 87
  %t346 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l89
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t346, ptr %t345
  %t347 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 88
  %t348 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l90
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t348, ptr %t347
  %t349 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 89
  %t350 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l91
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t350, ptr %t349
  %t351 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 90
  %t352 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l92
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t352, ptr %t351
  %t353 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 91
  %t354 = load { i64, [2 x i64] }, ptr %l93
  store { i64, [2 x i64] } %t354, ptr %t353
  %t355 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 92
  %t356 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l94
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t356, ptr %t355
  %t357 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 93
  %t358 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l95
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t358, ptr %t357
  %t359 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 94
  %t360 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l96
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t360, ptr %t359
  %t361 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 95
  %t362 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l97
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t362, ptr %t361
  %t363 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 96
  %t364 = load %"compiler/source:Span", ptr %l98
  store %"compiler/source:Span" %t364, ptr %t363
  %t365 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 97
  %t366 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l99
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t366, ptr %t365
  %t367 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 98
  %t368 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l100
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t368, ptr %t367
  %t369 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 99
  %t370 = load i1, ptr %l101, !tbaa !21
  store i1 %t370, ptr %t369, !tbaa !21
  %t371 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 100
  %t372 = load i64, ptr %l102, !tbaa !24
  store i64 %t372, ptr %t371, !tbaa !24
  %t373 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 101
  %t374 = load { i64, [2 x i64] }, ptr %l103
  store { i64, [2 x i64] } %t374, ptr %t373
  %t375 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 102
  %t376 = load i1, ptr %l104, !tbaa !21
  store i1 %t376, ptr %t375, !tbaa !21
  %t377 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 103
  %t378 = load i1, ptr %l105, !tbaa !21
  store i1 %t378, ptr %t377, !tbaa !21
  %t379 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 104
  %t380 = load i1, ptr %l106, !tbaa !21
  store i1 %t380, ptr %t379, !tbaa !21
  %t381 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 105
  %t382 = load i64, ptr %l107, !tbaa !24
  store i64 %t382, ptr %t381, !tbaa !24
  %t383 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 106
  %t384 = load i1, ptr %l108, !tbaa !21
  store i1 %t384, ptr %t383, !tbaa !21
  %t385 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 107
  %t386 = load i1, ptr %l109, !tbaa !21
  store i1 %t386, ptr %t385, !tbaa !21
  %t387 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 108
  %t388 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l110
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t388, ptr %t387
  %t389 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 109
  %t390 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l111
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t390, ptr %t389
  %t391 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 110
  %t392 = load i1, ptr %l112, !tbaa !21
  store i1 %t392, ptr %t391, !tbaa !21
  %t393 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 111
  %t394 = load i64, ptr %l113, !tbaa !24
  store i64 %t394, ptr %t393, !tbaa !24
  %t395 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 112
  %t396 = load i64, ptr %l114, !tbaa !24
  store i64 %t396, ptr %t395, !tbaa !24
  %t397 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 113
  %t398 = load i1, ptr %l115, !tbaa !21
  store i1 %t398, ptr %t397, !tbaa !21
  %t399 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 114
  %t400 = load i32, ptr %l116, !tbaa !23
  store i32 %t400, ptr %t399, !tbaa !23
  %t401 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 115
  %t402 = load i1, ptr %l117, !tbaa !21
  store i1 %t402, ptr %t401, !tbaa !21
  %t403 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 116
  %t404 = load i1, ptr %l118, !tbaa !21
  store i1 %t404, ptr %t403, !tbaa !21
  %t405 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 117
  %t406 = load i1, ptr %l119, !tbaa !21
  store i1 %t406, ptr %t405, !tbaa !21
  %t407 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 118
  %t408 = load i1, ptr %l120, !tbaa !21
  store i1 %t408, ptr %t407, !tbaa !21
  %t409 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 119
  %t410 = load i64, ptr %l121, !tbaa !24
  store i64 %t410, ptr %t409, !tbaa !24
  %t411 = getelementptr %"compiler/scope:Scoper", ptr %l203, i32 0, i32 120
  store %"compiler/source:Span" %t171, ptr %t411
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l203, i64 1128, i1 false)
  br label %ret
ret:
  ret void
}

declare void @__olang_check_failed(ptr) cold noreturn
@__olang_empty_array = external constant [16 x i64]
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 7}
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3, !range !{i64 0, i64 7}
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb13
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 i64 4, label %bb6 i64 5, label %bb7 ]
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [2 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  %t20 = icmp eq i32 %t13, %t17
  br i1 %t20, label %bb8, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb9, label %bb1
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [2 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i64, i64 }, ptr %t35, i32 0, i32 0
  %t37 = load i64, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [2 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i64, i64 }, ptr %t39, i32 0, i32 0
  %t41 = load i64, ptr %t40
  %t44 = icmp eq i64 %t37, %t41
  br i1 %t44, label %bb10, label %bb1
bb7:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [2 x i64] }, ptr %t46, i32 0, i32 1
  %t48 = getelementptr { i64 }, ptr %t47, i32 0, i32 0
  %t49 = load i64, ptr %t48
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [2 x i64] }, ptr %t50, i32 0, i32 1
  %t52 = getelementptr { i64 }, ptr %t51, i32 0, i32 0
  %t53 = load i64, ptr %t52
  %t56 = icmp eq i64 %t49, %t53
  br i1 %t56, label %bb12, label %bb1
bb8:
  br label %bb3
bb9:
  br label %bb3
bb10:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr { i64, [2 x i64] }, ptr %t58, i32 0, i32 1
  %t60 = getelementptr { i64, i64 }, ptr %t59, i32 0, i32 1
  %t61 = load i64, ptr %t60
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr { i64, [2 x i64] }, ptr %t62, i32 0, i32 1
  %t64 = getelementptr { i64, i64 }, ptr %t63, i32 0, i32 1
  %t65 = load i64, ptr %t64
  %t68 = icmp eq i64 %t61, %t65
  br i1 %t68, label %bb11, label %bb1
bb11:
  br label %bb3
bb12:
  br label %bb3
bb13:
  %t70 = load i1, ptr %l2, !tbaa !21
  store i1 %t70, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_ert_req_clear()
@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d1 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"where the generator does" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d2 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"with what '" }>, align 8
@.d3 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"' refers to" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d4 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d5 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d6 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d7 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d9 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d10 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d11 = private constant <{ i64, [0 x i32] }> <{ i64 0, [0 x i32] [] }>, align 8
@.d12 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"mut " }>, align 8
@.d13 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"&" }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d15 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"return" }>, align 8
@.d16 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"the instance" }>, align 8
@.d17 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"the closing scope" }>, align 8
define linkonce_odr %"compiler/scope:walked" @olang_2eHelperKind_2eZero_2ecompiler_2fscope_3awalked(ptr %v0) #0 {
entry:
  %l0 = alloca %"compiler/scope:walked"
  %rv = alloca %"compiler/scope:walked"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"compiler/scope:walked" @compiler_2fscope_3awalked_2ector(ptr %v0)
  store %"compiler/scope:walked" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"compiler/scope:walked", ptr %l0
  store %"compiler/scope:walked" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scope:walked", ptr %rv
  ret %"compiler/scope:walked" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aV_H3bb336b48f9f9239e303a7a9a8cec160(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_H01b6fb75b9cc96416bdc55b4e10a9a4d(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fsource_3aSpan_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_61be1b0fda526a24_254af50801a17418 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_43341c2c50c8e99b_9adf33b0078f612f = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_f704225c3a4a2006_7f75d15fe5a9495a = external constant [0 x i8]
declare i1 @compiler_2fscope_2ehasRel(ptr %v0, ptr %a0, %"compiler/scope:rel" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2ePush_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %a0, %"compiler/scope:rel" %a1)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esetEnd(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_ade2525ec560ecac_5eadaea182574e0 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ePush_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare %"compiler/scope:agreeAt" @compiler_2fscope_3aagreeAt_2ector(ptr %v0, { i64, [2 x i64] } %a0, i1 %a1)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eorder(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2)
@olang_loc_75a473c9145829d0_168d550c974bebd4 = external constant [0 x i8]
@olang_loc_2b3cb67345c2bf61_96483393ea0a8285 = external constant [0 x i8]
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elandTerm(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_85776ac018629bcc_231804c012e3a7c0 = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunPromoted(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erecOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_2489ab739aea8b00_863e154a28bdb8e4 = external constant [0 x i8]
declare %"compiler/scope:Val" @compiler_2fscope_2eplain()
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2)
@olang_loc_76dd643541c5999_442dc791771fad = external constant [0 x i8]
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblockTerm(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0, i64 %a1, { i64, [2 x i64] } %a2)
declare i1 @compiler_2fscope_2eflHas(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esetOf(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_a61f6227542ac272_aba93d64b04206c6 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_f34ecaa27a4fd2b3_7961e1dcca83cdb7 = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estmts(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePop_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0)
@olang_loc_b442aabc3e151319_4a7d8af854ba830d = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ereassigned(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteLate(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hb676fcc2696545b94a8186e92757a5eb(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eLen_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsInto(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, %"compiler/source:Span" %a2, i64 %a3, %"compiler/source:Span" %a4)
@olang_loc_43515980f8c6aee5_797864ac7e38a2e9 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartOK(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2)
@olang_loc_51647c5149cfd088_fff8b53f00e80584 = external constant [0 x i8]
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebodyOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esummed(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eresultVarOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %a0)
declare %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekTerm(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estaticVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
@olang_loc_40698dacb4c14a59_3145716d01d07175 = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
@olang_loc_fe18b6f8ffe1c828_d6769ee32e48c6ec = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecapturesNothing(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_6e154fb23d94f618_2ee03e6b3f75e7ac = external constant [0 x i8]
@olang_loc_e36c9ef691e1ece9_3ba86da2e7516a5d = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarriedPlace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecanKeep(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare i1 @compiler_2ftyped_2ePassesRefs(i32 %a0)
@olang_loc_9675e93c9f07526d_8a86ee267fb7b3d9 = external constant [0 x i8]
@olang_loc_768f72a2579754c5_d91cee094dc07e21 = external constant [0 x i8]
@olang_loc_15f791c29ca5960e_c2f6ea53b6b5628a = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_d9b9c9fdb1541cd0_611f76d9a930dfc4 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2earenaValue(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_fc2d23a56a9972c4_138c6d588cf96ab0 = external constant [0 x i8]
@olang_loc_3c97826faaf501b5_26e177716b83aa41 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
@olang_loc_f7f7e8cd8f874575_c4b9e23387941a21 = external constant [0 x i8]
@olang_loc_fdfd3ee9277a2fdd_9e10cfc7d92600f9 = external constant [0 x i8]
@olang_loc_933cba94e4afba7f_7f3963489057e55b = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisStruct(ptr %v0, ptr %a0, i32 %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efieldMark(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ectorParamIndex(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_a845573c521645ec_3201dcbaaced68 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ectorParams(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_1acba385e9948a9d_2fa01f36b12cdd39 = external constant [0 x i8]
@olang_loc_c629952a85fc4586_8463807efabcbcc2 = external constant [0 x i8]
@olang_loc_fb66d6a098581c09_2fd4002f8136e06d = external constant [0 x i8]
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparamIndex(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_cd1d16db8329fc51_df7e5714e2c1cec5 = external constant [0 x i8]
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erecAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartsTerm(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fscope_2ethroughElem(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
@olang_loc_4a18cd046f6561ba_7ee6763527d0100e = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnFuncTooShort(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnArgHoldsShort(ptr %v0)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/msgs:Msg" %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeMayNotOutlive(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReferenceNarrowed(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2ePayloadOutlived(ptr %v0)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egenElemTerm(ptr %v0, ptr %a0)
@olang_loc_12677068e04dfe45_ab703d1ad408b711 = external constant [0 x i8]
@olang_loc_bf00db29bdc1b99e_9dc03d0b43789e0a = external constant [0 x i8]
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenYieldShorter(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOwnCannotOutlive(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eStoredRefOutlived(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eElemNotInArrayScope(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eElemOutlived(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyCopyOutlived(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eGlobalHoldsShorter(ptr %v0)
@olang_loc_2de0ba6211cb93cf_481b942389356f0b = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eYieldOwnStorage(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnOwnStorage(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eValueRefsOutlived(ptr %v0)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisMethodCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflAdd(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarries(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eoutside(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fscope_2eflThroughRefExpr(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnUse_3e_2eLen_3ccompiler_2fscope_3afnUse_3e(ptr %v0, ptr %a0)
declare %"compiler/scope:fnUse" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnUse_3e_2eAt_3ccompiler_2fscope_3afnUse_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCallValueObligations(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
@olang_loc_27754b85c0c4924f_acb66791c9f4f5d3 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eFuncValueObligations(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eFromTypeVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@olang_loc_932a31ce6b630e99_55999437bdf20e8d = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_fc32950df7c04da2_11eedb932326b4f6 = external constant [0 x i8]
@olang_loc_af9ca28b921c6ea3_fa663a0c518bad97 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenYieldsBorrow(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaValueObligations(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaValueRelates(ptr %v0)
@olang_loc_3451003dd1e97df4_bcd12f7be62952d8 = external constant [0 x i8]
declare i64 @compiler_2fscope_2eflRoot(ptr %v0, ptr %a0)
declare i1 @compiler_2fscope_2eflThroughRef(ptr %v0, ptr %a0)
declare { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeHere(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elift(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_c4815f8d08aa5069_e0d3df7c014ad4fd = external constant [0 x i8]
@olang_loc_f2ff34bd09efe7b1_f9738b06cf9c6415 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_e2ea0fea769db7e4_aa8c1e0e7de89fc8 = external constant [0 x i8]
@olang_loc_4421e2d51127c851_53479ba5c20af2ad = external constant [0 x i8]
@olang_loc_ba8e38ed7d6b48a9_35acc5c55c21205 = external constant [0 x i8]
@olang_loc_d38420f770b56a25_293628bae4d10df9 = external constant [0 x i8]
@olang_loc_7d2ed71f654b640d_ba09ac545853f0c1 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_4d20f13e93e5e00_8edf44d94b0465ac = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_f39b1bd504b33948_8115a077853ab66c = external constant [0 x i8]
@olang_loc_707f747640e7de9_bc077dc74ca6c70d = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
@olang_loc_c0ef91a3e2c3a370_7d348321302c732c = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehandedRegion(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeStoresArg(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleePutsArg(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
@olang_loc_bf024f3f8d6f4701_89fcb258d807f5dd = external constant [0 x i8]
@olang_loc_791e790d87101aea_cc84b762fb4c0ac6 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehandleLent(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, ptr %a3)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeKeepsArg(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
@olang_loc_21c4adf4625d97ab_9350e01b86c380a7 = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_4f09217bbbe73e28_17ebc948c6ad3e44 = external constant [0 x i8]
declare %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H7e82b4dbdb79c77bc51fdaf9d4704834(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cI64_2c_20compiler_2ftyped_3aExpr_2_H4ea279ff901448a8d94a2f42aa119fd2(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_42ddfa07d54a3511_7eb6b931dfed5aa5 = external constant [0 x i8]
@olang_loc_133169b3f1711469_c566838c26ef218d = external constant [0 x i8]
@olang_loc_31030507f1509b32_81bbcae78c23c7f6 = external constant [0 x i8]
@olang_loc_406ffa91c23643d5_a8a413026b137651 = external constant [0 x i8]
@olang_loc_a53dc1127e8f642e_8cd05a2a2a6c7d4a = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eLen__Hdc799a0fe091f8e84d50200d058b631d(ptr %v0, ptr %a0)
@olang_loc_ce604c7c8d78c55f_37d65431cab9ef4b = external constant [0 x i8]
declare %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_bfbb893df1c35f5d_ebb7b8931b043491 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estaticLiteral(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_13609328335a5af4_71f6842a5be0a9a0 = external constant [0 x i8]
@olang_loc_2a83bf20490fb4f0_b79be661c23cb1e4 = external constant [0 x i8]
@olang_loc_28967cbbf3bb5881_fc5c9419ee26cbd5 = external constant [0 x i8]
@olang_loc_e2b2a689ed5c2c6a_2e02b8bd326f399e = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eRoleCtor = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteThroughResult(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, i64 %a3, { i64, ptr } %a4, i64 %a5)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
@olang_loc_9f5a8ccf03b4db04_630c918a623736e8 = external constant [0 x i8]
@olang_loc_f8891e21139a6c8c_91dd882c9f718fa8 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewordAt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
@olang_loc_7cb574562870c9ae_44cb25218e79651a = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteBindingWhere(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, %"compiler/msgs:Msg" %a4)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eindexCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeName(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@olang_loc_a5d7ffc0375a2adf_b8092e4cba9985db = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteMakeWhere(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnsubst(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i32 %a3)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eYield(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@olang_loc_b5bb9adcdc2b0f40_ee4aa96e819ebaec = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDeclareWhere(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efloorOf(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
@olang_loc_322b5045d3cabfc4_8f4e43b4ddbaa588 = external constant [0 x i8]
@olang_loc_7295af1014264eb5_7e53551048ac1f59 = external constant [0 x i8]
declare %"compiler/scope:rel" @compiler_2fscope_3arel_2ector(ptr %v0, { i64, [2 x i64] } %a0, { i64, [2 x i64] } %a1, i1 %a2, %"compiler/source:Span" %a3, i64 %a4)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eocExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i1 %a3)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eLen__H22c160154c8542d83ffe3c77c98973d0(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eAt_3ccompiler_2ftyped_3aLvalue_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fscope_2ewithin(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_40b97f37a7371750_40728193df6350fc = external constant [0 x i8]
@olang_loc_f651c1e1d8a1ace1_d593723da6a130ad = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elastName(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
@olang_loc_77d8df1bd6b52079_f0229fa895aca615 = external constant [0 x i8]
@olang_loc_bfd80b0298b19652_e537c33c4d886a6e = external constant [0 x i8]
@olang_loc_b1757fdcabe82f93_e12b45afd85e1a9f = external constant [0 x i8]
@olang_loc_a9000624b37114eb_4f5d8570083b5047 = external constant [0 x i8]
@olang_loc_6cb6018c48b7e44c_30fb4d691284a4b0 = external constant [0 x i8]
@olang_loc_50c5af6b9a55d13c_b172bff682b06040 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_74d9849f1cf072e4_d95edc215f7aa198 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_b99a325748da8cd5_4eb62b65b3c79869 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eadmitsStores(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evalueAdmits(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2ePayloadScopesDisagree(ptr %v0)
declare { i32, { i64, [2 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_H65b4b9a6d1679f5b3ddedaa5b2e336bd(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_a696eb2979219c3c_c9efb41471de78f8 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erunLength(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_7a4f424795892e70_52f604b9bdf9a7cc = external constant [0 x i8]
@olang_loc_da1486de58138450_28784370eb22bac = external constant [0 x i8]
@olang_loc_554265ba1528b3d8_d73d8ae267adc184 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisData(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_c484f993348186a9_88a471068962d75 = external constant [0 x i8]
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparamRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eopTok(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyToBuiltResultNo(ptr %v0)
@olang_loc_86025ef78c18fd61_51e54585f4e29a5d = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyToBuiltResult(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_ef7f9cdde83b319d_c7773e471ac0d6b1 = external constant [0 x i8]
@olang_loc_2a41cd82eb4d8236_be11ba524906eaaa = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisLambda(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_b810a17036e0b04c_ef2bb18623cc9e48 = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleRooted(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esolePlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
@olang_loc_df5619edc5954020_95eed2e83037cdb4 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleBorrow(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleStrictBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleArm(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
@olang_loc_80a42f326454c431_eaf1445ab36ad4e5 = external constant [0 x i8]
@olang_loc_fdb46d1d9262e41a_919c32215229332e = external constant [0 x i8]
@olang_loc_3a379002e95ffe1b_e75bb6252129afef = external constant [0 x i8]
@olang_loc_ae81d4d244f6a670_8f3729da339b0a94 = external constant [0 x i8]
@olang_loc_9da86a51b48ec4c_4c8b634b3e5eba18 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aStmt_2eSpan(ptr %v0, ptr %a0)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elet(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eassign(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eret(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eforWrap(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2espawn(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
@olang_loc_e68fbdb964820230_ed59a3d360e211c = external constant [0 x i8]
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eregionParam(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_d10963641a9b1fed_5d8116c763841fe1 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eassignableHolds(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_fab9d5262c098304_b0d84a3f5fe3aa00 = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_678543b1c51fd044_bcff5a6e112a6af8 = external constant [0 x i8]
@olang_loc_90a9d28716f9cb6_29834bc9108cc36a = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efirstToken(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eStrStoresInReceiver(ptr %v0)
@olang_loc_a7a579971a154b67_66936e5e8b24a2eb = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteStrBuildsHere(ptr %v0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ethroughDerivedExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ederivedRead(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_7f73b55f7a2eb5e4_273c44187eceff80 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i64 %a2)
@olang_loc_a99f843f7bf434a0_94e1f929e5b915f4 = external constant [0 x i8]
@olang_loc_4aed99841ab3b8b1_8d3edbdcac983025 = external constant [0 x i8]
@olang_loc_c7fdd76f48c1d89a_56d68a9de61a546e = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eocBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i1 %a3)
@olang_loc_3af8b11586f6b4c8_66242c1d15d5a764 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4)
declare { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elocalName(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i32 %a2, ptr %a3)
@olang_loc_33e8f6984fda8b38_987c5f6a5f702884 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eatCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fscope_2etempOf(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v0, ptr %a0)
@olang_loc_dd80a499a713524_336e9d155656b240 = external constant [0 x i8]
@olang_loc_56e16192221ba415_394443c36fbf1ad1 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enameSpan(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2euses(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3)
@olang_loc_704f1e45d26fb2de_b63ff9ec5bfa803a = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnAtElement(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eWriteThroughAtCall(ptr %v0)
declare { i32, %"compiler/source:Span" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H7d5384a5030fc995e793b3fe1f57e776(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteViewRefusedBy(ptr %v0)
@olang_loc_8ccf378ebead7f5f_f5ae40f475d40cbb = external constant [0 x i8]
@olang_loc_df7e42d0d720f8e0_ba1485f60a37606c = external constant [0 x i8]
@olang_loc_29ab6d94cb2a37cc_d7a08cac8eb9a0a8 = external constant [0 x i8]
declare %"compiler/scope:Val" @compiler_2fscope_3aVal_2ector(ptr %v0, i32 %a0, { i64, [2 x i64] } %a1)
@olang_loc_e9d57cf77a66352c_e30832457df38478 = external constant [0 x i8]
@olang_loc_f7b7284e8bdb42c_7d0460b025534e78 = external constant [0 x i8]
@olang_loc_1335909b8009e6b8_227574ff00a357c4 = external constant [0 x i8]
@olang_loc_18ba62b867b30c89_62dfd3c940fee6b5 = external constant [0 x i8]
@olang_loc_926310a74149af64_7456b8629edeed00 = external constant [0 x i8]
@olang_loc_d723be5f6d33c955_f64e13843779cd91 = external constant [0 x i8]
@olang_loc_6421b9c211daea5c_85adafb275b4c978 = external constant [0 x i8]
@olang_loc_30366b1ce1cb05a4_de371b7365ebcc00 = external constant [0 x i8]
@olang_loc_c76fb05b477ad754_aaa77e81edb6bb58 = external constant [0 x i8]
@olang_loc_472a8ee29a396e05_19ea125b0d0f8e29 = external constant [0 x i8]
declare void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2ftyped_3aPlan_2ector(ptr %out, ptr %v0, i64 %a0, i64 %a1, i64 %a2)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnUse_3e_2ector(ptr %v0, i64 %a0)
declare %"compiler/scope:walked" @compiler_2fscope_3awalked_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fsource_3aSpan_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
