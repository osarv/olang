; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/emit:Emitter" = type { ptr, ptr, ptr, ptr, i1, i1, i1, i1, i1, i1, i1, i1, { i64, ptr }, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, { i64, ptr }, { i64, ptr }, i64, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, { i64, ptr }, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, i1, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, { i64, ptr }, i64, { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/cabi:Way" = type { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr } }
%"compiler/cabi:Regs" = type { i64, i64 }
%"compiler/mir:Fn" = type { { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/lower:Lowerer" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/typed:Plan", ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i32, i32, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/typed:RefsKept", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/mir:GenInfo", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64 }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:RefsKept" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/mir:GenInfo" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/emit:fnEm" = type { ptr, ptr, { i64, [2 x i64] }, %"std/prelude/text:StringBuilder", %"std/prelude/text:StringBuilder", %"std/prelude/text:StringBuilder", i64, i64, i64, i32, i1, i1, i1, i1, i1, { i64, ptr }, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/text:StringBuilder", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, { i64, ptr }, i1 }
%"compiler/emit:Reused" = type { i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, ptr, i32 }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/mir:ScopeInfo" = type { i32, i32, i32, %"compiler/source:Span", i32 }
%"compiler/mir:Call" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Lvalue", i1, i32, i32, i32 }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/mir:Lvalue" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/lower:Clone" = type { { i64, [2 x i64] }, i64, { i64, [2 x i64] }, i32 }
%"compiler/mir:BasicBlock" = type { %"compiler/mir:StmtList", { i64, [8 x i64] } }
%"compiler/mir:StmtList" = type { { i64, ptr }, i64 }
%"compiler/mir:Task" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/source:Span", %"compiler/mir:Range", i64, i64, %"compiler/mir:Range" }
%"compiler/mir:TaskClause" = type { %"compiler/mir:Range", i1, { i64, [4 x i64] } }
%"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" = type { ptr, i64 }
%"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgPair(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, i32 %a3, { i64, ptr } %a4, i32 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca i64
  %l21 = alloca i64
  %l27 = alloca i64
  %l29 = alloca i64
  %l35 = alloca i64
  %l37 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l42 = alloca { i64, ptr }
  %l49 = alloca i64
  %l51 = alloca i64
  %l53 = alloca i64
  %l72 = alloca ptr
  %l73 = alloca i64
  %l76 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a3, ptr %l3
  store i32 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t1)
  store i64 %t3, ptr %l14
  br label %bb1
bb1:
  %t4 = load i64, ptr %l14, !tbaa !24
  store i64 %t4, ptr %l6, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/emit:Emitter", ptr %t5, i32 0, i32 84
  %t8 = load i32, ptr %l1, !tbaa !23
  %t10 = sext i32 %t8 to i64
  %t11 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t7, i64 %t10, i64 %t11)
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgVoidPtr(ptr %v0, ptr %t15)
  store i64 %t17, ptr %l21
  br label %bb3
bb3:
  %t18 = load i64, ptr %l21, !tbaa !24
  store i64 %t18, ptr %l7, !tbaa !24
  %t19 = load i32, ptr %l3, !tbaa !23
  %t20 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t23 = icmp ne i32 %t19, %t20
  br i1 %t23, label %bb4, label %bb5
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l3, !tbaa !23
  %t29 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgType(ptr %v0, ptr %t25, i32 %t26)
  store i64 %t29, ptr %l27
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t30 = load i64, ptr %l27, !tbaa !24
  store i64 %t30, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgVoidPtr(ptr %v0, ptr %t31)
  store i64 %t33, ptr %l29
  br label %bb8
bb8:
  %t34 = load i64, ptr %l29, !tbaa !24
  store i64 %t34, ptr %l8, !tbaa !24
  %t35 = load i32, ptr %l5, !tbaa !23
  %t36 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t39 = icmp ne i32 %t35, %t36
  br i1 %t39, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l5, !tbaa !23
  %t45 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgType(ptr %v0, ptr %t41, i32 %t42)
  store i64 %t45, ptr %l35
  br label %bb11
bb10:
  br label %bb17
bb11:
  %t46 = load i64, ptr %l35, !tbaa !24
  store i64 %t46, ptr %l9, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t47)
  store i64 %t49, ptr %l37
  br label %bb12
bb12:
  %t50 = load i64, ptr %l37, !tbaa !24
  store i64 %t50, ptr %l8, !tbaa !24
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l38, !tbaa !29
  %t52 = load i64, ptr %l8, !tbaa !24
  store i64 %t52, ptr %l39, !tbaa !24
  %t53 = load i64, ptr %l9, !tbaa !24
  %t55 = icmp sge i64 %t53, 0
  br i1 %t55, label %bb13, label %bb14
bb13:
  %t57 = load i64, ptr %l9, !tbaa !24
  %t58 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t59 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t61 = call i64 @__olang_fmt_i64(ptr null, i64 %t57)
  %t62 = add i64 %t59, %t61
  %t63 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t62)
  call void @olang_textcopy(ptr %t63, ptr %t58, i64 %t59)
  %t64 = getelementptr i8, ptr %t63, i64 %t59
  %t65 = call i64 @__olang_fmt_i64(ptr %t64, i64 %t57)
  %t66 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t63, 1
  store { i64, ptr } %t67, ptr %l42, !tbaa !27
  br label %bb15
bb14:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l42, !tbaa !27
  br label %bb15
bb15:
  %t70 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t71 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t72 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 1
  %t74 = extractvalue { i64, ptr } %t72, 0
  %t75 = add i64 %t71, %t74
  %t76 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t77 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t78 = add i64 %t75, %t77
  %t79 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t78)
  call void @olang_textcopy(ptr %t79, ptr %t70, i64 %t71)
  %t80 = getelementptr i8, ptr %t79, i64 %t71
  call void @olang_textcopy(ptr %t80, ptr %t73, i64 %t74)
  %t81 = getelementptr i8, ptr %t80, i64 %t74
  call void @olang_textcopy(ptr %t81, ptr %t76, i64 %t77)
  %t82 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t79, 1
  %t85 = load ptr, ptr %l38, !tbaa !29
  %t86 = load i64, ptr %l39, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s2, ptr %t85, i64 %t86, { i64, ptr } %t83)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t88)
  store i64 %t90, ptr %l49
  br label %bb18
bb18:
  %t91 = load i64, ptr %l49, !tbaa !24
  store i64 %t91, ptr %l10, !tbaa !24
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t92)
  store i64 %t94, ptr %l51
  br label %bb19
bb19:
  %t95 = load i64, ptr %l51, !tbaa !24
  store i64 %t95, ptr %l11, !tbaa !24
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t96)
  store i64 %t98, ptr %l53
  br label %bb20
bb20:
  %t99 = load i64, ptr %l53, !tbaa !24
  store i64 %t99, ptr %l12, !tbaa !24
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load i64, ptr %l10, !tbaa !24
  %t103 = load i64, ptr %l7, !tbaa !24
  %t104 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t105 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t107 = extractvalue { i64, ptr } %a2, 1
  %t108 = extractvalue { i64, ptr } %a2, 0
  %t109 = add i64 %t105, %t108
  %t110 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t111 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t112 = add i64 %t109, %t111
  %t114 = call i64 @__olang_fmt_i64(ptr null, i64 %t103)
  %t115 = add i64 %t112, %t114
  %t116 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t117 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t118 = add i64 %t115, %t117
  %t119 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t118)
  call void @olang_textcopy(ptr %t119, ptr %t104, i64 %t105)
  %t120 = getelementptr i8, ptr %t119, i64 %t105
  call void @olang_textcopy(ptr %t120, ptr %t107, i64 %t108)
  %t121 = getelementptr i8, ptr %t120, i64 %t108
  call void @olang_textcopy(ptr %t121, ptr %t110, i64 %t111)
  %t122 = getelementptr i8, ptr %t121, i64 %t111
  %t123 = call i64 @__olang_fmt_i64(ptr %t122, i64 %t103)
  %t124 = getelementptr i8, ptr %t122, i64 %t114
  call void @olang_textcopy(ptr %t124, ptr %t116, i64 %t117)
  %t125 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t119, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s0, ptr %t100, i64 %t101, { i64, ptr } %t126)
  br label %bb21
bb21:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i64, ptr %l11, !tbaa !24
  %t134 = load i64, ptr %l8, !tbaa !24
  %t135 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t136 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t138 = extractvalue { i64, ptr } %a4, 1
  %t139 = extractvalue { i64, ptr } %a4, 0
  %t140 = add i64 %t136, %t139
  %t141 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t142 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t143 = add i64 %t140, %t142
  %t145 = call i64 @__olang_fmt_i64(ptr null, i64 %t134)
  %t146 = add i64 %t143, %t145
  %t147 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t148 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t149 = add i64 %t146, %t148
  %t150 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t149)
  call void @olang_textcopy(ptr %t150, ptr %t135, i64 %t136)
  %t151 = getelementptr i8, ptr %t150, i64 %t136
  call void @olang_textcopy(ptr %t151, ptr %t138, i64 %t139)
  %t152 = getelementptr i8, ptr %t151, i64 %t139
  call void @olang_textcopy(ptr %t152, ptr %t141, i64 %t142)
  %t153 = getelementptr i8, ptr %t152, i64 %t142
  %t154 = call i64 @__olang_fmt_i64(ptr %t153, i64 %t134)
  %t155 = getelementptr i8, ptr %t153, i64 %t145
  call void @olang_textcopy(ptr %t155, ptr %t147, i64 %t148)
  %t156 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t150, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s0, ptr %t131, i64 %t132, { i64, ptr } %t157)
  br label %bb22
bb22:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load i64, ptr %l12, !tbaa !24
  %t164 = load i64, ptr %l10, !tbaa !24
  %t165 = load i64, ptr %l11, !tbaa !24
  %t166 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t167 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t169 = call i64 @__olang_fmt_i64(ptr null, i64 %t164)
  %t170 = add i64 %t167, %t169
  %t171 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t172 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t173 = add i64 %t170, %t172
  %t175 = call i64 @__olang_fmt_i64(ptr null, i64 %t165)
  %t176 = add i64 %t173, %t175
  %t177 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t178 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t179 = add i64 %t176, %t178
  %t180 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t179)
  call void @olang_textcopy(ptr %t180, ptr %t166, i64 %t167)
  %t181 = getelementptr i8, ptr %t180, i64 %t167
  %t182 = call i64 @__olang_fmt_i64(ptr %t181, i64 %t164)
  %t183 = getelementptr i8, ptr %t181, i64 %t169
  call void @olang_textcopy(ptr %t183, ptr %t171, i64 %t172)
  %t184 = getelementptr i8, ptr %t183, i64 %t172
  %t185 = call i64 @__olang_fmt_i64(ptr %t184, i64 %t165)
  %t186 = getelementptr i8, ptr %t184, i64 %t175
  call void @olang_textcopy(ptr %t186, ptr %t177, i64 %t178)
  %t187 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t180, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s0, ptr %t162, i64 %t163, { i64, ptr } %t188)
  br label %bb23
bb23:
  %t193 = load ptr, ptr %l0, !tbaa !29
  store ptr %t193, ptr %l72, !tbaa !29
  %t194 = load i64, ptr %l6, !tbaa !24
  store i64 %t194, ptr %l73, !tbaa !24
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t196 = load i32, ptr %l1, !tbaa !23
  %t199 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgTypeName(ptr %v0, ptr %s0, ptr %t195, i32 %t196)
  store { i64, ptr } %t199, ptr %l76
  br label %bb24
bb24:
  %t200 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t202 = call { i64, ptr } @compiler_2femit_2eescape(ptr %s0, ptr %s0, { i64, ptr } %t200)
  store { i64, ptr } %t202, ptr %l78
  br label %bb25
bb25:
  %t203 = load i64, ptr %l12, !tbaa !24
  %t204 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t205 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t206 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t207 = extractvalue { i64, ptr } %t206, 1
  %t208 = extractvalue { i64, ptr } %t206, 0
  %t209 = add i64 %t205, %t208
  %t210 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t211 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t212 = add i64 %t209, %t211
  %t214 = call i64 @__olang_fmt_i64(ptr null, i64 %t203)
  %t215 = add i64 %t212, %t214
  %t216 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t217 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t218 = add i64 %t215, %t217
  %t219 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t218)
  call void @olang_textcopy(ptr %t219, ptr %t204, i64 %t205)
  %t220 = getelementptr i8, ptr %t219, i64 %t205
  call void @olang_textcopy(ptr %t220, ptr %t207, i64 %t208)
  %t221 = getelementptr i8, ptr %t220, i64 %t208
  call void @olang_textcopy(ptr %t221, ptr %t210, i64 %t211)
  %t222 = getelementptr i8, ptr %t221, i64 %t211
  %t223 = call i64 @__olang_fmt_i64(ptr %t222, i64 %t203)
  %t224 = getelementptr i8, ptr %t222, i64 %t214
  call void @olang_textcopy(ptr %t224, ptr %t216, i64 %t217)
  %t225 = insertvalue { i64, ptr } undef, i64 %t218, 0
  %t226 = insertvalue { i64, ptr } %t225, ptr %t219, 1
  %t228 = load ptr, ptr %l72, !tbaa !29
  %t229 = load i64, ptr %l73, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s0, ptr %t228, i64 %t229, { i64, ptr } %t226)
  br label %bb26
bb26:
  %t231 = load i64, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t231, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgVoidPtr(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l6 = alloca i64
  %s1 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 81
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp slt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l6
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t12 = load i64, ptr %l6, !tbaa !24
  %t13 = load ptr, ptr %l4, !tbaa !29
  %t14 = getelementptr %"compiler/emit:Emitter", ptr %t13, i32 0, i32 81
  store i64 %t12, ptr %t14, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/emit:Emitter", ptr %t16, i32 0, i32 81
  %t19 = load i64, ptr %t18, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s1, ptr %t15, i64 %t19, { i64, ptr } { i64 66, ptr getelementptr inbounds (<{ i64, [66 x i8] }>, ptr @.d16, i32 0, i32 1) })
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/emit:Emitter", ptr %t22, i32 0, i32 81
  %t25 = load i64, ptr %t24, !tbaa !24
  store i64 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eexportParams(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, i32 %a2, ptr %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca { i64, ptr }
  %l19 = alloca i32
  %l20 = alloca { i64, ptr }
  %l21 = alloca %"compiler/cabi:Way"
  %l22 = alloca i32
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l36 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l49 = alloca i64
  %l52 = alloca i64
  %l70 = alloca { i64, ptr }
  %l75 = alloca i1
  %l78 = alloca i32
  %l79 = alloca i64
  %l82 = alloca { i64, ptr }
  %l88 = alloca i1
  %l89 = alloca ptr
  %l92 = alloca i32
  %l93 = alloca i32
  %l96 = alloca i32
  %l99 = alloca i1
  %l102 = alloca i32
  %l104 = alloca ptr
  %l105 = alloca i64
  %l110 = alloca ptr
  %l111 = alloca i64
  %l116 = alloca ptr
  %l124 = alloca { i64, ptr }
  %l125 = alloca ptr
  %l126 = alloca i64
  %l133 = alloca { i64, ptr }
  %l136 = alloca ptr
  %l137 = alloca i64
  %l142 = alloca ptr
  %l146 = alloca ptr
  %l147 = alloca i64
  %l152 = alloca ptr
  %l154 = alloca { i64, ptr }
  %l159 = alloca %"compiler/cabi:Way"
  %l163 = alloca ptr
  %l164 = alloca i64
  %l168 = alloca { i64, ptr }
  %l170 = alloca i1
  %l172 = alloca { i64, ptr }
  %l179 = alloca ptr
  %l180 = alloca i64
  %l184 = alloca { i64, ptr }
  %l190 = alloca ptr
  %l194 = alloca i64
  %l197 = alloca { i64, ptr }
  %l199 = alloca i64
  %l203 = alloca i64
  %l206 = alloca i64
  %l224 = alloca ptr
  %l225 = alloca i64
  %l229 = alloca { i64, ptr }
  %l236 = alloca i64
  %l238 = alloca { i64, ptr }
  %l240 = alloca ptr
  %l241 = alloca { i64, ptr }
  %l244 = alloca i64
  %l247 = alloca { i64, ptr }
  %l248 = alloca i64
  %l249 = alloca { i64, ptr }
  %l250 = alloca ptr
  %l253 = alloca { i64, ptr }
  %l255 = alloca { i64, ptr }
  %l256 = alloca { i64, ptr }
  %l257 = alloca { i64, ptr }
  %l268 = alloca i64
  %l270 = alloca { i64, ptr }
  %l271 = alloca i64
  %l272 = alloca { i64, ptr }
  %l273 = alloca { i64, ptr }
  %l278 = alloca ptr
  %l279 = alloca i64
  %l283 = alloca { i64, ptr }
  %l286 = alloca i64
  %l287 = alloca i64
  %l291 = alloca ptr
  %l292 = alloca i64
  %l302 = alloca { i64, ptr }
  %l303 = alloca ptr
  %l304 = alloca { i64, ptr }
  %l305 = alloca { i64, ptr }
  %l308 = alloca i64
  %l309 = alloca ptr
  %l310 = alloca i64
  %l315 = alloca ptr
  %l316 = alloca i64
  %l320 = alloca { i64, ptr }
  %l321 = alloca ptr
  %l324 = alloca { i64, ptr }
  %l327 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s32 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/emit:Emitter", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  store ptr %t9, ptr %l7, !tbaa !29
  %t11 = load ptr, ptr %l6, !tbaa !29
  store ptr %t11, ptr %l36, !tbaa !29
  %t12 = load ptr, ptr %l6, !tbaa !29
  %t13 = load i32, ptr %l2, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l39
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l36, !tbaa !29
  %t18 = load i32, ptr %l39, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t17, i32 %t18)
  store { i64, ptr } %t19, ptr %l40
  br label %bb2
bb2:
  %t20 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t20, ptr %l8, !tbaa !27
  %t21 = load ptr, ptr %l6, !tbaa !29
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePassing(ptr %v0, ptr %s0, ptr %t21, i32 %t22)
  store { i64, ptr } %t25, ptr %l43
  br label %bb3
bb3:
  %t26 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t26, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t27 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  store i64 %t29, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t31 = load i64, ptr %l11, !tbaa !24
  %t32 = load i64, ptr %l10, !tbaa !24
  %t35 = icmp sgt i64 %t31, %t32
  br i1 %t35, label %bb4, label %bb5
bb4:
  %t37 = load i64, ptr %l12, !tbaa !24
  %t39 = icmp sgt i64 %t37, 0
  br i1 %t39, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb9
bb6:
  %t41 = load i64, ptr %l11, !tbaa !24
  %t42 = load i64, ptr %l10, !tbaa !24
  %t45 = sub i64 %t41, %t42
  %t46 = load i64, ptr %l12, !tbaa !24
  %t49 = add i64 %t45, %t46
  %t51 = sub i64 %t49, 1
  %t52 = load i64, ptr %l12, !tbaa !24
  %t55 = sdiv i64 %t51, %t52
  store i64 %t55, ptr %l52, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb8
bb8:
  %t57 = load i64, ptr %l52, !tbaa !24
  store i64 %t57, ptr %l49, !tbaa !24
  br label %bb9
bb9:
  %t58 = load i64, ptr %l49, !tbaa !24
  store i64 %t58, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t59 = load i64, ptr %l14, !tbaa !24
  %t60 = load i64, ptr %l13, !tbaa !24
  %t63 = icmp slt i64 %t59, %t60
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb143
bb12:
  br label %bb13
bb13:
  %t67 = load i64, ptr %l10, !tbaa !24
  %t68 = load i64, ptr %l14, !tbaa !24
  %t69 = load i64, ptr %l12, !tbaa !24
  %t72 = mul i64 %t68, %t69
  %t75 = add i64 %t67, %t72
  store i64 %t75, ptr %l15, !tbaa !24
  %t77 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t77, ptr %l70, !tbaa !27
  %t78 = load i64, ptr %l15, !tbaa !24
  %t80 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr i32, ptr %t81, i64 %t78
  %t83 = load i32, ptr %t82, !tbaa !33
  store i32 %t83, ptr %l16, !tbaa !23
  %t85 = load ptr, ptr %l7, !tbaa !29
  %t86 = load i32, ptr %l16, !tbaa !23
  %t89 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t85, i32 %t86)
  store i1 %t89, ptr %l75
  br label %bb14
bb14:
  %t90 = load ptr, ptr %l6, !tbaa !29
  %t91 = load i32, ptr %l16, !tbaa !23
  %t94 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t90, i32 %t91)
  store i32 %t94, ptr %l78
  br label %bb15
bb15:
  %t95 = load i32, ptr %l78, !tbaa !23
  store i32 %t95, ptr %l17, !tbaa !23
  %t96 = call ptr @__olang_scope_hold(ptr %s2)
  %t97 = ptrtoint ptr %t96 to i64
  store i64 %t97, ptr %l79, !tbaa !24
  %t98 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3aEmitter__2eexportParams_2elocal_2e18
  br i1 %t98, label %bb16, label %bb17
bb16:
  %t100 = call ptr @__olang_region_make(ptr %s2)
  %t101 = ptrtoint ptr %t100 to i64
  store i64 %t101, ptr %l79, !tbaa !24
  br label %bb17
bb17:
  %t102 = load i64, ptr %l15, !tbaa !24
  %t103 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t104 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t106 = call i64 @__olang_fmt_i64(ptr null, i64 %t102)
  %t107 = add i64 %t104, %t106
  %t108 = load i64, ptr %l79
  %t109 = inttoptr i64 %t108 to ptr
  %t110 = call ptr @__olang_held_alloc(ptr %t109, i64 %t107)
  call void @olang_textcopy(ptr %t110, ptr %t103, i64 %t104)
  %t111 = getelementptr i8, ptr %t110, i64 %t104
  %t112 = call i64 @__olang_fmt_i64(ptr %t111, i64 %t102)
  %t113 = insertvalue { i64, ptr } undef, i64 %t107, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t110, 1
  store { i64, ptr } %t114, ptr %l82, !tbaa !27
  %t115 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3aEmitter__2eexportParams_2elocal_2e18
  br i1 %t115, label %bb18, label %bb19
bb18:
  %t117 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t117, 0
  %t120 = icmp eq i64 %t118, 0
  br i1 %t120, label %bb20, label %bb21
bb19:
  %t122 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t122, ptr %l18, !tbaa !27
  %t123 = load ptr, ptr %l6, !tbaa !29
  %t124 = load i32, ptr %l17, !tbaa !23
  %t127 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t123, i32 %t124)
  store i1 %t127, ptr %l88
  br label %bb22
bb20:
  store { i64, ptr } zeroinitializer, ptr %l82, !tbaa !27
  br label %bb21
bb21:
  %t128 = load i64, ptr %l79
  %t129 = inttoptr i64 %t128 to ptr
  %t130 = load { i64, ptr }, ptr %l82
  %t131 = extractvalue { i64, ptr } %t130, 1
  %t132 = call ptr @__olang_region_or(ptr %t131, ptr null)
  %t133 = icmp ne ptr %t132, null
  %t134 = select i1 %t133, ptr %t132, ptr null
  call void @__olang_region_settle_in(ptr %t129, ptr %t134)
  br label %bb19
bb22:
  %t135 = load i1, ptr %l88, !tbaa !21
  br i1 %t135, label %bb23, label %bb24
bb23:
  %t136 = load ptr, ptr %l6, !tbaa !29
  store ptr %t136, ptr %l89, !tbaa !29
  %t137 = load ptr, ptr %l6, !tbaa !29
  %t138 = load i32, ptr %l17, !tbaa !23
  %t141 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t137, i32 %t138)
  store i32 %t141, ptr %l92
  br label %bb25
bb24:
  br label %bb52
bb25:
  %t142 = load ptr, ptr %l89, !tbaa !29
  %t143 = load i32, ptr %l92, !tbaa !23
  %t144 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t142, i32 %t143)
  store i32 %t144, ptr %l93
  br label %bb26
bb26:
  %t145 = load i32, ptr %l93, !tbaa !23
  store i32 %t145, ptr %l19, !tbaa !23
  %t146 = load ptr, ptr %l6, !tbaa !29
  %t147 = load i32, ptr %l19, !tbaa !23
  %t150 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t146, i32 %t147)
  store i32 %t150, ptr %l96
  br label %bb27
bb27:
  %t151 = load i32, ptr %l96, !range !{i32 0, i32 33}
  %t153 = trunc i64 19 to i32
  %t154 = icmp eq i32 %t151, %t153
  br i1 %t154, label %bb28, label %bb29
bb28:
  %t156 = load ptr, ptr %l6, !tbaa !29
  %t157 = load i32, ptr %l19, !tbaa !23
  %t160 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t156, i32 %t157)
  store i32 %t160, ptr %l102
  br label %bb30
bb29:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb31
bb30:
  %t161 = load i32, ptr %l102, !tbaa !23
  %t162 = icmp eq i32 %t161, 0
  store i1 %t162, ptr %l99, !tbaa !21
  br label %bb31
bb31:
  %t164 = load i1, ptr %l99, !tbaa !21
  br i1 %t164, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s5
  %t165 = load ptr, ptr %l3, !tbaa !29
  store ptr %t165, ptr %l104, !tbaa !29
  %t166 = call ptr @__olang_scope_hold(ptr %v2)
  %t167 = ptrtoint ptr %t166 to i64
  store i64 %t167, ptr %l105, !tbaa !24
  %t168 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t168, label %bb34, label %bb35
bb33:
  %t170 = load ptr, ptr %l3, !tbaa !29
  store ptr %t170, ptr %l136, !tbaa !29
  %t171 = call ptr @__olang_scope_hold(ptr %v2)
  %t172 = ptrtoint ptr %t171 to i64
  store i64 %t172, ptr %l137, !tbaa !24
  %t173 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t173, label %bb45, label %bb46
bb34:
  %t175 = call ptr @__olang_region_make(ptr %v2)
  %t176 = ptrtoint ptr %t175 to i64
  store i64 %t176, ptr %l105, !tbaa !24
  br label %bb35
bb35:
  %t177 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t178 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t179 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t181 = extractvalue { i64, ptr } %t177, 1
  %t182 = extractvalue { i64, ptr } %t177, 0
  %t183 = add i64 %t179, %t182
  %t184 = load i64, ptr %l105
  %t185 = inttoptr i64 %t184 to ptr
  %t186 = call ptr @__olang_held_alloc(ptr %t185, i64 %t183)
  call void @olang_textcopy(ptr %t186, ptr %t178, i64 %t179)
  %t187 = getelementptr i8, ptr %t186, i64 %t179
  call void @olang_textcopy(ptr %t187, ptr %t181, i64 %t182)
  %t188 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t186, 1
  %t191 = load ptr, ptr %l104, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t191, { i64, ptr } %t189)
  br label %bb36
bb36:
  %t193 = load ptr, ptr %l3, !tbaa !29
  store ptr %t193, ptr %l110, !tbaa !29
  %t194 = call ptr @__olang_scope_hold(ptr %v2)
  %t195 = ptrtoint ptr %t194 to i64
  store i64 %t195, ptr %l111, !tbaa !24
  %t196 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t196, label %bb37, label %bb38
bb37:
  %t198 = call ptr @__olang_region_make(ptr %v2)
  %t199 = ptrtoint ptr %t198 to i64
  store i64 %t199, ptr %l111, !tbaa !24
  br label %bb38
bb38:
  %t200 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t201 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t202 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t204 = extractvalue { i64, ptr } %t200, 1
  %t205 = extractvalue { i64, ptr } %t200, 0
  %t206 = add i64 %t202, %t205
  %t207 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t208 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t209 = add i64 %t206, %t208
  %t210 = load i64, ptr %l111
  %t211 = inttoptr i64 %t210 to ptr
  %t212 = call ptr @__olang_held_alloc(ptr %t211, i64 %t209)
  call void @olang_textcopy(ptr %t212, ptr %t201, i64 %t202)
  %t213 = getelementptr i8, ptr %t212, i64 %t202
  call void @olang_textcopy(ptr %t213, ptr %t204, i64 %t205)
  %t214 = getelementptr i8, ptr %t213, i64 %t205
  call void @olang_textcopy(ptr %t214, ptr %t207, i64 %t208)
  %t215 = insertvalue { i64, ptr } undef, i64 %t209, 0
  %t216 = insertvalue { i64, ptr } %t215, ptr %t212, 1
  %t218 = load ptr, ptr %l110, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t218, { i64, ptr } %t216)
  br label %bb39
bb39:
  %t220 = load ptr, ptr %l4, !tbaa !29
  store ptr %t220, ptr %l116, !tbaa !29
  %t221 = load ptr, ptr %l116, !tbaa !29
  %t222 = getelementptr %"compiler/cabi:Regs", ptr %t221, i32 0, i32 0
  %t223 = load i64, ptr %t222, !tbaa !24
  %t226 = sub i64 %t223, 2
  %t228 = load ptr, ptr %l116, !tbaa !29
  %t229 = getelementptr %"compiler/cabi:Regs", ptr %t228, i32 0, i32 0
  store i64 %t226, ptr %t229, !tbaa !24
  %t230 = load ptr, ptr %l1, !tbaa !29
  %t231 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t232 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t233 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t235 = extractvalue { i64, ptr } %t231, 1
  %t236 = extractvalue { i64, ptr } %t231, 0
  %t237 = add i64 %t233, %t236
  %t238 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t239 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t240 = add i64 %t237, %t239
  %t241 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t240)
  call void @olang_textcopy(ptr %t241, ptr %t232, i64 %t233)
  %t242 = getelementptr i8, ptr %t241, i64 %t233
  call void @olang_textcopy(ptr %t242, ptr %t235, i64 %t236)
  %t243 = getelementptr i8, ptr %t242, i64 %t236
  call void @olang_textcopy(ptr %t243, ptr %t238, i64 %t239)
  %t244 = insertvalue { i64, ptr } undef, i64 %t240, 0
  %t245 = insertvalue { i64, ptr } %t244, ptr %t241, 1
  %t249 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v1, ptr %s5, ptr %s5, ptr %v5, ptr %t230, { i64, ptr } %t245)
  store { i64, ptr } %t249, ptr %l124
  br label %bb40
bb40:
  %t250 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t250, ptr %l20, !tbaa !27
  %t251 = load ptr, ptr %l5, !tbaa !29
  store ptr %t251, ptr %l125, !tbaa !29
  %t252 = call ptr @__olang_scope_hold(ptr %v4)
  %t253 = ptrtoint ptr %t252 to i64
  store i64 %t253, ptr %l126, !tbaa !24
  %t254 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t254, label %bb41, label %bb42
bb41:
  %t256 = call ptr @__olang_region_make(ptr %v4)
  %t257 = ptrtoint ptr %t256 to i64
  store i64 %t257, ptr %l126, !tbaa !24
  br label %bb42
bb42:
  %t258 = load ptr, ptr %l1, !tbaa !29
  %t259 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t260 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t261 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t262 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t264 = extractvalue { i64, ptr } %t259, 1
  %t265 = extractvalue { i64, ptr } %t259, 0
  %t266 = add i64 %t262, %t265
  %t267 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t268 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t269 = add i64 %t266, %t268
  %t271 = extractvalue { i64, ptr } %t260, 1
  %t272 = extractvalue { i64, ptr } %t260, 0
  %t273 = add i64 %t269, %t272
  %t274 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t275 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t276 = add i64 %t273, %t275
  %t277 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t276)
  call void @olang_textcopy(ptr %t277, ptr %t261, i64 %t262)
  %t278 = getelementptr i8, ptr %t277, i64 %t262
  call void @olang_textcopy(ptr %t278, ptr %t264, i64 %t265)
  %t279 = getelementptr i8, ptr %t278, i64 %t265
  call void @olang_textcopy(ptr %t279, ptr %t267, i64 %t268)
  %t280 = getelementptr i8, ptr %t279, i64 %t268
  call void @olang_textcopy(ptr %t280, ptr %t271, i64 %t272)
  %t281 = getelementptr i8, ptr %t280, i64 %t272
  call void @olang_textcopy(ptr %t281, ptr %t274, i64 %t275)
  %t282 = insertvalue { i64, ptr } undef, i64 %t276, 0
  %t283 = insertvalue { i64, ptr } %t282, ptr %t277, 1
  %t287 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v1, ptr %s5, ptr %s5, ptr %v5, ptr %t258, { i64, ptr } %t283)
  store { i64, ptr } %t287, ptr %l133
  br label %bb43
bb43:
  %t288 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t289 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t290 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t291 = extractvalue { i64, ptr } %t290, 1
  %t292 = extractvalue { i64, ptr } %t290, 0
  %t293 = add i64 %t289, %t292
  %t294 = load i64, ptr %l126
  %t295 = inttoptr i64 %t294 to ptr
  %t296 = call ptr @__olang_held_alloc(ptr %t295, i64 %t293)
  call void @olang_textcopy(ptr %t296, ptr %t288, i64 %t289)
  %t297 = getelementptr i8, ptr %t296, i64 %t289
  call void @olang_textcopy(ptr %t297, ptr %t291, i64 %t292)
  %t298 = insertvalue { i64, ptr } undef, i64 %t293, 0
  %t299 = insertvalue { i64, ptr } %t298, ptr %t296, 1
  %t301 = load ptr, ptr %l125, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t301, { i64, ptr } %t299)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s5)
  br label %bb51
bb45:
  %t303 = call ptr @__olang_region_make(ptr %v2)
  %t304 = ptrtoint ptr %t303 to i64
  store i64 %t304, ptr %l137, !tbaa !24
  br label %bb46
bb46:
  %t305 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t306 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t307 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t309 = extractvalue { i64, ptr } %t305, 1
  %t310 = extractvalue { i64, ptr } %t305, 0
  %t311 = add i64 %t307, %t310
  %t312 = load i64, ptr %l137
  %t313 = inttoptr i64 %t312 to ptr
  %t314 = call ptr @__olang_held_alloc(ptr %t313, i64 %t311)
  call void @olang_textcopy(ptr %t314, ptr %t306, i64 %t307)
  %t315 = getelementptr i8, ptr %t314, i64 %t307
  call void @olang_textcopy(ptr %t315, ptr %t309, i64 %t310)
  %t316 = insertvalue { i64, ptr } undef, i64 %t311, 0
  %t317 = insertvalue { i64, ptr } %t316, ptr %t314, 1
  %t319 = load ptr, ptr %l136, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t319, { i64, ptr } %t317)
  br label %bb47
bb47:
  %t321 = load ptr, ptr %l4, !tbaa !29
  store ptr %t321, ptr %l142, !tbaa !29
  %t322 = load ptr, ptr %l142, !tbaa !29
  %t323 = getelementptr %"compiler/cabi:Regs", ptr %t322, i32 0, i32 0
  %t324 = load i64, ptr %t323, !tbaa !24
  %t327 = sub i64 %t324, 1
  %t329 = load ptr, ptr %l142, !tbaa !29
  %t330 = getelementptr %"compiler/cabi:Regs", ptr %t329, i32 0, i32 0
  store i64 %t327, ptr %t330, !tbaa !24
  %t331 = load ptr, ptr %l5, !tbaa !29
  store ptr %t331, ptr %l146, !tbaa !29
  %t332 = call ptr @__olang_scope_hold(ptr %v4)
  %t333 = ptrtoint ptr %t332 to i64
  store i64 %t333, ptr %l147, !tbaa !24
  %t334 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t334, label %bb48, label %bb49
bb48:
  %t336 = call ptr @__olang_region_make(ptr %v4)
  %t337 = ptrtoint ptr %t336 to i64
  store i64 %t337, ptr %l147, !tbaa !24
  br label %bb49
bb49:
  %t338 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t339 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t340 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t342 = extractvalue { i64, ptr } %t338, 1
  %t343 = extractvalue { i64, ptr } %t338, 0
  %t344 = add i64 %t340, %t343
  %t345 = load i64, ptr %l147
  %t346 = inttoptr i64 %t345 to ptr
  %t347 = call ptr @__olang_held_alloc(ptr %t346, i64 %t344)
  call void @olang_textcopy(ptr %t347, ptr %t339, i64 %t340)
  %t348 = getelementptr i8, ptr %t347, i64 %t340
  call void @olang_textcopy(ptr %t348, ptr %t342, i64 %t343)
  %t349 = insertvalue { i64, ptr } undef, i64 %t344, 0
  %t350 = insertvalue { i64, ptr } %t349, ptr %t347, 1
  %t352 = load ptr, ptr %l146, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t352, { i64, ptr } %t350)
  br label %bb50
bb50:
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s2)
  br label %bb142
bb52:
  %t354 = load ptr, ptr %l6, !tbaa !29
  store ptr %t354, ptr %l152, !tbaa !29
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t357 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eabiArch(ptr %v0, ptr %s2, ptr %t355)
  store { i64, ptr } %t357, ptr %l154
  br label %bb53
bb53:
  %t358 = load { i64, ptr }, ptr %l154, !tbaa !27
  %t359 = load i32, ptr %l16, !tbaa !23
  %t360 = load ptr, ptr %l4, !tbaa !29
  %t362 = inttoptr i64 0 to ptr
  %t363 = load ptr, ptr %l152, !tbaa !29
  %t367 = call %"compiler/cabi:Way" @compiler_2fcabi_2eWay_2eParam(ptr %v0, ptr %s2, ptr %v3, ptr %s2, ptr %t362, ptr %t363, { i64, ptr } %t358, i32 %t359, ptr %t360)
  store %"compiler/cabi:Way" %t367, ptr %l159
  br label %bb54
bb54:
  %t368 = load %"compiler/cabi:Way", ptr %l159
  store %"compiler/cabi:Way" %t368, ptr %l21
  %t369 = getelementptr %"compiler/cabi:Way", ptr %l21, i32 0, i32 0
  %t370 = load i32, ptr %t369, !range !{i32 0, i32 5}
  store i32 %t370, ptr %l22
  %t372 = load i32, ptr %l22, !range !{i32 0, i32 5}
  %t374 = trunc i64 0 to i32
  %t375 = icmp eq i32 %t372, %t374
  br i1 %t375, label %bb55, label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb70
bb57:
  store %olang.scope zeroinitializer, ptr %s14
  %t377 = load ptr, ptr %l3, !tbaa !29
  store ptr %t377, ptr %l163, !tbaa !29
  %t378 = call ptr @__olang_scope_hold(ptr %v2)
  %t379 = ptrtoint ptr %t378 to i64
  store i64 %t379, ptr %l164, !tbaa !24
  %t380 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t380, label %bb58, label %bb59
bb58:
  %t382 = call ptr @__olang_region_make(ptr %v2)
  %t383 = ptrtoint ptr %t382 to i64
  store i64 %t383, ptr %l164, !tbaa !24
  br label %bb59
bb59:
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t385 = load i32, ptr %l16, !tbaa !23
  %t388 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s14, ptr %t384, i32 %t385)
  store { i64, ptr } %t388, ptr %l168
  br label %bb60
bb60:
  %t389 = getelementptr %"compiler/cabi:Way", ptr %l21, i32 0, i32 4
  %t390 = load { i64, ptr }, ptr %t389, !tbaa !27
  %t392 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s14, { i64, ptr } %t390, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store i1 %t392, ptr %l170
  br label %bb61
bb61:
  %t393 = load i1, ptr %l170, !tbaa !21
  %t394 = xor i1 %t393, true
  br i1 %t394, label %bb62, label %bb63
bb62:
  %t396 = getelementptr %"compiler/cabi:Way", ptr %l21, i32 0, i32 4
  %t397 = load { i64, ptr }, ptr %t396, !tbaa !27
  %t398 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t399 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t401 = extractvalue { i64, ptr } %t397, 1
  %t402 = extractvalue { i64, ptr } %t397, 0
  %t403 = add i64 %t399, %t402
  %t404 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t403)
  call void @olang_textcopy(ptr %t404, ptr %t398, i64 %t399)
  %t405 = getelementptr i8, ptr %t404, i64 %t399
  call void @olang_textcopy(ptr %t405, ptr %t401, i64 %t402)
  %t406 = insertvalue { i64, ptr } undef, i64 %t403, 0
  %t407 = insertvalue { i64, ptr } %t406, ptr %t404, 1
  store { i64, ptr } %t407, ptr %l172, !tbaa !27
  br label %bb64
bb63:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %l172, !tbaa !27
  br label %bb64
bb64:
  %t410 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t411 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t412 = extractvalue { i64, ptr } %t411, 1
  %t413 = extractvalue { i64, ptr } %t411, 0
  %t414 = load { i64, ptr }, ptr %l172, !tbaa !27
  %t415 = extractvalue { i64, ptr } %t414, 1
  %t416 = extractvalue { i64, ptr } %t414, 0
  %t417 = add i64 %t413, %t416
  %t418 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t419 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t420 = add i64 %t417, %t419
  %t422 = extractvalue { i64, ptr } %t410, 1
  %t423 = extractvalue { i64, ptr } %t410, 0
  %t424 = add i64 %t420, %t423
  %t425 = load i64, ptr %l164
  %t426 = inttoptr i64 %t425 to ptr
  %t427 = call ptr @__olang_held_alloc(ptr %t426, i64 %t424)
  call void @olang_textcopy(ptr %t427, ptr %t412, i64 %t413)
  %t428 = getelementptr i8, ptr %t427, i64 %t413
  call void @olang_textcopy(ptr %t428, ptr %t415, i64 %t416)
  %t429 = getelementptr i8, ptr %t428, i64 %t416
  call void @olang_textcopy(ptr %t429, ptr %t418, i64 %t419)
  %t430 = getelementptr i8, ptr %t429, i64 %t419
  call void @olang_textcopy(ptr %t430, ptr %t422, i64 %t423)
  %t431 = insertvalue { i64, ptr } undef, i64 %t424, 0
  %t432 = insertvalue { i64, ptr } %t431, ptr %t427, 1
  %t434 = load ptr, ptr %l163, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t434, { i64, ptr } %t432)
  br label %bb65
bb65:
  %t436 = load ptr, ptr %l5, !tbaa !29
  store ptr %t436, ptr %l179, !tbaa !29
  %t437 = call ptr @__olang_scope_hold(ptr %v4)
  %t438 = ptrtoint ptr %t437 to i64
  store i64 %t438, ptr %l180, !tbaa !24
  %t439 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t439, label %bb66, label %bb67
bb66:
  %t441 = call ptr @__olang_region_make(ptr %v4)
  %t442 = ptrtoint ptr %t441 to i64
  store i64 %t442, ptr %l180, !tbaa !24
  br label %bb67
bb67:
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t444 = load i32, ptr %l16, !tbaa !23
  %t447 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s14, ptr %t443, i32 %t444)
  store { i64, ptr } %t447, ptr %l184
  br label %bb68
bb68:
  %t448 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t449 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t450 = extractvalue { i64, ptr } %t449, 1
  %t451 = extractvalue { i64, ptr } %t449, 0
  %t452 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t453 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t454 = add i64 %t451, %t453
  %t456 = extractvalue { i64, ptr } %t448, 1
  %t457 = extractvalue { i64, ptr } %t448, 0
  %t458 = add i64 %t454, %t457
  %t459 = load i64, ptr %l180
  %t460 = inttoptr i64 %t459 to ptr
  %t461 = call ptr @__olang_held_alloc(ptr %t460, i64 %t458)
  call void @olang_textcopy(ptr %t461, ptr %t450, i64 %t451)
  %t462 = getelementptr i8, ptr %t461, i64 %t451
  call void @olang_textcopy(ptr %t462, ptr %t452, i64 %t453)
  %t463 = getelementptr i8, ptr %t462, i64 %t453
  call void @olang_textcopy(ptr %t463, ptr %t456, i64 %t457)
  %t464 = insertvalue { i64, ptr } undef, i64 %t458, 0
  %t465 = insertvalue { i64, ptr } %t464, ptr %t461, 1
  %t467 = load ptr, ptr %l179, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t467, { i64, ptr } %t465)
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s2)
  br label %bb142
bb70:
  %t469 = load i32, ptr %l22, !range !{i32 0, i32 5}
  %t471 = trunc i64 1 to i32
  %t472 = icmp eq i32 %t469, %t471
  br i1 %t472, label %bb71, label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb108
bb73:
  store %olang.scope zeroinitializer, ptr %s18
  %t474 = load ptr, ptr %l1, !tbaa !29
  store ptr %t474, ptr %l190, !tbaa !29
  %t475 = load ptr, ptr %l6, !tbaa !29
  %t476 = load i32, ptr %l16, !tbaa !23
  %t480 = call i64 @compiler_2fcabi_2eSpan(ptr %v0, ptr %s2, ptr %t475, ptr %l21, i32 %t476)
  store i64 %t480, ptr %l194
  br label %bb74
bb74:
  %t481 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t482 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t483 = load i64, ptr %l194, !tbaa !24
  %t484 = call i64 @__olang_fmt_i64(ptr null, i64 %t483)
  %t485 = add i64 %t482, %t484
  %t486 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t487 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t488 = add i64 %t485, %t487
  %t489 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t488)
  call void @olang_textcopy(ptr %t489, ptr %t481, i64 %t482)
  %t490 = getelementptr i8, ptr %t489, i64 %t482
  %t491 = call i64 @__olang_fmt_i64(ptr %t490, i64 %t483)
  %t492 = getelementptr i8, ptr %t490, i64 %t484
  call void @olang_textcopy(ptr %t492, ptr %t486, i64 %t487)
  %t493 = insertvalue { i64, ptr } undef, i64 %t488, 0
  %t494 = insertvalue { i64, ptr } %t493, ptr %t489, 1
  %t496 = load ptr, ptr %l190, !tbaa !29
  %t498 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v1, ptr %s18, ptr %s18, ptr %t496, { i64, ptr } %t494, i64 8)
  store { i64, ptr } %t498, ptr %l197
  br label %bb75
bb75:
  %t499 = load { i64, ptr }, ptr %l197, !tbaa !27
  store { i64, ptr } %t499, ptr %l23, !tbaa !27
  store i64 0, ptr %l24, !tbaa !24
  %t500 = getelementptr %"compiler/cabi:Way", ptr %l21, i32 0, i32 1
  %t502 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s2, ptr %t500)
  store i64 %t502, ptr %l199
  br label %bb76
bb76:
  %t503 = load i64, ptr %l199, !tbaa !24
  store i64 %t503, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t504 = load i64, ptr %l25, !tbaa !24
  %t505 = load i64, ptr %l24, !tbaa !24
  %t508 = icmp sgt i64 %t504, %t505
  br i1 %t508, label %bb77, label %bb78
bb77:
  %t510 = load i64, ptr %l26, !tbaa !24
  %t512 = icmp sgt i64 %t510, 0
  br i1 %t512, label %bb79, label %bb80
bb78:
  store i64 0, ptr %l203, !tbaa !24
  br label %bb82
bb79:
  %t514 = load i64, ptr %l25, !tbaa !24
  %t515 = load i64, ptr %l24, !tbaa !24
  %t518 = sub i64 %t514, %t515
  %t519 = load i64, ptr %l26, !tbaa !24
  %t522 = add i64 %t518, %t519
  %t524 = sub i64 %t522, 1
  %t525 = load i64, ptr %l26, !tbaa !24
  %t528 = sdiv i64 %t524, %t525
  store i64 %t528, ptr %l206, !tbaa !24
  br label %bb81
bb80:
  store i64 0, ptr %l206, !tbaa !24
  br label %bb81
bb81:
  %t530 = load i64, ptr %l206, !tbaa !24
  store i64 %t530, ptr %l203, !tbaa !24
  br label %bb82
bb82:
  %t531 = load i64, ptr %l203, !tbaa !24
  store i64 %t531, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb83
bb83:
  store %olang.scope zeroinitializer, ptr %s21
  %t532 = load i64, ptr %l28, !tbaa !24
  %t533 = load i64, ptr %l27, !tbaa !24
  %t536 = icmp slt i64 %t532, %t533
  %t538 = xor i1 %t536, true
  br i1 %t538, label %bb84, label %bb85
bb84:
  call void @__olang_scope_close(ptr %s21)
  br label %bb101
bb85:
  br label %bb86
bb86:
  %t540 = load i64, ptr %l24, !tbaa !24
  %t541 = load i64, ptr %l28, !tbaa !24
  %t542 = load i64, ptr %l26, !tbaa !24
  %t545 = mul i64 %t541, %t542
  %t548 = add i64 %t540, %t545
  store i64 %t548, ptr %l29, !tbaa !24
  %t550 = load ptr, ptr %l3, !tbaa !29
  store ptr %t550, ptr %l224, !tbaa !29
  %t551 = call ptr @__olang_scope_hold(ptr %v2)
  %t552 = ptrtoint ptr %t551 to i64
  store i64 %t552, ptr %l225, !tbaa !24
  %t553 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t553, label %bb87, label %bb88
bb87:
  %t555 = call ptr @__olang_region_make(ptr %v2)
  %t556 = ptrtoint ptr %t555 to i64
  store i64 %t556, ptr %l225, !tbaa !24
  br label %bb88
bb88:
  %t557 = getelementptr %"compiler/cabi:Way", ptr %l21, i32 0, i32 1
  %t558 = load i64, ptr %l29, !tbaa !24
  %t561 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s2, ptr %s21, ptr %t557, i64 %t558)
  store { i64, ptr } %t561, ptr %l229
  br label %bb89
bb89:
  %t562 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t563 = load i64, ptr %l29, !tbaa !24
  %t564 = load { i64, ptr }, ptr %l229, !tbaa !27
  %t565 = extractvalue { i64, ptr } %t564, 1
  %t566 = extractvalue { i64, ptr } %t564, 0
  %t567 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t568 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t569 = add i64 %t566, %t568
  %t571 = extractvalue { i64, ptr } %t562, 1
  %t572 = extractvalue { i64, ptr } %t562, 0
  %t573 = add i64 %t569, %t572
  %t574 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t575 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t576 = add i64 %t573, %t575
  %t578 = call i64 @__olang_fmt_i64(ptr null, i64 %t563)
  %t579 = add i64 %t576, %t578
  %t580 = load i64, ptr %l225
  %t581 = inttoptr i64 %t580 to ptr
  %t582 = call ptr @__olang_held_alloc(ptr %t581, i64 %t579)
  call void @olang_textcopy(ptr %t582, ptr %t565, i64 %t566)
  %t583 = getelementptr i8, ptr %t582, i64 %t566
  call void @olang_textcopy(ptr %t583, ptr %t567, i64 %t568)
  %t584 = getelementptr i8, ptr %t583, i64 %t568
  call void @olang_textcopy(ptr %t584, ptr %t571, i64 %t572)
  %t585 = getelementptr i8, ptr %t584, i64 %t572
  call void @olang_textcopy(ptr %t585, ptr %t574, i64 %t575)
  %t586 = getelementptr i8, ptr %t585, i64 %t575
  %t587 = call i64 @__olang_fmt_i64(ptr %t586, i64 %t563)
  %t588 = insertvalue { i64, ptr } undef, i64 %t579, 0
  %t589 = insertvalue { i64, ptr } %t588, ptr %t582, 1
  %t591 = load ptr, ptr %l224, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t591, { i64, ptr } %t589)
  br label %bb90
bb90:
  %t593 = getelementptr %"compiler/cabi:Way", ptr %l21, i32 0, i32 2
  %t594 = load i64, ptr %l29, !tbaa !24
  %t597 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %t593, i64 %t594)
  store i64 %t597, ptr %l236
  br label %bb91
bb91:
  %t598 = load i64, ptr %l236, !tbaa !24
  %t599 = icmp eq i64 %t598, 0
  br i1 %t599, label %bb92, label %bb93
bb92:
  %t601 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t601, ptr %l238, !tbaa !27
  br label %bb96
bb93:
  %t603 = load ptr, ptr %l1, !tbaa !29
  store ptr %t603, ptr %l240, !tbaa !29
  %t604 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t604, ptr %l241, !tbaa !27
  %t605 = getelementptr %"compiler/cabi:Way", ptr %l21, i32 0, i32 2
  %t606 = load i64, ptr %l29, !tbaa !24
  %t609 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %t605, i64 %t606)
  store i64 %t609, ptr %l244
  br label %bb94
bb94:
  %t610 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t611 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t612 = load { i64, ptr }, ptr %l241, !tbaa !27
  %t613 = extractvalue { i64, ptr } %t612, 1
  %t614 = extractvalue { i64, ptr } %t612, 0
  %t615 = add i64 %t611, %t614
  %t616 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t617 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t618 = add i64 %t615, %t617
  %t619 = load i64, ptr %l244, !tbaa !24
  %t620 = call i64 @__olang_fmt_i64(ptr null, i64 %t619)
  %t621 = add i64 %t618, %t620
  %t622 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t621)
  call void @olang_textcopy(ptr %t622, ptr %t610, i64 %t611)
  %t623 = getelementptr i8, ptr %t622, i64 %t611
  call void @olang_textcopy(ptr %t623, ptr %t613, i64 %t614)
  %t624 = getelementptr i8, ptr %t623, i64 %t614
  call void @olang_textcopy(ptr %t624, ptr %t616, i64 %t617)
  %t625 = getelementptr i8, ptr %t624, i64 %t617
  %t626 = call i64 @__olang_fmt_i64(ptr %t625, i64 %t619)
  %t627 = insertvalue { i64, ptr } undef, i64 %t621, 0
  %t628 = insertvalue { i64, ptr } %t627, ptr %t622, 1
  %t630 = load ptr, ptr %l240, !tbaa !29
  %t632 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v1, ptr %s21, ptr %s21, ptr %v5, ptr %t630, { i64, ptr } %t628)
  store { i64, ptr } %t632, ptr %l247
  br label %bb95
bb95:
  %t633 = load { i64, ptr }, ptr %l247, !tbaa !27
  store { i64, ptr } %t633, ptr %l238, !tbaa !27
  br label %bb96
bb96:
  %t634 = load { i64, ptr }, ptr %l238, !tbaa !27
  %t635 = extractvalue { i64, ptr } %t634, 0
  store i64 %t635, ptr %l248, !tbaa !24
  %t636 = load i64, ptr %l248, !tbaa !24
  %t637 = mul i64 %t636, 1
  %t638 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t637)
  %t639 = insertvalue { i64, ptr } undef, i64 %t636, 0
  %t640 = insertvalue { i64, ptr } %t639, ptr %t638, 1
  store { i64, ptr } %t640, ptr %l249, !tbaa !27
  %t641 = getelementptr { i64, ptr }, ptr %l249, i32 0, i32 1
  %t642 = load ptr, ptr %t641, !tbaa !27
  %t643 = getelementptr { i64, ptr }, ptr %l238, i32 0, i32 1
  %t644 = load ptr, ptr %t643, !tbaa !27
  %t645 = load i64, ptr %l248, !tbaa !24
  %t646 = mul i64 %t645, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t642, ptr %t644, i64 %t646, i1 false)
  %t647 = load { i64, ptr }, ptr %l249, !tbaa !27
  store { i64, ptr } %t647, ptr %l30, !tbaa !27
  %t648 = load ptr, ptr %l1, !tbaa !29
  store ptr %t648, ptr %l250, !tbaa !29
  %t649 = getelementptr %"compiler/cabi:Way", ptr %l21, i32 0, i32 1
  %t650 = load i64, ptr %l29, !tbaa !24
  %t653 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s2, ptr %s21, ptr %t649, i64 %t650)
  store { i64, ptr } %t653, ptr %l253
  br label %bb97
bb97:
  %t654 = load { i64, ptr }, ptr %l253, !tbaa !27
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %l255, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d41, i32 0, i32 1) }, ptr %l256, !tbaa !27
  %t656 = load { i64, ptr }, ptr %l255, !tbaa !27
  %t657 = load { i64, ptr }, ptr %l256, !tbaa !27
  %t658 = call { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s21, ptr %s21, ptr %s21, ptr %s21, { i64, ptr } %t654, { i64, ptr } %t656, { i64, ptr } %t657)
  store { i64, ptr } %t658, ptr %l257
  br label %bb98
bb98:
  %t659 = load { i64, ptr }, ptr %l257, !tbaa !27
  %t661 = extractvalue { i64, ptr } %t659, 0
  %t662 = extractvalue { i64, ptr } %t659, 1
  %t663 = mul i64 %t661, 1
  %t664 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t663)
  call void @llvm.memcpy.p0.p0.i64(ptr %t664, ptr %t662, i64 %t663, i1 false)
  %t665 = insertvalue { i64, ptr } undef, i64 %t661, 0
  %t666 = insertvalue { i64, ptr } %t665, ptr %t664, 1
  %t667 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t668 = load i64, ptr %l29, !tbaa !24
  %t670 = extractvalue { i64, ptr } %t667, 1
  %t671 = extractvalue { i64, ptr } %t667, 0
  %t672 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t673 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t674 = add i64 %t671, %t673
  %t676 = call i64 @__olang_fmt_i64(ptr null, i64 %t668)
  %t677 = add i64 %t674, %t676
  %t678 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t677)
  call void @olang_textcopy(ptr %t678, ptr %t670, i64 %t671)
  %t679 = getelementptr i8, ptr %t678, i64 %t671
  call void @olang_textcopy(ptr %t679, ptr %t672, i64 %t673)
  %t680 = getelementptr i8, ptr %t679, i64 %t673
  %t681 = call i64 @__olang_fmt_i64(ptr %t680, i64 %t668)
  %t682 = insertvalue { i64, ptr } undef, i64 %t677, 0
  %t683 = insertvalue { i64, ptr } %t682, ptr %t678, 1
  %t685 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t686 = load ptr, ptr %l250, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v1, ptr %s21, ptr %s21, ptr %s21, ptr %s21, ptr %v5, ptr %t686, { i64, ptr } %t666, { i64, ptr } %t683, { i64, ptr } %t685, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d43, i32 0, i32 1) })
  br label %bb99
bb99:
  call void @__olang_scope_close(ptr %s21)
  br label %bb100
bb100:
  %t690 = load i64, ptr %l28, !tbaa !24
  %t693 = add i64 %t690, 1
  store i64 %t693, ptr %l28, !tbaa !24
  br label %bb83
bb101:
  %t695 = call ptr @__olang_scope_hold(ptr %s2)
  %t696 = ptrtoint ptr %t695 to i64
  store i64 %t696, ptr %l268, !tbaa !24
  %t697 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3aEmitter__2eexportParams_2elocal_2e18
  br i1 %t697, label %bb102, label %bb103
bb102:
  %t699 = call ptr @__olang_region_make(ptr %s2)
  %t700 = ptrtoint ptr %t699 to i64
  store i64 %t700, ptr %l268, !tbaa !24
  br label %bb103
bb103:
  %t701 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t701, ptr %l270, !tbaa !27
  %t702 = load { i64, ptr }, ptr %l270, !tbaa !27
  %t703 = extractvalue { i64, ptr } %t702, 0
  store i64 %t703, ptr %l271, !tbaa !24
  %t704 = load i64, ptr %l271, !tbaa !24
  %t705 = mul i64 %t704, 1
  %t706 = load i64, ptr %l268
  %t707 = inttoptr i64 %t706 to ptr
  %t708 = call ptr @__olang_held_alloc(ptr %t707, i64 %t705)
  %t709 = insertvalue { i64, ptr } undef, i64 %t704, 0
  %t710 = insertvalue { i64, ptr } %t709, ptr %t708, 1
  store { i64, ptr } %t710, ptr %l272, !tbaa !27
  %t711 = getelementptr { i64, ptr }, ptr %l272, i32 0, i32 1
  %t712 = load ptr, ptr %t711, !tbaa !27
  %t713 = getelementptr { i64, ptr }, ptr %l270, i32 0, i32 1
  %t714 = load ptr, ptr %t713, !tbaa !27
  %t715 = load i64, ptr %l271, !tbaa !24
  %t716 = mul i64 %t715, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t712, ptr %t714, i64 %t716, i1 false)
  %t717 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t717, ptr %l273, !tbaa !27
  %t718 = load { i64, ptr }, ptr %l272, !tbaa !27
  store { i64, ptr } %t718, ptr %l18, !tbaa !27
  %t719 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3aEmitter__2eexportParams_2elocal_2e18
  br i1 %t719, label %bb104, label %bb105
bb104:
  %t721 = load { i64, ptr }, ptr %l273
  %t722 = extractvalue { i64, ptr } %t721, 1
  call void @__olang_region_release(ptr %t722)
  store { i64, ptr } zeroinitializer, ptr %l273
  br label %bb105
bb105:
  %t723 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3aEmitter__2eexportParams_2elocal_2e18
  br i1 %t723, label %bb106, label %bb107
bb106:
  %t725 = load i64, ptr %l268
  %t726 = inttoptr i64 %t725 to ptr
  %t727 = load { i64, ptr }, ptr %l18
  %t728 = extractvalue { i64, ptr } %t727, 1
  %t729 = call ptr @__olang_region_or(ptr %t728, ptr null)
  %t730 = icmp ne ptr %t729, null
  %t731 = select i1 %t730, ptr %t729, ptr null
  call void @__olang_region_settle_in(ptr %t726, ptr %t731)
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s18)
  br label %bb126
bb108:
  %t732 = load i32, ptr %l22, !range !{i32 0, i32 5}
  %t734 = trunc i64 2 to i32
  %t735 = icmp eq i32 %t732, %t734
  br i1 %t735, label %bb109, label %bb110
bb109:
  br label %bb111
bb110:
  br label %bb118
bb111:
  store %olang.scope zeroinitializer, ptr %s26
  %t737 = load ptr, ptr %l3, !tbaa !29
  store ptr %t737, ptr %l278, !tbaa !29
  %t738 = call ptr @__olang_scope_hold(ptr %v2)
  %t739 = ptrtoint ptr %t738 to i64
  store i64 %t739, ptr %l279, !tbaa !24
  %t740 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t740, label %bb112, label %bb113
bb112:
  %t742 = call ptr @__olang_region_make(ptr %v2)
  %t743 = ptrtoint ptr %t742 to i64
  store i64 %t743, ptr %l279, !tbaa !24
  br label %bb113
bb113:
  %t744 = load ptr, ptr %l0, !tbaa !29
  %t745 = load i32, ptr %l16, !tbaa !23
  %t748 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s26, ptr %t744, i32 %t745)
  store { i64, ptr } %t748, ptr %l283
  br label %bb114
bb114:
  %t749 = load ptr, ptr %l6, !tbaa !29
  %t750 = load i32, ptr %l16, !tbaa !23
  %t753 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %t749, i32 %t750)
  store i64 %t753, ptr %l286
  br label %bb115
bb115:
  %t754 = load i64, ptr %l286, !tbaa !24
  %t755 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t754, i64 8)
  store i64 %t755, ptr %l287
  br label %bb116
bb116:
  %t756 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t757 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t758 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t759 = load { i64, ptr }, ptr %l283, !tbaa !27
  %t760 = extractvalue { i64, ptr } %t759, 1
  %t761 = extractvalue { i64, ptr } %t759, 0
  %t762 = add i64 %t758, %t761
  %t763 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t764 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t765 = add i64 %t762, %t764
  %t766 = load i64, ptr %l287, !tbaa !24
  %t767 = call i64 @__olang_fmt_i64(ptr null, i64 %t766)
  %t768 = add i64 %t765, %t767
  %t769 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t770 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t771 = add i64 %t768, %t770
  %t773 = extractvalue { i64, ptr } %t756, 1
  %t774 = extractvalue { i64, ptr } %t756, 0
  %t775 = add i64 %t771, %t774
  %t776 = load i64, ptr %l279
  %t777 = inttoptr i64 %t776 to ptr
  %t778 = call ptr @__olang_held_alloc(ptr %t777, i64 %t775)
  call void @olang_textcopy(ptr %t778, ptr %t757, i64 %t758)
  %t779 = getelementptr i8, ptr %t778, i64 %t758
  call void @olang_textcopy(ptr %t779, ptr %t760, i64 %t761)
  %t780 = getelementptr i8, ptr %t779, i64 %t761
  call void @olang_textcopy(ptr %t780, ptr %t763, i64 %t764)
  %t781 = getelementptr i8, ptr %t780, i64 %t764
  %t782 = call i64 @__olang_fmt_i64(ptr %t781, i64 %t766)
  %t783 = getelementptr i8, ptr %t781, i64 %t767
  call void @olang_textcopy(ptr %t783, ptr %t769, i64 %t770)
  %t784 = getelementptr i8, ptr %t783, i64 %t770
  call void @olang_textcopy(ptr %t784, ptr %t773, i64 %t774)
  %t785 = insertvalue { i64, ptr } undef, i64 %t775, 0
  %t786 = insertvalue { i64, ptr } %t785, ptr %t778, 1
  %t788 = load ptr, ptr %l278, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t788, { i64, ptr } %t786)
  br label %bb117
bb117:
  call void @__olang_scope_close(ptr %s26)
  br label %bb126
bb118:
  br i1 true, label %bb119, label %bb120
bb119:
  br label %bb121
bb120:
  br label %bb125
bb121:
  %t790 = load ptr, ptr %l3, !tbaa !29
  store ptr %t790, ptr %l291, !tbaa !29
  %t791 = call ptr @__olang_scope_hold(ptr %v2)
  %t792 = ptrtoint ptr %t791 to i64
  store i64 %t792, ptr %l292, !tbaa !24
  %t793 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t793, label %bb122, label %bb123
bb122:
  %t795 = call ptr @__olang_region_make(ptr %v2)
  %t796 = ptrtoint ptr %t795 to i64
  store i64 %t796, ptr %l292, !tbaa !24
  br label %bb123
bb123:
  %t797 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t798 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t799 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  %t801 = extractvalue { i64, ptr } %t797, 1
  %t802 = extractvalue { i64, ptr } %t797, 0
  %t803 = add i64 %t799, %t802
  %t804 = load i64, ptr %l292
  %t805 = inttoptr i64 %t804 to ptr
  %t806 = call ptr @__olang_held_alloc(ptr %t805, i64 %t803)
  call void @olang_textcopy(ptr %t806, ptr %t798, i64 %t799)
  %t807 = getelementptr i8, ptr %t806, i64 %t799
  call void @olang_textcopy(ptr %t807, ptr %t801, i64 %t802)
  %t808 = insertvalue { i64, ptr } undef, i64 %t803, 0
  %t809 = insertvalue { i64, ptr } %t808, ptr %t806, 1
  %t811 = load ptr, ptr %l291, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t811, { i64, ptr } %t809)
  br label %bb124
bb124:
  br label %bb126
bb125:
  call void @__olang_check_failed(ptr @olang_loc_a19b535d764b2fc2_b8d21aa34486a36)
  unreachable
bb126:
  %t813 = load i64, ptr %l15, !tbaa !24
  %t815 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t816 = load ptr, ptr %t815, !tbaa !27
  %t817 = getelementptr i8, ptr %t816, i64 %t813
  %t818 = load i8, ptr %t817, !tbaa !32
  %t820 = icmp eq i8 %t818, 109
  br i1 %t820, label %bb127, label %bb128
bb127:
  store %olang.scope zeroinitializer, ptr %s30
  %t822 = load ptr, ptr %l1, !tbaa !29
  %t823 = load i32, ptr %l16, !tbaa !23
  %t826 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eslot(ptr %v1, ptr %s30, ptr %v5, ptr %t822, i32 %t823)
  store { i64, ptr } %t826, ptr %l302
  br label %bb129
bb128:
  store %olang.scope zeroinitializer, ptr %s32
  %t827 = load ptr, ptr %l5, !tbaa !29
  store ptr %t827, ptr %l315, !tbaa !29
  %t828 = call ptr @__olang_scope_hold(ptr %v4)
  %t829 = ptrtoint ptr %t828 to i64
  store i64 %t829, ptr %l316, !tbaa !24
  %t830 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t830, label %bb135, label %bb136
bb129:
  %t832 = load { i64, ptr }, ptr %l302, !tbaa !27
  store { i64, ptr } %t832, ptr %l31, !tbaa !27
  %t833 = load ptr, ptr %l1, !tbaa !29
  store ptr %t833, ptr %l303, !tbaa !29
  %t834 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t834, ptr %l304, !tbaa !27
  %t835 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t835, ptr %l305, !tbaa !27
  %t836 = load ptr, ptr %l6, !tbaa !29
  %t837 = load i32, ptr %l16, !tbaa !23
  %t840 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t836, i32 %t837)
  store i64 %t840, ptr %l308
  br label %bb130
bb130:
  %t841 = load ptr, ptr %l303, !tbaa !29
  %t842 = load { i64, ptr }, ptr %l304, !tbaa !27
  %t843 = load { i64, ptr }, ptr %l305, !tbaa !27
  %t844 = load i64, ptr %l308, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ememmove(ptr %v1, ptr %s30, ptr %s2, ptr %v5, ptr %t841, { i64, ptr } %t842, { i64, ptr } %t843, i64 %t844)
  br label %bb131
bb131:
  %t845 = load ptr, ptr %l5, !tbaa !29
  store ptr %t845, ptr %l309, !tbaa !29
  %t846 = call ptr @__olang_scope_hold(ptr %v4)
  %t847 = ptrtoint ptr %t846 to i64
  store i64 %t847, ptr %l310, !tbaa !24
  %t848 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t848, label %bb132, label %bb133
bb132:
  %t850 = call ptr @__olang_region_make(ptr %v4)
  %t851 = ptrtoint ptr %t850 to i64
  store i64 %t851, ptr %l310, !tbaa !24
  br label %bb133
bb133:
  %t852 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t853 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t854 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  %t856 = extractvalue { i64, ptr } %t852, 1
  %t857 = extractvalue { i64, ptr } %t852, 0
  %t858 = add i64 %t854, %t857
  %t859 = load i64, ptr %l310
  %t860 = inttoptr i64 %t859 to ptr
  %t861 = call ptr @__olang_held_alloc(ptr %t860, i64 %t858)
  call void @olang_textcopy(ptr %t861, ptr %t853, i64 %t854)
  %t862 = getelementptr i8, ptr %t861, i64 %t854
  call void @olang_textcopy(ptr %t862, ptr %t856, i64 %t857)
  %t863 = insertvalue { i64, ptr } undef, i64 %t858, 0
  %t864 = insertvalue { i64, ptr } %t863, ptr %t861, 1
  %t866 = load ptr, ptr %l309, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t866, { i64, ptr } %t864)
  br label %bb134
bb134:
  call void @__olang_scope_close(ptr %s30)
  br label %bb141
bb135:
  %t868 = call ptr @__olang_region_make(ptr %v4)
  %t869 = ptrtoint ptr %t868 to i64
  store i64 %t869, ptr %l316, !tbaa !24
  br label %bb136
bb136:
  %t870 = load ptr, ptr %l0, !tbaa !29
  %t871 = load i32, ptr %l16, !tbaa !23
  %t874 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s32, ptr %t870, i32 %t871)
  store { i64, ptr } %t874, ptr %l320
  br label %bb137
bb137:
  %t875 = load ptr, ptr %l1, !tbaa !29
  store ptr %t875, ptr %l321, !tbaa !29
  %t876 = load ptr, ptr %l0, !tbaa !29
  %t877 = load i32, ptr %l16, !tbaa !23
  %t880 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s32, ptr %t876, i32 %t877)
  store { i64, ptr } %t880, ptr %l324
  br label %bb138
bb138:
  %t881 = load { i64, ptr }, ptr %l324, !tbaa !27
  %t882 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t883 = load ptr, ptr %l321, !tbaa !29
  %t886 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v1, ptr %s32, ptr %s2, ptr %s32, ptr %s32, ptr %v5, ptr %t883, { i64, ptr } %t881, { i64, ptr } %t882, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d49, i32 0, i32 1) })
  store { i64, ptr } %t886, ptr %l327
  br label %bb139
bb139:
  %t887 = load { i64, ptr }, ptr %l320, !tbaa !27
  %t888 = extractvalue { i64, ptr } %t887, 1
  %t889 = extractvalue { i64, ptr } %t887, 0
  %t890 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t891 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t892 = add i64 %t889, %t891
  %t893 = load { i64, ptr }, ptr %l327, !tbaa !27
  %t894 = extractvalue { i64, ptr } %t893, 1
  %t895 = extractvalue { i64, ptr } %t893, 0
  %t896 = add i64 %t892, %t895
  %t897 = load i64, ptr %l316
  %t898 = inttoptr i64 %t897 to ptr
  %t899 = call ptr @__olang_held_alloc(ptr %t898, i64 %t896)
  call void @olang_textcopy(ptr %t899, ptr %t888, i64 %t889)
  %t900 = getelementptr i8, ptr %t899, i64 %t889
  call void @olang_textcopy(ptr %t900, ptr %t890, i64 %t891)
  %t901 = getelementptr i8, ptr %t900, i64 %t891
  call void @olang_textcopy(ptr %t901, ptr %t894, i64 %t895)
  %t902 = insertvalue { i64, ptr } undef, i64 %t896, 0
  %t903 = insertvalue { i64, ptr } %t902, ptr %t899, 1
  %t905 = load ptr, ptr %l315, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t905, { i64, ptr } %t903)
  br label %bb140
bb140:
  call void @__olang_scope_close(ptr %s32)
  br label %bb141
bb141:
  call void @__olang_scope_close(ptr %s2)
  br label %bb142
bb142:
  %t907 = load i64, ptr %l14, !tbaa !24
  %t910 = add i64 %t907, 1
  store i64 %t910, ptr %l14, !tbaa !24
  br label %bb10
bb143:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efunction(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i1
  %l20 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l26 = alloca i1
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca { i64, [2 x i64] }
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i1
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l50 = alloca i1
  %l54 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l63 = alloca i1
  %l65 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca { i64, ptr }
  %l70 = alloca i1
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l81 = alloca i1
  %l93 = alloca ptr
  %l94 = alloca { i64, [2 x i64] }
  %l96 = alloca i32
  %l97 = alloca { i64, ptr }
  %l98 = alloca i64
  %l99 = alloca i1
  %l100 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l120 = alloca i1
  %l124 = alloca i1
  %l126 = alloca ptr
  %l127 = alloca { i64, [2 x i64] }
  %l129 = alloca i32
  %l132 = alloca { i64, ptr }
  %l133 = alloca i64
  %l134 = alloca i1
  %l137 = alloca i64
  %l138 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %l150 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 89
  store ptr %t3, ptr %l10, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t5 = load { i64, [2 x i64] }, ptr %l1
  %t8 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehomeOf(ptr %v0, ptr %t4, { i64, [2 x i64] } %t5)
  store i64 %t8, ptr %l13
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l10, !tbaa !29
  %t10 = load i64, ptr %l13, !tbaa !24
  %t11 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t9, i64 %t10)
  store i1 %t11, ptr %l14
  br label %bb2
bb2:
  %t12 = load i1, ptr %l14, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load { i64, [2 x i64] }, ptr %l1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclared(ptr %v0, ptr %t13, { i64, [2 x i64] } %t14)
  br label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/emit:Emitter", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t21 = load { i64, [2 x i64] }, ptr %l1
  %t24 = call ptr @compiler_2flower_2ecompiler_2flower_3aLowerer_2eLowerKey(ptr %v0, ptr %s0, ptr %t20, { i64, [2 x i64] } %t21)
  store ptr %t24, ptr %l20
  br label %bb7
bb7:
  %t25 = load ptr, ptr %l20, !tbaa !29
  store ptr %t25, ptr %l2, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load { i64, [2 x i64] }, ptr %l1
  %t30 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s0, ptr %t26, { i64, [2 x i64] } %t27)
  store { i64, ptr } %t30, ptr %l23
  br label %bb8
bb8:
  %t31 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t31, ptr %l3, !tbaa !27
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load { i64, [2 x i64] }, ptr %l1
  %t36 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehasEnv(ptr %v0, ptr %t32, { i64, [2 x i64] } %t33)
  store i1 %t36, ptr %l26
  br label %bb9
bb9:
  %t37 = load i1, ptr %l26, !tbaa !21
  store i1 %t37, ptr %l4, !tbaa !21
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load { i64, [2 x i64] }, ptr %l1
  %t40 = load ptr, ptr %l2, !tbaa !29
  %t42 = getelementptr %"compiler/mir:Fn", ptr %t40, i32 0, i32 1
  %t43 = load i32, ptr %t42, !tbaa !23
  %t47 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2epassedOf(ptr %v0, ptr %t38, { i64, [2 x i64] } %t39, i32 %t43)
  store i64 %t47, ptr %l31
  br label %bb10
bb10:
  %t48 = load i64, ptr %l31, !tbaa !24
  store i64 %t48, ptr %l5, !tbaa !24
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l32, !tbaa !29
  %t50 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t50, ptr %l33
  %t51 = load ptr, ptr %l2, !tbaa !29
  %t53 = getelementptr %"compiler/mir:Fn", ptr %t51, i32 0, i32 1
  %t54 = load i32, ptr %t53, !tbaa !23
  store i32 %t54, ptr %l35, !tbaa !23
  %t55 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t55, ptr %l36, !tbaa !27
  %t56 = load i64, ptr %l5, !tbaa !24
  store i64 %t56, ptr %l37, !tbaa !24
  %t57 = load i1, ptr %l4, !tbaa !21
  store i1 %t57, ptr %l38, !tbaa !21
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load { i64, [2 x i64] }, ptr %l1
  %t62 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehomeOf(ptr %v0, ptr %t58, { i64, [2 x i64] } %t59)
  store i64 %t62, ptr %l41
  br label %bb11
bb11:
  %t63 = load i64, ptr %l41, !tbaa !24
  %t64 = call { i64, ptr } @compiler_2femit_2elinkFor(ptr %s0, i64 %t63)
  store { i64, ptr } %t64, ptr %l42
  br label %bb12
bb12:
  %t65 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t68 = getelementptr %"compiler/mir:Fn", ptr %t66, i32 0, i32 27
  %t69 = load i64, ptr %t68, !tbaa !24
  %t70 = load ptr, ptr %l32, !tbaa !29
  %t71 = load { i64, [2 x i64] }, ptr %l33
  %t72 = load i32, ptr %l35, !tbaa !23
  %t73 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t74 = load i64, ptr %l37, !tbaa !24
  %t75 = load i1, ptr %l38, !tbaa !21
  %t78 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eheader(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t70, { i64, [2 x i64] } %t71, i32 %t72, { i64, ptr } %t73, i64 %t74, i1 %t75, { i64, ptr } %t65, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d51, i32 0, i32 1) }, i64 %t69)
  store { i64, ptr } %t78, ptr %l46
  br label %bb13
bb13:
  %t79 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t79, ptr %l6, !tbaa !27
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/emit:Emitter", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = getelementptr %"compiler/lower:Lowerer", ptr %t83, i32 0, i32 14
  %t86 = load i1, ptr %t85, !tbaa !21
  br i1 %t86, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb16
bb15:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/emit:Emitter", ptr %t88, i32 0, i32 11
  %t91 = load i1, ptr %t90, !tbaa !21
  %t93 = xor i1 %t91, true
  store i1 %t93, ptr %l50, !tbaa !21
  br label %bb16
bb16:
  %t95 = load i1, ptr %l50, !tbaa !21
  br i1 %t95, label %bb17, label %bb18
bb17:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d52, i32 0, i32 1) }, ptr %l54, !tbaa !27
  br label %bb20
bb18:
  %t96 = load ptr, ptr %l2, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/emit:Emitter", ptr %t97, i32 0, i32 3
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t103 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eVerify(ptr %s0, ptr %v0, ptr %s0, ptr %t96, ptr %t100)
  store { i64, ptr } %t103, ptr %l58
  br label %bb19
bb19:
  %t104 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t104, ptr %l54, !tbaa !27
  br label %bb20
bb20:
  %t106 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t106, ptr %l7, !tbaa !27
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/emit:Emitter", ptr %t107, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/lower:Lowerer", ptr %t110, i32 0, i32 14
  %t113 = load i1, ptr %t112, !tbaa !21
  br i1 %t113, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l63, !tbaa !21
  br label %bb24
bb22:
  %t115 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t117 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t115, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d53, i32 0, i32 1) })
  store i1 %t117, ptr %l65
  br label %bb23
bb23:
  %t118 = load i1, ptr %l65, !tbaa !21
  %t119 = xor i1 %t118, true
  store i1 %t119, ptr %l63, !tbaa !21
  br label %bb24
bb24:
  %t121 = load i1, ptr %l63, !tbaa !21
  br i1 %t121, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s2
  %t122 = load ptr, ptr %l0, !tbaa !29
  store ptr %t122, ptr %l67, !tbaa !29
  %t123 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t123, ptr %l68, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t126 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s2, { i64, ptr } %t124, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d54, i32 0, i32 1) })
  store i1 %t126, ptr %l70
  br label %bb27
bb26:
  br label %bb42
bb27:
  %t127 = load i1, ptr %l70, !tbaa !21
  %t128 = xor i1 %t127, true
  br i1 %t128, label %bb28, label %bb29
bb28:
  %t130 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t132 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %s0, ptr %s2, { i64, ptr } %t130)
  store { i64, ptr } %t132, ptr %l74
  br label %bb30
bb29:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %l72, !tbaa !27
  br label %bb31
bb30:
  %t133 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t134 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t135 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 1
  %t137 = extractvalue { i64, ptr } %t135, 0
  %t138 = add i64 %t134, %t137
  %t139 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d57, i32 0, i32 1) }, 1
  %t140 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d57, i32 0, i32 1) }, 0
  %t141 = add i64 %t138, %t140
  %t142 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t141)
  call void @olang_textcopy(ptr %t142, ptr %t133, i64 %t134)
  %t143 = getelementptr i8, ptr %t142, i64 %t134
  call void @olang_textcopy(ptr %t143, ptr %t136, i64 %t137)
  %t144 = getelementptr i8, ptr %t143, i64 %t137
  call void @olang_textcopy(ptr %t144, ptr %t139, i64 %t140)
  %t145 = insertvalue { i64, ptr } undef, i64 %t141, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t142, 1
  store { i64, ptr } %t146, ptr %l72, !tbaa !27
  br label %bb31
bb31:
  %t149 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t150 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t151 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t151, 1
  %t153 = extractvalue { i64, ptr } %t151, 0
  %t154 = add i64 %t150, %t153
  %t155 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t155, 1
  %t157 = extractvalue { i64, ptr } %t155, 0
  %t158 = add i64 %t154, %t157
  %t159 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t158)
  call void @olang_textcopy(ptr %t159, ptr %t149, i64 %t150)
  %t160 = getelementptr i8, ptr %t159, i64 %t150
  call void @olang_textcopy(ptr %t160, ptr %t152, i64 %t153)
  %t161 = getelementptr i8, ptr %t160, i64 %t153
  call void @olang_textcopy(ptr %t161, ptr %t156, i64 %t157)
  %t162 = insertvalue { i64, ptr } undef, i64 %t158, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t159, 1
  %t165 = load ptr, ptr %l67, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2egap(ptr %v0, ptr %s2, ptr %t165, { i64, ptr } %t163)
  br label %bb32
bb32:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load { i64, [2 x i64] }, ptr %l1
  %t171 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisGlobalInit(ptr %v0, ptr %t167, { i64, [2 x i64] } %t168)
  store i1 %t171, ptr %l81
  br label %bb33
bb33:
  %t172 = load i1, ptr %l81, !tbaa !21
  br i1 %t172, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s5
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load { i64, [2 x i64] }, ptr %l1
  %t175 = load ptr, ptr %l2, !tbaa !29
  %t177 = getelementptr %"compiler/mir:Fn", ptr %t175, i32 0, i32 1
  %t178 = load i32, ptr %t177, !tbaa !23
  %t179 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t180 = load i64, ptr %l5, !tbaa !24
  %t181 = load i1, ptr %l4, !tbaa !21
  %t182 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t182, 1
  %t185 = extractvalue { i64, ptr } %t182, 0
  %t186 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t187 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t188 = add i64 %t185, %t187
  %t189 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t188)
  call void @olang_textcopy(ptr %t189, ptr %t184, i64 %t185)
  %t190 = getelementptr i8, ptr %t189, i64 %t185
  call void @olang_textcopy(ptr %t190, ptr %t186, i64 %t187)
  %t191 = insertvalue { i64, ptr } undef, i64 %t188, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t189, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efnItem(ptr %v0, ptr %s0, ptr %s5, ptr %t173, { i64, [2 x i64] } %t174, i32 %t178, { i64, ptr } %t179, i64 %t180, i1 %t181, { i64, ptr } %t192)
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb37:
  %t201 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s2, ptr %t201, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d60, i32 0, i32 1) })
  br label %bb38
bb38:
  %t203 = load ptr, ptr %l0, !tbaa !29
  store ptr %t203, ptr %l93, !tbaa !29
  %t204 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t204, ptr %l94
  %t205 = load ptr, ptr %l2, !tbaa !29
  %t207 = getelementptr %"compiler/mir:Fn", ptr %t205, i32 0, i32 1
  %t208 = load i32, ptr %t207, !tbaa !23
  store i32 %t208, ptr %l96, !tbaa !23
  %t209 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t209, ptr %l97, !tbaa !27
  %t210 = load i64, ptr %l5, !tbaa !24
  store i64 %t210, ptr %l98, !tbaa !24
  %t211 = load i1, ptr %l4, !tbaa !21
  store i1 %t211, ptr %l99, !tbaa !21
  %t212 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t212, ptr %l100, !tbaa !27
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t217 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2estub(ptr %v0, ptr %s2, ptr %s0, ptr %s2, ptr %t213, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d61, i32 0, i32 1) }, { i64, ptr } %t214)
  store { i64, ptr } %t217, ptr %l103
  br label %bb39
bb39:
  %t218 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t219 = extractvalue { i64, ptr } %t218, 1
  %t220 = extractvalue { i64, ptr } %t218, 0
  %t221 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t222 = extractvalue { i64, ptr } %t221, 1
  %t223 = extractvalue { i64, ptr } %t221, 0
  %t224 = add i64 %t220, %t223
  %t225 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t224)
  call void @olang_textcopy(ptr %t225, ptr %t219, i64 %t220)
  %t226 = getelementptr i8, ptr %t225, i64 %t220
  call void @olang_textcopy(ptr %t226, ptr %t222, i64 %t223)
  %t227 = insertvalue { i64, ptr } undef, i64 %t224, 0
  %t228 = insertvalue { i64, ptr } %t227, ptr %t225, 1
  %t230 = load ptr, ptr %l93, !tbaa !29
  %t231 = load { i64, [2 x i64] }, ptr %l94
  %t232 = load i32, ptr %l96, !tbaa !23
  %t233 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t234 = load i64, ptr %l98, !tbaa !24
  %t235 = load i1, ptr %l99, !tbaa !21
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efnItem(ptr %v0, ptr %s0, ptr %s2, ptr %t230, { i64, [2 x i64] } %t231, i32 %t232, { i64, ptr } %t233, i64 %t234, i1 %t235, { i64, ptr } %t228)
  br label %bb40
bb40:
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t238 = load { i64, [2 x i64] }, ptr %l1
  %t239 = load ptr, ptr %l2, !tbaa !29
  %t241 = getelementptr %"compiler/mir:Fn", ptr %t239, i32 0, i32 1
  %t242 = load i32, ptr %t241, !tbaa !23
  %t243 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t244 = load i64, ptr %l5, !tbaa !24
  %t245 = load i1, ptr %l4, !tbaa !21
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewalkStub(ptr %v0, ptr %s0, ptr %s2, ptr %t237, { i64, [2 x i64] } %t238, i32 %t242, { i64, ptr } %t243, i64 %t244, i1 %t245, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d62, i32 0, i32 1) })
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb42:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t253 = load { i64, [2 x i64] }, ptr %l1
  %t254 = load ptr, ptr %l2, !tbaa !29
  %t255 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t256 = load i64, ptr %l5, !tbaa !24
  %t257 = load i1, ptr %l4, !tbaa !21
  %t258 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t266 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewriteBody(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t252, { i64, [2 x i64] } %t253, ptr %t254, { i64, ptr } %t255, i64 %t256, i1 %t257, { i64, ptr } %t258, i1 false)
  store i1 %t266, ptr %l120
  br label %bb43
bb43:
  %t267 = load i1, ptr %l120, !tbaa !21
  %t268 = xor i1 %t267, true
  br i1 %t268, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb45:
  br label %bb46
bb46:
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t271 = load { i64, [2 x i64] }, ptr %l1
  %t274 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisGenFn(ptr %v0, ptr %t270, { i64, [2 x i64] } %t271)
  store i1 %t274, ptr %l124
  br label %bb47
bb47:
  %t275 = load i1, ptr %l124, !tbaa !21
  %t276 = xor i1 %t275, true
  br i1 %t276, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb49:
  br label %bb50
bb50:
  %t278 = load ptr, ptr %l0, !tbaa !29
  store ptr %t278, ptr %l126, !tbaa !29
  %t279 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t279, ptr %l127
  %t280 = load ptr, ptr %l2, !tbaa !29
  %t282 = getelementptr %"compiler/mir:Fn", ptr %t280, i32 0, i32 1
  %t283 = load i32, ptr %t282, !tbaa !23
  store i32 %t283, ptr %l129, !tbaa !23
  %t284 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t286 = extractvalue { i64, ptr } %t284, 1
  %t287 = extractvalue { i64, ptr } %t284, 0
  %t288 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t289 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  %t290 = add i64 %t287, %t289
  %t291 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t290)
  call void @olang_textcopy(ptr %t291, ptr %t286, i64 %t287)
  %t292 = getelementptr i8, ptr %t291, i64 %t287
  call void @olang_textcopy(ptr %t292, ptr %t288, i64 %t289)
  %t293 = insertvalue { i64, ptr } undef, i64 %t290, 0
  %t294 = insertvalue { i64, ptr } %t293, ptr %t291, 1
  store { i64, ptr } %t294, ptr %l132, !tbaa !27
  %t296 = load i64, ptr %l5, !tbaa !24
  store i64 %t296, ptr %l133, !tbaa !24
  %t297 = load i1, ptr %l4, !tbaa !21
  store i1 %t297, ptr %l134, !tbaa !21
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t299 = load { i64, [2 x i64] }, ptr %l1
  %t302 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehomeOf(ptr %v0, ptr %t298, { i64, [2 x i64] } %t299)
  store i64 %t302, ptr %l137
  br label %bb51
bb51:
  %t303 = load i64, ptr %l137, !tbaa !24
  %t304 = call { i64, ptr } @compiler_2femit_2elinkFor(ptr %s0, i64 %t303)
  store { i64, ptr } %t304, ptr %l138
  br label %bb52
bb52:
  %t305 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t306 = load ptr, ptr %l126, !tbaa !29
  %t307 = load { i64, [2 x i64] }, ptr %l127
  %t308 = load i32, ptr %l129, !tbaa !23
  %t309 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t310 = load i64, ptr %l133, !tbaa !24
  %t311 = load i1, ptr %l134, !tbaa !21
  %t313 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eheader(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t306, { i64, [2 x i64] } %t307, i32 %t308, { i64, ptr } %t309, i64 %t310, i1 %t311, { i64, ptr } %t305, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d64, i32 0, i32 1) }, i64 0)
  store { i64, ptr } %t313, ptr %l140
  br label %bb53
bb53:
  %t314 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t316 = load { i64, [2 x i64] }, ptr %l1
  %t317 = load ptr, ptr %l2, !tbaa !29
  %t318 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t320 = extractvalue { i64, ptr } %t318, 1
  %t321 = extractvalue { i64, ptr } %t318, 0
  %t322 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t323 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  %t324 = add i64 %t321, %t323
  %t325 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t324)
  call void @olang_textcopy(ptr %t325, ptr %t320, i64 %t321)
  %t326 = getelementptr i8, ptr %t325, i64 %t321
  call void @olang_textcopy(ptr %t326, ptr %t322, i64 %t323)
  %t327 = insertvalue { i64, ptr } undef, i64 %t324, 0
  %t328 = insertvalue { i64, ptr } %t327, ptr %t325, 1
  %t330 = load i64, ptr %l5, !tbaa !24
  %t331 = load i1, ptr %l4, !tbaa !21
  %t340 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewriteBody(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t315, { i64, [2 x i64] } %t316, ptr %t317, { i64, ptr } %t328, i64 %t330, i1 %t331, { i64, ptr } %t314, i1 true)
  store i1 %t340, ptr %l150
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efvAdapter(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"std/prelude/text:StringBuilder"
  %l12 = alloca i32
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i8
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i32
  %l31 = alloca i32
  %l32 = alloca { i64, ptr }
  %l33 = alloca i1
  %l34 = alloca i1
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l44 = alloca i64
  %l49 = alloca i64
  %l53 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca ptr
  %l63 = alloca { i64, [2 x i64] }
  %l64 = alloca i32
  %l65 = alloca %"compiler/source:Span"
  %l66 = alloca %"compiler/mir:Fn"
  %l69 = alloca %"compiler/emit:fnEm"
  %l72 = alloca { i64, ptr }
  %l73 = alloca ptr
  %l75 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l78 = alloca %"std/prelude/text:StringBuilder"
  %l87 = alloca i32
  %l91 = alloca i1
  %l95 = alloca i1
  %l98 = alloca i1
  %l104 = alloca i64
  %l107 = alloca i64
  %l132 = alloca ptr
  %l134 = alloca { i64, ptr }
  %l140 = alloca ptr
  %l143 = alloca i32
  %l144 = alloca { i64, ptr }
  %l147 = alloca { i64, ptr }
  %l153 = alloca i64
  %l156 = alloca i64
  %l189 = alloca ptr
  %l191 = alloca { i64, ptr }
  %l194 = alloca { i64, ptr }
  %l204 = alloca { i64, ptr }
  %l208 = alloca { i64, ptr }
  %l211 = alloca i32
  %l214 = alloca i32
  %l216 = alloca i1
  %l217 = alloca ptr
  %l218 = alloca { i64, ptr }
  %l220 = alloca { i64, ptr }
  %l223 = alloca ptr
  %l225 = alloca i1
  %l226 = alloca { i64, ptr }
  %l227 = alloca ptr
  %l228 = alloca { i64, ptr }
  %l229 = alloca { i64, ptr }
  %l231 = alloca { i64, ptr }
  %l234 = alloca { i64, ptr }
  %l238 = alloca i1
  %l242 = alloca i1
  %l245 = alloca i1
  %l249 = alloca { i64, ptr }
  %l252 = alloca { i64, ptr }
  %l255 = alloca i64
  %l257 = alloca ptr
  %l260 = alloca { i64, ptr }
  %l267 = alloca { i64, ptr }
  %l271 = alloca { i64, ptr }
  %l275 = alloca { i64, ptr }
  %l278 = alloca { i64, ptr }
  %l280 = alloca { i64, ptr }
  %l286 = alloca { i64, ptr }
  %l291 = alloca i1
  %l298 = alloca { i64, ptr }
  %l311 = alloca { i64, ptr }
  %l312 = alloca ptr
  %l313 = alloca { i64, ptr }
  %l314 = alloca ptr
  %l315 = alloca { i64, ptr }
  %l316 = alloca { i64, ptr }
  %l317 = alloca ptr
  %l320 = alloca i32
  %l321 = alloca { i64, ptr }
  %l325 = alloca { i64, ptr }
  %l328 = alloca ptr
  %l331 = alloca { i64, ptr }
  %l332 = alloca i64
  %l333 = alloca { i64, ptr }
  %l336 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %t7 = alloca { i64, [4 x i64] }, align 8
  %t10 = alloca { i64, [7 x i64] }, align 8
  %t23 = alloca { i64, [4 x i64] }, align 8
  %t26 = alloca { i64, [7 x i64] }, align 8
  %t47 = alloca { i64, [2 x i64] }, align 8
  %t74 = alloca { i64, [2 x i64] }, align 8
  %t81 = alloca %"compiler/mir:Fn", align 8
  %t86 = alloca { i64, [2 x i64] }, align 8
  %t91 = alloca %"compiler/emit:fnEm", align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t7
  %t8 = getelementptr { i64, [4 x i64] }, ptr %t7, i32 0, i32 0
  store i64 0, ptr %t8
  %t9 = load { i64, [4 x i64] }, ptr %t7
  store { i64, [7 x i64] } zeroinitializer, ptr %t10
  %t11 = getelementptr { i64, [7 x i64] }, ptr %t10, i32 0, i32 0
  store i64 2, ptr %t11
  %t13 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t9, 0
  %t14 = getelementptr { i64, [7 x i64] }, ptr %t10, i32 0, i32 1
  store { { i64, [4 x i64] } } %t13, ptr %t14
  %t15 = load { i64, [7 x i64] }, ptr %t10
  %t16 = load i32, ptr %l2, !tbaa !23
  %t20 = call i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %t6, { i64, [7 x i64] } %t15, i32 %t16)
  store i64 %t20, ptr %l44
  br label %bb1
bb1:
  %t21 = load i64, ptr %l44, !tbaa !24
  store i64 %t21, ptr %l4, !tbaa !24
  %t22 = load ptr, ptr %l3, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t23
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t23, i32 0, i32 0
  store i64 0, ptr %t24
  %t25 = load { i64, [4 x i64] }, ptr %t23
  store { i64, [7 x i64] } zeroinitializer, ptr %t26
  %t27 = getelementptr { i64, [7 x i64] }, ptr %t26, i32 0, i32 0
  store i64 2, ptr %t27
  %t29 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t25, 0
  %t30 = getelementptr { i64, [7 x i64] }, ptr %t26, i32 0, i32 1
  store { { i64, [4 x i64] } } %t29, ptr %t30
  %t31 = load { i64, [7 x i64] }, ptr %t26
  %t32 = load i32, ptr %l1, !tbaa !23
  %t36 = call i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %t22, { i64, [7 x i64] } %t31, i32 %t32)
  store i64 %t36, ptr %l49
  br label %bb2
bb2:
  %t37 = load i64, ptr %l49, !tbaa !24
  store i64 %t37, ptr %l5, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i32, ptr %l1, !tbaa !23
  %t40 = load i32, ptr %l2, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eadaptKey(ptr %v0, ptr %s0, ptr %t38, i32 %t39, i32 %t40)
  store { i64, ptr } %t44, ptr %l53
  br label %bb3
bb3:
  %t45 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t45, ptr %l6, !tbaa !27
  %t46 = load ptr, ptr %l0, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t47
  %t48 = getelementptr { i64, [2 x i64] }, ptr %t47, i32 0, i32 0
  store i64 4, ptr %t48
  %t49 = insertvalue { i64 } undef, i64 0, 0
  %t50 = getelementptr { i64, [2 x i64] }, ptr %t47, i32 0, i32 1
  store { i64 } %t49, ptr %t50
  %t51 = load { i64, [2 x i64] }, ptr %t47
  %t52 = load i32, ptr %l2, !tbaa !23
  %t53 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t54 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t55 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t57 = extractvalue { i64, ptr } %t53, 1
  %t58 = extractvalue { i64, ptr } %t53, 0
  %t59 = add i64 %t55, %t58
  %t60 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t59)
  call void @olang_textcopy(ptr %t60, ptr %t54, i64 %t55)
  %t61 = getelementptr i8, ptr %t60, i64 %t55
  call void @olang_textcopy(ptr %t61, ptr %t57, i64 %t58)
  %t62 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t60, 1
  %t65 = load i64, ptr %l4, !tbaa !24
  %t71 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eheader(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t46, { i64, [2 x i64] } %t51, i32 %t52, { i64, ptr } %t63, i64 %t65, i1 true, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d67, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d51, i32 0, i32 1) }, i64 0)
  store { i64, ptr } %t71, ptr %l61
  br label %bb4
bb4:
  %t72 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t72, ptr %l7, !tbaa !27
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l62, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t74
  %t75 = getelementptr { i64, [2 x i64] }, ptr %t74, i32 0, i32 0
  store i64 4, ptr %t75
  %t76 = insertvalue { i64 } undef, i64 0, 0
  %t77 = getelementptr { i64, [2 x i64] }, ptr %t74, i32 0, i32 1
  store { i64 } %t76, ptr %t77
  %t78 = load { i64, [2 x i64] }, ptr %t74
  store { i64, [2 x i64] } %t78, ptr %l63
  %t79 = load i32, ptr %l2, !tbaa !23
  store i32 %t79, ptr %l64, !tbaa !23
  %t80 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t80, ptr %l65
  br label %bb5
bb5:
  %t82 = load { i64, [2 x i64] }, ptr %l63
  %t83 = load i32, ptr %l64, !tbaa !23
  %t84 = load %"compiler/source:Span", ptr %l65
  call void @compiler_2fmir_3aFn_2ector(ptr %t81, ptr %s0, { i64, [2 x i64] } %t82, i32 %t83, i64 0, %"compiler/source:Span" %t84)
  call void @llvm.memmove.p0.p0.i64(ptr %l66, ptr %t81, i64 808, i1 false)
  br label %bb6
bb6:
  %t85 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 808, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t85, ptr %l66, i64 808, i1 false)
  store { i64, [2 x i64] } zeroinitializer, ptr %t86
  %t87 = getelementptr { i64, [2 x i64] }, ptr %t86, i32 0, i32 0
  store i64 4, ptr %t87
  %t88 = insertvalue { i64 } undef, i64 0, 0
  %t89 = getelementptr { i64, [2 x i64] }, ptr %t86, i32 0, i32 1
  store { i64 } %t88, ptr %t89
  %t90 = load { i64, [2 x i64] }, ptr %t86
  %t92 = load ptr, ptr %l62, !tbaa !29
  call void @compiler_2femit_3afnEm_2ector(ptr %t91, ptr %v0, ptr %s0, ptr %s0, ptr %t92, ptr %t85, { i64, [2 x i64] } %t90)
  call void @llvm.memmove.p0.p0.i64(ptr %l69, ptr %t91, i64 1104, i1 false)
  br label %bb7
bb7:
  %t95 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 1104, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t95, ptr %l69, i64 1104, i1 false)
  store ptr %t95, ptr %l8, !tbaa !29
  %t97 = load ptr, ptr %l8, !tbaa !29
  %t99 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %v0, ptr %t97, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d68, i32 0, i32 1) }, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d69, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d49, i32 0, i32 1) })
  store { i64, ptr } %t99, ptr %l72
  br label %bb8
bb8:
  %t100 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t100, ptr %l9, !tbaa !27
  %t101 = load ptr, ptr %l8, !tbaa !29
  store ptr %t101, ptr %l73, !tbaa !29
  %t102 = load ptr, ptr %l8, !tbaa !29
  %t104 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %s0, ptr %s0, ptr %s0, ptr %v0, ptr %t102, { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d70, i32 0, i32 1) })
  store { i64, ptr } %t104, ptr %l75
  br label %bb9
bb9:
  %t105 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t106 = load ptr, ptr %l73, !tbaa !29
  %t108 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %v0, ptr %t106, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d71, i32 0, i32 1) }, { i64, ptr } %t105, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d49, i32 0, i32 1) })
  store { i64, ptr } %t108, ptr %l77
  br label %bb10
bb10:
  %t109 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t109, ptr %l10, !tbaa !27
  %t110 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t110, ptr %l78
  br label %bb11
bb11:
  %t111 = load %"std/prelude/text:StringBuilder", ptr %l78
  store %"std/prelude/text:StringBuilder" %t111, ptr %l11
  %t112 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t113 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t114 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  %t116 = extractvalue { i64, ptr } %t112, 1
  %t117 = extractvalue { i64, ptr } %t112, 0
  %t118 = add i64 %t114, %t117
  %t119 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t118)
  call void @olang_textcopy(ptr %t119, ptr %t113, i64 %t114)
  %t120 = getelementptr i8, ptr %t119, i64 %t114
  call void @olang_textcopy(ptr %t120, ptr %t116, i64 %t117)
  %t121 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t119, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l11, { i64, ptr } %t122)
  br label %bb12
bb12:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2esignature(ptr %v0, ptr %t126, i32 %t127)
  br label %bb13
bb13:
  %t130 = load ptr, ptr %l3, !tbaa !29
  %t131 = load i32, ptr %l1, !tbaa !23
  %t134 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t130, i32 %t131)
  store i32 %t134, ptr %l87
  br label %bb14
bb14:
  %t135 = load i32, ptr %l87, !tbaa !23
  store i32 %t135, ptr %l12, !tbaa !23
  %t136 = load i32, ptr %l12, !tbaa !23
  %t137 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t140 = icmp ne i32 %t136, %t137
  br i1 %t140, label %bb15, label %bb16
bb15:
  %t142 = load i32, ptr %l12, !tbaa !23
  %t143 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t146 = icmp ne i32 %t142, %t143
  store i1 %t146, ptr %l91, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb17
bb17:
  %t148 = load i1, ptr %l91, !tbaa !21
  br i1 %t148, label %bb18, label %bb19
bb18:
  %t149 = load ptr, ptr %l3, !tbaa !29
  %t150 = load i32, ptr %l12, !tbaa !23
  %t153 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %t149, i32 %t150)
  store i1 %t153, ptr %l98
  br label %bb20
bb19:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb21
bb20:
  %t154 = load i1, ptr %l98, !tbaa !21
  store i1 %t154, ptr %l95, !tbaa !21
  br label %bb21
bb21:
  %t155 = load i1, ptr %l95, !tbaa !21
  br i1 %t155, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l11, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d73, i32 0, i32 1) })
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb25:
  store i64 0, ptr %l13, !tbaa !24
  %t157 = load i64, ptr %l5, !tbaa !24
  store i64 %t157, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t159 = load i64, ptr %l14, !tbaa !24
  %t160 = load i64, ptr %l13, !tbaa !24
  %t163 = icmp sgt i64 %t159, %t160
  br i1 %t163, label %bb26, label %bb27
bb26:
  %t165 = load i64, ptr %l15, !tbaa !24
  %t167 = icmp sgt i64 %t165, 0
  br i1 %t167, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l104, !tbaa !24
  br label %bb31
bb28:
  %t169 = load i64, ptr %l14, !tbaa !24
  %t170 = load i64, ptr %l13, !tbaa !24
  %t173 = sub i64 %t169, %t170
  %t174 = load i64, ptr %l15, !tbaa !24
  %t177 = add i64 %t173, %t174
  %t179 = sub i64 %t177, 1
  %t180 = load i64, ptr %l15, !tbaa !24
  %t183 = sdiv i64 %t179, %t180
  store i64 %t183, ptr %l107, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l107, !tbaa !24
  br label %bb30
bb30:
  %t185 = load i64, ptr %l107, !tbaa !24
  store i64 %t185, ptr %l104, !tbaa !24
  br label %bb31
bb31:
  %t186 = load i64, ptr %l104, !tbaa !24
  store i64 %t186, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb32
bb32:
  %t187 = load i64, ptr %l17, !tbaa !24
  %t188 = load i64, ptr %l16, !tbaa !24
  %t191 = icmp slt i64 %t187, %t188
  %t193 = xor i1 %t191, true
  br i1 %t193, label %bb33, label %bb34
bb33:
  br label %bb43
bb34:
  br label %bb35
bb35:
  %t195 = load i64, ptr %l13, !tbaa !24
  %t196 = load i64, ptr %l17, !tbaa !24
  %t197 = load i64, ptr %l15, !tbaa !24
  %t200 = mul i64 %t196, %t197
  %t203 = add i64 %t195, %t200
  store i64 %t203, ptr %l18, !tbaa !24
  %t205 = load i64, ptr %l18, !tbaa !24
  %t206 = load i64, ptr %l4, !tbaa !24
  %t209 = icmp slt i64 %t205, %t206
  br i1 %t209, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s6
  %t211 = load i64, ptr %l18, !tbaa !24
  %t212 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t213 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t215 = call i64 @__olang_fmt_i64(ptr null, i64 %t211)
  %t216 = add i64 %t213, %t215
  %t217 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t216)
  call void @olang_textcopy(ptr %t217, ptr %t212, i64 %t213)
  %t218 = getelementptr i8, ptr %t217, i64 %t213
  %t219 = call i64 @__olang_fmt_i64(ptr %t218, i64 %t211)
  %t220 = insertvalue { i64, ptr } undef, i64 %t216, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr %t217, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %l11, { i64, ptr } %t221)
  br label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s8
  store ptr %l11, ptr %l132, !tbaa !29
  %t225 = load ptr, ptr %l8, !tbaa !29
  %t227 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eprogram(ptr %s0, ptr %s8, ptr %v0, ptr %t225)
  store { i64, ptr } %t227, ptr %l134
  br label %bb39
bb38:
  call void @__olang_scope_close(ptr %s6)
  br label %bb41
bb39:
  %t228 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d75, i32 0, i32 1) }, 1
  %t229 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d75, i32 0, i32 1) }, 0
  %t230 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t231 = extractvalue { i64, ptr } %t230, 1
  %t232 = extractvalue { i64, ptr } %t230, 0
  %t233 = add i64 %t229, %t232
  %t234 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t233)
  call void @olang_textcopy(ptr %t234, ptr %t228, i64 %t229)
  %t235 = getelementptr i8, ptr %t234, i64 %t229
  call void @olang_textcopy(ptr %t235, ptr %t231, i64 %t232)
  %t236 = insertvalue { i64, ptr } undef, i64 %t233, 0
  %t237 = insertvalue { i64, ptr } %t236, ptr %t234, 1
  %t239 = load ptr, ptr %l132, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s8, ptr %t239, { i64, ptr } %t237)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s8)
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t241 = load i64, ptr %l17, !tbaa !24
  %t244 = add i64 %t241, 1
  store i64 %t244, ptr %l17, !tbaa !24
  br label %bb32
bb43:
  %t246 = load ptr, ptr %l3, !tbaa !29
  store ptr %t246, ptr %l140, !tbaa !29
  %t247 = load ptr, ptr %l3, !tbaa !29
  %t248 = load i32, ptr %l2, !tbaa !23
  %t251 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t247, i32 %t248)
  store i32 %t251, ptr %l143
  br label %bb44
bb44:
  %t252 = load ptr, ptr %l140, !tbaa !29
  %t253 = load i32, ptr %l143, !tbaa !23
  %t254 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t252, i32 %t253)
  store { i64, ptr } %t254, ptr %l144
  br label %bb45
bb45:
  %t255 = load { i64, ptr }, ptr %l144, !tbaa !27
  store { i64, ptr } %t255, ptr %l19, !tbaa !27
  %t256 = load ptr, ptr %l3, !tbaa !29
  %t257 = load i32, ptr %l2, !tbaa !23
  %t260 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePassing(ptr %v0, ptr %s0, ptr %t256, i32 %t257)
  store { i64, ptr } %t260, ptr %l147
  br label %bb46
bb46:
  %t261 = load { i64, ptr }, ptr %l147, !tbaa !27
  store { i64, ptr } %t261, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t262 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t264 = extractvalue { i64, ptr } %t262, 0
  store i64 %t264, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t266 = load i64, ptr %l22, !tbaa !24
  %t267 = load i64, ptr %l21, !tbaa !24
  %t270 = icmp sgt i64 %t266, %t267
  br i1 %t270, label %bb47, label %bb48
bb47:
  %t272 = load i64, ptr %l23, !tbaa !24
  %t274 = icmp sgt i64 %t272, 0
  br i1 %t274, label %bb49, label %bb50
bb48:
  store i64 0, ptr %l153, !tbaa !24
  br label %bb52
bb49:
  %t276 = load i64, ptr %l22, !tbaa !24
  %t277 = load i64, ptr %l21, !tbaa !24
  %t280 = sub i64 %t276, %t277
  %t281 = load i64, ptr %l23, !tbaa !24
  %t284 = add i64 %t280, %t281
  %t286 = sub i64 %t284, 1
  %t287 = load i64, ptr %l23, !tbaa !24
  %t290 = sdiv i64 %t286, %t287
  store i64 %t290, ptr %l156, !tbaa !24
  br label %bb51
bb50:
  store i64 0, ptr %l156, !tbaa !24
  br label %bb51
bb51:
  %t292 = load i64, ptr %l156, !tbaa !24
  store i64 %t292, ptr %l153, !tbaa !24
  br label %bb52
bb52:
  %t293 = load i64, ptr %l153, !tbaa !24
  store i64 %t293, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb53
bb53:
  %t294 = load i64, ptr %l25, !tbaa !24
  %t295 = load i64, ptr %l24, !tbaa !24
  %t298 = icmp slt i64 %t294, %t295
  %t300 = xor i1 %t298, true
  br i1 %t300, label %bb54, label %bb55
bb54:
  br label %bb75
bb55:
  br label %bb56
bb56:
  %t302 = load i64, ptr %l21, !tbaa !24
  %t303 = load i64, ptr %l25, !tbaa !24
  %t304 = load i64, ptr %l23, !tbaa !24
  %t307 = mul i64 %t303, %t304
  %t310 = add i64 %t302, %t307
  store i64 %t310, ptr %l26, !tbaa !24
  %t312 = load i64, ptr %l26, !tbaa !24
  %t314 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t315 = load ptr, ptr %t314, !tbaa !27
  %t316 = getelementptr i8, ptr %t315, i64 %t312
  %t317 = load i8, ptr %t316, !tbaa !32
  store i8 %t317, ptr %l27, !tbaa !22
  %t319 = load i8, ptr %l27, !tbaa !22
  %t321 = icmp eq i8 %t319, 109
  br i1 %t321, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb61
bb59:
  store %olang.scope zeroinitializer, ptr %s13
  %t323 = load i64, ptr %l26, !tbaa !24
  %t324 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d76, i32 0, i32 1) }, 1
  %t325 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d76, i32 0, i32 1) }, 0
  %t327 = call i64 @__olang_fmt_i64(ptr null, i64 %t323)
  %t328 = add i64 %t325, %t327
  %t329 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t328)
  call void @olang_textcopy(ptr %t329, ptr %t324, i64 %t325)
  %t330 = getelementptr i8, ptr %t329, i64 %t325
  %t331 = call i64 @__olang_fmt_i64(ptr %t330, i64 %t323)
  %t332 = insertvalue { i64, ptr } undef, i64 %t328, 0
  %t333 = insertvalue { i64, ptr } %t332, ptr %t329, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s13, ptr %l11, { i64, ptr } %t333)
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s13)
  br label %bb73
bb61:
  %t337 = load i8, ptr %l27, !tbaa !22
  %t339 = icmp eq i8 %t337, 115
  br i1 %t339, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb66
bb64:
  store %olang.scope zeroinitializer, ptr %s15
  %t341 = load i64, ptr %l26, !tbaa !24
  %t342 = load i64, ptr %l26, !tbaa !24
  %t343 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t344 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  %t346 = call i64 @__olang_fmt_i64(ptr null, i64 %t341)
  %t347 = add i64 %t344, %t346
  %t348 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d78, i32 0, i32 1) }, 1
  %t349 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d78, i32 0, i32 1) }, 0
  %t350 = add i64 %t347, %t349
  %t352 = call i64 @__olang_fmt_i64(ptr null, i64 %t342)
  %t353 = add i64 %t350, %t352
  %t354 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d79, i32 0, i32 1) }, 1
  %t355 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d79, i32 0, i32 1) }, 0
  %t356 = add i64 %t353, %t355
  %t357 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t356)
  call void @olang_textcopy(ptr %t357, ptr %t343, i64 %t344)
  %t358 = getelementptr i8, ptr %t357, i64 %t344
  %t359 = call i64 @__olang_fmt_i64(ptr %t358, i64 %t341)
  %t360 = getelementptr i8, ptr %t358, i64 %t346
  call void @olang_textcopy(ptr %t360, ptr %t348, i64 %t349)
  %t361 = getelementptr i8, ptr %t360, i64 %t349
  %t362 = call i64 @__olang_fmt_i64(ptr %t361, i64 %t342)
  %t363 = getelementptr i8, ptr %t361, i64 %t352
  call void @olang_textcopy(ptr %t363, ptr %t354, i64 %t355)
  %t364 = insertvalue { i64, ptr } undef, i64 %t356, 0
  %t365 = insertvalue { i64, ptr } %t364, ptr %t357, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s15, ptr %l11, { i64, ptr } %t365)
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s15)
  br label %bb73
bb66:
  br i1 true, label %bb67, label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb72
bb69:
  store %olang.scope zeroinitializer, ptr %s17
  store ptr %l11, ptr %l189, !tbaa !29
  %t369 = load ptr, ptr %l0, !tbaa !29
  %t370 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t370, ptr %l191, !tbaa !27
  %t371 = load i64, ptr %l26, !tbaa !24
  %t373 = getelementptr { i64, ptr }, ptr %l191, i32 0, i32 1
  %t374 = load ptr, ptr %t373, !tbaa !27
  %t375 = getelementptr i32, ptr %t374, i64 %t371
  %t376 = load i32, ptr %t375, !tbaa !33
  %t379 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s17, ptr %t369, i32 %t376)
  store { i64, ptr } %t379, ptr %l194
  br label %bb70
bb70:
  %t380 = load i64, ptr %l26, !tbaa !24
  %t381 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d80, i32 0, i32 1) }, 1
  %t382 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d80, i32 0, i32 1) }, 0
  %t383 = load { i64, ptr }, ptr %l194, !tbaa !27
  %t384 = extractvalue { i64, ptr } %t383, 1
  %t385 = extractvalue { i64, ptr } %t383, 0
  %t386 = add i64 %t382, %t385
  %t387 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d81, i32 0, i32 1) }, 1
  %t388 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d81, i32 0, i32 1) }, 0
  %t389 = add i64 %t386, %t388
  %t391 = call i64 @__olang_fmt_i64(ptr null, i64 %t380)
  %t392 = add i64 %t389, %t391
  %t393 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t392)
  call void @olang_textcopy(ptr %t393, ptr %t381, i64 %t382)
  %t394 = getelementptr i8, ptr %t393, i64 %t382
  call void @olang_textcopy(ptr %t394, ptr %t384, i64 %t385)
  %t395 = getelementptr i8, ptr %t394, i64 %t385
  call void @olang_textcopy(ptr %t395, ptr %t387, i64 %t388)
  %t396 = getelementptr i8, ptr %t395, i64 %t388
  %t397 = call i64 @__olang_fmt_i64(ptr %t396, i64 %t380)
  %t398 = insertvalue { i64, ptr } undef, i64 %t392, 0
  %t399 = insertvalue { i64, ptr } %t398, ptr %t393, 1
  %t401 = load ptr, ptr %l189, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s17, ptr %t401, { i64, ptr } %t399)
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s17)
  br label %bb73
bb72:
  call void @__olang_check_failed(ptr @olang_loc_e3ad71d8c7542caf_f4839b67a89e1c73)
  unreachable
bb73:
  br label %bb74
bb74:
  %t403 = load i64, ptr %l25, !tbaa !24
  %t406 = add i64 %t403, 1
  store i64 %t406, ptr %l25, !tbaa !24
  br label %bb53
bb75:
  %t408 = load ptr, ptr %l3, !tbaa !29
  %t409 = load i32, ptr %l1, !tbaa !23
  %t411 = inttoptr i64 0 to ptr
  %t414 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %s0, ptr %t411, ptr %t408, i32 %t409)
  store { i64, ptr } %t414, ptr %l204
  br label %bb76
bb76:
  %t415 = load { i64, ptr }, ptr %l204, !tbaa !27
  store { i64, ptr } %t415, ptr %l28, !tbaa !27
  %t416 = load ptr, ptr %l3, !tbaa !29
  %t417 = load i32, ptr %l2, !tbaa !23
  %t419 = inttoptr i64 0 to ptr
  %t422 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %s0, ptr %t419, ptr %t416, i32 %t417)
  store { i64, ptr } %t422, ptr %l208
  br label %bb77
bb77:
  %t423 = load { i64, ptr }, ptr %l208, !tbaa !27
  store { i64, ptr } %t423, ptr %l29, !tbaa !27
  %t424 = load ptr, ptr %l3, !tbaa !29
  %t425 = load i32, ptr %l1, !tbaa !23
  %t428 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t424, i32 %t425)
  store i32 %t428, ptr %l211
  br label %bb78
bb78:
  %t429 = load i32, ptr %l211, !tbaa !23
  store i32 %t429, ptr %l30, !tbaa !23
  %t430 = load ptr, ptr %l3, !tbaa !29
  %t431 = load i32, ptr %l2, !tbaa !23
  %t434 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t430, i32 %t431)
  store i32 %t434, ptr %l214
  br label %bb79
bb79:
  %t435 = load i32, ptr %l214, !tbaa !23
  store i32 %t435, ptr %l31, !tbaa !23
  %t436 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t438 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t436, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d82, i32 0, i32 1) })
  store i1 %t438, ptr %l216
  br label %bb80
bb80:
  %t439 = load i1, ptr %l216, !tbaa !21
  br i1 %t439, label %bb81, label %bb82
bb81:
  store %olang.scope zeroinitializer, ptr %s20
  %t440 = load ptr, ptr %l8, !tbaa !29
  store ptr %t440, ptr %l217, !tbaa !29
  %t441 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t441, ptr %l218, !tbaa !27
  %t443 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s20, ptr %l11)
  store { i64, ptr } %t443, ptr %l220
  br label %bb83
bb82:
  store %olang.scope zeroinitializer, ptr %s22
  %t444 = load ptr, ptr %l8, !tbaa !29
  store ptr %t444, ptr %l227, !tbaa !29
  %t445 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t445, ptr %l228, !tbaa !27
  %t446 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t446, ptr %l229, !tbaa !27
  %t448 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s22, ptr %l11)
  store { i64, ptr } %t448, ptr %l231
  br label %bb90
bb83:
  %t449 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d83, i32 0, i32 1) }, 1
  %t450 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d83, i32 0, i32 1) }, 0
  %t451 = load { i64, ptr }, ptr %l218, !tbaa !27
  %t452 = extractvalue { i64, ptr } %t451, 1
  %t453 = extractvalue { i64, ptr } %t451, 0
  %t454 = add i64 %t450, %t453
  %t455 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d84, i32 0, i32 1) }, 1
  %t456 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d84, i32 0, i32 1) }, 0
  %t457 = add i64 %t454, %t456
  %t458 = load { i64, ptr }, ptr %l220, !tbaa !27
  %t459 = extractvalue { i64, ptr } %t458, 1
  %t460 = extractvalue { i64, ptr } %t458, 0
  %t461 = add i64 %t457, %t460
  %t462 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d85, i32 0, i32 1) }, 1
  %t463 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d85, i32 0, i32 1) }, 0
  %t464 = add i64 %t461, %t463
  %t465 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t464)
  call void @olang_textcopy(ptr %t465, ptr %t449, i64 %t450)
  %t466 = getelementptr i8, ptr %t465, i64 %t450
  call void @olang_textcopy(ptr %t466, ptr %t452, i64 %t453)
  %t467 = getelementptr i8, ptr %t466, i64 %t453
  call void @olang_textcopy(ptr %t467, ptr %t455, i64 %t456)
  %t468 = getelementptr i8, ptr %t467, i64 %t456
  call void @olang_textcopy(ptr %t468, ptr %t459, i64 %t460)
  %t469 = getelementptr i8, ptr %t468, i64 %t460
  call void @olang_textcopy(ptr %t469, ptr %t462, i64 %t463)
  %t470 = insertvalue { i64, ptr } undef, i64 %t464, 0
  %t471 = insertvalue { i64, ptr } %t470, ptr %t465, 1
  %t473 = load ptr, ptr %l217, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %s0, ptr %s20, ptr %v0, ptr %t473, { i64, ptr } %t471)
  br label %bb84
bb84:
  %t475 = load ptr, ptr %l8, !tbaa !29
  store ptr %t475, ptr %l223, !tbaa !29
  %t476 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t478 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s20, { i64, ptr } %t476, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d86, i32 0, i32 1) })
  store i1 %t478, ptr %l225
  br label %bb85
bb85:
  %t479 = load i1, ptr %l225, !tbaa !21
  br i1 %t479, label %bb86, label %bb87
bb86:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d87, i32 0, i32 1) }, ptr %l226, !tbaa !27
  br label %bb88
bb87:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d88, i32 0, i32 1) }, ptr %l226, !tbaa !27
  br label %bb88
bb88:
  %t480 = load ptr, ptr %l223, !tbaa !29
  %t481 = load { i64, ptr }, ptr %l226, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %s0, ptr %s20, ptr %v0, ptr %t480, { i64, ptr } %t481)
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s20)
  br label %bb138
bb90:
  %t482 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d89, i32 0, i32 1) }, 1
  %t483 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d89, i32 0, i32 1) }, 0
  %t484 = load { i64, ptr }, ptr %l228, !tbaa !27
  %t485 = extractvalue { i64, ptr } %t484, 1
  %t486 = extractvalue { i64, ptr } %t484, 0
  %t487 = add i64 %t483, %t486
  %t488 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d90, i32 0, i32 1) }, 1
  %t489 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d90, i32 0, i32 1) }, 0
  %t490 = add i64 %t487, %t489
  %t491 = load { i64, ptr }, ptr %l229, !tbaa !27
  %t492 = extractvalue { i64, ptr } %t491, 1
  %t493 = extractvalue { i64, ptr } %t491, 0
  %t494 = add i64 %t490, %t493
  %t495 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d91, i32 0, i32 1) }, 1
  %t496 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d91, i32 0, i32 1) }, 0
  %t497 = add i64 %t494, %t496
  %t498 = load { i64, ptr }, ptr %l231, !tbaa !27
  %t499 = extractvalue { i64, ptr } %t498, 1
  %t500 = extractvalue { i64, ptr } %t498, 0
  %t501 = add i64 %t497, %t500
  %t502 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t503 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  %t504 = add i64 %t501, %t503
  %t505 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t504)
  call void @olang_textcopy(ptr %t505, ptr %t482, i64 %t483)
  %t506 = getelementptr i8, ptr %t505, i64 %t483
  call void @olang_textcopy(ptr %t506, ptr %t485, i64 %t486)
  %t507 = getelementptr i8, ptr %t506, i64 %t486
  call void @olang_textcopy(ptr %t507, ptr %t488, i64 %t489)
  %t508 = getelementptr i8, ptr %t507, i64 %t489
  call void @olang_textcopy(ptr %t508, ptr %t492, i64 %t493)
  %t509 = getelementptr i8, ptr %t508, i64 %t493
  call void @olang_textcopy(ptr %t509, ptr %t495, i64 %t496)
  %t510 = getelementptr i8, ptr %t509, i64 %t496
  call void @olang_textcopy(ptr %t510, ptr %t499, i64 %t500)
  %t511 = getelementptr i8, ptr %t510, i64 %t500
  call void @olang_textcopy(ptr %t511, ptr %t502, i64 %t503)
  %t512 = insertvalue { i64, ptr } undef, i64 %t504, 0
  %t513 = insertvalue { i64, ptr } %t512, ptr %t505, 1
  %t515 = load ptr, ptr %l227, !tbaa !29
  %t517 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %s0, ptr %s22, ptr %s22, ptr %v0, ptr %t515, { i64, ptr } %t513)
  store { i64, ptr } %t517, ptr %l234
  br label %bb91
bb91:
  %t518 = load { i64, ptr }, ptr %l234, !tbaa !27
  store { i64, ptr } %t518, ptr %l32, !tbaa !27
  %t519 = load i32, ptr %l12, !tbaa !23
  %t520 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t523 = icmp ne i32 %t519, %t520
  br i1 %t523, label %bb92, label %bb93
bb92:
  %t525 = load i32, ptr %l12, !tbaa !23
  %t526 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t529 = icmp ne i32 %t525, %t526
  store i1 %t529, ptr %l238, !tbaa !21
  br label %bb94
bb93:
  store i1 false, ptr %l238, !tbaa !21
  br label %bb94
bb94:
  %t531 = load i1, ptr %l238, !tbaa !21
  br i1 %t531, label %bb95, label %bb96
bb95:
  %t532 = load ptr, ptr %l3, !tbaa !29
  %t533 = load i32, ptr %l12, !tbaa !23
  %t536 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %t532, i32 %t533)
  store i1 %t536, ptr %l245
  br label %bb97
bb96:
  store i1 false, ptr %l242, !tbaa !21
  br label %bb98
bb97:
  %t537 = load i1, ptr %l245, !tbaa !21
  %t538 = xor i1 %t537, true
  store i1 %t538, ptr %l242, !tbaa !21
  br label %bb98
bb98:
  %t540 = load i1, ptr %l242, !tbaa !21
  store i1 %t540, ptr %l33, !tbaa !21
  %t541 = load ptr, ptr %l3, !tbaa !29
  %t542 = load i32, ptr %l30, !tbaa !23
  %t545 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s22, ptr %t541, i32 %t542)
  store { i64, ptr } %t545, ptr %l249
  br label %bb99
bb99:
  %t546 = load { i64, ptr }, ptr %l249, !tbaa !27
  %t547 = extractvalue { i64, ptr } %t546, 0
  %t549 = icmp sgt i64 %t547, 0
  store i1 %t549, ptr %l34, !tbaa !21
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d93, i32 0, i32 1) }, ptr %l252, !tbaa !27
  %t551 = load { i64, ptr }, ptr %l252, !tbaa !27
  store { i64, ptr } %t551, ptr %l35, !tbaa !27
  %t553 = load i1, ptr %l34, !tbaa !21
  br i1 %t553, label %bb100, label %bb101
bb100:
  store %olang.scope zeroinitializer, ptr %s24
  %t555 = call ptr @__olang_scope_hold(ptr %s22)
  %t556 = ptrtoint ptr %t555 to i64
  store i64 %t556, ptr %l255, !tbaa !24
  %t557 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3aEmitter__2efvAdapter_2elocal_2e35
  br i1 %t557, label %bb102, label %bb103
bb101:
  br label %bb115
bb102:
  %t559 = call ptr @__olang_region_make(ptr %s22)
  %t560 = ptrtoint ptr %t559 to i64
  store i64 %t560, ptr %l255, !tbaa !24
  br label %bb103
bb103:
  %t561 = load ptr, ptr %l8, !tbaa !29
  store ptr %t561, ptr %l257, !tbaa !29
  %t562 = load i1, ptr %l33, !tbaa !21
  %t564 = xor i1 %t562, true
  br i1 %t564, label %bb104, label %bb105
bb104:
  %t566 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t566, ptr %l260, !tbaa !27
  br label %bb107
bb105:
  %t568 = load ptr, ptr %l8, !tbaa !29
  %t569 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t570 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t571 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t572 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  %t574 = extractvalue { i64, ptr } %t569, 1
  %t575 = extractvalue { i64, ptr } %t569, 0
  %t576 = add i64 %t572, %t575
  %t577 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t578 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  %t579 = add i64 %t576, %t578
  %t581 = extractvalue { i64, ptr } %t570, 1
  %t582 = extractvalue { i64, ptr } %t570, 0
  %t583 = add i64 %t579, %t582
  %t584 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d96, i32 0, i32 1) }, 1
  %t585 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d96, i32 0, i32 1) }, 0
  %t586 = add i64 %t583, %t585
  %t587 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t586)
  call void @olang_textcopy(ptr %t587, ptr %t571, i64 %t572)
  %t588 = getelementptr i8, ptr %t587, i64 %t572
  call void @olang_textcopy(ptr %t588, ptr %t574, i64 %t575)
  %t589 = getelementptr i8, ptr %t588, i64 %t575
  call void @olang_textcopy(ptr %t589, ptr %t577, i64 %t578)
  %t590 = getelementptr i8, ptr %t589, i64 %t578
  call void @olang_textcopy(ptr %t590, ptr %t581, i64 %t582)
  %t591 = getelementptr i8, ptr %t590, i64 %t582
  call void @olang_textcopy(ptr %t591, ptr %t584, i64 %t585)
  %t592 = insertvalue { i64, ptr } undef, i64 %t586, 0
  %t593 = insertvalue { i64, ptr } %t592, ptr %t587, 1
  %t597 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %s0, ptr %s24, ptr %s22, ptr %v0, ptr %t568, { i64, ptr } %t593)
  store { i64, ptr } %t597, ptr %l267
  br label %bb106
bb106:
  %t598 = load { i64, ptr }, ptr %l267, !tbaa !27
  store { i64, ptr } %t598, ptr %l260, !tbaa !27
  br label %bb107
bb107:
  %t600 = load i32, ptr %l30, !tbaa !23
  %t601 = load i32, ptr %l31, !tbaa !23
  %t602 = load i64, ptr %l255
  %t603 = inttoptr i64 %t602 to ptr
  %t604 = load ptr, ptr %l257, !tbaa !29
  %t605 = load { i64, ptr }, ptr %l260, !tbaa !27
  %t608 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2erecode(ptr %s0, ptr %s22, ptr %t603, ptr %v0, ptr %t604, { i64, ptr } %t605, i32 %t600, i32 %t601)
  store { i64, ptr } %t608, ptr %l271
  br label %bb108
bb108:
  %t609 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3aEmitter__2efvAdapter_2elocal_2e35
  br i1 %t609, label %bb109, label %bb110
bb109:
  %t611 = load { i64, ptr }, ptr %l271, !tbaa !27
  %t612 = extractvalue { i64, ptr } %t611, 0
  %t614 = icmp eq i64 %t612, 0
  br i1 %t614, label %bb111, label %bb112
bb110:
  %t616 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t616, ptr %l275, !tbaa !27
  %t617 = load { i64, ptr }, ptr %l271, !tbaa !27
  store { i64, ptr } %t617, ptr %l35, !tbaa !27
  %t618 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3aEmitter__2efvAdapter_2elocal_2e35
  br i1 %t618, label %bb113, label %bb114
bb111:
  store { i64, ptr } zeroinitializer, ptr %l271, !tbaa !27
  br label %bb112
bb112:
  %t620 = load i64, ptr %l255
  %t621 = inttoptr i64 %t620 to ptr
  %t622 = load { i64, ptr }, ptr %l271
  %t623 = extractvalue { i64, ptr } %t622, 1
  %t624 = call ptr @__olang_region_or(ptr %t623, ptr null)
  %t625 = icmp ne ptr %t624, null
  %t626 = select i1 %t625, ptr %t624, ptr null
  call void @__olang_region_settle_in(ptr %t621, ptr %t626)
  br label %bb110
bb113:
  %t627 = load { i64, ptr }, ptr %l275
  %t628 = extractvalue { i64, ptr } %t627, 1
  call void @__olang_region_release(ptr %t628)
  store { i64, ptr } zeroinitializer, ptr %l275
  br label %bb114
bb114:
  call void @__olang_scope_close(ptr %s24)
  br label %bb115
bb115:
  %t629 = load i1, ptr %l33, !tbaa !21
  br i1 %t629, label %bb116, label %bb117
bb116:
  %t631 = load i1, ptr %l34, !tbaa !21
  br i1 %t631, label %bb118, label %bb119
bb117:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d97, i32 0, i32 1) }, ptr %l278, !tbaa !27
  br label %bb122
bb118:
  %t633 = load ptr, ptr %l8, !tbaa !29
  %t634 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t635 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t636 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d98, i32 0, i32 1) }, 1
  %t637 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d98, i32 0, i32 1) }, 0
  %t639 = extractvalue { i64, ptr } %t634, 1
  %t640 = extractvalue { i64, ptr } %t634, 0
  %t641 = add i64 %t637, %t640
  %t642 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d99, i32 0, i32 1) }, 1
  %t643 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d99, i32 0, i32 1) }, 0
  %t644 = add i64 %t641, %t643
  %t646 = extractvalue { i64, ptr } %t635, 1
  %t647 = extractvalue { i64, ptr } %t635, 0
  %t648 = add i64 %t644, %t647
  %t649 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d100, i32 0, i32 1) }, 1
  %t650 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d100, i32 0, i32 1) }, 0
  %t651 = add i64 %t648, %t650
  %t652 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t651)
  call void @olang_textcopy(ptr %t652, ptr %t636, i64 %t637)
  %t653 = getelementptr i8, ptr %t652, i64 %t637
  call void @olang_textcopy(ptr %t653, ptr %t639, i64 %t640)
  %t654 = getelementptr i8, ptr %t653, i64 %t640
  call void @olang_textcopy(ptr %t654, ptr %t642, i64 %t643)
  %t655 = getelementptr i8, ptr %t654, i64 %t643
  call void @olang_textcopy(ptr %t655, ptr %t646, i64 %t647)
  %t656 = getelementptr i8, ptr %t655, i64 %t647
  call void @olang_textcopy(ptr %t656, ptr %t649, i64 %t650)
  %t657 = insertvalue { i64, ptr } undef, i64 %t651, 0
  %t658 = insertvalue { i64, ptr } %t657, ptr %t652, 1
  %t662 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %s0, ptr %s22, ptr %s22, ptr %v0, ptr %t633, { i64, ptr } %t658)
  store { i64, ptr } %t662, ptr %l286
  br label %bb120
bb119:
  %t663 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t665 = extractvalue { i64, ptr } %t663, 0
  %t666 = extractvalue { i64, ptr } %t663, 1
  %t667 = mul i64 %t665, 1
  %t668 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t667)
  call void @llvm.memcpy.p0.p0.i64(ptr %t668, ptr %t666, i64 %t667, i1 false)
  %t669 = insertvalue { i64, ptr } undef, i64 %t665, 0
  %t670 = insertvalue { i64, ptr } %t669, ptr %t668, 1
  store { i64, ptr } %t670, ptr %l280, !tbaa !27
  br label %bb121
bb120:
  %t672 = load { i64, ptr }, ptr %l286, !tbaa !27
  store { i64, ptr } %t672, ptr %l280, !tbaa !27
  br label %bb121
bb121:
  %t674 = load { i64, ptr }, ptr %l280, !tbaa !27
  store { i64, ptr } %t674, ptr %l278, !tbaa !27
  br label %bb122
bb122:
  %t675 = load { i64, ptr }, ptr %l278, !tbaa !27
  store { i64, ptr } %t675, ptr %l36, !tbaa !27
  %t676 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t678 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s22, { i64, ptr } %t676, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d101, i32 0, i32 1) })
  store i1 %t678, ptr %l291
  br label %bb123
bb123:
  %t679 = load i1, ptr %l291, !tbaa !21
  br i1 %t679, label %bb124, label %bb125
bb124:
  store %olang.scope zeroinitializer, ptr %s27
  %t680 = load ptr, ptr %l8, !tbaa !29
  %t681 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t682 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d102, i32 0, i32 1) }, 1
  %t683 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d102, i32 0, i32 1) }, 0
  %t685 = extractvalue { i64, ptr } %t681, 1
  %t686 = extractvalue { i64, ptr } %t681, 0
  %t687 = add i64 %t683, %t686
  %t688 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t687)
  call void @olang_textcopy(ptr %t688, ptr %t682, i64 %t683)
  %t689 = getelementptr i8, ptr %t688, i64 %t683
  call void @olang_textcopy(ptr %t689, ptr %t685, i64 %t686)
  %t690 = insertvalue { i64, ptr } undef, i64 %t687, 0
  %t691 = insertvalue { i64, ptr } %t690, ptr %t688, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %s0, ptr %s27, ptr %v0, ptr %t680, { i64, ptr } %t691)
  br label %bb126
bb125:
  store %olang.scope zeroinitializer, ptr %s29
  %t695 = load ptr, ptr %l3, !tbaa !29
  %t696 = load i32, ptr %l31, !tbaa !23
  %t699 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s29, ptr %t695, i32 %t696)
  store { i64, ptr } %t699, ptr %l298
  br label %bb127
bb126:
  call void @__olang_scope_close(ptr %s27)
  br label %bb137
bb127:
  %t700 = load { i64, ptr }, ptr %l298, !tbaa !27
  %t701 = extractvalue { i64, ptr } %t700, 0
  %t703 = icmp eq i64 %t701, 0
  br i1 %t703, label %bb128, label %bb129
bb128:
  store %olang.scope zeroinitializer, ptr %s30
  %t705 = load ptr, ptr %l8, !tbaa !29
  %t706 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t707 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t708 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d103, i32 0, i32 1) }, 1
  %t709 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d103, i32 0, i32 1) }, 0
  %t711 = extractvalue { i64, ptr } %t706, 1
  %t712 = extractvalue { i64, ptr } %t706, 0
  %t713 = add i64 %t709, %t712
  %t714 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d104, i32 0, i32 1) }, 1
  %t715 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d104, i32 0, i32 1) }, 0
  %t716 = add i64 %t713, %t715
  %t718 = extractvalue { i64, ptr } %t707, 1
  %t719 = extractvalue { i64, ptr } %t707, 0
  %t720 = add i64 %t716, %t719
  %t721 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t720)
  call void @olang_textcopy(ptr %t721, ptr %t708, i64 %t709)
  %t722 = getelementptr i8, ptr %t721, i64 %t709
  call void @olang_textcopy(ptr %t722, ptr %t711, i64 %t712)
  %t723 = getelementptr i8, ptr %t722, i64 %t712
  call void @olang_textcopy(ptr %t723, ptr %t714, i64 %t715)
  %t724 = getelementptr i8, ptr %t723, i64 %t715
  call void @olang_textcopy(ptr %t724, ptr %t718, i64 %t719)
  %t725 = insertvalue { i64, ptr } undef, i64 %t720, 0
  %t726 = insertvalue { i64, ptr } %t725, ptr %t721, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %s0, ptr %s30, ptr %v0, ptr %t705, { i64, ptr } %t726)
  br label %bb130
bb129:
  store %olang.scope zeroinitializer, ptr %s32
  %t730 = load ptr, ptr %l8, !tbaa !29
  %t731 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t732 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t733 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d105, i32 0, i32 1) }, 1
  %t734 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d105, i32 0, i32 1) }, 0
  %t736 = extractvalue { i64, ptr } %t731, 1
  %t737 = extractvalue { i64, ptr } %t731, 0
  %t738 = add i64 %t734, %t737
  %t739 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d106, i32 0, i32 1) }, 1
  %t740 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d106, i32 0, i32 1) }, 0
  %t741 = add i64 %t738, %t740
  %t743 = extractvalue { i64, ptr } %t732, 1
  %t744 = extractvalue { i64, ptr } %t732, 0
  %t745 = add i64 %t741, %t744
  %t746 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d107, i32 0, i32 1) }, 1
  %t747 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d107, i32 0, i32 1) }, 0
  %t748 = add i64 %t745, %t747
  %t749 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t748)
  call void @olang_textcopy(ptr %t749, ptr %t733, i64 %t734)
  %t750 = getelementptr i8, ptr %t749, i64 %t734
  call void @olang_textcopy(ptr %t750, ptr %t736, i64 %t737)
  %t751 = getelementptr i8, ptr %t750, i64 %t737
  call void @olang_textcopy(ptr %t751, ptr %t739, i64 %t740)
  %t752 = getelementptr i8, ptr %t751, i64 %t740
  call void @olang_textcopy(ptr %t752, ptr %t743, i64 %t744)
  %t753 = getelementptr i8, ptr %t752, i64 %t744
  call void @olang_textcopy(ptr %t753, ptr %t746, i64 %t747)
  %t754 = insertvalue { i64, ptr } undef, i64 %t748, 0
  %t755 = insertvalue { i64, ptr } %t754, ptr %t749, 1
  %t759 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %s0, ptr %s32, ptr %s32, ptr %v0, ptr %t730, { i64, ptr } %t755)
  store { i64, ptr } %t759, ptr %l311
  br label %bb131
bb130:
  call void @__olang_scope_close(ptr %s30)
  br label %bb136
bb131:
  %t760 = load { i64, ptr }, ptr %l311, !tbaa !27
  %t761 = load ptr, ptr %l8, !tbaa !29
  store ptr %t761, ptr %l312, !tbaa !29
  %t762 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t762, ptr %l313, !tbaa !27
  %t763 = load ptr, ptr %l8, !tbaa !29
  store ptr %t763, ptr %l314, !tbaa !29
  %t764 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t764, ptr %l315, !tbaa !27
  store { i64, ptr } %t760, ptr %l316, !tbaa !27
  %t766 = load ptr, ptr %l0, !tbaa !29
  store ptr %t766, ptr %l317, !tbaa !29
  %t767 = load ptr, ptr %l3, !tbaa !29
  %t768 = load i32, ptr %l2, !tbaa !23
  %t771 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t767, i32 %t768)
  store i32 %t771, ptr %l320
  br label %bb132
bb132:
  %t772 = load ptr, ptr %l317, !tbaa !29
  %t773 = load i32, ptr %l320, !tbaa !23
  %t774 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s32, ptr %t772, i32 %t773)
  store { i64, ptr } %t774, ptr %l321
  br label %bb133
bb133:
  %t775 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t776 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d108, i32 0, i32 1) }, 1
  %t777 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d108, i32 0, i32 1) }, 0
  %t778 = load { i64, ptr }, ptr %l315, !tbaa !27
  %t779 = extractvalue { i64, ptr } %t778, 1
  %t780 = extractvalue { i64, ptr } %t778, 0
  %t781 = add i64 %t777, %t780
  %t782 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d109, i32 0, i32 1) }, 1
  %t783 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d109, i32 0, i32 1) }, 0
  %t784 = add i64 %t781, %t783
  %t785 = load { i64, ptr }, ptr %l316, !tbaa !27
  %t786 = extractvalue { i64, ptr } %t785, 1
  %t787 = extractvalue { i64, ptr } %t785, 0
  %t788 = add i64 %t784, %t787
  %t789 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d110, i32 0, i32 1) }, 1
  %t790 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d110, i32 0, i32 1) }, 0
  %t791 = add i64 %t788, %t790
  %t792 = load { i64, ptr }, ptr %l321, !tbaa !27
  %t793 = extractvalue { i64, ptr } %t792, 1
  %t794 = extractvalue { i64, ptr } %t792, 0
  %t795 = add i64 %t791, %t794
  %t796 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d109, i32 0, i32 1) }, 1
  %t797 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d109, i32 0, i32 1) }, 0
  %t798 = add i64 %t795, %t797
  %t800 = extractvalue { i64, ptr } %t775, 1
  %t801 = extractvalue { i64, ptr } %t775, 0
  %t802 = add i64 %t798, %t801
  %t803 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d111, i32 0, i32 1) }, 1
  %t804 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d111, i32 0, i32 1) }, 0
  %t805 = add i64 %t802, %t804
  %t806 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t805)
  call void @olang_textcopy(ptr %t806, ptr %t776, i64 %t777)
  %t807 = getelementptr i8, ptr %t806, i64 %t777
  call void @olang_textcopy(ptr %t807, ptr %t779, i64 %t780)
  %t808 = getelementptr i8, ptr %t807, i64 %t780
  call void @olang_textcopy(ptr %t808, ptr %t782, i64 %t783)
  %t809 = getelementptr i8, ptr %t808, i64 %t783
  call void @olang_textcopy(ptr %t809, ptr %t786, i64 %t787)
  %t810 = getelementptr i8, ptr %t809, i64 %t787
  call void @olang_textcopy(ptr %t810, ptr %t789, i64 %t790)
  %t811 = getelementptr i8, ptr %t810, i64 %t790
  call void @olang_textcopy(ptr %t811, ptr %t793, i64 %t794)
  %t812 = getelementptr i8, ptr %t811, i64 %t794
  call void @olang_textcopy(ptr %t812, ptr %t796, i64 %t797)
  %t813 = getelementptr i8, ptr %t812, i64 %t797
  call void @olang_textcopy(ptr %t813, ptr %t800, i64 %t801)
  %t814 = getelementptr i8, ptr %t813, i64 %t801
  call void @olang_textcopy(ptr %t814, ptr %t803, i64 %t804)
  %t815 = insertvalue { i64, ptr } undef, i64 %t805, 0
  %t816 = insertvalue { i64, ptr } %t815, ptr %t806, 1
  %t818 = load ptr, ptr %l314, !tbaa !29
  %t820 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %s0, ptr %s32, ptr %s32, ptr %v0, ptr %t818, { i64, ptr } %t816)
  store { i64, ptr } %t820, ptr %l325
  br label %bb134
bb134:
  %t821 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d112, i32 0, i32 1) }, 1
  %t822 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d112, i32 0, i32 1) }, 0
  %t823 = load { i64, ptr }, ptr %l313, !tbaa !27
  %t824 = extractvalue { i64, ptr } %t823, 1
  %t825 = extractvalue { i64, ptr } %t823, 0
  %t826 = add i64 %t822, %t825
  %t827 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d113, i32 0, i32 1) }, 1
  %t828 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d113, i32 0, i32 1) }, 0
  %t829 = add i64 %t826, %t828
  %t830 = load { i64, ptr }, ptr %l325, !tbaa !27
  %t831 = extractvalue { i64, ptr } %t830, 1
  %t832 = extractvalue { i64, ptr } %t830, 0
  %t833 = add i64 %t829, %t832
  %t834 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t833)
  call void @olang_textcopy(ptr %t834, ptr %t821, i64 %t822)
  %t835 = getelementptr i8, ptr %t834, i64 %t822
  call void @olang_textcopy(ptr %t835, ptr %t824, i64 %t825)
  %t836 = getelementptr i8, ptr %t835, i64 %t825
  call void @olang_textcopy(ptr %t836, ptr %t827, i64 %t828)
  %t837 = getelementptr i8, ptr %t836, i64 %t828
  call void @olang_textcopy(ptr %t837, ptr %t831, i64 %t832)
  %t838 = insertvalue { i64, ptr } undef, i64 %t833, 0
  %t839 = insertvalue { i64, ptr } %t838, ptr %t834, 1
  %t841 = load ptr, ptr %l312, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %s0, ptr %s32, ptr %v0, ptr %t841, { i64, ptr } %t839)
  br label %bb135
bb135:
  call void @__olang_scope_close(ptr %s32)
  br label %bb136
bb136:
  call void @__olang_scope_close(ptr %s29)
  br label %bb137
bb137:
  call void @__olang_scope_close(ptr %s22)
  br label %bb138
bb138:
  %t843 = load ptr, ptr %l0, !tbaa !29
  store ptr %t843, ptr %l328, !tbaa !29
  %t844 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t845 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d114, i32 0, i32 1) }, 1
  %t846 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d114, i32 0, i32 1) }, 0
  %t848 = extractvalue { i64, ptr } %t844, 1
  %t849 = extractvalue { i64, ptr } %t844, 0
  %t850 = add i64 %t846, %t849
  %t851 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t850)
  call void @olang_textcopy(ptr %t851, ptr %t845, i64 %t846)
  %t852 = getelementptr i8, ptr %t851, i64 %t846
  call void @olang_textcopy(ptr %t852, ptr %t848, i64 %t849)
  %t853 = insertvalue { i64, ptr } undef, i64 %t850, 0
  %t854 = insertvalue { i64, ptr } %t853, ptr %t851, 1
  store { i64, ptr } %t854, ptr %l331, !tbaa !27
  %t856 = load i64, ptr @G_2ecompiler_2femit_2eHomeShared, !tbaa !24
  store i64 %t856, ptr %l332, !tbaa !24
  %t857 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t857, ptr %l333, !tbaa !27
  %t858 = load ptr, ptr %l8, !tbaa !29
  %t860 = getelementptr %"compiler/emit:fnEm", ptr %t858, i32 0, i32 5
  %t862 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %t860)
  store { i64, ptr } %t862, ptr %l336
  br label %bb139
bb139:
  %t863 = load { i64, ptr }, ptr %l333, !tbaa !27
  %t864 = extractvalue { i64, ptr } %t863, 1
  %t865 = extractvalue { i64, ptr } %t863, 0
  %t866 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d115, i32 0, i32 1) }, 1
  %t867 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d115, i32 0, i32 1) }, 0
  %t868 = add i64 %t865, %t867
  %t869 = load { i64, ptr }, ptr %l336, !tbaa !27
  %t870 = extractvalue { i64, ptr } %t869, 1
  %t871 = extractvalue { i64, ptr } %t869, 0
  %t872 = add i64 %t868, %t871
  %t873 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d116, i32 0, i32 1) }, 1
  %t874 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d116, i32 0, i32 1) }, 0
  %t875 = add i64 %t872, %t874
  %t876 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t875)
  call void @olang_textcopy(ptr %t876, ptr %t864, i64 %t865)
  %t877 = getelementptr i8, ptr %t876, i64 %t865
  call void @olang_textcopy(ptr %t877, ptr %t866, i64 %t867)
  %t878 = getelementptr i8, ptr %t877, i64 %t867
  call void @olang_textcopy(ptr %t878, ptr %t870, i64 %t871)
  %t879 = getelementptr i8, ptr %t878, i64 %t871
  call void @olang_textcopy(ptr %t879, ptr %t873, i64 %t874)
  %t880 = insertvalue { i64, ptr } undef, i64 %t875, 0
  %t881 = insertvalue { i64, ptr } %t880, ptr %t876, 1
  %t883 = load ptr, ptr %l328, !tbaa !29
  %t884 = load { i64, ptr }, ptr %l331, !tbaa !27
  %t885 = load i64, ptr %l332, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t883, { i64, ptr } %t884, i64 %t885, { i64, ptr } %t881, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d117, i32 0, i32 1) })
  br label %bb140
bb140:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenDrop(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l17 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l4
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l4
  store %"std/prelude/text:StringBuilder" %t2, ptr %l3
  %t4 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d118, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d118, i32 0, i32 1) }, 0
  %t7 = extractvalue { i64, ptr } %a1, 1
  %t8 = extractvalue { i64, ptr } %a1, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d119, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d119, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t7, i64 %t8)
  %t15 = getelementptr i8, ptr %t14, i64 %t8
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } %t17)
  br label %bb2
bb2:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d120, i32 0, i32 1) })
  br label %bb3
bb3:
  %t23 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d121, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d121, i32 0, i32 1) }, 0
  %t26 = extractvalue { i64, ptr } %a2, 1
  %t27 = extractvalue { i64, ptr } %a2, 0
  %t28 = add i64 %t24, %t27
  %t29 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d122, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d122, i32 0, i32 1) }, 0
  %t31 = add i64 %t28, %t30
  %t32 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t31)
  call void @olang_textcopy(ptr %t32, ptr %t23, i64 %t24)
  %t33 = getelementptr i8, ptr %t32, i64 %t24
  call void @olang_textcopy(ptr %t33, ptr %t26, i64 %t27)
  %t34 = getelementptr i8, ptr %t33, i64 %t27
  call void @olang_textcopy(ptr %t34, ptr %t29, i64 %t30)
  %t35 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t32, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } %t36)
  br label %bb4
bb4:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } { i64 104, ptr getelementptr inbounds (<{ i64, [104 x i8] }>, ptr @.d123, i32 0, i32 1) })
  br label %bb5
bb5:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d124, i32 0, i32 1) })
  br label %bb6
bb6:
  %t43 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v3, ptr %l3)
  store { i64, ptr } %t43, ptr %l17
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t44 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t44, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2einstGroups(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca i64
  %l39 = alloca i64
  %l48 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l50 = alloca i64
  %l54 = alloca i64
  %l57 = alloca i64
  %l86 = alloca i64
  %l92 = alloca i64
  %l98 = alloca i64
  %l102 = alloca i64
  %l105 = alloca i64
  %l125 = alloca i64
  %l132 = alloca i64
  %l135 = alloca i1
  %l136 = alloca i64
  %l138 = alloca i64
  %l149 = alloca i64
  %l151 = alloca i64
  %l156 = alloca i64
  %l157 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l158 = alloca i64
  %l162 = alloca i64
  %l163 = alloca i32
  %l169 = alloca %"compiler/emit:Reused"
  %l171 = alloca %"compiler/emit:Reused"
  %l173 = alloca i64
  %l175 = alloca i64
  %l180 = alloca { i64, ptr }
  %l181 = alloca i64
  %l185 = alloca i64
  %l186 = alloca i32
  %l189 = alloca i1
  %l193 = alloca i64
  %l196 = alloca i1
  %l200 = alloca i1
  %l226 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l229 = alloca i64
  %l233 = alloca i64
  %l236 = alloca i64
  %l257 = alloca i64
  %l263 = alloca i1
  %l269 = alloca ptr
  %l270 = alloca i64
  %l274 = alloca i64
  %l275 = alloca i32
  %l281 = alloca i64
  %l283 = alloca i64
  %l288 = alloca i64
  %l291 = alloca i1
  %l293 = alloca ptr
  %l294 = alloca i64
  %l297 = alloca i64
  %s0 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %t103 = alloca i64
  %t128 = alloca i64
  %t288 = alloca %"compiler/emit:Reused", align 8
  %t298 = alloca %"compiler/emit:Reused", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 10
  store ptr %t9, ptr %l1, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/emit:Emitter", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/load:Loader", ptr %t17, i32 0, i32 12
  %t20 = load i64, ptr %t19, !tbaa !24
  store i64 %t20, ptr %l2, !tbaa !24
  %t22 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l48
  br label %bb1
bb1:
  %t23 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l48
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t24)
  store i64 %t26, ptr %l50
  br label %bb2
bb2:
  %t27 = load i64, ptr %l50, !tbaa !24
  store i64 %t27, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t28 = load i64, ptr %l5, !tbaa !24
  %t29 = load i64, ptr %l4, !tbaa !24
  %t32 = icmp sgt i64 %t28, %t29
  br i1 %t32, label %bb3, label %bb4
bb3:
  %t34 = load i64, ptr %l6, !tbaa !24
  %t36 = icmp sgt i64 %t34, 0
  br i1 %t36, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb8
bb5:
  %t38 = load i64, ptr %l5, !tbaa !24
  %t39 = load i64, ptr %l4, !tbaa !24
  %t42 = sub i64 %t38, %t39
  %t43 = load i64, ptr %l6, !tbaa !24
  %t46 = add i64 %t42, %t43
  %t48 = sub i64 %t46, 1
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = sdiv i64 %t48, %t49
  store i64 %t52, ptr %l57, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb7
bb7:
  %t54 = load i64, ptr %l57, !tbaa !24
  store i64 %t54, ptr %l54, !tbaa !24
  br label %bb8
bb8:
  %t55 = load i64, ptr %l54, !tbaa !24
  store i64 %t55, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  %t56 = load i64, ptr %l8, !tbaa !24
  %t57 = load i64, ptr %l7, !tbaa !24
  %t60 = icmp slt i64 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb10, label %bb11
bb10:
  br label %bb18
bb11:
  br label %bb12
bb12:
  %t64 = load i64, ptr %l4, !tbaa !24
  %t65 = load i64, ptr %l8, !tbaa !24
  %t66 = load i64, ptr %l6, !tbaa !24
  %t69 = mul i64 %t65, %t66
  %t72 = add i64 %t64, %t69
  store i64 %t72, ptr %l9, !tbaa !24
  %t74 = load i64, ptr %l9, !tbaa !24
  %t75 = load i64, ptr %l2, !tbaa !24
  %t78 = icmp ne i64 %t74, %t75
  br i1 %t78, label %bb13, label %bb14
bb13:
  %t80 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t80)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t83 = load i64, ptr %l8, !tbaa !24
  %t86 = add i64 %t83, 1
  store i64 %t86, ptr %l8, !tbaa !24
  br label %bb9
bb18:
  %t88 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t88)
  br label %bb19
bb19:
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t93 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t91)
  store i64 %t93, ptr %l86
  br label %bb20
bb20:
  %t94 = load i64, ptr %l86, !tbaa !24
  %t95 = icmp sge i64 %t94, 0
  br i1 %t95, label %bb21, label %bb22
bb21:
  %t97 = load i64, ptr %l86, !tbaa !24
  %t98 = icmp sle i64 %t97, 1152921504606846975
  br i1 %t98, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_5ff468ede8d2dad5_ce6794a5e99bfc39)
  unreachable
bb23:
  %t100 = load i64, ptr %l86, !tbaa !24
  %t101 = mul i64 %t100, 8
  %t102 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t101)
  store i64 0, ptr %t103
  br label %fill.104
fill.104:
  %t107 = load i64, ptr %t103
  %t108 = icmp slt i64 %t107, %t100
  br i1 %t108, label %fillb.105, label %filld.106
fillb.105:
  %t109 = getelementptr i64, ptr %t102, i64 %t107
  store i64 -1, ptr %t109
  %t110 = add i64 %t107, 1
  store i64 %t110, ptr %t103
  br label %fill.104
filld.106:
  %t111 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t102, 1
  store { i64, ptr } %t112, ptr %l10, !tbaa !27
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/emit:Emitter", ptr %t114, i32 0, i32 22
  %t118 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t116)
  store i64 %t118, ptr %l92
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_5ff468ede8d2dad5_ce6794a5e99bfc39)
  unreachable
bb25:
  %t119 = load i64, ptr %l92, !tbaa !24
  %t120 = icmp sge i64 %t119, 0
  br i1 %t120, label %bb26, label %bb27
bb26:
  %t122 = load i64, ptr %l92, !tbaa !24
  %t123 = icmp sle i64 %t122, 1152921504606846975
  br i1 %t123, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_fd5758dba8282ae8_cbed788f914882ac)
  unreachable
bb28:
  %t125 = load i64, ptr %l92, !tbaa !24
  %t126 = mul i64 %t125, 8
  %t127 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t126)
  store i64 0, ptr %t128
  br label %fill.129
fill.129:
  %t132 = load i64, ptr %t128
  %t133 = icmp slt i64 %t132, %t125
  br i1 %t133, label %fillb.130, label %filld.131
fillb.130:
  %t134 = getelementptr i64, ptr %t127, i64 %t132
  store i64 -1, ptr %t134
  %t135 = add i64 %t132, 1
  store i64 %t135, ptr %t128
  br label %fill.129
filld.131:
  %t136 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t127, 1
  store { i64, ptr } %t137, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/emit:Emitter", ptr %t139, i32 0, i32 22
  %t143 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t141)
  store i64 %t143, ptr %l98
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_fd5758dba8282ae8_cbed788f914882ac)
  unreachable
bb30:
  %t144 = load i64, ptr %l98, !tbaa !24
  store i64 %t144, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t145 = load i64, ptr %l13, !tbaa !24
  %t146 = load i64, ptr %l12, !tbaa !24
  %t149 = icmp sgt i64 %t145, %t146
  br i1 %t149, label %bb31, label %bb32
bb31:
  %t151 = load i64, ptr %l14, !tbaa !24
  %t153 = icmp sgt i64 %t151, 0
  br i1 %t153, label %bb33, label %bb34
bb32:
  store i64 0, ptr %l102, !tbaa !24
  br label %bb36
bb33:
  %t155 = load i64, ptr %l13, !tbaa !24
  %t156 = load i64, ptr %l12, !tbaa !24
  %t159 = sub i64 %t155, %t156
  %t160 = load i64, ptr %l14, !tbaa !24
  %t163 = add i64 %t159, %t160
  %t165 = sub i64 %t163, 1
  %t166 = load i64, ptr %l14, !tbaa !24
  %t169 = sdiv i64 %t165, %t166
  store i64 %t169, ptr %l105, !tbaa !24
  br label %bb35
bb34:
  store i64 0, ptr %l105, !tbaa !24
  br label %bb35
bb35:
  %t171 = load i64, ptr %l105, !tbaa !24
  store i64 %t171, ptr %l102, !tbaa !24
  br label %bb36
bb36:
  %t172 = load i64, ptr %l102, !tbaa !24
  store i64 %t172, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb37
bb37:
  %t173 = load i64, ptr %l16, !tbaa !24
  %t174 = load i64, ptr %l15, !tbaa !24
  %t177 = icmp slt i64 %t173, %t174
  %t179 = xor i1 %t177, true
  br i1 %t179, label %bb38, label %bb39
bb38:
  br label %bb51
bb39:
  br label %bb40
bb40:
  %t181 = load i64, ptr %l12, !tbaa !24
  %t182 = load i64, ptr %l16, !tbaa !24
  %t183 = load i64, ptr %l14, !tbaa !24
  %t186 = mul i64 %t182, %t183
  %t189 = add i64 %t181, %t186
  store i64 %t189, ptr %l17, !tbaa !24
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/emit:Emitter", ptr %t191, i32 0, i32 22
  %t195 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t193)
  store i64 %t195, ptr %l125
  br label %bb41
bb41:
  %t196 = load i64, ptr %l125, !tbaa !24
  %t197 = sub i64 %t196, 1
  %t198 = load i64, ptr %l17, !tbaa !24
  %t201 = sub i64 %t197, %t198
  store i64 %t201, ptr %l18, !tbaa !24
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/emit:Emitter", ptr %t203, i32 0, i32 24
  %t206 = load i64, ptr %l18, !tbaa !24
  %t209 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t205, i64 %t206)
  store i64 %t209, ptr %l132
  br label %bb42
bb42:
  %t210 = load i64, ptr %l132, !tbaa !24
  store i64 %t210, ptr %l19, !tbaa !24
  %t211 = load i64, ptr %l19, !tbaa !24
  %t213 = icmp sge i64 %t211, 0
  br i1 %t213, label %bb43, label %bb44
bb43:
  %t215 = load i64, ptr %l19, !tbaa !24
  store i64 %t215, ptr %l136, !tbaa !24
  %t216 = load ptr, ptr %l1, !tbaa !29
  %t218 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t216)
  store i64 %t218, ptr %l138
  br label %bb45
bb44:
  store i1 false, ptr %l135, !tbaa !21
  br label %bb46
bb45:
  %t219 = load i64, ptr %l136, !tbaa !24
  %t220 = load i64, ptr %l138, !tbaa !24
  %t221 = icmp slt i64 %t219, %t220
  store i1 %t221, ptr %l135, !tbaa !21
  br label %bb46
bb46:
  %t223 = load i1, ptr %l135, !tbaa !21
  br i1 %t223, label %bb47, label %bb48
bb47:
  %t224 = load i64, ptr %l18, !tbaa !24
  %t225 = load i64, ptr %l19, !tbaa !24
  %t227 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t228 = load ptr, ptr %t227, !tbaa !27
  %t229 = getelementptr i64, ptr %t228, i64 %t225
  %t230 = load i64, ptr %t229, !tbaa !34
  %t233 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !27
  %t235 = getelementptr i64, ptr %t234, i64 %t224
  store i64 %t230, ptr %t235, !tbaa !34
  %t236 = load i64, ptr %l19, !tbaa !24
  %t237 = load i64, ptr %l18, !tbaa !24
  %t240 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !27
  %t242 = getelementptr i64, ptr %t241, i64 %t236
  store i64 %t237, ptr %t242, !tbaa !34
  br label %bb49
bb48:
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t243 = load i64, ptr %l16, !tbaa !24
  %t246 = add i64 %t243, 1
  store i64 %t246, ptr %l16, !tbaa !24
  br label %bb37
bb51:
  store ptr %l3, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb52
bb52:
  store %olang.scope zeroinitializer, ptr %s10
  %t249 = load i64, ptr %l21, !tbaa !24
  store i64 %t249, ptr %l149, !tbaa !24
  %t250 = load ptr, ptr %l20, !tbaa !29
  %t252 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t250)
  store i64 %t252, ptr %l151
  br label %bb53
bb53:
  %t253 = load i64, ptr %l149, !tbaa !24
  %t254 = load i64, ptr %l151, !tbaa !24
  %t255 = icmp slt i64 %t253, %t254
  %t257 = xor i1 %t255, true
  br i1 %t257, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s10)
  br label %bb102
bb55:
  br label %bb56
bb56:
  %t259 = load ptr, ptr %l20, !tbaa !29
  %t260 = load i64, ptr %l21, !tbaa !24
  %t263 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t259, i64 %t260)
  store i64 %t263, ptr %l156
  br label %bb57
bb57:
  %t264 = load i64, ptr %l156, !tbaa !24
  store i64 %t264, ptr %l22, !tbaa !24
  %t265 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s10, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t265, ptr %l157
  br label %bb58
bb58:
  %t266 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l157
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t266, ptr %l23
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/emit:Emitter", ptr %t267, i32 0, i32 89
  %t270 = load i64, ptr %l22, !tbaa !24
  %t273 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t269, i64 %t270)
  %t274 = extractvalue { i32, i64 } %t273, 1
  %t275 = extractvalue { i32, i64 } %t273, 0
  store i32 %t275, ptr %l163
  %t276 = icmp ne i32 %t275, 0
  br i1 %t276, label %bb60, label %ok.277, !prof !99
ok.277:
  store i64 %t274, ptr %l162
  br label %bb59
bb59:
  %t278 = load i64, ptr %l162, !tbaa !24
  store i64 %t278, ptr %l158, !tbaa !24
  br label %bb62
bb60:
  br label %bb61
bb61:
  store i64 -1, ptr %l158, !tbaa !24
  br label %bb62
bb62:
  %t279 = load i64, ptr %l158, !tbaa !24
  store i64 %t279, ptr %l24, !tbaa !24
  %t280 = load i64, ptr %l24, !tbaa !24
  %t282 = icmp sge i64 %t280, 0
  br i1 %t282, label %bb63, label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s12
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t286 = getelementptr %"compiler/emit:Emitter", ptr %t284, i32 0, i32 88
  %t287 = load i64, ptr %l24, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aReused_3e_2eAt_3ccompiler_2femit_3aReused_3e(ptr %t288, ptr %v0, ptr %v0, ptr %t286, i64 %t287)
  call void @llvm.memmove.p0.p0.i64(ptr %l169, ptr %t288, i64 192, i1 false)
  br label %bb65
bb64:
  %t291 = load i64, ptr %l22, !tbaa !24
  %t293 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t294 = load ptr, ptr %t293, !tbaa !27
  %t295 = getelementptr i64, ptr %t294, i64 %t291
  %t296 = load i64, ptr %t295, !tbaa !34
  store i64 %t296, ptr %l29, !tbaa !24
  br label %bb92
bb65:
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2femit_3aReused(ptr %t298, ptr %v0, ptr %l169)
  call void @llvm.memmove.p0.p0.i64(ptr %l171, ptr %t298, i64 192, i1 false)
  br label %bb66
bb66:
  %t300 = getelementptr %"compiler/emit:Reused", ptr %l171, i32 0, i32 7
  store ptr %t300, ptr %l25, !tbaa !29
  store i64 0, ptr %l26, !tbaa !24
  br label %bb67
bb67:
  %t302 = load i64, ptr %l26, !tbaa !24
  store i64 %t302, ptr %l173, !tbaa !24
  %t303 = load ptr, ptr %l25, !tbaa !29
  %t305 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s12, ptr %t303)
  store i64 %t305, ptr %l175
  br label %bb68
bb68:
  %t306 = load i64, ptr %l173, !tbaa !24
  %t307 = load i64, ptr %l175, !tbaa !24
  %t308 = icmp slt i64 %t306, %t307
  %t310 = xor i1 %t308, true
  br i1 %t310, label %bb69, label %bb70
bb69:
  br label %bb91
bb70:
  br label %bb71
bb71:
  %t312 = load ptr, ptr %l25, !tbaa !29
  %t313 = load i64, ptr %l26, !tbaa !24
  %t316 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s12, ptr %s12, ptr %t312, i64 %t313)
  store { i64, ptr } %t316, ptr %l180
  br label %bb72
bb72:
  %t317 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t320 = getelementptr %"compiler/emit:Emitter", ptr %t318, i32 0, i32 26
  %t324 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %s12, ptr %t320, { i64, ptr } %t317)
  %t325 = extractvalue { i32, i64 } %t324, 1
  %t326 = extractvalue { i32, i64 } %t324, 0
  store i32 %t326, ptr %l186
  %t327 = icmp ne i32 %t326, 0
  br i1 %t327, label %bb74, label %ok.328, !prof !99
ok.328:
  store i64 %t325, ptr %l185
  br label %bb73
bb73:
  %t329 = load i64, ptr %l185, !tbaa !24
  store i64 %t329, ptr %l181, !tbaa !24
  br label %bb76
bb74:
  br label %bb75
bb75:
  store i64 -1, ptr %l181, !tbaa !24
  br label %bb76
bb76:
  %t330 = load i64, ptr %l181, !tbaa !24
  store i64 %t330, ptr %l28, !tbaa !24
  %t331 = load i64, ptr %l28, !tbaa !24
  %t333 = icmp sge i64 %t331, 0
  br i1 %t333, label %bb77, label %bb78
bb77:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t337 = getelementptr %"compiler/emit:Emitter", ptr %t335, i32 0, i32 24
  %t338 = load i64, ptr %l28, !tbaa !24
  %t341 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t337, i64 %t338)
  store i64 %t341, ptr %l193
  br label %bb79
bb78:
  store i1 false, ptr %l189, !tbaa !21
  br label %bb80
bb79:
  %t342 = load i64, ptr @G_2ecompiler_2femit_2eHomeInst, !tbaa !24
  %t343 = load i64, ptr %l193, !tbaa !24
  %t345 = icmp eq i64 %t343, %t342
  store i1 %t345, ptr %l189, !tbaa !21
  br label %bb80
bb80:
  %t347 = load i1, ptr %l189, !tbaa !21
  br i1 %t347, label %bb81, label %bb82
bb81:
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t350 = getelementptr %"compiler/emit:Emitter", ptr %t348, i32 0, i32 99
  %t351 = load i64, ptr %l28, !tbaa !24
  %t354 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t350, i64 %t351)
  store i1 %t354, ptr %l200
  br label %bb83
bb82:
  store i1 false, ptr %l196, !tbaa !21
  br label %bb84
bb83:
  %t355 = load i1, ptr %l200, !tbaa !21
  %t356 = xor i1 %t355, true
  store i1 %t356, ptr %l196, !tbaa !21
  br label %bb84
bb84:
  %t358 = load i1, ptr %l196, !tbaa !21
  br i1 %t358, label %bb85, label %bb86
bb85:
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t361 = getelementptr %"compiler/emit:Emitter", ptr %t359, i32 0, i32 99
  %t362 = load i64, ptr %l28, !tbaa !24
  %t363 = load i64, ptr %l22, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t361, i64 %t362, i64 %t363)
  br label %bb87
bb86:
  br label %bb89
bb87:
  %t367 = load i64, ptr %l28, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s10, ptr %l23, i64 %t367)
  br label %bb88
bb88:
  br label %bb89
bb89:
  br label %bb90
bb90:
  %t370 = load i64, ptr %l26, !tbaa !24
  %t373 = add i64 %t370, 1
  store i64 %t373, ptr %l26, !tbaa !24
  br label %bb67
bb91:
  call void @__olang_scope_close(ptr %s12)
  br label %bb99
bb92:
  %t375 = load i64, ptr %l29, !tbaa !24
  %t377 = icmp sge i64 %t375, 0
  %t379 = xor i1 %t377, true
  br i1 %t379, label %bb93, label %bb94
bb93:
  br label %bb98
bb94:
  br label %bb95
bb95:
  %t381 = load i64, ptr %l29, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s10, ptr %l23, i64 %t381)
  br label %bb96
bb96:
  br label %bb97
bb97:
  %t384 = load i64, ptr %l29, !tbaa !24
  %t386 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t387 = load ptr, ptr %t386, !tbaa !27
  %t388 = getelementptr i64, ptr %t387, i64 %t384
  %t389 = load i64, ptr %t388, !tbaa !34
  store i64 %t389, ptr %l29, !tbaa !24
  br label %bb92
bb98:
  br label %bb99
bb99:
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t392 = load i64, ptr %l22, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2egroupReached(ptr %v0, ptr %s10, ptr %t391, i64 %t392, ptr %l23)
  br label %bb100
bb100:
  call void @__olang_scope_close(ptr %s10)
  br label %bb101
bb101:
  %t396 = load i64, ptr %l21, !tbaa !24
  %t399 = add i64 %t396, 1
  store i64 %t399, ptr %l21, !tbaa !24
  br label %bb52
bb102:
  %t401 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t401, ptr %l226
  br label %bb103
bb103:
  %t402 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l226
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t402, ptr %l30
  store i64 0, ptr %l31, !tbaa !24
  %t403 = load ptr, ptr %l0, !tbaa !29
  %t405 = getelementptr %"compiler/emit:Emitter", ptr %t403, i32 0, i32 22
  %t407 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t405)
  store i64 %t407, ptr %l229
  br label %bb104
bb104:
  %t408 = load i64, ptr %l229, !tbaa !24
  store i64 %t408, ptr %l32, !tbaa !24
  store i64 1, ptr %l33, !tbaa !24
  %t409 = load i64, ptr %l32, !tbaa !24
  %t410 = load i64, ptr %l31, !tbaa !24
  %t413 = icmp sgt i64 %t409, %t410
  br i1 %t413, label %bb105, label %bb106
bb105:
  %t415 = load i64, ptr %l33, !tbaa !24
  %t417 = icmp sgt i64 %t415, 0
  br i1 %t417, label %bb107, label %bb108
bb106:
  store i64 0, ptr %l233, !tbaa !24
  br label %bb110
bb107:
  %t419 = load i64, ptr %l32, !tbaa !24
  %t420 = load i64, ptr %l31, !tbaa !24
  %t423 = sub i64 %t419, %t420
  %t424 = load i64, ptr %l33, !tbaa !24
  %t427 = add i64 %t423, %t424
  %t429 = sub i64 %t427, 1
  %t430 = load i64, ptr %l33, !tbaa !24
  %t433 = sdiv i64 %t429, %t430
  store i64 %t433, ptr %l236, !tbaa !24
  br label %bb109
bb108:
  store i64 0, ptr %l236, !tbaa !24
  br label %bb109
bb109:
  %t435 = load i64, ptr %l236, !tbaa !24
  store i64 %t435, ptr %l233, !tbaa !24
  br label %bb110
bb110:
  %t436 = load i64, ptr %l233, !tbaa !24
  store i64 %t436, ptr %l34, !tbaa !24
  store i64 0, ptr %l35, !tbaa !24
  br label %bb111
bb111:
  %t437 = load i64, ptr %l35, !tbaa !24
  %t438 = load i64, ptr %l34, !tbaa !24
  %t441 = icmp slt i64 %t437, %t438
  %t443 = xor i1 %t441, true
  br i1 %t443, label %bb112, label %bb113
bb112:
  br label %bb130
bb113:
  br label %bb114
bb114:
  %t445 = load i64, ptr %l31, !tbaa !24
  %t446 = load i64, ptr %l35, !tbaa !24
  %t447 = load i64, ptr %l33, !tbaa !24
  %t450 = mul i64 %t446, %t447
  %t453 = add i64 %t445, %t450
  store i64 %t453, ptr %l36, !tbaa !24
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t457 = getelementptr %"compiler/emit:Emitter", ptr %t455, i32 0, i32 24
  %t458 = load i64, ptr %l36, !tbaa !24
  %t461 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t457, i64 %t458)
  store i64 %t461, ptr %l257
  br label %bb115
bb115:
  %t462 = load i64, ptr @G_2ecompiler_2femit_2eHomeInst, !tbaa !24
  %t463 = load i64, ptr %l257, !tbaa !24
  %t465 = icmp ne i64 %t463, %t462
  br i1 %t465, label %bb116, label %bb117
bb116:
  br label %bb129
bb117:
  br label %bb118
bb118:
  %t467 = load ptr, ptr %l0, !tbaa !29
  %t469 = getelementptr %"compiler/emit:Emitter", ptr %t467, i32 0, i32 99
  %t470 = load i64, ptr %l36, !tbaa !24
  %t473 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t469, i64 %t470)
  store i1 %t473, ptr %l263
  br label %bb119
bb119:
  %t474 = load i1, ptr %l263, !tbaa !21
  %t475 = xor i1 %t474, true
  br i1 %t475, label %bb120, label %bb121
bb120:
  %t477 = load ptr, ptr %l0, !tbaa !29
  %t479 = getelementptr %"compiler/emit:Emitter", ptr %t477, i32 0, i32 99
  %t480 = load i64, ptr %l36, !tbaa !24
  %t481 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t479, i64 %t480, i64 %t481)
  br label %bb122
bb121:
  br label %bb123
bb122:
  br label %bb123
bb123:
  store ptr %l30, ptr %l269, !tbaa !29
  %t485 = load ptr, ptr %l0, !tbaa !29
  %t487 = getelementptr %"compiler/emit:Emitter", ptr %t485, i32 0, i32 99
  %t488 = load i64, ptr %l36, !tbaa !24
  %t491 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t487, i64 %t488)
  %t492 = extractvalue { i32, i64 } %t491, 1
  %t493 = extractvalue { i32, i64 } %t491, 0
  store i32 %t493, ptr %l275
  %t494 = icmp ne i32 %t493, 0
  br i1 %t494, label %bb125, label %ok.495, !prof !99
ok.495:
  store i64 %t492, ptr %l274
  br label %bb124
bb124:
  %t496 = load i64, ptr %l274, !tbaa !24
  store i64 %t496, ptr %l270, !tbaa !24
  br label %bb127
bb125:
  br label %bb126
bb126:
  %t497 = load i64, ptr %l2, !tbaa !24
  store i64 %t497, ptr %l270, !tbaa !24
  br label %bb127
bb127:
  %t499 = load ptr, ptr %l269, !tbaa !29
  %t500 = load i64, ptr %l270, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s0, ptr %t499, i64 %t500, i1 true)
  br label %bb128
bb128:
  br label %bb129
bb129:
  %t501 = load i64, ptr %l35, !tbaa !24
  %t504 = add i64 %t501, 1
  store i64 %t504, ptr %l35, !tbaa !24
  br label %bb111
bb130:
  store ptr %l3, ptr %l37, !tbaa !29
  store i64 0, ptr %l38, !tbaa !24
  br label %bb131
bb131:
  %t507 = load i64, ptr %l38, !tbaa !24
  store i64 %t507, ptr %l281, !tbaa !24
  %t508 = load ptr, ptr %l37, !tbaa !29
  %t510 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t508)
  store i64 %t510, ptr %l283
  br label %bb132
bb132:
  %t511 = load i64, ptr %l281, !tbaa !24
  %t512 = load i64, ptr %l283, !tbaa !24
  %t513 = icmp slt i64 %t511, %t512
  %t515 = xor i1 %t513, true
  br i1 %t515, label %bb133, label %bb134
bb133:
  br label %bb145
bb134:
  br label %bb135
bb135:
  %t517 = load ptr, ptr %l37, !tbaa !29
  %t518 = load i64, ptr %l38, !tbaa !24
  %t521 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t517, i64 %t518)
  store i64 %t521, ptr %l288
  br label %bb136
bb136:
  %t522 = load i64, ptr %l288, !tbaa !24
  store i64 %t522, ptr %l39, !tbaa !24
  %t523 = load i64, ptr %l39, !tbaa !24
  %t526 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %l30, i64 %t523)
  store i1 %t526, ptr %l291
  br label %bb137
bb137:
  %t527 = load i1, ptr %l291, !tbaa !21
  br i1 %t527, label %bb138, label %bb139
bb138:
  %t528 = load ptr, ptr %l0, !tbaa !29
  %t530 = getelementptr %"compiler/emit:Emitter", ptr %t528, i32 0, i32 101
  store ptr %t530, ptr %l293, !tbaa !29
  %t531 = load i64, ptr %l39, !tbaa !24
  store i64 %t531, ptr %l294, !tbaa !24
  %t532 = load ptr, ptr %l0, !tbaa !29
  %t534 = getelementptr %"compiler/emit:Emitter", ptr %t532, i32 0, i32 100
  %t536 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t534)
  store i64 %t536, ptr %l297
  br label %bb140
bb139:
  br label %bb143
bb140:
  %t537 = load ptr, ptr %l293, !tbaa !29
  %t538 = load i64, ptr %l294, !tbaa !24
  %t539 = load i64, ptr %l297, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t537, i64 %t538, i64 %t539)
  br label %bb141
bb141:
  %t540 = load ptr, ptr %l0, !tbaa !29
  %t542 = getelementptr %"compiler/emit:Emitter", ptr %t540, i32 0, i32 100
  %t543 = load i64, ptr %l39, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t542, i64 %t543)
  br label %bb142
bb142:
  br label %bb143
bb143:
  br label %bb144
bb144:
  %t546 = load i64, ptr %l38, !tbaa !24
  %t549 = add i64 %t546, 1
  store i64 %t549, ptr %l38, !tbaa !24
  br label %bb131
bb145:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisGlobalInit(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i32
  %l4 = alloca i1
  %l14 = alloca ptr
  %l17 = alloca i1
  %rv = alloca i1
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb14
bb3:
  %t12 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/lower:Lowerer", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = load i32, ptr %l2, !tbaa !23
  %t20 = sext i32 %t18 to i64
  %t23 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t16, i64 %t20)
  store ptr %t23, ptr %l14
  br label %bb4
bb4:
  %t24 = load ptr, ptr %l14, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Body", ptr %t24, i32 0, i32 1
  %t27 = load { i64, [2 x i64] }, ptr %t26
  %t31 = extractvalue { i64, [2 x i64] } %t27, 0
  %t32 = icmp eq i64 %t31, 6
  br i1 %t32, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb13
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_616c6f643d0ce9fd_dfe523617d4699c1)
  unreachable
bb13:
  %t34 = load i1, ptr %l17, !tbaa !21
  store i1 %t34, ptr %l4, !tbaa !21
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_b37ed008d0080fcc_cc9019489ebc5a30)
  unreachable
bb19:
  %t35 = load i1, ptr %l4, !tbaa !21
  store i1 %t35, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ereadableTypes(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i1
  %l26 = alloca %"std/prelude/text:StringBuilder"
  %l35 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l46 = alloca i64
  %l50 = alloca i64
  %l53 = alloca i64
  %l76 = alloca ptr
  %l87 = alloca i1
  %l91 = alloca i1
  %l92 = alloca { i64, ptr }
  %l93 = alloca i64
  %l94 = alloca i64
  %l95 = alloca i64
  %l101 = alloca i1
  %l105 = alloca i1
  %l106 = alloca { i64, ptr }
  %l110 = alloca i1
  %l121 = alloca { i64, ptr }
  %l122 = alloca { i64, ptr }
  %l129 = alloca ptr
  %l130 = alloca { i64, ptr }
  %l131 = alloca i64
  %l134 = alloca i64
  %l135 = alloca i64
  %l147 = alloca ptr
  %l148 = alloca { i64, ptr }
  %l149 = alloca i64
  %l152 = alloca i64
  %l153 = alloca i64
  %l159 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d125, i32 0, i32 1) }, ptr %l21, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t5 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t1, { i64, ptr } %t4)
  store i1 %t5, ptr %l22
  br label %bb1
bb1:
  %t6 = load i1, ptr %l22, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 1
  %t12 = extractvalue { i64, ptr } %t9, 0
  %t13 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t11, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t15, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t17, ptr %l26
  br label %bb5
bb5:
  %t18 = load %"std/prelude/text:StringBuilder", ptr %l26
  store %"std/prelude/text:StringBuilder" %t18, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t19, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s4
  %t25 = load i64, ptr %l5, !tbaa !24
  %t26 = load i64, ptr %l6, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s4)
  br label %bb65
bb8:
  br label %bb9
bb9:
  %t33 = load i64, ptr %l5, !tbaa !24
  store i64 %t33, ptr %l7, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t35, ptr %l35, !tbaa !27
  %t36 = load i64, ptr %l5, !tbaa !24
  %t38 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr i8, ptr %t39, i64 %t36
  %t41 = load i8, ptr %t40, !tbaa !32
  %t45 = icmp ne i8 %t41, 58
  br i1 %t45, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s4)
  br label %bb64
bb11:
  br label %bb12
bb12:
  store i64 -1, ptr %l9, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d126, i32 0, i32 1) }, ptr %l40, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t47, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/emit:Emitter", ptr %t49, i32 0, i32 0
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/generic:Program", ptr %t52, i32 0, i32 0
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/load:Loader", ptr %t55, i32 0, i32 10
  %t59 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t57)
  store i64 %t59, ptr %l46
  br label %bb13
bb13:
  %t60 = load i64, ptr %l46, !tbaa !24
  store i64 %t60, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t61 = load i64, ptr %l12, !tbaa !24
  %t62 = load i64, ptr %l11, !tbaa !24
  %t65 = icmp sgt i64 %t61, %t62
  br i1 %t65, label %bb14, label %bb15
bb14:
  %t67 = load i64, ptr %l13, !tbaa !24
  %t69 = icmp sgt i64 %t67, 0
  br i1 %t69, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l50, !tbaa !24
  br label %bb19
bb16:
  %t71 = load i64, ptr %l12, !tbaa !24
  %t72 = load i64, ptr %l11, !tbaa !24
  %t75 = sub i64 %t71, %t72
  %t76 = load i64, ptr %l13, !tbaa !24
  %t79 = add i64 %t75, %t76
  %t81 = sub i64 %t79, 1
  %t82 = load i64, ptr %l13, !tbaa !24
  %t85 = sdiv i64 %t81, %t82
  store i64 %t85, ptr %l53, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l53, !tbaa !24
  br label %bb18
bb18:
  %t87 = load i64, ptr %l53, !tbaa !24
  store i64 %t87, ptr %l50, !tbaa !24
  br label %bb19
bb19:
  %t88 = load i64, ptr %l50, !tbaa !24
  store i64 %t88, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb20
bb20:
  %t89 = load i64, ptr %l15, !tbaa !24
  %t90 = load i64, ptr %l14, !tbaa !24
  %t93 = icmp slt i64 %t89, %t90
  %t95 = xor i1 %t93, true
  br i1 %t95, label %bb21, label %bb22
bb21:
  br label %bb52
bb22:
  br label %bb23
bb23:
  %t97 = load i64, ptr %l11, !tbaa !24
  %t98 = load i64, ptr %l15, !tbaa !24
  %t99 = load i64, ptr %l13, !tbaa !24
  %t102 = mul i64 %t98, %t99
  %t105 = add i64 %t97, %t102
  store i64 %t105, ptr %l16, !tbaa !24
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/emit:Emitter", ptr %t107, i32 0, i32 0
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/generic:Program", ptr %t110, i32 0, i32 0
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = getelementptr %"compiler/load:Loader", ptr %t113, i32 0, i32 10
  %t116 = load i64, ptr %l16, !tbaa !24
  %t119 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t115, i64 %t116)
  store ptr %t119, ptr %l76
  br label %bb24
bb24:
  %t120 = load ptr, ptr %l76, !tbaa !29
  %t122 = getelementptr %"compiler/load:Module", ptr %t120, i32 0, i32 2
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  store { i64, ptr } %t123, ptr %l17, !tbaa !27
  %t125 = load i64, ptr %l7, !tbaa !24
  %t126 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t126, 0
  %t131 = sub i64 %t125, %t128
  store i64 %t131, ptr %l18, !tbaa !24
  %t133 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t133, 0
  %t136 = load i64, ptr %l9, !tbaa !24
  %t139 = icmp sle i64 %t135, %t136
  br i1 %t139, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l87, !tbaa !21
  br label %bb27
bb26:
  %t141 = load i64, ptr %l18, !tbaa !24
  %t142 = load i64, ptr %l3, !tbaa !24
  %t145 = icmp slt i64 %t141, %t142
  store i1 %t145, ptr %l87, !tbaa !21
  br label %bb27
bb27:
  %t147 = load i1, ptr %l87, !tbaa !21
  br i1 %t147, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l91, !tbaa !21
  br label %bb37
bb29:
  %t148 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t148, ptr %l92, !tbaa !27
  %t149 = load i64, ptr %l18, !tbaa !24
  store i64 %t149, ptr %l93, !tbaa !24
  %t150 = load i64, ptr %l7, !tbaa !24
  store i64 %t150, ptr %l94, !tbaa !24
  %t151 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t151, 0
  store i64 %t152, ptr %l95, !tbaa !24
  %t153 = load i64, ptr %l93, !tbaa !24
  %t154 = icmp sge i64 %t153, 0
  br i1 %t154, label %bb30, label %bb31
bb30:
  %t156 = load i64, ptr %l93, !tbaa !24
  %t157 = load i64, ptr %l94, !tbaa !24
  %t158 = icmp sle i64 %t156, %t157
  br i1 %t158, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_1a9d82a78676b0a6_b4156ec517c232f2)
  unreachable
bb32:
  %t160 = load i64, ptr %l94, !tbaa !24
  %t161 = load i64, ptr %l95, !tbaa !24
  %t162 = icmp sle i64 %t160, %t161
  br i1 %t162, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_1a9d82a78676b0a6_b4156ec517c232f2)
  unreachable
bb34:
  %t164 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !27
  %t166 = load i64, ptr %l93, !tbaa !24
  %t167 = load i64, ptr %l94, !tbaa !24
  %t168 = getelementptr i8, ptr %t165, i64 %t166
  %t169 = sub i64 %t167, %t166
  %t170 = insertvalue { i64, ptr } undef, i64 %t169, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t168, 1
  %t172 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t175 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %v0, { i64, ptr } %t171, { i64, ptr } %t172)
  store i1 %t175, ptr %l101
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_1a9d82a78676b0a6_b4156ec517c232f2)
  unreachable
bb36:
  %t176 = load i1, ptr %l101, !tbaa !21
  %t177 = xor i1 %t176, true
  store i1 %t177, ptr %l91, !tbaa !21
  br label %bb37
bb37:
  %t179 = load i1, ptr %l91, !tbaa !21
  br i1 %t179, label %bb38, label %bb39
bb38:
  br label %bb51
bb39:
  br label %bb40
bb40:
  %t180 = load i64, ptr %l18, !tbaa !24
  %t182 = icmp sgt i64 %t180, 0
  br i1 %t182, label %bb41, label %bb42
bb41:
  %t184 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t184, ptr %l106, !tbaa !27
  %t185 = load i64, ptr %l18, !tbaa !24
  %t187 = sub i64 %t185, 1
  %t189 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !27
  %t191 = getelementptr i8, ptr %t190, i64 %t187
  %t192 = load i8, ptr %t191, !tbaa !32
  %t194 = call i1 @compiler_2femit_2etypeDelim(i8 %t192)
  store i1 %t194, ptr %l110
  br label %bb43
bb42:
  store i1 false, ptr %l105, !tbaa !21
  br label %bb44
bb43:
  %t195 = load i1, ptr %l110, !tbaa !21
  %t196 = xor i1 %t195, true
  store i1 %t196, ptr %l105, !tbaa !21
  br label %bb44
bb44:
  %t198 = load i1, ptr %l105, !tbaa !21
  br i1 %t198, label %bb45, label %bb46
bb45:
  br label %bb51
bb46:
  br label %bb47
bb47:
  %t199 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t201 = extractvalue { i64, ptr } %t199, 0
  store i64 %t201, ptr %l9, !tbaa !24
  %t203 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t204 = load i64, ptr %l16, !tbaa !24
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/emit:Emitter", ptr %t205, i32 0, i32 0
  %t208 = load ptr, ptr %t207, !tbaa !29
  %t210 = getelementptr %"compiler/generic:Program", ptr %t208, i32 0, i32 0
  %t211 = load ptr, ptr %t210, !tbaa !29
  %t213 = getelementptr %"compiler/load:Loader", ptr %t211, i32 0, i32 12
  %t214 = load i64, ptr %t213, !tbaa !24
  %t217 = icmp eq i64 %t204, %t214
  %t220 = call { i64, ptr } @compiler_2fload_2eErrQualifier(ptr %v0, ptr %s4, { i64, ptr } %t203, i1 %t217)
  store { i64, ptr } %t220, ptr %l121
  br label %bb48
bb48:
  %t221 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t221, ptr %l122, !tbaa !27
  %t222 = load { i64, ptr }, ptr %l121, !tbaa !27
  store { i64, ptr } %t222, ptr %l10, !tbaa !27
  %t223 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3aEmitter__2ereadableTypes_2elocal_2e10
  br i1 %t223, label %bb49, label %bb50
bb49:
  %t225 = load { i64, ptr }, ptr %l122
  %t226 = extractvalue { i64, ptr } %t225, 1
  call void @__olang_region_release(ptr %t226)
  store { i64, ptr } zeroinitializer, ptr %l122
  br label %bb50
bb50:
  br label %bb51
bb51:
  %t227 = load i64, ptr %l15, !tbaa !24
  %t230 = add i64 %t227, 1
  store i64 %t230, ptr %l15, !tbaa !24
  br label %bb20
bb52:
  %t232 = load i64, ptr %l9, !tbaa !24
  %t234 = icmp slt i64 %t232, 0
  br i1 %t234, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s4)
  br label %bb64
bb54:
  br label %bb55
bb55:
  store ptr %l2, ptr %l129, !tbaa !29
  %t236 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t236, ptr %l130, !tbaa !27
  %t237 = load i64, ptr %l3, !tbaa !24
  store i64 %t237, ptr %l131, !tbaa !24
  %t238 = load i64, ptr %l7, !tbaa !24
  %t239 = load i64, ptr %l9, !tbaa !24
  %t242 = sub i64 %t238, %t239
  store i64 %t242, ptr %l134, !tbaa !24
  %t243 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t244 = extractvalue { i64, ptr } %t243, 0
  store i64 %t244, ptr %l135, !tbaa !24
  %t245 = load i64, ptr %l131, !tbaa !24
  %t246 = icmp sge i64 %t245, 0
  br i1 %t246, label %bb56, label %bb57
bb56:
  %t248 = load i64, ptr %l131, !tbaa !24
  %t249 = load i64, ptr %l134, !tbaa !24
  %t250 = icmp sle i64 %t248, %t249
  br i1 %t250, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_59a9be6f9464903_424bcbda67d6186f)
  unreachable
bb58:
  %t252 = load i64, ptr %l134, !tbaa !24
  %t253 = load i64, ptr %l135, !tbaa !24
  %t254 = icmp sle i64 %t252, %t253
  br i1 %t254, label %bb60, label %bb61
bb59:
  call void @__olang_check_failed(ptr @olang_loc_59a9be6f9464903_424bcbda67d6186f)
  unreachable
bb60:
  %t256 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t257 = load ptr, ptr %t256, !tbaa !27
  %t258 = load i64, ptr %l131, !tbaa !24
  %t259 = load i64, ptr %l134, !tbaa !24
  %t260 = getelementptr i8, ptr %t257, i64 %t258
  %t261 = sub i64 %t259, %t258
  %t262 = insertvalue { i64, ptr } undef, i64 %t261, 0
  %t263 = insertvalue { i64, ptr } %t262, ptr %t260, 1
  %t264 = load ptr, ptr %l129, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v1, ptr %t264, { i64, ptr } %t263)
  br label %bb62
bb61:
  call void @__olang_check_failed(ptr @olang_loc_59a9be6f9464903_424bcbda67d6186f)
  unreachable
bb62:
  %t266 = load { i64, ptr }, ptr %l10, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l2, { i64, ptr } %t266)
  br label %bb63
bb63:
  %t269 = load i64, ptr %l7, !tbaa !24
  %t271 = add i64 %t269, 1
  store i64 %t271, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb64
bb64:
  %t273 = load i64, ptr %l5, !tbaa !24
  %t276 = add i64 %t273, 1
  store i64 %t276, ptr %l5, !tbaa !24
  br label %bb6
bb65:
  store ptr %l2, ptr %l147, !tbaa !29
  %t278 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t278, ptr %l148, !tbaa !27
  %t279 = load i64, ptr %l3, !tbaa !24
  store i64 %t279, ptr %l149, !tbaa !24
  %t280 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t283 = extractvalue { i64, ptr } %t280, 0
  store i64 %t283, ptr %l152, !tbaa !24
  %t284 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t285 = extractvalue { i64, ptr } %t284, 0
  store i64 %t285, ptr %l153, !tbaa !24
  %t286 = load i64, ptr %l149, !tbaa !24
  %t287 = icmp sge i64 %t286, 0
  br i1 %t287, label %bb66, label %bb67
bb66:
  %t289 = load i64, ptr %l149, !tbaa !24
  %t290 = load i64, ptr %l152, !tbaa !24
  %t291 = icmp sle i64 %t289, %t290
  br i1 %t291, label %bb68, label %bb69
bb67:
  call void @__olang_check_failed(ptr @olang_loc_f7c6dddb13d754e8_bd1e858aa2031304)
  unreachable
bb68:
  %t293 = load i64, ptr %l152, !tbaa !24
  %t294 = load i64, ptr %l153, !tbaa !24
  %t295 = icmp sle i64 %t293, %t294
  br i1 %t295, label %bb70, label %bb71
bb69:
  call void @__olang_check_failed(ptr @olang_loc_f7c6dddb13d754e8_bd1e858aa2031304)
  unreachable
bb70:
  %t297 = getelementptr { i64, ptr }, ptr %l148, i32 0, i32 1
  %t298 = load ptr, ptr %t297, !tbaa !27
  %t299 = load i64, ptr %l149, !tbaa !24
  %t300 = load i64, ptr %l152, !tbaa !24
  %t301 = getelementptr i8, ptr %t298, i64 %t299
  %t302 = sub i64 %t300, %t299
  %t303 = insertvalue { i64, ptr } undef, i64 %t302, 0
  %t304 = insertvalue { i64, ptr } %t303, ptr %t301, 1
  %t305 = load ptr, ptr %l147, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v1, ptr %t305, { i64, ptr } %t304)
  br label %bb72
bb71:
  call void @__olang_check_failed(ptr @olang_loc_f7c6dddb13d754e8_bd1e858aa2031304)
  unreachable
bb72:
  %t308 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t308, ptr %l159
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s0)
  %t309 = load { i64, ptr }, ptr %l159, !tbaa !27
  store { i64, ptr } %t309, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esignatureText(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l10 = alloca i64
  %l16 = alloca ptr
  %l22 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l34 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l43 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i32
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca i64
  %l57 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t4, i64 %t5)
  store i64 %t8, ptr %l10
  br label %bb1
bb1:
  %t9 = load i64, ptr %l10, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/emit:Emitter", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/load:Loader", ptr %t16, i32 0, i32 10
  %t22 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t18, i64 %t9)
  store ptr %t22, ptr %l16
  br label %bb2
bb2:
  %t23 = load ptr, ptr %l16, !tbaa !29
  %t25 = getelementptr %"compiler/load:Module", ptr %t23, i32 0, i32 6
  %t26 = load ptr, ptr %t25, !tbaa !29
  store ptr %t26, ptr %l3, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/emit:Emitter", ptr %t28, i32 0, i32 0
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t31, i64 %t32)
  store ptr %t35, ptr %l22
  br label %bb3
bb3:
  %t36 = load ptr, ptr %l22, !tbaa !29
  store ptr %t36, ptr %l4, !tbaa !29
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  br i1 %t39, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load ptr, ptr %l4, !tbaa !29
  %t44 = getelementptr %"compiler/ast:Func", ptr %t42, i32 0, i32 2
  %t45 = load i32, ptr %t44, !tbaa !23
  %t48 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %s1, ptr %t41, i32 %t45)
  store { i64, ptr } %t48, ptr %l28
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t49 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d127, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d127, i32 0, i32 1) }, 0
  %t51 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t51, 1
  %t53 = extractvalue { i64, ptr } %t51, 0
  %t54 = add i64 %t50, %t53
  %t55 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t54)
  call void @olang_textcopy(ptr %t55, ptr %t49, i64 %t50)
  %t56 = getelementptr i8, ptr %t55, i64 %t50
  call void @olang_textcopy(ptr %t56, ptr %t52, i64 %t53)
  %t57 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t55, 1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t58, ptr %rv
  br label %ret
bb7:
  %t60 = load ptr, ptr %l3, !tbaa !29
  %t62 = getelementptr %"compiler/source:Source", ptr %t60, i32 0, i32 1
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  store { i64, ptr } %t63, ptr %l31, !tbaa !27
  %t64 = load ptr, ptr %l4, !tbaa !29
  %t66 = getelementptr %"compiler/ast:Func", ptr %t64, i32 0, i32 0
  %t67 = getelementptr %"compiler/source:Span", ptr %t66, i32 0, i32 0
  %t68 = load i32, ptr %t67, !tbaa !23
  %t70 = sext i32 %t68 to i64
  store i64 %t70, ptr %l34, !tbaa !24
  %t71 = load ptr, ptr %l4, !tbaa !29
  %t73 = getelementptr %"compiler/ast:Func", ptr %t71, i32 0, i32 0
  %t74 = getelementptr %"compiler/source:Span", ptr %t73, i32 0, i32 1
  %t75 = load i32, ptr %t74, !tbaa !23
  %t77 = sext i32 %t75 to i64
  store i64 %t77, ptr %l37, !tbaa !24
  %t78 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 0
  store i64 %t79, ptr %l38, !tbaa !24
  %t80 = load i64, ptr %l34, !tbaa !24
  %t81 = icmp sge i64 %t80, 0
  br i1 %t81, label %bb8, label %bb9
bb8:
  %t83 = load i64, ptr %l34, !tbaa !24
  %t84 = load i64, ptr %l37, !tbaa !24
  %t85 = icmp sle i64 %t83, %t84
  br i1 %t85, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_42bc5298e90f43ae_6d491b8985e0cdda)
  unreachable
bb10:
  %t87 = load i64, ptr %l37, !tbaa !24
  %t88 = load i64, ptr %l38, !tbaa !24
  %t89 = icmp sle i64 %t87, %t88
  br i1 %t89, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_42bc5298e90f43ae_6d491b8985e0cdda)
  unreachable
bb12:
  %t91 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = load i64, ptr %l34, !tbaa !24
  %t94 = load i64, ptr %l37, !tbaa !24
  %t95 = getelementptr i8, ptr %t92, i64 %t93
  %t96 = sub i64 %t94, %t93
  %t97 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t95, 1
  store { i64, ptr } %t98, ptr %l5, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t103 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %t100, i8 123)
  %t104 = extractvalue { i32, i64 } %t103, 1
  %t105 = extractvalue { i32, i64 } %t103, 0
  store i32 %t105, ptr %l47
  %t106 = icmp ne i32 %t105, 0
  br i1 %t106, label %bb15, label %ok.107, !prof !99
ok.107:
  store i64 %t104, ptr %l46
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_42bc5298e90f43ae_6d491b8985e0cdda)
  unreachable
bb14:
  %t108 = load i64, ptr %l46, !tbaa !24
  store i64 %t108, ptr %l43, !tbaa !24
  br label %bb17
bb15:
  br label %bb16
bb16:
  %t109 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t109, 0
  store i64 %t111, ptr %l43, !tbaa !24
  br label %bb17
bb17:
  %t113 = load i64, ptr %l43, !tbaa !24
  %t114 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t114, ptr %l50, !tbaa !27
  store i64 %t113, ptr %l51, !tbaa !24
  %t116 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t116, 0
  store i64 %t117, ptr %l52, !tbaa !24
  %t118 = icmp sge i64 0, 0
  br i1 %t118, label %bb18, label %bb19
bb18:
  %t120 = load i64, ptr %l51, !tbaa !24
  %t121 = icmp sle i64 0, %t120
  br i1 %t121, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_5c86fd64ff4c2cab_ac7223dcbaf0ef37)
  unreachable
bb20:
  %t123 = load i64, ptr %l51, !tbaa !24
  %t124 = load i64, ptr %l52, !tbaa !24
  %t125 = icmp sle i64 %t123, %t124
  br i1 %t125, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_5c86fd64ff4c2cab_ac7223dcbaf0ef37)
  unreachable
bb22:
  %t127 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = load i64, ptr %l51, !tbaa !24
  %t130 = getelementptr i8, ptr %t128, i64 0
  %t131 = sub i64 %t129, 0
  %t132 = insertvalue { i64, ptr } undef, i64 %t131, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t130, 1
  %t135 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %s0, { i64, ptr } %t133)
  store { i64, ptr } %t135, ptr %l57
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_5c86fd64ff4c2cab_ac7223dcbaf0ef37)
  unreachable
bb24:
  %t136 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d128, i32 0, i32 1) }, ptr %l59, !tbaa !27
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d129, i32 0, i32 1) }, ptr %l60, !tbaa !27
  %t138 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t139 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t140 = call { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t136, { i64, ptr } %t138, { i64, ptr } %t139)
  store { i64, ptr } %t140, ptr %l61
  br label %bb25
bb25:
  %t141 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t141, 1
  %t144 = extractvalue { i64, ptr } %t141, 0
  %t145 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t144)
  call void @olang_textcopy(ptr %t145, ptr %t143, i64 %t144)
  %t146 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t145, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t147, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2esiteable(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i1
  %l8 = alloca i1
  %l11 = alloca i1
  %l18 = alloca i64
  %l22 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 5
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/emit:Emitter", ptr %t6, i32 0, i32 48
  %t9 = load i1, ptr %t8, !tbaa !21
  store i1 %t9, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l5, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb6
bb5:
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr %"compiler/emit:fnEm", ptr %t12, i32 0, i32 33
  %t15 = load i1, ptr %t14, !tbaa !21
  store i1 %t15, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l8, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb9
bb8:
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/emit:fnEm", ptr %t18, i32 0, i32 29
  %t21 = load i1, ptr %t20, !tbaa !21
  store i1 %t21, ptr %l11, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l11, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  store i1 false, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr %"compiler/emit:fnEm", ptr %t26, i32 0, i32 2
  %t29 = load { i64, [2 x i64] }, ptr %t28
  %t32 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehomeOf(ptr %v0, ptr %t25, { i64, [2 x i64] } %t29)
  store i64 %t32, ptr %l18
  br label %bb13
bb13:
  %t33 = load i64, ptr %l18, !tbaa !24
  store i64 %t33, ptr %l2, !tbaa !24
  %t34 = load i64, ptr %l2, !tbaa !24
  %t35 = load i64, ptr @G_2ecompiler_2femit_2eHomeInst, !tbaa !24
  %t38 = icmp eq i64 %t34, %t35
  br i1 %t38, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb16
bb15:
  %t40 = load i64, ptr %l2, !tbaa !24
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/emit:Emitter", ptr %t41, i32 0, i32 0
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/load:Loader", ptr %t47, i32 0, i32 12
  %t50 = load i64, ptr %t49, !tbaa !24
  %t53 = icmp eq i64 %t40, %t50
  store i1 %t53, ptr %l22, !tbaa !21
  br label %bb16
bb16:
  %t55 = load i1, ptr %l22, !tbaa !21
  store i1 %t55, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewantType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l20 = alloca { i64, ptr }
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i64
  %l51 = alloca i64
  %l53 = alloca i64
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l60 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i32
  %l74 = alloca i1
  %l77 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v2, ptr %t1, i64 %t2, i1 true)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t5, i64 %t6)
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/emit:Emitter", ptr %t9, i32 0, i32 59
  %t12 = load i64, ptr %l1, !tbaa !24
  %t15 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t11, i64 %t12)
  store { i64, ptr } %t15, ptr %l20
  br label %bb3
bb3:
  %t16 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t16, ptr %l4, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2femit_2erefsIn(ptr %v0, ptr %s0, { i64, ptr } %t17)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l22
  br label %bb4
bb4:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l5)
  store i64 %t22, ptr %l24
  br label %bb5
bb5:
  %t23 = load i64, ptr %l24, !tbaa !24
  store i64 %t23, ptr %l7, !tbaa !24
  store i64 3, ptr %l8, !tbaa !24
  %t24 = load i64, ptr %l7, !tbaa !24
  %t25 = load i64, ptr %l6, !tbaa !24
  %t28 = icmp sgt i64 %t24, %t25
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t30 = load i64, ptr %l8, !tbaa !24
  %t32 = icmp sgt i64 %t30, 0
  br i1 %t32, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb11
bb8:
  %t34 = load i64, ptr %l7, !tbaa !24
  %t35 = load i64, ptr %l6, !tbaa !24
  %t38 = sub i64 %t34, %t35
  %t39 = load i64, ptr %l8, !tbaa !24
  %t42 = add i64 %t38, %t39
  %t44 = sub i64 %t42, 1
  %t45 = load i64, ptr %l8, !tbaa !24
  %t48 = sdiv i64 %t44, %t45
  store i64 %t48, ptr %l31, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb10
bb10:
  %t50 = load i64, ptr %l31, !tbaa !24
  store i64 %t50, ptr %l28, !tbaa !24
  br label %bb11
bb11:
  %t51 = load i64, ptr %l28, !tbaa !24
  store i64 %t51, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb12
bb12:
  %t52 = load i64, ptr %l10, !tbaa !24
  %t53 = load i64, ptr %l9, !tbaa !24
  %t56 = icmp slt i64 %t52, %t53
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb13, label %bb14
bb13:
  br label %bb41
bb14:
  br label %bb15
bb15:
  %t60 = load i64, ptr %l6, !tbaa !24
  %t61 = load i64, ptr %l10, !tbaa !24
  %t62 = load i64, ptr %l8, !tbaa !24
  %t65 = mul i64 %t61, %t62
  %t68 = add i64 %t60, %t65
  store i64 %t68, ptr %l11, !tbaa !24
  %t70 = load i64, ptr %l11, !tbaa !24
  %t73 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l5, i64 %t70)
  store i64 %t73, ptr %l51
  br label %bb16
bb16:
  %t74 = load i64, ptr %l51, !tbaa !24
  %t75 = icmp ne i64 %t74, 1
  br i1 %t75, label %bb17, label %bb18
bb17:
  br label %bb40
bb18:
  br label %bb19
bb19:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/emit:Emitter", ptr %t77, i32 0, i32 60
  store ptr %t79, ptr %l55, !tbaa !29
  %t80 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t80, ptr %l56, !tbaa !27
  %t81 = load i64, ptr %l11, !tbaa !24
  %t83 = add i64 %t81, 1
  %t86 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l5, i64 %t83)
  store i64 %t86, ptr %l60
  br label %bb20
bb20:
  %t87 = load i64, ptr %l11, !tbaa !24
  %t89 = add i64 %t87, 2
  %t92 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l5, i64 %t89)
  store i64 %t92, ptr %l64
  br label %bb21
bb21:
  %t93 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 0
  store i64 %t94, ptr %l65, !tbaa !24
  %t95 = load i64, ptr %l60, !tbaa !24
  %t96 = icmp sge i64 %t95, 0
  br i1 %t96, label %bb22, label %bb23
bb22:
  %t98 = load i64, ptr %l60, !tbaa !24
  %t99 = load i64, ptr %l64, !tbaa !24
  %t100 = icmp sle i64 %t98, %t99
  br i1 %t100, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_6f064da57090b2af_17093dce158f11fb)
  unreachable
bb24:
  %t102 = load i64, ptr %l64, !tbaa !24
  %t103 = load i64, ptr %l65, !tbaa !24
  %t104 = icmp sle i64 %t102, %t103
  br i1 %t104, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_6f064da57090b2af_17093dce158f11fb)
  unreachable
bb26:
  %t106 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = load i64, ptr %l60, !tbaa !24
  %t109 = load i64, ptr %l64, !tbaa !24
  %t110 = getelementptr i8, ptr %t107, i64 %t108
  %t111 = sub i64 %t109, %t108
  %t112 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t110, 1
  %t114 = load ptr, ptr %l55, !tbaa !29
  %t116 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v0, ptr %t114, { i64, ptr } %t113)
  %t117 = extractvalue { i32, i64 } %t116, 1
  %t118 = extractvalue { i32, i64 } %t116, 0
  store i32 %t118, ptr %l71
  %t119 = icmp ne i32 %t118, 0
  br i1 %t119, label %bb29, label %ok.120, !prof !99
ok.120:
  store i64 %t117, ptr %l70
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_6f064da57090b2af_17093dce158f11fb)
  unreachable
bb28:
  %t121 = load i64, ptr %l70, !tbaa !24
  store i64 %t121, ptr %l53, !tbaa !24
  br label %bb31
bb29:
  br label %bb30
bb30:
  store i64 -1, ptr %l53, !tbaa !24
  br label %bb31
bb31:
  %t122 = load i64, ptr %l53, !tbaa !24
  store i64 %t122, ptr %l12, !tbaa !24
  %t123 = load i64, ptr %l12, !tbaa !24
  %t125 = icmp sge i64 %t123, 0
  br i1 %t125, label %bb32, label %bb33
bb32:
  %t127 = load ptr, ptr %l3, !tbaa !29
  %t128 = load i64, ptr %l12, !tbaa !24
  %t131 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v2, ptr %t127, i64 %t128)
  store i1 %t131, ptr %l77
  br label %bb34
bb33:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb35
bb34:
  %t132 = load i1, ptr %l77, !tbaa !21
  %t133 = xor i1 %t132, true
  store i1 %t133, ptr %l74, !tbaa !21
  br label %bb35
bb35:
  %t135 = load i1, ptr %l74, !tbaa !21
  br i1 %t135, label %bb36, label %bb37
bb36:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load i64, ptr %l12, !tbaa !24
  %t138 = load ptr, ptr %l2, !tbaa !29
  %t139 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewantType(ptr %v0, ptr %v1, ptr %v2, ptr %t136, i64 %t137, ptr %t138, ptr %t139)
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t144 = load i64, ptr %l10, !tbaa !24
  %t147 = add i64 %t144, 1
  store i64 %t147, ptr %l10, !tbaa !24
  br label %bb12
bb41:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewriteBody(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [2 x i64] } %a1, ptr %a2, { i64, ptr } %a3, i64 %a4, i1 %a5, { i64, ptr } %a6, i1 %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i1
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca %"std/prelude/text:StringBuilder"
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l17 = alloca { i64, ptr }
  %l24 = alloca %"compiler/emit:fnEm"
  %l40 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca { i64, [2 x i64] }
  %l49 = alloca i32
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca i1
  %l53 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l69 = alloca %"std/prelude/text:StringBuilder"
  %l72 = alloca i64
  %l75 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l84 = alloca ptr
  %l87 = alloca i64
  %l88 = alloca i64
  %l101 = alloca ptr
  %l104 = alloca { i64, ptr }
  %l106 = alloca ptr
  %l109 = alloca { i64, ptr }
  %l114 = alloca i1
  %l120 = alloca ptr
  %l123 = alloca { i64, ptr }
  %l126 = alloca ptr
  %l129 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l154 = alloca { i64, ptr }
  %l155 = alloca ptr
  %l156 = alloca { i64, [2 x i64] }
  %l158 = alloca i32
  %l159 = alloca { i64, ptr }
  %l160 = alloca i64
  %l161 = alloca i1
  %l162 = alloca { i64, ptr }
  %l163 = alloca { i64, ptr }
  %l164 = alloca i64
  %l167 = alloca { i64, ptr }
  %l168 = alloca { i64, ptr }
  %l171 = alloca i64
  %l172 = alloca { i64, ptr }
  %l174 = alloca { i64, ptr }
  %l179 = alloca ptr
  %l180 = alloca { i64, [2 x i64] }
  %l182 = alloca i32
  %l183 = alloca { i64, ptr }
  %l184 = alloca i64
  %l185 = alloca i1
  %l187 = alloca { i64, ptr }
  %l188 = alloca { i64, ptr }
  %l191 = alloca i64
  %l192 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca i1
  %t27 = alloca %"compiler/emit:fnEm", align 8
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i64 %a4, ptr %l4
  store i1 %a5, ptr %l5
  store i1 %a7, ptr %l7
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call ptr @__olang_scope_hold(ptr %s0)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l14, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3aEmitter__2ewriteBody_2elocal_2e8
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %s0)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l14, !tbaa !24
  br label %bb2
bb2:
  %t9 = extractvalue { i64, ptr } %a6, 1
  %t10 = extractvalue { i64, ptr } %a6, 0
  %t11 = load i64, ptr %l14
  %t12 = inttoptr i64 %t11 to ptr
  %t13 = call ptr @__olang_held_alloc(ptr %t12, i64 %t10)
  call void @olang_textcopy(ptr %t13, ptr %t9, i64 %t10)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l17, !tbaa !27
  %t16 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3aEmitter__2ewriteBody_2elocal_2e8
  br i1 %t16, label %bb3, label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t18, 0
  %t21 = icmp eq i64 %t19, 0
  br i1 %t21, label %bb5, label %bb6
bb4:
  %t23 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t23, ptr %l8, !tbaa !27
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t26 = load { i64, [2 x i64] }, ptr %l1
  call void @compiler_2femit_3afnEm_2ector(ptr %t27, ptr %v0, ptr %v1, ptr %s0, ptr %t24, ptr %t25, { i64, [2 x i64] } %t26)
  call void @llvm.memmove.p0.p0.i64(ptr %l24, ptr %t27, i64 1104, i1 false)
  br label %bb7
bb5:
  store { i64, ptr } zeroinitializer, ptr %l17, !tbaa !27
  br label %bb6
bb6:
  %t31 = load i64, ptr %l14
  %t32 = inttoptr i64 %t31 to ptr
  %t33 = load { i64, ptr }, ptr %l17
  %t34 = extractvalue { i64, ptr } %t33, 1
  %t35 = call ptr @__olang_region_or(ptr %t34, ptr null)
  %t36 = icmp ne ptr %t35, null
  %t37 = select i1 %t36, ptr %t35, ptr null
  call void @__olang_region_settle_in(ptr %t32, ptr %t37)
  br label %bb4
bb7:
  %t38 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 1104, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t38, ptr %l24, i64 1104, i1 false)
  store ptr %t38, ptr %l9, !tbaa !29
  %t40 = load ptr, ptr %l9, !tbaa !29
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = getelementptr %"compiler/emit:fnEm", ptr %t40, i32 0, i32 7
  store i64 %t41, ptr %t44, !tbaa !24
  %t45 = load ptr, ptr %l9, !tbaa !29
  %t46 = load i1, ptr %l5, !tbaa !21
  %t49 = getelementptr %"compiler/emit:fnEm", ptr %t45, i32 0, i32 12
  store i1 %t46, ptr %t49, !tbaa !21
  %t50 = load ptr, ptr %l9, !tbaa !29
  %t51 = load ptr, ptr %l2, !tbaa !29
  %t53 = getelementptr %"compiler/mir:Fn", ptr %t51, i32 0, i32 25
  %t54 = load i1, ptr %t53, !tbaa !21
  %t57 = getelementptr %"compiler/emit:fnEm", ptr %t50, i32 0, i32 29
  store i1 %t54, ptr %t57, !tbaa !21
  %t58 = load ptr, ptr %l9, !tbaa !29
  %t59 = load i1, ptr %l7, !tbaa !21
  %t62 = getelementptr %"compiler/emit:fnEm", ptr %t58, i32 0, i32 33
  store i1 %t59, ptr %t62, !tbaa !21
  %t63 = load ptr, ptr %l9, !tbaa !29
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/emit:Emitter", ptr %t64, i32 0, i32 58
  %t67 = load i64, ptr %t66, !tbaa !24
  %t70 = getelementptr %"compiler/emit:fnEm", ptr %t63, i32 0, i32 40
  store i64 %t67, ptr %t70, !tbaa !24
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/emit:Emitter", ptr %t71, i32 0, i32 33
  store i1 false, ptr %t73, !tbaa !21
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbg(ptr %v0, ptr %t74)
  store i1 %t76, ptr %l40
  br label %bb8
bb8:
  %t77 = load i1, ptr %l40, !tbaa !21
  br i1 %t77, label %bb9, label %bb10
bb9:
  %t78 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2esubprogram(ptr %s0, ptr %v0, ptr %v1, ptr %t78)
  br label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t80 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2erun(ptr %s0, ptr %v0, ptr %v1, ptr %t80)
  br label %bb13
bb13:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/emit:Emitter", ptr %t82, i32 0, i32 33
  %t85 = load i1, ptr %t84, !tbaa !21
  br i1 %t85, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t87 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s3, ptr %t87, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d130, i32 0, i32 1) })
  br label %bb16
bb15:
  br label %bb23
bb16:
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l46, !tbaa !29
  %t90 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t90, ptr %l47
  %t91 = load ptr, ptr %l2, !tbaa !29
  %t93 = getelementptr %"compiler/mir:Fn", ptr %t91, i32 0, i32 1
  %t94 = load i32, ptr %t93, !tbaa !23
  store i32 %t94, ptr %l49, !tbaa !23
  %t95 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t95, ptr %l50, !tbaa !27
  %t96 = load i64, ptr %l4, !tbaa !24
  store i64 %t96, ptr %l51, !tbaa !24
  %t97 = load i1, ptr %l5, !tbaa !21
  store i1 %t97, ptr %l52, !tbaa !21
  %t98 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t98, ptr %l53, !tbaa !27
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t103 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2estub(ptr %v0, ptr %s3, ptr %v2, ptr %s3, ptr %t99, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d131, i32 0, i32 1) }, { i64, ptr } %t100)
  store { i64, ptr } %t103, ptr %l56
  br label %bb17
bb17:
  %t104 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 1
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t107 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t107, 1
  %t109 = extractvalue { i64, ptr } %t107, 0
  %t110 = add i64 %t106, %t109
  %t111 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t110)
  call void @olang_textcopy(ptr %t111, ptr %t105, i64 %t106)
  %t112 = getelementptr i8, ptr %t111, i64 %t106
  call void @olang_textcopy(ptr %t112, ptr %t108, i64 %t109)
  %t113 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t111, 1
  %t116 = load ptr, ptr %l46, !tbaa !29
  %t117 = load { i64, [2 x i64] }, ptr %l47
  %t118 = load i32, ptr %l49, !tbaa !23
  %t119 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t120 = load i64, ptr %l51, !tbaa !24
  %t121 = load i1, ptr %l52, !tbaa !21
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efnItem(ptr %v0, ptr %v2, ptr %s3, ptr %t116, { i64, [2 x i64] } %t117, i32 %t118, { i64, ptr } %t119, i64 %t120, i1 %t121, { i64, ptr } %t114)
  br label %bb18
bb18:
  %t123 = load i1, ptr %l7, !tbaa !21
  %t125 = xor i1 %t123, true
  br i1 %t125, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load { i64, [2 x i64] }, ptr %l1
  %t129 = load ptr, ptr %l2, !tbaa !29
  %t131 = getelementptr %"compiler/mir:Fn", ptr %t129, i32 0, i32 1
  %t132 = load i32, ptr %t131, !tbaa !23
  %t133 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t134 = load i64, ptr %l4, !tbaa !24
  %t135 = load i1, ptr %l5, !tbaa !21
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewalkStub(ptr %v0, ptr %v2, ptr %s5, ptr %t127, { i64, [2 x i64] } %t128, i32 %t132, { i64, ptr } %t133, i64 %t134, i1 %t135, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d132, i32 0, i32 1) })
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_scope_close(ptr %s5)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb23:
  %t143 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t143, ptr %l69
  br label %bb24
bb24:
  %t144 = load %"std/prelude/text:StringBuilder", ptr %l69
  store %"std/prelude/text:StringBuilder" %t144, ptr %l10
  %t145 = load ptr, ptr %l9, !tbaa !29
  %t147 = getelementptr %"compiler/emit:fnEm", ptr %t145, i32 0, i32 29
  %t148 = load i1, ptr %t147, !tbaa !21
  br i1 %t148, label %bb25, label %bb26
bb25:
  %t150 = call ptr @__olang_scope_hold(ptr %s0)
  %t151 = ptrtoint ptr %t150 to i64
  store i64 %t151, ptr %l72, !tbaa !24
  %t152 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3aEmitter__2ewriteBody_2elocal_2e8
  br i1 %t152, label %bb27, label %bb28
bb26:
  br label %bb35
bb27:
  %t154 = call ptr @__olang_region_make(ptr %s0)
  %t155 = ptrtoint ptr %t154 to i64
  store i64 %t155, ptr %l72, !tbaa !24
  br label %bb28
bb28:
  %t156 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t157 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d133, i32 0, i32 1) }, 1
  %t158 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d133, i32 0, i32 1) }, 0
  %t160 = extractvalue { i64, ptr } %t156, 1
  %t161 = extractvalue { i64, ptr } %t156, 0
  %t162 = add i64 %t158, %t161
  %t163 = extractvalue { i64, ptr } { i64 63, ptr getelementptr inbounds (<{ i64, [63 x i8] }>, ptr @.d134, i32 0, i32 1) }, 1
  %t164 = extractvalue { i64, ptr } { i64 63, ptr getelementptr inbounds (<{ i64, [63 x i8] }>, ptr @.d134, i32 0, i32 1) }, 0
  %t165 = add i64 %t162, %t164
  %t166 = load i64, ptr %l72
  %t167 = inttoptr i64 %t166 to ptr
  %t168 = call ptr @__olang_held_alloc(ptr %t167, i64 %t165)
  call void @olang_textcopy(ptr %t168, ptr %t157, i64 %t158)
  %t169 = getelementptr i8, ptr %t168, i64 %t158
  call void @olang_textcopy(ptr %t169, ptr %t160, i64 %t161)
  %t170 = getelementptr i8, ptr %t169, i64 %t161
  call void @olang_textcopy(ptr %t170, ptr %t163, i64 %t164)
  %t171 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t172 = insertvalue { i64, ptr } %t171, ptr %t168, 1
  store { i64, ptr } %t172, ptr %l75, !tbaa !27
  %t173 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3aEmitter__2ewriteBody_2elocal_2e8
  br i1 %t173, label %bb29, label %bb30
bb29:
  %t175 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t176 = extractvalue { i64, ptr } %t175, 0
  %t178 = icmp eq i64 %t176, 0
  br i1 %t178, label %bb31, label %bb32
bb30:
  %t180 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t180, ptr %l79, !tbaa !27
  %t181 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t181, ptr %l8, !tbaa !27
  %t182 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3aEmitter__2ewriteBody_2elocal_2e8
  br i1 %t182, label %bb33, label %bb34
bb31:
  store { i64, ptr } zeroinitializer, ptr %l75, !tbaa !27
  br label %bb32
bb32:
  %t184 = load i64, ptr %l72
  %t185 = inttoptr i64 %t184 to ptr
  %t186 = load { i64, ptr }, ptr %l75
  %t187 = extractvalue { i64, ptr } %t186, 1
  %t188 = call ptr @__olang_region_or(ptr %t187, ptr null)
  %t189 = icmp ne ptr %t188, null
  %t190 = select i1 %t189, ptr %t188, ptr null
  call void @__olang_region_settle_in(ptr %t185, ptr %t190)
  br label %bb30
bb33:
  %t191 = load { i64, ptr }, ptr %l79
  %t192 = extractvalue { i64, ptr } %t191, 1
  call void @__olang_region_release(ptr %t192)
  store { i64, ptr } zeroinitializer, ptr %l79
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t193 = load ptr, ptr %l9, !tbaa !29
  %t195 = getelementptr %"compiler/emit:fnEm", ptr %t193, i32 0, i32 18
  %t196 = load i64, ptr %t195, !tbaa !24
  %t198 = icmp sge i64 %t196, 0
  br i1 %t198, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s8
  store ptr %l10, ptr %l84, !tbaa !29
  %t200 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t202 = extractvalue { i64, ptr } %t200, 0
  %t204 = sub i64 %t202, 2
  store i64 %t204, ptr %l87, !tbaa !24
  %t205 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t206 = extractvalue { i64, ptr } %t205, 0
  store i64 %t206, ptr %l88, !tbaa !24
  %t207 = icmp sge i64 0, 0
  br i1 %t207, label %bb38, label %bb39
bb37:
  %t209 = load { i64, ptr }, ptr %l8, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l10, { i64, ptr } %t209)
  br label %bb46
bb38:
  %t212 = load i64, ptr %l87, !tbaa !24
  %t213 = icmp sle i64 0, %t212
  br i1 %t213, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_8de51998cc7658b0_11d2469cc10d3f54)
  unreachable
bb40:
  %t215 = load i64, ptr %l87, !tbaa !24
  %t216 = load i64, ptr %l88, !tbaa !24
  %t217 = icmp sle i64 %t215, %t216
  br i1 %t217, label %bb42, label %bb43
bb41:
  call void @__olang_check_failed(ptr @olang_loc_8de51998cc7658b0_11d2469cc10d3f54)
  unreachable
bb42:
  %t219 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t220 = load ptr, ptr %t219, !tbaa !27
  %t221 = load i64, ptr %l87, !tbaa !24
  %t222 = getelementptr i8, ptr %t220, i64 0
  %t223 = sub i64 %t221, 0
  %t224 = insertvalue { i64, ptr } undef, i64 %t223, 0
  %t225 = insertvalue { i64, ptr } %t224, ptr %t222, 1
  %t226 = load ptr, ptr %l84, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t226, { i64, ptr } %t225)
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_8de51998cc7658b0_11d2469cc10d3f54)
  unreachable
bb44:
  %t228 = load ptr, ptr %l9, !tbaa !29
  %t230 = getelementptr %"compiler/emit:fnEm", ptr %t228, i32 0, i32 18
  %t231 = load i64, ptr %t230, !tbaa !24
  %t232 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d135, i32 0, i32 1) }, 1
  %t233 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d135, i32 0, i32 1) }, 0
  %t235 = call i64 @__olang_fmt_i64(ptr null, i64 %t231)
  %t236 = add i64 %t233, %t235
  %t237 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d136, i32 0, i32 1) }, 1
  %t238 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d136, i32 0, i32 1) }, 0
  %t239 = add i64 %t236, %t238
  %t240 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t239)
  call void @olang_textcopy(ptr %t240, ptr %t232, i64 %t233)
  %t241 = getelementptr i8, ptr %t240, i64 %t233
  %t242 = call i64 @__olang_fmt_i64(ptr %t241, i64 %t231)
  %t243 = getelementptr i8, ptr %t241, i64 %t235
  call void @olang_textcopy(ptr %t243, ptr %t237, i64 %t238)
  %t244 = insertvalue { i64, ptr } undef, i64 %t239, 0
  %t245 = insertvalue { i64, ptr } %t244, ptr %t240, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s8, ptr %l10, { i64, ptr } %t245)
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s8)
  br label %bb47
bb46:
  br label %bb47
bb47:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l10, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d137, i32 0, i32 1) })
  br label %bb48
bb48:
  store ptr %l10, ptr %l101, !tbaa !29
  %t250 = load ptr, ptr %l9, !tbaa !29
  %t252 = getelementptr %"compiler/emit:fnEm", ptr %t250, i32 0, i32 3
  %t254 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %t252)
  store { i64, ptr } %t254, ptr %l104
  br label %bb49
bb49:
  %t255 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t256 = load ptr, ptr %l101, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t256, { i64, ptr } %t255)
  br label %bb50
bb50:
  store ptr %l10, ptr %l106, !tbaa !29
  %t258 = load ptr, ptr %l9, !tbaa !29
  %t260 = getelementptr %"compiler/emit:fnEm", ptr %t258, i32 0, i32 4
  %t262 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %t260)
  store { i64, ptr } %t262, ptr %l109
  br label %bb51
bb51:
  %t263 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t264 = load ptr, ptr %l106, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t264, { i64, ptr } %t263)
  br label %bb52
bb52:
  %t266 = load ptr, ptr %l9, !tbaa !29
  %t268 = getelementptr %"compiler/emit:fnEm", ptr %t266, i32 0, i32 18
  %t269 = load i64, ptr %t268, !tbaa !24
  %t271 = icmp sge i64 %t269, 0
  br i1 %t271, label %bb53, label %bb54
bb53:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/emit:Emitter", ptr %t273, i32 0, i32 5
  %t276 = load i1, ptr %t275, !tbaa !21
  store i1 %t276, ptr %l114, !tbaa !21
  br label %bb55
bb54:
  store i1 false, ptr %l114, !tbaa !21
  br label %bb55
bb55:
  %t278 = load i1, ptr %l114, !tbaa !21
  br i1 %t278, label %bb56, label %bb57
bb56:
  %t279 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2edeclareVars(ptr %s0, ptr %s0, ptr %v0, ptr %v1, ptr %t279, ptr %l10)
  br label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb59
bb59:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l10, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d138, i32 0, i32 1) })
  br label %bb60
bb60:
  store ptr %l10, ptr %l120, !tbaa !29
  %t283 = load ptr, ptr %l9, !tbaa !29
  %t285 = getelementptr %"compiler/emit:fnEm", ptr %t283, i32 0, i32 5
  %t287 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %t285)
  store { i64, ptr } %t287, ptr %l123
  br label %bb61
bb61:
  %t288 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t289 = load ptr, ptr %l120, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t289, { i64, ptr } %t288)
  br label %bb62
bb62:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l10, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d139, i32 0, i32 1) })
  br label %bb63
bb63:
  store ptr %l10, ptr %l126, !tbaa !29
  %t292 = load ptr, ptr %l9, !tbaa !29
  %t294 = getelementptr %"compiler/emit:fnEm", ptr %t292, i32 0, i32 22
  %t296 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %t294)
  store { i64, ptr } %t296, ptr %l129
  br label %bb64
bb64:
  %t297 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t298 = load ptr, ptr %l126, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t298, { i64, ptr } %t297)
  br label %bb65
bb65:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l10, i8 10)
  br label %bb66
bb66:
  %t301 = load ptr, ptr %l9, !tbaa !29
  %t303 = getelementptr %"compiler/emit:fnEm", ptr %t301, i32 0, i32 29
  %t304 = load i1, ptr %t303, !tbaa !21
  br i1 %t304, label %bb67, label %bb68
bb67:
  store %olang.scope zeroinitializer, ptr %s12
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load { i64, [2 x i64] }, ptr %l1
  %t308 = load ptr, ptr %l2, !tbaa !29
  %t309 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t310 = load i64, ptr %l4, !tbaa !24
  %t311 = load ptr, ptr %l9, !tbaa !29
  %t313 = getelementptr %"compiler/emit:fnEm", ptr %t311, i32 0, i32 30
  %t314 = load { i64, ptr }, ptr %t313, !tbaa !27
  %t321 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenNext(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %s12, ptr %t306, { i64, [2 x i64] } %t307, ptr %t308, { i64, ptr } %t309, i64 %t310, { i64, ptr } %t314, i1 false)
  store { i64, ptr } %t321, ptr %l141
  br label %bb69
bb68:
  br label %bb79
bb69:
  %t322 = load { i64, ptr }, ptr %l141, !tbaa !27
  store { i64, ptr } %t322, ptr %l11, !tbaa !27
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load { i64, [2 x i64] }, ptr %l1
  %t325 = load ptr, ptr %l2, !tbaa !29
  %t326 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t327 = load i64, ptr %l4, !tbaa !24
  %t328 = load ptr, ptr %l9, !tbaa !29
  %t330 = getelementptr %"compiler/emit:fnEm", ptr %t328, i32 0, i32 30
  %t331 = load { i64, ptr }, ptr %t330, !tbaa !27
  %t338 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenNext(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %s12, ptr %t323, { i64, [2 x i64] } %t324, ptr %t325, { i64, ptr } %t326, i64 %t327, { i64, ptr } %t331, i1 true)
  store { i64, ptr } %t338, ptr %l149
  br label %bb70
bb70:
  %t339 = load { i64, ptr }, ptr %l149, !tbaa !27
  store { i64, ptr } %t339, ptr %l12, !tbaa !27
  %t340 = load ptr, ptr %l0, !tbaa !29
  %t341 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t342 = load ptr, ptr %l9, !tbaa !29
  %t344 = getelementptr %"compiler/emit:fnEm", ptr %t342, i32 0, i32 30
  %t345 = load { i64, ptr }, ptr %t344, !tbaa !27
  %t349 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenDrop(ptr %v0, ptr %v2, ptr %s0, ptr %s12, ptr %t340, { i64, ptr } %t341, { i64, ptr } %t345)
  store { i64, ptr } %t349, ptr %l154
  br label %bb71
bb71:
  %t350 = load { i64, ptr }, ptr %l154, !tbaa !27
  store { i64, ptr } %t350, ptr %l13, !tbaa !27
  %t351 = load ptr, ptr %l0, !tbaa !29
  store ptr %t351, ptr %l155, !tbaa !29
  %t352 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t352, ptr %l156
  %t353 = load ptr, ptr %l2, !tbaa !29
  %t355 = getelementptr %"compiler/mir:Fn", ptr %t353, i32 0, i32 1
  %t356 = load i32, ptr %t355, !tbaa !23
  store i32 %t356, ptr %l158, !tbaa !23
  %t357 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t357, ptr %l159, !tbaa !27
  %t358 = load i64, ptr %l4, !tbaa !24
  store i64 %t358, ptr %l160, !tbaa !24
  %t359 = load i1, ptr %l5, !tbaa !21
  store i1 %t359, ptr %l161, !tbaa !21
  %t360 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t360, ptr %l162, !tbaa !27
  %t361 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t361, ptr %l163, !tbaa !27
  %t362 = call ptr @__olang_scope_hold(ptr %s12)
  %t363 = ptrtoint ptr %t362 to i64
  store i64 %t363, ptr %l164, !tbaa !24
  %t364 = load i1, ptr @olang_2esole_2estd_2fprelude_2ftext_3aLineIter_2e0
  br i1 %t364, label %bb72, label %bb73
bb72:
  %t366 = call ptr @__olang_region_make(ptr %s12)
  %t367 = ptrtoint ptr %t366 to i64
  store i64 %t367, ptr %l164, !tbaa !24
  br label %bb73
bb73:
  %t368 = load i64, ptr %l164
  %t369 = inttoptr i64 %t368 to ptr
  %t371 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %t369, ptr %l10)
  store { i64, ptr } %t371, ptr %l167
  br label %bb74
bb74:
  %t372 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t373 = load i64, ptr %l164
  %t374 = inttoptr i64 %t373 to ptr
  %t375 = extractvalue { i64, ptr } %t372, 0
  %t376 = extractvalue { i64, ptr } %t372, 1
  %t377 = mul i64 %t375, 1
  %t378 = call ptr @__olang_held_alloc(ptr %t374, i64 %t377)
  call void @llvm.memcpy.p0.p0.i64(ptr %t378, ptr %t376, i64 %t377, i1 false)
  %t379 = insertvalue { i64, ptr } undef, i64 %t375, 0
  %t380 = insertvalue { i64, ptr } %t379, ptr %t378, 1
  store { i64, ptr } %t380, ptr %l168, !tbaa !27
  %t381 = load ptr, ptr %l2, !tbaa !29
  %t383 = getelementptr %"compiler/mir:Fn", ptr %t381, i32 0, i32 7
  %t385 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %v1, ptr %t383)
  store i64 %t385, ptr %l171
  br label %bb75
bb75:
  %t386 = load i64, ptr %l164
  %t387 = inttoptr i64 %t386 to ptr
  %t388 = load i64, ptr %l164
  %t389 = inttoptr i64 %t388 to ptr
  %t390 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t391 = load i64, ptr %l171, !tbaa !24
  %t392 = call { i64, ptr } @compiler_2femit_2efoldSlots(ptr %t387, ptr %t389, { i64, ptr } %t390, i64 %t391)
  store { i64, ptr } %t392, ptr %l172
  br label %bb76
bb76:
  %t393 = load { i64, ptr }, ptr %l172, !tbaa !27
  %t395 = call { i64, ptr } @compiler_2femit_2eframeKept(ptr %s12, ptr %s12, { i64, ptr } %t393)
  store { i64, ptr } %t395, ptr %l174
  br label %bb77
bb77:
  %t396 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t397 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t398 = extractvalue { i64, ptr } %t397, 1
  %t399 = extractvalue { i64, ptr } %t397, 0
  %t400 = load { i64, ptr }, ptr %l163, !tbaa !27
  %t401 = extractvalue { i64, ptr } %t400, 1
  %t402 = extractvalue { i64, ptr } %t400, 0
  %t403 = add i64 %t399, %t402
  %t404 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t405 = extractvalue { i64, ptr } %t404, 1
  %t406 = extractvalue { i64, ptr } %t404, 0
  %t407 = add i64 %t403, %t406
  %t409 = extractvalue { i64, ptr } %t396, 1
  %t410 = extractvalue { i64, ptr } %t396, 0
  %t411 = add i64 %t407, %t410
  %t412 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t411)
  call void @olang_textcopy(ptr %t412, ptr %t398, i64 %t399)
  %t413 = getelementptr i8, ptr %t412, i64 %t399
  call void @olang_textcopy(ptr %t413, ptr %t401, i64 %t402)
  %t414 = getelementptr i8, ptr %t413, i64 %t402
  call void @olang_textcopy(ptr %t414, ptr %t405, i64 %t406)
  %t415 = getelementptr i8, ptr %t414, i64 %t406
  call void @olang_textcopy(ptr %t415, ptr %t409, i64 %t410)
  %t416 = insertvalue { i64, ptr } undef, i64 %t411, 0
  %t417 = insertvalue { i64, ptr } %t416, ptr %t412, 1
  %t419 = load ptr, ptr %l155, !tbaa !29
  %t420 = load { i64, [2 x i64] }, ptr %l156
  %t421 = load i32, ptr %l158, !tbaa !23
  %t422 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t423 = load i64, ptr %l160, !tbaa !24
  %t424 = load i1, ptr %l161, !tbaa !21
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efnItem(ptr %v0, ptr %v2, ptr %s12, ptr %t419, { i64, [2 x i64] } %t420, i32 %t421, { i64, ptr } %t422, i64 %t423, i1 %t424, { i64, ptr } %t417)
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb79:
  %t427 = load ptr, ptr %l0, !tbaa !29
  store ptr %t427, ptr %l179, !tbaa !29
  %t428 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t428, ptr %l180
  %t429 = load ptr, ptr %l2, !tbaa !29
  %t431 = getelementptr %"compiler/mir:Fn", ptr %t429, i32 0, i32 1
  %t432 = load i32, ptr %t431, !tbaa !23
  store i32 %t432, ptr %l182, !tbaa !23
  %t433 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t433, ptr %l183, !tbaa !27
  %t434 = load i64, ptr %l4, !tbaa !24
  store i64 %t434, ptr %l184, !tbaa !24
  %t435 = load i1, ptr %l5, !tbaa !21
  store i1 %t435, ptr %l185, !tbaa !21
  %t437 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l10)
  store { i64, ptr } %t437, ptr %l187
  br label %bb80
bb80:
  %t438 = load { i64, ptr }, ptr %l187, !tbaa !27
  store { i64, ptr } %t438, ptr %l188, !tbaa !27
  %t439 = load ptr, ptr %l2, !tbaa !29
  %t441 = getelementptr %"compiler/mir:Fn", ptr %t439, i32 0, i32 7
  %t443 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %v1, ptr %t441)
  store i64 %t443, ptr %l191
  br label %bb81
bb81:
  %t444 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t445 = load i64, ptr %l191, !tbaa !24
  %t446 = call { i64, ptr } @compiler_2femit_2efoldSlots(ptr %s0, ptr %s0, { i64, ptr } %t444, i64 %t445)
  store { i64, ptr } %t446, ptr %l192
  br label %bb82
bb82:
  %t447 = load { i64, ptr }, ptr %l192, !tbaa !27
  %t448 = load ptr, ptr %l179, !tbaa !29
  %t449 = load { i64, [2 x i64] }, ptr %l180
  %t450 = load i32, ptr %l182, !tbaa !23
  %t451 = load { i64, ptr }, ptr %l183, !tbaa !27
  %t452 = load i64, ptr %l184, !tbaa !24
  %t453 = load i1, ptr %l185, !tbaa !21
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efnItem(ptr %v0, ptr %v2, ptr %s0, ptr %t448, { i64, [2 x i64] } %t449, i32 %t450, { i64, ptr } %t451, i64 %t452, i1 %t453, { i64, ptr } %t447)
  br label %bb83
bb83:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ebuilderOpened(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i1
  %l11 = alloca ptr
  %l15 = alloca %"compiler/mir:ScopeInfo"
  %rv = alloca i64
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 20}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [21 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb10
bb5:
  %t18 = getelementptr %"compiler/emit:fnEm", ptr %a0, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/mir:Fn", ptr %t19, i32 0, i32 8
  store ptr %t21, ptr %l11, !tbaa !29
  %t22 = load i32, ptr %l2, !tbaa !23
  %t24 = sext i32 %t22 to i64
  %t25 = load ptr, ptr %l11, !tbaa !29
  %t26 = call ptr @__olang_scope_or(ptr %v2, ptr %t25)
  %t27 = call ptr @__olang_scope_hold(ptr %t26)
  %t28 = ptrtoint ptr %t27 to i64
  %t30 = inttoptr i64 %t28 to ptr
  %t31 = load ptr, ptr %l11, !tbaa !29
  %t33 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %t30, ptr %t31, i64 %t24)
  store %"compiler/mir:ScopeInfo" %t33, ptr %l15
  br label %bb6
bb6:
  %t34 = getelementptr %"compiler/mir:ScopeInfo", ptr %l15, i32 0, i32 0
  %t35 = load i32, ptr %t34, !range !{i32 0, i32 7}
  %t37 = trunc i64 6 to i32
  %t38 = icmp eq i32 %t35, %t37
  br i1 %t38, label %bb7, label %bb8
bb7:
  %t40 = load i32, ptr %l2, !tbaa !23
  %t42 = sext i32 %t40 to i64
  store i64 %t42, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb15
bb10:
  br i1 true, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_538eacb44f7c8f74_e1c936133deb4fd8)
  unreachable
bb15:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2ecCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/mir:Call" %a1, { i64, ptr } %a2, i32 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Call"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca i1
  %l9 = alloca %"compiler/cabi:Regs"
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"compiler/cabi:Way"
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca { i64, [4 x i64] }
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca %"compiler/cabi:Way"
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca { i64, [4 x i64] }
  %l32 = alloca i32
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l40 = alloca ptr
  %l43 = alloca i32
  %l44 = alloca %"std/prelude/text:StringBuilder"
  %l45 = alloca %"compiler/cabi:Regs"
  %l46 = alloca { i64, ptr }
  %l48 = alloca i32
  %l49 = alloca i64
  %l51 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l53 = alloca i64
  %l55 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l57 = alloca i64
  %l59 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l61 = alloca %"compiler/cabi:Way"
  %l65 = alloca i1
  %l71 = alloca ptr
  %l74 = alloca i1
  %l75 = alloca ptr
  %l77 = alloca ptr
  %l79 = alloca { i64, ptr }
  %l84 = alloca %"compiler/cabi:Way"
  %l85 = alloca %"compiler/cabi:Way"
  %l95 = alloca i64
  %l99 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l105 = alloca ptr
  %l108 = alloca { i64, ptr }
  %l109 = alloca ptr
  %l112 = alloca i64
  %l119 = alloca ptr
  %l120 = alloca ptr
  %l123 = alloca i32
  %l128 = alloca { i64, ptr }
  %l134 = alloca i64
  %l137 = alloca i64
  %l161 = alloca { i64, [4 x i64] }
  %l162 = alloca { i64, ptr }
  %l165 = alloca ptr
  %l168 = alloca i32
  %l169 = alloca ptr
  %l172 = alloca i32
  %l175 = alloca i1
  %l177 = alloca i1
  %l181 = alloca ptr
  %l182 = alloca ptr
  %l186 = alloca { i64, ptr }
  %l189 = alloca { i64, ptr }
  %l191 = alloca ptr
  %l194 = alloca i32
  %l200 = alloca ptr
  %l203 = alloca { i64, ptr }
  %l206 = alloca ptr
  %l209 = alloca i1
  %l210 = alloca i32
  %l211 = alloca ptr
  %l214 = alloca i32
  %l216 = alloca ptr
  %l219 = alloca i1
  %l220 = alloca i1
  %l221 = alloca ptr
  %l222 = alloca ptr
  %l225 = alloca i32
  %l227 = alloca i32
  %l235 = alloca i32
  %l236 = alloca ptr
  %l237 = alloca ptr
  %l241 = alloca { i64, ptr }
  %l244 = alloca { i64, ptr }
  %l248 = alloca ptr
  %l251 = alloca i1
  %l252 = alloca ptr
  %l254 = alloca ptr
  %l256 = alloca { i64, ptr }
  %l262 = alloca %"compiler/cabi:Way"
  %l278 = alloca i64
  %l281 = alloca i64
  %l305 = alloca { i64, [4 x i64] }
  %l308 = alloca i32
  %l309 = alloca ptr
  %l310 = alloca ptr
  %l314 = alloca { i64, ptr }
  %l317 = alloca { i64, ptr }
  %l323 = alloca ptr
  %l326 = alloca { i64, ptr }
  %l327 = alloca { i64, ptr }
  %l328 = alloca i64
  %l329 = alloca { i64, ptr }
  %l332 = alloca i1
  %l334 = alloca i1
  %l336 = alloca i64
  %l340 = alloca i64
  %l342 = alloca i64
  %l343 = alloca i64
  %l348 = alloca { i64, ptr }
  %l349 = alloca i64
  %l350 = alloca { i64, ptr }
  %l351 = alloca { i64, ptr }
  %l354 = alloca { i64, ptr }
  %l355 = alloca i64
  %l356 = alloca { i64, ptr }
  %l358 = alloca i64
  %l360 = alloca { i64, ptr }
  %l362 = alloca ptr
  %l365 = alloca { i64, ptr }
  %l369 = alloca { i64, ptr }
  %l370 = alloca { i64, ptr }
  %l374 = alloca { i64, ptr }
  %l376 = alloca { i64, ptr }
  %l379 = alloca i1
  %l380 = alloca ptr
  %l381 = alloca { i64, ptr }
  %l382 = alloca { i64, ptr }
  %l384 = alloca { i64, ptr }
  %l387 = alloca i64
  %l389 = alloca ptr
  %l390 = alloca { i64, ptr }
  %l391 = alloca { i64, ptr }
  %l393 = alloca { i64, ptr }
  %l396 = alloca { i64, ptr }
  %l400 = alloca { i64, ptr }
  %l407 = alloca i1
  %l418 = alloca ptr
  %l420 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s23 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/mir:Call" %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l5, !tbaa !29
  %t9 = load ptr, ptr %l5, !tbaa !29
  store ptr %t9, ptr %l40, !tbaa !29
  %t10 = load i32, ptr %l3, !tbaa !23
  %t11 = load ptr, ptr %l40, !tbaa !29
  %t12 = call ptr @__olang_scope_or(ptr %v2, ptr %t11)
  %t13 = call ptr @__olang_scope_hold(ptr %t12)
  %t14 = ptrtoint ptr %t13 to i64
  %t16 = inttoptr i64 %t14 to ptr
  %t17 = load ptr, ptr %l40, !tbaa !29
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %t16, ptr %t17, i32 %t10)
  store i32 %t19, ptr %l43
  br label %bb1
bb1:
  %t20 = load i32, ptr %l43, !tbaa !23
  store i32 %t20, ptr %l6, !tbaa !23
  %t21 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t21, ptr %l44
  br label %bb2
bb2:
  %t22 = load %"std/prelude/text:StringBuilder", ptr %l44
  store %"std/prelude/text:StringBuilder" %t22, ptr %l7
  store i1 true, ptr %l8, !tbaa !21
  %t23 = call %"compiler/cabi:Regs" @compiler_2fcabi_3aRegs_2ector(ptr %s0, i64 6, i64 8)
  store %"compiler/cabi:Regs" %t23, ptr %l45
  br label %bb3
bb3:
  %t24 = load %"compiler/cabi:Regs", ptr %l45
  store %"compiler/cabi:Regs" %t24, ptr %l9
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d140, i32 0, i32 1) }, ptr %l46, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t25, ptr %l10, !tbaa !27
  store i32 0, ptr %l48
  %t27 = call ptr @__olang_scope_hold(ptr %s0)
  %t28 = ptrtoint ptr %t27 to i64
  store i64 %t28, ptr %l49, !tbaa !24
  %t29 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e1
  br i1 %t29, label %bb4, label %bb5
bb4:
  %t31 = call ptr @__olang_region_make(ptr %s0)
  %t32 = ptrtoint ptr %t31 to i64
  store i64 %t32, ptr %l49, !tbaa !24
  br label %bb5
bb5:
  %t33 = load i64, ptr %l49
  %t34 = inttoptr i64 %t33 to ptr
  %t35 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t34, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %l51
  br label %bb6
bb6:
  %t36 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e1
  br i1 %t36, label %bb7, label %bb8
bb7:
  %t38 = load i64, ptr %l49
  %t39 = inttoptr i64 %t38 to ptr
  %t40 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l51, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40
  %t42 = extractvalue { i64, ptr } %t41, 1
  %t43 = call ptr @__olang_region_or(ptr %t42, ptr null)
  %t44 = call ptr @__olang_region_home(ptr %t43)
  %t45 = icmp ne ptr %t44, null
  %t46 = select i1 %t45, ptr %t44, ptr null
  call void @__olang_region_settle_in(ptr %t39, ptr %t46)
  br label %bb8
bb8:
  %t47 = call ptr @__olang_scope_hold(ptr %s0)
  %t48 = ptrtoint ptr %t47 to i64
  store i64 %t48, ptr %l53, !tbaa !24
  %t49 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e2
  br i1 %t49, label %bb9, label %bb10
bb9:
  %t51 = call ptr @__olang_region_make(ptr %s0)
  %t52 = ptrtoint ptr %t51 to i64
  store i64 %t52, ptr %l53, !tbaa !24
  br label %bb10
bb10:
  %t53 = load i64, ptr %l53
  %t54 = inttoptr i64 %t53 to ptr
  %t55 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t54, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t55, ptr %l55
  br label %bb11
bb11:
  %t56 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e2
  br i1 %t56, label %bb12, label %bb13
bb12:
  %t58 = load i64, ptr %l53
  %t59 = inttoptr i64 %t58 to ptr
  %t60 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l55, i32 0, i32 0
  %t61 = load { i64, ptr }, ptr %t60
  %t62 = extractvalue { i64, ptr } %t61, 1
  %t63 = call ptr @__olang_region_or(ptr %t62, ptr null)
  %t64 = call ptr @__olang_region_home(ptr %t63)
  %t65 = icmp ne ptr %t64, null
  %t66 = select i1 %t65, ptr %t64, ptr null
  call void @__olang_region_settle_in(ptr %t59, ptr %t66)
  br label %bb13
bb13:
  %t67 = call ptr @__olang_scope_hold(ptr %s0)
  %t68 = ptrtoint ptr %t67 to i64
  store i64 %t68, ptr %l57, !tbaa !24
  %t69 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e3
  br i1 %t69, label %bb14, label %bb15
bb14:
  %t71 = call ptr @__olang_region_make(ptr %s0)
  %t72 = ptrtoint ptr %t71 to i64
  store i64 %t72, ptr %l57, !tbaa !24
  br label %bb15
bb15:
  %t73 = load i64, ptr %l57
  %t74 = inttoptr i64 %t73 to ptr
  %t75 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t74, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t75, ptr %l59
  br label %bb16
bb16:
  %t76 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e3
  br i1 %t76, label %bb17, label %bb18
bb17:
  %t78 = load i64, ptr %l57
  %t79 = inttoptr i64 %t78 to ptr
  %t80 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l59, i32 0, i32 0
  %t81 = load { i64, ptr }, ptr %t80
  %t82 = extractvalue { i64, ptr } %t81, 1
  %t83 = call ptr @__olang_region_or(ptr %t82, ptr null)
  %t84 = call ptr @__olang_region_home(ptr %t83)
  %t85 = icmp ne ptr %t84, null
  %t86 = select i1 %t85, ptr %t84, ptr null
  call void @__olang_region_settle_in(ptr %t79, ptr %t86)
  br label %bb18
bb18:
  %t87 = load i32, ptr %l48, !range !{i32 0, i32 5}
  %t88 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l51
  %t89 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l55
  %t90 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l59
  %t91 = call %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, i32 %t87, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t88, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t89, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t90, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d141, i32 0, i32 1) })
  store %"compiler/cabi:Way" %t91, ptr %l61
  br label %bb19
bb19:
  %t92 = load %"compiler/cabi:Way", ptr %l61
  store %"compiler/cabi:Way" %t92, ptr %l11
  %t93 = load i32, ptr %l6, !tbaa !23
  %t94 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t97 = icmp ne i32 %t93, %t94
  br i1 %t97, label %bb20, label %bb21
bb20:
  %t99 = load i32, ptr %l6, !tbaa !23
  %t100 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t103 = icmp ne i32 %t99, %t100
  store i1 %t103, ptr %l65, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb22
bb22:
  %t105 = load i1, ptr %l65, !tbaa !21
  br i1 %t105, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s1
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/emit:fnEm", ptr %t106, i32 0, i32 0
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/emit:Emitter", ptr %t109, i32 0, i32 0
  %t112 = load ptr, ptr %t111, !tbaa !29
  store ptr %t112, ptr %l71, !tbaa !29
  %t113 = load i32, ptr %l6, !tbaa !23
  %t114 = load ptr, ptr %l71, !tbaa !29
  %t115 = call ptr @__olang_scope_or(ptr %v2, ptr %t114)
  %t116 = call ptr @__olang_scope_hold(ptr %t115)
  %t117 = ptrtoint ptr %t116 to i64
  %t119 = inttoptr i64 %t117 to ptr
  %t120 = load ptr, ptr %l71, !tbaa !29
  %t122 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %t119, ptr %t120, i32 %t113)
  store i1 %t122, ptr %l74
  br label %bb25
bb24:
  br label %bb57
bb25:
  %t123 = load ptr, ptr %l5, !tbaa !29
  store ptr %t123, ptr %l75, !tbaa !29
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/emit:fnEm", ptr %t124, i32 0, i32 0
  %t127 = load ptr, ptr %t126, !tbaa !29
  store ptr %t127, ptr %l77, !tbaa !29
  %t128 = load ptr, ptr %l77, !tbaa !29
  %t129 = call ptr @__olang_scope_or(ptr %v2, ptr %t128)
  %t130 = call ptr @__olang_scope_hold(ptr %t129)
  %t131 = ptrtoint ptr %t130 to i64
  %t133 = inttoptr i64 %t131 to ptr
  %t134 = load ptr, ptr %l77, !tbaa !29
  %t135 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eabiArch(ptr %t133, ptr %s1, ptr %t134)
  store { i64, ptr } %t135, ptr %l79
  br label %bb26
bb26:
  %t136 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t137 = load i32, ptr %l6, !tbaa !23
  %t138 = load ptr, ptr %l75, !tbaa !29
  %t139 = call ptr @__olang_scope_or(ptr %v2, ptr %t138)
  %t140 = call ptr @__olang_scope_hold(ptr %t139)
  %t141 = ptrtoint ptr %t140 to i64
  %t143 = inttoptr i64 %t141 to ptr
  %t145 = inttoptr i64 0 to ptr
  %t146 = load ptr, ptr %l75, !tbaa !29
  %t149 = call %"compiler/cabi:Way" @compiler_2fcabi_2eWay_2eResult(ptr %t143, ptr %s1, ptr %s0, ptr %t145, ptr %t146, { i64, ptr } %t136, i32 %t137)
  store %"compiler/cabi:Way" %t149, ptr %l84
  br label %bb27
bb27:
  %t150 = load %"compiler/cabi:Way", ptr %l11
  store %"compiler/cabi:Way" %t150, ptr %l85
  %t151 = load %"compiler/cabi:Way", ptr %l84
  store %"compiler/cabi:Way" %t151, ptr %l11
  %t152 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e1
  br i1 %t152, label %bb28, label %bb29
bb28:
  %t154 = getelementptr %"compiler/cabi:Way", ptr %l85, i32 0, i32 1
  %t155 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t154, i32 0, i32 0
  %t156 = load { i64, ptr }, ptr %t155
  %t157 = extractvalue { i64, ptr } %t156, 1
  %t158 = call ptr @__olang_region_or(ptr %t157, ptr null)
  %t159 = call ptr @__olang_region_home(ptr %t158)
  %t160 = icmp ne ptr %t159, null
  %t161 = select i1 %t160, ptr %t159, ptr null
  call void @__olang_region_drop(ptr %t161)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %t154
  br label %bb29
bb29:
  %t162 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t162, label %bb30, label %bb31
bb30:
  %t164 = getelementptr %"compiler/cabi:Way", ptr %l85, i32 0, i32 1
  %t165 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t164, i32 0, i32 0
  %t166 = load { i64, ptr }, ptr %t165
  %t167 = extractvalue { i64, ptr } %t166, 0
  %t168 = extractvalue { i64, ptr } %t166, 1
  call void @__olang_region_release_part(ptr %t168, i64 %t167)
  store { i64, ptr } zeroinitializer, ptr %t165
  br label %bb31
bb31:
  %t169 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e2
  br i1 %t169, label %bb32, label %bb33
bb32:
  %t171 = getelementptr %"compiler/cabi:Way", ptr %l85, i32 0, i32 2
  %t172 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t171, i32 0, i32 0
  %t173 = load { i64, ptr }, ptr %t172
  %t174 = extractvalue { i64, ptr } %t173, 1
  %t175 = call ptr @__olang_region_or(ptr %t174, ptr null)
  %t176 = call ptr @__olang_region_home(ptr %t175)
  %t177 = icmp ne ptr %t176, null
  %t178 = select i1 %t177, ptr %t176, ptr null
  call void @__olang_region_drop(ptr %t178)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %t171
  br label %bb33
bb33:
  %t179 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t179, label %bb34, label %bb35
bb34:
  %t181 = getelementptr %"compiler/cabi:Way", ptr %l85, i32 0, i32 2
  %t182 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t181, i32 0, i32 0
  %t183 = load { i64, ptr }, ptr %t182
  %t184 = extractvalue { i64, ptr } %t183, 0
  %t185 = extractvalue { i64, ptr } %t183, 1
  call void @__olang_region_release_part(ptr %t185, i64 %t184)
  store { i64, ptr } zeroinitializer, ptr %t182
  br label %bb35
bb35:
  %t186 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e3
  br i1 %t186, label %bb36, label %bb37
bb36:
  %t188 = getelementptr %"compiler/cabi:Way", ptr %l85, i32 0, i32 3
  %t189 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t188, i32 0, i32 0
  %t190 = load { i64, ptr }, ptr %t189
  %t191 = extractvalue { i64, ptr } %t190, 1
  %t192 = call ptr @__olang_region_or(ptr %t191, ptr null)
  %t193 = call ptr @__olang_region_home(ptr %t192)
  %t194 = icmp ne ptr %t193, null
  %t195 = select i1 %t194, ptr %t193, ptr null
  call void @__olang_region_drop(ptr %t195)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %t188
  br label %bb37
bb37:
  %t196 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t196, label %bb38, label %bb39
bb38:
  %t198 = getelementptr %"compiler/cabi:Way", ptr %l85, i32 0, i32 3
  %t199 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t198, i32 0, i32 0
  %t200 = load { i64, ptr }, ptr %t199
  %t201 = extractvalue { i64, ptr } %t200, 0
  %t202 = extractvalue { i64, ptr } %t200, 1
  call void @__olang_region_release_part(ptr %t202, i64 %t201)
  store { i64, ptr } zeroinitializer, ptr %t199
  br label %bb39
bb39:
  %t203 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e4
  br i1 %t203, label %bb40, label %bb41
bb40:
  %t205 = getelementptr %"compiler/cabi:Way", ptr %l85, i32 0, i32 4
  %t206 = load { i64, ptr }, ptr %t205
  %t207 = extractvalue { i64, ptr } %t206, 1
  call void @__olang_region_release(ptr %t207)
  store { i64, ptr } zeroinitializer, ptr %t205
  br label %bb41
bb41:
  %t208 = getelementptr %"compiler/cabi:Way", ptr %l11, i32 0, i32 0
  %t209 = load i32, ptr %t208, !range !{i32 0, i32 5}
  %t211 = trunc i64 4 to i32
  %t212 = icmp eq i32 %t209, %t211
  br i1 %t212, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s2
  %t214 = call ptr @__olang_scope_hold(ptr %s0)
  %t215 = ptrtoint ptr %t214 to i64
  store i64 %t215, ptr %l95, !tbaa !24
  %t216 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ecCall_2elocal_2e10
  br i1 %t216, label %bb44, label %bb45
bb43:
  br label %bb56
bb44:
  %t218 = call ptr @__olang_region_make(ptr %s0)
  %t219 = ptrtoint ptr %t218 to i64
  store i64 %t219, ptr %l95, !tbaa !24
  br label %bb45
bb45:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load i32, ptr %l6, !tbaa !23
  %t222 = load i64, ptr %l95
  %t223 = inttoptr i64 %t222 to ptr
  %t226 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eslot(ptr %v0, ptr %t223, ptr %v2, ptr %t220, i32 %t221)
  store { i64, ptr } %t226, ptr %l99
  br label %bb46
bb46:
  %t227 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ecCall_2elocal_2e10
  br i1 %t227, label %bb47, label %bb48
bb47:
  %t229 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t229, 0
  %t232 = icmp eq i64 %t230, 0
  br i1 %t232, label %bb49, label %bb50
bb48:
  %t234 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t234, ptr %l103, !tbaa !27
  %t235 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t235, ptr %l10, !tbaa !27
  %t236 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ecCall_2elocal_2e10
  br i1 %t236, label %bb51, label %bb52
bb49:
  store { i64, ptr } zeroinitializer, ptr %l99, !tbaa !27
  br label %bb50
bb50:
  %t238 = load i64, ptr %l95
  %t239 = inttoptr i64 %t238 to ptr
  %t240 = load { i64, ptr }, ptr %l99
  %t241 = extractvalue { i64, ptr } %t240, 1
  %t242 = call ptr @__olang_region_or(ptr %t241, ptr null)
  %t243 = icmp ne ptr %t242, null
  %t244 = select i1 %t243, ptr %t242, ptr null
  call void @__olang_region_settle_in(ptr %t239, ptr %t244)
  br label %bb48
bb51:
  %t245 = load { i64, ptr }, ptr %l103
  %t246 = extractvalue { i64, ptr } %t245, 1
  call void @__olang_region_release(ptr %t246)
  store { i64, ptr } zeroinitializer, ptr %l103
  br label %bb52
bb52:
  store ptr %l7, ptr %l105, !tbaa !29
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load i32, ptr %l6, !tbaa !23
  %t251 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s2, ptr %v2, ptr %t247, i32 %t248)
  store { i64, ptr } %t251, ptr %l108
  br label %bb53
bb53:
  %t252 = load ptr, ptr %l5, !tbaa !29
  store ptr %t252, ptr %l109, !tbaa !29
  %t253 = load i32, ptr %l6, !tbaa !23
  %t254 = load ptr, ptr %l109, !tbaa !29
  %t255 = call ptr @__olang_scope_or(ptr %v2, ptr %t254)
  %t256 = call ptr @__olang_scope_hold(ptr %t255)
  %t257 = ptrtoint ptr %t256 to i64
  %t259 = inttoptr i64 %t257 to ptr
  %t260 = load ptr, ptr %l109, !tbaa !29
  %t262 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %t259, ptr %t260, i32 %t253)
  store i64 %t262, ptr %l112
  br label %bb54
bb54:
  %t263 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t264 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d142, i32 0, i32 1) }, 1
  %t265 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d142, i32 0, i32 1) }, 0
  %t266 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t267 = extractvalue { i64, ptr } %t266, 1
  %t268 = extractvalue { i64, ptr } %t266, 0
  %t269 = add i64 %t265, %t268
  %t270 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d143, i32 0, i32 1) }, 1
  %t271 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d143, i32 0, i32 1) }, 0
  %t272 = add i64 %t269, %t271
  %t273 = load i64, ptr %l112, !tbaa !24
  %t274 = call i64 @__olang_fmt_i64(ptr null, i64 %t273)
  %t275 = add i64 %t272, %t274
  %t276 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d144, i32 0, i32 1) }, 1
  %t277 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d144, i32 0, i32 1) }, 0
  %t278 = add i64 %t275, %t277
  %t280 = extractvalue { i64, ptr } %t263, 1
  %t281 = extractvalue { i64, ptr } %t263, 0
  %t282 = add i64 %t278, %t281
  %t283 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t282)
  call void @olang_textcopy(ptr %t283, ptr %t264, i64 %t265)
  %t284 = getelementptr i8, ptr %t283, i64 %t265
  call void @olang_textcopy(ptr %t284, ptr %t267, i64 %t268)
  %t285 = getelementptr i8, ptr %t284, i64 %t268
  call void @olang_textcopy(ptr %t285, ptr %t270, i64 %t271)
  %t286 = getelementptr i8, ptr %t285, i64 %t271
  %t287 = call i64 @__olang_fmt_i64(ptr %t286, i64 %t273)
  %t288 = getelementptr i8, ptr %t286, i64 %t274
  call void @olang_textcopy(ptr %t288, ptr %t276, i64 %t277)
  %t289 = getelementptr i8, ptr %t288, i64 %t277
  call void @olang_textcopy(ptr %t289, ptr %t280, i64 %t281)
  %t290 = insertvalue { i64, ptr } undef, i64 %t282, 0
  %t291 = insertvalue { i64, ptr } %t290, ptr %t283, 1
  %t293 = load ptr, ptr %l105, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t293, { i64, ptr } %t291)
  br label %bb55
bb55:
  store i1 false, ptr %l8, !tbaa !21
  %t295 = getelementptr %"compiler/cabi:Regs", ptr %l9, i32 0, i32 0
  %t296 = load i64, ptr %t295, !tbaa !24
  %t299 = sub i64 %t296, 1
  %t301 = getelementptr %"compiler/cabi:Regs", ptr %l9, i32 0, i32 0
  store i64 %t299, ptr %t301, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s1)
  br label %bb57
bb57:
  %t302 = load ptr, ptr %l5, !tbaa !29
  store ptr %t302, ptr %l119, !tbaa !29
  %t303 = load ptr, ptr %l5, !tbaa !29
  store ptr %t303, ptr %l120, !tbaa !29
  %t304 = load i32, ptr %l3, !tbaa !23
  %t305 = load ptr, ptr %l120, !tbaa !29
  %t306 = call ptr @__olang_scope_or(ptr %v2, ptr %t305)
  %t307 = call ptr @__olang_scope_hold(ptr %t306)
  %t308 = ptrtoint ptr %t307 to i64
  %t310 = inttoptr i64 %t308 to ptr
  %t311 = load ptr, ptr %l120, !tbaa !29
  %t313 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %t310, ptr %t311, i32 %t304)
  store i32 %t313, ptr %l123
  br label %bb58
bb58:
  %t314 = load ptr, ptr %l119, !tbaa !29
  %t315 = call ptr @__olang_scope_or(ptr %v2, ptr %t314)
  %t316 = call ptr @__olang_scope_hold(ptr %t315)
  %t317 = ptrtoint ptr %t316 to i64
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t320 = getelementptr %"compiler/emit:fnEm", ptr %t318, i32 0, i32 0
  %t321 = load ptr, ptr %t320, !tbaa !29
  %t323 = call ptr @__olang_scope_or(ptr %v2, ptr %t321)
  %t324 = call ptr @__olang_scope_hold(ptr %t323)
  %t325 = ptrtoint ptr %t324 to i64
  %t327 = inttoptr i64 %t317 to ptr
  %t329 = inttoptr i64 %t325 to ptr
  %t330 = load ptr, ptr %l119, !tbaa !29
  %t331 = load i32, ptr %l123, !tbaa !23
  %t332 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t327, ptr %t329, ptr %t330, i32 %t331)
  store { i64, ptr } %t332, ptr %l128
  br label %bb59
bb59:
  %t333 = load { i64, ptr }, ptr %l128, !tbaa !27
  store { i64, ptr } %t333, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t334 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t336 = extractvalue { i64, ptr } %t334, 0
  store i64 %t336, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t338 = load i64, ptr %l14, !tbaa !24
  %t339 = load i64, ptr %l13, !tbaa !24
  %t342 = icmp sgt i64 %t338, %t339
  br i1 %t342, label %bb60, label %bb61
bb60:
  %t344 = load i64, ptr %l15, !tbaa !24
  %t346 = icmp sgt i64 %t344, 0
  br i1 %t346, label %bb62, label %bb63
bb61:
  store i64 0, ptr %l134, !tbaa !24
  br label %bb65
bb62:
  %t348 = load i64, ptr %l14, !tbaa !24
  %t349 = load i64, ptr %l13, !tbaa !24
  %t352 = sub i64 %t348, %t349
  %t353 = load i64, ptr %l15, !tbaa !24
  %t356 = add i64 %t352, %t353
  %t358 = sub i64 %t356, 1
  %t359 = load i64, ptr %l15, !tbaa !24
  %t362 = sdiv i64 %t358, %t359
  store i64 %t362, ptr %l137, !tbaa !24
  br label %bb64
bb63:
  store i64 0, ptr %l137, !tbaa !24
  br label %bb64
bb64:
  %t364 = load i64, ptr %l137, !tbaa !24
  store i64 %t364, ptr %l134, !tbaa !24
  br label %bb65
bb65:
  %t365 = load i64, ptr %l134, !tbaa !24
  store i64 %t365, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb66
bb66:
  store %olang.scope zeroinitializer, ptr %s5
  %t366 = load i64, ptr %l17, !tbaa !24
  %t367 = load i64, ptr %l16, !tbaa !24
  %t370 = icmp slt i64 %t366, %t367
  %t372 = xor i1 %t370, true
  br i1 %t372, label %bb67, label %bb68
bb67:
  call void @__olang_scope_close(ptr %s5)
  br label %bb116
bb68:
  br label %bb69
bb69:
  %t374 = load i64, ptr %l13, !tbaa !24
  %t375 = load i64, ptr %l17, !tbaa !24
  %t376 = load i64, ptr %l15, !tbaa !24
  %t379 = mul i64 %t375, %t376
  %t382 = add i64 %t374, %t379
  store i64 %t382, ptr %l18, !tbaa !24
  %t384 = load i1, ptr %l8, !tbaa !21
  %t386 = xor i1 %t384, true
  br i1 %t386, label %bb70, label %bb71
bb70:
  store %olang.scope zeroinitializer, ptr %s6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %l7, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d145, i32 0, i32 1) })
  br label %bb72
bb71:
  br label %bb73
bb72:
  call void @__olang_scope_close(ptr %s6)
  br label %bb73
bb73:
  store i1 false, ptr %l8, !tbaa !21
  %t389 = load ptr, ptr %l0, !tbaa !29
  %t390 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 1
  %t391 = load %"compiler/mir:Range", ptr %t390
  %t392 = load i64, ptr %l18, !tbaa !24
  %t396 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %v3, ptr %t389, %"compiler/mir:Range" %t391, i64 %t392)
  store { i64, [4 x i64] } %t396, ptr %l161
  br label %bb74
bb74:
  %t397 = load { i64, [4 x i64] }, ptr %l161
  store { i64, [4 x i64] } %t397, ptr %l19
  %t398 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t398, ptr %l162, !tbaa !27
  %t399 = load i64, ptr %l18, !tbaa !24
  %t401 = getelementptr { i64, ptr }, ptr %l162, i32 0, i32 1
  %t402 = load ptr, ptr %t401, !tbaa !27
  %t403 = getelementptr i32, ptr %t402, i64 %t399
  %t404 = load i32, ptr %t403, !tbaa !33
  store i32 %t404, ptr %l20, !tbaa !23
  %t406 = load ptr, ptr %l5, !tbaa !29
  store ptr %t406, ptr %l165, !tbaa !29
  %t407 = load i32, ptr %l20, !tbaa !23
  %t408 = load ptr, ptr %l165, !tbaa !29
  %t409 = call ptr @__olang_scope_or(ptr %v2, ptr %t408)
  %t410 = call ptr @__olang_scope_hold(ptr %t409)
  %t411 = ptrtoint ptr %t410 to i64
  %t413 = inttoptr i64 %t411 to ptr
  %t414 = load ptr, ptr %l165, !tbaa !29
  %t416 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t413, ptr %t414, i32 %t407)
  store i32 %t416, ptr %l168
  br label %bb75
bb75:
  %t417 = load i32, ptr %l168, !tbaa !23
  store i32 %t417, ptr %l21, !tbaa !23
  %t418 = load ptr, ptr %l5, !tbaa !29
  store ptr %t418, ptr %l169, !tbaa !29
  %t419 = load i32, ptr %l21, !tbaa !23
  %t420 = load ptr, ptr %l169, !tbaa !29
  %t421 = call ptr @__olang_scope_or(ptr %v2, ptr %t420)
  %t422 = call ptr @__olang_scope_hold(ptr %t421)
  %t423 = ptrtoint ptr %t422 to i64
  %t425 = inttoptr i64 %t423 to ptr
  %t426 = load ptr, ptr %l169, !tbaa !29
  %t428 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t425, ptr %t426, i32 %t419)
  store i32 %t428, ptr %l172
  br label %bb76
bb76:
  %t429 = load i32, ptr %l172, !range !{i32 0, i32 33}
  %t431 = trunc i64 21 to i32
  %t432 = icmp eq i32 %t429, %t431
  br i1 %t432, label %bb77, label %bb78
bb77:
  %t434 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t436 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s5, { i64, ptr } %t434, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d146, i32 0, i32 1) })
  store i1 %t436, ptr %l177
  br label %bb79
bb78:
  store i1 false, ptr %l175, !tbaa !21
  br label %bb80
bb79:
  %t437 = load i1, ptr %l177, !tbaa !21
  store i1 %t437, ptr %l175, !tbaa !21
  br label %bb80
bb80:
  %t438 = load i1, ptr %l175, !tbaa !21
  br i1 %t438, label %bb81, label %bb82
bb81:
  store %olang.scope zeroinitializer, ptr %s7
  %t439 = getelementptr %"compiler/cabi:Regs", ptr %l9, i32 0, i32 0
  %t440 = load i64, ptr %t439, !tbaa !24
  %t443 = sub i64 %t440, 2
  %t445 = getelementptr %"compiler/cabi:Regs", ptr %l9, i32 0, i32 0
  store i64 %t443, ptr %t445, !tbaa !24
  store ptr %l7, ptr %l181, !tbaa !29
  %t446 = load ptr, ptr %l0, !tbaa !29
  store ptr %t446, ptr %l182, !tbaa !29
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t448 = load { i64, [4 x i64] }, ptr %l19
  %t449 = load i32, ptr %l20, !tbaa !23
  %t453 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s7, ptr %v3, ptr %v2, ptr %t447, { i64, [4 x i64] } %t448, i32 %t449)
  store { i64, ptr } %t453, ptr %l186
  br label %bb83
bb82:
  br label %bb86
bb83:
  %t454 = load { i64, ptr }, ptr %l186, !tbaa !27
  %t455 = load i32, ptr %l20, !tbaa !23
  %t456 = load ptr, ptr %l182, !tbaa !29
  %t459 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eexternArg(ptr %v0, ptr %s7, ptr %s7, ptr %v2, ptr %t456, { i64, ptr } %t454, i32 %t455)
  store { i64, ptr } %t459, ptr %l189
  br label %bb84
bb84:
  %t460 = load { i64, ptr }, ptr %l189, !tbaa !27
  %t461 = load ptr, ptr %l181, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %t461, { i64, ptr } %t460)
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s5)
  br label %bb115
bb86:
  %t463 = load ptr, ptr %l5, !tbaa !29
  store ptr %t463, ptr %l191, !tbaa !29
  %t464 = load i32, ptr %l21, !tbaa !23
  %t465 = load ptr, ptr %l191, !tbaa !29
  %t466 = call ptr @__olang_scope_or(ptr %v2, ptr %t465)
  %t467 = call ptr @__olang_scope_hold(ptr %t466)
  %t468 = ptrtoint ptr %t467 to i64
  %t470 = inttoptr i64 %t468 to ptr
  %t471 = load ptr, ptr %l191, !tbaa !29
  %t473 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t470, ptr %t471, i32 %t464)
  store i32 %t473, ptr %l194
  br label %bb87
bb87:
  %t474 = load i32, ptr %l194, !range !{i32 0, i32 33}
  %t476 = trunc i64 21 to i32
  %t477 = icmp eq i32 %t474, %t476
  br i1 %t477, label %bb88, label %bb89
bb88:
  store %olang.scope zeroinitializer, ptr %s8
  %t479 = getelementptr %"compiler/cabi:Regs", ptr %l9, i32 0, i32 0
  %t480 = load i64, ptr %t479, !tbaa !24
  %t483 = sub i64 %t480, 1
  %t485 = getelementptr %"compiler/cabi:Regs", ptr %l9, i32 0, i32 0
  store i64 %t483, ptr %t485, !tbaa !24
  store ptr %l7, ptr %l200, !tbaa !29
  %t486 = load ptr, ptr %l0, !tbaa !29
  %t487 = load { i64, [4 x i64] }, ptr %l19
  %t490 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eexportNamed(ptr %v0, ptr %s8, ptr %v3, ptr %v2, ptr %t486, { i64, [4 x i64] } %t487)
  store { i64, ptr } %t490, ptr %l203
  br label %bb90
bb89:
  br label %bb92
bb90:
  %t491 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d147, i32 0, i32 1) }, 1
  %t492 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d147, i32 0, i32 1) }, 0
  %t493 = load { i64, ptr }, ptr %l203, !tbaa !27
  %t494 = extractvalue { i64, ptr } %t493, 1
  %t495 = extractvalue { i64, ptr } %t493, 0
  %t496 = add i64 %t492, %t495
  %t497 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t496)
  call void @olang_textcopy(ptr %t497, ptr %t491, i64 %t492)
  %t498 = getelementptr i8, ptr %t497, i64 %t492
  call void @olang_textcopy(ptr %t498, ptr %t494, i64 %t495)
  %t499 = insertvalue { i64, ptr } undef, i64 %t496, 0
  %t500 = insertvalue { i64, ptr } %t499, ptr %t497, 1
  %t502 = load ptr, ptr %l200, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s8, ptr %t502, { i64, ptr } %t500)
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s5)
  br label %bb115
bb92:
  %t504 = load ptr, ptr %l5, !tbaa !29
  store ptr %t504, ptr %l206, !tbaa !29
  %t505 = load i32, ptr %l21, !tbaa !23
  %t506 = load ptr, ptr %l206, !tbaa !29
  %t507 = call ptr @__olang_scope_or(ptr %v2, ptr %t506)
  %t508 = call ptr @__olang_scope_hold(ptr %t507)
  %t509 = ptrtoint ptr %t508 to i64
  %t511 = inttoptr i64 %t509 to ptr
  %t512 = load ptr, ptr %l206, !tbaa !29
  %t514 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t511, ptr %t512, i32 %t505)
  store i1 %t514, ptr %l209
  br label %bb93
bb93:
  %t515 = load i1, ptr %l209, !tbaa !21
  br i1 %t515, label %bb94, label %bb95
bb94:
  %t516 = load ptr, ptr %l5, !tbaa !29
  store ptr %t516, ptr %l211, !tbaa !29
  %t517 = load i32, ptr %l21, !tbaa !23
  %t518 = load ptr, ptr %l211, !tbaa !29
  %t519 = call ptr @__olang_scope_or(ptr %v2, ptr %t518)
  %t520 = call ptr @__olang_scope_hold(ptr %t519)
  %t521 = ptrtoint ptr %t520 to i64
  %t523 = inttoptr i64 %t521 to ptr
  %t524 = load ptr, ptr %l211, !tbaa !29
  %t526 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t523, ptr %t524, i32 %t517)
  store i32 %t526, ptr %l214
  br label %bb96
bb95:
  %t527 = load i32, ptr %l21, !tbaa !23
  store i32 %t527, ptr %l210, !tbaa !23
  br label %bb97
bb96:
  %t529 = load i32, ptr %l214, !tbaa !23
  store i32 %t529, ptr %l210, !tbaa !23
  br label %bb97
bb97:
  %t530 = load i32, ptr %l210, !tbaa !23
  store i32 %t530, ptr %l22, !tbaa !23
  %t531 = load ptr, ptr %l5, !tbaa !29
  store ptr %t531, ptr %l216, !tbaa !29
  %t532 = load i32, ptr %l21, !tbaa !23
  %t533 = load ptr, ptr %l216, !tbaa !29
  %t534 = call ptr @__olang_scope_or(ptr %v2, ptr %t533)
  %t535 = call ptr @__olang_scope_hold(ptr %t534)
  %t536 = ptrtoint ptr %t535 to i64
  %t538 = inttoptr i64 %t536 to ptr
  %t539 = load ptr, ptr %l216, !tbaa !29
  %t541 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t538, ptr %t539, i32 %t532)
  store i1 %t541, ptr %l219
  br label %bb98
bb98:
  %t542 = load i1, ptr %l219, !tbaa !21
  br i1 %t542, label %bb99, label %bb100
bb99:
  store i1 true, ptr %l220, !tbaa !21
  br label %bb103
bb100:
  %t543 = load ptr, ptr %l5, !tbaa !29
  store ptr %t543, ptr %l221, !tbaa !29
  %t544 = load ptr, ptr %l5, !tbaa !29
  store ptr %t544, ptr %l222, !tbaa !29
  %t545 = load i32, ptr %l22, !tbaa !23
  %t546 = load ptr, ptr %l222, !tbaa !29
  %t547 = call ptr @__olang_scope_or(ptr %v2, ptr %t546)
  %t548 = call ptr @__olang_scope_hold(ptr %t547)
  %t549 = ptrtoint ptr %t548 to i64
  %t551 = inttoptr i64 %t549 to ptr
  %t552 = load ptr, ptr %l222, !tbaa !29
  %t554 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t551, ptr %t552, i32 %t545)
  store i32 %t554, ptr %l225
  br label %bb101
bb101:
  %t555 = load ptr, ptr %l221, !tbaa !29
  %t556 = call ptr @__olang_scope_or(ptr %v2, ptr %t555)
  %t557 = call ptr @__olang_scope_hold(ptr %t556)
  %t558 = ptrtoint ptr %t557 to i64
  %t560 = inttoptr i64 %t558 to ptr
  %t561 = load ptr, ptr %l221, !tbaa !29
  %t562 = load i32, ptr %l225, !tbaa !23
  %t563 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t560, ptr %t561, i32 %t562)
  store i32 %t563, ptr %l227
  br label %bb102
bb102:
  %t564 = load i32, ptr %l227, !range !{i32 0, i32 33}
  %t566 = trunc i64 19 to i32
  %t567 = icmp eq i32 %t564, %t566
  store i1 %t567, ptr %l220, !tbaa !21
  br label %bb103
bb103:
  %t569 = load i1, ptr %l220, !tbaa !21
  br i1 %t569, label %bb104, label %bb105
bb104:
  store %olang.scope zeroinitializer, ptr %s10
  %t570 = getelementptr %"compiler/cabi:Regs", ptr %l9, i32 0, i32 0
  %t571 = load i64, ptr %t570, !tbaa !24
  %t574 = sub i64 %t571, 1
  %t576 = getelementptr %"compiler/cabi:Regs", ptr %l9, i32 0, i32 0
  store i64 %t574, ptr %t576, !tbaa !24
  %t577 = load ptr, ptr %l0, !tbaa !29
  %t578 = load { i64, [4 x i64] }, ptr %l19
  %t581 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %v3, ptr %v2, ptr %t577, { i64, [4 x i64] } %t578)
  store i32 %t581, ptr %l235
  br label %bb106
bb105:
  br label %bb110
bb106:
  %t582 = load i32, ptr %l235, !tbaa !23
  store i32 %t582, ptr %l23, !tbaa !23
  store ptr %l7, ptr %l236, !tbaa !29
  %t583 = load ptr, ptr %l0, !tbaa !29
  store ptr %t583, ptr %l237, !tbaa !29
  %t584 = load ptr, ptr %l0, !tbaa !29
  %t585 = load { i64, [4 x i64] }, ptr %l19
  %t586 = load i32, ptr %l23, !tbaa !23
  %t590 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s10, ptr %v3, ptr %v2, ptr %t584, { i64, [4 x i64] } %t585, i32 %t586)
  store { i64, ptr } %t590, ptr %l241
  br label %bb107
bb107:
  %t591 = load { i64, ptr }, ptr %l241, !tbaa !27
  %t592 = load i32, ptr %l23, !tbaa !23
  %t593 = load ptr, ptr %l237, !tbaa !29
  %t596 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eexternArg(ptr %v0, ptr %s10, ptr %s10, ptr %v2, ptr %t593, { i64, ptr } %t591, i32 %t592)
  store { i64, ptr } %t596, ptr %l244
  br label %bb108
bb108:
  %t597 = load { i64, ptr }, ptr %l244, !tbaa !27
  %t598 = load ptr, ptr %l236, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s10, ptr %t598, { i64, ptr } %t597)
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s5)
  br label %bb115
bb110:
  %t600 = load ptr, ptr %l0, !tbaa !29
  %t602 = getelementptr %"compiler/emit:fnEm", ptr %t600, i32 0, i32 0
  %t603 = load ptr, ptr %t602, !tbaa !29
  %t605 = getelementptr %"compiler/emit:Emitter", ptr %t603, i32 0, i32 0
  %t606 = load ptr, ptr %t605, !tbaa !29
  store ptr %t606, ptr %l248, !tbaa !29
  %t607 = load i32, ptr %l20, !tbaa !23
  %t608 = load ptr, ptr %l248, !tbaa !29
  %t609 = call ptr @__olang_scope_or(ptr %v2, ptr %t608)
  %t610 = call ptr @__olang_scope_hold(ptr %t609)
  %t611 = ptrtoint ptr %t610 to i64
  %t613 = inttoptr i64 %t611 to ptr
  %t614 = load ptr, ptr %l248, !tbaa !29
  %t616 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %t613, ptr %t614, i32 %t607)
  store i1 %t616, ptr %l251
  br label %bb111
bb111:
  %t617 = load ptr, ptr %l5, !tbaa !29
  store ptr %t617, ptr %l252, !tbaa !29
  %t618 = load ptr, ptr %l0, !tbaa !29
  %t620 = getelementptr %"compiler/emit:fnEm", ptr %t618, i32 0, i32 0
  %t621 = load ptr, ptr %t620, !tbaa !29
  store ptr %t621, ptr %l254, !tbaa !29
  %t622 = load ptr, ptr %l254, !tbaa !29
  %t623 = call ptr @__olang_scope_or(ptr %v2, ptr %t622)
  %t624 = call ptr @__olang_scope_hold(ptr %t623)
  %t625 = ptrtoint ptr %t624 to i64
  %t627 = inttoptr i64 %t625 to ptr
  %t628 = load ptr, ptr %l254, !tbaa !29
  %t629 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eabiArch(ptr %t627, ptr %s5, ptr %t628)
  store { i64, ptr } %t629, ptr %l256
  br label %bb112
bb112:
  %t630 = load { i64, ptr }, ptr %l256, !tbaa !27
  %t631 = load i32, ptr %l20, !tbaa !23
  %t632 = load ptr, ptr %l252, !tbaa !29
  %t633 = call ptr @__olang_scope_or(ptr %v2, ptr %t632)
  %t634 = call ptr @__olang_scope_hold(ptr %t633)
  %t635 = ptrtoint ptr %t634 to i64
  %t637 = inttoptr i64 %t635 to ptr
  %t639 = inttoptr i64 0 to ptr
  %t640 = load ptr, ptr %l252, !tbaa !29
  %t644 = call %"compiler/cabi:Way" @compiler_2fcabi_2eWay_2eParam(ptr %t637, ptr %s5, ptr %s0, ptr %s5, ptr %t639, ptr %t640, { i64, ptr } %t630, i32 %t631, ptr %l9)
  store %"compiler/cabi:Way" %t644, ptr %l262
  br label %bb113
bb113:
  %t645 = load %"compiler/cabi:Way", ptr %l262
  store %"compiler/cabi:Way" %t645, ptr %l24
  %t646 = load ptr, ptr %l0, !tbaa !29
  %t647 = load i32, ptr %l20, !tbaa !23
  %t648 = load { i64, [4 x i64] }, ptr %l19
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ecArg(ptr %v0, ptr %s0, ptr %s5, ptr %v2, ptr %v3, ptr %t646, ptr %l7, ptr %l24, i32 %t647, { i64, [4 x i64] } %t648)
  br label %bb114
bb114:
  call void @__olang_scope_close(ptr %s5)
  br label %bb115
bb115:
  %t654 = load i64, ptr %l17, !tbaa !24
  %t657 = add i64 %t654, 1
  store i64 %t657, ptr %l17, !tbaa !24
  br label %bb66
bb116:
  %t659 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t661 = extractvalue { i64, ptr } %t659, 0
  store i64 %t661, ptr %l25, !tbaa !24
  %t663 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 1
  %t664 = getelementptr %"compiler/mir:Range", ptr %t663, i32 0, i32 1
  %t665 = load i32, ptr %t664, !tbaa !23
  %t667 = sext i32 %t665 to i64
  store i64 %t667, ptr %l26, !tbaa !24
  store i64 1, ptr %l27, !tbaa !24
  %t669 = load i64, ptr %l26, !tbaa !24
  %t670 = load i64, ptr %l25, !tbaa !24
  %t673 = icmp sgt i64 %t669, %t670
  br i1 %t673, label %bb117, label %bb118
bb117:
  %t675 = load i64, ptr %l27, !tbaa !24
  %t677 = icmp sgt i64 %t675, 0
  br i1 %t677, label %bb119, label %bb120
bb118:
  store i64 0, ptr %l278, !tbaa !24
  br label %bb122
bb119:
  %t679 = load i64, ptr %l26, !tbaa !24
  %t680 = load i64, ptr %l25, !tbaa !24
  %t683 = sub i64 %t679, %t680
  %t684 = load i64, ptr %l27, !tbaa !24
  %t687 = add i64 %t683, %t684
  %t689 = sub i64 %t687, 1
  %t690 = load i64, ptr %l27, !tbaa !24
  %t693 = sdiv i64 %t689, %t690
  store i64 %t693, ptr %l281, !tbaa !24
  br label %bb121
bb120:
  store i64 0, ptr %l281, !tbaa !24
  br label %bb121
bb121:
  %t695 = load i64, ptr %l281, !tbaa !24
  store i64 %t695, ptr %l278, !tbaa !24
  br label %bb122
bb122:
  %t696 = load i64, ptr %l278, !tbaa !24
  store i64 %t696, ptr %l28, !tbaa !24
  store i64 0, ptr %l29, !tbaa !24
  br label %bb123
bb123:
  store %olang.scope zeroinitializer, ptr %s13
  %t697 = load i64, ptr %l29, !tbaa !24
  %t698 = load i64, ptr %l28, !tbaa !24
  %t701 = icmp slt i64 %t697, %t698
  %t703 = xor i1 %t701, true
  br i1 %t703, label %bb124, label %bb125
bb124:
  call void @__olang_scope_close(ptr %s13)
  br label %bb137
bb125:
  br label %bb126
bb126:
  %t705 = load i64, ptr %l25, !tbaa !24
  %t706 = load i64, ptr %l29, !tbaa !24
  %t707 = load i64, ptr %l27, !tbaa !24
  %t710 = mul i64 %t706, %t707
  %t713 = add i64 %t705, %t710
  store i64 %t713, ptr %l30, !tbaa !24
  %t715 = load i1, ptr %l8, !tbaa !21
  %t717 = xor i1 %t715, true
  br i1 %t717, label %bb127, label %bb128
bb127:
  store %olang.scope zeroinitializer, ptr %s14
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s14, ptr %l7, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d148, i32 0, i32 1) })
  br label %bb129
bb128:
  br label %bb130
bb129:
  call void @__olang_scope_close(ptr %s14)
  br label %bb130
bb130:
  store i1 false, ptr %l8, !tbaa !21
  %t720 = load ptr, ptr %l0, !tbaa !29
  %t721 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 1
  %t722 = load %"compiler/mir:Range", ptr %t721
  %t723 = load i64, ptr %l30, !tbaa !24
  %t727 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %v3, ptr %t720, %"compiler/mir:Range" %t722, i64 %t723)
  store { i64, [4 x i64] } %t727, ptr %l305
  br label %bb131
bb131:
  %t728 = load { i64, [4 x i64] }, ptr %l305
  store { i64, [4 x i64] } %t728, ptr %l31
  %t729 = load ptr, ptr %l0, !tbaa !29
  %t730 = load { i64, [4 x i64] }, ptr %l31
  %t733 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %v3, ptr %v2, ptr %t729, { i64, [4 x i64] } %t730)
  store i32 %t733, ptr %l308
  br label %bb132
bb132:
  %t734 = load i32, ptr %l308, !tbaa !23
  store i32 %t734, ptr %l32, !tbaa !23
  store ptr %l7, ptr %l309, !tbaa !29
  %t735 = load ptr, ptr %l0, !tbaa !29
  store ptr %t735, ptr %l310, !tbaa !29
  %t736 = load ptr, ptr %l0, !tbaa !29
  %t737 = load { i64, [4 x i64] }, ptr %l31
  %t738 = load i32, ptr %l32, !tbaa !23
  %t742 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s13, ptr %v3, ptr %v2, ptr %t736, { i64, [4 x i64] } %t737, i32 %t738)
  store { i64, ptr } %t742, ptr %l314
  br label %bb133
bb133:
  %t743 = load { i64, ptr }, ptr %l314, !tbaa !27
  %t744 = load i32, ptr %l32, !tbaa !23
  %t745 = load ptr, ptr %l310, !tbaa !29
  %t748 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eexternArg(ptr %v0, ptr %s13, ptr %s13, ptr %v2, ptr %t745, { i64, ptr } %t743, i32 %t744)
  store { i64, ptr } %t748, ptr %l317
  br label %bb134
bb134:
  %t749 = load { i64, ptr }, ptr %l317, !tbaa !27
  %t750 = load ptr, ptr %l309, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s13, ptr %t750, { i64, ptr } %t749)
  br label %bb135
bb135:
  call void @__olang_scope_close(ptr %s13)
  br label %bb136
bb136:
  %t752 = load i64, ptr %l29, !tbaa !24
  %t755 = add i64 %t752, 1
  store i64 %t755, ptr %l29, !tbaa !24
  br label %bb123
bb137:
  %t757 = load ptr, ptr %l0, !tbaa !29
  %t759 = getelementptr %"compiler/emit:fnEm", ptr %t757, i32 0, i32 0
  %t760 = load ptr, ptr %t759, !tbaa !29
  store ptr %t760, ptr %l323, !tbaa !29
  %t761 = load i32, ptr %l3, !tbaa !23
  %t762 = load ptr, ptr %l323, !tbaa !29
  %t763 = call ptr @__olang_scope_or(ptr %v2, ptr %t762)
  %t764 = call ptr @__olang_scope_hold(ptr %t763)
  %t765 = ptrtoint ptr %t764 to i64
  %t767 = inttoptr i64 %t765 to ptr
  %t768 = load ptr, ptr %l323, !tbaa !29
  %t770 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecHeader(ptr %t767, ptr %s0, ptr %t768, i32 %t761)
  store { i64, ptr } %t770, ptr %l326
  br label %bb138
bb138:
  %t771 = load { i64, ptr }, ptr %l326, !tbaa !27
  store { i64, ptr } %t771, ptr %l33, !tbaa !27
  %t772 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t772, ptr %l327, !tbaa !27
  %t773 = load { i64, ptr }, ptr %l327, !tbaa !27
  %t774 = extractvalue { i64, ptr } %t773, 0
  store i64 %t774, ptr %l328, !tbaa !24
  %t775 = load i64, ptr %l328, !tbaa !24
  %t776 = mul i64 %t775, 1
  %t777 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t776)
  %t778 = insertvalue { i64, ptr } undef, i64 %t775, 0
  %t779 = insertvalue { i64, ptr } %t778, ptr %t777, 1
  store { i64, ptr } %t779, ptr %l329, !tbaa !27
  %t780 = getelementptr { i64, ptr }, ptr %l329, i32 0, i32 1
  %t781 = load ptr, ptr %t780, !tbaa !27
  %t782 = getelementptr { i64, ptr }, ptr %l327, i32 0, i32 1
  %t783 = load ptr, ptr %t782, !tbaa !27
  %t784 = load i64, ptr %l328, !tbaa !24
  %t785 = mul i64 %t784, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t781, ptr %t783, i64 %t785, i1 false)
  %t786 = load { i64, ptr }, ptr %l329, !tbaa !27
  store { i64, ptr } %t786, ptr %l34, !tbaa !27
  %t787 = getelementptr %"compiler/cabi:Way", ptr %l11, i32 0, i32 0
  %t788 = load i32, ptr %t787, !range !{i32 0, i32 5}
  %t790 = trunc i64 0 to i32
  %t791 = icmp eq i32 %t788, %t790
  br i1 %t791, label %bb139, label %bb140
bb139:
  %t793 = getelementptr %"compiler/cabi:Way", ptr %l11, i32 0, i32 4
  %t794 = load { i64, ptr }, ptr %t793, !tbaa !27
  %t796 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t794, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d149, i32 0, i32 1) })
  store i1 %t796, ptr %l334
  br label %bb141
bb140:
  store i1 false, ptr %l332, !tbaa !21
  br label %bb142
bb141:
  %t797 = load i1, ptr %l334, !tbaa !21
  %t798 = xor i1 %t797, true
  store i1 %t798, ptr %l332, !tbaa !21
  br label %bb142
bb142:
  %t800 = load i1, ptr %l332, !tbaa !21
  br i1 %t800, label %bb143, label %bb144
bb143:
  %t801 = call ptr @__olang_scope_hold(ptr %s0)
  %t802 = ptrtoint ptr %t801 to i64
  store i64 %t802, ptr %l336, !tbaa !24
  %t803 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ecCall_2elocal_2e34
  br i1 %t803, label %bb145, label %bb146
bb144:
  br label %bb157
bb145:
  %t805 = call ptr @__olang_region_make(ptr %s0)
  %t806 = ptrtoint ptr %t805 to i64
  store i64 %t806, ptr %l336, !tbaa !24
  br label %bb146
bb146:
  %t807 = getelementptr %"compiler/cabi:Way", ptr %l11, i32 0, i32 4
  %t808 = load { i64, ptr }, ptr %t807, !tbaa !27
  %t810 = extractvalue { i64, ptr } %t808, 0
  %t812 = add i64 %t810, 1
  store i64 %t812, ptr %l340, !tbaa !24
  %t813 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t815 = extractvalue { i64, ptr } %t813, 0
  store i64 %t815, ptr %l342, !tbaa !24
  %t816 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t817 = extractvalue { i64, ptr } %t816, 0
  store i64 %t817, ptr %l343, !tbaa !24
  %t818 = load i64, ptr %l340, !tbaa !24
  %t819 = icmp sge i64 %t818, 0
  br i1 %t819, label %bb147, label %bb148
bb147:
  %t821 = load i64, ptr %l340, !tbaa !24
  %t822 = load i64, ptr %l342, !tbaa !24
  %t823 = icmp sle i64 %t821, %t822
  br i1 %t823, label %bb149, label %bb150
bb148:
  call void @__olang_check_failed(ptr @olang_loc_89905a2f16c466ce_9c68de6bba1a420a)
  unreachable
bb149:
  %t825 = load i64, ptr %l342, !tbaa !24
  %t826 = load i64, ptr %l343, !tbaa !24
  %t827 = icmp sle i64 %t825, %t826
  br i1 %t827, label %bb151, label %bb152
bb150:
  call void @__olang_check_failed(ptr @olang_loc_89905a2f16c466ce_9c68de6bba1a420a)
  unreachable
bb151:
  %t829 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t830 = load ptr, ptr %t829, !tbaa !27
  %t831 = load i64, ptr %l340, !tbaa !24
  %t832 = load i64, ptr %l342, !tbaa !24
  %t833 = getelementptr i8, ptr %t830, i64 %t831
  %t834 = sub i64 %t832, %t831
  %t835 = insertvalue { i64, ptr } undef, i64 %t834, 0
  %t836 = insertvalue { i64, ptr } %t835, ptr %t833, 1
  store { i64, ptr } %t836, ptr %l348, !tbaa !27
  %t838 = load { i64, ptr }, ptr %l348, !tbaa !27
  %t839 = extractvalue { i64, ptr } %t838, 0
  store i64 %t839, ptr %l349, !tbaa !24
  %t840 = load i64, ptr %l349, !tbaa !24
  %t841 = mul i64 %t840, 1
  %t842 = load i64, ptr %l336
  %t843 = inttoptr i64 %t842 to ptr
  %t844 = call ptr @__olang_held_alloc(ptr %t843, i64 %t841)
  %t845 = insertvalue { i64, ptr } undef, i64 %t840, 0
  %t846 = insertvalue { i64, ptr } %t845, ptr %t844, 1
  store { i64, ptr } %t846, ptr %l350, !tbaa !27
  %t847 = getelementptr { i64, ptr }, ptr %l350, i32 0, i32 1
  %t848 = load ptr, ptr %t847, !tbaa !27
  %t849 = getelementptr { i64, ptr }, ptr %l348, i32 0, i32 1
  %t850 = load ptr, ptr %t849, !tbaa !27
  %t851 = load i64, ptr %l349, !tbaa !24
  %t852 = mul i64 %t851, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t848, ptr %t850, i64 %t852, i1 false)
  %t853 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t853, ptr %l351, !tbaa !27
  %t854 = load { i64, ptr }, ptr %l350, !tbaa !27
  store { i64, ptr } %t854, ptr %l34, !tbaa !27
  %t855 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ecCall_2elocal_2e34
  br i1 %t855, label %bb153, label %bb154
bb152:
  call void @__olang_check_failed(ptr @olang_loc_89905a2f16c466ce_9c68de6bba1a420a)
  unreachable
bb153:
  %t857 = load { i64, ptr }, ptr %l351
  %t858 = extractvalue { i64, ptr } %t857, 1
  call void @__olang_region_release(ptr %t858)
  store { i64, ptr } zeroinitializer, ptr %l351
  br label %bb154
bb154:
  %t859 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ecCall_2elocal_2e34
  br i1 %t859, label %bb155, label %bb156
bb155:
  %t861 = load i64, ptr %l336
  %t862 = inttoptr i64 %t861 to ptr
  %t863 = load { i64, ptr }, ptr %l34
  %t864 = extractvalue { i64, ptr } %t863, 1
  %t865 = call ptr @__olang_region_or(ptr %t864, ptr null)
  %t866 = icmp ne ptr %t865, null
  %t867 = select i1 %t866, ptr %t865, ptr null
  call void @__olang_region_settle_in(ptr %t862, ptr %t867)
  br label %bb156
bb156:
  br label %bb157
bb157:
  %t868 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t868, ptr %l354, !tbaa !27
  %t869 = load { i64, ptr }, ptr %l354, !tbaa !27
  %t870 = extractvalue { i64, ptr } %t869, 0
  store i64 %t870, ptr %l355, !tbaa !24
  %t871 = load i64, ptr %l355, !tbaa !24
  %t872 = mul i64 %t871, 1
  %t873 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t872)
  %t874 = insertvalue { i64, ptr } undef, i64 %t871, 0
  %t875 = insertvalue { i64, ptr } %t874, ptr %t873, 1
  store { i64, ptr } %t875, ptr %l356, !tbaa !27
  %t876 = getelementptr { i64, ptr }, ptr %l356, i32 0, i32 1
  %t877 = load ptr, ptr %t876, !tbaa !27
  %t878 = getelementptr { i64, ptr }, ptr %l354, i32 0, i32 1
  %t879 = load ptr, ptr %t878, !tbaa !27
  %t880 = load i64, ptr %l355, !tbaa !24
  %t881 = mul i64 %t880, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t877, ptr %t879, i64 %t881, i1 false)
  %t882 = load { i64, ptr }, ptr %l356, !tbaa !27
  store { i64, ptr } %t882, ptr %l35, !tbaa !27
  br i1 %a4, label %bb158, label %bb159
bb158:
  store %olang.scope zeroinitializer, ptr %s17
  %t885 = call ptr @__olang_scope_hold(ptr %s0)
  %t886 = ptrtoint ptr %t885 to i64
  store i64 %t886, ptr %l358, !tbaa !24
  %t887 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ecCall_2elocal_2e35
  br i1 %t887, label %bb160, label %bb161
bb159:
  br label %bb172
bb160:
  %t889 = call ptr @__olang_region_make(ptr %s0)
  %t890 = ptrtoint ptr %t889 to i64
  store i64 %t890, ptr %l358, !tbaa !24
  br label %bb161
bb161:
  %t891 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t891, ptr %l360, !tbaa !27
  %t892 = load ptr, ptr %l0, !tbaa !29
  %t894 = getelementptr %"compiler/emit:fnEm", ptr %t892, i32 0, i32 0
  %t895 = load ptr, ptr %t894, !tbaa !29
  store ptr %t895, ptr %l362, !tbaa !29
  %t896 = load i32, ptr %l3, !tbaa !23
  %t897 = load ptr, ptr %l362, !tbaa !29
  %t898 = call ptr @__olang_scope_or(ptr %v2, ptr %t897)
  %t899 = call ptr @__olang_scope_hold(ptr %t898)
  %t900 = ptrtoint ptr %t899 to i64
  %t902 = inttoptr i64 %t900 to ptr
  %t903 = load ptr, ptr %l362, !tbaa !29
  %t905 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecParamList(ptr %t902, ptr %s17, ptr %t903, i32 %t896, i1 false)
  store { i64, ptr } %t905, ptr %l365
  br label %bb162
bb162:
  %t906 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t908 = extractvalue { i64, ptr } %t906, 0
  %t910 = icmp sgt i64 %t908, 0
  br i1 %t910, label %bb163, label %bb164
bb163:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d150, i32 0, i32 1) }, ptr %l369, !tbaa !27
  br label %bb165
bb164:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d151, i32 0, i32 1) }, ptr %l369, !tbaa !27
  br label %bb165
bb165:
  %t912 = load { i64, ptr }, ptr %l360, !tbaa !27
  %t913 = extractvalue { i64, ptr } %t912, 1
  %t914 = extractvalue { i64, ptr } %t912, 0
  %t915 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d152, i32 0, i32 1) }, 1
  %t916 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d152, i32 0, i32 1) }, 0
  %t917 = add i64 %t914, %t916
  %t918 = load { i64, ptr }, ptr %l365, !tbaa !27
  %t919 = extractvalue { i64, ptr } %t918, 1
  %t920 = extractvalue { i64, ptr } %t918, 0
  %t921 = add i64 %t917, %t920
  %t922 = load { i64, ptr }, ptr %l369, !tbaa !27
  %t923 = extractvalue { i64, ptr } %t922, 1
  %t924 = extractvalue { i64, ptr } %t922, 0
  %t925 = add i64 %t921, %t924
  %t926 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d153, i32 0, i32 1) }, 1
  %t927 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d153, i32 0, i32 1) }, 0
  %t928 = add i64 %t925, %t927
  %t929 = load i64, ptr %l358
  %t930 = inttoptr i64 %t929 to ptr
  %t931 = call ptr @__olang_held_alloc(ptr %t930, i64 %t928)
  call void @olang_textcopy(ptr %t931, ptr %t913, i64 %t914)
  %t932 = getelementptr i8, ptr %t931, i64 %t914
  call void @olang_textcopy(ptr %t932, ptr %t915, i64 %t916)
  %t933 = getelementptr i8, ptr %t932, i64 %t916
  call void @olang_textcopy(ptr %t933, ptr %t919, i64 %t920)
  %t934 = getelementptr i8, ptr %t933, i64 %t920
  call void @olang_textcopy(ptr %t934, ptr %t923, i64 %t924)
  %t935 = getelementptr i8, ptr %t934, i64 %t924
  call void @olang_textcopy(ptr %t935, ptr %t926, i64 %t927)
  %t936 = insertvalue { i64, ptr } undef, i64 %t928, 0
  %t937 = insertvalue { i64, ptr } %t936, ptr %t931, 1
  store { i64, ptr } %t937, ptr %l370, !tbaa !27
  %t938 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ecCall_2elocal_2e35
  br i1 %t938, label %bb166, label %bb167
bb166:
  %t940 = load { i64, ptr }, ptr %l370, !tbaa !27
  %t941 = extractvalue { i64, ptr } %t940, 0
  %t943 = icmp eq i64 %t941, 0
  br i1 %t943, label %bb168, label %bb169
bb167:
  %t945 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t945, ptr %l374, !tbaa !27
  %t946 = load { i64, ptr }, ptr %l370, !tbaa !27
  store { i64, ptr } %t946, ptr %l35, !tbaa !27
  %t947 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ecCall_2elocal_2e35
  br i1 %t947, label %bb170, label %bb171
bb168:
  store { i64, ptr } zeroinitializer, ptr %l370, !tbaa !27
  br label %bb169
bb169:
  %t949 = load i64, ptr %l358
  %t950 = inttoptr i64 %t949 to ptr
  %t951 = load { i64, ptr }, ptr %l370
  %t952 = extractvalue { i64, ptr } %t951, 1
  %t953 = call ptr @__olang_region_or(ptr %t952, ptr null)
  %t954 = icmp ne ptr %t953, null
  %t955 = select i1 %t954, ptr %t953, ptr null
  call void @__olang_region_settle_in(ptr %t950, ptr %t955)
  br label %bb167
bb170:
  %t956 = load { i64, ptr }, ptr %l374
  %t957 = extractvalue { i64, ptr } %t956, 1
  call void @__olang_region_release(ptr %t957)
  store { i64, ptr } zeroinitializer, ptr %l374
  br label %bb171
bb171:
  call void @__olang_scope_close(ptr %s17)
  br label %bb172
bb172:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d154, i32 0, i32 1) }, ptr %l376, !tbaa !27
  %t958 = load { i64, ptr }, ptr %l376, !tbaa !27
  store { i64, ptr } %t958, ptr %l36, !tbaa !27
  %t960 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t962 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t960, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d155, i32 0, i32 1) })
  store i1 %t962, ptr %l379
  br label %bb173
bb173:
  %t963 = load i1, ptr %l379, !tbaa !21
  br i1 %t963, label %bb174, label %bb175
bb174:
  store %olang.scope zeroinitializer, ptr %s19
  %t964 = load ptr, ptr %l0, !tbaa !29
  store ptr %t964, ptr %l380, !tbaa !29
  %t965 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t965, ptr %l381, !tbaa !27
  %t966 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t966, ptr %l382, !tbaa !27
  %t968 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s19, ptr %l7)
  store { i64, ptr } %t968, ptr %l384
  br label %bb176
bb175:
  store %olang.scope zeroinitializer, ptr %s21
  %t969 = call ptr @__olang_scope_hold(ptr %s0)
  %t970 = ptrtoint ptr %t969 to i64
  store i64 %t970, ptr %l387, !tbaa !24
  %t971 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ecCall_2elocal_2e36
  br i1 %t971, label %bb178, label %bb179
bb176:
  %t973 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d156, i32 0, i32 1) }, 1
  %t974 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d156, i32 0, i32 1) }, 0
  %t975 = load { i64, ptr }, ptr %l381, !tbaa !27
  %t976 = extractvalue { i64, ptr } %t975, 1
  %t977 = extractvalue { i64, ptr } %t975, 0
  %t978 = add i64 %t974, %t977
  %t979 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d157, i32 0, i32 1) }, 1
  %t980 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d157, i32 0, i32 1) }, 0
  %t981 = add i64 %t978, %t980
  %t982 = load { i64, ptr }, ptr %l382, !tbaa !27
  %t983 = extractvalue { i64, ptr } %t982, 1
  %t984 = extractvalue { i64, ptr } %t982, 0
  %t985 = add i64 %t981, %t984
  %t986 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d158, i32 0, i32 1) }, 1
  %t987 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d158, i32 0, i32 1) }, 0
  %t988 = add i64 %t985, %t987
  %t989 = load { i64, ptr }, ptr %l384, !tbaa !27
  %t990 = extractvalue { i64, ptr } %t989, 1
  %t991 = extractvalue { i64, ptr } %t989, 0
  %t992 = add i64 %t988, %t991
  %t993 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d159, i32 0, i32 1) }, 1
  %t994 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d159, i32 0, i32 1) }, 0
  %t995 = add i64 %t992, %t994
  %t996 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t995)
  call void @olang_textcopy(ptr %t996, ptr %t973, i64 %t974)
  %t997 = getelementptr i8, ptr %t996, i64 %t974
  call void @olang_textcopy(ptr %t997, ptr %t976, i64 %t977)
  %t998 = getelementptr i8, ptr %t997, i64 %t977
  call void @olang_textcopy(ptr %t998, ptr %t979, i64 %t980)
  %t999 = getelementptr i8, ptr %t998, i64 %t980
  call void @olang_textcopy(ptr %t999, ptr %t983, i64 %t984)
  %t1000 = getelementptr i8, ptr %t999, i64 %t984
  call void @olang_textcopy(ptr %t1000, ptr %t986, i64 %t987)
  %t1001 = getelementptr i8, ptr %t1000, i64 %t987
  call void @olang_textcopy(ptr %t1001, ptr %t990, i64 %t991)
  %t1002 = getelementptr i8, ptr %t1001, i64 %t991
  call void @olang_textcopy(ptr %t1002, ptr %t993, i64 %t994)
  %t1003 = insertvalue { i64, ptr } undef, i64 %t995, 0
  %t1004 = insertvalue { i64, ptr } %t1003, ptr %t996, 1
  %t1006 = load ptr, ptr %l380, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s19, ptr %v2, ptr %t1006, { i64, ptr } %t1004)
  br label %bb177
bb177:
  call void @__olang_scope_close(ptr %s19)
  br label %bb188
bb178:
  %t1008 = call ptr @__olang_region_make(ptr %s0)
  %t1009 = ptrtoint ptr %t1008 to i64
  store i64 %t1009, ptr %l387, !tbaa !24
  br label %bb179
bb179:
  %t1010 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1010, ptr %l389, !tbaa !29
  %t1011 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t1011, ptr %l390, !tbaa !27
  %t1012 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t1012, ptr %l391, !tbaa !27
  %t1014 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s21, ptr %l7)
  store { i64, ptr } %t1014, ptr %l393
  br label %bb180
bb180:
  %t1015 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d160, i32 0, i32 1) }, 1
  %t1016 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d160, i32 0, i32 1) }, 0
  %t1017 = load { i64, ptr }, ptr %l390, !tbaa !27
  %t1018 = extractvalue { i64, ptr } %t1017, 1
  %t1019 = extractvalue { i64, ptr } %t1017, 0
  %t1020 = add i64 %t1016, %t1019
  %t1021 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d161, i32 0, i32 1) }, 1
  %t1022 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d161, i32 0, i32 1) }, 0
  %t1023 = add i64 %t1020, %t1022
  %t1024 = load { i64, ptr }, ptr %l391, !tbaa !27
  %t1025 = extractvalue { i64, ptr } %t1024, 1
  %t1026 = extractvalue { i64, ptr } %t1024, 0
  %t1027 = add i64 %t1023, %t1026
  %t1028 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d162, i32 0, i32 1) }, 1
  %t1029 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d162, i32 0, i32 1) }, 0
  %t1030 = add i64 %t1027, %t1029
  %t1031 = load { i64, ptr }, ptr %l393, !tbaa !27
  %t1032 = extractvalue { i64, ptr } %t1031, 1
  %t1033 = extractvalue { i64, ptr } %t1031, 0
  %t1034 = add i64 %t1030, %t1033
  %t1035 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d163, i32 0, i32 1) }, 1
  %t1036 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d163, i32 0, i32 1) }, 0
  %t1037 = add i64 %t1034, %t1036
  %t1038 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t1037)
  call void @olang_textcopy(ptr %t1038, ptr %t1015, i64 %t1016)
  %t1039 = getelementptr i8, ptr %t1038, i64 %t1016
  call void @olang_textcopy(ptr %t1039, ptr %t1018, i64 %t1019)
  %t1040 = getelementptr i8, ptr %t1039, i64 %t1019
  call void @olang_textcopy(ptr %t1040, ptr %t1021, i64 %t1022)
  %t1041 = getelementptr i8, ptr %t1040, i64 %t1022
  call void @olang_textcopy(ptr %t1041, ptr %t1025, i64 %t1026)
  %t1042 = getelementptr i8, ptr %t1041, i64 %t1026
  call void @olang_textcopy(ptr %t1042, ptr %t1028, i64 %t1029)
  %t1043 = getelementptr i8, ptr %t1042, i64 %t1029
  call void @olang_textcopy(ptr %t1043, ptr %t1032, i64 %t1033)
  %t1044 = getelementptr i8, ptr %t1043, i64 %t1033
  call void @olang_textcopy(ptr %t1044, ptr %t1035, i64 %t1036)
  %t1045 = insertvalue { i64, ptr } undef, i64 %t1037, 0
  %t1046 = insertvalue { i64, ptr } %t1045, ptr %t1038, 1
  %t1048 = load i64, ptr %l387
  %t1049 = inttoptr i64 %t1048 to ptr
  %t1050 = load ptr, ptr %l389, !tbaa !29
  %t1052 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s21, ptr %t1049, ptr %v2, ptr %t1050, { i64, ptr } %t1046)
  store { i64, ptr } %t1052, ptr %l396
  br label %bb181
bb181:
  %t1053 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ecCall_2elocal_2e36
  br i1 %t1053, label %bb182, label %bb183
bb182:
  %t1055 = load { i64, ptr }, ptr %l396, !tbaa !27
  %t1056 = extractvalue { i64, ptr } %t1055, 0
  %t1058 = icmp eq i64 %t1056, 0
  br i1 %t1058, label %bb184, label %bb185
bb183:
  %t1060 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t1060, ptr %l400, !tbaa !27
  %t1061 = load { i64, ptr }, ptr %l396, !tbaa !27
  store { i64, ptr } %t1061, ptr %l36, !tbaa !27
  %t1062 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ecCall_2elocal_2e36
  br i1 %t1062, label %bb186, label %bb187
bb184:
  store { i64, ptr } zeroinitializer, ptr %l396, !tbaa !27
  br label %bb185
bb185:
  %t1064 = load i64, ptr %l387
  %t1065 = inttoptr i64 %t1064 to ptr
  %t1066 = load { i64, ptr }, ptr %l396
  %t1067 = extractvalue { i64, ptr } %t1066, 1
  %t1068 = call ptr @__olang_region_or(ptr %t1067, ptr null)
  %t1069 = icmp ne ptr %t1068, null
  %t1070 = select i1 %t1069, ptr %t1068, ptr null
  call void @__olang_region_settle_in(ptr %t1065, ptr %t1070)
  br label %bb183
bb186:
  %t1071 = load { i64, ptr }, ptr %l400
  %t1072 = extractvalue { i64, ptr } %t1071, 1
  call void @__olang_region_release(ptr %t1072)
  store { i64, ptr } zeroinitializer, ptr %l400
  br label %bb187
bb187:
  call void @__olang_scope_close(ptr %s21)
  br label %bb188
bb188:
  %t1073 = load i32, ptr %l6, !tbaa !23
  %t1074 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t1077 = icmp eq i32 %t1073, %t1074
  br i1 %t1077, label %bb189, label %bb190
bb189:
  store %olang.scope zeroinitializer, ptr %s23
  %t1079 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s23, ptr %v2, ptr %t1079, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d164, i32 0, i32 1) })
  br label %bb191
bb190:
  br label %bb192
bb191:
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb192:
  %t1081 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 4
  %t1082 = load i1, ptr %t1081, !tbaa !21
  br i1 %t1082, label %bb193, label %bb194
bb193:
  %t1084 = load i32, ptr %l6, !tbaa !23
  %t1085 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t1088 = icmp ne i32 %t1084, %t1085
  store i1 %t1088, ptr %l407, !tbaa !21
  br label %bb195
bb194:
  store i1 false, ptr %l407, !tbaa !21
  br label %bb195
bb195:
  %t1090 = load i1, ptr %l407, !tbaa !21
  br i1 %t1090, label %bb196, label %bb197
bb196:
  %t1091 = load ptr, ptr %l0, !tbaa !29
  %t1092 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t1093 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t1094 = load i32, ptr %l6, !tbaa !23
  %t1095 = load { i64, ptr }, ptr %l10, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ecResult(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %v3, ptr %v2, ptr %t1091, ptr %l1, ptr %l11, { i64, ptr } %t1092, { i64, ptr } %t1093, i32 %t1094, { i64, ptr } %t1095)
  br label %bb198
bb197:
  br label %bb199
bb198:
  br label %bb199
bb199:
  %t1103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1103, ptr %l418, !tbaa !29
  %t1104 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 5
  %t1105 = load i32, ptr %t1104, !tbaa !23
  %t1107 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s0, i32 %t1105)
  store { i64, ptr } %t1107, ptr %l420
  br label %bb200
bb200:
  %t1108 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d165, i32 0, i32 1) }, 1
  %t1109 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d165, i32 0, i32 1) }, 0
  %t1110 = load { i64, ptr }, ptr %l420, !tbaa !27
  %t1111 = extractvalue { i64, ptr } %t1110, 1
  %t1112 = extractvalue { i64, ptr } %t1110, 0
  %t1113 = add i64 %t1109, %t1112
  %t1114 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1113)
  call void @olang_textcopy(ptr %t1114, ptr %t1108, i64 %t1109)
  %t1115 = getelementptr i8, ptr %t1114, i64 %t1109
  call void @olang_textcopy(ptr %t1115, ptr %t1111, i64 %t1112)
  %t1116 = insertvalue { i64, ptr } undef, i64 %t1113, 0
  %t1117 = insertvalue { i64, ptr } %t1116, ptr %t1114, 1
  %t1119 = load ptr, ptr %l418, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %v2, ptr %t1119, { i64, ptr } %t1117)
  br label %bb201
bb201:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ecEntry(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i32
  %l4 = alloca { i64, [2 x i64] }
  %l6 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l21 = alloca ptr
  %l28 = alloca ptr
  %l31 = alloca ptr
  %l34 = alloca ptr
  %l37 = alloca i64
  %l39 = alloca ptr
  %l43 = alloca { i64, ptr }
  %l46 = alloca ptr
  %l49 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l58 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l61 = alloca ptr
  %l64 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l73 = alloca i64
  %l74 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/emit:fnEm", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/emit:Emitter", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/lower:Lowerer", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %l14, !tbaa !29
  %t23 = sext i32 %t8 to i64
  %t24 = load ptr, ptr %l14, !tbaa !29
  %t25 = call ptr @__olang_scope_or(ptr %v2, ptr %t24)
  %t26 = call ptr @__olang_scope_hold(ptr %t25)
  %t27 = ptrtoint ptr %t26 to i64
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/emit:fnEm", ptr %t28, i32 0, i32 0
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = call ptr @__olang_scope_or(ptr %v2, ptr %t31)
  %t34 = call ptr @__olang_scope_hold(ptr %t33)
  %t35 = ptrtoint ptr %t34 to i64
  %t37 = inttoptr i64 %t27 to ptr
  %t39 = inttoptr i64 %t35 to ptr
  %t40 = load ptr, ptr %l14, !tbaa !29
  %t42 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %t37, ptr %t39, ptr %t40, i64 %t23)
  store ptr %t42, ptr %l21
  br label %bb3
bb2:
  br label %bb17
bb3:
  %t43 = load ptr, ptr %l21, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Body", ptr %t43, i32 0, i32 1
  %t46 = load { i64, [2 x i64] }, ptr %t45
  store { i64, [2 x i64] } %t46, ptr %l4
  %t48 = load { i64, [2 x i64] }, ptr %l4
  %t50 = extractvalue { i64, [2 x i64] } %t48, 0
  %t51 = icmp eq i64 %t50, 0
  br i1 %t51, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t53 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t54 = getelementptr { i64 }, ptr %t53, i32 0, i32 0
  %t55 = load i64, ptr %t54
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/emit:fnEm", ptr %t57, i32 0, i32 0
  %t60 = load ptr, ptr %t59, !tbaa !29
  store ptr %t60, ptr %l28, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/emit:fnEm", ptr %t61, i32 0, i32 0
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = getelementptr %"compiler/emit:Emitter", ptr %t64, i32 0, i32 0
  %t67 = load ptr, ptr %t66, !tbaa !29
  store ptr %t67, ptr %l31, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/emit:fnEm", ptr %t68, i32 0, i32 0
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/emit:Emitter", ptr %t71, i32 0, i32 0
  %t74 = load ptr, ptr %t73, !tbaa !29
  store ptr %t74, ptr %l34, !tbaa !29
  %t76 = load ptr, ptr %l34, !tbaa !29
  %t77 = call ptr @__olang_scope_or(ptr %v2, ptr %t76)
  %t78 = call ptr @__olang_scope_hold(ptr %t77)
  %t79 = ptrtoint ptr %t78 to i64
  %t81 = inttoptr i64 %t79 to ptr
  %t82 = load ptr, ptr %l34, !tbaa !29
  %t84 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %t81, ptr %t82, i64 %t55)
  store i64 %t84, ptr %l37
  br label %bb6
bb5:
  br label %bb16
bb6:
  %t85 = load ptr, ptr %l31, !tbaa !29
  %t86 = call ptr @__olang_scope_or(ptr %v2, ptr %t85)
  %t87 = call ptr @__olang_scope_hold(ptr %t86)
  %t88 = ptrtoint ptr %t87 to i64
  %t90 = inttoptr i64 %t88 to ptr
  %t91 = load ptr, ptr %l31, !tbaa !29
  %t92 = load i64, ptr %l37, !tbaa !24
  %t93 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %t90, ptr %s2, ptr %t91, i64 %t92)
  store ptr %t93, ptr %l39
  br label %bb7
bb7:
  %t94 = load ptr, ptr %l39, !tbaa !29
  %t96 = getelementptr %"compiler/ast:Func", ptr %t94, i32 0, i32 2
  %t97 = load i32, ptr %t96, !tbaa !23
  %t98 = load ptr, ptr %l28, !tbaa !29
  %t99 = call ptr @__olang_scope_or(ptr %v2, ptr %t98)
  %t100 = call ptr @__olang_scope_hold(ptr %t99)
  %t101 = ptrtoint ptr %t100 to i64
  %t103 = inttoptr i64 %t101 to ptr
  %t104 = load ptr, ptr %l28, !tbaa !29
  %t106 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %t103, ptr %s2, ptr %t104, i32 %t97)
  store { i64, ptr } %t106, ptr %l43
  br label %bb8
bb8:
  %t107 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t107, 1
  %t109 = extractvalue { i64, ptr } %t107, 0
  %t110 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t109)
  call void @olang_textcopy(ptr %t110, ptr %t108, i64 %t109)
  %t111 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l6, !tbaa !27
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/emit:fnEm", ptr %t114, i32 0, i32 0
  %t117 = load ptr, ptr %t116, !tbaa !29
  store ptr %t117, ptr %l46, !tbaa !29
  %t118 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t119 = load ptr, ptr %l46, !tbaa !29
  %t120 = call ptr @__olang_scope_or(ptr %v2, ptr %t119)
  %t121 = call ptr @__olang_scope_hold(ptr %t120)
  %t122 = ptrtoint ptr %t121 to i64
  %t124 = inttoptr i64 %t122 to ptr
  %t125 = load ptr, ptr %l46, !tbaa !29
  %t127 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehas(ptr %t124, ptr %s2, ptr %t125, { i64, ptr } %t118)
  store i1 %t127, ptr %l49
  br label %bb9
bb9:
  %t128 = load i1, ptr %l49, !tbaa !21
  %t129 = xor i1 %t128, true
  br i1 %t129, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/emit:fnEm", ptr %t131, i32 0, i32 0
  %t134 = load ptr, ptr %t133, !tbaa !29
  store ptr %t134, ptr %l52, !tbaa !29
  %t135 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t135, ptr %l53, !tbaa !27
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/emit:fnEm", ptr %t136, i32 0, i32 0
  %t139 = load ptr, ptr %t138, !tbaa !29
  store ptr %t139, ptr %l55, !tbaa !29
  %t140 = load i32, ptr %l2, !tbaa !23
  %t141 = load ptr, ptr %l55, !tbaa !29
  %t142 = call ptr @__olang_scope_or(ptr %v2, ptr %t141)
  %t143 = call ptr @__olang_scope_hold(ptr %t142)
  %t144 = ptrtoint ptr %t143 to i64
  %t146 = inttoptr i64 %t144 to ptr
  %t147 = load ptr, ptr %l55, !tbaa !29
  %t149 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecHeader(ptr %t146, ptr %s4, ptr %t147, i32 %t140)
  store { i64, ptr } %t149, ptr %l58
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t150 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t150, ptr %l59, !tbaa !27
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/emit:fnEm", ptr %t151, i32 0, i32 0
  %t154 = load ptr, ptr %t153, !tbaa !29
  store ptr %t154, ptr %l61, !tbaa !29
  %t155 = load i32, ptr %l2, !tbaa !23
  %t156 = load ptr, ptr %l61, !tbaa !29
  %t157 = call ptr @__olang_scope_or(ptr %v2, ptr %t156)
  %t158 = call ptr @__olang_scope_hold(ptr %t157)
  %t159 = ptrtoint ptr %t158 to i64
  %t161 = inttoptr i64 %t159 to ptr
  %t162 = load ptr, ptr %l61, !tbaa !29
  %t164 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecParamList(ptr %t161, ptr %s4, ptr %t162, i32 %t155, i1 false)
  store { i64, ptr } %t164, ptr %l64
  br label %bb13
bb13:
  %t165 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t166 = extractvalue { i64, ptr } %t165, 1
  %t167 = extractvalue { i64, ptr } %t165, 0
  %t168 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d166, i32 0, i32 1) }, 1
  %t169 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d166, i32 0, i32 1) }, 0
  %t170 = add i64 %t167, %t169
  %t171 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t172 = extractvalue { i64, ptr } %t171, 1
  %t173 = extractvalue { i64, ptr } %t171, 0
  %t174 = add i64 %t170, %t173
  %t175 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d167, i32 0, i32 1) }, 1
  %t176 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d167, i32 0, i32 1) }, 0
  %t177 = add i64 %t174, %t176
  %t178 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t178, 1
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t181 = add i64 %t177, %t180
  %t182 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d168, i32 0, i32 1) }, 1
  %t183 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d168, i32 0, i32 1) }, 0
  %t184 = add i64 %t181, %t183
  %t185 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t184)
  call void @olang_textcopy(ptr %t185, ptr %t166, i64 %t167)
  %t186 = getelementptr i8, ptr %t185, i64 %t167
  call void @olang_textcopy(ptr %t186, ptr %t168, i64 %t169)
  %t187 = getelementptr i8, ptr %t186, i64 %t169
  call void @olang_textcopy(ptr %t187, ptr %t172, i64 %t173)
  %t188 = getelementptr i8, ptr %t187, i64 %t173
  call void @olang_textcopy(ptr %t188, ptr %t175, i64 %t176)
  %t189 = getelementptr i8, ptr %t188, i64 %t176
  call void @olang_textcopy(ptr %t189, ptr %t179, i64 %t180)
  %t190 = getelementptr i8, ptr %t189, i64 %t180
  call void @olang_textcopy(ptr %t190, ptr %t182, i64 %t183)
  %t191 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t185, 1
  %t194 = load ptr, ptr %l52, !tbaa !29
  %t195 = call ptr @__olang_scope_or(ptr %v2, ptr %t194)
  %t196 = call ptr @__olang_scope_hold(ptr %t195)
  %t197 = ptrtoint ptr %t196 to i64
  %t199 = inttoptr i64 %t197 to ptr
  %t200 = load ptr, ptr %l52, !tbaa !29
  %t201 = load { i64, ptr }, ptr %l53, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %t199, ptr %s2, ptr %s4, ptr %t200, { i64, ptr } %t201, { i64, ptr } %t192)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb15
bb15:
  %t203 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t204 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d169, i32 0, i32 1) }, 1
  %t205 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d169, i32 0, i32 1) }, 0
  %t207 = extractvalue { i64, ptr } %t203, 1
  %t208 = extractvalue { i64, ptr } %t203, 0
  %t209 = add i64 %t205, %t208
  %t210 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t209)
  call void @olang_textcopy(ptr %t210, ptr %t204, i64 %t205)
  %t211 = getelementptr i8, ptr %t210, i64 %t205
  call void @olang_textcopy(ptr %t211, ptr %t207, i64 %t208)
  %t212 = insertvalue { i64, ptr } undef, i64 %t209, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %t210, 1
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t213, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t215 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s0, ptr %v2, ptr %t215, { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d170, i32 0, i32 1) })
  br label %bb18
bb18:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d171, i32 0, i32 1) }, ptr %l71, !tbaa !27
  %t217 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t217, ptr %l72, !tbaa !27
  %t218 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t219 = extractvalue { i64, ptr } %t218, 0
  store i64 %t219, ptr %l73, !tbaa !24
  %t220 = load i64, ptr %l73, !tbaa !24
  %t221 = mul i64 %t220, 1
  %t222 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t221)
  %t223 = insertvalue { i64, ptr } undef, i64 %t220, 0
  %t224 = insertvalue { i64, ptr } %t223, ptr %t222, 1
  store { i64, ptr } %t224, ptr %l74, !tbaa !27
  %t225 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t228 = load ptr, ptr %t227, !tbaa !27
  %t229 = load i64, ptr %l73, !tbaa !24
  %t230 = mul i64 %t229, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t226, ptr %t228, i64 %t230, i1 false)
  %t231 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t231, ptr %l72, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t232 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t232, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ecallSym(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, %"compiler/mir:Call" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i32
  %l3 = alloca %"compiler/mir:Call"
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca %"compiler/lower:Clone"
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, [4 x i64] }
  %l15 = alloca i64
  %l16 = alloca i64
  %l26 = alloca ptr
  %l30 = alloca %"compiler/lower:Clone"
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l35 = alloca i32
  %l40 = alloca { i64, ptr }
  %l46 = alloca i64
  %l49 = alloca i64
  %l70 = alloca { i64, [4 x i64] }
  %l75 = alloca i1
  %l76 = alloca { i64, ptr }
  %l81 = alloca i1
  %l84 = alloca i32
  %l87 = alloca i1
  %l90 = alloca { i64, [4 x i64] }
  %l93 = alloca i1
  %l96 = alloca { i64, [4 x i64] }
  %l102 = alloca ptr
  %l108 = alloca i64
  %l111 = alloca ptr
  %l114 = alloca { i64, ptr }
  %l118 = alloca ptr
  %l121 = alloca { i64, ptr }
  %l122 = alloca ptr
  %l125 = alloca i1
  %l127 = alloca ptr
  %l130 = alloca { i64, ptr }
  %l133 = alloca i64
  %l135 = alloca ptr
  %l136 = alloca ptr
  %l140 = alloca { i64, ptr }
  %l146 = alloca i64
  %l147 = alloca i32
  %l150 = alloca { i64, ptr }
  %l151 = alloca ptr
  %l154 = alloca { i64, ptr }
  %l155 = alloca ptr
  %l158 = alloca { i64, ptr }
  %l163 = alloca ptr
  %l166 = alloca { i64, ptr }
  %s8 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/mir:Call" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = getelementptr %"compiler/emit:Emitter", ptr %t6, i32 0, i32 3
  %t9 = load ptr, ptr %t8, !tbaa !29
  store ptr %t9, ptr %l5, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/emit:fnEm", ptr %t11, i32 0, i32 40
  %t14 = load i64, ptr %t13, !tbaa !24
  %t16 = icmp sge i64 %t14, 0
  br i1 %t16, label %bb1, label %bb2
bb1:
  %t18 = load ptr, ptr %l4, !tbaa !29
  %t20 = getelementptr %"compiler/emit:Emitter", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/lower:Lowerer", ptr %t21, i32 0, i32 52
  store ptr %t23, ptr %l26, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/emit:fnEm", ptr %t24, i32 0, i32 40
  %t27 = load i64, ptr %t26, !tbaa !24
  %t28 = load ptr, ptr %l26, !tbaa !29
  %t29 = call ptr @__olang_scope_or(ptr %v2, ptr %t28)
  %t30 = call ptr @__olang_scope_hold(ptr %t29)
  %t31 = ptrtoint ptr %t30 to i64
  %t33 = inttoptr i64 %t31 to ptr
  %t34 = load ptr, ptr %l26, !tbaa !29
  %t36 = call %"compiler/lower:Clone" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aClone_3e_2eAt_3ccompiler_2flower_3aClone_3e(ptr %t33, ptr %t34, i64 %t27)
  store %"compiler/lower:Clone" %t36, ptr %l30
  br label %bb3
bb2:
  br label %bb43
bb3:
  %t37 = load %"compiler/lower:Clone", ptr %l30
  store %"compiler/lower:Clone" %t37, ptr %l6
  %t38 = load ptr, ptr %l5, !tbaa !29
  store ptr %t38, ptr %l31, !tbaa !29
  %t39 = load ptr, ptr %l5, !tbaa !29
  store ptr %t39, ptr %l32, !tbaa !29
  %t40 = load i32, ptr %l2, !tbaa !23
  %t41 = load ptr, ptr %l32, !tbaa !29
  %t42 = call ptr @__olang_scope_or(ptr %v2, ptr %t41)
  %t43 = call ptr @__olang_scope_hold(ptr %t42)
  %t44 = ptrtoint ptr %t43 to i64
  %t46 = inttoptr i64 %t44 to ptr
  %t47 = load ptr, ptr %l32, !tbaa !29
  %t49 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %t46, ptr %t47, i32 %t40)
  store i32 %t49, ptr %l35
  br label %bb4
bb4:
  %t50 = load ptr, ptr %l31, !tbaa !29
  %t51 = call ptr @__olang_scope_or(ptr %v2, ptr %t50)
  %t52 = call ptr @__olang_scope_hold(ptr %t51)
  %t53 = ptrtoint ptr %t52 to i64
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/emit:fnEm", ptr %t54, i32 0, i32 0
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = call ptr @__olang_scope_or(ptr %v2, ptr %t57)
  %t60 = call ptr @__olang_scope_hold(ptr %t59)
  %t61 = ptrtoint ptr %t60 to i64
  %t63 = inttoptr i64 %t53 to ptr
  %t65 = inttoptr i64 %t61 to ptr
  %t66 = load ptr, ptr %l31, !tbaa !29
  %t67 = load i32, ptr %l35, !tbaa !23
  %t68 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t63, ptr %t65, ptr %t66, i32 %t67)
  store { i64, ptr } %t68, ptr %l40
  br label %bb5
bb5:
  %t69 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t69, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t70 = getelementptr %"compiler/mir:Call", ptr %l3, i32 0, i32 1
  %t71 = getelementptr %"compiler/mir:Range", ptr %t70, i32 0, i32 1
  %t72 = load i32, ptr %t71, !tbaa !23
  %t74 = sext i32 %t72 to i64
  store i64 %t74, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t76 = load i64, ptr %l9, !tbaa !24
  %t77 = load i64, ptr %l8, !tbaa !24
  %t80 = icmp sgt i64 %t76, %t77
  br i1 %t80, label %bb6, label %bb7
bb6:
  %t82 = load i64, ptr %l10, !tbaa !24
  %t84 = icmp sgt i64 %t82, 0
  br i1 %t84, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb11
bb8:
  %t86 = load i64, ptr %l9, !tbaa !24
  %t87 = load i64, ptr %l8, !tbaa !24
  %t90 = sub i64 %t86, %t87
  %t91 = load i64, ptr %l10, !tbaa !24
  %t94 = add i64 %t90, %t91
  %t96 = sub i64 %t94, 1
  %t97 = load i64, ptr %l10, !tbaa !24
  %t100 = sdiv i64 %t96, %t97
  store i64 %t100, ptr %l49, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb10
bb10:
  %t102 = load i64, ptr %l49, !tbaa !24
  store i64 %t102, ptr %l46, !tbaa !24
  br label %bb11
bb11:
  %t103 = load i64, ptr %l46, !tbaa !24
  store i64 %t103, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb12
bb12:
  %t104 = load i64, ptr %l12, !tbaa !24
  %t105 = load i64, ptr %l11, !tbaa !24
  %t108 = icmp slt i64 %t104, %t105
  %t110 = xor i1 %t108, true
  br i1 %t110, label %bb13, label %bb14
bb13:
  br label %bb41
bb14:
  br label %bb15
bb15:
  %t112 = load i64, ptr %l8, !tbaa !24
  %t113 = load i64, ptr %l12, !tbaa !24
  %t114 = load i64, ptr %l10, !tbaa !24
  %t117 = mul i64 %t113, %t114
  %t120 = add i64 %t112, %t117
  store i64 %t120, ptr %l13, !tbaa !24
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/mir:Call", ptr %l3, i32 0, i32 1
  %t124 = load %"compiler/mir:Range", ptr %t123
  %t125 = load i64, ptr %l13, !tbaa !24
  %t129 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %v3, ptr %t122, %"compiler/mir:Range" %t124, i64 %t125)
  store { i64, [4 x i64] } %t129, ptr %l70
  br label %bb16
bb16:
  %t130 = load { i64, [4 x i64] }, ptr %l70
  store { i64, [4 x i64] } %t130, ptr %l14
  %t131 = load i64, ptr %l13, !tbaa !24
  %t132 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t132, 0
  %t137 = icmp sge i64 %t131, %t134
  br i1 %t137, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l75, !tbaa !21
  br label %bb19
bb18:
  %t139 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t139, ptr %l76, !tbaa !27
  %t140 = load i64, ptr %l13, !tbaa !24
  %t142 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr i32, ptr %t143, i64 %t140
  %t145 = load i32, ptr %t144, !tbaa !33
  %t146 = getelementptr %"compiler/lower:Clone", ptr %l6, i32 0, i32 3
  %t147 = load i32, ptr %t146, !tbaa !23
  %t150 = icmp ne i32 %t145, %t147
  store i1 %t150, ptr %l75, !tbaa !21
  br label %bb19
bb19:
  %t152 = load i1, ptr %l75, !tbaa !21
  br i1 %t152, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l81, !tbaa !21
  br label %bb23
bb21:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load { i64, [4 x i64] }, ptr %l14
  %t157 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %v3, ptr %v2, ptr %t153, { i64, [4 x i64] } %t154)
  store i32 %t157, ptr %l84
  br label %bb22
bb22:
  %t158 = getelementptr %"compiler/lower:Clone", ptr %l6, i32 0, i32 3
  %t159 = load i32, ptr %t158, !tbaa !23
  %t160 = load i32, ptr %l84, !tbaa !23
  %t162 = icmp ne i32 %t160, %t159
  store i1 %t162, ptr %l81, !tbaa !21
  br label %bb23
bb23:
  %t164 = load i1, ptr %l81, !tbaa !21
  br i1 %t164, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l87, !tbaa !21
  br label %bb31
bb25:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load { i64, [4 x i64] }, ptr %l14
  %t169 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2eknownOf(ptr %v0, ptr %v3, ptr %t165, { i64, [4 x i64] } %t166)
  store { i64, [4 x i64] } %t169, ptr %l90
  br label %bb26
bb26:
  %t170 = load { i64, [4 x i64] }, ptr %l90
  %t172 = extractvalue { i64, [4 x i64] } %t170, 0
  %t173 = icmp eq i64 %t172, 1
  br i1 %t173, label %bb27, label %bb28
bb27:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load { i64, [4 x i64] }, ptr %l14
  %t179 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2eknownOf(ptr %v0, ptr %v3, ptr %t175, { i64, [4 x i64] } %t176)
  store { i64, [4 x i64] } %t179, ptr %l96
  br label %bb29
bb28:
  store i1 false, ptr %l93, !tbaa !21
  br label %bb30
bb29:
  %t180 = getelementptr { i64, [4 x i64] }, ptr %l96, i32 0, i32 1
  %t181 = getelementptr { i64 }, ptr %t180, i32 0, i32 0
  %t182 = load i64, ptr %t181
  %t183 = getelementptr %"compiler/lower:Clone", ptr %l6, i32 0, i32 1
  %t184 = load i64, ptr %t183, !tbaa !24
  %t187 = icmp eq i64 %t182, %t184
  store i1 %t187, ptr %l93, !tbaa !21
  br label %bb30
bb30:
  %t189 = load i1, ptr %l93, !tbaa !21
  %t190 = xor i1 %t189, true
  store i1 %t190, ptr %l87, !tbaa !21
  br label %bb31
bb31:
  %t192 = load i1, ptr %l87, !tbaa !21
  br i1 %t192, label %bb32, label %bb33
bb32:
  br label %bb40
bb33:
  br label %bb34
bb34:
  %t193 = load ptr, ptr %l4, !tbaa !29
  %t195 = getelementptr %"compiler/emit:Emitter", ptr %t193, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !29
  store ptr %t196, ptr %l102, !tbaa !29
  %t197 = load { i64, [2 x i64] }, ptr %l1
  %t198 = load i64, ptr %l13, !tbaa !24
  %t199 = getelementptr %"compiler/lower:Clone", ptr %l6, i32 0, i32 2
  %t200 = load { i64, [2 x i64] }, ptr %t199
  %t201 = getelementptr %"compiler/lower:Clone", ptr %l6, i32 0, i32 3
  %t202 = load i32, ptr %t201, !tbaa !23
  %t203 = load ptr, ptr %l102, !tbaa !29
  %t204 = call ptr @__olang_scope_or(ptr %v2, ptr %t203)
  %t205 = call ptr @__olang_scope_hold(ptr %t204)
  %t206 = ptrtoint ptr %t205 to i64
  %t208 = inttoptr i64 %t206 to ptr
  %t209 = load ptr, ptr %l102, !tbaa !29
  %t214 = call i64 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eCloneOf(ptr %t208, ptr %t209, { i64, [2 x i64] } %t197, i64 %t198, { i64, [2 x i64] } %t200, i32 %t202)
  store i64 %t214, ptr %l108
  br label %bb35
bb35:
  %t215 = load i64, ptr %l108, !tbaa !24
  store i64 %t215, ptr %l15, !tbaa !24
  %t216 = load i64, ptr %l15, !tbaa !24
  %t218 = icmp sge i64 %t216, 0
  br i1 %t218, label %bb36, label %bb37
bb36:
  %t220 = load ptr, ptr %l4, !tbaa !29
  store ptr %t220, ptr %l111, !tbaa !29
  %t221 = load i64, ptr %l15, !tbaa !24
  %t222 = load ptr, ptr %l111, !tbaa !29
  %t223 = call ptr @__olang_scope_or(ptr %v2, ptr %t222)
  %t224 = call ptr @__olang_scope_hold(ptr %t223)
  %t225 = ptrtoint ptr %t224 to i64
  %t227 = inttoptr i64 %t225 to ptr
  %t228 = load ptr, ptr %l111, !tbaa !29
  %t230 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecloneSym(ptr %t227, ptr %v1, ptr %t228, i64 %t221)
  store { i64, ptr } %t230, ptr %l114
  br label %bb38
bb37:
  br label %bb39
bb38:
  %t231 = load { i64, ptr }, ptr %l114, !tbaa !27
  store { i64, ptr } %t231, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  %t232 = load i64, ptr %l12, !tbaa !24
  %t235 = add i64 %t232, 1
  store i64 %t235, ptr %l12, !tbaa !24
  br label %bb12
bb41:
  %t237 = load ptr, ptr %l4, !tbaa !29
  store ptr %t237, ptr %l118, !tbaa !29
  %t238 = load { i64, [2 x i64] }, ptr %l1
  %t239 = load ptr, ptr %l118, !tbaa !29
  %t240 = call ptr @__olang_scope_or(ptr %v2, ptr %t239)
  %t241 = call ptr @__olang_scope_hold(ptr %t240)
  %t242 = ptrtoint ptr %t241 to i64
  %t244 = inttoptr i64 %t242 to ptr
  %t245 = load ptr, ptr %l118, !tbaa !29
  %t247 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %t244, ptr %v1, ptr %t245, { i64, [2 x i64] } %t238)
  store { i64, ptr } %t247, ptr %l121
  br label %bb42
bb42:
  %t248 = load { i64, ptr }, ptr %l121, !tbaa !27
  store { i64, ptr } %t248, ptr %rv
  br label %ret
bb43:
  %t249 = load ptr, ptr %l4, !tbaa !29
  store ptr %t249, ptr %l122, !tbaa !29
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load ptr, ptr %l122, !tbaa !29
  %t252 = call ptr @__olang_scope_or(ptr %v2, ptr %t251)
  %t253 = call ptr @__olang_scope_hold(ptr %t252)
  %t254 = ptrtoint ptr %t253 to i64
  %t256 = inttoptr i64 %t254 to ptr
  %t257 = load ptr, ptr %l122, !tbaa !29
  %t259 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2esiteable(ptr %t256, ptr %v0, ptr %t257, ptr %t250)
  store i1 %t259, ptr %l125
  br label %bb44
bb44:
  %t260 = load i1, ptr %l125, !tbaa !21
  %t261 = xor i1 %t260, true
  br i1 %t261, label %bb45, label %bb46
bb45:
  %t263 = load ptr, ptr %l4, !tbaa !29
  store ptr %t263, ptr %l127, !tbaa !29
  %t264 = load { i64, [2 x i64] }, ptr %l1
  %t265 = load ptr, ptr %l127, !tbaa !29
  %t266 = call ptr @__olang_scope_or(ptr %v2, ptr %t265)
  %t267 = call ptr @__olang_scope_hold(ptr %t266)
  %t268 = ptrtoint ptr %t267 to i64
  %t270 = inttoptr i64 %t268 to ptr
  %t271 = load ptr, ptr %l127, !tbaa !29
  %t273 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %t270, ptr %v1, ptr %t271, { i64, [2 x i64] } %t264)
  store { i64, ptr } %t273, ptr %l130
  br label %bb47
bb46:
  br label %bb48
bb47:
  %t274 = load { i64, ptr }, ptr %l130, !tbaa !27
  store { i64, ptr } %t274, ptr %rv
  br label %ret
bb48:
  %t275 = load ptr, ptr %l4, !tbaa !29
  %t277 = getelementptr %"compiler/emit:Emitter", ptr %t275, i32 0, i32 56
  %t278 = load i1, ptr %t277, !tbaa !21
  br i1 %t278, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s8
  %t280 = load ptr, ptr %l4, !tbaa !29
  %t282 = getelementptr %"compiler/emit:Emitter", ptr %t280, i32 0, i32 55
  store ptr %t282, ptr %l135, !tbaa !29
  %t283 = load ptr, ptr %l4, !tbaa !29
  store ptr %t283, ptr %l136, !tbaa !29
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t286 = getelementptr %"compiler/emit:fnEm", ptr %t284, i32 0, i32 2
  %t287 = load { i64, [2 x i64] }, ptr %t286
  %t288 = load ptr, ptr %l136, !tbaa !29
  %t289 = call ptr @__olang_scope_or(ptr %v2, ptr %t288)
  %t290 = call ptr @__olang_scope_hold(ptr %t289)
  %t291 = ptrtoint ptr %t290 to i64
  %t293 = inttoptr i64 %t291 to ptr
  %t294 = load ptr, ptr %l136, !tbaa !29
  %t296 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %t293, ptr %s8, ptr %t294, { i64, [2 x i64] } %t287)
  store { i64, ptr } %t296, ptr %l140
  br label %bb51
bb50:
  br label %bb61
bb51:
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t299 = getelementptr %"compiler/emit:fnEm", ptr %t297, i32 0, i32 39
  %t300 = load i64, ptr %t299, !tbaa !24
  %t301 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t302 = extractvalue { i64, ptr } %t301, 1
  %t303 = extractvalue { i64, ptr } %t301, 0
  %t304 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d172, i32 0, i32 1) }, 1
  %t305 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d172, i32 0, i32 1) }, 0
  %t306 = add i64 %t303, %t305
  %t308 = call i64 @__olang_fmt_i64(ptr null, i64 %t300)
  %t309 = add i64 %t306, %t308
  %t310 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t309)
  call void @olang_textcopy(ptr %t310, ptr %t302, i64 %t303)
  %t311 = getelementptr i8, ptr %t310, i64 %t303
  call void @olang_textcopy(ptr %t311, ptr %t304, i64 %t305)
  %t312 = getelementptr i8, ptr %t311, i64 %t305
  %t313 = call i64 @__olang_fmt_i64(ptr %t312, i64 %t300)
  %t314 = insertvalue { i64, ptr } undef, i64 %t309, 0
  %t315 = insertvalue { i64, ptr } %t314, ptr %t310, 1
  %t317 = load ptr, ptr %l135, !tbaa !29
  %t318 = call ptr @__olang_scope_or(ptr %v2, ptr %t317)
  %t319 = call ptr @__olang_scope_hold(ptr %t318)
  %t320 = ptrtoint ptr %t319 to i64
  %t322 = inttoptr i64 %t320 to ptr
  %t323 = load ptr, ptr %l135, !tbaa !29
  %t325 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %t322, ptr %s8, ptr %t323, { i64, ptr } %t315)
  %t326 = extractvalue { i32, i64 } %t325, 1
  %t327 = extractvalue { i32, i64 } %t325, 0
  store i32 %t327, ptr %l147
  %t328 = icmp ne i32 %t327, 0
  br i1 %t328, label %bb53, label %ok.329, !prof !99
ok.329:
  store i64 %t326, ptr %l146
  br label %bb52
bb52:
  %t330 = load i64, ptr %l146, !tbaa !24
  store i64 %t330, ptr %l133, !tbaa !24
  br label %bb55
bb53:
  br label %bb54
bb54:
  store i64 -1, ptr %l133, !tbaa !24
  br label %bb55
bb55:
  %t331 = load i64, ptr %l133, !tbaa !24
  store i64 %t331, ptr %l16, !tbaa !24
  %t332 = load i64, ptr %l16, !tbaa !24
  %t334 = icmp sge i64 %t332, 0
  br i1 %t334, label %bb56, label %bb57
bb56:
  %t336 = load ptr, ptr %l4, !tbaa !29
  store ptr %t336, ptr %l151, !tbaa !29
  %t337 = load i64, ptr %l16, !tbaa !24
  %t338 = load ptr, ptr %l151, !tbaa !29
  %t339 = call ptr @__olang_scope_or(ptr %v2, ptr %t338)
  %t340 = call ptr @__olang_scope_hold(ptr %t339)
  %t341 = ptrtoint ptr %t340 to i64
  %t343 = inttoptr i64 %t341 to ptr
  %t344 = load ptr, ptr %l151, !tbaa !29
  %t346 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecloneSym(ptr %t343, ptr %v1, ptr %t344, i64 %t337)
  store { i64, ptr } %t346, ptr %l154
  br label %bb58
bb57:
  %t347 = load ptr, ptr %l4, !tbaa !29
  store ptr %t347, ptr %l155, !tbaa !29
  %t348 = load { i64, [2 x i64] }, ptr %l1
  %t349 = load ptr, ptr %l155, !tbaa !29
  %t350 = call ptr @__olang_scope_or(ptr %v2, ptr %t349)
  %t351 = call ptr @__olang_scope_hold(ptr %t350)
  %t352 = ptrtoint ptr %t351 to i64
  %t354 = inttoptr i64 %t352 to ptr
  %t355 = load ptr, ptr %l155, !tbaa !29
  %t357 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %t354, ptr %v1, ptr %t355, { i64, [2 x i64] } %t348)
  store { i64, ptr } %t357, ptr %l158
  br label %bb59
bb58:
  %t358 = load { i64, ptr }, ptr %l154, !tbaa !27
  store { i64, ptr } %t358, ptr %l150, !tbaa !27
  br label %bb60
bb59:
  %t359 = load { i64, ptr }, ptr %l158, !tbaa !27
  store { i64, ptr } %t359, ptr %l150, !tbaa !27
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s8)
  %t360 = load { i64, ptr }, ptr %l150, !tbaa !27
  store { i64, ptr } %t360, ptr %rv
  br label %ret
bb61:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load { i64, [2 x i64] }, ptr %l1
  %t363 = load i32, ptr %l2, !tbaa !23
  %t364 = load %"compiler/mir:Call", ptr %l3
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2enoteSites(ptr %v0, ptr %v2, ptr %v3, ptr %t361, { i64, [2 x i64] } %t362, i32 %t363, %"compiler/mir:Call" %t364)
  br label %bb62
bb62:
  %t369 = load ptr, ptr %l4, !tbaa !29
  store ptr %t369, ptr %l163, !tbaa !29
  %t370 = load { i64, [2 x i64] }, ptr %l1
  %t371 = load ptr, ptr %l163, !tbaa !29
  %t372 = call ptr @__olang_scope_or(ptr %v2, ptr %t371)
  %t373 = call ptr @__olang_scope_hold(ptr %t372)
  %t374 = ptrtoint ptr %t373 to i64
  %t376 = inttoptr i64 %t374 to ptr
  %t377 = load ptr, ptr %l163, !tbaa !29
  %t379 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %t376, ptr %v1, ptr %t377, { i64, [2 x i64] } %t370)
  store { i64, ptr } %t379, ptr %l166
  br label %bb63
bb63:
  %t380 = load { i64, ptr }, ptr %l166, !tbaa !27
  store { i64, ptr } %t380, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ecloneCode(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [4 x i64] }
  %l3 = alloca %"compiler/lower:Clone"
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l18 = alloca %"compiler/lower:Clone"
  %l22 = alloca i1
  %l25 = alloca { i64, [4 x i64] }
  %l28 = alloca i1
  %l31 = alloca { i64, [4 x i64] }
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca { i64, ptr }
  %l41 = alloca ptr
  %l45 = alloca ptr
  %l49 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [4 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 40
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp slt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d173, i32 0, i32 1) }, ptr %l7, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t8, ptr %l8, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l9, !tbaa !24
  %t11 = load i64, ptr %l9, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l10, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l9, !tbaa !24
  %t21 = mul i64 %t20, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  %t22 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t22, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t23 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t23, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/emit:fnEm", ptr %t24, i32 0, i32 0
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/emit:Emitter", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/lower:Lowerer", ptr %t30, i32 0, i32 52
  store ptr %t32, ptr %l14, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/emit:fnEm", ptr %t33, i32 0, i32 40
  %t36 = load i64, ptr %t35, !tbaa !24
  %t37 = load ptr, ptr %l14, !tbaa !29
  %t38 = call ptr @__olang_scope_or(ptr %v2, ptr %t37)
  %t39 = call ptr @__olang_scope_hold(ptr %t38)
  %t40 = ptrtoint ptr %t39 to i64
  %t42 = inttoptr i64 %t40 to ptr
  %t43 = load ptr, ptr %l14, !tbaa !29
  %t45 = call %"compiler/lower:Clone" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aClone_3e_2eAt_3ccompiler_2flower_3aClone_3e(ptr %t42, ptr %t43, i64 %t36)
  store %"compiler/lower:Clone" %t45, ptr %l18
  br label %bb4
bb4:
  %t46 = load %"compiler/lower:Clone", ptr %l18
  store %"compiler/lower:Clone" %t46, ptr %l3
  %t48 = getelementptr %"compiler/lower:Clone", ptr %l3, i32 0, i32 3
  %t49 = load i32, ptr %t48, !tbaa !23
  %t52 = icmp ne i32 %a2, %t49
  br i1 %t52, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb12
bb6:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load { i64, [4 x i64] }, ptr %l1
  %t58 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2eknownOf(ptr %v0, ptr %v3, ptr %t54, { i64, [4 x i64] } %t55)
  store { i64, [4 x i64] } %t58, ptr %l25
  br label %bb7
bb7:
  %t59 = load { i64, [4 x i64] }, ptr %l25
  %t61 = extractvalue { i64, [4 x i64] } %t59, 0
  %t62 = icmp eq i64 %t61, 1
  br i1 %t62, label %bb8, label %bb9
bb8:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load { i64, [4 x i64] }, ptr %l1
  %t68 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2eknownOf(ptr %v0, ptr %v3, ptr %t64, { i64, [4 x i64] } %t65)
  store { i64, [4 x i64] } %t68, ptr %l31
  br label %bb10
bb9:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb11
bb10:
  %t69 = getelementptr { i64, [4 x i64] }, ptr %l31, i32 0, i32 1
  %t70 = getelementptr { i64 }, ptr %t69, i32 0, i32 0
  %t71 = load i64, ptr %t70
  %t72 = getelementptr %"compiler/lower:Clone", ptr %l3, i32 0, i32 1
  %t73 = load i64, ptr %t72, !tbaa !24
  %t76 = icmp eq i64 %t71, %t73
  store i1 %t76, ptr %l28, !tbaa !21
  br label %bb11
bb11:
  %t78 = load i1, ptr %l28, !tbaa !21
  %t79 = xor i1 %t78, true
  store i1 %t79, ptr %l22, !tbaa !21
  br label %bb12
bb12:
  %t81 = load i1, ptr %l22, !tbaa !21
  br i1 %t81, label %bb13, label %bb14
bb13:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d174, i32 0, i32 1) }, ptr %l36, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t82, ptr %l37, !tbaa !27
  %t83 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 0
  store i64 %t84, ptr %l38, !tbaa !24
  %t85 = load i64, ptr %l38, !tbaa !24
  %t86 = mul i64 %t85, 1
  %t87 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t86)
  %t88 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t87, 1
  store { i64, ptr } %t89, ptr %l39, !tbaa !27
  %t90 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = load i64, ptr %l38, !tbaa !24
  %t95 = mul i64 %t94, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t91, ptr %t93, i64 %t95, i1 false)
  %t96 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t96, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t97 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t97, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/emit:fnEm", ptr %t98, i32 0, i32 0
  %t101 = load ptr, ptr %t100, !tbaa !29
  store ptr %t101, ptr %l41, !tbaa !29
  %t102 = getelementptr %"compiler/lower:Clone", ptr %l3, i32 0, i32 2
  %t103 = load { i64, [2 x i64] }, ptr %t102
  %t104 = load ptr, ptr %l41, !tbaa !29
  %t105 = call ptr @__olang_scope_or(ptr %v2, ptr %t104)
  %t106 = call ptr @__olang_scope_hold(ptr %t105)
  %t107 = ptrtoint ptr %t106 to i64
  %t109 = inttoptr i64 %t107 to ptr
  %t110 = load ptr, ptr %l41, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewant(ptr %t109, ptr %t110, { i64, [2 x i64] } %t103)
  br label %bb16
bb16:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/emit:fnEm", ptr %t112, i32 0, i32 0
  %t115 = load ptr, ptr %t114, !tbaa !29
  store ptr %t115, ptr %l45, !tbaa !29
  %t116 = getelementptr %"compiler/lower:Clone", ptr %l3, i32 0, i32 2
  %t117 = load { i64, [2 x i64] }, ptr %t116
  %t118 = getelementptr %"compiler/lower:Clone", ptr %l3, i32 0, i32 3
  %t119 = load i32, ptr %t118, !tbaa !23
  %t120 = load ptr, ptr %l45, !tbaa !29
  %t121 = call ptr @__olang_scope_or(ptr %v2, ptr %t120)
  %t122 = call ptr @__olang_scope_hold(ptr %t121)
  %t123 = ptrtoint ptr %t122 to i64
  %t125 = inttoptr i64 %t123 to ptr
  %t126 = load ptr, ptr %l45, !tbaa !29
  %t129 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecodeFor(ptr %t125, ptr %s0, ptr %t126, { i64, [2 x i64] } %t117, i32 %t119)
  store { i64, ptr } %t129, ptr %l49
  br label %bb17
bb17:
  %t130 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d175, i32 0, i32 1) }, 1
  %t131 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d175, i32 0, i32 1) }, 0
  %t132 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t132, 1
  %t134 = extractvalue { i64, ptr } %t132, 0
  %t135 = add i64 %t131, %t134
  %t136 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t135)
  call void @olang_textcopy(ptr %t136, ptr %t130, i64 %t131)
  %t137 = getelementptr i8, ptr %t136, i64 %t131
  call void @olang_textcopy(ptr %t137, ptr %t133, i64 %t134)
  %t138 = insertvalue { i64, ptr } undef, i64 %t135, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t136, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t139, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2efindDirect(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i1
  %l18 = alloca { i64, [21 x i64] }
  %l19 = alloca i32
  %l20 = alloca i1
  %l23 = alloca ptr
  %l25 = alloca i64
  %l29 = alloca i64
  %l32 = alloca i64
  %l52 = alloca ptr
  %l58 = alloca ptr
  %l60 = alloca ptr
  %l62 = alloca i64
  %l67 = alloca i64
  %l70 = alloca i64
  %l88 = alloca ptr
  %l90 = alloca ptr
  %l93 = alloca { i64, [21 x i64] }
  %l95 = alloca i64
  %l103 = alloca i1
  %l104 = alloca ptr
  %l106 = alloca ptr
  %l109 = alloca { i64, [21 x i64] }
  %l112 = alloca i1
  %l121 = alloca ptr
  %l123 = alloca ptr
  %l126 = alloca { i64, [21 x i64] }
  %l129 = alloca i1
  %l131 = alloca ptr
  %l135 = alloca { i64, [21 x i64] }
  %l136 = alloca i1
  %l137 = alloca { i64, [21 x i64] }
  %l145 = alloca i1
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/mir:Fn", ptr %t4, i32 0, i32 9
  store ptr %t6, ptr %l23, !tbaa !29
  %t7 = load ptr, ptr %l23, !tbaa !29
  %t8 = call ptr @__olang_scope_or(ptr %v1, ptr %t7)
  %t9 = call ptr @__olang_scope_hold(ptr %t8)
  %t10 = ptrtoint ptr %t9 to i64
  %t12 = inttoptr i64 %t10 to ptr
  %t13 = load ptr, ptr %l23, !tbaa !29
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %t12, ptr %t13)
  store i64 %t14, ptr %l25
  br label %bb1
bb1:
  %t15 = load i64, ptr %l25, !tbaa !24
  store i64 %t15, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb2, label %bb3
bb2:
  %t22 = load i64, ptr %l3, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb7
bb4:
  %t26 = load i64, ptr %l2, !tbaa !24
  %t27 = load i64, ptr %l1, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l3, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l3, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l32, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb6
bb6:
  %t42 = load i64, ptr %l32, !tbaa !24
  store i64 %t42, ptr %l29, !tbaa !24
  br label %bb7
bb7:
  %t43 = load i64, ptr %l29, !tbaa !24
  store i64 %t43, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb9, label %bb10
bb9:
  br label %bb65
bb10:
  br label %bb11
bb11:
  %t52 = load i64, ptr %l1, !tbaa !24
  %t53 = load i64, ptr %l5, !tbaa !24
  %t54 = load i64, ptr %l3, !tbaa !24
  %t57 = mul i64 %t53, %t54
  %t60 = add i64 %t52, %t57
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/emit:fnEm", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/mir:Fn", ptr %t65, i32 0, i32 9
  store ptr %t67, ptr %l52, !tbaa !29
  %t69 = load ptr, ptr %l52, !tbaa !29
  %t70 = call ptr @__olang_scope_or(ptr %v1, ptr %t69)
  %t71 = call ptr @__olang_scope_hold(ptr %t70)
  %t72 = ptrtoint ptr %t71 to i64
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/emit:fnEm", ptr %t73, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = call ptr @__olang_scope_or(ptr %v1, ptr %t76)
  %t79 = call ptr @__olang_scope_hold(ptr %t78)
  %t80 = ptrtoint ptr %t79 to i64
  %t82 = inttoptr i64 %t72 to ptr
  %t84 = inttoptr i64 %t80 to ptr
  %t85 = load ptr, ptr %l52, !tbaa !29
  %t87 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eRef_3ccompiler_2fmir_3aBasicBlock_3e(ptr %t82, ptr %t84, ptr %t85, i64 %t60)
  store ptr %t87, ptr %l58
  br label %bb12
bb12:
  %t88 = load ptr, ptr %l58, !tbaa !29
  store ptr %t88, ptr %l7, !tbaa !29
  %t89 = load ptr, ptr %l7, !tbaa !29
  %t91 = getelementptr %"compiler/mir:BasicBlock", ptr %t89, i32 0, i32 0
  store ptr %t91, ptr %l60, !tbaa !29
  %t92 = load ptr, ptr %l60, !tbaa !29
  %t93 = call ptr @__olang_scope_or(ptr %v1, ptr %t92)
  %t94 = call ptr @__olang_scope_hold(ptr %t93)
  %t95 = ptrtoint ptr %t94 to i64
  %t97 = inttoptr i64 %t95 to ptr
  %t98 = load ptr, ptr %l60, !tbaa !29
  %t99 = call i64 @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eLen(ptr %t97, ptr %t98)
  store i64 %t99, ptr %l62
  br label %bb13
bb13:
  %t100 = load i64, ptr %l62, !tbaa !24
  store i64 %t100, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  %t101 = load i64, ptr %l8, !tbaa !24
  store i64 %t101, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t103 = load i64, ptr %l10, !tbaa !24
  %t104 = load i64, ptr %l9, !tbaa !24
  %t107 = icmp sgt i64 %t103, %t104
  br i1 %t107, label %bb14, label %bb15
bb14:
  %t109 = load i64, ptr %l11, !tbaa !24
  %t111 = icmp sgt i64 %t109, 0
  br i1 %t111, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l67, !tbaa !24
  br label %bb19
bb16:
  %t113 = load i64, ptr %l10, !tbaa !24
  %t114 = load i64, ptr %l9, !tbaa !24
  %t117 = sub i64 %t113, %t114
  %t118 = load i64, ptr %l11, !tbaa !24
  %t121 = add i64 %t117, %t118
  %t123 = sub i64 %t121, 1
  %t124 = load i64, ptr %l11, !tbaa !24
  %t127 = sdiv i64 %t123, %t124
  store i64 %t127, ptr %l70, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l70, !tbaa !24
  br label %bb18
bb18:
  %t129 = load i64, ptr %l70, !tbaa !24
  store i64 %t129, ptr %l67, !tbaa !24
  br label %bb19
bb19:
  %t130 = load i64, ptr %l67, !tbaa !24
  store i64 %t130, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s4
  %t131 = load i64, ptr %l13, !tbaa !24
  %t132 = load i64, ptr %l12, !tbaa !24
  %t135 = icmp slt i64 %t131, %t132
  %t137 = xor i1 %t135, true
  br i1 %t137, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s4)
  br label %bb63
bb22:
  br label %bb23
bb23:
  %t139 = load i64, ptr %l9, !tbaa !24
  %t140 = load i64, ptr %l13, !tbaa !24
  %t141 = load i64, ptr %l11, !tbaa !24
  %t144 = mul i64 %t140, %t141
  %t147 = add i64 %t139, %t144
  store i64 %t147, ptr %l14, !tbaa !24
  %t149 = load ptr, ptr %l0, !tbaa !29
  store ptr %t149, ptr %l88, !tbaa !29
  %t150 = load ptr, ptr %l7, !tbaa !29
  %t152 = getelementptr %"compiler/mir:BasicBlock", ptr %t150, i32 0, i32 0
  store ptr %t152, ptr %l90, !tbaa !29
  %t153 = load i64, ptr %l14, !tbaa !24
  %t154 = load ptr, ptr %l90, !tbaa !29
  %t155 = call ptr @__olang_scope_or(ptr %v1, ptr %t154)
  %t156 = call ptr @__olang_scope_hold(ptr %t155)
  %t157 = ptrtoint ptr %t156 to i64
  %t159 = inttoptr i64 %t157 to ptr
  %t160 = load ptr, ptr %l90, !tbaa !29
  %t162 = call { i64, [21 x i64] } @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eAt(ptr %t159, ptr %t160, i64 %t153)
  store { i64, [21 x i64] } %t162, ptr %l93
  br label %bb24
bb24:
  %t163 = load ptr, ptr %l88, !tbaa !29
  %t165 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ebuilderOpened(ptr %v0, ptr %s4, ptr %v1, ptr %t163, ptr %l93)
  store i64 %t165, ptr %l95
  br label %bb25
bb25:
  %t166 = load i64, ptr %l95, !tbaa !24
  store i64 %t166, ptr %l15, !tbaa !24
  %t167 = load i64, ptr %l15, !tbaa !24
  %t169 = icmp slt i64 %t167, 0
  br i1 %t169, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s4)
  br label %bb62
bb27:
  br label %bb28
bb28:
  %t171 = load i64, ptr %l14, !tbaa !24
  %t173 = add i64 %t171, 1
  store i64 %t173, ptr %l16, !tbaa !24
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s6
  %t175 = load i64, ptr %l16, !tbaa !24
  %t176 = load i64, ptr %l8, !tbaa !24
  %t179 = icmp slt i64 %t175, %t176
  br i1 %t179, label %bb30, label %bb31
bb30:
  %t181 = load ptr, ptr %l0, !tbaa !29
  store ptr %t181, ptr %l104, !tbaa !29
  %t182 = load ptr, ptr %l7, !tbaa !29
  %t184 = getelementptr %"compiler/mir:BasicBlock", ptr %t182, i32 0, i32 0
  store ptr %t184, ptr %l106, !tbaa !29
  %t185 = load i64, ptr %l16, !tbaa !24
  %t186 = load ptr, ptr %l106, !tbaa !29
  %t187 = call ptr @__olang_scope_or(ptr %v1, ptr %t186)
  %t188 = call ptr @__olang_scope_hold(ptr %t187)
  %t189 = ptrtoint ptr %t188 to i64
  %t191 = inttoptr i64 %t189 to ptr
  %t192 = load ptr, ptr %l106, !tbaa !29
  %t194 = call { i64, [21 x i64] } @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eAt(ptr %t191, ptr %t192, i64 %t185)
  store { i64, [21 x i64] } %t194, ptr %l109
  br label %bb32
bb31:
  store i1 false, ptr %l103, !tbaa !21
  br label %bb34
bb32:
  %t195 = load { i64, [21 x i64] }, ptr %l109
  %t196 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 176, i64 8)
  store { i64, [21 x i64] } %t195, ptr %t196
  %t197 = load i64, ptr %l15, !tbaa !24
  %t198 = load ptr, ptr %l104, !tbaa !29
  %t201 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eplainWrite(ptr %v0, ptr %s6, ptr %t198, ptr %t196, i64 %t197)
  store i1 %t201, ptr %l112
  br label %bb33
bb33:
  %t202 = load i1, ptr %l112, !tbaa !21
  store i1 %t202, ptr %l103, !tbaa !21
  br label %bb34
bb34:
  %t203 = load i1, ptr %l103, !tbaa !21
  %t204 = xor i1 %t203, true
  br i1 %t204, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s6)
  br label %bb39
bb36:
  br label %bb37
bb37:
  %t206 = load i64, ptr %l16, !tbaa !24
  %t209 = add i64 %t206, 1
  store i64 %t209, ptr %l16, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb38
bb38:
  br label %bb29
bb39:
  %t211 = load i64, ptr %l16, !tbaa !24
  %t213 = add i64 %t211, 1
  %t214 = load i64, ptr %l8, !tbaa !24
  %t217 = icmp sge i64 %t213, %t214
  br i1 %t217, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s4)
  br label %bb62
bb41:
  br label %bb42
bb42:
  %t219 = load ptr, ptr %l0, !tbaa !29
  store ptr %t219, ptr %l121, !tbaa !29
  %t220 = load ptr, ptr %l7, !tbaa !29
  %t222 = getelementptr %"compiler/mir:BasicBlock", ptr %t220, i32 0, i32 0
  store ptr %t222, ptr %l123, !tbaa !29
  %t223 = load i64, ptr %l16, !tbaa !24
  %t224 = load ptr, ptr %l123, !tbaa !29
  %t225 = call ptr @__olang_scope_or(ptr %v1, ptr %t224)
  %t226 = call ptr @__olang_scope_hold(ptr %t225)
  %t227 = ptrtoint ptr %t226 to i64
  %t229 = inttoptr i64 %t227 to ptr
  %t230 = load ptr, ptr %l123, !tbaa !29
  %t232 = call { i64, [21 x i64] } @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eAt(ptr %t229, ptr %t230, i64 %t223)
  store { i64, [21 x i64] } %t232, ptr %l126
  br label %bb43
bb43:
  %t233 = load { i64, [21 x i64] }, ptr %l126
  %t234 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 176, i64 8)
  store { i64, [21 x i64] } %t233, ptr %t234
  %t235 = load i64, ptr %l15, !tbaa !24
  %t236 = load ptr, ptr %l121, !tbaa !29
  %t239 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2etextInto(ptr %v0, ptr %s4, ptr %t236, ptr %t234, i64 %t235)
  store i1 %t239, ptr %l129
  br label %bb44
bb44:
  %t240 = load i1, ptr %l129, !tbaa !21
  store i1 %t240, ptr %l17, !tbaa !21
  %t241 = load ptr, ptr %l7, !tbaa !29
  %t243 = getelementptr %"compiler/mir:BasicBlock", ptr %t241, i32 0, i32 0
  store ptr %t243, ptr %l131, !tbaa !29
  %t244 = load i64, ptr %l16, !tbaa !24
  %t246 = add i64 %t244, 1
  %t247 = load ptr, ptr %l131, !tbaa !29
  %t248 = call ptr @__olang_scope_or(ptr %v1, ptr %t247)
  %t249 = call ptr @__olang_scope_hold(ptr %t248)
  %t250 = ptrtoint ptr %t249 to i64
  %t252 = inttoptr i64 %t250 to ptr
  %t253 = load ptr, ptr %l131, !tbaa !29
  %t255 = call { i64, [21 x i64] } @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eAt(ptr %t252, ptr %t253, i64 %t246)
  store { i64, [21 x i64] } %t255, ptr %l135
  br label %bb45
bb45:
  call void @llvm.memmove.p0.p0.i64(ptr %l18, ptr %l135, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l137, ptr %l18, i64 176, i1 false)
  %t256 = load { i64, [21 x i64] }, ptr %l137
  %t257 = extractvalue { i64, [21 x i64] } %t256, 0
  %t258 = icmp eq i64 %t257, 4
  br i1 %t258, label %bb46, label %bb47
bb46:
  %t260 = getelementptr { i64, [21 x i64] }, ptr %l18, i32 0, i32 1
  %t261 = getelementptr { %"compiler/source:Span", i32 }, ptr %t260, i32 0, i32 1
  %t262 = load i32, ptr %t261
  store i32 %t262, ptr %l19, !tbaa !23
  br label %bb48
bb47:
  br label %bb49
bb48:
  %t264 = load i32, ptr %l19, !tbaa !23
  %t266 = sext i32 %t264 to i64
  %t267 = load i64, ptr %l15, !tbaa !24
  %t270 = icmp eq i64 %t266, %t267
  store i1 %t270, ptr %l136, !tbaa !21
  br label %bb54
bb49:
  br i1 true, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  store i1 false, ptr %l136, !tbaa !21
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_8a0f087481b95ab0_a13f080fe7b316d4)
  unreachable
bb54:
  %t272 = load i1, ptr %l136, !tbaa !21
  store i1 %t272, ptr %l20, !tbaa !21
  %t273 = load i1, ptr %l17, !tbaa !21
  br i1 %t273, label %bb55, label %bb56
bb55:
  %t275 = load i1, ptr %l20, !tbaa !21
  store i1 %t275, ptr %l145, !tbaa !21
  br label %bb57
bb56:
  store i1 false, ptr %l145, !tbaa !21
  br label %bb57
bb57:
  %t277 = load i1, ptr %l145, !tbaa !21
  br i1 %t277, label %bb58, label %bb59
bb58:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr %"compiler/emit:fnEm", ptr %t278, i32 0, i32 25
  %t281 = load i64, ptr %l15, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t280, i64 %t281, i1 true)
  br label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s4)
  br label %bb62
bb62:
  %t284 = load i64, ptr %l13, !tbaa !24
  %t287 = add i64 %t284, 1
  store i64 %t287, ptr %l13, !tbaa !24
  br label %bb20
bb63:
  br label %bb64
bb64:
  %t289 = load i64, ptr %l5, !tbaa !24
  %t292 = add i64 %t289, 1
  store i64 %t292, ptr %l5, !tbaa !24
  br label %bb8
bb65:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2egenOwn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca ptr
  %l20 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca ptr
  %l47 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l49 = alloca i32
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l68 = alloca ptr
  %l69 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2femit_2ecompiler_2femit_3afnEm_2egenLeaves(ptr %v0, ptr %s0, ptr %v3, ptr %t1, i32 %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l15
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l4
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/emit:fnEm", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l17, !tbaa !29
  %t11 = load ptr, ptr %l17, !tbaa !29
  %t12 = call ptr @__olang_scope_or(ptr %v3, ptr %t11)
  %t13 = call ptr @__olang_scope_hold(ptr %t12)
  %t14 = ptrtoint ptr %t13 to i64
  %t16 = inttoptr i64 %t14 to ptr
  %t17 = load ptr, ptr %l17, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %t16, ptr %s0, ptr %t17, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d176, i32 0, i32 1) })
  br label %bb2
bb2:
  store i64 0, ptr %l5, !tbaa !24
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eLen_3cArray_3cI64_3e_3e(ptr %s0, ptr %l4)
  store i64 %t19, ptr %l20
  br label %bb3
bb3:
  %t20 = load i64, ptr %l20, !tbaa !24
  store i64 %t20, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t21 = load i64, ptr %l6, !tbaa !24
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = icmp sgt i64 %t21, %t22
  br i1 %t25, label %bb4, label %bb5
bb4:
  %t27 = load i64, ptr %l7, !tbaa !24
  %t29 = icmp sgt i64 %t27, 0
  br i1 %t29, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb9
bb6:
  %t31 = load i64, ptr %l6, !tbaa !24
  %t32 = load i64, ptr %l5, !tbaa !24
  %t35 = sub i64 %t31, %t32
  %t36 = load i64, ptr %l7, !tbaa !24
  %t39 = add i64 %t35, %t36
  %t41 = sub i64 %t39, 1
  %t42 = load i64, ptr %l7, !tbaa !24
  %t45 = sdiv i64 %t41, %t42
  store i64 %t45, ptr %l27, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb8
bb8:
  %t47 = load i64, ptr %l27, !tbaa !24
  store i64 %t47, ptr %l24, !tbaa !24
  br label %bb9
bb9:
  %t48 = load i64, ptr %l24, !tbaa !24
  store i64 %t48, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t49 = load i64, ptr %l9, !tbaa !24
  %t50 = load i64, ptr %l8, !tbaa !24
  %t53 = icmp slt i64 %t49, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb12:
  br label %bb13
bb13:
  %t57 = load i64, ptr %l5, !tbaa !24
  %t58 = load i64, ptr %l9, !tbaa !24
  %t59 = load i64, ptr %l7, !tbaa !24
  %t62 = mul i64 %t58, %t59
  %t65 = add i64 %t57, %t62
  store i64 %t65, ptr %l10, !tbaa !24
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l45, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  store ptr %t68, ptr %l46, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l47, !tbaa !29
  %t70 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t70, ptr %l48, !tbaa !27
  %t71 = load i32, ptr %l2, !tbaa !23
  store i32 %t71, ptr %l49, !tbaa !23
  %t72 = load i64, ptr %l10, !tbaa !24
  %t75 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eAt_3cArray_3cI64_3e_3e(ptr %s0, ptr %s2, ptr %l4, i64 %t72)
  store { i64, ptr } %t75, ptr %l52
  br label %bb14
bb14:
  %t76 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 0
  store i64 %t77, ptr %l53, !tbaa !24
  %t78 = load i64, ptr %l53, !tbaa !24
  %t79 = mul i64 %t78, 8
  %t80 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t79)
  %t81 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t80, 1
  store { i64, ptr } %t82, ptr %l54, !tbaa !27
  %t83 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = load i64, ptr %l53, !tbaa !24
  %t88 = mul i64 %t87, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t84, ptr %t86, i64 %t88, i1 false)
  %t89 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t89, 0
  %t91 = extractvalue { i64, ptr } %t89, 1
  %t92 = mul i64 %t90, 8
  %t93 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t92)
  call void @llvm.memcpy.p0.p0.i64(ptr %t93, ptr %t91, i64 %t92, i1 false)
  %t94 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t93, 1
  %t96 = load ptr, ptr %l47, !tbaa !29
  %t97 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t98 = load i32, ptr %l49, !tbaa !23
  %t100 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eleafAt(ptr %v0, ptr %v1, ptr %s2, ptr %s2, ptr %v3, ptr %t96, { i64, ptr } %t97, i32 %t98, { i64, ptr } %t95)
  store { i64, ptr } %t100, ptr %l56
  br label %bb15
bb15:
  %t101 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d177, i32 0, i32 1) }, 1
  %t102 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d177, i32 0, i32 1) }, 0
  %t103 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 1
  %t105 = extractvalue { i64, ptr } %t103, 0
  %t106 = add i64 %t102, %t105
  %t107 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d178, i32 0, i32 1) }, 1
  %t108 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d178, i32 0, i32 1) }, 0
  %t109 = add i64 %t106, %t108
  %t110 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t109)
  call void @olang_textcopy(ptr %t110, ptr %t101, i64 %t102)
  %t111 = getelementptr i8, ptr %t110, i64 %t102
  call void @olang_textcopy(ptr %t111, ptr %t104, i64 %t105)
  %t112 = getelementptr i8, ptr %t111, i64 %t105
  call void @olang_textcopy(ptr %t112, ptr %t107, i64 %t108)
  %t113 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t110, 1
  %t116 = load ptr, ptr %l46, !tbaa !29
  %t118 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s2, ptr %s2, ptr %v3, ptr %t116, { i64, ptr } %t114)
  store { i64, ptr } %t118, ptr %l59
  br label %bb16
bb16:
  %t119 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t120 = load ptr, ptr %l45, !tbaa !29
  %t122 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s2, ptr %s2, ptr %s2, ptr %s2, ptr %v3, ptr %t120, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d179, i32 0, i32 1) }, { i64, ptr } %t119, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d49, i32 0, i32 1) })
  store { i64, ptr } %t122, ptr %l61
  br label %bb17
bb17:
  %t123 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t127 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d180, i32 0, i32 1) }, 1
  %t128 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d180, i32 0, i32 1) }, 0
  %t130 = extractvalue { i64, ptr } %a3, 1
  %t131 = extractvalue { i64, ptr } %a3, 0
  %t132 = add i64 %t128, %t131
  %t133 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d181, i32 0, i32 1) }, 1
  %t134 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d181, i32 0, i32 1) }, 0
  %t135 = add i64 %t132, %t134
  %t137 = extractvalue { i64, ptr } %t123, 1
  %t138 = extractvalue { i64, ptr } %t123, 0
  %t139 = add i64 %t135, %t138
  %t140 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d182, i32 0, i32 1) }, 1
  %t141 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d182, i32 0, i32 1) }, 0
  %t142 = add i64 %t139, %t141
  %t143 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t142)
  call void @olang_textcopy(ptr %t143, ptr %t127, i64 %t128)
  %t144 = getelementptr i8, ptr %t143, i64 %t128
  call void @olang_textcopy(ptr %t144, ptr %t130, i64 %t131)
  %t145 = getelementptr i8, ptr %t144, i64 %t131
  call void @olang_textcopy(ptr %t145, ptr %t133, i64 %t134)
  %t146 = getelementptr i8, ptr %t145, i64 %t134
  call void @olang_textcopy(ptr %t146, ptr %t137, i64 %t138)
  %t147 = getelementptr i8, ptr %t146, i64 %t138
  call void @olang_textcopy(ptr %t147, ptr %t140, i64 %t141)
  %t148 = insertvalue { i64, ptr } undef, i64 %t142, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t143, 1
  %t153 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s2, ptr %s2, ptr %v3, ptr %t124, { i64, ptr } %t149)
  store { i64, ptr } %t153, ptr %l67
  br label %bb18
bb18:
  %t154 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l68, !tbaa !29
  store { i64, ptr } %t154, ptr %l69, !tbaa !27
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t159 = load i32, ptr %l2, !tbaa !23
  %t160 = load i64, ptr %l10, !tbaa !24
  %t165 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eownWord(ptr %v0, ptr %v1, ptr %s2, ptr %v3, ptr %t157, { i64, ptr } %t158, i32 %t159, i64 %t160)
  store { i64, ptr } %t165, ptr %l74
  br label %bb19
bb19:
  %t166 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d183, i32 0, i32 1) }, 1
  %t167 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d183, i32 0, i32 1) }, 0
  %t168 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t168, 1
  %t170 = extractvalue { i64, ptr } %t168, 0
  %t171 = add i64 %t167, %t170
  %t172 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d184, i32 0, i32 1) }, 1
  %t173 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d184, i32 0, i32 1) }, 0
  %t174 = add i64 %t171, %t173
  %t175 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t176 = extractvalue { i64, ptr } %t175, 1
  %t177 = extractvalue { i64, ptr } %t175, 0
  %t178 = add i64 %t174, %t177
  %t179 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d185, i32 0, i32 1) }, 1
  %t180 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d185, i32 0, i32 1) }, 0
  %t181 = add i64 %t178, %t180
  %t182 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t181)
  call void @olang_textcopy(ptr %t182, ptr %t166, i64 %t167)
  %t183 = getelementptr i8, ptr %t182, i64 %t167
  call void @olang_textcopy(ptr %t183, ptr %t169, i64 %t170)
  %t184 = getelementptr i8, ptr %t183, i64 %t170
  call void @olang_textcopy(ptr %t184, ptr %t172, i64 %t173)
  %t185 = getelementptr i8, ptr %t184, i64 %t173
  call void @olang_textcopy(ptr %t185, ptr %t176, i64 %t177)
  %t186 = getelementptr i8, ptr %t185, i64 %t177
  call void @olang_textcopy(ptr %t186, ptr %t179, i64 %t180)
  %t187 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t182, 1
  %t190 = load ptr, ptr %l68, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s2, ptr %v3, ptr %t190, { i64, ptr } %t188)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb21:
  %t192 = load i64, ptr %l9, !tbaa !24
  %t195 = add i64 %t192, 1
  store i64 %t195, ptr %l9, !tbaa !24
  br label %bb10
bb22:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eindex(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca i32
  %l9 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca ptr
  %l16 = alloca i64
  %l20 = alloca ptr
  %l23 = alloca i64
  %l25 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l36 = alloca i1
  %l37 = alloca { i64, ptr }
  %l38 = alloca ptr
  %l39 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l3, !tbaa !29
  store ptr %t9, ptr %l9, !tbaa !29
  %t11 = load ptr, ptr %l9, !tbaa !29
  %t12 = call ptr @__olang_scope_or(ptr %v3, ptr %t11)
  %t13 = call ptr @__olang_scope_hold(ptr %t12)
  %t14 = ptrtoint ptr %t13 to i64
  %t16 = inttoptr i64 %t14 to ptr
  %t17 = load ptr, ptr %l9, !tbaa !29
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t16, ptr %t17, i32 %a2)
  store i32 %t19, ptr %l12
  br label %bb1
bb1:
  %t20 = load i32, ptr %l12, !tbaa !23
  store i32 %t20, ptr %l4, !tbaa !23
  %t21 = load ptr, ptr %l3, !tbaa !29
  store ptr %t21, ptr %l13, !tbaa !29
  %t22 = load i32, ptr %l4, !tbaa !23
  %t23 = load ptr, ptr %l13, !tbaa !29
  %t24 = call ptr @__olang_scope_or(ptr %v3, ptr %t23)
  %t25 = call ptr @__olang_scope_hold(ptr %t24)
  %t26 = ptrtoint ptr %t25 to i64
  %t28 = inttoptr i64 %t26 to ptr
  %t29 = load ptr, ptr %l13, !tbaa !29
  %t31 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %t28, ptr %t29, i32 %t22)
  store i64 %t31, ptr %l16
  br label %bb2
bb2:
  %t32 = load i64, ptr %l16, !tbaa !24
  %t33 = icmp eq i64 %t32, 64
  br i1 %t33, label %bb3, label %bb4
bb3:
  %t35 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 1
  %t38 = extractvalue { i64, ptr } %t35, 0
  %t39 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t38)
  call void @olang_textcopy(ptr %t39, ptr %t37, i64 %t38)
  %t40 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t41, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t43 = load ptr, ptr %l3, !tbaa !29
  store ptr %t43, ptr %l20, !tbaa !29
  %t44 = load i32, ptr %l4, !tbaa !23
  %t45 = load ptr, ptr %l20, !tbaa !29
  %t46 = call ptr @__olang_scope_or(ptr %v3, ptr %t45)
  %t47 = call ptr @__olang_scope_hold(ptr %t46)
  %t48 = ptrtoint ptr %t47 to i64
  %t50 = inttoptr i64 %t48 to ptr
  %t51 = load ptr, ptr %l20, !tbaa !29
  %t53 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %t50, ptr %t51, i32 %t44)
  store i64 %t53, ptr %l23
  br label %bb6
bb6:
  %t54 = load i64, ptr %l23, !tbaa !24
  %t55 = icmp sgt i64 %t54, 64
  br i1 %t55, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l25, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i32, ptr %l4, !tbaa !23
  %t62 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s3, ptr %v3, ptr %t58, i32 %t59)
  store { i64, ptr } %t62, ptr %l28
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t63 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t64 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d186, i32 0, i32 1) }, 1
  %t65 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d186, i32 0, i32 1) }, 0
  %t66 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 1
  %t68 = extractvalue { i64, ptr } %t66, 0
  %t69 = add i64 %t65, %t68
  %t70 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d187, i32 0, i32 1) }, 1
  %t71 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d187, i32 0, i32 1) }, 0
  %t72 = add i64 %t69, %t71
  %t74 = extractvalue { i64, ptr } %t63, 1
  %t75 = extractvalue { i64, ptr } %t63, 0
  %t76 = add i64 %t72, %t75
  %t77 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d188, i32 0, i32 1) }, 1
  %t78 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d188, i32 0, i32 1) }, 0
  %t79 = add i64 %t76, %t78
  %t80 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t79)
  call void @olang_textcopy(ptr %t80, ptr %t64, i64 %t65)
  %t81 = getelementptr i8, ptr %t80, i64 %t65
  call void @olang_textcopy(ptr %t81, ptr %t67, i64 %t68)
  %t82 = getelementptr i8, ptr %t81, i64 %t68
  call void @olang_textcopy(ptr %t82, ptr %t70, i64 %t71)
  %t83 = getelementptr i8, ptr %t82, i64 %t71
  call void @olang_textcopy(ptr %t83, ptr %t74, i64 %t75)
  %t84 = getelementptr i8, ptr %t83, i64 %t75
  call void @olang_textcopy(ptr %t84, ptr %t77, i64 %t78)
  %t85 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t80, 1
  %t88 = load ptr, ptr %l25, !tbaa !29
  %t90 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s3, ptr %v2, ptr %v3, ptr %t88, { i64, ptr } %t86)
  store { i64, ptr } %t90, ptr %l32
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t91 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t91, ptr %rv
  br label %ret
bb11:
  %t92 = load ptr, ptr %l3, !tbaa !29
  store ptr %t92, ptr %l33, !tbaa !29
  %t93 = load i32, ptr %l4, !tbaa !23
  %t94 = load ptr, ptr %l33, !tbaa !29
  %t95 = call ptr @__olang_scope_or(ptr %v3, ptr %t94)
  %t96 = call ptr @__olang_scope_hold(ptr %t95)
  %t97 = ptrtoint ptr %t96 to i64
  %t99 = inttoptr i64 %t97 to ptr
  %t100 = load ptr, ptr %l33, !tbaa !29
  %t102 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %t99, ptr %t100, i32 %t93)
  store i1 %t102, ptr %l36
  br label %bb12
bb12:
  %t103 = load i1, ptr %l36, !tbaa !21
  br i1 %t103, label %bb13, label %bb14
bb13:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d189, i32 0, i32 1) }, ptr %l37, !tbaa !27
  br label %bb15
bb14:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d190, i32 0, i32 1) }, ptr %l37, !tbaa !27
  br label %bb15
bb15:
  %t104 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l38, !tbaa !29
  store { i64, ptr } %t104, ptr %l39, !tbaa !27
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i32, ptr %l4, !tbaa !23
  %t111 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s0, ptr %v3, ptr %t107, i32 %t108)
  store { i64, ptr } %t111, ptr %l42
  br label %bb16
bb16:
  %t112 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t113 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 1
  %t115 = extractvalue { i64, ptr } %t113, 0
  %t116 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d191, i32 0, i32 1) }, 1
  %t117 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d191, i32 0, i32 1) }, 0
  %t118 = add i64 %t115, %t117
  %t119 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t119, 1
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t122 = add i64 %t118, %t121
  %t123 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d191, i32 0, i32 1) }, 1
  %t124 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d191, i32 0, i32 1) }, 0
  %t125 = add i64 %t122, %t124
  %t127 = extractvalue { i64, ptr } %t112, 1
  %t128 = extractvalue { i64, ptr } %t112, 0
  %t129 = add i64 %t125, %t128
  %t130 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d192, i32 0, i32 1) }, 1
  %t131 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d192, i32 0, i32 1) }, 0
  %t132 = add i64 %t129, %t131
  %t133 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t132)
  call void @olang_textcopy(ptr %t133, ptr %t114, i64 %t115)
  %t134 = getelementptr i8, ptr %t133, i64 %t115
  call void @olang_textcopy(ptr %t134, ptr %t116, i64 %t117)
  %t135 = getelementptr i8, ptr %t134, i64 %t117
  call void @olang_textcopy(ptr %t135, ptr %t120, i64 %t121)
  %t136 = getelementptr i8, ptr %t135, i64 %t121
  call void @olang_textcopy(ptr %t136, ptr %t123, i64 %t124)
  %t137 = getelementptr i8, ptr %t136, i64 %t124
  call void @olang_textcopy(ptr %t137, ptr %t127, i64 %t128)
  %t138 = getelementptr i8, ptr %t137, i64 %t128
  call void @olang_textcopy(ptr %t138, ptr %t130, i64 %t131)
  %t139 = insertvalue { i64, ptr } undef, i64 %t132, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr %t133, 1
  %t142 = load ptr, ptr %l38, !tbaa !29
  %t144 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %v2, ptr %v3, ptr %t142, { i64, ptr } %t140)
  store { i64, ptr } %t144, ptr %l46
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t145 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t145, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epackedPrim(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i32 %a1, i32 %a2, %"compiler/mir:Range" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/mir:Range"
  %l4 = alloca ptr
  %l5 = alloca { i64, [4 x i64] }
  %l6 = alloca i32
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l21 = alloca { i64, [4 x i64] }
  %l22 = alloca ptr
  %l25 = alloca i32
  %l27 = alloca i32
  %l30 = alloca { i64, [4 x i64] }
  %l31 = alloca i64
  %l38 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l44 = alloca i32
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l56 = alloca ptr
  %l59 = alloca i64
  %l63 = alloca { i64, ptr }
  %l66 = alloca ptr
  %l72 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l77 = alloca ptr
  %l78 = alloca { i64, ptr }
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca ptr
  %l83 = alloca ptr
  %l86 = alloca { i64, [4 x i64] }
  %l88 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store %"compiler/mir:Range" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load %"compiler/mir:Range", ptr %l3
  %t13 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %v2, ptr %t9, %"compiler/mir:Range" %t10, i64 0)
  store { i64, [4 x i64] } %t13, ptr %l21
  br label %bb1
bb1:
  %t14 = load { i64, [4 x i64] }, ptr %l21
  store { i64, [4 x i64] } %t14, ptr %l5
  %t15 = load ptr, ptr %l4, !tbaa !29
  store ptr %t15, ptr %l22, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load { i64, [4 x i64] }, ptr %l5
  %t20 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %v2, ptr %v3, ptr %t16, { i64, [4 x i64] } %t17)
  store i32 %t20, ptr %l25
  br label %bb2
bb2:
  %t21 = load ptr, ptr %l22, !tbaa !29
  %t22 = call ptr @__olang_scope_or(ptr %v3, ptr %t21)
  %t23 = call ptr @__olang_scope_hold(ptr %t22)
  %t24 = ptrtoint ptr %t23 to i64
  %t26 = inttoptr i64 %t24 to ptr
  %t27 = load ptr, ptr %l22, !tbaa !29
  %t28 = load i32, ptr %l25, !tbaa !23
  %t29 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t26, ptr %t27, i32 %t28)
  store i32 %t29, ptr %l27
  br label %bb3
bb3:
  %t30 = load i32, ptr %l27, !tbaa !23
  store i32 %t30, ptr %l6, !tbaa !23
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load %"compiler/mir:Range", ptr %l3
  %t35 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %v2, ptr %t31, %"compiler/mir:Range" %t32, i64 1)
  store { i64, [4 x i64] } %t35, ptr %l30
  br label %bb4
bb4:
  %t36 = load { i64, [4 x i64] }, ptr %l30
  store { i64, [4 x i64] } %t36, ptr %l7
  %t37 = load { i64, [4 x i64] }, ptr %l7
  %t39 = extractvalue { i64, [4 x i64] } %t37, 0
  %t40 = icmp eq i64 %t39, 2
  br i1 %t40, label %bb5, label %bb6
bb5:
  %t42 = getelementptr { i64, [4 x i64] }, ptr %l7, i32 0, i32 1
  %t43 = getelementptr { i32, i64 }, ptr %t42, i32 0, i32 1
  %t44 = load i64, ptr %t43
  store i64 %t44, ptr %l8, !tbaa !24
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t46 = load i64, ptr %l8, !tbaa !24
  store i64 %t46, ptr %l31, !tbaa !24
  br label %bb13
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_961c92f0031f8566_93f78080bb0935c2)
  unreachable
bb13:
  %t48 = load i64, ptr %l31, !tbaa !24
  store i64 %t48, ptr %l9, !tbaa !24
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i32, ptr %l6, !tbaa !23
  %t53 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %v3, ptr %t49, i32 %t50)
  store i64 %t53, ptr %l38
  br label %bb14
bb14:
  %t54 = load i64, ptr %l38, !tbaa !24
  %t55 = mul i64 8, %t54
  store i64 %t55, ptr %l10, !tbaa !24
  %t57 = load ptr, ptr %l4, !tbaa !29
  store ptr %t57, ptr %l40, !tbaa !29
  %t58 = load ptr, ptr %l4, !tbaa !29
  store ptr %t58, ptr %l41, !tbaa !29
  %t59 = load i32, ptr %l6, !tbaa !23
  %t60 = load ptr, ptr %l41, !tbaa !29
  %t61 = call ptr @__olang_scope_or(ptr %v3, ptr %t60)
  %t62 = call ptr @__olang_scope_hold(ptr %t61)
  %t63 = ptrtoint ptr %t62 to i64
  %t65 = inttoptr i64 %t63 to ptr
  %t66 = load ptr, ptr %l41, !tbaa !29
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %t65, ptr %t66, i32 %t59)
  store i32 %t68, ptr %l44
  br label %bb15
bb15:
  %t69 = load ptr, ptr %l40, !tbaa !29
  %t70 = call ptr @__olang_scope_or(ptr %v3, ptr %t69)
  %t71 = call ptr @__olang_scope_hold(ptr %t70)
  %t72 = ptrtoint ptr %t71 to i64
  %t74 = inttoptr i64 %t72 to ptr
  %t75 = load ptr, ptr %l40, !tbaa !29
  %t76 = load i32, ptr %l44, !tbaa !23
  %t77 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t74, ptr %s0, ptr %t75, i32 %t76)
  store { i64, ptr } %t77, ptr %l46
  br label %bb16
bb16:
  %t78 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t78, ptr %l47, !tbaa !27
  %t79 = load i64, ptr %l9, !tbaa !24
  %t81 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr i32, ptr %t82, i64 %t79
  %t84 = load i32, ptr %t83, !tbaa !33
  store i32 %t84, ptr %l11, !tbaa !23
  %t86 = load ptr, ptr %l4, !tbaa !29
  store ptr %t86, ptr %l50, !tbaa !29
  %t87 = load i32, ptr %l6, !tbaa !23
  %t88 = load ptr, ptr %l50, !tbaa !29
  %t89 = call ptr @__olang_scope_or(ptr %v3, ptr %t88)
  %t90 = call ptr @__olang_scope_hold(ptr %t89)
  %t91 = ptrtoint ptr %t90 to i64
  %t93 = inttoptr i64 %t91 to ptr
  %t94 = load ptr, ptr %l50, !tbaa !29
  %t96 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBitOffsets(ptr %t93, ptr %s0, ptr %t94, i32 %t87)
  store { i64, ptr } %t96, ptr %l53
  br label %bb17
bb17:
  %t97 = load i64, ptr %l9, !tbaa !24
  %t99 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr i64, ptr %t100, i64 %t97
  %t102 = load i64, ptr %t101, !tbaa !34
  store i64 %t102, ptr %l12, !tbaa !24
  %t104 = load ptr, ptr %l4, !tbaa !29
  store ptr %t104, ptr %l56, !tbaa !29
  %t105 = load i32, ptr %l11, !tbaa !23
  %t106 = load ptr, ptr %l56, !tbaa !29
  %t107 = call ptr @__olang_scope_or(ptr %v3, ptr %t106)
  %t108 = call ptr @__olang_scope_hold(ptr %t107)
  %t109 = ptrtoint ptr %t108 to i64
  %t111 = inttoptr i64 %t109 to ptr
  %t112 = load ptr, ptr %l56, !tbaa !29
  %t114 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePackedBits(ptr %t111, ptr %t112, i32 %t105)
  store i64 %t114, ptr %l59
  br label %bb18
bb18:
  %t115 = load i64, ptr %l59, !tbaa !24
  store i64 %t115, ptr %l13, !tbaa !24
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load { i64, [4 x i64] }, ptr %l5
  %t118 = load i32, ptr %l6, !tbaa !23
  %t122 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epackedBits(ptr %v0, ptr %s0, ptr %v3, ptr %v2, ptr %t116, { i64, [4 x i64] } %t117, i32 %t118)
  store { i64, ptr } %t122, ptr %l63
  br label %bb19
bb19:
  %t123 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t123, ptr %l14, !tbaa !27
  %t126 = trunc i64 42 to i32
  %t127 = icmp eq i32 %a1, %t126
  br i1 %t127, label %bb20, label %bb21
bb20:
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l66, !tbaa !29
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t132 = load i64, ptr %l10, !tbaa !24
  %t133 = load i64, ptr %l12, !tbaa !24
  %t134 = load i64, ptr %l13, !tbaa !24
  %t140 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ecut(ptr %v0, ptr %s0, ptr %v1, ptr %v3, ptr %t130, { i64, ptr } %t131, i64 %t132, i64 %t133, i64 %t134)
  store { i64, ptr } %t140, ptr %l72
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t141 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t142 = load i64, ptr %l13, !tbaa !24
  %t143 = load i32, ptr %l11, !tbaa !23
  %t144 = load ptr, ptr %l66, !tbaa !29
  %t148 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efromBits(ptr %v0, ptr %v1, ptr %v1, ptr %v3, ptr %t144, { i64, ptr } %t141, i64 %t142, i32 %t143)
  store { i64, ptr } %t148, ptr %l76
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  %t149 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t149, ptr %rv
  br label %ret
bb24:
  %t150 = load ptr, ptr %l0, !tbaa !29
  store ptr %t150, ptr %l77, !tbaa !29
  %t151 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t151, ptr %l78, !tbaa !27
  %t152 = load i64, ptr %l10, !tbaa !24
  store i64 %t152, ptr %l79, !tbaa !24
  %t153 = load i64, ptr %l12, !tbaa !24
  store i64 %t153, ptr %l80, !tbaa !24
  %t154 = load i64, ptr %l13, !tbaa !24
  store i64 %t154, ptr %l81, !tbaa !24
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l82, !tbaa !29
  %t156 = load ptr, ptr %l0, !tbaa !29
  store ptr %t156, ptr %l83, !tbaa !29
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load %"compiler/mir:Range", ptr %l3
  %t161 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %v2, ptr %t157, %"compiler/mir:Range" %t158, i64 2)
  store { i64, [4 x i64] } %t161, ptr %l86
  br label %bb25
bb25:
  %t162 = load i32, ptr %l11, !tbaa !23
  %t163 = load ptr, ptr %l83, !tbaa !29
  %t164 = load { i64, [4 x i64] }, ptr %l86
  %t166 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s0, ptr %v2, ptr %v3, ptr %t163, { i64, [4 x i64] } %t164, i32 %t162)
  store { i64, ptr } %t166, ptr %l88
  br label %bb26
bb26:
  %t167 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t168 = load i32, ptr %l11, !tbaa !23
  %t169 = load i64, ptr %l13, !tbaa !24
  %t170 = load ptr, ptr %l82, !tbaa !29
  %t174 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2etoBits(ptr %v0, ptr %s0, ptr %s0, ptr %v3, ptr %t170, { i64, ptr } %t167, i32 %t168, i64 %t169)
  store { i64, ptr } %t174, ptr %l92
  br label %bb27
bb27:
  %t175 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t176 = load ptr, ptr %l77, !tbaa !29
  %t177 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t178 = load i64, ptr %l79, !tbaa !24
  %t179 = load i64, ptr %l80, !tbaa !24
  %t180 = load i64, ptr %l81, !tbaa !24
  %t182 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eplaceBits(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %v3, ptr %t176, { i64, ptr } %t177, i64 %t178, i64 %t179, i64 %t180, { i64, ptr } %t175)
  store { i64, ptr } %t182, ptr %l94
  br label %bb28
bb28:
  %t183 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = load i32, ptr %l6, !tbaa !23
  %t190 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2easPacked(ptr %v0, ptr %s0, ptr %v1, ptr %v3, ptr %t184, { i64, ptr } %t183, i32 %t186)
  store { i64, ptr } %t190, ptr %l98
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s0)
  %t191 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t191, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eplaceBits(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, i64 %a2, i64 %a3, i64 %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l69 = alloca ptr
  %l70 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l4, !tbaa !24
  %t3 = icmp eq i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 1
  %t8 = extractvalue { i64, ptr } %t5, 0
  %t9 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t8)
  call void @olang_textcopy(ptr %t9, ptr %t7, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t11, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t13 = load i64, ptr %l2, !tbaa !24
  %t14 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d193, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d193, i32 0, i32 1) }, 0
  %t17 = call i64 @__olang_fmt_i64(ptr null, i64 %t13)
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t14, i64 %t15)
  %t20 = getelementptr i8, ptr %t19, i64 %t15
  %t21 = call i64 @__olang_fmt_i64(ptr %t20, i64 %t13)
  %t22 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t19, 1
  store { i64, ptr } %t23, ptr %l6, !tbaa !27
  %t25 = load i64, ptr %l4, !tbaa !24
  %t26 = load i64, ptr %l2, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  br i1 %t29, label %bb4, label %bb5
bb4:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i64, ptr %l4, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t35 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d194, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d194, i32 0, i32 1) }, 0
  %t38 = call i64 @__olang_fmt_i64(ptr null, i64 %t32)
  %t39 = add i64 %t36, %t38
  %t40 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d195, i32 0, i32 1) }, 1
  %t41 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d195, i32 0, i32 1) }, 0
  %t42 = add i64 %t39, %t41
  %t44 = extractvalue { i64, ptr } %t33, 1
  %t45 = extractvalue { i64, ptr } %t33, 0
  %t46 = add i64 %t42, %t45
  %t47 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d196, i32 0, i32 1) }, 1
  %t48 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d196, i32 0, i32 1) }, 0
  %t49 = add i64 %t46, %t48
  %t51 = extractvalue { i64, ptr } %t34, 1
  %t52 = extractvalue { i64, ptr } %t34, 0
  %t53 = add i64 %t49, %t52
  %t54 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t53)
  call void @olang_textcopy(ptr %t54, ptr %t35, i64 %t36)
  %t55 = getelementptr i8, ptr %t54, i64 %t36
  %t56 = call i64 @__olang_fmt_i64(ptr %t55, i64 %t32)
  %t57 = getelementptr i8, ptr %t55, i64 %t38
  call void @olang_textcopy(ptr %t57, ptr %t40, i64 %t41)
  %t58 = getelementptr i8, ptr %t57, i64 %t41
  call void @olang_textcopy(ptr %t58, ptr %t44, i64 %t45)
  %t59 = getelementptr i8, ptr %t58, i64 %t45
  call void @olang_textcopy(ptr %t59, ptr %t47, i64 %t48)
  %t60 = getelementptr i8, ptr %t59, i64 %t48
  call void @olang_textcopy(ptr %t60, ptr %t51, i64 %t52)
  %t61 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t54, 1
  %t66 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v4, ptr %t31, { i64, ptr } %t62)
  store { i64, ptr } %t66, ptr %l28
  br label %bb6
bb5:
  %t67 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 1
  %t70 = extractvalue { i64, ptr } %t67, 0
  %t71 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t70)
  call void @olang_textcopy(ptr %t71, ptr %t69, i64 %t70)
  %t72 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t71, 1
  store { i64, ptr } %t73, ptr %l21, !tbaa !27
  br label %bb7
bb6:
  %t75 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t75, ptr %l21, !tbaa !27
  br label %bb7
bb7:
  %t76 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t76, ptr %l7, !tbaa !27
  %t77 = load i64, ptr %l3, !tbaa !24
  %t79 = icmp sgt i64 %t77, 0
  br i1 %t79, label %bb8, label %bb9
bb8:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t83 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t84 = load i64, ptr %l3, !tbaa !24
  %t85 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d197, i32 0, i32 1) }, 1
  %t86 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d197, i32 0, i32 1) }, 0
  %t88 = extractvalue { i64, ptr } %t82, 1
  %t89 = extractvalue { i64, ptr } %t82, 0
  %t90 = add i64 %t86, %t89
  %t91 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d198, i32 0, i32 1) }, 1
  %t92 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d198, i32 0, i32 1) }, 0
  %t93 = add i64 %t90, %t92
  %t95 = extractvalue { i64, ptr } %t83, 1
  %t96 = extractvalue { i64, ptr } %t83, 0
  %t97 = add i64 %t93, %t96
  %t98 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d199, i32 0, i32 1) }, 1
  %t99 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d199, i32 0, i32 1) }, 0
  %t100 = add i64 %t97, %t99
  %t102 = call i64 @__olang_fmt_i64(ptr null, i64 %t84)
  %t103 = add i64 %t100, %t102
  %t104 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t103)
  call void @olang_textcopy(ptr %t104, ptr %t85, i64 %t86)
  %t105 = getelementptr i8, ptr %t104, i64 %t86
  call void @olang_textcopy(ptr %t105, ptr %t88, i64 %t89)
  %t106 = getelementptr i8, ptr %t105, i64 %t89
  call void @olang_textcopy(ptr %t106, ptr %t91, i64 %t92)
  %t107 = getelementptr i8, ptr %t106, i64 %t92
  call void @olang_textcopy(ptr %t107, ptr %t95, i64 %t96)
  %t108 = getelementptr i8, ptr %t107, i64 %t96
  call void @olang_textcopy(ptr %t108, ptr %t98, i64 %t99)
  %t109 = getelementptr i8, ptr %t108, i64 %t99
  %t110 = call i64 @__olang_fmt_i64(ptr %t109, i64 %t84)
  %t111 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t104, 1
  %t116 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v4, ptr %t81, { i64, ptr } %t112)
  store { i64, ptr } %t116, ptr %l40
  br label %bb10
bb9:
  %t117 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t117, ptr %l33, !tbaa !27
  br label %bb11
bb10:
  %t119 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t119, ptr %l33, !tbaa !27
  br label %bb11
bb11:
  %t120 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t120, 0
  store i64 %t121, ptr %l42, !tbaa !24
  %t122 = load i64, ptr %l42, !tbaa !24
  %t123 = mul i64 %t122, 1
  %t124 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t123)
  %t125 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t124, 1
  store { i64, ptr } %t126, ptr %l43, !tbaa !27
  %t127 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = load i64, ptr %l42, !tbaa !24
  %t132 = mul i64 %t131, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t128, ptr %t130, i64 %t132, i1 false)
  %t133 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t133, ptr %l8, !tbaa !27
  %t134 = load i64, ptr %l4, !tbaa !24
  %t135 = load i64, ptr %l2, !tbaa !24
  %t138 = icmp slt i64 %t134, %t135
  br i1 %t138, label %bb12, label %bb13
bb12:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t142 = load i64, ptr %l2, !tbaa !24
  %t143 = load i64, ptr %l4, !tbaa !24
  %t146 = sub i64 %t142, %t143
  %t147 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d200, i32 0, i32 1) }, 1
  %t148 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d200, i32 0, i32 1) }, 0
  %t150 = extractvalue { i64, ptr } %t141, 1
  %t151 = extractvalue { i64, ptr } %t141, 0
  %t152 = add i64 %t148, %t151
  %t153 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d201, i32 0, i32 1) }, 1
  %t154 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d201, i32 0, i32 1) }, 0
  %t155 = add i64 %t152, %t154
  %t157 = call i64 @__olang_fmt_i64(ptr null, i64 %t146)
  %t158 = add i64 %t155, %t157
  %t159 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t158)
  call void @olang_textcopy(ptr %t159, ptr %t147, i64 %t148)
  %t160 = getelementptr i8, ptr %t159, i64 %t148
  call void @olang_textcopy(ptr %t160, ptr %t150, i64 %t151)
  %t161 = getelementptr i8, ptr %t160, i64 %t151
  call void @olang_textcopy(ptr %t161, ptr %t153, i64 %t154)
  %t162 = getelementptr i8, ptr %t161, i64 %t154
  %t163 = call i64 @__olang_fmt_i64(ptr %t162, i64 %t146)
  %t164 = insertvalue { i64, ptr } undef, i64 %t158, 0
  %t165 = insertvalue { i64, ptr } %t164, ptr %t159, 1
  %t169 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v4, ptr %t140, { i64, ptr } %t165)
  store { i64, ptr } %t169, ptr %l55
  br label %bb14
bb13:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d202, i32 0, i32 1) }, ptr %l47, !tbaa !27
  br label %bb15
bb14:
  %t170 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t170, ptr %l47, !tbaa !27
  br label %bb15
bb15:
  %t172 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t172, ptr %l9, !tbaa !27
  %t173 = load i64, ptr %l3, !tbaa !24
  %t175 = icmp sgt i64 %t173, 0
  br i1 %t175, label %bb16, label %bb17
bb16:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t179 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t180 = load i64, ptr %l3, !tbaa !24
  %t181 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d203, i32 0, i32 1) }, 1
  %t182 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d203, i32 0, i32 1) }, 0
  %t184 = extractvalue { i64, ptr } %t178, 1
  %t185 = extractvalue { i64, ptr } %t178, 0
  %t186 = add i64 %t182, %t185
  %t187 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d204, i32 0, i32 1) }, 1
  %t188 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d204, i32 0, i32 1) }, 0
  %t189 = add i64 %t186, %t188
  %t191 = extractvalue { i64, ptr } %t179, 1
  %t192 = extractvalue { i64, ptr } %t179, 0
  %t193 = add i64 %t189, %t192
  %t194 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d205, i32 0, i32 1) }, 1
  %t195 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d205, i32 0, i32 1) }, 0
  %t196 = add i64 %t193, %t195
  %t198 = call i64 @__olang_fmt_i64(ptr null, i64 %t180)
  %t199 = add i64 %t196, %t198
  %t200 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t199)
  call void @olang_textcopy(ptr %t200, ptr %t181, i64 %t182)
  %t201 = getelementptr i8, ptr %t200, i64 %t182
  call void @olang_textcopy(ptr %t201, ptr %t184, i64 %t185)
  %t202 = getelementptr i8, ptr %t201, i64 %t185
  call void @olang_textcopy(ptr %t202, ptr %t187, i64 %t188)
  %t203 = getelementptr i8, ptr %t202, i64 %t188
  call void @olang_textcopy(ptr %t203, ptr %t191, i64 %t192)
  %t204 = getelementptr i8, ptr %t203, i64 %t192
  call void @olang_textcopy(ptr %t204, ptr %t194, i64 %t195)
  %t205 = getelementptr i8, ptr %t204, i64 %t195
  %t206 = call i64 @__olang_fmt_i64(ptr %t205, i64 %t180)
  %t207 = insertvalue { i64, ptr } undef, i64 %t199, 0
  %t208 = insertvalue { i64, ptr } %t207, ptr %t200, 1
  %t212 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v4, ptr %t177, { i64, ptr } %t208)
  store { i64, ptr } %t212, ptr %l66
  br label %bb18
bb17:
  %t213 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t213, ptr %l59, !tbaa !27
  br label %bb19
bb18:
  %t215 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t215, ptr %l59, !tbaa !27
  br label %bb19
bb19:
  %t217 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t218 = load ptr, ptr %l0, !tbaa !29
  store ptr %t218, ptr %l69, !tbaa !29
  %t219 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t219, ptr %l70, !tbaa !27
  %t220 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t220, ptr %l71, !tbaa !27
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t224 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d206, i32 0, i32 1) }, 1
  %t225 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d206, i32 0, i32 1) }, 0
  %t227 = extractvalue { i64, ptr } %t222, 1
  %t228 = extractvalue { i64, ptr } %t222, 0
  %t229 = add i64 %t225, %t228
  %t230 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d207, i32 0, i32 1) }, 1
  %t231 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d207, i32 0, i32 1) }, 0
  %t232 = add i64 %t229, %t231
  %t234 = extractvalue { i64, ptr } %t217, 1
  %t235 = extractvalue { i64, ptr } %t217, 0
  %t236 = add i64 %t232, %t235
  %t237 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d208, i32 0, i32 1) }, 1
  %t238 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d208, i32 0, i32 1) }, 0
  %t239 = add i64 %t236, %t238
  %t240 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t239)
  call void @olang_textcopy(ptr %t240, ptr %t224, i64 %t225)
  %t241 = getelementptr i8, ptr %t240, i64 %t225
  call void @olang_textcopy(ptr %t241, ptr %t227, i64 %t228)
  %t242 = getelementptr i8, ptr %t241, i64 %t228
  call void @olang_textcopy(ptr %t242, ptr %t230, i64 %t231)
  %t243 = getelementptr i8, ptr %t242, i64 %t231
  call void @olang_textcopy(ptr %t243, ptr %t234, i64 %t235)
  %t244 = getelementptr i8, ptr %t243, i64 %t235
  call void @olang_textcopy(ptr %t244, ptr %t237, i64 %t238)
  %t245 = insertvalue { i64, ptr } undef, i64 %t239, 0
  %t246 = insertvalue { i64, ptr } %t245, ptr %t240, 1
  %t250 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v4, ptr %t221, { i64, ptr } %t246)
  store { i64, ptr } %t250, ptr %l77
  br label %bb20
bb20:
  %t251 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d209, i32 0, i32 1) }, 1
  %t252 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d209, i32 0, i32 1) }, 0
  %t253 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t254 = extractvalue { i64, ptr } %t253, 1
  %t255 = extractvalue { i64, ptr } %t253, 0
  %t256 = add i64 %t252, %t255
  %t257 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d210, i32 0, i32 1) }, 1
  %t258 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d210, i32 0, i32 1) }, 0
  %t259 = add i64 %t256, %t258
  %t260 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t261 = extractvalue { i64, ptr } %t260, 1
  %t262 = extractvalue { i64, ptr } %t260, 0
  %t263 = add i64 %t259, %t262
  %t264 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d211, i32 0, i32 1) }, 1
  %t265 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d211, i32 0, i32 1) }, 0
  %t266 = add i64 %t263, %t265
  %t267 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t268 = extractvalue { i64, ptr } %t267, 1
  %t269 = extractvalue { i64, ptr } %t267, 0
  %t270 = add i64 %t266, %t269
  %t271 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t270)
  call void @olang_textcopy(ptr %t271, ptr %t251, i64 %t252)
  %t272 = getelementptr i8, ptr %t271, i64 %t252
  call void @olang_textcopy(ptr %t272, ptr %t254, i64 %t255)
  %t273 = getelementptr i8, ptr %t272, i64 %t255
  call void @olang_textcopy(ptr %t273, ptr %t257, i64 %t258)
  %t274 = getelementptr i8, ptr %t273, i64 %t258
  call void @olang_textcopy(ptr %t274, ptr %t261, i64 %t262)
  %t275 = getelementptr i8, ptr %t274, i64 %t262
  call void @olang_textcopy(ptr %t275, ptr %t264, i64 %t265)
  %t276 = getelementptr i8, ptr %t275, i64 %t265
  call void @olang_textcopy(ptr %t276, ptr %t268, i64 %t269)
  %t277 = insertvalue { i64, ptr } undef, i64 %t270, 0
  %t278 = insertvalue { i64, ptr } %t277, ptr %t271, 1
  %t280 = load ptr, ptr %l69, !tbaa !29
  %t282 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v4, ptr %t280, { i64, ptr } %t278)
  store { i64, ptr } %t282, ptr %l80
  br label %bb21
bb21:
  %t283 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t287 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t288 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d212, i32 0, i32 1) }, 1
  %t289 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d212, i32 0, i32 1) }, 0
  %t291 = extractvalue { i64, ptr } %t285, 1
  %t292 = extractvalue { i64, ptr } %t285, 0
  %t293 = add i64 %t289, %t292
  %t294 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d213, i32 0, i32 1) }, 1
  %t295 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d213, i32 0, i32 1) }, 0
  %t296 = add i64 %t293, %t295
  %t298 = extractvalue { i64, ptr } %t283, 1
  %t299 = extractvalue { i64, ptr } %t283, 0
  %t300 = add i64 %t296, %t299
  %t301 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d214, i32 0, i32 1) }, 1
  %t302 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d214, i32 0, i32 1) }, 0
  %t303 = add i64 %t300, %t302
  %t305 = extractvalue { i64, ptr } %t287, 1
  %t306 = extractvalue { i64, ptr } %t287, 0
  %t307 = add i64 %t303, %t306
  %t308 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t307)
  call void @olang_textcopy(ptr %t308, ptr %t288, i64 %t289)
  %t309 = getelementptr i8, ptr %t308, i64 %t289
  call void @olang_textcopy(ptr %t309, ptr %t291, i64 %t292)
  %t310 = getelementptr i8, ptr %t309, i64 %t292
  call void @olang_textcopy(ptr %t310, ptr %t294, i64 %t295)
  %t311 = getelementptr i8, ptr %t310, i64 %t295
  call void @olang_textcopy(ptr %t311, ptr %t298, i64 %t299)
  %t312 = getelementptr i8, ptr %t311, i64 %t299
  call void @olang_textcopy(ptr %t312, ptr %t301, i64 %t302)
  %t313 = getelementptr i8, ptr %t312, i64 %t302
  call void @olang_textcopy(ptr %t313, ptr %t305, i64 %t306)
  %t314 = insertvalue { i64, ptr } undef, i64 %t307, 0
  %t315 = insertvalue { i64, ptr } %t314, ptr %t308, 1
  %t319 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %v3, ptr %v4, ptr %t284, { i64, ptr } %t315)
  store { i64, ptr } %t319, ptr %l87
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t320 = load { i64, ptr }, ptr %l87, !tbaa !27
  store { i64, ptr } %t320, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eplainWrite(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca { i64, [1 x i64] }
  %l4 = alloca i32
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i1
  %l17 = alloca i1
  %l18 = alloca i1
  %l19 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 20}
  %t8 = icmp eq i64 %t6, 11
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [21 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t12, i32 0, i32 1
  %t14 = load { i64, [1 x i64] }, ptr %t13
  store { i64, [1 x i64] } %t14, ptr %l3
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [21 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t18, i32 0, i32 2
  %t20 = load i32, ptr %t19, !range !{i32 0, i32 8}
  store i32 %t20, ptr %l4
  br label %bb5
bb4:
  br label %bb27
bb5:
  %t23 = load { i64, [1 x i64] }, ptr %l3
  %t28 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erefIs(ptr %v0, ptr %a0, { i64, [1 x i64] } %t23, i64 %a2)
  store i1 %t28, ptr %l17
  br label %bb6
bb6:
  %t29 = load i1, ptr %l17, !tbaa !21
  br i1 %t29, label %bb7, label %bb8
bb7:
  %t30 = load i32, ptr %l4, !range !{i32 0, i32 8}
  %t32 = trunc i64 0 to i32
  %t33 = icmp eq i32 %t30, %t32
  br i1 %t33, label %bb9, label %bb10
bb8:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb26
bb9:
  br label %bb19
bb10:
  %t35 = load i32, ptr %l4, !range !{i32 0, i32 8}
  %t37 = trunc i64 2 to i32
  %t38 = icmp eq i32 %t35, %t37
  br i1 %t38, label %bb11, label %bb12
bb11:
  br label %bb19
bb12:
  %t40 = load i32, ptr %l4, !range !{i32 0, i32 8}
  %t42 = trunc i64 4 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb13, label %bb14
bb13:
  br label %bb19
bb14:
  %t45 = load i32, ptr %l4, !range !{i32 0, i32 8}
  %t47 = trunc i64 5 to i32
  %t48 = icmp eq i32 %t45, %t47
  br i1 %t48, label %bb15, label %bb16
bb15:
  br label %bb19
bb16:
  %t50 = load i32, ptr %l4, !range !{i32 0, i32 8}
  %t52 = trunc i64 7 to i32
  %t53 = icmp eq i32 %t50, %t52
  br i1 %t53, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_efeca4a527577807_589cfb9b46e56fc3)
  unreachable
bb25:
  %t55 = load i1, ptr %l19, !tbaa !21
  store i1 %t55, ptr %l18, !tbaa !21
  br label %bb26
bb26:
  %t56 = load i1, ptr %l18, !tbaa !21
  store i1 %t56, ptr %l5, !tbaa !21
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_be60a18777a318a6_1ca0557f7b352842)
  unreachable
bb32:
  %t57 = load i1, ptr %l5, !tbaa !21
  store i1 %t57, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2erecode(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l46 = alloca i64
  %l49 = alloca i64
  %l68 = alloca ptr
  %l70 = alloca { i64, ptr }
  %l74 = alloca i64
  %l81 = alloca { i64, ptr }
  %l82 = alloca i64
  %l90 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l104 = alloca ptr
  %l109 = alloca { i64, ptr }
  %l113 = alloca { i64, ptr }
  %l119 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l22, !tbaa !29
  %t11 = load ptr, ptr %l22, !tbaa !29
  %t12 = call ptr @__olang_scope_or(ptr %v3, ptr %t11)
  %t13 = call ptr @__olang_scope_hold(ptr %t12)
  %t14 = ptrtoint ptr %t13 to i64
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/emit:fnEm", ptr %t15, i32 0, i32 0
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = call ptr @__olang_scope_or(ptr %v3, ptr %t18)
  %t21 = call ptr @__olang_scope_hold(ptr %t20)
  %t22 = ptrtoint ptr %t21 to i64
  %t24 = inttoptr i64 %t14 to ptr
  %t26 = inttoptr i64 %t22 to ptr
  %t27 = load ptr, ptr %l22, !tbaa !29
  %t29 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t24, ptr %t26, ptr %t27, i32 %a2)
  store { i64, ptr } %t29, ptr %l28
  br label %bb1
bb1:
  %t30 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t30, ptr %l5, !tbaa !27
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t33 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d215, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d215, i32 0, i32 1) }, 0
  %t36 = extractvalue { i64, ptr } %t32, 1
  %t37 = extractvalue { i64, ptr } %t32, 0
  %t38 = add i64 %t34, %t37
  %t39 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d216, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d216, i32 0, i32 1) }, 0
  %t41 = add i64 %t38, %t40
  %t42 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t41)
  call void @olang_textcopy(ptr %t42, ptr %t33, i64 %t34)
  %t43 = getelementptr i8, ptr %t42, i64 %t34
  call void @olang_textcopy(ptr %t43, ptr %t36, i64 %t37)
  %t44 = getelementptr i8, ptr %t43, i64 %t37
  call void @olang_textcopy(ptr %t44, ptr %t39, i64 %t40)
  %t45 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t42, 1
  %t50 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v3, ptr %t31, { i64, ptr } %t46)
  store { i64, ptr } %t50, ptr %l33
  br label %bb2
bb2:
  %t51 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t51, ptr %l6, !tbaa !27
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t54 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d217, i32 0, i32 1) }, 1
  %t55 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d217, i32 0, i32 1) }, 0
  %t57 = extractvalue { i64, ptr } %t53, 1
  %t58 = extractvalue { i64, ptr } %t53, 0
  %t59 = add i64 %t55, %t58
  %t60 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d218, i32 0, i32 1) }, 1
  %t61 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d218, i32 0, i32 1) }, 0
  %t62 = add i64 %t59, %t61
  %t63 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t62)
  call void @olang_textcopy(ptr %t63, ptr %t54, i64 %t55)
  %t64 = getelementptr i8, ptr %t63, i64 %t55
  call void @olang_textcopy(ptr %t64, ptr %t57, i64 %t58)
  %t65 = getelementptr i8, ptr %t64, i64 %t58
  call void @olang_textcopy(ptr %t65, ptr %t60, i64 %t61)
  %t66 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t63, 1
  %t71 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v3, ptr %t52, { i64, ptr } %t67)
  store { i64, ptr } %t71, ptr %l38
  br label %bb3
bb3:
  %t72 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t72, ptr %l7, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d219, i32 0, i32 1) }, ptr %l39, !tbaa !27
  %t73 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t73, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t75 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t75, 0
  store i64 %t77, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t79 = load i64, ptr %l10, !tbaa !24
  %t80 = load i64, ptr %l9, !tbaa !24
  %t83 = icmp sgt i64 %t79, %t80
  br i1 %t83, label %bb4, label %bb5
bb4:
  %t85 = load i64, ptr %l11, !tbaa !24
  %t87 = icmp sgt i64 %t85, 0
  br i1 %t87, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb9
bb6:
  %t89 = load i64, ptr %l10, !tbaa !24
  %t90 = load i64, ptr %l9, !tbaa !24
  %t93 = sub i64 %t89, %t90
  %t94 = load i64, ptr %l11, !tbaa !24
  %t97 = add i64 %t93, %t94
  %t99 = sub i64 %t97, 1
  %t100 = load i64, ptr %l11, !tbaa !24
  %t103 = sdiv i64 %t99, %t100
  store i64 %t103, ptr %l49, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb8
bb8:
  %t105 = load i64, ptr %l49, !tbaa !24
  store i64 %t105, ptr %l46, !tbaa !24
  br label %bb9
bb9:
  %t106 = load i64, ptr %l46, !tbaa !24
  store i64 %t106, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t107 = load i64, ptr %l13, !tbaa !24
  %t108 = load i64, ptr %l12, !tbaa !24
  %t111 = icmp slt i64 %t107, %t108
  %t113 = xor i1 %t111, true
  br i1 %t113, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s4)
  br label %bb26
bb12:
  br label %bb13
bb13:
  %t115 = load i64, ptr %l9, !tbaa !24
  %t116 = load i64, ptr %l13, !tbaa !24
  %t117 = load i64, ptr %l11, !tbaa !24
  %t120 = mul i64 %t116, %t117
  %t123 = add i64 %t115, %t120
  store i64 %t123, ptr %l14, !tbaa !24
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/emit:fnEm", ptr %t125, i32 0, i32 0
  %t128 = load ptr, ptr %t127, !tbaa !29
  store ptr %t128, ptr %l68, !tbaa !29
  %t130 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t130, ptr %l70, !tbaa !27
  %t131 = load i64, ptr %l14, !tbaa !24
  %t133 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr i32, ptr %t134, i64 %t131
  %t136 = load i32, ptr %t135, !tbaa !33
  %t137 = load ptr, ptr %l68, !tbaa !29
  %t138 = call ptr @__olang_scope_or(ptr %v3, ptr %t137)
  %t139 = call ptr @__olang_scope_hold(ptr %t138)
  %t140 = ptrtoint ptr %t139 to i64
  %t142 = inttoptr i64 %t140 to ptr
  %t143 = load ptr, ptr %l68, !tbaa !29
  %t146 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eposition(ptr %t142, ptr %t143, i32 %a3, i32 %t136)
  store i64 %t146, ptr %l74
  br label %bb14
bb14:
  %t147 = load i64, ptr %l74, !tbaa !24
  store i64 %t147, ptr %l15, !tbaa !24
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t150 = load i64, ptr %l14, !tbaa !24
  %t152 = add i64 %t150, 1
  %t153 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d220, i32 0, i32 1) }, 1
  %t154 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d220, i32 0, i32 1) }, 0
  %t156 = extractvalue { i64, ptr } %t149, 1
  %t157 = extractvalue { i64, ptr } %t149, 0
  %t158 = add i64 %t154, %t157
  %t159 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d221, i32 0, i32 1) }, 1
  %t160 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d221, i32 0, i32 1) }, 0
  %t161 = add i64 %t158, %t160
  %t163 = call i64 @__olang_fmt_i64(ptr null, i64 %t152)
  %t164 = add i64 %t161, %t163
  %t165 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t164)
  call void @olang_textcopy(ptr %t165, ptr %t153, i64 %t154)
  %t166 = getelementptr i8, ptr %t165, i64 %t154
  call void @olang_textcopy(ptr %t166, ptr %t156, i64 %t157)
  %t167 = getelementptr i8, ptr %t166, i64 %t157
  call void @olang_textcopy(ptr %t167, ptr %t159, i64 %t160)
  %t168 = getelementptr i8, ptr %t167, i64 %t160
  %t169 = call i64 @__olang_fmt_i64(ptr %t168, i64 %t152)
  %t170 = insertvalue { i64, ptr } undef, i64 %t164, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t165, 1
  %t175 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s4, ptr %s4, ptr %v3, ptr %t148, { i64, ptr } %t171)
  store { i64, ptr } %t175, ptr %l81
  br label %bb15
bb15:
  %t176 = load { i64, ptr }, ptr %l81, !tbaa !27
  store { i64, ptr } %t176, ptr %l16, !tbaa !27
  %t177 = call ptr @__olang_scope_hold(ptr %s0)
  %t178 = ptrtoint ptr %t177 to i64
  store i64 %t178, ptr %l82, !tbaa !24
  %t179 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2erecode_2elocal_2e8
  br i1 %t179, label %bb16, label %bb17
bb16:
  %t181 = call ptr @__olang_region_make(ptr %s0)
  %t182 = ptrtoint ptr %t181 to i64
  store i64 %t182, ptr %l82, !tbaa !24
  br label %bb17
bb17:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t185 = load i64, ptr %l15, !tbaa !24
  %t186 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t187 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d222, i32 0, i32 1) }, 1
  %t188 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d222, i32 0, i32 1) }, 0
  %t190 = extractvalue { i64, ptr } %t184, 1
  %t191 = extractvalue { i64, ptr } %t184, 0
  %t192 = add i64 %t188, %t191
  %t193 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d223, i32 0, i32 1) }, 1
  %t194 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d223, i32 0, i32 1) }, 0
  %t195 = add i64 %t192, %t194
  %t197 = call i64 @__olang_fmt_i64(ptr null, i64 %t185)
  %t198 = add i64 %t195, %t197
  %t199 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d223, i32 0, i32 1) }, 1
  %t200 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d223, i32 0, i32 1) }, 0
  %t201 = add i64 %t198, %t200
  %t203 = extractvalue { i64, ptr } %t186, 1
  %t204 = extractvalue { i64, ptr } %t186, 0
  %t205 = add i64 %t201, %t204
  %t206 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t205)
  call void @olang_textcopy(ptr %t206, ptr %t187, i64 %t188)
  %t207 = getelementptr i8, ptr %t206, i64 %t188
  call void @olang_textcopy(ptr %t207, ptr %t190, i64 %t191)
  %t208 = getelementptr i8, ptr %t207, i64 %t191
  call void @olang_textcopy(ptr %t208, ptr %t193, i64 %t194)
  %t209 = getelementptr i8, ptr %t208, i64 %t194
  %t210 = call i64 @__olang_fmt_i64(ptr %t209, i64 %t185)
  %t211 = getelementptr i8, ptr %t209, i64 %t197
  call void @olang_textcopy(ptr %t211, ptr %t199, i64 %t200)
  %t212 = getelementptr i8, ptr %t211, i64 %t200
  call void @olang_textcopy(ptr %t212, ptr %t203, i64 %t204)
  %t213 = insertvalue { i64, ptr } undef, i64 %t205, 0
  %t214 = insertvalue { i64, ptr } %t213, ptr %t206, 1
  %t216 = load i64, ptr %l82
  %t217 = inttoptr i64 %t216 to ptr
  %t220 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s4, ptr %t217, ptr %v3, ptr %t183, { i64, ptr } %t214)
  store { i64, ptr } %t220, ptr %l90
  br label %bb18
bb18:
  %t221 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2erecode_2elocal_2e8
  br i1 %t221, label %bb19, label %bb20
bb19:
  %t223 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t224 = extractvalue { i64, ptr } %t223, 0
  %t226 = icmp eq i64 %t224, 0
  br i1 %t226, label %bb21, label %bb22
bb20:
  %t228 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t228, ptr %l94, !tbaa !27
  %t229 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t229, ptr %l8, !tbaa !27
  %t230 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2erecode_2elocal_2e8
  br i1 %t230, label %bb23, label %bb24
bb21:
  store { i64, ptr } zeroinitializer, ptr %l90, !tbaa !27
  br label %bb22
bb22:
  %t232 = load i64, ptr %l82
  %t233 = inttoptr i64 %t232 to ptr
  %t234 = load { i64, ptr }, ptr %l90
  %t235 = extractvalue { i64, ptr } %t234, 1
  %t236 = call ptr @__olang_region_or(ptr %t235, ptr null)
  %t237 = icmp ne ptr %t236, null
  %t238 = select i1 %t237, ptr %t236, ptr null
  call void @__olang_region_settle_in(ptr %t233, ptr %t238)
  br label %bb20
bb23:
  %t239 = load { i64, ptr }, ptr %l94
  %t240 = extractvalue { i64, ptr } %t239, 1
  call void @__olang_region_release(ptr %t240)
  store { i64, ptr } zeroinitializer, ptr %l94
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s4)
  br label %bb25
bb25:
  %t241 = load i64, ptr %l13, !tbaa !24
  %t244 = add i64 %t241, 1
  store i64 %t244, ptr %l13, !tbaa !24
  br label %bb10
bb26:
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t247 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t248 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d224, i32 0, i32 1) }, 1
  %t249 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d224, i32 0, i32 1) }, 0
  %t251 = extractvalue { i64, ptr } %t247, 1
  %t252 = extractvalue { i64, ptr } %t247, 0
  %t253 = add i64 %t249, %t252
  %t254 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d225, i32 0, i32 1) }, 1
  %t255 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d225, i32 0, i32 1) }, 0
  %t256 = add i64 %t253, %t255
  %t257 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t256)
  call void @olang_textcopy(ptr %t257, ptr %t248, i64 %t249)
  %t258 = getelementptr i8, ptr %t257, i64 %t249
  call void @olang_textcopy(ptr %t258, ptr %t251, i64 %t252)
  %t259 = getelementptr i8, ptr %t258, i64 %t252
  call void @olang_textcopy(ptr %t259, ptr %t254, i64 %t255)
  %t260 = insertvalue { i64, ptr } undef, i64 %t256, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t257, 1
  %t265 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v3, ptr %t246, { i64, ptr } %t261)
  store { i64, ptr } %t265, ptr %l103
  br label %bb27
bb27:
  %t266 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t266, ptr %l17, !tbaa !27
  %t267 = load ptr, ptr %l0, !tbaa !29
  store ptr %t267, ptr %l104, !tbaa !29
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t270 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d226, i32 0, i32 1) }, 1
  %t271 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d226, i32 0, i32 1) }, 0
  %t273 = extractvalue { i64, ptr } %t269, 1
  %t274 = extractvalue { i64, ptr } %t269, 0
  %t275 = add i64 %t271, %t274
  %t276 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d227, i32 0, i32 1) }, 1
  %t277 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d227, i32 0, i32 1) }, 0
  %t278 = add i64 %t275, %t277
  %t279 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t278)
  call void @olang_textcopy(ptr %t279, ptr %t270, i64 %t271)
  %t280 = getelementptr i8, ptr %t279, i64 %t271
  call void @olang_textcopy(ptr %t280, ptr %t273, i64 %t274)
  %t281 = getelementptr i8, ptr %t280, i64 %t274
  call void @olang_textcopy(ptr %t281, ptr %t276, i64 %t277)
  %t282 = insertvalue { i64, ptr } undef, i64 %t278, 0
  %t283 = insertvalue { i64, ptr } %t282, ptr %t279, 1
  %t287 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v3, ptr %t268, { i64, ptr } %t283)
  store { i64, ptr } %t287, ptr %l109
  br label %bb28
bb28:
  %t288 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t289 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d228, i32 0, i32 1) }, 1
  %t290 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d228, i32 0, i32 1) }, 0
  %t291 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t292 = extractvalue { i64, ptr } %t291, 1
  %t293 = extractvalue { i64, ptr } %t291, 0
  %t294 = add i64 %t290, %t293
  %t295 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d229, i32 0, i32 1) }, 1
  %t296 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d229, i32 0, i32 1) }, 0
  %t297 = add i64 %t294, %t296
  %t299 = extractvalue { i64, ptr } %t288, 1
  %t300 = extractvalue { i64, ptr } %t288, 0
  %t301 = add i64 %t297, %t300
  %t302 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t301)
  call void @olang_textcopy(ptr %t302, ptr %t289, i64 %t290)
  %t303 = getelementptr i8, ptr %t302, i64 %t290
  call void @olang_textcopy(ptr %t303, ptr %t292, i64 %t293)
  %t304 = getelementptr i8, ptr %t303, i64 %t293
  call void @olang_textcopy(ptr %t304, ptr %t295, i64 %t296)
  %t305 = getelementptr i8, ptr %t304, i64 %t296
  call void @olang_textcopy(ptr %t305, ptr %t299, i64 %t300)
  %t306 = insertvalue { i64, ptr } undef, i64 %t301, 0
  %t307 = insertvalue { i64, ptr } %t306, ptr %t302, 1
  %t309 = load ptr, ptr %l104, !tbaa !29
  %t311 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v3, ptr %t309, { i64, ptr } %t307)
  store { i64, ptr } %t311, ptr %l113
  br label %bb29
bb29:
  %t312 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t314 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t316 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d230, i32 0, i32 1) }, 1
  %t317 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d230, i32 0, i32 1) }, 0
  %t319 = extractvalue { i64, ptr } %t314, 1
  %t320 = extractvalue { i64, ptr } %t314, 0
  %t321 = add i64 %t317, %t320
  %t322 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d231, i32 0, i32 1) }, 1
  %t323 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d231, i32 0, i32 1) }, 0
  %t324 = add i64 %t321, %t323
  %t326 = extractvalue { i64, ptr } %t312, 1
  %t327 = extractvalue { i64, ptr } %t312, 0
  %t328 = add i64 %t324, %t327
  %t329 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t328)
  call void @olang_textcopy(ptr %t329, ptr %t316, i64 %t317)
  %t330 = getelementptr i8, ptr %t329, i64 %t317
  call void @olang_textcopy(ptr %t330, ptr %t319, i64 %t320)
  %t331 = getelementptr i8, ptr %t330, i64 %t320
  call void @olang_textcopy(ptr %t331, ptr %t322, i64 %t323)
  %t332 = getelementptr i8, ptr %t331, i64 %t323
  call void @olang_textcopy(ptr %t332, ptr %t326, i64 %t327)
  %t333 = insertvalue { i64, ptr } undef, i64 %t328, 0
  %t334 = insertvalue { i64, ptr } %t333, ptr %t329, 1
  %t338 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %v2, ptr %v3, ptr %t313, { i64, ptr } %t334)
  store { i64, ptr } %t338, ptr %l119
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  %t339 = load { i64, ptr }, ptr %l119, !tbaa !27
  store { i64, ptr } %t339, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2esatMulWide(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i64 %a3, { i64, ptr } %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l35 = alloca ptr
  %l37 = alloca i1
  %l38 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l49 = alloca i1
  %l50 = alloca i64
  %l55 = alloca i64
  %l58 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l64 = alloca i64
  %l66 = alloca ptr
  %l67 = alloca { i64, ptr }
  %l72 = alloca i64
  %l75 = alloca { i64, ptr }
  %l78 = alloca i64
  %l81 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = mul i64 2, %t1
  %t4 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d232, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d232, i32 0, i32 1) }, 0
  %t7 = call i64 @__olang_fmt_i64(ptr null, i64 %t3)
  %t8 = add i64 %t5, %t7
  %t9 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t8)
  call void @olang_textcopy(ptr %t9, ptr %t4, i64 %t5)
  %t10 = getelementptr i8, ptr %t9, i64 %t5
  %t11 = call i64 @__olang_fmt_i64(ptr %t10, i64 %t3)
  %t12 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t9, 1
  store { i64, ptr } %t13, ptr %l6, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t17 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t15, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d233, i32 0, i32 1) })
  store i1 %t17, ptr %l15
  br label %bb1
bb1:
  %t18 = load i1, ptr %l15, !tbaa !21
  br i1 %t18, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d234, i32 0, i32 1) }, ptr %l16, !tbaa !27
  br label %bb4
bb3:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d235, i32 0, i32 1) }, ptr %l16, !tbaa !27
  br label %bb4
bb4:
  %t19 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t19, ptr %l7, !tbaa !27
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t21, 1
  %t27 = extractvalue { i64, ptr } %t21, 0
  %t29 = extractvalue { i64, ptr } %t22, 1
  %t30 = extractvalue { i64, ptr } %t22, 0
  %t31 = add i64 %t27, %t30
  %t32 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d236, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d236, i32 0, i32 1) }, 0
  %t34 = add i64 %t31, %t33
  %t36 = extractvalue { i64, ptr } %a4, 1
  %t37 = extractvalue { i64, ptr } %a4, 0
  %t38 = add i64 %t34, %t37
  %t39 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d237, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d237, i32 0, i32 1) }, 0
  %t41 = add i64 %t38, %t40
  %t43 = extractvalue { i64, ptr } %t24, 1
  %t44 = extractvalue { i64, ptr } %t24, 0
  %t45 = add i64 %t41, %t44
  %t46 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t45)
  call void @olang_textcopy(ptr %t46, ptr %t26, i64 %t27)
  %t47 = getelementptr i8, ptr %t46, i64 %t27
  call void @olang_textcopy(ptr %t47, ptr %t29, i64 %t30)
  %t48 = getelementptr i8, ptr %t47, i64 %t30
  call void @olang_textcopy(ptr %t48, ptr %t32, i64 %t33)
  %t49 = getelementptr i8, ptr %t48, i64 %t33
  call void @olang_textcopy(ptr %t49, ptr %t36, i64 %t37)
  %t50 = getelementptr i8, ptr %t49, i64 %t37
  call void @olang_textcopy(ptr %t50, ptr %t39, i64 %t40)
  %t51 = getelementptr i8, ptr %t50, i64 %t40
  call void @olang_textcopy(ptr %t51, ptr %t43, i64 %t44)
  %t52 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t46, 1
  %t57 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v6, ptr %t20, { i64, ptr } %t53)
  store { i64, ptr } %t57, ptr %l24
  br label %bb5
bb5:
  %t58 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t58, ptr %l8, !tbaa !27
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t60, 1
  %t66 = extractvalue { i64, ptr } %t60, 0
  %t68 = extractvalue { i64, ptr } %t61, 1
  %t69 = extractvalue { i64, ptr } %t61, 0
  %t70 = add i64 %t66, %t69
  %t71 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d238, i32 0, i32 1) }, 1
  %t72 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d238, i32 0, i32 1) }, 0
  %t73 = add i64 %t70, %t72
  %t75 = extractvalue { i64, ptr } %a5, 1
  %t76 = extractvalue { i64, ptr } %a5, 0
  %t77 = add i64 %t73, %t76
  %t78 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d239, i32 0, i32 1) }, 1
  %t79 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d239, i32 0, i32 1) }, 0
  %t80 = add i64 %t77, %t79
  %t82 = extractvalue { i64, ptr } %t63, 1
  %t83 = extractvalue { i64, ptr } %t63, 0
  %t84 = add i64 %t80, %t83
  %t85 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t84)
  call void @olang_textcopy(ptr %t85, ptr %t65, i64 %t66)
  %t86 = getelementptr i8, ptr %t85, i64 %t66
  call void @olang_textcopy(ptr %t86, ptr %t68, i64 %t69)
  %t87 = getelementptr i8, ptr %t86, i64 %t69
  call void @olang_textcopy(ptr %t87, ptr %t71, i64 %t72)
  %t88 = getelementptr i8, ptr %t87, i64 %t72
  call void @olang_textcopy(ptr %t88, ptr %t75, i64 %t76)
  %t89 = getelementptr i8, ptr %t88, i64 %t76
  call void @olang_textcopy(ptr %t89, ptr %t78, i64 %t79)
  %t90 = getelementptr i8, ptr %t89, i64 %t79
  call void @olang_textcopy(ptr %t90, ptr %t82, i64 %t83)
  %t91 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t85, 1
  %t96 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v6, ptr %t59, { i64, ptr } %t92)
  store { i64, ptr } %t96, ptr %l32
  br label %bb6
bb6:
  %t97 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t97, ptr %l9, !tbaa !27
  %t98 = call ptr @__olang_scope_hold(ptr %s0)
  %t99 = ptrtoint ptr %t98 to i64
  store i64 %t99, ptr %l33, !tbaa !24
  %t100 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2esatMulWide_2elocal_2e10
  br i1 %t100, label %bb7, label %bb8
bb7:
  %t102 = call ptr @__olang_region_make(ptr %s0)
  %t103 = ptrtoint ptr %t102 to i64
  store i64 %t103, ptr %l33, !tbaa !24
  br label %bb8
bb8:
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l35, !tbaa !29
  %t105 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t107 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t105, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d240, i32 0, i32 1) })
  store i1 %t107, ptr %l37
  br label %bb9
bb9:
  %t108 = load i1, ptr %l37, !tbaa !21
  br i1 %t108, label %bb10, label %bb11
bb10:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d241, i32 0, i32 1) }, ptr %l38, !tbaa !27
  br label %bb12
bb11:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d242, i32 0, i32 1) }, ptr %l38, !tbaa !27
  br label %bb12
bb12:
  %t109 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t110 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t111 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t112 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d243, i32 0, i32 1) }, 1
  %t113 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d243, i32 0, i32 1) }, 0
  %t114 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t114, 1
  %t116 = extractvalue { i64, ptr } %t114, 0
  %t117 = add i64 %t113, %t116
  %t119 = extractvalue { i64, ptr } %t109, 1
  %t120 = extractvalue { i64, ptr } %t109, 0
  %t121 = add i64 %t117, %t120
  %t122 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d244, i32 0, i32 1) }, 1
  %t123 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d244, i32 0, i32 1) }, 0
  %t124 = add i64 %t121, %t123
  %t126 = extractvalue { i64, ptr } %t110, 1
  %t127 = extractvalue { i64, ptr } %t110, 0
  %t128 = add i64 %t124, %t127
  %t129 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d245, i32 0, i32 1) }, 1
  %t130 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d245, i32 0, i32 1) }, 0
  %t131 = add i64 %t128, %t130
  %t133 = extractvalue { i64, ptr } %t111, 1
  %t134 = extractvalue { i64, ptr } %t111, 0
  %t135 = add i64 %t131, %t134
  %t136 = load i64, ptr %l33
  %t137 = inttoptr i64 %t136 to ptr
  %t138 = call ptr @__olang_held_alloc(ptr %t137, i64 %t135)
  call void @olang_textcopy(ptr %t138, ptr %t112, i64 %t113)
  %t139 = getelementptr i8, ptr %t138, i64 %t113
  call void @olang_textcopy(ptr %t139, ptr %t115, i64 %t116)
  %t140 = getelementptr i8, ptr %t139, i64 %t116
  call void @olang_textcopy(ptr %t140, ptr %t119, i64 %t120)
  %t141 = getelementptr i8, ptr %t140, i64 %t120
  call void @olang_textcopy(ptr %t141, ptr %t122, i64 %t123)
  %t142 = getelementptr i8, ptr %t141, i64 %t123
  call void @olang_textcopy(ptr %t142, ptr %t126, i64 %t127)
  %t143 = getelementptr i8, ptr %t142, i64 %t127
  call void @olang_textcopy(ptr %t143, ptr %t129, i64 %t130)
  %t144 = getelementptr i8, ptr %t143, i64 %t130
  call void @olang_textcopy(ptr %t144, ptr %t133, i64 %t134)
  %t145 = insertvalue { i64, ptr } undef, i64 %t135, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t138, 1
  %t148 = load i64, ptr %l33
  %t149 = inttoptr i64 %t148 to ptr
  %t150 = load i64, ptr %l33
  %t151 = inttoptr i64 %t150 to ptr
  %t152 = load ptr, ptr %l35, !tbaa !29
  %t154 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %t149, ptr %t151, ptr %v6, ptr %t152, { i64, ptr } %t146)
  store { i64, ptr } %t154, ptr %l44
  br label %bb13
bb13:
  %t155 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2esatMulWide_2elocal_2e10
  br i1 %t155, label %bb14, label %bb15
bb14:
  %t157 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t157, 0
  %t160 = icmp eq i64 %t158, 0
  br i1 %t160, label %bb16, label %bb17
bb15:
  %t162 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t162, ptr %l10, !tbaa !27
  %t163 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t165 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t163, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d246, i32 0, i32 1) })
  store i1 %t165, ptr %l49
  br label %bb18
bb16:
  store { i64, ptr } zeroinitializer, ptr %l44, !tbaa !27
  br label %bb17
bb17:
  %t166 = load i64, ptr %l33
  %t167 = inttoptr i64 %t166 to ptr
  %t168 = load { i64, ptr }, ptr %l44
  %t169 = extractvalue { i64, ptr } %t168, 1
  %t170 = call ptr @__olang_region_or(ptr %t169, ptr null)
  %t171 = icmp ne ptr %t170, null
  %t172 = select i1 %t171, ptr %t170, ptr null
  call void @__olang_region_settle_in(ptr %t167, ptr %t172)
  br label %bb15
bb18:
  %t173 = load i1, ptr %l49, !tbaa !21
  br i1 %t173, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  %t174 = call ptr @__olang_scope_hold(ptr %s0)
  %t175 = ptrtoint ptr %t174 to i64
  store i64 %t175, ptr %l50, !tbaa !24
  %t176 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2esatMulWide_2elocal_2e10
  br i1 %t176, label %bb21, label %bb22
bb20:
  store %olang.scope zeroinitializer, ptr %s6
  %t178 = call ptr @__olang_scope_hold(ptr %s0)
  %t179 = ptrtoint ptr %t178 to i64
  store i64 %t179, ptr %l64, !tbaa !24
  %t180 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2esatMulWide_2elocal_2e10
  br i1 %t180, label %bb30, label %bb31
bb21:
  %t182 = call ptr @__olang_region_make(ptr %s0)
  %t183 = ptrtoint ptr %t182 to i64
  store i64 %t183, ptr %l50, !tbaa !24
  br label %bb22
bb22:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t185 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t186 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t187 = load i64, ptr %l3, !tbaa !24
  store i64 %t187, ptr %l55, !tbaa !24
  %t188 = load i64, ptr %l55, !tbaa !24
  %t189 = load i64, ptr %l55, !tbaa !24
  %t190 = shl i64 1, %t189
  %t192 = sub i64 %t190, 1
  %t193 = load i64, ptr %l50
  %t194 = inttoptr i64 %t193 to ptr
  %t199 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eminMax(ptr %v0, ptr %s5, ptr %s0, ptr %s0, ptr %t194, ptr %v6, ptr %t184, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d247, i32 0, i32 1) }, { i64, ptr } %t185, { i64, ptr } %t186, i64 %t192)
  store { i64, ptr } %t199, ptr %l58
  br label %bb23
bb23:
  %t200 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2esatMulWide_2elocal_2e10
  br i1 %t200, label %bb24, label %bb25
bb24:
  %t202 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t203 = extractvalue { i64, ptr } %t202, 0
  %t205 = icmp eq i64 %t203, 0
  br i1 %t205, label %bb26, label %bb27
bb25:
  %t207 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t207, ptr %l62, !tbaa !27
  %t208 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t208, ptr %l10, !tbaa !27
  %t209 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2esatMulWide_2elocal_2e10
  br i1 %t209, label %bb28, label %bb29
bb26:
  store { i64, ptr } zeroinitializer, ptr %l58, !tbaa !27
  br label %bb27
bb27:
  %t211 = load i64, ptr %l50
  %t212 = inttoptr i64 %t211 to ptr
  %t213 = load { i64, ptr }, ptr %l58
  %t214 = extractvalue { i64, ptr } %t213, 1
  %t215 = call ptr @__olang_region_or(ptr %t214, ptr null)
  %t216 = icmp ne ptr %t215, null
  %t217 = select i1 %t216, ptr %t215, ptr null
  call void @__olang_region_settle_in(ptr %t212, ptr %t217)
  br label %bb25
bb28:
  %t218 = load { i64, ptr }, ptr %l62
  %t219 = extractvalue { i64, ptr } %t218, 1
  call void @__olang_region_release(ptr %t219)
  store { i64, ptr } zeroinitializer, ptr %l62
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s5)
  br label %bb40
bb30:
  %t220 = call ptr @__olang_region_make(ptr %s0)
  %t221 = ptrtoint ptr %t220 to i64
  store i64 %t221, ptr %l64, !tbaa !24
  br label %bb31
bb31:
  %t222 = load ptr, ptr %l0, !tbaa !29
  store ptr %t222, ptr %l66, !tbaa !29
  %t223 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t223, ptr %l67, !tbaa !27
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t225 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t226 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t227 = load i64, ptr %l3, !tbaa !24
  %t229 = sub i64 %t227, 1
  store i64 %t229, ptr %l72, !tbaa !24
  %t230 = load i64, ptr %l72, !tbaa !24
  %t231 = load i64, ptr %l72, !tbaa !24
  %t232 = shl i64 1, %t231
  %t234 = sub i64 %t232, 1
  %t239 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eminMax(ptr %v0, ptr %s6, ptr %s0, ptr %s0, ptr %s6, ptr %v6, ptr %t224, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d248, i32 0, i32 1) }, { i64, ptr } %t225, { i64, ptr } %t226, i64 %t234)
  store { i64, ptr } %t239, ptr %l75
  br label %bb32
bb32:
  %t240 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t241 = load i64, ptr %l3, !tbaa !24
  %t243 = sub i64 %t241, 1
  store i64 %t243, ptr %l78, !tbaa !24
  %t244 = load i64, ptr %l78, !tbaa !24
  %t245 = load i64, ptr %l78, !tbaa !24
  %t246 = shl i64 1, %t245
  %t248 = sub i64 0, %t246
  %t249 = load i64, ptr %l64
  %t250 = inttoptr i64 %t249 to ptr
  %t251 = load ptr, ptr %l66, !tbaa !29
  %t252 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t255 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eminMax(ptr %v0, ptr %s6, ptr %s0, ptr %s6, ptr %t250, ptr %v6, ptr %t251, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d249, i32 0, i32 1) }, { i64, ptr } %t252, { i64, ptr } %t240, i64 %t248)
  store { i64, ptr } %t255, ptr %l81
  br label %bb33
bb33:
  %t256 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2esatMulWide_2elocal_2e10
  br i1 %t256, label %bb34, label %bb35
bb34:
  %t258 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t259 = extractvalue { i64, ptr } %t258, 0
  %t261 = icmp eq i64 %t259, 0
  br i1 %t261, label %bb36, label %bb37
bb35:
  %t263 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t263, ptr %l85, !tbaa !27
  %t264 = load { i64, ptr }, ptr %l81, !tbaa !27
  store { i64, ptr } %t264, ptr %l10, !tbaa !27
  %t265 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2esatMulWide_2elocal_2e10
  br i1 %t265, label %bb38, label %bb39
bb36:
  store { i64, ptr } zeroinitializer, ptr %l81, !tbaa !27
  br label %bb37
bb37:
  %t267 = load i64, ptr %l64
  %t268 = inttoptr i64 %t267 to ptr
  %t269 = load { i64, ptr }, ptr %l81
  %t270 = extractvalue { i64, ptr } %t269, 1
  %t271 = call ptr @__olang_region_or(ptr %t270, ptr null)
  %t272 = icmp ne ptr %t271, null
  %t273 = select i1 %t272, ptr %t271, ptr null
  call void @__olang_region_settle_in(ptr %t268, ptr %t273)
  br label %bb35
bb38:
  %t274 = load { i64, ptr }, ptr %l85
  %t275 = extractvalue { i64, ptr } %t274, 1
  call void @__olang_region_release(ptr %t275)
  store { i64, ptr } zeroinitializer, ptr %l85
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s6)
  br label %bb40
bb40:
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t277 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t278 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t279 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t280 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d250, i32 0, i32 1) }, 1
  %t281 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d250, i32 0, i32 1) }, 0
  %t283 = extractvalue { i64, ptr } %t277, 1
  %t284 = extractvalue { i64, ptr } %t277, 0
  %t285 = add i64 %t281, %t284
  %t286 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d251, i32 0, i32 1) }, 1
  %t287 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d251, i32 0, i32 1) }, 0
  %t288 = add i64 %t285, %t287
  %t290 = extractvalue { i64, ptr } %t278, 1
  %t291 = extractvalue { i64, ptr } %t278, 0
  %t292 = add i64 %t288, %t291
  %t293 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d252, i32 0, i32 1) }, 1
  %t294 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d252, i32 0, i32 1) }, 0
  %t295 = add i64 %t292, %t294
  %t297 = extractvalue { i64, ptr } %t279, 1
  %t298 = extractvalue { i64, ptr } %t279, 0
  %t299 = add i64 %t295, %t298
  %t300 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t299)
  call void @olang_textcopy(ptr %t300, ptr %t280, i64 %t281)
  %t301 = getelementptr i8, ptr %t300, i64 %t281
  call void @olang_textcopy(ptr %t301, ptr %t283, i64 %t284)
  %t302 = getelementptr i8, ptr %t301, i64 %t284
  call void @olang_textcopy(ptr %t302, ptr %t286, i64 %t287)
  %t303 = getelementptr i8, ptr %t302, i64 %t287
  call void @olang_textcopy(ptr %t303, ptr %t290, i64 %t291)
  %t304 = getelementptr i8, ptr %t303, i64 %t291
  call void @olang_textcopy(ptr %t304, ptr %t293, i64 %t294)
  %t305 = getelementptr i8, ptr %t304, i64 %t294
  call void @olang_textcopy(ptr %t305, ptr %t297, i64 %t298)
  %t306 = insertvalue { i64, ptr } undef, i64 %t299, 0
  %t307 = insertvalue { i64, ptr } %t306, ptr %t300, 1
  %t311 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %v5, ptr %v6, ptr %t276, { i64, ptr } %t307)
  store { i64, ptr } %t311, ptr %l93
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s0)
  %t312 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t312, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2eslotCopy(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/mir:Call" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Call"
  %l2 = alloca ptr
  %l3 = alloca { i64, [7 x i64] }
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca i32
  %l11 = alloca i64
  %l16 = alloca i32
  %l20 = alloca i32
  %l27 = alloca i32
  %l35 = alloca i1
  %l38 = alloca i1
  %l41 = alloca i1
  %l45 = alloca ptr
  %l48 = alloca i32
  %l50 = alloca ptr
  %l53 = alloca i1
  %l55 = alloca i1
  %l56 = alloca ptr
  %l59 = alloca i1
  %l60 = alloca i1
  %l61 = alloca ptr
  %l64 = alloca i1
  %l65 = alloca i1
  %l68 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l70 = alloca i64
  %l74 = alloca i64
  %l82 = alloca i1
  %l86 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/mir:Call" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t9 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 0
  %t10 = load { i64, [7 x i64] }, ptr %t9
  store { i64, [7 x i64] } %t10, ptr %l3
  %t12 = load { i64, [7 x i64] }, ptr %l3
  %t14 = extractvalue { i64, [7 x i64] } %t12, 0
  %t15 = icmp eq i64 %t14, 0
  br i1 %t15, label %bb1, label %bb2
bb1:
  %t17 = getelementptr { i64, [7 x i64] }, ptr %l3, i32 0, i32 1
  %t18 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t17, i32 0, i32 0
  %t19 = load { i64, [2 x i64] }, ptr %t18
  store { i64, [2 x i64] } %t19, ptr %l4
  br label %bb3
bb2:
  br label %bb16
bb3:
  %t21 = load { i64, [2 x i64] }, ptr %l4
  %t23 = extractvalue { i64, [2 x i64] } %t21, 0
  %t24 = icmp eq i64 %t23, 3
  br i1 %t24, label %bb4, label %bb5
bb4:
  %t26 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t27 = getelementptr { i32, i32 }, ptr %t26, i32 0, i32 0
  %t28 = load i32, ptr %t27, !range !{i32 0, i32 10}
  store i32 %t28, ptr %l5
  %t30 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t31 = getelementptr { i32, i32 }, ptr %t30, i32 0, i32 1
  %t32 = load i32, ptr %t31
  store i32 %t32, ptr %l6, !tbaa !23
  br label %bb6
bb5:
  br label %bb10
bb6:
  %t34 = load i32, ptr %l5, !range !{i32 0, i32 10}
  %t36 = trunc i64 4 to i32
  %t37 = icmp eq i32 %t34, %t36
  br i1 %t37, label %bb7, label %bb8
bb7:
  %t39 = load i32, ptr %l6, !tbaa !23
  store i32 %t39, ptr %l27, !tbaa !23
  br label %bb9
bb8:
  %t41 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t41, ptr %l27, !tbaa !23
  br label %bb9
bb9:
  %t43 = load i32, ptr %l27, !tbaa !23
  store i32 %t43, ptr %l20, !tbaa !23
  br label %bb15
bb10:
  br i1 true, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t44 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t44, ptr %l20, !tbaa !23
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_b9f3dbc2e93b92cd_66187346ebf9cfe1)
  unreachable
bb15:
  %t46 = load i32, ptr %l20, !tbaa !23
  store i32 %t46, ptr %l16, !tbaa !23
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t47 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t47, ptr %l16, !tbaa !23
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_96197af7424aa9c_b080309cba8f3a50)
  unreachable
bb21:
  %t49 = load i32, ptr %l16, !tbaa !23
  store i32 %t49, ptr %l7, !tbaa !23
  %t50 = load i32, ptr %l7, !tbaa !23
  %t51 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t54 = icmp eq i32 %t50, %t51
  br i1 %t54, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb24
bb23:
  %t56 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 2
  %t57 = getelementptr %"compiler/mir:Range", ptr %t56, i32 0, i32 1
  %t58 = load i32, ptr %t57, !tbaa !23
  %t60 = icmp ne i32 %t58, 1
  store i1 %t60, ptr %l35, !tbaa !21
  br label %bb24
bb24:
  %t62 = load i1, ptr %l35, !tbaa !21
  br i1 %t62, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb27
bb26:
  %t63 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 4
  %t64 = load i1, ptr %t63, !tbaa !21
  %t66 = xor i1 %t64, true
  store i1 %t66, ptr %l38, !tbaa !21
  br label %bb27
bb27:
  %t68 = load i1, ptr %l38, !tbaa !21
  br i1 %t68, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb30
bb29:
  %t69 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 3
  %t70 = getelementptr %"compiler/mir:Lvalue", ptr %t69, i32 0, i32 1
  %t71 = getelementptr %"compiler/mir:Range", ptr %t70, i32 0, i32 1
  %t72 = load i32, ptr %t71, !tbaa !23
  %t74 = icmp ne i32 %t72, 0
  store i1 %t74, ptr %l41, !tbaa !21
  br label %bb30
bb30:
  %t76 = load i1, ptr %l41, !tbaa !21
  br i1 %t76, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t78 = load ptr, ptr %l2, !tbaa !29
  store ptr %t78, ptr %l45, !tbaa !29
  %t79 = load i32, ptr %l7, !tbaa !23
  %t80 = load ptr, ptr %l45, !tbaa !29
  %t81 = call ptr @__olang_scope_or(ptr %v1, ptr %t80)
  %t82 = call ptr @__olang_scope_hold(ptr %t81)
  %t83 = ptrtoint ptr %t82 to i64
  %t85 = inttoptr i64 %t83 to ptr
  %t86 = load ptr, ptr %l45, !tbaa !29
  %t88 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t85, ptr %t86, i32 %t79)
  store i32 %t88, ptr %l48
  br label %bb34
bb34:
  %t89 = load i32, ptr %l48, !tbaa !23
  store i32 %t89, ptr %l8, !tbaa !23
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/emit:fnEm", ptr %t90, i32 0, i32 0
  %t93 = load ptr, ptr %t92, !tbaa !29
  store ptr %t93, ptr %l50, !tbaa !29
  %t94 = load i32, ptr %l8, !tbaa !23
  %t95 = load ptr, ptr %l50, !tbaa !29
  %t96 = call ptr @__olang_scope_or(ptr %v1, ptr %t95)
  %t97 = call ptr @__olang_scope_hold(ptr %t96)
  %t98 = ptrtoint ptr %t97 to i64
  %t100 = inttoptr i64 %t98 to ptr
  %t101 = load ptr, ptr %l50, !tbaa !29
  %t103 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenType(ptr %t100, ptr %t101, i32 %t94)
  store i1 %t103, ptr %l53
  br label %bb35
bb35:
  %t104 = load i1, ptr %l53, !tbaa !21
  %t105 = xor i1 %t104, true
  br i1 %t105, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l55, !tbaa !21
  br label %bb39
bb37:
  %t107 = load ptr, ptr %l2, !tbaa !29
  store ptr %t107, ptr %l56, !tbaa !29
  %t108 = load i32, ptr %l8, !tbaa !23
  %t109 = load ptr, ptr %l56, !tbaa !29
  %t110 = call ptr @__olang_scope_or(ptr %v1, ptr %t109)
  %t111 = call ptr @__olang_scope_hold(ptr %t110)
  %t112 = ptrtoint ptr %t111 to i64
  %t114 = inttoptr i64 %t112 to ptr
  %t115 = load ptr, ptr %l56, !tbaa !29
  %t117 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %t114, ptr %t115, i32 %t108)
  store i1 %t117, ptr %l59
  br label %bb38
bb38:
  %t118 = load i1, ptr %l59, !tbaa !21
  store i1 %t118, ptr %l55, !tbaa !21
  br label %bb39
bb39:
  %t119 = load i1, ptr %l55, !tbaa !21
  br i1 %t119, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb43
bb41:
  %t120 = load ptr, ptr %l2, !tbaa !29
  store ptr %t120, ptr %l61, !tbaa !29
  %t121 = load i32, ptr %l8, !tbaa !23
  %t122 = load ptr, ptr %l61, !tbaa !29
  %t123 = call ptr @__olang_scope_or(ptr %v1, ptr %t122)
  %t124 = call ptr @__olang_scope_hold(ptr %t123)
  %t125 = ptrtoint ptr %t124 to i64
  %t127 = inttoptr i64 %t125 to ptr
  %t128 = load ptr, ptr %l61, !tbaa !29
  %t130 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclaresCopy(ptr %t127, ptr %t128, i32 %t121)
  store i1 %t130, ptr %l64
  br label %bb42
bb42:
  %t131 = load i1, ptr %l64, !tbaa !21
  store i1 %t131, ptr %l60, !tbaa !21
  br label %bb43
bb43:
  %t132 = load i1, ptr %l60, !tbaa !21
  br i1 %t132, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb48
bb45:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load i32, ptr %l8, !tbaa !23
  %t137 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2femit_2ecompiler_2femit_3afnEm_2egenLeaves(ptr %v0, ptr %s0, ptr %v1, ptr %t133, i32 %t134)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t137, ptr %l68
  br label %bb46
bb46:
  %t139 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eLen_3cArray_3cI64_3e_3e(ptr %s0, ptr %l68)
  store i64 %t139, ptr %l70
  br label %bb47
bb47:
  %t140 = load i64, ptr %l70, !tbaa !24
  %t141 = icmp eq i64 %t140, 0
  store i1 %t141, ptr %l65, !tbaa !21
  br label %bb48
bb48:
  %t143 = load i1, ptr %l65, !tbaa !21
  br i1 %t143, label %bb49, label %bb50
bb49:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb50:
  br label %bb51
bb51:
  %t145 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 3
  %t146 = getelementptr %"compiler/mir:Lvalue", ptr %t145, i32 0, i32 0
  %t147 = load { i64, [2 x i64] }, ptr %t146
  store { i64, [2 x i64] } %t147, ptr %l9
  %t149 = load { i64, [2 x i64] }, ptr %l9
  %t151 = extractvalue { i64, [2 x i64] } %t149, 0
  %t152 = icmp eq i64 %t151, 1
  br i1 %t152, label %bb52, label %bb53
bb52:
  %t154 = getelementptr { i64, [2 x i64] }, ptr %l9, i32 0, i32 1
  %t155 = getelementptr { i32 }, ptr %t154, i32 0, i32 0
  %t156 = load i32, ptr %t155
  store i32 %t156, ptr %l10, !tbaa !23
  br label %bb54
bb53:
  br label %bb55
bb54:
  %t158 = load i32, ptr %l10, !tbaa !23
  %t160 = sext i32 %t158 to i64
  store i64 %t160, ptr %l74, !tbaa !24
  br label %bb60
bb55:
  br i1 true, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb59
bb58:
  store i64 -1, ptr %l74, !tbaa !24
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_4a9082f792731fd7_7c42022e8195998b)
  unreachable
bb60:
  %t162 = load i64, ptr %l74, !tbaa !24
  store i64 %t162, ptr %l11, !tbaa !24
  %t163 = load i64, ptr %l11, !tbaa !24
  %t165 = icmp slt i64 %t163, 0
  br i1 %t165, label %bb61, label %bb62
bb61:
  store i1 true, ptr %l82, !tbaa !21
  br label %bb64
bb62:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load i64, ptr %l11, !tbaa !24
  %t169 = load i32, ptr %l8, !tbaa !23
  %t173 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2enewOnce(ptr %v0, ptr %v2, ptr %v1, ptr %t167, i64 %t168, i32 %t169)
  store i1 %t173, ptr %l86
  br label %bb63
bb63:
  %t174 = load i1, ptr %l86, !tbaa !21
  %t175 = xor i1 %t174, true
  store i1 %t175, ptr %l82, !tbaa !21
  br label %bb64
bb64:
  %t177 = load i1, ptr %l82, !tbaa !21
  br i1 %t177, label %bb65, label %bb66
bb65:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb66:
  br label %bb67
bb67:
  %t179 = load i64, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t179, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eslotScope(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l39 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = call ptr @__olang_scope_or(ptr %v3, ptr %t5)
  %t7 = call ptr @__olang_scope_hold(ptr %t6)
  %t8 = ptrtoint ptr %t7 to i64
  %t10 = inttoptr i64 %t8 to ptr
  %t11 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %t10, ptr %s0, ptr %t11, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d253, i32 0, i32 1) })
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %s0, ptr %v2, ptr %t12, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d254, i32 0, i32 1) }, i64 0)
  store { i64, ptr } %t14, ptr %l9
  br label %bb2
bb2:
  %t15 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t15, ptr %l3, !tbaa !27
  br i1 %a2, label %bb3, label %bb4
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t22 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eflatScope(ptr %v0, ptr %v1, ptr %v1, ptr %v3, ptr %t18, { i64, ptr } %t19)
  store { i64, ptr } %t22, ptr %l14
  br label %bb5
bb4:
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t23, ptr %l11, !tbaa !27
  br label %bb6
bb5:
  %t25 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t25, ptr %l11, !tbaa !27
  br label %bb6
bb6:
  %t27 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t27, ptr %l4, !tbaa !27
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t30 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d255, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d255, i32 0, i32 1) }, 0
  %t33 = extractvalue { i64, ptr } %t29, 1
  %t34 = extractvalue { i64, ptr } %t29, 0
  %t35 = add i64 %t31, %t34
  %t36 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t35)
  call void @olang_textcopy(ptr %t36, ptr %t30, i64 %t31)
  %t37 = getelementptr i8, ptr %t36, i64 %t31
  call void @olang_textcopy(ptr %t37, ptr %t33, i64 %t34)
  %t38 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t36, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %v3, ptr %t28, { i64, ptr } %t39)
  br label %bb7
bb7:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t45 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d256, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d256, i32 0, i32 1) }, 0
  %t48 = extractvalue { i64, ptr } %t44, 1
  %t49 = extractvalue { i64, ptr } %t44, 0
  %t50 = add i64 %t46, %t49
  %t51 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t50)
  call void @olang_textcopy(ptr %t51, ptr %t45, i64 %t46)
  %t52 = getelementptr i8, ptr %t51, i64 %t46
  call void @olang_textcopy(ptr %t52, ptr %t48, i64 %t49)
  %t53 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t51, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %v3, ptr %t43, { i64, ptr } %t54)
  br label %bb8
bb8:
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l25, !tbaa !29
  %t59 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t59, ptr %l26, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t62 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d257, i32 0, i32 1) }, 1
  %t63 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d257, i32 0, i32 1) }, 0
  %t65 = extractvalue { i64, ptr } %t61, 1
  %t66 = extractvalue { i64, ptr } %t61, 0
  %t67 = add i64 %t63, %t66
  %t68 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d258, i32 0, i32 1) }, 1
  %t69 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d258, i32 0, i32 1) }, 0
  %t70 = add i64 %t67, %t69
  %t71 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t70)
  call void @olang_textcopy(ptr %t71, ptr %t62, i64 %t63)
  %t72 = getelementptr i8, ptr %t71, i64 %t63
  call void @olang_textcopy(ptr %t72, ptr %t65, i64 %t66)
  %t73 = getelementptr i8, ptr %t72, i64 %t66
  call void @olang_textcopy(ptr %t73, ptr %t68, i64 %t69)
  %t74 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t71, 1
  %t79 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v3, ptr %t60, { i64, ptr } %t75)
  store { i64, ptr } %t79, ptr %l31
  br label %bb9
bb9:
  %t80 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d259, i32 0, i32 1) }, 1
  %t81 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d259, i32 0, i32 1) }, 0
  %t82 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 1
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t85 = add i64 %t81, %t84
  %t86 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d260, i32 0, i32 1) }, 1
  %t87 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d260, i32 0, i32 1) }, 0
  %t88 = add i64 %t85, %t87
  %t89 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t89, 1
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t92 = add i64 %t88, %t91
  %t93 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t92)
  call void @olang_textcopy(ptr %t93, ptr %t80, i64 %t81)
  %t94 = getelementptr i8, ptr %t93, i64 %t81
  call void @olang_textcopy(ptr %t94, ptr %t83, i64 %t84)
  %t95 = getelementptr i8, ptr %t94, i64 %t84
  call void @olang_textcopy(ptr %t95, ptr %t86, i64 %t87)
  %t96 = getelementptr i8, ptr %t95, i64 %t87
  call void @olang_textcopy(ptr %t96, ptr %t90, i64 %t91)
  %t97 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t93, 1
  %t100 = load ptr, ptr %l25, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %v3, ptr %t100, { i64, ptr } %t98)
  br label %bb10
bb10:
  %t102 = load ptr, ptr %l0, !tbaa !29
  store ptr %t102, ptr %l34, !tbaa !29
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t105 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d261, i32 0, i32 1) }, 1
  %t106 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d261, i32 0, i32 1) }, 0
  %t108 = extractvalue { i64, ptr } %t104, 1
  %t109 = extractvalue { i64, ptr } %t104, 0
  %t110 = add i64 %t106, %t109
  %t111 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d262, i32 0, i32 1) }, 1
  %t112 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d262, i32 0, i32 1) }, 0
  %t113 = add i64 %t110, %t112
  %t114 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t113)
  call void @olang_textcopy(ptr %t114, ptr %t105, i64 %t106)
  %t115 = getelementptr i8, ptr %t114, i64 %t106
  call void @olang_textcopy(ptr %t115, ptr %t108, i64 %t109)
  %t116 = getelementptr i8, ptr %t115, i64 %t109
  call void @olang_textcopy(ptr %t116, ptr %t111, i64 %t112)
  %t117 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t114, 1
  %t122 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v3, ptr %t103, { i64, ptr } %t118)
  store { i64, ptr } %t122, ptr %l39
  br label %bb11
bb11:
  %t123 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d263, i32 0, i32 1) }, 1
  %t124 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d263, i32 0, i32 1) }, 0
  %t125 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t125, 1
  %t127 = extractvalue { i64, ptr } %t125, 0
  %t128 = add i64 %t124, %t127
  %t129 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t128)
  call void @olang_textcopy(ptr %t129, ptr %t123, i64 %t124)
  %t130 = getelementptr i8, ptr %t129, i64 %t124
  call void @olang_textcopy(ptr %t130, ptr %t126, i64 %t127)
  %t131 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t129, 1
  %t134 = load ptr, ptr %l34, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %v3, ptr %t134, { i64, ptr } %t132)
  br label %bb12
bb12:
  %t136 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t136, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2espawn(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/mir:Task"
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, [7 x i64] }
  %l11 = alloca { i64, [2 x i64] }
  %l12 = alloca i32
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca { i64, [4 x i64] }
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca { i64, ptr }
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca i32
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i32
  %l32 = alloca i32
  %l33 = alloca i32
  %l34 = alloca { i64, [1 x i64] }
  %l35 = alloca i1
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca i32
  %l40 = alloca i32
  %l41 = alloca i32
  %l42 = alloca i32
  %l43 = alloca i32
  %l44 = alloca i32
  %l45 = alloca { { i64, ptr }, i32 }
  %l46 = alloca { i64, ptr }
  %l47 = alloca i32
  %l48 = alloca i32
  %l49 = alloca i32
  %l50 = alloca i32
  %l51 = alloca i32
  %l53 = alloca { i64, [4 x i64] }
  %l54 = alloca { i64, ptr }
  %l55 = alloca i32
  %l56 = alloca i32
  %l57 = alloca i32
  %l58 = alloca i32
  %l59 = alloca i32
  %l60 = alloca i32
  %l61 = alloca { i64, [1 x i64] }
  %l62 = alloca { i64, ptr }
  %l63 = alloca i64
  %l64 = alloca { i64, ptr }
  %l65 = alloca %"std/prelude/text:StringBuilder"
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i64
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l85 = alloca ptr
  %l86 = alloca i64
  %l87 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %l108 = alloca ptr
  %l112 = alloca i64
  %l114 = alloca ptr
  %l117 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l122 = alloca { i64, ptr }
  %l129 = alloca i64
  %l131 = alloca ptr
  %l135 = alloca { i64, ptr }
  %l136 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %l148 = alloca i32
  %l152 = alloca { i64, ptr }
  %l153 = alloca { i64, ptr }
  %l165 = alloca ptr
  %l166 = alloca ptr
  %l169 = alloca i32
  %l174 = alloca { i64, ptr }
  %l175 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l176 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l186 = alloca i64
  %l189 = alloca i64
  %l207 = alloca ptr
  %l208 = alloca i64
  %l211 = alloca { i64, ptr }
  %l214 = alloca { i64, ptr }
  %l216 = alloca ptr
  %l217 = alloca i64
  %l220 = alloca { i64, ptr }
  %l223 = alloca i1
  %l224 = alloca { i64, ptr }
  %l225 = alloca { i64, ptr }
  %l228 = alloca ptr
  %l232 = alloca { i64, [4 x i64] }
  %l233 = alloca { i64, ptr }
  %l236 = alloca { i64, ptr }
  %l241 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l246 = alloca i32
  %l249 = alloca i32
  %l269 = alloca ptr
  %l276 = alloca { i64, [1 x i64] }
  %l281 = alloca %"compiler/mir:Task"
  %l284 = alloca i1
  %l286 = alloca { i64, ptr }
  %l287 = alloca ptr
  %l290 = alloca { i64, ptr }
  %l293 = alloca i64
  %l297 = alloca { i64, ptr }
  %l298 = alloca ptr
  %l299 = alloca ptr
  %l302 = alloca { i64, ptr }
  %l305 = alloca { i64, ptr }
  %l307 = alloca { i64, ptr }
  %l311 = alloca { i64, ptr }
  %l313 = alloca ptr
  %l314 = alloca { i64, ptr }
  %l317 = alloca { i64, ptr }
  %l322 = alloca { i64, ptr }
  %l323 = alloca ptr
  %l324 = alloca i64
  %l329 = alloca ptr
  %l330 = alloca i64
  %l342 = alloca i32
  %l345 = alloca i32
  %l364 = alloca ptr
  %l367 = alloca ptr
  %l374 = alloca %"compiler/mir:Lvalue"
  %l375 = alloca { { i64, ptr }, i32 }
  %l377 = alloca ptr
  %l378 = alloca i64
  %l390 = alloca i32
  %l393 = alloca i32
  %l413 = alloca ptr
  %l420 = alloca %"compiler/mir:TaskClause"
  %l426 = alloca ptr
  %l427 = alloca i64
  %l429 = alloca ptr
  %l430 = alloca { i64, [4 x i64] }
  %l433 = alloca i32
  %l434 = alloca { i64, ptr }
  %l440 = alloca i64
  %l448 = alloca i32
  %l451 = alloca i32
  %l471 = alloca ptr
  %l478 = alloca { i64, [1 x i64] }
  %l483 = alloca i32
  %l485 = alloca i64
  %l488 = alloca ptr
  %l490 = alloca ptr
  %l493 = alloca { i64, ptr }
  %l497 = alloca { i64, ptr }
  %l498 = alloca ptr
  %l499 = alloca i64
  %l504 = alloca i32
  %l506 = alloca i64
  %l508 = alloca ptr
  %l509 = alloca i64
  %l519 = alloca ptr
  %l521 = alloca ptr
  %l522 = alloca ptr
  %l525 = alloca ptr
  %l529 = alloca { i64, [1 x i64] }
  %l530 = alloca { i64, ptr }
  %l534 = alloca { i64, ptr }
  %l535 = alloca ptr
  %l536 = alloca i64
  %l542 = alloca i64
  %l544 = alloca ptr
  %l545 = alloca i64
  %l550 = alloca %"std/prelude/text:StringBuilder"
  %l553 = alloca i64
  %l557 = alloca i64
  %l560 = alloca i64
  %l581 = alloca ptr
  %l584 = alloca { i64, ptr }
  %l589 = alloca i64
  %l594 = alloca { i64, ptr }
  %l595 = alloca ptr
  %l597 = alloca ptr
  %l602 = alloca { i64, ptr }
  %l605 = alloca { i64, ptr }
  %l611 = alloca { i64, ptr }
  %l613 = alloca i64
  %l615 = alloca i64
  %l619 = alloca i64
  %l622 = alloca i64
  %l646 = alloca { i64, ptr }
  %l649 = alloca { i64, ptr }
  %l650 = alloca i1
  %l651 = alloca ptr
  %l652 = alloca { i64, ptr }
  %l653 = alloca { i64, ptr }
  %l657 = alloca i32
  %l663 = alloca { i64, [4 x i64] }
  %l664 = alloca ptr
  %l667 = alloca { i64, ptr }
  %l670 = alloca { i64, ptr }
  %l679 = alloca { i64, ptr }
  %l680 = alloca { i64, ptr }
  %l683 = alloca i64
  %l685 = alloca i64
  %l690 = alloca { i64, ptr }
  %l695 = alloca { i64, ptr }
  %l699 = alloca ptr
  %l700 = alloca { i64, ptr }
  %l705 = alloca { i64, ptr }
  %l707 = alloca i64
  %l709 = alloca { i64, ptr }
  %l710 = alloca i64
  %l711 = alloca { i64, ptr }
  %l712 = alloca { i64, ptr }
  %l718 = alloca ptr
  %l719 = alloca { i64, ptr }
  %l724 = alloca { i64, ptr }
  %l726 = alloca ptr
  %l731 = alloca { i64, ptr }
  %l733 = alloca ptr
  %l738 = alloca { i64, ptr }
  %l740 = alloca ptr
  %l745 = alloca { i64, ptr }
  %l747 = alloca ptr
  %l748 = alloca { i64, ptr }
  %l749 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l751 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l752 = alloca i1
  %l753 = alloca { i64, ptr }
  %l754 = alloca i32
  %l756 = alloca i64
  %l757 = alloca %"compiler/mir:Task"
  %l760 = alloca ptr
  %l764 = alloca %"compiler/mir:ScopeInfo"
  %l768 = alloca { i64, ptr }
  %l769 = alloca ptr
  %l771 = alloca ptr
  %l774 = alloca { i64, ptr }
  %l782 = alloca ptr
  %l787 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s47 = alloca %olang.scope
  %s49 = alloca %olang.scope
  %s54 = alloca %olang.scope
  %s56 = alloca %olang.scope
  %s57 = alloca %olang.scope
  %s61 = alloca %olang.scope
  %t509 = alloca %"compiler/mir:Task", align 8
  %t939 = alloca i64
  %t1826 = alloca %"compiler/mir:Task", align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %a2, i64 144, i1 false)
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/emit:fnEm", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  store ptr %t12, ptr %l4, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t15 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d264, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d264, i32 0, i32 1) }, 0
  %t18 = sext i32 %t14 to i64
  %t19 = call i64 @__olang_fmt_i64(ptr null, i64 %t18)
  %t20 = add i64 %t16, %t19
  %t21 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t20)
  call void @olang_textcopy(ptr %t21, ptr %t15, i64 %t16)
  %t22 = getelementptr i8, ptr %t21, i64 %t16
  %t23 = call i64 @__olang_fmt_i64(ptr %t22, i64 %t18)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t21, 1
  store { i64, ptr } %t25, ptr %l5, !tbaa !27
  %t27 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t27, ptr %l6, !tbaa !23
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d265, i32 0, i32 1) }, ptr %l99, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t29, ptr %l7, !tbaa !27
  store i1 false, ptr %l8, !tbaa !21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d266, i32 0, i32 1) }, ptr %l101, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l101, !tbaa !27
  store { i64, ptr } %t31, ptr %l9, !tbaa !27
  %t33 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 0
  %t34 = load { i64, [7 x i64] }, ptr %t33
  store { i64, [7 x i64] } %t34, ptr %l10
  %t36 = load { i64, [7 x i64] }, ptr %l10
  %t38 = extractvalue { i64, [7 x i64] } %t36, 0
  %t39 = icmp eq i64 %t38, 0
  br i1 %t39, label %bb1, label %bb2
bb1:
  %t41 = getelementptr { i64, [7 x i64] }, ptr %l10, i32 0, i32 1
  %t42 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t41, i32 0, i32 0
  %t43 = load { i64, [2 x i64] }, ptr %t42
  store { i64, [2 x i64] } %t43, ptr %l11
  %t45 = getelementptr { i64, [7 x i64] }, ptr %l10, i32 0, i32 1
  %t46 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t45, i32 0, i32 1
  %t47 = load i32, ptr %t46
  store i32 %t47, ptr %l12, !tbaa !23
  br label %bb3
bb2:
  br label %bb14
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t49 = load ptr, ptr %l4, !tbaa !29
  store ptr %t49, ptr %l108, !tbaa !29
  %t50 = load { i64, [2 x i64] }, ptr %l11
  %t51 = load ptr, ptr %l108, !tbaa !29
  %t52 = call ptr @__olang_scope_or(ptr %v1, ptr %t51)
  %t53 = call ptr @__olang_scope_hold(ptr %t52)
  %t54 = ptrtoint ptr %t53 to i64
  %t56 = inttoptr i64 %t54 to ptr
  %t57 = load ptr, ptr %l108, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewant(ptr %t56, ptr %t57, { i64, [2 x i64] } %t50)
  br label %bb4
bb4:
  %t59 = load i32, ptr %l12, !tbaa !23
  store i32 %t59, ptr %l6, !tbaa !23
  %t61 = call ptr @__olang_scope_hold(ptr %s0)
  %t62 = ptrtoint ptr %t61 to i64
  store i64 %t62, ptr %l112, !tbaa !24
  %t63 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2espawn_2elocal_2e7
  br i1 %t63, label %bb5, label %bb6
bb5:
  %t65 = call ptr @__olang_region_make(ptr %s0)
  %t66 = ptrtoint ptr %t65 to i64
  store i64 %t66, ptr %l112, !tbaa !24
  br label %bb6
bb6:
  %t67 = load ptr, ptr %l4, !tbaa !29
  store ptr %t67, ptr %l114, !tbaa !29
  %t68 = load { i64, [2 x i64] }, ptr %l11
  %t69 = load ptr, ptr %l114, !tbaa !29
  %t70 = call ptr @__olang_scope_or(ptr %v1, ptr %t69)
  %t71 = call ptr @__olang_scope_hold(ptr %t70)
  %t72 = ptrtoint ptr %t71 to i64
  %t74 = inttoptr i64 %t72 to ptr
  %t75 = load ptr, ptr %l114, !tbaa !29
  %t77 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %t74, ptr %s2, ptr %t75, { i64, [2 x i64] } %t68)
  store { i64, ptr } %t77, ptr %l117
  br label %bb7
bb7:
  %t78 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d267, i32 0, i32 1) }, 1
  %t79 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d267, i32 0, i32 1) }, 0
  %t80 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 1
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t83 = add i64 %t79, %t82
  %t84 = load i64, ptr %l112
  %t85 = inttoptr i64 %t84 to ptr
  %t86 = call ptr @__olang_held_alloc(ptr %t85, i64 %t83)
  call void @olang_textcopy(ptr %t86, ptr %t78, i64 %t79)
  %t87 = getelementptr i8, ptr %t86, i64 %t79
  call void @olang_textcopy(ptr %t87, ptr %t81, i64 %t82)
  %t88 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t86, 1
  store { i64, ptr } %t89, ptr %l118, !tbaa !27
  %t90 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2espawn_2elocal_2e7
  br i1 %t90, label %bb8, label %bb9
bb8:
  %t92 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 0
  %t95 = icmp eq i64 %t93, 0
  br i1 %t95, label %bb10, label %bb11
bb9:
  %t97 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t97, ptr %l122, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l118, !tbaa !27
  store { i64, ptr } %t98, ptr %l7, !tbaa !27
  %t99 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2espawn_2elocal_2e7
  br i1 %t99, label %bb12, label %bb13
bb10:
  store { i64, ptr } zeroinitializer, ptr %l118, !tbaa !27
  br label %bb11
bb11:
  %t101 = load i64, ptr %l112
  %t102 = inttoptr i64 %t101 to ptr
  %t103 = load { i64, ptr }, ptr %l118
  %t104 = extractvalue { i64, ptr } %t103, 1
  %t105 = call ptr @__olang_region_or(ptr %t104, ptr null)
  %t106 = icmp ne ptr %t105, null
  %t107 = select i1 %t106, ptr %t105, ptr null
  call void @__olang_region_settle_in(ptr %t102, ptr %t107)
  br label %bb9
bb12:
  %t108 = load { i64, ptr }, ptr %l122
  %t109 = extractvalue { i64, ptr } %t108, 1
  call void @__olang_region_release(ptr %t109)
  store { i64, ptr } zeroinitializer, ptr %l122
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb47
bb14:
  %t110 = load { i64, [7 x i64] }, ptr %l10
  %t112 = extractvalue { i64, [7 x i64] } %t110, 0
  %t113 = icmp eq i64 %t112, 1
  br i1 %t113, label %bb15, label %bb16
bb15:
  %t115 = getelementptr { i64, [7 x i64] }, ptr %l10, i32 0, i32 1
  %t116 = getelementptr { i64, i32 }, ptr %t115, i32 0, i32 0
  %t117 = load i64, ptr %t116
  store i64 %t117, ptr %l13, !tbaa !24
  %t119 = getelementptr { i64, [7 x i64] }, ptr %l10, i32 0, i32 1
  %t120 = getelementptr { i64, i32 }, ptr %t119, i32 0, i32 1
  %t121 = load i32, ptr %t120
  store i32 %t121, ptr %l14, !tbaa !23
  br label %bb17
bb16:
  br label %bb28
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t123 = load i32, ptr %l14, !tbaa !23
  store i32 %t123, ptr %l6, !tbaa !23
  %t125 = call ptr @__olang_scope_hold(ptr %s0)
  %t126 = ptrtoint ptr %t125 to i64
  store i64 %t126, ptr %l129, !tbaa !24
  %t127 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2espawn_2elocal_2e7
  br i1 %t127, label %bb18, label %bb19
bb18:
  %t129 = call ptr @__olang_region_make(ptr %s0)
  %t130 = ptrtoint ptr %t129 to i64
  store i64 %t130, ptr %l129, !tbaa !24
  br label %bb19
bb19:
  %t131 = load ptr, ptr %l4, !tbaa !29
  store ptr %t131, ptr %l131, !tbaa !29
  %t132 = load i64, ptr %l13, !tbaa !24
  %t133 = load i32, ptr %l14, !tbaa !23
  %t134 = load ptr, ptr %l131, !tbaa !29
  %t135 = call ptr @__olang_scope_or(ptr %v1, ptr %t134)
  %t136 = call ptr @__olang_scope_hold(ptr %t135)
  %t137 = ptrtoint ptr %t136 to i64
  %t139 = inttoptr i64 %t137 to ptr
  %t140 = load ptr, ptr %l131, !tbaa !29
  %t143 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eextern(ptr %t139, ptr %s4, ptr %t140, i64 %t132, i32 %t133)
  store { i64, ptr } %t143, ptr %l135
  br label %bb20
bb20:
  %t144 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d268, i32 0, i32 1) }, 1
  %t145 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d268, i32 0, i32 1) }, 0
  %t146 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t146, 1
  %t148 = extractvalue { i64, ptr } %t146, 0
  %t149 = add i64 %t145, %t148
  %t150 = load i64, ptr %l129
  %t151 = inttoptr i64 %t150 to ptr
  %t152 = call ptr @__olang_held_alloc(ptr %t151, i64 %t149)
  call void @olang_textcopy(ptr %t152, ptr %t144, i64 %t145)
  %t153 = getelementptr i8, ptr %t152, i64 %t145
  call void @olang_textcopy(ptr %t153, ptr %t147, i64 %t148)
  %t154 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t152, 1
  store { i64, ptr } %t155, ptr %l136, !tbaa !27
  %t156 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2espawn_2elocal_2e7
  br i1 %t156, label %bb21, label %bb22
bb21:
  %t158 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t158, 0
  %t161 = icmp eq i64 %t159, 0
  br i1 %t161, label %bb23, label %bb24
bb22:
  %t163 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t163, ptr %l140, !tbaa !27
  %t164 = load { i64, ptr }, ptr %l136, !tbaa !27
  store { i64, ptr } %t164, ptr %l7, !tbaa !27
  %t165 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2espawn_2elocal_2e7
  br i1 %t165, label %bb25, label %bb26
bb23:
  store { i64, ptr } zeroinitializer, ptr %l136, !tbaa !27
  br label %bb24
bb24:
  %t167 = load i64, ptr %l129
  %t168 = inttoptr i64 %t167 to ptr
  %t169 = load { i64, ptr }, ptr %l136
  %t170 = extractvalue { i64, ptr } %t169, 1
  %t171 = call ptr @__olang_region_or(ptr %t170, ptr null)
  %t172 = icmp ne ptr %t171, null
  %t173 = select i1 %t172, ptr %t171, ptr null
  call void @__olang_region_settle_in(ptr %t168, ptr %t173)
  br label %bb22
bb25:
  %t174 = load { i64, ptr }, ptr %l140
  %t175 = extractvalue { i64, ptr } %t174, 1
  call void @__olang_region_release(ptr %t175)
  store { i64, ptr } zeroinitializer, ptr %l140
  br label %bb26
bb26:
  %t176 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s4, ptr %v1, ptr %t176, { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d269, i32 0, i32 1) })
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s4)
  br label %bb47
bb28:
  %t178 = load { i64, [7 x i64] }, ptr %l10
  %t180 = extractvalue { i64, [7 x i64] } %t178, 0
  %t181 = icmp eq i64 %t180, 2
  br i1 %t181, label %bb29, label %bb30
bb29:
  %t183 = getelementptr { i64, [7 x i64] }, ptr %l10, i32 0, i32 1
  %t184 = getelementptr { { i64, [4 x i64] } }, ptr %t183, i32 0, i32 0
  %t185 = load { i64, [4 x i64] }, ptr %t184
  store { i64, [4 x i64] } %t185, ptr %l15
  br label %bb31
bb30:
  br label %bb36
bb31:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load { i64, [4 x i64] }, ptr %l15
  %t191 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %v2, ptr %v1, ptr %t187, { i64, [4 x i64] } %t188)
  store i32 %t191, ptr %l148
  br label %bb32
bb32:
  %t192 = load i32, ptr %l148, !tbaa !23
  store i32 %t192, ptr %l6, !tbaa !23
  store i1 true, ptr %l8, !tbaa !21
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load { i64, [4 x i64] }, ptr %l15
  %t195 = load i32, ptr %l6, !tbaa !23
  %t199 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s0, ptr %v2, ptr %v1, ptr %t193, { i64, [4 x i64] } %t194, i32 %t195)
  store { i64, ptr } %t199, ptr %l152
  br label %bb33
bb33:
  %t200 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t200, ptr %l153, !tbaa !27
  %t201 = load { i64, ptr }, ptr %l152, !tbaa !27
  store { i64, ptr } %t201, ptr %l9, !tbaa !27
  %t202 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2espawn_2elocal_2e9
  br i1 %t202, label %bb34, label %bb35
bb34:
  %t204 = load { i64, ptr }, ptr %l153
  %t205 = extractvalue { i64, ptr } %t204, 1
  call void @__olang_region_release(ptr %t205)
  store { i64, ptr } zeroinitializer, ptr %l153
  br label %bb35
bb35:
  br label %bb47
bb36:
  %t206 = load { i64, [7 x i64] }, ptr %l10
  %t208 = extractvalue { i64, [7 x i64] } %t206, 0
  %t209 = icmp eq i64 %t208, 3
  br i1 %t209, label %bb37, label %bb38
bb37:
  %t211 = getelementptr { i64, [7 x i64] }, ptr %l10, i32 0, i32 1
  %t212 = getelementptr { { i64, [4 x i64] }, i64, i32 }, ptr %t211, i32 0, i32 2
  %t213 = load i32, ptr %t212
  store i32 %t213, ptr %l16, !tbaa !23
  br label %bb39
bb38:
  br label %bb41
bb39:
  store %olang.scope zeroinitializer, ptr %s7
  %t215 = load i32, ptr %l16, !tbaa !23
  store i32 %t215, ptr %l6, !tbaa !23
  %t217 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s7, ptr %v1, ptr %t217, { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d270, i32 0, i32 1) })
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s7)
  br label %bb47
bb41:
  %t219 = load { i64, [7 x i64] }, ptr %l10
  %t221 = extractvalue { i64, [7 x i64] } %t219, 0
  %t222 = icmp eq i64 %t221, 4
  br i1 %t222, label %bb42, label %bb43
bb42:
  %t224 = getelementptr { i64, [7 x i64] }, ptr %l10, i32 0, i32 1
  %t225 = getelementptr { { i64, [4 x i64] }, i32 }, ptr %t224, i32 0, i32 1
  %t226 = load i32, ptr %t225
  store i32 %t226, ptr %l17, !tbaa !23
  br label %bb44
bb43:
  br label %bb46
bb44:
  store %olang.scope zeroinitializer, ptr %s8
  %t228 = load i32, ptr %l17, !tbaa !23
  store i32 %t228, ptr %l6, !tbaa !23
  %t230 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s8, ptr %v1, ptr %t230, { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d271, i32 0, i32 1) })
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s8)
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_e0bde991406b3b8f_e6287fb3b91b7a9b)
  unreachable
bb47:
  %t232 = load ptr, ptr %l3, !tbaa !29
  store ptr %t232, ptr %l165, !tbaa !29
  %t233 = load ptr, ptr %l3, !tbaa !29
  store ptr %t233, ptr %l166, !tbaa !29
  %t234 = load i32, ptr %l6, !tbaa !23
  %t235 = load ptr, ptr %l166, !tbaa !29
  %t236 = call ptr @__olang_scope_or(ptr %v1, ptr %t235)
  %t237 = call ptr @__olang_scope_hold(ptr %t236)
  %t238 = ptrtoint ptr %t237 to i64
  %t240 = inttoptr i64 %t238 to ptr
  %t241 = load ptr, ptr %l166, !tbaa !29
  %t243 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %t240, ptr %t241, i32 %t234)
  store i32 %t243, ptr %l169
  br label %bb48
bb48:
  %t244 = load ptr, ptr %l165, !tbaa !29
  %t245 = call ptr @__olang_scope_or(ptr %v1, ptr %t244)
  %t246 = call ptr @__olang_scope_hold(ptr %t245)
  %t247 = ptrtoint ptr %t246 to i64
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t250 = getelementptr %"compiler/emit:fnEm", ptr %t248, i32 0, i32 0
  %t251 = load ptr, ptr %t250, !tbaa !29
  %t253 = call ptr @__olang_scope_or(ptr %v1, ptr %t251)
  %t254 = call ptr @__olang_scope_hold(ptr %t253)
  %t255 = ptrtoint ptr %t254 to i64
  %t257 = inttoptr i64 %t247 to ptr
  %t259 = inttoptr i64 %t255 to ptr
  %t260 = load ptr, ptr %l165, !tbaa !29
  %t261 = load i32, ptr %l169, !tbaa !23
  %t262 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t257, ptr %t259, ptr %t260, i32 %t261)
  store { i64, ptr } %t262, ptr %l174
  br label %bb49
bb49:
  %t263 = load { i64, ptr }, ptr %l174, !tbaa !27
  store { i64, ptr } %t263, ptr %l18, !tbaa !27
  %t264 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t264, ptr %l175
  br label %bb50
bb50:
  %t265 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l175
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t265, ptr %l19
  %t266 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t266, ptr %l176
  br label %bb51
bb51:
  %t267 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l176
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t267, ptr %l20
  %t268 = load i1, ptr %l8, !tbaa !21
  br i1 %t268, label %bb52, label %bb53
bb52:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l19, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d272, i32 0, i32 1) })
  br label %bb54
bb53:
  br label %bb56
bb54:
  %t271 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l20, { i64, ptr } %t271)
  br label %bb55
bb55:
  br label %bb56
bb56:
  store i64 0, ptr %l21, !tbaa !24
  %t274 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t276 = extractvalue { i64, ptr } %t274, 0
  store i64 %t276, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t278 = load i64, ptr %l22, !tbaa !24
  %t279 = load i64, ptr %l21, !tbaa !24
  %t282 = icmp sgt i64 %t278, %t279
  br i1 %t282, label %bb57, label %bb58
bb57:
  %t284 = load i64, ptr %l23, !tbaa !24
  %t286 = icmp sgt i64 %t284, 0
  br i1 %t286, label %bb59, label %bb60
bb58:
  store i64 0, ptr %l186, !tbaa !24
  br label %bb62
bb59:
  %t288 = load i64, ptr %l22, !tbaa !24
  %t289 = load i64, ptr %l21, !tbaa !24
  %t292 = sub i64 %t288, %t289
  %t293 = load i64, ptr %l23, !tbaa !24
  %t296 = add i64 %t292, %t293
  %t298 = sub i64 %t296, 1
  %t299 = load i64, ptr %l23, !tbaa !24
  %t302 = sdiv i64 %t298, %t299
  store i64 %t302, ptr %l189, !tbaa !24
  br label %bb61
bb60:
  store i64 0, ptr %l189, !tbaa !24
  br label %bb61
bb61:
  %t304 = load i64, ptr %l189, !tbaa !24
  store i64 %t304, ptr %l186, !tbaa !24
  br label %bb62
bb62:
  %t305 = load i64, ptr %l186, !tbaa !24
  store i64 %t305, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb63
bb63:
  %t306 = load i64, ptr %l25, !tbaa !24
  %t307 = load i64, ptr %l24, !tbaa !24
  %t310 = icmp slt i64 %t306, %t307
  %t312 = xor i1 %t310, true
  br i1 %t312, label %bb64, label %bb65
bb64:
  br label %bb81
bb65:
  br label %bb66
bb66:
  %t314 = load i64, ptr %l21, !tbaa !24
  %t315 = load i64, ptr %l25, !tbaa !24
  %t316 = load i64, ptr %l23, !tbaa !24
  %t319 = mul i64 %t315, %t316
  %t322 = add i64 %t314, %t319
  store i64 %t322, ptr %l26, !tbaa !24
  store ptr %l19, ptr %l207, !tbaa !29
  %t324 = call ptr @__olang_scope_hold(ptr %s0)
  %t325 = ptrtoint ptr %t324 to i64
  store i64 %t325, ptr %l208, !tbaa !24
  %t326 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t326, label %bb67, label %bb68
bb67:
  %t328 = call ptr @__olang_region_make(ptr %s0)
  %t329 = ptrtoint ptr %t328 to i64
  store i64 %t329, ptr %l208, !tbaa !24
  br label %bb68
bb68:
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t331 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t331, ptr %l211, !tbaa !27
  %t332 = load i64, ptr %l26, !tbaa !24
  %t334 = getelementptr { i64, ptr }, ptr %l211, i32 0, i32 1
  %t335 = load ptr, ptr %t334, !tbaa !27
  %t336 = getelementptr i32, ptr %t335, i64 %t332
  %t337 = load i32, ptr %t336, !tbaa !33
  %t338 = load i64, ptr %l208
  %t339 = inttoptr i64 %t338 to ptr
  %t342 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %t339, ptr %v1, ptr %t330, i32 %t337)
  store { i64, ptr } %t342, ptr %l214
  br label %bb69
bb69:
  %t343 = load { i64, ptr }, ptr %l214, !tbaa !27
  %t344 = load i64, ptr %l208
  %t345 = inttoptr i64 %t344 to ptr
  %t346 = extractvalue { i64, ptr } %t343, 0
  %t347 = extractvalue { i64, ptr } %t343, 1
  %t348 = mul i64 %t346, 1
  %t349 = call ptr @__olang_held_alloc(ptr %t345, i64 %t348)
  call void @llvm.memcpy.p0.p0.i64(ptr %t349, ptr %t347, i64 %t348, i1 false)
  %t350 = insertvalue { i64, ptr } undef, i64 %t346, 0
  %t351 = insertvalue { i64, ptr } %t350, ptr %t349, 1
  %t352 = load ptr, ptr %l207, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t352, { i64, ptr } %t351)
  br label %bb70
bb70:
  store ptr %l20, ptr %l216, !tbaa !29
  %t354 = call ptr @__olang_scope_hold(ptr %s0)
  %t355 = ptrtoint ptr %t354 to i64
  store i64 %t355, ptr %l217, !tbaa !24
  %t356 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t356, label %bb71, label %bb72
bb71:
  %t358 = call ptr @__olang_region_make(ptr %s0)
  %t359 = ptrtoint ptr %t358 to i64
  store i64 %t359, ptr %l217, !tbaa !24
  br label %bb72
bb72:
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t361 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t361, ptr %l220, !tbaa !27
  %t362 = load i64, ptr %l26, !tbaa !24
  %t364 = getelementptr { i64, ptr }, ptr %l220, i32 0, i32 1
  %t365 = load ptr, ptr %t364, !tbaa !27
  %t366 = getelementptr i32, ptr %t365, i64 %t362
  %t367 = load i32, ptr %t366, !tbaa !33
  %t370 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eviaMem(ptr %v0, ptr %v1, ptr %t360, i32 %t367)
  store i1 %t370, ptr %l223
  br label %bb73
bb73:
  %t371 = load i1, ptr %l223, !tbaa !21
  br i1 %t371, label %bb74, label %bb75
bb74:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d273, i32 0, i32 1) }, ptr %l225, !tbaa !27
  %t372 = load { i64, ptr }, ptr %l225, !tbaa !27
  %t374 = load i64, ptr %l217
  %t375 = inttoptr i64 %t374 to ptr
  %t376 = extractvalue { i64, ptr } %t372, 0
  %t377 = extractvalue { i64, ptr } %t372, 1
  %t378 = mul i64 %t376, 1
  %t379 = call ptr @__olang_held_alloc(ptr %t375, i64 %t378)
  call void @llvm.memcpy.p0.p0.i64(ptr %t379, ptr %t377, i64 %t378, i1 false)
  %t380 = insertvalue { i64, ptr } undef, i64 %t376, 0
  %t381 = insertvalue { i64, ptr } %t380, ptr %t379, 1
  store { i64, ptr } %t381, ptr %l224, !tbaa !27
  br label %bb78
bb75:
  %t383 = load ptr, ptr %l0, !tbaa !29
  store ptr %t383, ptr %l228, !tbaa !29
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t385 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 1
  %t386 = load %"compiler/mir:Range", ptr %t385
  %t387 = load i64, ptr %l26, !tbaa !24
  %t391 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %v2, ptr %t384, %"compiler/mir:Range" %t386, i64 %t387)
  store { i64, [4 x i64] } %t391, ptr %l232
  br label %bb76
bb76:
  %t392 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t392, ptr %l233, !tbaa !27
  %t393 = load i64, ptr %l26, !tbaa !24
  %t395 = getelementptr { i64, ptr }, ptr %l233, i32 0, i32 1
  %t396 = load ptr, ptr %t395, !tbaa !27
  %t397 = getelementptr i32, ptr %t396, i64 %t393
  %t398 = load i32, ptr %t397, !tbaa !33
  %t399 = load ptr, ptr %l228, !tbaa !29
  %t400 = load { i64, [4 x i64] }, ptr %l232
  %t402 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s0, ptr %v2, ptr %v1, ptr %t399, { i64, [4 x i64] } %t400, i32 %t398)
  store { i64, ptr } %t402, ptr %l236
  br label %bb77
bb77:
  %t403 = load { i64, ptr }, ptr %l236, !tbaa !27
  %t404 = load i64, ptr %l217
  %t405 = inttoptr i64 %t404 to ptr
  %t406 = extractvalue { i64, ptr } %t403, 0
  %t407 = extractvalue { i64, ptr } %t403, 1
  %t408 = mul i64 %t406, 1
  %t409 = call ptr @__olang_held_alloc(ptr %t405, i64 %t408)
  call void @llvm.memcpy.p0.p0.i64(ptr %t409, ptr %t407, i64 %t408, i1 false)
  %t410 = insertvalue { i64, ptr } undef, i64 %t406, 0
  %t411 = insertvalue { i64, ptr } %t410, ptr %t409, 1
  store { i64, ptr } %t411, ptr %l224, !tbaa !27
  br label %bb78
bb78:
  %t413 = load ptr, ptr %l216, !tbaa !29
  %t414 = load { i64, ptr }, ptr %l224, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t413, { i64, ptr } %t414)
  br label %bb79
bb79:
  br label %bb80
bb80:
  %t415 = load i64, ptr %l25, !tbaa !24
  %t418 = add i64 %t415, 1
  store i64 %t418, ptr %l25, !tbaa !24
  br label %bb63
bb81:
  %t420 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t420, ptr %l241
  br label %bb82
bb82:
  %t421 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l241
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t421, ptr %l27
  store i32 0, ptr %l28, !tbaa !23
  %t422 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 2
  %t423 = getelementptr %"compiler/mir:Range", ptr %t422, i32 0, i32 1
  %t424 = load i32, ptr %t423, !tbaa !23
  store i32 %t424, ptr %l29, !tbaa !23
  store i32 1, ptr %l30, !tbaa !23
  %t426 = load i32, ptr %l29, !tbaa !23
  %t427 = load i32, ptr %l28, !tbaa !23
  %t430 = icmp sgt i32 %t426, %t427
  br i1 %t430, label %bb83, label %bb84
bb83:
  %t432 = load i32, ptr %l30, !tbaa !23
  %t434 = icmp sgt i32 %t432, 0
  br i1 %t434, label %bb85, label %bb86
bb84:
  store i32 0, ptr %l246, !tbaa !23
  br label %bb88
bb85:
  %t436 = load i32, ptr %l29, !tbaa !23
  %t437 = load i32, ptr %l28, !tbaa !23
  %t440 = sub i32 %t436, %t437
  %t441 = load i32, ptr %l30, !tbaa !23
  %t444 = add i32 %t440, %t441
  %t446 = sub i32 %t444, 1
  %t447 = load i32, ptr %l30, !tbaa !23
  %t450 = sdiv i32 %t446, %t447
  store i32 %t450, ptr %l249, !tbaa !23
  br label %bb87
bb86:
  store i32 0, ptr %l249, !tbaa !23
  br label %bb87
bb87:
  %t452 = load i32, ptr %l249, !tbaa !23
  store i32 %t452, ptr %l246, !tbaa !23
  br label %bb88
bb88:
  %t453 = load i32, ptr %l246, !tbaa !23
  store i32 %t453, ptr %l31, !tbaa !23
  store i32 0, ptr %l32, !tbaa !23
  br label %bb89
bb89:
  %t454 = load i32, ptr %l32, !tbaa !23
  %t455 = load i32, ptr %l31, !tbaa !23
  %t458 = icmp slt i32 %t454, %t455
  %t460 = xor i1 %t458, true
  br i1 %t460, label %bb90, label %bb91
bb90:
  br label %bb135
bb91:
  br label %bb92
bb92:
  %t462 = load i32, ptr %l28, !tbaa !23
  %t463 = load i32, ptr %l32, !tbaa !23
  %t464 = load i32, ptr %l30, !tbaa !23
  %t467 = mul i32 %t463, %t464
  %t470 = add i32 %t462, %t467
  store i32 %t470, ptr %l33, !tbaa !23
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t474 = getelementptr %"compiler/emit:fnEm", ptr %t472, i32 0, i32 1
  %t475 = load ptr, ptr %t474, !tbaa !29
  %t477 = getelementptr %"compiler/mir:Fn", ptr %t475, i32 0, i32 12
  store ptr %t477, ptr %l269, !tbaa !29
  %t478 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 2
  %t479 = getelementptr %"compiler/mir:Range", ptr %t478, i32 0, i32 0
  %t480 = load i32, ptr %t479, !tbaa !23
  %t482 = sext i32 %t480 to i64
  %t483 = load i32, ptr %l33, !tbaa !23
  %t485 = sext i32 %t483 to i64
  %t488 = add i64 %t482, %t485
  %t489 = load ptr, ptr %l269, !tbaa !29
  %t490 = call ptr @__olang_scope_or(ptr %v2, ptr %t489)
  %t491 = call ptr @__olang_scope_hold(ptr %t490)
  %t492 = ptrtoint ptr %t491 to i64
  %t494 = inttoptr i64 %t492 to ptr
  %t495 = load ptr, ptr %l269, !tbaa !29
  %t497 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %t494, ptr %t495, i64 %t488)
  store { i64, [1 x i64] } %t497, ptr %l276
  br label %bb93
bb93:
  %t498 = load { i64, [1 x i64] }, ptr %l276
  store { i64, [1 x i64] } %t498, ptr %l34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l19, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d274, i32 0, i32 1) })
  br label %bb94
bb94:
  %t500 = load { i64, [1 x i64] }, ptr %l34
  %t502 = extractvalue { i64, [1 x i64] } %t500, 0
  %t503 = icmp eq i64 %t502, 2
  br i1 %t503, label %bb95, label %bb96
bb95:
  br label %bb97
bb96:
  br label %bb99
bb97:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l20, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d275, i32 0, i32 1) })
  br label %bb98
bb98:
  br label %bb133
bb99:
  br i1 true, label %bb100, label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb132
bb102:
  store %olang.scope zeroinitializer, ptr %s16
  call void @llvm.memmove.p0.p0.i64(ptr %l281, ptr %l2, i64 144, i1 false)
  %t506 = load i32, ptr %l33, !tbaa !23
  %t508 = sext i32 %t506 to i64
  call void @llvm.memmove.p0.p0.i64(ptr %t509, ptr %l281, i64 144, i1 false)
  %t511 = call i1 @compiler_2femit_2efreshScope(ptr %t509, i64 %t508)
  store i1 %t511, ptr %l284
  br label %bb103
bb103:
  %t512 = load i1, ptr %l284, !tbaa !21
  store i1 %t512, ptr %l35, !tbaa !21
  %t513 = load i1, ptr %l35, !tbaa !21
  br i1 %t513, label %bb104, label %bb105
bb104:
  store { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d276, i32 0, i32 1) }, ptr %l286, !tbaa !27
  br label %bb106
bb105:
  store { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d277, i32 0, i32 1) }, ptr %l286, !tbaa !27
  br label %bb106
bb106:
  %t515 = load { i64, ptr }, ptr %l286, !tbaa !27
  store { i64, ptr } %t515, ptr %l36, !tbaa !27
  %t516 = load ptr, ptr %l4, !tbaa !29
  store ptr %t516, ptr %l287, !tbaa !29
  %t517 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t518 = load ptr, ptr %l287, !tbaa !29
  %t519 = call ptr @__olang_scope_or(ptr %v1, ptr %t518)
  %t520 = call ptr @__olang_scope_hold(ptr %t519)
  %t521 = ptrtoint ptr %t520 to i64
  %t523 = inttoptr i64 %t521 to ptr
  %t524 = load ptr, ptr @__olang_prog_scope
  %t525 = load ptr, ptr %l287, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %t523, ptr %t524, ptr %t525, { i64, ptr } %t517)
  br label %bb107
bb107:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d278, i32 0, i32 1) }, ptr %l290, !tbaa !27
  %t527 = load { i64, ptr }, ptr %l290, !tbaa !27
  store { i64, ptr } %t527, ptr %l37, !tbaa !27
  %t529 = load i1, ptr %l35, !tbaa !21
  br i1 %t529, label %bb108, label %bb109
bb108:
  store %olang.scope zeroinitializer, ptr %s17
  %t531 = call ptr @__olang_scope_hold(ptr %s16)
  %t532 = ptrtoint ptr %t531 to i64
  store i64 %t532, ptr %l293, !tbaa !24
  %t533 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2espawn_2elocal_2e37
  br i1 %t533, label %bb110, label %bb111
bb109:
  br label %bb123
bb110:
  %t535 = call ptr @__olang_region_make(ptr %s16)
  %t536 = ptrtoint ptr %t535 to i64
  store i64 %t536, ptr %l293, !tbaa !24
  br label %bb111
bb111:
  %t537 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 9
  %t538 = load i64, ptr %t537, !tbaa !24
  %t540 = icmp slt i64 %t538, 0
  br i1 %t540, label %bb112, label %bb113
bb112:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d279, i32 0, i32 1) }, ptr %l297, !tbaa !27
  br label %bb116
bb113:
  %t542 = load ptr, ptr %l0, !tbaa !29
  store ptr %t542, ptr %l298, !tbaa !29
  %t543 = load ptr, ptr %l4, !tbaa !29
  store ptr %t543, ptr %l299, !tbaa !29
  %t544 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 9
  %t545 = load i64, ptr %t544, !tbaa !24
  %t546 = load ptr, ptr %l299, !tbaa !29
  %t547 = call ptr @__olang_scope_or(ptr %v1, ptr %t546)
  %t548 = call ptr @__olang_scope_hold(ptr %t547)
  %t549 = ptrtoint ptr %t548 to i64
  %t551 = inttoptr i64 %t549 to ptr
  %t552 = load ptr, ptr %l299, !tbaa !29
  %t554 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esole(ptr %t551, ptr %s17, ptr %t552, i64 %t545)
  store { i64, ptr } %t554, ptr %l302
  br label %bb114
bb114:
  %t555 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d280, i32 0, i32 1) }, 1
  %t556 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d280, i32 0, i32 1) }, 0
  %t557 = load { i64, ptr }, ptr %l302, !tbaa !27
  %t558 = extractvalue { i64, ptr } %t557, 1
  %t559 = extractvalue { i64, ptr } %t557, 0
  %t560 = add i64 %t556, %t559
  %t561 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t560)
  call void @olang_textcopy(ptr %t561, ptr %t555, i64 %t556)
  %t562 = getelementptr i8, ptr %t561, i64 %t556
  call void @olang_textcopy(ptr %t562, ptr %t558, i64 %t559)
  %t563 = insertvalue { i64, ptr } undef, i64 %t560, 0
  %t564 = insertvalue { i64, ptr } %t563, ptr %t561, 1
  %t566 = load ptr, ptr %l298, !tbaa !29
  %t568 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s17, ptr %s17, ptr %s17, ptr %s17, ptr %v1, ptr %t566, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d281, i32 0, i32 1) }, { i64, ptr } %t564, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d49, i32 0, i32 1) })
  store { i64, ptr } %t568, ptr %l305
  br label %bb115
bb115:
  %t569 = load { i64, ptr }, ptr %l305, !tbaa !27
  store { i64, ptr } %t569, ptr %l297, !tbaa !27
  br label %bb116
bb116:
  %t571 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d282, i32 0, i32 1) }, 1
  %t572 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d282, i32 0, i32 1) }, 0
  %t573 = load { i64, ptr }, ptr %l297, !tbaa !27
  %t574 = extractvalue { i64, ptr } %t573, 1
  %t575 = extractvalue { i64, ptr } %t573, 0
  %t576 = add i64 %t572, %t575
  %t577 = load i64, ptr %l293
  %t578 = inttoptr i64 %t577 to ptr
  %t579 = call ptr @__olang_held_alloc(ptr %t578, i64 %t576)
  call void @olang_textcopy(ptr %t579, ptr %t571, i64 %t572)
  %t580 = getelementptr i8, ptr %t579, i64 %t572
  call void @olang_textcopy(ptr %t580, ptr %t574, i64 %t575)
  %t581 = insertvalue { i64, ptr } undef, i64 %t576, 0
  %t582 = insertvalue { i64, ptr } %t581, ptr %t579, 1
  store { i64, ptr } %t582, ptr %l307, !tbaa !27
  %t583 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2espawn_2elocal_2e37
  br i1 %t583, label %bb117, label %bb118
bb117:
  %t585 = load { i64, ptr }, ptr %l307, !tbaa !27
  %t586 = extractvalue { i64, ptr } %t585, 0
  %t588 = icmp eq i64 %t586, 0
  br i1 %t588, label %bb119, label %bb120
bb118:
  %t590 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t590, ptr %l311, !tbaa !27
  %t591 = load { i64, ptr }, ptr %l307, !tbaa !27
  store { i64, ptr } %t591, ptr %l37, !tbaa !27
  %t592 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2espawn_2elocal_2e37
  br i1 %t592, label %bb121, label %bb122
bb119:
  store { i64, ptr } zeroinitializer, ptr %l307, !tbaa !27
  br label %bb120
bb120:
  %t594 = load i64, ptr %l293
  %t595 = inttoptr i64 %t594 to ptr
  %t596 = load { i64, ptr }, ptr %l307
  %t597 = extractvalue { i64, ptr } %t596, 1
  %t598 = call ptr @__olang_region_or(ptr %t597, ptr null)
  %t599 = icmp ne ptr %t598, null
  %t600 = select i1 %t599, ptr %t598, ptr null
  call void @__olang_region_settle_in(ptr %t595, ptr %t600)
  br label %bb118
bb121:
  %t601 = load { i64, ptr }, ptr %l311
  %t602 = extractvalue { i64, ptr } %t601, 1
  call void @__olang_region_release(ptr %t602)
  store { i64, ptr } zeroinitializer, ptr %l311
  br label %bb122
bb122:
  call void @__olang_scope_close(ptr %s17)
  br label %bb123
bb123:
  %t603 = load ptr, ptr %l0, !tbaa !29
  store ptr %t603, ptr %l313, !tbaa !29
  %t604 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t604, ptr %l314, !tbaa !27
  %t605 = load ptr, ptr %l0, !tbaa !29
  %t606 = load { i64, [1 x i64] }, ptr %l34
  %t609 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %s16, ptr %v1, ptr %v2, ptr %t605, { i64, [1 x i64] } %t606)
  store { i64, ptr } %t609, ptr %l317
  br label %bb124
bb124:
  %t610 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t611 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t612 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d283, i32 0, i32 1) }, 1
  %t613 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d283, i32 0, i32 1) }, 0
  %t614 = load { i64, ptr }, ptr %l314, !tbaa !27
  %t615 = extractvalue { i64, ptr } %t614, 1
  %t616 = extractvalue { i64, ptr } %t614, 0
  %t617 = add i64 %t613, %t616
  %t618 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d284, i32 0, i32 1) }, 1
  %t619 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d284, i32 0, i32 1) }, 0
  %t620 = add i64 %t617, %t619
  %t621 = load { i64, ptr }, ptr %l317, !tbaa !27
  %t622 = extractvalue { i64, ptr } %t621, 1
  %t623 = extractvalue { i64, ptr } %t621, 0
  %t624 = add i64 %t620, %t623
  %t625 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d285, i32 0, i32 1) }, 1
  %t626 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d285, i32 0, i32 1) }, 0
  %t627 = add i64 %t624, %t626
  %t629 = extractvalue { i64, ptr } %t610, 1
  %t630 = extractvalue { i64, ptr } %t610, 0
  %t631 = add i64 %t627, %t630
  %t633 = extractvalue { i64, ptr } %t611, 1
  %t634 = extractvalue { i64, ptr } %t611, 0
  %t635 = add i64 %t631, %t634
  %t636 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d286, i32 0, i32 1) }, 1
  %t637 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d286, i32 0, i32 1) }, 0
  %t638 = add i64 %t635, %t637
  %t639 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t638)
  call void @olang_textcopy(ptr %t639, ptr %t612, i64 %t613)
  %t640 = getelementptr i8, ptr %t639, i64 %t613
  call void @olang_textcopy(ptr %t640, ptr %t615, i64 %t616)
  %t641 = getelementptr i8, ptr %t640, i64 %t616
  call void @olang_textcopy(ptr %t641, ptr %t618, i64 %t619)
  %t642 = getelementptr i8, ptr %t641, i64 %t619
  call void @olang_textcopy(ptr %t642, ptr %t622, i64 %t623)
  %t643 = getelementptr i8, ptr %t642, i64 %t623
  call void @olang_textcopy(ptr %t643, ptr %t625, i64 %t626)
  %t644 = getelementptr i8, ptr %t643, i64 %t626
  call void @olang_textcopy(ptr %t644, ptr %t629, i64 %t630)
  %t645 = getelementptr i8, ptr %t644, i64 %t630
  call void @olang_textcopy(ptr %t645, ptr %t633, i64 %t634)
  %t646 = getelementptr i8, ptr %t645, i64 %t634
  call void @olang_textcopy(ptr %t646, ptr %t636, i64 %t637)
  %t647 = insertvalue { i64, ptr } undef, i64 %t638, 0
  %t648 = insertvalue { i64, ptr } %t647, ptr %t639, 1
  %t650 = load ptr, ptr %l313, !tbaa !29
  %t652 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s16, ptr %s16, ptr %v1, ptr %t650, { i64, ptr } %t648)
  store { i64, ptr } %t652, ptr %l322
  br label %bb125
bb125:
  %t653 = load { i64, ptr }, ptr %l322, !tbaa !27
  store { i64, ptr } %t653, ptr %l38, !tbaa !27
  store ptr %l27, ptr %l323, !tbaa !29
  %t654 = call ptr @__olang_scope_hold(ptr %s0)
  %t655 = ptrtoint ptr %t654 to i64
  store i64 %t655, ptr %l324, !tbaa !24
  %t656 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t656, label %bb126, label %bb127
bb126:
  %t658 = call ptr @__olang_region_make(ptr %s0)
  %t659 = ptrtoint ptr %t658 to i64
  store i64 %t659, ptr %l324, !tbaa !24
  br label %bb127
bb127:
  %t660 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t662 = extractvalue { i64, ptr } %t660, 1
  %t663 = extractvalue { i64, ptr } %t660, 0
  %t664 = load i64, ptr %l324
  %t665 = inttoptr i64 %t664 to ptr
  %t666 = call ptr @__olang_held_alloc(ptr %t665, i64 %t663)
  call void @olang_textcopy(ptr %t666, ptr %t662, i64 %t663)
  %t667 = insertvalue { i64, ptr } undef, i64 %t663, 0
  %t668 = insertvalue { i64, ptr } %t667, ptr %t666, 1
  %t670 = load ptr, ptr %l323, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t670, { i64, ptr } %t668)
  br label %bb128
bb128:
  store ptr %l20, ptr %l329, !tbaa !29
  %t672 = call ptr @__olang_scope_hold(ptr %s0)
  %t673 = ptrtoint ptr %t672 to i64
  store i64 %t673, ptr %l330, !tbaa !24
  %t674 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t674, label %bb129, label %bb130
bb129:
  %t676 = call ptr @__olang_region_make(ptr %s0)
  %t677 = ptrtoint ptr %t676 to i64
  store i64 %t677, ptr %l330, !tbaa !24
  br label %bb130
bb130:
  %t678 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t680 = extractvalue { i64, ptr } %t678, 1
  %t681 = extractvalue { i64, ptr } %t678, 0
  %t682 = load i64, ptr %l330
  %t683 = inttoptr i64 %t682 to ptr
  %t684 = call ptr @__olang_held_alloc(ptr %t683, i64 %t681)
  call void @olang_textcopy(ptr %t684, ptr %t680, i64 %t681)
  %t685 = insertvalue { i64, ptr } undef, i64 %t681, 0
  %t686 = insertvalue { i64, ptr } %t685, ptr %t684, 1
  %t688 = load ptr, ptr %l329, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t688, { i64, ptr } %t686)
  br label %bb131
bb131:
  call void @__olang_scope_close(ptr %s16)
  br label %bb133
bb132:
  call void @__olang_check_failed(ptr @olang_loc_a90a878cc09c574e_a9a55cce621e609a)
  unreachable
bb133:
  br label %bb134
bb134:
  %t690 = load i32, ptr %l32, !tbaa !23
  %t693 = add i32 %t690, 1
  store i32 %t693, ptr %l32, !tbaa !23
  br label %bb89
bb135:
  store i32 0, ptr %l39, !tbaa !23
  %t695 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 3
  %t696 = getelementptr %"compiler/mir:Range", ptr %t695, i32 0, i32 1
  %t697 = load i32, ptr %t696, !tbaa !23
  store i32 %t697, ptr %l40, !tbaa !23
  store i32 1, ptr %l41, !tbaa !23
  %t699 = load i32, ptr %l40, !tbaa !23
  %t700 = load i32, ptr %l39, !tbaa !23
  %t703 = icmp sgt i32 %t699, %t700
  br i1 %t703, label %bb136, label %bb137
bb136:
  %t705 = load i32, ptr %l41, !tbaa !23
  %t707 = icmp sgt i32 %t705, 0
  br i1 %t707, label %bb138, label %bb139
bb137:
  store i32 0, ptr %l342, !tbaa !23
  br label %bb141
bb138:
  %t709 = load i32, ptr %l40, !tbaa !23
  %t710 = load i32, ptr %l39, !tbaa !23
  %t713 = sub i32 %t709, %t710
  %t714 = load i32, ptr %l41, !tbaa !23
  %t717 = add i32 %t713, %t714
  %t719 = sub i32 %t717, 1
  %t720 = load i32, ptr %l41, !tbaa !23
  %t723 = sdiv i32 %t719, %t720
  store i32 %t723, ptr %l345, !tbaa !23
  br label %bb140
bb139:
  store i32 0, ptr %l345, !tbaa !23
  br label %bb140
bb140:
  %t725 = load i32, ptr %l345, !tbaa !23
  store i32 %t725, ptr %l342, !tbaa !23
  br label %bb141
bb141:
  %t726 = load i32, ptr %l342, !tbaa !23
  store i32 %t726, ptr %l42, !tbaa !23
  store i32 0, ptr %l43, !tbaa !23
  br label %bb142
bb142:
  store %olang.scope zeroinitializer, ptr %s25
  %t727 = load i32, ptr %l43, !tbaa !23
  %t728 = load i32, ptr %l42, !tbaa !23
  %t731 = icmp slt i32 %t727, %t728
  %t733 = xor i1 %t731, true
  br i1 %t733, label %bb143, label %bb144
bb143:
  call void @__olang_scope_close(ptr %s25)
  br label %bb153
bb144:
  br label %bb145
bb145:
  %t735 = load i32, ptr %l39, !tbaa !23
  %t736 = load i32, ptr %l43, !tbaa !23
  %t737 = load i32, ptr %l41, !tbaa !23
  %t740 = mul i32 %t736, %t737
  %t743 = add i32 %t735, %t740
  store i32 %t743, ptr %l44, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l19, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d287, i32 0, i32 1) })
  br label %bb146
bb146:
  %t746 = load ptr, ptr %l0, !tbaa !29
  store ptr %t746, ptr %l364, !tbaa !29
  %t747 = load ptr, ptr %l0, !tbaa !29
  %t749 = getelementptr %"compiler/emit:fnEm", ptr %t747, i32 0, i32 1
  %t750 = load ptr, ptr %t749, !tbaa !29
  %t752 = getelementptr %"compiler/mir:Fn", ptr %t750, i32 0, i32 13
  store ptr %t752, ptr %l367, !tbaa !29
  %t753 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 3
  %t754 = getelementptr %"compiler/mir:Range", ptr %t753, i32 0, i32 0
  %t755 = load i32, ptr %t754, !tbaa !23
  %t757 = sext i32 %t755 to i64
  %t758 = load i32, ptr %l44, !tbaa !23
  %t760 = sext i32 %t758 to i64
  %t763 = add i64 %t757, %t760
  %t764 = load ptr, ptr %l367, !tbaa !29
  %t765 = call ptr @__olang_scope_or(ptr %v2, ptr %t764)
  %t766 = call ptr @__olang_scope_hold(ptr %t765)
  %t767 = ptrtoint ptr %t766 to i64
  %t769 = inttoptr i64 %t767 to ptr
  %t770 = load ptr, ptr %l367, !tbaa !29
  %t772 = call %"compiler/mir:Lvalue" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e_2eAt_3ccompiler_2fmir_3aLvalue_3e(ptr %t769, ptr %t770, i64 %t763)
  store %"compiler/mir:Lvalue" %t772, ptr %l374
  br label %bb147
bb147:
  %t773 = load ptr, ptr %l364, !tbaa !29
  %t774 = load %"compiler/mir:Lvalue", ptr %l374
  %t775 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s25, ptr %v2, ptr %v1, ptr %t773, %"compiler/mir:Lvalue" %t774)
  store { { i64, ptr }, i32 } %t775, ptr %l375
  br label %bb148
bb148:
  %t776 = load { { i64, ptr }, i32 }, ptr %l375
  store { { i64, ptr }, i32 } %t776, ptr %l45
  %t777 = getelementptr { { i64, ptr }, i32 }, ptr %l45, i32 0, i32 0
  %t778 = load { i64, ptr }, ptr %t777, !tbaa !27
  store { i64, ptr } %t778, ptr %l46, !tbaa !27
  store ptr %l20, ptr %l377, !tbaa !29
  %t780 = call ptr @__olang_scope_hold(ptr %s0)
  %t781 = ptrtoint ptr %t780 to i64
  store i64 %t781, ptr %l378, !tbaa !24
  %t782 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t782, label %bb149, label %bb150
bb149:
  %t784 = call ptr @__olang_region_make(ptr %s0)
  %t785 = ptrtoint ptr %t784 to i64
  store i64 %t785, ptr %l378, !tbaa !24
  br label %bb150
bb150:
  %t786 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t788 = extractvalue { i64, ptr } %t786, 1
  %t789 = extractvalue { i64, ptr } %t786, 0
  %t790 = load i64, ptr %l378
  %t791 = inttoptr i64 %t790 to ptr
  %t792 = call ptr @__olang_held_alloc(ptr %t791, i64 %t789)
  call void @olang_textcopy(ptr %t792, ptr %t788, i64 %t789)
  %t793 = insertvalue { i64, ptr } undef, i64 %t789, 0
  %t794 = insertvalue { i64, ptr } %t793, ptr %t792, 1
  %t796 = load ptr, ptr %l377, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t796, { i64, ptr } %t794)
  br label %bb151
bb151:
  call void @__olang_scope_close(ptr %s25)
  br label %bb152
bb152:
  %t798 = load i32, ptr %l43, !tbaa !23
  %t801 = add i32 %t798, 1
  store i32 %t801, ptr %l43, !tbaa !23
  br label %bb142
bb153:
  store i32 0, ptr %l47, !tbaa !23
  %t803 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 4
  %t804 = getelementptr %"compiler/mir:Range", ptr %t803, i32 0, i32 1
  %t805 = load i32, ptr %t804, !tbaa !23
  store i32 %t805, ptr %l48, !tbaa !23
  store i32 1, ptr %l49, !tbaa !23
  %t807 = load i32, ptr %l48, !tbaa !23
  %t808 = load i32, ptr %l47, !tbaa !23
  %t811 = icmp sgt i32 %t807, %t808
  br i1 %t811, label %bb154, label %bb155
bb154:
  %t813 = load i32, ptr %l49, !tbaa !23
  %t815 = icmp sgt i32 %t813, 0
  br i1 %t815, label %bb156, label %bb157
bb155:
  store i32 0, ptr %l390, !tbaa !23
  br label %bb159
bb156:
  %t817 = load i32, ptr %l48, !tbaa !23
  %t818 = load i32, ptr %l47, !tbaa !23
  %t821 = sub i32 %t817, %t818
  %t822 = load i32, ptr %l49, !tbaa !23
  %t825 = add i32 %t821, %t822
  %t827 = sub i32 %t825, 1
  %t828 = load i32, ptr %l49, !tbaa !23
  %t831 = sdiv i32 %t827, %t828
  store i32 %t831, ptr %l393, !tbaa !23
  br label %bb158
bb157:
  store i32 0, ptr %l393, !tbaa !23
  br label %bb158
bb158:
  %t833 = load i32, ptr %l393, !tbaa !23
  store i32 %t833, ptr %l390, !tbaa !23
  br label %bb159
bb159:
  %t834 = load i32, ptr %l390, !tbaa !23
  store i32 %t834, ptr %l50, !tbaa !23
  store i32 0, ptr %l51, !tbaa !23
  br label %bb160
bb160:
  %t835 = load i32, ptr %l51, !tbaa !23
  %t836 = load i32, ptr %l50, !tbaa !23
  %t839 = icmp slt i32 %t835, %t836
  %t841 = xor i1 %t839, true
  br i1 %t841, label %bb161, label %bb162
bb161:
  br label %bb175
bb162:
  br label %bb163
bb163:
  %t843 = load i32, ptr %l47, !tbaa !23
  %t844 = load i32, ptr %l51, !tbaa !23
  %t845 = load i32, ptr %l49, !tbaa !23
  %t848 = mul i32 %t844, %t845
  %t851 = add i32 %t843, %t848
  %t853 = load ptr, ptr %l0, !tbaa !29
  %t855 = getelementptr %"compiler/emit:fnEm", ptr %t853, i32 0, i32 1
  %t856 = load ptr, ptr %t855, !tbaa !29
  %t858 = getelementptr %"compiler/mir:Fn", ptr %t856, i32 0, i32 17
  store ptr %t858, ptr %l413, !tbaa !29
  %t859 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 4
  %t860 = getelementptr %"compiler/mir:Range", ptr %t859, i32 0, i32 0
  %t861 = load i32, ptr %t860, !tbaa !23
  %t863 = sext i32 %t861 to i64
  %t866 = sext i32 %t851 to i64
  %t869 = add i64 %t863, %t866
  %t870 = load ptr, ptr %l413, !tbaa !29
  %t871 = call ptr @__olang_scope_or(ptr %v2, ptr %t870)
  %t872 = call ptr @__olang_scope_hold(ptr %t871)
  %t873 = ptrtoint ptr %t872 to i64
  %t875 = inttoptr i64 %t873 to ptr
  %t876 = load ptr, ptr %l413, !tbaa !29
  %t878 = call %"compiler/mir:TaskClause" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2eAt_3ccompiler_2fmir_3aTaskClause_3e(ptr %t875, ptr %t876, i64 %t869)
  store %"compiler/mir:TaskClause" %t878, ptr %l420
  br label %bb164
bb164:
  %t879 = getelementptr %"compiler/mir:TaskClause", ptr %l420, i32 0, i32 2
  %t880 = load { i64, [4 x i64] }, ptr %t879
  store { i64, [4 x i64] } %t880, ptr %l53
  %t882 = load { i64, [4 x i64] }, ptr %l53
  %t884 = extractvalue { i64, [4 x i64] } %t882, 0
  %t885 = icmp eq i64 %t884, 0
  %t887 = xor i1 %t885, true
  br i1 %t887, label %bb165, label %bb166
bb165:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l19, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d288, i32 0, i32 1) })
  br label %bb167
bb166:
  br label %bb173
bb167:
  store ptr %l20, ptr %l426, !tbaa !29
  %t890 = call ptr @__olang_scope_hold(ptr %s0)
  %t891 = ptrtoint ptr %t890 to i64
  store i64 %t891, ptr %l427, !tbaa !24
  %t892 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t892, label %bb168, label %bb169
bb168:
  %t894 = call ptr @__olang_region_make(ptr %s0)
  %t895 = ptrtoint ptr %t894 to i64
  store i64 %t895, ptr %l427, !tbaa !24
  br label %bb169
bb169:
  %t896 = load ptr, ptr %l0, !tbaa !29
  store ptr %t896, ptr %l429, !tbaa !29
  %t897 = load { i64, [4 x i64] }, ptr %l53
  store { i64, [4 x i64] } %t897, ptr %l430
  %t898 = load ptr, ptr %l0, !tbaa !29
  %t899 = load { i64, [4 x i64] }, ptr %l53
  %t902 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %v2, ptr %v1, ptr %t898, { i64, [4 x i64] } %t899)
  store i32 %t902, ptr %l433
  br label %bb170
bb170:
  %t903 = load i64, ptr %l427
  %t904 = inttoptr i64 %t903 to ptr
  %t905 = load ptr, ptr %l429, !tbaa !29
  %t906 = load { i64, [4 x i64] }, ptr %l430
  %t907 = load i32, ptr %l433, !tbaa !23
  %t908 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %t904, ptr %v2, ptr %v1, ptr %t905, { i64, [4 x i64] } %t906, i32 %t907)
  store { i64, ptr } %t908, ptr %l434
  br label %bb171
bb171:
  %t909 = load { i64, ptr }, ptr %l434, !tbaa !27
  %t910 = load i64, ptr %l427
  %t911 = inttoptr i64 %t910 to ptr
  %t912 = extractvalue { i64, ptr } %t909, 0
  %t913 = extractvalue { i64, ptr } %t909, 1
  %t914 = mul i64 %t912, 1
  %t915 = call ptr @__olang_held_alloc(ptr %t911, i64 %t914)
  call void @llvm.memcpy.p0.p0.i64(ptr %t915, ptr %t913, i64 %t914, i1 false)
  %t916 = insertvalue { i64, ptr } undef, i64 %t912, 0
  %t917 = insertvalue { i64, ptr } %t916, ptr %t915, 1
  %t918 = load ptr, ptr %l426, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t918, { i64, ptr } %t917)
  br label %bb172
bb172:
  br label %bb173
bb173:
  br label %bb174
bb174:
  %t920 = load i32, ptr %l51, !tbaa !23
  %t923 = add i32 %t920, 1
  store i32 %t923, ptr %l51, !tbaa !23
  br label %bb160
bb175:
  %t925 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 3
  %t926 = getelementptr %"compiler/mir:Range", ptr %t925, i32 0, i32 1
  %t927 = load i32, ptr %t926, !tbaa !23
  %t929 = sext i32 %t927 to i64
  store i64 %t929, ptr %l440, !tbaa !24
  %t930 = load i64, ptr %l440, !tbaa !24
  %t931 = icmp sge i64 %t930, 0
  br i1 %t931, label %bb176, label %bb177
bb176:
  %t933 = load i64, ptr %l440, !tbaa !24
  %t934 = icmp sle i64 %t933, 1152921504606846975
  br i1 %t934, label %bb178, label %bb179
bb177:
  call void @__olang_check_failed(ptr @olang_loc_9287686e475a7dbe_ea834ed677e35522)
  unreachable
bb178:
  %t936 = load i64, ptr %l440, !tbaa !24
  %t937 = mul i64 %t936, 8
  %t938 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t937)
  store i64 0, ptr %t939
  br label %fill.940
fill.940:
  %t943 = load i64, ptr %t939
  %t944 = icmp slt i64 %t943, %t936
  br i1 %t944, label %fillb.941, label %filld.942
fillb.941:
  %t945 = getelementptr i64, ptr %t938, i64 %t943
  store i64 -1, ptr %t945
  %t946 = add i64 %t943, 1
  store i64 %t946, ptr %t939
  br label %fill.940
filld.942:
  %t947 = insertvalue { i64, ptr } undef, i64 %t936, 0
  %t948 = insertvalue { i64, ptr } %t947, ptr %t938, 1
  store { i64, ptr } %t948, ptr %l54, !tbaa !27
  store i32 0, ptr %l55, !tbaa !23
  %t950 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 7
  %t951 = getelementptr %"compiler/mir:Range", ptr %t950, i32 0, i32 1
  %t952 = load i32, ptr %t951, !tbaa !23
  store i32 %t952, ptr %l56, !tbaa !23
  store i32 1, ptr %l57, !tbaa !23
  %t954 = load i32, ptr %l56, !tbaa !23
  %t955 = load i32, ptr %l55, !tbaa !23
  %t958 = icmp sgt i32 %t954, %t955
  br i1 %t958, label %bb180, label %bb181
bb179:
  call void @__olang_check_failed(ptr @olang_loc_9287686e475a7dbe_ea834ed677e35522)
  unreachable
bb180:
  %t960 = load i32, ptr %l57, !tbaa !23
  %t962 = icmp sgt i32 %t960, 0
  br i1 %t962, label %bb182, label %bb183
bb181:
  store i32 0, ptr %l448, !tbaa !23
  br label %bb185
bb182:
  %t964 = load i32, ptr %l56, !tbaa !23
  %t965 = load i32, ptr %l55, !tbaa !23
  %t968 = sub i32 %t964, %t965
  %t969 = load i32, ptr %l57, !tbaa !23
  %t972 = add i32 %t968, %t969
  %t974 = sub i32 %t972, 1
  %t975 = load i32, ptr %l57, !tbaa !23
  %t978 = sdiv i32 %t974, %t975
  store i32 %t978, ptr %l451, !tbaa !23
  br label %bb184
bb183:
  store i32 0, ptr %l451, !tbaa !23
  br label %bb184
bb184:
  %t980 = load i32, ptr %l451, !tbaa !23
  store i32 %t980, ptr %l448, !tbaa !23
  br label %bb185
bb185:
  %t981 = load i32, ptr %l448, !tbaa !23
  store i32 %t981, ptr %l58, !tbaa !23
  store i32 0, ptr %l59, !tbaa !23
  br label %bb186
bb186:
  %t982 = load i32, ptr %l59, !tbaa !23
  %t983 = load i32, ptr %l58, !tbaa !23
  %t986 = icmp slt i32 %t982, %t983
  %t988 = xor i1 %t986, true
  br i1 %t988, label %bb187, label %bb188
bb187:
  br label %bb219
bb188:
  br label %bb189
bb189:
  %t990 = load i32, ptr %l55, !tbaa !23
  %t991 = load i32, ptr %l59, !tbaa !23
  %t992 = load i32, ptr %l57, !tbaa !23
  %t995 = mul i32 %t991, %t992
  %t998 = add i32 %t990, %t995
  store i32 %t998, ptr %l60, !tbaa !23
  %t1000 = load ptr, ptr %l0, !tbaa !29
  %t1002 = getelementptr %"compiler/emit:fnEm", ptr %t1000, i32 0, i32 1
  %t1003 = load ptr, ptr %t1002, !tbaa !29
  %t1005 = getelementptr %"compiler/mir:Fn", ptr %t1003, i32 0, i32 12
  store ptr %t1005, ptr %l471, !tbaa !29
  %t1006 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 7
  %t1007 = getelementptr %"compiler/mir:Range", ptr %t1006, i32 0, i32 0
  %t1008 = load i32, ptr %t1007, !tbaa !23
  %t1010 = sext i32 %t1008 to i64
  %t1011 = load i32, ptr %l60, !tbaa !23
  %t1013 = sext i32 %t1011 to i64
  %t1016 = add i64 %t1010, %t1013
  %t1017 = load ptr, ptr %l471, !tbaa !29
  %t1018 = call ptr @__olang_scope_or(ptr %v2, ptr %t1017)
  %t1019 = call ptr @__olang_scope_hold(ptr %t1018)
  %t1020 = ptrtoint ptr %t1019 to i64
  %t1022 = inttoptr i64 %t1020 to ptr
  %t1023 = load ptr, ptr %l471, !tbaa !29
  %t1025 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %t1022, ptr %t1023, i64 %t1016)
  store { i64, [1 x i64] } %t1025, ptr %l478
  br label %bb190
bb190:
  %t1026 = load { i64, [1 x i64] }, ptr %l478
  store { i64, [1 x i64] } %t1026, ptr %l61
  %t1027 = load { i64, [1 x i64] }, ptr %l61
  %t1029 = extractvalue { i64, [1 x i64] } %t1027, 0
  %t1030 = icmp eq i64 %t1029, 3
  br i1 %t1030, label %bb191, label %bb192
bb191:
  br label %bb193
bb192:
  br label %bb194
bb193:
  br label %bb217
bb194:
  %t1032 = load { i64, [1 x i64] }, ptr %l61
  %t1034 = extractvalue { i64, [1 x i64] } %t1032, 0
  %t1035 = icmp eq i64 %t1034, 2
  br i1 %t1035, label %bb195, label %bb196
bb195:
  br label %bb197
bb196:
  br label %bb201
bb197:
  %t1037 = load i32, ptr %l60, !tbaa !23
  store i32 %t1037, ptr %l483, !tbaa !23
  %t1039 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l19)
  store i64 %t1039, ptr %l485
  br label %bb198
bb198:
  %t1040 = load i64, ptr %l485, !tbaa !24
  %t1041 = load i32, ptr %l483, !tbaa !23
  %t1042 = sext i32 %t1041 to i64
  %t1043 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t1044 = load ptr, ptr %t1043, !tbaa !27
  %t1045 = getelementptr i64, ptr %t1044, i64 %t1042
  store i64 %t1040, ptr %t1045, !tbaa !34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l19, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d289, i32 0, i32 1) })
  br label %bb199
bb199:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l20, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d290, i32 0, i32 1) })
  br label %bb200
bb200:
  br label %bb217
bb201:
  br i1 true, label %bb202, label %bb203
bb202:
  br label %bb204
bb203:
  br label %bb216
bb204:
  store %olang.scope zeroinitializer, ptr %s36
  %t1048 = load ptr, ptr %l4, !tbaa !29
  store ptr %t1048, ptr %l488, !tbaa !29
  %t1049 = load ptr, ptr %l488, !tbaa !29
  %t1050 = call ptr @__olang_scope_or(ptr %v1, ptr %t1049)
  %t1051 = call ptr @__olang_scope_hold(ptr %t1050)
  %t1052 = ptrtoint ptr %t1051 to i64
  %t1054 = inttoptr i64 %t1052 to ptr
  %t1055 = load ptr, ptr %l488, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %t1054, ptr %s36, ptr %t1055, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d291, i32 0, i32 1) })
  br label %bb205
bb205:
  %t1056 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1056, ptr %l490, !tbaa !29
  %t1057 = load ptr, ptr %l0, !tbaa !29
  %t1058 = load { i64, [1 x i64] }, ptr %l61
  %t1061 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %s36, ptr %v1, ptr %v2, ptr %t1057, { i64, [1 x i64] } %t1058)
  store { i64, ptr } %t1061, ptr %l493
  br label %bb206
bb206:
  %t1062 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t1063 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d292, i32 0, i32 1) }, 1
  %t1064 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d292, i32 0, i32 1) }, 0
  %t1065 = load { i64, ptr }, ptr %l493, !tbaa !27
  %t1066 = extractvalue { i64, ptr } %t1065, 1
  %t1067 = extractvalue { i64, ptr } %t1065, 0
  %t1068 = add i64 %t1064, %t1067
  %t1069 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d293, i32 0, i32 1) }, 1
  %t1070 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d293, i32 0, i32 1) }, 0
  %t1071 = add i64 %t1068, %t1070
  %t1073 = extractvalue { i64, ptr } %t1062, 1
  %t1074 = extractvalue { i64, ptr } %t1062, 0
  %t1075 = add i64 %t1071, %t1074
  %t1076 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d294, i32 0, i32 1) }, 1
  %t1077 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d294, i32 0, i32 1) }, 0
  %t1078 = add i64 %t1075, %t1077
  %t1079 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t1078)
  call void @olang_textcopy(ptr %t1079, ptr %t1063, i64 %t1064)
  %t1080 = getelementptr i8, ptr %t1079, i64 %t1064
  call void @olang_textcopy(ptr %t1080, ptr %t1066, i64 %t1067)
  %t1081 = getelementptr i8, ptr %t1080, i64 %t1067
  call void @olang_textcopy(ptr %t1081, ptr %t1069, i64 %t1070)
  %t1082 = getelementptr i8, ptr %t1081, i64 %t1070
  call void @olang_textcopy(ptr %t1082, ptr %t1073, i64 %t1074)
  %t1083 = getelementptr i8, ptr %t1082, i64 %t1074
  call void @olang_textcopy(ptr %t1083, ptr %t1076, i64 %t1077)
  %t1084 = insertvalue { i64, ptr } undef, i64 %t1078, 0
  %t1085 = insertvalue { i64, ptr } %t1084, ptr %t1079, 1
  %t1087 = load ptr, ptr %l490, !tbaa !29
  %t1089 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s36, ptr %s36, ptr %v1, ptr %t1087, { i64, ptr } %t1085)
  store { i64, ptr } %t1089, ptr %l497
  br label %bb207
bb207:
  %t1090 = load { i64, ptr }, ptr %l497, !tbaa !27
  store { i64, ptr } %t1090, ptr %l62, !tbaa !27
  store ptr %l27, ptr %l498, !tbaa !29
  %t1091 = call ptr @__olang_scope_hold(ptr %s0)
  %t1092 = ptrtoint ptr %t1091 to i64
  store i64 %t1092, ptr %l499, !tbaa !24
  %t1093 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t1093, label %bb208, label %bb209
bb208:
  %t1095 = call ptr @__olang_region_make(ptr %s0)
  %t1096 = ptrtoint ptr %t1095 to i64
  store i64 %t1096, ptr %l499, !tbaa !24
  br label %bb209
bb209:
  %t1097 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t1099 = extractvalue { i64, ptr } %t1097, 1
  %t1100 = extractvalue { i64, ptr } %t1097, 0
  %t1101 = load i64, ptr %l499
  %t1102 = inttoptr i64 %t1101 to ptr
  %t1103 = call ptr @__olang_held_alloc(ptr %t1102, i64 %t1100)
  call void @olang_textcopy(ptr %t1103, ptr %t1099, i64 %t1100)
  %t1104 = insertvalue { i64, ptr } undef, i64 %t1100, 0
  %t1105 = insertvalue { i64, ptr } %t1104, ptr %t1103, 1
  %t1107 = load ptr, ptr %l498, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t1107, { i64, ptr } %t1105)
  br label %bb210
bb210:
  %t1109 = load i32, ptr %l60, !tbaa !23
  store i32 %t1109, ptr %l504, !tbaa !23
  %t1111 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l19)
  store i64 %t1111, ptr %l506
  br label %bb211
bb211:
  %t1112 = load i64, ptr %l506, !tbaa !24
  %t1113 = load i32, ptr %l504, !tbaa !23
  %t1114 = sext i32 %t1113 to i64
  %t1115 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t1116 = load ptr, ptr %t1115, !tbaa !27
  %t1117 = getelementptr i64, ptr %t1116, i64 %t1114
  store i64 %t1112, ptr %t1117, !tbaa !34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l19, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d295, i32 0, i32 1) })
  br label %bb212
bb212:
  store ptr %l20, ptr %l508, !tbaa !29
  %t1119 = call ptr @__olang_scope_hold(ptr %s0)
  %t1120 = ptrtoint ptr %t1119 to i64
  store i64 %t1120, ptr %l509, !tbaa !24
  %t1121 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t1121, label %bb213, label %bb214
bb213:
  %t1123 = call ptr @__olang_region_make(ptr %s0)
  %t1124 = ptrtoint ptr %t1123 to i64
  store i64 %t1124, ptr %l509, !tbaa !24
  br label %bb214
bb214:
  %t1125 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t1127 = extractvalue { i64, ptr } %t1125, 1
  %t1128 = extractvalue { i64, ptr } %t1125, 0
  %t1129 = load i64, ptr %l509
  %t1130 = inttoptr i64 %t1129 to ptr
  %t1131 = call ptr @__olang_held_alloc(ptr %t1130, i64 %t1128)
  call void @olang_textcopy(ptr %t1131, ptr %t1127, i64 %t1128)
  %t1132 = insertvalue { i64, ptr } undef, i64 %t1128, 0
  %t1133 = insertvalue { i64, ptr } %t1132, ptr %t1131, 1
  %t1135 = load ptr, ptr %l508, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t1135, { i64, ptr } %t1133)
  br label %bb215
bb215:
  call void @__olang_scope_close(ptr %s36)
  br label %bb217
bb216:
  call void @__olang_check_failed(ptr @olang_loc_45f21d64bb841654_8b47099e9550bca0)
  unreachable
bb217:
  br label %bb218
bb218:
  %t1137 = load i32, ptr %l59, !tbaa !23
  %t1140 = add i32 %t1137, 1
  store i32 %t1140, ptr %l59, !tbaa !23
  br label %bb186
bb219:
  store i64 -1, ptr %l63, !tbaa !24
  %t1142 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 10
  %t1143 = getelementptr %"compiler/mir:Range", ptr %t1142, i32 0, i32 1
  %t1144 = load i32, ptr %t1143, !tbaa !23
  %t1146 = icmp sgt i32 %t1144, 0
  br i1 %t1146, label %bb220, label %bb221
bb220:
  store %olang.scope zeroinitializer, ptr %s41
  %t1148 = load ptr, ptr %l4, !tbaa !29
  store ptr %t1148, ptr %l519, !tbaa !29
  %t1149 = load ptr, ptr %l519, !tbaa !29
  %t1150 = call ptr @__olang_scope_or(ptr %v1, ptr %t1149)
  %t1151 = call ptr @__olang_scope_hold(ptr %t1150)
  %t1152 = ptrtoint ptr %t1151 to i64
  %t1154 = inttoptr i64 %t1152 to ptr
  %t1155 = load ptr, ptr %l519, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %t1154, ptr %s41, ptr %t1155, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d296, i32 0, i32 1) })
  br label %bb222
bb221:
  br label %bb234
bb222:
  %t1156 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1156, ptr %l521, !tbaa !29
  %t1157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1157, ptr %l522, !tbaa !29
  %t1158 = load ptr, ptr %l0, !tbaa !29
  %t1160 = getelementptr %"compiler/emit:fnEm", ptr %t1158, i32 0, i32 1
  %t1161 = load ptr, ptr %t1160, !tbaa !29
  %t1163 = getelementptr %"compiler/mir:Fn", ptr %t1161, i32 0, i32 12
  store ptr %t1163, ptr %l525, !tbaa !29
  %t1164 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 10
  %t1165 = getelementptr %"compiler/mir:Range", ptr %t1164, i32 0, i32 0
  %t1166 = load i32, ptr %t1165, !tbaa !23
  %t1168 = sext i32 %t1166 to i64
  %t1169 = load ptr, ptr %l525, !tbaa !29
  %t1170 = call ptr @__olang_scope_or(ptr %v2, ptr %t1169)
  %t1171 = call ptr @__olang_scope_hold(ptr %t1170)
  %t1172 = ptrtoint ptr %t1171 to i64
  %t1174 = inttoptr i64 %t1172 to ptr
  %t1175 = load ptr, ptr %l525, !tbaa !29
  %t1177 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %t1174, ptr %t1175, i64 %t1168)
  store { i64, [1 x i64] } %t1177, ptr %l529
  br label %bb223
bb223:
  %t1178 = load ptr, ptr %l522, !tbaa !29
  %t1179 = load { i64, [1 x i64] }, ptr %l529
  %t1180 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %s41, ptr %v1, ptr %v2, ptr %t1178, { i64, [1 x i64] } %t1179)
  store { i64, ptr } %t1180, ptr %l530
  br label %bb224
bb224:
  %t1181 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t1182 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d297, i32 0, i32 1) }, 1
  %t1183 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d297, i32 0, i32 1) }, 0
  %t1184 = load { i64, ptr }, ptr %l530, !tbaa !27
  %t1185 = extractvalue { i64, ptr } %t1184, 1
  %t1186 = extractvalue { i64, ptr } %t1184, 0
  %t1187 = add i64 %t1183, %t1186
  %t1188 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d298, i32 0, i32 1) }, 1
  %t1189 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d298, i32 0, i32 1) }, 0
  %t1190 = add i64 %t1187, %t1189
  %t1192 = extractvalue { i64, ptr } %t1181, 1
  %t1193 = extractvalue { i64, ptr } %t1181, 0
  %t1194 = add i64 %t1190, %t1193
  %t1195 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d299, i32 0, i32 1) }, 1
  %t1196 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d299, i32 0, i32 1) }, 0
  %t1197 = add i64 %t1194, %t1196
  %t1198 = call ptr @__olang_scope_alloc(ptr %s41, i64 %t1197)
  call void @olang_textcopy(ptr %t1198, ptr %t1182, i64 %t1183)
  %t1199 = getelementptr i8, ptr %t1198, i64 %t1183
  call void @olang_textcopy(ptr %t1199, ptr %t1185, i64 %t1186)
  %t1200 = getelementptr i8, ptr %t1199, i64 %t1186
  call void @olang_textcopy(ptr %t1200, ptr %t1188, i64 %t1189)
  %t1201 = getelementptr i8, ptr %t1200, i64 %t1189
  call void @olang_textcopy(ptr %t1201, ptr %t1192, i64 %t1193)
  %t1202 = getelementptr i8, ptr %t1201, i64 %t1193
  call void @olang_textcopy(ptr %t1202, ptr %t1195, i64 %t1196)
  %t1203 = insertvalue { i64, ptr } undef, i64 %t1197, 0
  %t1204 = insertvalue { i64, ptr } %t1203, ptr %t1198, 1
  %t1206 = load ptr, ptr %l521, !tbaa !29
  %t1208 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s41, ptr %s41, ptr %v1, ptr %t1206, { i64, ptr } %t1204)
  store { i64, ptr } %t1208, ptr %l534
  br label %bb225
bb225:
  %t1209 = load { i64, ptr }, ptr %l534, !tbaa !27
  store { i64, ptr } %t1209, ptr %l64, !tbaa !27
  store ptr %l27, ptr %l535, !tbaa !29
  %t1210 = call ptr @__olang_scope_hold(ptr %s0)
  %t1211 = ptrtoint ptr %t1210 to i64
  store i64 %t1211, ptr %l536, !tbaa !24
  %t1212 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t1212, label %bb226, label %bb227
bb226:
  %t1214 = call ptr @__olang_region_make(ptr %s0)
  %t1215 = ptrtoint ptr %t1214 to i64
  store i64 %t1215, ptr %l536, !tbaa !24
  br label %bb227
bb227:
  %t1216 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t1218 = extractvalue { i64, ptr } %t1216, 1
  %t1219 = extractvalue { i64, ptr } %t1216, 0
  %t1220 = load i64, ptr %l536
  %t1221 = inttoptr i64 %t1220 to ptr
  %t1222 = call ptr @__olang_held_alloc(ptr %t1221, i64 %t1219)
  call void @olang_textcopy(ptr %t1222, ptr %t1218, i64 %t1219)
  %t1223 = insertvalue { i64, ptr } undef, i64 %t1219, 0
  %t1224 = insertvalue { i64, ptr } %t1223, ptr %t1222, 1
  %t1226 = load ptr, ptr %l535, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t1226, { i64, ptr } %t1224)
  br label %bb228
bb228:
  %t1229 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l19)
  store i64 %t1229, ptr %l542
  br label %bb229
bb229:
  %t1230 = load i64, ptr %l542, !tbaa !24
  store i64 %t1230, ptr %l63, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l19, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d300, i32 0, i32 1) })
  br label %bb230
bb230:
  store ptr %l20, ptr %l544, !tbaa !29
  %t1232 = call ptr @__olang_scope_hold(ptr %s0)
  %t1233 = ptrtoint ptr %t1232 to i64
  store i64 %t1233, ptr %l545, !tbaa !24
  %t1234 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t1234, label %bb231, label %bb232
bb231:
  %t1236 = call ptr @__olang_region_make(ptr %s0)
  %t1237 = ptrtoint ptr %t1236 to i64
  store i64 %t1237, ptr %l545, !tbaa !24
  br label %bb232
bb232:
  %t1238 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t1240 = extractvalue { i64, ptr } %t1238, 1
  %t1241 = extractvalue { i64, ptr } %t1238, 0
  %t1242 = load i64, ptr %l545
  %t1243 = inttoptr i64 %t1242 to ptr
  %t1244 = call ptr @__olang_held_alloc(ptr %t1243, i64 %t1241)
  call void @olang_textcopy(ptr %t1244, ptr %t1240, i64 %t1241)
  %t1245 = insertvalue { i64, ptr } undef, i64 %t1241, 0
  %t1246 = insertvalue { i64, ptr } %t1245, ptr %t1244, 1
  %t1248 = load ptr, ptr %l544, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t1248, { i64, ptr } %t1246)
  br label %bb233
bb233:
  call void @__olang_scope_close(ptr %s41)
  br label %bb234
bb234:
  %t1250 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1250, ptr %l550
  br label %bb235
bb235:
  %t1251 = load %"std/prelude/text:StringBuilder", ptr %l550
  store %"std/prelude/text:StringBuilder" %t1251, ptr %l65
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l65, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d301, i32 0, i32 1) })
  br label %bb236
bb236:
  store i64 0, ptr %l66, !tbaa !24
  %t1254 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l19)
  store i64 %t1254, ptr %l553
  br label %bb237
bb237:
  %t1255 = load i64, ptr %l553, !tbaa !24
  store i64 %t1255, ptr %l67, !tbaa !24
  store i64 1, ptr %l68, !tbaa !24
  %t1256 = load i64, ptr %l67, !tbaa !24
  %t1257 = load i64, ptr %l66, !tbaa !24
  %t1260 = icmp sgt i64 %t1256, %t1257
  br i1 %t1260, label %bb238, label %bb239
bb238:
  %t1262 = load i64, ptr %l68, !tbaa !24
  %t1264 = icmp sgt i64 %t1262, 0
  br i1 %t1264, label %bb240, label %bb241
bb239:
  store i64 0, ptr %l557, !tbaa !24
  br label %bb243
bb240:
  %t1266 = load i64, ptr %l67, !tbaa !24
  %t1267 = load i64, ptr %l66, !tbaa !24
  %t1270 = sub i64 %t1266, %t1267
  %t1271 = load i64, ptr %l68, !tbaa !24
  %t1274 = add i64 %t1270, %t1271
  %t1276 = sub i64 %t1274, 1
  %t1277 = load i64, ptr %l68, !tbaa !24
  %t1280 = sdiv i64 %t1276, %t1277
  store i64 %t1280, ptr %l560, !tbaa !24
  br label %bb242
bb241:
  store i64 0, ptr %l560, !tbaa !24
  br label %bb242
bb242:
  %t1282 = load i64, ptr %l560, !tbaa !24
  store i64 %t1282, ptr %l557, !tbaa !24
  br label %bb243
bb243:
  %t1283 = load i64, ptr %l557, !tbaa !24
  store i64 %t1283, ptr %l69, !tbaa !24
  store i64 0, ptr %l70, !tbaa !24
  br label %bb244
bb244:
  %t1284 = load i64, ptr %l70, !tbaa !24
  %t1285 = load i64, ptr %l69, !tbaa !24
  %t1288 = icmp slt i64 %t1284, %t1285
  %t1290 = xor i1 %t1288, true
  br i1 %t1290, label %bb245, label %bb246
bb245:
  br label %bb255
bb246:
  br label %bb247
bb247:
  %t1292 = load i64, ptr %l66, !tbaa !24
  %t1293 = load i64, ptr %l70, !tbaa !24
  %t1294 = load i64, ptr %l68, !tbaa !24
  %t1297 = mul i64 %t1293, %t1294
  %t1300 = add i64 %t1292, %t1297
  store i64 %t1300, ptr %l71, !tbaa !24
  %t1302 = load i64, ptr %l71, !tbaa !24
  %t1304 = icmp sgt i64 %t1302, 0
  br i1 %t1304, label %bb248, label %bb249
bb248:
  store %olang.scope zeroinitializer, ptr %s47
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s47, ptr %l65, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d302, i32 0, i32 1) })
  br label %bb250
bb249:
  br label %bb251
bb250:
  call void @__olang_scope_close(ptr %s47)
  br label %bb251
bb251:
  store ptr %l65, ptr %l581, !tbaa !29
  %t1307 = load i64, ptr %l71, !tbaa !24
  %t1310 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l19, i64 %t1307)
  store { i64, ptr } %t1310, ptr %l584
  br label %bb252
bb252:
  %t1311 = load ptr, ptr %l581, !tbaa !29
  %t1312 = load { i64, ptr }, ptr %l584, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t1311, { i64, ptr } %t1312)
  br label %bb253
bb253:
  br label %bb254
bb254:
  %t1313 = load i64, ptr %l70, !tbaa !24
  %t1316 = add i64 %t1313, 1
  store i64 %t1316, ptr %l70, !tbaa !24
  br label %bb244
bb255:
  %t1319 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l19)
  store i64 %t1319, ptr %l589
  br label %bb256
bb256:
  %t1320 = load i64, ptr %l589, !tbaa !24
  %t1321 = icmp eq i64 %t1320, 0
  br i1 %t1321, label %bb257, label %bb258
bb257:
  store %olang.scope zeroinitializer, ptr %s49
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s49, ptr %l65, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d303, i32 0, i32 1) })
  br label %bb259
bb258:
  br label %bb260
bb259:
  call void @__olang_scope_close(ptr %s49)
  br label %bb260
bb260:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l65, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d304, i32 0, i32 1) })
  br label %bb261
bb261:
  %t1326 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l65)
  store { i64, ptr } %t1326, ptr %l594
  br label %bb262
bb262:
  %t1327 = load { i64, ptr }, ptr %l594, !tbaa !27
  store { i64, ptr } %t1327, ptr %l72, !tbaa !27
  %t1328 = load ptr, ptr %l4, !tbaa !29
  store ptr %t1328, ptr %l595, !tbaa !29
  %t1329 = load ptr, ptr %l595, !tbaa !29
  %t1330 = call ptr @__olang_scope_or(ptr %v1, ptr %t1329)
  %t1331 = call ptr @__olang_scope_hold(ptr %t1330)
  %t1332 = ptrtoint ptr %t1331 to i64
  %t1334 = inttoptr i64 %t1332 to ptr
  %t1335 = load ptr, ptr %l595, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %t1334, ptr %s0, ptr %t1335, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d305, i32 0, i32 1) })
  br label %bb263
bb263:
  %t1336 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1336, ptr %l597, !tbaa !29
  %t1337 = load ptr, ptr %l0, !tbaa !29
  %t1338 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t1339 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d306, i32 0, i32 1) }, 1
  %t1340 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d306, i32 0, i32 1) }, 0
  %t1342 = extractvalue { i64, ptr } %t1338, 1
  %t1343 = extractvalue { i64, ptr } %t1338, 0
  %t1344 = add i64 %t1340, %t1343
  %t1345 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d307, i32 0, i32 1) }, 1
  %t1346 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d307, i32 0, i32 1) }, 0
  %t1347 = add i64 %t1344, %t1346
  %t1348 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1347)
  call void @olang_textcopy(ptr %t1348, ptr %t1339, i64 %t1340)
  %t1349 = getelementptr i8, ptr %t1348, i64 %t1340
  call void @olang_textcopy(ptr %t1349, ptr %t1342, i64 %t1343)
  %t1350 = getelementptr i8, ptr %t1349, i64 %t1343
  call void @olang_textcopy(ptr %t1350, ptr %t1345, i64 %t1346)
  %t1351 = insertvalue { i64, ptr } undef, i64 %t1347, 0
  %t1352 = insertvalue { i64, ptr } %t1351, ptr %t1348, 1
  %t1356 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v1, ptr %t1337, { i64, ptr } %t1352)
  store { i64, ptr } %t1356, ptr %l602
  br label %bb264
bb264:
  %t1357 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d308, i32 0, i32 1) }, 1
  %t1358 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d308, i32 0, i32 1) }, 0
  %t1359 = load { i64, ptr }, ptr %l602, !tbaa !27
  %t1360 = extractvalue { i64, ptr } %t1359, 1
  %t1361 = extractvalue { i64, ptr } %t1359, 0
  %t1362 = add i64 %t1358, %t1361
  %t1363 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d309, i32 0, i32 1) }, 1
  %t1364 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d309, i32 0, i32 1) }, 0
  %t1365 = add i64 %t1362, %t1364
  %t1366 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1365)
  call void @olang_textcopy(ptr %t1366, ptr %t1357, i64 %t1358)
  %t1367 = getelementptr i8, ptr %t1366, i64 %t1358
  call void @olang_textcopy(ptr %t1367, ptr %t1360, i64 %t1361)
  %t1368 = getelementptr i8, ptr %t1367, i64 %t1361
  call void @olang_textcopy(ptr %t1368, ptr %t1363, i64 %t1364)
  %t1369 = insertvalue { i64, ptr } undef, i64 %t1365, 0
  %t1370 = insertvalue { i64, ptr } %t1369, ptr %t1366, 1
  %t1372 = load ptr, ptr %l597, !tbaa !29
  %t1374 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v1, ptr %t1372, { i64, ptr } %t1370)
  store { i64, ptr } %t1374, ptr %l605
  br label %bb265
bb265:
  %t1375 = load { i64, ptr }, ptr %l605, !tbaa !27
  %t1376 = load ptr, ptr %l0, !tbaa !29
  %t1377 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t1379 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d310, i32 0, i32 1) }, 1
  %t1380 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d310, i32 0, i32 1) }, 0
  %t1382 = extractvalue { i64, ptr } %t1377, 1
  %t1383 = extractvalue { i64, ptr } %t1377, 0
  %t1384 = add i64 %t1380, %t1383
  %t1385 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d311, i32 0, i32 1) }, 1
  %t1386 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d311, i32 0, i32 1) }, 0
  %t1387 = add i64 %t1384, %t1386
  %t1389 = extractvalue { i64, ptr } %t1375, 1
  %t1390 = extractvalue { i64, ptr } %t1375, 0
  %t1391 = add i64 %t1387, %t1390
  %t1392 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d312, i32 0, i32 1) }, 1
  %t1393 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d312, i32 0, i32 1) }, 0
  %t1394 = add i64 %t1391, %t1393
  %t1395 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1394)
  call void @olang_textcopy(ptr %t1395, ptr %t1379, i64 %t1380)
  %t1396 = getelementptr i8, ptr %t1395, i64 %t1380
  call void @olang_textcopy(ptr %t1396, ptr %t1382, i64 %t1383)
  %t1397 = getelementptr i8, ptr %t1396, i64 %t1383
  call void @olang_textcopy(ptr %t1397, ptr %t1385, i64 %t1386)
  %t1398 = getelementptr i8, ptr %t1397, i64 %t1386
  call void @olang_textcopy(ptr %t1398, ptr %t1389, i64 %t1390)
  %t1399 = getelementptr i8, ptr %t1398, i64 %t1390
  call void @olang_textcopy(ptr %t1399, ptr %t1392, i64 %t1393)
  %t1400 = insertvalue { i64, ptr } undef, i64 %t1394, 0
  %t1401 = insertvalue { i64, ptr } %t1400, ptr %t1395, 1
  %t1405 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v1, ptr %t1376, { i64, ptr } %t1401)
  store { i64, ptr } %t1405, ptr %l611
  br label %bb266
bb266:
  %t1406 = load { i64, ptr }, ptr %l611, !tbaa !27
  store { i64, ptr } %t1406, ptr %l74, !tbaa !27
  %t1407 = load i1, ptr %l8, !tbaa !21
  br i1 %t1407, label %bb267, label %bb268
bb267:
  store i64 1, ptr %l613, !tbaa !24
  br label %bb269
bb268:
  store i64 0, ptr %l613, !tbaa !24
  br label %bb269
bb269:
  %t1409 = load i64, ptr %l613, !tbaa !24
  store i64 %t1409, ptr %l75, !tbaa !24
  store i64 0, ptr %l76, !tbaa !24
  %t1411 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l19)
  store i64 %t1411, ptr %l615
  br label %bb270
bb270:
  %t1412 = load i64, ptr %l615, !tbaa !24
  store i64 %t1412, ptr %l77, !tbaa !24
  store i64 1, ptr %l78, !tbaa !24
  %t1413 = load i64, ptr %l77, !tbaa !24
  %t1414 = load i64, ptr %l76, !tbaa !24
  %t1417 = icmp sgt i64 %t1413, %t1414
  br i1 %t1417, label %bb271, label %bb272
bb271:
  %t1419 = load i64, ptr %l78, !tbaa !24
  %t1421 = icmp sgt i64 %t1419, 0
  br i1 %t1421, label %bb273, label %bb274
bb272:
  store i64 0, ptr %l619, !tbaa !24
  br label %bb276
bb273:
  %t1423 = load i64, ptr %l77, !tbaa !24
  %t1424 = load i64, ptr %l76, !tbaa !24
  %t1427 = sub i64 %t1423, %t1424
  %t1428 = load i64, ptr %l78, !tbaa !24
  %t1431 = add i64 %t1427, %t1428
  %t1433 = sub i64 %t1431, 1
  %t1434 = load i64, ptr %l78, !tbaa !24
  %t1437 = sdiv i64 %t1433, %t1434
  store i64 %t1437, ptr %l622, !tbaa !24
  br label %bb275
bb274:
  store i64 0, ptr %l622, !tbaa !24
  br label %bb275
bb275:
  %t1439 = load i64, ptr %l622, !tbaa !24
  store i64 %t1439, ptr %l619, !tbaa !24
  br label %bb276
bb276:
  %t1440 = load i64, ptr %l619, !tbaa !24
  store i64 %t1440, ptr %l79, !tbaa !24
  store i64 0, ptr %l80, !tbaa !24
  br label %bb277
bb277:
  store %olang.scope zeroinitializer, ptr %s54
  %t1441 = load i64, ptr %l80, !tbaa !24
  %t1442 = load i64, ptr %l79, !tbaa !24
  %t1445 = icmp slt i64 %t1441, %t1442
  %t1447 = xor i1 %t1445, true
  br i1 %t1447, label %bb278, label %bb279
bb278:
  call void @__olang_scope_close(ptr %s54)
  br label %bb293
bb279:
  br label %bb280
bb280:
  %t1449 = load i64, ptr %l76, !tbaa !24
  %t1450 = load i64, ptr %l80, !tbaa !24
  %t1451 = load i64, ptr %l78, !tbaa !24
  %t1454 = mul i64 %t1450, %t1451
  %t1457 = add i64 %t1449, %t1454
  store i64 %t1457, ptr %l81, !tbaa !24
  %t1459 = load ptr, ptr %l0, !tbaa !29
  %t1460 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t1461 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t1462 = load i64, ptr %l81, !tbaa !24
  %t1463 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d313, i32 0, i32 1) }, 1
  %t1464 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d313, i32 0, i32 1) }, 0
  %t1466 = extractvalue { i64, ptr } %t1460, 1
  %t1467 = extractvalue { i64, ptr } %t1460, 0
  %t1468 = add i64 %t1464, %t1467
  %t1469 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d314, i32 0, i32 1) }, 1
  %t1470 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d314, i32 0, i32 1) }, 0
  %t1471 = add i64 %t1468, %t1470
  %t1473 = extractvalue { i64, ptr } %t1461, 1
  %t1474 = extractvalue { i64, ptr } %t1461, 0
  %t1475 = add i64 %t1471, %t1474
  %t1476 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d315, i32 0, i32 1) }, 1
  %t1477 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d315, i32 0, i32 1) }, 0
  %t1478 = add i64 %t1475, %t1477
  %t1480 = call i64 @__olang_fmt_i64(ptr null, i64 %t1462)
  %t1481 = add i64 %t1478, %t1480
  %t1482 = call ptr @__olang_scope_alloc(ptr %s54, i64 %t1481)
  call void @olang_textcopy(ptr %t1482, ptr %t1463, i64 %t1464)
  %t1483 = getelementptr i8, ptr %t1482, i64 %t1464
  call void @olang_textcopy(ptr %t1483, ptr %t1466, i64 %t1467)
  %t1484 = getelementptr i8, ptr %t1483, i64 %t1467
  call void @olang_textcopy(ptr %t1484, ptr %t1469, i64 %t1470)
  %t1485 = getelementptr i8, ptr %t1484, i64 %t1470
  call void @olang_textcopy(ptr %t1485, ptr %t1473, i64 %t1474)
  %t1486 = getelementptr i8, ptr %t1485, i64 %t1474
  call void @olang_textcopy(ptr %t1486, ptr %t1476, i64 %t1477)
  %t1487 = getelementptr i8, ptr %t1486, i64 %t1477
  %t1488 = call i64 @__olang_fmt_i64(ptr %t1487, i64 %t1462)
  %t1489 = insertvalue { i64, ptr } undef, i64 %t1481, 0
  %t1490 = insertvalue { i64, ptr } %t1489, ptr %t1482, 1
  %t1494 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s54, ptr %s54, ptr %v1, ptr %t1459, { i64, ptr } %t1490)
  store { i64, ptr } %t1494, ptr %l646
  br label %bb281
bb281:
  %t1495 = load { i64, ptr }, ptr %l646, !tbaa !27
  store { i64, ptr } %t1495, ptr %l82, !tbaa !27
  %t1496 = load i64, ptr %l81, !tbaa !24
  %t1499 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l20, i64 %t1496)
  store { i64, ptr } %t1499, ptr %l649
  br label %bb282
bb282:
  %t1500 = load { i64, ptr }, ptr %l649, !tbaa !27
  %t1501 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s54, { i64, ptr } %t1500, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d316, i32 0, i32 1) })
  store i1 %t1501, ptr %l650
  br label %bb283
bb283:
  %t1502 = load i1, ptr %l650, !tbaa !21
  br i1 %t1502, label %bb284, label %bb285
bb284:
  store %olang.scope zeroinitializer, ptr %s56
  %t1503 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1503, ptr %l651, !tbaa !29
  %t1504 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t1504, ptr %l652, !tbaa !27
  %t1505 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t1505, ptr %l653, !tbaa !27
  %t1506 = load i64, ptr %l81, !tbaa !24
  %t1507 = load i64, ptr %l75, !tbaa !24
  %t1510 = sub i64 %t1506, %t1507
  %t1512 = getelementptr { i64, ptr }, ptr %l653, i32 0, i32 1
  %t1513 = load ptr, ptr %t1512, !tbaa !27
  %t1514 = getelementptr i32, ptr %t1513, i64 %t1510
  %t1515 = load i32, ptr %t1514, !tbaa !33
  store i32 %t1515, ptr %l657, !tbaa !23
  %t1516 = load ptr, ptr %l0, !tbaa !29
  %t1517 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 1
  %t1518 = load %"compiler/mir:Range", ptr %t1517
  %t1519 = load i64, ptr %l81, !tbaa !24
  %t1520 = load i64, ptr %l75, !tbaa !24
  %t1523 = sub i64 %t1519, %t1520
  %t1527 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %v2, ptr %t1516, %"compiler/mir:Range" %t1518, i64 %t1523)
  store { i64, [4 x i64] } %t1527, ptr %l663
  br label %bb286
bb285:
  store %olang.scope zeroinitializer, ptr %s57
  %t1528 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1528, ptr %l664, !tbaa !29
  %t1529 = load i64, ptr %l81, !tbaa !24
  %t1532 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l19, i64 %t1529)
  store { i64, ptr } %t1532, ptr %l667
  br label %bb288
bb286:
  %t1533 = load ptr, ptr %l651, !tbaa !29
  %t1534 = load { i64, ptr }, ptr %l652, !tbaa !27
  %t1535 = load i32, ptr %l657, !tbaa !23
  %t1536 = load { i64, [4 x i64] }, ptr %l663
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eput(ptr %v0, ptr %s54, ptr %s56, ptr %v1, ptr %v2, ptr %t1533, { i64, ptr } %t1534, i32 %t1535, { i64, [4 x i64] } %t1536, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d317, i32 0, i32 1) })
  br label %bb287
bb287:
  call void @__olang_scope_close(ptr %s56)
  br label %bb291
bb288:
  %t1537 = load i64, ptr %l81, !tbaa !24
  %t1540 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l20, i64 %t1537)
  store { i64, ptr } %t1540, ptr %l670
  br label %bb289
bb289:
  %t1541 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t1542 = load ptr, ptr %l664, !tbaa !29
  %t1543 = load { i64, ptr }, ptr %l667, !tbaa !27
  %t1544 = load { i64, ptr }, ptr %l670, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %s54, ptr %s57, ptr %v1, ptr %t1542, { i64, ptr } %t1543, { i64, ptr } %t1544, { i64, ptr } %t1541, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d43, i32 0, i32 1) })
  br label %bb290
bb290:
  call void @__olang_scope_close(ptr %s57)
  br label %bb291
bb291:
  call void @__olang_scope_close(ptr %s54)
  br label %bb292
bb292:
  %t1546 = load i64, ptr %l80, !tbaa !24
  %t1549 = add i64 %t1546, 1
  store i64 %t1549, ptr %l80, !tbaa !24
  br label %bb277
bb293:
  %t1551 = load ptr, ptr %l0, !tbaa !29
  %t1552 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t1553 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d318, i32 0, i32 1) }, 1
  %t1554 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d318, i32 0, i32 1) }, 0
  %t1556 = extractvalue { i64, ptr } %t1552, 1
  %t1557 = extractvalue { i64, ptr } %t1552, 0
  %t1558 = add i64 %t1554, %t1557
  %t1559 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d319, i32 0, i32 1) }, 1
  %t1560 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d319, i32 0, i32 1) }, 0
  %t1561 = add i64 %t1558, %t1560
  %t1562 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1561)
  call void @olang_textcopy(ptr %t1562, ptr %t1553, i64 %t1554)
  %t1563 = getelementptr i8, ptr %t1562, i64 %t1554
  call void @olang_textcopy(ptr %t1563, ptr %t1556, i64 %t1557)
  %t1564 = getelementptr i8, ptr %t1563, i64 %t1557
  call void @olang_textcopy(ptr %t1564, ptr %t1559, i64 %t1560)
  %t1565 = insertvalue { i64, ptr } undef, i64 %t1561, 0
  %t1566 = insertvalue { i64, ptr } %t1565, ptr %t1562, 1
  %t1570 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v1, ptr %t1551, { i64, ptr } %t1566)
  store { i64, ptr } %t1570, ptr %l679
  br label %bb294
bb294:
  %t1571 = load { i64, ptr }, ptr %l679, !tbaa !27
  store { i64, ptr } %t1571, ptr %l83, !tbaa !27
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d320, i32 0, i32 1) }, ptr %l680, !tbaa !27
  %t1572 = load { i64, ptr }, ptr %l680, !tbaa !27
  store { i64, ptr } %t1572, ptr %l84, !tbaa !27
  store ptr %l27, ptr %l85, !tbaa !29
  store i64 0, ptr %l86, !tbaa !24
  br label %bb295
bb295:
  store %olang.scope zeroinitializer, ptr %s61
  %t1575 = load i64, ptr %l86, !tbaa !24
  store i64 %t1575, ptr %l683, !tbaa !24
  %t1576 = load ptr, ptr %l85, !tbaa !29
  %t1578 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t1576)
  store i64 %t1578, ptr %l685
  br label %bb296
bb296:
  %t1579 = load i64, ptr %l683, !tbaa !24
  %t1580 = load i64, ptr %l685, !tbaa !24
  %t1581 = icmp slt i64 %t1579, %t1580
  %t1583 = xor i1 %t1581, true
  br i1 %t1583, label %bb297, label %bb298
bb297:
  call void @__olang_scope_close(ptr %s61)
  br label %bb312
bb298:
  br label %bb299
bb299:
  %t1585 = load ptr, ptr %l85, !tbaa !29
  %t1586 = load i64, ptr %l86, !tbaa !24
  %t1589 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t1585, i64 %t1586)
  store { i64, ptr } %t1589, ptr %l690
  br label %bb300
bb300:
  %t1590 = load { i64, ptr }, ptr %l690, !tbaa !27
  store { i64, ptr } %t1590, ptr %l87, !tbaa !27
  %t1591 = load ptr, ptr %l0, !tbaa !29
  %t1592 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t1593 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d321, i32 0, i32 1) }, 1
  %t1594 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d321, i32 0, i32 1) }, 0
  %t1596 = extractvalue { i64, ptr } %t1592, 1
  %t1597 = extractvalue { i64, ptr } %t1592, 0
  %t1598 = add i64 %t1594, %t1597
  %t1599 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d322, i32 0, i32 1) }, 1
  %t1600 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d322, i32 0, i32 1) }, 0
  %t1601 = add i64 %t1598, %t1600
  %t1602 = call ptr @__olang_scope_alloc(ptr %s61, i64 %t1601)
  call void @olang_textcopy(ptr %t1602, ptr %t1593, i64 %t1594)
  %t1603 = getelementptr i8, ptr %t1602, i64 %t1594
  call void @olang_textcopy(ptr %t1603, ptr %t1596, i64 %t1597)
  %t1604 = getelementptr i8, ptr %t1603, i64 %t1597
  call void @olang_textcopy(ptr %t1604, ptr %t1599, i64 %t1600)
  %t1605 = insertvalue { i64, ptr } undef, i64 %t1601, 0
  %t1606 = insertvalue { i64, ptr } %t1605, ptr %t1602, 1
  %t1610 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s61, ptr %s61, ptr %v1, ptr %t1591, { i64, ptr } %t1606)
  store { i64, ptr } %t1610, ptr %l695
  br label %bb301
bb301:
  %t1611 = load { i64, ptr }, ptr %l695, !tbaa !27
  store { i64, ptr } %t1611, ptr %l88, !tbaa !27
  %t1612 = load ptr, ptr %l0, !tbaa !29
  %t1613 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t1614 = load { i64, ptr }, ptr %l88, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s61, ptr %s0, ptr %s61, ptr %s61, ptr %v1, ptr %t1612, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d323, i32 0, i32 1) }, { i64, ptr } %t1613, { i64, ptr } %t1614, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d43, i32 0, i32 1) })
  br label %bb302
bb302:
  %t1618 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1618, ptr %l699, !tbaa !29
  %t1619 = load { i64, ptr }, ptr %l87, !tbaa !27
  store { i64, ptr } %t1619, ptr %l700, !tbaa !27
  %t1620 = load ptr, ptr %l0, !tbaa !29
  %t1621 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t1622 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d324, i32 0, i32 1) }, 1
  %t1623 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d324, i32 0, i32 1) }, 0
  %t1625 = extractvalue { i64, ptr } %t1621, 1
  %t1626 = extractvalue { i64, ptr } %t1621, 0
  %t1627 = add i64 %t1623, %t1626
  %t1628 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d325, i32 0, i32 1) }, 1
  %t1629 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d325, i32 0, i32 1) }, 0
  %t1630 = add i64 %t1627, %t1629
  %t1631 = call ptr @__olang_scope_alloc(ptr %s61, i64 %t1630)
  call void @olang_textcopy(ptr %t1631, ptr %t1622, i64 %t1623)
  %t1632 = getelementptr i8, ptr %t1631, i64 %t1623
  call void @olang_textcopy(ptr %t1632, ptr %t1625, i64 %t1626)
  %t1633 = getelementptr i8, ptr %t1632, i64 %t1626
  call void @olang_textcopy(ptr %t1633, ptr %t1628, i64 %t1629)
  %t1634 = insertvalue { i64, ptr } undef, i64 %t1630, 0
  %t1635 = insertvalue { i64, ptr } %t1634, ptr %t1631, 1
  %t1639 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s61, ptr %s61, ptr %v1, ptr %t1620, { i64, ptr } %t1635)
  store { i64, ptr } %t1639, ptr %l705
  br label %bb303
bb303:
  %t1640 = load { i64, ptr }, ptr %l705, !tbaa !27
  %t1641 = load ptr, ptr %l699, !tbaa !29
  %t1642 = load { i64, ptr }, ptr %l700, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s61, ptr %s0, ptr %s61, ptr %s61, ptr %v1, ptr %t1641, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d326, i32 0, i32 1) }, { i64, ptr } %t1642, { i64, ptr } %t1640, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d43, i32 0, i32 1) })
  br label %bb304
bb304:
  %t1644 = call ptr @__olang_scope_hold(ptr %s0)
  %t1645 = ptrtoint ptr %t1644 to i64
  store i64 %t1645, ptr %l707, !tbaa !24
  %t1646 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2espawn_2elocal_2e84
  br i1 %t1646, label %bb305, label %bb306
bb305:
  %t1648 = call ptr @__olang_region_make(ptr %s0)
  %t1649 = ptrtoint ptr %t1648 to i64
  store i64 %t1649, ptr %l707, !tbaa !24
  br label %bb306
bb306:
  %t1650 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t1650, ptr %l709, !tbaa !27
  %t1651 = load { i64, ptr }, ptr %l709, !tbaa !27
  %t1652 = extractvalue { i64, ptr } %t1651, 0
  store i64 %t1652, ptr %l710, !tbaa !24
  %t1653 = load i64, ptr %l710, !tbaa !24
  %t1654 = mul i64 %t1653, 1
  %t1655 = load i64, ptr %l707
  %t1656 = inttoptr i64 %t1655 to ptr
  %t1657 = call ptr @__olang_held_alloc(ptr %t1656, i64 %t1654)
  %t1658 = insertvalue { i64, ptr } undef, i64 %t1653, 0
  %t1659 = insertvalue { i64, ptr } %t1658, ptr %t1657, 1
  store { i64, ptr } %t1659, ptr %l711, !tbaa !27
  %t1660 = getelementptr { i64, ptr }, ptr %l711, i32 0, i32 1
  %t1661 = load ptr, ptr %t1660, !tbaa !27
  %t1662 = getelementptr { i64, ptr }, ptr %l709, i32 0, i32 1
  %t1663 = load ptr, ptr %t1662, !tbaa !27
  %t1664 = load i64, ptr %l710, !tbaa !24
  %t1665 = mul i64 %t1664, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1661, ptr %t1663, i64 %t1665, i1 false)
  %t1666 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t1666, ptr %l712, !tbaa !27
  %t1667 = load { i64, ptr }, ptr %l711, !tbaa !27
  store { i64, ptr } %t1667, ptr %l84, !tbaa !27
  %t1668 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2espawn_2elocal_2e84
  br i1 %t1668, label %bb307, label %bb308
bb307:
  %t1670 = load { i64, ptr }, ptr %l712
  %t1671 = extractvalue { i64, ptr } %t1670, 1
  call void @__olang_region_release(ptr %t1671)
  store { i64, ptr } zeroinitializer, ptr %l712
  br label %bb308
bb308:
  %t1672 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2espawn_2elocal_2e84
  br i1 %t1672, label %bb309, label %bb310
bb309:
  %t1674 = load i64, ptr %l707
  %t1675 = inttoptr i64 %t1674 to ptr
  %t1676 = load { i64, ptr }, ptr %l84
  %t1677 = extractvalue { i64, ptr } %t1676, 1
  %t1678 = call ptr @__olang_region_or(ptr %t1677, ptr null)
  %t1679 = icmp ne ptr %t1678, null
  %t1680 = select i1 %t1679, ptr %t1678, ptr null
  call void @__olang_region_settle_in(ptr %t1675, ptr %t1680)
  br label %bb310
bb310:
  call void @__olang_scope_close(ptr %s61)
  br label %bb311
bb311:
  %t1681 = load i64, ptr %l86, !tbaa !24
  %t1684 = add i64 %t1681, 1
  store i64 %t1684, ptr %l86, !tbaa !24
  br label %bb295
bb312:
  %t1686 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1686, ptr %l718, !tbaa !29
  %t1687 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t1687, ptr %l719, !tbaa !27
  %t1688 = load ptr, ptr %l0, !tbaa !29
  %t1689 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t1690 = extractvalue { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d327, i32 0, i32 1) }, 1
  %t1691 = extractvalue { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d327, i32 0, i32 1) }, 0
  %t1693 = extractvalue { i64, ptr } %t1689, 1
  %t1694 = extractvalue { i64, ptr } %t1689, 0
  %t1695 = add i64 %t1691, %t1694
  %t1696 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d328, i32 0, i32 1) }, 1
  %t1697 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d328, i32 0, i32 1) }, 0
  %t1698 = add i64 %t1695, %t1697
  %t1699 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1698)
  call void @olang_textcopy(ptr %t1699, ptr %t1690, i64 %t1691)
  %t1700 = getelementptr i8, ptr %t1699, i64 %t1691
  call void @olang_textcopy(ptr %t1700, ptr %t1693, i64 %t1694)
  %t1701 = getelementptr i8, ptr %t1700, i64 %t1694
  call void @olang_textcopy(ptr %t1701, ptr %t1696, i64 %t1697)
  %t1702 = insertvalue { i64, ptr } undef, i64 %t1698, 0
  %t1703 = insertvalue { i64, ptr } %t1702, ptr %t1699, 1
  %t1707 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v1, ptr %t1688, { i64, ptr } %t1703)
  store { i64, ptr } %t1707, ptr %l724
  br label %bb313
bb313:
  %t1708 = load { i64, ptr }, ptr %l724, !tbaa !27
  %t1709 = load ptr, ptr %l718, !tbaa !29
  %t1710 = load { i64, ptr }, ptr %l719, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %v1, ptr %t1709, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d329, i32 0, i32 1) }, { i64, ptr } %t1710, { i64, ptr } %t1708, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d43, i32 0, i32 1) })
  br label %bb314
bb314:
  %t1712 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1712, ptr %l726, !tbaa !29
  %t1713 = load ptr, ptr %l0, !tbaa !29
  %t1714 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t1715 = extractvalue { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d330, i32 0, i32 1) }, 1
  %t1716 = extractvalue { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d330, i32 0, i32 1) }, 0
  %t1718 = extractvalue { i64, ptr } %t1714, 1
  %t1719 = extractvalue { i64, ptr } %t1714, 0
  %t1720 = add i64 %t1716, %t1719
  %t1721 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d331, i32 0, i32 1) }, 1
  %t1722 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d331, i32 0, i32 1) }, 0
  %t1723 = add i64 %t1720, %t1722
  %t1724 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1723)
  call void @olang_textcopy(ptr %t1724, ptr %t1715, i64 %t1716)
  %t1725 = getelementptr i8, ptr %t1724, i64 %t1716
  call void @olang_textcopy(ptr %t1725, ptr %t1718, i64 %t1719)
  %t1726 = getelementptr i8, ptr %t1725, i64 %t1719
  call void @olang_textcopy(ptr %t1726, ptr %t1721, i64 %t1722)
  %t1727 = insertvalue { i64, ptr } undef, i64 %t1723, 0
  %t1728 = insertvalue { i64, ptr } %t1727, ptr %t1724, 1
  %t1732 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v1, ptr %t1713, { i64, ptr } %t1728)
  store { i64, ptr } %t1732, ptr %l731
  br label %bb315
bb315:
  %t1733 = load { i64, ptr }, ptr %l731, !tbaa !27
  %t1734 = load ptr, ptr %l726, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %v1, ptr %t1734, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d332, i32 0, i32 1) }, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d333, i32 0, i32 1) }, { i64, ptr } %t1733, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d43, i32 0, i32 1) })
  br label %bb316
bb316:
  %t1736 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1736, ptr %l733, !tbaa !29
  %t1737 = load ptr, ptr %l0, !tbaa !29
  %t1738 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t1739 = extractvalue { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d334, i32 0, i32 1) }, 1
  %t1740 = extractvalue { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d334, i32 0, i32 1) }, 0
  %t1742 = extractvalue { i64, ptr } %t1738, 1
  %t1743 = extractvalue { i64, ptr } %t1738, 0
  %t1744 = add i64 %t1740, %t1743
  %t1745 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d335, i32 0, i32 1) }, 1
  %t1746 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d335, i32 0, i32 1) }, 0
  %t1747 = add i64 %t1744, %t1746
  %t1748 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1747)
  call void @olang_textcopy(ptr %t1748, ptr %t1739, i64 %t1740)
  %t1749 = getelementptr i8, ptr %t1748, i64 %t1740
  call void @olang_textcopy(ptr %t1749, ptr %t1742, i64 %t1743)
  %t1750 = getelementptr i8, ptr %t1749, i64 %t1743
  call void @olang_textcopy(ptr %t1750, ptr %t1745, i64 %t1746)
  %t1751 = insertvalue { i64, ptr } undef, i64 %t1747, 0
  %t1752 = insertvalue { i64, ptr } %t1751, ptr %t1748, 1
  %t1756 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v1, ptr %t1737, { i64, ptr } %t1752)
  store { i64, ptr } %t1756, ptr %l738
  br label %bb317
bb317:
  %t1757 = load { i64, ptr }, ptr %l738, !tbaa !27
  %t1758 = load ptr, ptr %l733, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %v1, ptr %t1758, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d336, i32 0, i32 1) }, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d337, i32 0, i32 1) }, { i64, ptr } %t1757, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d43, i32 0, i32 1) })
  br label %bb318
bb318:
  %t1760 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1760, ptr %l740, !tbaa !29
  %t1761 = load ptr, ptr %l0, !tbaa !29
  %t1762 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t1763 = extractvalue { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d338, i32 0, i32 1) }, 1
  %t1764 = extractvalue { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d338, i32 0, i32 1) }, 0
  %t1766 = extractvalue { i64, ptr } %t1762, 1
  %t1767 = extractvalue { i64, ptr } %t1762, 0
  %t1768 = add i64 %t1764, %t1767
  %t1769 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d339, i32 0, i32 1) }, 1
  %t1770 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d339, i32 0, i32 1) }, 0
  %t1771 = add i64 %t1768, %t1770
  %t1772 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1771)
  call void @olang_textcopy(ptr %t1772, ptr %t1763, i64 %t1764)
  %t1773 = getelementptr i8, ptr %t1772, i64 %t1764
  call void @olang_textcopy(ptr %t1773, ptr %t1766, i64 %t1767)
  %t1774 = getelementptr i8, ptr %t1773, i64 %t1767
  call void @olang_textcopy(ptr %t1774, ptr %t1769, i64 %t1770)
  %t1775 = insertvalue { i64, ptr } undef, i64 %t1771, 0
  %t1776 = insertvalue { i64, ptr } %t1775, ptr %t1772, 1
  %t1780 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v1, ptr %t1761, { i64, ptr } %t1776)
  store { i64, ptr } %t1780, ptr %l745
  br label %bb319
bb319:
  %t1781 = load { i64, ptr }, ptr %l745, !tbaa !27
  %t1782 = load ptr, ptr %l740, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %v1, ptr %t1782, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d340, i32 0, i32 1) }, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d341, i32 0, i32 1) }, { i64, ptr } %t1781, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d43, i32 0, i32 1) })
  br label %bb320
bb320:
  %t1784 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1784, ptr %l747, !tbaa !29
  %t1785 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t1785, ptr %l748, !tbaa !27
  %t1786 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1786, ptr %l749
  %t1788 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s0, ptr %l749)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1788, ptr %l751
  br label %bb321
bb321:
  %t1789 = load i1, ptr %l8, !tbaa !21
  store i1 %t1789, ptr %l752, !tbaa !21
  %t1790 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t1790, ptr %l753, !tbaa !27
  %t1791 = load i32, ptr %l6, !tbaa !23
  store i32 %t1791, ptr %l754, !tbaa !23
  %t1792 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 2
  %t1793 = getelementptr %"compiler/mir:Range", ptr %t1792, i32 0, i32 1
  %t1794 = load i32, ptr %t1793, !tbaa !23
  %t1796 = sext i32 %t1794 to i64
  store i64 %t1796, ptr %l756, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l757, ptr %l2, i64 144, i1 false)
  %t1797 = load ptr, ptr %l0, !tbaa !29
  %t1799 = getelementptr %"compiler/emit:fnEm", ptr %t1797, i32 0, i32 1
  %t1800 = load ptr, ptr %t1799, !tbaa !29
  %t1802 = getelementptr %"compiler/mir:Fn", ptr %t1800, i32 0, i32 8
  store ptr %t1802, ptr %l760, !tbaa !29
  %t1803 = load i32, ptr %l1, !tbaa !23
  %t1805 = sext i32 %t1803 to i64
  %t1806 = load ptr, ptr %l760, !tbaa !29
  %t1807 = call ptr @__olang_scope_or(ptr %v2, ptr %t1806)
  %t1808 = call ptr @__olang_scope_hold(ptr %t1807)
  %t1809 = ptrtoint ptr %t1808 to i64
  %t1811 = inttoptr i64 %t1809 to ptr
  %t1812 = load ptr, ptr %l760, !tbaa !29
  %t1814 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %t1811, ptr %t1812, i64 %t1805)
  store %"compiler/mir:ScopeInfo" %t1814, ptr %l764
  br label %bb322
bb322:
  %t1815 = getelementptr %"compiler/mir:ScopeInfo", ptr %l764, i32 0, i32 4
  %t1816 = load i32, ptr %t1815, !tbaa !23
  %t1817 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t1818 = load i64, ptr %l63, !tbaa !24
  %t1819 = load ptr, ptr %l747, !tbaa !29
  %t1820 = load { i64, ptr }, ptr %l748, !tbaa !27
  %t1821 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l751
  %t1822 = load i1, ptr %l752, !tbaa !21
  %t1823 = load { i64, ptr }, ptr %l753, !tbaa !27
  %t1824 = load i32, ptr %l754, !tbaa !23
  %t1825 = load i64, ptr %l756, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %t1826, ptr %l757, i64 144, i1 false)
  %t1830 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2etrampoline(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %v1, ptr %v2, ptr %t1819, { i64, ptr } %t1820, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1821, i1 %t1822, { i64, ptr } %t1823, i32 %t1824, i64 %t1825, ptr %t1826, i32 %t1816, { i64, ptr } %t1817, i64 %t1818)
  store { i64, ptr } %t1830, ptr %l768
  br label %bb323
bb323:
  %t1831 = load { i64, ptr }, ptr %l768, !tbaa !27
  store { i64, ptr } %t1831, ptr %l89, !tbaa !27
  %t1832 = load ptr, ptr %l4, !tbaa !29
  store ptr %t1832, ptr %l769, !tbaa !29
  %t1833 = load ptr, ptr %l769, !tbaa !29
  %t1834 = call ptr @__olang_scope_or(ptr %v1, ptr %t1833)
  %t1835 = call ptr @__olang_scope_hold(ptr %t1834)
  %t1836 = ptrtoint ptr %t1835 to i64
  %t1838 = inttoptr i64 %t1836 to ptr
  %t1839 = load ptr, ptr %l769, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %t1838, ptr %s0, ptr %s0, ptr %t1839, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d342, i32 0, i32 1) }, { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d343, i32 0, i32 1) })
  br label %bb324
bb324:
  %t1840 = load ptr, ptr %l4, !tbaa !29
  store ptr %t1840, ptr %l771, !tbaa !29
  %t1841 = load ptr, ptr %l771, !tbaa !29
  %t1842 = call ptr @__olang_scope_or(ptr %v1, ptr %t1841)
  %t1843 = call ptr @__olang_scope_hold(ptr %t1842)
  %t1844 = ptrtoint ptr %t1843 to i64
  %t1846 = inttoptr i64 %t1844 to ptr
  %t1847 = load ptr, ptr %l771, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %t1846, ptr %s0, ptr %s0, ptr %t1847, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d344, i32 0, i32 1) }, { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d345, i32 0, i32 1) })
  br label %bb325
bb325:
  %t1848 = load ptr, ptr %l0, !tbaa !29
  %t1850 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v1, ptr %t1848, { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d346, i32 0, i32 1) })
  store { i64, ptr } %t1850, ptr %l774
  br label %bb326
bb326:
  %t1851 = load { i64, ptr }, ptr %l774, !tbaa !27
  %t1852 = load ptr, ptr %l0, !tbaa !29
  %t1854 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t1855 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t1856 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t1857 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d347, i32 0, i32 1) }, 1
  %t1858 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d347, i32 0, i32 1) }, 0
  %t1860 = extractvalue { i64, ptr } %t1851, 1
  %t1861 = extractvalue { i64, ptr } %t1851, 0
  %t1862 = add i64 %t1858, %t1861
  %t1863 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d348, i32 0, i32 1) }, 1
  %t1864 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d348, i32 0, i32 1) }, 0
  %t1865 = add i64 %t1862, %t1864
  %t1867 = extractvalue { i64, ptr } %t1854, 1
  %t1868 = extractvalue { i64, ptr } %t1854, 0
  %t1869 = add i64 %t1865, %t1868
  %t1870 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d349, i32 0, i32 1) }, 1
  %t1871 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d349, i32 0, i32 1) }, 0
  %t1872 = add i64 %t1869, %t1871
  %t1874 = extractvalue { i64, ptr } %t1855, 1
  %t1875 = extractvalue { i64, ptr } %t1855, 0
  %t1876 = add i64 %t1872, %t1875
  %t1877 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d349, i32 0, i32 1) }, 1
  %t1878 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d349, i32 0, i32 1) }, 0
  %t1879 = add i64 %t1876, %t1878
  %t1881 = extractvalue { i64, ptr } %t1856, 1
  %t1882 = extractvalue { i64, ptr } %t1856, 0
  %t1883 = add i64 %t1879, %t1882
  %t1884 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d350, i32 0, i32 1) }, 1
  %t1885 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d350, i32 0, i32 1) }, 0
  %t1886 = add i64 %t1883, %t1885
  %t1887 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1886)
  call void @olang_textcopy(ptr %t1887, ptr %t1857, i64 %t1858)
  %t1888 = getelementptr i8, ptr %t1887, i64 %t1858
  call void @olang_textcopy(ptr %t1888, ptr %t1860, i64 %t1861)
  %t1889 = getelementptr i8, ptr %t1888, i64 %t1861
  call void @olang_textcopy(ptr %t1889, ptr %t1863, i64 %t1864)
  %t1890 = getelementptr i8, ptr %t1889, i64 %t1864
  call void @olang_textcopy(ptr %t1890, ptr %t1867, i64 %t1868)
  %t1891 = getelementptr i8, ptr %t1890, i64 %t1868
  call void @olang_textcopy(ptr %t1891, ptr %t1870, i64 %t1871)
  %t1892 = getelementptr i8, ptr %t1891, i64 %t1871
  call void @olang_textcopy(ptr %t1892, ptr %t1874, i64 %t1875)
  %t1893 = getelementptr i8, ptr %t1892, i64 %t1875
  call void @olang_textcopy(ptr %t1893, ptr %t1877, i64 %t1878)
  %t1894 = getelementptr i8, ptr %t1893, i64 %t1878
  call void @olang_textcopy(ptr %t1894, ptr %t1881, i64 %t1882)
  %t1895 = getelementptr i8, ptr %t1894, i64 %t1882
  call void @olang_textcopy(ptr %t1895, ptr %t1884, i64 %t1885)
  %t1896 = insertvalue { i64, ptr } undef, i64 %t1886, 0
  %t1897 = insertvalue { i64, ptr } %t1896, ptr %t1887, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %v1, ptr %t1852, { i64, ptr } %t1897)
  br label %bb327
bb327:
  %t1901 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1901, ptr %l782, !tbaa !29
  %t1902 = load ptr, ptr %l0, !tbaa !29
  %t1903 = load i32, ptr %l1, !tbaa !23
  %t1904 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d351, i32 0, i32 1) }, 1
  %t1905 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d351, i32 0, i32 1) }, 0
  %t1907 = sext i32 %t1903 to i64
  %t1908 = call i64 @__olang_fmt_i64(ptr null, i64 %t1907)
  %t1909 = add i64 %t1905, %t1908
  %t1910 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1909)
  call void @olang_textcopy(ptr %t1910, ptr %t1904, i64 %t1905)
  %t1911 = getelementptr i8, ptr %t1910, i64 %t1905
  %t1912 = call i64 @__olang_fmt_i64(ptr %t1911, i64 %t1907)
  %t1913 = insertvalue { i64, ptr } undef, i64 %t1909, 0
  %t1914 = insertvalue { i64, ptr } %t1913, ptr %t1910, 1
  %t1918 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %v1, ptr %t1902, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d352, i32 0, i32 1) }, { i64, ptr } %t1914, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d49, i32 0, i32 1) })
  store { i64, ptr } %t1918, ptr %l787
  br label %bb328
bb328:
  %t1919 = load { i64, ptr }, ptr %l787, !tbaa !27
  %t1920 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t1921 = load ptr, ptr %l782, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %v1, ptr %t1921, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d353, i32 0, i32 1) }, { i64, ptr } %t1919, { i64, ptr } %t1920, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d43, i32 0, i32 1) })
  br label %bb329
bb329:
  %t1924 = load ptr, ptr %l0, !tbaa !29
  %t1925 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t1926 = load i32, ptr %l1, !tbaa !23
  %t1927 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d354, i32 0, i32 1) }, 1
  %t1928 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d354, i32 0, i32 1) }, 0
  %t1930 = sext i32 %t1926 to i64
  %t1931 = call i64 @__olang_fmt_i64(ptr null, i64 %t1930)
  %t1932 = add i64 %t1928, %t1931
  %t1933 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1932)
  call void @olang_textcopy(ptr %t1933, ptr %t1927, i64 %t1928)
  %t1934 = getelementptr i8, ptr %t1933, i64 %t1928
  %t1935 = call i64 @__olang_fmt_i64(ptr %t1934, i64 %t1930)
  %t1936 = insertvalue { i64, ptr } undef, i64 %t1932, 0
  %t1937 = insertvalue { i64, ptr } %t1936, ptr %t1933, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %v1, ptr %t1924, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d355, i32 0, i32 1) }, { i64, ptr } %t1925, { i64, ptr } %t1937, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d43, i32 0, i32 1) })
  br label %bb330
bb330:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2estoreParts(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, i32 %a3, { i64, ptr } %a4, i64 %a5, i32 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l23 = alloca i32
  %l25 = alloca i32
  %l30 = alloca { i64, ptr }
  %l35 = alloca i32
  %l38 = alloca i32
  %l65 = alloca ptr
  %l66 = alloca { i64, ptr }
  %l67 = alloca i32
  %l69 = alloca ptr
  %l72 = alloca { i64, ptr }
  %l77 = alloca ptr
  %l79 = alloca ptr
  %l80 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l7, !tbaa !29
  %t9 = load ptr, ptr %l7, !tbaa !29
  store ptr %t9, ptr %l18, !tbaa !29
  %t10 = load ptr, ptr %l7, !tbaa !29
  store ptr %t10, ptr %l19, !tbaa !29
  %t11 = load ptr, ptr %l7, !tbaa !29
  store ptr %t11, ptr %l20, !tbaa !29
  %t12 = load i32, ptr %l3, !tbaa !23
  %t13 = load ptr, ptr %l20, !tbaa !29
  %t14 = call ptr @__olang_scope_or(ptr %v4, ptr %t13)
  %t15 = call ptr @__olang_scope_hold(ptr %t14)
  %t16 = ptrtoint ptr %t15 to i64
  %t18 = inttoptr i64 %t16 to ptr
  %t19 = load ptr, ptr %l20, !tbaa !29
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t18, ptr %t19, i32 %t12)
  store i32 %t21, ptr %l23
  br label %bb1
bb1:
  %t22 = load ptr, ptr %l19, !tbaa !29
  %t23 = call ptr @__olang_scope_or(ptr %v4, ptr %t22)
  %t24 = call ptr @__olang_scope_hold(ptr %t23)
  %t25 = ptrtoint ptr %t24 to i64
  %t27 = inttoptr i64 %t25 to ptr
  %t28 = load ptr, ptr %l19, !tbaa !29
  %t29 = load i32, ptr %l23, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %t27, ptr %t28, i32 %t29)
  store i32 %t30, ptr %l25
  br label %bb2
bb2:
  %t31 = load ptr, ptr %l18, !tbaa !29
  %t32 = call ptr @__olang_scope_or(ptr %v4, ptr %t31)
  %t33 = call ptr @__olang_scope_hold(ptr %t32)
  %t34 = ptrtoint ptr %t33 to i64
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/emit:fnEm", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = call ptr @__olang_scope_or(ptr %v4, ptr %t38)
  %t41 = call ptr @__olang_scope_hold(ptr %t40)
  %t42 = ptrtoint ptr %t41 to i64
  %t44 = inttoptr i64 %t34 to ptr
  %t46 = inttoptr i64 %t42 to ptr
  %t47 = load ptr, ptr %l18, !tbaa !29
  %t48 = load i32, ptr %l25, !tbaa !23
  %t49 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t44, ptr %t46, ptr %t47, i32 %t48)
  store { i64, ptr } %t49, ptr %l30
  br label %bb3
bb3:
  %t50 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t50, ptr %l8, !tbaa !27
  store i32 0, ptr %l9, !tbaa !23
  store i32 %a6, ptr %l10, !tbaa !23
  store i32 1, ptr %l11, !tbaa !23
  %t53 = load i32, ptr %l10, !tbaa !23
  %t54 = load i32, ptr %l9, !tbaa !23
  %t57 = icmp sgt i32 %t53, %t54
  br i1 %t57, label %bb4, label %bb5
bb4:
  %t59 = load i32, ptr %l11, !tbaa !23
  %t61 = icmp sgt i32 %t59, 0
  br i1 %t61, label %bb6, label %bb7
bb5:
  store i32 0, ptr %l35, !tbaa !23
  br label %bb9
bb6:
  %t63 = load i32, ptr %l10, !tbaa !23
  %t64 = load i32, ptr %l9, !tbaa !23
  %t67 = sub i32 %t63, %t64
  %t68 = load i32, ptr %l11, !tbaa !23
  %t71 = add i32 %t67, %t68
  %t73 = sub i32 %t71, 1
  %t74 = load i32, ptr %l11, !tbaa !23
  %t77 = sdiv i32 %t73, %t74
  store i32 %t77, ptr %l38, !tbaa !23
  br label %bb8
bb7:
  store i32 0, ptr %l38, !tbaa !23
  br label %bb8
bb8:
  %t79 = load i32, ptr %l38, !tbaa !23
  store i32 %t79, ptr %l35, !tbaa !23
  br label %bb9
bb9:
  %t80 = load i32, ptr %l35, !tbaa !23
  store i32 %t80, ptr %l12, !tbaa !23
  store i32 0, ptr %l13, !tbaa !23
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t81 = load i32, ptr %l13, !tbaa !23
  %t82 = load i32, ptr %l12, !tbaa !23
  %t85 = icmp slt i32 %t81, %t82
  %t87 = xor i1 %t85, true
  br i1 %t87, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb12:
  br label %bb13
bb13:
  %t89 = load i32, ptr %l9, !tbaa !23
  %t90 = load i32, ptr %l13, !tbaa !23
  %t91 = load i32, ptr %l11, !tbaa !23
  %t94 = mul i32 %t90, %t91
  %t97 = add i32 %t89, %t94
  store i32 %t97, ptr %l14, !tbaa !23
  %t99 = load ptr, ptr %l1, !tbaa !29
  %t100 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t101 = load i32, ptr %l14, !tbaa !23
  %t103 = load i32, ptr %l14, !tbaa !23
  %t105 = sext i32 %t103 to i64
  %t108 = add i64 %a5, %t105
  %t109 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d356, i32 0, i32 1) }, 1
  %t110 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d356, i32 0, i32 1) }, 0
  %t112 = extractvalue { i64, ptr } %t100, 1
  %t113 = extractvalue { i64, ptr } %t100, 0
  %t114 = add i64 %t110, %t113
  %t115 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d357, i32 0, i32 1) }, 1
  %t116 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d357, i32 0, i32 1) }, 0
  %t117 = add i64 %t114, %t116
  %t119 = sext i32 %t101 to i64
  %t120 = call i64 @__olang_fmt_i64(ptr null, i64 %t119)
  %t121 = add i64 %t117, %t120
  %t122 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d358, i32 0, i32 1) }, 1
  %t123 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d358, i32 0, i32 1) }, 0
  %t124 = add i64 %t121, %t123
  %t126 = call i64 @__olang_fmt_i64(ptr null, i64 %t108)
  %t127 = add i64 %t124, %t126
  %t128 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d359, i32 0, i32 1) }, 1
  %t129 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d359, i32 0, i32 1) }, 0
  %t130 = add i64 %t127, %t129
  %t131 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t130)
  call void @olang_textcopy(ptr %t131, ptr %t109, i64 %t110)
  %t132 = getelementptr i8, ptr %t131, i64 %t110
  call void @olang_textcopy(ptr %t132, ptr %t112, i64 %t113)
  %t133 = getelementptr i8, ptr %t132, i64 %t113
  call void @olang_textcopy(ptr %t133, ptr %t115, i64 %t116)
  %t134 = getelementptr i8, ptr %t133, i64 %t116
  %t135 = call i64 @__olang_fmt_i64(ptr %t134, i64 %t119)
  %t136 = getelementptr i8, ptr %t134, i64 %t120
  call void @olang_textcopy(ptr %t136, ptr %t122, i64 %t123)
  %t137 = getelementptr i8, ptr %t136, i64 %t123
  %t138 = call i64 @__olang_fmt_i64(ptr %t137, i64 %t108)
  %t139 = getelementptr i8, ptr %t137, i64 %t126
  call void @olang_textcopy(ptr %t139, ptr %t128, i64 %t129)
  %t140 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t131, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t99, { i64, ptr } %t141)
  br label %bb14
bb14:
  %t145 = load ptr, ptr %l1, !tbaa !29
  store ptr %t145, ptr %l65, !tbaa !29
  %t146 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t146, ptr %l66, !tbaa !27
  %t147 = load i32, ptr %l14, !tbaa !23
  store i32 %t147, ptr %l67, !tbaa !23
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/emit:fnEm", ptr %t148, i32 0, i32 0
  %t151 = load ptr, ptr %t150, !tbaa !29
  store ptr %t151, ptr %l69, !tbaa !29
  %t152 = load i32, ptr %l3, !tbaa !23
  %t153 = load ptr, ptr %l69, !tbaa !29
  %t154 = call ptr @__olang_scope_or(ptr %v4, ptr %t153)
  %t155 = call ptr @__olang_scope_hold(ptr %t154)
  %t156 = ptrtoint ptr %t155 to i64
  %t158 = inttoptr i64 %t156 to ptr
  %t159 = load ptr, ptr %l69, !tbaa !29
  %t161 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %t158, ptr %s2, ptr %t159, i32 %t152)
  store { i64, ptr } %t161, ptr %l72
  br label %bb15
bb15:
  %t163 = load i32, ptr %l14, !tbaa !23
  %t164 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d360, i32 0, i32 1) }, 1
  %t165 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d360, i32 0, i32 1) }, 0
  %t166 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t167 = extractvalue { i64, ptr } %t166, 1
  %t168 = extractvalue { i64, ptr } %t166, 0
  %t169 = add i64 %t165, %t168
  %t170 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d361, i32 0, i32 1) }, 1
  %t171 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d361, i32 0, i32 1) }, 0
  %t172 = add i64 %t169, %t171
  %t173 = load i32, ptr %l67, !tbaa !23
  %t174 = sext i32 %t173 to i64
  %t175 = call i64 @__olang_fmt_i64(ptr null, i64 %t174)
  %t176 = add i64 %t172, %t175
  %t177 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d362, i32 0, i32 1) }, 1
  %t178 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d362, i32 0, i32 1) }, 0
  %t179 = add i64 %t176, %t178
  %t180 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t180, 1
  %t182 = extractvalue { i64, ptr } %t180, 0
  %t183 = add i64 %t179, %t182
  %t184 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d363, i32 0, i32 1) }, 1
  %t185 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d363, i32 0, i32 1) }, 0
  %t186 = add i64 %t183, %t185
  %t188 = extractvalue { i64, ptr } %a4, 1
  %t189 = extractvalue { i64, ptr } %a4, 0
  %t190 = add i64 %t186, %t189
  %t191 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d364, i32 0, i32 1) }, 1
  %t192 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d364, i32 0, i32 1) }, 0
  %t193 = add i64 %t190, %t192
  %t195 = sext i32 %t163 to i64
  %t196 = call i64 @__olang_fmt_i64(ptr null, i64 %t195)
  %t197 = add i64 %t193, %t196
  %t198 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d365, i32 0, i32 1) }, 1
  %t199 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d365, i32 0, i32 1) }, 0
  %t200 = add i64 %t197, %t199
  %t201 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t200)
  call void @olang_textcopy(ptr %t201, ptr %t164, i64 %t165)
  %t202 = getelementptr i8, ptr %t201, i64 %t165
  call void @olang_textcopy(ptr %t202, ptr %t167, i64 %t168)
  %t203 = getelementptr i8, ptr %t202, i64 %t168
  call void @olang_textcopy(ptr %t203, ptr %t170, i64 %t171)
  %t204 = getelementptr i8, ptr %t203, i64 %t171
  %t205 = call i64 @__olang_fmt_i64(ptr %t204, i64 %t174)
  %t206 = getelementptr i8, ptr %t204, i64 %t175
  call void @olang_textcopy(ptr %t206, ptr %t177, i64 %t178)
  %t207 = getelementptr i8, ptr %t206, i64 %t178
  call void @olang_textcopy(ptr %t207, ptr %t181, i64 %t182)
  %t208 = getelementptr i8, ptr %t207, i64 %t182
  call void @olang_textcopy(ptr %t208, ptr %t184, i64 %t185)
  %t209 = getelementptr i8, ptr %t208, i64 %t185
  call void @olang_textcopy(ptr %t209, ptr %t188, i64 %t189)
  %t210 = getelementptr i8, ptr %t209, i64 %t189
  call void @olang_textcopy(ptr %t210, ptr %t191, i64 %t192)
  %t211 = getelementptr i8, ptr %t210, i64 %t192
  %t212 = call i64 @__olang_fmt_i64(ptr %t211, i64 %t195)
  %t213 = getelementptr i8, ptr %t211, i64 %t196
  call void @olang_textcopy(ptr %t213, ptr %t198, i64 %t199)
  %t214 = insertvalue { i64, ptr } undef, i64 %t200, 0
  %t215 = insertvalue { i64, ptr } %t214, ptr %t201, 1
  %t217 = load ptr, ptr %l65, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t217, { i64, ptr } %t215)
  br label %bb16
bb16:
  %t219 = load ptr, ptr %l1, !tbaa !29
  store ptr %t219, ptr %l77, !tbaa !29
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/emit:fnEm", ptr %t220, i32 0, i32 0
  %t223 = load ptr, ptr %t222, !tbaa !29
  store ptr %t223, ptr %l79, !tbaa !29
  %t224 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t224, ptr %l80, !tbaa !27
  %t225 = load i32, ptr %l14, !tbaa !23
  %t227 = sext i32 %t225 to i64
  %t228 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t229 = load ptr, ptr %t228, !tbaa !27
  %t230 = getelementptr i32, ptr %t229, i64 %t227
  %t231 = load i32, ptr %t230, !tbaa !33
  %t232 = load ptr, ptr %l79, !tbaa !29
  %t233 = call ptr @__olang_scope_or(ptr %v4, ptr %t232)
  %t234 = call ptr @__olang_scope_hold(ptr %t233)
  %t235 = ptrtoint ptr %t234 to i64
  %t237 = inttoptr i64 %t235 to ptr
  %t238 = load ptr, ptr %l79, !tbaa !29
  %t240 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %t237, ptr %s2, ptr %t238, i32 %t231)
  store { i64, ptr } %t240, ptr %l84
  br label %bb17
bb17:
  %t241 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t242 = load i32, ptr %l14, !tbaa !23
  %t243 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t244 = load i32, ptr %l14, !tbaa !23
  %t245 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d366, i32 0, i32 1) }, 1
  %t246 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d366, i32 0, i32 1) }, 0
  %t247 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t248 = extractvalue { i64, ptr } %t247, 1
  %t249 = extractvalue { i64, ptr } %t247, 0
  %t250 = add i64 %t246, %t249
  %t251 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d367, i32 0, i32 1) }, 1
  %t252 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d367, i32 0, i32 1) }, 0
  %t253 = add i64 %t250, %t252
  %t255 = extractvalue { i64, ptr } %t241, 1
  %t256 = extractvalue { i64, ptr } %t241, 0
  %t257 = add i64 %t253, %t256
  %t258 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d368, i32 0, i32 1) }, 1
  %t259 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d368, i32 0, i32 1) }, 0
  %t260 = add i64 %t257, %t259
  %t262 = sext i32 %t242 to i64
  %t263 = call i64 @__olang_fmt_i64(ptr null, i64 %t262)
  %t264 = add i64 %t260, %t263
  %t265 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d369, i32 0, i32 1) }, 1
  %t266 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d369, i32 0, i32 1) }, 0
  %t267 = add i64 %t264, %t266
  %t269 = extractvalue { i64, ptr } %t243, 1
  %t270 = extractvalue { i64, ptr } %t243, 0
  %t271 = add i64 %t267, %t270
  %t272 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d368, i32 0, i32 1) }, 1
  %t273 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d368, i32 0, i32 1) }, 0
  %t274 = add i64 %t271, %t273
  %t276 = sext i32 %t244 to i64
  %t277 = call i64 @__olang_fmt_i64(ptr null, i64 %t276)
  %t278 = add i64 %t274, %t277
  %t279 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d370, i32 0, i32 1) }, 1
  %t280 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d370, i32 0, i32 1) }, 0
  %t281 = add i64 %t278, %t280
  %t282 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t281)
  call void @olang_textcopy(ptr %t282, ptr %t245, i64 %t246)
  %t283 = getelementptr i8, ptr %t282, i64 %t246
  call void @olang_textcopy(ptr %t283, ptr %t248, i64 %t249)
  %t284 = getelementptr i8, ptr %t283, i64 %t249
  call void @olang_textcopy(ptr %t284, ptr %t251, i64 %t252)
  %t285 = getelementptr i8, ptr %t284, i64 %t252
  call void @olang_textcopy(ptr %t285, ptr %t255, i64 %t256)
  %t286 = getelementptr i8, ptr %t285, i64 %t256
  call void @olang_textcopy(ptr %t286, ptr %t258, i64 %t259)
  %t287 = getelementptr i8, ptr %t286, i64 %t259
  %t288 = call i64 @__olang_fmt_i64(ptr %t287, i64 %t262)
  %t289 = getelementptr i8, ptr %t287, i64 %t263
  call void @olang_textcopy(ptr %t289, ptr %t265, i64 %t266)
  %t290 = getelementptr i8, ptr %t289, i64 %t266
  call void @olang_textcopy(ptr %t290, ptr %t269, i64 %t270)
  %t291 = getelementptr i8, ptr %t290, i64 %t270
  call void @olang_textcopy(ptr %t291, ptr %t272, i64 %t273)
  %t292 = getelementptr i8, ptr %t291, i64 %t273
  %t293 = call i64 @__olang_fmt_i64(ptr %t292, i64 %t276)
  %t294 = getelementptr i8, ptr %t292, i64 %t277
  call void @olang_textcopy(ptr %t294, ptr %t279, i64 %t280)
  %t295 = insertvalue { i64, ptr } undef, i64 %t281, 0
  %t296 = insertvalue { i64, ptr } %t295, ptr %t282, 1
  %t298 = load ptr, ptr %l77, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t298, { i64, ptr } %t296)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t300 = load i32, ptr %l13, !tbaa !23
  %t303 = add i32 %t300, 1
  store i32 %t303, ptr %l13, !tbaa !23
  br label %bb10
bb20:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2etailCall(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/mir:Call" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Call"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, [7 x i64] }
  %l6 = alloca { i64, [2 x i64] }
  %l7 = alloca i32
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca i1
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l40 = alloca ptr
  %l44 = alloca i64
  %l47 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l58 = alloca ptr
  %l61 = alloca i1
  %l66 = alloca ptr
  %l69 = alloca %"std/prelude/text:StringBuilder"
  %l74 = alloca i32
  %l77 = alloca i32
  %l98 = alloca ptr
  %l99 = alloca ptr
  %l102 = alloca ptr
  %l109 = alloca { i64, [1 x i64] }
  %l110 = alloca { i64, ptr }
  %l116 = alloca ptr
  %l117 = alloca ptr
  %l120 = alloca i32
  %l125 = alloca { i64, ptr }
  %l126 = alloca ptr
  %l129 = alloca { i64, ptr }
  %l135 = alloca i64
  %l138 = alloca i64
  %l163 = alloca ptr
  %l167 = alloca { i64, [4 x i64] }
  %l168 = alloca { i64, ptr }
  %l171 = alloca { i64, ptr }
  %l176 = alloca ptr
  %l181 = alloca { i64, ptr }
  %l186 = alloca { i64, ptr }
  %l189 = alloca ptr
  %l191 = alloca { i64, ptr }
  %l194 = alloca { i64, ptr }
  %l205 = alloca ptr
  %l209 = alloca { i64, ptr }
  %l211 = alloca i1
  %l212 = alloca ptr
  %l213 = alloca { i64, ptr }
  %l215 = alloca { i64, ptr }
  %l219 = alloca ptr
  %l220 = alloca { i64, ptr }
  %l221 = alloca { i64, ptr }
  %l223 = alloca { i64, ptr }
  %l226 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s23 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/mir:Call" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t9 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t9, ptr %l3, !tbaa !23
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d371, i32 0, i32 1) }, ptr %l32, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t13 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 0
  %t14 = load { i64, [7 x i64] }, ptr %t13
  store { i64, [7 x i64] } %t14, ptr %l5
  %t16 = load { i64, [7 x i64] }, ptr %l5
  %t18 = extractvalue { i64, [7 x i64] } %t16, 0
  %t19 = icmp eq i64 %t18, 0
  br i1 %t19, label %bb1, label %bb2
bb1:
  %t21 = getelementptr { i64, [7 x i64] }, ptr %l5, i32 0, i32 1
  %t22 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t21, i32 0, i32 0
  %t23 = load { i64, [2 x i64] }, ptr %t22
  store { i64, [2 x i64] } %t23, ptr %l6
  %t25 = getelementptr { i64, [7 x i64] }, ptr %l5, i32 0, i32 1
  %t26 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t25, i32 0, i32 1
  %t27 = load i32, ptr %t26
  store i32 %t27, ptr %l7, !tbaa !23
  br label %bb3
bb2:
  br label %bb19
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/emit:fnEm", ptr %t29, i32 0, i32 0
  %t32 = load ptr, ptr %t31, !tbaa !29
  store ptr %t32, ptr %l40, !tbaa !29
  %t33 = load { i64, [2 x i64] }, ptr %l6
  %t34 = load ptr, ptr %l40, !tbaa !29
  %t35 = call ptr @__olang_scope_or(ptr %v1, ptr %t34)
  %t36 = call ptr @__olang_scope_hold(ptr %t35)
  %t37 = ptrtoint ptr %t36 to i64
  %t39 = inttoptr i64 %t37 to ptr
  %t40 = load ptr, ptr %l40, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewant(ptr %t39, ptr %t40, { i64, [2 x i64] } %t33)
  br label %bb4
bb4:
  %t42 = load i32, ptr %l7, !tbaa !23
  store i32 %t42, ptr %l3, !tbaa !23
  %t44 = call ptr @__olang_scope_hold(ptr %s0)
  %t45 = ptrtoint ptr %t44 to i64
  store i64 %t45, ptr %l44, !tbaa !24
  %t46 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2etailCall_2elocal_2e4
  br i1 %t46, label %bb5, label %bb6
bb5:
  %t48 = call ptr @__olang_region_make(ptr %s0)
  %t49 = ptrtoint ptr %t48 to i64
  store i64 %t49, ptr %l44, !tbaa !24
  br label %bb6
bb6:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/emit:fnEm", ptr %t50, i32 0, i32 0
  %t53 = load ptr, ptr %t52, !tbaa !29
  store ptr %t53, ptr %l47, !tbaa !29
  %t54 = load { i64, [2 x i64] }, ptr %l6
  %t55 = load ptr, ptr %l47, !tbaa !29
  %t56 = call ptr @__olang_scope_or(ptr %v1, ptr %t55)
  %t57 = call ptr @__olang_scope_hold(ptr %t56)
  %t58 = ptrtoint ptr %t57 to i64
  %t60 = inttoptr i64 %t58 to ptr
  %t61 = load ptr, ptr %l47, !tbaa !29
  %t63 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %t60, ptr %s1, ptr %t61, { i64, [2 x i64] } %t54)
  store { i64, ptr } %t63, ptr %l50
  br label %bb7
bb7:
  %t64 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d372, i32 0, i32 1) }, 1
  %t65 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d372, i32 0, i32 1) }, 0
  %t66 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 1
  %t68 = extractvalue { i64, ptr } %t66, 0
  %t69 = add i64 %t65, %t68
  %t70 = load i64, ptr %l44
  %t71 = inttoptr i64 %t70 to ptr
  %t72 = call ptr @__olang_held_alloc(ptr %t71, i64 %t69)
  call void @olang_textcopy(ptr %t72, ptr %t64, i64 %t65)
  %t73 = getelementptr i8, ptr %t72, i64 %t65
  call void @olang_textcopy(ptr %t73, ptr %t67, i64 %t68)
  %t74 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t72, 1
  store { i64, ptr } %t75, ptr %l51, !tbaa !27
  %t76 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2etailCall_2elocal_2e4
  br i1 %t76, label %bb8, label %bb9
bb8:
  %t78 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 0
  %t81 = icmp eq i64 %t79, 0
  br i1 %t81, label %bb10, label %bb11
bb9:
  %t83 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t83, ptr %l55, !tbaa !27
  %t84 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t84, ptr %l4, !tbaa !27
  %t85 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2etailCall_2elocal_2e4
  br i1 %t85, label %bb12, label %bb13
bb10:
  store { i64, ptr } zeroinitializer, ptr %l51, !tbaa !27
  br label %bb11
bb11:
  %t87 = load i64, ptr %l44
  %t88 = inttoptr i64 %t87 to ptr
  %t89 = load { i64, ptr }, ptr %l51
  %t90 = extractvalue { i64, ptr } %t89, 1
  %t91 = call ptr @__olang_region_or(ptr %t90, ptr null)
  %t92 = icmp ne ptr %t91, null
  %t93 = select i1 %t92, ptr %t91, ptr null
  call void @__olang_region_settle_in(ptr %t88, ptr %t93)
  br label %bb9
bb12:
  %t94 = load { i64, ptr }, ptr %l55
  %t95 = extractvalue { i64, ptr } %t94, 1
  call void @__olang_region_release(ptr %t95)
  store { i64, ptr } zeroinitializer, ptr %l55
  br label %bb13
bb13:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/emit:fnEm", ptr %t96, i32 0, i32 0
  %t99 = load ptr, ptr %t98, !tbaa !29
  store ptr %t99, ptr %l58, !tbaa !29
  %t100 = load { i64, [2 x i64] }, ptr %l6
  %t101 = load ptr, ptr %l58, !tbaa !29
  %t102 = call ptr @__olang_scope_or(ptr %v1, ptr %t101)
  %t103 = call ptr @__olang_scope_hold(ptr %t102)
  %t104 = ptrtoint ptr %t103 to i64
  %t106 = inttoptr i64 %t104 to ptr
  %t107 = load ptr, ptr %l58, !tbaa !29
  %t109 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehasEnv(ptr %t106, ptr %t107, { i64, [2 x i64] } %t100)
  store i1 %t109, ptr %l61
  br label %bb14
bb14:
  %t110 = load i1, ptr %l61, !tbaa !21
  br i1 %t110, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t111 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s3, ptr %v1, ptr %t111, { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d373, i32 0, i32 1) })
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s1)
  br label %bb26
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb25
bb22:
  store %olang.scope zeroinitializer, ptr %s4
  %t113 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s4, ptr %v1, ptr %t113, { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d374, i32 0, i32 1) })
  br label %bb23
bb23:
  %t115 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s4, ptr %v1, ptr %t115, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d375, i32 0, i32 1) })
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb25:
  call void @__olang_check_failed(ptr @olang_loc_5928719bf5ddeb28_6f82e9f6c6163cdc)
  unreachable
bb26:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/emit:fnEm", ptr %t117, i32 0, i32 0
  %t120 = load ptr, ptr %t119, !tbaa !29
  store ptr %t120, ptr %l66, !tbaa !29
  %t121 = load i32, ptr %l3, !tbaa !23
  %t122 = load ptr, ptr %l66, !tbaa !29
  %t123 = call ptr @__olang_scope_or(ptr %v1, ptr %t122)
  %t124 = call ptr @__olang_scope_hold(ptr %t123)
  %t125 = ptrtoint ptr %t124 to i64
  %t127 = inttoptr i64 %t125 to ptr
  %t128 = load ptr, ptr %l66, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2esignature(ptr %t127, ptr %t128, i32 %t121)
  br label %bb27
bb27:
  %t130 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t130, ptr %l69
  br label %bb28
bb28:
  %t131 = load %"std/prelude/text:StringBuilder", ptr %l69
  store %"std/prelude/text:StringBuilder" %t131, ptr %l8
  store i1 true, ptr %l9, !tbaa !21
  store i32 0, ptr %l10, !tbaa !23
  %t132 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 2
  %t133 = getelementptr %"compiler/mir:Range", ptr %t132, i32 0, i32 1
  %t134 = load i32, ptr %t133, !tbaa !23
  store i32 %t134, ptr %l11, !tbaa !23
  store i32 1, ptr %l12, !tbaa !23
  %t136 = load i32, ptr %l11, !tbaa !23
  %t137 = load i32, ptr %l10, !tbaa !23
  %t140 = icmp sgt i32 %t136, %t137
  br i1 %t140, label %bb29, label %bb30
bb29:
  %t142 = load i32, ptr %l12, !tbaa !23
  %t144 = icmp sgt i32 %t142, 0
  br i1 %t144, label %bb31, label %bb32
bb30:
  store i32 0, ptr %l74, !tbaa !23
  br label %bb34
bb31:
  %t146 = load i32, ptr %l11, !tbaa !23
  %t147 = load i32, ptr %l10, !tbaa !23
  %t150 = sub i32 %t146, %t147
  %t151 = load i32, ptr %l12, !tbaa !23
  %t154 = add i32 %t150, %t151
  %t156 = sub i32 %t154, 1
  %t157 = load i32, ptr %l12, !tbaa !23
  %t160 = sdiv i32 %t156, %t157
  store i32 %t160, ptr %l77, !tbaa !23
  br label %bb33
bb32:
  store i32 0, ptr %l77, !tbaa !23
  br label %bb33
bb33:
  %t162 = load i32, ptr %l77, !tbaa !23
  store i32 %t162, ptr %l74, !tbaa !23
  br label %bb34
bb34:
  %t163 = load i32, ptr %l74, !tbaa !23
  store i32 %t163, ptr %l13, !tbaa !23
  store i32 0, ptr %l14, !tbaa !23
  br label %bb35
bb35:
  store %olang.scope zeroinitializer, ptr %s6
  %t164 = load i32, ptr %l14, !tbaa !23
  %t165 = load i32, ptr %l13, !tbaa !23
  %t168 = icmp slt i32 %t164, %t165
  %t170 = xor i1 %t168, true
  br i1 %t170, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s6)
  br label %bb47
bb37:
  br label %bb38
bb38:
  %t172 = load i32, ptr %l10, !tbaa !23
  %t173 = load i32, ptr %l14, !tbaa !23
  %t174 = load i32, ptr %l12, !tbaa !23
  %t177 = mul i32 %t173, %t174
  %t180 = add i32 %t172, %t177
  store i32 %t180, ptr %l15, !tbaa !23
  %t182 = load i1, ptr %l9, !tbaa !21
  %t184 = xor i1 %t182, true
  br i1 %t184, label %bb39, label %bb40
bb39:
  store %olang.scope zeroinitializer, ptr %s7
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %l8, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d376, i32 0, i32 1) })
  br label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_scope_close(ptr %s7)
  br label %bb42
bb42:
  store i1 false, ptr %l9, !tbaa !21
  store ptr %l8, ptr %l98, !tbaa !29
  %t187 = load ptr, ptr %l0, !tbaa !29
  store ptr %t187, ptr %l99, !tbaa !29
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/emit:fnEm", ptr %t188, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !29
  %t193 = getelementptr %"compiler/mir:Fn", ptr %t191, i32 0, i32 12
  store ptr %t193, ptr %l102, !tbaa !29
  %t194 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 2
  %t195 = getelementptr %"compiler/mir:Range", ptr %t194, i32 0, i32 0
  %t196 = load i32, ptr %t195, !tbaa !23
  %t198 = sext i32 %t196 to i64
  %t199 = load i32, ptr %l15, !tbaa !23
  %t201 = sext i32 %t199 to i64
  %t204 = add i64 %t198, %t201
  %t205 = load ptr, ptr %l102, !tbaa !29
  %t206 = call ptr @__olang_scope_or(ptr %v2, ptr %t205)
  %t207 = call ptr @__olang_scope_hold(ptr %t206)
  %t208 = ptrtoint ptr %t207 to i64
  %t210 = inttoptr i64 %t208 to ptr
  %t211 = load ptr, ptr %l102, !tbaa !29
  %t213 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %t210, ptr %t211, i64 %t204)
  store { i64, [1 x i64] } %t213, ptr %l109
  br label %bb43
bb43:
  %t214 = load ptr, ptr %l99, !tbaa !29
  %t215 = load { i64, [1 x i64] }, ptr %l109
  %t216 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %s6, ptr %v1, ptr %v2, ptr %t214, { i64, [1 x i64] } %t215)
  store { i64, ptr } %t216, ptr %l110
  br label %bb44
bb44:
  %t217 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d377, i32 0, i32 1) }, 1
  %t218 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d377, i32 0, i32 1) }, 0
  %t219 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t220 = extractvalue { i64, ptr } %t219, 1
  %t221 = extractvalue { i64, ptr } %t219, 0
  %t222 = add i64 %t218, %t221
  %t223 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t222)
  call void @olang_textcopy(ptr %t223, ptr %t217, i64 %t218)
  %t224 = getelementptr i8, ptr %t223, i64 %t218
  call void @olang_textcopy(ptr %t224, ptr %t220, i64 %t221)
  %t225 = insertvalue { i64, ptr } undef, i64 %t222, 0
  %t226 = insertvalue { i64, ptr } %t225, ptr %t223, 1
  %t228 = load ptr, ptr %l98, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %t228, { i64, ptr } %t226)
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s6)
  br label %bb46
bb46:
  %t230 = load i32, ptr %l14, !tbaa !23
  %t233 = add i32 %t230, 1
  store i32 %t233, ptr %l14, !tbaa !23
  br label %bb35
bb47:
  %t235 = load ptr, ptr %l2, !tbaa !29
  store ptr %t235, ptr %l116, !tbaa !29
  %t236 = load ptr, ptr %l2, !tbaa !29
  store ptr %t236, ptr %l117, !tbaa !29
  %t237 = load i32, ptr %l3, !tbaa !23
  %t238 = load ptr, ptr %l117, !tbaa !29
  %t239 = call ptr @__olang_scope_or(ptr %v1, ptr %t238)
  %t240 = call ptr @__olang_scope_hold(ptr %t239)
  %t241 = ptrtoint ptr %t240 to i64
  %t243 = inttoptr i64 %t241 to ptr
  %t244 = load ptr, ptr %l117, !tbaa !29
  %t246 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %t243, ptr %t244, i32 %t237)
  store i32 %t246, ptr %l120
  br label %bb48
bb48:
  %t247 = load ptr, ptr %l116, !tbaa !29
  %t248 = call ptr @__olang_scope_or(ptr %v1, ptr %t247)
  %t249 = call ptr @__olang_scope_hold(ptr %t248)
  %t250 = ptrtoint ptr %t249 to i64
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t253 = getelementptr %"compiler/emit:fnEm", ptr %t251, i32 0, i32 0
  %t254 = load ptr, ptr %t253, !tbaa !29
  %t256 = call ptr @__olang_scope_or(ptr %v1, ptr %t254)
  %t257 = call ptr @__olang_scope_hold(ptr %t256)
  %t258 = ptrtoint ptr %t257 to i64
  %t260 = inttoptr i64 %t250 to ptr
  %t262 = inttoptr i64 %t258 to ptr
  %t263 = load ptr, ptr %l116, !tbaa !29
  %t264 = load i32, ptr %l120, !tbaa !23
  %t265 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t260, ptr %t262, ptr %t263, i32 %t264)
  store { i64, ptr } %t265, ptr %l125
  br label %bb49
bb49:
  %t266 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t266, ptr %l16, !tbaa !27
  %t267 = load ptr, ptr %l2, !tbaa !29
  store ptr %t267, ptr %l126, !tbaa !29
  %t268 = load i32, ptr %l3, !tbaa !23
  %t269 = load ptr, ptr %l126, !tbaa !29
  %t270 = call ptr @__olang_scope_or(ptr %v1, ptr %t269)
  %t271 = call ptr @__olang_scope_hold(ptr %t270)
  %t272 = ptrtoint ptr %t271 to i64
  %t274 = inttoptr i64 %t272 to ptr
  %t275 = load ptr, ptr %l126, !tbaa !29
  %t277 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePassing(ptr %t274, ptr %s0, ptr %t275, i32 %t268)
  store { i64, ptr } %t277, ptr %l129
  br label %bb50
bb50:
  %t278 = load { i64, ptr }, ptr %l129, !tbaa !27
  store { i64, ptr } %t278, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t279 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t281 = extractvalue { i64, ptr } %t279, 0
  store i64 %t281, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t283 = load i64, ptr %l19, !tbaa !24
  %t284 = load i64, ptr %l18, !tbaa !24
  %t287 = icmp sgt i64 %t283, %t284
  br i1 %t287, label %bb51, label %bb52
bb51:
  %t289 = load i64, ptr %l20, !tbaa !24
  %t291 = icmp sgt i64 %t289, 0
  br i1 %t291, label %bb53, label %bb54
bb52:
  store i64 0, ptr %l135, !tbaa !24
  br label %bb56
bb53:
  %t293 = load i64, ptr %l19, !tbaa !24
  %t294 = load i64, ptr %l18, !tbaa !24
  %t297 = sub i64 %t293, %t294
  %t298 = load i64, ptr %l20, !tbaa !24
  %t301 = add i64 %t297, %t298
  %t303 = sub i64 %t301, 1
  %t304 = load i64, ptr %l20, !tbaa !24
  %t307 = sdiv i64 %t303, %t304
  store i64 %t307, ptr %l138, !tbaa !24
  br label %bb55
bb54:
  store i64 0, ptr %l138, !tbaa !24
  br label %bb55
bb55:
  %t309 = load i64, ptr %l138, !tbaa !24
  store i64 %t309, ptr %l135, !tbaa !24
  br label %bb56
bb56:
  %t310 = load i64, ptr %l135, !tbaa !24
  store i64 %t310, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb57
bb57:
  store %olang.scope zeroinitializer, ptr %s11
  %t311 = load i64, ptr %l22, !tbaa !24
  %t312 = load i64, ptr %l21, !tbaa !24
  %t315 = icmp slt i64 %t311, %t312
  %t317 = xor i1 %t315, true
  br i1 %t317, label %bb58, label %bb59
bb58:
  call void @__olang_scope_close(ptr %s11)
  br label %bb86
bb59:
  br label %bb60
bb60:
  %t319 = load i64, ptr %l18, !tbaa !24
  %t320 = load i64, ptr %l22, !tbaa !24
  %t321 = load i64, ptr %l20, !tbaa !24
  %t324 = mul i64 %t320, %t321
  %t327 = add i64 %t319, %t324
  store i64 %t327, ptr %l23, !tbaa !24
  %t329 = load i1, ptr %l9, !tbaa !21
  %t331 = xor i1 %t329, true
  br i1 %t331, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s12
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s12, ptr %l8, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d378, i32 0, i32 1) })
  br label %bb63
bb62:
  br label %bb64
bb63:
  call void @__olang_scope_close(ptr %s12)
  br label %bb64
bb64:
  store i1 false, ptr %l9, !tbaa !21
  %t334 = load i64, ptr %l23, !tbaa !24
  %t336 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t337 = load ptr, ptr %t336, !tbaa !27
  %t338 = getelementptr i8, ptr %t337, i64 %t334
  %t339 = load i8, ptr %t338, !tbaa !32
  %t341 = icmp eq i8 %t339, 109
  br i1 %t341, label %bb65, label %bb66
bb65:
  store %olang.scope zeroinitializer, ptr %s13
  %t343 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s13, ptr %v1, ptr %t343, { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d379, i32 0, i32 1) })
  br label %bb67
bb66:
  br label %bb68
bb67:
  call void @__olang_scope_close(ptr %s13)
  br label %bb68
bb68:
  %t345 = load ptr, ptr %l0, !tbaa !29
  store ptr %t345, ptr %l163, !tbaa !29
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t347 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 1
  %t348 = load %"compiler/mir:Range", ptr %t347
  %t349 = load i64, ptr %l23, !tbaa !24
  %t353 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %v2, ptr %t346, %"compiler/mir:Range" %t348, i64 %t349)
  store { i64, [4 x i64] } %t353, ptr %l167
  br label %bb69
bb69:
  %t354 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t354, ptr %l168, !tbaa !27
  %t355 = load i64, ptr %l23, !tbaa !24
  %t357 = getelementptr { i64, ptr }, ptr %l168, i32 0, i32 1
  %t358 = load ptr, ptr %t357, !tbaa !27
  %t359 = getelementptr i32, ptr %t358, i64 %t355
  %t360 = load i32, ptr %t359, !tbaa !33
  %t361 = load ptr, ptr %l163, !tbaa !29
  %t362 = load { i64, [4 x i64] }, ptr %l167
  %t364 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s11, ptr %v2, ptr %v1, ptr %t361, { i64, [4 x i64] } %t362, i32 %t360)
  store { i64, ptr } %t364, ptr %l171
  br label %bb70
bb70:
  %t365 = load { i64, ptr }, ptr %l171, !tbaa !27
  store { i64, ptr } %t365, ptr %l24, !tbaa !27
  %t366 = load i64, ptr %l23, !tbaa !24
  %t368 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t369 = load ptr, ptr %t368, !tbaa !27
  %t370 = getelementptr i8, ptr %t369, i64 %t366
  %t371 = load i8, ptr %t370, !tbaa !32
  %t375 = icmp eq i8 %t371, 115
  br i1 %t375, label %bb71, label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb77
bb73:
  store %olang.scope zeroinitializer, ptr %s14
  store ptr %l8, ptr %l176, !tbaa !29
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t378 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t379 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d380, i32 0, i32 1) }, 1
  %t380 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d380, i32 0, i32 1) }, 0
  %t382 = extractvalue { i64, ptr } %t378, 1
  %t383 = extractvalue { i64, ptr } %t378, 0
  %t384 = add i64 %t380, %t383
  %t385 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d381, i32 0, i32 1) }, 1
  %t386 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d381, i32 0, i32 1) }, 0
  %t387 = add i64 %t384, %t386
  %t388 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t387)
  call void @olang_textcopy(ptr %t388, ptr %t379, i64 %t380)
  %t389 = getelementptr i8, ptr %t388, i64 %t380
  call void @olang_textcopy(ptr %t389, ptr %t382, i64 %t383)
  %t390 = getelementptr i8, ptr %t389, i64 %t383
  call void @olang_textcopy(ptr %t390, ptr %t385, i64 %t386)
  %t391 = insertvalue { i64, ptr } undef, i64 %t387, 0
  %t392 = insertvalue { i64, ptr } %t391, ptr %t388, 1
  %t396 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s14, ptr %s14, ptr %v1, ptr %t377, { i64, ptr } %t392)
  store { i64, ptr } %t396, ptr %l181
  br label %bb74
bb74:
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t398 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t399 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d382, i32 0, i32 1) }, 1
  %t400 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d382, i32 0, i32 1) }, 0
  %t402 = extractvalue { i64, ptr } %t398, 1
  %t403 = extractvalue { i64, ptr } %t398, 0
  %t404 = add i64 %t400, %t403
  %t405 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d383, i32 0, i32 1) }, 1
  %t406 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d383, i32 0, i32 1) }, 0
  %t407 = add i64 %t404, %t406
  %t408 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t407)
  call void @olang_textcopy(ptr %t408, ptr %t399, i64 %t400)
  %t409 = getelementptr i8, ptr %t408, i64 %t400
  call void @olang_textcopy(ptr %t409, ptr %t402, i64 %t403)
  %t410 = getelementptr i8, ptr %t409, i64 %t403
  call void @olang_textcopy(ptr %t410, ptr %t405, i64 %t406)
  %t411 = insertvalue { i64, ptr } undef, i64 %t407, 0
  %t412 = insertvalue { i64, ptr } %t411, ptr %t408, 1
  %t416 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s14, ptr %s14, ptr %v1, ptr %t397, { i64, ptr } %t412)
  store { i64, ptr } %t416, ptr %l186
  br label %bb75
bb75:
  %t417 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d384, i32 0, i32 1) }, 1
  %t418 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d384, i32 0, i32 1) }, 0
  %t419 = load { i64, ptr }, ptr %l181, !tbaa !27
  %t420 = extractvalue { i64, ptr } %t419, 1
  %t421 = extractvalue { i64, ptr } %t419, 0
  %t422 = add i64 %t418, %t421
  %t423 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d385, i32 0, i32 1) }, 1
  %t424 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d385, i32 0, i32 1) }, 0
  %t425 = add i64 %t422, %t424
  %t426 = load { i64, ptr }, ptr %l186, !tbaa !27
  %t427 = extractvalue { i64, ptr } %t426, 1
  %t428 = extractvalue { i64, ptr } %t426, 0
  %t429 = add i64 %t425, %t428
  %t430 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t429)
  call void @olang_textcopy(ptr %t430, ptr %t417, i64 %t418)
  %t431 = getelementptr i8, ptr %t430, i64 %t418
  call void @olang_textcopy(ptr %t431, ptr %t420, i64 %t421)
  %t432 = getelementptr i8, ptr %t431, i64 %t421
  call void @olang_textcopy(ptr %t432, ptr %t423, i64 %t424)
  %t433 = getelementptr i8, ptr %t432, i64 %t424
  call void @olang_textcopy(ptr %t433, ptr %t427, i64 %t428)
  %t434 = insertvalue { i64, ptr } undef, i64 %t429, 0
  %t435 = insertvalue { i64, ptr } %t434, ptr %t430, 1
  %t437 = load ptr, ptr %l176, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s14, ptr %t437, { i64, ptr } %t435)
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s14)
  br label %bb84
bb77:
  br i1 true, label %bb78, label %bb79
bb78:
  br label %bb80
bb79:
  br label %bb83
bb80:
  store %olang.scope zeroinitializer, ptr %s18
  store ptr %l8, ptr %l189, !tbaa !29
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t440 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t440, ptr %l191, !tbaa !27
  %t441 = load i64, ptr %l23, !tbaa !24
  %t443 = getelementptr { i64, ptr }, ptr %l191, i32 0, i32 1
  %t444 = load ptr, ptr %t443, !tbaa !27
  %t445 = getelementptr i32, ptr %t444, i64 %t441
  %t446 = load i32, ptr %t445, !tbaa !33
  %t449 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s18, ptr %v1, ptr %t439, i32 %t446)
  store { i64, ptr } %t449, ptr %l194
  br label %bb81
bb81:
  %t450 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t451 = load { i64, ptr }, ptr %l194, !tbaa !27
  %t452 = extractvalue { i64, ptr } %t451, 1
  %t453 = extractvalue { i64, ptr } %t451, 0
  %t454 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d386, i32 0, i32 1) }, 1
  %t455 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d386, i32 0, i32 1) }, 0
  %t456 = add i64 %t453, %t455
  %t458 = extractvalue { i64, ptr } %t450, 1
  %t459 = extractvalue { i64, ptr } %t450, 0
  %t460 = add i64 %t456, %t459
  %t461 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t460)
  call void @olang_textcopy(ptr %t461, ptr %t452, i64 %t453)
  %t462 = getelementptr i8, ptr %t461, i64 %t453
  call void @olang_textcopy(ptr %t462, ptr %t454, i64 %t455)
  %t463 = getelementptr i8, ptr %t462, i64 %t455
  call void @olang_textcopy(ptr %t463, ptr %t458, i64 %t459)
  %t464 = insertvalue { i64, ptr } undef, i64 %t460, 0
  %t465 = insertvalue { i64, ptr } %t464, ptr %t461, 1
  %t467 = load ptr, ptr %l189, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s18, ptr %t467, { i64, ptr } %t465)
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s18)
  br label %bb84
bb83:
  call void @__olang_check_failed(ptr @olang_loc_51f36d50f4dfa9f9_6a3d5d7fb2ed60d)
  unreachable
bb84:
  call void @__olang_scope_close(ptr %s11)
  br label %bb85
bb85:
  %t469 = load i64, ptr %l22, !tbaa !24
  %t472 = add i64 %t469, 1
  store i64 %t472, ptr %l22, !tbaa !24
  br label %bb57
bb86:
  %t474 = load ptr, ptr %l0, !tbaa !29
  %t476 = getelementptr %"compiler/emit:fnEm", ptr %t474, i32 0, i32 14
  store i1 true, ptr %t476, !tbaa !21
  %t477 = load ptr, ptr %l0, !tbaa !29
  %t479 = getelementptr %"compiler/emit:fnEm", ptr %t477, i32 0, i32 5
  %t480 = load { i64, ptr }, ptr @G_2ecompiler_2femit_2eBigCloseMark, !tbaa !27
  %t481 = load ptr, ptr @__olang_prog_scope
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %t481, ptr %t479, { i64, ptr } %t480)
  br label %bb87
bb87:
  %t484 = load ptr, ptr %l2, !tbaa !29
  store ptr %t484, ptr %l205, !tbaa !29
  %t485 = load i32, ptr %l3, !tbaa !23
  %t486 = load ptr, ptr %l205, !tbaa !29
  %t487 = call ptr @__olang_scope_or(ptr %v1, ptr %t486)
  %t488 = call ptr @__olang_scope_hold(ptr %t487)
  %t489 = ptrtoint ptr %t488 to i64
  %t491 = inttoptr i64 %t489 to ptr
  %t493 = inttoptr i64 0 to ptr
  %t494 = load ptr, ptr %l205, !tbaa !29
  %t496 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %t491, ptr %s0, ptr %t493, ptr %t494, i32 %t485)
  store { i64, ptr } %t496, ptr %l209
  br label %bb88
bb88:
  %t497 = load { i64, ptr }, ptr %l209, !tbaa !27
  store { i64, ptr } %t497, ptr %l26, !tbaa !27
  %t498 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t500 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t498, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d387, i32 0, i32 1) })
  store i1 %t500, ptr %l211
  br label %bb89
bb89:
  %t501 = load i1, ptr %l211, !tbaa !21
  br i1 %t501, label %bb90, label %bb91
bb90:
  store %olang.scope zeroinitializer, ptr %s21
  %t502 = load ptr, ptr %l0, !tbaa !29
  store ptr %t502, ptr %l212, !tbaa !29
  %t503 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t503, ptr %l213, !tbaa !27
  %t505 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s21, ptr %l8)
  store { i64, ptr } %t505, ptr %l215
  br label %bb92
bb91:
  store %olang.scope zeroinitializer, ptr %s23
  %t506 = load ptr, ptr %l0, !tbaa !29
  store ptr %t506, ptr %l219, !tbaa !29
  %t507 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t507, ptr %l220, !tbaa !27
  %t508 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t508, ptr %l221, !tbaa !27
  %t510 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s23, ptr %l8)
  store { i64, ptr } %t510, ptr %l223
  br label %bb95
bb92:
  %t511 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d388, i32 0, i32 1) }, 1
  %t512 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d388, i32 0, i32 1) }, 0
  %t513 = load { i64, ptr }, ptr %l213, !tbaa !27
  %t514 = extractvalue { i64, ptr } %t513, 1
  %t515 = extractvalue { i64, ptr } %t513, 0
  %t516 = add i64 %t512, %t515
  %t517 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d389, i32 0, i32 1) }, 1
  %t518 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d389, i32 0, i32 1) }, 0
  %t519 = add i64 %t516, %t518
  %t520 = load { i64, ptr }, ptr %l215, !tbaa !27
  %t521 = extractvalue { i64, ptr } %t520, 1
  %t522 = extractvalue { i64, ptr } %t520, 0
  %t523 = add i64 %t519, %t522
  %t524 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d390, i32 0, i32 1) }, 1
  %t525 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d390, i32 0, i32 1) }, 0
  %t526 = add i64 %t523, %t525
  %t527 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t526)
  call void @olang_textcopy(ptr %t527, ptr %t511, i64 %t512)
  %t528 = getelementptr i8, ptr %t527, i64 %t512
  call void @olang_textcopy(ptr %t528, ptr %t514, i64 %t515)
  %t529 = getelementptr i8, ptr %t528, i64 %t515
  call void @olang_textcopy(ptr %t529, ptr %t517, i64 %t518)
  %t530 = getelementptr i8, ptr %t529, i64 %t518
  call void @olang_textcopy(ptr %t530, ptr %t521, i64 %t522)
  %t531 = getelementptr i8, ptr %t530, i64 %t522
  call void @olang_textcopy(ptr %t531, ptr %t524, i64 %t525)
  %t532 = insertvalue { i64, ptr } undef, i64 %t526, 0
  %t533 = insertvalue { i64, ptr } %t532, ptr %t527, 1
  %t535 = load ptr, ptr %l212, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s21, ptr %v1, ptr %t535, { i64, ptr } %t533)
  br label %bb93
bb93:
  %t537 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s21, ptr %v1, ptr %t537, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d391, i32 0, i32 1) })
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s21)
  br label %bb98
bb95:
  %t539 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d392, i32 0, i32 1) }, 1
  %t540 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d392, i32 0, i32 1) }, 0
  %t541 = load { i64, ptr }, ptr %l220, !tbaa !27
  %t542 = extractvalue { i64, ptr } %t541, 1
  %t543 = extractvalue { i64, ptr } %t541, 0
  %t544 = add i64 %t540, %t543
  %t545 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d393, i32 0, i32 1) }, 1
  %t546 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d393, i32 0, i32 1) }, 0
  %t547 = add i64 %t544, %t546
  %t548 = load { i64, ptr }, ptr %l221, !tbaa !27
  %t549 = extractvalue { i64, ptr } %t548, 1
  %t550 = extractvalue { i64, ptr } %t548, 0
  %t551 = add i64 %t547, %t550
  %t552 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d394, i32 0, i32 1) }, 1
  %t553 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d394, i32 0, i32 1) }, 0
  %t554 = add i64 %t551, %t553
  %t555 = load { i64, ptr }, ptr %l223, !tbaa !27
  %t556 = extractvalue { i64, ptr } %t555, 1
  %t557 = extractvalue { i64, ptr } %t555, 0
  %t558 = add i64 %t554, %t557
  %t559 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d395, i32 0, i32 1) }, 1
  %t560 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d395, i32 0, i32 1) }, 0
  %t561 = add i64 %t558, %t560
  %t562 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t561)
  call void @olang_textcopy(ptr %t562, ptr %t539, i64 %t540)
  %t563 = getelementptr i8, ptr %t562, i64 %t540
  call void @olang_textcopy(ptr %t563, ptr %t542, i64 %t543)
  %t564 = getelementptr i8, ptr %t563, i64 %t543
  call void @olang_textcopy(ptr %t564, ptr %t545, i64 %t546)
  %t565 = getelementptr i8, ptr %t564, i64 %t546
  call void @olang_textcopy(ptr %t565, ptr %t549, i64 %t550)
  %t566 = getelementptr i8, ptr %t565, i64 %t550
  call void @olang_textcopy(ptr %t566, ptr %t552, i64 %t553)
  %t567 = getelementptr i8, ptr %t566, i64 %t553
  call void @olang_textcopy(ptr %t567, ptr %t556, i64 %t557)
  %t568 = getelementptr i8, ptr %t567, i64 %t557
  call void @olang_textcopy(ptr %t568, ptr %t559, i64 %t560)
  %t569 = insertvalue { i64, ptr } undef, i64 %t561, 0
  %t570 = insertvalue { i64, ptr } %t569, ptr %t562, 1
  %t572 = load ptr, ptr %l219, !tbaa !29
  %t574 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s23, ptr %s23, ptr %v1, ptr %t572, { i64, ptr } %t570)
  store { i64, ptr } %t574, ptr %l226
  br label %bb96
bb96:
  %t575 = load { i64, ptr }, ptr %l226, !tbaa !27
  %t576 = load ptr, ptr %l0, !tbaa !29
  %t577 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t579 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d396, i32 0, i32 1) }, 1
  %t580 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d396, i32 0, i32 1) }, 0
  %t582 = extractvalue { i64, ptr } %t577, 1
  %t583 = extractvalue { i64, ptr } %t577, 0
  %t584 = add i64 %t580, %t583
  %t585 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d397, i32 0, i32 1) }, 1
  %t586 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d397, i32 0, i32 1) }, 0
  %t587 = add i64 %t584, %t586
  %t589 = extractvalue { i64, ptr } %t575, 1
  %t590 = extractvalue { i64, ptr } %t575, 0
  %t591 = add i64 %t587, %t590
  %t592 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t591)
  call void @olang_textcopy(ptr %t592, ptr %t579, i64 %t580)
  %t593 = getelementptr i8, ptr %t592, i64 %t580
  call void @olang_textcopy(ptr %t593, ptr %t582, i64 %t583)
  %t594 = getelementptr i8, ptr %t593, i64 %t583
  call void @olang_textcopy(ptr %t594, ptr %t585, i64 %t586)
  %t595 = getelementptr i8, ptr %t594, i64 %t586
  call void @olang_textcopy(ptr %t595, ptr %t589, i64 %t590)
  %t596 = insertvalue { i64, ptr } undef, i64 %t591, 0
  %t597 = insertvalue { i64, ptr } %t596, ptr %t592, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s23, ptr %v1, ptr %t576, { i64, ptr } %t597)
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s23)
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2etextInto(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca { i64, [15 x i64] }
  %l4 = alloca { i64, [1 x i64] }
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i1
  %l12 = alloca i1
  %l19 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 20}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [21 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t12, i32 0, i32 2
  %t14 = load { i64, [15 x i64] }, ptr %t13
  store { i64, [15 x i64] } %t14, ptr %l3
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t16 = load { i64, [15 x i64] }, ptr %l3
  %t18 = extractvalue { i64, [15 x i64] } %t16, 0
  %t19 = icmp eq i64 %t18, 12
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t21 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t22 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t21, i32 0, i32 0
  %t23 = load { i64, [1 x i64] }, ptr %t22
  store { i64, [1 x i64] } %t23, ptr %l4
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t26 = load { i64, [1 x i64] }, ptr %l4
  %t31 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erefIs(ptr %v0, ptr %a0, { i64, [1 x i64] } %t26, i64 %a2)
  store i1 %t31, ptr %l19
  br label %bb9
bb9:
  %t32 = load i1, ptr %l19, !tbaa !21
  store i1 %t32, ptr %l12, !tbaa !21
  br label %bb15
bb10:
  br i1 true, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_7415e49a8c587c29_9b5b9278cce8582d)
  unreachable
bb15:
  %t33 = load i1, ptr %l12, !tbaa !21
  store i1 %t33, ptr %l5, !tbaa !21
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_4d350c16cffa958_63aa1cf05aa787c)
  unreachable
bb21:
  %t34 = load i1, ptr %l5, !tbaa !21
  store i1 %t34, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2ewalkEnd(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l7 = alloca i1
  %l9 = alloca i1
  %l10 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i32
  %l17 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 34
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %t4)
  store i1 %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load i1, ptr %l7, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb8
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/emit:fnEm", ptr %t11, i32 0, i32 35
  %t17 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %t13, i64 %a2)
  %t18 = extractvalue { i32, i1 } %t17, 1
  %t19 = extractvalue { i32, i1 } %t17, 0
  store i32 %t19, ptr %l15
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb5, label %ok.21, !prof !99
ok.21:
  store i1 %t18, ptr %l14
  br label %bb4
bb4:
  %t22 = load i1, ptr %l14, !tbaa !21
  store i1 %t22, ptr %l10, !tbaa !21
  br label %bb7
bb5:
  br label %bb6
bb6:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb7
bb7:
  %t23 = load i1, ptr %l10, !tbaa !21
  %t24 = xor i1 %t23, true
  store i1 %t24, ptr %l9, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l9, !tbaa !21
  br i1 %t26, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb10:
  br label %bb11
bb11:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/emit:fnEm", ptr %t27, i32 0, i32 36
  %t30 = load i64, ptr %l1, !tbaa !24
  %t33 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t29, i64 %t30)
  %t34 = extractvalue { i32, i64 } %t33, 1
  %t35 = extractvalue { i32, i64 } %t33, 0
  store i32 %t35, ptr %l22
  %t36 = icmp ne i32 %t35, 0
  br i1 %t36, label %bb13, label %ok.37, !prof !99
ok.37:
  store i64 %t34, ptr %l21
  br label %bb12
bb12:
  %t38 = load i64, ptr %l21, !tbaa !24
  store i64 %t38, ptr %l17, !tbaa !24
  br label %bb15
bb13:
  br label %bb14
bb14:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb15
bb15:
  %t39 = load i64, ptr %l17, !tbaa !24
  store i64 %t39, ptr %l3, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/emit:fnEm", ptr %t40, i32 0, i32 36
  %t43 = load i64, ptr %l1, !tbaa !24
  %t44 = load i64, ptr %l3, !tbaa !24
  %t46 = add i64 %t44, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t42, i64 %t43, i64 %t46)
  br label %bb16
bb16:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load i64, ptr %l3, !tbaa !24
  %t53 = call i64 @__olang_fmt_i64(ptr null, i64 %t51)
  %t54 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t53)
  %t55 = call i64 @__olang_fmt_i64(ptr %t54, i64 %t51)
  %t56 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t54, 1
  %t59 = load i64, ptr %l1, !tbaa !24
  %t60 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d398, i32 0, i32 1) }, 1
  %t61 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d398, i32 0, i32 1) }, 0
  %t63 = call i64 @__olang_fmt_i64(ptr null, i64 %t59)
  %t64 = add i64 %t61, %t63
  %t65 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t64)
  call void @olang_textcopy(ptr %t65, ptr %t60, i64 %t61)
  %t66 = getelementptr i8, ptr %t65, i64 %t61
  %t67 = call i64 @__olang_fmt_i64(ptr %t66, i64 %t59)
  %t68 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t65, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %v1, ptr %t50, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d399, i32 0, i32 1) }, { i64, ptr } %t57, { i64, ptr } %t69, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d43, i32 0, i32 1) })
  br label %bb17
bb17:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i64, ptr %l1, !tbaa !24
  %t76 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d400, i32 0, i32 1) }, 1
  %t77 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d400, i32 0, i32 1) }, 0
  %t79 = call i64 @__olang_fmt_i64(ptr null, i64 %t75)
  %t80 = add i64 %t77, %t79
  %t81 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t80)
  call void @olang_textcopy(ptr %t81, ptr %t76, i64 %t77)
  %t82 = getelementptr i8, ptr %t81, i64 %t77
  %t83 = call i64 @__olang_fmt_i64(ptr %t82, i64 %t75)
  %t84 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t81, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %v1, ptr %t74, { i64, ptr } %t85)
  br label %bb18
bb18:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i64, ptr %l1, !tbaa !24
  %t91 = load i64, ptr %l3, !tbaa !24
  %t92 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d401, i32 0, i32 1) }, 1
  %t93 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d401, i32 0, i32 1) }, 0
  %t95 = call i64 @__olang_fmt_i64(ptr null, i64 %t90)
  %t96 = add i64 %t93, %t95
  %t97 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d402, i32 0, i32 1) }, 1
  %t98 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d402, i32 0, i32 1) }, 0
  %t99 = add i64 %t96, %t98
  %t101 = call i64 @__olang_fmt_i64(ptr null, i64 %t91)
  %t102 = add i64 %t99, %t101
  %t103 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t102)
  call void @olang_textcopy(ptr %t103, ptr %t92, i64 %t93)
  %t104 = getelementptr i8, ptr %t103, i64 %t93
  %t105 = call i64 @__olang_fmt_i64(ptr %t104, i64 %t90)
  %t106 = getelementptr i8, ptr %t104, i64 %t95
  call void @olang_textcopy(ptr %t106, ptr %t97, i64 %t98)
  %t107 = getelementptr i8, ptr %t106, i64 %t98
  %t108 = call i64 @__olang_fmt_i64(ptr %t107, i64 %t91)
  %t109 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t103, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s0, ptr %t89, { i64, ptr } %t110)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2ewalkEnds(ptr %v0, ptr %v1, ptr %v2, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l3 = alloca %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0"
  %l4 = alloca i64
  %l5 = alloca %"compiler/mir:Call"
  %l6 = alloca i32
  %l7 = alloca { i64, [7 x i64] }
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l14 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca %"std/prelude/text:StringBuilder"
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l35 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l36 = alloca %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0"
  %l38 = alloca %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0"
  %l39 = alloca i32
  %l41 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i32
  %l57 = alloca %"compiler/mir:Call"
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l66 = alloca ptr
  %l67 = alloca ptr
  %l70 = alloca i32
  %l72 = alloca i32
  %l74 = alloca i32
  %l76 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l80 = alloca ptr
  %l84 = alloca ptr
  %l86 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l106 = alloca ptr
  %l112 = alloca { i64, ptr }
  %l114 = alloca %"std/prelude/text:StringBuilder"
  %l119 = alloca ptr
  %l122 = alloca i32
  %l126 = alloca i1
  %l130 = alloca i1
  %l131 = alloca ptr
  %l134 = alloca i1
  %l135 = alloca ptr
  %l138 = alloca { i64, ptr }
  %l141 = alloca ptr
  %l146 = alloca i64
  %l150 = alloca i64
  %l153 = alloca i64
  %l176 = alloca i1
  %l177 = alloca ptr
  %l178 = alloca { i64, ptr }
  %l180 = alloca { i64, ptr }
  %l183 = alloca ptr
  %l184 = alloca { i64, ptr }
  %l185 = alloca { i64, ptr }
  %l187 = alloca { i64, ptr }
  %l190 = alloca { i64, ptr }
  %l195 = alloca { i64, ptr }
  %l196 = alloca %"std/prelude/text:StringBuilder"
  %l206 = alloca i64
  %l209 = alloca i64
  %l237 = alloca ptr
  %l239 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %t336 = alloca { i64, [4 x i64] }, align 8
  %t339 = alloca { i64, [7 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l1, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/emit:fnEm", ptr %t9, i32 0, i32 36
  %t13 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eIter_3cI64_2c_20I64_3e(ptr %v0, ptr %v0, ptr %t11)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t13, ptr %l35
  br label %bb1
bb1:
  %t14 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l35
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t14, ptr %l2
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t16 = call { i32, %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cI64_2c_20I64_3e_2eNext_3cI64_2c_20I64_3e(ptr %v0, ptr %l2)
  %t17 = extractvalue { i32, %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" } %t16, 1
  %t18 = extractvalue { i32, %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" } %t16, 0
  store i32 %t18, ptr %l39
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb4, label %ok.20, !prof !99
ok.20:
  store %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" %t17, ptr %l38
  br label %bb3
bb3:
  %t21 = load %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0", ptr %l38
  store %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" %t21, ptr %l36
  br label %bb6
bb4:
  %t22 = load i32, ptr %l39, !tbaa !23
  %t23 = ashr i32 %t22, 16
  %t25 = icmp eq i32 %t23, 1
  store i1 %t25, ptr %l41, !tbaa !21
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb91
bb6:
  %t26 = load %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0", ptr %l36
  store %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" %t26, ptr %l3
  %t27 = getelementptr %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0", ptr %l3, i32 0, i32 0
  %t28 = load i64, ptr %t27, !tbaa !24
  store i64 %t28, ptr %l4, !tbaa !24
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i64, ptr %l4, !tbaa !24
  %t32 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d403, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d403, i32 0, i32 1) }, 0
  %t35 = call i64 @__olang_fmt_i64(ptr null, i64 %t31)
  %t36 = add i64 %t33, %t35
  %t37 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t36)
  call void @olang_textcopy(ptr %t37, ptr %t32, i64 %t33)
  %t38 = getelementptr i8, ptr %t37, i64 %t33
  %t39 = call i64 @__olang_fmt_i64(ptr %t38, i64 %t31)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t37, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s2, ptr %t30, { i64, ptr } %t41)
  br label %bb7
bb7:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/emit:fnEm", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = getelementptr %"compiler/mir:Fn", ptr %t48, i32 0, i32 14
  store ptr %t50, ptr %l49, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/emit:fnEm", ptr %t51, i32 0, i32 34
  %t54 = load i64, ptr %l4, !tbaa !24
  %t57 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t53, i64 %t54)
  %t58 = extractvalue { i32, i64 } %t57, 1
  %t59 = extractvalue { i32, i64 } %t57, 0
  store i32 %t59, ptr %l55
  %t60 = icmp ne i32 %t59, 0
  br i1 %t60, label %bb9, label %ok.61, !prof !99
ok.61:
  store i64 %t58, ptr %l54
  br label %bb8
bb8:
  %t62 = load i64, ptr %l54, !tbaa !24
  store i64 %t62, ptr %l50, !tbaa !24
  br label %bb11
bb9:
  br label %bb10
bb10:
  call void @__olang_check_failed(ptr @olang_loc_d55aab1360531c47_f82e8a31cf9de643)
  unreachable
bb11:
  %t63 = load ptr, ptr %l49, !tbaa !29
  %t64 = call ptr @__olang_scope_or(ptr %v1, ptr %t63)
  %t65 = call ptr @__olang_scope_hold(ptr %t64)
  %t66 = ptrtoint ptr %t65 to i64
  %t68 = inttoptr i64 %t66 to ptr
  %t69 = load ptr, ptr %l49, !tbaa !29
  %t70 = load i64, ptr %l50, !tbaa !24
  %t71 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %t68, ptr %t69, i64 %t70)
  store %"compiler/mir:Call" %t71, ptr %l57
  br label %bb12
bb12:
  %t72 = load %"compiler/mir:Call", ptr %l57
  store %"compiler/mir:Call" %t72, ptr %l5
  %t73 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t73, ptr %l6, !tbaa !23
  %t75 = getelementptr %"compiler/mir:Call", ptr %l5, i32 0, i32 0
  %t76 = load { i64, [7 x i64] }, ptr %t75
  store { i64, [7 x i64] } %t76, ptr %l7
  %t78 = load { i64, [7 x i64] }, ptr %l7
  %t80 = extractvalue { i64, [7 x i64] } %t78, 0
  %t81 = icmp eq i64 %t80, 0
  br i1 %t81, label %bb13, label %bb14
bb13:
  %t83 = getelementptr { i64, [7 x i64] }, ptr %l7, i32 0, i32 1
  %t84 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t83, i32 0, i32 1
  %t85 = load i32, ptr %t84
  store i32 %t85, ptr %l8, !tbaa !23
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t87 = load i32, ptr %l8, !tbaa !23
  store i32 %t87, ptr %l6, !tbaa !23
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_e9cd50c1ae7327e6_bc31e41603ed9ec2)
  unreachable
bb21:
  %t89 = load ptr, ptr %l1, !tbaa !29
  store ptr %t89, ptr %l64, !tbaa !29
  %t90 = load ptr, ptr %l1, !tbaa !29
  store ptr %t90, ptr %l65, !tbaa !29
  %t91 = load ptr, ptr %l1, !tbaa !29
  store ptr %t91, ptr %l66, !tbaa !29
  %t92 = load ptr, ptr %l1, !tbaa !29
  store ptr %t92, ptr %l67, !tbaa !29
  %t93 = load i32, ptr %l6, !tbaa !23
  %t94 = load ptr, ptr %l67, !tbaa !29
  %t95 = call ptr @__olang_scope_or(ptr %v2, ptr %t94)
  %t96 = call ptr @__olang_scope_hold(ptr %t95)
  %t97 = ptrtoint ptr %t96 to i64
  %t99 = inttoptr i64 %t97 to ptr
  %t100 = load ptr, ptr %l67, !tbaa !29
  %t102 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %t99, ptr %t100, i32 %t93)
  store i32 %t102, ptr %l70
  br label %bb22
bb22:
  %t103 = load ptr, ptr %l66, !tbaa !29
  %t104 = call ptr @__olang_scope_or(ptr %v2, ptr %t103)
  %t105 = call ptr @__olang_scope_hold(ptr %t104)
  %t106 = ptrtoint ptr %t105 to i64
  %t108 = inttoptr i64 %t106 to ptr
  %t109 = load ptr, ptr %l66, !tbaa !29
  %t110 = load i32, ptr %l70, !tbaa !23
  %t111 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t108, ptr %t109, i32 %t110)
  store i32 %t111, ptr %l72
  br label %bb23
bb23:
  %t112 = load ptr, ptr %l65, !tbaa !29
  %t113 = call ptr @__olang_scope_or(ptr %v2, ptr %t112)
  %t114 = call ptr @__olang_scope_hold(ptr %t113)
  %t115 = ptrtoint ptr %t114 to i64
  %t117 = inttoptr i64 %t115 to ptr
  %t118 = load ptr, ptr %l65, !tbaa !29
  %t119 = load i32, ptr %l72, !tbaa !23
  %t120 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %t117, ptr %t118, i32 %t119)
  store i32 %t120, ptr %l74
  br label %bb24
bb24:
  %t121 = load ptr, ptr %l64, !tbaa !29
  %t122 = call ptr @__olang_scope_or(ptr %v2, ptr %t121)
  %t123 = call ptr @__olang_scope_hold(ptr %t122)
  %t124 = ptrtoint ptr %t123 to i64
  %t126 = inttoptr i64 %t124 to ptr
  %t127 = load ptr, ptr %l64, !tbaa !29
  %t128 = load i32, ptr %l74, !tbaa !23
  %t129 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t126, ptr %s2, ptr %t127, i32 %t128)
  store { i64, ptr } %t129, ptr %l76
  br label %bb25
bb25:
  %t130 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t130, ptr %l77, !tbaa !27
  %t131 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr i32, ptr %t132, i64 0
  %t134 = load i32, ptr %t133, !tbaa !33
  store i32 %t134, ptr %l9, !tbaa !23
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/emit:fnEm", ptr %t136, i32 0, i32 0
  %t139 = load ptr, ptr %t138, !tbaa !29
  store ptr %t139, ptr %l80, !tbaa !29
  %t140 = load i32, ptr %l9, !tbaa !23
  %t141 = load ptr, ptr %l80, !tbaa !29
  %t142 = call ptr @__olang_scope_or(ptr %v2, ptr %t141)
  %t143 = call ptr @__olang_scope_hold(ptr %t142)
  %t144 = ptrtoint ptr %t143 to i64
  %t146 = inttoptr i64 %t144 to ptr
  %t147 = load ptr, ptr %l80, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2esignature(ptr %t146, ptr %t147, i32 %t140)
  br label %bb26
bb26:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/emit:fnEm", ptr %t149, i32 0, i32 0
  %t152 = load ptr, ptr %t151, !tbaa !29
  store ptr %t152, ptr %l84, !tbaa !29
  %t153 = load ptr, ptr %l84, !tbaa !29
  %t154 = call ptr @__olang_scope_or(ptr %v2, ptr %t153)
  %t155 = call ptr @__olang_scope_hold(ptr %t154)
  %t156 = ptrtoint ptr %t155 to i64
  %t158 = inttoptr i64 %t156 to ptr
  %t159 = load ptr, ptr %l84, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecoroDecls(ptr %t158, ptr %t159)
  br label %bb27
bb27:
  %t160 = load ptr, ptr %l1, !tbaa !29
  store ptr %t160, ptr %l86, !tbaa !29
  %t161 = load i32, ptr %l9, !tbaa !23
  %t162 = load ptr, ptr %l86, !tbaa !29
  %t163 = call ptr @__olang_scope_or(ptr %v2, ptr %t162)
  %t164 = call ptr @__olang_scope_hold(ptr %t163)
  %t165 = ptrtoint ptr %t164 to i64
  %t167 = inttoptr i64 %t165 to ptr
  %t169 = inttoptr i64 0 to ptr
  %t170 = load ptr, ptr %l86, !tbaa !29
  %t172 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %t167, ptr %s2, ptr %t169, ptr %t170, i32 %t161)
  store { i64, ptr } %t172, ptr %l90
  br label %bb28
bb28:
  %t173 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t173, ptr %l10, !tbaa !27
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load i64, ptr %l4, !tbaa !24
  %t176 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d404, i32 0, i32 1) }, 1
  %t177 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d404, i32 0, i32 1) }, 0
  %t179 = call i64 @__olang_fmt_i64(ptr null, i64 %t175)
  %t180 = add i64 %t177, %t179
  %t181 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t180)
  call void @olang_textcopy(ptr %t181, ptr %t176, i64 %t177)
  %t182 = getelementptr i8, ptr %t181, i64 %t177
  %t183 = call i64 @__olang_fmt_i64(ptr %t182, i64 %t175)
  %t184 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t181, 1
  %t189 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s2, ptr %s2, ptr %s2, ptr %s2, ptr %v2, ptr %t174, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d405, i32 0, i32 1) }, { i64, ptr } %t185, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d49, i32 0, i32 1) })
  store { i64, ptr } %t189, ptr %l95
  br label %bb29
bb29:
  %t190 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t190, ptr %l11, !tbaa !27
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t192 = load i64, ptr %l4, !tbaa !24
  %t193 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d406, i32 0, i32 1) }, 1
  %t194 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d406, i32 0, i32 1) }, 0
  %t196 = call i64 @__olang_fmt_i64(ptr null, i64 %t192)
  %t197 = add i64 %t194, %t196
  %t198 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t197)
  call void @olang_textcopy(ptr %t198, ptr %t193, i64 %t194)
  %t199 = getelementptr i8, ptr %t198, i64 %t194
  %t200 = call i64 @__olang_fmt_i64(ptr %t199, i64 %t192)
  %t201 = insertvalue { i64, ptr } undef, i64 %t197, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t198, 1
  %t206 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s2, ptr %s2, ptr %s2, ptr %s2, ptr %v2, ptr %t191, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d407, i32 0, i32 1) }, { i64, ptr } %t202, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d49, i32 0, i32 1) })
  store { i64, ptr } %t206, ptr %l100
  br label %bb30
bb30:
  %t207 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t207, ptr %l12, !tbaa !27
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t210 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d408, i32 0, i32 1) }, 1
  %t211 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d408, i32 0, i32 1) }, 0
  %t213 = extractvalue { i64, ptr } %t209, 1
  %t214 = extractvalue { i64, ptr } %t209, 0
  %t215 = add i64 %t211, %t214
  %t216 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d409, i32 0, i32 1) }, 1
  %t217 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d409, i32 0, i32 1) }, 0
  %t218 = add i64 %t215, %t217
  %t219 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t218)
  call void @olang_textcopy(ptr %t219, ptr %t210, i64 %t211)
  %t220 = getelementptr i8, ptr %t219, i64 %t211
  call void @olang_textcopy(ptr %t220, ptr %t213, i64 %t214)
  %t221 = getelementptr i8, ptr %t220, i64 %t214
  call void @olang_textcopy(ptr %t221, ptr %t216, i64 %t217)
  %t222 = insertvalue { i64, ptr } undef, i64 %t218, 0
  %t223 = insertvalue { i64, ptr } %t222, ptr %t219, 1
  %t227 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s2, ptr %s2, ptr %v2, ptr %t208, { i64, ptr } %t223)
  store { i64, ptr } %t227, ptr %l105
  br label %bb31
bb31:
  %t228 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t229 = load ptr, ptr %l0, !tbaa !29
  store ptr %t229, ptr %l106, !tbaa !29
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t233 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d410, i32 0, i32 1) }, 1
  %t234 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d410, i32 0, i32 1) }, 0
  %t236 = extractvalue { i64, ptr } %t231, 1
  %t237 = extractvalue { i64, ptr } %t231, 0
  %t238 = add i64 %t234, %t237
  %t239 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d411, i32 0, i32 1) }, 1
  %t240 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d411, i32 0, i32 1) }, 0
  %t241 = add i64 %t238, %t240
  %t243 = extractvalue { i64, ptr } %t228, 1
  %t244 = extractvalue { i64, ptr } %t228, 0
  %t245 = add i64 %t241, %t244
  %t246 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d412, i32 0, i32 1) }, 1
  %t247 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d412, i32 0, i32 1) }, 0
  %t248 = add i64 %t245, %t247
  %t249 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t248)
  call void @olang_textcopy(ptr %t249, ptr %t233, i64 %t234)
  %t250 = getelementptr i8, ptr %t249, i64 %t234
  call void @olang_textcopy(ptr %t250, ptr %t236, i64 %t237)
  %t251 = getelementptr i8, ptr %t250, i64 %t237
  call void @olang_textcopy(ptr %t251, ptr %t239, i64 %t240)
  %t252 = getelementptr i8, ptr %t251, i64 %t240
  call void @olang_textcopy(ptr %t252, ptr %t243, i64 %t244)
  %t253 = getelementptr i8, ptr %t252, i64 %t244
  call void @olang_textcopy(ptr %t253, ptr %t246, i64 %t247)
  %t254 = insertvalue { i64, ptr } undef, i64 %t248, 0
  %t255 = insertvalue { i64, ptr } %t254, ptr %t249, 1
  %t259 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s2, ptr %s2, ptr %v2, ptr %t230, { i64, ptr } %t255)
  store { i64, ptr } %t259, ptr %l112
  br label %bb32
bb32:
  %t260 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t261 = load ptr, ptr %l106, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s2, ptr %s2, ptr %s2, ptr %s2, ptr %v2, ptr %t261, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d413, i32 0, i32 1) }, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d414, i32 0, i32 1) }, { i64, ptr } %t260, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d43, i32 0, i32 1) })
  br label %bb33
bb33:
  %t263 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s2)
  store %"std/prelude/text:StringBuilder" %t263, ptr %l114
  br label %bb34
bb34:
  %t264 = load %"std/prelude/text:StringBuilder", ptr %l114
  store %"std/prelude/text:StringBuilder" %t264, ptr %l14
  %t265 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t266 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d415, i32 0, i32 1) }, 1
  %t267 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d415, i32 0, i32 1) }, 0
  %t269 = extractvalue { i64, ptr } %t265, 1
  %t270 = extractvalue { i64, ptr } %t265, 0
  %t271 = add i64 %t267, %t270
  %t272 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t271)
  call void @olang_textcopy(ptr %t272, ptr %t266, i64 %t267)
  %t273 = getelementptr i8, ptr %t272, i64 %t267
  call void @olang_textcopy(ptr %t273, ptr %t269, i64 %t270)
  %t274 = insertvalue { i64, ptr } undef, i64 %t271, 0
  %t275 = insertvalue { i64, ptr } %t274, ptr %t272, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s2, ptr %s2, ptr %l14, { i64, ptr } %t275)
  br label %bb35
bb35:
  %t279 = load ptr, ptr %l1, !tbaa !29
  store ptr %t279, ptr %l119, !tbaa !29
  %t280 = load i32, ptr %l9, !tbaa !23
  %t281 = load ptr, ptr %l119, !tbaa !29
  %t282 = call ptr @__olang_scope_or(ptr %v2, ptr %t281)
  %t283 = call ptr @__olang_scope_hold(ptr %t282)
  %t284 = ptrtoint ptr %t283 to i64
  %t286 = inttoptr i64 %t284 to ptr
  %t287 = load ptr, ptr %l119, !tbaa !29
  %t289 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %t286, ptr %t287, i32 %t280)
  store i32 %t289, ptr %l122
  br label %bb36
bb36:
  %t290 = load i32, ptr %l122, !tbaa !23
  store i32 %t290, ptr %l15, !tbaa !23
  %t291 = load i32, ptr %l15, !tbaa !23
  %t292 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t295 = icmp ne i32 %t291, %t292
  br i1 %t295, label %bb37, label %bb38
bb37:
  %t297 = load i32, ptr %l15, !tbaa !23
  %t298 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t301 = icmp ne i32 %t297, %t298
  store i1 %t301, ptr %l126, !tbaa !21
  br label %bb39
bb38:
  store i1 false, ptr %l126, !tbaa !21
  br label %bb39
bb39:
  %t303 = load i1, ptr %l126, !tbaa !21
  br i1 %t303, label %bb40, label %bb41
bb40:
  %t304 = load ptr, ptr %l1, !tbaa !29
  store ptr %t304, ptr %l131, !tbaa !29
  %t305 = load i32, ptr %l15, !tbaa !23
  %t306 = load ptr, ptr %l131, !tbaa !29
  %t307 = call ptr @__olang_scope_or(ptr %v2, ptr %t306)
  %t308 = call ptr @__olang_scope_hold(ptr %t307)
  %t309 = ptrtoint ptr %t308 to i64
  %t311 = inttoptr i64 %t309 to ptr
  %t312 = load ptr, ptr %l131, !tbaa !29
  %t314 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %t311, ptr %t312, i32 %t305)
  store i1 %t314, ptr %l134
  br label %bb42
bb41:
  store i1 false, ptr %l130, !tbaa !21
  br label %bb43
bb42:
  %t315 = load i1, ptr %l134, !tbaa !21
  store i1 %t315, ptr %l130, !tbaa !21
  br label %bb43
bb43:
  %t316 = load i1, ptr %l130, !tbaa !21
  br i1 %t316, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s12
  store ptr %l14, ptr %l135, !tbaa !29
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t318 = load i32, ptr %l15, !tbaa !23
  %t321 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eslot(ptr %v0, ptr %s12, ptr %v2, ptr %t317, i32 %t318)
  store { i64, ptr } %t321, ptr %l138
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t322 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d416, i32 0, i32 1) }, 1
  %t323 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d416, i32 0, i32 1) }, 0
  %t324 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t325 = extractvalue { i64, ptr } %t324, 1
  %t326 = extractvalue { i64, ptr } %t324, 0
  %t327 = add i64 %t323, %t326
  %t328 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t327)
  call void @olang_textcopy(ptr %t328, ptr %t322, i64 %t323)
  %t329 = getelementptr i8, ptr %t328, i64 %t323
  call void @olang_textcopy(ptr %t329, ptr %t325, i64 %t326)
  %t330 = insertvalue { i64, ptr } undef, i64 %t327, 0
  %t331 = insertvalue { i64, ptr } %t330, ptr %t328, 1
  %t333 = load ptr, ptr %l135, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s2, ptr %s12, ptr %t333, { i64, ptr } %t331)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s12)
  br label %bb48
bb48:
  store i64 0, ptr %l16, !tbaa !24
  %t335 = load ptr, ptr %l1, !tbaa !29
  store ptr %t335, ptr %l141, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t336
  %t337 = getelementptr { i64, [4 x i64] }, ptr %t336, i32 0, i32 0
  store i64 0, ptr %t337
  %t338 = load { i64, [4 x i64] }, ptr %t336
  store { i64, [7 x i64] } zeroinitializer, ptr %t339
  %t340 = getelementptr { i64, [7 x i64] }, ptr %t339, i32 0, i32 0
  store i64 2, ptr %t340
  %t342 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t338, 0
  %t343 = getelementptr { i64, [7 x i64] }, ptr %t339, i32 0, i32 1
  store { { i64, [4 x i64] } } %t342, ptr %t343
  %t344 = load { i64, [7 x i64] }, ptr %t339
  %t345 = load i32, ptr %l9, !tbaa !23
  %t346 = load ptr, ptr %l141, !tbaa !29
  %t347 = call ptr @__olang_scope_or(ptr %v2, ptr %t346)
  %t348 = call ptr @__olang_scope_hold(ptr %t347)
  %t349 = ptrtoint ptr %t348 to i64
  %t351 = inttoptr i64 %t349 to ptr
  %t352 = load ptr, ptr %l141, !tbaa !29
  %t355 = call i64 @compiler_2fmir_2ePassedCount(ptr %t351, ptr %t352, { i64, [7 x i64] } %t344, i32 %t345)
  store i64 %t355, ptr %l146
  br label %bb49
bb49:
  %t356 = load i64, ptr %l146, !tbaa !24
  store i64 %t356, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t357 = load i64, ptr %l17, !tbaa !24
  %t358 = load i64, ptr %l16, !tbaa !24
  %t361 = icmp sgt i64 %t357, %t358
  br i1 %t361, label %bb50, label %bb51
bb50:
  %t363 = load i64, ptr %l18, !tbaa !24
  %t365 = icmp sgt i64 %t363, 0
  br i1 %t365, label %bb52, label %bb53
bb51:
  store i64 0, ptr %l150, !tbaa !24
  br label %bb55
bb52:
  %t367 = load i64, ptr %l17, !tbaa !24
  %t368 = load i64, ptr %l16, !tbaa !24
  %t371 = sub i64 %t367, %t368
  %t372 = load i64, ptr %l18, !tbaa !24
  %t375 = add i64 %t371, %t372
  %t377 = sub i64 %t375, 1
  %t378 = load i64, ptr %l18, !tbaa !24
  %t381 = sdiv i64 %t377, %t378
  store i64 %t381, ptr %l153, !tbaa !24
  br label %bb54
bb53:
  store i64 0, ptr %l153, !tbaa !24
  br label %bb54
bb54:
  %t383 = load i64, ptr %l153, !tbaa !24
  store i64 %t383, ptr %l150, !tbaa !24
  br label %bb55
bb55:
  %t384 = load i64, ptr %l150, !tbaa !24
  store i64 %t384, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb56
bb56:
  store %olang.scope zeroinitializer, ptr %s15
  %t385 = load i64, ptr %l20, !tbaa !24
  %t386 = load i64, ptr %l19, !tbaa !24
  %t389 = icmp slt i64 %t385, %t386
  %t391 = xor i1 %t389, true
  br i1 %t391, label %bb57, label %bb58
bb57:
  call void @__olang_scope_close(ptr %s15)
  br label %bb62
bb58:
  br label %bb59
bb59:
  %t393 = load i64, ptr %l16, !tbaa !24
  %t394 = load i64, ptr %l20, !tbaa !24
  %t395 = load i64, ptr %l18, !tbaa !24
  %t398 = mul i64 %t394, %t395
  %t401 = add i64 %t393, %t398
  store i64 %t401, ptr %l21, !tbaa !24
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s2, ptr %s15, ptr %l14, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d417, i32 0, i32 1) })
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s15)
  br label %bb61
bb61:
  %t404 = load i64, ptr %l20, !tbaa !24
  %t407 = add i64 %t404, 1
  store i64 %t407, ptr %l20, !tbaa !24
  br label %bb56
bb62:
  %t409 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t411 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t409, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d418, i32 0, i32 1) })
  store i1 %t411, ptr %l176
  br label %bb63
bb63:
  %t412 = load i1, ptr %l176, !tbaa !21
  br i1 %t412, label %bb64, label %bb65
bb64:
  store %olang.scope zeroinitializer, ptr %s17
  %t413 = load ptr, ptr %l0, !tbaa !29
  store ptr %t413, ptr %l177, !tbaa !29
  %t414 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t414, ptr %l178, !tbaa !27
  %t416 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s2, ptr %s17, ptr %l14)
  store { i64, ptr } %t416, ptr %l180
  br label %bb66
bb65:
  store %olang.scope zeroinitializer, ptr %s19
  %t417 = load ptr, ptr %l0, !tbaa !29
  store ptr %t417, ptr %l183, !tbaa !29
  %t418 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t418, ptr %l184, !tbaa !27
  %t419 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t419, ptr %l185, !tbaa !27
  %t421 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s2, ptr %s19, ptr %l14)
  store { i64, ptr } %t421, ptr %l187
  br label %bb68
bb66:
  %t422 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d419, i32 0, i32 1) }, 1
  %t423 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d419, i32 0, i32 1) }, 0
  %t424 = load { i64, ptr }, ptr %l178, !tbaa !27
  %t425 = extractvalue { i64, ptr } %t424, 1
  %t426 = extractvalue { i64, ptr } %t424, 0
  %t427 = add i64 %t423, %t426
  %t428 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d420, i32 0, i32 1) }, 1
  %t429 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d420, i32 0, i32 1) }, 0
  %t430 = add i64 %t427, %t429
  %t431 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t432 = extractvalue { i64, ptr } %t431, 1
  %t433 = extractvalue { i64, ptr } %t431, 0
  %t434 = add i64 %t430, %t433
  %t435 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d421, i32 0, i32 1) }, 1
  %t436 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d421, i32 0, i32 1) }, 0
  %t437 = add i64 %t434, %t436
  %t438 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t437)
  call void @olang_textcopy(ptr %t438, ptr %t422, i64 %t423)
  %t439 = getelementptr i8, ptr %t438, i64 %t423
  call void @olang_textcopy(ptr %t439, ptr %t425, i64 %t426)
  %t440 = getelementptr i8, ptr %t439, i64 %t426
  call void @olang_textcopy(ptr %t440, ptr %t428, i64 %t429)
  %t441 = getelementptr i8, ptr %t440, i64 %t429
  call void @olang_textcopy(ptr %t441, ptr %t432, i64 %t433)
  %t442 = getelementptr i8, ptr %t441, i64 %t433
  call void @olang_textcopy(ptr %t442, ptr %t435, i64 %t436)
  %t443 = insertvalue { i64, ptr } undef, i64 %t437, 0
  %t444 = insertvalue { i64, ptr } %t443, ptr %t438, 1
  %t446 = load ptr, ptr %l177, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s17, ptr %v2, ptr %t446, { i64, ptr } %t444)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s17)
  br label %bb70
bb68:
  %t448 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d422, i32 0, i32 1) }, 1
  %t449 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d422, i32 0, i32 1) }, 0
  %t450 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t451 = extractvalue { i64, ptr } %t450, 1
  %t452 = extractvalue { i64, ptr } %t450, 0
  %t453 = add i64 %t449, %t452
  %t454 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d423, i32 0, i32 1) }, 1
  %t455 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d423, i32 0, i32 1) }, 0
  %t456 = add i64 %t453, %t455
  %t457 = load { i64, ptr }, ptr %l185, !tbaa !27
  %t458 = extractvalue { i64, ptr } %t457, 1
  %t459 = extractvalue { i64, ptr } %t457, 0
  %t460 = add i64 %t456, %t459
  %t461 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d424, i32 0, i32 1) }, 1
  %t462 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d424, i32 0, i32 1) }, 0
  %t463 = add i64 %t460, %t462
  %t464 = load { i64, ptr }, ptr %l187, !tbaa !27
  %t465 = extractvalue { i64, ptr } %t464, 1
  %t466 = extractvalue { i64, ptr } %t464, 0
  %t467 = add i64 %t463, %t466
  %t468 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d425, i32 0, i32 1) }, 1
  %t469 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d425, i32 0, i32 1) }, 0
  %t470 = add i64 %t467, %t469
  %t471 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t470)
  call void @olang_textcopy(ptr %t471, ptr %t448, i64 %t449)
  %t472 = getelementptr i8, ptr %t471, i64 %t449
  call void @olang_textcopy(ptr %t472, ptr %t451, i64 %t452)
  %t473 = getelementptr i8, ptr %t472, i64 %t452
  call void @olang_textcopy(ptr %t473, ptr %t454, i64 %t455)
  %t474 = getelementptr i8, ptr %t473, i64 %t455
  call void @olang_textcopy(ptr %t474, ptr %t458, i64 %t459)
  %t475 = getelementptr i8, ptr %t474, i64 %t459
  call void @olang_textcopy(ptr %t475, ptr %t461, i64 %t462)
  %t476 = getelementptr i8, ptr %t475, i64 %t462
  call void @olang_textcopy(ptr %t476, ptr %t465, i64 %t466)
  %t477 = getelementptr i8, ptr %t476, i64 %t466
  call void @olang_textcopy(ptr %t477, ptr %t468, i64 %t469)
  %t478 = insertvalue { i64, ptr } undef, i64 %t470, 0
  %t479 = insertvalue { i64, ptr } %t478, ptr %t471, 1
  %t481 = load ptr, ptr %l183, !tbaa !29
  %t483 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s19, ptr %s19, ptr %v2, ptr %t481, { i64, ptr } %t479)
  store { i64, ptr } %t483, ptr %l190
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s19)
  br label %bb70
bb70:
  %t484 = load ptr, ptr %l0, !tbaa !29
  %t485 = load i64, ptr %l4, !tbaa !24
  %t486 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d426, i32 0, i32 1) }, 1
  %t487 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d426, i32 0, i32 1) }, 0
  %t489 = call i64 @__olang_fmt_i64(ptr null, i64 %t485)
  %t490 = add i64 %t487, %t489
  %t491 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t490)
  call void @olang_textcopy(ptr %t491, ptr %t486, i64 %t487)
  %t492 = getelementptr i8, ptr %t491, i64 %t487
  %t493 = call i64 @__olang_fmt_i64(ptr %t492, i64 %t485)
  %t494 = insertvalue { i64, ptr } undef, i64 %t490, 0
  %t495 = insertvalue { i64, ptr } %t494, ptr %t491, 1
  %t499 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s2, ptr %s2, ptr %s2, ptr %s2, ptr %v2, ptr %t484, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d427, i32 0, i32 1) }, { i64, ptr } %t495, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d49, i32 0, i32 1) })
  store { i64, ptr } %t499, ptr %l195
  br label %bb71
bb71:
  %t500 = load { i64, ptr }, ptr %l195, !tbaa !27
  store { i64, ptr } %t500, ptr %l22, !tbaa !27
  %t501 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s2)
  store %"std/prelude/text:StringBuilder" %t501, ptr %l196
  br label %bb72
bb72:
  %t502 = load %"std/prelude/text:StringBuilder", ptr %l196
  store %"std/prelude/text:StringBuilder" %t502, ptr %l23
  %t503 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t504 = load i64, ptr %l4, !tbaa !24
  %t505 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d428, i32 0, i32 1) }, 1
  %t506 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d428, i32 0, i32 1) }, 0
  %t508 = extractvalue { i64, ptr } %t503, 1
  %t509 = extractvalue { i64, ptr } %t503, 0
  %t510 = add i64 %t506, %t509
  %t511 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d429, i32 0, i32 1) }, 1
  %t512 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d429, i32 0, i32 1) }, 0
  %t513 = add i64 %t510, %t512
  %t515 = call i64 @__olang_fmt_i64(ptr null, i64 %t504)
  %t516 = add i64 %t513, %t515
  %t517 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d430, i32 0, i32 1) }, 1
  %t518 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d430, i32 0, i32 1) }, 0
  %t519 = add i64 %t516, %t518
  %t520 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t519)
  call void @olang_textcopy(ptr %t520, ptr %t505, i64 %t506)
  %t521 = getelementptr i8, ptr %t520, i64 %t506
  call void @olang_textcopy(ptr %t521, ptr %t508, i64 %t509)
  %t522 = getelementptr i8, ptr %t521, i64 %t509
  call void @olang_textcopy(ptr %t522, ptr %t511, i64 %t512)
  %t523 = getelementptr i8, ptr %t522, i64 %t512
  %t524 = call i64 @__olang_fmt_i64(ptr %t523, i64 %t504)
  %t525 = getelementptr i8, ptr %t523, i64 %t515
  call void @olang_textcopy(ptr %t525, ptr %t517, i64 %t518)
  %t526 = insertvalue { i64, ptr } undef, i64 %t519, 0
  %t527 = insertvalue { i64, ptr } %t526, ptr %t520, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s2, ptr %s2, ptr %l23, { i64, ptr } %t527)
  br label %bb73
bb73:
  store i64 1, ptr %l24, !tbaa !24
  %t531 = getelementptr %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0", ptr %l3, i32 0, i32 1
  %t532 = load i64, ptr %t531, !tbaa !24
  store i64 %t532, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t534 = load i64, ptr %l25, !tbaa !24
  %t535 = load i64, ptr %l24, !tbaa !24
  %t538 = icmp sgt i64 %t534, %t535
  br i1 %t538, label %bb74, label %bb75
bb74:
  %t540 = load i64, ptr %l26, !tbaa !24
  %t542 = icmp sgt i64 %t540, 0
  br i1 %t542, label %bb76, label %bb77
bb75:
  store i64 0, ptr %l206, !tbaa !24
  br label %bb79
bb76:
  %t544 = load i64, ptr %l25, !tbaa !24
  %t545 = load i64, ptr %l24, !tbaa !24
  %t548 = sub i64 %t544, %t545
  %t549 = load i64, ptr %l26, !tbaa !24
  %t552 = add i64 %t548, %t549
  %t554 = sub i64 %t552, 1
  %t555 = load i64, ptr %l26, !tbaa !24
  %t558 = sdiv i64 %t554, %t555
  store i64 %t558, ptr %l209, !tbaa !24
  br label %bb78
bb77:
  store i64 0, ptr %l209, !tbaa !24
  br label %bb78
bb78:
  %t560 = load i64, ptr %l209, !tbaa !24
  store i64 %t560, ptr %l206, !tbaa !24
  br label %bb79
bb79:
  %t561 = load i64, ptr %l206, !tbaa !24
  store i64 %t561, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb80
bb80:
  store %olang.scope zeroinitializer, ptr %s24
  %t562 = load i64, ptr %l28, !tbaa !24
  %t563 = load i64, ptr %l27, !tbaa !24
  %t566 = icmp slt i64 %t562, %t563
  %t568 = xor i1 %t566, true
  br i1 %t568, label %bb81, label %bb82
bb81:
  call void @__olang_scope_close(ptr %s24)
  br label %bb86
bb82:
  br label %bb83
bb83:
  %t570 = load i64, ptr %l24, !tbaa !24
  %t571 = load i64, ptr %l28, !tbaa !24
  %t572 = load i64, ptr %l26, !tbaa !24
  %t575 = mul i64 %t571, %t572
  %t578 = add i64 %t570, %t575
  store i64 %t578, ptr %l29, !tbaa !24
  %t580 = load i64, ptr %l29, !tbaa !24
  %t581 = load i64, ptr %l4, !tbaa !24
  %t582 = load i64, ptr %l29, !tbaa !24
  %t583 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d431, i32 0, i32 1) }, 1
  %t584 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d431, i32 0, i32 1) }, 0
  %t586 = call i64 @__olang_fmt_i64(ptr null, i64 %t580)
  %t587 = add i64 %t584, %t586
  %t588 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d432, i32 0, i32 1) }, 1
  %t589 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d432, i32 0, i32 1) }, 0
  %t590 = add i64 %t587, %t589
  %t592 = call i64 @__olang_fmt_i64(ptr null, i64 %t581)
  %t593 = add i64 %t590, %t592
  %t594 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d433, i32 0, i32 1) }, 1
  %t595 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d433, i32 0, i32 1) }, 0
  %t596 = add i64 %t593, %t595
  %t598 = call i64 @__olang_fmt_i64(ptr null, i64 %t582)
  %t599 = add i64 %t596, %t598
  %t600 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t599)
  call void @olang_textcopy(ptr %t600, ptr %t583, i64 %t584)
  %t601 = getelementptr i8, ptr %t600, i64 %t584
  %t602 = call i64 @__olang_fmt_i64(ptr %t601, i64 %t580)
  %t603 = getelementptr i8, ptr %t601, i64 %t586
  call void @olang_textcopy(ptr %t603, ptr %t588, i64 %t589)
  %t604 = getelementptr i8, ptr %t603, i64 %t589
  %t605 = call i64 @__olang_fmt_i64(ptr %t604, i64 %t581)
  %t606 = getelementptr i8, ptr %t604, i64 %t592
  call void @olang_textcopy(ptr %t606, ptr %t594, i64 %t595)
  %t607 = getelementptr i8, ptr %t606, i64 %t595
  %t608 = call i64 @__olang_fmt_i64(ptr %t607, i64 %t582)
  %t609 = insertvalue { i64, ptr } undef, i64 %t599, 0
  %t610 = insertvalue { i64, ptr } %t609, ptr %t600, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s2, ptr %s24, ptr %l23, { i64, ptr } %t610)
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s24)
  br label %bb85
bb85:
  %t614 = load i64, ptr %l28, !tbaa !24
  %t617 = add i64 %t614, 1
  store i64 %t617, ptr %l28, !tbaa !24
  br label %bb80
bb86:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s2, ptr %s2, ptr %l23, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d434, i32 0, i32 1) })
  br label %bb87
bb87:
  %t620 = load ptr, ptr %l0, !tbaa !29
  store ptr %t620, ptr %l237, !tbaa !29
  %t622 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s2, ptr %s2, ptr %l23)
  store { i64, ptr } %t622, ptr %l239
  br label %bb88
bb88:
  %t623 = load { i64, ptr }, ptr %l239, !tbaa !27
  %t624 = load ptr, ptr %l237, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s2, ptr %v2, ptr %t624, { i64, ptr } %t623)
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s2)
  br label %bb90
bb90:
  br label %bb2
bb91:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2efuzzCorpus(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l10 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l29 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d435, i32 0, i32 1) })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l6
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i64 %t4, ptr %l5
  br label %bb1
bb1:
  %t8 = load i64, ptr %l5, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t9 = load i64, ptr %l3, !tbaa !24
  store i64 %t9, ptr %l2, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp slt i64 %t10, 0
  br i1 %t12, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t16 = call { i64, ptr } @compiler_2femit_2efuzzSlug(ptr %v1, ptr %s1, { i64, ptr } %t14)
  store { i64, ptr } %t16, ptr %l10
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t17 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d436, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d436, i32 0, i32 1) }, 0
  %t19 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 1
  %t21 = extractvalue { i64, ptr } %t19, 0
  %t22 = add i64 %t18, %t21
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t17, i64 %t18)
  %t24 = getelementptr i8, ptr %t23, i64 %t18
  call void @olang_textcopy(ptr %t24, ptr %t20, i64 %t21)
  %t25 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t23, 1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t26, ptr %rv
  br label %ret
bb8:
  %t28 = load i64, ptr %l2, !tbaa !24
  %t30 = icmp eq i64 %t28, 0
  br i1 %t30, label %bb9, label %bb10
bb9:
  %t32 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t32, ptr %l15, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l16, !tbaa !24
  %t35 = icmp sge i64 0, 0
  br i1 %t35, label %bb11, label %bb12
bb10:
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t37, ptr %l21, !tbaa !27
  %t38 = load i64, ptr %l2, !tbaa !24
  store i64 %t38, ptr %l22, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l23, !tbaa !24
  %t41 = icmp sge i64 0, 0
  br i1 %t41, label %bb17, label %bb18
bb11:
  %t43 = icmp sle i64 0, 1
  br i1 %t43, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_8432ee6ea571e3a6_71b81f3ed515f9b2)
  unreachable
bb13:
  %t45 = load i64, ptr %l16, !tbaa !24
  %t46 = icmp sle i64 1, %t45
  br i1 %t46, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_8432ee6ea571e3a6_71b81f3ed515f9b2)
  unreachable
bb15:
  %t48 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr i8, ptr %t49, i64 0
  %t51 = sub i64 1, 0
  %t52 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t50, 1
  store { i64, ptr } %t53, ptr %l14, !tbaa !27
  br label %bb23
bb16:
  call void @__olang_check_failed(ptr @olang_loc_8432ee6ea571e3a6_71b81f3ed515f9b2)
  unreachable
bb17:
  %t55 = load i64, ptr %l22, !tbaa !24
  %t56 = icmp sle i64 0, %t55
  br i1 %t56, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_8432ee6ea571e3a6_71b81f3ed515f9b2)
  unreachable
bb19:
  %t58 = load i64, ptr %l22, !tbaa !24
  %t59 = load i64, ptr %l23, !tbaa !24
  %t60 = icmp sle i64 %t58, %t59
  br i1 %t60, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_8432ee6ea571e3a6_71b81f3ed515f9b2)
  unreachable
bb21:
  %t62 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = load i64, ptr %l22, !tbaa !24
  %t65 = getelementptr i8, ptr %t63, i64 0
  %t66 = sub i64 %t64, 0
  %t67 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t65, 1
  store { i64, ptr } %t68, ptr %l14, !tbaa !27
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_8432ee6ea571e3a6_71b81f3ed515f9b2)
  unreachable
bb23:
  %t70 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t72 = call { i64, ptr } @compiler_2femit_2efuzzSlug(ptr %v1, ptr %s0, { i64, ptr } %t70)
  store { i64, ptr } %t72, ptr %l29
  br label %bb24
bb24:
  %t73 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 1
  %t75 = extractvalue { i64, ptr } %t73, 0
  %t76 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d437, i32 0, i32 1) }, 1
  %t77 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d437, i32 0, i32 1) }, 0
  %t78 = add i64 %t75, %t77
  %t79 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 1
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t82 = add i64 %t78, %t81
  %t83 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t82)
  call void @olang_textcopy(ptr %t83, ptr %t74, i64 %t75)
  %t84 = getelementptr i8, ptr %t83, i64 %t75
  call void @olang_textcopy(ptr %t84, ptr %t76, i64 %t77)
  %t85 = getelementptr i8, ptr %t84, i64 %t77
  call void @olang_textcopy(ptr %t85, ptr %t80, i64 %t81)
  %t86 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t83, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t87, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2eprefixOf(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l33 = alloca { i64, ptr }
  %l36 = alloca i1
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load i64, ptr %l1, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l12, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l2, !tbaa !24
  %t16 = load i64, ptr %l1, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l15, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l15, !tbaa !24
  store i64 %t31, ptr %l12, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l12, !tbaa !24
  store i64 %t32, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb7
bb7:
  %t33 = load i64, ptr %l5, !tbaa !24
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb22
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l1, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = load i64, ptr %l3, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l6, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t51, ptr %l33, !tbaa !27
  %t52 = load i64, ptr %l6, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i8, ptr %t55, i64 %t52
  %t57 = load i8, ptr %t56, !tbaa !32
  %t59 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t57)
  store i1 %t59, ptr %l36
  br label %bb11
bb11:
  %t60 = load i1, ptr %l36, !tbaa !21
  br i1 %t60, label %bb12, label %bb13
bb12:
  %t61 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t61, ptr %l37, !tbaa !27
  %t62 = load i64, ptr %l6, !tbaa !24
  store i64 %t62, ptr %l38, !tbaa !24
  %t63 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 0
  store i64 %t64, ptr %l39, !tbaa !24
  %t65 = icmp sge i64 0, 0
  br i1 %t65, label %bb14, label %bb15
bb13:
  br label %bb20
bb14:
  %t67 = load i64, ptr %l38, !tbaa !24
  %t68 = icmp sle i64 0, %t67
  br i1 %t68, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_1e1ac9afcf25b4a6_b14a079dd13715c2)
  unreachable
bb16:
  %t70 = load i64, ptr %l38, !tbaa !24
  %t71 = load i64, ptr %l39, !tbaa !24
  %t72 = icmp sle i64 %t70, %t71
  br i1 %t72, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_1e1ac9afcf25b4a6_b14a079dd13715c2)
  unreachable
bb18:
  %t74 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = load i64, ptr %l38, !tbaa !24
  %t77 = getelementptr i8, ptr %t75, i64 0
  %t78 = sub i64 %t76, 0
  %t79 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t77, 1
  %t82 = extractvalue { i64, ptr } %t80, 1
  %t83 = extractvalue { i64, ptr } %t80, 0
  %t84 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t83)
  call void @olang_textcopy(ptr %t84, ptr %t82, i64 %t83)
  %t85 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  store { i64, ptr } %t86, ptr %rv
  br label %ret
bb19:
  call void @__olang_check_failed(ptr @olang_loc_1e1ac9afcf25b4a6_b14a079dd13715c2)
  unreachable
bb20:
  br label %bb21
bb21:
  %t88 = load i64, ptr %l5, !tbaa !24
  %t91 = add i64 %t88, 1
  store i64 %t91, ptr %l5, !tbaa !24
  br label %bb7
bb22:
  %t93 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t93, 1
  %t96 = extractvalue { i64, ptr } %t93, 0
  %t97 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d438, i32 0, i32 1) }, 1
  %t98 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d438, i32 0, i32 1) }, 0
  %t99 = add i64 %t96, %t98
  %t100 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t99)
  call void @olang_textcopy(ptr %t100, ptr %t95, i64 %t96)
  %t101 = getelementptr i8, ptr %t100, i64 %t96
  call void @olang_textcopy(ptr %t101, ptr %t97, i64 %t98)
  %t102 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t100, 1
  store { i64, ptr } %t103, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2femit_2erefsIn(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i8
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca { i64, ptr }
  %l26 = alloca i1
  %l27 = alloca { i64, ptr }
  %l43 = alloca i1
  %l44 = alloca { i64, ptr }
  %l54 = alloca i1
  %l59 = alloca i1
  %l60 = alloca { i64, ptr }
  %l71 = alloca i1
  %l72 = alloca { i64, ptr }
  %l96 = alloca i1
  %l97 = alloca { i64, ptr }
  %l100 = alloca i1
  %l115 = alloca i1
  %l120 = alloca i1
  %l121 = alloca { i64, ptr }
  %l125 = alloca i1
  %l133 = alloca i1
  %l134 = alloca { i64, ptr }
  %l137 = alloca i1
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb94
bb4:
  br label %bb5
bb5:
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t15, ptr %l15, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 %t16
  %t21 = load i8, ptr %t20, !tbaa !32
  store i8 %t21, ptr %l4, !tbaa !22
  %t23 = load i8, ptr %l4, !tbaa !22
  %t25 = icmp eq i8 %t23, 34
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t27 = load i64, ptr %l3, !tbaa !24
  %t30 = add i64 %t27, 1
  store i64 %t30, ptr %l3, !tbaa !24
  br label %bb8
bb7:
  %t32 = load i8, ptr %l4, !tbaa !22
  %t34 = icmp eq i8 %t32, 59
  br i1 %t34, label %bb17, label %bb18
bb8:
  %t36 = load i64, ptr %l3, !tbaa !24
  %t37 = load i64, ptr %l2, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  br i1 %t40, label %bb9, label %bb10
bb9:
  %t42 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t42, ptr %l27, !tbaa !27
  %t43 = load i64, ptr %l3, !tbaa !24
  %t45 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr i8, ptr %t46, i64 %t43
  %t48 = load i8, ptr %t47, !tbaa !32
  %t50 = icmp ne i8 %t48, 34
  store i1 %t50, ptr %l26, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb11
bb11:
  %t52 = load i1, ptr %l26, !tbaa !21
  %t53 = xor i1 %t52, true
  br i1 %t53, label %bb12, label %bb13
bb12:
  br label %bb16
bb13:
  br label %bb14
bb14:
  %t55 = load i64, ptr %l3, !tbaa !24
  %t58 = add i64 %t55, 1
  store i64 %t58, ptr %l3, !tbaa !24
  br label %bb15
bb15:
  br label %bb8
bb16:
  %t60 = load i64, ptr %l3, !tbaa !24
  %t63 = add i64 %t60, 1
  store i64 %t63, ptr %l3, !tbaa !24
  br label %bb92
bb17:
  br label %bb19
bb18:
  %t65 = load i8, ptr %l4, !tbaa !22
  %t67 = icmp eq i8 %t65, 37
  br i1 %t67, label %bb28, label %bb29
bb19:
  %t69 = load i64, ptr %l3, !tbaa !24
  %t70 = load i64, ptr %l2, !tbaa !24
  %t73 = icmp slt i64 %t69, %t70
  br i1 %t73, label %bb20, label %bb21
bb20:
  %t75 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t75, ptr %l44, !tbaa !27
  %t76 = load i64, ptr %l3, !tbaa !24
  %t78 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr i8, ptr %t79, i64 %t76
  %t81 = load i8, ptr %t80, !tbaa !32
  %t83 = icmp ne i8 %t81, 10
  store i1 %t83, ptr %l43, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb22
bb22:
  %t85 = load i1, ptr %l43, !tbaa !21
  %t86 = xor i1 %t85, true
  br i1 %t86, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t88 = load i64, ptr %l3, !tbaa !24
  %t91 = add i64 %t88, 1
  store i64 %t91, ptr %l3, !tbaa !24
  br label %bb26
bb26:
  br label %bb19
bb27:
  br label %bb91
bb28:
  %t93 = load i64, ptr %l3, !tbaa !24
  %t95 = add i64 %t93, 1
  %t96 = load i64, ptr %l2, !tbaa !24
  %t99 = icmp slt i64 %t95, %t96
  store i1 %t99, ptr %l54, !tbaa !21
  br label %bb30
bb29:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb30
bb30:
  %t101 = load i1, ptr %l54, !tbaa !21
  br i1 %t101, label %bb31, label %bb32
bb31:
  %t102 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t102, ptr %l60, !tbaa !27
  %t103 = load i64, ptr %l3, !tbaa !24
  %t105 = add i64 %t103, 1
  %t107 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr i8, ptr %t108, i64 %t105
  %t110 = load i8, ptr %t109, !tbaa !32
  %t112 = icmp eq i8 %t110, 34
  store i1 %t112, ptr %l59, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb33
bb33:
  %t114 = load i1, ptr %l59, !tbaa !21
  br i1 %t114, label %bb34, label %bb35
bb34:
  %t115 = load i64, ptr %l3, !tbaa !24
  %t117 = add i64 %t115, 2
  store i64 %t117, ptr %l5, !tbaa !24
  %t119 = load i64, ptr %l5, !tbaa !24
  store i64 %t119, ptr %l3, !tbaa !24
  br label %bb36
bb35:
  %t121 = load i8, ptr %l4, !tbaa !22
  %t123 = icmp eq i8 %t121, 64
  br i1 %t123, label %bb48, label %bb49
bb36:
  %t125 = load i64, ptr %l3, !tbaa !24
  %t126 = load i64, ptr %l2, !tbaa !24
  %t129 = icmp slt i64 %t125, %t126
  br i1 %t129, label %bb37, label %bb38
bb37:
  %t131 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t131, ptr %l72, !tbaa !27
  %t132 = load i64, ptr %l3, !tbaa !24
  %t134 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = getelementptr i8, ptr %t135, i64 %t132
  %t137 = load i8, ptr %t136, !tbaa !32
  %t139 = icmp ne i8 %t137, 34
  store i1 %t139, ptr %l71, !tbaa !21
  br label %bb39
bb38:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb39
bb39:
  %t141 = load i1, ptr %l71, !tbaa !21
  %t142 = xor i1 %t141, true
  br i1 %t142, label %bb40, label %bb41
bb40:
  br label %bb44
bb41:
  br label %bb42
bb42:
  %t144 = load i64, ptr %l3, !tbaa !24
  %t147 = add i64 %t144, 1
  store i64 %t147, ptr %l3, !tbaa !24
  br label %bb43
bb43:
  br label %bb36
bb44:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %l1, i64 1)
  br label %bb45
bb45:
  %t150 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %l1, i64 %t150)
  br label %bb46
bb46:
  %t153 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %l1, i64 %t153)
  br label %bb47
bb47:
  %t156 = load i64, ptr %l3, !tbaa !24
  %t159 = add i64 %t156, 1
  store i64 %t159, ptr %l3, !tbaa !24
  br label %bb90
bb48:
  %t161 = load i64, ptr %l3, !tbaa !24
  %t163 = add i64 %t161, 1
  store i64 %t163, ptr %l6, !tbaa !24
  %t165 = load i64, ptr %l6, !tbaa !24
  store i64 %t165, ptr %l3, !tbaa !24
  br label %bb50
bb49:
  %t167 = load i8, ptr %l4, !tbaa !22
  %t169 = icmp eq i8 %t167, 33
  br i1 %t169, label %bb66, label %bb67
bb50:
  %t171 = load i64, ptr %l3, !tbaa !24
  %t172 = load i64, ptr %l2, !tbaa !24
  %t175 = icmp slt i64 %t171, %t172
  br i1 %t175, label %bb51, label %bb52
bb51:
  %t177 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t177, ptr %l97, !tbaa !27
  %t178 = load i64, ptr %l3, !tbaa !24
  %t180 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !27
  %t182 = getelementptr i8, ptr %t181, i64 %t178
  %t183 = load i8, ptr %t182, !tbaa !32
  %t185 = call i1 @compiler_2femit_2esymbolChar(i8 %t183)
  store i1 %t185, ptr %l100
  br label %bb53
bb52:
  store i1 false, ptr %l96, !tbaa !21
  br label %bb54
bb53:
  %t186 = load i1, ptr %l100, !tbaa !21
  store i1 %t186, ptr %l96, !tbaa !21
  br label %bb54
bb54:
  %t187 = load i1, ptr %l96, !tbaa !21
  %t188 = xor i1 %t187, true
  br i1 %t188, label %bb55, label %bb56
bb55:
  br label %bb59
bb56:
  br label %bb57
bb57:
  %t190 = load i64, ptr %l3, !tbaa !24
  %t193 = add i64 %t190, 1
  store i64 %t193, ptr %l3, !tbaa !24
  br label %bb58
bb58:
  br label %bb50
bb59:
  %t195 = load i64, ptr %l3, !tbaa !24
  %t196 = load i64, ptr %l6, !tbaa !24
  %t199 = icmp sgt i64 %t195, %t196
  br i1 %t199, label %bb60, label %bb61
bb60:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %l1, i64 0)
  br label %bb62
bb61:
  br label %bb65
bb62:
  %t202 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %l1, i64 %t202)
  br label %bb63
bb63:
  %t205 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %l1, i64 %t205)
  br label %bb64
bb64:
  br label %bb65
bb65:
  br label %bb89
bb66:
  %t208 = load i64, ptr %l3, !tbaa !24
  %t210 = add i64 %t208, 1
  %t211 = load i64, ptr %l2, !tbaa !24
  %t214 = icmp slt i64 %t210, %t211
  store i1 %t214, ptr %l115, !tbaa !21
  br label %bb68
bb67:
  store i1 false, ptr %l115, !tbaa !21
  br label %bb68
bb68:
  %t216 = load i1, ptr %l115, !tbaa !21
  br i1 %t216, label %bb69, label %bb70
bb69:
  %t217 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t217, ptr %l121, !tbaa !27
  %t218 = load i64, ptr %l3, !tbaa !24
  %t220 = add i64 %t218, 1
  %t222 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t223 = load ptr, ptr %t222, !tbaa !27
  %t224 = getelementptr i8, ptr %t223, i64 %t220
  %t225 = load i8, ptr %t224, !tbaa !32
  %t227 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t225)
  store i1 %t227, ptr %l125
  br label %bb71
bb70:
  store i1 false, ptr %l120, !tbaa !21
  br label %bb72
bb71:
  %t228 = load i1, ptr %l125, !tbaa !21
  store i1 %t228, ptr %l120, !tbaa !21
  br label %bb72
bb72:
  %t229 = load i1, ptr %l120, !tbaa !21
  br i1 %t229, label %bb73, label %bb74
bb73:
  %t230 = load i64, ptr %l3, !tbaa !24
  store i64 %t230, ptr %l7, !tbaa !24
  %t232 = load i64, ptr %l3, !tbaa !24
  %t235 = add i64 %t232, 1
  store i64 %t235, ptr %l3, !tbaa !24
  br label %bb75
bb74:
  %t237 = load i64, ptr %l3, !tbaa !24
  %t240 = add i64 %t237, 1
  store i64 %t240, ptr %l3, !tbaa !24
  br label %bb88
bb75:
  %t242 = load i64, ptr %l3, !tbaa !24
  %t243 = load i64, ptr %l2, !tbaa !24
  %t246 = icmp slt i64 %t242, %t243
  br i1 %t246, label %bb76, label %bb77
bb76:
  %t248 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t248, ptr %l134, !tbaa !27
  %t249 = load i64, ptr %l3, !tbaa !24
  %t251 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t252 = load ptr, ptr %t251, !tbaa !27
  %t253 = getelementptr i8, ptr %t252, i64 %t249
  %t254 = load i8, ptr %t253, !tbaa !32
  %t256 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t254)
  store i1 %t256, ptr %l137
  br label %bb78
bb77:
  store i1 false, ptr %l133, !tbaa !21
  br label %bb79
bb78:
  %t257 = load i1, ptr %l137, !tbaa !21
  store i1 %t257, ptr %l133, !tbaa !21
  br label %bb79
bb79:
  %t258 = load i1, ptr %l133, !tbaa !21
  %t259 = xor i1 %t258, true
  br i1 %t259, label %bb80, label %bb81
bb80:
  br label %bb84
bb81:
  br label %bb82
bb82:
  %t261 = load i64, ptr %l3, !tbaa !24
  %t264 = add i64 %t261, 1
  store i64 %t264, ptr %l3, !tbaa !24
  br label %bb83
bb83:
  br label %bb75
bb84:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %l1, i64 2)
  br label %bb85
bb85:
  %t267 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %l1, i64 %t267)
  br label %bb86
bb86:
  %t270 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %l1, i64 %t270)
  br label %bb87
bb87:
  br label %bb88
bb88:
  br label %bb89
bb89:
  br label %bb90
bb90:
  br label %bb91
bb91:
  br label %bb92
bb92:
  br label %bb93
bb93:
  br label %bb2
bb94:
  %t273 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t273, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i1 @compiler_2femit_2etypeDelim(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = icmp eq i8 %t1, 60
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i8, ptr %l0, !tbaa !22
  %t7 = icmp eq i8 %t5, 123
  store i1 %t7, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t10 = load i8, ptr %l0, !tbaa !22
  %t12 = icmp eq i8 %t10, 44
  store i1 %t12, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb9
bb8:
  %t15 = load i8, ptr %l0, !tbaa !22
  %t17 = icmp eq i8 %t15, 32
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb12
bb11:
  %t20 = load i8, ptr %l0, !tbaa !22
  %t22 = icmp eq i8 %t20, 40
  store i1 %t22, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb15
bb14:
  %t25 = load i8, ptr %l0, !tbaa !22
  %t27 = icmp eq i8 %t25, 91
  store i1 %t27, ptr %l15, !tbaa !21
  br label %bb15
bb15:
  %t29 = load i1, ptr %l15, !tbaa !21
  br i1 %t29, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb18
bb17:
  %t30 = load i8, ptr %l0, !tbaa !22
  %t32 = icmp eq i8 %t30, 38
  store i1 %t32, ptr %l18, !tbaa !21
  br label %bb18
bb18:
  %t34 = load i1, ptr %l18, !tbaa !21
  br i1 %t34, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb21
bb20:
  %t35 = load i8, ptr %l0, !tbaa !22
  %t37 = icmp eq i8 %t35, 63
  store i1 %t37, ptr %l21, !tbaa !21
  br label %bb21
bb21:
  %t39 = load i1, ptr %l21, !tbaa !21
  store i1 %t39, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d0 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"!" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d1 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d2 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c"!DIDerivedType(tag: DW_TAG_pointer_type, baseType: " }>, align 8
@.d3 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c", size: 64)" }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d4 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"!DIDerivedType(tag: DW_TAG_member, name: \22" }>, align 8
@.d5 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"\22, baseType: !" }>, align 8
@.d6 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c", size: 64, offset: 0)" }>, align 8
@.d7 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"!DIDerivedType(tag: DW_TAG_member, name: \22" }>, align 8
@.d8 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"\22, baseType: !" }>, align 8
@.d9 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c", size: 64, offset: 64)" }>, align 8
@.d10 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"!{!" }>, align 8
@.d11 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", !" }>, align 8
@.d12 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d13 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c"!DICompositeType(tag: DW_TAG_structure_type, name: \22" }>, align 8
@.d14 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"\22, size: 128, elements: !" }>, align 8
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d16 = private constant <{ i64, [66 x i8] }> <{ i64 0, [66 x i8] c"!DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)" }>, align 8
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3aEmitter__2eexportParams_2elocal_2e18 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
@.d17 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"%p" }>, align 8
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle_in(ptr, ptr)
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
@.d18 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ptr " }>, align 8
@.d19 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"i64 " }>, align 8
@.d20 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"n" }>, align 8
@.d21 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"insertvalue { i64, ptr } undef, i64 " }>, align 8
@.d22 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"n, 0" }>, align 8
@.d23 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"insertvalue { i64, ptr } " }>, align 8
@.d24 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d25 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d26 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"{ i64, ptr } " }>, align 8
@.d27 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ptr " }>, align 8
@.d28 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ptr " }>, align 8
@.d29 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d30 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d31 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d32 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d33 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d34 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d35 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" x i8]" }>, align 8
@.d36 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d37 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d38 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"getelementptr i8, ptr " }>, align 8
@.d39 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d40 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c" alignstack(8)" }>, align 8
@.d41 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d42 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d43 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @__olang_region_release(ptr) noinline
@.d44 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"ptr byval(" }>, align 8
@.d45 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c") align " }>, align 8
@.d46 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d47 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ptr " }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
@.d48 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ptr " }>, align 8
@.d49 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d50 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d51 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d52 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d53 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d54 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d55 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d56 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" (" }>, align 8
@.d57 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d58 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"not lowered: " }>, align 8
@.d59 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"entry:\0A  ret void\0A}\0A\0A" }>, align 8
@.d60 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"__olang_check_failed" }>, align 8
@.d61 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"not lowered" }>, align 8
@.d62 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"not lowered" }>, align 8
@.d63 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".walk" }>, align 8
@.d64 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" alwaysinline" }>, align 8
@.d65 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".walk" }>, align 8
@.d66 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"olang_fvadapt_" }>, align 8
@.d67 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"linkonce_odr" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d68 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d69 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"%env" }>, align 8
@.d70 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c"getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1" }>, align 8
@.d71 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d72 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ptr " }>, align 8
@.d73 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c", ptr %out" }>, align 8
@.d74 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", ptr %v" }>, align 8
@.d75 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d76 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", ptr %a" }>, align 8
@.d77 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", ptr %a" }>, align 8
@.d78 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"c, ptr %a" }>, align 8
@.d79 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"e" }>, align 8
@.d80 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d81 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" %a" }>, align 8
@.d82 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d83 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"call void " }>, align 8
@.d84 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d85 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d86 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d87 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"ret void" }>, align 8
@.d88 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"ret i32 0" }>, align 8
@.d89 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"call " }>, align 8
@.d90 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d91 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d92 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d93 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
@olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3aEmitter__2efvAdapter_2elocal_2e35 = weak hidden constant i1 false
@.d94 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"extractvalue " }>, align 8
@.d95 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d96 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d97 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d98 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"extractvalue " }>, align 8
@.d99 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d100 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d101 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i32" }>, align 8
@.d102 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"ret i32 " }>, align 8
@.d103 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ret " }>, align 8
@.d104 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d105 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"insertvalue " }>, align 8
@.d106 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c" zeroinitializer, i32 " }>, align 8
@.d107 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d108 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"insertvalue " }>, align 8
@.d109 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d110 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d111 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d112 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ret " }>, align 8
@.d113 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d114 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"olang_fvadapt_" }>, align 8
@.d115 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"entry:\0A" }>, align 8
@.d116 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"}\0A\0A" }>, align 8
@.d117 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d118 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"define internal void @" }>, align 8
@.d119 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c".drop(ptr %h, ptr %scope) #0 {\0Aentry:\0A" }>, align 8
@.d120 = private constant <{ i64, [60 x i8] }> <{ i64 0, [60 x i8] c"  %p = call ptr @llvm.coro.promise(ptr %h, i32 8, i1 false)\0A" }>, align 8
@.d121 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"  %pr = getelementptr " }>, align 8
@.d122 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c", ptr %p, i32 0, i32 1\0A  %r = load i32, ptr %pr\0A" }>, align 8
@.d123 = private constant <{ i64, [104 x i8] }> <{ i64 0, [104 x i8] c"  %idle = icmp eq i32 %r, 0\0A  br i1 %idle, label %d, label %x\0Ad:\0A  call void @llvm.coro.destroy(ptr %h)\0A" }>, align 8
@.d124 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"  br label %x\0Ax:\0A  ret void\0A}\0A\0A" }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2femit_3aReused(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/emit:Reused"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 192, i1 false)
  %t2 = getelementptr %"compiler/emit:Reused", ptr %l1, i32 0, i32 1
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t6 = getelementptr %"compiler/emit:Reused", ptr %l1, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  %t7 = getelementptr %"compiler/emit:Reused", ptr %l1, i32 0, i32 2
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cBool_3e(ptr %v0, ptr %t7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t11 = getelementptr %"compiler/emit:Reused", ptr %l1, i32 0, i32 2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %t11
  %t12 = getelementptr %"compiler/emit:Reused", ptr %l1, i32 0, i32 3
  %t14 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t12)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l7
  br label %bb3
bb3:
  %t15 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t16 = getelementptr %"compiler/emit:Reused", ptr %l1, i32 0, i32 3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %t16
  %t17 = getelementptr %"compiler/emit:Reused", ptr %l1, i32 0, i32 7
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t17)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l9
  br label %bb4
bb4:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  %t21 = getelementptr %"compiler/emit:Reused", ptr %l1, i32 0, i32 7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %t21
  %t22 = getelementptr %"compiler/emit:Reused", ptr %l1, i32 0, i32 8
  %t24 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t22)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l11
  br label %bb5
bb5:
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  %t26 = getelementptr %"compiler/emit:Reused", ptr %l1, i32 0, i32 8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %t26
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 192, i1 false)
  br label %ret
ret:
  ret void
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d125 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d126 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3aEmitter__2ereadableTypes_2elocal_2e10 = weak hidden constant i1 false
@.d127 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d128 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"*/" }>, align 8
@.d129 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"* /" }>, align 8
@olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3aEmitter__2ewriteBody_2elocal_2e8 = weak hidden constant i1 false
@.d130 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"__olang_check_failed" }>, align 8
@.d131 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"not emitted" }>, align 8
@.d132 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"not emitted" }>, align 8
@.d133 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"define internal ptr @" }>, align 8
@.d134 = private constant <{ i64, [63 x i8] }> <{ i64 0, [63 x i8] c".coro(ptr %env, ptr %home) presplitcoroutine alwaysinline #0 {\0A" }>, align 8
@.d135 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" !dbg !" }>, align 8
@.d136 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" {\0A" }>, align 8
@.d137 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"entry:\0A" }>, align 8
@.d138 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"  br label %start\0A" }>, align 8
@.d139 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"}\0A" }>, align 8
@olang_2esole_2estd_2fprelude_2ftext_3aLineIter_2e0 = weak hidden constant i1 false
declare ptr @__olang_scope_or(ptr, ptr)
@.d140 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fcabi_3aWay_2e1 = weak hidden constant i1 false
declare ptr @__olang_region_home(ptr)
@olang_2esole_2ecompiler_2fcabi_3aWay_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fcabi_3aWay_2e3 = weak hidden constant i1 false
@.d141 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @__olang_region_drop(ptr) noinline
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0 = weak hidden constant i1 false
declare void @__olang_region_release_part(ptr, i64) noinline
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fcabi_3aWay_2e4 = weak hidden constant i1 false
@olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ecCall_2elocal_2e10 = weak hidden constant i1 false
@.d142 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"ptr sret(" }>, align 8
@.d143 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c") align " }>, align 8
@.d144 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d145 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d146 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"@__olang_" }>, align 8
@.d147 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"ptr @" }>, align 8
@.d148 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d149 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ecCall_2elocal_2e34 = weak hidden constant i1 false
@olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ecCall_2elocal_2e35 = weak hidden constant i1 false
@.d150 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c", ..." }>, align 8
@.d151 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"..." }>, align 8
@.d152 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" (" }>, align 8
@.d153 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d154 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d155 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ecCall_2elocal_2e36 = weak hidden constant i1 false
@.d156 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"call " }>, align 8
@.d157 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d158 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d159 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d160 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"call " }>, align 8
@.d161 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d162 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d163 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d164 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"unreachable" }>, align 8
@.d165 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"br label %" }>, align 8
@.d166 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" @" }>, align 8
@.d167 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d168 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d169 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d170 = private constant <{ i64, [49 x i8] }> <{ i64 0, [49 x i8] c"a C function pointer that is no export fn's entry" }>, align 8
@.d171 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d172 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"|" }>, align 8
@.d173 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d174 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d175 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d176 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"__olang_gen_mine" }>, align 8
@.d177 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"getelementptr { i64, ptr }, ptr " }>, align 8
@.d178 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", i32 0, i32 1" }>, align 8
@.d179 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d180 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"call ptr @__olang_gen_mine(ptr " }>, align 8
@.d181 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d182 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d183 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"store ptr " }>, align 8
@.d184 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d185 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", align 8" }>, align 8
@.d186 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"trunc " }>, align 8
@.d187 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d188 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" to i64" }>, align 8
@.d189 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"zext" }>, align 8
@.d190 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"sext" }>, align 8
@.d191 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d192 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" to i64" }>, align 8
@.d193 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"i" }>, align 8
@.d194 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"zext i" }>, align 8
@.d195 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d196 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" to " }>, align 8
@.d197 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"shl " }>, align 8
@.d198 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d199 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d200 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"lshr " }>, align 8
@.d201 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" -1, " }>, align 8
@.d202 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-1" }>, align 8
@.d203 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"shl " }>, align 8
@.d204 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d205 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d206 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"xor " }>, align 8
@.d207 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d208 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c", -1" }>, align 8
@.d209 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"and " }>, align 8
@.d210 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d211 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d212 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"or " }>, align 8
@.d213 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d214 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d215 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"lshr i32 " }>, align 8
@.d216 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c", 16" }>, align 8
@.d217 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"and i32 " }>, align 8
@.d218 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c", 65535" }>, align 8
@.d219 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
@.d220 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"icmp eq i32 " }>, align 8
@.d221 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2erecode_2elocal_2e8 = weak hidden constant i1 false
@.d222 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"select i1 " }>, align 8
@.d223 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i32 " }>, align 8
@.d224 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"icmp eq i32 " }>, align 8
@.d225 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d226 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"shl i32 " }>, align 8
@.d227 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c", 16" }>, align 8
@.d228 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"or i32 " }>, align 8
@.d229 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d230 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"select i1 " }>, align 8
@.d231 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", i32 0, i32 " }>, align 8
@.d232 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"i" }>, align 8
@.d233 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"u" }>, align 8
@.d234 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"zext " }>, align 8
@.d235 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"sext " }>, align 8
@.d236 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d237 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" to " }>, align 8
@.d238 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d239 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" to " }>, align 8
@olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2esatMulWide_2elocal_2e10 = weak hidden constant i1 false
@.d240 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"u" }>, align 8
@.d241 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"nuw " }>, align 8
@.d242 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"nsw " }>, align 8
@.d243 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"mul " }>, align 8
@.d244 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d245 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d246 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"u" }>, align 8
@.d247 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"umin" }>, align 8
@.d248 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"smin" }>, align 8
@.d249 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"smax" }>, align 8
@.d250 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"trunc " }>, align 8
@.d251 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d252 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" to " }>, align 8
@.d253 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"__olang_slot_chunk" }>, align 8
@.d254 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"%olang.slotscope" }>, align 8
@.d255 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"store %olang.scope zeroinitializer, ptr " }>, align 8
@.d256 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"store ptr @__olang_slot_chunk, ptr " }>, align 8
@.d257 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"getelementptr %olang.scope, ptr " }>, align 8
@.d258 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", i32 0, i32 2" }>, align 8
@.d259 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"store ptr " }>, align 8
@.d260 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d261 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"getelementptr %olang.slotscope, ptr " }>, align 8
@.d262 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", i32 0, i32 1" }>, align 8
@.d263 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"store i64 0, ptr " }>, align 8
@.d264 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"%s" }>, align 8
@.d265 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d266 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2espawn_2elocal_2e7 = weak hidden constant i1 false
@.d267 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d268 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d269 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"a task calling an extern" }>, align 8
@olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2espawn_2elocal_2e9 = weak hidden constant i1 false
@.d270 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"a task calling through an any" }>, align 8
@.d271 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"a task calling through a C function pointer" }>, align 8
@.d272 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"{ ptr, ptr }" }>, align 8
@.d273 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d274 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d275 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d276 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"__olang_standin_or" }>, align 8
@.d277 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"__olang_standin_in" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d278 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2espawn_2elocal_2e37 = weak hidden constant i1 false
@.d279 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"true" }>, align 8
@.d280 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d281 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"i1" }>, align 8
@.d282 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c", i1 " }>, align 8
@.d283 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"call ptr @" }>, align 8
@.d284 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(ptr " }>, align 8
@.d285 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d286 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d287 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d288 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"{ ptr, ptr }" }>, align 8
@.d289 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d290 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d291 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"__olang_standin_in" }>, align 8
@.d292 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"call ptr @__olang_standin_in(ptr " }>, align 8
@.d293 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d294 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d295 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d296 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"__olang_standin_in" }>, align 8
@.d297 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"call ptr @__olang_standin_in(ptr " }>, align 8
@.d298 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d299 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d300 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d301 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"{ " }>, align 8
@.d302 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d303 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"i8" }>, align 8
@.d304 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" }" }>, align 8
@.d305 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"__olang_scope_alloc_a" }>, align 8
@.d306 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"getelementptr " }>, align 8
@.d307 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c", ptr null, i32 1" }>, align 8
@.d308 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"ptrtoint ptr " }>, align 8
@.d309 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" to i64" }>, align 8
@.d310 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"call ptr @__olang_scope_alloc_a(ptr " }>, align 8
@.d311 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d312 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", i64 8)" }>, align 8
@.d313 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"getelementptr " }>, align 8
@.d314 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d315 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", i32 0, i32 " }>, align 8
@.d316 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d317 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d318 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"call ptr @__olang_scope_alloc_a(ptr " }>, align 8
@.d319 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c", i64 40, i64 8)" }>, align 8
@.d320 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d321 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"call ptr @__olang_scope_alloc_a(ptr " }>, align 8
@.d322 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c", i64 16, i64 8)" }>, align 8
@.d323 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d324 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"getelementptr { ptr, ptr }, ptr " }>, align 8
@.d325 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", i32 0, i32 1" }>, align 8
@.d326 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2espawn_2elocal_2e84 = weak hidden constant i1 false
@.d327 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c"getelementptr { ptr, i64, ptr, i64, ptr }, ptr " }>, align 8
@.d328 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", i32 0, i32 2" }>, align 8
@.d329 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d330 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c"getelementptr { ptr, i64, ptr, i64, ptr }, ptr " }>, align 8
@.d331 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", i32 0, i32 1" }>, align 8
@.d332 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i64" }>, align 8
@.d333 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
@.d334 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c"getelementptr { ptr, i64, ptr, i64, ptr }, ptr " }>, align 8
@.d335 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", i32 0, i32 3" }>, align 8
@.d336 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i64" }>, align 8
@.d337 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
@.d338 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c"getelementptr { ptr, i64, ptr, i64, ptr }, ptr " }>, align 8
@.d339 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", i32 0, i32 4" }>, align 8
@.d340 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d341 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d342 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"__olang_worker_get" }>, align 8
@.d343 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"ptr @__olang_worker_get()" }>, align 8
@.d344 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"__olang_worker_start" }>, align 8
@.d345 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"void @__olang_worker_start(ptr, ptr, ptr, ptr)" }>, align 8
@.d346 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"call ptr @__olang_worker_get()" }>, align 8
@.d347 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"call void @__olang_worker_start(ptr " }>, align 8
@.d348 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c", ptr @" }>, align 8
@.d349 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d350 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d351 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%jh" }>, align 8
@.d352 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d353 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d354 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%jh" }>, align 8
@.d355 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d356 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"  %hd" }>, align 8
@.d357 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d358 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" = load ptr, ptr %f" }>, align 8
@.d359 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d360 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"  %hx" }>, align 8
@.d361 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d362 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c" = extractvalue " }>, align 8
@.d363 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d364 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d365 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d366 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"  store " }>, align 8
@.d367 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" %hx" }>, align 8
@.d368 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d369 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", ptr %hd" }>, align 8
@.d370 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d371 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2etailCall_2elocal_2e4 = weak hidden constant i1 false
@.d372 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d373 = private constant <{ i64, [49 x i8] }> <{ i64 0, [49 x i8] c"a become's call of a function with an environment" }>, align 8
@.d374 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"a become's call of anything but a function" }>, align 8
@.d375 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"unreachable" }>, align 8
@.d376 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d377 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ptr " }>, align 8
@.d378 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d379 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"a become's argument passed through memory" }>, align 8
@.d380 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"extractvalue { ptr, ptr } " }>, align 8
@.d381 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d382 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"extractvalue { ptr, ptr } " }>, align 8
@.d383 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d384 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ptr " }>, align 8
@.d385 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d386 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d387 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d388 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"musttail call void " }>, align 8
@.d389 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d390 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d391 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"ret void" }>, align 8
@.d392 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"musttail call " }>, align 8
@.d393 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d394 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d395 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d396 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ret " }>, align 8
@.d397 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d398 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%ws" }>, align 8
@.d399 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i32" }>, align 8
@.d400 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"br label %wend" }>, align 8
@.d401 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"wend" }>, align 8
@.d402 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".c" }>, align 8
@.d403 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"wend" }>, align 8
@.d404 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%wh" }>, align 8
@.d405 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d406 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%wc" }>, align 8
@.d407 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d408 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"call ptr @llvm.coro.promise(ptr " }>, align 8
@.d409 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c", i32 8, i1 false)" }>, align 8
@.d410 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"getelementptr { " }>, align 8
@.d411 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", i32 }, ptr " }>, align 8
@.d412 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", i32 0, i32 1" }>, align 8
@.d413 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i32" }>, align 8
@.d414 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"2" }>, align 8
@.d415 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ptr " }>, align 8
@.d416 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d417 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c", ptr null" }>, align 8
@.d418 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d419 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"call void " }>, align 8
@.d420 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d421 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d422 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"call " }>, align 8
@.d423 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d424 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d425 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d426 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%ws" }>, align 8
@.d427 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i32" }>, align 8
@.d428 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"switch i32 " }>, align 8
@.d429 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", label %wend" }>, align 8
@.d430 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".c0 [" }>, align 8
@.d431 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" i32 " }>, align 8
@.d432 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", label %wend" }>, align 8
@.d433 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".c" }>, align 8
@.d434 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" ]" }>, align 8
@.d435 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d436 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"testdata/fuzz/" }>, align 8
@.d437 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"/testdata/fuzz/" }>, align 8
@.d438 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cBool_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgType(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgTypeName(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2eescape(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePassing(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eabiArch(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/cabi:Way" @compiler_2fcabi_2eWay_2eParam(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, i32 %a2, ptr %a3)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcabi_2eSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %a0, i64 %a1)
@olang_loc_a19b535d764b2fc2_b8d21aa34486a36 = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eslot(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ememmove(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i64 %a3)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehomeOf(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclared(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare ptr @compiler_2flower_2ecompiler_2flower_3aLowerer_2eLowerKey(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehasEnv(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2epassedOf(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2elinkFor(ptr %v0, i64 %a0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eheader(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, { i64, ptr } %a3, i64 %a4, i1 %a5, { i64, ptr } %a6, { i64, ptr } %a7, i64 %a8)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eVerify(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2egap(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efnItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, { i64, ptr } %a3, i64 %a4, i1 %a5, { i64, ptr } %a6)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2estub(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewalkStub(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, { i64, ptr } %a3, i64 %a4, i1 %a5, { i64, ptr } %a6)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisGenFn(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eadaptKey(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare void @compiler_2fmir_3aFn_2ector(ptr %out, ptr %v0, { i64, [2 x i64] } %a0, i32 %a1, i64 %a2, %"compiler/source:Span" %a3)
declare void @compiler_2femit_3afnEm_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2esignature(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eprogram(ptr %v0, ptr %v1, ptr %v2, ptr %a0)
@olang_loc_e3ad71d8c7542caf_f4839b67a89e1c73 = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2femit_2eHomeShared = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i64 %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_5ff468ede8d2dad5_ce6794a5e99bfc39 = external constant [0 x i8]
@olang_loc_fd5758dba8282ae8_cbed788f914882ac = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aReused_3e_2eAt_3ccompiler_2femit_3aReused_3e(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2femit_2eHomeInst = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FD\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2egroupReached(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_616c6f643d0ce9fd_dfe523617d4699c1 = external constant [0 x i8]
@olang_loc_b37ed008d0080fcc_cc9019489ebc5a30 = external constant [0 x i8]
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_1a9d82a78676b0a6_b4156ec517c232f2 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fload_2eErrQualifier(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1)
@olang_loc_59a9be6f9464903_424bcbda67d6186f = external constant [0 x i8]
@olang_loc_f7c6dddb13d754e8_bd1e858aa2031304 = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_42bc5298e90f43ae_6d491b8985e0cdda = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %a0, i8 %a1)
@olang_loc_5c86fd64ff4c2cab_ac7223dcbaf0ef37 = external constant [0 x i8]
@olang_loc_6f064da57090b2af_17093dce158f11fb = external constant [0 x i8]
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbg(ptr %v0, ptr %a0)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2esubprogram(ptr %v0, ptr %v1, ptr %v2, ptr %a0)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2erun(ptr %v0, ptr %v1, ptr %v2, ptr %a0)
@olang_loc_8de51998cc7658b0_11d2469cc10d3f54 = external constant [0 x i8]
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2edeclareVars(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenNext(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, [2 x i64] } %a1, ptr %a2, { i64, ptr } %a3, i64 %a4, { i64, ptr } %a5, i1 %a6)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2femit_2efoldSlots(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2eframeKept(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_538eacb44f7c8f74_e1c936133deb4fd8 = external constant [0 x i8]
declare %"compiler/cabi:Regs" @compiler_2fcabi_3aRegs_2ector(ptr %v0, i64 %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, i32 %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a3, { i64, ptr } %a4)
declare %"compiler/cabi:Way" @compiler_2fcabi_2eWay_2eResult(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1, i64 %a2)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eexternArg(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eexportNamed(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [4 x i64] } %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [4 x i64] } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ecArg(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i32 %a3, { i64, [4 x i64] } %a4)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecHeader(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_89905a2f16c466ce_9c68de6bba1a420a = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecParamList(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i1 %a2)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ecResult(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %v7, ptr %a0, ptr %a1, ptr %a2, { i64, ptr } %a3, { i64, ptr } %a4, i32 %a5, { i64, ptr } %a6)
declare { i64, ptr } @compiler_2femit_2eblockName(ptr %v0, i32 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehas(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare %"compiler/lower:Clone" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aClone_3e_2eAt_3ccompiler_2flower_3aClone_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2eknownOf(ptr %v0, ptr %v1, ptr %a0, { i64, [4 x i64] } %a1)
declare i64 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eCloneOf(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i64 %a2, { i64, [2 x i64] } %a3, i32 %a4)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecloneSym(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2enoteSites(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, %"compiler/mir:Call" %a3)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewant(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecodeFor(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eRef_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eLen(ptr %v0, ptr %a0)
declare { i64, [21 x i64] } @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eAt(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_8a0f087481b95ab0_a13f080fe7b316d4 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2femit_2ecompiler_2femit_3afnEm_2egenLeaves(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eLen_3cArray_3cI64_3e_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eAt_3cArray_3cI64_3e_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eleafAt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, ptr } %a3)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eownWord(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2, i64 %a3)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_961c92f0031f8566_93f78080bb0935c2 = external constant [0 x i8]
declare i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBitOffsets(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePackedBits(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epackedBits(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ecut(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i64 %a2, i64 %a3, i64 %a4)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efromBits(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i64 %a2, i32 %a3)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2etoBits(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2, i64 %a3)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2easPacked(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erefIs(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1, i64 %a2)
@olang_loc_efeca4a527577807_589cfb9b46e56fc3 = external constant [0 x i8]
@olang_loc_be60a18777a318a6_1ca0557f7b352842 = external constant [0 x i8]
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eposition(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eminMax(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, i64 %a4)
@olang_loc_b9f3dbc2e93b92cd_66187346ebf9cfe1 = external constant [0 x i8]
@olang_loc_96197af7424aa9c_b080309cba8f3a50 = external constant [0 x i8]
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenType(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclaresCopy(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_4a9082f792731fd7_7c42022e8195998b = external constant [0 x i8]
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2enewOnce(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eflatScope(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eextern(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_e0bde991406b3b8f_e6287fb3b91b7a9b = external constant [0 x i8]
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eviaMem(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2femit_2efreshScope(ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esole(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [1 x i64] } %a1)
@olang_loc_a90a878cc09c574e_a9a55cce621e609a = external constant [0 x i8]
declare %"compiler/mir:Lvalue" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e_2eAt_3ccompiler_2fmir_3aLvalue_3e(ptr %v0, ptr %a0, i64 %a1)
declare { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/mir:Lvalue" %a1)
declare %"compiler/mir:TaskClause" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2eAt_3ccompiler_2fmir_3aTaskClause_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9287686e475a7dbe_ea834ed677e35522 = external constant [0 x i8]
@olang_loc_45f21d64bb841654_8b47099e9550bca0 = external constant [0 x i8]
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2eput(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, [4 x i64] } %a3, { i64, ptr } %a4)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2etrampoline(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %v7, ptr %a0, { i64, ptr } %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2, i1 %a3, { i64, ptr } %a4, i32 %a5, i64 %a6, ptr %a7, i32 %a8, { i64, ptr } %a9, i64 %a10)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_5928719bf5ddeb28_6f82e9f6c6163cdc = external constant [0 x i8]
@olang_loc_51f36d50f4dfa9f9_6a3d5d7fb2ed60d = external constant [0 x i8]
@G_2ecompiler_2femit_2eBigCloseMark = external constant <{ [8 x i8], ptr }>
@olang_loc_7415e49a8c587c29_9b5b9278cce8582d = external constant [0 x i8]
@olang_loc_4d350c16cffa958_63aa1cf05aa787c = external constant [0 x i8]
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eIter_3cI64_2c_20I64_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cI64_2c_20I64_3e_2eNext_3cI64_2c_20I64_3e(ptr %v0, ptr %a0)
@olang_loc_d55aab1360531c47_f82e8a31cf9de643 = external constant [0 x i8]
declare %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_e9cd50c1ae7327e6_bc31e41603ed9ec2 = external constant [0 x i8]
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecoroDecls(ptr %v0, ptr %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2efuzzSlug(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_8432ee6ea571e3a6_71b81f3ed515f9b2 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
@olang_loc_1e1ac9afcf25b4a6_b14a079dd13715c2 = external constant [0 x i8]
declare i1 @compiler_2femit_2esymbolChar(i8 %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
