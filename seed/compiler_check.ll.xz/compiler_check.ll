; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i32, %"compiler/source:Span" }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, [3 x i64] }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1 }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1 }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, ptr, i1 }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i32, i64, i64, i64, i1, i64, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/check:ctSource" = type { ptr, ptr, { i64, ptr }, i64, { i64, ptr } }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/cond:Value" = type { i32, i64, double, i64, i64, i1 }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/check:EmbedAsk" = type { i64, i64, i32 }
%"compiler/check:b5aWalk" = type { i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1 }
%"compiler/check:ContractAsk" = type { i64, i64, %"compiler/source:Span", i64, %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, [3 x i64] }, { i64, ptr }, { i64, ptr } }
%"compiler/check:laneNode" = type { i64, i32, %"compiler/source:Span", %"compiler/source:Span", i64, i64, i64, ptr, i32, i64, i32 }
%"compiler/check:laneVals" = type { i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/check:reflList" = type { i1, i32, i64, i64 }
%"compiler/check:nullNarrow" = type { { i64, ptr }, i64, i1 }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr }, ptr }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"std/pair:Pair.1eb2466213689e002f25e81e83536e78" = type { i64, ptr }
%"compiler/check:roOrigin" = type { ptr, i1 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/generic:varRow" = type { i64, i32, i32, i32 }
%"compiler/generic:AnySlot" = type { i32, i32, i64, i64, i1, i32 }
%"compiler/check:typeCase" = type { i1, i1, i32, i64, i64, i1 }
%"compiler/ast:If" = type { ptr, ptr, ptr }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"compiler/check:reflVal" = type { i1, i64, i64, { i64, ptr }, i32 }
@G_2ecompiler_2fcheck_2eCtEns = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eCtEntry = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eCtReq = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eLaneArr = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eLaneBin = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eLaneCmp = constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eLaneMagic = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\01\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eLaneScalar = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eLaneSel = constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eLaneUn = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes = constant <{ [8 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k1, [24 x i8] c"\01\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k2, [24 x i8] c"\01\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k3, [24 x i8] c"\01\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k4, [24 x i8] c"\01\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k5, [24 x i8] c"\01\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k6, [24 x i8] c"\01\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k7, [24 x i8] c"\00\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k8, [24 x i8] c"\01\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k9, [24 x i8] c"\01\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k10, [24 x i8] c"\02\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k11, [24 x i8] c"\02\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k12, [24 x i8] c"\01\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k13, [24 x i8] c"\01\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k14, [24 x i8] c"\01\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k15, [24 x i8] c"\01\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\0A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k16, [24 x i8] c"\01\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k17, [24 x i8] c"\00\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k18, [24 x i8] c"\00\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k19, [24 x i8] c"\00\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k20, [24 x i8] c"\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k21, [24 x i8] c"\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k22, [16 x i8] c"\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2fcheck_2eOpShapes.k1 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\50\6C\75\73" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k2 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\4D\69\6E\75\73" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k3 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\4D\75\6C" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k4 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\44\69\76" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k5 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\52\65\6D" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k6 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\4D\61\74\4D\75\6C" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k7 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\4E\65\67" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k8 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\4C\65\73\73" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k9 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\41\74" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k10 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\53\65\74\41\74" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k11 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\53\6C\69\63\65" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k12 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\42\69\74\41\6E\64" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k13 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\42\69\74\4F\72" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k14 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\42\69\74\58\6F\72" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k15 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\53\68\69\66\74\4C\65\66\74" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k16 = internal constant <{ [10 x i8] }> <{ [10 x i8] c"\53\68\69\66\74\52\69\67\68\74" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k17 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\42\69\74\4E\6F\74" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k18 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\49\6E\63" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k19 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\44\65\63" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k20 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\4C\65\6E" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k21 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\45\71" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k22 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\53\74\72" }>, align 8
@G_2ecompiler_2fcheck_2eRoDecl = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eRoGlobal = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eRoReturned = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eRoStored = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eRvBool = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eRvCase = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eRvInt = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eRvText = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eliteralOrder = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eliteralOrder.k1, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eliteralOrder.k2, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eliteralOrder.k3, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eliteralOrder.k4, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eliteralOrder.k5, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eliteralOrder.k6, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eliteralOrder.k7, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eliteralOrder.k8, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eliteralOrder.k9, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eliteralOrder.k10, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eliteralOrder.k11, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eliteralOrder.k12 }>, align 64
@G_2ecompiler_2fcheck_2eliteralOrder.k1 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\46\36\34" }>, align 8
@G_2ecompiler_2fcheck_2eliteralOrder.k2 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\49\36\34" }>, align 8
@G_2ecompiler_2fcheck_2eliteralOrder.k3 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\55\36\34" }>, align 8
@G_2ecompiler_2fcheck_2eliteralOrder.k4 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\46\33\32" }>, align 8
@G_2ecompiler_2fcheck_2eliteralOrder.k5 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\49\33\32" }>, align 8
@G_2ecompiler_2fcheck_2eliteralOrder.k6 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\55\33\32" }>, align 8
@G_2ecompiler_2fcheck_2eliteralOrder.k7 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\46\31\36" }>, align 8
@G_2ecompiler_2fcheck_2eliteralOrder.k8 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\42\46\31\36" }>, align 8
@G_2ecompiler_2fcheck_2eliteralOrder.k9 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\49\31\36" }>, align 8
@G_2ecompiler_2fcheck_2eliteralOrder.k10 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\55\31\36" }>, align 8
@G_2ecompiler_2fcheck_2eliteralOrder.k11 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\49\38" }>, align 8
@G_2ecompiler_2fcheck_2eliteralOrder.k12 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\55\38" }>, align 8
define dso_local void @compiler_2fcheck_2eRvInt_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr @G_2ecompiler_2fcheck_2eRvInt, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ebadSeparator(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l33 = alloca { i64, ptr }
  %l39 = alloca i1
  %l46 = alloca { i64, ptr }
  %l50 = alloca i1
  %l52 = alloca i1
  %l53 = alloca { i64, ptr }
  %l57 = alloca i1
  %l60 = alloca { i64, ptr }
  %l64 = alloca i1
  %l66 = alloca i1
  %l67 = alloca { i64, ptr }
  %l71 = alloca i1
  %l76 = alloca i1
  %l77 = alloca { i64, ptr }
  %l82 = alloca i1
  %l83 = alloca { i64, ptr }
  %l88 = alloca i1
  %l91 = alloca i1
  %l92 = alloca { i64, ptr }
  %l97 = alloca i1
  %l98 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load i64, ptr %l1, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l12, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l2, !tbaa !24
  %t16 = load i64, ptr %l1, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l15, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l15, !tbaa !24
  store i64 %t31, ptr %l12, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l12, !tbaa !24
  store i64 %t32, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i64, ptr %l5, !tbaa !24
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb55
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l1, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = load i64, ptr %l3, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l6, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t51, ptr %l33, !tbaa !27
  %t52 = load i64, ptr %l6, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i8, ptr %t55, i64 %t52
  %t57 = load i8, ptr %t56, !tbaa !32
  %t59 = icmp ne i8 %t57, 95
  br i1 %t59, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb54
bb12:
  br label %bb13
bb13:
  %t61 = load i64, ptr %l6, !tbaa !24
  %t63 = icmp eq i64 %t61, 0
  br i1 %t63, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb16
bb15:
  %t65 = load i64, ptr %l6, !tbaa !24
  %t67 = add i64 %t65, 1
  %t68 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t73 = icmp sge i64 %t67, %t70
  store i1 %t73, ptr %l39, !tbaa !21
  br label %bb16
bb16:
  %t75 = load i1, ptr %l39, !tbaa !21
  br i1 %t75, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t77 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t77, ptr %l46, !tbaa !27
  %t78 = load i64, ptr %l6, !tbaa !24
  %t80 = sub i64 %t78, 1
  %t82 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr i8, ptr %t83, i64 %t80
  %t85 = load i8, ptr %t84, !tbaa !32
  %t87 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t85)
  store i1 %t87, ptr %l50
  br label %bb20
bb20:
  %t88 = load i1, ptr %l50, !tbaa !21
  %t89 = xor i1 %t88, true
  br i1 %t89, label %bb21, label %bb22
bb21:
  %t91 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t91, ptr %l53, !tbaa !27
  %t92 = load i64, ptr %l6, !tbaa !24
  %t94 = sub i64 %t92, 1
  %t96 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr i8, ptr %t97, i64 %t94
  %t99 = load i8, ptr %t98, !tbaa !32
  %t101 = call i1 @compiler_2fcheck_2eisHexDigit(i8 %t99)
  store i1 %t101, ptr %l57
  br label %bb23
bb22:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb24
bb23:
  %t102 = load i1, ptr %l57, !tbaa !21
  %t103 = xor i1 %t102, true
  store i1 %t103, ptr %l52, !tbaa !21
  br label %bb24
bb24:
  %t105 = load i1, ptr %l52, !tbaa !21
  br i1 %t105, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t107 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t107, ptr %l60, !tbaa !27
  %t108 = load i64, ptr %l6, !tbaa !24
  %t110 = add i64 %t108, 1
  %t112 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr i8, ptr %t113, i64 %t110
  %t115 = load i8, ptr %t114, !tbaa !32
  %t117 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t115)
  store i1 %t117, ptr %l64
  br label %bb28
bb28:
  %t118 = load i1, ptr %l64, !tbaa !21
  %t119 = xor i1 %t118, true
  br i1 %t119, label %bb29, label %bb30
bb29:
  %t121 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t121, ptr %l67, !tbaa !27
  %t122 = load i64, ptr %l6, !tbaa !24
  %t124 = add i64 %t122, 1
  %t126 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr i8, ptr %t127, i64 %t124
  %t129 = load i8, ptr %t128, !tbaa !32
  %t131 = call i1 @compiler_2fcheck_2eisHexDigit(i8 %t129)
  store i1 %t131, ptr %l71
  br label %bb31
bb30:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb32
bb31:
  %t132 = load i1, ptr %l71, !tbaa !21
  %t133 = xor i1 %t132, true
  store i1 %t133, ptr %l66, !tbaa !21
  br label %bb32
bb32:
  %t135 = load i1, ptr %l66, !tbaa !21
  br i1 %t135, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t137 = load i64, ptr %l6, !tbaa !24
  %t139 = icmp sge i64 %t137, 2
  br i1 %t139, label %bb36, label %bb37
bb36:
  %t141 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t141, ptr %l77, !tbaa !27
  %t142 = load i64, ptr %l6, !tbaa !24
  %t144 = sub i64 %t142, 1
  %t146 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr i8, ptr %t147, i64 %t144
  %t149 = load i8, ptr %t148, !tbaa !32
  %t151 = icmp eq i8 %t149, 120
  store i1 %t151, ptr %l76, !tbaa !21
  br label %bb38
bb37:
  store i1 false, ptr %l76, !tbaa !21
  br label %bb38
bb38:
  %t153 = load i1, ptr %l76, !tbaa !21
  br i1 %t153, label %bb39, label %bb40
bb39:
  %t154 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t154, ptr %l83, !tbaa !27
  %t155 = load i64, ptr %l6, !tbaa !24
  %t157 = sub i64 %t155, 2
  %t159 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr i8, ptr %t160, i64 %t157
  %t162 = load i8, ptr %t161, !tbaa !32
  %t164 = icmp eq i8 %t162, 48
  store i1 %t164, ptr %l82, !tbaa !21
  br label %bb41
bb40:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb41
bb41:
  %t166 = load i1, ptr %l82, !tbaa !21
  br i1 %t166, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l88, !tbaa !21
  br label %bb50
bb43:
  %t167 = load i64, ptr %l6, !tbaa !24
  %t169 = icmp sge i64 %t167, 2
  br i1 %t169, label %bb44, label %bb45
bb44:
  %t171 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t171, ptr %l92, !tbaa !27
  %t172 = load i64, ptr %l6, !tbaa !24
  %t174 = sub i64 %t172, 1
  %t176 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr i8, ptr %t177, i64 %t174
  %t179 = load i8, ptr %t178, !tbaa !32
  %t181 = icmp eq i8 %t179, 98
  store i1 %t181, ptr %l91, !tbaa !21
  br label %bb46
bb45:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb46
bb46:
  %t183 = load i1, ptr %l91, !tbaa !21
  br i1 %t183, label %bb47, label %bb48
bb47:
  %t184 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t184, ptr %l98, !tbaa !27
  %t185 = load i64, ptr %l6, !tbaa !24
  %t187 = sub i64 %t185, 2
  %t189 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !27
  %t191 = getelementptr i8, ptr %t190, i64 %t187
  %t192 = load i8, ptr %t191, !tbaa !32
  %t194 = icmp eq i8 %t192, 48
  store i1 %t194, ptr %l97, !tbaa !21
  br label %bb49
bb48:
  store i1 false, ptr %l97, !tbaa !21
  br label %bb49
bb49:
  %t196 = load i1, ptr %l97, !tbaa !21
  store i1 %t196, ptr %l88, !tbaa !21
  br label %bb50
bb50:
  %t197 = load i1, ptr %l88, !tbaa !21
  br i1 %t197, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s2)
  br label %bb54
bb54:
  %t199 = load i64, ptr %l5, !tbaa !24
  %t201 = add i64 %t199, 1
  store i64 %t201, ptr %l5, !tbaa !24
  br label %bb7
bb55:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eclausesAssign(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l17 = alloca { i64, ptr }
  %l23 = alloca i1
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t32 = getelementptr %"compiler/ast:Catch", ptr %t28, i32 0, i32 2
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  %t37 = call i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %t33, { i64, ptr } %a1)
  store i1 %t37, ptr %l23
  br label %bb8
bb8:
  %t38 = load i1, ptr %l23, !tbaa !21
  br i1 %t38, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  %t40 = load i64, ptr %l3, !tbaa !24
  %t42 = add i64 %t40, 1
  store i64 %t42, ptr %l3, !tbaa !24
  br label %bb4
bb13:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecommutative(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0
  %t3 = trunc i64 51 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l0
  %t8 = trunc i64 53 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i32, ptr %l0
  %t14 = trunc i64 83 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l6, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb9
bb8:
  %t18 = load i32, ptr %l0
  %t20 = trunc i64 84 to i32
  %t21 = icmp eq i32 %t18, %t20
  store i1 %t21, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l9, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb12
bb11:
  %t24 = load i32, ptr %l0
  %t26 = trunc i64 85 to i32
  %t27 = icmp eq i32 %t24, %t26
  store i1 %t27, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  %t29 = load i1, ptr %l12, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aInit(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l13 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l34 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 11
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t3, i64 %a2)
  store ptr %t7, ptr %l13
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l13, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 11
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Body", ptr %t16, i32 0, i32 11
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = icmp eq ptr %t19, null
  br i1 %t21, label %bb5, label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_76c98d42818871e4_51853c380fcafc70)
  unreachable
bb6:
  br label %bb7
bb7:
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t25 = getelementptr %"compiler/typed:Body", ptr %t23, i32 0, i32 11
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Block", ptr %t26, i32 0, i32 1
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  store { i64, ptr } %t30, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  store i64 %t34, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t36 = load i64, ptr %l5, !tbaa !24
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb38
bb10:
  br label %bb11
bb11:
  %t44 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t44, ptr %l30, !tbaa !27
  %t45 = load i64, ptr %l5, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr ptr, ptr %t48, i64 %t45
  %t50 = load ptr, ptr %t49, !tbaa !39
  store ptr %t50, ptr %l7, !tbaa !29
  %t52 = load ptr, ptr %l7, !tbaa !29
  store ptr %t52, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t53 = load ptr, ptr %l33, !tbaa !29
  %t54 = icmp ne ptr %t53, null
  br i1 %t54, label %bb12, label %bb13
bb12:
  %t56 = load ptr, ptr %l33, !tbaa !29
  %t57 = load i64, ptr %t56
  %t59 = icmp eq i64 %t57, 1
  store i1 %t59, ptr %l34, !tbaa !21
  br label %bb13
bb13:
  %t60 = load i1, ptr %l34, !tbaa !21
  br i1 %t60, label %bb14, label %bb15
bb14:
  %t61 = load ptr, ptr %l7, !tbaa !29
  %t63 = getelementptr { i64, [3 x i64] }, ptr %t61, i32 0, i32 1
  %t64 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t63, i32 0, i32 1
  %t65 = load ptr, ptr %t64
  store ptr %t65, ptr %l8, !tbaa !29
  %t67 = load ptr, ptr %l7, !tbaa !29
  %t69 = getelementptr { i64, [3 x i64] }, ptr %t67, i32 0, i32 1
  %t70 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t69, i32 0, i32 2
  %t71 = load ptr, ptr %t70
  store ptr %t71, ptr %l9, !tbaa !29
  br label %bb16
bb15:
  br label %bb30
bb16:
  %t73 = load ptr, ptr %l8, !tbaa !29
  store ptr %t73, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t74 = load ptr, ptr %l41, !tbaa !29
  %t75 = icmp ne ptr %t74, null
  br i1 %t75, label %bb17, label %bb18
bb17:
  %t77 = load ptr, ptr %l41, !tbaa !29
  %t78 = load i64, ptr %t77
  %t80 = icmp eq i64 %t78, 1
  store i1 %t80, ptr %l42, !tbaa !21
  br label %bb18
bb18:
  %t81 = load i1, ptr %l42, !tbaa !21
  br i1 %t81, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t84 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v0, ptr %t82, ptr %t83, ptr %t84)
  br label %bb22
bb22:
  br label %bb29
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load ptr, ptr %l1, !tbaa !29
  %t91 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStmt(ptr %v0, ptr %v1, ptr %v0, ptr %t89, ptr %t90, ptr %t91)
  br label %bb27
bb27:
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_5b6dfd884f12314a_d55d816e86cc2196)
  unreachable
bb29:
  br label %bb36
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t98 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStmt(ptr %v0, ptr %v1, ptr %v0, ptr %t96, ptr %t97, ptr %t98)
  br label %bb34
bb34:
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_fdeda218c1a4d1e1_676c59a9a8adaaad)
  unreachable
bb36:
  call void @__olang_scope_close(ptr %s3)
  br label %bb37
bb37:
  %t103 = load i64, ptr %l5, !tbaa !24
  %t105 = add i64 %t103, 1
  store i64 %t105, ptr %l5, !tbaa !24
  br label %bb8
bb38:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eblockOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, i64, i64 }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i64
  %l15 = alloca { i64, i64, i64 }
  %l26 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 33
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr %l11, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t13 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t7, i32 %a2, %"compiler/source:Span" %a3)
  store { i64, i64, i64 } %t13, ptr %l15
  br label %bb2
bb2:
  %t14 = load { i64, i64, i64 }, ptr %l15
  store { i64, i64, i64 } %t14, ptr %l5
  %t15 = getelementptr { i64, i64, i64 }, ptr %l5, i32 0, i32 0
  %t16 = load i64, ptr %t15, !tbaa !24
  store i64 %t16, ptr %l6, !tbaa !24
  %t18 = getelementptr { i64, i64, i64 }, ptr %l5, i32 0, i32 1
  %t19 = load i64, ptr %t18, !tbaa !24
  store i64 %t19, ptr %l7, !tbaa !24
  %t21 = getelementptr { i64, i64, i64 }, ptr %l5, i32 0, i32 2
  %t22 = load i64, ptr %t21, !tbaa !24
  store i64 %t22, ptr %l8, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %t24, { i64, ptr } %a1)
  br label %bb3
bb3:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i64, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l7, !tbaa !24
  %t31 = load i64, ptr %l8, !tbaa !24
  %t32 = load i64, ptr %l4, !tbaa !24
  %t38 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t28, i64 %t29, i64 %t30, i64 %t31, i64 %t32)
  store ptr %t38, ptr %l26
  br label %bb4
bb4:
  %t39 = load ptr, ptr %l26, !tbaa !29
  store ptr %t39, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eborrowedResult(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i1
  %l19 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i1
  %l30 = alloca i32
  %l35 = alloca i1
  %l40 = alloca i32
  %l49 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Call", ptr %a1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t7 = load ptr, ptr %l9, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l9, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l10, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { i32 }, ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 11
  %t24 = load i32, ptr %l3, !tbaa !23
  %t26 = sext i32 %t24 to i64
  %t29 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t23, i64 %t26)
  store ptr %t29, ptr %l19
  br label %bb6
bb6:
  %t30 = load ptr, ptr %l19, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Body", ptr %t30, i32 0, i32 2
  %t33 = load i32, ptr %t32, !tbaa !23
  store i32 %t33, ptr %l8, !tbaa !23
  br label %bb19
bb7:
  %t35 = load ptr, ptr %l2, !tbaa !29
  store ptr %t35, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t36 = load ptr, ptr %l22, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb8, label %bb9
bb8:
  %t39 = load ptr, ptr %l22, !tbaa !29
  %t40 = load i64, ptr %t39
  %t42 = icmp eq i64 %t40, 2
  store i1 %t42, ptr %l23, !tbaa !21
  br label %bb9
bb9:
  %t43 = load i1, ptr %l23, !tbaa !21
  br i1 %t43, label %bb10, label %bb11
bb10:
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t46 = getelementptr { i64, [3 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { ptr }, ptr %t46, i32 0, i32 0
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l4, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t53 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t50)
  store i32 %t53, ptr %l30
  br label %bb13
bb13:
  %t54 = load i32, ptr %l30, !tbaa !23
  store i32 %t54, ptr %l8, !tbaa !23
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t55 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t55, ptr %l8, !tbaa !23
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_d8b8a4cfeb0897ac_ce33cd750b46e790)
  unreachable
bb19:
  %t57 = load i32, ptr %l8, !tbaa !23
  store i32 %t57, ptr %l5, !tbaa !23
  %t58 = load i32, ptr %l5, !tbaa !23
  %t59 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t62 = icmp eq i32 %t58, %t59
  br i1 %t62, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb23
bb21:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  %t70 = load i32, ptr %l5, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l40
  br label %bb22
bb22:
  %t74 = load i32, ptr %l40
  %t76 = trunc i64 21 to i32
  %t77 = icmp eq i32 %t74, %t76
  %t79 = xor i1 %t77, true
  store i1 %t79, ptr %l35, !tbaa !21
  br label %bb23
bb23:
  %t81 = load i1, ptr %l35, !tbaa !21
  br i1 %t81, label %bb24, label %bb25
bb24:
  store i1 false, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  %t89 = load i32, ptr %l5, !tbaa !23
  %t92 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t88, i32 %t89, i64 0)
  store i64 %t92, ptr %l49
  br label %bb27
bb27:
  %t93 = load i64, ptr %l49, !tbaa !24
  %t94 = icmp sge i64 %t93, 0
  store i1 %t94, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eborrowedSource(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca ptr
  %l9 = alloca i32
  %l12 = alloca i1
  %l13 = alloca i32
  %l20 = alloca i32
  %l23 = alloca i1
  %l24 = alloca i1
  %l29 = alloca i64
  %l33 = alloca i1
  %l37 = alloca i1
  %l40 = alloca ptr
  %l45 = alloca i32
  %l50 = alloca i64
  %l53 = alloca i32
  %l57 = alloca i64
  %l59 = alloca ptr
  %l62 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l65 = alloca i1
  %l66 = alloca i1
  %l70 = alloca i1
  %l71 = alloca ptr
  %l73 = alloca ptr
  %l74 = alloca i1
  %l79 = alloca ptr
  %rv = alloca i64
  %t159 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1)
  store i32 %t4, ptr %l9
  br label %bb1
bb1:
  %t5 = load i32, ptr %l9, !tbaa !23
  store i32 %t5, ptr %l3, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l3, !tbaa !23
  %t10 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l12
  br label %bb2
bb2:
  %t11 = load i1, ptr %l12, !tbaa !21
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t12 = load i32, ptr %l3, !tbaa !23
  store i32 %t12, ptr %l13, !tbaa !23
  br label %bb6
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 2
  %t20 = load i32, ptr %l3, !tbaa !23
  %t21 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t19, i32 %t20, i64 %t21)
  store i32 %t25, ptr %l20
  br label %bb5
bb5:
  %t26 = load i32, ptr %l20, !tbaa !23
  store i32 %t26, ptr %l13, !tbaa !23
  br label %bb6
bb6:
  %t27 = load i32, ptr %l13, !tbaa !23
  store i32 %t27, ptr %l4, !tbaa !23
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l3, !tbaa !23
  %t32 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t28, i32 %t29)
  store i1 %t32, ptr %l23
  br label %bb7
bb7:
  %t33 = load i1, ptr %l23, !tbaa !21
  br i1 %t33, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  %t40 = load i32, ptr %l3, !tbaa !23
  %t43 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t39, i32 %t40)
  store i64 %t43, ptr %l29
  br label %bb10
bb9:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb11
bb10:
  %t44 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t45 = load i64, ptr %l29, !tbaa !24
  %t47 = and i64 %t45, %t44
  %t49 = icmp ne i64 %t47, 0
  store i1 %t49, ptr %l24, !tbaa !21
  br label %bb11
bb11:
  %t51 = load i1, ptr %l24, !tbaa !21
  br i1 %t51, label %bb12, label %bb13
bb12:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t57 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v0, ptr %t52, ptr %t53)
  store i1 %t57, ptr %l37
  br label %bb14
bb13:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb15
bb14:
  %t58 = load i1, ptr %l37, !tbaa !21
  store i1 %t58, ptr %l33, !tbaa !21
  br label %bb15
bb15:
  %t59 = load i1, ptr %l33, !tbaa !21
  br i1 %t59, label %bb16, label %bb17
bb16:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Checker", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = getelementptr %"compiler/generic:Program", ptr %t63, i32 0, i32 2
  store ptr %t65, ptr %l40, !tbaa !29
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = getelementptr %"compiler/generic:Program", ptr %t69, i32 0, i32 2
  %t72 = load i32, ptr %l3, !tbaa !23
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t71, i32 %t72)
  store i32 %t75, ptr %l45
  br label %bb18
bb17:
  br label %bb21
bb18:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/generic:Program", ptr %t79, i32 0, i32 2
  %t82 = load i32, ptr %l3, !tbaa !23
  %t85 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t81, i32 %t82)
  store i64 %t85, ptr %l50
  br label %bb19
bb19:
  %t86 = load i64, ptr @G_2ecompiler_2ftypes_2eOwning, !tbaa !24
  %t87 = load i64, ptr %l50, !tbaa !24
  %t89 = and i64 %t87, %t86
  %t90 = load ptr, ptr %l40, !tbaa !29
  %t91 = load i32, ptr %l45, !tbaa !23
  %t93 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t90, i32 %t91, i64 %t89)
  store i32 %t93, ptr %l53
  br label %bb20
bb20:
  %t94 = load i32, ptr %l53, !tbaa !23
  store i32 %t94, ptr %l4, !tbaa !23
  br label %bb21
bb21:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load %"compiler/source:Span", ptr %l1
  %t97 = load i32, ptr %l4, !tbaa !23
  %t101 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t95, %"compiler/source:Span" %t96, i32 %t97)
  store i64 %t101, ptr %l57
  br label %bb22
bb22:
  %t102 = load i64, ptr %l57, !tbaa !24
  store i64 %t102, ptr %l5, !tbaa !24
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t103, i32 0, i32 58
  store ptr %t105, ptr %l59, !tbaa !29
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i64, ptr %l5, !tbaa !24
  %t110 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %t106, i64 %t107)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t110, ptr %l62
  br label %bb23
bb23:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load i32, ptr %l3, !tbaa !23
  %t115 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t111, i32 %t112)
  store i1 %t115, ptr %l65
  br label %bb24
bb24:
  %t116 = load i1, ptr %l65, !tbaa !21
  br i1 %t116, label %bb25, label %bb26
bb25:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load ptr, ptr %l2, !tbaa !29
  %t122 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v0, ptr %t117, ptr %t118)
  store i1 %t122, ptr %l70
  br label %bb27
bb26:
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l71, !tbaa !29
  %t124 = load ptr, ptr %l2, !tbaa !29
  %t126 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %t124)
  store ptr %t126, ptr %l73
  br label %bb28
bb27:
  %t127 = load i1, ptr %l70, !tbaa !21
  store i1 %t127, ptr %l66, !tbaa !21
  br label %bb30
bb28:
  %t128 = load ptr, ptr %l71, !tbaa !29
  %t129 = load ptr, ptr %l73, !tbaa !29
  %t130 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v0, ptr %t128, ptr %t129)
  store i1 %t130, ptr %l74
  br label %bb29
bb29:
  %t131 = load i1, ptr %l74, !tbaa !21
  store i1 %t131, ptr %l66, !tbaa !21
  br label %bb30
bb30:
  %t132 = load ptr, ptr %l59, !tbaa !29
  %t133 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l62
  %t134 = load i1, ptr %l66, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t132, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t133, i1 %t134)
  br label %bb31
bb31:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load ptr, ptr %l2, !tbaa !29
  %t137 = load i32, ptr %l4, !tbaa !23
  %t138 = load %"compiler/source:Span", ptr %l1
  %t143 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t135, ptr %t136, i32 %t137, %"compiler/source:Span" %t138)
  store ptr %t143, ptr %l79
  br label %bb32
bb32:
  %t144 = load ptr, ptr %l79, !tbaa !29
  store ptr %t144, ptr %l6, !tbaa !29
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load i64, ptr %l5, !tbaa !24
  %t147 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTrack(ptr %v0, ptr %v0, ptr %t145, i64 %t146, ptr %t147)
  br label %bb33
bb33:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load %"compiler/source:Span", ptr %l1
  %t154 = load i64, ptr %l5, !tbaa !24
  %t156 = trunc i64 %t154 to i32
  %t158 = load ptr, ptr %l6, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t159
  %t160 = getelementptr { i64, [3 x i64] }, ptr %t159, i32 0, i32 0
  store i64 0, ptr %t160
  %t162 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t153, 0
  %t164 = insertvalue { %"compiler/source:Span", i32, ptr } %t162, i32 %t156, 1
  %t166 = insertvalue { %"compiler/source:Span", i32, ptr } %t164, ptr %t158, 2
  %t167 = getelementptr { i64, [3 x i64] }, ptr %t159, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t166, ptr %t167
  %t168 = load { i64, [3 x i64] }, ptr %t159
  %t170 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t168, ptr %t170
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t152, ptr %t170)
  br label %bb34
bb34:
  %t173 = load i64, ptr %l5, !tbaa !24
  store i64 %t173, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebranchBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l18 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Branch", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sge i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t8, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/generic:Program", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/load:Loader", ptr %t14, i32 0, i32 4
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/ast:Branch", ptr %t18, i32 0, i32 2
  %t21 = load i64, ptr %t20, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eReopen(ptr %v0, ptr %t17, i64 %t21)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/ast:Branch", ptr %t25, i32 0, i32 1
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/ast:Branch", ptr %t29, i32 0, i32 0
  %t32 = load %"compiler/source:Span", ptr %t31
  %t37 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eblockOf(ptr %v0, ptr %v1, ptr %t24, { i64, ptr } %t28, i32 1, %"compiler/source:Span" %t32)
  store ptr %t37, ptr %l18
  br label %bb5
bb5:
  %t38 = load ptr, ptr %l18, !tbaa !29
  store ptr %t38, ptr %l2, !tbaa !29
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr %"compiler/ast:Branch", ptr %t39, i32 0, i32 2
  %t42 = load i64, ptr %t41, !tbaa !24
  %t44 = icmp sge i64 %t42, 0
  br i1 %t44, label %bb6, label %bb7
bb6:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 0
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/load:Loader", ptr %t52, i32 0, i32 4
  %t55 = load ptr, ptr %t54, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t55)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t57 = load ptr, ptr %l2, !tbaa !29
  store ptr %t57, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuildDefaulted(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l10 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca i1
  %l17 = alloca i1
  %l20 = alloca i1
  %l25 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l29 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 5
  %t13 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t9, i64 %a1)
  store ptr %t13, ptr %l10
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l10, !tbaa !29
  store ptr %t14, ptr %l4, !tbaa !29
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t17 = getelementptr %"compiler/load:Module", ptr %t15, i32 0, i32 3
  %t18 = load i1, ptr %t17, !tbaa !21
  br i1 %t18, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb5
bb3:
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t22 = getelementptr %"compiler/load:Module", ptr %t20, i32 0, i32 2
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t23, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t25, ptr %l16
  br label %bb4
bb4:
  %t26 = load i1, ptr %l16, !tbaa !21
  store i1 %t26, ptr %l13, !tbaa !21
  br label %bb5
bb5:
  %t27 = load i1, ptr %l13, !tbaa !21
  br i1 %t27, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb9
bb7:
  %t30 = getelementptr %"compiler/ast:VarDecl", ptr %a3, i32 0, i32 2
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = call i1 @compiler_2fcheck_2ewrittenMut(ptr %v1, ptr %t31)
  store i1 %t33, ptr %l20
  br label %bb8
bb8:
  %t34 = load i1, ptr %l20, !tbaa !21
  store i1 %t34, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t35 = load i1, ptr %l17, !tbaa !21
  br i1 %t35, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 0
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/load:Loader", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  store ptr %t46, ptr %l25, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t51 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t47, i32 %a2)
  store { i64, ptr } %t51, ptr %l28
  br label %bb13
bb13:
  %t52 = load ptr, ptr %l25, !tbaa !29
  %t53 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t54 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eDefined(ptr %v0, ptr %v0, ptr %t52, { i64, ptr } %t53)
  store i1 %t54, ptr %l29
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t55 = load i1, ptr %l29, !tbaa !21
  store i1 %t55, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuiltinType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l7 = alloca i1
  %l10 = alloca i1
  %l16 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t1, i32 %a1)
  store { i64, ptr } %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t7, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t9, ptr %l7
  br label %bb2
bb2:
  %t10 = load i1, ptr %l7, !tbaa !21
  br i1 %t10, label %bb3, label %bb4
bb3:
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t11, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t15 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t13, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i1 %t15, ptr %l10
  br label %bb6
bb6:
  %t16 = load i1, ptr %l10, !tbaa !21
  br i1 %t16, label %bb7, label %bb8
bb7:
  %t17 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t17, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 2
  %t25 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v0, ptr %t24, { i64, ptr } %t25)
  store i32 %t28, ptr %l16
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load i32, ptr %l16, !tbaa !23
  store i32 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalledAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca { i64, [2 x i64] }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l24 = alloca i64
  %l27 = alloca i64
  %l34 = alloca ptr
  %l43 = alloca i64
  %l47 = alloca ptr
  %l55 = alloca ptr
  %l59 = alloca i64
  %l60 = alloca { i64, ptr }
  %l63 = alloca { i64, [3 x i64] }
  %rv = alloca { i64, [3 x i64] }
  %t48 = alloca { i64, [3 x i64] }, align 8
  %t106 = alloca { i64, [3 x i64] }, align 8
  %t130 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb30
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Call", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %l3, !tbaa !29
  %t21 = load ptr, ptr %l3, !tbaa !29
  store ptr %t21, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t22 = load ptr, ptr %l17, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t25 = load ptr, ptr %l17, !tbaa !29
  %t26 = load i64, ptr %t25
  %t28 = icmp eq i64 %t26, 0
  store i1 %t28, ptr %l18, !tbaa !21
  br label %bb7
bb7:
  %t29 = load i1, ptr %l18, !tbaa !21
  br i1 %t29, label %bb8, label %bb9
bb8:
  %t30 = load ptr, ptr %l3, !tbaa !29
  %t32 = getelementptr { i64, [3 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { i32 }, ptr %t32, i32 0, i32 0
  %t34 = load i32, ptr %t33
  store i32 %t34, ptr %l4, !tbaa !23
  br label %bb10
bb9:
  br label %bb28
bb10:
  %t36 = load i32, ptr %l4, !tbaa !23
  %t38 = sext i32 %t36 to i64
  store i64 %t38, ptr %l24, !tbaa !24
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 11
  %t43 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %t41)
  store i64 %t43, ptr %l27
  br label %bb11
bb11:
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = load i64, ptr %l27, !tbaa !24
  %t46 = icmp sge i64 %t44, %t45
  br i1 %t46, label %bb12, label %bb13
bb12:
  store { i64, [3 x i64] } zeroinitializer, ptr %t48
  %t49 = getelementptr { i64, [3 x i64] }, ptr %t48, i32 0, i32 0
  store i64 0, ptr %t49
  %t50 = load { i64, [3 x i64] }, ptr %t48
  store { i64, [3 x i64] } %t50, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 11
  %t55 = load i32, ptr %l4, !tbaa !23
  %t57 = sext i32 %t55 to i64
  %t60 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t54, i64 %t57)
  store ptr %t60, ptr %l34
  br label %bb15
bb15:
  %t61 = load ptr, ptr %l34, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Body", ptr %t61, i32 0, i32 1
  %t64 = load { i64, [2 x i64] }, ptr %t63
  store { i64, [2 x i64] } %t64, ptr %l5
  %t66 = load { i64, [2 x i64] }, ptr %l5
  %t68 = extractvalue { i64, [2 x i64] } %t66, 0
  %t69 = icmp eq i64 %t68, 0
  br i1 %t69, label %bb16, label %bb17
bb16:
  %t71 = getelementptr { i64, [2 x i64] }, ptr %l5, i32 0, i32 1
  %t72 = getelementptr { i64 }, ptr %t71, i32 0, i32 0
  %t73 = load i64, ptr %t72
  store i64 %t73, ptr %l6, !tbaa !24
  br label %bb18
bb17:
  br label %bb26
bb18:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/check:Checker", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t79 = load i64, ptr %l6, !tbaa !24
  %t82 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t78, i64 %t79)
  store i64 %t82, ptr %l43
  br label %bb19
bb19:
  %t83 = load i64, ptr %l43, !tbaa !24
  store i64 %t83, ptr %l7, !tbaa !24
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/check:Checker", ptr %t84, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t88 = load i64, ptr %l7, !tbaa !24
  %t91 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t87, i64 %t88)
  store ptr %t91, ptr %l47
  br label %bb20
bb20:
  %t92 = load ptr, ptr %l47, !tbaa !29
  %t94 = getelementptr %"compiler/ast:Func", ptr %t92, i32 0, i32 3
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = getelementptr %"compiler/ast:Sig", ptr %t95, i32 0, i32 1
  %t98 = load { i64, ptr }, ptr %t97, !tbaa !27
  store { i64, ptr } %t98, ptr %l8, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t104 = icmp eq i64 %t102, 0
  br i1 %t104, label %bb21, label %bb22
bb21:
  store { i64, [3 x i64] } zeroinitializer, ptr %t106
  %t107 = getelementptr { i64, [3 x i64] }, ptr %t106, i32 0, i32 0
  store i64 0, ptr %t107
  %t108 = load { i64, [3 x i64] }, ptr %t106
  store { i64, [3 x i64] } %t108, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l55, !tbaa !29
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/check:Checker", ptr %t111, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t115 = load i64, ptr %l7, !tbaa !24
  %t118 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t114, i64 %t115)
  store i64 %t118, ptr %l59
  br label %bb24
bb24:
  %t119 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t119, ptr %l60, !tbaa !27
  %t120 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr ptr, ptr %t121, i64 0
  %t123 = load ptr, ptr %t122, !tbaa !39
  %t125 = load ptr, ptr %l55, !tbaa !29
  %t126 = load i64, ptr %l59, !tbaa !24
  %t128 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkAt(ptr %v0, ptr %v0, ptr %t125, i64 %t126, ptr %t123)
  store { i64, [3 x i64] } %t128, ptr %l63
  br label %bb25
bb25:
  %t129 = load { i64, [3 x i64] }, ptr %l63
  store { i64, [3 x i64] } %t129, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  br label %bb29
bb28:
  br label %bb29
bb29:
  br label %bb31
bb30:
  br label %bb31
bb31:
  store { i64, [3 x i64] } zeroinitializer, ptr %t130
  %t131 = getelementptr { i64, [3 x i64] }, ptr %t130, i32 0, i32 0
  store i64 0, ptr %t131
  %t132 = load { i64, [3 x i64] }, ptr %t130
  store { i64, [3 x i64] } %t132, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [3 x i64] }, ptr %rv
  ret { i64, [3 x i64] } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTypeWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"compiler/names:Ref"
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i1
  %l20 = alloca ptr
  %l22 = alloca ptr
  %l26 = alloca %"compiler/names:Ref"
  %l30 = alloca i1
  %l35 = alloca ptr
  %l37 = alloca ptr
  %l41 = alloca %"compiler/names:Ref"
  %l44 = alloca i1
  %l51 = alloca { i64, ptr }
  %l56 = alloca i1
  %l63 = alloca i32
  %l68 = alloca i1
  %l71 = alloca ptr
  %l73 = alloca %"compiler/source:Span"
  %l75 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l84 = alloca i64
  %l86 = alloca i64
  %l87 = alloca %"compiler/msgs:Msg"
  %l88 = alloca i64
  %s7 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l3
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t18, i32 0, i32 1
  %t20 = load { i64, ptr }, ptr %t19
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t24, i32 0, i32 2
  %t26 = load { i64, ptr }, ptr %t25
  store { i64, ptr } %t26, ptr %l5, !tbaa !27
  br label %bb5
bb4:
  br label %bb46
bb5:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  store ptr %t34, ptr %l20, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t35)
  store ptr %t37, ptr %l22
  br label %bb6
bb6:
  %t38 = load ptr, ptr %l22, !tbaa !29
  %t40 = getelementptr %"compiler/check:frame", ptr %t38, i32 0, i32 2
  %t41 = load i64, ptr %t40, !tbaa !24
  %t42 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t43 = load i32, ptr %t42, !tbaa !23
  %t44 = load ptr, ptr %l20, !tbaa !29
  %t47 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t44, i64 %t41, i32 %t43)
  store %"compiler/names:Ref" %t47, ptr %l26
  br label %bb7
bb7:
  %t48 = load %"compiler/names:Ref", ptr %l26
  store %"compiler/names:Ref" %t48, ptr %l6
  %t49 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t53 = icmp sgt i64 %t51, 1
  br i1 %t53, label %bb8, label %bb9
bb8:
  %t55 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 0
  %t56 = load i32, ptr %t55
  %t58 = trunc i64 0 to i32
  %t59 = icmp eq i32 %t56, %t58
  store i1 %t59, ptr %l30, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb10
bb10:
  %t61 = load i1, ptr %l30, !tbaa !21
  br i1 %t61, label %bb11, label %bb12
bb11:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  store ptr %t68, ptr %l35, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t69)
  store ptr %t71, ptr %l37
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t72 = load ptr, ptr %l37, !tbaa !29
  %t74 = getelementptr %"compiler/check:frame", ptr %t72, i32 0, i32 2
  %t75 = load i64, ptr %t74, !tbaa !24
  %t76 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 1
  %t77 = load i32, ptr %t76, !tbaa !23
  %t78 = load ptr, ptr %l35, !tbaa !29
  %t81 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %t78, i64 %t75, i32 %t77)
  store %"compiler/names:Ref" %t81, ptr %l41
  br label %bb14
bb14:
  %t82 = load %"compiler/names:Ref", ptr %l41
  store %"compiler/names:Ref" %t82, ptr %l6
  br label %bb15
bb15:
  %t83 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 0
  %t84 = load i32, ptr %t83
  %t86 = trunc i64 0 to i32
  %t87 = icmp eq i32 %t84, %t86
  br i1 %t87, label %bb16, label %bb17
bb16:
  %t89 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t93 = icmp eq i64 %t91, 1
  store i1 %t93, ptr %l44, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb18
bb18:
  %t95 = load i1, ptr %l44, !tbaa !21
  br i1 %t95, label %bb19, label %bb20
bb19:
  %t96 = load i1, ptr %l2, !tbaa !21
  br i1 %t96, label %bb21, label %bb22
bb20:
  br label %bb25
bb21:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load %"compiler/source:Span", ptr %l3
  %t100 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t100, ptr %l51, !tbaa !27
  %t101 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr i32, ptr %t102, i64 0
  %t104 = load i32, ptr %t103, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknownType(ptr %v0, ptr %t98, %"compiler/source:Span" %t99, i32 %t104)
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb24
bb24:
  store i1 false, ptr %rv
  br label %ret
bb25:
  %t109 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 0
  %t110 = load i32, ptr %t109
  %t112 = trunc i64 4 to i32
  %t113 = icmp eq i32 %t110, %t112
  br i1 %t113, label %bb26, label %bb27
bb26:
  %t115 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 2
  %t116 = load i64, ptr %t115, !tbaa !24
  %t118 = icmp sge i64 %t116, 0
  store i1 %t118, ptr %l56, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb28
bb28:
  %t120 = load i1, ptr %l56, !tbaa !21
  br i1 %t120, label %bb29, label %bb30
bb29:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/check:Checker", ptr %t121, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t125 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 1
  %t126 = load i64, ptr %t125, !tbaa !24
  %t127 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 2
  %t128 = load i64, ptr %t127, !tbaa !24
  %t132 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t124, i64 %t126, i64 %t128)
  store i32 %t132, ptr %l63
  br label %bb31
bb30:
  br label %bb45
bb31:
  %t133 = load i32, ptr %l63, !tbaa !23
  store i32 %t133, ptr %l7, !tbaa !23
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t134, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t138 = load i32, ptr %l7, !tbaa !23
  %t139 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t143 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eArgsFit(ptr %v0, ptr %v1, ptr %t137, i32 %t138, { i64, ptr } %t139)
  store i1 %t143, ptr %l68
  br label %bb32
bb32:
  %t144 = load i1, ptr %l68, !tbaa !21
  %t145 = xor i1 %t144, true
  br i1 %t145, label %bb33, label %bb34
bb33:
  %t147 = load i1, ptr %l2, !tbaa !21
  br i1 %t147, label %bb35, label %bb36
bb34:
  br label %bb44
bb35:
  store %olang.scope zeroinitializer, ptr %s7
  %t149 = load ptr, ptr %l0, !tbaa !29
  store ptr %t149, ptr %l71, !tbaa !29
  %t150 = load ptr, ptr %l1, !tbaa !29
  %t152 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t150)
  store %"compiler/source:Span" %t152, ptr %l73
  br label %bb37
bb36:
  br label %bb43
bb37:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t154, ptr %l75, !tbaa !27
  %t155 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t155, 0
  %t159 = sub i64 %t157, 1
  %t161 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr i32, ptr %t162, i64 %t159
  %t164 = load i32, ptr %t163, !tbaa !33
  %t167 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t153, i32 %t164)
  store { i64, ptr } %t167, ptr %l80
  br label %bb38
bb38:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/check:Checker", ptr %t168, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !29
  %t172 = load i32, ptr %l7, !tbaa !23
  %t175 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWrittenArity(ptr %v0, ptr %t171, i32 %t172)
  store i64 %t175, ptr %l84
  br label %bb39
bb39:
  %t176 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t178 = call i64 @compiler_2fgeneric_2eWrittenTypes(ptr %v1, { i64, ptr } %t176)
  store i64 %t178, ptr %l86
  br label %bb40
bb40:
  %t179 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t180 = load i64, ptr %l84, !tbaa !24
  %t181 = load i64, ptr %l86, !tbaa !24
  %t182 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgCount(ptr %v0, ptr %s7, { i64, ptr } %t179, i64 %t180, i64 %t181)
  store %"compiler/msgs:Msg" %t182, ptr %l87
  br label %bb41
bb41:
  %t183 = load ptr, ptr %l71, !tbaa !29
  %t184 = load %"compiler/source:Span", ptr %l73
  %t185 = load %"compiler/msgs:Msg", ptr %l87
  %t186 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t183, %"compiler/source:Span" %t184, %"compiler/msgs:Msg" %t185)
  store i64 %t186, ptr %l88
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s7)
  br label %bb43
bb43:
  store i1 false, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  store i1 true, ptr %rv
  br label %ret
bb46:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i32
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca { i64, i32 }
  %l31 = alloca i64
  %l32 = alloca i32
  %l37 = alloca i1
  %l39 = alloca ptr
  %l43 = alloca { i64, ptr }
  %l45 = alloca i1
  %l47 = alloca ptr
  %l49 = alloca ptr
  %l53 = alloca i32
  %l58 = alloca i32
  %l63 = alloca ptr
  %l68 = alloca i32
  %l69 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l83 = alloca i32
  %l90 = alloca i64
  %l94 = alloca i64
  %l97 = alloca i64
  %l116 = alloca i64
  %l120 = alloca ptr
  %l125 = alloca i32
  %l127 = alloca %"compiler/typed:Item"
  %l134 = alloca i32
  %l137 = alloca ptr
  %l139 = alloca %"compiler/typed:Item"
  %l145 = alloca i1
  %l147 = alloca ptr
  %l149 = alloca ptr
  %l153 = alloca i32
  %l160 = alloca i1
  %l162 = alloca ptr
  %l164 = alloca %"compiler/typed:Item"
  %l165 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l171 = alloca { i64, ptr }
  %l174 = alloca { i64, ptr }
  %l175 = alloca i32
  %l184 = alloca { i64, ptr }
  %l194 = alloca i32
  %l198 = alloca ptr
  %l200 = alloca %"compiler/typed:Item"
  %l205 = alloca i64
  %l209 = alloca i64
  %l212 = alloca i64
  %l231 = alloca i64
  %l235 = alloca ptr
  %l240 = alloca i32
  %l242 = alloca %"compiler/typed:Item"
  %l252 = alloca { i64, i32 }
  %l258 = alloca ptr
  %l260 = alloca ptr
  %l264 = alloca i1
  %l265 = alloca ptr
  %l268 = alloca %"compiler/typed:Item"
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Path", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 1
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t10)
  store ptr %t12, ptr %l39
  br label %bb3
bb2:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb5
bb3:
  %t13 = load ptr, ptr %l39, !tbaa !29
  %t15 = getelementptr %"compiler/check:frame", ptr %t13, i32 0, i32 4
  %t16 = getelementptr %"compiler/generic:Context", ptr %t15, i32 0, i32 2
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr %"compiler/ast:Path", ptr %t17, i32 0, i32 1
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l43, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr i32, ptr %t22, i64 0
  %t24 = load i32, ptr %t23, !tbaa !33
  %t27 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_He6be2b0836caba7ddc59483ff74db438(ptr %v0, ptr %t16, i32 %t24)
  store i1 %t27, ptr %l45
  br label %bb4
bb4:
  %t28 = load i1, ptr %l45, !tbaa !21
  store i1 %t28, ptr %l37, !tbaa !21
  br label %bb5
bb5:
  %t29 = load i1, ptr %l37, !tbaa !21
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  store ptr %t33, ptr %l47, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t34)
  store ptr %t36, ptr %l49
  br label %bb8
bb7:
  br label %bb55
bb8:
  %t37 = load ptr, ptr %l49, !tbaa !29
  %t39 = getelementptr %"compiler/check:frame", ptr %t37, i32 0, i32 4
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t41 = load ptr, ptr %l47, !tbaa !29
  %t44 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorSetItem(ptr %v0, ptr %v0, ptr %v1, ptr %t41, ptr %t39, ptr %t40)
  store i32 %t44, ptr %l53
  br label %bb9
bb9:
  %t45 = load i32, ptr %l53, !tbaa !23
  store i32 %t45, ptr %l3, !tbaa !23
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 2
  %t52 = load i32, ptr %l3, !tbaa !23
  %t55 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t51, i32 %t52)
  store i32 %t55, ptr %l58
  br label %bb10
bb10:
  %t56 = load i32, ptr %l58
  %t58 = trunc i64 30 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb11, label %bb12
bb11:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/check:Checker", ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = getelementptr %"compiler/generic:Program", ptr %t64, i32 0, i32 2
  store ptr %t66, ptr %l63, !tbaa !29
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t70, i32 0, i32 2
  %t73 = load i32, ptr %l3, !tbaa !23
  %t76 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %t72, i32 %t73)
  store i32 %t76, ptr %l68
  br label %bb13
bb12:
  br label %bb50
bb13:
  %t77 = load ptr, ptr %l63, !tbaa !29
  %t78 = load i32, ptr %l68, !tbaa !23
  %t79 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t77, i32 %t78)
  store { i64, ptr } %t79, ptr %l69
  br label %bb14
bb14:
  %t80 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t80, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t81 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t81, 0
  store i64 %t83, ptr %l6, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t85 = load i64, ptr %l5, !tbaa !24
  %t86 = load i64, ptr %l6, !tbaa !24
  %t89 = icmp slt i64 %t85, %t86
  %t91 = xor i1 %t89, true
  br i1 %t91, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s4)
  br label %bb49
bb17:
  br label %bb18
bb18:
  %t93 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t93, ptr %l76, !tbaa !27
  %t94 = load i64, ptr %l5, !tbaa !24
  %t96 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr i32, ptr %t97, i64 %t94
  %t99 = load i32, ptr %t98, !tbaa !33
  store i32 %t99, ptr %l7, !tbaa !23
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/check:Checker", ptr %t101, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = getelementptr %"compiler/generic:Program", ptr %t104, i32 0, i32 2
  %t107 = load i32, ptr %l7, !tbaa !23
  %t110 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t106, i32 %t107)
  store i32 %t110, ptr %l83
  br label %bb19
bb19:
  %t111 = load i32, ptr %l83
  %t113 = trunc i64 28 to i32
  %t114 = icmp eq i32 %t111, %t113
  br i1 %t114, label %bb20, label %bb21
bb20:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/check:Checker", ptr %t116, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t121 = getelementptr %"compiler/generic:Program", ptr %t119, i32 0, i32 2
  %t122 = load i32, ptr %l7, !tbaa !23
  %t125 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t121, i32 %t122)
  store i64 %t125, ptr %l90
  br label %bb22
bb21:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/generic:Program", ptr %t129, i32 0, i32 2
  %t132 = load i32, ptr %l7, !tbaa !23
  %t135 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t131, i32 %t132)
  store i32 %t135, ptr %l134
  br label %bb41
bb22:
  %t136 = load i64, ptr %l90, !tbaa !65
  store i64 %t136, ptr %l8, !tbaa !65
  store i64 0, ptr %l9, !tbaa !24
  store i64 64, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t137 = load i64, ptr %l10, !tbaa !24
  %t138 = load i64, ptr %l9, !tbaa !24
  %t141 = icmp sgt i64 %t137, %t138
  br i1 %t141, label %bb23, label %bb24
bb23:
  %t143 = load i64, ptr %l11, !tbaa !24
  %t145 = icmp sgt i64 %t143, 0
  br i1 %t145, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l94, !tbaa !24
  br label %bb28
bb25:
  %t147 = load i64, ptr %l10, !tbaa !24
  %t148 = load i64, ptr %l9, !tbaa !24
  %t151 = sub i64 %t147, %t148
  %t152 = load i64, ptr %l11, !tbaa !24
  %t155 = add i64 %t151, %t152
  %t157 = sub i64 %t155, 1
  %t158 = load i64, ptr %l11, !tbaa !24
  %t161 = sdiv i64 %t157, %t158
  store i64 %t161, ptr %l97, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l97, !tbaa !24
  br label %bb27
bb27:
  %t163 = load i64, ptr %l97, !tbaa !24
  store i64 %t163, ptr %l94, !tbaa !24
  br label %bb28
bb28:
  %t164 = load i64, ptr %l94, !tbaa !24
  store i64 %t164, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s7
  %t165 = load i64, ptr %l13, !tbaa !24
  %t166 = load i64, ptr %l12, !tbaa !24
  %t169 = icmp slt i64 %t165, %t166
  %t171 = xor i1 %t169, true
  br i1 %t171, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s7)
  br label %bb40
bb31:
  br label %bb32
bb32:
  %t173 = load i64, ptr %l9, !tbaa !24
  %t174 = load i64, ptr %l13, !tbaa !24
  %t175 = load i64, ptr %l11, !tbaa !24
  %t178 = mul i64 %t174, %t175
  %t181 = add i64 %t173, %t178
  store i64 %t181, ptr %l14, !tbaa !24
  %t183 = load i64, ptr %l8, !tbaa !65
  %t184 = load i64, ptr %l14, !tbaa !24
  store i64 %t184, ptr %l116, !tbaa !24
  %t185 = load i64, ptr %l116, !tbaa !24
  %t186 = load i64, ptr %l116, !tbaa !24
  %t187 = shl i64 1, %t186
  %t190 = and i64 %t183, %t187
  %t192 = icmp ne i64 %t190, 0
  br i1 %t192, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s8
  %t194 = load ptr, ptr %l2, !tbaa !29
  store ptr %t194, ptr %l120, !tbaa !29
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/check:Checker", ptr %t195, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t200 = getelementptr %"compiler/generic:Program", ptr %t198, i32 0, i32 2
  %t201 = load i32, ptr %l7, !tbaa !23
  %t204 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t200, i32 %t201)
  store i32 %t204, ptr %l125
  br label %bb35
bb34:
  br label %bb38
bb35:
  %t205 = load i64, ptr %l14, !tbaa !24
  %t206 = load i32, ptr %l125, !tbaa !23
  %t208 = call %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %s8, i32 %t206, i64 %t205)
  store %"compiler/typed:Item" %t208, ptr %l127
  br label %bb36
bb36:
  %t209 = load ptr, ptr %l120, !tbaa !29
  %t210 = load %"compiler/typed:Item", ptr %l127
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v2, ptr %t209, %"compiler/typed:Item" %t210)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s8)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s7)
  br label %bb39
bb39:
  %t211 = load i64, ptr %l13, !tbaa !24
  %t213 = add i64 %t211, 1
  store i64 %t213, ptr %l13, !tbaa !24
  br label %bb29
bb40:
  br label %bb47
bb41:
  %t215 = load i32, ptr %l134
  %t217 = trunc i64 18 to i32
  %t218 = icmp eq i32 %t215, %t217
  br i1 %t218, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s11
  %t220 = load ptr, ptr %l2, !tbaa !29
  store ptr %t220, ptr %l137, !tbaa !29
  %t221 = load i32, ptr %l7, !tbaa !23
  %t223 = call %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %s11, i32 %t221, i64 -1)
  store %"compiler/typed:Item" %t223, ptr %l139
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t224 = load ptr, ptr %l137, !tbaa !29
  %t225 = load %"compiler/typed:Item", ptr %l139
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v2, ptr %t224, %"compiler/typed:Item" %t225)
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s11)
  br label %bb46
bb46:
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s4)
  br label %bb48
bb48:
  %t226 = load i64, ptr %l5, !tbaa !24
  %t228 = add i64 %t226, 1
  store i64 %t228, ptr %l5, !tbaa !24
  br label %bb15
bb49:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb50:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t232 = getelementptr %"compiler/check:Checker", ptr %t230, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !29
  %t234 = load i32, ptr %l3, !tbaa !23
  %t237 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsErrVar(ptr %v0, ptr %t233, i32 %t234)
  store i1 %t237, ptr %l145
  br label %bb51
bb51:
  %t238 = load i1, ptr %l145, !tbaa !21
  br i1 %t238, label %bb52, label %bb53
bb52:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb53:
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/check:Checker", ptr %t239, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !29
  store ptr %t242, ptr %l147, !tbaa !29
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t245 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t243)
  store ptr %t245, ptr %l149
  br label %bb56
bb56:
  %t246 = load ptr, ptr %l149, !tbaa !29
  %t248 = getelementptr %"compiler/check:frame", ptr %t246, i32 0, i32 4
  %t249 = load ptr, ptr %l1, !tbaa !29
  %t250 = load ptr, ptr %l147, !tbaa !29
  %t253 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorType(ptr %v0, ptr %v0, ptr %v1, ptr %t250, ptr %t248, ptr %t249)
  store i32 %t253, ptr %l153
  br label %bb57
bb57:
  %t254 = load i32, ptr %l153, !tbaa !23
  store i32 %t254, ptr %l15, !tbaa !23
  %t255 = load i32, ptr %l15, !tbaa !23
  %t256 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t259 = icmp ne i32 %t255, %t256
  br i1 %t259, label %bb58, label %bb59
bb58:
  store %olang.scope zeroinitializer, ptr %s14
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/check:Checker", ptr %t261, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !29
  %t265 = load i32, ptr %l15, !tbaa !23
  %t268 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsErrorSet(ptr %v0, ptr %t264, i32 %t265)
  store i1 %t268, ptr %l160
  br label %bb60
bb59:
  br label %bb111
bb60:
  %t269 = load i1, ptr %l160, !tbaa !21
  %t270 = xor i1 %t269, true
  br i1 %t270, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s15
  %t272 = load ptr, ptr %l2, !tbaa !29
  store ptr %t272, ptr %l162, !tbaa !29
  %t273 = load i32, ptr %l15, !tbaa !23
  %t275 = call %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %s15, i32 %t273, i64 -1)
  store %"compiler/typed:Item" %t275, ptr %l164
  br label %bb63
bb62:
  br label %bb65
bb63:
  %t276 = load ptr, ptr %l162, !tbaa !29
  %t277 = load %"compiler/typed:Item", ptr %l164
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v2, ptr %t276, %"compiler/typed:Item" %t277)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb65:
  %t278 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %s14)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t278, ptr %l165
  br label %bb66
bb66:
  %t279 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l165
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t279, ptr %l16
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = getelementptr %"compiler/check:Checker", ptr %t280, i32 0, i32 1
  %t283 = load ptr, ptr %t282, !tbaa !29
  %t284 = load i32, ptr %l15, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eEntriesOf(ptr %v0, ptr %s14, ptr %t283, i32 %t284, ptr %l16)
  br label %bb67
bb67:
  store ptr %l16, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb68
bb68:
  store %olang.scope zeroinitializer, ptr %s17
  %t289 = load ptr, ptr %l17, !tbaa !29
  %t290 = load i64, ptr %l18, !tbaa !24
  %t293 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %s14, ptr %t289, i64 %t290)
  %t294 = extractvalue { i32, { i64, ptr } } %t293, 1
  %t295 = extractvalue { i32, { i64, ptr } } %t293, 0
  store i32 %t295, ptr %l175
  %t296 = icmp ne i32 %t295, 0
  br i1 %t296, label %bb70, label %ok.297
ok.297:
  store { i64, ptr } %t294, ptr %l174
  br label %bb69
bb69:
  %t298 = load { i64, ptr }, ptr %l174, !tbaa !27
  store { i64, ptr } %t298, ptr %l171, !tbaa !27
  br label %bb74
bb70:
  %t299 = load i32, ptr %l175, !tbaa !23
  %t300 = ashr i32 %t299, 16
  %t302 = icmp eq i32 %t300, 1
  br i1 %t302, label %bb71, label %bb72
bb71:
  br label %bb73
bb72:
  call void @__olang_check_failed(ptr @olang_loc_1cd9defc72140005_b2649171260378c9)
  unreachable
bb73:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s17)
  br label %bb110
bb74:
  %t304 = load { i64, ptr }, ptr %l171, !tbaa !27
  store { i64, ptr } %t304, ptr %l19, !tbaa !27
  %t305 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t307 = extractvalue { i64, ptr } %t305, 0
  store i64 %t307, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb75
bb75:
  store %olang.scope zeroinitializer, ptr %s18
  %t309 = load i64, ptr %l21, !tbaa !24
  %t310 = load i64, ptr %l20, !tbaa !24
  %t313 = icmp slt i64 %t309, %t310
  %t315 = xor i1 %t313, true
  br i1 %t315, label %bb76, label %bb77
bb76:
  call void @__olang_scope_close(ptr %s18)
  br label %bb108
bb77:
  br label %bb78
bb78:
  %t317 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t317, ptr %l184, !tbaa !27
  %t318 = load i64, ptr %l21, !tbaa !24
  %t320 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t321 = load ptr, ptr %t320, !tbaa !27
  %t322 = getelementptr i32, ptr %t321, i64 %t318
  %t323 = load i32, ptr %t322, !tbaa !33
  store i32 %t323, ptr %l22, !tbaa !23
  %t325 = load i32, ptr %l22, !tbaa !23
  %t326 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t329 = icmp eq i32 %t325, %t326
  br i1 %t329, label %bb79, label %bb80
bb79:
  call void @__olang_scope_close(ptr %s18)
  br label %bb107
bb80:
  br label %bb81
bb81:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t333 = getelementptr %"compiler/check:Checker", ptr %t331, i32 0, i32 1
  %t334 = load ptr, ptr %t333, !tbaa !29
  %t336 = getelementptr %"compiler/generic:Program", ptr %t334, i32 0, i32 2
  %t337 = load i32, ptr %l22, !tbaa !23
  %t340 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t336, i32 %t337)
  store i32 %t340, ptr %l194
  br label %bb82
bb82:
  %t341 = load i32, ptr %l194
  %t343 = trunc i64 28 to i32
  %t344 = icmp eq i32 %t341, %t343
  %t346 = xor i1 %t344, true
  br i1 %t346, label %bb83, label %bb84
bb83:
  store %olang.scope zeroinitializer, ptr %s20
  %t348 = load ptr, ptr %l2, !tbaa !29
  store ptr %t348, ptr %l198, !tbaa !29
  %t349 = load i32, ptr %l22, !tbaa !23
  %t351 = call %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %s20, i32 %t349, i64 -1)
  store %"compiler/typed:Item" %t351, ptr %l200
  br label %bb85
bb84:
  br label %bb87
bb85:
  %t352 = load ptr, ptr %l198, !tbaa !29
  %t353 = load %"compiler/typed:Item", ptr %l200
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v2, ptr %t352, %"compiler/typed:Item" %t353)
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s18)
  br label %bb107
bb87:
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t356 = getelementptr %"compiler/check:Checker", ptr %t354, i32 0, i32 1
  %t357 = load ptr, ptr %t356, !tbaa !29
  %t359 = getelementptr %"compiler/generic:Program", ptr %t357, i32 0, i32 2
  %t360 = load i32, ptr %l22, !tbaa !23
  %t363 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t359, i32 %t360)
  store i64 %t363, ptr %l205
  br label %bb88
bb88:
  %t364 = load i64, ptr %l205, !tbaa !65
  store i64 %t364, ptr %l23, !tbaa !65
  store i64 0, ptr %l24, !tbaa !24
  store i64 64, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t365 = load i64, ptr %l25, !tbaa !24
  %t366 = load i64, ptr %l24, !tbaa !24
  %t369 = icmp sgt i64 %t365, %t366
  br i1 %t369, label %bb89, label %bb90
bb89:
  %t371 = load i64, ptr %l26, !tbaa !24
  %t373 = icmp sgt i64 %t371, 0
  br i1 %t373, label %bb91, label %bb92
bb90:
  store i64 0, ptr %l209, !tbaa !24
  br label %bb94
bb91:
  %t375 = load i64, ptr %l25, !tbaa !24
  %t376 = load i64, ptr %l24, !tbaa !24
  %t379 = sub i64 %t375, %t376
  %t380 = load i64, ptr %l26, !tbaa !24
  %t383 = add i64 %t379, %t380
  %t385 = sub i64 %t383, 1
  %t386 = load i64, ptr %l26, !tbaa !24
  %t389 = sdiv i64 %t385, %t386
  store i64 %t389, ptr %l212, !tbaa !24
  br label %bb93
bb92:
  store i64 0, ptr %l212, !tbaa !24
  br label %bb93
bb93:
  %t391 = load i64, ptr %l212, !tbaa !24
  store i64 %t391, ptr %l209, !tbaa !24
  br label %bb94
bb94:
  %t392 = load i64, ptr %l209, !tbaa !24
  store i64 %t392, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb95
bb95:
  store %olang.scope zeroinitializer, ptr %s22
  %t393 = load i64, ptr %l28, !tbaa !24
  %t394 = load i64, ptr %l27, !tbaa !24
  %t397 = icmp slt i64 %t393, %t394
  %t399 = xor i1 %t397, true
  br i1 %t399, label %bb96, label %bb97
bb96:
  call void @__olang_scope_close(ptr %s22)
  br label %bb106
bb97:
  br label %bb98
bb98:
  %t401 = load i64, ptr %l24, !tbaa !24
  %t402 = load i64, ptr %l28, !tbaa !24
  %t403 = load i64, ptr %l26, !tbaa !24
  %t406 = mul i64 %t402, %t403
  %t409 = add i64 %t401, %t406
  store i64 %t409, ptr %l29, !tbaa !24
  %t411 = load i64, ptr %l23, !tbaa !65
  %t412 = load i64, ptr %l29, !tbaa !24
  store i64 %t412, ptr %l231, !tbaa !24
  %t413 = load i64, ptr %l231, !tbaa !24
  %t414 = load i64, ptr %l231, !tbaa !24
  %t415 = shl i64 1, %t414
  %t418 = and i64 %t411, %t415
  %t420 = icmp ne i64 %t418, 0
  br i1 %t420, label %bb99, label %bb100
bb99:
  store %olang.scope zeroinitializer, ptr %s23
  %t422 = load ptr, ptr %l2, !tbaa !29
  store ptr %t422, ptr %l235, !tbaa !29
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t425 = getelementptr %"compiler/check:Checker", ptr %t423, i32 0, i32 1
  %t426 = load ptr, ptr %t425, !tbaa !29
  %t428 = getelementptr %"compiler/generic:Program", ptr %t426, i32 0, i32 2
  %t429 = load i32, ptr %l22, !tbaa !23
  %t432 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t428, i32 %t429)
  store i32 %t432, ptr %l240
  br label %bb101
bb100:
  br label %bb104
bb101:
  %t433 = load i64, ptr %l29, !tbaa !24
  %t434 = load i32, ptr %l240, !tbaa !23
  %t436 = call %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %s23, i32 %t434, i64 %t433)
  store %"compiler/typed:Item" %t436, ptr %l242
  br label %bb102
bb102:
  %t437 = load ptr, ptr %l235, !tbaa !29
  %t438 = load %"compiler/typed:Item", ptr %l242
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v2, ptr %t437, %"compiler/typed:Item" %t438)
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s23)
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s22)
  br label %bb105
bb105:
  %t439 = load i64, ptr %l28, !tbaa !24
  %t441 = add i64 %t439, 1
  store i64 %t441, ptr %l28, !tbaa !24
  br label %bb95
bb106:
  call void @__olang_scope_close(ptr %s18)
  br label %bb107
bb107:
  %t443 = load i64, ptr %l21, !tbaa !24
  %t445 = add i64 %t443, 1
  store i64 %t445, ptr %l21, !tbaa !24
  br label %bb75
bb108:
  %t447 = load i64, ptr %l18, !tbaa !24
  %t448 = load i64, ptr %l20, !tbaa !24
  %t451 = add i64 %t447, %t448
  store i64 %t451, ptr %l18, !tbaa !24
  call void @__olang_scope_close(ptr %s17)
  br label %bb109
bb109:
  br label %bb68
bb110:
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb111:
  %t453 = load ptr, ptr %l0, !tbaa !29
  %t454 = load ptr, ptr %l1, !tbaa !29
  %t457 = call { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorWord(ptr %v0, ptr %v1, ptr %t453, ptr %t454)
  store { i64, i32 } %t457, ptr %l252
  br label %bb112
bb112:
  %t458 = load { i64, i32 }, ptr %l252
  store { i64, i32 } %t458, ptr %l30
  %t459 = getelementptr { i64, i32 }, ptr %l30, i32 0, i32 0
  %t460 = load i64, ptr %t459, !tbaa !24
  store i64 %t460, ptr %l31, !tbaa !24
  %t462 = getelementptr { i64, i32 }, ptr %l30, i32 0, i32 1
  %t463 = load i32, ptr %t462, !tbaa !23
  store i32 %t463, ptr %l32, !tbaa !23
  %t465 = load i64, ptr %l31, !tbaa !24
  %t467 = icmp slt i64 %t465, 0
  br i1 %t467, label %bb113, label %bb114
bb113:
  %t469 = load ptr, ptr %l0, !tbaa !29
  %t471 = getelementptr %"compiler/check:Checker", ptr %t469, i32 0, i32 1
  %t472 = load ptr, ptr %t471, !tbaa !29
  store ptr %t472, ptr %l258, !tbaa !29
  %t473 = load ptr, ptr %l0, !tbaa !29
  %t475 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t473)
  store ptr %t475, ptr %l260
  br label %bb115
bb114:
  br label %bb117
bb115:
  %t476 = load ptr, ptr %l260, !tbaa !29
  %t478 = getelementptr %"compiler/check:frame", ptr %t476, i32 0, i32 4
  %t479 = load ptr, ptr %l1, !tbaa !29
  %t480 = load ptr, ptr %l258, !tbaa !29
  %t483 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorItemKnown(ptr %v0, ptr %v0, ptr %v1, ptr %t480, ptr %t478, ptr %t479)
  store i1 %t483, ptr %l264
  br label %bb116
bb116:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb117:
  %t484 = load ptr, ptr %l2, !tbaa !29
  store ptr %t484, ptr %l265, !tbaa !29
  %t485 = load i32, ptr %l32, !tbaa !23
  %t486 = load i64, ptr %l31, !tbaa !24
  %t489 = call %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %s0, i32 %t485, i64 %t486)
  store %"compiler/typed:Item" %t489, ptr %l268
  br label %bb118
bb118:
  %t490 = load ptr, ptr %l265, !tbaa !29
  %t491 = load %"compiler/typed:Item", ptr %l268
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v2, ptr %t490, %"compiler/typed:Item" %t491)
  br label %bb119
bb119:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecommutesRule(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l5 = alloca %"compiler/source:Span"
  %l7 = alloca { i64, ptr }
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i64
  %l17 = alloca i64
  %l21 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l28 = alloca i32
  %l31 = alloca ptr
  %l36 = alloca i32
  %l37 = alloca { i64, ptr }
  %l39 = alloca i1
  %l40 = alloca i1
  %l42 = alloca i1
  %l43 = alloca i1
  %l45 = alloca i1
  %l46 = alloca i1
  %l48 = alloca i1
  %l49 = alloca i1
  %l51 = alloca i1
  %l54 = alloca i1
  %l58 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca %"compiler/source:Span"
  %l67 = alloca { i64, ptr }
  %l69 = alloca %"compiler/msgs:Msg"
  %l70 = alloca i64
  %l74 = alloca ptr
  %l76 = alloca { i64, ptr }
  %l78 = alloca i32
  %l79 = alloca i32
  %l82 = alloca ptr
  %l84 = alloca { i64, ptr }
  %l86 = alloca i32
  %l87 = alloca i32
  %l93 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca %"compiler/source:Span"
  %l99 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l105 = alloca %"compiler/msgs:Msg"
  %l106 = alloca i64
  %l110 = alloca i1
  %l116 = alloca i64
  %l119 = alloca i1
  %l126 = alloca ptr
  %l129 = alloca ptr
  %l133 = alloca i32
  %l134 = alloca i32
  %l135 = alloca { i64, ptr }
  %l138 = alloca ptr
  %l141 = alloca ptr
  %l143 = alloca { i64, ptr }
  %l145 = alloca i32
  %l146 = alloca i32
  %l148 = alloca i1
  %l154 = alloca ptr
  %l158 = alloca i1
  %l164 = alloca i1
  %l165 = alloca { i64, ptr }
  %l167 = alloca i1
  %l168 = alloca { i64, ptr }
  %l170 = alloca i1
  %l171 = alloca { i64, ptr }
  %l173 = alloca i1
  %l174 = alloca { i64, ptr }
  %l175 = alloca ptr
  %l176 = alloca %"compiler/source:Span"
  %l177 = alloca { i64, ptr }
  %l180 = alloca { i64, ptr }
  %l181 = alloca { i64, ptr }
  %l184 = alloca { i64, ptr }
  %l185 = alloca { i64, ptr }
  %l188 = alloca { i64, ptr }
  %l189 = alloca ptr
  %l193 = alloca ptr
  %l196 = alloca { i64, ptr }
  %l199 = alloca %"compiler/msgs:Msg"
  %l200 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t4, i64 %t5)
  store i64 %t8, ptr %l17
  br label %bb1
bb1:
  %t9 = load i64, ptr %l17, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t16 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t10, i64 -1, i64 %t9, i32 %t12, i32 0)
  store ptr %t16, ptr %l21
  br label %bb2
bb2:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t21 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v1, ptr %t17, ptr %t18)
  store %"compiler/source:Span" %t21, ptr %l24
  br label %bb3
bb3:
  %t22 = load %"compiler/source:Span", ptr %l24
  store %"compiler/source:Span" %t22, ptr %l5
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t27 = load i64, ptr %l1, !tbaa !24
  %t30 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t26, i64 %t27)
  store i32 %t30, ptr %l28
  br label %bb4
bb4:
  %t31 = load i32, ptr %l28, !tbaa !23
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  store ptr %t37, ptr %l31, !tbaa !29
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 2
  %t47 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t43, i32 %t31)
  store i32 %t47, ptr %l36
  br label %bb5
bb5:
  %t48 = load ptr, ptr %l31, !tbaa !29
  %t49 = load i32, ptr %l36, !tbaa !23
  %t50 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t48, i32 %t49)
  store { i64, ptr } %t50, ptr %l37
  br label %bb6
bb6:
  %t51 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t51, ptr %l7, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t54 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t52, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i1 %t54, ptr %l39
  br label %bb7
bb7:
  %t55 = load i1, ptr %l39, !tbaa !21
  br i1 %t55, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb11
bb9:
  %t56 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t58 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t56, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store i1 %t58, ptr %l42
  br label %bb10
bb10:
  %t59 = load i1, ptr %l42, !tbaa !21
  store i1 %t59, ptr %l40, !tbaa !21
  br label %bb11
bb11:
  %t60 = load i1, ptr %l40, !tbaa !21
  br i1 %t60, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb15
bb13:
  %t61 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t63 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t61, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i1 %t63, ptr %l45
  br label %bb14
bb14:
  %t64 = load i1, ptr %l45, !tbaa !21
  store i1 %t64, ptr %l43, !tbaa !21
  br label %bb15
bb15:
  %t65 = load i1, ptr %l43, !tbaa !21
  br i1 %t65, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb19
bb17:
  %t66 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t68 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t66, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store i1 %t68, ptr %l48
  br label %bb18
bb18:
  %t69 = load i1, ptr %l48, !tbaa !21
  store i1 %t69, ptr %l46, !tbaa !21
  br label %bb19
bb19:
  %t70 = load i1, ptr %l46, !tbaa !21
  br i1 %t70, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb23
bb21:
  %t71 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t73 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t71, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i1 %t73, ptr %l51
  br label %bb22
bb22:
  %t74 = load i1, ptr %l51, !tbaa !21
  store i1 %t74, ptr %l49, !tbaa !21
  br label %bb23
bb23:
  %t75 = load i1, ptr %l49, !tbaa !21
  %t78 = xor i1 %t75, true
  br i1 %t78, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb26
bb25:
  %t80 = load ptr, ptr %l2, !tbaa !29
  %t82 = getelementptr %"compiler/ast:Func", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = icmp eq ptr %t83, null
  store i1 %t85, ptr %l54, !tbaa !21
  br label %bb26
bb26:
  %t87 = load i1, ptr %l54, !tbaa !21
  br i1 %t87, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l58, !tbaa !21
  br label %bb29
bb28:
  %t88 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t92 = icmp ne i64 %t90, 2
  store i1 %t92, ptr %l58, !tbaa !21
  br label %bb29
bb29:
  %t94 = load i1, ptr %l58, !tbaa !21
  br i1 %t94, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s1
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l62, !tbaa !29
  %t96 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t96, ptr %l63
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %l2, !tbaa !29
  %t100 = getelementptr %"compiler/ast:Func", ptr %t98, i32 0, i32 2
  %t101 = load i32, ptr %t100, !tbaa !23
  %t104 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s1, ptr %t97, i32 %t101)
  store { i64, ptr } %t104, ptr %l67
  br label %bb32
bb31:
  br label %bb36
bb32:
  %t105 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t105, 0
  %t107 = extractvalue { i64, ptr } %t105, 1
  %t108 = mul i64 %t106, 1
  %t109 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t108)
  call void @llvm.memcpy.p0.p0.i64(ptr %t109, ptr %t107, i64 %t108, i1 false)
  %t110 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  %t113 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCommutesNotHere(ptr %s1, ptr %s1, { i64, ptr } %t111)
  store %"compiler/msgs:Msg" %t113, ptr %l69
  br label %bb33
bb33:
  %t114 = load ptr, ptr %l62, !tbaa !29
  %t115 = load %"compiler/source:Span", ptr %l63
  %t116 = load %"compiler/msgs:Msg", ptr %l69
  %t117 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t114, %"compiler/source:Span" %t115, %"compiler/msgs:Msg" %t116)
  store i64 %t117, ptr %l70
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s1)
  %t118 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t118)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb36:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/check:Checker", ptr %t120, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = getelementptr %"compiler/generic:Program", ptr %t123, i32 0, i32 2
  store ptr %t125, ptr %l74, !tbaa !29
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t127, ptr %l76, !tbaa !27
  %t128 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr i32, ptr %t129, i64 0
  %t131 = load i32, ptr %t130, !tbaa !33
  %t134 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t126, i32 %t131)
  store i32 %t134, ptr %l78
  br label %bb37
bb37:
  %t135 = load ptr, ptr %l74, !tbaa !29
  %t136 = load i32, ptr %l78, !tbaa !23
  %t137 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t135, i32 %t136)
  store i32 %t137, ptr %l79
  br label %bb38
bb38:
  %t138 = load i32, ptr %l79, !tbaa !23
  store i32 %t138, ptr %l9, !tbaa !23
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/check:Checker", ptr %t139, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t144 = getelementptr %"compiler/generic:Program", ptr %t142, i32 0, i32 2
  store ptr %t144, ptr %l82, !tbaa !29
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t146, ptr %l84, !tbaa !27
  %t147 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = getelementptr i32, ptr %t148, i64 1
  %t150 = load i32, ptr %t149, !tbaa !33
  %t153 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t145, i32 %t150)
  store i32 %t153, ptr %l86
  br label %bb39
bb39:
  %t154 = load ptr, ptr %l82, !tbaa !29
  %t155 = load i32, ptr %l86, !tbaa !23
  %t156 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t154, i32 %t155)
  store i32 %t156, ptr %l87
  br label %bb40
bb40:
  %t157 = load i32, ptr %l87, !tbaa !23
  store i32 %t157, ptr %l10, !tbaa !23
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/check:Checker", ptr %t158, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = getelementptr %"compiler/generic:Program", ptr %t161, i32 0, i32 2
  %t164 = load i32, ptr %l9, !tbaa !23
  %t165 = load i32, ptr %l10, !tbaa !23
  %t169 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t163, i32 %t164, i32 %t165)
  store i1 %t169, ptr %l93
  br label %bb41
bb41:
  %t170 = load i1, ptr %l93, !tbaa !21
  br i1 %t170, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s3
  %t171 = load ptr, ptr %l0, !tbaa !29
  store ptr %t171, ptr %l94, !tbaa !29
  %t172 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t172, ptr %l95
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load ptr, ptr %l2, !tbaa !29
  %t176 = getelementptr %"compiler/ast:Func", ptr %t174, i32 0, i32 2
  %t177 = load i32, ptr %t176, !tbaa !23
  %t180 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s3, ptr %t173, i32 %t177)
  store { i64, ptr } %t180, ptr %l99
  br label %bb44
bb43:
  br label %bb49
bb44:
  %t181 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t181, 0
  %t183 = extractvalue { i64, ptr } %t181, 1
  %t184 = mul i64 %t182, 1
  %t185 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t184)
  call void @llvm.memcpy.p0.p0.i64(ptr %t185, ptr %t183, i64 %t184, i1 false)
  %t186 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t185, 1
  store { i64, ptr } %t187, ptr %l100, !tbaa !27
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load i32, ptr %l10, !tbaa !23
  %t192 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t188, i32 %t189)
  store { i64, ptr } %t192, ptr %l103
  br label %bb45
bb45:
  %t193 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t194 = extractvalue { i64, ptr } %t193, 0
  %t195 = extractvalue { i64, ptr } %t193, 1
  %t196 = mul i64 %t194, 1
  %t197 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t196)
  call void @llvm.memcpy.p0.p0.i64(ptr %t197, ptr %t195, i64 %t196, i1 false)
  %t198 = insertvalue { i64, ptr } undef, i64 %t194, 0
  %t199 = insertvalue { i64, ptr } %t198, ptr %t197, 1
  %t200 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t202 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCommutesSameType(ptr %s3, ptr %s3, ptr %s3, { i64, ptr } %t200, { i64, ptr } %t199)
  store %"compiler/msgs:Msg" %t202, ptr %l105
  br label %bb46
bb46:
  %t203 = load ptr, ptr %l94, !tbaa !29
  %t204 = load %"compiler/source:Span", ptr %l95
  %t205 = load %"compiler/msgs:Msg", ptr %l105
  %t206 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t203, %"compiler/source:Span" %t204, %"compiler/msgs:Msg" %t205)
  store i64 %t206, ptr %l106
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s3)
  %t207 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t207)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb49:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load i32, ptr %l10, !tbaa !23
  %t213 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t209, i32 %t210)
  store i1 %t213, ptr %l110
  br label %bb50
bb50:
  %t214 = load i1, ptr %l110, !tbaa !21
  %t215 = xor i1 %t214, true
  br i1 %t215, label %bb51, label %bb52
bb51:
  %t217 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t217)
  br label %bb53
bb52:
  br label %bb54
bb53:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb54:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load i32, ptr %l10, !tbaa !23
  %t221 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t225 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %v2, ptr %t219, i32 %t220, { i64, ptr } %t221, i64 1)
  store i64 %t225, ptr %l116
  br label %bb55
bb55:
  %t226 = load i64, ptr %l116, !tbaa !24
  store i64 %t226, ptr %l11, !tbaa !24
  %t227 = load i64, ptr %l11, !tbaa !24
  %t229 = icmp slt i64 %t227, 0
  br i1 %t229, label %bb56, label %bb57
bb56:
  store i1 true, ptr %l119, !tbaa !21
  br label %bb58
bb57:
  %t231 = load i64, ptr %l11, !tbaa !24
  %t232 = load i64, ptr %l1, !tbaa !24
  %t235 = icmp eq i64 %t231, %t232
  store i1 %t235, ptr %l119, !tbaa !21
  br label %bb58
bb58:
  %t237 = load i1, ptr %l119, !tbaa !21
  br i1 %t237, label %bb59, label %bb60
bb59:
  %t238 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t238)
  br label %bb61
bb60:
  br label %bb62
bb61:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb62:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = getelementptr %"compiler/check:Checker", ptr %t240, i32 0, i32 1
  %t243 = load ptr, ptr %t242, !tbaa !29
  %t245 = getelementptr %"compiler/generic:Program", ptr %t243, i32 0, i32 2
  store ptr %t245, ptr %l126, !tbaa !29
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t248 = getelementptr %"compiler/check:Checker", ptr %t246, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !29
  %t251 = getelementptr %"compiler/generic:Program", ptr %t249, i32 0, i32 2
  store ptr %t251, ptr %l129, !tbaa !29
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr %"compiler/check:Checker", ptr %t252, i32 0, i32 1
  %t255 = load ptr, ptr %t254, !tbaa !29
  %t256 = load i64, ptr %l11, !tbaa !24
  %t259 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t255, i64 %t256)
  store i32 %t259, ptr %l133
  br label %bb63
bb63:
  %t260 = load ptr, ptr %l129, !tbaa !29
  %t261 = load i32, ptr %l133, !tbaa !23
  %t262 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t260, i32 %t261)
  store i32 %t262, ptr %l134
  br label %bb64
bb64:
  %t263 = load ptr, ptr %l126, !tbaa !29
  %t264 = load i32, ptr %l134, !tbaa !23
  %t265 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t263, i32 %t264)
  store { i64, ptr } %t265, ptr %l135
  br label %bb65
bb65:
  %t266 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/check:Checker", ptr %t267, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !29
  %t272 = getelementptr %"compiler/generic:Program", ptr %t270, i32 0, i32 2
  store ptr %t272, ptr %l138, !tbaa !29
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/check:Checker", ptr %t273, i32 0, i32 1
  %t276 = load ptr, ptr %t275, !tbaa !29
  %t278 = getelementptr %"compiler/generic:Program", ptr %t276, i32 0, i32 2
  store ptr %t278, ptr %l141, !tbaa !29
  %t279 = load ptr, ptr %l0, !tbaa !29
  store { i64, ptr } %t266, ptr %l143, !tbaa !27
  %t281 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !27
  %t283 = getelementptr i32, ptr %t282, i64 1
  %t284 = load i32, ptr %t283, !tbaa !33
  %t287 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t279, i32 %t284)
  store i32 %t287, ptr %l145
  br label %bb66
bb66:
  %t288 = load ptr, ptr %l141, !tbaa !29
  %t289 = load i32, ptr %l145, !tbaa !23
  %t290 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t288, i32 %t289)
  store i32 %t290, ptr %l146
  br label %bb67
bb67:
  %t291 = load i32, ptr %l9, !tbaa !23
  %t292 = load ptr, ptr %l138, !tbaa !29
  %t293 = load i32, ptr %l146, !tbaa !23
  %t295 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t292, i32 %t293, i32 %t291)
  store i1 %t295, ptr %l148
  br label %bb68
bb68:
  %t296 = load i1, ptr %l148, !tbaa !21
  %t297 = xor i1 %t296, true
  br i1 %t297, label %bb69, label %bb70
bb69:
  %t299 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t299)
  br label %bb71
bb70:
  br label %bb72
bb71:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb72:
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t303 = getelementptr %"compiler/check:Checker", ptr %t301, i32 0, i32 1
  %t304 = load ptr, ptr %t303, !tbaa !29
  %t305 = load i64, ptr %l11, !tbaa !24
  %t308 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t304, i64 %t305)
  store ptr %t308, ptr %l154
  br label %bb73
bb73:
  %t309 = load ptr, ptr %l154, !tbaa !29
  %t311 = getelementptr %"compiler/ast:Func", ptr %t309, i32 0, i32 3
  %t312 = load ptr, ptr %t311, !tbaa !29
  %t314 = getelementptr %"compiler/ast:Sig", ptr %t312, i32 0, i32 6
  %t315 = load i1, ptr %t314, !tbaa !21
  br i1 %t315, label %bb74, label %bb75
bb74:
  %t317 = load i64, ptr %l11, !tbaa !24
  %t318 = load i64, ptr %l1, !tbaa !24
  %t321 = icmp sgt i64 %t317, %t318
  store i1 %t321, ptr %l158, !tbaa !21
  br label %bb76
bb75:
  store i1 false, ptr %l158, !tbaa !21
  br label %bb76
bb76:
  %t323 = load i1, ptr %l158, !tbaa !21
  br i1 %t323, label %bb77, label %bb78
bb77:
  %t324 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t324)
  br label %bb79
bb78:
  br label %bb80
bb79:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb80:
  %t326 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t328 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t326, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i1 %t328, ptr %l164
  br label %bb81
bb81:
  %t329 = load i1, ptr %l164, !tbaa !21
  br i1 %t329, label %bb82, label %bb83
bb82:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l165, !tbaa !27
  br label %bb96
bb83:
  %t330 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t332 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t330, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i1 %t332, ptr %l167
  br label %bb84
bb84:
  %t333 = load i1, ptr %l167, !tbaa !21
  br i1 %t333, label %bb85, label %bb86
bb85:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %l168, !tbaa !27
  br label %bb95
bb86:
  %t334 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t336 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t334, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t336, ptr %l170
  br label %bb87
bb87:
  %t337 = load i1, ptr %l170, !tbaa !21
  br i1 %t337, label %bb88, label %bb89
bb88:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d13, i32 0, i32 1) }, ptr %l171, !tbaa !27
  br label %bb94
bb89:
  %t338 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t340 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t338, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i1 %t340, ptr %l173
  br label %bb90
bb90:
  %t341 = load i1, ptr %l173, !tbaa !21
  br i1 %t341, label %bb91, label %bb92
bb91:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %l174, !tbaa !27
  br label %bb93
bb92:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l174, !tbaa !27
  br label %bb93
bb93:
  %t342 = load { i64, ptr }, ptr %l174, !tbaa !27
  store { i64, ptr } %t342, ptr %l171, !tbaa !27
  br label %bb94
bb94:
  %t343 = load { i64, ptr }, ptr %l171, !tbaa !27
  store { i64, ptr } %t343, ptr %l168, !tbaa !27
  br label %bb95
bb95:
  %t344 = load { i64, ptr }, ptr %l168, !tbaa !27
  store { i64, ptr } %t344, ptr %l165, !tbaa !27
  br label %bb96
bb96:
  %t345 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t346 = load ptr, ptr %l0, !tbaa !29
  store ptr %t346, ptr %l175, !tbaa !29
  %t347 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t347, ptr %l176
  store { i64, ptr } %t345, ptr %l177, !tbaa !27
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t350 = load i32, ptr %l9, !tbaa !23
  %t353 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t349, i32 %t350)
  store { i64, ptr } %t353, ptr %l180
  br label %bb97
bb97:
  %t354 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t355 = extractvalue { i64, ptr } %t354, 0
  %t356 = extractvalue { i64, ptr } %t354, 1
  %t357 = mul i64 %t355, 1
  %t358 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t357)
  call void @llvm.memcpy.p0.p0.i64(ptr %t358, ptr %t356, i64 %t357, i1 false)
  %t359 = insertvalue { i64, ptr } undef, i64 %t355, 0
  %t360 = insertvalue { i64, ptr } %t359, ptr %t358, 1
  store { i64, ptr } %t360, ptr %l181, !tbaa !27
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load i32, ptr %l10, !tbaa !23
  %t365 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t361, i32 %t362)
  store { i64, ptr } %t365, ptr %l184
  br label %bb98
bb98:
  %t366 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t367 = extractvalue { i64, ptr } %t366, 0
  %t368 = extractvalue { i64, ptr } %t366, 1
  %t369 = mul i64 %t367, 1
  %t370 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t369)
  call void @llvm.memcpy.p0.p0.i64(ptr %t370, ptr %t368, i64 %t369, i1 false)
  %t371 = insertvalue { i64, ptr } undef, i64 %t367, 0
  %t372 = insertvalue { i64, ptr } %t371, ptr %t370, 1
  store { i64, ptr } %t372, ptr %l185, !tbaa !27
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t374 = load i32, ptr %l10, !tbaa !23
  %t377 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t373, i32 %t374)
  store { i64, ptr } %t377, ptr %l188
  br label %bb99
bb99:
  %t378 = load ptr, ptr %l0, !tbaa !29
  store ptr %t378, ptr %l189, !tbaa !29
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t381 = getelementptr %"compiler/check:Checker", ptr %t379, i32 0, i32 1
  %t382 = load ptr, ptr %t381, !tbaa !29
  %t383 = load i64, ptr %l11, !tbaa !24
  %t386 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t382, i64 %t383)
  store ptr %t386, ptr %l193
  br label %bb100
bb100:
  %t387 = load ptr, ptr %l193, !tbaa !29
  %t389 = getelementptr %"compiler/ast:Func", ptr %t387, i32 0, i32 2
  %t390 = load i32, ptr %t389, !tbaa !23
  %t391 = load ptr, ptr %l189, !tbaa !29
  %t393 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t391, i32 %t390)
  store { i64, ptr } %t393, ptr %l196
  br label %bb101
bb101:
  %t394 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t395 = extractvalue { i64, ptr } %t394, 1
  %t396 = extractvalue { i64, ptr } %t394, 0
  %t397 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t398 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t399 = add i64 %t396, %t398
  %t400 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t401 = extractvalue { i64, ptr } %t400, 1
  %t402 = extractvalue { i64, ptr } %t400, 0
  %t403 = add i64 %t399, %t402
  %t404 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t403)
  call void @olang_textcopy(ptr %t404, ptr %t395, i64 %t396)
  %t405 = getelementptr i8, ptr %t404, i64 %t396
  call void @olang_textcopy(ptr %t405, ptr %t397, i64 %t398)
  %t406 = getelementptr i8, ptr %t405, i64 %t398
  call void @olang_textcopy(ptr %t406, ptr %t401, i64 %t402)
  %t407 = insertvalue { i64, ptr } undef, i64 %t403, 0
  %t408 = insertvalue { i64, ptr } %t407, ptr %t404, 1
  %t410 = extractvalue { i64, ptr } %t408, 0
  %t411 = extractvalue { i64, ptr } %t408, 1
  %t412 = mul i64 %t410, 1
  %t413 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t412)
  call void @llvm.memcpy.p0.p0.i64(ptr %t413, ptr %t411, i64 %t412, i1 false)
  %t414 = insertvalue { i64, ptr } undef, i64 %t410, 0
  %t415 = insertvalue { i64, ptr } %t414, ptr %t413, 1
  %t416 = load ptr, ptr @__olang_prog_scope
  %t417 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t418 = load { i64, ptr }, ptr %l181, !tbaa !27
  %t419 = load { i64, ptr }, ptr %l185, !tbaa !27
  %t421 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCommutesClash(ptr %t416, ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t417, { i64, ptr } %t418, { i64, ptr } %t419, { i64, ptr } %t415)
  store %"compiler/msgs:Msg" %t421, ptr %l199
  br label %bb102
bb102:
  %t422 = load ptr, ptr %l175, !tbaa !29
  %t423 = load %"compiler/source:Span", ptr %l176
  %t424 = load %"compiler/msgs:Msg", ptr %l199
  %t425 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t422, %"compiler/source:Span" %t423, %"compiler/msgs:Msg" %t424)
  store i64 %t425, ptr %l200
  br label %bb103
bb103:
  %t426 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t426)
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecommuting(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i64
  %l5 = alloca i1
  %l7 = alloca i1
  %l10 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l20 = alloca i1
  %l24 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2
  %t3 = call i1 @compiler_2fcheck_2ecommutative(i32 %t1)
  store i1 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i1, ptr %l5, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb5
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t7, i32 %t8)
  store i1 %t11, ptr %l10
  br label %bb4
bb4:
  %t12 = load i1, ptr %l10, !tbaa !21
  %t13 = xor i1 %t12, true
  store i1 %t13, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t15 = load i1, ptr %l7, !tbaa !21
  br i1 %t15, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l13, !tbaa !29
  %t18 = load i32, ptr %l1, !tbaa !23
  store i32 %t18, ptr %l14, !tbaa !23
  %t19 = load i32, ptr %l2
  %t21 = call { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %s0, i32 %t19)
  store { i64, ptr } %t21, ptr %l16
  br label %bb9
bb9:
  %t22 = load ptr, ptr %l13, !tbaa !29
  %t23 = load i32, ptr %l14, !tbaa !23
  %t24 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t25 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t22, i32 %t23, { i64, ptr } %t24, i64 1)
  store i64 %t25, ptr %l17
  br label %bb10
bb10:
  %t26 = load i64, ptr %l17, !tbaa !24
  store i64 %t26, ptr %l3, !tbaa !24
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = icmp slt i64 %t27, 0
  br i1 %t29, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb14
bb12:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t35 = load i64, ptr %l3, !tbaa !24
  %t38 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t34, i64 %t35)
  store ptr %t38, ptr %l24
  br label %bb13
bb13:
  %t39 = load ptr, ptr %l24, !tbaa !29
  %t41 = getelementptr %"compiler/ast:Func", ptr %t39, i32 0, i32 3
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/ast:Sig", ptr %t42, i32 0, i32 6
  %t45 = load i1, ptr %t44, !tbaa !21
  %t47 = xor i1 %t45, true
  store i1 %t47, ptr %l20, !tbaa !21
  br label %bb14
bb14:
  %t49 = load i1, ptr %l20, !tbaa !21
  br i1 %t49, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t51 = load i64, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t51, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, ptr %a4, i32 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l16 = alloca i64
  %l23 = alloca ptr
  %l30 = alloca ptr
  %l33 = alloca ptr
  %l35 = alloca ptr
  %l38 = alloca i64
  %l42 = alloca i1
  %l45 = alloca i1
  %l46 = alloca i1
  %l49 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca ptr
  %l54 = alloca ptr
  %l61 = alloca ptr
  %l64 = alloca ptr
  %l68 = alloca ptr
  %l69 = alloca ptr
  %l71 = alloca ptr
  %l74 = alloca ptr
  %l76 = alloca ptr
  %l77 = alloca ptr
  %l80 = alloca i32
  %l81 = alloca i1
  %l82 = alloca i32
  %l85 = alloca i32
  %l87 = alloca ptr
  %l90 = alloca ptr
  %l94 = alloca ptr
  %l95 = alloca ptr
  %l97 = alloca ptr
  %l104 = alloca ptr
  %l107 = alloca ptr
  %l111 = alloca ptr
  %l112 = alloca ptr
  %l114 = alloca ptr
  %l117 = alloca ptr
  %l119 = alloca ptr
  %l123 = alloca i1
  %l126 = alloca i1
  %l127 = alloca i1
  %l130 = alloca i1
  %l132 = alloca i1
  %l133 = alloca ptr
  %l136 = alloca i32
  %l137 = alloca i1
  %l138 = alloca i32
  %l141 = alloca i32
  %l143 = alloca ptr
  %l146 = alloca ptr
  %l151 = alloca i32
  %l153 = alloca i32
  %l156 = alloca i1
  %l157 = alloca i1
  %l160 = alloca i1
  %l161 = alloca i1
  %l167 = alloca i1
  %l169 = alloca i1
  %l172 = alloca i1
  %l174 = alloca i1
  %l177 = alloca i1
  %l179 = alloca ptr
  %l180 = alloca ptr
  %l182 = alloca %"compiler/source:Span"
  %l184 = alloca %"compiler/source:Span"
  %l185 = alloca %"compiler/source:Span"
  %l188 = alloca { i64, ptr }
  %l189 = alloca { i64, ptr }
  %l192 = alloca { i64, ptr }
  %l194 = alloca %"compiler/msgs:Msg"
  %l195 = alloca i64
  %l198 = alloca ptr
  %l207 = alloca i1
  %l219 = alloca i1
  %l228 = alloca i1
  %l232 = alloca i1
  %l233 = alloca i1
  %l236 = alloca i1
  %l237 = alloca i1
  %l242 = alloca i32
  %l248 = alloca i32
  %l252 = alloca i1
  %l255 = alloca i1
  %l256 = alloca i1
  %l261 = alloca i32
  %l268 = alloca i32
  %l272 = alloca i1
  %l275 = alloca i1
  %l276 = alloca i1
  %l281 = alloca i32
  %l288 = alloca i32
  %l291 = alloca i1
  %l292 = alloca i1
  %l295 = alloca i1
  %l297 = alloca i1
  %l298 = alloca ptr
  %l299 = alloca i32
  %l304 = alloca i32
  %l305 = alloca i1
  %l309 = alloca i1
  %l310 = alloca i1
  %l313 = alloca i1
  %l315 = alloca i1
  %l316 = alloca ptr
  %l317 = alloca i32
  %l322 = alloca i32
  %l323 = alloca i1
  %l327 = alloca i1
  %l328 = alloca i1
  %l331 = alloca i1
  %l332 = alloca i1
  %l335 = alloca ptr
  %l338 = alloca i32
  %l341 = alloca i32
  %l342 = alloca i1
  %l345 = alloca ptr
  %l348 = alloca i32
  %l353 = alloca i64
  %l358 = alloca i64
  %l359 = alloca i64
  %l360 = alloca i32
  %l363 = alloca i1
  %l364 = alloca i1
  %l367 = alloca i1
  %l368 = alloca i1
  %l371 = alloca ptr
  %l372 = alloca ptr
  %l375 = alloca i32
  %l376 = alloca i32
  %l377 = alloca ptr
  %l380 = alloca i32
  %l381 = alloca i32
  %l382 = alloca i1
  %l385 = alloca ptr
  %l386 = alloca ptr
  %l389 = alloca i32
  %l390 = alloca i32
  %l395 = alloca i64
  %l400 = alloca i64
  %l401 = alloca i64
  %l402 = alloca i32
  %l407 = alloca i32
  %l410 = alloca i1
  %l415 = alloca i32
  %l418 = alloca i1
  %l421 = alloca ptr
  %l426 = alloca i32
  %l431 = alloca i32
  %l432 = alloca i1
  %l435 = alloca ptr
  %l440 = alloca i32
  %l441 = alloca i32
  %l442 = alloca ptr
  %l443 = alloca %"compiler/source:Span"
  %l446 = alloca { i64, ptr }
  %l447 = alloca { i64, ptr }
  %l450 = alloca { i64, ptr }
  %l452 = alloca %"compiler/msgs:Msg"
  %l453 = alloca i64
  %l456 = alloca ptr
  %l457 = alloca %"compiler/source:Span"
  %l458 = alloca i32
  %l459 = alloca ptr
  %l460 = alloca ptr
  %l463 = alloca ptr
  %l464 = alloca i32
  %l466 = alloca %"compiler/source:Span"
  %l467 = alloca ptr
  %l468 = alloca ptr
  %l469 = alloca ptr
  %l472 = alloca ptr
  %l473 = alloca i32
  %l475 = alloca %"compiler/source:Span"
  %l476 = alloca ptr
  %l477 = alloca %"compiler/typed:Cond"
  %s5 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %rv = alloca ptr
  %t922 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store i32 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econstCond(ptr %v0, ptr %v2, ptr %t1, ptr %t2)
  store i64 %t5, ptr %l16
  br label %bb1
bb1:
  %t6 = load i64, ptr %l16, !tbaa !24
  store i64 %t6, ptr %l6, !tbaa !24
  %t7 = load i64, ptr %l6, !tbaa !24
  %t9 = icmp eq i64 %t7, 1
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t14 = load i32, ptr %l5, !tbaa !23
  %t18 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t11, ptr %t12, i32 %t14)
  store ptr %t18, ptr %l23
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t19 = load ptr, ptr %l23, !tbaa !29
  store ptr %t19, ptr %rv
  br label %ret
bb5:
  %t20 = load i64, ptr %l6, !tbaa !24
  %t22 = icmp eq i64 %t20, 0
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load ptr, ptr %l4, !tbaa !29
  %t27 = load i32, ptr %l5, !tbaa !23
  %t31 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v3, ptr %t24, ptr %t25, i32 %t27)
  store ptr %t31, ptr %l30
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t32 = load ptr, ptr %l30, !tbaa !29
  store ptr %t32, ptr %rv
  br label %ret
bb9:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t37 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v2, ptr %t33, ptr %t34)
  store ptr %t37, ptr %l33
  br label %bb10
bb10:
  %t38 = load ptr, ptr %l33, !tbaa !29
  store ptr %t38, ptr %l7, !tbaa !29
  store ptr null, ptr %l8, !tbaa !29
  store ptr null, ptr %l9, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t39)
  store ptr %t41, ptr %l35
  br label %bb11
bb11:
  %t42 = load ptr, ptr %l35, !tbaa !29
  %t44 = getelementptr %"compiler/check:frame", ptr %t42, i32 0, i32 46
  %t46 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anullNarrow_3e_2e_H86c927da52ed537ecb3749a8061e4fd7(ptr %v0, ptr %t44)
  store i64 %t46, ptr %l38
  br label %bb12
bb12:
  %t47 = load i64, ptr %l38, !tbaa !24
  store i64 %t47, ptr %l10, !tbaa !24
  %t48 = load i32, ptr %l5, !tbaa !23
  %t49 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t52 = icmp eq i32 %t48, %t49
  br i1 %t52, label %bb13, label %bb14
bb13:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l2, !tbaa !29
  %t58 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t54, ptr %t55)
  store i1 %t58, ptr %l45
  br label %bb15
bb14:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb16
bb15:
  %t59 = load i1, ptr %l45, !tbaa !21
  store i1 %t59, ptr %l42, !tbaa !21
  br label %bb16
bb16:
  %t60 = load i1, ptr %l42, !tbaa !21
  br i1 %t60, label %bb17, label %bb18
bb17:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t65 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v3, ptr %t61, ptr %t62)
  store i1 %t65, ptr %l49
  br label %bb19
bb18:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb20
bb19:
  %t66 = load i1, ptr %l49, !tbaa !21
  %t67 = xor i1 %t66, true
  store i1 %t67, ptr %l46, !tbaa !21
  br label %bb20
bb20:
  %t69 = load i1, ptr %l46, !tbaa !21
  br i1 %t69, label %bb21, label %bb22
bb21:
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l51, !tbaa !29
  %t71 = load ptr, ptr %l3, !tbaa !29
  store ptr %t71, ptr %l52, !tbaa !29
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t72)
  store ptr %t74, ptr %l54
  br label %bb23
bb22:
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l94, !tbaa !29
  %t76 = load ptr, ptr %l3, !tbaa !29
  store ptr %t76, ptr %l95, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t77)
  store ptr %t79, ptr %l97
  br label %bb39
bb23:
  %t80 = load ptr, ptr %l54, !tbaa !29
  %t82 = getelementptr %"compiler/check:frame", ptr %t80, i32 0, i32 7
  %t83 = load i64, ptr %t82, !tbaa !24
  %t84 = load ptr, ptr %l51, !tbaa !29
  %t85 = load ptr, ptr %l52, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushNulls(ptr %v0, ptr %v2, ptr %t84, ptr %t85, i1 false, i64 %t83)
  br label %bb24
bb24:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l4, !tbaa !29
  %t90 = load i32, ptr %l5, !tbaa !23
  %t94 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v3, ptr %t87, ptr %t88, i32 %t90)
  store ptr %t94, ptr %l61
  br label %bb25
bb25:
  %t95 = load ptr, ptr %l61, !tbaa !29
  store ptr %t95, ptr %l9, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t97)
  store ptr %t99, ptr %l64
  br label %bb26
bb26:
  %t100 = load ptr, ptr %l64, !tbaa !29
  %t102 = getelementptr %"compiler/check:frame", ptr %t100, i32 0, i32 46
  %t103 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anullNarrow_3e_2e_H929f17842d04d84b7252ab4439481a7f(ptr %v0, ptr %t102, i64 %t103)
  br label %bb27
bb27:
  %t106 = load ptr, ptr %l0, !tbaa !29
  store ptr %t106, ptr %l68, !tbaa !29
  %t107 = load ptr, ptr %l3, !tbaa !29
  store ptr %t107, ptr %l69, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t108)
  store ptr %t110, ptr %l71
  br label %bb28
bb28:
  %t111 = load ptr, ptr %l71, !tbaa !29
  %t113 = getelementptr %"compiler/check:frame", ptr %t111, i32 0, i32 7
  %t114 = load i64, ptr %t113, !tbaa !24
  %t115 = load ptr, ptr %l68, !tbaa !29
  %t116 = load ptr, ptr %l69, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushNulls(ptr %v0, ptr %v2, ptr %t115, ptr %t116, i1 true, i64 %t114)
  br label %bb29
bb29:
  %t118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t118, ptr %l74, !tbaa !29
  %t119 = load ptr, ptr %l2, !tbaa !29
  store ptr %t119, ptr %l76, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l77, !tbaa !29
  %t122 = load ptr, ptr %l9, !tbaa !29
  %t125 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t122)
  store i32 %t125, ptr %l80
  br label %bb30
bb30:
  %t126 = load ptr, ptr %l77, !tbaa !29
  %t127 = load i32, ptr %l80, !tbaa !23
  %t128 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t126, i32 %t127)
  store i1 %t128, ptr %l81
  br label %bb31
bb31:
  %t129 = load i1, ptr %l81, !tbaa !21
  br i1 %t129, label %bb32, label %bb33
bb32:
  %t130 = load ptr, ptr %l9, !tbaa !29
  %t133 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t130)
  store i32 %t133, ptr %l85
  br label %bb34
bb33:
  %t134 = load i32, ptr %l5, !tbaa !23
  store i32 %t134, ptr %l82, !tbaa !23
  br label %bb35
bb34:
  %t136 = load i32, ptr %l85, !tbaa !23
  store i32 %t136, ptr %l82, !tbaa !23
  br label %bb35
bb35:
  %t137 = load ptr, ptr %l74, !tbaa !29
  %t138 = load ptr, ptr %l76, !tbaa !29
  %t139 = load i32, ptr %l82, !tbaa !23
  %t140 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t137, ptr %t138, i32 %t139)
  store ptr %t140, ptr %l87
  br label %bb36
bb36:
  %t141 = load ptr, ptr %l87, !tbaa !29
  store ptr %t141, ptr %l8, !tbaa !29
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t143)
  store ptr %t145, ptr %l90
  br label %bb37
bb37:
  %t146 = load ptr, ptr %l90, !tbaa !29
  %t148 = getelementptr %"compiler/check:frame", ptr %t146, i32 0, i32 46
  %t149 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anullNarrow_3e_2e_H929f17842d04d84b7252ab4439481a7f(ptr %v0, ptr %t148, i64 %t149)
  br label %bb38
bb38:
  br label %bb66
bb39:
  %t152 = load ptr, ptr %l97, !tbaa !29
  %t154 = getelementptr %"compiler/check:frame", ptr %t152, i32 0, i32 7
  %t155 = load i64, ptr %t154, !tbaa !24
  %t156 = load ptr, ptr %l94, !tbaa !29
  %t157 = load ptr, ptr %l95, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushNulls(ptr %v0, ptr %v2, ptr %t156, ptr %t157, i1 true, i64 %t155)
  br label %bb40
bb40:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load ptr, ptr %l2, !tbaa !29
  %t162 = load i32, ptr %l5, !tbaa !23
  %t166 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t159, ptr %t160, i32 %t162)
  store ptr %t166, ptr %l104
  br label %bb41
bb41:
  %t167 = load ptr, ptr %l104, !tbaa !29
  store ptr %t167, ptr %l8, !tbaa !29
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t169)
  store ptr %t171, ptr %l107
  br label %bb42
bb42:
  %t172 = load ptr, ptr %l107, !tbaa !29
  %t174 = getelementptr %"compiler/check:frame", ptr %t172, i32 0, i32 46
  %t175 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anullNarrow_3e_2e_H929f17842d04d84b7252ab4439481a7f(ptr %v0, ptr %t174, i64 %t175)
  br label %bb43
bb43:
  %t178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t178, ptr %l111, !tbaa !29
  %t179 = load ptr, ptr %l3, !tbaa !29
  store ptr %t179, ptr %l112, !tbaa !29
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t180)
  store ptr %t182, ptr %l114
  br label %bb44
bb44:
  %t183 = load ptr, ptr %l114, !tbaa !29
  %t185 = getelementptr %"compiler/check:frame", ptr %t183, i32 0, i32 7
  %t186 = load i64, ptr %t185, !tbaa !24
  %t187 = load ptr, ptr %l111, !tbaa !29
  %t188 = load ptr, ptr %l112, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushNulls(ptr %v0, ptr %v2, ptr %t187, ptr %t188, i1 false, i64 %t186)
  br label %bb45
bb45:
  %t190 = load ptr, ptr %l0, !tbaa !29
  store ptr %t190, ptr %l117, !tbaa !29
  %t191 = load ptr, ptr %l4, !tbaa !29
  store ptr %t191, ptr %l119, !tbaa !29
  %t193 = load i32, ptr %l5, !tbaa !23
  %t194 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t197 = icmp eq i32 %t193, %t194
  br i1 %t197, label %bb46, label %bb47
bb46:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load ptr, ptr %l4, !tbaa !29
  %t203 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v3, ptr %t199, ptr %t200)
  store i1 %t203, ptr %l126
  br label %bb48
bb47:
  store i1 false, ptr %l123, !tbaa !21
  br label %bb49
bb48:
  %t204 = load i1, ptr %l126, !tbaa !21
  store i1 %t204, ptr %l123, !tbaa !21
  br label %bb49
bb49:
  %t205 = load i1, ptr %l123, !tbaa !21
  br i1 %t205, label %bb50, label %bb51
bb50:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t207 = load ptr, ptr %l2, !tbaa !29
  %t210 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t206, ptr %t207)
  store i1 %t210, ptr %l130
  br label %bb52
bb51:
  store i1 false, ptr %l127, !tbaa !21
  br label %bb53
bb52:
  %t211 = load i1, ptr %l130, !tbaa !21
  %t212 = xor i1 %t211, true
  store i1 %t212, ptr %l127, !tbaa !21
  br label %bb53
bb53:
  %t214 = load i1, ptr %l127, !tbaa !21
  br i1 %t214, label %bb54, label %bb55
bb54:
  %t215 = load ptr, ptr %l0, !tbaa !29
  store ptr %t215, ptr %l133, !tbaa !29
  %t216 = load ptr, ptr %l8, !tbaa !29
  %t219 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t216)
  store i32 %t219, ptr %l136
  br label %bb56
bb55:
  store i1 false, ptr %l132, !tbaa !21
  br label %bb58
bb56:
  %t220 = load ptr, ptr %l133, !tbaa !29
  %t221 = load i32, ptr %l136, !tbaa !23
  %t222 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t220, i32 %t221)
  store i1 %t222, ptr %l137
  br label %bb57
bb57:
  %t223 = load i1, ptr %l137, !tbaa !21
  store i1 %t223, ptr %l132, !tbaa !21
  br label %bb58
bb58:
  %t224 = load i1, ptr %l132, !tbaa !21
  br i1 %t224, label %bb59, label %bb60
bb59:
  %t225 = load ptr, ptr %l8, !tbaa !29
  %t228 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t225)
  store i32 %t228, ptr %l141
  br label %bb61
bb60:
  %t229 = load i32, ptr %l5, !tbaa !23
  store i32 %t229, ptr %l138, !tbaa !23
  br label %bb62
bb61:
  %t231 = load i32, ptr %l141, !tbaa !23
  store i32 %t231, ptr %l138, !tbaa !23
  br label %bb62
bb62:
  %t232 = load ptr, ptr %l117, !tbaa !29
  %t233 = load ptr, ptr %l119, !tbaa !29
  %t234 = load i32, ptr %l138, !tbaa !23
  %t235 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v3, ptr %t232, ptr %t233, i32 %t234)
  store ptr %t235, ptr %l143
  br label %bb63
bb63:
  %t236 = load ptr, ptr %l143, !tbaa !29
  store ptr %t236, ptr %l9, !tbaa !29
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t238)
  store ptr %t240, ptr %l146
  br label %bb64
bb64:
  %t241 = load ptr, ptr %l146, !tbaa !29
  %t243 = getelementptr %"compiler/check:frame", ptr %t241, i32 0, i32 46
  %t244 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anullNarrow_3e_2e_H929f17842d04d84b7252ab4439481a7f(ptr %v0, ptr %t243, i64 %t244)
  br label %bb65
bb65:
  br label %bb66
bb66:
  %t247 = load ptr, ptr %l8, !tbaa !29
  %t249 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t247)
  store i32 %t249, ptr %l151
  br label %bb67
bb67:
  %t250 = load i32, ptr %l151, !tbaa !23
  store i32 %t250, ptr %l11, !tbaa !23
  %t251 = load ptr, ptr %l9, !tbaa !29
  %t253 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t251)
  store i32 %t253, ptr %l153
  br label %bb68
bb68:
  %t254 = load i32, ptr %l153, !tbaa !23
  store i32 %t254, ptr %l12, !tbaa !23
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t256 = load i32, ptr %l11, !tbaa !23
  %t259 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t255, i32 %t256)
  store i1 %t259, ptr %l156
  br label %bb69
bb69:
  %t260 = load i1, ptr %l156, !tbaa !21
  br i1 %t260, label %bb70, label %bb71
bb70:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t262 = load i32, ptr %l12, !tbaa !23
  %t265 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t261, i32 %t262)
  store i1 %t265, ptr %l160
  br label %bb72
bb71:
  store i1 false, ptr %l157, !tbaa !21
  br label %bb73
bb72:
  %t266 = load i1, ptr %l160, !tbaa !21
  store i1 %t266, ptr %l157, !tbaa !21
  br label %bb73
bb73:
  %t267 = load i1, ptr %l157, !tbaa !21
  br i1 %t267, label %bb74, label %bb75
bb74:
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = getelementptr %"compiler/check:Checker", ptr %t268, i32 0, i32 1
  %t271 = load ptr, ptr %t270, !tbaa !29
  %t273 = getelementptr %"compiler/generic:Program", ptr %t271, i32 0, i32 2
  %t274 = load i32, ptr %l11, !tbaa !23
  %t275 = load i32, ptr %l12, !tbaa !23
  %t279 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t273, i32 %t274, i32 %t275)
  store i1 %t279, ptr %l167
  br label %bb76
bb75:
  store i1 false, ptr %l161, !tbaa !21
  br label %bb77
bb76:
  %t280 = load i1, ptr %l167, !tbaa !21
  %t281 = xor i1 %t280, true
  store i1 %t281, ptr %l161, !tbaa !21
  br label %bb77
bb77:
  %t283 = load i1, ptr %l161, !tbaa !21
  br i1 %t283, label %bb78, label %bb79
bb78:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load ptr, ptr %l2, !tbaa !29
  %t288 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t284, ptr %t285)
  store i1 %t288, ptr %l172
  br label %bb80
bb79:
  store i1 false, ptr %l169, !tbaa !21
  br label %bb81
bb80:
  %t289 = load i1, ptr %l172, !tbaa !21
  %t290 = xor i1 %t289, true
  store i1 %t290, ptr %l169, !tbaa !21
  br label %bb81
bb81:
  %t292 = load i1, ptr %l169, !tbaa !21
  br i1 %t292, label %bb82, label %bb83
bb82:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t294 = load ptr, ptr %l4, !tbaa !29
  %t297 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v3, ptr %t293, ptr %t294)
  store i1 %t297, ptr %l177
  br label %bb84
bb83:
  store i1 false, ptr %l174, !tbaa !21
  br label %bb85
bb84:
  %t298 = load i1, ptr %l177, !tbaa !21
  %t299 = xor i1 %t298, true
  store i1 %t299, ptr %l174, !tbaa !21
  br label %bb85
bb85:
  %t301 = load i1, ptr %l174, !tbaa !21
  br i1 %t301, label %bb86, label %bb87
bb86:
  store %olang.scope zeroinitializer, ptr %s5
  %t302 = load ptr, ptr %l0, !tbaa !29
  store ptr %t302, ptr %l179, !tbaa !29
  %t303 = load ptr, ptr %l0, !tbaa !29
  store ptr %t303, ptr %l180, !tbaa !29
  %t304 = load ptr, ptr %l2, !tbaa !29
  %t306 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t304)
  store %"compiler/source:Span" %t306, ptr %l182
  br label %bb88
bb87:
  br label %bb96
bb88:
  %t307 = load ptr, ptr %l3, !tbaa !29
  %t309 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t307)
  store %"compiler/source:Span" %t309, ptr %l184
  br label %bb89
bb89:
  %t310 = load ptr, ptr %l180, !tbaa !29
  %t311 = load %"compiler/source:Span", ptr %l182
  %t312 = load %"compiler/source:Span", ptr %l184
  %t313 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t310, %"compiler/source:Span" %t311, %"compiler/source:Span" %t312, i64 2)
  store %"compiler/source:Span" %t313, ptr %l185
  br label %bb90
bb90:
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t315 = load i32, ptr %l11, !tbaa !23
  %t318 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t314, i32 %t315)
  store { i64, ptr } %t318, ptr %l188
  br label %bb91
bb91:
  %t319 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t320 = extractvalue { i64, ptr } %t319, 0
  %t321 = extractvalue { i64, ptr } %t319, 1
  %t322 = mul i64 %t320, 1
  %t323 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t322)
  call void @llvm.memcpy.p0.p0.i64(ptr %t323, ptr %t321, i64 %t322, i1 false)
  %t324 = insertvalue { i64, ptr } undef, i64 %t320, 0
  %t325 = insertvalue { i64, ptr } %t324, ptr %t323, 1
  store { i64, ptr } %t325, ptr %l189, !tbaa !27
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t327 = load i32, ptr %l12, !tbaa !23
  %t330 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t326, i32 %t327)
  store { i64, ptr } %t330, ptr %l192
  br label %bb92
bb92:
  %t331 = load { i64, ptr }, ptr %l192, !tbaa !27
  %t332 = extractvalue { i64, ptr } %t331, 0
  %t333 = extractvalue { i64, ptr } %t331, 1
  %t334 = mul i64 %t332, 1
  %t335 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t334)
  call void @llvm.memcpy.p0.p0.i64(ptr %t335, ptr %t333, i64 %t334, i1 false)
  %t336 = insertvalue { i64, ptr } undef, i64 %t332, 0
  %t337 = insertvalue { i64, ptr } %t336, ptr %t335, 1
  %t338 = load { i64, ptr }, ptr %l189, !tbaa !27
  %t340 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondBranchTypes(ptr %s5, ptr %s5, ptr %s5, { i64, ptr } %t338, { i64, ptr } %t337)
  store %"compiler/msgs:Msg" %t340, ptr %l194
  br label %bb93
bb93:
  %t341 = load ptr, ptr %l179, !tbaa !29
  %t342 = load %"compiler/source:Span", ptr %l185
  %t343 = load %"compiler/msgs:Msg", ptr %l194
  %t344 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t341, %"compiler/source:Span" %t342, %"compiler/msgs:Msg" %t343)
  store i64 %t344, ptr %l195
  br label %bb94
bb94:
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t346 = load %"compiler/source:Span", ptr %l1
  %t349 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t345, %"compiler/source:Span" %t346)
  store ptr %t349, ptr %l198
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s5)
  %t350 = load ptr, ptr %l198, !tbaa !29
  store ptr %t350, ptr %rv
  br label %ret
bb96:
  %t351 = load i32, ptr %l11, !tbaa !23
  store i32 %t351, ptr %l13, !tbaa !23
  %t353 = load i32, ptr %l5, !tbaa !23
  %t354 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t357 = icmp ne i32 %t353, %t354
  br i1 %t357, label %bb97, label %bb98
bb97:
  %t359 = load i32, ptr %l5, !tbaa !23
  store i32 %t359, ptr %l13, !tbaa !23
  br label %bb243
bb98:
  %t361 = load i32, ptr %l11, !tbaa !23
  %t362 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t365 = icmp eq i32 %t361, %t362
  br i1 %t365, label %bb99, label %bb100
bb99:
  store i1 true, ptr %l207, !tbaa !21
  br label %bb101
bb100:
  %t367 = load i32, ptr %l11, !tbaa !23
  %t368 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t371 = icmp eq i32 %t367, %t368
  store i1 %t371, ptr %l207, !tbaa !21
  br label %bb101
bb101:
  %t373 = load i1, ptr %l207, !tbaa !21
  br i1 %t373, label %bb102, label %bb103
bb102:
  %t374 = load i32, ptr %l12, !tbaa !23
  store i32 %t374, ptr %l13, !tbaa !23
  br label %bb242
bb103:
  %t376 = load i32, ptr %l12, !tbaa !23
  %t377 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t380 = icmp eq i32 %t376, %t377
  br i1 %t380, label %bb104, label %bb105
bb104:
  %t382 = load i32, ptr %l11, !tbaa !23
  store i32 %t382, ptr %l13, !tbaa !23
  br label %bb241
bb105:
  %t384 = load i32, ptr %l11, !tbaa !23
  %t385 = load i32, ptr %l12, !tbaa !23
  %t388 = icmp ne i32 %t384, %t385
  br i1 %t388, label %bb106, label %bb107
bb106:
  %t390 = load i32, ptr %l12, !tbaa !23
  %t391 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t394 = icmp ne i32 %t390, %t391
  store i1 %t394, ptr %l219, !tbaa !21
  br label %bb108
bb107:
  store i1 false, ptr %l219, !tbaa !21
  br label %bb108
bb108:
  %t396 = load i1, ptr %l219, !tbaa !21
  br i1 %t396, label %bb109, label %bb110
bb109:
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t399 = getelementptr %"compiler/check:Checker", ptr %t397, i32 0, i32 1
  %t400 = load ptr, ptr %t399, !tbaa !29
  %t402 = getelementptr %"compiler/generic:Program", ptr %t400, i32 0, i32 2
  %t403 = load i32, ptr %l11, !tbaa !23
  %t404 = load i32, ptr %l12, !tbaa !23
  %t408 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t402, i32 %t403, i32 %t404)
  store i1 %t408, ptr %l228
  br label %bb111
bb110:
  br label %bb240
bb111:
  %t409 = load i1, ptr %l228, !tbaa !21
  br i1 %t409, label %bb112, label %bb113
bb112:
  %t410 = load i32, ptr %l11, !tbaa !23
  store i32 %t410, ptr %l13, !tbaa !23
  br label %bb239
bb113:
  %t412 = load ptr, ptr %l0, !tbaa !29
  %t413 = load i32, ptr %l11, !tbaa !23
  %t416 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t412, i32 %t413)
  store i1 %t416, ptr %l232
  br label %bb114
bb114:
  %t417 = load i1, ptr %l232, !tbaa !21
  br i1 %t417, label %bb115, label %bb116
bb115:
  %t418 = load ptr, ptr %l0, !tbaa !29
  %t419 = load i32, ptr %l12, !tbaa !23
  %t422 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t418, i32 %t419)
  store i1 %t422, ptr %l236
  br label %bb117
bb116:
  store i1 false, ptr %l233, !tbaa !21
  br label %bb118
bb117:
  %t423 = load i1, ptr %l236, !tbaa !21
  store i1 %t423, ptr %l233, !tbaa !21
  br label %bb118
bb118:
  %t424 = load i1, ptr %l233, !tbaa !21
  br i1 %t424, label %bb119, label %bb120
bb119:
  %t425 = load ptr, ptr %l0, !tbaa !29
  %t427 = getelementptr %"compiler/check:Checker", ptr %t425, i32 0, i32 1
  %t428 = load ptr, ptr %t427, !tbaa !29
  %t429 = load i32, ptr %l11, !tbaa !23
  %t430 = load i32, ptr %l12, !tbaa !23
  %t434 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %t428, i32 %t429, i32 %t430)
  store i32 %t434, ptr %l242
  br label %bb121
bb120:
  store i1 false, ptr %l237, !tbaa !21
  br label %bb122
bb121:
  %t435 = load i32, ptr %l242, !tbaa !23
  %t436 = icmp sge i32 %t435, 0
  store i1 %t436, ptr %l237, !tbaa !21
  br label %bb122
bb122:
  %t438 = load i1, ptr %l237, !tbaa !21
  br i1 %t438, label %bb123, label %bb124
bb123:
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t441 = getelementptr %"compiler/check:Checker", ptr %t439, i32 0, i32 1
  %t442 = load ptr, ptr %t441, !tbaa !29
  %t443 = load i32, ptr %l11, !tbaa !23
  %t444 = load i32, ptr %l12, !tbaa !23
  %t448 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %t442, i32 %t443, i32 %t444)
  store i32 %t448, ptr %l248
  br label %bb125
bb124:
  %t449 = load i32, ptr %l12, !tbaa !23
  %t450 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t453 = icmp eq i32 %t449, %t450
  br i1 %t453, label %bb126, label %bb127
bb125:
  %t455 = load i32, ptr %l248, !tbaa !23
  store i32 %t455, ptr %l13, !tbaa !23
  br label %bb238
bb126:
  %t456 = load ptr, ptr %l0, !tbaa !29
  %t457 = load i32, ptr %l11, !tbaa !23
  %t460 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t456, i32 %t457)
  store i1 %t460, ptr %l255
  br label %bb128
bb127:
  store i1 false, ptr %l252, !tbaa !21
  br label %bb133
bb128:
  %t461 = load i1, ptr %l255, !tbaa !21
  br i1 %t461, label %bb129, label %bb130
bb129:
  store i1 true, ptr %l256, !tbaa !21
  br label %bb132
bb130:
  %t462 = load ptr, ptr %l0, !tbaa !29
  %t464 = getelementptr %"compiler/check:Checker", ptr %t462, i32 0, i32 1
  %t465 = load ptr, ptr %t464, !tbaa !29
  %t467 = getelementptr %"compiler/generic:Program", ptr %t465, i32 0, i32 2
  %t468 = load i32, ptr %l11, !tbaa !23
  %t471 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t467, i32 %t468)
  store i32 %t471, ptr %l261
  br label %bb131
bb131:
  %t472 = load i32, ptr %l261
  %t474 = trunc i64 21 to i32
  %t475 = icmp eq i32 %t472, %t474
  store i1 %t475, ptr %l256, !tbaa !21
  br label %bb132
bb132:
  %t477 = load i1, ptr %l256, !tbaa !21
  store i1 %t477, ptr %l252, !tbaa !21
  br label %bb133
bb133:
  %t478 = load i1, ptr %l252, !tbaa !21
  br i1 %t478, label %bb134, label %bb135
bb134:
  %t479 = load ptr, ptr %l0, !tbaa !29
  %t481 = getelementptr %"compiler/check:Checker", ptr %t479, i32 0, i32 1
  %t482 = load ptr, ptr %t481, !tbaa !29
  %t484 = getelementptr %"compiler/generic:Program", ptr %t482, i32 0, i32 2
  %t485 = load i32, ptr %l11, !tbaa !23
  %t488 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t484, i32 %t485)
  store i32 %t488, ptr %l268
  br label %bb136
bb135:
  %t489 = load i32, ptr %l11, !tbaa !23
  %t490 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t493 = icmp eq i32 %t489, %t490
  br i1 %t493, label %bb137, label %bb138
bb136:
  %t495 = load i32, ptr %l268, !tbaa !23
  store i32 %t495, ptr %l13, !tbaa !23
  br label %bb237
bb137:
  %t496 = load ptr, ptr %l0, !tbaa !29
  %t497 = load i32, ptr %l12, !tbaa !23
  %t500 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t496, i32 %t497)
  store i1 %t500, ptr %l275
  br label %bb139
bb138:
  store i1 false, ptr %l272, !tbaa !21
  br label %bb144
bb139:
  %t501 = load i1, ptr %l275, !tbaa !21
  br i1 %t501, label %bb140, label %bb141
bb140:
  store i1 true, ptr %l276, !tbaa !21
  br label %bb143
bb141:
  %t502 = load ptr, ptr %l0, !tbaa !29
  %t504 = getelementptr %"compiler/check:Checker", ptr %t502, i32 0, i32 1
  %t505 = load ptr, ptr %t504, !tbaa !29
  %t507 = getelementptr %"compiler/generic:Program", ptr %t505, i32 0, i32 2
  %t508 = load i32, ptr %l12, !tbaa !23
  %t511 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t507, i32 %t508)
  store i32 %t511, ptr %l281
  br label %bb142
bb142:
  %t512 = load i32, ptr %l281
  %t514 = trunc i64 21 to i32
  %t515 = icmp eq i32 %t512, %t514
  store i1 %t515, ptr %l276, !tbaa !21
  br label %bb143
bb143:
  %t517 = load i1, ptr %l276, !tbaa !21
  store i1 %t517, ptr %l272, !tbaa !21
  br label %bb144
bb144:
  %t518 = load i1, ptr %l272, !tbaa !21
  br i1 %t518, label %bb145, label %bb146
bb145:
  %t519 = load ptr, ptr %l0, !tbaa !29
  %t521 = getelementptr %"compiler/check:Checker", ptr %t519, i32 0, i32 1
  %t522 = load ptr, ptr %t521, !tbaa !29
  %t524 = getelementptr %"compiler/generic:Program", ptr %t522, i32 0, i32 2
  %t525 = load i32, ptr %l12, !tbaa !23
  %t528 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t524, i32 %t525)
  store i32 %t528, ptr %l288
  br label %bb147
bb146:
  %t529 = load ptr, ptr %l0, !tbaa !29
  %t530 = load i32, ptr %l11, !tbaa !23
  %t533 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t529, i32 %t530)
  store i1 %t533, ptr %l291
  br label %bb148
bb147:
  %t534 = load i32, ptr %l288, !tbaa !23
  store i32 %t534, ptr %l13, !tbaa !23
  br label %bb236
bb148:
  %t535 = load i1, ptr %l291, !tbaa !21
  br i1 %t535, label %bb149, label %bb150
bb149:
  %t536 = load ptr, ptr %l0, !tbaa !29
  %t537 = load i32, ptr %l12, !tbaa !23
  %t540 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t536, i32 %t537)
  store i1 %t540, ptr %l295
  br label %bb151
bb150:
  store i1 false, ptr %l292, !tbaa !21
  br label %bb152
bb151:
  %t541 = load i1, ptr %l295, !tbaa !21
  %t542 = xor i1 %t541, true
  store i1 %t542, ptr %l292, !tbaa !21
  br label %bb152
bb152:
  %t544 = load i1, ptr %l292, !tbaa !21
  br i1 %t544, label %bb153, label %bb154
bb153:
  %t545 = load ptr, ptr %l0, !tbaa !29
  store ptr %t545, ptr %l298, !tbaa !29
  %t546 = load i32, ptr %l12, !tbaa !23
  store i32 %t546, ptr %l299, !tbaa !23
  %t547 = load ptr, ptr %l0, !tbaa !29
  %t549 = getelementptr %"compiler/check:Checker", ptr %t547, i32 0, i32 1
  %t550 = load ptr, ptr %t549, !tbaa !29
  %t552 = getelementptr %"compiler/generic:Program", ptr %t550, i32 0, i32 2
  %t553 = load i32, ptr %l11, !tbaa !23
  %t556 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t552, i32 %t553)
  store i32 %t556, ptr %l304
  br label %bb155
bb154:
  store i1 false, ptr %l297, !tbaa !21
  br label %bb157
bb155:
  %t557 = load ptr, ptr %l298, !tbaa !29
  %t558 = load i32, ptr %l299, !tbaa !23
  %t559 = load i32, ptr %l304, !tbaa !23
  %t560 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t557, i32 %t558, i32 %t559)
  store i1 %t560, ptr %l305
  br label %bb156
bb156:
  %t561 = load i1, ptr %l305, !tbaa !21
  store i1 %t561, ptr %l297, !tbaa !21
  br label %bb157
bb157:
  %t562 = load i1, ptr %l297, !tbaa !21
  br i1 %t562, label %bb158, label %bb159
bb158:
  %t563 = load i32, ptr %l11, !tbaa !23
  store i32 %t563, ptr %l13, !tbaa !23
  br label %bb235
bb159:
  %t565 = load ptr, ptr %l0, !tbaa !29
  %t566 = load i32, ptr %l12, !tbaa !23
  %t569 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t565, i32 %t566)
  store i1 %t569, ptr %l309
  br label %bb160
bb160:
  %t570 = load i1, ptr %l309, !tbaa !21
  br i1 %t570, label %bb161, label %bb162
bb161:
  %t571 = load ptr, ptr %l0, !tbaa !29
  %t572 = load i32, ptr %l11, !tbaa !23
  %t575 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t571, i32 %t572)
  store i1 %t575, ptr %l313
  br label %bb163
bb162:
  store i1 false, ptr %l310, !tbaa !21
  br label %bb164
bb163:
  %t576 = load i1, ptr %l313, !tbaa !21
  %t577 = xor i1 %t576, true
  store i1 %t577, ptr %l310, !tbaa !21
  br label %bb164
bb164:
  %t579 = load i1, ptr %l310, !tbaa !21
  br i1 %t579, label %bb165, label %bb166
bb165:
  %t580 = load ptr, ptr %l0, !tbaa !29
  store ptr %t580, ptr %l316, !tbaa !29
  %t581 = load i32, ptr %l11, !tbaa !23
  store i32 %t581, ptr %l317, !tbaa !23
  %t582 = load ptr, ptr %l0, !tbaa !29
  %t584 = getelementptr %"compiler/check:Checker", ptr %t582, i32 0, i32 1
  %t585 = load ptr, ptr %t584, !tbaa !29
  %t587 = getelementptr %"compiler/generic:Program", ptr %t585, i32 0, i32 2
  %t588 = load i32, ptr %l12, !tbaa !23
  %t591 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t587, i32 %t588)
  store i32 %t591, ptr %l322
  br label %bb167
bb166:
  store i1 false, ptr %l315, !tbaa !21
  br label %bb169
bb167:
  %t592 = load ptr, ptr %l316, !tbaa !29
  %t593 = load i32, ptr %l317, !tbaa !23
  %t594 = load i32, ptr %l322, !tbaa !23
  %t595 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t592, i32 %t593, i32 %t594)
  store i1 %t595, ptr %l323
  br label %bb168
bb168:
  %t596 = load i1, ptr %l323, !tbaa !21
  store i1 %t596, ptr %l315, !tbaa !21
  br label %bb169
bb169:
  %t597 = load i1, ptr %l315, !tbaa !21
  br i1 %t597, label %bb170, label %bb171
bb170:
  %t598 = load i32, ptr %l12, !tbaa !23
  store i32 %t598, ptr %l13, !tbaa !23
  br label %bb234
bb171:
  %t600 = load ptr, ptr %l0, !tbaa !29
  %t601 = load i32, ptr %l11, !tbaa !23
  %t604 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t600, i32 %t601)
  store i1 %t604, ptr %l327
  br label %bb172
bb172:
  %t605 = load i1, ptr %l327, !tbaa !21
  br i1 %t605, label %bb173, label %bb174
bb173:
  %t606 = load ptr, ptr %l0, !tbaa !29
  %t607 = load i32, ptr %l12, !tbaa !23
  %t610 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t606, i32 %t607)
  store i1 %t610, ptr %l331
  br label %bb175
bb174:
  store i1 false, ptr %l328, !tbaa !21
  br label %bb176
bb175:
  %t611 = load i1, ptr %l331, !tbaa !21
  store i1 %t611, ptr %l328, !tbaa !21
  br label %bb176
bb176:
  %t612 = load i1, ptr %l328, !tbaa !21
  br i1 %t612, label %bb177, label %bb178
bb177:
  %t613 = load ptr, ptr %l0, !tbaa !29
  %t615 = getelementptr %"compiler/check:Checker", ptr %t613, i32 0, i32 1
  %t616 = load ptr, ptr %t615, !tbaa !29
  %t618 = getelementptr %"compiler/generic:Program", ptr %t616, i32 0, i32 2
  store ptr %t618, ptr %l335, !tbaa !29
  %t619 = load ptr, ptr %l0, !tbaa !29
  %t620 = load i32, ptr %l11, !tbaa !23
  %t623 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t619, i32 %t620)
  store i32 %t623, ptr %l338
  br label %bb179
bb178:
  store i1 false, ptr %l332, !tbaa !21
  br label %bb182
bb179:
  %t624 = load ptr, ptr %l0, !tbaa !29
  %t625 = load i32, ptr %l12, !tbaa !23
  %t628 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t624, i32 %t625)
  store i32 %t628, ptr %l341
  br label %bb180
bb180:
  %t629 = load ptr, ptr %l335, !tbaa !29
  %t630 = load i32, ptr %l338, !tbaa !23
  %t631 = load i32, ptr %l341, !tbaa !23
  %t632 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t629, i32 %t630, i32 %t631)
  store i1 %t632, ptr %l342
  br label %bb181
bb181:
  %t633 = load i1, ptr %l342, !tbaa !21
  store i1 %t633, ptr %l332, !tbaa !21
  br label %bb182
bb182:
  %t634 = load i1, ptr %l332, !tbaa !21
  br i1 %t634, label %bb183, label %bb184
bb183:
  %t635 = load ptr, ptr %l0, !tbaa !29
  %t637 = getelementptr %"compiler/check:Checker", ptr %t635, i32 0, i32 1
  %t638 = load ptr, ptr %t637, !tbaa !29
  %t640 = getelementptr %"compiler/generic:Program", ptr %t638, i32 0, i32 2
  store ptr %t640, ptr %l345, !tbaa !29
  %t641 = load ptr, ptr %l0, !tbaa !29
  %t642 = load i32, ptr %l11, !tbaa !23
  %t645 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t641, i32 %t642)
  store i32 %t645, ptr %l348
  br label %bb185
bb184:
  %t646 = load ptr, ptr %l0, !tbaa !29
  %t647 = load i32, ptr %l11, !tbaa !23
  %t650 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t646, i32 %t647)
  store i1 %t650, ptr %l363
  br label %bb190
bb185:
  %t651 = load ptr, ptr %l0, !tbaa !29
  %t653 = getelementptr %"compiler/check:Checker", ptr %t651, i32 0, i32 1
  %t654 = load ptr, ptr %t653, !tbaa !29
  %t656 = getelementptr %"compiler/generic:Program", ptr %t654, i32 0, i32 2
  %t657 = load i32, ptr %l11, !tbaa !23
  %t660 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t656, i32 %t657)
  store i64 %t660, ptr %l353
  br label %bb186
bb186:
  %t661 = load ptr, ptr %l0, !tbaa !29
  %t663 = getelementptr %"compiler/check:Checker", ptr %t661, i32 0, i32 1
  %t664 = load ptr, ptr %t663, !tbaa !29
  %t666 = getelementptr %"compiler/generic:Program", ptr %t664, i32 0, i32 2
  %t667 = load i32, ptr %l12, !tbaa !23
  %t670 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t666, i32 %t667)
  store i64 %t670, ptr %l358
  br label %bb187
bb187:
  %t671 = load i64, ptr %l353, !tbaa !24
  %t672 = load i64, ptr %l358, !tbaa !24
  %t673 = call i64 @compiler_2fcheck_2emeetPerm(i64 %t671, i64 %t672)
  store i64 %t673, ptr %l359
  br label %bb188
bb188:
  %t674 = load ptr, ptr %l345, !tbaa !29
  %t675 = load i32, ptr %l348, !tbaa !23
  %t676 = load i64, ptr %l359, !tbaa !24
  %t677 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t674, i32 %t675, i64 %t676)
  store i32 %t677, ptr %l360
  br label %bb189
bb189:
  %t678 = load i32, ptr %l360, !tbaa !23
  store i32 %t678, ptr %l13, !tbaa !23
  br label %bb233
bb190:
  %t679 = load i1, ptr %l363, !tbaa !21
  br i1 %t679, label %bb191, label %bb192
bb191:
  %t680 = load ptr, ptr %l0, !tbaa !29
  %t681 = load i32, ptr %l12, !tbaa !23
  %t684 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t680, i32 %t681)
  store i1 %t684, ptr %l367
  br label %bb193
bb192:
  store i1 false, ptr %l364, !tbaa !21
  br label %bb194
bb193:
  %t685 = load i1, ptr %l367, !tbaa !21
  store i1 %t685, ptr %l364, !tbaa !21
  br label %bb194
bb194:
  %t686 = load i1, ptr %l364, !tbaa !21
  br i1 %t686, label %bb195, label %bb196
bb195:
  %t687 = load ptr, ptr %l0, !tbaa !29
  %t689 = getelementptr %"compiler/check:Checker", ptr %t687, i32 0, i32 1
  %t690 = load ptr, ptr %t689, !tbaa !29
  %t692 = getelementptr %"compiler/generic:Program", ptr %t690, i32 0, i32 2
  store ptr %t692, ptr %l371, !tbaa !29
  %t693 = load ptr, ptr %l0, !tbaa !29
  store ptr %t693, ptr %l372, !tbaa !29
  %t694 = load ptr, ptr %l0, !tbaa !29
  %t695 = load i32, ptr %l11, !tbaa !23
  %t698 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %t694, i32 %t695)
  store i32 %t698, ptr %l375
  br label %bb197
bb196:
  store i1 false, ptr %l368, !tbaa !21
  br label %bb202
bb197:
  %t699 = load ptr, ptr %l372, !tbaa !29
  %t700 = load i32, ptr %l375, !tbaa !23
  %t701 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t699, i32 %t700)
  store i32 %t701, ptr %l376
  br label %bb198
bb198:
  %t702 = load ptr, ptr %l0, !tbaa !29
  store ptr %t702, ptr %l377, !tbaa !29
  %t703 = load ptr, ptr %l0, !tbaa !29
  %t704 = load i32, ptr %l12, !tbaa !23
  %t707 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %t703, i32 %t704)
  store i32 %t707, ptr %l380
  br label %bb199
bb199:
  %t708 = load ptr, ptr %l377, !tbaa !29
  %t709 = load i32, ptr %l380, !tbaa !23
  %t710 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t708, i32 %t709)
  store i32 %t710, ptr %l381
  br label %bb200
bb200:
  %t711 = load ptr, ptr %l371, !tbaa !29
  %t712 = load i32, ptr %l376, !tbaa !23
  %t713 = load i32, ptr %l381, !tbaa !23
  %t714 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t711, i32 %t712, i32 %t713)
  store i1 %t714, ptr %l382
  br label %bb201
bb201:
  %t715 = load i1, ptr %l382, !tbaa !21
  store i1 %t715, ptr %l368, !tbaa !21
  br label %bb202
bb202:
  %t716 = load i1, ptr %l368, !tbaa !21
  br i1 %t716, label %bb203, label %bb204
bb203:
  %t717 = load ptr, ptr %l0, !tbaa !29
  %t719 = getelementptr %"compiler/check:Checker", ptr %t717, i32 0, i32 1
  %t720 = load ptr, ptr %t719, !tbaa !29
  %t722 = getelementptr %"compiler/generic:Program", ptr %t720, i32 0, i32 2
  store ptr %t722, ptr %l385, !tbaa !29
  %t723 = load ptr, ptr %l0, !tbaa !29
  store ptr %t723, ptr %l386, !tbaa !29
  %t724 = load ptr, ptr %l0, !tbaa !29
  %t725 = load i32, ptr %l11, !tbaa !23
  %t728 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %t724, i32 %t725)
  store i32 %t728, ptr %l389
  br label %bb205
bb204:
  %t729 = load ptr, ptr %l0, !tbaa !29
  %t731 = getelementptr %"compiler/check:Checker", ptr %t729, i32 0, i32 1
  %t732 = load ptr, ptr %t731, !tbaa !29
  %t734 = getelementptr %"compiler/generic:Program", ptr %t732, i32 0, i32 2
  %t735 = load i32, ptr %l11, !tbaa !23
  %t738 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t734, i32 %t735)
  store i32 %t738, ptr %l407
  br label %bb211
bb205:
  %t739 = load ptr, ptr %l386, !tbaa !29
  %t740 = load i32, ptr %l389, !tbaa !23
  %t741 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t739, i32 %t740)
  store i32 %t741, ptr %l390
  br label %bb206
bb206:
  %t742 = load ptr, ptr %l0, !tbaa !29
  %t744 = getelementptr %"compiler/check:Checker", ptr %t742, i32 0, i32 1
  %t745 = load ptr, ptr %t744, !tbaa !29
  %t747 = getelementptr %"compiler/generic:Program", ptr %t745, i32 0, i32 2
  %t748 = load i32, ptr %l11, !tbaa !23
  %t751 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t747, i32 %t748)
  store i64 %t751, ptr %l395
  br label %bb207
bb207:
  %t752 = load ptr, ptr %l0, !tbaa !29
  %t754 = getelementptr %"compiler/check:Checker", ptr %t752, i32 0, i32 1
  %t755 = load ptr, ptr %t754, !tbaa !29
  %t757 = getelementptr %"compiler/generic:Program", ptr %t755, i32 0, i32 2
  %t758 = load i32, ptr %l12, !tbaa !23
  %t761 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t757, i32 %t758)
  store i64 %t761, ptr %l400
  br label %bb208
bb208:
  %t762 = load i64, ptr %l395, !tbaa !24
  %t763 = load i64, ptr %l400, !tbaa !24
  %t764 = call i64 @compiler_2fcheck_2emeetPerm(i64 %t762, i64 %t763)
  store i64 %t764, ptr %l401
  br label %bb209
bb209:
  %t765 = load ptr, ptr %l385, !tbaa !29
  %t766 = load i32, ptr %l390, !tbaa !23
  %t767 = load i64, ptr %l401, !tbaa !24
  %t768 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t765, i32 %t766, i64 %t767)
  store i32 %t768, ptr %l402
  br label %bb210
bb210:
  %t769 = load i32, ptr %l402, !tbaa !23
  store i32 %t769, ptr %l13, !tbaa !23
  br label %bb232
bb211:
  %t770 = load i32, ptr %l407
  %t772 = trunc i64 19 to i32
  %t773 = icmp eq i32 %t770, %t772
  br i1 %t773, label %bb212, label %bb213
bb212:
  %t775 = load ptr, ptr %l0, !tbaa !29
  %t777 = getelementptr %"compiler/check:Checker", ptr %t775, i32 0, i32 1
  %t778 = load ptr, ptr %t777, !tbaa !29
  %t780 = getelementptr %"compiler/generic:Program", ptr %t778, i32 0, i32 2
  %t781 = load i32, ptr %l12, !tbaa !23
  %t784 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t780, i32 %t781)
  store i32 %t784, ptr %l415
  br label %bb214
bb213:
  store i1 false, ptr %l410, !tbaa !21
  br label %bb215
bb214:
  %t785 = load i32, ptr %l415
  %t787 = trunc i64 19 to i32
  %t788 = icmp eq i32 %t785, %t787
  store i1 %t788, ptr %l410, !tbaa !21
  br label %bb215
bb215:
  %t790 = load i1, ptr %l410, !tbaa !21
  br i1 %t790, label %bb216, label %bb217
bb216:
  %t791 = load ptr, ptr %l0, !tbaa !29
  %t793 = getelementptr %"compiler/check:Checker", ptr %t791, i32 0, i32 1
  %t794 = load ptr, ptr %t793, !tbaa !29
  %t796 = getelementptr %"compiler/generic:Program", ptr %t794, i32 0, i32 2
  store ptr %t796, ptr %l421, !tbaa !29
  %t797 = load ptr, ptr %l0, !tbaa !29
  %t799 = getelementptr %"compiler/check:Checker", ptr %t797, i32 0, i32 1
  %t800 = load ptr, ptr %t799, !tbaa !29
  %t802 = getelementptr %"compiler/generic:Program", ptr %t800, i32 0, i32 2
  %t803 = load i32, ptr %l11, !tbaa !23
  %t806 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t802, i32 %t803)
  store i32 %t806, ptr %l426
  br label %bb218
bb217:
  store i1 false, ptr %l418, !tbaa !21
  br label %bb221
bb218:
  %t807 = load ptr, ptr %l0, !tbaa !29
  %t809 = getelementptr %"compiler/check:Checker", ptr %t807, i32 0, i32 1
  %t810 = load ptr, ptr %t809, !tbaa !29
  %t812 = getelementptr %"compiler/generic:Program", ptr %t810, i32 0, i32 2
  %t813 = load i32, ptr %l12, !tbaa !23
  %t816 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t812, i32 %t813)
  store i32 %t816, ptr %l431
  br label %bb219
bb219:
  %t817 = load ptr, ptr %l421, !tbaa !29
  %t818 = load i32, ptr %l426, !tbaa !23
  %t819 = load i32, ptr %l431, !tbaa !23
  %t820 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t817, i32 %t818, i32 %t819)
  store i1 %t820, ptr %l432
  br label %bb220
bb220:
  %t821 = load i1, ptr %l432, !tbaa !21
  store i1 %t821, ptr %l418, !tbaa !21
  br label %bb221
bb221:
  %t822 = load i1, ptr %l418, !tbaa !21
  br i1 %t822, label %bb222, label %bb223
bb222:
  %t823 = load ptr, ptr %l0, !tbaa !29
  %t825 = getelementptr %"compiler/check:Checker", ptr %t823, i32 0, i32 1
  %t826 = load ptr, ptr %t825, !tbaa !29
  %t828 = getelementptr %"compiler/generic:Program", ptr %t826, i32 0, i32 2
  store ptr %t828, ptr %l435, !tbaa !29
  %t829 = load ptr, ptr %l0, !tbaa !29
  %t831 = getelementptr %"compiler/check:Checker", ptr %t829, i32 0, i32 1
  %t832 = load ptr, ptr %t831, !tbaa !29
  %t834 = getelementptr %"compiler/generic:Program", ptr %t832, i32 0, i32 2
  %t835 = load i32, ptr %l11, !tbaa !23
  %t838 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t834, i32 %t835)
  store i32 %t838, ptr %l440
  br label %bb224
bb223:
  store %olang.scope zeroinitializer, ptr %s30
  %t839 = load ptr, ptr %l0, !tbaa !29
  store ptr %t839, ptr %l442, !tbaa !29
  %t840 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t840, ptr %l443
  %t841 = load ptr, ptr %l0, !tbaa !29
  %t842 = load i32, ptr %l11, !tbaa !23
  %t845 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s30, ptr %t841, i32 %t842)
  store { i64, ptr } %t845, ptr %l446
  br label %bb226
bb224:
  %t846 = load ptr, ptr %l435, !tbaa !29
  %t847 = load i32, ptr %l440, !tbaa !23
  %t848 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t846, i32 %t847, i32 0)
  store i32 %t848, ptr %l441
  br label %bb225
bb225:
  %t849 = load i32, ptr %l441, !tbaa !23
  store i32 %t849, ptr %l13, !tbaa !23
  br label %bb231
bb226:
  %t850 = load { i64, ptr }, ptr %l446, !tbaa !27
  %t851 = extractvalue { i64, ptr } %t850, 0
  %t852 = extractvalue { i64, ptr } %t850, 1
  %t853 = mul i64 %t851, 1
  %t854 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t853)
  call void @llvm.memcpy.p0.p0.i64(ptr %t854, ptr %t852, i64 %t853, i1 false)
  %t855 = insertvalue { i64, ptr } undef, i64 %t851, 0
  %t856 = insertvalue { i64, ptr } %t855, ptr %t854, 1
  store { i64, ptr } %t856, ptr %l447, !tbaa !27
  %t857 = load ptr, ptr %l0, !tbaa !29
  %t858 = load i32, ptr %l12, !tbaa !23
  %t861 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s30, ptr %t857, i32 %t858)
  store { i64, ptr } %t861, ptr %l450
  br label %bb227
bb227:
  %t862 = load { i64, ptr }, ptr %l450, !tbaa !27
  %t863 = extractvalue { i64, ptr } %t862, 0
  %t864 = extractvalue { i64, ptr } %t862, 1
  %t865 = mul i64 %t863, 1
  %t866 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t865)
  call void @llvm.memcpy.p0.p0.i64(ptr %t866, ptr %t864, i64 %t865, i1 false)
  %t867 = insertvalue { i64, ptr } undef, i64 %t863, 0
  %t868 = insertvalue { i64, ptr } %t867, ptr %t866, 1
  %t869 = load { i64, ptr }, ptr %l447, !tbaa !27
  %t871 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondBranchTypes(ptr %s30, ptr %s30, ptr %s30, { i64, ptr } %t869, { i64, ptr } %t868)
  store %"compiler/msgs:Msg" %t871, ptr %l452
  br label %bb228
bb228:
  %t872 = load ptr, ptr %l442, !tbaa !29
  %t873 = load %"compiler/source:Span", ptr %l443
  %t874 = load %"compiler/msgs:Msg", ptr %l452
  %t875 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s30, ptr %t872, %"compiler/source:Span" %t873, %"compiler/msgs:Msg" %t874)
  store i64 %t875, ptr %l453
  br label %bb229
bb229:
  %t876 = load ptr, ptr %l0, !tbaa !29
  %t877 = load %"compiler/source:Span", ptr %l1
  %t880 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t876, %"compiler/source:Span" %t877)
  store ptr %t880, ptr %l456
  br label %bb230
bb230:
  call void @__olang_scope_close(ptr %s30)
  %t881 = load ptr, ptr %l456, !tbaa !29
  store ptr %t881, ptr %rv
  br label %ret
bb231:
  br label %bb232
bb232:
  br label %bb233
bb233:
  br label %bb234
bb234:
  br label %bb235
bb235:
  br label %bb236
bb236:
  br label %bb237
bb237:
  br label %bb238
bb238:
  br label %bb239
bb239:
  br label %bb240
bb240:
  br label %bb241
bb241:
  br label %bb242
bb242:
  br label %bb243
bb243:
  %t882 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t882, ptr %l457
  %t883 = load i32, ptr %l13, !tbaa !23
  store i32 %t883, ptr %l458, !tbaa !23
  %t884 = load ptr, ptr %l7, !tbaa !29
  store ptr %t884, ptr %l459, !tbaa !29
  %t885 = load ptr, ptr %l0, !tbaa !29
  store ptr %t885, ptr %l460, !tbaa !29
  %t886 = load ptr, ptr %l8, !tbaa !29
  %t888 = icmp eq ptr %t886, null
  br i1 %t888, label %bb244, label %bb245
bb244:
  call void @__olang_check_failed(ptr @olang_loc_db85c439bc9f5684_3c0400873f27ba78)
  unreachable
bb245:
  br label %bb246
bb246:
  %t890 = load ptr, ptr %l8, !tbaa !29
  store ptr %t890, ptr %l463, !tbaa !29
  %t891 = load i32, ptr %l13, !tbaa !23
  store i32 %t891, ptr %l464, !tbaa !23
  %t892 = load ptr, ptr %l2, !tbaa !29
  %t894 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t892)
  store %"compiler/source:Span" %t894, ptr %l466
  br label %bb247
bb247:
  %t895 = load ptr, ptr %l460, !tbaa !29
  %t896 = load ptr, ptr %l463, !tbaa !29
  %t897 = load i32, ptr %l464, !tbaa !23
  %t898 = load %"compiler/source:Span", ptr %l466
  %t899 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t895, ptr %t896, i32 %t897, %"compiler/source:Span" %t898)
  store ptr %t899, ptr %l467
  br label %bb248
bb248:
  %t900 = load ptr, ptr %l467, !tbaa !29
  store ptr %t900, ptr %l468, !tbaa !29
  %t901 = load ptr, ptr %l0, !tbaa !29
  store ptr %t901, ptr %l469, !tbaa !29
  %t902 = load ptr, ptr %l9, !tbaa !29
  %t904 = icmp eq ptr %t902, null
  br i1 %t904, label %bb249, label %bb250
bb249:
  call void @__olang_check_failed(ptr @olang_loc_db85c439bc9f5684_3c0400873f27ba78)
  unreachable
bb250:
  br label %bb251
bb251:
  %t906 = load ptr, ptr %l9, !tbaa !29
  store ptr %t906, ptr %l472, !tbaa !29
  %t907 = load i32, ptr %l13, !tbaa !23
  store i32 %t907, ptr %l473, !tbaa !23
  %t908 = load ptr, ptr %l4, !tbaa !29
  %t910 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v3, ptr %t908)
  store %"compiler/source:Span" %t910, ptr %l475
  br label %bb252
bb252:
  %t911 = load ptr, ptr %l469, !tbaa !29
  %t912 = load ptr, ptr %l472, !tbaa !29
  %t913 = load i32, ptr %l473, !tbaa !23
  %t914 = load %"compiler/source:Span", ptr %l475
  %t915 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t911, ptr %t912, i32 %t913, %"compiler/source:Span" %t914)
  store ptr %t915, ptr %l476
  br label %bb253
bb253:
  %t916 = load ptr, ptr %l459, !tbaa !29
  %t917 = load ptr, ptr %l468, !tbaa !29
  %t918 = load ptr, ptr %l476, !tbaa !29
  %t919 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t916, ptr %t917, ptr %t918)
  store %"compiler/typed:Cond" %t919, ptr %l477
  br label %bb254
bb254:
  %t920 = load %"compiler/typed:Cond", ptr %l477
  %t921 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Cond" %t920, ptr %t921
  store { i64, [5 x i64] } zeroinitializer, ptr %t922
  %t923 = getelementptr { i64, [5 x i64] }, ptr %t922, i32 0, i32 0
  store i64 11, ptr %t923
  %t924 = load %"compiler/source:Span", ptr %l457
  %t925 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t924, 0
  %t926 = load i32, ptr %l458, !tbaa !23
  %t927 = insertvalue { %"compiler/source:Span", i32, ptr } %t925, i32 %t926, 1
  %t929 = insertvalue { %"compiler/source:Span", i32, ptr } %t927, ptr %t921, 2
  %t930 = getelementptr { i64, [5 x i64] }, ptr %t922, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t929, ptr %t930
  %t931 = load { i64, [5 x i64] }, ptr %t922
  %t933 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t931, ptr %t933
  store ptr %t933, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l9 = alloca ptr
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t10 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a3, i32 20, ptr %a2, ptr null)
  store ptr %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l9, !tbaa !29
  store ptr %t11, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecountPost(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, i64, i64 }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l13 = alloca i64
  %l17 = alloca { i64, i64, i64 }
  %l21 = alloca ptr
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca %"compiler/source:Span"
  %l25 = alloca i32
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca %"compiler/source:Span"
  %l34 = alloca i32
  %l35 = alloca i32
  %l39 = alloca ptr
  %l40 = alloca ptr
  %l41 = alloca %"compiler/source:Span"
  %l43 = alloca i32
  %l44 = alloca ptr
  %l46 = alloca ptr
  %l54 = alloca ptr
  %rv = alloca ptr
  %t38 = alloca { i64, [4 x i64] }, align 8
  %t79 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store ptr null, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 33
  %t10 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l13
  br label %bb4
bb4:
  %t11 = load i64, ptr %l13, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load %"compiler/source:Span", ptr %l1
  %t17 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t12, i32 3, %"compiler/source:Span" %t13)
  store { i64, i64, i64 } %t17, ptr %l17
  br label %bb5
bb5:
  %t18 = load { i64, i64, i64 }, ptr %l17
  store { i64, i64, i64 } %t18, ptr %l4
  %t19 = getelementptr { i64, i64, i64 }, ptr %l4, i32 0, i32 0
  %t20 = load i64, ptr %t19, !tbaa !24
  store i64 %t20, ptr %l5, !tbaa !24
  %t22 = getelementptr { i64, i64, i64 }, ptr %l4, i32 0, i32 1
  %t23 = load i64, ptr %t22, !tbaa !24
  store i64 %t23, ptr %l6, !tbaa !24
  %t25 = getelementptr { i64, i64, i64 }, ptr %l4, i32 0, i32 2
  %t26 = load i64, ptr %t25, !tbaa !24
  store i64 %t26, ptr %l7, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l21, !tbaa !29
  %t29 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t29, ptr %l22
  %t30 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t30, ptr %l23
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t31)
  store i32 %t33, ptr %l25
  br label %bb6
bb6:
  %t34 = load i64, ptr %l2, !tbaa !24
  %t36 = trunc i64 %t34 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t38
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 0
  store i64 0, ptr %t39
  %t40 = load %"compiler/source:Span", ptr %l23
  %t41 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t40, 0
  %t42 = load i32, ptr %l25, !tbaa !23
  %t43 = insertvalue { %"compiler/source:Span", i32, i32 } %t41, i32 %t42, 1
  %t45 = insertvalue { %"compiler/source:Span", i32, i32 } %t43, i32 %t36, 2
  %t46 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t45, ptr %t46
  %t47 = load { i64, [4 x i64] }, ptr %t38
  %t49 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t47, ptr %t49
  store ptr %t49, ptr %l30, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l31, !tbaa !29
  %t51 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t51, ptr %l32
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t52)
  store i32 %t54, ptr %l34
  br label %bb7
bb7:
  store i32 3, ptr %l35
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load %"compiler/source:Span", ptr %l1
  %t57 = load i64, ptr %l2, !tbaa !24
  %t61 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t55, %"compiler/source:Span" %t56, i64 %t57)
  store ptr %t61, ptr %l39
  br label %bb8
bb8:
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l40, !tbaa !29
  %t63 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t63, ptr %l41
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t64)
  store i32 %t66, ptr %l43
  br label %bb9
bb9:
  %t67 = load ptr, ptr %l40, !tbaa !29
  %t68 = load %"compiler/source:Span", ptr %l41
  %t69 = load i32, ptr %l43, !tbaa !23
  %t70 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t67, %"compiler/source:Span" %t68, i32 %t69, i64 1)
  store ptr %t70, ptr %l44
  br label %bb10
bb10:
  %t71 = load ptr, ptr %l44, !tbaa !29
  %t72 = load ptr, ptr %l31, !tbaa !29
  %t73 = load %"compiler/source:Span", ptr %l32
  %t74 = load i32, ptr %l34, !tbaa !23
  %t75 = load i32, ptr %l35
  %t76 = load ptr, ptr %l39, !tbaa !29
  %t78 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t72, %"compiler/source:Span" %t73, i32 %t74, i32 %t75, ptr %t76, ptr %t71)
  store ptr %t78, ptr %l46
  br label %bb11
bb11:
  store { i64, [3 x i64] } zeroinitializer, ptr %t79
  %t80 = getelementptr { i64, [3 x i64] }, ptr %t79, i32 0, i32 0
  store i64 1, ptr %t80
  %t81 = load %"compiler/source:Span", ptr %l22
  %t82 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t81, 0
  %t83 = load ptr, ptr %l30, !tbaa !29
  %t84 = insertvalue { %"compiler/source:Span", ptr, ptr } %t82, ptr %t83, 1
  %t85 = load ptr, ptr %l46, !tbaa !29
  %t86 = insertvalue { %"compiler/source:Span", ptr, ptr } %t84, ptr %t85, 2
  %t87 = getelementptr { i64, [3 x i64] }, ptr %t79, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t86, ptr %t87
  %t88 = load { i64, [3 x i64] }, ptr %t79
  %t90 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t88, ptr %t90
  %t91 = load ptr, ptr %l21, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t91, ptr %t90)
  br label %bb12
bb12:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i64, ptr %l5, !tbaa !24
  %t95 = load i64, ptr %l6, !tbaa !24
  %t96 = load i64, ptr %l7, !tbaa !24
  %t97 = load i64, ptr %l3, !tbaa !24
  %t103 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t93, i64 %t94, i64 %t95, i64 %t96, i64 %t97)
  store ptr %t103, ptr %l54
  br label %bb13
bb13:
  %t104 = load ptr, ptr %l54, !tbaa !29
  store ptr %t104, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectBody(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca ptr
  %l27 = alloca ptr
  %l33 = alloca ptr
  %l38 = alloca i32
  %l39 = alloca { i64, ptr }
  %l40 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l41 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l47 = alloca i64
  %l50 = alloca i64
  %l68 = alloca { i64, ptr }
  %l73 = alloca i1
  %l76 = alloca ptr
  %l81 = alloca i32
  %l86 = alloca i64
  %l90 = alloca i32
  %l93 = alloca ptr
  %l99 = alloca i64
  %l104 = alloca ptr
  %l107 = alloca ptr
  %l109 = alloca { i64, ptr }
  %l110 = alloca i32
  %l111 = alloca i32
  %l116 = alloca i32
  %l119 = alloca ptr
  %l120 = alloca i64
  %l122 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l125 = alloca i32
  %l126 = alloca i32
  %l138 = alloca i64
  %l145 = alloca ptr
  %l146 = alloca i64
  %l148 = alloca i64
  %l149 = alloca i32
  %l154 = alloca i32
  %l155 = alloca ptr
  %l156 = alloca ptr
  %l159 = alloca %"compiler/generic:Context"
  %l163 = alloca ptr
  %l166 = alloca i32
  %l175 = alloca ptr
  %l182 = alloca i32
  %l189 = alloca %"compiler/source:Span"
  %l191 = alloca i32
  %l207 = alloca { i64, ptr }
  %l214 = alloca ptr
  %l216 = alloca i32
  %l218 = alloca %"compiler/source:Span"
  %l221 = alloca i32
  %l230 = alloca ptr
  %l234 = alloca { i64, ptr }
  %l236 = alloca ptr
  %l239 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca i64
  %t223 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectSourceOf(ptr %v0, ptr %t1, i64 %t2)
  store ptr %t5, ptr %l27
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l27, !tbaa !29
  store ptr %t6, ptr %l5, !tbaa !29
  %t7 = load ptr, ptr %l5, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb2, label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_4d78ccd557b2cb07_4b61304073c9a48b)
  unreachable
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l5, !tbaa !29
  store ptr %t11, ptr %l6, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  store ptr %t18, ptr %l33, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 2
  %t25 = load i32, ptr %l3, !tbaa !23
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t28, ptr %l38
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l33, !tbaa !29
  %t30 = load i32, ptr %l38, !tbaa !23
  %t31 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t29, i32 %t30)
  store { i64, ptr } %t31, ptr %l39
  br label %bb6
bb6:
  %t32 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t32, ptr %l7, !tbaa !27
  %t33 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t33, ptr %l40
  br label %bb7
bb7:
  %t34 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l40
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t34, ptr %l8
  %t35 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t35, ptr %l41
  br label %bb8
bb8:
  %t36 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l41
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t36, ptr %l9
  store i64 0, ptr %l10, !tbaa !24
  %t37 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  store i64 %t39, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t41 = load i64, ptr %l11, !tbaa !24
  %t42 = load i64, ptr %l10, !tbaa !24
  %t45 = icmp sgt i64 %t41, %t42
  br i1 %t45, label %bb9, label %bb10
bb9:
  %t47 = load i64, ptr %l12, !tbaa !24
  %t49 = icmp sgt i64 %t47, 0
  br i1 %t49, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb14
bb11:
  %t51 = load i64, ptr %l11, !tbaa !24
  %t52 = load i64, ptr %l10, !tbaa !24
  %t55 = sub i64 %t51, %t52
  %t56 = load i64, ptr %l12, !tbaa !24
  %t59 = add i64 %t55, %t56
  %t61 = sub i64 %t59, 1
  %t62 = load i64, ptr %l12, !tbaa !24
  %t65 = sdiv i64 %t61, %t62
  store i64 %t65, ptr %l50, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l50, !tbaa !24
  br label %bb13
bb13:
  %t67 = load i64, ptr %l50, !tbaa !24
  store i64 %t67, ptr %l47, !tbaa !24
  br label %bb14
bb14:
  %t68 = load i64, ptr %l47, !tbaa !24
  store i64 %t68, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t69 = load i64, ptr %l14, !tbaa !24
  %t70 = load i64, ptr %l13, !tbaa !24
  %t73 = icmp slt i64 %t69, %t70
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb17:
  br label %bb18
bb18:
  %t77 = load i64, ptr %l10, !tbaa !24
  %t78 = load i64, ptr %l14, !tbaa !24
  %t79 = load i64, ptr %l12, !tbaa !24
  %t82 = mul i64 %t78, %t79
  %t85 = add i64 %t77, %t82
  store i64 %t85, ptr %l15, !tbaa !24
  %t87 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t87, ptr %l68, !tbaa !27
  %t88 = load i64, ptr %l15, !tbaa !24
  %t90 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr i32, ptr %t91, i64 %t88
  %t93 = load i32, ptr %t92, !tbaa !33
  store i32 %t93, ptr %l16, !tbaa !23
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load i32, ptr %l16, !tbaa !23
  %t99 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t95, i32 %t96)
  store i1 %t99, ptr %l73
  br label %bb19
bb19:
  %t100 = load i1, ptr %l73, !tbaa !21
  br i1 %t100, label %bb20, label %bb21
bb20:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/check:Checker", ptr %t101, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = getelementptr %"compiler/generic:Program", ptr %t104, i32 0, i32 2
  store ptr %t106, ptr %l76, !tbaa !29
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/check:Checker", ptr %t107, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/generic:Program", ptr %t110, i32 0, i32 2
  %t113 = load i32, ptr %l16, !tbaa !23
  %t116 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t112, i32 %t113)
  store i32 %t116, ptr %l81
  br label %bb22
bb21:
  br label %bb25
bb22:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = getelementptr %"compiler/generic:Program", ptr %t120, i32 0, i32 2
  %t123 = load i32, ptr %l16, !tbaa !23
  %t126 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t122, i32 %t123)
  store i64 %t126, ptr %l86
  br label %bb23
bb23:
  %t127 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t129 = xor i64 %t127, -1
  %t130 = load i64, ptr %l86, !tbaa !24
  %t132 = and i64 %t130, %t129
  %t133 = load ptr, ptr %l76, !tbaa !29
  %t134 = load i32, ptr %l81, !tbaa !23
  %t136 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t133, i32 %t134, i64 %t132)
  store i32 %t136, ptr %l90
  br label %bb24
bb24:
  %t137 = load i32, ptr %l90, !tbaa !23
  store i32 %t137, ptr %l16, !tbaa !23
  br label %bb25
bb25:
  %t138 = load i32, ptr %l16, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l8, i32 %t138)
  br label %bb26
bb26:
  store ptr %l9, ptr %l93, !tbaa !29
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/check:Checker", ptr %t141, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t146 = getelementptr %"compiler/generic:Program", ptr %t144, i32 0, i32 2
  %t147 = load i32, ptr %l3, !tbaa !23
  %t148 = load i64, ptr %l15, !tbaa !24
  %t152 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t146, i32 %t147, i64 %t148)
  store i64 %t152, ptr %l99
  br label %bb27
bb27:
  %t153 = load ptr, ptr %l93, !tbaa !29
  %t154 = load i64, ptr %l99, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t153, i64 %t154)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb29:
  %t155 = load i64, ptr %l14, !tbaa !24
  %t157 = add i64 %t155, 1
  store i64 %t157, ptr %l14, !tbaa !24
  br label %bb15
bb30:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/check:Checker", ptr %t159, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !29
  %t164 = getelementptr %"compiler/generic:Program", ptr %t162, i32 0, i32 2
  store ptr %t164, ptr %l104, !tbaa !29
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/check:Checker", ptr %t165, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t170 = getelementptr %"compiler/generic:Program", ptr %t168, i32 0, i32 2
  store ptr %t170, ptr %l107, !tbaa !29
  %t172 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eToAr_H9d0f958437b2bc29fe1d416dfb9901d7(ptr %s0, ptr %s0, ptr %l8)
  store { i64, ptr } %t172, ptr %l109
  br label %bb31
bb31:
  %t173 = load ptr, ptr %l107, !tbaa !29
  %t174 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t175 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t173, { i64, ptr } %t174)
  store i32 %t175, ptr %l110
  br label %bb32
bb32:
  %t176 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t176, ptr %l111, !tbaa !23
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/check:Checker", ptr %t177, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !29
  %t182 = getelementptr %"compiler/generic:Program", ptr %t180, i32 0, i32 2
  %t183 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  %t186 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %t182, i32 %t183)
  store i32 %t186, ptr %l116
  br label %bb33
bb33:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/check:Checker", ptr %t187, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !29
  %t192 = getelementptr %"compiler/generic:Program", ptr %t190, i32 0, i32 2
  store ptr %t192, ptr %l119, !tbaa !29
  %t193 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleFn, !tbaa !24
  store i64 %t193, ptr %l120, !tbaa !24
  %t195 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %l9)
  store { i64, ptr } %t195, ptr %l122
  br label %bb34
bb34:
  %t196 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t197 = mul i64 1, 8
  %t198 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t197)
  %t199 = insertvalue { i64, ptr } undef, i64 1, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr %t198, 1
  store { i64, ptr } %t200, ptr %l124, !tbaa !27
  %t202 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !27
  %t204 = getelementptr i64, ptr %t203, i64 0
  store i64 %t196, ptr %t204, !tbaa !34
  %t205 = load ptr, ptr %l119, !tbaa !29
  %t206 = load i64, ptr %l120, !tbaa !24
  %t207 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t208 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t209 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopes(ptr %v0, ptr %s0, ptr %s0, ptr %t205, i64 %t206, { i64, ptr } %t207, { i64, ptr } %t208)
  store i32 %t209, ptr %l125
  br label %bb35
bb35:
  %t210 = load ptr, ptr %l104, !tbaa !29
  %t211 = load i32, ptr %l110, !tbaa !23
  %t212 = load i32, ptr %l111, !tbaa !23
  %t213 = load i32, ptr %l116, !tbaa !23
  %t214 = load i32, ptr %l125, !tbaa !23
  %t215 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t210, i32 %t211, i32 %t212, i32 %t213, i32 %t214, i64 0)
  store i32 %t215, ptr %l126
  br label %bb36
bb36:
  %t216 = load i32, ptr %l126, !tbaa !23
  store i32 %t216, ptr %l17, !tbaa !23
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load i64, ptr %l1, !tbaa !24
  %t220 = trunc i64 %t218 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t223
  %t224 = getelementptr { i64, [2 x i64] }, ptr %t223, i32 0, i32 0
  store i64 8, ptr %t224
  %t226 = insertvalue { i32, i32, i64 } undef, i32 %t220, 0
  %t228 = insertvalue { i32, i32, i64 } %t226, i32 0, 1
  %t230 = insertvalue { i32, i32, i64 } %t228, i64 %a2, 2
  %t231 = getelementptr { i64, [2 x i64] }, ptr %t223, i32 0, i32 1
  store { i32, i32, i64 } %t230, ptr %t231
  %t232 = load { i64, [2 x i64] }, ptr %t223
  %t233 = load i32, ptr %l17, !tbaa !23
  %t234 = load ptr, ptr %l6, !tbaa !29
  %t236 = getelementptr %"compiler/check:ctSource", ptr %t234, i32 0, i32 3
  %t237 = load i64, ptr %t236, !tbaa !24
  %t238 = load %"compiler/source:Span", ptr %l4
  %t244 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t217, { i64, [2 x i64] } %t232, i32 %t233, i64 %t237, %"compiler/source:Span" %t238)
  store i64 %t244, ptr %l138
  br label %bb37
bb37:
  %t245 = load i64, ptr %l138, !tbaa !24
  store i64 %t245, ptr %l18, !tbaa !24
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t248 = getelementptr %"compiler/check:Checker", ptr %t246, i32 0, i32 16
  %t249 = load i64, ptr %l18, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t248, i64 %t249, i64 1)
  br label %bb38
bb38:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr %"compiler/check:Checker", ptr %t252, i32 0, i32 49
  %t255 = load i64, ptr %l18, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t254, i64 %t255, i1 true)
  br label %bb39
bb39:
  %t258 = load ptr, ptr %l0, !tbaa !29
  store ptr %t258, ptr %l145, !tbaa !29
  %t259 = load i64, ptr %l18, !tbaa !24
  store i64 %t259, ptr %l146, !tbaa !24
  %t260 = load ptr, ptr %l6, !tbaa !29
  %t262 = getelementptr %"compiler/check:ctSource", ptr %t260, i32 0, i32 3
  %t263 = load i64, ptr %t262, !tbaa !24
  store i64 %t263, ptr %l148, !tbaa !24
  %t264 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t264, ptr %l149, !tbaa !23
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t267 = getelementptr %"compiler/check:Checker", ptr %t265, i32 0, i32 1
  %t268 = load ptr, ptr %t267, !tbaa !29
  %t270 = getelementptr %"compiler/generic:Program", ptr %t268, i32 0, i32 2
  %t271 = load i32, ptr %l17, !tbaa !23
  %t274 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t270, i32 %t271)
  store i32 %t274, ptr %l154
  br label %bb40
bb40:
  %t275 = load ptr, ptr %l145, !tbaa !29
  %t276 = load i64, ptr %l146, !tbaa !24
  %t277 = load i64, ptr %l148, !tbaa !24
  %t278 = load i32, ptr %l149, !tbaa !23
  %t279 = load i32, ptr %l154, !tbaa !23
  %t280 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t275, i64 %t276, i64 %t277, i32 %t278, i32 %t279)
  store ptr %t280, ptr %l155
  br label %bb41
bb41:
  %t281 = load ptr, ptr %l155, !tbaa !29
  store ptr %t281, ptr %l19, !tbaa !29
  %t282 = load ptr, ptr %l19, !tbaa !29
  store ptr %t282, ptr %l156, !tbaa !29
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t284 = load i64, ptr %l1, !tbaa !24
  %t287 = call %"compiler/generic:Context" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectContext(ptr %v0, ptr %v0, ptr %t283, i64 %t284)
  store %"compiler/generic:Context" %t287, ptr %l159
  br label %bb42
bb42:
  %t288 = load %"compiler/generic:Context", ptr %l159
  %t289 = load ptr, ptr %l156, !tbaa !29
  %t290 = getelementptr %"compiler/check:frame", ptr %t289, i32 0, i32 4
  store %"compiler/generic:Context" %t288, ptr %t290
  %t291 = load ptr, ptr %l19, !tbaa !29
  %t292 = load i64, ptr @G_2ecompiler_2fcheck_2eCtReq, !tbaa !24
  %t295 = getelementptr %"compiler/check:frame", ptr %t291, i32 0, i32 49
  store i64 %t292, ptr %t295, !tbaa !24
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t298 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t296)
  store ptr %t298, ptr %l163
  br label %bb43
bb43:
  %t299 = load %"compiler/source:Span", ptr %l4
  %t300 = load ptr, ptr %l163, !tbaa !29
  %t303 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t300, i32 -1, i32 0, %"compiler/source:Span" %t299)
  store i32 %t303, ptr %l166
  br label %bb44
bb44:
  store i64 0, ptr %l20, !tbaa !24
  %t304 = load ptr, ptr %l6, !tbaa !29
  %t306 = getelementptr %"compiler/check:ctSource", ptr %t304, i32 0, i32 1
  %t307 = load ptr, ptr %t306, !tbaa !29
  %t309 = icmp eq ptr %t307, null
  %t311 = xor i1 %t309, true
  br i1 %t311, label %bb45, label %bb46
bb45:
  %t313 = load i64, ptr %l20, !tbaa !24
  %t314 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t316 = extractvalue { i64, ptr } %t314, 0
  %t319 = icmp slt i64 %t313, %t316
  br i1 %t319, label %bb47, label %bb48
bb46:
  br label %bb61
bb47:
  %t321 = load ptr, ptr %l0, !tbaa !29
  store ptr %t321, ptr %l175, !tbaa !29
  %t322 = load ptr, ptr %l6, !tbaa !29
  %t324 = getelementptr %"compiler/check:ctSource", ptr %t322, i32 0, i32 1
  %t325 = load ptr, ptr %t324, !tbaa !29
  %t327 = icmp eq ptr %t325, null
  br i1 %t327, label %bb49, label %bb50
bb48:
  br label %bb60
bb49:
  call void @__olang_check_failed(ptr @olang_loc_82a7c94587506de8_24388316e0066d9c)
  unreachable
bb50:
  br label %bb51
bb51:
  %t329 = load ptr, ptr %l6, !tbaa !29
  %t331 = getelementptr %"compiler/check:ctSource", ptr %t329, i32 0, i32 1
  %t332 = load ptr, ptr %t331, !tbaa !29
  %t335 = getelementptr %"compiler/ast:Param", ptr %t332, i32 0, i32 1
  %t336 = load i32, ptr %t335, !tbaa !23
  store i32 %t336, ptr %l182, !tbaa !23
  %t337 = load ptr, ptr %l6, !tbaa !29
  %t339 = getelementptr %"compiler/check:ctSource", ptr %t337, i32 0, i32 1
  %t340 = load ptr, ptr %t339, !tbaa !29
  %t342 = icmp eq ptr %t340, null
  br i1 %t342, label %bb52, label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_82a7c94587506de8_24388316e0066d9c)
  unreachable
bb53:
  br label %bb54
bb54:
  %t344 = load ptr, ptr %l6, !tbaa !29
  %t346 = getelementptr %"compiler/check:ctSource", ptr %t344, i32 0, i32 1
  %t347 = load ptr, ptr %t346, !tbaa !29
  %t350 = getelementptr %"compiler/ast:Param", ptr %t347, i32 0, i32 0
  %t351 = load %"compiler/source:Span", ptr %t350
  store %"compiler/source:Span" %t351, ptr %l189
  %t353 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l8, i64 0)
  store i32 %t353, ptr %l191
  br label %bb55
bb55:
  %t354 = load ptr, ptr %l6, !tbaa !29
  %t356 = getelementptr %"compiler/check:ctSource", ptr %t354, i32 0, i32 1
  %t357 = load ptr, ptr %t356, !tbaa !29
  %t359 = icmp eq ptr %t357, null
  br i1 %t359, label %bb56, label %bb57
bb56:
  call void @__olang_check_failed(ptr @olang_loc_82a7c94587506de8_24388316e0066d9c)
  unreachable
bb57:
  br label %bb58
bb58:
  %t361 = load ptr, ptr %l6, !tbaa !29
  %t363 = getelementptr %"compiler/check:ctSource", ptr %t361, i32 0, i32 1
  %t364 = load ptr, ptr %t363, !tbaa !29
  %t367 = getelementptr %"compiler/ast:Param", ptr %t364, i32 0, i32 2
  %t368 = load ptr, ptr %t367, !tbaa !29
  %t369 = load ptr, ptr %l175, !tbaa !29
  %t370 = load i32, ptr %l182, !tbaa !23
  %t371 = load %"compiler/source:Span", ptr %l189
  %t372 = load i32, ptr %l191, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparam(ptr %v0, ptr %v0, ptr %t369, i32 %t370, %"compiler/source:Span" %t371, i32 %t372, i64 0, ptr %t368)
  br label %bb59
bb59:
  br label %bb60
bb60:
  store i64 1, ptr %l20, !tbaa !24
  br label %bb61
bb61:
  %t374 = load ptr, ptr %l6, !tbaa !29
  %t376 = getelementptr %"compiler/check:ctSource", ptr %t374, i32 0, i32 2
  %t377 = load { i64, ptr }, ptr %t376, !tbaa !27
  store { i64, ptr } %t377, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t379 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t381 = extractvalue { i64, ptr } %t379, 0
  store i64 %t381, ptr %l23, !tbaa !24
  br label %bb62
bb62:
  store %olang.scope zeroinitializer, ptr %s8
  %t383 = load i64, ptr %l22, !tbaa !24
  %t384 = load i64, ptr %l23, !tbaa !24
  %t387 = icmp slt i64 %t383, %t384
  %t389 = xor i1 %t387, true
  br i1 %t389, label %bb63, label %bb64
bb63:
  call void @__olang_scope_close(ptr %s8)
  br label %bb72
bb64:
  br label %bb65
bb65:
  %t391 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t391, ptr %l207, !tbaa !27
  %t392 = load i64, ptr %l22, !tbaa !24
  %t394 = getelementptr { i64, ptr }, ptr %l207, i32 0, i32 1
  %t395 = load ptr, ptr %t394, !tbaa !27
  %t396 = getelementptr ptr, ptr %t395, i64 %t392
  %t397 = load ptr, ptr %t396, !tbaa !39
  store ptr %t397, ptr %l24, !tbaa !29
  %t399 = load i64, ptr %l20, !tbaa !24
  %t400 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t402 = extractvalue { i64, ptr } %t400, 0
  %t405 = icmp slt i64 %t399, %t402
  br i1 %t405, label %bb66, label %bb67
bb66:
  %t407 = load ptr, ptr %l0, !tbaa !29
  store ptr %t407, ptr %l214, !tbaa !29
  %t408 = load ptr, ptr %l24, !tbaa !29
  %t410 = getelementptr %"compiler/ast:Param", ptr %t408, i32 0, i32 1
  %t411 = load i32, ptr %t410, !tbaa !23
  store i32 %t411, ptr %l216, !tbaa !23
  %t412 = load ptr, ptr %l24, !tbaa !29
  %t414 = getelementptr %"compiler/ast:Param", ptr %t412, i32 0, i32 0
  %t415 = load %"compiler/source:Span", ptr %t414
  store %"compiler/source:Span" %t415, ptr %l218
  %t416 = load i64, ptr %l20, !tbaa !24
  %t419 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l8, i64 %t416)
  store i32 %t419, ptr %l221
  br label %bb68
bb67:
  br label %bb70
bb68:
  %t420 = load i64, ptr %l20, !tbaa !24
  %t421 = load ptr, ptr %l24, !tbaa !29
  %t423 = getelementptr %"compiler/ast:Param", ptr %t421, i32 0, i32 2
  %t424 = load ptr, ptr %t423, !tbaa !29
  %t425 = load ptr, ptr %l214, !tbaa !29
  %t426 = load i32, ptr %l216, !tbaa !23
  %t427 = load %"compiler/source:Span", ptr %l218
  %t428 = load i32, ptr %l221, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparam(ptr %v0, ptr %v0, ptr %t425, i32 %t426, %"compiler/source:Span" %t427, i32 %t428, i64 %t420, ptr %t424)
  br label %bb69
bb69:
  br label %bb70
bb70:
  %t431 = load i64, ptr %l20, !tbaa !24
  %t433 = add i64 %t431, 1
  store i64 %t433, ptr %l20, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb71
bb71:
  %t435 = load i64, ptr %l22, !tbaa !24
  %t437 = add i64 %t435, 1
  store i64 %t437, ptr %l22, !tbaa !24
  br label %bb62
bb72:
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t441 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t439)
  store ptr %t441, ptr %l230
  br label %bb73
bb73:
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t444 = getelementptr %"compiler/check:Checker", ptr %t442, i32 0, i32 1
  %t445 = load ptr, ptr %t444, !tbaa !29
  %t446 = load i32, ptr %l17, !tbaa !23
  %t449 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t445, i32 %t446)
  store { i64, ptr } %t449, ptr %l234
  br label %bb74
bb74:
  %t450 = load { i64, ptr }, ptr %l234, !tbaa !27
  %t451 = extractvalue { i64, ptr } %t450, 0
  %t452 = extractvalue { i64, ptr } %t450, 1
  %t453 = mul i64 %t451, 8
  %t454 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t453)
  call void @llvm.memcpy.p0.p0.i64(ptr %t454, ptr %t452, i64 %t453, i1 false)
  %t455 = insertvalue { i64, ptr } undef, i64 %t451, 0
  %t456 = insertvalue { i64, ptr } %t455, ptr %t454, 1
  %t457 = load ptr, ptr %l230, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eSetVars(ptr %v0, ptr %s0, ptr %t457, { i64, ptr } %t456)
  br label %bb75
bb75:
  %t459 = load ptr, ptr %l19, !tbaa !29
  store ptr %t459, ptr %l236, !tbaa !29
  %t460 = load ptr, ptr %l0, !tbaa !29
  %t462 = getelementptr %"compiler/check:Checker", ptr %t460, i32 0, i32 33
  %t464 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t462)
  store i64 %t464, ptr %l239
  br label %bb76
bb76:
  %t465 = load i64, ptr %l239, !tbaa !24
  %t466 = load ptr, ptr %l236, !tbaa !29
  %t467 = getelementptr %"compiler/check:frame", ptr %t466, i32 0, i32 52
  store i64 %t465, ptr %t467, !tbaa !24
  %t468 = load i64, ptr %l18, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t468, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefineValue(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca { %"compiler/cond:Value", i1 }
  %l5 = alloca %"compiler/cond:Value"
  %l6 = alloca i1
  %l7 = alloca i32
  %l8 = alloca { %"compiler/cond:Value", i1 }
  %l12 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca { %"compiler/cond:Value", i1 }
  %l17 = alloca i32
  %l23 = alloca i32
  %l26 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca i32
  %l35 = alloca i64
  %l36 = alloca ptr
  %l40 = alloca i1
  %l45 = alloca i1
  %l50 = alloca ptr
  %l54 = alloca i1
  %l59 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca %"compiler/source:Span"
  %l62 = alloca i32
  %l63 = alloca i32
  %l66 = alloca %"compiler/check:litv"
  %l67 = alloca i64
  %l68 = alloca ptr
  %l72 = alloca i1
  %l77 = alloca i1
  %l78 = alloca ptr
  %l79 = alloca %"compiler/source:Span"
  %l80 = alloca i32
  %l83 = alloca i64
  %l84 = alloca ptr
  %l88 = alloca i1
  %l89 = alloca i32
  %l91 = alloca i32
  %l96 = alloca ptr
  %s4 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l12, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l2, !tbaa !23
  %t15 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t11, i32 %t12)
  store { i64, ptr } %t15, ptr %l15
  br label %bb1
bb1:
  %t16 = load ptr, ptr %l12, !tbaa !29
  %t17 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t18 = call { i32, { %"compiler/cond:Value", i1 } } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eValueOf(ptr %v0, ptr %v0, ptr %t16, { i64, ptr } %t17)
  %t19 = extractvalue { i32, { %"compiler/cond:Value", i1 } } %t18, 1
  %t20 = extractvalue { i32, { %"compiler/cond:Value", i1 } } %t18, 0
  store i32 %t20, ptr %l17
  %t21 = icmp ne i32 %t20, 0
  br i1 %t21, label %bb3, label %ok.22
ok.22:
  store { %"compiler/cond:Value", i1 } %t19, ptr %l16
  br label %bb2
bb2:
  %t23 = load { %"compiler/cond:Value", i1 }, ptr %l16
  store { %"compiler/cond:Value", i1 } %t23, ptr %l8
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store ptr null, ptr %rv
  br label %ret
bb5:
  %t25 = load { %"compiler/cond:Value", i1 }, ptr %l8
  store { %"compiler/cond:Value", i1 } %t25, ptr %l4
  %t26 = getelementptr { %"compiler/cond:Value", i1 }, ptr %l4, i32 0, i32 0
  %t27 = load %"compiler/cond:Value", ptr %t26
  store %"compiler/cond:Value" %t27, ptr %l5
  %t29 = getelementptr { %"compiler/cond:Value", i1 }, ptr %l4, i32 0, i32 1
  %t30 = load i1, ptr %t29, !tbaa !21
  store i1 %t30, ptr %l6, !tbaa !21
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l3, !tbaa !23
  %t36 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t36, ptr %l23
  br label %bb6
bb6:
  %t37 = load i32, ptr %l23, !tbaa !23
  store i32 %t37, ptr %l7, !tbaa !23
  %t38 = getelementptr %"compiler/cond:Value", ptr %l5, i32 0, i32 0
  %t39 = load i32, ptr %t38
  %t41 = trunc i64 1 to i32
  %t42 = icmp eq i32 %t39, %t41
  br i1 %t42, label %bb7, label %bb8
bb7:
  %t44 = load i32, ptr %l7, !tbaa !23
  %t45 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t48 = icmp eq i32 %t44, %t45
  store i1 %t48, ptr %l26, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb9
bb9:
  %t50 = load i1, ptr %l26, !tbaa !21
  br i1 %t50, label %bb10, label %bb11
bb10:
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l30, !tbaa !29
  %t52 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t52, ptr %l31
  %t53 = load i32, ptr %l3, !tbaa !23
  store i32 %t53, ptr %l32, !tbaa !23
  %t54 = getelementptr %"compiler/cond:Value", ptr %l5, i32 0, i32 1
  %t55 = load i64, ptr %t54, !tbaa !24
  %t57 = icmp ne i64 %t55, 0
  br i1 %t57, label %bb12, label %bb13
bb11:
  br label %bb16
bb12:
  store i64 1, ptr %l35, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb14
bb14:
  %t59 = load ptr, ptr %l30, !tbaa !29
  %t60 = load %"compiler/source:Span", ptr %l31
  %t61 = load i32, ptr %l32, !tbaa !23
  %t62 = load i64, ptr %l35, !tbaa !24
  %t63 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t59, %"compiler/source:Span" %t60, i32 %t61, i64 %t62)
  store ptr %t63, ptr %l36
  br label %bb15
bb15:
  %t64 = load ptr, ptr %l36, !tbaa !29
  store ptr %t64, ptr %rv
  br label %ret
bb16:
  %t66 = getelementptr %"compiler/cond:Value", ptr %l5, i32 0, i32 0
  %t67 = load i32, ptr %t66
  %t69 = trunc i64 2 to i32
  %t70 = icmp eq i32 %t67, %t69
  br i1 %t70, label %bb17, label %bb18
bb17:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/check:Checker", ptr %t72, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = getelementptr %"compiler/generic:Program", ptr %t75, i32 0, i32 2
  %t78 = load i32, ptr %l7, !tbaa !23
  %t81 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t77, i32 %t78)
  store i1 %t81, ptr %l45
  br label %bb19
bb18:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb20
bb19:
  %t82 = load i1, ptr %l45, !tbaa !21
  store i1 %t82, ptr %l40, !tbaa !21
  br label %bb20
bb20:
  %t83 = load i1, ptr %l40, !tbaa !21
  br i1 %t83, label %bb21, label %bb22
bb21:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load %"compiler/source:Span", ptr %l1
  %t86 = load i32, ptr %l3, !tbaa !23
  %t87 = getelementptr %"compiler/cond:Value", ptr %l5, i32 0, i32 1
  %t88 = load i64, ptr %t87, !tbaa !24
  %t93 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t84, %"compiler/source:Span" %t85, i32 %t86, i64 %t88)
  store ptr %t93, ptr %l50
  br label %bb23
bb22:
  br label %bb24
bb23:
  %t94 = load ptr, ptr %l50, !tbaa !29
  store ptr %t94, ptr %rv
  br label %ret
bb24:
  %t96 = getelementptr %"compiler/cond:Value", ptr %l5, i32 0, i32 0
  %t97 = load i32, ptr %t96
  %t99 = trunc i64 2 to i32
  %t100 = icmp eq i32 %t97, %t99
  br i1 %t100, label %bb25, label %bb26
bb25:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/check:Checker", ptr %t102, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = getelementptr %"compiler/generic:Program", ptr %t105, i32 0, i32 2
  %t108 = load i32, ptr %l7, !tbaa !23
  %t111 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t107, i32 %t108)
  store i1 %t111, ptr %l59
  br label %bb27
bb26:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb28
bb27:
  %t112 = load i1, ptr %l59, !tbaa !21
  store i1 %t112, ptr %l54, !tbaa !21
  br label %bb28
bb28:
  %t113 = load i1, ptr %l54, !tbaa !21
  br i1 %t113, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s4
  %t114 = load ptr, ptr %l0, !tbaa !29
  store ptr %t114, ptr %l60, !tbaa !29
  %t115 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t115, ptr %l61
  %t116 = load i32, ptr %l3, !tbaa !23
  store i32 %t116, ptr %l62, !tbaa !23
  %t117 = load i32, ptr %l7, !tbaa !23
  store i32 %t117, ptr %l63, !tbaa !23
  %t118 = load i1, ptr %l6, !tbaa !21
  %t119 = getelementptr %"compiler/cond:Value", ptr %l5, i32 0, i32 1
  %t120 = load i64, ptr %t119, !tbaa !24
  %t123 = call %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %s4, i1 true, i1 false, i1 %t118, i64 %t120, double 0x0000000000000000)
  store %"compiler/check:litv" %t123, ptr %l66
  br label %bb31
bb30:
  br label %bb34
bb31:
  %t124 = load i32, ptr %l63, !tbaa !23
  %t125 = load %"compiler/check:litv", ptr %l66
  %t126 = call i64 @compiler_2fcheck_2eintFloatBits(i32 %t124, %"compiler/check:litv" %t125)
  store i64 %t126, ptr %l67
  br label %bb32
bb32:
  %t127 = load ptr, ptr %l60, !tbaa !29
  %t128 = load %"compiler/source:Span", ptr %l61
  %t129 = load i32, ptr %l62, !tbaa !23
  %t130 = load i64, ptr %l67, !tbaa !24
  %t131 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t127, %"compiler/source:Span" %t128, i32 %t129, i64 %t130)
  store ptr %t131, ptr %l68
  br label %bb33
bb33:
  %t132 = load ptr, ptr %l68, !tbaa !29
  call void @__olang_scope_close(ptr %s4)
  store ptr %t132, ptr %rv
  br label %ret
bb34:
  %t134 = getelementptr %"compiler/cond:Value", ptr %l5, i32 0, i32 0
  %t135 = load i32, ptr %t134
  %t137 = trunc i64 3 to i32
  %t138 = icmp eq i32 %t135, %t137
  br i1 %t138, label %bb35, label %bb36
bb35:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/check:Checker", ptr %t140, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t145 = getelementptr %"compiler/generic:Program", ptr %t143, i32 0, i32 2
  %t146 = load i32, ptr %l7, !tbaa !23
  %t149 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t145, i32 %t146)
  store i1 %t149, ptr %l77
  br label %bb37
bb36:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb38
bb37:
  %t150 = load i1, ptr %l77, !tbaa !21
  store i1 %t150, ptr %l72, !tbaa !21
  br label %bb38
bb38:
  %t151 = load i1, ptr %l72, !tbaa !21
  br i1 %t151, label %bb39, label %bb40
bb39:
  %t152 = load ptr, ptr %l0, !tbaa !29
  store ptr %t152, ptr %l78, !tbaa !29
  %t153 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t153, ptr %l79
  %t154 = load i32, ptr %l3, !tbaa !23
  store i32 %t154, ptr %l80, !tbaa !23
  %t155 = load i32, ptr %l7, !tbaa !23
  %t156 = getelementptr %"compiler/cond:Value", ptr %l5, i32 0, i32 2
  %t157 = load double, ptr %t156, !tbaa !26
  %t160 = call i64 @compiler_2fcheck_2efloatBits(i32 %t155, double %t157)
  store i64 %t160, ptr %l83
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t161 = load ptr, ptr %l78, !tbaa !29
  %t162 = load %"compiler/source:Span", ptr %l79
  %t163 = load i32, ptr %l80, !tbaa !23
  %t164 = load i64, ptr %l83, !tbaa !24
  %t165 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t161, %"compiler/source:Span" %t162, i32 %t163, i64 %t164)
  store ptr %t165, ptr %l84
  br label %bb42
bb42:
  %t166 = load ptr, ptr %l84, !tbaa !29
  store ptr %t166, ptr %rv
  br label %ret
bb43:
  %t168 = getelementptr %"compiler/cond:Value", ptr %l5, i32 0, i32 0
  %t169 = load i32, ptr %t168
  %t171 = trunc i64 4 to i32
  %t172 = icmp eq i32 %t169, %t171
  br i1 %t172, label %bb44, label %bb45
bb44:
  %t174 = load i32, ptr %l3, !tbaa !23
  store i32 %t174, ptr %l89, !tbaa !23
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t175)
  store i32 %t177, ptr %l91
  br label %bb46
bb45:
  store i1 false, ptr %l88, !tbaa !21
  br label %bb47
bb46:
  %t178 = load i32, ptr %l89, !tbaa !23
  %t179 = load i32, ptr %l91, !tbaa !23
  %t180 = icmp eq i32 %t178, %t179
  store i1 %t180, ptr %l88, !tbaa !21
  br label %bb47
bb47:
  %t182 = load i1, ptr %l88, !tbaa !21
  br i1 %t182, label %bb48, label %bb49
bb48:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load %"compiler/source:Span", ptr %l1
  %t185 = load i32, ptr %l2, !tbaa !23
  %t189 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuildConst(ptr %v0, ptr %t183, %"compiler/source:Span" %t184, i32 %t185)
  store ptr %t189, ptr %l96
  br label %bb50
bb49:
  br label %bb51
bb50:
  %t190 = load ptr, ptr %l96, !tbaa !29
  store ptr %t190, ptr %rv
  br label %ret
bb51:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edestructs(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i32
  %l12 = alloca i1
  %l13 = alloca i1
  %l18 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l5, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t7, i32 %a1)
  store i32 %t11, ptr %l8
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l5, !tbaa !29
  %t13 = load i32, ptr %l8, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t14, ptr %l9
  br label %bb2
bb2:
  %t15 = load i32, ptr %l9, !tbaa !23
  store i32 %t15, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t16, i32 %t17)
  store i1 %t20, ptr %l12
  br label %bb3
bb3:
  %t21 = load i1, ptr %l12, !tbaa !21
  br i1 %t21, label %bb4, label %bb5
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l2, !tbaa !23
  %t31 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t27, i32 %t28)
  store i1 %t31, ptr %l18
  br label %bb6
bb5:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb7
bb6:
  %t32 = load i1, ptr %l18, !tbaa !21
  store i1 %t32, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t33 = load i1, ptr %l13, !tbaa !21
  store i1 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edrain(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l6 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l20 = alloca i64
  %l25 = alloca i1
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 15
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 14
  %t9 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l6
  br label %bb3
bb3:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l6, !tbaa !24
  %t12 = icmp slt i64 %t10, %t11
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb5:
  br label %bb6
bb6:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 14
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 15
  %t22 = load i64, ptr %t21, !tbaa !24
  %t25 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t18, i64 %t22)
  store i64 %t25, ptr %l13
  br label %bb7
bb7:
  %t26 = load i64, ptr %l13, !tbaa !24
  store i64 %t26, ptr %l1, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l14, !tbaa !29
  %t28 = load ptr, ptr %l14, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 15
  %t30 = load i64, ptr %t29, !tbaa !24
  %t32 = add i64 %t30, 1
  %t34 = load ptr, ptr %l14, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 15
  store i64 %t32, ptr %t35, !tbaa !24
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 16
  %t39 = load i64, ptr %l1, !tbaa !24
  %t42 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t38, i64 %t39)
  store i64 %t42, ptr %l20
  br label %bb8
bb8:
  %t43 = load i64, ptr %l20, !tbaa !24
  %t44 = icmp eq i64 %t43, 0
  br i1 %t44, label %bb9, label %bb10
bb9:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeck(ptr %v0, ptr %t46, i64 %t47)
  br label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  br label %bb2
bb14:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewakeThunks(ptr %v0, ptr %t50)
  store i1 %t52, ptr %l25
  br label %bb15
bb15:
  %t53 = load i1, ptr %l25, !tbaa !21
  %t54 = xor i1 %t53, true
  br i1 %t54, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb17:
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s1)
  br label %bb19
bb19:
  br label %bb1
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eembed(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %lp5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l15 = alloca i64
  %l16 = alloca { { i64, ptr }, { i64, ptr } }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l23 = alloca ptr
  %l27 = alloca i32
  %l29 = alloca i32
  %l30 = alloca %"compiler/source:Span"
  %l31 = alloca i32
  %l33 = alloca i64
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %l43 = alloca ptr
  %l44 = alloca i1
  %l47 = alloca i1
  %l55 = alloca { i64, ptr }
  %l56 = alloca %"std/prelude/text:StringBuilder"
  %l64 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l76 = alloca i64
  %l78 = alloca i64
  %l79 = alloca { i64, ptr }
  %l84 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l89 = alloca i1
  %l90 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l96 = alloca i32
  %l97 = alloca { i64, ptr }
  %l99 = alloca i64
  %l101 = alloca i64
  %l102 = alloca { i64, ptr }
  %l104 = alloca i1
  %l105 = alloca ptr
  %l107 = alloca %"compiler/source:Span"
  %l108 = alloca %"compiler/msgs:Msg"
  %l109 = alloca i64
  %l111 = alloca ptr
  %l113 = alloca i64
  %l114 = alloca ptr
  %l116 = alloca i32
  %l117 = alloca i64
  %l120 = alloca ptr
  %l122 = alloca %"compiler/source:Span"
  %l123 = alloca %"compiler/msgs:Msg"
  %l124 = alloca i64
  %l127 = alloca ptr
  %l132 = alloca %"compiler/check:EmbedAsk"
  %l140 = alloca { { i64, ptr }, { i64, ptr } }
  %l142 = alloca { i64, ptr }
  %l143 = alloca i64
  %l144 = alloca { i64, ptr }
  %l146 = alloca i1
  %l148 = alloca ptr
  %l150 = alloca %"compiler/source:Span"
  %l152 = alloca { i64, ptr }
  %l155 = alloca %"compiler/msgs:Msg"
  %l156 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca ptr
  %t37 = alloca { i64, [2 x i64] }, align 8
  %t45 = alloca { i64, [5 x i64] }, align 8
  %t372 = alloca { i64, [2 x i64] }, align 8
  %t380 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l20
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l20, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/generic:Program", ptr %t8, i32 0, i32 2
  store ptr %t10, ptr %l23, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 2
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t16, i32 7, i32 0)
  store i32 %t18, ptr %l27
  br label %bb2
bb2:
  %t19 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t20 = load ptr, ptr %l23, !tbaa !29
  %t21 = load i32, ptr %l27, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t20, i32 %t21, i64 %t19)
  store i32 %t23, ptr %l29
  br label %bb3
bb3:
  %t24 = load i32, ptr %l29, !tbaa !23
  store i32 %t24, ptr %l4, !tbaa !23
  %t25 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t25, ptr %l30
  %t26 = load i32, ptr %l4, !tbaa !23
  store i32 %t26, ptr %l31, !tbaa !23
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t29 = getelementptr %"compiler/check:frame", ptr %t27, i32 0, i32 2
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l33, !tbaa !24
  %t31 = icmp sge i64 0, 0
  br i1 %t31, label %bb4, label %bb5
bb4:
  %t33 = mul i64 0, 1
  %t34 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t33)
  %t35 = insertvalue { i64, ptr } undef, i64 0, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  store { i64, [2 x i64] } zeroinitializer, ptr %t37
  %t38 = getelementptr { i64, [2 x i64] }, ptr %t37, i32 0, i32 0
  store i64 1, ptr %t38
  %t40 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t36, 0
  %t41 = getelementptr { i64, [2 x i64] }, ptr %t37, i32 0, i32 1
  store { { i64, ptr } } %t40, ptr %t41
  %t42 = load { i64, [2 x i64] }, ptr %t37
  %t44 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t42, ptr %t44
  store { i64, [5 x i64] } zeroinitializer, ptr %t45
  %t46 = getelementptr { i64, [5 x i64] }, ptr %t45, i32 0, i32 0
  store i64 1, ptr %t46
  %t47 = load %"compiler/source:Span", ptr %l30
  %t48 = insertvalue { %"compiler/source:Span", i32, i64, ptr } undef, %"compiler/source:Span" %t47, 0
  %t49 = load i32, ptr %l31, !tbaa !23
  %t50 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t48, i32 %t49, 1
  %t51 = load i64, ptr %l33, !tbaa !24
  %t52 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t50, i64 %t51, 2
  %t54 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t52, ptr %t44, 3
  %t55 = getelementptr { i64, [5 x i64] }, ptr %t45, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, ptr } %t54, ptr %t55
  %t56 = load { i64, [5 x i64] }, ptr %t45
  %t57 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store ptr %t57, ptr %lp5
  %t59 = load ptr, ptr %lp5
  store { i64, [5 x i64] } %t56, ptr %t59
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l39, !tbaa !27
  %t60 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t60, ptr %l40, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t61, 0
  store i64 %t62, ptr %l41, !tbaa !24
  %t63 = load i64, ptr %l41, !tbaa !24
  %t64 = mul i64 %t63, 1
  %t65 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t64)
  %t66 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t65, 1
  store { i64, ptr } %t67, ptr %l42, !tbaa !27
  %t68 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = load i64, ptr %l41, !tbaa !24
  %t73 = mul i64 %t72, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t69, ptr %t71, i64 %t73, i1 false)
  %t74 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t74, ptr %l6, !tbaa !27
  %t75 = load ptr, ptr %l2, !tbaa !29
  store ptr %t75, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t76 = load ptr, ptr %l43, !tbaa !29
  %t77 = icmp ne ptr %t76, null
  br i1 %t77, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_2d16f3aa36d067c5_95008946090581a1)
  unreachable
bb6:
  %t79 = load ptr, ptr %l43, !tbaa !29
  %t80 = load i64, ptr %t79
  %t82 = icmp eq i64 %t80, 1
  store i1 %t82, ptr %l44, !tbaa !21
  br label %bb7
bb7:
  %t83 = load i1, ptr %l44, !tbaa !21
  br i1 %t83, label %bb8, label %bb9
bb8:
  %t84 = load ptr, ptr %l2, !tbaa !29
  %t86 = getelementptr { i64, [5 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", i32 }, ptr %t86, i32 0, i32 1
  %t88 = load i32, ptr %t87
  %t90 = trunc i64 5 to i32
  %t91 = icmp eq i32 %t88, %t90
  store i1 %t91, ptr %l47, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb10
bb10:
  %t93 = load i1, ptr %l47, !tbaa !21
  br i1 %t93, label %bb11, label %bb12
bb11:
  %t94 = load ptr, ptr %l2, !tbaa !29
  %t96 = getelementptr { i64, [5 x i64] }, ptr %t94, i32 0, i32 1
  %t97 = getelementptr { %"compiler/source:Span", i32 }, ptr %t96, i32 0, i32 0
  %t98 = load %"compiler/source:Span", ptr %t97
  store %"compiler/source:Span" %t98, ptr %l7
  br label %bb13
bb12:
  br label %bb27
bb13:
  store %olang.scope zeroinitializer, ptr %s1
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load %"compiler/source:Span", ptr %l7
  %t104 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estrBytes(ptr %v0, ptr %t100, %"compiler/source:Span" %t101)
  store { i64, ptr } %t104, ptr %l55
  br label %bb14
bb14:
  %t105 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t105, ptr %l8, !tbaa !27
  %t106 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s1)
  store %"std/prelude/text:StringBuilder" %t106, ptr %l56
  br label %bb15
bb15:
  %t107 = load %"std/prelude/text:StringBuilder", ptr %l56
  store %"std/prelude/text:StringBuilder" %t107, ptr %l9
  %t108 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t108, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t110 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t110, 0
  store i64 %t112, ptr %l12, !tbaa !24
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t114 = load i64, ptr %l11, !tbaa !24
  %t115 = load i64, ptr %l12, !tbaa !24
  %t118 = icmp slt i64 %t114, %t115
  %t120 = xor i1 %t118, true
  br i1 %t120, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb18:
  br label %bb19
bb19:
  %t122 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t122, ptr %l64, !tbaa !27
  %t123 = load i64, ptr %l11, !tbaa !24
  %t125 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = getelementptr i8, ptr %t126, i64 %t123
  %t128 = load i8, ptr %t127, !tbaa !32
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s1, ptr %l9, i8 %t128)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb21:
  %t134 = load i64, ptr %l11, !tbaa !24
  %t136 = add i64 %t134, 1
  store i64 %t136, ptr %l11, !tbaa !24
  br label %bb16
bb22:
  %t139 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s1, ptr %s0, ptr %l9)
  store { i64, ptr } %t139, ptr %l73
  br label %bb23
bb23:
  %t140 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t140, ptr %l74, !tbaa !27
  %t141 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 0
  %t143 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t143, 0
  store i64 %t144, ptr %l76, !tbaa !24
  %t146 = load i64, ptr %l76, !tbaa !24
  %t147 = icmp eq i64 %t142, %t146
  br i1 %t147, label %bb24, label %bb25
bb24:
  %t149 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = load i64, ptr %l76, !tbaa !24
  %t154 = mul i64 %t153, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t150, ptr %t152, i64 %t154, i1 false)
  br label %bb26
bb25:
  %t155 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t155, 0
  store i64 %t156, ptr %l78, !tbaa !24
  %t157 = load i64, ptr %l78, !tbaa !24
  %t158 = mul i64 %t157, 1
  %t159 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t158)
  %t160 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t161 = insertvalue { i64, ptr } %t160, ptr %t159, 1
  store { i64, ptr } %t161, ptr %l79, !tbaa !27
  %t162 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !27
  %t164 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !27
  %t166 = load i64, ptr %l78, !tbaa !24
  %t167 = mul i64 %t166, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t163, ptr %t165, i64 %t167, i1 false)
  %t168 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t168, ptr %l6, !tbaa !27
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s1)
  br label %bb57
bb27:
  store %olang.scope zeroinitializer, ptr %s5
  %t169 = load ptr, ptr %l3, !tbaa !29
  %t171 = getelementptr %"compiler/check:frame", ptr %t169, i32 0, i32 2
  %t172 = load i64, ptr %t171, !tbaa !24
  %t173 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t174 = load i32, ptr %t173, !tbaa !23
  %t176 = sext i32 %t174 to i64
  %t179 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s5, i64 %t172, i64 %t176)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t179, ptr %l84
  br label %bb28
bb28:
  %t180 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l84
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t180, ptr %l14
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/check:Checker", ptr %t181, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !29
  %t186 = getelementptr %"compiler/generic:Program", ptr %t184, i32 0, i32 40
  %t187 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l14
  %t190 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H4b90e82c7a9c5937397e46eef988cfe3(ptr %v0, ptr %t186, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t187)
  store i1 %t190, ptr %l89
  br label %bb29
bb29:
  %t191 = load i1, ptr %l89, !tbaa !21
  br i1 %t191, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s6
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/check:Checker", ptr %t192, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !29
  %t197 = getelementptr %"compiler/generic:Program", ptr %t195, i32 0, i32 40
  %t198 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l14
  %t201 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H031c7c147cc8ce0b988dd3fed8d142ad(ptr %v0, ptr %s0, ptr %t197, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t198)
  %t202 = extractvalue { i32, { i64, ptr } } %t201, 1
  %t203 = extractvalue { i32, { i64, ptr } } %t201, 0
  store i32 %t203, ptr %l96
  %t204 = icmp ne i32 %t203, 0
  br i1 %t204, label %bb33, label %ok.205
ok.205:
  store { i64, ptr } %t202, ptr %l95
  br label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s8
  %t206 = load ptr, ptr %l0, !tbaa !29
  store ptr %t206, ptr %l111, !tbaa !29
  %t207 = load ptr, ptr %l3, !tbaa !29
  %t209 = getelementptr %"compiler/check:frame", ptr %t207, i32 0, i32 1
  %t210 = load i64, ptr %t209, !tbaa !24
  store i64 %t210, ptr %l113, !tbaa !24
  %t211 = load ptr, ptr %l2, !tbaa !29
  store ptr %t211, ptr %l114, !tbaa !29
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t212)
  store i32 %t214, ptr %l116
  br label %bb46
bb32:
  %t215 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t215, ptr %l90, !tbaa !27
  br label %bb35
bb33:
  br label %bb34
bb34:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l90, !tbaa !27
  br label %bb35
bb35:
  %t216 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t216, ptr %l97, !tbaa !27
  %t217 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t218 = extractvalue { i64, ptr } %t217, 0
  %t219 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t220 = extractvalue { i64, ptr } %t219, 0
  store i64 %t220, ptr %l99, !tbaa !24
  %t222 = load i64, ptr %l99, !tbaa !24
  %t223 = icmp eq i64 %t218, %t222
  br i1 %t223, label %bb36, label %bb37
bb36:
  %t225 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t228 = load ptr, ptr %t227, !tbaa !27
  %t229 = load i64, ptr %l99, !tbaa !24
  %t230 = mul i64 %t229, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t226, ptr %t228, i64 %t230, i1 false)
  br label %bb38
bb37:
  %t231 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t231, 0
  store i64 %t232, ptr %l101, !tbaa !24
  %t233 = load i64, ptr %l101, !tbaa !24
  %t234 = mul i64 %t233, 1
  %t235 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t234)
  %t236 = insertvalue { i64, ptr } undef, i64 %t233, 0
  %t237 = insertvalue { i64, ptr } %t236, ptr %t235, 1
  store { i64, ptr } %t237, ptr %l102, !tbaa !27
  %t238 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t239 = load ptr, ptr %t238, !tbaa !27
  %t240 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !27
  %t242 = load i64, ptr %l101, !tbaa !24
  %t243 = mul i64 %t242, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t239, ptr %t241, i64 %t243, i1 false)
  %t244 = load { i64, ptr }, ptr %l102, !tbaa !27
  store { i64, ptr } %t244, ptr %l6, !tbaa !27
  br label %bb38
bb38:
  %t245 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t247 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s6, { i64, ptr } %t245, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) })
  store i1 %t247, ptr %l104
  br label %bb39
bb39:
  %t248 = load i1, ptr %l104, !tbaa !21
  br i1 %t248, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s7
  %t249 = load ptr, ptr %l0, !tbaa !29
  store ptr %t249, ptr %l105, !tbaa !29
  %t250 = load ptr, ptr %l2, !tbaa !29
  %t252 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t250)
  store %"compiler/source:Span" %t252, ptr %l107
  br label %bb42
bb41:
  br label %bb45
bb42:
  %t253 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eEmbedPathUndecided(ptr %s7)
  store %"compiler/msgs:Msg" %t253, ptr %l108
  br label %bb43
bb43:
  %t254 = load ptr, ptr %l105, !tbaa !29
  %t255 = load %"compiler/source:Span", ptr %l107
  %t256 = load %"compiler/msgs:Msg", ptr %l108
  %t257 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t254, %"compiler/source:Span" %t255, %"compiler/msgs:Msg" %t256)
  store i64 %t257, ptr %l109
  br label %bb44
bb44:
  %t258 = load ptr, ptr %lp5
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t258, ptr %rv
  br label %ret
bb45:
  call void @__olang_scope_close(ptr %s6)
  br label %bb56
bb46:
  %t260 = load ptr, ptr %l111, !tbaa !29
  %t261 = load i64, ptr %l113, !tbaa !24
  %t262 = load ptr, ptr %l114, !tbaa !29
  %t263 = load i32, ptr %l116, !tbaa !23
  %t264 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBody(ptr %v0, ptr %v1, ptr %t260, i64 %t261, ptr %t262, i32 %t263)
  store i64 %t264, ptr %l117
  br label %bb47
bb47:
  %t265 = load i64, ptr %l117, !tbaa !24
  store i64 %t265, ptr %l15, !tbaa !24
  %t266 = load i64, ptr %l15, !tbaa !24
  %t268 = icmp slt i64 %t266, 0
  br i1 %t268, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s9
  %t270 = load ptr, ptr %l0, !tbaa !29
  store ptr %t270, ptr %l120, !tbaa !29
  %t271 = load ptr, ptr %l2, !tbaa !29
  %t273 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t271)
  store %"compiler/source:Span" %t273, ptr %l122
  br label %bb50
bb49:
  br label %bb53
bb50:
  %t274 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eEmbedPathUnknown(ptr %s9)
  store %"compiler/msgs:Msg" %t274, ptr %l123
  br label %bb51
bb51:
  %t275 = load ptr, ptr %l120, !tbaa !29
  %t276 = load %"compiler/source:Span", ptr %l122
  %t277 = load %"compiler/msgs:Msg", ptr %l123
  %t278 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s9, ptr %t275, %"compiler/source:Span" %t276, %"compiler/msgs:Msg" %t277)
  store i64 %t278, ptr %l124
  br label %bb52
bb52:
  %t279 = load ptr, ptr %lp5
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t279, ptr %rv
  br label %ret
bb53:
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t283 = getelementptr %"compiler/check:Checker", ptr %t281, i32 0, i32 77
  store ptr %t283, ptr %l127, !tbaa !29
  %t284 = load i64, ptr %l15, !tbaa !24
  %t285 = load ptr, ptr %l3, !tbaa !29
  %t287 = getelementptr %"compiler/check:frame", ptr %t285, i32 0, i32 2
  %t288 = load i64, ptr %t287, !tbaa !24
  %t289 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t290 = load i32, ptr %t289, !tbaa !23
  %t294 = call %"compiler/check:EmbedAsk" @compiler_2fcheck_3aEmbedAsk_2ector(ptr %s8, i64 %t284, i64 %t288, i32 %t290)
  store %"compiler/check:EmbedAsk" %t294, ptr %l132
  br label %bb54
bb54:
  %t295 = load ptr, ptr %l127, !tbaa !29
  %t296 = load %"compiler/check:EmbedAsk", ptr %l132
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aEmbedAsk_3e_2ePu_Hace14f5ea0faa2954e863427c94d4269(ptr %v0, ptr %t295, %"compiler/check:EmbedAsk" %t296)
  br label %bb55
bb55:
  %t297 = load ptr, ptr %lp5
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t297, ptr %rv
  br label %ret
bb56:
  call void @__olang_scope_close(ptr %s5)
  br label %bb57
bb57:
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t301 = getelementptr %"compiler/check:Checker", ptr %t299, i32 0, i32 1
  %t302 = load ptr, ptr %t301, !tbaa !29
  %t304 = getelementptr %"compiler/generic:Program", ptr %t302, i32 0, i32 0
  %t305 = load ptr, ptr %t304, !tbaa !29
  %t306 = load ptr, ptr %l3, !tbaa !29
  %t308 = getelementptr %"compiler/check:frame", ptr %t306, i32 0, i32 1
  %t309 = load i64, ptr %t308, !tbaa !24
  %t310 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t314 = call { { i64, ptr }, { i64, ptr } } @compiler_2fload_2ecompiler_2fload_3aLoader_2eEmbed(ptr %v0, ptr %s0, ptr %s0, ptr %t305, i64 %t309, { i64, ptr } %t310)
  store { { i64, ptr }, { i64, ptr } } %t314, ptr %l140
  br label %bb58
bb58:
  %t315 = load { { i64, ptr }, { i64, ptr } }, ptr %l140
  store { { i64, ptr }, { i64, ptr } } %t315, ptr %l16
  %t316 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l16, i32 0, i32 0
  %t317 = load { i64, ptr }, ptr %t316, !tbaa !27
  store { i64, ptr } %t317, ptr %l17, !tbaa !27
  %t319 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l16, i32 0, i32 1
  %t320 = load { i64, ptr }, ptr %t319, !tbaa !27
  store { i64, ptr } %t320, ptr %l142, !tbaa !27
  %t321 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t322 = extractvalue { i64, ptr } %t321, 0
  store i64 %t322, ptr %l143, !tbaa !24
  %t323 = load i64, ptr %l143, !tbaa !24
  %t324 = mul i64 %t323, 1
  %t325 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t324)
  %t326 = insertvalue { i64, ptr } undef, i64 %t323, 0
  %t327 = insertvalue { i64, ptr } %t326, ptr %t325, 1
  store { i64, ptr } %t327, ptr %l144, !tbaa !27
  %t328 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t329 = load ptr, ptr %t328, !tbaa !27
  %t330 = getelementptr { i64, ptr }, ptr %l142, i32 0, i32 1
  %t331 = load ptr, ptr %t330, !tbaa !27
  %t332 = load i64, ptr %l143, !tbaa !24
  %t333 = mul i64 %t332, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t329, ptr %t331, i64 %t333, i1 false)
  %t334 = load { i64, ptr }, ptr %l144, !tbaa !27
  store { i64, ptr } %t334, ptr %l18, !tbaa !27
  %t335 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t337 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t335, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d21, i32 0, i32 1) })
  store i1 %t337, ptr %l146
  br label %bb59
bb59:
  %t338 = load i1, ptr %l146, !tbaa !21
  %t339 = xor i1 %t338, true
  br i1 %t339, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s10
  %t341 = load ptr, ptr %l0, !tbaa !29
  store ptr %t341, ptr %l148, !tbaa !29
  %t342 = load ptr, ptr %l2, !tbaa !29
  %t344 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t342)
  store %"compiler/source:Span" %t344, ptr %l150
  br label %bb62
bb61:
  br label %bb66
bb62:
  %t345 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t347 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s0, ptr %s10, { i64, ptr } %t345)
  store { i64, ptr } %t347, ptr %l152
  br label %bb63
bb63:
  %t348 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t349 = extractvalue { i64, ptr } %t348, 0
  %t350 = extractvalue { i64, ptr } %t348, 1
  %t351 = mul i64 %t349, 1
  %t352 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t351)
  call void @llvm.memcpy.p0.p0.i64(ptr %t352, ptr %t350, i64 %t351, i1 false)
  %t353 = insertvalue { i64, ptr } undef, i64 %t349, 0
  %t354 = insertvalue { i64, ptr } %t353, ptr %t352, 1
  %t355 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t358 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eEmbedNotRead(ptr %s10, ptr %s0, ptr %s10, { i64, ptr } %t354, { i64, ptr } %t355)
  store %"compiler/msgs:Msg" %t358, ptr %l155
  br label %bb64
bb64:
  %t359 = load ptr, ptr %l148, !tbaa !29
  %t360 = load %"compiler/source:Span", ptr %l150
  %t361 = load %"compiler/msgs:Msg", ptr %l155
  %t362 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s10, ptr %t359, %"compiler/source:Span" %t360, %"compiler/msgs:Msg" %t361)
  store i64 %t362, ptr %l156
  br label %bb65
bb65:
  %t363 = load ptr, ptr %lp5
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t363, ptr %rv
  br label %ret
bb66:
  %t365 = load %"compiler/source:Span", ptr %l1
  %t366 = load i32, ptr %l4, !tbaa !23
  %t367 = load ptr, ptr %l3, !tbaa !29
  %t369 = getelementptr %"compiler/check:frame", ptr %t367, i32 0, i32 2
  %t370 = load i64, ptr %t369, !tbaa !24
  %t371 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, [2 x i64] } zeroinitializer, ptr %t372
  %t373 = getelementptr { i64, [2 x i64] }, ptr %t372, i32 0, i32 0
  store i64 1, ptr %t373
  %t375 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t371, 0
  %t376 = getelementptr { i64, [2 x i64] }, ptr %t372, i32 0, i32 1
  store { { i64, ptr } } %t375, ptr %t376
  %t377 = load { i64, [2 x i64] }, ptr %t372
  %t379 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t377, ptr %t379
  store { i64, [5 x i64] } zeroinitializer, ptr %t380
  %t381 = getelementptr { i64, [5 x i64] }, ptr %t380, i32 0, i32 0
  store i64 1, ptr %t381
  %t383 = insertvalue { %"compiler/source:Span", i32, i64, ptr } undef, %"compiler/source:Span" %t365, 0
  %t385 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t383, i32 %t366, 1
  %t387 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t385, i64 %t370, 2
  %t389 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t387, ptr %t379, 3
  %t390 = getelementptr { i64, [5 x i64] }, ptr %t380, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, ptr } %t389, ptr %t390
  %t391 = load { i64, [5 x i64] }, ptr %t380
  %t393 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t391, ptr %t393
  call void @__olang_scope_close(ptr %s0)
  store ptr %t393, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l9 = alloca ptr
  %l18 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca i32
  %l28 = alloca %"compiler/source:Span"
  %l29 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i32, ptr %l2, !tbaa !23
  %t8 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitCtor(ptr %v0, ptr %v1, ptr %t1, ptr %t2, i32 %t4)
  store ptr %t8, ptr %l9
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l9, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t12 = icmp eq ptr %t10, null
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l3, !tbaa !29
  store ptr %t16, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = load i32, ptr %l2, !tbaa !23
  %t25 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t18, ptr %t19, i32 %t21)
  store ptr %t25, ptr %l18
  br label %bb5
bb5:
  %t26 = load ptr, ptr %l18, !tbaa !29
  store ptr %t26, ptr %l4, !tbaa !29
  %t27 = load i32, ptr %l2, !tbaa !23
  %t28 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t31 = icmp eq i32 %t27, %t28
  br i1 %t31, label %bb6, label %bb7
bb6:
  %t33 = load ptr, ptr %l4, !tbaa !29
  store ptr %t33, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l23, !tbaa !29
  %t36 = load ptr, ptr %l4, !tbaa !29
  store ptr %t36, ptr %l24, !tbaa !29
  %t37 = load i32, ptr %l2, !tbaa !23
  store i32 %t37, ptr %l25, !tbaa !23
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t42 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %t38, ptr %t39)
  store %"compiler/source:Span" %t42, ptr %l28
  br label %bb9
bb9:
  %t43 = load ptr, ptr %l23, !tbaa !29
  %t44 = load ptr, ptr %l24, !tbaa !29
  %t45 = load i32, ptr %l25, !tbaa !23
  %t46 = load %"compiler/source:Span", ptr %l28
  %t47 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t43, ptr %t44, i32 %t45, %"compiler/source:Span" %t46)
  store ptr %t47, ptr %l29
  br label %bb10
bb10:
  %t48 = load ptr, ptr %l29, !tbaa !29
  store ptr %t48, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternArray(ptr %v0, ptr %v1, ptr %a0, ptr %a1, ptr %a2, i32 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l20 = alloca i32
  %l23 = alloca i32
  %l27 = alloca i1
  %l32 = alloca i32
  %l39 = alloca i32
  %l43 = alloca i1
  %l48 = alloca i32
  %l52 = alloca ptr
  %l58 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca %"compiler/source:Span"
  %l61 = alloca %"compiler/source:Span"
  %l67 = alloca i32
  %l70 = alloca ptr
  %l73 = alloca ptr
  %l78 = alloca i32
  %l80 = alloca i32
  %l81 = alloca ptr
  %l83 = alloca ptr
  %l84 = alloca %"compiler/source:Span"
  %l85 = alloca %"compiler/source:Span"
  %l91 = alloca i32
  %l94 = alloca ptr
  %l100 = alloca i32
  %l101 = alloca ptr
  %l109 = alloca ptr
  %rv = alloca ptr
  %t111 = alloca { i64, [5 x i64] }, align 8
  %t167 = alloca { i64, [5 x i64] }, align 8
  %t202 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_12a7e56ab193c888_f3ea9b5a769b449c)
  unreachable
bb11:
  %t10 = load i1, ptr %l10, !tbaa !21
  %t13 = xor i1 %t10, true
  br i1 %t13, label %bb12, label %bb13
bb12:
  store ptr null, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t19 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t16)
  store i32 %t19, ptr %l20
  br label %bb15
bb15:
  %t20 = load i32, ptr %l20, !tbaa !23
  store i32 %t20, ptr %l6, !tbaa !23
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l3, !tbaa !23
  %t25 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l23
  br label %bb16
bb16:
  %t26 = load i32, ptr %l23, !tbaa !23
  store i32 %t26, ptr %l7, !tbaa !23
  %t27 = load i32, ptr %l7, !tbaa !23
  %t28 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t31 = icmp eq i32 %t27, %t28
  br i1 %t31, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb20
bb18:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %l7, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l32
  br label %bb19
bb19:
  %t43 = load i32, ptr %l32, !tbaa !23
  %t44 = icmp ne i32 %t43, 0
  store i1 %t44, ptr %l27, !tbaa !21
  br label %bb20
bb20:
  %t46 = load i1, ptr %l27, !tbaa !21
  br i1 %t46, label %bb21, label %bb22
bb21:
  store ptr null, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = getelementptr %"compiler/generic:Program", ptr %t51, i32 0, i32 2
  %t54 = load i32, ptr %l6, !tbaa !23
  %t57 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t53, i32 %t54)
  store i32 %t57, ptr %l39
  br label %bb24
bb24:
  %t58 = load i32, ptr %l39
  %t60 = trunc i64 19 to i32
  %t61 = icmp eq i32 %t58, %t60
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb28
bb26:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Program", ptr %t68, i32 0, i32 2
  %t71 = load i32, ptr %l6, !tbaa !23
  %t74 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t74, ptr %l48
  br label %bb27
bb27:
  %t75 = load i32, ptr %l48, !tbaa !23
  %t76 = icmp eq i32 %t75, 0
  store i1 %t76, ptr %l43, !tbaa !21
  br label %bb28
bb28:
  %t78 = load i1, ptr %l43, !tbaa !21
  br i1 %t78, label %bb29, label %bb30
bb29:
  store ptr null, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  %t80 = load ptr, ptr %l2, !tbaa !29
  %t82 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %t80)
  store ptr %t82, ptr %l52
  br label %bb32
bb32:
  %t83 = load ptr, ptr %l52, !tbaa !29
  store ptr %t83, ptr %l8, !tbaa !29
  %t84 = load ptr, ptr %l8, !tbaa !29
  %t86 = icmp eq ptr %t84, null
  br i1 %t86, label %bb33, label %bb34
bb33:
  store ptr null, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i32, ptr %l3, !tbaa !23
  %t93 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t89, i32 %t90)
  store i1 %t93, ptr %l58
  br label %bb36
bb36:
  %t94 = load i1, ptr %l58, !tbaa !21
  br i1 %t94, label %bb37, label %bb38
bb37:
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l59, !tbaa !29
  %t96 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t96, ptr %l60
  %t97 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t97, ptr %l61
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/check:Checker", ptr %t98, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = getelementptr %"compiler/generic:Program", ptr %t101, i32 0, i32 2
  %t104 = load i32, ptr %l6, !tbaa !23
  %t105 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t109 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t103, i32 %t104, i64 %t105)
  store i32 %t109, ptr %l67
  br label %bb39
bb38:
  br label %bb43
bb39:
  %t110 = load ptr, ptr %l8, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t111
  %t112 = getelementptr { i64, [5 x i64] }, ptr %t111, i32 0, i32 0
  store i64 3, ptr %t112
  %t113 = load %"compiler/source:Span", ptr %l61
  %t114 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t113, 0
  %t115 = load i32, ptr %l67, !tbaa !23
  %t116 = insertvalue { %"compiler/source:Span", i32, ptr } %t114, i32 %t115, 1
  %t118 = insertvalue { %"compiler/source:Span", i32, ptr } %t116, ptr %t110, 2
  %t119 = getelementptr { i64, [5 x i64] }, ptr %t111, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t118, ptr %t119
  %t120 = load { i64, [5 x i64] }, ptr %t111
  %t122 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t120, ptr %t122
  store ptr %t122, ptr %l70, !tbaa !29
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/check:Checker", ptr %t123, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t128 = getelementptr %"compiler/generic:Program", ptr %t126, i32 0, i32 2
  store ptr %t128, ptr %l73, !tbaa !29
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/check:Checker", ptr %t129, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t134 = getelementptr %"compiler/generic:Program", ptr %t132, i32 0, i32 2
  %t135 = load i32, ptr %l3, !tbaa !23
  %t138 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t134, i32 %t135)
  store i32 %t138, ptr %l78
  br label %bb40
bb40:
  %t139 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t140 = load ptr, ptr %l73, !tbaa !29
  %t141 = load i32, ptr %l78, !tbaa !23
  %t143 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t140, i32 %t141, i64 %t139)
  store i32 %t143, ptr %l80
  br label %bb41
bb41:
  %t144 = load ptr, ptr %l59, !tbaa !29
  %t145 = load %"compiler/source:Span", ptr %l60
  %t146 = load ptr, ptr %l70, !tbaa !29
  %t147 = load i32, ptr %l80, !tbaa !23
  %t148 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t144, %"compiler/source:Span" %t145, ptr %t146, i32 %t147)
  store ptr %t148, ptr %l81
  br label %bb42
bb42:
  %t149 = load ptr, ptr %l81, !tbaa !29
  store ptr %t149, ptr %rv
  br label %ret
bb43:
  %t151 = load ptr, ptr %l0, !tbaa !29
  store ptr %t151, ptr %l83, !tbaa !29
  %t152 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t152, ptr %l84
  %t153 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t153, ptr %l85
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/check:Checker", ptr %t154, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = getelementptr %"compiler/generic:Program", ptr %t157, i32 0, i32 2
  %t160 = load i32, ptr %l6, !tbaa !23
  %t161 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t165 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t159, i32 %t160, i64 %t161)
  store i32 %t165, ptr %l91
  br label %bb44
bb44:
  %t166 = load ptr, ptr %l8, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t167
  %t168 = getelementptr { i64, [5 x i64] }, ptr %t167, i32 0, i32 0
  store i64 3, ptr %t168
  %t169 = load %"compiler/source:Span", ptr %l85
  %t170 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t169, 0
  %t171 = load i32, ptr %l91, !tbaa !23
  %t172 = insertvalue { %"compiler/source:Span", i32, ptr } %t170, i32 %t171, 1
  %t174 = insertvalue { %"compiler/source:Span", i32, ptr } %t172, ptr %t166, 2
  %t175 = getelementptr { i64, [5 x i64] }, ptr %t167, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t174, ptr %t175
  %t176 = load { i64, [5 x i64] }, ptr %t167
  %t178 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t176, ptr %t178
  store ptr %t178, ptr %l94, !tbaa !29
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t179, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t184 = getelementptr %"compiler/generic:Program", ptr %t182, i32 0, i32 2
  %t185 = load i32, ptr %l3, !tbaa !23
  %t186 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t190 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t184, i32 %t185, i64 %t186)
  store i32 %t190, ptr %l100
  br label %bb45
bb45:
  %t191 = load ptr, ptr %l83, !tbaa !29
  %t192 = load %"compiler/source:Span", ptr %l84
  %t193 = load ptr, ptr %l94, !tbaa !29
  %t194 = load i32, ptr %l100, !tbaa !23
  %t195 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t191, %"compiler/source:Span" %t192, ptr %t193, i32 %t194)
  store ptr %t195, ptr %l101
  br label %bb46
bb46:
  %t196 = load ptr, ptr %l101, !tbaa !29
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load %"compiler/source:Span", ptr %l4
  %t199 = load %"compiler/source:Span", ptr %l4
  %t200 = load i32, ptr %l3, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t202
  %t203 = getelementptr { i64, [4 x i64] }, ptr %t202, i32 0, i32 0
  store i64 2, ptr %t203
  %t205 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t199, 0
  %t207 = insertvalue { %"compiler/source:Span", i32, ptr } %t205, i32 %t200, 1
  %t209 = insertvalue { %"compiler/source:Span", i32, ptr } %t207, ptr %t196, 2
  %t210 = getelementptr { i64, [4 x i64] }, ptr %t202, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t209, ptr %t210
  %t211 = load { i64, [4 x i64] }, ptr %t202
  %t213 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t211, ptr %t213
  %t217 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t197, %"compiler/source:Span" %t198, ptr %t213)
  store ptr %t217, ptr %l109
  br label %bb47
bb47:
  %t218 = load ptr, ptr %l109, !tbaa !29
  store ptr %t218, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efield(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l18 = alloca i32
  %l22 = alloca i64
  %l25 = alloca i64
  %l45 = alloca i1
  %l49 = alloca %"compiler/source:Span"
  %l54 = alloca i32
  %l58 = alloca ptr
  %l65 = alloca i32
  %l74 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca %"compiler/source:Span"
  %l79 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l84 = alloca %"compiler/msgs:Msg"
  %l85 = alloca i64
  %l89 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca %"compiler/source:Span"
  %l95 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l100 = alloca %"compiler/msgs:Msg"
  %l101 = alloca i64
  %l106 = alloca i64
  %l109 = alloca ptr
  %l110 = alloca %"compiler/source:Span"
  %l113 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l117 = alloca { i64, ptr }
  %l118 = alloca %"compiler/msgs:Msg"
  %l119 = alloca i64
  %l123 = alloca ptr
  %l128 = alloca i32
  %l129 = alloca { i64, ptr }
  %l134 = alloca i1
  %l135 = alloca { i64, ptr }
  %l140 = alloca i1
  %l143 = alloca i1
  %l145 = alloca i1
  %l149 = alloca i32
  %l154 = alloca i64
  %l158 = alloca i64
  %l164 = alloca ptr
  %l169 = alloca i32
  %l170 = alloca { i64, ptr }
  %l180 = alloca { i64, ptr }
  %l181 = alloca { i64, ptr }
  %l183 = alloca i1
  %l185 = alloca i1
  %l188 = alloca ptr
  %l193 = alloca i32
  %l194 = alloca i64
  %l196 = alloca ptr
  %l200 = alloca i1
  %l201 = alloca ptr
  %l204 = alloca ptr
  %l209 = alloca i32
  %l210 = alloca i32
  %l211 = alloca { i64, ptr }
  %l212 = alloca { i64, ptr }
  %l214 = alloca i1
  %l215 = alloca ptr
  %l216 = alloca %"compiler/source:Span"
  %l219 = alloca { i64, ptr }
  %l222 = alloca { i64, ptr }
  %l224 = alloca %"compiler/msgs:Msg"
  %l225 = alloca i64
  %l227 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca ptr
  %t83 = alloca { i64, [4 x i64] }, align 8
  %t456 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l3, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  %t3 = load ptr, ptr %l3, !tbaa !29
  %t5 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %t3)
  store i32 %t5, ptr %l18
  br label %bb1
bb1:
  %t6 = load i32, ptr %l18, !tbaa !23
  store i32 %t6, ptr %l6, !tbaa !23
  store i64 0, ptr %l7, !tbaa !24
  store i64 4, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t7 = load i64, ptr %l8, !tbaa !24
  %t8 = load i64, ptr %l7, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l9, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l8, !tbaa !24
  %t18 = load i64, ptr %l7, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l9, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l9, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l25, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l25, !tbaa !24
  store i64 %t33, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l22, !tbaa !24
  store i64 %t34, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l11, !tbaa !24
  %t36 = load i64, ptr %l10, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l7, !tbaa !24
  %t44 = load i64, ptr %l11, !tbaa !24
  %t45 = load i64, ptr %l9, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l12, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i32, ptr %l6, !tbaa !23
  %t57 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t53, i32 %t54)
  store i1 %t57, ptr %l45
  br label %bb12
bb12:
  %t58 = load i1, ptr %l45, !tbaa !21
  %t59 = xor i1 %t58, true
  br i1 %t59, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb14:
  br label %bb15
bb15:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullRead(ptr %v0, ptr %v0, ptr %t61, ptr %t62)
  br label %bb16
bb16:
  %t65 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t65, ptr %l49
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = getelementptr %"compiler/generic:Program", ptr %t69, i32 0, i32 2
  %t72 = load i32, ptr %l6, !tbaa !23
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t71, i32 %t72)
  store i32 %t75, ptr %l54
  br label %bb17
bb17:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load %"compiler/source:Span", ptr %l1
  %t78 = load ptr, ptr %l5, !tbaa !29
  %t82 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t76, %"compiler/source:Span" %t77, ptr %t78)
  store ptr %t82, ptr %l58
  br label %bb18
bb18:
  store { i64, [4 x i64] } zeroinitializer, ptr %t83
  %t84 = getelementptr { i64, [4 x i64] }, ptr %t83, i32 0, i32 0
  store i64 2, ptr %t84
  %t85 = load %"compiler/source:Span", ptr %l49
  %t86 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t85, 0
  %t87 = load i32, ptr %l54, !tbaa !23
  %t88 = insertvalue { %"compiler/source:Span", i32, ptr } %t86, i32 %t87, 1
  %t89 = load ptr, ptr %l58, !tbaa !29
  %t90 = insertvalue { %"compiler/source:Span", i32, ptr } %t88, ptr %t89, 2
  %t91 = getelementptr { i64, [4 x i64] }, ptr %t83, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t90, ptr %t91
  %t92 = load { i64, [4 x i64] }, ptr %t83
  %t94 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t92, ptr %t94
  store ptr %t94, ptr %l5, !tbaa !29
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/check:Checker", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/generic:Program", ptr %t99, i32 0, i32 2
  %t102 = load i32, ptr %l6, !tbaa !23
  %t105 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t101, i32 %t102)
  store i32 %t105, ptr %l65
  br label %bb19
bb19:
  %t106 = load i32, ptr %l65, !tbaa !23
  store i32 %t106, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  %t107 = load i64, ptr %l11, !tbaa !24
  %t109 = add i64 %t107, 1
  store i64 %t109, ptr %l11, !tbaa !24
  br label %bb8
bb21:
  %t111 = load i32, ptr %l6, !tbaa !23
  %t112 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t115 = icmp eq i32 %t111, %t112
  br i1 %t115, label %bb22, label %bb23
bb22:
  store ptr null, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load i32, ptr %l6, !tbaa !23
  %t122 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t118, i32 %t119)
  store i1 %t122, ptr %l74
  br label %bb25
bb25:
  %t123 = load i1, ptr %l74, !tbaa !21
  br i1 %t123, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s6
  %t124 = load ptr, ptr %l0, !tbaa !29
  store ptr %t124, ptr %l75, !tbaa !29
  %t125 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t125, ptr %l76
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load i32, ptr %l6, !tbaa !23
  %t130 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s6, ptr %t126, i32 %t127)
  store { i64, ptr } %t130, ptr %l79
  br label %bb28
bb27:
  br label %bb32
bb28:
  %t131 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t131, 0
  %t133 = extractvalue { i64, ptr } %t131, 1
  %t134 = mul i64 %t132, 1
  %t135 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t134)
  call void @llvm.memcpy.p0.p0.i64(ptr %t135, ptr %t133, i64 %t134, i1 false)
  %t136 = insertvalue { i64, ptr } undef, i64 %t132, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t135, 1
  store { i64, ptr } %t137, ptr %l80, !tbaa !27
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load i32, ptr %l4, !tbaa !23
  %t142 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t138, i32 %t139)
  store { i64, ptr } %t142, ptr %l83
  br label %bb29
bb29:
  %t143 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t144 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t145 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eFieldOfEnum(ptr %s6, ptr %v0, ptr %s6, { i64, ptr } %t143, { i64, ptr } %t144)
  store %"compiler/msgs:Msg" %t145, ptr %l84
  br label %bb30
bb30:
  %t146 = load ptr, ptr %l75, !tbaa !29
  %t147 = load %"compiler/source:Span", ptr %l76
  %t148 = load %"compiler/msgs:Msg", ptr %l84
  %t149 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t146, %"compiler/source:Span" %t147, %"compiler/msgs:Msg" %t148)
  store i64 %t149, ptr %l85
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s6)
  store ptr null, ptr %rv
  br label %ret
bb32:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load i32, ptr %l6, !tbaa !23
  %t155 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t151, i32 %t152)
  store i1 %t155, ptr %l89
  br label %bb33
bb33:
  %t156 = load i1, ptr %l89, !tbaa !21
  %t157 = xor i1 %t156, true
  br i1 %t157, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s7
  %t159 = load ptr, ptr %l0, !tbaa !29
  store ptr %t159, ptr %l91, !tbaa !29
  %t160 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t160, ptr %l92
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load i32, ptr %l6, !tbaa !23
  %t165 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s7, ptr %t161, i32 %t162)
  store { i64, ptr } %t165, ptr %l95
  br label %bb36
bb35:
  br label %bb40
bb36:
  %t166 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t167 = extractvalue { i64, ptr } %t166, 0
  %t168 = extractvalue { i64, ptr } %t166, 1
  %t169 = mul i64 %t167, 1
  %t170 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t169)
  call void @llvm.memcpy.p0.p0.i64(ptr %t170, ptr %t168, i64 %t169, i1 false)
  %t171 = insertvalue { i64, ptr } undef, i64 %t167, 0
  %t172 = insertvalue { i64, ptr } %t171, ptr %t170, 1
  store { i64, ptr } %t172, ptr %l96, !tbaa !27
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i32, ptr %l4, !tbaa !23
  %t177 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t173, i32 %t174)
  store { i64, ptr } %t177, ptr %l99
  br label %bb37
bb37:
  %t178 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t179 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t180 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSuchMember(ptr %s7, ptr %v0, ptr %s7, { i64, ptr } %t178, { i64, ptr } %t179)
  store %"compiler/msgs:Msg" %t180, ptr %l100
  br label %bb38
bb38:
  %t181 = load ptr, ptr %l91, !tbaa !29
  %t182 = load %"compiler/source:Span", ptr %l92
  %t183 = load %"compiler/msgs:Msg", ptr %l100
  %t184 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t181, %"compiler/source:Span" %t182, %"compiler/msgs:Msg" %t183)
  store i64 %t184, ptr %l101
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s7)
  store ptr null, ptr %rv
  br label %ret
bb40:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load i32, ptr %l6, !tbaa !23
  %t188 = load i32, ptr %l4, !tbaa !23
  %t192 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldIndex(ptr %v0, ptr %t186, i32 %t187, i32 %t188)
  store i64 %t192, ptr %l106
  br label %bb41
bb41:
  %t193 = load i64, ptr %l106, !tbaa !24
  store i64 %t193, ptr %l13, !tbaa !24
  %t194 = load i64, ptr %l13, !tbaa !24
  %t196 = icmp slt i64 %t194, 0
  br i1 %t196, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s8
  %t198 = load ptr, ptr %l0, !tbaa !29
  store ptr %t198, ptr %l109, !tbaa !29
  %t199 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t199, ptr %l110
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load i32, ptr %l6, !tbaa !23
  %t204 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s8, ptr %t200, i32 %t201)
  store { i64, ptr } %t204, ptr %l113
  br label %bb44
bb43:
  br label %bb48
bb44:
  %t205 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t206 = extractvalue { i64, ptr } %t205, 0
  %t207 = extractvalue { i64, ptr } %t205, 1
  %t208 = mul i64 %t206, 1
  %t209 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t208)
  call void @llvm.memcpy.p0.p0.i64(ptr %t209, ptr %t207, i64 %t208, i1 false)
  %t210 = insertvalue { i64, ptr } undef, i64 %t206, 0
  %t211 = insertvalue { i64, ptr } %t210, ptr %t209, 1
  store { i64, ptr } %t211, ptr %l114, !tbaa !27
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load i32, ptr %l4, !tbaa !23
  %t216 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t212, i32 %t213)
  store { i64, ptr } %t216, ptr %l117
  br label %bb45
bb45:
  %t217 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t218 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t219 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSuchMember(ptr %s8, ptr %v0, ptr %s8, { i64, ptr } %t217, { i64, ptr } %t218)
  store %"compiler/msgs:Msg" %t219, ptr %l118
  br label %bb46
bb46:
  %t220 = load ptr, ptr %l109, !tbaa !29
  %t221 = load %"compiler/source:Span", ptr %l110
  %t222 = load %"compiler/msgs:Msg", ptr %l118
  %t223 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t220, %"compiler/source:Span" %t221, %"compiler/msgs:Msg" %t222)
  store i64 %t223, ptr %l119
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s8)
  store ptr null, ptr %rv
  br label %ret
bb48:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"compiler/check:Checker", ptr %t225, i32 0, i32 1
  %t228 = load ptr, ptr %t227, !tbaa !29
  %t230 = getelementptr %"compiler/generic:Program", ptr %t228, i32 0, i32 2
  store ptr %t230, ptr %l123, !tbaa !29
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr %"compiler/check:Checker", ptr %t231, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !29
  %t236 = getelementptr %"compiler/generic:Program", ptr %t234, i32 0, i32 2
  %t237 = load i32, ptr %l6, !tbaa !23
  %t240 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t236, i32 %t237)
  store i32 %t240, ptr %l128
  br label %bb49
bb49:
  %t241 = load ptr, ptr %l123, !tbaa !29
  %t242 = load i32, ptr %l128, !tbaa !23
  %t243 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t241, i32 %t242)
  store { i64, ptr } %t243, ptr %l129
  br label %bb50
bb50:
  %t244 = load { i64, ptr }, ptr %l129, !tbaa !27
  store { i64, ptr } %t244, ptr %l14, !tbaa !27
  %t245 = load i64, ptr %l13, !tbaa !24
  %t246 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t248 = extractvalue { i64, ptr } %t246, 0
  %t251 = icmp slt i64 %t245, %t248
  br i1 %t251, label %bb51, label %bb52
bb51:
  %t253 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t253, ptr %l135, !tbaa !27
  %t254 = load i64, ptr %l13, !tbaa !24
  %t256 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t257 = load ptr, ptr %t256, !tbaa !27
  %t258 = getelementptr i32, ptr %t257, i64 %t254
  %t259 = load i32, ptr %t258, !tbaa !33
  %t260 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t263 = icmp eq i32 %t259, %t260
  store i1 %t263, ptr %l134, !tbaa !21
  br label %bb53
bb52:
  store i1 false, ptr %l134, !tbaa !21
  br label %bb53
bb53:
  %t265 = load i1, ptr %l134, !tbaa !21
  br i1 %t265, label %bb54, label %bb55
bb54:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t267 = load i32, ptr %l6, !tbaa !23
  %t270 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ementionsVar(ptr %v0, ptr %t266, i32 %t267, i64 -1)
  store i1 %t270, ptr %l143
  br label %bb56
bb55:
  store i1 false, ptr %l140, !tbaa !21
  br label %bb57
bb56:
  %t271 = load i1, ptr %l143, !tbaa !21
  %t272 = xor i1 %t271, true
  store i1 %t272, ptr %l140, !tbaa !21
  br label %bb57
bb57:
  %t274 = load i1, ptr %l140, !tbaa !21
  br i1 %t274, label %bb58, label %bb59
bb58:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = getelementptr %"compiler/check:Checker", ptr %t275, i32 0, i32 1
  %t278 = load ptr, ptr %t277, !tbaa !29
  %t279 = load i32, ptr %l6, !tbaa !23
  %t282 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t278, i32 %t279)
  store i32 %t282, ptr %l149
  br label %bb60
bb59:
  store i1 false, ptr %l145, !tbaa !21
  br label %bb61
bb60:
  %t283 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t284 = load i32, ptr %l149, !tbaa !23
  %t286 = icmp ne i32 %t284, %t283
  store i1 %t286, ptr %l145, !tbaa !21
  br label %bb61
bb61:
  %t288 = load i1, ptr %l145, !tbaa !21
  br i1 %t288, label %bb62, label %bb63
bb62:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t290 = load i32, ptr %l6, !tbaa !23
  %t293 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %t289, i32 %t290)
  store i64 %t293, ptr %l154
  br label %bb64
bb63:
  br label %bb72
bb64:
  %t294 = load i64, ptr %l154, !tbaa !24
  store i64 %t294, ptr %l15, !tbaa !24
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t297 = getelementptr %"compiler/check:Checker", ptr %t295, i32 0, i32 16
  %t298 = load i64, ptr %l15, !tbaa !24
  %t301 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t297, i64 %t298)
  store i64 %t301, ptr %l158
  br label %bb65
bb65:
  %t302 = load i64, ptr %l158, !tbaa !24
  %t303 = icmp eq i64 %t302, 0
  br i1 %t303, label %bb66, label %bb67
bb66:
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t306 = load i64, ptr %l15, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckNow(ptr %v0, ptr %t305, i64 %t306)
  br label %bb68
bb67:
  br label %bb71
bb68:
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t311 = getelementptr %"compiler/check:Checker", ptr %t309, i32 0, i32 1
  %t312 = load ptr, ptr %t311, !tbaa !29
  %t314 = getelementptr %"compiler/generic:Program", ptr %t312, i32 0, i32 2
  store ptr %t314, ptr %l164, !tbaa !29
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr %"compiler/check:Checker", ptr %t315, i32 0, i32 1
  %t318 = load ptr, ptr %t317, !tbaa !29
  %t320 = getelementptr %"compiler/generic:Program", ptr %t318, i32 0, i32 2
  %t321 = load i32, ptr %l6, !tbaa !23
  %t324 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t320, i32 %t321)
  store i32 %t324, ptr %l169
  br label %bb69
bb69:
  %t325 = load ptr, ptr %l164, !tbaa !29
  %t326 = load i32, ptr %l169, !tbaa !23
  %t327 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t325, i32 %t326)
  store { i64, ptr } %t327, ptr %l170
  br label %bb70
bb70:
  %t328 = load { i64, ptr }, ptr %l170, !tbaa !27
  store { i64, ptr } %t328, ptr %l14, !tbaa !27
  br label %bb71
bb71:
  br label %bb72
bb72:
  %t329 = load i64, ptr %l13, !tbaa !24
  %t330 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t332 = extractvalue { i64, ptr } %t330, 0
  %t335 = icmp sge i64 %t329, %t332
  br i1 %t335, label %bb73, label %bb74
bb73:
  store %olang.scope zeroinitializer, ptr %s11
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t338 = load %"compiler/source:Span", ptr %l2
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s11, ptr %t337, %"compiler/source:Span" %t338, { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d22, i32 0, i32 1) })
  br label %bb75
bb74:
  br label %bb76
bb75:
  call void @__olang_scope_close(ptr %s11)
  store ptr null, ptr %rv
  br label %ret
bb76:
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t343 = load i32, ptr %l4, !tbaa !23
  %t346 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t342, i32 %t343)
  store { i64, ptr } %t346, ptr %l180
  br label %bb77
bb77:
  %t347 = load { i64, ptr }, ptr %l180, !tbaa !27
  store { i64, ptr } %t347, ptr %l181, !tbaa !27
  %t348 = getelementptr { i64, ptr }, ptr %l181, i32 0, i32 1
  %t349 = load ptr, ptr %t348, !tbaa !27
  %t350 = getelementptr i8, ptr %t349, i64 0
  %t351 = load i8, ptr %t350, !tbaa !32
  %t353 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t351)
  store i1 %t353, ptr %l183
  br label %bb78
bb78:
  %t354 = load i1, ptr %l183, !tbaa !21
  %t355 = xor i1 %t354, true
  br i1 %t355, label %bb79, label %bb80
bb79:
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t359 = getelementptr %"compiler/check:Checker", ptr %t357, i32 0, i32 1
  %t360 = load ptr, ptr %t359, !tbaa !29
  %t362 = getelementptr %"compiler/generic:Program", ptr %t360, i32 0, i32 2
  store ptr %t362, ptr %l188, !tbaa !29
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t365 = getelementptr %"compiler/check:Checker", ptr %t363, i32 0, i32 1
  %t366 = load ptr, ptr %t365, !tbaa !29
  %t368 = getelementptr %"compiler/generic:Program", ptr %t366, i32 0, i32 2
  %t369 = load i32, ptr %l6, !tbaa !23
  %t372 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t368, i32 %t369)
  store i32 %t372, ptr %l193
  br label %bb81
bb80:
  store i1 false, ptr %l185, !tbaa !21
  br label %bb84
bb81:
  %t373 = load ptr, ptr %l188, !tbaa !29
  %t374 = load i32, ptr %l193, !tbaa !23
  %t375 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t373, i32 %t374)
  store i64 %t375, ptr %l194
  br label %bb82
bb82:
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t378 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t376)
  store ptr %t378, ptr %l196
  br label %bb83
bb83:
  %t379 = load ptr, ptr %l196, !tbaa !29
  %t381 = getelementptr %"compiler/check:frame", ptr %t379, i32 0, i32 1
  %t382 = load i64, ptr %t381, !tbaa !24
  %t383 = load i64, ptr %l194, !tbaa !24
  %t385 = icmp ne i64 %t383, %t382
  store i1 %t385, ptr %l185, !tbaa !21
  br label %bb84
bb84:
  %t387 = load i1, ptr %l185, !tbaa !21
  br i1 %t387, label %bb85, label %bb86
bb85:
  %t388 = load ptr, ptr %l0, !tbaa !29
  store ptr %t388, ptr %l201, !tbaa !29
  %t389 = load ptr, ptr %l0, !tbaa !29
  %t391 = getelementptr %"compiler/check:Checker", ptr %t389, i32 0, i32 1
  %t392 = load ptr, ptr %t391, !tbaa !29
  %t394 = getelementptr %"compiler/generic:Program", ptr %t392, i32 0, i32 2
  store ptr %t394, ptr %l204, !tbaa !29
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t397 = getelementptr %"compiler/check:Checker", ptr %t395, i32 0, i32 1
  %t398 = load ptr, ptr %t397, !tbaa !29
  %t400 = getelementptr %"compiler/generic:Program", ptr %t398, i32 0, i32 2
  %t401 = load i32, ptr %l6, !tbaa !23
  %t404 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t400, i32 %t401)
  store i32 %t404, ptr %l209
  br label %bb87
bb86:
  store i1 false, ptr %l200, !tbaa !21
  br label %bb91
bb87:
  %t405 = load ptr, ptr %l204, !tbaa !29
  %t406 = load i32, ptr %l209, !tbaa !23
  %t407 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t405, i32 %t406)
  store i32 %t407, ptr %l210
  br label %bb88
bb88:
  %t408 = load ptr, ptr %l201, !tbaa !29
  %t409 = load i32, ptr %l210, !tbaa !23
  %t410 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t408, i32 %t409)
  store { i64, ptr } %t410, ptr %l211
  br label %bb89
bb89:
  %t411 = load { i64, ptr }, ptr %l211, !tbaa !27
  store { i64, ptr } %t411, ptr %l212, !tbaa !27
  %t412 = getelementptr { i64, ptr }, ptr %l212, i32 0, i32 1
  %t413 = load ptr, ptr %t412, !tbaa !27
  %t414 = getelementptr i8, ptr %t413, i64 0
  %t415 = load i8, ptr %t414, !tbaa !32
  %t417 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t415)
  store i1 %t417, ptr %l214
  br label %bb90
bb90:
  %t418 = load i1, ptr %l214, !tbaa !21
  store i1 %t418, ptr %l200, !tbaa !21
  br label %bb91
bb91:
  %t419 = load i1, ptr %l200, !tbaa !21
  br i1 %t419, label %bb92, label %bb93
bb92:
  store %olang.scope zeroinitializer, ptr %s12
  %t420 = load ptr, ptr %l0, !tbaa !29
  store ptr %t420, ptr %l215, !tbaa !29
  %t421 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t421, ptr %l216
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t423 = load i32, ptr %l4, !tbaa !23
  %t426 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t422, i32 %t423)
  store { i64, ptr } %t426, ptr %l219
  br label %bb94
bb93:
  br label %bb98
bb94:
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t428 = load i32, ptr %l6, !tbaa !23
  %t431 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s12, ptr %t427, i32 %t428)
  store { i64, ptr } %t431, ptr %l222
  br label %bb95
bb95:
  %t432 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t433 = extractvalue { i64, ptr } %t432, 0
  %t434 = extractvalue { i64, ptr } %t432, 1
  %t435 = mul i64 %t433, 1
  %t436 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t435)
  call void @llvm.memcpy.p0.p0.i64(ptr %t436, ptr %t434, i64 %t435, i1 false)
  %t437 = insertvalue { i64, ptr } undef, i64 %t433, 0
  %t438 = insertvalue { i64, ptr } %t437, ptr %t436, 1
  %t439 = load { i64, ptr }, ptr %l219, !tbaa !27
  %t441 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMemberIsPrivate(ptr %v0, ptr %s12, ptr %s12, { i64, ptr } %t439, { i64, ptr } %t438)
  store %"compiler/msgs:Msg" %t441, ptr %l224
  br label %bb96
bb96:
  %t442 = load ptr, ptr %l215, !tbaa !29
  %t443 = load %"compiler/source:Span", ptr %l216
  %t444 = load %"compiler/msgs:Msg", ptr %l224
  %t445 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s12, ptr %t442, %"compiler/source:Span" %t443, %"compiler/msgs:Msg" %t444)
  store i64 %t445, ptr %l225
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s12)
  br label %bb98
bb98:
  %t446 = load %"compiler/source:Span", ptr %l1
  %t447 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t447, ptr %l227, !tbaa !27
  %t448 = load i64, ptr %l13, !tbaa !24
  %t450 = getelementptr { i64, ptr }, ptr %l227, i32 0, i32 1
  %t451 = load ptr, ptr %t450, !tbaa !27
  %t452 = getelementptr i32, ptr %t451, i64 %t448
  %t453 = load i32, ptr %t452, !tbaa !33
  %t454 = load ptr, ptr %l5, !tbaa !29
  %t455 = load i64, ptr %l13, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t456
  %t457 = getelementptr { i64, [4 x i64] }, ptr %t456, i32 0, i32 0
  store i64 3, ptr %t457
  %t459 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t446, 0
  %t461 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t459, i32 %t453, 1
  %t463 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t461, ptr %t454, 2
  %t465 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t463, i64 %t455, 3
  %t466 = getelementptr { i64, [4 x i64] }, ptr %t456, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t465, ptr %t466
  %t467 = load { i64, [4 x i64] }, ptr %t456
  %t469 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t467, ptr %t469
  store ptr %t469, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnBody(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l17 = alloca i64
  %l21 = alloca i32
  %l22 = alloca ptr
  %l24 = alloca { i64, [2 x i64] }
  %l25 = alloca i32
  %l29 = alloca i64
  %l33 = alloca ptr
  %l36 = alloca i64
  %l43 = alloca i1
  %rv = alloca i64
  %t40 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 17
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l10
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11
ok.11:
  store i64 %t8, ptr %l9
  br label %bb1
bb1:
  %t12 = load i64, ptr %l9, !tbaa !24
  store i64 %t12, ptr %l5, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l5, !tbaa !24
  store i64 %t13, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp sge i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load i64, ptr %l2, !tbaa !24
  store i64 %t18, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t24 = load i64, ptr %l1, !tbaa !24
  %t27 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t23, i64 %t24)
  store i64 %t27, ptr %l17
  br label %bb8
bb8:
  %t28 = load i64, ptr %l17, !tbaa !24
  store i64 %t28, ptr %l3, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t33 = load i64, ptr %l1, !tbaa !24
  %t36 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %t32, i64 %t33)
  store i32 %t36, ptr %l21
  br label %bb9
bb9:
  %t37 = load i32, ptr %l21, !tbaa !23
  store i32 %t37, ptr %l4, !tbaa !23
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l22, !tbaa !29
  %t39 = load i64, ptr %l1, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t40
  %t41 = getelementptr { i64, [2 x i64] }, ptr %t40, i32 0, i32 0
  store i64 0, ptr %t41
  %t43 = insertvalue { i64 } undef, i64 %t39, 0
  %t44 = getelementptr { i64, [2 x i64] }, ptr %t40, i32 0, i32 1
  store { i64 } %t43, ptr %t44
  %t45 = load { i64, [2 x i64] }, ptr %t40
  store { i64, [2 x i64] } %t45, ptr %l24
  %t46 = load i32, ptr %l4, !tbaa !23
  store i32 %t46, ptr %l25, !tbaa !23
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t51 = load i64, ptr %l3, !tbaa !24
  %t54 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t50, i64 %t51)
  store i64 %t54, ptr %l29
  br label %bb10
bb10:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  %t62 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t58, i64 %t59)
  store ptr %t62, ptr %l33
  br label %bb11
bb11:
  %t63 = load ptr, ptr %l33, !tbaa !29
  %t65 = getelementptr %"compiler/ast:Func", ptr %t63, i32 0, i32 0
  %t66 = load %"compiler/source:Span", ptr %t65
  %t67 = load ptr, ptr %l22, !tbaa !29
  %t68 = load { i64, [2 x i64] }, ptr %l24
  %t69 = load i32, ptr %l25, !tbaa !23
  %t70 = load i64, ptr %l29, !tbaa !24
  %t72 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t67, { i64, [2 x i64] } %t68, i32 %t69, i64 %t70, %"compiler/source:Span" %t66)
  store i64 %t72, ptr %l36
  br label %bb12
bb12:
  %t73 = load i64, ptr %l36, !tbaa !24
  store i64 %t73, ptr %l2, !tbaa !24
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t74, i32 0, i32 17
  %t77 = load i64, ptr %l1, !tbaa !24
  %t78 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t76, i64 %t77, i64 %t78)
  br label %bb13
bb13:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i32, ptr %l4, !tbaa !23
  %t86 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %t82, i32 %t83)
  store i1 %t86, ptr %l43
  br label %bb14
bb14:
  %t87 = load i1, ptr %l43, !tbaa !21
  br i1 %t87, label %bb15, label %bb16
bb15:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/check:Checker", ptr %t88, i32 0, i32 49
  %t91 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t90, i64 %t91, i1 true)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  %t94 = load i64, ptr %l2, !tbaa !24
  store i64 %t94, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalDeps(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l6 = alloca %"compiler/check:b5aWalk"
  %l11 = alloca i1
  %l12 = alloca i64
  %l14 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l21 = alloca i64
  %s1 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call %"compiler/check:b5aWalk" @compiler_2fcheck_3ab5aWalk_2ector(ptr %v1, i64 %a1)
  store %"compiler/check:b5aWalk" %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 56, i64 8)
  store ptr %t4, ptr %lp3
  %t5 = load %"compiler/check:b5aWalk", ptr %l6
  %t6 = load ptr, ptr %lp3
  store %"compiler/check:b5aWalk" %t5, ptr %t6
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load ptr, ptr %lp3
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aInit(ptr %v0, ptr %v1, ptr %t7, ptr %t8, i64 %a2)
  br label %bb2
bb2:
  store i64 0, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = load ptr, ptr %lp3
  %t14 = getelementptr %"compiler/check:b5aWalk", ptr %t13, i32 0, i32 7
  %t15 = load i1, ptr %t14, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  %t17 = load i64, ptr %l4, !tbaa !24
  store i64 %t17, ptr %l12, !tbaa !24
  %t18 = load ptr, ptr %lp3
  %t19 = getelementptr %"compiler/check:b5aWalk", ptr %t18, i32 0, i32 2
  %t21 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t19)
  store i64 %t21, ptr %l14
  br label %bb6
bb5:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb7
bb6:
  %t22 = load i64, ptr %l12, !tbaa !24
  %t23 = load i64, ptr %l14, !tbaa !24
  %t24 = icmp slt i64 %t22, %t23
  store i1 %t24, ptr %l11, !tbaa !21
  br label %bb7
bb7:
  %t26 = load i1, ptr %l11, !tbaa !21
  %t27 = xor i1 %t26, true
  br i1 %t27, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb14
bb9:
  br label %bb10
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l17, !tbaa !29
  %t30 = load ptr, ptr %lp3
  store ptr %t30, ptr %l18, !tbaa !29
  %t31 = load ptr, ptr %lp3
  %t32 = getelementptr %"compiler/check:b5aWalk", ptr %t31, i32 0, i32 2
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t32, i64 %t33)
  store i64 %t36, ptr %l21
  br label %bb11
bb11:
  %t37 = load ptr, ptr %l17, !tbaa !29
  %t38 = load ptr, ptr %l18, !tbaa !29
  %t39 = load i64, ptr %l21, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aFn(ptr %v0, ptr %v1, ptr %t37, ptr %t38, i64 %t39)
  br label %bb12
bb12:
  %t40 = load i64, ptr %l4, !tbaa !24
  %t42 = add i64 %t40, 1
  store i64 %t42, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb13
bb13:
  br label %bb3
bb14:
  %t44 = load ptr, ptr %lp3
  %t45 = getelementptr %"compiler/check:b5aWalk", ptr %t44, i32 0, i32 3
  %t46 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t45
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t46, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehandlesContracts(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i32
  %l19 = alloca i1
  %l23 = alloca i32
  %l29 = alloca i64
  %l33 = alloca i64
  %l36 = alloca i64
  %l57 = alloca i64
  %l59 = alloca ptr
  %l63 = alloca i1
  %l67 = alloca %"compiler/check:ContractAsk"
  %l69 = alloca i1
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %t109 = alloca %"compiler/check:ContractAsk", align 8
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eL_H39694dc3b7c161b4999ab170e8f3fd84(ptr %v1, ptr %t1)
  store i64 %t3, ptr %l11
  br label %bb1
bb1:
  %t4 = load i64, ptr %l11, !tbaa !24
  %t5 = icmp eq i64 %t4, 0
  br i1 %t5, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s0, ptr %s0, ptr %t10, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d23, i32 0, i32 1) }, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d24, i32 0, i32 1) })
  store i32 %t12, ptr %l15
  br label %bb5
bb5:
  %t13 = load i32, ptr %l15, !tbaa !23
  store i32 %t13, ptr %l3, !tbaa !23
  %t14 = load i32, ptr %l3, !tbaa !23
  %t15 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t18 = icmp eq i32 %t14, %t15
  br i1 %t18, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb9
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l3, !tbaa !23
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t26 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleft(ptr %v0, ptr %v1, ptr %t20, i32 %t21, ptr %t22)
  store i32 %t26, ptr %l23
  br label %bb8
bb8:
  %t27 = load i32, ptr %l3, !tbaa !23
  %t28 = load i32, ptr %l23, !tbaa !23
  %t30 = icmp eq i32 %t28, %t27
  store i1 %t30, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t32 = load i1, ptr %l19, !tbaa !21
  br i1 %t32, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb11:
  br label %bb12
bb12:
  store i64 %a1, ptr %l4, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 82
  %t39 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aContractAsk_3e_2_Hb6ae083c0cacd8c0f7c4b8758a199876(ptr %v0, ptr %t37)
  store i64 %t39, ptr %l29
  br label %bb13
bb13:
  %t40 = load i64, ptr %l29, !tbaa !24
  store i64 %t40, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t42 = load i64, ptr %l4, !tbaa !24
  %t45 = icmp sgt i64 %t41, %t42
  br i1 %t45, label %bb14, label %bb15
bb14:
  %t47 = load i64, ptr %l6, !tbaa !24
  %t49 = icmp sgt i64 %t47, 0
  br i1 %t49, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb19
bb16:
  %t51 = load i64, ptr %l5, !tbaa !24
  %t52 = load i64, ptr %l4, !tbaa !24
  %t55 = sub i64 %t51, %t52
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = add i64 %t55, %t56
  %t61 = sub i64 %t59, 1
  %t62 = load i64, ptr %l6, !tbaa !24
  %t65 = sdiv i64 %t61, %t62
  store i64 %t65, ptr %l36, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb18
bb18:
  %t67 = load i64, ptr %l36, !tbaa !24
  store i64 %t67, ptr %l33, !tbaa !24
  br label %bb19
bb19:
  %t68 = load i64, ptr %l33, !tbaa !24
  store i64 %t68, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s4
  %t69 = load i64, ptr %l8, !tbaa !24
  %t70 = load i64, ptr %l7, !tbaa !24
  %t73 = icmp slt i64 %t69, %t70
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s4)
  br label %bb36
bb22:
  br label %bb23
bb23:
  %t77 = load i64, ptr %l4, !tbaa !24
  %t78 = load i64, ptr %l8, !tbaa !24
  %t79 = load i64, ptr %l6, !tbaa !24
  %t82 = mul i64 %t78, %t79
  %t85 = add i64 %t77, %t82
  store i64 %t85, ptr %l9, !tbaa !24
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/check:Checker", ptr %t87, i32 0, i32 83
  %t90 = load i64, ptr %l9, !tbaa !24
  %t93 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t89, i64 %t90)
  store i64 %t93, ptr %l57
  br label %bb24
bb24:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t94)
  store ptr %t96, ptr %l59
  br label %bb25
bb25:
  %t97 = load ptr, ptr %l59, !tbaa !29
  %t99 = getelementptr %"compiler/check:frame", ptr %t97, i32 0, i32 0
  %t100 = load i64, ptr %t99, !tbaa !24
  %t101 = load i64, ptr %l57, !tbaa !24
  %t103 = icmp eq i64 %t101, %t100
  br i1 %t103, label %bb26, label %bb27
bb26:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/check:Checker", ptr %t105, i32 0, i32 82
  %t108 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aContractAsk_3e_2_H588006d0a62537be0708297bfbeb4a05(ptr %t109, ptr %v0, ptr %v0, ptr %t107, i64 %t108)
  call void @llvm.memmove.p0.p0.i64(ptr %l67, ptr %t109, i64 136, i1 false)
  br label %bb28
bb27:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb30
bb28:
  %t112 = getelementptr %"compiler/check:ContractAsk", ptr %l67, i32 0, i32 5
  %t113 = load { i64, ptr }, ptr %t112, !tbaa !27
  %t115 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t113, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d25, i32 0, i32 1) })
  store i1 %t115, ptr %l69
  br label %bb29
bb29:
  %t116 = load i1, ptr %l69, !tbaa !21
  %t117 = xor i1 %t116, true
  store i1 %t117, ptr %l63, !tbaa !21
  br label %bb30
bb30:
  %t119 = load i1, ptr %l63, !tbaa !21
  br i1 %t119, label %bb31, label %bb32
bb31:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/check:Checker", ptr %t120, i32 0, i32 84
  %t123 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t122, i64 %t123, i1 true)
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s4)
  br label %bb35
bb35:
  %t126 = load i64, ptr %l8, !tbaa !24
  %t128 = add i64 %t126, 1
  store i64 %t128, ptr %l8, !tbaa !24
  br label %bb20
bb36:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritableAt(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i32
  %l7 = alloca i1
  %l16 = alloca i32
  %l23 = alloca i64
  %l27 = alloca i1
  %l36 = alloca i32
  %l39 = alloca ptr
  %l44 = alloca i32
  %l47 = alloca i1
  %l52 = alloca ptr
  %l57 = alloca i32
  %l59 = alloca i1
  %l62 = alloca ptr
  %l67 = alloca i32
  %l69 = alloca i1
  %l75 = alloca i1
  %l80 = alloca i32
  %l83 = alloca ptr
  %l88 = alloca i32
  %l90 = alloca i1
  %l93 = alloca ptr
  %l98 = alloca i32
  %l100 = alloca i1
  %l103 = alloca ptr
  %l108 = alloca i32
  %l111 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  store i1 %t9, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l7, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l16
  br label %bb7
bb7:
  %t23 = load i32, ptr %l16
  store i32 %t23, ptr %l3
  %t24 = load i32, ptr %l3
  %t26 = trunc i64 20 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb15
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load i32, ptr %l1, !tbaa !23
  %t38 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t34, i32 %t35)
  store i64 %t38, ptr %l23
  br label %bb11
bb11:
  %t39 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t40 = load i64, ptr %l23, !tbaa !24
  %t42 = and i64 %t40, %t39
  %t44 = icmp ne i64 %t42, 0
  br i1 %t44, label %bb12, label %bb13
bb12:
  %t46 = load i64, ptr %l2, !tbaa !24
  %t48 = icmp sgt i64 %t46, 0
  store i1 %t48, ptr %l27, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb14
bb14:
  %t50 = load i1, ptr %l27, !tbaa !21
  store i1 %t50, ptr %rv
  br label %ret
bb15:
  %t51 = load i32, ptr %l3
  %t53 = trunc i64 19 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb25
bb18:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  %t62 = load i32, ptr %l1, !tbaa !23
  %t65 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t61, i32 %t62)
  store i32 %t65, ptr %l36
  br label %bb19
bb19:
  %t66 = load i32, ptr %l36, !tbaa !23
  %t67 = icmp eq i32 %t66, 0
  br i1 %t67, label %bb20, label %bb21
bb20:
  store i1 false, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l39, !tbaa !29
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 2
  %t77 = load i32, ptr %l1, !tbaa !23
  %t80 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t76, i32 %t77)
  store i32 %t80, ptr %l44
  br label %bb23
bb23:
  %t81 = load i64, ptr %l2, !tbaa !24
  %t83 = add i64 %t81, 1
  %t84 = load ptr, ptr %l39, !tbaa !29
  %t85 = load i32, ptr %l44, !tbaa !23
  %t87 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritableAt(ptr %v0, ptr %t84, i32 %t85, i64 %t83)
  store i1 %t87, ptr %l47
  br label %bb24
bb24:
  %t88 = load i1, ptr %l47, !tbaa !21
  store i1 %t88, ptr %rv
  br label %ret
bb25:
  %t89 = load i32, ptr %l3
  %t91 = trunc i64 22 to i32
  %t92 = icmp eq i32 %t89, %t91
  br i1 %t92, label %bb26, label %bb27
bb26:
  br label %bb30
bb27:
  %t94 = load i32, ptr %l3
  %t96 = trunc i64 23 to i32
  %t97 = icmp eq i32 %t94, %t96
  br i1 %t97, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb33
bb30:
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l52, !tbaa !29
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/check:Checker", ptr %t100, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = getelementptr %"compiler/generic:Program", ptr %t103, i32 0, i32 2
  %t106 = load i32, ptr %l1, !tbaa !23
  %t109 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t105, i32 %t106)
  store i32 %t109, ptr %l57
  br label %bb31
bb31:
  %t110 = load i64, ptr %l2, !tbaa !24
  %t111 = load ptr, ptr %l52, !tbaa !29
  %t112 = load i32, ptr %l57, !tbaa !23
  %t114 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsWritable(ptr %v0, ptr %t111, i32 %t112, i64 %t110)
  store i1 %t114, ptr %l59
  br label %bb32
bb32:
  %t115 = load i1, ptr %l59, !tbaa !21
  store i1 %t115, ptr %rv
  br label %ret
bb33:
  %t116 = load i32, ptr %l3
  %t118 = trunc i64 24 to i32
  %t119 = icmp eq i32 %t116, %t118
  br i1 %t119, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb39
bb36:
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l62, !tbaa !29
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/check:Checker", ptr %t122, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !29
  %t127 = getelementptr %"compiler/generic:Program", ptr %t125, i32 0, i32 2
  %t128 = load i32, ptr %l1, !tbaa !23
  %t131 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t127, i32 %t128)
  store i32 %t131, ptr %l67
  br label %bb37
bb37:
  %t132 = load i64, ptr %l2, !tbaa !24
  %t133 = load ptr, ptr %l62, !tbaa !29
  %t134 = load i32, ptr %l67, !tbaa !23
  %t136 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsWritable(ptr %v0, ptr %t133, i32 %t134, i64 %t132)
  store i1 %t136, ptr %l69
  br label %bb38
bb38:
  %t137 = load i1, ptr %l69, !tbaa !21
  store i1 %t137, ptr %rv
  br label %ret
bb39:
  %t138 = load i32, ptr %l3
  %t140 = trunc i64 18 to i32
  %t141 = icmp eq i32 %t138, %t140
  br i1 %t141, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb63
bb42:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/check:Checker", ptr %t143, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t147 = load i32, ptr %l1, !tbaa !23
  %t150 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t146, i32 %t147)
  store i1 %t150, ptr %l75
  br label %bb43
bb43:
  %t151 = load i1, ptr %l75, !tbaa !21
  %t152 = xor i1 %t151, true
  br i1 %t152, label %bb44, label %bb45
bb44:
  store i1 false, ptr %rv
  br label %ret
bb45:
  br label %bb46
bb46:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load i32, ptr %l1, !tbaa !23
  %t159 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t155, i32 %t156)
  store i32 %t159, ptr %l80
  br label %bb47
bb47:
  %t160 = load i32, ptr %l80
  store i32 %t160, ptr %l4
  %t161 = load i32, ptr %l4
  %t163 = trunc i64 0 to i32
  %t164 = icmp eq i32 %t161, %t163
  br i1 %t164, label %bb48, label %bb49
bb48:
  %t166 = load ptr, ptr %l0, !tbaa !29
  store ptr %t166, ptr %l83, !tbaa !29
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/check:Checker", ptr %t167, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t172 = getelementptr %"compiler/generic:Program", ptr %t170, i32 0, i32 2
  %t173 = load i32, ptr %l1, !tbaa !23
  %t176 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t172, i32 %t173)
  store i32 %t176, ptr %l88
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t177 = load i64, ptr %l2, !tbaa !24
  %t178 = load ptr, ptr %l83, !tbaa !29
  %t179 = load i32, ptr %l88, !tbaa !23
  %t181 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsWritable(ptr %v0, ptr %t178, i32 %t179, i64 %t177)
  store i1 %t181, ptr %l90
  br label %bb51
bb51:
  %t182 = load i1, ptr %l90, !tbaa !21
  store i1 %t182, ptr %rv
  br label %ret
bb52:
  %t183 = load i32, ptr %l4
  %t185 = trunc i64 1 to i32
  %t186 = icmp eq i32 %t183, %t185
  br i1 %t186, label %bb53, label %bb54
bb53:
  %t188 = load ptr, ptr %l0, !tbaa !29
  store ptr %t188, ptr %l93, !tbaa !29
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/check:Checker", ptr %t189, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t194 = getelementptr %"compiler/generic:Program", ptr %t192, i32 0, i32 2
  %t195 = load i32, ptr %l1, !tbaa !23
  %t198 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t194, i32 %t195)
  store i32 %t198, ptr %l98
  br label %bb55
bb54:
  br label %bb57
bb55:
  %t199 = load i64, ptr %l2, !tbaa !24
  %t200 = load ptr, ptr %l93, !tbaa !29
  %t201 = load i32, ptr %l98, !tbaa !23
  %t203 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsWritable(ptr %v0, ptr %t200, i32 %t201, i64 %t199)
  store i1 %t203, ptr %l100
  br label %bb56
bb56:
  %t204 = load i1, ptr %l100, !tbaa !21
  store i1 %t204, ptr %rv
  br label %ret
bb57:
  %t205 = load i32, ptr %l4
  %t207 = trunc i64 4 to i32
  %t208 = icmp eq i32 %t205, %t207
  br i1 %t208, label %bb58, label %bb59
bb58:
  %t210 = load ptr, ptr %l0, !tbaa !29
  store ptr %t210, ptr %l103, !tbaa !29
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/check:Checker", ptr %t211, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t216 = getelementptr %"compiler/generic:Program", ptr %t214, i32 0, i32 2
  %t217 = load i32, ptr %l1, !tbaa !23
  %t220 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t216, i32 %t217)
  store i32 %t220, ptr %l108
  br label %bb60
bb59:
  br label %bb62
bb60:
  %t221 = load i64, ptr %l2, !tbaa !24
  %t223 = add i64 %t221, 1
  %t224 = load ptr, ptr %l103, !tbaa !29
  %t225 = load i32, ptr %l108, !tbaa !23
  %t227 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritableAt(ptr %v0, ptr %t224, i32 %t225, i64 %t223)
  store i1 %t227, ptr %l111
  br label %bb61
bb61:
  %t228 = load i1, ptr %l111, !tbaa !21
  store i1 %t228, ptr %rv
  br label %ret
bb62:
  store i1 false, ptr %rv
  br label %ret
bb63:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferred(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca i32
  %l7 = alloca i32
  %l11 = alloca ptr
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca %"compiler/msgs:Msg"
  %l16 = alloca i64
  %l21 = alloca ptr
  %l23 = alloca %"compiler/source:Span"
  %l24 = alloca %"compiler/msgs:Msg"
  %l25 = alloca i64
  %l30 = alloca ptr
  %l32 = alloca %"compiler/source:Span"
  %l33 = alloca %"compiler/msgs:Msg"
  %l34 = alloca i64
  %l38 = alloca i1
  %l39 = alloca i1
  %l44 = alloca i32
  %l46 = alloca i32
  %l48 = alloca ptr
  %l49 = alloca i1
  %l53 = alloca i32
  %l58 = alloca i32
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t1)
  store i32 %t4, ptr %l7
  br label %bb1
bb1:
  %t5 = load i32, ptr %l7, !tbaa !23
  store i32 %t5, ptr %l4, !tbaa !23
  %t6 = load i32, ptr %l4, !tbaa !23
  %t7 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t10 = icmp eq i32 %t6, %t7
  br i1 %t10, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l11, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t17 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeSpan(ptr %v0, ptr %v1, ptr %t13, ptr %t14)
  store %"compiler/source:Span" %t17, ptr %l14
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t18 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeclFromNoreturn(ptr %s1)
  store %"compiler/msgs:Msg" %t18, ptr %l15
  br label %bb5
bb5:
  %t19 = load ptr, ptr %l11, !tbaa !29
  %t20 = load %"compiler/source:Span", ptr %l14
  %t21 = load %"compiler/msgs:Msg", ptr %l15
  %t22 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t19, %"compiler/source:Span" %t20, %"compiler/msgs:Msg" %t21)
  store i64 %t22, ptr %l16
  br label %bb6
bb6:
  %t23 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  store i32 %t23, ptr %rv
  br label %ret
bb7:
  %t25 = load i32, ptr %l4, !tbaa !23
  %t26 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t29 = icmp eq i32 %t25, %t26
  br i1 %t29, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l21, !tbaa !29
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t32)
  store %"compiler/source:Span" %t34, ptr %l23
  br label %bb10
bb9:
  br label %bb13
bb10:
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeclFromNull(ptr %s2)
  store %"compiler/msgs:Msg" %t35, ptr %l24
  br label %bb11
bb11:
  %t36 = load ptr, ptr %l21, !tbaa !29
  %t37 = load %"compiler/source:Span", ptr %l23
  %t38 = load %"compiler/msgs:Msg", ptr %l24
  %t39 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t36, %"compiler/source:Span" %t37, %"compiler/msgs:Msg" %t38)
  store i64 %t39, ptr %l25
  br label %bb12
bb12:
  %t40 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  store i32 %t40, ptr %rv
  br label %ret
bb13:
  %t42 = load i32, ptr %l4, !tbaa !23
  %t43 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t46 = icmp eq i32 %t42, %t43
  br i1 %t46, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l30, !tbaa !29
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t49)
  store %"compiler/source:Span" %t51, ptr %l32
  br label %bb16
bb15:
  br label %bb19
bb16:
  %t52 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeNotInferable(ptr %s3)
  store %"compiler/msgs:Msg" %t52, ptr %l33
  br label %bb17
bb17:
  %t53 = load ptr, ptr %l30, !tbaa !29
  %t54 = load %"compiler/source:Span", ptr %l32
  %t55 = load %"compiler/msgs:Msg", ptr %l33
  %t56 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t53, %"compiler/source:Span" %t54, %"compiler/msgs:Msg" %t55)
  store i64 %t56, ptr %l34
  br label %bb18
bb18:
  %t57 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s3)
  store i32 %t57, ptr %rv
  br label %ret
bb19:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i32, ptr %l4, !tbaa !23
  %t63 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t59, i32 %t60)
  store i1 %t63, ptr %l38
  br label %bb20
bb20:
  %t64 = load i1, ptr %l38, !tbaa !21
  br i1 %t64, label %bb21, label %bb22
bb21:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Program", ptr %t68, i32 0, i32 2
  %t71 = load i32, ptr %l4, !tbaa !23
  %t74 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t74, ptr %l44
  br label %bb23
bb22:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb25
bb23:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t75)
  store i32 %t77, ptr %l46
  br label %bb24
bb24:
  %t78 = load i32, ptr %l44, !tbaa !23
  %t79 = load i32, ptr %l46, !tbaa !23
  %t80 = icmp eq i32 %t78, %t79
  store i1 %t80, ptr %l39, !tbaa !21
  br label %bb25
bb25:
  %t82 = load i1, ptr %l39, !tbaa !21
  br i1 %t82, label %bb26, label %bb27
bb26:
  %t83 = load ptr, ptr %l2, !tbaa !29
  store ptr %t83, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t84 = load ptr, ptr %l48, !tbaa !29
  %t85 = icmp ne ptr %t84, null
  br i1 %t85, label %bb28, label %bb29
bb27:
  br label %bb36
bb28:
  %t87 = load ptr, ptr %l48, !tbaa !29
  %t88 = load i64, ptr %t87
  %t90 = icmp eq i64 %t88, 1
  store i1 %t90, ptr %l49, !tbaa !21
  br label %bb29
bb29:
  %t91 = load i1, ptr %l49, !tbaa !21
  br i1 %t91, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t92)
  store i32 %t94, ptr %l53
  br label %bb33
bb33:
  %t95 = load i32, ptr %l53, !tbaa !23
  store i32 %t95, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t98 = xor i1 %a3, true
  br i1 %t98, label %bb37, label %bb38
bb37:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load i32, ptr %l4, !tbaa !23
  %t104 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %t100, i32 %t101)
  store i32 %t104, ptr %l58
  br label %bb39
bb38:
  br label %bb40
bb39:
  %t105 = load i32, ptr %l58, !tbaa !23
  store i32 %t105, ptr %rv
  br label %ret
bb40:
  %t106 = load i32, ptr %l4, !tbaa !23
  store i32 %t106, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i64
  %l10 = alloca i64
  %l16 = alloca ptr
  %l19 = alloca i1
  %l25 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca { i64, ptr }
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l7, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 11
  %t10 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l10
  br label %bb3
bb3:
  %t11 = load i64, ptr %l7, !tbaa !24
  %t12 = load i64, ptr %l10, !tbaa !24
  %t13 = icmp sge i64 %t11, %t12
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l6, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 11
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t19, i64 %t20)
  store ptr %t23, ptr %l16
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l16, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Body", ptr %t24, i32 0, i32 1
  %t27 = load { i64, [2 x i64] }, ptr %t26
  store { i64, [2 x i64] } %t27, ptr %l2
  %t29 = load { i64, [2 x i64] }, ptr %l2
  %t31 = extractvalue { i64, [2 x i64] } %t29, 0
  %t32 = icmp eq i64 %t31, 0
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t34 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t35 = getelementptr { i64 }, ptr %t34, i32 0, i32 0
  %t36 = load i64, ptr %t35
  store i64 %t36, ptr %l3, !tbaa !24
  br label %bb11
bb10:
  br label %bb14
bb11:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 2
  store ptr %t43, ptr %l25, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t48 = load i64, ptr %l3, !tbaa !24
  %t51 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t47, i64 %t48)
  store i32 %t51, ptr %l29
  br label %bb12
bb12:
  %t52 = load ptr, ptr %l25, !tbaa !29
  %t53 = load i32, ptr %l29, !tbaa !23
  %t54 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t52, i32 %t53)
  store { i64, ptr } %t54, ptr %l30
  br label %bb13
bb13:
  %t55 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  %t58 = icmp sgt i64 %t56, 0
  store i1 %t58, ptr %l19, !tbaa !21
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_9109cadfb541186e_2a46ab96c2b41f0a)
  unreachable
bb19:
  %t60 = load i1, ptr %l19, !tbaa !21
  store i1 %t60, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisGlobalBody(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l6 = alloca ptr
  %l9 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 11
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l6, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 1
  %t11 = load { i64, [2 x i64] }, ptr %t10
  %t15 = extractvalue { i64, [2 x i64] } %t11, 0
  %t16 = icmp eq i64 %t15, 6
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb5
bb4:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_4bb92e4e6aa9fa92_ae49a41c9a1a92ee)
  unreachable
bb10:
  %t18 = load i1, ptr %l9, !tbaa !21
  store i1 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneCount(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l7 = alloca %"compiler/check:laneNode"
  %l10 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l13 = alloca i32
  %l17 = alloca %"compiler/check:laneNode"
  %l19 = alloca ptr
  %l24 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 35
  %t4 = load i64, ptr %l2, !tbaa !24
  %t7 = call %"compiler/check:laneNode" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3alaneNode_3e_2eAt_H1a82638d5202f9f6649df5fa501425e5(ptr %v0, ptr %s0, ptr %t3, i64 %t4)
  store %"compiler/check:laneNode" %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = getelementptr %"compiler/check:laneNode", ptr %l7, i32 0, i32 9
  %t9 = load i64, ptr %t8, !tbaa !24
  %t11 = icmp sge i64 %t9, 0
  br i1 %t11, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l10, !tbaa !29
  %t14 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t14, ptr %l11
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t15)
  store i32 %t17, ptr %l13
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 35
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = call %"compiler/check:laneNode" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3alaneNode_3e_2eAt_H1a82638d5202f9f6649df5fa501425e5(ptr %v0, ptr %s1, ptr %t20, i64 %t21)
  store %"compiler/check:laneNode" %t24, ptr %l17
  br label %bb5
bb5:
  %t25 = getelementptr %"compiler/check:laneNode", ptr %l17, i32 0, i32 9
  %t26 = load i64, ptr %t25, !tbaa !24
  %t27 = load ptr, ptr %l10, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l11
  %t29 = load i32, ptr %l13, !tbaa !23
  %t31 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t27, %"compiler/source:Span" %t28, i32 %t29, i64 %t26)
  store ptr %t31, ptr %l19
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t32 = load ptr, ptr %l19, !tbaa !29
  store ptr %t32, ptr %rv
  br label %ret
bb7:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load %"compiler/source:Span", ptr %l1
  %t37 = getelementptr %"compiler/check:laneVals", ptr %a3, i32 0, i32 0
  %t38 = load i64, ptr %t37, !tbaa !24
  %t42 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t33, %"compiler/source:Span" %t34, i64 %t38)
  store ptr %t42, ptr %l24
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t43 = load ptr, ptr %l24, !tbaa !29
  store ptr %t43, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %lp5 = alloca ptr
  %l6 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l19 = alloca %"compiler/check:laneNode"
  %l23 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i32
  %l33 = alloca ptr
  %l36 = alloca i32
  %l37 = alloca %"compiler/source:Span"
  %l40 = alloca i32
  %l44 = alloca ptr
  %l47 = alloca ptr
  %l48 = alloca %"compiler/source:Span"
  %l49 = alloca %"compiler/source:Span"
  %l50 = alloca i32
  %l54 = alloca %"compiler/typed:Elem"
  %l58 = alloca ptr
  %l62 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i32
  %l76 = alloca ptr
  %l85 = alloca ptr
  %l91 = alloca i1
  %l95 = alloca ptr
  %l96 = alloca ptr
  %l101 = alloca ptr
  %l102 = alloca ptr
  %l111 = alloca ptr
  %l117 = alloca ptr
  %l123 = alloca ptr
  %l129 = alloca ptr
  %l130 = alloca %"compiler/source:Span"
  %l131 = alloca i32
  %l132 = alloca ptr
  %l137 = alloca ptr
  %l138 = alloca ptr
  %l143 = alloca ptr
  %l144 = alloca %"compiler/typed:Cond"
  %l153 = alloca ptr
  %l159 = alloca ptr
  %l162 = alloca i1
  %l165 = alloca ptr
  %l166 = alloca ptr
  %l167 = alloca %"compiler/source:Span"
  %l169 = alloca { i64, ptr }
  %l170 = alloca { i64, ptr }
  %l172 = alloca i1
  %l174 = alloca i1
  %l175 = alloca ptr
  %l176 = alloca ptr
  %l177 = alloca %"compiler/source:Span"
  %l179 = alloca { i64, ptr }
  %l180 = alloca { i64, ptr }
  %l182 = alloca i1
  %l186 = alloca ptr
  %l189 = alloca %"compiler/source:Span"
  %l190 = alloca i32
  %l191 = alloca ptr
  %l193 = alloca ptr
  %l197 = alloca ptr
  %l198 = alloca %"compiler/typed:Cond"
  %l202 = alloca %"compiler/source:Span"
  %l203 = alloca i32
  %l204 = alloca ptr
  %l208 = alloca ptr
  %l211 = alloca %"compiler/typed:Cond"
  %l215 = alloca ptr
  %l224 = alloca ptr
  %l225 = alloca ptr
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca ptr
  %t61 = alloca { i64, [4 x i64] }, align 8
  %t88 = alloca { i64, [4 x i64] }, align 8
  %t322 = alloca { i64, [5 x i64] }, align 8
  %t470 = alloca { i64, [5 x i64] }, align 8
  %t505 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 35
  %t4 = load i64, ptr %l2, !tbaa !24
  %t7 = call %"compiler/check:laneNode" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3alaneNode_3e_2eAt_H1a82638d5202f9f6649df5fa501425e5(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store %"compiler/check:laneNode" %t7, ptr %l19
  br label %bb1
bb1:
  %t8 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 88, i64 8)
  store ptr %t8, ptr %lp5
  %t9 = load %"compiler/check:laneNode", ptr %l19
  %t10 = load ptr, ptr %lp5
  store %"compiler/check:laneNode" %t9, ptr %t10
  %t11 = load ptr, ptr %lp5
  %t12 = getelementptr %"compiler/check:laneNode", ptr %t11, i32 0, i32 0
  %t13 = load i64, ptr %t12, !tbaa !24
  %t14 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneArr, !tbaa !24
  %t17 = icmp eq i64 %t13, %t14
  br i1 %t17, label %bb2, label %bb3
bb2:
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t21 = getelementptr %"compiler/check:laneVals", ptr %t19, i32 0, i32 1
  %t22 = load i64, ptr %l2, !tbaa !24
  %t25 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v1, ptr %t21, i64 %t22)
  %t26 = extractvalue { i32, i64 } %t25, 1
  %t27 = extractvalue { i32, i64 } %t25, 0
  store i32 %t27, ptr %l28
  %t28 = icmp ne i32 %t27, 0
  br i1 %t28, label %bb5, label %ok.29
ok.29:
  store i64 %t26, ptr %l27
  br label %bb4
bb3:
  br label %bb17
bb4:
  %t30 = load i64, ptr %l27, !tbaa !24
  store i64 %t30, ptr %l23, !tbaa !24
  br label %bb7
bb5:
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t31 = load i64, ptr %l23, !tbaa !24
  store i64 %t31, ptr %l6, !tbaa !24
  %t32 = load i64, ptr %l6, !tbaa !24
  %t34 = icmp slt i64 %t32, 0
  br i1 %t34, label %bb8, label %bb9
bb8:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load %"compiler/source:Span", ptr %l1
  %t40 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t36, %"compiler/source:Span" %t37)
  store ptr %t40, ptr %l33
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t41 = load ptr, ptr %l33, !tbaa !29
  store ptr %t41, ptr %rv
  br label %ret
bb11:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i64, ptr %l6, !tbaa !24
  %t46 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t42, i64 %t43)
  store i32 %t46, ptr %l36
  br label %bb12
bb12:
  %t47 = load i32, ptr %l36, !tbaa !23
  %t48 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t48, ptr %l37
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t53 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t49, i32 %t47)
  store i32 %t53, ptr %l40
  br label %bb13
bb13:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l1
  %t56 = load i64, ptr %l6, !tbaa !24
  %t60 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t54, %"compiler/source:Span" %t55, i64 %t56)
  store ptr %t60, ptr %l44
  br label %bb14
bb14:
  store { i64, [4 x i64] } zeroinitializer, ptr %t61
  %t62 = getelementptr { i64, [4 x i64] }, ptr %t61, i32 0, i32 0
  store i64 2, ptr %t62
  %t63 = load %"compiler/source:Span", ptr %l37
  %t64 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t63, 0
  %t65 = load i32, ptr %l40, !tbaa !23
  %t66 = insertvalue { %"compiler/source:Span", i32, ptr } %t64, i32 %t65, 1
  %t67 = load ptr, ptr %l44, !tbaa !29
  %t68 = insertvalue { %"compiler/source:Span", i32, ptr } %t66, ptr %t67, 2
  %t69 = getelementptr { i64, [4 x i64] }, ptr %t61, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t68, ptr %t69
  %t70 = load { i64, [4 x i64] }, ptr %t61
  %t72 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t70, ptr %t72
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l47, !tbaa !29
  %t75 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t75, ptr %l48
  %t76 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t76, ptr %l49
  %t77 = load ptr, ptr %lp5
  %t78 = getelementptr %"compiler/check:laneNode", ptr %t77, i32 0, i32 8
  %t79 = load i32, ptr %t78, !tbaa !23
  store i32 %t79, ptr %l50, !tbaa !23
  %t81 = load ptr, ptr %l4, !tbaa !29
  %t85 = call %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t72, ptr %t81, i32 0)
  store %"compiler/typed:Elem" %t85, ptr %l54
  br label %bb15
bb15:
  %t86 = load %"compiler/typed:Elem", ptr %l54
  %t87 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Elem" %t86, ptr %t87
  store { i64, [4 x i64] } zeroinitializer, ptr %t88
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t88, i32 0, i32 0
  store i64 4, ptr %t89
  %t90 = load %"compiler/source:Span", ptr %l49
  %t91 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t90, 0
  %t92 = load i32, ptr %l50, !tbaa !23
  %t93 = insertvalue { %"compiler/source:Span", i32, ptr } %t91, i32 %t92, 1
  %t95 = insertvalue { %"compiler/source:Span", i32, ptr } %t93, ptr %t87, 2
  %t96 = getelementptr { i64, [4 x i64] }, ptr %t88, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t95, ptr %t96
  %t97 = load { i64, [4 x i64] }, ptr %t88
  %t99 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t97, ptr %t99
  %t100 = load ptr, ptr %l47, !tbaa !29
  %t101 = load %"compiler/source:Span", ptr %l48
  %t103 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t100, %"compiler/source:Span" %t101, ptr %t99)
  store ptr %t103, ptr %l58
  br label %bb16
bb16:
  %t104 = load ptr, ptr %l58, !tbaa !29
  store ptr %t104, ptr %rv
  br label %ret
bb17:
  %t105 = load ptr, ptr %lp5
  %t106 = getelementptr %"compiler/check:laneNode", ptr %t105, i32 0, i32 0
  %t107 = load i64, ptr %t106, !tbaa !24
  %t108 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneScalar, !tbaa !24
  %t111 = icmp eq i64 %t107, %t108
  br i1 %t111, label %bb18, label %bb19
bb18:
  %t113 = load ptr, ptr %l3, !tbaa !29
  %t115 = getelementptr %"compiler/check:laneVals", ptr %t113, i32 0, i32 1
  %t116 = load i64, ptr %l2, !tbaa !24
  %t119 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v1, ptr %t115, i64 %t116)
  %t120 = extractvalue { i32, i64 } %t119, 1
  %t121 = extractvalue { i32, i64 } %t119, 0
  store i32 %t121, ptr %l67
  %t122 = icmp ne i32 %t121, 0
  br i1 %t122, label %bb21, label %ok.123
ok.123:
  store i64 %t120, ptr %l66
  br label %bb20
bb19:
  br label %bb31
bb20:
  %t124 = load i64, ptr %l66, !tbaa !24
  store i64 %t124, ptr %l62, !tbaa !24
  br label %bb23
bb21:
  br label %bb22
bb22:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l62, !tbaa !24
  br label %bb23
bb23:
  %t125 = load i64, ptr %l62, !tbaa !24
  store i64 %t125, ptr %l9, !tbaa !24
  %t126 = load i64, ptr %l9, !tbaa !24
  %t128 = icmp slt i64 %t126, 0
  br i1 %t128, label %bb24, label %bb25
bb24:
  %t130 = load ptr, ptr %lp5
  %t131 = getelementptr %"compiler/check:laneNode", ptr %t130, i32 0, i32 7
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t134 = icmp eq ptr %t132, null
  br i1 %t134, label %bb26, label %bb27
bb25:
  br label %bb29
bb26:
  call void @__olang_check_failed(ptr @olang_loc_24a46e21631caff9_33b011dc8e05d16d)
  unreachable
bb27:
  br label %bb28
bb28:
  %t136 = load ptr, ptr %lp5
  %t137 = getelementptr %"compiler/check:laneNode", ptr %t136, i32 0, i32 7
  %t138 = load ptr, ptr %t137, !tbaa !29
  store ptr %t138, ptr %rv
  br label %ret
bb29:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load ptr, ptr %lp5
  %t142 = getelementptr %"compiler/check:laneNode", ptr %t141, i32 0, i32 2
  %t143 = load %"compiler/source:Span", ptr %t142
  %t144 = load i64, ptr %l9, !tbaa !24
  %t148 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t140, %"compiler/source:Span" %t143, i64 %t144)
  store ptr %t148, ptr %l76
  br label %bb30
bb30:
  %t149 = load ptr, ptr %l76, !tbaa !29
  store ptr %t149, ptr %rv
  br label %ret
bb31:
  %t150 = load ptr, ptr %lp5
  %t151 = getelementptr %"compiler/check:laneNode", ptr %t150, i32 0, i32 0
  %t152 = load i64, ptr %t151, !tbaa !24
  %t153 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneUn, !tbaa !24
  %t156 = icmp eq i64 %t152, %t153
  br i1 %t156, label %bb32, label %bb33
bb32:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load %"compiler/source:Span", ptr %l1
  %t160 = load ptr, ptr %lp5
  %t161 = getelementptr %"compiler/check:laneNode", ptr %t160, i32 0, i32 4
  %t162 = load i64, ptr %t161, !tbaa !24
  %t163 = load ptr, ptr %l3, !tbaa !29
  %t164 = load ptr, ptr %l4, !tbaa !29
  %t170 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v1, ptr %t158, %"compiler/source:Span" %t159, i64 %t162, ptr %t163, ptr %t164)
  store ptr %t170, ptr %l85
  br label %bb34
bb33:
  br label %bb42
bb34:
  %t171 = load ptr, ptr %l85, !tbaa !29
  store ptr %t171, ptr %l10, !tbaa !29
  %t172 = load ptr, ptr %lp5
  %t173 = getelementptr %"compiler/check:laneNode", ptr %t172, i32 0, i32 1
  %t174 = load i32, ptr %t173
  %t176 = trunc i64 49 to i32
  %t177 = icmp eq i32 %t174, %t176
  br i1 %t177, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s6
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load ptr, ptr %l10, !tbaa !29
  %t181 = load ptr, ptr %lp5
  %t182 = getelementptr %"compiler/check:laneNode", ptr %t181, i32 0, i32 2
  %t183 = load %"compiler/source:Span", ptr %t182
  %t187 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneBool(ptr %v0, ptr %s6, ptr %t179, ptr %t180, %"compiler/source:Span" %t183, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d26, i32 0, i32 1) })
  store i1 %t187, ptr %l91
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load ptr, ptr %lp5
  %t190 = getelementptr %"compiler/check:laneNode", ptr %t189, i32 0, i32 2
  %t191 = load %"compiler/source:Span", ptr %t190
  %t192 = load ptr, ptr %l10, !tbaa !29
  %t196 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %t188, %"compiler/source:Span" %t191, ptr %t192)
  store ptr %t196, ptr %l95
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s6)
  %t197 = load ptr, ptr %l95, !tbaa !29
  store ptr %t197, ptr %rv
  br label %ret
bb39:
  %t198 = load ptr, ptr %l0, !tbaa !29
  store ptr %t198, ptr %l96, !tbaa !29
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load ptr, ptr %lp5
  %t201 = getelementptr %"compiler/check:laneNode", ptr %t200, i32 0, i32 2
  %t202 = load %"compiler/source:Span", ptr %t201
  %t203 = load ptr, ptr %lp5
  %t204 = getelementptr %"compiler/check:laneNode", ptr %t203, i32 0, i32 1
  %t205 = load i32, ptr %t204
  %t206 = load ptr, ptr %l10, !tbaa !29
  %t211 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunaryOn(ptr %v0, ptr %t199, %"compiler/source:Span" %t202, i32 %t205, ptr %t206)
  store ptr %t211, ptr %l101
  br label %bb40
bb40:
  %t212 = load ptr, ptr %l96, !tbaa !29
  %t213 = load ptr, ptr %l101, !tbaa !29
  %t214 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOut(ptr %v0, ptr %t212, ptr %t213)
  store ptr %t214, ptr %l102
  br label %bb41
bb41:
  %t215 = load ptr, ptr %l102, !tbaa !29
  store ptr %t215, ptr %rv
  br label %ret
bb42:
  %t216 = load ptr, ptr %lp5
  %t217 = getelementptr %"compiler/check:laneNode", ptr %t216, i32 0, i32 0
  %t218 = load i64, ptr %t217, !tbaa !24
  %t219 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneSel, !tbaa !24
  %t222 = icmp eq i64 %t218, %t219
  br i1 %t222, label %bb43, label %bb44
bb43:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t225 = load %"compiler/source:Span", ptr %l1
  %t226 = load ptr, ptr %lp5
  %t227 = getelementptr %"compiler/check:laneNode", ptr %t226, i32 0, i32 4
  %t228 = load i64, ptr %t227, !tbaa !24
  %t229 = load ptr, ptr %l3, !tbaa !29
  %t230 = load ptr, ptr %l4, !tbaa !29
  %t236 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v1, ptr %t224, %"compiler/source:Span" %t225, i64 %t228, ptr %t229, ptr %t230)
  store ptr %t236, ptr %l111
  br label %bb45
bb44:
  br label %bb55
bb45:
  %t237 = load ptr, ptr %l111, !tbaa !29
  store ptr %t237, ptr %l11, !tbaa !29
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load %"compiler/source:Span", ptr %l1
  %t240 = load ptr, ptr %lp5
  %t241 = getelementptr %"compiler/check:laneNode", ptr %t240, i32 0, i32 5
  %t242 = load i64, ptr %t241, !tbaa !24
  %t243 = load ptr, ptr %l3, !tbaa !29
  %t244 = load ptr, ptr %l4, !tbaa !29
  %t250 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v1, ptr %t238, %"compiler/source:Span" %t239, i64 %t242, ptr %t243, ptr %t244)
  store ptr %t250, ptr %l117
  br label %bb46
bb46:
  %t251 = load ptr, ptr %l117, !tbaa !29
  store ptr %t251, ptr %l12, !tbaa !29
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t253 = load %"compiler/source:Span", ptr %l1
  %t254 = load ptr, ptr %lp5
  %t255 = getelementptr %"compiler/check:laneNode", ptr %t254, i32 0, i32 6
  %t256 = load i64, ptr %t255, !tbaa !24
  %t257 = load ptr, ptr %l3, !tbaa !29
  %t258 = load ptr, ptr %l4, !tbaa !29
  %t264 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v1, ptr %t252, %"compiler/source:Span" %t253, i64 %t256, ptr %t257, ptr %t258)
  store ptr %t264, ptr %l123
  br label %bb47
bb47:
  %t265 = load ptr, ptr %l123, !tbaa !29
  store ptr %t265, ptr %l13, !tbaa !29
  %t266 = load ptr, ptr %lp5
  %t267 = getelementptr %"compiler/check:laneNode", ptr %t266, i32 0, i32 8
  %t268 = load i32, ptr %t267, !tbaa !23
  %t269 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t272 = icmp eq i32 %t268, %t269
  br i1 %t272, label %bb48, label %bb49
bb48:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load ptr, ptr %lp5
  %t276 = getelementptr %"compiler/check:laneNode", ptr %t275, i32 0, i32 2
  %t277 = load %"compiler/source:Span", ptr %t276
  %t280 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t274, %"compiler/source:Span" %t277)
  store ptr %t280, ptr %l129
  br label %bb50
bb49:
  br label %bb51
bb50:
  %t281 = load ptr, ptr %l129, !tbaa !29
  store ptr %t281, ptr %rv
  br label %ret
bb51:
  %t282 = load ptr, ptr %lp5
  %t283 = getelementptr %"compiler/check:laneNode", ptr %t282, i32 0, i32 2
  %t284 = load %"compiler/source:Span", ptr %t283
  store %"compiler/source:Span" %t284, ptr %l130
  %t285 = load ptr, ptr %lp5
  %t286 = getelementptr %"compiler/check:laneNode", ptr %t285, i32 0, i32 8
  %t287 = load i32, ptr %t286, !tbaa !23
  store i32 %t287, ptr %l131, !tbaa !23
  %t288 = load ptr, ptr %l11, !tbaa !29
  store ptr %t288, ptr %l132, !tbaa !29
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t290 = load ptr, ptr %l12, !tbaa !29
  %t291 = load ptr, ptr %lp5
  %t292 = getelementptr %"compiler/check:laneNode", ptr %t291, i32 0, i32 8
  %t293 = load i32, ptr %t292, !tbaa !23
  %t294 = load ptr, ptr %lp5
  %t295 = getelementptr %"compiler/check:laneNode", ptr %t294, i32 0, i32 2
  %t296 = load %"compiler/source:Span", ptr %t295
  %t301 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t289, ptr %t290, i32 %t293, %"compiler/source:Span" %t296)
  store ptr %t301, ptr %l137
  br label %bb52
bb52:
  %t302 = load ptr, ptr %l137, !tbaa !29
  store ptr %t302, ptr %l138, !tbaa !29
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t304 = load ptr, ptr %l13, !tbaa !29
  %t305 = load ptr, ptr %lp5
  %t306 = getelementptr %"compiler/check:laneNode", ptr %t305, i32 0, i32 8
  %t307 = load i32, ptr %t306, !tbaa !23
  %t308 = load ptr, ptr %lp5
  %t309 = getelementptr %"compiler/check:laneNode", ptr %t308, i32 0, i32 2
  %t310 = load %"compiler/source:Span", ptr %t309
  %t315 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t303, ptr %t304, i32 %t307, %"compiler/source:Span" %t310)
  store ptr %t315, ptr %l143
  br label %bb53
bb53:
  %t316 = load ptr, ptr %l132, !tbaa !29
  %t317 = load ptr, ptr %l138, !tbaa !29
  %t318 = load ptr, ptr %l143, !tbaa !29
  %t319 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t316, ptr %t317, ptr %t318)
  store %"compiler/typed:Cond" %t319, ptr %l144
  br label %bb54
bb54:
  %t320 = load %"compiler/typed:Cond", ptr %l144
  %t321 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Cond" %t320, ptr %t321
  store { i64, [5 x i64] } zeroinitializer, ptr %t322
  %t323 = getelementptr { i64, [5 x i64] }, ptr %t322, i32 0, i32 0
  store i64 11, ptr %t323
  %t324 = load %"compiler/source:Span", ptr %l130
  %t325 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t324, 0
  %t326 = load i32, ptr %l131, !tbaa !23
  %t327 = insertvalue { %"compiler/source:Span", i32, ptr } %t325, i32 %t326, 1
  %t329 = insertvalue { %"compiler/source:Span", i32, ptr } %t327, ptr %t321, 2
  %t330 = getelementptr { i64, [5 x i64] }, ptr %t322, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t329, ptr %t330
  %t331 = load { i64, [5 x i64] }, ptr %t322
  %t333 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t331, ptr %t333
  store ptr %t333, ptr %rv
  br label %ret
bb55:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t336 = load %"compiler/source:Span", ptr %l1
  %t337 = load ptr, ptr %lp5
  %t338 = getelementptr %"compiler/check:laneNode", ptr %t337, i32 0, i32 4
  %t339 = load i64, ptr %t338, !tbaa !24
  %t340 = load ptr, ptr %l3, !tbaa !29
  %t341 = load ptr, ptr %l4, !tbaa !29
  %t347 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v1, ptr %t335, %"compiler/source:Span" %t336, i64 %t339, ptr %t340, ptr %t341)
  store ptr %t347, ptr %l153
  br label %bb56
bb56:
  %t348 = load ptr, ptr %l153, !tbaa !29
  store ptr %t348, ptr %l14, !tbaa !29
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t350 = load %"compiler/source:Span", ptr %l1
  %t351 = load ptr, ptr %lp5
  %t352 = getelementptr %"compiler/check:laneNode", ptr %t351, i32 0, i32 5
  %t353 = load i64, ptr %t352, !tbaa !24
  %t354 = load ptr, ptr %l3, !tbaa !29
  %t355 = load ptr, ptr %l4, !tbaa !29
  %t361 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v1, ptr %t349, %"compiler/source:Span" %t350, i64 %t353, ptr %t354, ptr %t355)
  store ptr %t361, ptr %l159
  br label %bb57
bb57:
  %t362 = load ptr, ptr %l159, !tbaa !29
  store ptr %t362, ptr %l15, !tbaa !29
  %t363 = load ptr, ptr %lp5
  %t364 = getelementptr %"compiler/check:laneNode", ptr %t363, i32 0, i32 1
  %t365 = load i32, ptr %t364
  %t367 = trunc i64 46 to i32
  %t368 = icmp eq i32 %t365, %t367
  br i1 %t368, label %bb58, label %bb59
bb58:
  store i1 true, ptr %l162, !tbaa !21
  br label %bb60
bb59:
  %t370 = load ptr, ptr %lp5
  %t371 = getelementptr %"compiler/check:laneNode", ptr %t370, i32 0, i32 1
  %t372 = load i32, ptr %t371
  %t374 = trunc i64 47 to i32
  %t375 = icmp eq i32 %t372, %t374
  store i1 %t375, ptr %l162, !tbaa !21
  br label %bb60
bb60:
  %t377 = load i1, ptr %l162, !tbaa !21
  br i1 %t377, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s9
  %t378 = load ptr, ptr %l0, !tbaa !29
  store ptr %t378, ptr %l165, !tbaa !29
  %t379 = load ptr, ptr %l14, !tbaa !29
  store ptr %t379, ptr %l166, !tbaa !29
  %t380 = load ptr, ptr %lp5
  %t381 = getelementptr %"compiler/check:laneNode", ptr %t380, i32 0, i32 3
  %t382 = load %"compiler/source:Span", ptr %t381
  store %"compiler/source:Span" %t382, ptr %l167
  %t383 = load ptr, ptr %lp5
  %t384 = getelementptr %"compiler/check:laneNode", ptr %t383, i32 0, i32 1
  %t385 = load i32, ptr %t384
  %t387 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s9, i32 %t385)
  store { i64, ptr } %t387, ptr %l169
  br label %bb63
bb62:
  br label %bb83
bb63:
  %t388 = load { i64, ptr }, ptr %l169, !tbaa !27
  %t389 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s9, ptr %s9, { i64, ptr } %t388)
  store { i64, ptr } %t389, ptr %l170
  br label %bb64
bb64:
  %t390 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t391 = extractvalue { i64, ptr } %t390, 0
  %t392 = extractvalue { i64, ptr } %t390, 1
  %t393 = mul i64 %t391, 1
  %t394 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t393)
  call void @llvm.memcpy.p0.p0.i64(ptr %t394, ptr %t392, i64 %t393, i1 false)
  %t395 = insertvalue { i64, ptr } undef, i64 %t391, 0
  %t396 = insertvalue { i64, ptr } %t395, ptr %t394, 1
  %t397 = load ptr, ptr %l165, !tbaa !29
  %t398 = load ptr, ptr %l166, !tbaa !29
  %t399 = load %"compiler/source:Span", ptr %l167
  %t401 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneBool(ptr %v0, ptr %s9, ptr %t397, ptr %t398, %"compiler/source:Span" %t399, { i64, ptr } %t396)
  store i1 %t401, ptr %l172
  br label %bb65
bb65:
  %t402 = load i1, ptr %l172, !tbaa !21
  %t403 = xor i1 %t402, true
  br i1 %t403, label %bb66, label %bb67
bb66:
  store i1 true, ptr %l174, !tbaa !21
  br label %bb71
bb67:
  %t405 = load ptr, ptr %l0, !tbaa !29
  store ptr %t405, ptr %l175, !tbaa !29
  %t406 = load ptr, ptr %l15, !tbaa !29
  store ptr %t406, ptr %l176, !tbaa !29
  %t407 = load ptr, ptr %lp5
  %t408 = getelementptr %"compiler/check:laneNode", ptr %t407, i32 0, i32 3
  %t409 = load %"compiler/source:Span", ptr %t408
  store %"compiler/source:Span" %t409, ptr %l177
  %t410 = load ptr, ptr %lp5
  %t411 = getelementptr %"compiler/check:laneNode", ptr %t410, i32 0, i32 1
  %t412 = load i32, ptr %t411
  %t414 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s9, i32 %t412)
  store { i64, ptr } %t414, ptr %l179
  br label %bb68
bb68:
  %t415 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t416 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s9, ptr %s9, { i64, ptr } %t415)
  store { i64, ptr } %t416, ptr %l180
  br label %bb69
bb69:
  %t417 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t418 = extractvalue { i64, ptr } %t417, 0
  %t419 = extractvalue { i64, ptr } %t417, 1
  %t420 = mul i64 %t418, 1
  %t421 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t420)
  call void @llvm.memcpy.p0.p0.i64(ptr %t421, ptr %t419, i64 %t420, i1 false)
  %t422 = insertvalue { i64, ptr } undef, i64 %t418, 0
  %t423 = insertvalue { i64, ptr } %t422, ptr %t421, 1
  %t424 = load ptr, ptr %l175, !tbaa !29
  %t425 = load ptr, ptr %l176, !tbaa !29
  %t426 = load %"compiler/source:Span", ptr %l177
  %t428 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneBool(ptr %v0, ptr %s9, ptr %t424, ptr %t425, %"compiler/source:Span" %t426, { i64, ptr } %t423)
  store i1 %t428, ptr %l182
  br label %bb70
bb70:
  %t429 = load i1, ptr %l182, !tbaa !21
  %t430 = xor i1 %t429, true
  store i1 %t430, ptr %l174, !tbaa !21
  br label %bb71
bb71:
  %t432 = load i1, ptr %l174, !tbaa !21
  br i1 %t432, label %bb72, label %bb73
bb72:
  %t433 = load ptr, ptr %l0, !tbaa !29
  %t434 = load ptr, ptr %lp5
  %t435 = getelementptr %"compiler/check:laneNode", ptr %t434, i32 0, i32 2
  %t436 = load %"compiler/source:Span", ptr %t435
  %t439 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t433, %"compiler/source:Span" %t436)
  store ptr %t439, ptr %l186
  br label %bb74
bb73:
  br label %bb75
bb74:
  call void @__olang_scope_close(ptr %s9)
  %t440 = load ptr, ptr %l186, !tbaa !29
  store ptr %t440, ptr %rv
  br label %ret
bb75:
  %t441 = load ptr, ptr %lp5
  %t442 = getelementptr %"compiler/check:laneNode", ptr %t441, i32 0, i32 1
  %t443 = load i32, ptr %t442
  %t445 = trunc i64 46 to i32
  %t446 = icmp eq i32 %t443, %t445
  br i1 %t446, label %bb76, label %bb77
bb76:
  %t448 = load ptr, ptr %lp5
  %t449 = getelementptr %"compiler/check:laneNode", ptr %t448, i32 0, i32 2
  %t450 = load %"compiler/source:Span", ptr %t449
  store %"compiler/source:Span" %t450, ptr %l189
  %t451 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t451, ptr %l190, !tbaa !23
  %t452 = load ptr, ptr %l14, !tbaa !29
  store ptr %t452, ptr %l191, !tbaa !29
  %t453 = load ptr, ptr %l15, !tbaa !29
  store ptr %t453, ptr %l193, !tbaa !29
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t456 = load ptr, ptr %lp5
  %t457 = getelementptr %"compiler/check:laneNode", ptr %t456, i32 0, i32 2
  %t458 = load %"compiler/source:Span", ptr %t457
  %t459 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t463 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t455, %"compiler/source:Span" %t458, i32 %t459, i64 0)
  store ptr %t463, ptr %l197
  br label %bb78
bb77:
  br label %bb80
bb78:
  %t464 = load ptr, ptr %l191, !tbaa !29
  %t465 = load ptr, ptr %l193, !tbaa !29
  %t466 = load ptr, ptr %l197, !tbaa !29
  %t467 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t464, ptr %t465, ptr %t466)
  store %"compiler/typed:Cond" %t467, ptr %l198
  br label %bb79
bb79:
  %t468 = load %"compiler/typed:Cond", ptr %l198
  %t469 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Cond" %t468, ptr %t469
  store { i64, [5 x i64] } zeroinitializer, ptr %t470
  %t471 = getelementptr { i64, [5 x i64] }, ptr %t470, i32 0, i32 0
  store i64 11, ptr %t471
  %t472 = load %"compiler/source:Span", ptr %l189
  %t473 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t472, 0
  %t474 = load i32, ptr %l190, !tbaa !23
  %t475 = insertvalue { %"compiler/source:Span", i32, ptr } %t473, i32 %t474, 1
  %t477 = insertvalue { %"compiler/source:Span", i32, ptr } %t475, ptr %t469, 2
  %t478 = getelementptr { i64, [5 x i64] }, ptr %t470, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t477, ptr %t478
  %t479 = load { i64, [5 x i64] }, ptr %t470
  %t481 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t479, ptr %t481
  call void @__olang_scope_close(ptr %s9)
  store ptr %t481, ptr %rv
  br label %ret
bb80:
  %t483 = load ptr, ptr %lp5
  %t484 = getelementptr %"compiler/check:laneNode", ptr %t483, i32 0, i32 2
  %t485 = load %"compiler/source:Span", ptr %t484
  store %"compiler/source:Span" %t485, ptr %l202
  %t486 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t486, ptr %l203, !tbaa !23
  %t487 = load ptr, ptr %l14, !tbaa !29
  store ptr %t487, ptr %l204, !tbaa !29
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t489 = load ptr, ptr %lp5
  %t490 = getelementptr %"compiler/check:laneNode", ptr %t489, i32 0, i32 2
  %t491 = load %"compiler/source:Span", ptr %t490
  %t492 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t496 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t488, %"compiler/source:Span" %t491, i32 %t492, i64 1)
  store ptr %t496, ptr %l208
  br label %bb81
bb81:
  %t497 = load ptr, ptr %l208, !tbaa !29
  %t498 = load ptr, ptr %l15, !tbaa !29
  %t499 = load ptr, ptr %l204, !tbaa !29
  %t502 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t499, ptr %t497, ptr %t498)
  store %"compiler/typed:Cond" %t502, ptr %l211
  br label %bb82
bb82:
  %t503 = load %"compiler/typed:Cond", ptr %l211
  %t504 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Cond" %t503, ptr %t504
  store { i64, [5 x i64] } zeroinitializer, ptr %t505
  %t506 = getelementptr { i64, [5 x i64] }, ptr %t505, i32 0, i32 0
  store i64 11, ptr %t506
  %t507 = load %"compiler/source:Span", ptr %l202
  %t508 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t507, 0
  %t509 = load i32, ptr %l203, !tbaa !23
  %t510 = insertvalue { %"compiler/source:Span", i32, ptr } %t508, i32 %t509, 1
  %t512 = insertvalue { %"compiler/source:Span", i32, ptr } %t510, ptr %t504, 2
  %t513 = getelementptr { i64, [5 x i64] }, ptr %t505, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t512, ptr %t513
  %t514 = load { i64, [5 x i64] }, ptr %t505
  %t516 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t514, ptr %t516
  call void @__olang_scope_close(ptr %s9)
  store ptr %t516, ptr %rv
  br label %ret
bb83:
  %t518 = load ptr, ptr %l0, !tbaa !29
  store ptr %t518, ptr %l215, !tbaa !29
  %t519 = load ptr, ptr %l0, !tbaa !29
  %t520 = load ptr, ptr %lp5
  %t521 = getelementptr %"compiler/check:laneNode", ptr %t520, i32 0, i32 2
  %t522 = load %"compiler/source:Span", ptr %t521
  %t523 = load ptr, ptr %lp5
  %t524 = getelementptr %"compiler/check:laneNode", ptr %t523, i32 0, i32 3
  %t525 = load %"compiler/source:Span", ptr %t524
  %t526 = load ptr, ptr %lp5
  %t527 = getelementptr %"compiler/check:laneNode", ptr %t526, i32 0, i32 1
  %t528 = load i32, ptr %t527
  %t529 = load ptr, ptr %l14, !tbaa !29
  %t530 = load ptr, ptr %l15, !tbaa !29
  %t531 = load ptr, ptr %lp5
  %t532 = getelementptr %"compiler/check:laneNode", ptr %t531, i32 0, i32 2
  %t533 = load %"compiler/source:Span", ptr %t532
  %t534 = load ptr, ptr %lp5
  %t535 = getelementptr %"compiler/check:laneNode", ptr %t534, i32 0, i32 2
  %t536 = load %"compiler/source:Span", ptr %t535
  %t545 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %t519, %"compiler/source:Span" %t522, %"compiler/source:Span" %t525, i32 %t528, ptr %t529, ptr %t530, %"compiler/source:Span" %t533, %"compiler/source:Span" %t536)
  store ptr %t545, ptr %l224
  br label %bb84
bb84:
  %t546 = load ptr, ptr %l215, !tbaa !29
  %t547 = load ptr, ptr %l224, !tbaa !29
  %t548 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOut(ptr %v0, ptr %t546, ptr %t547)
  store ptr %t548, ptr %l225
  br label %bb85
bb85:
  %t549 = load ptr, ptr %l225, !tbaa !29
  store ptr %t549, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneHold(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %rv = alloca ptr
  %t12 = alloca { i64, [5 x i64] }, align 8
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %"compiler/source:Span" %a1, ptr %l3
  %t3 = load i64, ptr %l2, !tbaa !24
  %t6 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneType(ptr %v0, ptr %a0, i64 %t3)
  store i32 %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneMagic, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = add i64 %t7, %t8
  store { i64, [5 x i64] } zeroinitializer, ptr %t12
  %t13 = getelementptr { i64, [5 x i64] }, ptr %t12, i32 0, i32 0
  store i64 0, ptr %t13
  %t14 = load %"compiler/source:Span", ptr %l3
  %t15 = insertvalue { %"compiler/source:Span", i32, i64 } undef, %"compiler/source:Span" %t14, 0
  %t16 = load i32, ptr %l6, !tbaa !23
  %t17 = insertvalue { %"compiler/source:Span", i32, i64 } %t15, i32 %t16, 1
  %t19 = insertvalue { %"compiler/source:Span", i32, i64 } %t17, i64 %t11, 2
  %t20 = getelementptr { i64, [5 x i64] }, ptr %t12, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64 } %t19, ptr %t20
  %t21 = load { i64, [5 x i64] }, ptr %t12
  %t23 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t21, ptr %t23
  store ptr %t23, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistItem(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/check:reflList" %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/check:reflList"
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l15 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca %"compiler/source:Span"
  %l25 = alloca %"compiler/msgs:Msg"
  %l26 = alloca i64
  %l32 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/check:reflList" %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load %"compiler/source:Span", ptr %l1
  %t3 = load %"compiler/check:reflList", ptr %l2
  %t7 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistItems(ptr %v0, ptr %s0, ptr %t1, %"compiler/source:Span" %t2, %"compiler/check:reflList" %t3)
  store { i64, ptr } %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t8, ptr %l4, !tbaa !27
  %t9 = getelementptr %"compiler/check:reflList", ptr %l2, i32 0, i32 1
  %t10 = load i32, ptr %t9, !tbaa !23
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t14 = icmp eq i32 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t16, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = icmp slt i64 %t18, 0
  br i1 %t20, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb7
bb6:
  %t22 = load i64, ptr %l3, !tbaa !24
  %t23 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t28 = icmp sge i64 %t22, %t25
  store i1 %t28, ptr %l15, !tbaa !21
  br label %bb7
bb7:
  %t30 = load i1, ptr %l15, !tbaa !21
  br i1 %t30, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l20, !tbaa !29
  %t32 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t32, ptr %l21
  %t33 = load i64, ptr %l3, !tbaa !24
  %t34 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t39 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflIndexRange(ptr %s2, i64 %t33, i64 %t36)
  store %"compiler/msgs:Msg" %t39, ptr %l25
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t40 = load ptr, ptr %l20, !tbaa !29
  %t41 = load %"compiler/source:Span", ptr %l21
  %t42 = load %"compiler/msgs:Msg", ptr %l25
  %t43 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t40, %"compiler/source:Span" %t41, %"compiler/msgs:Msg" %t42)
  store i64 %t43, ptr %l26
  br label %bb11
bb11:
  %t44 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t44, ptr %rv
  br label %ret
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load %"compiler/check:reflList", ptr %l2
  %t48 = load i64, ptr %l3, !tbaa !24
  %t50 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr i64, ptr %t51, i64 %t48
  %t53 = load i64, ptr %t52, !tbaa !34
  %t57 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescriptor(ptr %v0, ptr %t46, %"compiler/check:reflList" %t47, i64 %t53)
  store i32 %t57, ptr %l32
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t58 = load i32, ptr %l32, !tbaa !23
  store i32 %t58, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloop(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, i64, i64 }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, i64, i64 }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca %"compiler/check:nullNarrow"
  %l27 = alloca i64
  %l31 = alloca { i64, i64, i64 }
  %l36 = alloca ptr
  %l41 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca ptr
  %l50 = alloca %"compiler/source:Span"
  %l53 = alloca ptr
  %l55 = alloca ptr
  %l67 = alloca i64
  %l69 = alloca ptr
  %l72 = alloca i64
  %l73 = alloca i32
  %l74 = alloca i64
  %l76 = alloca ptr
  %l79 = alloca i64
  %l80 = alloca i32
  %l86 = alloca ptr
  %l92 = alloca i64
  %l96 = alloca { i64, i64, i64 }
  %l104 = alloca ptr
  %l107 = alloca i64
  %l113 = alloca ptr
  %l116 = alloca i64
  %l120 = alloca i64
  %l123 = alloca i64
  %l142 = alloca ptr
  %l146 = alloca %"compiler/check:nullNarrow"
  %l149 = alloca i1
  %l151 = alloca ptr
  %l153 = alloca ptr
  %l154 = alloca i64
  %l157 = alloca %"compiler/check:nullNarrow"
  %l168 = alloca ptr
  %l179 = alloca i1
  %l182 = alloca { i64, ptr }
  %l184 = alloca { i64, ptr }
  %l185 = alloca i1
  %l187 = alloca ptr
  %l188 = alloca ptr
  %l190 = alloca ptr
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %t290 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 33
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l27
  br label %bb1
bb1:
  %t6 = load i64, ptr %l27, !tbaa !24
  store i64 %t6, ptr %l5, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  %t12 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t7, i32 2, %"compiler/source:Span" %t8)
  store { i64, i64, i64 } %t12, ptr %l31
  br label %bb2
bb2:
  %t13 = load { i64, i64, i64 }, ptr %l31
  store { i64, i64, i64 } %t13, ptr %l6
  %t14 = getelementptr { i64, i64, i64 }, ptr %l6, i32 0, i32 0
  %t15 = load i64, ptr %t14, !tbaa !24
  store i64 %t15, ptr %l7, !tbaa !24
  %t17 = getelementptr { i64, i64, i64 }, ptr %l6, i32 0, i32 1
  %t18 = load i64, ptr %t17, !tbaa !24
  store i64 %t18, ptr %l8, !tbaa !24
  %t20 = getelementptr { i64, i64, i64 }, ptr %l6, i32 0, i32 2
  %t21 = load i64, ptr %t20, !tbaa !24
  store i64 %t21, ptr %l9, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t23)
  store ptr %t25, ptr %l36
  br label %bb3
bb3:
  %t26 = load ptr, ptr %l36, !tbaa !29
  %t28 = getelementptr %"compiler/check:frame", ptr %t26, i32 0, i32 10
  %t29 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t28, i64 %t29)
  br label %bb4
bb4:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t32)
  store ptr %t34, ptr %l41
  br label %bb5
bb5:
  %t35 = load ptr, ptr %l41, !tbaa !29
  %t37 = getelementptr %"compiler/check:frame", ptr %t35, i32 0, i32 11
  %t38 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t37, i64 %t38)
  br label %bb6
bb6:
  %t41 = load ptr, ptr %l2, !tbaa !29
  %t43 = icmp eq ptr %t41, null
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb7, label %bb8
bb7:
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l48, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l49, !tbaa !29
  %t49 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t49, ptr %l50
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load ptr, ptr %l2, !tbaa !29
  %t54 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v1, ptr %t50, ptr %t51)
  store ptr %t54, ptr %l53
  br label %bb9
bb8:
  br label %bb12
bb9:
  %t55 = load i64, ptr %l7, !tbaa !24
  %t56 = load ptr, ptr %l49, !tbaa !29
  %t57 = load %"compiler/source:Span", ptr %l50
  %t58 = load ptr, ptr %l53, !tbaa !29
  %t60 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebreakUnless(ptr %v0, ptr %t56, %"compiler/source:Span" %t57, ptr %t58, i64 %t55)
  store ptr %t60, ptr %l55
  br label %bb10
bb10:
  %t61 = load ptr, ptr %l48, !tbaa !29
  %t62 = load ptr, ptr %l55, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t61, ptr %t62)
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t63 = load ptr, ptr %l2, !tbaa !29
  %t65 = icmp eq ptr %t63, null
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb13, label %bb14
bb13:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load ptr, ptr %l2, !tbaa !29
  %t71 = load i64, ptr %l7, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushNulls(ptr %v0, ptr %v1, ptr %t69, ptr %t70, i1 true, i64 %t71)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  %t75 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t75, 0
  %t79 = icmp sgt i64 %t77, 0
  br i1 %t79, label %bb17, label %bb18
bb17:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v2, ptr %t81, { i64, ptr } %t82)
  br label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb20
bb20:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t85)
  store ptr %t87, ptr %l69
  br label %bb21
bb21:
  %t88 = load ptr, ptr %l69, !tbaa !29
  %t90 = getelementptr %"compiler/check:frame", ptr %t88, i32 0, i32 10
  %t92 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t90)
  %t93 = extractvalue { i32, i64 } %t92, 1
  %t94 = extractvalue { i32, i64 } %t92, 0
  store i32 %t94, ptr %l73
  %t95 = icmp ne i32 %t94, 0
  br i1 %t95, label %bb23, label %ok.96
ok.96:
  store i64 %t93, ptr %l72
  br label %bb22
bb22:
  %t97 = load i64, ptr %l72, !tbaa !24
  store i64 %t97, ptr %l67, !tbaa !24
  br label %bb25
bb23:
  br label %bb24
bb24:
  call void @__olang_ert_req_clear()
  br label %bb25
bb25:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t98)
  store ptr %t100, ptr %l76
  br label %bb26
bb26:
  %t101 = load ptr, ptr %l76, !tbaa !29
  %t103 = getelementptr %"compiler/check:frame", ptr %t101, i32 0, i32 11
  %t105 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t103)
  %t106 = extractvalue { i32, i64 } %t105, 1
  %t107 = extractvalue { i32, i64 } %t105, 0
  store i32 %t107, ptr %l80
  %t108 = icmp ne i32 %t107, 0
  br i1 %t108, label %bb28, label %ok.109
ok.109:
  store i64 %t106, ptr %l79
  br label %bb27
bb27:
  %t110 = load i64, ptr %l79, !tbaa !24
  store i64 %t110, ptr %l74, !tbaa !24
  br label %bb30
bb28:
  br label %bb29
bb29:
  call void @__olang_ert_req_clear()
  br label %bb30
bb30:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load i64, ptr %l7, !tbaa !24
  %t113 = load i64, ptr %l8, !tbaa !24
  %t114 = load i64, ptr %l9, !tbaa !24
  %t115 = load i64, ptr %l5, !tbaa !24
  %t121 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t111, i64 %t112, i64 %t113, i64 %t114, i64 %t115)
  store ptr %t121, ptr %l86
  br label %bb31
bb31:
  %t122 = load ptr, ptr %l86, !tbaa !29
  store ptr %t122, ptr %l10, !tbaa !29
  store ptr null, ptr %l11, !tbaa !29
  %t123 = load ptr, ptr %l4, !tbaa !29
  %t125 = icmp eq ptr %t123, null
  %t127 = xor i1 %t125, true
  br i1 %t127, label %bb32, label %bb33
bb32:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/check:Checker", ptr %t129, i32 0, i32 33
  %t133 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t131)
  store i64 %t133, ptr %l92
  br label %bb34
bb33:
  br label %bb67
bb34:
  %t134 = load i64, ptr %l92, !tbaa !24
  store i64 %t134, ptr %l12, !tbaa !24
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load %"compiler/source:Span", ptr %l1
  %t140 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t135, i32 3, %"compiler/source:Span" %t136)
  store { i64, i64, i64 } %t140, ptr %l96
  br label %bb35
bb35:
  %t141 = load { i64, i64, i64 }, ptr %l96
  store { i64, i64, i64 } %t141, ptr %l13
  %t142 = getelementptr { i64, i64, i64 }, ptr %l13, i32 0, i32 0
  %t143 = load i64, ptr %t142, !tbaa !24
  store i64 %t143, ptr %l14, !tbaa !24
  %t145 = getelementptr { i64, i64, i64 }, ptr %l13, i32 0, i32 1
  %t146 = load i64, ptr %t145, !tbaa !24
  store i64 %t146, ptr %l15, !tbaa !24
  %t148 = getelementptr { i64, i64, i64 }, ptr %l13, i32 0, i32 2
  %t149 = load i64, ptr %t148, !tbaa !24
  store i64 %t149, ptr %l16, !tbaa !24
  %t151 = load ptr, ptr %l2, !tbaa !29
  %t153 = icmp eq ptr %t151, null
  %t155 = xor i1 %t153, true
  br i1 %t155, label %bb36, label %bb37
bb36:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t157)
  store ptr %t159, ptr %l104
  br label %bb38
bb37:
  br label %bb64
bb38:
  %t160 = load ptr, ptr %l104, !tbaa !29
  %t162 = getelementptr %"compiler/check:frame", ptr %t160, i32 0, i32 46
  %t164 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anullNarrow_3e_2e_H86c927da52ed537ecb3749a8061e4fd7(ptr %v0, ptr %t162)
  store i64 %t164, ptr %l107
  br label %bb39
bb39:
  %t165 = load i64, ptr %l107, !tbaa !24
  store i64 %t165, ptr %l17, !tbaa !24
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load ptr, ptr %l2, !tbaa !29
  %t168 = load i64, ptr %l14, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushNulls(ptr %v0, ptr %v1, ptr %t166, ptr %t167, i1 true, i64 %t168)
  br label %bb40
bb40:
  %t172 = load i64, ptr %l17, !tbaa !24
  store i64 %t172, ptr %l18, !tbaa !24
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t174)
  store ptr %t176, ptr %l113
  br label %bb41
bb41:
  %t177 = load ptr, ptr %l113, !tbaa !29
  %t179 = getelementptr %"compiler/check:frame", ptr %t177, i32 0, i32 46
  %t181 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anullNarrow_3e_2e_H86c927da52ed537ecb3749a8061e4fd7(ptr %v0, ptr %t179)
  store i64 %t181, ptr %l116
  br label %bb42
bb42:
  %t182 = load i64, ptr %l116, !tbaa !24
  store i64 %t182, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t183 = load i64, ptr %l19, !tbaa !24
  %t184 = load i64, ptr %l18, !tbaa !24
  %t187 = icmp sgt i64 %t183, %t184
  br i1 %t187, label %bb43, label %bb44
bb43:
  %t189 = load i64, ptr %l20, !tbaa !24
  %t191 = icmp sgt i64 %t189, 0
  br i1 %t191, label %bb45, label %bb46
bb44:
  store i64 0, ptr %l120, !tbaa !24
  br label %bb48
bb45:
  %t193 = load i64, ptr %l19, !tbaa !24
  %t194 = load i64, ptr %l18, !tbaa !24
  %t197 = sub i64 %t193, %t194
  %t198 = load i64, ptr %l20, !tbaa !24
  %t201 = add i64 %t197, %t198
  %t203 = sub i64 %t201, 1
  %t204 = load i64, ptr %l20, !tbaa !24
  %t207 = sdiv i64 %t203, %t204
  store i64 %t207, ptr %l123, !tbaa !24
  br label %bb47
bb46:
  store i64 0, ptr %l123, !tbaa !24
  br label %bb47
bb47:
  %t209 = load i64, ptr %l123, !tbaa !24
  store i64 %t209, ptr %l120, !tbaa !24
  br label %bb48
bb48:
  %t210 = load i64, ptr %l120, !tbaa !24
  store i64 %t210, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb49
bb49:
  store %olang.scope zeroinitializer, ptr %s9
  %t211 = load i64, ptr %l22, !tbaa !24
  %t212 = load i64, ptr %l21, !tbaa !24
  %t215 = icmp slt i64 %t211, %t212
  %t217 = xor i1 %t215, true
  br i1 %t217, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s9)
  br label %bb63
bb51:
  br label %bb52
bb52:
  %t219 = load i64, ptr %l18, !tbaa !24
  %t220 = load i64, ptr %l22, !tbaa !24
  %t221 = load i64, ptr %l20, !tbaa !24
  %t224 = mul i64 %t220, %t221
  %t227 = add i64 %t219, %t224
  store i64 %t227, ptr %l23, !tbaa !24
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t229)
  store ptr %t231, ptr %l142
  br label %bb53
bb53:
  %t232 = load ptr, ptr %l142, !tbaa !29
  %t234 = getelementptr %"compiler/check:frame", ptr %t232, i32 0, i32 46
  %t235 = load i64, ptr %l23, !tbaa !24
  %t238 = call %"compiler/check:nullNarrow" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anullNarrow_3e_2e_H9251d6c69ab4c1f2fc390a801d12eb1a(ptr %v0, ptr %v0, ptr %t234, i64 %t235)
  store %"compiler/check:nullNarrow" %t238, ptr %l146
  br label %bb54
bb54:
  %t239 = load %"compiler/check:nullNarrow", ptr %l146
  store %"compiler/check:nullNarrow" %t239, ptr %l24
  %t240 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t241 = getelementptr %"compiler/check:nullNarrow", ptr %l24, i32 0, i32 0
  %t242 = load { i64, ptr }, ptr %t241, !tbaa !27
  %t245 = call i1 @compiler_2fcheck_2eassignsName(ptr %v2, ptr %v0, { i64, ptr } %t240, { i64, ptr } %t242)
  store i1 %t245, ptr %l149
  br label %bb55
bb55:
  %t246 = load i1, ptr %l149, !tbaa !21
  br i1 %t246, label %bb56, label %bb57
bb56:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t249 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t247)
  store ptr %t249, ptr %l151
  br label %bb58
bb57:
  br label %bb61
bb58:
  %t250 = load ptr, ptr %l151, !tbaa !29
  %t252 = getelementptr %"compiler/check:frame", ptr %t250, i32 0, i32 46
  store ptr %t252, ptr %l153, !tbaa !29
  %t253 = load i64, ptr %l23, !tbaa !24
  store i64 %t253, ptr %l154, !tbaa !24
  %t254 = getelementptr %"compiler/check:nullNarrow", ptr %l24, i32 0, i32 0
  %t255 = load { i64, ptr }, ptr %t254, !tbaa !27
  %t256 = getelementptr %"compiler/check:nullNarrow", ptr %l24, i32 0, i32 1
  %t257 = load i64, ptr %t256, !tbaa !24
  %t260 = call %"compiler/check:nullNarrow" @compiler_2fcheck_3anullNarrow_2ector(ptr %v0, ptr %v0, { i64, ptr } %t255, i64 %t257, i1 true)
  store %"compiler/check:nullNarrow" %t260, ptr %l157
  br label %bb59
bb59:
  %t261 = load ptr, ptr %l153, !tbaa !29
  %t262 = load i64, ptr %l154, !tbaa !24
  %t263 = load %"compiler/check:nullNarrow", ptr %l157
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anullNarrow_3e_2e_H4655d3a13eddeb483b63f4107fff886e(ptr %v0, ptr %v0, ptr %t261, i64 %t262, %"compiler/check:nullNarrow" %t263)
  br label %bb60
bb60:
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s9)
  br label %bb62
bb62:
  %t264 = load i64, ptr %l22, !tbaa !24
  %t266 = add i64 %t264, 1
  store i64 %t266, ptr %l22, !tbaa !24
  br label %bb49
bb63:
  br label %bb64
bb64:
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v3, ptr %t268, ptr %t269)
  br label %bb65
bb65:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = load i64, ptr %l14, !tbaa !24
  %t275 = load i64, ptr %l15, !tbaa !24
  %t276 = load i64, ptr %l16, !tbaa !24
  %t277 = load i64, ptr %l12, !tbaa !24
  %t283 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t273, i64 %t274, i64 %t275, i64 %t276, i64 %t277)
  store ptr %t283, ptr %l168
  br label %bb66
bb66:
  %t284 = load ptr, ptr %l168, !tbaa !29
  store ptr %t284, ptr %l11, !tbaa !29
  br label %bb67
bb67:
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t287 = load %"compiler/source:Span", ptr %l1
  %t288 = load ptr, ptr %l10, !tbaa !29
  %t289 = load ptr, ptr %l11, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t290
  %t291 = getelementptr { i64, [3 x i64] }, ptr %t290, i32 0, i32 0
  store i64 4, ptr %t291
  %t293 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t287, 0
  %t295 = insertvalue { %"compiler/source:Span", ptr, ptr } %t293, ptr %t288, 1
  %t297 = insertvalue { %"compiler/source:Span", ptr, ptr } %t295, ptr %t289, 2
  %t298 = getelementptr { i64, [3 x i64] }, ptr %t290, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t297, ptr %t298
  %t299 = load { i64, [3 x i64] }, ptr %t290
  %t301 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t299, ptr %t301
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t286, ptr %t301)
  br label %bb68
bb68:
  %t304 = load ptr, ptr %l2, !tbaa !29
  %t306 = icmp eq ptr %t304, null
  %t308 = xor i1 %t306, true
  br i1 %t308, label %bb69, label %bb70
bb69:
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t311 = load %"compiler/source:Span", ptr %l1
  %t314 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t310, %"compiler/source:Span" %t311)
  store { i64, ptr } %t314, ptr %l182
  br label %bb71
bb70:
  store i1 false, ptr %l179, !tbaa !21
  br label %bb73
bb71:
  %t315 = load { i64, ptr }, ptr %l182, !tbaa !27
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %l184, !tbaa !27
  %t317 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t318 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s0, { i64, ptr } %t315, { i64, ptr } %t317)
  store i1 %t318, ptr %l185
  br label %bb72
bb72:
  %t319 = load i1, ptr %l185, !tbaa !21
  %t320 = xor i1 %t319, true
  store i1 %t320, ptr %l179, !tbaa !21
  br label %bb73
bb73:
  %t322 = load i1, ptr %l179, !tbaa !21
  br i1 %t322, label %bb74, label %bb75
bb74:
  %t323 = load ptr, ptr %l0, !tbaa !29
  store ptr %t323, ptr %l187, !tbaa !29
  %t324 = load ptr, ptr %l2, !tbaa !29
  store ptr %t324, ptr %l188, !tbaa !29
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t327 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t325)
  store ptr %t327, ptr %l190
  br label %bb76
bb75:
  br label %bb78
bb76:
  %t328 = load ptr, ptr %l190, !tbaa !29
  %t330 = getelementptr %"compiler/check:frame", ptr %t328, i32 0, i32 7
  %t331 = load i64, ptr %t330, !tbaa !24
  %t332 = load ptr, ptr %l187, !tbaa !29
  %t333 = load ptr, ptr %l188, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushNulls(ptr %v0, ptr %v1, ptr %t332, ptr %t333, i1 false, i64 %t331)
  br label %bb77
bb77:
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchExpr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i1 %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i1
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i64
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca { i64, i64, i64 }
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca ptr
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca ptr
  %l54 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca ptr
  %l59 = alloca i1
  %l60 = alloca { ptr, i1 }
  %l61 = alloca ptr
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l68 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i64
  %l71 = alloca { i64, ptr }
  %l72 = alloca i64
  %l73 = alloca i64
  %l75 = alloca ptr
  %l76 = alloca ptr
  %l77 = alloca { i64, i64, i64 }
  %l78 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca ptr
  %l83 = alloca i1
  %l84 = alloca ptr
  %l85 = alloca ptr
  %l86 = alloca { ptr, i1 }
  %l87 = alloca ptr
  %l88 = alloca ptr
  %l89 = alloca i64
  %l90 = alloca i64
  %l91 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l93 = alloca i64
  %l94 = alloca i64
  %l95 = alloca i64
  %l96 = alloca i64
  %l97 = alloca i64
  %l98 = alloca i64
  %lp99 = alloca ptr
  %l105 = alloca ptr
  %l108 = alloca i32
  %l111 = alloca %"compiler/source:Span"
  %l114 = alloca i64
  %l116 = alloca ptr
  %l120 = alloca ptr
  %l121 = alloca i1
  %l131 = alloca i64
  %l154 = alloca { i64, ptr }
  %l156 = alloca i32
  %l160 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l162 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l166 = alloca i32
  %l169 = alloca i1
  %l172 = alloca ptr
  %l177 = alloca i32
  %l178 = alloca { i64, ptr }
  %l183 = alloca i64
  %l186 = alloca i64
  %l211 = alloca i32
  %l214 = alloca i1
  %l216 = alloca ptr
  %l221 = alloca i32
  %l222 = alloca i1
  %l224 = alloca ptr
  %l229 = alloca i32
  %l230 = alloca { i64, ptr }
  %l235 = alloca i64
  %l238 = alloca i64
  %l262 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l264 = alloca ptr
  %l265 = alloca i1
  %l281 = alloca { i64, ptr }
  %l285 = alloca i1
  %l288 = alloca ptr
  %l294 = alloca %"compiler/source:Span"
  %l295 = alloca %"compiler/msgs:Msg"
  %l296 = alloca i64
  %l301 = alloca { i64, i64, i64 }
  %l307 = alloca i64
  %l308 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l310 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l318 = alloca i64
  %l321 = alloca i64
  %l340 = alloca { i64, ptr }
  %l344 = alloca i1
  %l345 = alloca i1
  %l350 = alloca ptr
  %l352 = alloca %"compiler/source:Span"
  %l353 = alloca %"compiler/msgs:Msg"
  %l354 = alloca i64
  %l357 = alloca i1
  %l358 = alloca i1
  %l363 = alloca ptr
  %l365 = alloca %"compiler/source:Span"
  %l366 = alloca %"compiler/msgs:Msg"
  %l367 = alloca i64
  %l368 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l373 = alloca i1
  %l374 = alloca ptr
  %l376 = alloca %"compiler/source:Span"
  %l378 = alloca ptr
  %l380 = alloca ptr
  %l381 = alloca ptr
  %l388 = alloca ptr
  %l395 = alloca ptr
  %l398 = alloca ptr
  %l400 = alloca { i64, ptr }
  %l401 = alloca %"compiler/typed:Alt"
  %l414 = alloca i1
  %l416 = alloca i1
  %l420 = alloca ptr
  %l422 = alloca { i64, ptr }
  %l429 = alloca ptr
  %l434 = alloca ptr
  %l440 = alloca %"compiler/source:Span"
  %l441 = alloca ptr
  %l445 = alloca i32
  %l449 = alloca i1
  %l453 = alloca ptr
  %l459 = alloca %"compiler/source:Span"
  %l462 = alloca { i64, ptr }
  %l464 = alloca %"compiler/msgs:Msg"
  %l465 = alloca i64
  %l466 = alloca ptr
  %l472 = alloca %"compiler/source:Span"
  %l473 = alloca ptr
  %l488 = alloca ptr
  %l489 = alloca ptr
  %l495 = alloca %"compiler/source:Span"
  %l497 = alloca %"compiler/source:Span"
  %l498 = alloca %"compiler/msgs:Msg"
  %l499 = alloca i64
  %l503 = alloca i1
  %l507 = alloca i1
  %l508 = alloca ptr
  %l514 = alloca i1
  %l519 = alloca ptr
  %l521 = alloca i32
  %l526 = alloca ptr
  %l535 = alloca i1
  %l538 = alloca i32
  %l543 = alloca i32
  %l546 = alloca i1
  %l547 = alloca i1
  %l549 = alloca i1
  %l554 = alloca i32
  %l559 = alloca i32
  %l562 = alloca i1
  %l567 = alloca i32
  %l569 = alloca i1
  %l570 = alloca ptr
  %l576 = alloca i1
  %l579 = alloca ptr
  %l584 = alloca i32
  %l585 = alloca i32
  %l588 = alloca i1
  %l591 = alloca i32
  %l592 = alloca ptr
  %l595 = alloca ptr
  %l596 = alloca i32
  %l602 = alloca %"compiler/source:Span"
  %l603 = alloca { ptr, i1 }
  %l609 = alloca ptr
  %l615 = alloca %"compiler/source:Span"
  %l616 = alloca i32
  %l617 = alloca i32
  %l626 = alloca ptr
  %l628 = alloca i1
  %l632 = alloca i1
  %l634 = alloca i1
  %l636 = alloca ptr
  %l639 = alloca %"compiler/source:Span"
  %l640 = alloca %"compiler/msgs:Msg"
  %l641 = alloca i64
  %l642 = alloca ptr
  %l644 = alloca %"compiler/source:Span"
  %l646 = alloca { i64, ptr }
  %l651 = alloca %"compiler/typed:Arm"
  %l659 = alloca i1
  %l661 = alloca i1
  %l664 = alloca ptr
  %l671 = alloca i32
  %l680 = alloca %"compiler/source:Span"
  %l681 = alloca %"compiler/msgs:Msg"
  %l682 = alloca i64
  %l684 = alloca i64
  %l688 = alloca i64
  %l691 = alloca i64
  %l711 = alloca i1
  %l718 = alloca i1
  %l720 = alloca i64
  %l723 = alloca { i64, ptr }
  %l726 = alloca { i64, ptr }
  %l727 = alloca i32
  %l736 = alloca { i64, ptr }
  %l748 = alloca ptr
  %l749 = alloca ptr
  %l750 = alloca i32
  %l754 = alloca i1
  %l765 = alloca ptr
  %l766 = alloca i32
  %l772 = alloca { i64, i64, i64 }
  %l778 = alloca i64
  %l786 = alloca ptr
  %l799 = alloca i1
  %l801 = alloca ptr
  %l808 = alloca ptr
  %l813 = alloca i1
  %l816 = alloca i32
  %l821 = alloca i32
  %l824 = alloca i1
  %l825 = alloca i1
  %l827 = alloca i1
  %l832 = alloca i32
  %l837 = alloca i32
  %l840 = alloca i1
  %l845 = alloca i32
  %l847 = alloca i1
  %l848 = alloca ptr
  %l857 = alloca i1
  %l860 = alloca ptr
  %l865 = alloca i32
  %l866 = alloca i32
  %l869 = alloca i1
  %l872 = alloca i32
  %l877 = alloca ptr
  %l880 = alloca ptr
  %l881 = alloca i32
  %l890 = alloca %"compiler/source:Span"
  %l891 = alloca { ptr, i1 }
  %l897 = alloca ptr
  %l906 = alloca %"compiler/source:Span"
  %l907 = alloca i32
  %l908 = alloca i32
  %l917 = alloca ptr
  %l922 = alloca %"compiler/source:Span"
  %l929 = alloca %"compiler/typed:Arm"
  %l933 = alloca i64
  %l935 = alloca i1
  %l946 = alloca i1
  %l949 = alloca i1
  %l953 = alloca i64
  %l960 = alloca { i64, ptr }
  %l961 = alloca ptr
  %l962 = alloca %"compiler/source:Span"
  %l966 = alloca i1
  %l971 = alloca { i64, ptr }
  %l973 = alloca { i64, ptr }
  %l976 = alloca { i64, ptr }
  %l979 = alloca { i64, ptr }
  %l981 = alloca %"compiler/msgs:Msg"
  %l982 = alloca i64
  %l985 = alloca i1
  %l987 = alloca i64
  %l989 = alloca i1
  %l994 = alloca i32
  %l998 = alloca ptr
  %l1003 = alloca i32
  %l1004 = alloca { i64, ptr }
  %l1006 = alloca i64
  %l1010 = alloca i64
  %l1013 = alloca i64
  %l1033 = alloca i1
  %l1035 = alloca i1
  %l1040 = alloca ptr
  %l1041 = alloca %"compiler/source:Span"
  %l1043 = alloca { i64, ptr }
  %l1046 = alloca { i64, ptr }
  %l1047 = alloca { i64, ptr }
  %l1050 = alloca { i64, ptr }
  %l1052 = alloca %"compiler/msgs:Msg"
  %l1053 = alloca i64
  %l1057 = alloca i1
  %l1060 = alloca i1
  %l1064 = alloca ptr
  %l1070 = alloca %"compiler/source:Span"
  %l1073 = alloca { i64, ptr }
  %l1075 = alloca %"compiler/msgs:Msg"
  %l1076 = alloca i64
  %l1078 = alloca ptr
  %l1082 = alloca i32
  %l1086 = alloca { i64, ptr }
  %l1087 = alloca %"compiler/typed:Block"
  %l1089 = alloca %"compiler/source:Span"
  %l1094 = alloca %"compiler/typed:Arm"
  %l1099 = alloca %"compiler/source:Span"
  %l1100 = alloca i32
  %l1101 = alloca { i64, ptr }
  %l1103 = alloca { i64, ptr }
  %l1106 = alloca %"compiler/typed:Match"
  %s7 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s43 = alloca %olang.scope
  %s45 = alloca %olang.scope
  %s47 = alloca %olang.scope
  %s52 = alloca %olang.scope
  %s53 = alloca %olang.scope
  %s56 = alloca %olang.scope
  %s70 = alloca %olang.scope
  %s74 = alloca %olang.scope
  %s75 = alloca %olang.scope
  %s78 = alloca %olang.scope
  %rv = alloca ptr
  %t57 = alloca { i64, [2 x i64] }, align 8
  %t82 = alloca { i64, [3 x i64] }, align 8
  %t102 = alloca { i64, [4 x i64] }, align 8
  %t1354 = alloca i64
  %t1745 = alloca { i64, [3 x i64] }, align 8
  %t2107 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t4 = getelementptr %"compiler/ast:Match", ptr %t2, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t7 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t11 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t1, ptr %t5, i32 %t7)
  store ptr %t11, ptr %l105
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l105, !tbaa !29
  store ptr %t12, ptr %l5, !tbaa !29
  %t13 = load ptr, ptr %l5, !tbaa !29
  %t16 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t13)
  store i32 %t16, ptr %l108
  br label %bb2
bb2:
  %t17 = load i32, ptr %l108, !tbaa !23
  store i32 %t17, ptr %l6, !tbaa !23
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t20 = getelementptr %"compiler/ast:Match", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t21)
  store %"compiler/source:Span" %t23, ptr %l111
  br label %bb3
bb3:
  %t24 = load %"compiler/source:Span", ptr %l111
  store %"compiler/source:Span" %t24, ptr %l7
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 33
  %t29 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t27)
  store i64 %t29, ptr %l114
  br label %bb4
bb4:
  %t30 = load i64, ptr %l114, !tbaa !24
  store i64 %t30, ptr %l8, !tbaa !24
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t33 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %t31)
  store ptr %t33, ptr %l116
  br label %bb5
bb5:
  %t34 = load ptr, ptr %l116, !tbaa !29
  store ptr %t34, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t35 = load ptr, ptr %l9, !tbaa !29
  %t37 = icmp eq ptr %t35, null
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb6, label %bb7
bb6:
  %t41 = load ptr, ptr %l9, !tbaa !29
  store ptr %t41, ptr %l120, !tbaa !29
  store i1 false, ptr %l121, !tbaa !21
  %t42 = load ptr, ptr %l120, !tbaa !29
  %t43 = icmp ne ptr %t42, null
  br i1 %t43, label %bb8, label %bb9
bb7:
  br label %bb15
bb8:
  %t45 = load ptr, ptr %l120, !tbaa !29
  %t46 = load i64, ptr %t45
  %t48 = icmp eq i64 %t46, 0
  store i1 %t48, ptr %l121, !tbaa !21
  br label %bb9
bb9:
  %t49 = load i1, ptr %l121, !tbaa !21
  br i1 %t49, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb14
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t50 = load i1, ptr %l10, !tbaa !21
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb16, label %bb17
bb16:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l7
  %t56 = load i32, ptr %l6, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t57
  %t58 = getelementptr { i64, [2 x i64] }, ptr %t57, i32 0, i32 0
  store i64 0, ptr %t58
  %t59 = load { i64, [2 x i64] }, ptr %t57
  %t65 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t54, i32 0, %"compiler/source:Span" %t55, i32 %t56, i32 2, { i64, [2 x i64] } %t59)
  store i64 %t65, ptr %l131
  br label %bb18
bb17:
  br label %bb21
bb18:
  %t66 = load i64, ptr %l131, !tbaa !24
  store i64 %t66, ptr %l11, !tbaa !24
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i64, ptr %l11, !tbaa !24
  %t69 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v0, ptr %t67, i64 %t68, ptr %t69)
  br label %bb19
bb19:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 33
  %t76 = load %"compiler/source:Span", ptr %l7
  %t77 = load i64, ptr %l11, !tbaa !24
  %t79 = trunc i64 %t77 to i32
  %t81 = load ptr, ptr %l5, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t82
  %t83 = getelementptr { i64, [3 x i64] }, ptr %t82, i32 0, i32 0
  store i64 0, ptr %t83
  %t85 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t76, 0
  %t87 = insertvalue { %"compiler/source:Span", i32, ptr } %t85, i32 %t79, 1
  %t89 = insertvalue { %"compiler/source:Span", i32, ptr } %t87, ptr %t81, 2
  %t90 = getelementptr { i64, [3 x i64] }, ptr %t82, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t89, ptr %t90
  %t91 = load { i64, [3 x i64] }, ptr %t82
  %t93 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t91, ptr %t93
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v0, ptr %t75, ptr %t93)
  br label %bb20
bb20:
  %t96 = load %"compiler/source:Span", ptr %l7
  %t97 = load i32, ptr %l6, !tbaa !23
  %t98 = load i64, ptr %l11, !tbaa !24
  %t100 = trunc i64 %t98 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t102
  %t103 = getelementptr { i64, [4 x i64] }, ptr %t102, i32 0, i32 0
  store i64 0, ptr %t103
  %t105 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t96, 0
  %t107 = insertvalue { %"compiler/source:Span", i32, i32 } %t105, i32 %t97, 1
  %t109 = insertvalue { %"compiler/source:Span", i32, i32 } %t107, i32 %t100, 2
  %t110 = getelementptr { i64, [4 x i64] }, ptr %t102, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t109, ptr %t110
  %t111 = load { i64, [4 x i64] }, ptr %t102
  %t113 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t111, ptr %t113
  store ptr %t113, ptr %l9, !tbaa !29
  br label %bb21
bb21:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/check:Checker", ptr %t115, i32 0, i32 33
  %t118 = load i64, ptr %l8, !tbaa !24
  %t121 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t117, i64 %t118)
  store { i64, ptr } %t121, ptr %l154
  br label %bb22
bb22:
  %t122 = load { i64, ptr }, ptr %l154, !tbaa !27
  store { i64, ptr } %t122, ptr %l12, !tbaa !27
  %t123 = load i1, ptr %l3, !tbaa !21
  br i1 %t123, label %bb23, label %bb24
bb23:
  store i32 %a4, ptr %l156, !tbaa !23
  br label %bb25
bb24:
  %t127 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t127, ptr %l156, !tbaa !23
  br label %bb25
bb25:
  %t129 = load i32, ptr %l156, !tbaa !23
  store i32 %t129, ptr %l13, !tbaa !23
  %t130 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t130, ptr %l14, !tbaa !23
  %t132 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aArm_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t132, ptr %l160
  br label %bb26
bb26:
  %t133 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l160
  %t134 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t133, ptr %t134
  store ptr %t134, ptr %l15, !tbaa !29
  %t136 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cBool_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t136, ptr %l162
  br label %bb27
bb27:
  %t137 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l162
  %t138 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t137, ptr %t138
  store ptr %t138, ptr %l16, !tbaa !29
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i32, ptr %l6, !tbaa !23
  %t144 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t140, i32 %t141)
  store i32 %t144, ptr %l166
  br label %bb28
bb28:
  %t145 = load i32, ptr %l166, !tbaa !23
  store i32 %t145, ptr %l17, !tbaa !23
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load i32, ptr %l17, !tbaa !23
  %t150 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t146, i32 %t147)
  store i1 %t150, ptr %l169
  br label %bb29
bb29:
  %t151 = load i1, ptr %l169, !tbaa !21
  br i1 %t151, label %bb30, label %bb31
bb30:
  store i64 0, ptr %l18, !tbaa !24
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/check:Checker", ptr %t152, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t157 = getelementptr %"compiler/generic:Program", ptr %t155, i32 0, i32 2
  store ptr %t157, ptr %l172, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/check:Checker", ptr %t158, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = getelementptr %"compiler/generic:Program", ptr %t161, i32 0, i32 2
  %t164 = load i32, ptr %l17, !tbaa !23
  %t167 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t163, i32 %t164)
  store i32 %t167, ptr %l177
  br label %bb32
bb31:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/check:Checker", ptr %t168, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !29
  %t173 = getelementptr %"compiler/generic:Program", ptr %t171, i32 0, i32 2
  %t174 = load i32, ptr %l17, !tbaa !23
  %t177 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t173, i32 %t174)
  store i32 %t177, ptr %l211
  br label %bb47
bb32:
  %t178 = load ptr, ptr %l172, !tbaa !29
  %t179 = load i32, ptr %l177, !tbaa !23
  %t180 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t178, i32 %t179)
  store { i64, ptr } %t180, ptr %l178
  br label %bb33
bb33:
  %t181 = load { i64, ptr }, ptr %l178, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t181, 0
  store i64 %t182, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t184 = load i64, ptr %l19, !tbaa !24
  %t185 = load i64, ptr %l18, !tbaa !24
  %t188 = icmp sgt i64 %t184, %t185
  br i1 %t188, label %bb34, label %bb35
bb34:
  %t190 = load i64, ptr %l20, !tbaa !24
  %t192 = icmp sgt i64 %t190, 0
  br i1 %t192, label %bb36, label %bb37
bb35:
  store i64 0, ptr %l183, !tbaa !24
  br label %bb39
bb36:
  %t194 = load i64, ptr %l19, !tbaa !24
  %t195 = load i64, ptr %l18, !tbaa !24
  %t198 = sub i64 %t194, %t195
  %t199 = load i64, ptr %l20, !tbaa !24
  %t202 = add i64 %t198, %t199
  %t204 = sub i64 %t202, 1
  %t205 = load i64, ptr %l20, !tbaa !24
  %t208 = sdiv i64 %t204, %t205
  store i64 %t208, ptr %l186, !tbaa !24
  br label %bb38
bb37:
  store i64 0, ptr %l186, !tbaa !24
  br label %bb38
bb38:
  %t210 = load i64, ptr %l186, !tbaa !24
  store i64 %t210, ptr %l183, !tbaa !24
  br label %bb39
bb39:
  %t211 = load i64, ptr %l183, !tbaa !24
  store i64 %t211, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s7
  %t212 = load i64, ptr %l22, !tbaa !24
  %t213 = load i64, ptr %l21, !tbaa !24
  %t216 = icmp slt i64 %t212, %t213
  %t218 = xor i1 %t216, true
  br i1 %t218, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s7)
  br label %bb46
bb42:
  br label %bb43
bb43:
  %t220 = load i64, ptr %l18, !tbaa !24
  %t221 = load i64, ptr %l22, !tbaa !24
  %t222 = load i64, ptr %l20, !tbaa !24
  %t225 = mul i64 %t221, %t222
  %t228 = add i64 %t220, %t225
  store i64 %t228, ptr %l23, !tbaa !24
  %t230 = load ptr, ptr %l16, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t230, i1 false)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s7)
  br label %bb45
bb45:
  %t232 = load i64, ptr %l22, !tbaa !24
  %t234 = add i64 %t232, 1
  store i64 %t234, ptr %l22, !tbaa !24
  br label %bb40
bb46:
  br label %bb71
bb47:
  %t236 = load i32, ptr %l211
  %t238 = trunc i64 29 to i32
  %t239 = icmp eq i32 %t236, %t238
  br i1 %t239, label %bb48, label %bb49
bb48:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr %"compiler/check:Checker", ptr %t241, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !29
  store ptr %t244, ptr %l216, !tbaa !29
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t247 = getelementptr %"compiler/check:Checker", ptr %t245, i32 0, i32 1
  %t248 = load ptr, ptr %t247, !tbaa !29
  %t250 = getelementptr %"compiler/generic:Program", ptr %t248, i32 0, i32 2
  %t251 = load i32, ptr %l17, !tbaa !23
  %t254 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t250, i32 %t251)
  store i32 %t254, ptr %l221
  br label %bb50
bb49:
  store i1 false, ptr %l214, !tbaa !21
  br label %bb52
bb50:
  %t255 = load ptr, ptr %l216, !tbaa !29
  %t256 = load i32, ptr %l221, !tbaa !23
  %t257 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsClosedTrait(ptr %v0, ptr %t255, i32 %t256)
  store i1 %t257, ptr %l222
  br label %bb51
bb51:
  %t258 = load i1, ptr %l222, !tbaa !21
  store i1 %t258, ptr %l214, !tbaa !21
  br label %bb52
bb52:
  %t259 = load i1, ptr %l214, !tbaa !21
  br i1 %t259, label %bb53, label %bb54
bb53:
  store i64 0, ptr %l24, !tbaa !24
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t262 = getelementptr %"compiler/check:Checker", ptr %t260, i32 0, i32 1
  %t263 = load ptr, ptr %t262, !tbaa !29
  store ptr %t263, ptr %l224, !tbaa !29
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t266 = getelementptr %"compiler/check:Checker", ptr %t264, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !29
  %t269 = getelementptr %"compiler/generic:Program", ptr %t267, i32 0, i32 2
  %t270 = load i32, ptr %l17, !tbaa !23
  %t273 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t269, i32 %t270)
  store i32 %t273, ptr %l229
  br label %bb55
bb54:
  br label %bb70
bb55:
  %t274 = load ptr, ptr %l224, !tbaa !29
  %t275 = load i32, ptr %l229, !tbaa !23
  %t276 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMembers(ptr %v0, ptr %t274, i32 %t275)
  store { i64, ptr } %t276, ptr %l230
  br label %bb56
bb56:
  %t277 = load { i64, ptr }, ptr %l230, !tbaa !27
  %t278 = extractvalue { i64, ptr } %t277, 0
  store i64 %t278, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t280 = load i64, ptr %l25, !tbaa !24
  %t281 = load i64, ptr %l24, !tbaa !24
  %t284 = icmp sgt i64 %t280, %t281
  br i1 %t284, label %bb57, label %bb58
bb57:
  %t286 = load i64, ptr %l26, !tbaa !24
  %t288 = icmp sgt i64 %t286, 0
  br i1 %t288, label %bb59, label %bb60
bb58:
  store i64 0, ptr %l235, !tbaa !24
  br label %bb62
bb59:
  %t290 = load i64, ptr %l25, !tbaa !24
  %t291 = load i64, ptr %l24, !tbaa !24
  %t294 = sub i64 %t290, %t291
  %t295 = load i64, ptr %l26, !tbaa !24
  %t298 = add i64 %t294, %t295
  %t300 = sub i64 %t298, 1
  %t301 = load i64, ptr %l26, !tbaa !24
  %t304 = sdiv i64 %t300, %t301
  store i64 %t304, ptr %l238, !tbaa !24
  br label %bb61
bb60:
  store i64 0, ptr %l238, !tbaa !24
  br label %bb61
bb61:
  %t306 = load i64, ptr %l238, !tbaa !24
  store i64 %t306, ptr %l235, !tbaa !24
  br label %bb62
bb62:
  %t307 = load i64, ptr %l235, !tbaa !24
  store i64 %t307, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb63
bb63:
  store %olang.scope zeroinitializer, ptr %s12
  %t308 = load i64, ptr %l28, !tbaa !24
  %t309 = load i64, ptr %l27, !tbaa !24
  %t312 = icmp slt i64 %t308, %t309
  %t314 = xor i1 %t312, true
  br i1 %t314, label %bb64, label %bb65
bb64:
  call void @__olang_scope_close(ptr %s12)
  br label %bb69
bb65:
  br label %bb66
bb66:
  %t316 = load i64, ptr %l24, !tbaa !24
  %t317 = load i64, ptr %l28, !tbaa !24
  %t318 = load i64, ptr %l26, !tbaa !24
  %t321 = mul i64 %t317, %t318
  %t324 = add i64 %t316, %t321
  store i64 %t324, ptr %l29, !tbaa !24
  %t326 = load ptr, ptr %l16, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t326, i1 false)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s12)
  br label %bb68
bb68:
  %t328 = load i64, ptr %l28, !tbaa !24
  %t330 = add i64 %t328, 1
  store i64 %t330, ptr %l28, !tbaa !24
  br label %bb63
bb69:
  br label %bb70
bb70:
  br label %bb71
bb71:
  store i1 false, ptr %l30, !tbaa !21
  store i1 false, ptr %l31, !tbaa !21
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t334 = getelementptr %"compiler/check:Checker", ptr %t332, i32 0, i32 94
  %t335 = load i1, ptr %t334, !tbaa !21
  store i1 %t335, ptr %l32, !tbaa !21
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t339 = getelementptr %"compiler/check:Checker", ptr %t337, i32 0, i32 94
  store i1 false, ptr %t339, !tbaa !21
  %t340 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3ccompiler_2fast_3aPattern_26_3e_26_3e_2ector(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t340, ptr %l262
  br label %bb72
bb72:
  %t341 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l262
  %t342 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t341, ptr %t342
  store ptr %t342, ptr %l33, !tbaa !29
  store i64 -1, ptr %l34, !tbaa !24
  %t344 = load ptr, ptr %l9, !tbaa !29
  store ptr %t344, ptr %l264, !tbaa !29
  store i1 false, ptr %l265, !tbaa !21
  %t345 = load ptr, ptr %l264, !tbaa !29
  %t346 = icmp ne ptr %t345, null
  br i1 %t346, label %bb73, label %bb74
bb73:
  %t348 = load ptr, ptr %l264, !tbaa !29
  %t349 = load i64, ptr %t348
  %t351 = icmp eq i64 %t349, 0
  store i1 %t351, ptr %l265, !tbaa !21
  br label %bb74
bb74:
  %t352 = load i1, ptr %l265, !tbaa !21
  br i1 %t352, label %bb75, label %bb76
bb75:
  %t353 = load ptr, ptr %l9, !tbaa !29
  %t355 = getelementptr { i64, [4 x i64] }, ptr %t353, i32 0, i32 1
  %t356 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t355, i32 0, i32 2
  %t357 = load i32, ptr %t356
  store i32 %t357, ptr %l35, !tbaa !23
  br label %bb77
bb76:
  br label %bb81
bb77:
  %t359 = load i1, ptr %l10, !tbaa !21
  br i1 %t359, label %bb78, label %bb79
bb78:
  %t361 = load i32, ptr %l35, !tbaa !23
  %t363 = sext i32 %t361 to i64
  store i64 %t363, ptr %l34, !tbaa !24
  br label %bb80
bb79:
  br label %bb80
bb80:
  br label %bb82
bb81:
  br label %bb82
bb82:
  %t365 = load ptr, ptr %l2, !tbaa !29
  %t367 = getelementptr %"compiler/ast:Match", ptr %t365, i32 0, i32 3
  %t368 = load { i64, ptr }, ptr %t367, !tbaa !27
  store { i64, ptr } %t368, ptr %l36, !tbaa !27
  store i64 0, ptr %l37, !tbaa !24
  %t370 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t372 = extractvalue { i64, ptr } %t370, 0
  store i64 %t372, ptr %l38, !tbaa !24
  br label %bb83
bb83:
  store %olang.scope zeroinitializer, ptr %s18
  %t374 = load i64, ptr %l37, !tbaa !24
  %t375 = load i64, ptr %l38, !tbaa !24
  %t378 = icmp slt i64 %t374, %t375
  %t380 = xor i1 %t378, true
  br i1 %t380, label %bb84, label %bb85
bb84:
  call void @__olang_scope_close(ptr %s18)
  br label %bb306
bb85:
  br label %bb86
bb86:
  %t382 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t382, ptr %l281, !tbaa !27
  %t383 = load i64, ptr %l37, !tbaa !24
  %t385 = getelementptr { i64, ptr }, ptr %l281, i32 0, i32 1
  %t386 = load ptr, ptr %t385, !tbaa !27
  %t387 = getelementptr ptr, ptr %t386, i64 %t383
  %t388 = load ptr, ptr %t387, !tbaa !39
  store ptr %t388, ptr %l39, !tbaa !29
  %t390 = load i1, ptr %l30, !tbaa !21
  br i1 %t390, label %bb87, label %bb88
bb87:
  %t392 = load i1, ptr %l31, !tbaa !21
  %t394 = xor i1 %t392, true
  store i1 %t394, ptr %l285, !tbaa !21
  br label %bb89
bb88:
  store i1 false, ptr %l285, !tbaa !21
  br label %bb89
bb89:
  %t396 = load i1, ptr %l285, !tbaa !21
  br i1 %t396, label %bb90, label %bb91
bb90:
  store %olang.scope zeroinitializer, ptr %s19
  %t397 = load ptr, ptr %l0, !tbaa !29
  store ptr %t397, ptr %l288, !tbaa !29
  %t398 = load ptr, ptr %l39, !tbaa !29
  %t400 = getelementptr %"compiler/ast:Case", ptr %t398, i32 0, i32 0
  %t401 = getelementptr %"compiler/source:Span", ptr %t400, i32 0, i32 0
  %t402 = load i32, ptr %t401, !tbaa !23
  %t403 = load ptr, ptr %l39, !tbaa !29
  %t405 = getelementptr %"compiler/ast:Case", ptr %t403, i32 0, i32 0
  %t406 = getelementptr %"compiler/source:Span", ptr %t405, i32 0, i32 0
  %t407 = load i32, ptr %t406, !tbaa !23
  %t409 = add i32 %t407, 4
  %t412 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s19, i32 %t402, i32 %t409)
  store %"compiler/source:Span" %t412, ptr %l294
  br label %bb92
bb91:
  br label %bb95
bb92:
  %t413 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseAfterWildcard(ptr %s19)
  store %"compiler/msgs:Msg" %t413, ptr %l295
  br label %bb93
bb93:
  %t414 = load ptr, ptr %l288, !tbaa !29
  %t415 = load %"compiler/source:Span", ptr %l294
  %t416 = load %"compiler/msgs:Msg", ptr %l295
  %t417 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s19, ptr %t414, %"compiler/source:Span" %t415, %"compiler/msgs:Msg" %t416)
  store i64 %t417, ptr %l296
  br label %bb94
bb94:
  store i1 true, ptr %l31, !tbaa !21
  call void @__olang_scope_close(ptr %s19)
  br label %bb95
bb95:
  %t418 = load ptr, ptr %l0, !tbaa !29
  %t419 = load ptr, ptr %l39, !tbaa !29
  %t421 = getelementptr %"compiler/ast:Case", ptr %t419, i32 0, i32 0
  %t422 = load %"compiler/source:Span", ptr %t421
  %t426 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t418, i32 1, %"compiler/source:Span" %t422)
  store { i64, i64, i64 } %t426, ptr %l301
  br label %bb96
bb96:
  %t427 = load { i64, i64, i64 }, ptr %l301
  store { i64, i64, i64 } %t427, ptr %l40
  %t428 = getelementptr { i64, i64, i64 }, ptr %l40, i32 0, i32 0
  %t429 = load i64, ptr %t428, !tbaa !24
  store i64 %t429, ptr %l41, !tbaa !24
  %t431 = getelementptr { i64, i64, i64 }, ptr %l40, i32 0, i32 1
  %t432 = load i64, ptr %t431, !tbaa !24
  store i64 %t432, ptr %l42, !tbaa !24
  %t434 = getelementptr { i64, i64, i64 }, ptr %l40, i32 0, i32 2
  %t435 = load i64, ptr %t434, !tbaa !24
  store i64 %t435, ptr %l43, !tbaa !24
  %t437 = load ptr, ptr %l0, !tbaa !29
  %t439 = getelementptr %"compiler/check:Checker", ptr %t437, i32 0, i32 33
  %t441 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t439)
  store i64 %t441, ptr %l307
  br label %bb97
bb97:
  %t442 = load i64, ptr %l307, !tbaa !24
  store i64 %t442, ptr %l44, !tbaa !24
  %t443 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aAlt_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t443, ptr %l308
  br label %bb98
bb98:
  %t444 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l308
  %t445 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t444, ptr %t445
  store ptr %t445, ptr %l45, !tbaa !29
  %t447 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t447, ptr %l310
  br label %bb99
bb99:
  %t448 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l310
  %t449 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t448, ptr %t449
  store ptr %t449, ptr %l46, !tbaa !29
  store i64 0, ptr %l47, !tbaa !24
  %t451 = load ptr, ptr %l39, !tbaa !29
  %t453 = getelementptr %"compiler/ast:Case", ptr %t451, i32 0, i32 1
  %t454 = load { i64, ptr }, ptr %t453, !tbaa !27
  %t456 = extractvalue { i64, ptr } %t454, 0
  store i64 %t456, ptr %l48, !tbaa !24
  store i64 1, ptr %l49, !tbaa !24
  %t458 = load i64, ptr %l48, !tbaa !24
  %t459 = load i64, ptr %l47, !tbaa !24
  %t462 = icmp sgt i64 %t458, %t459
  br i1 %t462, label %bb100, label %bb101
bb100:
  %t464 = load i64, ptr %l49, !tbaa !24
  %t466 = icmp sgt i64 %t464, 0
  br i1 %t466, label %bb102, label %bb103
bb101:
  store i64 0, ptr %l318, !tbaa !24
  br label %bb105
bb102:
  %t468 = load i64, ptr %l48, !tbaa !24
  %t469 = load i64, ptr %l47, !tbaa !24
  %t472 = sub i64 %t468, %t469
  %t473 = load i64, ptr %l49, !tbaa !24
  %t476 = add i64 %t472, %t473
  %t478 = sub i64 %t476, 1
  %t479 = load i64, ptr %l49, !tbaa !24
  %t482 = sdiv i64 %t478, %t479
  store i64 %t482, ptr %l321, !tbaa !24
  br label %bb104
bb103:
  store i64 0, ptr %l321, !tbaa !24
  br label %bb104
bb104:
  %t484 = load i64, ptr %l321, !tbaa !24
  store i64 %t484, ptr %l318, !tbaa !24
  br label %bb105
bb105:
  %t485 = load i64, ptr %l318, !tbaa !24
  store i64 %t485, ptr %l50, !tbaa !24
  store i64 0, ptr %l51, !tbaa !24
  br label %bb106
bb106:
  store %olang.scope zeroinitializer, ptr %s21
  %t486 = load i64, ptr %l51, !tbaa !24
  %t487 = load i64, ptr %l50, !tbaa !24
  %t490 = icmp slt i64 %t486, %t487
  %t492 = xor i1 %t490, true
  br i1 %t492, label %bb107, label %bb108
bb107:
  call void @__olang_scope_close(ptr %s21)
  br label %bb165
bb108:
  br label %bb109
bb109:
  %t494 = load i64, ptr %l47, !tbaa !24
  %t495 = load i64, ptr %l51, !tbaa !24
  %t496 = load i64, ptr %l49, !tbaa !24
  %t499 = mul i64 %t495, %t496
  %t502 = add i64 %t494, %t499
  store i64 %t502, ptr %l52, !tbaa !24
  %t504 = load ptr, ptr %l39, !tbaa !29
  %t506 = getelementptr %"compiler/ast:Case", ptr %t504, i32 0, i32 1
  %t507 = load { i64, ptr }, ptr %t506, !tbaa !27
  store { i64, ptr } %t507, ptr %l340, !tbaa !27
  %t508 = load i64, ptr %l52, !tbaa !24
  %t510 = getelementptr { i64, ptr }, ptr %l340, i32 0, i32 1
  %t511 = load ptr, ptr %t510, !tbaa !27
  %t512 = getelementptr ptr, ptr %t511, i64 %t508
  %t513 = load ptr, ptr %t512, !tbaa !39
  store ptr %t513, ptr %l53, !tbaa !29
  %t515 = load ptr, ptr %l53, !tbaa !29
  %t517 = call i1 @compiler_2fcheck_2eisWild(ptr %v1, ptr %t515)
  store i1 %t517, ptr %l344
  br label %bb110
bb110:
  %t518 = load i1, ptr %l344, !tbaa !21
  br i1 %t518, label %bb111, label %bb112
bb111:
  %t519 = load ptr, ptr %l39, !tbaa !29
  %t521 = getelementptr %"compiler/ast:Case", ptr %t519, i32 0, i32 1
  %t522 = load { i64, ptr }, ptr %t521, !tbaa !27
  %t524 = extractvalue { i64, ptr } %t522, 0
  %t526 = icmp sgt i64 %t524, 1
  store i1 %t526, ptr %l345, !tbaa !21
  br label %bb113
bb112:
  store i1 false, ptr %l345, !tbaa !21
  br label %bb113
bb113:
  %t528 = load i1, ptr %l345, !tbaa !21
  br i1 %t528, label %bb114, label %bb115
bb114:
  store %olang.scope zeroinitializer, ptr %s22
  %t529 = load ptr, ptr %l0, !tbaa !29
  store ptr %t529, ptr %l350, !tbaa !29
  %t530 = load ptr, ptr %l53, !tbaa !29
  %t532 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t530)
  store %"compiler/source:Span" %t532, ptr %l352
  br label %bb116
bb115:
  br label %bb119
bb116:
  %t533 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eWildcardNotAlone(ptr %s22)
  store %"compiler/msgs:Msg" %t533, ptr %l353
  br label %bb117
bb117:
  %t534 = load ptr, ptr %l350, !tbaa !29
  %t535 = load %"compiler/source:Span", ptr %l352
  %t536 = load %"compiler/msgs:Msg", ptr %l353
  %t537 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s22, ptr %t534, %"compiler/source:Span" %t535, %"compiler/msgs:Msg" %t536)
  store i64 %t537, ptr %l354
  br label %bb118
bb118:
  call void @__olang_scope_close(ptr %s22)
  br label %bb119
bb119:
  %t538 = load ptr, ptr %l0, !tbaa !29
  %t539 = load ptr, ptr %l53, !tbaa !29
  %t542 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindsType(ptr %v0, ptr %v1, ptr %t538, ptr %t539)
  store i1 %t542, ptr %l357
  br label %bb120
bb120:
  %t543 = load i1, ptr %l357, !tbaa !21
  br i1 %t543, label %bb121, label %bb122
bb121:
  %t544 = load ptr, ptr %l39, !tbaa !29
  %t546 = getelementptr %"compiler/ast:Case", ptr %t544, i32 0, i32 1
  %t547 = load { i64, ptr }, ptr %t546, !tbaa !27
  %t549 = extractvalue { i64, ptr } %t547, 0
  %t551 = icmp sgt i64 %t549, 1
  store i1 %t551, ptr %l358, !tbaa !21
  br label %bb123
bb122:
  store i1 false, ptr %l358, !tbaa !21
  br label %bb123
bb123:
  %t553 = load i1, ptr %l358, !tbaa !21
  br i1 %t553, label %bb124, label %bb125
bb124:
  store %olang.scope zeroinitializer, ptr %s23
  %t554 = load ptr, ptr %l0, !tbaa !29
  store ptr %t554, ptr %l363, !tbaa !29
  %t555 = load ptr, ptr %l53, !tbaa !29
  %t557 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t555)
  store %"compiler/source:Span" %t557, ptr %l365
  br label %bb126
bb125:
  br label %bb129
bb126:
  %t558 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyCaseAlone(ptr %s23)
  store %"compiler/msgs:Msg" %t558, ptr %l366
  br label %bb127
bb127:
  %t559 = load ptr, ptr %l363, !tbaa !29
  %t560 = load %"compiler/source:Span", ptr %l365
  %t561 = load %"compiler/msgs:Msg", ptr %l366
  %t562 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s23, ptr %t559, %"compiler/source:Span" %t560, %"compiler/msgs:Msg" %t561)
  store i64 %t562, ptr %l367
  br label %bb128
bb128:
  call void @__olang_scope_close(ptr %s23)
  br label %bb129
bb129:
  %t563 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBind_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t563, ptr %l368
  br label %bb130
bb130:
  %t564 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l368
  %t565 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t564, ptr %t565
  store ptr %t565, ptr %l54, !tbaa !29
  store ptr null, ptr %l55, !tbaa !29
  %t567 = load ptr, ptr %l0, !tbaa !29
  %t568 = load ptr, ptr %l53, !tbaa !29
  %t569 = load i64, ptr %l34, !tbaa !24
  %t573 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseName(ptr %v0, ptr %v1, ptr %t567, ptr %t568, i64 %t569)
  store i1 %t573, ptr %l373
  br label %bb131
bb131:
  %t574 = load i1, ptr %l373, !tbaa !21
  br i1 %t574, label %bb132, label %bb133
bb132:
  %t575 = load ptr, ptr %l0, !tbaa !29
  store ptr %t575, ptr %l374, !tbaa !29
  %t576 = load ptr, ptr %l53, !tbaa !29
  %t578 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t576)
  store %"compiler/source:Span" %t578, ptr %l376
  br label %bb134
bb133:
  %t579 = load ptr, ptr %l0, !tbaa !29
  store ptr %t579, ptr %l380, !tbaa !29
  %t580 = load ptr, ptr %l53, !tbaa !29
  store ptr %t580, ptr %l381, !tbaa !29
  %t581 = load ptr, ptr %l9, !tbaa !29
  %t583 = icmp eq ptr %t581, null
  br i1 %t583, label %bb136, label %bb137
bb134:
  %t585 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t586 = load ptr, ptr %l374, !tbaa !29
  %t587 = load %"compiler/source:Span", ptr %l376
  %t589 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t586, %"compiler/source:Span" %t587, i32 %t585, i64 1)
  store ptr %t589, ptr %l378
  br label %bb135
bb135:
  %t590 = load ptr, ptr %l378, !tbaa !29
  store ptr %t590, ptr %l55, !tbaa !29
  br label %bb140
bb136:
  call void @__olang_check_failed(ptr @olang_loc_d3fec93f25782e10_68d55d5867a9701c)
  unreachable
bb137:
  br label %bb138
bb138:
  %t592 = load ptr, ptr %l9, !tbaa !29
  %t593 = load i32, ptr %l6, !tbaa !23
  %t594 = load ptr, ptr %l54, !tbaa !29
  %t595 = load i64, ptr %l41, !tbaa !24
  %t596 = load ptr, ptr %l380, !tbaa !29
  %t597 = load ptr, ptr %l381, !tbaa !29
  %t602 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epattern(ptr %v0, ptr %v1, ptr %t596, ptr %t597, ptr %t592, i32 %t593, ptr %t594, i64 %t595)
  store ptr %t602, ptr %l388
  br label %bb139
bb139:
  %t603 = load ptr, ptr %l388, !tbaa !29
  store ptr %t603, ptr %l55, !tbaa !29
  br label %bb140
bb140:
  %t605 = load ptr, ptr %l0, !tbaa !29
  %t606 = load ptr, ptr %l54, !tbaa !29
  %t607 = load ptr, ptr %l46, !tbaa !29
  %t608 = load i64, ptr %l52, !tbaa !24
  %t609 = load ptr, ptr %l53, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ealtNames(ptr %v0, ptr %v0, ptr %v0, ptr %v1, ptr %t605, ptr %t606, ptr %t607, i64 %t608, ptr %t609)
  br label %bb141
bb141:
  %t615 = load ptr, ptr %l45, !tbaa !29
  store ptr %t615, ptr %l395, !tbaa !29
  %t616 = load ptr, ptr %l55, !tbaa !29
  %t618 = icmp eq ptr %t616, null
  br i1 %t618, label %bb142, label %bb143
bb142:
  call void @__olang_check_failed(ptr @olang_loc_55099387dbe6ec6f_8ffe0a81fb6ca70b)
  unreachable
bb143:
  br label %bb144
bb144:
  %t620 = load ptr, ptr %l55, !tbaa !29
  store ptr %t620, ptr %l398, !tbaa !29
  %t621 = load ptr, ptr %l54, !tbaa !29
  %t623 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBind_26_3e_2eToA_Haa3aaef1a08a39694cf52a6e640ce172(ptr %v0, ptr %v0, ptr %t621)
  store { i64, ptr } %t623, ptr %l400
  br label %bb145
bb145:
  %t624 = load ptr, ptr %l398, !tbaa !29
  %t625 = load { i64, ptr }, ptr %l400, !tbaa !27
  %t626 = call %"compiler/typed:Alt" @compiler_2ftyped_3aAlt_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t624, { i64, ptr } %t625)
  store %"compiler/typed:Alt" %t626, ptr %l401
  br label %bb146
bb146:
  %t627 = load %"compiler/typed:Alt", ptr %l401
  %t628 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Alt" %t627, ptr %t628
  %t629 = load ptr, ptr %l395, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aAlt_26_3e_2ePush_3ccompiler_2ftyped_3aAlt_26_3e(ptr %v0, ptr %v0, ptr %t629, ptr %t628)
  br label %bb147
bb147:
  %t631 = load ptr, ptr %l39, !tbaa !29
  %t633 = getelementptr %"compiler/ast:Case", ptr %t631, i32 0, i32 3
  %t634 = load ptr, ptr %t633, !tbaa !29
  %t636 = icmp eq ptr %t634, null
  br i1 %t636, label %bb148, label %bb149
bb148:
  %t638 = load ptr, ptr %l0, !tbaa !29
  %t639 = load ptr, ptr %l53, !tbaa !29
  %t640 = load i32, ptr %l17, !tbaa !23
  %t641 = load ptr, ptr %l16, !tbaa !29
  %t642 = load i1, ptr %l30, !tbaa !21
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecover(ptr %v0, ptr %v1, ptr %v0, ptr %t638, ptr %t639, i32 %t640, ptr %t641, i1 %t642)
  br label %bb150
bb149:
  br label %bb151
bb150:
  br label %bb151
bb151:
  %t648 = load ptr, ptr %l39, !tbaa !29
  %t650 = getelementptr %"compiler/ast:Case", ptr %t648, i32 0, i32 3
  %t651 = load ptr, ptr %t650, !tbaa !29
  %t653 = icmp eq ptr %t651, null
  br i1 %t653, label %bb152, label %bb153
bb152:
  %t655 = load ptr, ptr %l53, !tbaa !29
  %t657 = call i1 @compiler_2fcheck_2eisWild(ptr %v1, ptr %t655)
  store i1 %t657, ptr %l416
  br label %bb154
bb153:
  store i1 false, ptr %l414, !tbaa !21
  br label %bb155
bb154:
  %t658 = load i1, ptr %l416, !tbaa !21
  store i1 %t658, ptr %l414, !tbaa !21
  br label %bb155
bb155:
  %t659 = load i1, ptr %l414, !tbaa !21
  br i1 %t659, label %bb156, label %bb157
bb156:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb158
bb157:
  br label %bb158
bb158:
  %t660 = load ptr, ptr %l39, !tbaa !29
  %t662 = getelementptr %"compiler/ast:Case", ptr %t660, i32 0, i32 3
  %t663 = load ptr, ptr %t662, !tbaa !29
  %t665 = icmp eq ptr %t663, null
  br i1 %t665, label %bb159, label %bb160
bb159:
  %t667 = load ptr, ptr %l33, !tbaa !29
  store ptr %t667, ptr %l420, !tbaa !29
  %t668 = load ptr, ptr %l53, !tbaa !29
  %t670 = call { i64, ptr } @compiler_2fcheck_2epatRow(ptr %v1, ptr %t668)
  store { i64, ptr } %t670, ptr %l422
  br label %bb161
bb160:
  br label %bb163
bb161:
  %t671 = load ptr, ptr %l420, !tbaa !29
  %t672 = load { i64, ptr }, ptr %l422, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fast_3aPattern_26_H1d860e259259c4952a7ac353d360c942(ptr %v1, ptr %v1, ptr %t671, { i64, ptr } %t672)
  br label %bb162
bb162:
  br label %bb163
bb163:
  call void @__olang_scope_close(ptr %s21)
  br label %bb164
bb164:
  %t673 = load i64, ptr %l51, !tbaa !24
  %t675 = add i64 %t673, 1
  store i64 %t675, ptr %l51, !tbaa !24
  br label %bb106
bb165:
  store ptr null, ptr %l56, !tbaa !29
  %t677 = load ptr, ptr %l39, !tbaa !29
  %t679 = getelementptr %"compiler/ast:Case", ptr %t677, i32 0, i32 3
  %t680 = load ptr, ptr %t679, !tbaa !29
  %t682 = icmp eq ptr %t680, null
  %t684 = xor i1 %t682, true
  br i1 %t684, label %bb166, label %bb167
bb166:
  %t686 = load ptr, ptr %l0, !tbaa !29
  store ptr %t686, ptr %l429, !tbaa !29
  %t687 = load ptr, ptr %l0, !tbaa !29
  %t688 = load ptr, ptr %l39, !tbaa !29
  %t690 = getelementptr %"compiler/ast:Case", ptr %t688, i32 0, i32 3
  %t691 = load ptr, ptr %t690, !tbaa !29
  %t692 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t696 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t687, ptr %t691, i32 %t692)
  store ptr %t696, ptr %l434
  br label %bb168
bb167:
  br label %bb193
bb168:
  %t697 = load ptr, ptr %l39, !tbaa !29
  %t699 = getelementptr %"compiler/ast:Case", ptr %t697, i32 0, i32 3
  %t700 = load ptr, ptr %t699, !tbaa !29
  %t702 = icmp eq ptr %t700, null
  br i1 %t702, label %bb169, label %bb170
bb169:
  call void @__olang_check_failed(ptr @olang_loc_43973455075247be_e5a2b369b5afd60a)
  unreachable
bb170:
  br label %bb171
bb171:
  %t704 = load ptr, ptr %l39, !tbaa !29
  %t706 = getelementptr %"compiler/ast:Case", ptr %t704, i32 0, i32 3
  %t707 = load ptr, ptr %t706, !tbaa !29
  %t709 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t707)
  store %"compiler/source:Span" %t709, ptr %l440
  br label %bb172
bb172:
  %t710 = load ptr, ptr %l429, !tbaa !29
  %t711 = load ptr, ptr %l434, !tbaa !29
  %t712 = load %"compiler/source:Span", ptr %l440
  %t713 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t710, ptr %t711, %"compiler/source:Span" %t712)
  store ptr %t713, ptr %l441
  br label %bb173
bb173:
  %t714 = load ptr, ptr %l441, !tbaa !29
  store ptr %t714, ptr %l56, !tbaa !29
  %t716 = load ptr, ptr %l56, !tbaa !29
  %t719 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t716)
  store i32 %t719, ptr %l445
  br label %bb174
bb174:
  %t720 = load i32, ptr %l445, !tbaa !23
  store i32 %t720, ptr %l57, !tbaa !23
  %t721 = load i32, ptr %l57, !tbaa !23
  %t722 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t725 = icmp ne i32 %t721, %t722
  br i1 %t725, label %bb175, label %bb176
bb175:
  %t727 = load i32, ptr %l57, !tbaa !23
  %t728 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t731 = icmp ne i32 %t727, %t728
  store i1 %t731, ptr %l449, !tbaa !21
  br label %bb177
bb176:
  store i1 false, ptr %l449, !tbaa !21
  br label %bb177
bb177:
  %t733 = load i1, ptr %l449, !tbaa !21
  br i1 %t733, label %bb178, label %bb179
bb178:
  store %olang.scope zeroinitializer, ptr %s31
  %t734 = load ptr, ptr %l0, !tbaa !29
  store ptr %t734, ptr %l453, !tbaa !29
  %t735 = load ptr, ptr %l39, !tbaa !29
  %t737 = getelementptr %"compiler/ast:Case", ptr %t735, i32 0, i32 3
  %t738 = load ptr, ptr %t737, !tbaa !29
  %t740 = icmp eq ptr %t738, null
  br i1 %t740, label %bb180, label %bb181
bb179:
  br label %bb192
bb180:
  call void @__olang_check_failed(ptr @olang_loc_65d4e94bd43e965_f352b379463fef11)
  unreachable
bb181:
  br label %bb182
bb182:
  %t742 = load ptr, ptr %l39, !tbaa !29
  %t744 = getelementptr %"compiler/ast:Case", ptr %t742, i32 0, i32 3
  %t745 = load ptr, ptr %t744, !tbaa !29
  %t747 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t745)
  store %"compiler/source:Span" %t747, ptr %l459
  br label %bb183
bb183:
  %t748 = load ptr, ptr %l0, !tbaa !29
  %t749 = load i32, ptr %l57, !tbaa !23
  %t752 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s31, ptr %t748, i32 %t749)
  store { i64, ptr } %t752, ptr %l462
  br label %bb184
bb184:
  %t753 = load { i64, ptr }, ptr %l462, !tbaa !27
  %t754 = extractvalue { i64, ptr } %t753, 0
  %t755 = extractvalue { i64, ptr } %t753, 1
  %t756 = mul i64 %t754, 1
  %t757 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t756)
  call void @llvm.memcpy.p0.p0.i64(ptr %t757, ptr %t755, i64 %t756, i1 false)
  %t758 = insertvalue { i64, ptr } undef, i64 %t754, 0
  %t759 = insertvalue { i64, ptr } %t758, ptr %t757, 1
  %t761 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eGuardNotBool(ptr %s31, ptr %s31, { i64, ptr } %t759)
  store %"compiler/msgs:Msg" %t761, ptr %l464
  br label %bb185
bb185:
  %t762 = load ptr, ptr %l453, !tbaa !29
  %t763 = load %"compiler/source:Span", ptr %l459
  %t764 = load %"compiler/msgs:Msg", ptr %l464
  %t765 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s31, ptr %t762, %"compiler/source:Span" %t763, %"compiler/msgs:Msg" %t764)
  store i64 %t765, ptr %l465
  br label %bb186
bb186:
  %t766 = load ptr, ptr %l0, !tbaa !29
  store ptr %t766, ptr %l466, !tbaa !29
  %t767 = load ptr, ptr %l39, !tbaa !29
  %t769 = getelementptr %"compiler/ast:Case", ptr %t767, i32 0, i32 3
  %t770 = load ptr, ptr %t769, !tbaa !29
  %t772 = icmp eq ptr %t770, null
  br i1 %t772, label %bb187, label %bb188
bb187:
  call void @__olang_check_failed(ptr @olang_loc_d6337ada1dd29694_8ce46a4ddad80bd8)
  unreachable
bb188:
  br label %bb189
bb189:
  %t774 = load ptr, ptr %l39, !tbaa !29
  %t776 = getelementptr %"compiler/ast:Case", ptr %t774, i32 0, i32 3
  %t777 = load ptr, ptr %t776, !tbaa !29
  %t779 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t777)
  store %"compiler/source:Span" %t779, ptr %l472
  br label %bb190
bb190:
  %t780 = load ptr, ptr %l466, !tbaa !29
  %t781 = load %"compiler/source:Span", ptr %l472
  %t782 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t780, %"compiler/source:Span" %t781)
  store ptr %t782, ptr %l473
  br label %bb191
bb191:
  %t783 = load ptr, ptr %l473, !tbaa !29
  store ptr %t783, ptr %l56, !tbaa !29
  call void @__olang_scope_close(ptr %s31)
  br label %bb192
bb192:
  br label %bb193
bb193:
  %t785 = load ptr, ptr %l39, !tbaa !29
  %t787 = getelementptr %"compiler/ast:Case", ptr %t785, i32 0, i32 4
  %t788 = load { i64, ptr }, ptr %t787, !tbaa !27
  %t790 = extractvalue { i64, ptr } %t788, 0
  %t792 = icmp sgt i64 %t790, 0
  br i1 %t792, label %bb194, label %bb195
bb194:
  %t794 = load ptr, ptr %l0, !tbaa !29
  %t795 = load ptr, ptr %l39, !tbaa !29
  %t797 = getelementptr %"compiler/ast:Case", ptr %t795, i32 0, i32 4
  %t798 = load { i64, ptr }, ptr %t797, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %t794, { i64, ptr } %t798)
  br label %bb196
bb195:
  br label %bb197
bb196:
  br label %bb197
bb197:
  store ptr null, ptr %l58, !tbaa !29
  %t801 = load ptr, ptr %l39, !tbaa !29
  %t803 = getelementptr %"compiler/ast:Case", ptr %t801, i32 0, i32 5
  %t804 = load ptr, ptr %t803, !tbaa !29
  %t806 = icmp eq ptr %t804, null
  %t808 = xor i1 %t806, true
  br i1 %t808, label %bb198, label %bb199
bb198:
  %t810 = load i1, ptr %l3, !tbaa !21
  %t812 = xor i1 %t810, true
  br i1 %t812, label %bb200, label %bb201
bb199:
  br label %bb287
bb200:
  store %olang.scope zeroinitializer, ptr %s34
  %t814 = load ptr, ptr %l0, !tbaa !29
  store ptr %t814, ptr %l488, !tbaa !29
  %t815 = load ptr, ptr %l0, !tbaa !29
  store ptr %t815, ptr %l489, !tbaa !29
  %t816 = load ptr, ptr %l39, !tbaa !29
  %t818 = getelementptr %"compiler/ast:Case", ptr %t816, i32 0, i32 5
  %t819 = load ptr, ptr %t818, !tbaa !29
  %t821 = icmp eq ptr %t819, null
  br i1 %t821, label %bb202, label %bb203
bb201:
  %t823 = load i32, ptr %l14, !tbaa !23
  %t824 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t827 = icmp eq i32 %t823, %t824
  br i1 %t827, label %bb209, label %bb210
bb202:
  call void @__olang_check_failed(ptr @olang_loc_922951d2017ae1a3_4c5f7ef571495bf7)
  unreachable
bb203:
  br label %bb204
bb204:
  %t829 = load ptr, ptr %l39, !tbaa !29
  %t831 = getelementptr %"compiler/ast:Case", ptr %t829, i32 0, i32 5
  %t832 = load ptr, ptr %t831, !tbaa !29
  %t834 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t832)
  store %"compiler/source:Span" %t834, ptr %l495
  br label %bb205
bb205:
  %t835 = getelementptr %"compiler/source:Span", ptr %l495, i32 0, i32 0
  %t836 = load i32, ptr %t835, !tbaa !23
  %t837 = load ptr, ptr %l489, !tbaa !29
  %t839 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordBefore(ptr %v0, ptr %s34, ptr %t837, i32 %t836, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d28, i32 0, i32 1) })
  store %"compiler/source:Span" %t839, ptr %l497
  br label %bb206
bb206:
  %t840 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrowInStatement(ptr %s34)
  store %"compiler/msgs:Msg" %t840, ptr %l498
  br label %bb207
bb207:
  %t841 = load ptr, ptr %l488, !tbaa !29
  %t842 = load %"compiler/source:Span", ptr %l497
  %t843 = load %"compiler/msgs:Msg", ptr %l498
  %t844 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s34, ptr %t841, %"compiler/source:Span" %t842, %"compiler/msgs:Msg" %t843)
  store i64 %t844, ptr %l499
  br label %bb208
bb208:
  call void @__olang_scope_close(ptr %s34)
  br label %bb286
bb209:
  %t845 = load i32, ptr %l13, !tbaa !23
  %t846 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t849 = icmp ne i32 %t845, %t846
  store i1 %t849, ptr %l503, !tbaa !21
  br label %bb211
bb210:
  store i1 false, ptr %l503, !tbaa !21
  br label %bb211
bb211:
  %t851 = load i1, ptr %l503, !tbaa !21
  br i1 %t851, label %bb212, label %bb213
bb212:
  %t852 = load ptr, ptr %l0, !tbaa !29
  store ptr %t852, ptr %l508, !tbaa !29
  %t853 = load ptr, ptr %l39, !tbaa !29
  %t855 = getelementptr %"compiler/ast:Case", ptr %t853, i32 0, i32 5
  %t856 = load ptr, ptr %t855, !tbaa !29
  %t858 = icmp eq ptr %t856, null
  br i1 %t858, label %bb214, label %bb215
bb213:
  store i1 false, ptr %l507, !tbaa !21
  br label %bb218
bb214:
  call void @__olang_check_failed(ptr @olang_loc_ce31ac887a0ebd22_30602d5443d77806)
  unreachable
bb215:
  br label %bb216
bb216:
  %t860 = load ptr, ptr %l39, !tbaa !29
  %t862 = getelementptr %"compiler/ast:Case", ptr %t860, i32 0, i32 5
  %t863 = load ptr, ptr %t862, !tbaa !29
  %t864 = load ptr, ptr %l508, !tbaa !29
  %t866 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t864, ptr %t863)
  store i1 %t866, ptr %l514
  br label %bb217
bb217:
  %t867 = load i1, ptr %l514, !tbaa !21
  store i1 %t867, ptr %l507, !tbaa !21
  br label %bb218
bb218:
  %t868 = load i1, ptr %l507, !tbaa !21
  br i1 %t868, label %bb219, label %bb220
bb219:
  %t869 = load ptr, ptr %l0, !tbaa !29
  %t870 = load ptr, ptr %l39, !tbaa !29
  %t872 = getelementptr %"compiler/ast:Case", ptr %t870, i32 0, i32 5
  %t873 = load ptr, ptr %t872, !tbaa !29
  %t874 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t878 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t869, ptr %t873, i32 %t874)
  store ptr %t878, ptr %l519
  br label %bb221
bb220:
  br label %bb223
bb221:
  %t879 = load ptr, ptr %l519, !tbaa !29
  %t881 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t879)
  store i32 %t881, ptr %l521
  br label %bb222
bb222:
  %t882 = load i32, ptr %l521, !tbaa !23
  store i32 %t882, ptr %l14, !tbaa !23
  br label %bb223
bb223:
  %t883 = load ptr, ptr %l0, !tbaa !29
  %t884 = load ptr, ptr %l39, !tbaa !29
  %t886 = getelementptr %"compiler/ast:Case", ptr %t884, i32 0, i32 5
  %t887 = load ptr, ptr %t886, !tbaa !29
  %t888 = load i32, ptr %l13, !tbaa !23
  %t892 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t883, ptr %t887, i32 %t888)
  store ptr %t892, ptr %l526
  br label %bb224
bb224:
  %t893 = load ptr, ptr %l526, !tbaa !29
  store ptr %t893, ptr %l58, !tbaa !29
  %t895 = load i32, ptr %l14, !tbaa !23
  %t896 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t899 = icmp eq i32 %t895, %t896
  br i1 %t899, label %bb225, label %bb226
bb225:
  %t901 = load i32, ptr %l13, !tbaa !23
  store i32 %t901, ptr %l14, !tbaa !23
  br label %bb227
bb226:
  br label %bb227
bb227:
  %t903 = load i32, ptr %l13, !tbaa !23
  %t904 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t907 = icmp eq i32 %t903, %t904
  br i1 %t907, label %bb228, label %bb229
bb228:
  %t909 = load ptr, ptr %l58, !tbaa !29
  %t912 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t909)
  store i32 %t912, ptr %l538
  br label %bb230
bb229:
  store i1 false, ptr %l535, !tbaa !21
  br label %bb231
bb230:
  %t913 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t914 = load i32, ptr %l538, !tbaa !23
  %t916 = icmp ne i32 %t914, %t913
  store i1 %t916, ptr %l535, !tbaa !21
  br label %bb231
bb231:
  %t918 = load i1, ptr %l535, !tbaa !21
  br i1 %t918, label %bb232, label %bb233
bb232:
  %t919 = load ptr, ptr %l58, !tbaa !29
  %t922 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t919)
  store i32 %t922, ptr %l543
  br label %bb234
bb233:
  br label %bb266
bb234:
  %t923 = load i32, ptr %l543, !tbaa !23
  store i32 %t923, ptr %l13, !tbaa !23
  %t924 = load ptr, ptr %l0, !tbaa !29
  %t925 = load i32, ptr %l13, !tbaa !23
  %t928 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t924, i32 %t925)
  store i1 %t928, ptr %l546
  br label %bb235
bb235:
  %t929 = load i1, ptr %l546, !tbaa !21
  br i1 %t929, label %bb236, label %bb237
bb236:
  %t930 = load ptr, ptr %l2, !tbaa !29
  %t932 = call i1 @compiler_2fcheck_2enullValue(ptr %v1, ptr %t930)
  store i1 %t932, ptr %l549
  br label %bb238
bb237:
  store i1 false, ptr %l547, !tbaa !21
  br label %bb239
bb238:
  %t933 = load i1, ptr %l549, !tbaa !21
  store i1 %t933, ptr %l547, !tbaa !21
  br label %bb239
bb239:
  %t934 = load i1, ptr %l547, !tbaa !21
  br i1 %t934, label %bb240, label %bb241
bb240:
  %t935 = load ptr, ptr %l0, !tbaa !29
  %t937 = getelementptr %"compiler/check:Checker", ptr %t935, i32 0, i32 1
  %t938 = load ptr, ptr %t937, !tbaa !29
  %t940 = getelementptr %"compiler/generic:Program", ptr %t938, i32 0, i32 2
  %t941 = load i32, ptr %l13, !tbaa !23
  %t944 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t940, i32 %t941)
  store i32 %t944, ptr %l554
  br label %bb242
bb241:
  br label %bb243
bb242:
  %t945 = load i32, ptr %l554, !tbaa !23
  store i32 %t945, ptr %l13, !tbaa !23
  br label %bb243
bb243:
  %t946 = load ptr, ptr %l0, !tbaa !29
  %t948 = getelementptr %"compiler/check:Checker", ptr %t946, i32 0, i32 1
  %t949 = load ptr, ptr %t948, !tbaa !29
  %t951 = getelementptr %"compiler/generic:Program", ptr %t949, i32 0, i32 2
  %t952 = load i32, ptr %l13, !tbaa !23
  %t955 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t951, i32 %t952)
  store i32 %t955, ptr %l559
  br label %bb244
bb244:
  %t956 = load i32, ptr %l559
  %t958 = trunc i64 19 to i32
  %t959 = icmp eq i32 %t956, %t958
  br i1 %t959, label %bb245, label %bb246
bb245:
  %t961 = load ptr, ptr %l0, !tbaa !29
  %t963 = getelementptr %"compiler/check:Checker", ptr %t961, i32 0, i32 1
  %t964 = load ptr, ptr %t963, !tbaa !29
  %t966 = getelementptr %"compiler/generic:Program", ptr %t964, i32 0, i32 2
  %t967 = load i32, ptr %l13, !tbaa !23
  %t970 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t966, i32 %t967)
  store i32 %t970, ptr %l567
  br label %bb247
bb246:
  store i1 false, ptr %l562, !tbaa !21
  br label %bb248
bb247:
  %t971 = load i32, ptr %l567, !tbaa !23
  %t972 = icmp ne i32 %t971, 0
  store i1 %t972, ptr %l562, !tbaa !21
  br label %bb248
bb248:
  %t974 = load i1, ptr %l562, !tbaa !21
  br i1 %t974, label %bb249, label %bb250
bb249:
  %t975 = load ptr, ptr %l0, !tbaa !29
  store ptr %t975, ptr %l570, !tbaa !29
  %t976 = load ptr, ptr %l39, !tbaa !29
  %t978 = getelementptr %"compiler/ast:Case", ptr %t976, i32 0, i32 5
  %t979 = load ptr, ptr %t978, !tbaa !29
  %t981 = icmp eq ptr %t979, null
  br i1 %t981, label %bb251, label %bb252
bb250:
  store i1 false, ptr %l569, !tbaa !21
  br label %bb255
bb251:
  call void @__olang_check_failed(ptr @olang_loc_14962851291ac789_3280c2851d649aed)
  unreachable
bb252:
  br label %bb253
bb253:
  %t983 = load ptr, ptr %l39, !tbaa !29
  %t985 = getelementptr %"compiler/ast:Case", ptr %t983, i32 0, i32 5
  %t986 = load ptr, ptr %t985, !tbaa !29
  %t987 = load ptr, ptr %l570, !tbaa !29
  %t989 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitArray(ptr %v0, ptr %v1, ptr %t987, ptr %t986)
  store i1 %t989, ptr %l576
  br label %bb254
bb254:
  %t990 = load i1, ptr %l576, !tbaa !21
  store i1 %t990, ptr %l569, !tbaa !21
  br label %bb255
bb255:
  %t991 = load i1, ptr %l569, !tbaa !21
  br i1 %t991, label %bb256, label %bb257
bb256:
  %t992 = load ptr, ptr %l0, !tbaa !29
  %t994 = getelementptr %"compiler/check:Checker", ptr %t992, i32 0, i32 1
  %t995 = load ptr, ptr %t994, !tbaa !29
  %t997 = getelementptr %"compiler/generic:Program", ptr %t995, i32 0, i32 2
  store ptr %t997, ptr %l579, !tbaa !29
  %t998 = load ptr, ptr %l0, !tbaa !29
  %t1000 = getelementptr %"compiler/check:Checker", ptr %t998, i32 0, i32 1
  %t1001 = load ptr, ptr %t1000, !tbaa !29
  %t1003 = getelementptr %"compiler/generic:Program", ptr %t1001, i32 0, i32 2
  %t1004 = load i32, ptr %l13, !tbaa !23
  %t1007 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t1003, i32 %t1004)
  store i32 %t1007, ptr %l584
  br label %bb258
bb257:
  br label %bb260
bb258:
  %t1008 = load ptr, ptr %l579, !tbaa !29
  %t1009 = load i32, ptr %l584, !tbaa !23
  %t1010 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t1008, i32 %t1009, i32 0)
  store i32 %t1010, ptr %l585
  br label %bb259
bb259:
  %t1011 = load i32, ptr %l585, !tbaa !23
  store i32 %t1011, ptr %l13, !tbaa !23
  br label %bb260
bb260:
  %t1012 = load ptr, ptr %l0, !tbaa !29
  %t1013 = load i32, ptr %l13, !tbaa !23
  %t1016 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1012, i32 %t1013)
  store i1 %t1016, ptr %l588
  br label %bb261
bb261:
  %t1017 = load i1, ptr %l588, !tbaa !21
  br i1 %t1017, label %bb262, label %bb263
bb262:
  %t1018 = load ptr, ptr %l0, !tbaa !29
  %t1019 = load i32, ptr %l13, !tbaa !23
  %t1022 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %t1018, i32 %t1019)
  store i32 %t1022, ptr %l591
  br label %bb264
bb263:
  br label %bb265
bb264:
  %t1023 = load i32, ptr %l591, !tbaa !23
  store i32 %t1023, ptr %l13, !tbaa !23
  br label %bb265
bb265:
  br label %bb266
bb266:
  store i1 false, ptr %l59, !tbaa !21
  %t1024 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1024, ptr %l592, !tbaa !29
  %t1025 = load ptr, ptr %l58, !tbaa !29
  %t1027 = icmp eq ptr %t1025, null
  br i1 %t1027, label %bb267, label %bb268
bb267:
  call void @__olang_check_failed(ptr @olang_loc_cfe87ec003b82748_d94fc5f0b326c124)
  unreachable
bb268:
  br label %bb269
bb269:
  %t1029 = load ptr, ptr %l58, !tbaa !29
  store ptr %t1029, ptr %l595, !tbaa !29
  %t1030 = load i32, ptr %l13, !tbaa !23
  store i32 %t1030, ptr %l596, !tbaa !23
  %t1031 = load ptr, ptr %l39, !tbaa !29
  %t1033 = getelementptr %"compiler/ast:Case", ptr %t1031, i32 0, i32 5
  %t1034 = load ptr, ptr %t1033, !tbaa !29
  %t1036 = icmp eq ptr %t1034, null
  br i1 %t1036, label %bb270, label %bb271
bb270:
  call void @__olang_check_failed(ptr @olang_loc_cfe87ec003b82748_d94fc5f0b326c124)
  unreachable
bb271:
  br label %bb272
bb272:
  %t1038 = load ptr, ptr %l39, !tbaa !29
  %t1040 = getelementptr %"compiler/ast:Case", ptr %t1038, i32 0, i32 5
  %t1041 = load ptr, ptr %t1040, !tbaa !29
  %t1043 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t1041)
  store %"compiler/source:Span" %t1043, ptr %l602
  br label %bb273
bb273:
  %t1044 = load ptr, ptr %l592, !tbaa !29
  %t1045 = load ptr, ptr %l595, !tbaa !29
  %t1046 = load i32, ptr %l596, !tbaa !23
  %t1047 = load %"compiler/source:Span", ptr %l602
  %t1048 = call { ptr, i1 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efitQuiet(ptr %v0, ptr %t1044, ptr %t1045, i32 %t1046, %"compiler/source:Span" %t1047)
  store { ptr, i1 } %t1048, ptr %l603
  br label %bb274
bb274:
  %t1049 = load { ptr, i1 }, ptr %l603
  store { ptr, i1 } %t1049, ptr %l60
  %t1050 = getelementptr { ptr, i1 }, ptr %l60, i32 0, i32 0
  %t1051 = load ptr, ptr %t1050, !tbaa !29
  store ptr %t1051, ptr %l58, !tbaa !29
  %t1054 = getelementptr { ptr, i1 }, ptr %l60, i32 0, i32 1
  %t1055 = load i1, ptr %t1054, !tbaa !21
  store i1 %t1055, ptr %l59, !tbaa !21
  %t1057 = load i1, ptr %l59, !tbaa !21
  %t1059 = xor i1 %t1057, true
  br i1 %t1059, label %bb275, label %bb276
bb275:
  %t1061 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1061, ptr %l609, !tbaa !29
  %t1062 = load ptr, ptr %l39, !tbaa !29
  %t1064 = getelementptr %"compiler/ast:Case", ptr %t1062, i32 0, i32 5
  %t1065 = load ptr, ptr %t1064, !tbaa !29
  %t1067 = icmp eq ptr %t1065, null
  br i1 %t1067, label %bb277, label %bb278
bb276:
  br label %bb285
bb277:
  call void @__olang_check_failed(ptr @olang_loc_2d3bd09159184b67_8c3194b4e7d06af3)
  unreachable
bb278:
  br label %bb279
bb279:
  %t1069 = load ptr, ptr %l39, !tbaa !29
  %t1071 = getelementptr %"compiler/ast:Case", ptr %t1069, i32 0, i32 5
  %t1072 = load ptr, ptr %t1071, !tbaa !29
  %t1074 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t1072)
  store %"compiler/source:Span" %t1074, ptr %l615
  br label %bb280
bb280:
  %t1075 = load i32, ptr %l14, !tbaa !23
  store i32 %t1075, ptr %l616, !tbaa !23
  %t1076 = load i32, ptr %l13, !tbaa !23
  store i32 %t1076, ptr %l617, !tbaa !23
  %t1077 = load ptr, ptr %l58, !tbaa !29
  %t1079 = icmp eq ptr %t1077, null
  br i1 %t1079, label %bb281, label %bb282
bb281:
  call void @__olang_check_failed(ptr @olang_loc_2d3bd09159184b67_8c3194b4e7d06af3)
  unreachable
bb282:
  br label %bb283
bb283:
  %t1081 = load ptr, ptr %l58, !tbaa !29
  %t1082 = load ptr, ptr %l609, !tbaa !29
  %t1083 = load %"compiler/source:Span", ptr %l615
  %t1084 = load i32, ptr %l616, !tbaa !23
  %t1085 = load i32, ptr %l617, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchValueMismatch(ptr %v0, ptr %v0, ptr %t1082, %"compiler/source:Span" %t1083, i32 %t1084, i32 %t1085, ptr %t1081)
  br label %bb284
bb284:
  br label %bb285
bb285:
  br label %bb286
bb286:
  br label %bb287
bb287:
  %t1087 = load ptr, ptr %l0, !tbaa !29
  %t1088 = load i64, ptr %l41, !tbaa !24
  %t1089 = load i64, ptr %l42, !tbaa !24
  %t1090 = load i64, ptr %l43, !tbaa !24
  %t1091 = load i64, ptr %l44, !tbaa !24
  %t1097 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t1087, i64 %t1088, i64 %t1089, i64 %t1090, i64 %t1091)
  store ptr %t1097, ptr %l626
  br label %bb288
bb288:
  %t1098 = load ptr, ptr %l626, !tbaa !29
  store ptr %t1098, ptr %l61, !tbaa !29
  %t1099 = load i1, ptr %l3, !tbaa !21
  br i1 %t1099, label %bb289, label %bb290
bb289:
  %t1101 = load ptr, ptr %l39, !tbaa !29
  %t1103 = getelementptr %"compiler/ast:Case", ptr %t1101, i32 0, i32 5
  %t1104 = load ptr, ptr %t1103, !tbaa !29
  %t1106 = icmp eq ptr %t1104, null
  store i1 %t1106, ptr %l628, !tbaa !21
  br label %bb291
bb290:
  store i1 false, ptr %l628, !tbaa !21
  br label %bb291
bb291:
  %t1108 = load i1, ptr %l628, !tbaa !21
  br i1 %t1108, label %bb292, label %bb293
bb292:
  %t1109 = load ptr, ptr %l61, !tbaa !29
  %t1111 = call i1 @compiler_2fcheck_2eleavesValue(ptr %v0, ptr %t1109)
  store i1 %t1111, ptr %l634
  br label %bb294
bb293:
  store i1 false, ptr %l632, !tbaa !21
  br label %bb295
bb294:
  %t1112 = load i1, ptr %l634, !tbaa !21
  %t1113 = xor i1 %t1112, true
  store i1 %t1113, ptr %l632, !tbaa !21
  br label %bb295
bb295:
  %t1115 = load i1, ptr %l632, !tbaa !21
  br i1 %t1115, label %bb296, label %bb297
bb296:
  store %olang.scope zeroinitializer, ptr %s43
  %t1116 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1116, ptr %l636, !tbaa !29
  %t1117 = load ptr, ptr %l0, !tbaa !29
  %t1118 = load ptr, ptr %l39, !tbaa !29
  %t1121 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebraceAfter(ptr %v0, ptr %v1, ptr %t1117, ptr %t1118)
  store %"compiler/source:Span" %t1121, ptr %l639
  br label %bb298
bb297:
  br label %bb301
bb298:
  %t1122 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseBlockStays(ptr %s43)
  store %"compiler/msgs:Msg" %t1122, ptr %l640
  br label %bb299
bb299:
  %t1123 = load ptr, ptr %l636, !tbaa !29
  %t1124 = load %"compiler/source:Span", ptr %l639
  %t1125 = load %"compiler/msgs:Msg", ptr %l640
  %t1126 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s43, ptr %t1123, %"compiler/source:Span" %t1124, %"compiler/msgs:Msg" %t1125)
  store i64 %t1126, ptr %l641
  br label %bb300
bb300:
  call void @__olang_scope_close(ptr %s43)
  br label %bb301
bb301:
  %t1127 = load ptr, ptr %l15, !tbaa !29
  store ptr %t1127, ptr %l642, !tbaa !29
  %t1128 = load ptr, ptr %l39, !tbaa !29
  %t1130 = getelementptr %"compiler/ast:Case", ptr %t1128, i32 0, i32 0
  %t1131 = load %"compiler/source:Span", ptr %t1130
  store %"compiler/source:Span" %t1131, ptr %l644
  %t1132 = load ptr, ptr %l45, !tbaa !29
  %t1134 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aAlt_26_3e_2eToAr_H3e99e7a5e111f31f686caa567ecdef7c(ptr %v0, ptr %v0, ptr %t1132)
  store { i64, ptr } %t1134, ptr %l646
  br label %bb302
bb302:
  %t1135 = load ptr, ptr %l56, !tbaa !29
  %t1136 = load ptr, ptr %l61, !tbaa !29
  %t1138 = load ptr, ptr %l58, !tbaa !29
  %t1139 = load %"compiler/source:Span", ptr %l644
  %t1140 = load { i64, ptr }, ptr %l646, !tbaa !27
  %t1144 = call %"compiler/typed:Arm" @compiler_2ftyped_3aArm_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t1139, { i64, ptr } %t1140, ptr %t1135, ptr %t1136, ptr %t1138)
  store %"compiler/typed:Arm" %t1144, ptr %l651
  br label %bb303
bb303:
  %t1145 = load %"compiler/typed:Arm", ptr %l651
  %t1146 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store %"compiler/typed:Arm" %t1145, ptr %t1146
  %t1147 = load ptr, ptr %l642, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aArm_26_3e_2ePush_3ccompiler_2ftyped_3aArm_26_3e(ptr %v0, ptr %v0, ptr %t1147, ptr %t1146)
  br label %bb304
bb304:
  call void @__olang_scope_close(ptr %s18)
  br label %bb305
bb305:
  %t1149 = load i64, ptr %l37, !tbaa !24
  %t1151 = add i64 %t1149, 1
  store i64 %t1151, ptr %l37, !tbaa !24
  br label %bb83
bb306:
  %t1153 = load ptr, ptr %l2, !tbaa !29
  %t1155 = getelementptr %"compiler/ast:Match", ptr %t1153, i32 0, i32 4
  %t1156 = load ptr, ptr %t1155, !tbaa !29
  %t1158 = icmp eq ptr %t1156, null
  %t1160 = xor i1 %t1158, true
  br i1 %t1160, label %bb307, label %bb308
bb307:
  %t1162 = load i1, ptr %l30, !tbaa !21
  store i1 %t1162, ptr %l659, !tbaa !21
  br label %bb309
bb308:
  store i1 false, ptr %l659, !tbaa !21
  br label %bb309
bb309:
  %t1164 = load i1, ptr %l659, !tbaa !21
  br i1 %t1164, label %bb310, label %bb311
bb310:
  %t1165 = load i1, ptr %l31, !tbaa !21
  %t1167 = xor i1 %t1165, true
  store i1 %t1167, ptr %l661, !tbaa !21
  br label %bb312
bb311:
  store i1 false, ptr %l661, !tbaa !21
  br label %bb312
bb312:
  %t1169 = load i1, ptr %l661, !tbaa !21
  br i1 %t1169, label %bb313, label %bb314
bb313:
  store %olang.scope zeroinitializer, ptr %s45
  %t1170 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1170, ptr %l664, !tbaa !29
  %t1171 = load ptr, ptr %l2, !tbaa !29
  %t1173 = getelementptr %"compiler/ast:Match", ptr %t1171, i32 0, i32 4
  %t1174 = load ptr, ptr %t1173, !tbaa !29
  %t1176 = icmp eq ptr %t1174, null
  br i1 %t1176, label %bb315, label %bb316
bb314:
  br label %bb324
bb315:
  call void @__olang_check_failed(ptr @olang_loc_ce7cfa545e041e73_169b678143e0167)
  unreachable
bb316:
  br label %bb317
bb317:
  %t1178 = load ptr, ptr %l2, !tbaa !29
  %t1180 = getelementptr %"compiler/ast:Match", ptr %t1178, i32 0, i32 4
  %t1181 = load ptr, ptr %t1180, !tbaa !29
  %t1184 = getelementptr %"compiler/ast:Case", ptr %t1181, i32 0, i32 0
  %t1185 = getelementptr %"compiler/source:Span", ptr %t1184, i32 0, i32 0
  %t1186 = load i32, ptr %t1185, !tbaa !23
  store i32 %t1186, ptr %l671, !tbaa !23
  %t1187 = load ptr, ptr %l2, !tbaa !29
  %t1189 = getelementptr %"compiler/ast:Match", ptr %t1187, i32 0, i32 4
  %t1190 = load ptr, ptr %t1189, !tbaa !29
  %t1192 = icmp eq ptr %t1190, null
  br i1 %t1192, label %bb318, label %bb319
bb318:
  call void @__olang_check_failed(ptr @olang_loc_ce7cfa545e041e73_169b678143e0167)
  unreachable
bb319:
  br label %bb320
bb320:
  %t1194 = load ptr, ptr %l2, !tbaa !29
  %t1196 = getelementptr %"compiler/ast:Match", ptr %t1194, i32 0, i32 4
  %t1197 = load ptr, ptr %t1196, !tbaa !29
  %t1200 = getelementptr %"compiler/ast:Case", ptr %t1197, i32 0, i32 0
  %t1201 = getelementptr %"compiler/source:Span", ptr %t1200, i32 0, i32 0
  %t1202 = load i32, ptr %t1201, !tbaa !23
  %t1204 = add i32 %t1202, 7
  %t1205 = load i32, ptr %l671, !tbaa !23
  %t1207 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s45, i32 %t1205, i32 %t1204)
  store %"compiler/source:Span" %t1207, ptr %l680
  br label %bb321
bb321:
  %t1208 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseAfterWildcard(ptr %s45)
  store %"compiler/msgs:Msg" %t1208, ptr %l681
  br label %bb322
bb322:
  %t1209 = load ptr, ptr %l664, !tbaa !29
  %t1210 = load %"compiler/source:Span", ptr %l680
  %t1211 = load %"compiler/msgs:Msg", ptr %l681
  %t1212 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s45, ptr %t1209, %"compiler/source:Span" %t1210, %"compiler/msgs:Msg" %t1211)
  store i64 %t1212, ptr %l682
  br label %bb323
bb323:
  call void @__olang_scope_close(ptr %s45)
  br label %bb324
bb324:
  store i64 0, ptr %l62, !tbaa !24
  %t1213 = load ptr, ptr %l16, !tbaa !29
  %t1215 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t1213)
  store i64 %t1215, ptr %l684
  br label %bb325
bb325:
  %t1216 = load i64, ptr %l684, !tbaa !24
  store i64 %t1216, ptr %l63, !tbaa !24
  store i64 1, ptr %l64, !tbaa !24
  %t1217 = load i64, ptr %l63, !tbaa !24
  %t1218 = load i64, ptr %l62, !tbaa !24
  %t1221 = icmp sgt i64 %t1217, %t1218
  br i1 %t1221, label %bb326, label %bb327
bb326:
  %t1223 = load i64, ptr %l64, !tbaa !24
  %t1225 = icmp sgt i64 %t1223, 0
  br i1 %t1225, label %bb328, label %bb329
bb327:
  store i64 0, ptr %l688, !tbaa !24
  br label %bb331
bb328:
  %t1227 = load i64, ptr %l63, !tbaa !24
  %t1228 = load i64, ptr %l62, !tbaa !24
  %t1231 = sub i64 %t1227, %t1228
  %t1232 = load i64, ptr %l64, !tbaa !24
  %t1235 = add i64 %t1231, %t1232
  %t1237 = sub i64 %t1235, 1
  %t1238 = load i64, ptr %l64, !tbaa !24
  %t1241 = sdiv i64 %t1237, %t1238
  store i64 %t1241, ptr %l691, !tbaa !24
  br label %bb330
bb329:
  store i64 0, ptr %l691, !tbaa !24
  br label %bb330
bb330:
  %t1243 = load i64, ptr %l691, !tbaa !24
  store i64 %t1243, ptr %l688, !tbaa !24
  br label %bb331
bb331:
  %t1244 = load i64, ptr %l688, !tbaa !24
  store i64 %t1244, ptr %l65, !tbaa !24
  store i64 0, ptr %l66, !tbaa !24
  br label %bb332
bb332:
  store %olang.scope zeroinitializer, ptr %s47
  %t1245 = load i64, ptr %l66, !tbaa !24
  %t1246 = load i64, ptr %l65, !tbaa !24
  %t1249 = icmp slt i64 %t1245, %t1246
  %t1251 = xor i1 %t1249, true
  br i1 %t1251, label %bb333, label %bb334
bb333:
  call void @__olang_scope_close(ptr %s47)
  br label %bb341
bb334:
  br label %bb335
bb335:
  %t1253 = load i64, ptr %l62, !tbaa !24
  %t1254 = load i64, ptr %l66, !tbaa !24
  %t1255 = load i64, ptr %l64, !tbaa !24
  %t1258 = mul i64 %t1254, %t1255
  %t1261 = add i64 %t1253, %t1258
  %t1263 = load ptr, ptr %l16, !tbaa !29
  %t1267 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t1263, i64 %t1261)
  store i1 %t1267, ptr %l711
  br label %bb336
bb336:
  %t1268 = load i1, ptr %l711, !tbaa !21
  br i1 %t1268, label %bb337, label %bb338
bb337:
  call void @__olang_scope_close(ptr %s47)
  br label %bb340
bb338:
  br label %bb339
bb339:
  %t1269 = load i1, ptr %l30, !tbaa !21
  store i1 %t1269, ptr %l30, !tbaa !21
  call void @__olang_scope_close(ptr %s47)
  br label %bb340
bb340:
  %t1271 = load i64, ptr %l66, !tbaa !24
  %t1273 = add i64 %t1271, 1
  store i64 %t1273, ptr %l66, !tbaa !24
  br label %bb332
bb341:
  %t1275 = load i1, ptr %l30, !tbaa !21
  store i1 %t1275, ptr %l68, !tbaa !21
  %t1277 = load i1, ptr %l68, !tbaa !21
  %t1279 = xor i1 %t1277, true
  br i1 %t1279, label %bb342, label %bb343
bb342:
  %t1281 = load ptr, ptr %l16, !tbaa !29
  %t1283 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t1281)
  store i64 %t1283, ptr %l720
  br label %bb344
bb343:
  store i1 false, ptr %l718, !tbaa !21
  br label %bb345
bb344:
  %t1284 = load i64, ptr %l720, !tbaa !24
  %t1285 = icmp sgt i64 %t1284, 0
  store i1 %t1285, ptr %l718, !tbaa !21
  br label %bb345
bb345:
  %t1287 = load i1, ptr %l718, !tbaa !21
  br i1 %t1287, label %bb346, label %bb347
bb346:
  store i1 true, ptr %l68, !tbaa !21
  %t1288 = load ptr, ptr %l16, !tbaa !29
  store ptr %t1288, ptr %l69, !tbaa !29
  store i64 0, ptr %l70, !tbaa !24
  br label %bb348
bb347:
  br label %bb366
bb348:
  store %olang.scope zeroinitializer, ptr %s52
  %t1290 = load ptr, ptr %l69, !tbaa !29
  %t1291 = load i64, ptr %l70, !tbaa !24
  %t1294 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eRunFrom_3cBool_3e(ptr %v0, ptr %t1290, i64 %t1291)
  %t1295 = extractvalue { i32, { i64, ptr } } %t1294, 1
  %t1296 = extractvalue { i32, { i64, ptr } } %t1294, 0
  store i32 %t1296, ptr %l727
  %t1297 = icmp ne i32 %t1296, 0
  br i1 %t1297, label %bb350, label %ok.1298
ok.1298:
  store { i64, ptr } %t1295, ptr %l726
  br label %bb349
bb349:
  %t1299 = load { i64, ptr }, ptr %l726, !tbaa !27
  store { i64, ptr } %t1299, ptr %l723, !tbaa !27
  br label %bb354
bb350:
  %t1300 = load i32, ptr %l727, !tbaa !23
  %t1301 = ashr i32 %t1300, 16
  %t1303 = icmp eq i32 %t1301, 1
  br i1 %t1303, label %bb351, label %bb352
bb351:
  br label %bb353
bb352:
  call void @__olang_check_failed(ptr @olang_loc_643d73169027a84b_389e1bbb110ca97f)
  unreachable
bb353:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s52)
  br label %bb365
bb354:
  %t1305 = load { i64, ptr }, ptr %l723, !tbaa !27
  store { i64, ptr } %t1305, ptr %l71, !tbaa !27
  %t1306 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t1308 = extractvalue { i64, ptr } %t1306, 0
  store i64 %t1308, ptr %l72, !tbaa !24
  store i64 0, ptr %l73, !tbaa !24
  br label %bb355
bb355:
  store %olang.scope zeroinitializer, ptr %s53
  %t1310 = load i64, ptr %l73, !tbaa !24
  %t1311 = load i64, ptr %l72, !tbaa !24
  %t1314 = icmp slt i64 %t1310, %t1311
  %t1316 = xor i1 %t1314, true
  br i1 %t1316, label %bb356, label %bb357
bb356:
  call void @__olang_scope_close(ptr %s53)
  br label %bb363
bb357:
  br label %bb358
bb358:
  %t1318 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t1318, ptr %l736, !tbaa !27
  %t1319 = load i64, ptr %l73, !tbaa !24
  %t1321 = getelementptr { i64, ptr }, ptr %l736, i32 0, i32 1
  %t1322 = load ptr, ptr %t1321, !tbaa !27
  %t1323 = getelementptr i1, ptr %t1322, i64 %t1319
  %t1324 = load i1, ptr %t1323, !tbaa !31
  %t1328 = xor i1 %t1324, true
  br i1 %t1328, label %bb359, label %bb360
bb359:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb361
bb360:
  br label %bb361
bb361:
  call void @__olang_scope_close(ptr %s53)
  br label %bb362
bb362:
  %t1330 = load i64, ptr %l73, !tbaa !24
  %t1332 = add i64 %t1330, 1
  store i64 %t1332, ptr %l73, !tbaa !24
  br label %bb355
bb363:
  %t1334 = load i64, ptr %l70, !tbaa !24
  %t1335 = load i64, ptr %l72, !tbaa !24
  %t1338 = add i64 %t1334, %t1335
  store i64 %t1338, ptr %l70, !tbaa !24
  call void @__olang_scope_close(ptr %s52)
  br label %bb364
bb364:
  br label %bb348
bb365:
  br label %bb366
bb366:
  %t1340 = load i1, ptr %l68, !tbaa !21
  %t1342 = xor i1 %t1340, true
  br i1 %t1342, label %bb367, label %bb368
bb367:
  store %olang.scope zeroinitializer, ptr %s56
  %t1344 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1344, ptr %l748, !tbaa !29
  %t1345 = load ptr, ptr %l33, !tbaa !29
  store ptr %t1345, ptr %l749, !tbaa !29
  %t1346 = load i32, ptr %l17, !tbaa !23
  store i32 %t1346, ptr %l750, !tbaa !23
  %t1347 = icmp sge i64 1, 0
  br i1 %t1347, label %bb369, label %bb370
bb368:
  br label %bb374
bb369:
  %t1349 = icmp sle i64 1, 2305843009213693951
  br i1 %t1349, label %bb371, label %bb372
bb370:
  call void @__olang_check_failed(ptr @olang_loc_655dce139344447_4241f7f5f2334ea3)
  unreachable
bb371:
  %t1351 = mul i64 1, 4
  %t1352 = call ptr @__olang_scope_alloc(ptr %s56, i64 %t1351)
  %t1353 = load i32, ptr %l750, !tbaa !23
  store i64 0, ptr %t1354
  br label %fill.1355
fill.1355:
  %t1358 = load i64, ptr %t1354
  %t1359 = icmp slt i64 %t1358, 1
  br i1 %t1359, label %fillb.1356, label %filld.1357
fillb.1356:
  %t1360 = getelementptr i32, ptr %t1352, i64 %t1358
  store i32 %t1353, ptr %t1360
  %t1361 = add i64 %t1358, 1
  store i64 %t1361, ptr %t1354
  br label %fill.1355
filld.1357:
  %t1362 = insertvalue { i64, ptr } undef, i64 1, 0
  %t1363 = insertvalue { i64, ptr } %t1362, ptr %t1352, 1
  %t1364 = load ptr, ptr %l748, !tbaa !29
  %t1365 = load ptr, ptr %l749, !tbaa !29
  %t1367 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecoversRows(ptr %v0, ptr %v1, ptr %s56, ptr %t1364, ptr %t1365, { i64, ptr } %t1363, i64 0)
  store i1 %t1367, ptr %l754
  br label %bb373
bb372:
  call void @__olang_check_failed(ptr @olang_loc_655dce139344447_4241f7f5f2334ea3)
  unreachable
bb373:
  %t1368 = load i1, ptr %l754, !tbaa !21
  store i1 %t1368, ptr %l68, !tbaa !21
  call void @__olang_scope_close(ptr %s56)
  br label %bb374
bb374:
  %t1369 = load ptr, ptr %l0, !tbaa !29
  %t1371 = getelementptr %"compiler/check:Checker", ptr %t1369, i32 0, i32 94
  %t1372 = load i1, ptr %t1371, !tbaa !21
  br i1 %t1372, label %bb375, label %bb376
bb375:
  store i1 true, ptr %l68, !tbaa !21
  br label %bb377
bb376:
  br label %bb377
bb377:
  %t1374 = load ptr, ptr %l0, !tbaa !29
  %t1375 = load i1, ptr %l32, !tbaa !21
  %t1378 = getelementptr %"compiler/check:Checker", ptr %t1374, i32 0, i32 94
  store i1 %t1375, ptr %t1378, !tbaa !21
  store ptr null, ptr %l75, !tbaa !29
  %t1379 = load ptr, ptr %l2, !tbaa !29
  %t1381 = getelementptr %"compiler/ast:Match", ptr %t1379, i32 0, i32 4
  %t1382 = load ptr, ptr %t1381, !tbaa !29
  %t1384 = icmp eq ptr %t1382, null
  %t1386 = xor i1 %t1384, true
  br i1 %t1386, label %bb378, label %bb379
bb378:
  %t1388 = load ptr, ptr %l2, !tbaa !29
  %t1390 = getelementptr %"compiler/ast:Match", ptr %t1388, i32 0, i32 4
  %t1391 = load ptr, ptr %t1390, !tbaa !29
  store ptr %t1391, ptr %l76, !tbaa !29
  %t1393 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1393, ptr %l765, !tbaa !29
  store i32 1, ptr %l766
  %t1394 = load ptr, ptr %l76, !tbaa !29
  %t1396 = icmp eq ptr %t1394, null
  br i1 %t1396, label %bb380, label %bb381
bb379:
  %t1398 = load ptr, ptr %l0, !tbaa !29
  %t1400 = getelementptr %"compiler/check:Checker", ptr %t1398, i32 0, i32 33
  %t1402 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t1400)
  store i64 %t1402, ptr %l933
  br label %bb487
bb380:
  call void @__olang_check_failed(ptr @olang_loc_dcdc4b5c1e449f32_62ceda096b9852b6)
  unreachable
bb381:
  br label %bb382
bb382:
  %t1403 = load ptr, ptr %l76, !tbaa !29
  %t1406 = getelementptr %"compiler/ast:Case", ptr %t1403, i32 0, i32 0
  %t1407 = load %"compiler/source:Span", ptr %t1406
  %t1408 = load ptr, ptr %l765, !tbaa !29
  %t1409 = load i32, ptr %l766
  %t1411 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t1408, i32 %t1409, %"compiler/source:Span" %t1407)
  store { i64, i64, i64 } %t1411, ptr %l772
  br label %bb383
bb383:
  %t1412 = load { i64, i64, i64 }, ptr %l772
  store { i64, i64, i64 } %t1412, ptr %l77
  %t1413 = getelementptr { i64, i64, i64 }, ptr %l77, i32 0, i32 0
  %t1414 = load i64, ptr %t1413, !tbaa !24
  store i64 %t1414, ptr %l78, !tbaa !24
  %t1416 = getelementptr { i64, i64, i64 }, ptr %l77, i32 0, i32 1
  %t1417 = load i64, ptr %t1416, !tbaa !24
  store i64 %t1417, ptr %l79, !tbaa !24
  %t1419 = getelementptr { i64, i64, i64 }, ptr %l77, i32 0, i32 2
  %t1420 = load i64, ptr %t1419, !tbaa !24
  store i64 %t1420, ptr %l80, !tbaa !24
  %t1422 = load ptr, ptr %l0, !tbaa !29
  %t1424 = getelementptr %"compiler/check:Checker", ptr %t1422, i32 0, i32 33
  %t1426 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t1424)
  store i64 %t1426, ptr %l778
  br label %bb384
bb384:
  %t1427 = load i64, ptr %l778, !tbaa !24
  store i64 %t1427, ptr %l81, !tbaa !24
  %t1428 = load ptr, ptr %l76, !tbaa !29
  %t1430 = icmp eq ptr %t1428, null
  br i1 %t1430, label %bb385, label %bb386
bb385:
  call void @__olang_check_failed(ptr @olang_loc_d9c718d647bddfff_22edbe4f84dc963b)
  unreachable
bb386:
  br label %bb387
bb387:
  %t1432 = load ptr, ptr %l76, !tbaa !29
  %t1435 = getelementptr %"compiler/ast:Case", ptr %t1432, i32 0, i32 4
  %t1436 = load { i64, ptr }, ptr %t1435, !tbaa !27
  %t1438 = extractvalue { i64, ptr } %t1436, 0
  %t1440 = icmp sgt i64 %t1438, 0
  br i1 %t1440, label %bb388, label %bb389
bb388:
  %t1442 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1442, ptr %l786, !tbaa !29
  %t1443 = load ptr, ptr %l76, !tbaa !29
  %t1445 = icmp eq ptr %t1443, null
  br i1 %t1445, label %bb390, label %bb391
bb389:
  br label %bb394
bb390:
  call void @__olang_check_failed(ptr @olang_loc_3a843a558863e2e0_22d07d3cfe1539cc)
  unreachable
bb391:
  br label %bb392
bb392:
  %t1447 = load ptr, ptr %l76, !tbaa !29
  %t1450 = getelementptr %"compiler/ast:Case", ptr %t1447, i32 0, i32 4
  %t1451 = load { i64, ptr }, ptr %t1450, !tbaa !27
  %t1452 = load ptr, ptr %l786, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %t1452, { i64, ptr } %t1451)
  br label %bb393
bb393:
  br label %bb394
bb394:
  store ptr null, ptr %l82, !tbaa !29
  %t1454 = load ptr, ptr %l76, !tbaa !29
  %t1456 = icmp eq ptr %t1454, null
  br i1 %t1456, label %bb395, label %bb396
bb395:
  call void @__olang_check_failed(ptr @olang_loc_3e82470ef2956af5_ad5cca336f09c301)
  unreachable
bb396:
  br label %bb397
bb397:
  %t1458 = load ptr, ptr %l76, !tbaa !29
  %t1461 = getelementptr %"compiler/ast:Case", ptr %t1458, i32 0, i32 5
  %t1462 = load ptr, ptr %t1461, !tbaa !29
  %t1464 = icmp eq ptr %t1462, null
  %t1466 = xor i1 %t1464, true
  br i1 %t1466, label %bb398, label %bb399
bb398:
  %t1468 = load i1, ptr %l3, !tbaa !21
  store i1 %t1468, ptr %l799, !tbaa !21
  br label %bb400
bb399:
  store i1 false, ptr %l799, !tbaa !21
  br label %bb400
bb400:
  %t1470 = load i1, ptr %l799, !tbaa !21
  br i1 %t1470, label %bb401, label %bb402
bb401:
  store i1 false, ptr %l83, !tbaa !21
  %t1471 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1471, ptr %l801, !tbaa !29
  %t1472 = load ptr, ptr %l76, !tbaa !29
  %t1474 = icmp eq ptr %t1472, null
  br i1 %t1474, label %bb403, label %bb404
bb402:
  br label %bb477
bb403:
  call void @__olang_check_failed(ptr @olang_loc_ddb0759225e71b4e_d466412c7868a47a)
  unreachable
bb404:
  br label %bb405
bb405:
  %t1476 = load ptr, ptr %l76, !tbaa !29
  %t1479 = getelementptr %"compiler/ast:Case", ptr %t1476, i32 0, i32 5
  %t1480 = load ptr, ptr %t1479, !tbaa !29
  %t1481 = load i32, ptr %l13, !tbaa !23
  %t1482 = load ptr, ptr %l801, !tbaa !29
  %t1485 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t1482, ptr %t1480, i32 %t1481)
  store ptr %t1485, ptr %l808
  br label %bb406
bb406:
  %t1486 = load ptr, ptr %l808, !tbaa !29
  store ptr %t1486, ptr %l82, !tbaa !29
  %t1488 = load i32, ptr %l13, !tbaa !23
  %t1489 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t1492 = icmp eq i32 %t1488, %t1489
  br i1 %t1492, label %bb407, label %bb408
bb407:
  %t1494 = load ptr, ptr %l82, !tbaa !29
  %t1497 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1494)
  store i32 %t1497, ptr %l816
  br label %bb409
bb408:
  store i1 false, ptr %l813, !tbaa !21
  br label %bb410
bb409:
  %t1498 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t1499 = load i32, ptr %l816, !tbaa !23
  %t1501 = icmp ne i32 %t1499, %t1498
  store i1 %t1501, ptr %l813, !tbaa !21
  br label %bb410
bb410:
  %t1503 = load i1, ptr %l813, !tbaa !21
  br i1 %t1503, label %bb411, label %bb412
bb411:
  %t1504 = load ptr, ptr %l82, !tbaa !29
  %t1507 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1504)
  store i32 %t1507, ptr %l821
  br label %bb413
bb412:
  br label %bb451
bb413:
  %t1508 = load i32, ptr %l821, !tbaa !23
  store i32 %t1508, ptr %l13, !tbaa !23
  %t1509 = load ptr, ptr %l0, !tbaa !29
  %t1510 = load i32, ptr %l13, !tbaa !23
  %t1513 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1509, i32 %t1510)
  store i1 %t1513, ptr %l824
  br label %bb414
bb414:
  %t1514 = load i1, ptr %l824, !tbaa !21
  br i1 %t1514, label %bb415, label %bb416
bb415:
  %t1515 = load ptr, ptr %l2, !tbaa !29
  %t1517 = call i1 @compiler_2fcheck_2enullValue(ptr %v1, ptr %t1515)
  store i1 %t1517, ptr %l827
  br label %bb417
bb416:
  store i1 false, ptr %l825, !tbaa !21
  br label %bb418
bb417:
  %t1518 = load i1, ptr %l827, !tbaa !21
  store i1 %t1518, ptr %l825, !tbaa !21
  br label %bb418
bb418:
  %t1519 = load i1, ptr %l825, !tbaa !21
  br i1 %t1519, label %bb419, label %bb420
bb419:
  %t1520 = load ptr, ptr %l0, !tbaa !29
  %t1522 = getelementptr %"compiler/check:Checker", ptr %t1520, i32 0, i32 1
  %t1523 = load ptr, ptr %t1522, !tbaa !29
  %t1525 = getelementptr %"compiler/generic:Program", ptr %t1523, i32 0, i32 2
  %t1526 = load i32, ptr %l13, !tbaa !23
  %t1529 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t1525, i32 %t1526)
  store i32 %t1529, ptr %l832
  br label %bb421
bb420:
  br label %bb422
bb421:
  %t1530 = load i32, ptr %l832, !tbaa !23
  store i32 %t1530, ptr %l13, !tbaa !23
  br label %bb422
bb422:
  %t1531 = load ptr, ptr %l0, !tbaa !29
  %t1533 = getelementptr %"compiler/check:Checker", ptr %t1531, i32 0, i32 1
  %t1534 = load ptr, ptr %t1533, !tbaa !29
  %t1536 = getelementptr %"compiler/generic:Program", ptr %t1534, i32 0, i32 2
  %t1537 = load i32, ptr %l13, !tbaa !23
  %t1540 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1536, i32 %t1537)
  store i32 %t1540, ptr %l837
  br label %bb423
bb423:
  %t1541 = load i32, ptr %l837
  %t1543 = trunc i64 19 to i32
  %t1544 = icmp eq i32 %t1541, %t1543
  br i1 %t1544, label %bb424, label %bb425
bb424:
  %t1546 = load ptr, ptr %l0, !tbaa !29
  %t1548 = getelementptr %"compiler/check:Checker", ptr %t1546, i32 0, i32 1
  %t1549 = load ptr, ptr %t1548, !tbaa !29
  %t1551 = getelementptr %"compiler/generic:Program", ptr %t1549, i32 0, i32 2
  %t1552 = load i32, ptr %l13, !tbaa !23
  %t1555 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t1551, i32 %t1552)
  store i32 %t1555, ptr %l845
  br label %bb426
bb425:
  store i1 false, ptr %l840, !tbaa !21
  br label %bb427
bb426:
  %t1556 = load i32, ptr %l845, !tbaa !23
  %t1557 = icmp ne i32 %t1556, 0
  store i1 %t1557, ptr %l840, !tbaa !21
  br label %bb427
bb427:
  %t1559 = load i1, ptr %l840, !tbaa !21
  br i1 %t1559, label %bb428, label %bb429
bb428:
  %t1560 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1560, ptr %l848, !tbaa !29
  %t1561 = load ptr, ptr %l76, !tbaa !29
  %t1563 = icmp eq ptr %t1561, null
  br i1 %t1563, label %bb430, label %bb431
bb429:
  store i1 false, ptr %l847, !tbaa !21
  br label %bb437
bb430:
  call void @__olang_check_failed(ptr @olang_loc_d249702171a05a8b_2937796e970ca26f)
  unreachable
bb431:
  br label %bb432
bb432:
  %t1565 = load ptr, ptr %l76, !tbaa !29
  %t1568 = getelementptr %"compiler/ast:Case", ptr %t1565, i32 0, i32 5
  %t1569 = load ptr, ptr %t1568, !tbaa !29
  store ptr %t1569, ptr %l84, !tbaa !29
  %t1571 = load ptr, ptr %l84, !tbaa !29
  %t1573 = icmp eq ptr %t1571, null
  br i1 %t1573, label %bb433, label %bb434
bb433:
  call void @__olang_check_failed(ptr @olang_loc_d249702171a05a8b_2937796e970ca26f)
  unreachable
bb434:
  br label %bb435
bb435:
  %t1575 = load ptr, ptr %l84, !tbaa !29
  %t1576 = load ptr, ptr %l848, !tbaa !29
  %t1578 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitArray(ptr %v0, ptr %v1, ptr %t1576, ptr %t1575)
  store i1 %t1578, ptr %l857
  br label %bb436
bb436:
  %t1579 = load i1, ptr %l857, !tbaa !21
  store i1 %t1579, ptr %l847, !tbaa !21
  br label %bb437
bb437:
  %t1580 = load i1, ptr %l847, !tbaa !21
  br i1 %t1580, label %bb438, label %bb439
bb438:
  %t1581 = load ptr, ptr %l0, !tbaa !29
  %t1583 = getelementptr %"compiler/check:Checker", ptr %t1581, i32 0, i32 1
  %t1584 = load ptr, ptr %t1583, !tbaa !29
  %t1586 = getelementptr %"compiler/generic:Program", ptr %t1584, i32 0, i32 2
  store ptr %t1586, ptr %l860, !tbaa !29
  %t1587 = load ptr, ptr %l0, !tbaa !29
  %t1589 = getelementptr %"compiler/check:Checker", ptr %t1587, i32 0, i32 1
  %t1590 = load ptr, ptr %t1589, !tbaa !29
  %t1592 = getelementptr %"compiler/generic:Program", ptr %t1590, i32 0, i32 2
  %t1593 = load i32, ptr %l13, !tbaa !23
  %t1596 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t1592, i32 %t1593)
  store i32 %t1596, ptr %l865
  br label %bb440
bb439:
  br label %bb442
bb440:
  %t1597 = load ptr, ptr %l860, !tbaa !29
  %t1598 = load i32, ptr %l865, !tbaa !23
  %t1599 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t1597, i32 %t1598, i32 0)
  store i32 %t1599, ptr %l866
  br label %bb441
bb441:
  %t1600 = load i32, ptr %l866, !tbaa !23
  store i32 %t1600, ptr %l13, !tbaa !23
  br label %bb442
bb442:
  %t1601 = load ptr, ptr %l0, !tbaa !29
  %t1602 = load i32, ptr %l13, !tbaa !23
  %t1605 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1601, i32 %t1602)
  store i1 %t1605, ptr %l869
  br label %bb443
bb443:
  %t1606 = load i1, ptr %l869, !tbaa !21
  br i1 %t1606, label %bb444, label %bb445
bb444:
  %t1607 = load ptr, ptr %l0, !tbaa !29
  %t1608 = load i32, ptr %l13, !tbaa !23
  %t1611 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %t1607, i32 %t1608)
  store i32 %t1611, ptr %l872
  br label %bb446
bb445:
  br label %bb447
bb446:
  %t1612 = load i32, ptr %l872, !tbaa !23
  store i32 %t1612, ptr %l13, !tbaa !23
  br label %bb447
bb447:
  %t1613 = load i32, ptr %l14, !tbaa !23
  %t1614 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t1617 = icmp eq i32 %t1613, %t1614
  br i1 %t1617, label %bb448, label %bb449
bb448:
  %t1619 = load i32, ptr %l13, !tbaa !23
  store i32 %t1619, ptr %l14, !tbaa !23
  br label %bb450
bb449:
  br label %bb450
bb450:
  br label %bb451
bb451:
  %t1621 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1621, ptr %l877, !tbaa !29
  %t1622 = load ptr, ptr %l82, !tbaa !29
  %t1624 = icmp eq ptr %t1622, null
  br i1 %t1624, label %bb452, label %bb453
bb452:
  call void @__olang_check_failed(ptr @olang_loc_ab20c2f7dddd239c_a82caf25e09de410)
  unreachable
bb453:
  br label %bb454
bb454:
  %t1626 = load ptr, ptr %l82, !tbaa !29
  store ptr %t1626, ptr %l880, !tbaa !29
  %t1627 = load i32, ptr %l13, !tbaa !23
  store i32 %t1627, ptr %l881, !tbaa !23
  %t1628 = load ptr, ptr %l76, !tbaa !29
  %t1630 = icmp eq ptr %t1628, null
  br i1 %t1630, label %bb455, label %bb456
bb455:
  call void @__olang_check_failed(ptr @olang_loc_ab20c2f7dddd239c_a82caf25e09de410)
  unreachable
bb456:
  br label %bb457
bb457:
  %t1632 = load ptr, ptr %l76, !tbaa !29
  %t1635 = getelementptr %"compiler/ast:Case", ptr %t1632, i32 0, i32 5
  %t1636 = load ptr, ptr %t1635, !tbaa !29
  store ptr %t1636, ptr %l85, !tbaa !29
  %t1638 = load ptr, ptr %l85, !tbaa !29
  %t1640 = icmp eq ptr %t1638, null
  br i1 %t1640, label %bb458, label %bb459
bb458:
  call void @__olang_check_failed(ptr @olang_loc_ab20c2f7dddd239c_a82caf25e09de410)
  unreachable
bb459:
  br label %bb460
bb460:
  %t1642 = load ptr, ptr %l85, !tbaa !29
  %t1644 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t1642)
  store %"compiler/source:Span" %t1644, ptr %l890
  br label %bb461
bb461:
  %t1645 = load ptr, ptr %l877, !tbaa !29
  %t1646 = load ptr, ptr %l880, !tbaa !29
  %t1647 = load i32, ptr %l881, !tbaa !23
  %t1648 = load %"compiler/source:Span", ptr %l890
  %t1649 = call { ptr, i1 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efitQuiet(ptr %v0, ptr %t1645, ptr %t1646, i32 %t1647, %"compiler/source:Span" %t1648)
  store { ptr, i1 } %t1649, ptr %l891
  br label %bb462
bb462:
  %t1650 = load { ptr, i1 }, ptr %l891
  store { ptr, i1 } %t1650, ptr %l86
  %t1651 = getelementptr { ptr, i1 }, ptr %l86, i32 0, i32 0
  %t1652 = load ptr, ptr %t1651, !tbaa !29
  store ptr %t1652, ptr %l82, !tbaa !29
  %t1655 = getelementptr { ptr, i1 }, ptr %l86, i32 0, i32 1
  %t1656 = load i1, ptr %t1655, !tbaa !21
  store i1 %t1656, ptr %l83, !tbaa !21
  %t1658 = load i1, ptr %l83, !tbaa !21
  %t1660 = xor i1 %t1658, true
  br i1 %t1660, label %bb463, label %bb464
bb463:
  %t1662 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1662, ptr %l897, !tbaa !29
  %t1663 = load ptr, ptr %l76, !tbaa !29
  %t1665 = icmp eq ptr %t1663, null
  br i1 %t1665, label %bb465, label %bb466
bb464:
  br label %bb476
bb465:
  call void @__olang_check_failed(ptr @olang_loc_1cb8a67bcda73d28_932f2868e4afd59c)
  unreachable
bb466:
  br label %bb467
bb467:
  %t1667 = load ptr, ptr %l76, !tbaa !29
  %t1670 = getelementptr %"compiler/ast:Case", ptr %t1667, i32 0, i32 5
  %t1671 = load ptr, ptr %t1670, !tbaa !29
  store ptr %t1671, ptr %l87, !tbaa !29
  %t1673 = load ptr, ptr %l87, !tbaa !29
  %t1675 = icmp eq ptr %t1673, null
  br i1 %t1675, label %bb468, label %bb469
bb468:
  call void @__olang_check_failed(ptr @olang_loc_1cb8a67bcda73d28_932f2868e4afd59c)
  unreachable
bb469:
  br label %bb470
bb470:
  %t1677 = load ptr, ptr %l87, !tbaa !29
  %t1679 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t1677)
  store %"compiler/source:Span" %t1679, ptr %l906
  br label %bb471
bb471:
  %t1680 = load i32, ptr %l14, !tbaa !23
  store i32 %t1680, ptr %l907, !tbaa !23
  %t1681 = load i32, ptr %l13, !tbaa !23
  store i32 %t1681, ptr %l908, !tbaa !23
  %t1682 = load ptr, ptr %l82, !tbaa !29
  %t1684 = icmp eq ptr %t1682, null
  br i1 %t1684, label %bb472, label %bb473
bb472:
  call void @__olang_check_failed(ptr @olang_loc_1cb8a67bcda73d28_932f2868e4afd59c)
  unreachable
bb473:
  br label %bb474
bb474:
  %t1686 = load ptr, ptr %l82, !tbaa !29
  %t1687 = load ptr, ptr %l897, !tbaa !29
  %t1688 = load %"compiler/source:Span", ptr %l906
  %t1689 = load i32, ptr %l907, !tbaa !23
  %t1690 = load i32, ptr %l908, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchValueMismatch(ptr %v0, ptr %v0, ptr %t1687, %"compiler/source:Span" %t1688, i32 %t1689, i32 %t1690, ptr %t1686)
  br label %bb475
bb475:
  br label %bb476
bb476:
  br label %bb477
bb477:
  %t1692 = load ptr, ptr %l0, !tbaa !29
  %t1693 = load i64, ptr %l78, !tbaa !24
  %t1694 = load i64, ptr %l79, !tbaa !24
  %t1695 = load i64, ptr %l80, !tbaa !24
  %t1696 = load i64, ptr %l81, !tbaa !24
  %t1702 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t1692, i64 %t1693, i64 %t1694, i64 %t1695, i64 %t1696)
  store ptr %t1702, ptr %l917
  br label %bb478
bb478:
  %t1703 = load ptr, ptr %l917, !tbaa !29
  store ptr %t1703, ptr %l88, !tbaa !29
  %t1704 = load ptr, ptr %l76, !tbaa !29
  %t1706 = icmp eq ptr %t1704, null
  br i1 %t1706, label %bb479, label %bb480
bb479:
  call void @__olang_check_failed(ptr @olang_loc_f97b348e6d625e47_ba57d59278730c8b)
  unreachable
bb480:
  br label %bb481
bb481:
  %t1708 = load ptr, ptr %l76, !tbaa !29
  %t1711 = getelementptr %"compiler/ast:Case", ptr %t1708, i32 0, i32 0
  %t1712 = load %"compiler/source:Span", ptr %t1711
  store %"compiler/source:Span" %t1712, ptr %l922
  %t1713 = icmp sge i64 0, 0
  br i1 %t1713, label %bb482, label %bb483
bb482:
  %t1715 = icmp sle i64 0, 1152921504606846975
  br i1 %t1715, label %bb484, label %bb485
bb483:
  call void @__olang_check_failed(ptr @olang_loc_814511bd48ee038e_643da95161de4c6a)
  unreachable
bb484:
  %t1717 = mul i64 0, 8
  %t1718 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t1717)
  %t1719 = insertvalue { i64, ptr } undef, i64 0, 0
  %t1720 = insertvalue { i64, ptr } %t1719, ptr %t1718, 1
  %t1721 = load ptr, ptr %l88, !tbaa !29
  %t1723 = load ptr, ptr %l82, !tbaa !29
  %t1724 = load %"compiler/source:Span", ptr %l922
  %t1728 = call %"compiler/typed:Arm" @compiler_2ftyped_3aArm_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t1724, { i64, ptr } %t1720, ptr null, ptr %t1721, ptr %t1723)
  store %"compiler/typed:Arm" %t1728, ptr %l929
  br label %bb486
bb485:
  call void @__olang_check_failed(ptr @olang_loc_814511bd48ee038e_643da95161de4c6a)
  unreachable
bb486:
  %t1729 = load %"compiler/typed:Arm", ptr %l929
  %t1730 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store %"compiler/typed:Arm" %t1729, ptr %t1730
  store ptr %t1730, ptr %l75, !tbaa !29
  br label %bb575
bb487:
  %t1732 = load i64, ptr %l933, !tbaa !24
  store i64 %t1732, ptr %l89, !tbaa !24
  %t1733 = load i1, ptr %l68, !tbaa !21
  br i1 %t1733, label %bb488, label %bb489
bb488:
  store i1 true, ptr %l935, !tbaa !21
  br label %bb490
bb489:
  %t1735 = load i1, ptr %l3, !tbaa !21
  store i1 %t1735, ptr %l935, !tbaa !21
  br label %bb490
bb490:
  %t1737 = load i1, ptr %l935, !tbaa !21
  br i1 %t1737, label %bb491, label %bb492
bb491:
  %t1738 = load ptr, ptr %l0, !tbaa !29
  %t1740 = getelementptr %"compiler/check:Checker", ptr %t1738, i32 0, i32 33
  %t1741 = load ptr, ptr %l2, !tbaa !29
  %t1743 = getelementptr %"compiler/ast:Match", ptr %t1741, i32 0, i32 0
  %t1744 = load %"compiler/source:Span", ptr %t1743
  store { i64, [3 x i64] } zeroinitializer, ptr %t1745
  %t1746 = getelementptr { i64, [3 x i64] }, ptr %t1745, i32 0, i32 0
  store i64 9, ptr %t1746
  %t1748 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1744, 0
  %t1750 = insertvalue { %"compiler/source:Span", i32, ptr } %t1748, i32 0, 1
  %t1751 = insertvalue { %"compiler/source:Span", i32, ptr } %t1750, ptr null, 2
  %t1752 = getelementptr { i64, [3 x i64] }, ptr %t1745, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1751, ptr %t1752
  %t1753 = load { i64, [3 x i64] }, ptr %t1745
  %t1755 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t1753, ptr %t1755
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v0, ptr %t1740, ptr %t1755)
  br label %bb493
bb492:
  br label %bb494
bb493:
  br label %bb494
bb494:
  %t1758 = load i1, ptr %l68, !tbaa !21
  %t1760 = xor i1 %t1758, true
  br i1 %t1760, label %bb495, label %bb496
bb495:
  %t1762 = load ptr, ptr %l0, !tbaa !29
  %t1763 = load i32, ptr %l17, !tbaa !23
  %t1766 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t1762, i32 %t1763)
  store i1 %t1766, ptr %l949
  br label %bb497
bb496:
  store i1 false, ptr %l946, !tbaa !21
  br label %bb498
bb497:
  %t1767 = load i1, ptr %l949, !tbaa !21
  store i1 %t1767, ptr %l946, !tbaa !21
  br label %bb498
bb498:
  %t1768 = load i1, ptr %l946, !tbaa !21
  br i1 %t1768, label %bb499, label %bb500
bb499:
  %t1769 = load ptr, ptr %l0, !tbaa !29
  %t1770 = load ptr, ptr %l33, !tbaa !29
  %t1771 = load i32, ptr %l17, !tbaa !23
  %t1775 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efirstUncovered(ptr %v0, ptr %v1, ptr %t1769, ptr %t1770, i32 %t1771)
  store i64 %t1775, ptr %l953
  br label %bb501
bb500:
  %t1776 = load i1, ptr %l68, !tbaa !21
  %t1778 = xor i1 %t1776, true
  br i1 %t1778, label %bb516, label %bb517
bb501:
  %t1780 = load i64, ptr %l953, !tbaa !24
  store i64 %t1780, ptr %l90, !tbaa !24
  %t1781 = load i64, ptr %l90, !tbaa !24
  %t1783 = icmp sge i64 %t1781, 0
  br i1 %t1783, label %bb502, label %bb503
bb502:
  store %olang.scope zeroinitializer, ptr %s70
  %t1785 = load ptr, ptr %l0, !tbaa !29
  %t1787 = getelementptr %"compiler/check:Checker", ptr %t1785, i32 0, i32 1
  %t1788 = load ptr, ptr %t1787, !tbaa !29
  %t1790 = getelementptr %"compiler/generic:Program", ptr %t1788, i32 0, i32 2
  %t1791 = load i32, ptr %l17, !tbaa !23
  %t1794 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %t1790, i32 %t1791)
  store { i64, ptr } %t1794, ptr %l960
  br label %bb504
bb503:
  br label %bb515
bb504:
  %t1795 = load { i64, ptr }, ptr %l960, !tbaa !27
  store { i64, ptr } %t1795, ptr %l91, !tbaa !27
  %t1796 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1796, ptr %l961, !tbaa !29
  %t1797 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t1797, ptr %l962
  %t1798 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t1800 = extractvalue { i64, ptr } %t1798, 0
  %t1802 = icmp sgt i64 %t1800, 0
  br i1 %t1802, label %bb505, label %bb506
bb505:
  %t1804 = load i64, ptr %l90, !tbaa !24
  %t1805 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t1807 = extractvalue { i64, ptr } %t1805, 0
  %t1810 = icmp slt i64 %t1804, %t1807
  store i1 %t1810, ptr %l966, !tbaa !21
  br label %bb507
bb506:
  store i1 false, ptr %l966, !tbaa !21
  br label %bb507
bb507:
  %t1812 = load i1, ptr %l966, !tbaa !21
  br i1 %t1812, label %bb508, label %bb509
bb508:
  %t1813 = load ptr, ptr %l0, !tbaa !29
  %t1814 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t1814, ptr %l973, !tbaa !27
  %t1815 = load i64, ptr %l90, !tbaa !24
  %t1817 = getelementptr { i64, ptr }, ptr %l973, i32 0, i32 1
  %t1818 = load ptr, ptr %t1817, !tbaa !27
  %t1819 = getelementptr i32, ptr %t1818, i64 %t1815
  %t1820 = load i32, ptr %t1819, !tbaa !33
  %t1823 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t1813, i32 %t1820)
  store { i64, ptr } %t1823, ptr %l976
  br label %bb510
bb509:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, ptr %l971, !tbaa !27
  br label %bb511
bb510:
  %t1824 = load { i64, ptr }, ptr %l976, !tbaa !27
  store { i64, ptr } %t1824, ptr %l971, !tbaa !27
  br label %bb511
bb511:
  %t1825 = load ptr, ptr %l0, !tbaa !29
  %t1826 = load i32, ptr %l17, !tbaa !23
  %t1829 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s70, ptr %t1825, i32 %t1826)
  store { i64, ptr } %t1829, ptr %l979
  br label %bb512
bb512:
  %t1830 = load { i64, ptr }, ptr %l979, !tbaa !27
  %t1831 = extractvalue { i64, ptr } %t1830, 0
  %t1832 = extractvalue { i64, ptr } %t1830, 1
  %t1833 = mul i64 %t1831, 1
  %t1834 = call ptr @__olang_scope_alloc(ptr %s70, i64 %t1833)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1834, ptr %t1832, i64 %t1833, i1 false)
  %t1835 = insertvalue { i64, ptr } undef, i64 %t1831, 0
  %t1836 = insertvalue { i64, ptr } %t1835, ptr %t1834, 1
  %t1837 = load { i64, ptr }, ptr %l971, !tbaa !27
  %t1839 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatchNotExhaustive(ptr %v0, ptr %s70, ptr %s70, { i64, ptr } %t1837, { i64, ptr } %t1836)
  store %"compiler/msgs:Msg" %t1839, ptr %l981
  br label %bb513
bb513:
  %t1840 = load ptr, ptr %l961, !tbaa !29
  %t1841 = load %"compiler/source:Span", ptr %l962
  %t1842 = load %"compiler/msgs:Msg", ptr %l981
  %t1843 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s70, ptr %t1840, %"compiler/source:Span" %t1841, %"compiler/msgs:Msg" %t1842)
  store i64 %t1843, ptr %l982
  br label %bb514
bb514:
  call void @__olang_scope_close(ptr %s70)
  br label %bb515
bb515:
  br label %bb566
bb516:
  %t1844 = load ptr, ptr %l16, !tbaa !29
  %t1846 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t1844)
  store i64 %t1846, ptr %l987
  br label %bb518
bb517:
  store i1 false, ptr %l985, !tbaa !21
  br label %bb519
bb518:
  %t1847 = load i64, ptr %l987, !tbaa !24
  %t1848 = icmp sgt i64 %t1847, 0
  store i1 %t1848, ptr %l985, !tbaa !21
  br label %bb519
bb519:
  %t1850 = load i1, ptr %l985, !tbaa !21
  br i1 %t1850, label %bb520, label %bb521
bb520:
  %t1851 = load ptr, ptr %l0, !tbaa !29
  %t1853 = getelementptr %"compiler/check:Checker", ptr %t1851, i32 0, i32 1
  %t1854 = load ptr, ptr %t1853, !tbaa !29
  %t1856 = getelementptr %"compiler/generic:Program", ptr %t1854, i32 0, i32 2
  %t1857 = load i32, ptr %l17, !tbaa !23
  %t1860 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1856, i32 %t1857)
  store i32 %t1860, ptr %l994
  br label %bb522
bb521:
  store i1 false, ptr %l989, !tbaa !21
  br label %bb523
bb522:
  %t1861 = load i32, ptr %l994
  %t1863 = trunc i64 29 to i32
  %t1864 = icmp eq i32 %t1861, %t1863
  store i1 %t1864, ptr %l989, !tbaa !21
  br label %bb523
bb523:
  %t1866 = load i1, ptr %l989, !tbaa !21
  br i1 %t1866, label %bb524, label %bb525
bb524:
  %t1867 = load ptr, ptr %l0, !tbaa !29
  %t1869 = getelementptr %"compiler/check:Checker", ptr %t1867, i32 0, i32 1
  %t1870 = load ptr, ptr %t1869, !tbaa !29
  store ptr %t1870, ptr %l998, !tbaa !29
  %t1871 = load ptr, ptr %l0, !tbaa !29
  %t1873 = getelementptr %"compiler/check:Checker", ptr %t1871, i32 0, i32 1
  %t1874 = load ptr, ptr %t1873, !tbaa !29
  %t1876 = getelementptr %"compiler/generic:Program", ptr %t1874, i32 0, i32 2
  %t1877 = load i32, ptr %l17, !tbaa !23
  %t1880 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t1876, i32 %t1877)
  store i32 %t1880, ptr %l1003
  br label %bb526
bb525:
  %t1881 = load i1, ptr %l3, !tbaa !21
  br i1 %t1881, label %bb552, label %bb553
bb526:
  %t1883 = load ptr, ptr %l998, !tbaa !29
  %t1884 = load i32, ptr %l1003, !tbaa !23
  %t1885 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMembers(ptr %v0, ptr %t1883, i32 %t1884)
  store { i64, ptr } %t1885, ptr %l1004
  br label %bb527
bb527:
  %t1886 = load { i64, ptr }, ptr %l1004, !tbaa !27
  store { i64, ptr } %t1886, ptr %l92, !tbaa !27
  store i64 0, ptr %l93, !tbaa !24
  %t1887 = load ptr, ptr %l16, !tbaa !29
  %t1889 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t1887)
  store i64 %t1889, ptr %l1006
  br label %bb528
bb528:
  %t1890 = load i64, ptr %l1006, !tbaa !24
  store i64 %t1890, ptr %l94, !tbaa !24
  store i64 1, ptr %l95, !tbaa !24
  %t1891 = load i64, ptr %l94, !tbaa !24
  %t1892 = load i64, ptr %l93, !tbaa !24
  %t1895 = icmp sgt i64 %t1891, %t1892
  br i1 %t1895, label %bb529, label %bb530
bb529:
  %t1897 = load i64, ptr %l95, !tbaa !24
  %t1899 = icmp sgt i64 %t1897, 0
  br i1 %t1899, label %bb531, label %bb532
bb530:
  store i64 0, ptr %l1010, !tbaa !24
  br label %bb534
bb531:
  %t1901 = load i64, ptr %l94, !tbaa !24
  %t1902 = load i64, ptr %l93, !tbaa !24
  %t1905 = sub i64 %t1901, %t1902
  %t1906 = load i64, ptr %l95, !tbaa !24
  %t1909 = add i64 %t1905, %t1906
  %t1911 = sub i64 %t1909, 1
  %t1912 = load i64, ptr %l95, !tbaa !24
  %t1915 = sdiv i64 %t1911, %t1912
  store i64 %t1915, ptr %l1013, !tbaa !24
  br label %bb533
bb532:
  store i64 0, ptr %l1013, !tbaa !24
  br label %bb533
bb533:
  %t1917 = load i64, ptr %l1013, !tbaa !24
  store i64 %t1917, ptr %l1010, !tbaa !24
  br label %bb534
bb534:
  %t1918 = load i64, ptr %l1010, !tbaa !24
  store i64 %t1918, ptr %l96, !tbaa !24
  store i64 0, ptr %l97, !tbaa !24
  br label %bb535
bb535:
  store %olang.scope zeroinitializer, ptr %s74
  %t1919 = load i64, ptr %l97, !tbaa !24
  %t1920 = load i64, ptr %l96, !tbaa !24
  %t1923 = icmp slt i64 %t1919, %t1920
  %t1925 = xor i1 %t1923, true
  br i1 %t1925, label %bb536, label %bb537
bb536:
  call void @__olang_scope_close(ptr %s74)
  br label %bb551
bb537:
  br label %bb538
bb538:
  %t1927 = load i64, ptr %l93, !tbaa !24
  %t1928 = load i64, ptr %l97, !tbaa !24
  %t1929 = load i64, ptr %l95, !tbaa !24
  %t1932 = mul i64 %t1928, %t1929
  %t1935 = add i64 %t1927, %t1932
  store i64 %t1935, ptr %l98, !tbaa !24
  %t1937 = load ptr, ptr %l16, !tbaa !29
  %t1938 = load i64, ptr %l98, !tbaa !24
  %t1941 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t1937, i64 %t1938)
  store i1 %t1941, ptr %l1033
  br label %bb539
bb539:
  %t1942 = load i1, ptr %l1033, !tbaa !21
  %t1943 = xor i1 %t1942, true
  br i1 %t1943, label %bb540, label %bb541
bb540:
  %t1945 = load i64, ptr %l98, !tbaa !24
  %t1946 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t1948 = extractvalue { i64, ptr } %t1946, 0
  %t1951 = icmp slt i64 %t1945, %t1948
  store i1 %t1951, ptr %l1035, !tbaa !21
  br label %bb542
bb541:
  store i1 false, ptr %l1035, !tbaa !21
  br label %bb542
bb542:
  %t1953 = load i1, ptr %l1035, !tbaa !21
  br i1 %t1953, label %bb543, label %bb544
bb543:
  store %olang.scope zeroinitializer, ptr %s75
  %t1954 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1954, ptr %l1040, !tbaa !29
  %t1955 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t1955, ptr %l1041
  %t1956 = load ptr, ptr %l0, !tbaa !29
  %t1957 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t1957, ptr %l1043, !tbaa !27
  %t1958 = load i64, ptr %l98, !tbaa !24
  %t1960 = getelementptr { i64, ptr }, ptr %l1043, i32 0, i32 1
  %t1961 = load ptr, ptr %t1960, !tbaa !27
  %t1962 = getelementptr i32, ptr %t1961, i64 %t1958
  %t1963 = load i32, ptr %t1962, !tbaa !33
  %t1966 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s75, ptr %t1956, i32 %t1963)
  store { i64, ptr } %t1966, ptr %l1046
  br label %bb545
bb544:
  br label %bb549
bb545:
  %t1967 = load { i64, ptr }, ptr %l1046, !tbaa !27
  %t1968 = extractvalue { i64, ptr } %t1967, 0
  %t1969 = extractvalue { i64, ptr } %t1967, 1
  %t1970 = mul i64 %t1968, 1
  %t1971 = call ptr @__olang_scope_alloc(ptr %s75, i64 %t1970)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1971, ptr %t1969, i64 %t1970, i1 false)
  %t1972 = insertvalue { i64, ptr } undef, i64 %t1968, 0
  %t1973 = insertvalue { i64, ptr } %t1972, ptr %t1971, 1
  store { i64, ptr } %t1973, ptr %l1047, !tbaa !27
  %t1974 = load ptr, ptr %l0, !tbaa !29
  %t1975 = load i32, ptr %l6, !tbaa !23
  %t1978 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s75, ptr %t1974, i32 %t1975)
  store { i64, ptr } %t1978, ptr %l1050
  br label %bb546
bb546:
  %t1979 = load { i64, ptr }, ptr %l1050, !tbaa !27
  %t1980 = extractvalue { i64, ptr } %t1979, 0
  %t1981 = extractvalue { i64, ptr } %t1979, 1
  %t1982 = mul i64 %t1980, 1
  %t1983 = call ptr @__olang_scope_alloc(ptr %s75, i64 %t1982)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1983, ptr %t1981, i64 %t1982, i1 false)
  %t1984 = insertvalue { i64, ptr } undef, i64 %t1980, 0
  %t1985 = insertvalue { i64, ptr } %t1984, ptr %t1983, 1
  %t1986 = load { i64, ptr }, ptr %l1047, !tbaa !27
  %t1988 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatchNotExhaustive(ptr %s75, ptr %s75, ptr %s75, { i64, ptr } %t1986, { i64, ptr } %t1985)
  store %"compiler/msgs:Msg" %t1988, ptr %l1052
  br label %bb547
bb547:
  %t1989 = load ptr, ptr %l1040, !tbaa !29
  %t1990 = load %"compiler/source:Span", ptr %l1041
  %t1991 = load %"compiler/msgs:Msg", ptr %l1052
  %t1992 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s75, ptr %t1989, %"compiler/source:Span" %t1990, %"compiler/msgs:Msg" %t1991)
  store i64 %t1992, ptr %l1053
  br label %bb548
bb548:
  call void @__olang_scope_close(ptr %s75)
  call void @__olang_scope_close(ptr %s74)
  br label %bb551
bb549:
  call void @__olang_scope_close(ptr %s74)
  br label %bb550
bb550:
  %t1993 = load i64, ptr %l97, !tbaa !24
  %t1995 = add i64 %t1993, 1
  store i64 %t1995, ptr %l97, !tbaa !24
  br label %bb535
bb551:
  br label %bb565
bb552:
  %t1997 = load i1, ptr %l68, !tbaa !21
  %t1999 = xor i1 %t1997, true
  store i1 %t1999, ptr %l1057, !tbaa !21
  br label %bb554
bb553:
  store i1 false, ptr %l1057, !tbaa !21
  br label %bb554
bb554:
  %t2001 = load i1, ptr %l1057, !tbaa !21
  br i1 %t2001, label %bb555, label %bb556
bb555:
  %t2002 = load i32, ptr %l6, !tbaa !23
  %t2003 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t2006 = icmp ne i32 %t2002, %t2003
  store i1 %t2006, ptr %l1060, !tbaa !21
  br label %bb557
bb556:
  store i1 false, ptr %l1060, !tbaa !21
  br label %bb557
bb557:
  %t2008 = load i1, ptr %l1060, !tbaa !21
  br i1 %t2008, label %bb558, label %bb559
bb558:
  store %olang.scope zeroinitializer, ptr %s78
  %t2009 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2009, ptr %l1064, !tbaa !29
  %t2010 = load ptr, ptr %l2, !tbaa !29
  %t2012 = getelementptr %"compiler/ast:Match", ptr %t2010, i32 0, i32 0
  %t2013 = getelementptr %"compiler/source:Span", ptr %t2012, i32 0, i32 0
  %t2014 = load i32, ptr %t2013, !tbaa !23
  %t2015 = load ptr, ptr %l2, !tbaa !29
  %t2017 = getelementptr %"compiler/ast:Match", ptr %t2015, i32 0, i32 0
  %t2018 = getelementptr %"compiler/source:Span", ptr %t2017, i32 0, i32 0
  %t2019 = load i32, ptr %t2018, !tbaa !23
  %t2021 = add i32 %t2019, 5
  %t2024 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s78, i32 %t2014, i32 %t2021)
  store %"compiler/source:Span" %t2024, ptr %l1070
  br label %bb560
bb559:
  br label %bb564
bb560:
  %t2025 = load ptr, ptr %l0, !tbaa !29
  %t2026 = load i32, ptr %l6, !tbaa !23
  %t2029 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s78, ptr %t2025, i32 %t2026)
  store { i64, ptr } %t2029, ptr %l1073
  br label %bb561
bb561:
  %t2030 = load { i64, ptr }, ptr %l1073, !tbaa !27
  %t2031 = extractvalue { i64, ptr } %t2030, 0
  %t2032 = extractvalue { i64, ptr } %t2030, 1
  %t2033 = mul i64 %t2031, 1
  %t2034 = call ptr @__olang_scope_alloc(ptr %s78, i64 %t2033)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2034, ptr %t2032, i64 %t2033, i1 false)
  %t2035 = insertvalue { i64, ptr } undef, i64 %t2031, 0
  %t2036 = insertvalue { i64, ptr } %t2035, ptr %t2034, 1
  %t2038 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatchValueNeedsNomatch(ptr %s78, ptr %s78, { i64, ptr } %t2036)
  store %"compiler/msgs:Msg" %t2038, ptr %l1075
  br label %bb562
bb562:
  %t2039 = load ptr, ptr %l1064, !tbaa !29
  %t2040 = load %"compiler/source:Span", ptr %l1070
  %t2041 = load %"compiler/msgs:Msg", ptr %l1075
  %t2042 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s78, ptr %t2039, %"compiler/source:Span" %t2040, %"compiler/msgs:Msg" %t2041)
  store i64 %t2042, ptr %l1076
  br label %bb563
bb563:
  call void @__olang_scope_close(ptr %s78)
  br label %bb564
bb564:
  br label %bb565
bb565:
  br label %bb566
bb566:
  %t2043 = load ptr, ptr %l0, !tbaa !29
  %t2045 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t2043)
  store ptr %t2045, ptr %l1078
  br label %bb567
bb567:
  %t2046 = load ptr, ptr %l1078, !tbaa !29
  %t2048 = getelementptr %"compiler/check:frame", ptr %t2046, i32 0, i32 7
  %t2049 = load i64, ptr %t2048, !tbaa !24
  %t2051 = trunc i64 %t2049 to i32
  store i32 %t2051, ptr %l1082, !tbaa !23
  %t2053 = load ptr, ptr %l0, !tbaa !29
  %t2055 = getelementptr %"compiler/check:Checker", ptr %t2053, i32 0, i32 33
  %t2056 = load i64, ptr %l89, !tbaa !24
  %t2059 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t2055, i64 %t2056)
  store { i64, ptr } %t2059, ptr %l1086
  br label %bb568
bb568:
  %t2060 = load i32, ptr %l1082, !tbaa !23
  %t2061 = load { i64, ptr }, ptr %l1086, !tbaa !27
  %t2062 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 %t2060, { i64, ptr } %t2061)
  store %"compiler/typed:Block" %t2062, ptr %l1087
  br label %bb569
bb569:
  %t2063 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store ptr %t2063, ptr %lp99
  %t2064 = load %"compiler/typed:Block", ptr %l1087
  %t2065 = load ptr, ptr %lp99
  store %"compiler/typed:Block" %t2064, ptr %t2065
  %t2066 = load ptr, ptr %l2, !tbaa !29
  %t2068 = getelementptr %"compiler/ast:Match", ptr %t2066, i32 0, i32 0
  %t2069 = load %"compiler/source:Span", ptr %t2068
  store %"compiler/source:Span" %t2069, ptr %l1089
  %t2070 = icmp sge i64 0, 0
  br i1 %t2070, label %bb570, label %bb571
bb570:
  %t2072 = icmp sle i64 0, 1152921504606846975
  br i1 %t2072, label %bb572, label %bb573
bb571:
  call void @__olang_check_failed(ptr @olang_loc_2c70c8b858b42283_1a594eed4640d73f)
  unreachable
bb572:
  %t2074 = mul i64 0, 8
  %t2075 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t2074)
  %t2076 = insertvalue { i64, ptr } undef, i64 0, 0
  %t2077 = insertvalue { i64, ptr } %t2076, ptr %t2075, 1
  %t2078 = load ptr, ptr %lp99
  %t2079 = load %"compiler/source:Span", ptr %l1089
  %t2082 = call %"compiler/typed:Arm" @compiler_2ftyped_3aArm_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t2079, { i64, ptr } %t2077, ptr null, ptr %t2078, ptr null)
  store %"compiler/typed:Arm" %t2082, ptr %l1094
  br label %bb574
bb573:
  call void @__olang_check_failed(ptr @olang_loc_2c70c8b858b42283_1a594eed4640d73f)
  unreachable
bb574:
  %t2083 = load %"compiler/typed:Arm", ptr %l1094
  %t2084 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store %"compiler/typed:Arm" %t2083, ptr %t2084
  store ptr %t2084, ptr %l75, !tbaa !29
  br label %bb575
bb575:
  %t2086 = load i1, ptr %l3, !tbaa !21
  %t2088 = xor i1 %t2086, true
  br i1 %t2088, label %bb576, label %bb577
bb576:
  %t2090 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t2090, ptr %l13, !tbaa !23
  br label %bb578
bb577:
  br label %bb578
bb578:
  store %"compiler/source:Span" %a1, ptr %l1099
  %t2093 = load i32, ptr %l13, !tbaa !23
  store i32 %t2093, ptr %l1100, !tbaa !23
  %t2094 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t2094, ptr %l1101, !tbaa !27
  %t2095 = load ptr, ptr %l15, !tbaa !29
  %t2097 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aArm_26_3e_2eToAr_H5bf9b1ae81338b8dbc841edb7f38b9b5(ptr %v0, ptr %v0, ptr %t2095)
  store { i64, ptr } %t2097, ptr %l1103
  br label %bb579
bb579:
  %t2098 = load ptr, ptr %l75, !tbaa !29
  %t2099 = load i1, ptr %l3, !tbaa !21
  %t2100 = load { i64, ptr }, ptr %l1101, !tbaa !27
  %t2101 = load { i64, ptr }, ptr %l1103, !tbaa !27
  %t2104 = call %"compiler/typed:Match" @compiler_2ftyped_3aMatch_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t2100, { i64, ptr } %t2101, ptr %t2098, i1 %t2099)
  store %"compiler/typed:Match" %t2104, ptr %l1106
  br label %bb580
bb580:
  %t2105 = load %"compiler/typed:Match", ptr %l1106
  %t2106 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store %"compiler/typed:Match" %t2105, ptr %t2106
  store { i64, [5 x i64] } zeroinitializer, ptr %t2107
  %t2108 = getelementptr { i64, [5 x i64] }, ptr %t2107, i32 0, i32 0
  store i64 13, ptr %t2108
  %t2109 = load %"compiler/source:Span", ptr %l1099
  %t2110 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t2109, 0
  %t2111 = load i32, ptr %l1100, !tbaa !23
  %t2112 = insertvalue { %"compiler/source:Span", i32, ptr } %t2110, i32 %t2111, 1
  %t2114 = insertvalue { %"compiler/source:Span", i32, ptr } %t2112, ptr %t2106, 2
  %t2115 = getelementptr { i64, [5 x i64] }, ptr %t2107, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t2114, ptr %t2115
  %t2116 = load { i64, [5 x i64] }, ptr %t2107
  %t2118 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t2116, ptr %t2118
  store ptr %t2118, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emerged(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i32
  %l35 = alloca { i64, ptr }
  %l41 = alloca i1
  %l49 = alloca i32
  %l51 = alloca i64
  %l55 = alloca i64
  %l58 = alloca i64
  %l78 = alloca ptr
  %l81 = alloca i32
  %l82 = alloca i32
  %l94 = alloca i32
  %l97 = alloca i1
  %l106 = alloca i64
  %l109 = alloca i64
  %l111 = alloca i64
  %l116 = alloca ptr
  %l119 = alloca i32
  %l120 = alloca i64
  %l125 = alloca i64
  %l129 = alloca ptr
  %l130 = alloca i64
  %l134 = alloca i32
  %l141 = alloca i32
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l20
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  store ptr %a1, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %v1, ptr %t7, i64 %t8)
  %t12 = extractvalue { i32, { i64, ptr } } %t11, 1
  %t13 = extractvalue { i32, { i64, ptr } } %t11, 0
  store i32 %t13, ptr %l26
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb4, label %ok.15
ok.15:
  store { i64, ptr } %t12, ptr %l25
  br label %bb3
bb3:
  %t16 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t16, ptr %l22, !tbaa !27
  br label %bb8
bb4:
  %t17 = load i32, ptr %l26, !tbaa !23
  %t18 = ashr i32 %t17, 16
  %t20 = icmp eq i32 %t18, 1
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_6cbd96901f6df06f_ceca876e38978373)
  unreachable
bb7:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb65
bb8:
  %t22 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t22, ptr %l5, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 0
  store i64 %t25, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t27 = load i64, ptr %l7, !tbaa !24
  %t28 = load i64, ptr %l6, !tbaa !24
  %t31 = icmp slt i64 %t27, %t28
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb63
bb11:
  br label %bb12
bb12:
  %t35 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t35, ptr %l35, !tbaa !27
  %t36 = load i64, ptr %l7, !tbaa !24
  %t38 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr i32, ptr %t39, i64 %t36
  %t41 = load i32, ptr %t40, !tbaa !33
  store i32 %t41, ptr %l8, !tbaa !23
  %t43 = load i32, ptr %l8, !tbaa !23
  %t44 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  %t47 = icmp eq i32 %t43, %t44
  br i1 %t47, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb15
bb14:
  %t49 = load i32, ptr %l8, !tbaa !23
  %t50 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t53 = icmp eq i32 %t49, %t50
  store i1 %t53, ptr %l41, !tbaa !21
  br label %bb15
bb15:
  %t55 = load i1, ptr %l41, !tbaa !21
  br i1 %t55, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb62
bb17:
  br label %bb18
bb18:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  %t62 = load i32, ptr %l8, !tbaa !23
  %t65 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t61, i32 %t62)
  store i32 %t65, ptr %l49
  br label %bb19
bb19:
  %t66 = load i32, ptr %l49, !tbaa !23
  store i32 %t66, ptr %l9, !tbaa !23
  store i64 -1, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  %t67 = load ptr, ptr %lp2
  %t69 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t67)
  store i64 %t69, ptr %l51
  br label %bb20
bb20:
  %t70 = load i64, ptr %l51, !tbaa !24
  store i64 %t70, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t71 = load i64, ptr %l12, !tbaa !24
  %t72 = load i64, ptr %l11, !tbaa !24
  %t75 = icmp sgt i64 %t71, %t72
  br i1 %t75, label %bb21, label %bb22
bb21:
  %t77 = load i64, ptr %l13, !tbaa !24
  %t79 = icmp sgt i64 %t77, 0
  br i1 %t79, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb26
bb23:
  %t81 = load i64, ptr %l12, !tbaa !24
  %t82 = load i64, ptr %l11, !tbaa !24
  %t85 = sub i64 %t81, %t82
  %t86 = load i64, ptr %l13, !tbaa !24
  %t89 = add i64 %t85, %t86
  %t91 = sub i64 %t89, 1
  %t92 = load i64, ptr %l13, !tbaa !24
  %t95 = sdiv i64 %t91, %t92
  store i64 %t95, ptr %l58, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb25
bb25:
  %t97 = load i64, ptr %l58, !tbaa !24
  store i64 %t97, ptr %l55, !tbaa !24
  br label %bb26
bb26:
  %t98 = load i64, ptr %l55, !tbaa !24
  store i64 %t98, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s6
  %t99 = load i64, ptr %l15, !tbaa !24
  %t100 = load i64, ptr %l14, !tbaa !24
  %t103 = icmp slt i64 %t99, %t100
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s6)
  br label %bb37
bb29:
  br label %bb30
bb30:
  %t107 = load i64, ptr %l11, !tbaa !24
  %t108 = load i64, ptr %l15, !tbaa !24
  %t109 = load i64, ptr %l13, !tbaa !24
  %t112 = mul i64 %t108, %t109
  %t115 = add i64 %t107, %t112
  store i64 %t115, ptr %l16, !tbaa !24
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = getelementptr %"compiler/generic:Program", ptr %t120, i32 0, i32 2
  store ptr %t122, ptr %l78, !tbaa !29
  %t123 = load ptr, ptr %lp2
  %t124 = load i64, ptr %l16, !tbaa !24
  %t127 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t123, i64 %t124)
  store i32 %t127, ptr %l81
  br label %bb31
bb31:
  %t128 = load ptr, ptr %l78, !tbaa !29
  %t129 = load i32, ptr %l81, !tbaa !23
  %t130 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t128, i32 %t129)
  store i32 %t130, ptr %l82
  br label %bb32
bb32:
  %t131 = load i32, ptr %l9, !tbaa !23
  %t132 = load i32, ptr %l82, !tbaa !23
  %t134 = icmp eq i32 %t132, %t131
  br i1 %t134, label %bb33, label %bb34
bb33:
  %t136 = load i64, ptr %l16, !tbaa !24
  store i64 %t136, ptr %l10, !tbaa !24
  br label %bb35
bb34:
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s6)
  br label %bb36
bb36:
  %t138 = load i64, ptr %l15, !tbaa !24
  %t140 = add i64 %t138, 1
  store i64 %t140, ptr %l15, !tbaa !24
  br label %bb27
bb37:
  %t142 = load i64, ptr %l10, !tbaa !24
  %t144 = icmp slt i64 %t142, 0
  br i1 %t144, label %bb38, label %bb39
bb38:
  %t146 = load ptr, ptr %lp2
  %t147 = load i32, ptr %l8, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t146, i32 %t147)
  br label %bb40
bb39:
  br label %bb41
bb40:
  call void @__olang_scope_close(ptr %s3)
  br label %bb62
bb41:
  %t150 = load ptr, ptr %lp2
  %t151 = load i64, ptr %l10, !tbaa !24
  %t154 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t150, i64 %t151)
  store i32 %t154, ptr %l94
  br label %bb42
bb42:
  %t155 = load i32, ptr %l9, !tbaa !23
  %t156 = load i32, ptr %l94, !tbaa !23
  %t158 = icmp eq i32 %t156, %t155
  br i1 %t158, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l97, !tbaa !21
  br label %bb45
bb44:
  %t160 = load i32, ptr %l8, !tbaa !23
  %t161 = load i32, ptr %l9, !tbaa !23
  %t164 = icmp eq i32 %t160, %t161
  store i1 %t164, ptr %l97, !tbaa !21
  br label %bb45
bb45:
  %t166 = load i1, ptr %l97, !tbaa !21
  br i1 %t166, label %bb46, label %bb47
bb46:
  %t167 = load ptr, ptr %lp2
  %t168 = load i64, ptr %l10, !tbaa !24
  %t169 = load i32, ptr %l9, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t167, i64 %t168, i32 %t169)
  br label %bb48
bb47:
  br label %bb49
bb48:
  call void @__olang_scope_close(ptr %s3)
  br label %bb62
bb49:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i32, ptr %l9, !tbaa !23
  %t177 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordCount(ptr %v0, ptr %t173, i32 %t174)
  store i64 %t177, ptr %l106
  br label %bb50
bb50:
  %t178 = load i64, ptr %l106, !tbaa !24
  store i64 %t178, ptr %l17, !tbaa !24
  %t179 = load i64, ptr %l17, !tbaa !24
  %t181 = icmp sge i64 %t179, 64
  br i1 %t181, label %bb51, label %bb52
bb51:
  %t183 = sub i64 0, 1
  store i64 %t183, ptr %l109, !tbaa !65
  br label %bb53
bb52:
  %t185 = load i64, ptr %l17, !tbaa !24
  store i64 %t185, ptr %l111, !tbaa !24
  %t186 = load i64, ptr %l111, !tbaa !24
  %t187 = load i64, ptr %l111, !tbaa !24
  %t188 = shl i64 1, %t187
  %t190 = sub i64 %t188, 1
  store i64 %t190, ptr %l109, !tbaa !65
  br label %bb53
bb53:
  %t192 = load i64, ptr %l109, !tbaa !65
  store i64 %t192, ptr %l18, !tbaa !65
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/check:Checker", ptr %t193, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !29
  %t198 = getelementptr %"compiler/generic:Program", ptr %t196, i32 0, i32 2
  store ptr %t198, ptr %l116, !tbaa !29
  %t199 = load ptr, ptr %lp2
  %t200 = load i64, ptr %l10, !tbaa !24
  %t203 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t199, i64 %t200)
  store i32 %t203, ptr %l119
  br label %bb54
bb54:
  %t204 = load ptr, ptr %l116, !tbaa !29
  %t205 = load i32, ptr %l119, !tbaa !23
  %t206 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t204, i32 %t205)
  store i64 %t206, ptr %l120
  br label %bb55
bb55:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t209 = getelementptr %"compiler/check:Checker", ptr %t207, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !29
  %t212 = getelementptr %"compiler/generic:Program", ptr %t210, i32 0, i32 2
  %t213 = load i32, ptr %l8, !tbaa !23
  %t216 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t212, i32 %t213)
  store i64 %t216, ptr %l125
  br label %bb56
bb56:
  %t217 = load i64, ptr %l120, !tbaa !65
  %t218 = load i64, ptr %l125, !tbaa !65
  %t219 = or i64 %t217, %t218
  %t220 = load i64, ptr %l18, !tbaa !65
  %t223 = and i64 %t219, %t220
  store i64 %t223, ptr %l19, !tbaa !65
  %t225 = load ptr, ptr %lp2
  store ptr %t225, ptr %l129, !tbaa !29
  %t226 = load i64, ptr %l10, !tbaa !24
  store i64 %t226, ptr %l130, !tbaa !24
  %t227 = load i64, ptr %l19, !tbaa !65
  %t228 = load i64, ptr %l18, !tbaa !65
  %t231 = icmp eq i64 %t227, %t228
  br i1 %t231, label %bb57, label %bb58
bb57:
  %t233 = load i32, ptr %l9, !tbaa !23
  store i32 %t233, ptr %l134, !tbaa !23
  br label %bb60
bb58:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/check:Checker", ptr %t235, i32 0, i32 1
  %t238 = load ptr, ptr %t237, !tbaa !29
  %t240 = getelementptr %"compiler/generic:Program", ptr %t238, i32 0, i32 2
  %t241 = load i32, ptr %l9, !tbaa !23
  %t242 = load i64, ptr %l19, !tbaa !65
  %t246 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %t240, i32 %t241, i64 %t242)
  store i32 %t246, ptr %l141
  br label %bb59
bb59:
  %t247 = load i32, ptr %l141, !tbaa !23
  store i32 %t247, ptr %l134, !tbaa !23
  br label %bb60
bb60:
  %t248 = load ptr, ptr %l129, !tbaa !29
  %t249 = load i64, ptr %l130, !tbaa !24
  %t250 = load i32, ptr %l134, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t248, i64 %t249, i32 %t250)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s3)
  br label %bb62
bb62:
  %t251 = load i64, ptr %l7, !tbaa !24
  %t253 = add i64 %t251, 1
  store i64 %t253, ptr %l7, !tbaa !24
  br label %bb9
bb63:
  %t255 = load i64, ptr %l4, !tbaa !24
  %t256 = load i64, ptr %l6, !tbaa !24
  %t259 = add i64 %t255, %t256
  store i64 %t259, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb64
bb64:
  br label %bb2
bb65:
  %t261 = load ptr, ptr %lp2
  %t262 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t261
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t262, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesType(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l12 = alloca { i64, ptr }
  %l17 = alloca i32
  %l20 = alloca i1
  %l22 = alloca i1
  %l23 = alloca i1
  %l25 = alloca i1
  %l31 = alloca i64
  %l35 = alloca i1
  %l42 = alloca i64
  %l46 = alloca i64
  %l49 = alloca i64
  %l72 = alloca ptr
  %l75 = alloca i1
  %l80 = alloca i64
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v0, ptr %t12, { i64, ptr } %t13)
  store i32 %t16, ptr %l17
  br label %bb2
bb2:
  %t17 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t18 = load i32, ptr %l17, !tbaa !23
  %t20 = icmp ne i32 %t18, %t17
  br i1 %t20, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb6
bb4:
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t24 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t22, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store i1 %t24, ptr %l22
  br label %bb5
bb5:
  %t25 = load i1, ptr %l22, !tbaa !21
  store i1 %t25, ptr %l20, !tbaa !21
  br label %bb6
bb6:
  %t26 = load i1, ptr %l20, !tbaa !21
  br i1 %t26, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb10
bb8:
  %t27 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t29 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t27, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store i1 %t29, ptr %l25
  br label %bb9
bb9:
  %t30 = load i1, ptr %l25, !tbaa !21
  store i1 %t30, ptr %l23, !tbaa !21
  br label %bb10
bb10:
  %t31 = load i1, ptr %l23, !tbaa !21
  br i1 %t31, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = load i32, ptr %l2, !tbaa !23
  %t42 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %t36, i64 %a1, i32 %t38)
  store i64 %t42, ptr %l31
  br label %bb14
bb14:
  %t43 = load i64, ptr %l31, !tbaa !24
  %t44 = icmp sge i64 %t43, 0
  br i1 %t44, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t47 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t49 = call i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %t47)
  store i1 %t49, ptr %l35
  br label %bb18
bb18:
  %t50 = load i1, ptr %l35, !tbaa !21
  %t51 = xor i1 %t50, true
  br i1 %t51, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  store i64 0, ptr %l4, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/generic:Program", ptr %t57, i32 0, i32 0
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/load:Loader", ptr %t60, i32 0, i32 5
  %t64 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %t62)
  store i64 %t64, ptr %l42
  br label %bb22
bb22:
  %t65 = load i64, ptr %l42, !tbaa !24
  store i64 %t65, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t66 = load i64, ptr %l5, !tbaa !24
  %t67 = load i64, ptr %l4, !tbaa !24
  %t70 = icmp sgt i64 %t66, %t67
  br i1 %t70, label %bb23, label %bb24
bb23:
  %t72 = load i64, ptr %l6, !tbaa !24
  %t74 = icmp sgt i64 %t72, 0
  br i1 %t74, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb28
bb25:
  %t76 = load i64, ptr %l5, !tbaa !24
  %t77 = load i64, ptr %l4, !tbaa !24
  %t80 = sub i64 %t76, %t77
  %t81 = load i64, ptr %l6, !tbaa !24
  %t84 = add i64 %t80, %t81
  %t86 = sub i64 %t84, 1
  %t87 = load i64, ptr %l6, !tbaa !24
  %t90 = sdiv i64 %t86, %t87
  store i64 %t90, ptr %l49, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb27
bb27:
  %t92 = load i64, ptr %l49, !tbaa !24
  store i64 %t92, ptr %l46, !tbaa !24
  br label %bb28
bb28:
  %t93 = load i64, ptr %l46, !tbaa !24
  store i64 %t93, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s5
  %t94 = load i64, ptr %l8, !tbaa !24
  %t95 = load i64, ptr %l7, !tbaa !24
  %t98 = icmp slt i64 %t94, %t95
  %t100 = xor i1 %t98, true
  br i1 %t100, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb42
bb31:
  br label %bb32
bb32:
  %t102 = load i64, ptr %l4, !tbaa !24
  %t103 = load i64, ptr %l8, !tbaa !24
  %t104 = load i64, ptr %l6, !tbaa !24
  %t107 = mul i64 %t103, %t104
  %t110 = add i64 %t102, %t107
  store i64 %t110, ptr %l9, !tbaa !24
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/check:Checker", ptr %t112, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t117 = getelementptr %"compiler/generic:Program", ptr %t115, i32 0, i32 0
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = getelementptr %"compiler/load:Loader", ptr %t118, i32 0, i32 5
  %t121 = load i64, ptr %l9, !tbaa !24
  %t124 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t120, i64 %t121)
  store ptr %t124, ptr %l72
  br label %bb33
bb33:
  %t125 = load ptr, ptr %l72, !tbaa !29
  %t127 = getelementptr %"compiler/load:Module", ptr %t125, i32 0, i32 3
  %t128 = load i1, ptr %t127, !tbaa !21
  br i1 %t128, label %bb34, label %bb35
bb34:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/check:Checker", ptr %t130, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t134 = load i64, ptr %l9, !tbaa !24
  %t135 = load i32, ptr %l2, !tbaa !23
  %t139 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %t133, i64 %t134, i32 %t135)
  store i64 %t139, ptr %l80
  br label %bb36
bb35:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb37
bb36:
  %t140 = load i64, ptr %l80, !tbaa !24
  %t141 = icmp sge i64 %t140, 0
  store i1 %t141, ptr %l75, !tbaa !21
  br label %bb37
bb37:
  %t143 = load i1, ptr %l75, !tbaa !21
  br i1 %t143, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s5)
  br label %bb41
bb41:
  %t145 = load i64, ptr %l8, !tbaa !24
  %t147 = add i64 %t145, 1
  store i64 %t147, ptr %l8, !tbaa !24
  br label %bb29
bb42:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoreturnSpan(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l24 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = load %"compiler/source:Span", ptr %l1
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %a0, %"compiler/source:Span" %t2)
  store { i64, ptr } %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t9 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s0, { i64, ptr } %t6, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d32, i32 0, i32 1) })
  %t10 = extractvalue { i32, i64 } %t9, 1
  %t11 = extractvalue { i32, i64 } %t9, 0
  store i32 %t11, ptr %l10
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13
ok.13:
  store i64 %t10, ptr %l9
  br label %bb2
bb2:
  %t14 = load i64, ptr %l9, !tbaa !24
  store i64 %t14, ptr %l7, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l7, !tbaa !24
  br label %bb5
bb5:
  %t15 = load i64, ptr %l7, !tbaa !24
  store i64 %t15, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = icmp slt i64 %t16, 0
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load %"compiler/source:Span", ptr %l1
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/source:Span" %t20, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t22 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t23 = load i32, ptr %t22, !tbaa !23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t26 = add i64 %t24, 2
  %t28 = trunc i64 %t26 to i32
  %t31 = add i32 %t23, %t28
  %t32 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t33 = load i32, ptr %t32, !tbaa !23
  %t34 = load i64, ptr %l3, !tbaa !24
  %t36 = add i64 %t34, 10
  %t38 = trunc i64 %t36 to i32
  %t41 = add i32 %t33, %t38
  %t44 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t31, i32 %t41)
  store %"compiler/source:Span" %t44, ptr %l24
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t45 = load %"compiler/source:Span", ptr %l24
  store %"compiler/source:Span" %t45, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eowningIn(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l14 = alloca i1
  %l23 = alloca i32
  %l30 = alloca i64
  %l36 = alloca i1
  %l41 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l61 = alloca i1
  %l68 = alloca i1
  %l73 = alloca i32
  %l75 = alloca ptr
  %l80 = alloca i32
  %l83 = alloca i1
  %l86 = alloca i1
  %l90 = alloca i1
  %l91 = alloca i1
  %l94 = alloca ptr
  %l99 = alloca i32
  %l100 = alloca i32
  %l105 = alloca ptr
  %l110 = alloca i32
  %l111 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l125 = alloca i1
  %s5 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  store i1 %t9, ptr %l14, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l14, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l23
  br label %bb7
bb7:
  %t23 = load i32, ptr %l23
  store i32 %t23, ptr %l3
  %t24 = load i32, ptr %l3
  %t26 = trunc i64 20 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb8, label %bb9
bb8:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load i32, ptr %l1, !tbaa !23
  %t38 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t34, i32 %t35)
  store i64 %t38, ptr %l30
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t39 = load i64, ptr @G_2ecompiler_2ftypes_2eOwning, !tbaa !24
  %t40 = load i64, ptr %l30, !tbaa !24
  %t42 = and i64 %t40, %t39
  %t44 = icmp ne i64 %t42, 0
  store i1 %t44, ptr %rv
  br label %ret
bb11:
  %t46 = load i32, ptr %l3
  %t48 = trunc i64 22 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb14
bb13:
  %t51 = load i32, ptr %l3
  %t53 = trunc i64 23 to i32
  %t54 = icmp eq i32 %t51, %t53
  store i1 %t54, ptr %l36, !tbaa !21
  br label %bb14
bb14:
  %t56 = load i1, ptr %l36, !tbaa !21
  br i1 %t56, label %bb15, label %bb16
bb15:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 2
  store ptr %t62, ptr %l41, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  %t69 = load i32, ptr %l1, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t72, ptr %l46
  br label %bb17
bb16:
  br label %bb29
bb17:
  %t73 = load ptr, ptr %l41, !tbaa !29
  %t74 = load i32, ptr %l46, !tbaa !23
  %t75 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t73, i32 %t74)
  store { i64, ptr } %t75, ptr %l47
  br label %bb18
bb18:
  %t76 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t76, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t77 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t77, 0
  store i64 %t79, ptr %l6, !tbaa !24
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  %t81 = load i64, ptr %l5, !tbaa !24
  %t82 = load i64, ptr %l6, !tbaa !24
  %t85 = icmp slt i64 %t81, %t82
  %t87 = xor i1 %t85, true
  br i1 %t87, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s5)
  br label %bb28
bb21:
  br label %bb22
bb22:
  %t89 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t89, ptr %l54, !tbaa !27
  %t90 = load i64, ptr %l5, !tbaa !24
  %t92 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr i32, ptr %t93, i64 %t90
  %t95 = load i32, ptr %t94, !tbaa !33
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = load i64, ptr %l2, !tbaa !24
  %t101 = add i64 %t99, 1
  %t105 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eowningIn(ptr %v0, ptr %t97, i32 %t95, i64 %t101)
  store i1 %t105, ptr %l61
  br label %bb23
bb23:
  %t106 = load i1, ptr %l61, !tbaa !21
  br i1 %t106, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s5)
  store i1 true, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s5)
  br label %bb27
bb27:
  %t108 = load i64, ptr %l5, !tbaa !24
  %t110 = add i64 %t108, 1
  store i64 %t110, ptr %l5, !tbaa !24
  br label %bb19
bb28:
  store i1 false, ptr %rv
  br label %ret
bb29:
  %t113 = load i32, ptr %l3
  %t115 = trunc i64 19 to i32
  %t116 = icmp eq i32 %t113, %t115
  br i1 %t116, label %bb30, label %bb31
bb30:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/check:Checker", ptr %t118, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t123 = getelementptr %"compiler/generic:Program", ptr %t121, i32 0, i32 2
  %t124 = load i32, ptr %l1, !tbaa !23
  %t127 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t123, i32 %t124)
  store i32 %t127, ptr %l73
  br label %bb32
bb31:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb33
bb32:
  %t128 = load i32, ptr %l73, !tbaa !23
  %t129 = icmp ne i32 %t128, 0
  store i1 %t129, ptr %l68, !tbaa !21
  br label %bb33
bb33:
  %t131 = load i1, ptr %l68, !tbaa !21
  br i1 %t131, label %bb34, label %bb35
bb34:
  %t132 = load ptr, ptr %l0, !tbaa !29
  store ptr %t132, ptr %l75, !tbaa !29
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/check:Checker", ptr %t133, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t138 = getelementptr %"compiler/generic:Program", ptr %t136, i32 0, i32 2
  %t139 = load i32, ptr %l1, !tbaa !23
  %t142 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t138, i32 %t139)
  store i32 %t142, ptr %l80
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t143 = load i64, ptr %l2, !tbaa !24
  %t145 = add i64 %t143, 1
  %t146 = load ptr, ptr %l75, !tbaa !29
  %t147 = load i32, ptr %l80, !tbaa !23
  %t149 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eowningIn(ptr %v0, ptr %t146, i32 %t147, i64 %t145)
  store i1 %t149, ptr %l83
  br label %bb37
bb37:
  %t150 = load i1, ptr %l83, !tbaa !21
  store i1 %t150, ptr %rv
  br label %ret
bb38:
  %t151 = load i32, ptr %l3
  %t153 = trunc i64 18 to i32
  %t154 = icmp eq i32 %t151, %t153
  br i1 %t154, label %bb39, label %bb40
bb39:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/check:Checker", ptr %t156, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t160 = load i32, ptr %l1, !tbaa !23
  %t163 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t159, i32 %t160)
  store i1 %t163, ptr %l90
  br label %bb41
bb40:
  store i1 false, ptr %l86, !tbaa !21
  br label %bb42
bb41:
  %t164 = load i1, ptr %l90, !tbaa !21
  store i1 %t164, ptr %l86, !tbaa !21
  br label %bb42
bb42:
  %t165 = load i1, ptr %l86, !tbaa !21
  br i1 %t165, label %bb43, label %bb44
bb43:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/check:Checker", ptr %t166, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t171 = getelementptr %"compiler/generic:Program", ptr %t169, i32 0, i32 2
  store ptr %t171, ptr %l94, !tbaa !29
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"compiler/check:Checker", ptr %t172, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !29
  %t177 = getelementptr %"compiler/generic:Program", ptr %t175, i32 0, i32 2
  %t178 = load i32, ptr %l1, !tbaa !23
  %t181 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t177, i32 %t178)
  store i32 %t181, ptr %l99
  br label %bb45
bb44:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb47
bb45:
  %t182 = load ptr, ptr %l94, !tbaa !29
  %t183 = load i32, ptr %l99, !tbaa !23
  %t184 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t182, i32 %t183)
  store i32 %t184, ptr %l100
  br label %bb46
bb46:
  %t185 = load i32, ptr %l100
  %t187 = trunc i64 0 to i32
  %t188 = icmp eq i32 %t185, %t187
  store i1 %t188, ptr %l91, !tbaa !21
  br label %bb47
bb47:
  %t190 = load i1, ptr %l91, !tbaa !21
  br i1 %t190, label %bb48, label %bb49
bb48:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/check:Checker", ptr %t191, i32 0, i32 1
  %t194 = load ptr, ptr %t193, !tbaa !29
  %t196 = getelementptr %"compiler/generic:Program", ptr %t194, i32 0, i32 2
  store ptr %t196, ptr %l105, !tbaa !29
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/check:Checker", ptr %t197, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !29
  %t202 = getelementptr %"compiler/generic:Program", ptr %t200, i32 0, i32 2
  %t203 = load i32, ptr %l1, !tbaa !23
  %t206 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t202, i32 %t203)
  store i32 %t206, ptr %l110
  br label %bb50
bb49:
  br label %bb62
bb50:
  %t207 = load ptr, ptr %l105, !tbaa !29
  %t208 = load i32, ptr %l110, !tbaa !23
  %t209 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t207, i32 %t208)
  store { i64, ptr } %t209, ptr %l111
  br label %bb51
bb51:
  %t210 = load { i64, ptr }, ptr %l111, !tbaa !27
  store { i64, ptr } %t210, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t211 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t211, 0
  store i64 %t213, ptr %l10, !tbaa !24
  br label %bb52
bb52:
  store %olang.scope zeroinitializer, ptr %s11
  %t215 = load i64, ptr %l9, !tbaa !24
  %t216 = load i64, ptr %l10, !tbaa !24
  %t219 = icmp slt i64 %t215, %t216
  %t221 = xor i1 %t219, true
  br i1 %t221, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s11)
  br label %bb61
bb54:
  br label %bb55
bb55:
  %t223 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t223, ptr %l118, !tbaa !27
  %t224 = load i64, ptr %l9, !tbaa !24
  %t226 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !27
  %t228 = getelementptr i32, ptr %t227, i64 %t224
  %t229 = load i32, ptr %t228, !tbaa !33
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = load i64, ptr %l2, !tbaa !24
  %t235 = add i64 %t233, 1
  %t239 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eowningIn(ptr %v0, ptr %t231, i32 %t229, i64 %t235)
  store i1 %t239, ptr %l125
  br label %bb56
bb56:
  %t240 = load i1, ptr %l125, !tbaa !21
  br i1 %t240, label %bb57, label %bb58
bb57:
  call void @__olang_scope_close(ptr %s11)
  store i1 true, ptr %rv
  br label %ret
bb58:
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s11)
  br label %bb60
bb60:
  %t242 = load i64, ptr %l9, !tbaa !24
  %t244 = add i64 %t242, 1
  store i64 %t244, ptr %l9, !tbaa !24
  br label %bb52
bb61:
  br label %bb62
bb62:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i64
  %l16 = alloca i32
  %l17 = alloca ptr
  %l23 = alloca ptr
  %l27 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca i64
  %l44 = alloca { i64, [3 x i64] }
  %l49 = alloca i1
  %l55 = alloca i1
  %l66 = alloca { i64, ptr }
  %l70 = alloca { i64, [3 x i64] }
  %l72 = alloca ptr
  %l73 = alloca i1
  %l79 = alloca i64
  %l82 = alloca i64
  %l89 = alloca ptr
  %l97 = alloca ptr
  %l100 = alloca i32
  %l101 = alloca i32
  %l105 = alloca ptr
  %l108 = alloca i1
  %l115 = alloca ptr
  %l116 = alloca i1
  %l125 = alloca i1
  %l131 = alloca ptr
  %l135 = alloca i64
  %l137 = alloca { i64, ptr }
  %l141 = alloca { i64, [3 x i64] }
  %l148 = alloca ptr
  %l151 = alloca i32
  %l152 = alloca i32
  %l156 = alloca ptr
  %l158 = alloca ptr
  %l162 = alloca i1
  %l167 = alloca i1
  %l173 = alloca ptr
  %l177 = alloca i64
  %l179 = alloca { i64, ptr }
  %l183 = alloca { i64, [3 x i64] }
  %rv = alloca { i64, [3 x i64] }
  %t119 = alloca { i64, [3 x i64] }, align 8
  %t150 = alloca { i64, [3 x i64] }, align 8
  %t213 = alloca { i64, [3 x i64] }, align 8
  %t381 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sge i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t8, i64 %t9)
  store ptr %t12, ptr %l23
  br label %bb3
bb2:
  br label %bb25
bb3:
  %t13 = load ptr, ptr %l23, !tbaa !29
  store ptr %t13, ptr %l4, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t17, i64 %t18)
  store i64 %t21, ptr %l27
  br label %bb4
bb4:
  %t22 = load i64, ptr %l27, !tbaa !24
  store i64 %t22, ptr %l5, !tbaa !24
  %t23 = load i64, ptr %l3, !tbaa !24
  store i64 %t23, ptr %l6, !tbaa !24
  %t25 = load ptr, ptr %l4, !tbaa !29
  %t27 = getelementptr %"compiler/ast:Func", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = icmp eq ptr %t28, null
  %t32 = xor i1 %t30, true
  br i1 %t32, label %bb5, label %bb6
bb5:
  %t34 = load i64, ptr %l3, !tbaa !24
  %t36 = icmp eq i64 %t34, 0
  br i1 %t36, label %bb7, label %bb8
bb6:
  br label %bb14
bb7:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l35, !tbaa !29
  %t39 = load i64, ptr %l5, !tbaa !24
  store i64 %t39, ptr %l36, !tbaa !24
  %t40 = load ptr, ptr %l4, !tbaa !29
  %t42 = getelementptr %"compiler/ast:Func", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = icmp eq ptr %t43, null
  br i1 %t45, label %bb9, label %bb10
bb8:
  br label %bb13
bb9:
  call void @__olang_check_failed(ptr @olang_loc_e5a247dfc16ec462_1cb55c2f24e67da6)
  unreachable
bb10:
  br label %bb11
bb11:
  %t47 = load ptr, ptr %l4, !tbaa !29
  %t49 = getelementptr %"compiler/ast:Func", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t53 = getelementptr %"compiler/ast:Param", ptr %t50, i32 0, i32 2
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t55 = load ptr, ptr %l35, !tbaa !29
  %t56 = load i64, ptr %l36, !tbaa !24
  %t58 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkAt(ptr %v0, ptr %v0, ptr %t55, i64 %t56, ptr %t54)
  store { i64, [3 x i64] } %t58, ptr %l44
  br label %bb12
bb12:
  %t59 = load { i64, [3 x i64] }, ptr %l44
  store { i64, [3 x i64] } %t59, ptr %rv
  br label %ret
bb13:
  %t60 = load i64, ptr %l3, !tbaa !24
  %t62 = sub i64 %t60, 1
  store i64 %t62, ptr %l6, !tbaa !24
  br label %bb14
bb14:
  %t64 = load i64, ptr %l6, !tbaa !24
  %t66 = icmp sge i64 %t64, 0
  br i1 %t66, label %bb15, label %bb16
bb15:
  %t68 = load ptr, ptr %l4, !tbaa !29
  %t70 = getelementptr %"compiler/ast:Func", ptr %t68, i32 0, i32 3
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/ast:Sig", ptr %t71, i32 0, i32 0
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t74, 0
  %t78 = icmp sgt i64 %t76, 0
  store i1 %t78, ptr %l49, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb17
bb17:
  %t80 = load i1, ptr %l49, !tbaa !21
  br i1 %t80, label %bb18, label %bb19
bb18:
  %t81 = load i64, ptr %l6, !tbaa !24
  %t82 = load ptr, ptr %l4, !tbaa !29
  %t84 = getelementptr %"compiler/ast:Func", ptr %t82, i32 0, i32 3
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/ast:Sig", ptr %t85, i32 0, i32 0
  %t88 = load { i64, ptr }, ptr %t87, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t93 = icmp slt i64 %t81, %t90
  store i1 %t93, ptr %l55, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb20
bb20:
  %t95 = load i1, ptr %l55, !tbaa !21
  br i1 %t95, label %bb21, label %bb22
bb21:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load i64, ptr %l5, !tbaa !24
  %t98 = load ptr, ptr %l4, !tbaa !29
  %t100 = getelementptr %"compiler/ast:Func", ptr %t98, i32 0, i32 3
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = getelementptr %"compiler/ast:Sig", ptr %t101, i32 0, i32 0
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !27
  store { i64, ptr } %t104, ptr %l66, !tbaa !27
  %t105 = load i64, ptr %l6, !tbaa !24
  %t107 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr ptr, ptr %t108, i64 %t105
  %t110 = load ptr, ptr %t109, !tbaa !39
  %t112 = getelementptr %"compiler/ast:Param", ptr %t110, i32 0, i32 2
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t117 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkAt(ptr %v0, ptr %v0, ptr %t96, i64 %t97, ptr %t113)
  store { i64, [3 x i64] } %t117, ptr %l70
  br label %bb23
bb22:
  br label %bb24
bb23:
  %t118 = load { i64, [3 x i64] }, ptr %l70
  store { i64, [3 x i64] } %t118, ptr %rv
  br label %ret
bb24:
  store { i64, [3 x i64] } zeroinitializer, ptr %t119
  %t120 = getelementptr { i64, [3 x i64] }, ptr %t119, i32 0, i32 0
  store i64 0, ptr %t120
  %t121 = load { i64, [3 x i64] }, ptr %t119
  store { i64, [3 x i64] } %t121, ptr %rv
  br label %ret
bb25:
  %t123 = load ptr, ptr %l1, !tbaa !29
  store ptr %t123, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t124 = load ptr, ptr %l72, !tbaa !29
  %t125 = icmp ne ptr %t124, null
  br i1 %t125, label %bb26, label %bb27
bb26:
  %t127 = load ptr, ptr %l72, !tbaa !29
  %t128 = load i64, ptr %t127
  %t130 = icmp eq i64 %t128, 0
  store i1 %t130, ptr %l73, !tbaa !21
  br label %bb27
bb27:
  %t131 = load i1, ptr %l73, !tbaa !21
  br i1 %t131, label %bb28, label %bb29
bb28:
  %t132 = load ptr, ptr %l1, !tbaa !29
  %t134 = getelementptr { i64, [3 x i64] }, ptr %t132, i32 0, i32 1
  %t135 = getelementptr { i32 }, ptr %t134, i32 0, i32 0
  %t136 = load i32, ptr %t135
  store i32 %t136, ptr %l7, !tbaa !23
  br label %bb30
bb29:
  br label %bb84
bb30:
  %t138 = load i32, ptr %l7, !tbaa !23
  %t140 = sext i32 %t138 to i64
  store i64 %t140, ptr %l79, !tbaa !24
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/check:Checker", ptr %t141, i32 0, i32 11
  %t145 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %t143)
  store i64 %t145, ptr %l82
  br label %bb31
bb31:
  %t146 = load i64, ptr %l79, !tbaa !24
  %t147 = load i64, ptr %l82, !tbaa !24
  %t148 = icmp sge i64 %t146, %t147
  br i1 %t148, label %bb32, label %bb33
bb32:
  store { i64, [3 x i64] } zeroinitializer, ptr %t150
  %t151 = getelementptr { i64, [3 x i64] }, ptr %t150, i32 0, i32 0
  store i64 0, ptr %t151
  %t152 = load { i64, [3 x i64] }, ptr %t150
  store { i64, [3 x i64] } %t152, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/check:Checker", ptr %t154, i32 0, i32 11
  %t157 = load i32, ptr %l7, !tbaa !23
  %t159 = sext i32 %t157 to i64
  %t162 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t156, i64 %t159)
  store ptr %t162, ptr %l89
  br label %bb35
bb35:
  %t163 = load ptr, ptr %l89, !tbaa !29
  %t165 = getelementptr %"compiler/typed:Body", ptr %t163, i32 0, i32 1
  %t166 = load { i64, [2 x i64] }, ptr %t165
  store { i64, [2 x i64] } %t166, ptr %l8
  %t168 = load { i64, [2 x i64] }, ptr %l8
  %t170 = extractvalue { i64, [2 x i64] } %t168, 0
  %t171 = icmp eq i64 %t170, 1
  br i1 %t171, label %bb36, label %bb37
bb36:
  %t173 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t174 = getelementptr { i32, i32 }, ptr %t173, i32 0, i32 0
  %t175 = load i32, ptr %t174
  store i32 %t175, ptr %l9, !tbaa !23
  br label %bb38
bb37:
  br label %bb63
bb38:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/check:Checker", ptr %t177, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !29
  %t182 = getelementptr %"compiler/generic:Program", ptr %t180, i32 0, i32 2
  store ptr %t182, ptr %l97, !tbaa !29
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load i32, ptr %l9, !tbaa !23
  %t187 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t183, i32 %t184)
  store i32 %t187, ptr %l100
  br label %bb39
bb39:
  %t188 = load ptr, ptr %l97, !tbaa !29
  %t189 = load i32, ptr %l100, !tbaa !23
  %t190 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t188, i32 %t189)
  store i32 %t190, ptr %l101
  br label %bb40
bb40:
  %t191 = load i32, ptr %l101, !tbaa !23
  store i32 %t191, ptr %l10, !tbaa !23
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/check:Checker", ptr %t192, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !29
  %t196 = load i32, ptr %l10, !tbaa !23
  %t199 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t195, i32 %t196)
  store ptr %t199, ptr %l105
  br label %bb41
bb41:
  %t200 = load ptr, ptr %l105, !tbaa !29
  store ptr %t200, ptr %l11, !tbaa !29
  %t201 = load ptr, ptr %l11, !tbaa !29
  %t203 = icmp eq ptr %t201, null
  br i1 %t203, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l108, !tbaa !21
  br label %bb44
bb43:
  %t205 = load ptr, ptr %l11, !tbaa !29
  %t207 = getelementptr %"compiler/ast:TypeDecl", ptr %t205, i32 0, i32 3
  %t208 = load ptr, ptr %t207, !tbaa !29
  %t210 = icmp eq ptr %t208, null
  store i1 %t210, ptr %l108, !tbaa !21
  br label %bb44
bb44:
  %t212 = load i1, ptr %l108, !tbaa !21
  br i1 %t212, label %bb45, label %bb46
bb45:
  store { i64, [3 x i64] } zeroinitializer, ptr %t213
  %t214 = getelementptr { i64, [3 x i64] }, ptr %t213, i32 0, i32 0
  store i64 0, ptr %t214
  %t215 = load { i64, [3 x i64] }, ptr %t213
  store { i64, [3 x i64] } %t215, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t217 = load ptr, ptr %l11, !tbaa !29
  %t219 = getelementptr %"compiler/ast:TypeDecl", ptr %t217, i32 0, i32 3
  %t220 = load ptr, ptr %t219, !tbaa !29
  store ptr %t220, ptr %l12, !tbaa !29
  %t222 = load ptr, ptr %l12, !tbaa !29
  store ptr %t222, ptr %l115, !tbaa !29
  store i1 false, ptr %l116, !tbaa !21
  %t223 = load ptr, ptr %l115, !tbaa !29
  %t224 = icmp ne ptr %t223, null
  br i1 %t224, label %bb48, label %bb49
bb48:
  %t226 = load ptr, ptr %l115, !tbaa !29
  %t227 = load i64, ptr %t226
  %t229 = icmp eq i64 %t227, 0
  store i1 %t229, ptr %l116, !tbaa !21
  br label %bb49
bb49:
  %t230 = load i1, ptr %l116, !tbaa !21
  br i1 %t230, label %bb50, label %bb51
bb50:
  %t231 = load ptr, ptr %l12, !tbaa !29
  %t233 = getelementptr { i64, [6 x i64] }, ptr %t231, i32 0, i32 1
  %t234 = getelementptr { ptr }, ptr %t233, i32 0, i32 0
  %t235 = load ptr, ptr %t234
  store ptr %t235, ptr %l13, !tbaa !29
  br label %bb52
bb51:
  br label %bb61
bb52:
  %t237 = load ptr, ptr %l13, !tbaa !29
  %t239 = getelementptr %"compiler/ast:StructBody", ptr %t237, i32 0, i32 0
  %t240 = load { i64, ptr }, ptr %t239, !tbaa !27
  %t242 = extractvalue { i64, ptr } %t240, 0
  %t244 = icmp sgt i64 %t242, 0
  br i1 %t244, label %bb53, label %bb54
bb53:
  %t246 = load i64, ptr %l3, !tbaa !24
  %t247 = load ptr, ptr %l13, !tbaa !29
  %t249 = getelementptr %"compiler/ast:StructBody", ptr %t247, i32 0, i32 0
  %t250 = load { i64, ptr }, ptr %t249, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t250, 0
  %t255 = icmp slt i64 %t246, %t252
  store i1 %t255, ptr %l125, !tbaa !21
  br label %bb55
bb54:
  store i1 false, ptr %l125, !tbaa !21
  br label %bb55
bb55:
  %t257 = load i1, ptr %l125, !tbaa !21
  br i1 %t257, label %bb56, label %bb57
bb56:
  %t258 = load ptr, ptr %l0, !tbaa !29
  store ptr %t258, ptr %l131, !tbaa !29
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t261 = getelementptr %"compiler/check:Checker", ptr %t259, i32 0, i32 1
  %t262 = load ptr, ptr %t261, !tbaa !29
  %t263 = load i32, ptr %l10, !tbaa !23
  %t266 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t262, i32 %t263)
  store i64 %t266, ptr %l135
  br label %bb58
bb57:
  br label %bb60
bb58:
  %t267 = load ptr, ptr %l13, !tbaa !29
  %t269 = getelementptr %"compiler/ast:StructBody", ptr %t267, i32 0, i32 0
  %t270 = load { i64, ptr }, ptr %t269, !tbaa !27
  store { i64, ptr } %t270, ptr %l137, !tbaa !27
  %t271 = load i64, ptr %l3, !tbaa !24
  %t273 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t274 = load ptr, ptr %t273, !tbaa !27
  %t275 = getelementptr ptr, ptr %t274, i64 %t271
  %t276 = load ptr, ptr %t275, !tbaa !39
  %t278 = getelementptr %"compiler/ast:Param", ptr %t276, i32 0, i32 2
  %t279 = load ptr, ptr %t278, !tbaa !29
  %t280 = load ptr, ptr %l131, !tbaa !29
  %t281 = load i64, ptr %l135, !tbaa !24
  %t283 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkAt(ptr %v0, ptr %v0, ptr %t280, i64 %t281, ptr %t279)
  store { i64, [3 x i64] } %t283, ptr %l141
  br label %bb59
bb59:
  %t284 = load { i64, [3 x i64] }, ptr %l141
  store { i64, [3 x i64] } %t284, ptr %rv
  br label %ret
bb60:
  br label %bb62
bb61:
  br label %bb62
bb62:
  br label %bb83
bb63:
  %t285 = load { i64, [2 x i64] }, ptr %l8
  %t287 = extractvalue { i64, [2 x i64] } %t285, 0
  %t288 = icmp eq i64 %t287, 2
  br i1 %t288, label %bb64, label %bb65
bb64:
  %t290 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t291 = getelementptr { i32, i64 }, ptr %t290, i32 0, i32 0
  %t292 = load i32, ptr %t291
  store i32 %t292, ptr %l14, !tbaa !23
  %t294 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t295 = getelementptr { i32, i64 }, ptr %t294, i32 0, i32 1
  %t296 = load i64, ptr %t295
  store i64 %t296, ptr %l15, !tbaa !24
  br label %bb66
bb65:
  br label %bb82
bb66:
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t300 = getelementptr %"compiler/check:Checker", ptr %t298, i32 0, i32 1
  %t301 = load ptr, ptr %t300, !tbaa !29
  %t303 = getelementptr %"compiler/generic:Program", ptr %t301, i32 0, i32 2
  store ptr %t303, ptr %l148, !tbaa !29
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t305 = load i32, ptr %l14, !tbaa !23
  %t308 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t304, i32 %t305)
  store i32 %t308, ptr %l151
  br label %bb67
bb67:
  %t309 = load ptr, ptr %l148, !tbaa !29
  %t310 = load i32, ptr %l151, !tbaa !23
  %t311 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t309, i32 %t310)
  store i32 %t311, ptr %l152
  br label %bb68
bb68:
  %t312 = load i32, ptr %l152, !tbaa !23
  store i32 %t312, ptr %l16, !tbaa !23
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t315 = getelementptr %"compiler/check:Checker", ptr %t313, i32 0, i32 1
  %t316 = load ptr, ptr %t315, !tbaa !29
  %t317 = load i32, ptr %l16, !tbaa !23
  %t320 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t316, i32 %t317)
  store ptr %t320, ptr %l156
  br label %bb69
bb69:
  %t321 = load i64, ptr %l15, !tbaa !24
  %t322 = load ptr, ptr %l156, !tbaa !29
  %t324 = call ptr @compiler_2fcheck_2ecaseDecl(ptr %v0, ptr %t322, i64 %t321)
  store ptr %t324, ptr %l158
  br label %bb70
bb70:
  %t325 = load ptr, ptr %l158, !tbaa !29
  store ptr %t325, ptr %l17, !tbaa !29
  %t326 = load ptr, ptr %l17, !tbaa !29
  %t328 = icmp eq ptr %t326, null
  %t330 = xor i1 %t328, true
  br i1 %t330, label %bb71, label %bb72
bb71:
  %t332 = load ptr, ptr %l17, !tbaa !29
  %t334 = getelementptr %"compiler/ast:CaseDecl", ptr %t332, i32 0, i32 2
  %t335 = load { i64, ptr }, ptr %t334, !tbaa !27
  %t337 = extractvalue { i64, ptr } %t335, 0
  %t339 = icmp sgt i64 %t337, 0
  store i1 %t339, ptr %l162, !tbaa !21
  br label %bb73
bb72:
  store i1 false, ptr %l162, !tbaa !21
  br label %bb73
bb73:
  %t341 = load i1, ptr %l162, !tbaa !21
  br i1 %t341, label %bb74, label %bb75
bb74:
  %t342 = load i64, ptr %l3, !tbaa !24
  %t343 = load ptr, ptr %l17, !tbaa !29
  %t345 = getelementptr %"compiler/ast:CaseDecl", ptr %t343, i32 0, i32 2
  %t346 = load { i64, ptr }, ptr %t345, !tbaa !27
  %t348 = extractvalue { i64, ptr } %t346, 0
  %t351 = icmp slt i64 %t342, %t348
  store i1 %t351, ptr %l167, !tbaa !21
  br label %bb76
bb75:
  store i1 false, ptr %l167, !tbaa !21
  br label %bb76
bb76:
  %t353 = load i1, ptr %l167, !tbaa !21
  br i1 %t353, label %bb77, label %bb78
bb77:
  %t354 = load ptr, ptr %l0, !tbaa !29
  store ptr %t354, ptr %l173, !tbaa !29
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t357 = getelementptr %"compiler/check:Checker", ptr %t355, i32 0, i32 1
  %t358 = load ptr, ptr %t357, !tbaa !29
  %t359 = load i32, ptr %l16, !tbaa !23
  %t362 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t358, i32 %t359)
  store i64 %t362, ptr %l177
  br label %bb79
bb78:
  br label %bb81
bb79:
  %t363 = load ptr, ptr %l17, !tbaa !29
  %t365 = getelementptr %"compiler/ast:CaseDecl", ptr %t363, i32 0, i32 2
  %t366 = load { i64, ptr }, ptr %t365, !tbaa !27
  store { i64, ptr } %t366, ptr %l179, !tbaa !27
  %t367 = load i64, ptr %l3, !tbaa !24
  %t369 = getelementptr { i64, ptr }, ptr %l179, i32 0, i32 1
  %t370 = load ptr, ptr %t369, !tbaa !27
  %t371 = getelementptr ptr, ptr %t370, i64 %t367
  %t372 = load ptr, ptr %t371, !tbaa !39
  %t374 = getelementptr %"compiler/ast:Param", ptr %t372, i32 0, i32 2
  %t375 = load ptr, ptr %t374, !tbaa !29
  %t376 = load ptr, ptr %l173, !tbaa !29
  %t377 = load i64, ptr %l177, !tbaa !24
  %t379 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkAt(ptr %v0, ptr %v0, ptr %t376, i64 %t377, ptr %t375)
  store { i64, [3 x i64] } %t379, ptr %l183
  br label %bb80
bb80:
  %t380 = load { i64, [3 x i64] }, ptr %l183
  store { i64, [3 x i64] } %t380, ptr %rv
  br label %ret
bb81:
  br label %bb83
bb82:
  br label %bb83
bb83:
  br label %bb85
bb84:
  br label %bb85
bb85:
  store { i64, [3 x i64] } zeroinitializer, ptr %t381
  %t382 = getelementptr { i64, [3 x i64] }, ptr %t381, i32 0, i32 0
  store i64 0, ptr %t382
  %t383 = load { i64, [3 x i64] }, ptr %t381
  store { i64, [3 x i64] } %t383, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [3 x i64] }, ptr %rv
  ret { i64, [3 x i64] } %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatBool(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l29 = alloca { i64, ptr }
  %l30 = alloca i1
  %l31 = alloca i64
  %s3 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 4
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb9
bb4:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t17 = load ptr, ptr %l11, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l11, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", ptr }, ptr %t27, i32 0, i32 1
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l2, !tbaa !29
  br label %bb9
bb8:
  br label %bb25
bb9:
  %t31 = load ptr, ptr %l2, !tbaa !29
  store ptr %t31, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t32 = load ptr, ptr %l17, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb10, label %bb11
bb10:
  %t35 = load ptr, ptr %l17, !tbaa !29
  %t36 = load i64, ptr %t35
  %t38 = icmp eq i64 %t36, 1
  store i1 %t38, ptr %l18, !tbaa !21
  br label %bb11
bb11:
  %t39 = load i1, ptr %l18, !tbaa !21
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t40 = load ptr, ptr %l2, !tbaa !29
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32 }, ptr %t42, i32 0, i32 0
  %t44 = load %"compiler/source:Span", ptr %t43
  store %"compiler/source:Span" %t44, ptr %l3
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t48 = getelementptr { i64, [5 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i32 }, ptr %t48, i32 0, i32 1
  %t50 = load i32, ptr %t49
  store i32 %t50, ptr %l4
  br label %bb14
bb13:
  br label %bb23
bb14:
  %t52 = load i32, ptr %l4
  %t54 = trunc i64 6 to i32
  %t55 = icmp eq i32 %t52, %t54
  br i1 %t55, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t58 = load %"compiler/source:Span", ptr %l3
  %t61 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %a0, %"compiler/source:Span" %t58)
  store { i64, ptr } %t61, ptr %l29
  br label %bb17
bb16:
  br label %bb22
bb17:
  %t62 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t63 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t62, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i1 %t63, ptr %l30
  br label %bb18
bb18:
  %t64 = load i1, ptr %l30, !tbaa !21
  br i1 %t64, label %bb19, label %bb20
bb19:
  store i64 1, ptr %l31, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  %t65 = load i64, ptr %l31, !tbaa !24
  store i64 %t65, ptr %rv
  br label %ret
bb22:
  br label %bb24
bb23:
  br label %bb24
bb24:
  br label %bb26
bb25:
  br label %bb26
bb26:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsConst(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l36 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i1
  %l48 = alloca i64
  %l50 = alloca ptr
  %l51 = alloca i1
  %l61 = alloca i1
  %l62 = alloca i1
  %l66 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca i1
  %l81 = alloca { i64, ptr }
  %l87 = alloca i1
  %s7 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t7 = load ptr, ptr %l15, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l15, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 2
  store i1 %t13, ptr %l16, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l16, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", ptr }, ptr %t17, i32 0, i32 1
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb16
bb7:
  %t21 = load ptr, ptr %l1, !tbaa !29
  store ptr %t21, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t22 = load ptr, ptr %l21, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l21, !tbaa !29
  %t26 = load i64, ptr %t25
  %t28 = icmp eq i64 %t26, 3
  store i1 %t28, ptr %l22, !tbaa !21
  br label %bb9
bb9:
  %t29 = load i1, ptr %l22, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = getelementptr { i64, [5 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t32, i32 0, i32 2
  %t34 = load ptr, ptr %t33
  store ptr %t34, ptr %l2, !tbaa !29
  br label %bb16
bb11:
  %t36 = load ptr, ptr %l1, !tbaa !29
  store ptr %t36, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t37 = load ptr, ptr %l27, !tbaa !29
  %t38 = icmp ne ptr %t37, null
  br i1 %t38, label %bb12, label %bb13
bb12:
  %t40 = load ptr, ptr %l27, !tbaa !29
  %t41 = load i64, ptr %t40
  %t43 = icmp eq i64 %t41, 15
  store i1 %t43, ptr %l28, !tbaa !21
  br label %bb13
bb13:
  %t44 = load i1, ptr %l28, !tbaa !21
  br i1 %t44, label %bb14, label %bb15
bb14:
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr { i64, [5 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t47, i32 0, i32 1
  %t49 = load ptr, ptr %t48
  store ptr %t49, ptr %l2, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t56 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsConst(ptr %v0, ptr %v1, ptr %t51, ptr %t52)
  store i1 %t56, ptr %l36
  br label %bb17
bb17:
  %t57 = load i1, ptr %l36, !tbaa !21
  store i1 %t57, ptr %rv
  br label %ret
bb18:
  %t58 = load ptr, ptr %l1, !tbaa !29
  store ptr %t58, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t59 = load ptr, ptr %l37, !tbaa !29
  %t60 = icmp ne ptr %t59, null
  br i1 %t60, label %bb19, label %bb20
bb19:
  %t62 = load ptr, ptr %l37, !tbaa !29
  %t63 = load i64, ptr %t62
  %t65 = icmp eq i64 %t63, 12
  store i1 %t65, ptr %l38, !tbaa !21
  br label %bb20
bb20:
  %t66 = load i1, ptr %l38, !tbaa !21
  br i1 %t66, label %bb21, label %bb22
bb21:
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t69 = getelementptr { i64, [5 x i64] }, ptr %t67, i32 0, i32 1
  %t70 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t69, i32 0, i32 1
  %t71 = load ptr, ptr %t70
  store ptr %t71, ptr %l3, !tbaa !29
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [5 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t75, i32 0, i32 2
  %t77 = load { i64, ptr }, ptr %t76
  store { i64, ptr } %t77, ptr %l4, !tbaa !27
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load ptr, ptr %l3, !tbaa !29
  %t81 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t85 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamLen(ptr %v0, ptr %v1, ptr %v1, ptr %t79, ptr %t80, { i64, ptr } %t81)
  store i64 %t85, ptr %l48
  br label %bb24
bb24:
  %t86 = load i64, ptr %l48, !tbaa !24
  %t87 = icmp sge i64 %t86, 0
  store i1 %t87, ptr %rv
  br label %ret
bb25:
  %t89 = load ptr, ptr %l1, !tbaa !29
  store ptr %t89, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t90 = load ptr, ptr %l50, !tbaa !29
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %bb26, label %bb27
bb26:
  %t93 = load ptr, ptr %l50, !tbaa !29
  %t94 = load i64, ptr %t93
  %t96 = icmp eq i64 %t94, 5
  store i1 %t96, ptr %l51, !tbaa !21
  br label %bb27
bb27:
  %t97 = load i1, ptr %l51, !tbaa !21
  br i1 %t97, label %bb28, label %bb29
bb28:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr { i64, [5 x i64] }, ptr %t98, i32 0, i32 1
  %t101 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t100, i32 0, i32 2
  %t102 = load ptr, ptr %t101
  store ptr %t102, ptr %l5, !tbaa !29
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr { i64, [5 x i64] }, ptr %t104, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t106, i32 0, i32 3
  %t108 = load ptr, ptr %t107
  store ptr %t108, ptr %l6, !tbaa !29
  br label %bb30
bb29:
  br label %bb36
bb30:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load ptr, ptr %l5, !tbaa !29
  %t115 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsConst(ptr %v0, ptr %v1, ptr %t110, ptr %t111)
  store i1 %t115, ptr %l61
  br label %bb31
bb31:
  %t116 = load i1, ptr %l61, !tbaa !21
  br i1 %t116, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb35
bb33:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load ptr, ptr %l6, !tbaa !29
  %t122 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsConst(ptr %v0, ptr %v1, ptr %t117, ptr %t118)
  store i1 %t122, ptr %l66
  br label %bb34
bb34:
  %t123 = load i1, ptr %l66, !tbaa !21
  store i1 %t123, ptr %l62, !tbaa !21
  br label %bb35
bb35:
  %t124 = load i1, ptr %l62, !tbaa !21
  store i1 %t124, ptr %rv
  br label %ret
bb36:
  %t125 = load ptr, ptr %l1, !tbaa !29
  store ptr %t125, ptr %l67, !tbaa !29
  store i1 false, ptr %l68, !tbaa !21
  %t126 = load ptr, ptr %l67, !tbaa !29
  %t127 = icmp ne ptr %t126, null
  br i1 %t127, label %bb37, label %bb38
bb37:
  %t129 = load ptr, ptr %l67, !tbaa !29
  %t130 = load i64, ptr %t129
  %t132 = icmp eq i64 %t130, 7
  store i1 %t132, ptr %l68, !tbaa !21
  br label %bb38
bb38:
  %t133 = load i1, ptr %l68, !tbaa !21
  br i1 %t133, label %bb39, label %bb40
bb39:
  %t134 = load ptr, ptr %l1, !tbaa !29
  %t136 = getelementptr { i64, [5 x i64] }, ptr %t134, i32 0, i32 1
  %t137 = getelementptr { %"compiler/source:Span", ptr }, ptr %t136, i32 0, i32 1
  %t138 = load ptr, ptr %t137
  store ptr %t138, ptr %l7, !tbaa !29
  br label %bb41
bb40:
  br label %bb52
bb41:
  %t140 = load ptr, ptr %l7, !tbaa !29
  %t142 = getelementptr %"compiler/ast:Chain", ptr %t140, i32 0, i32 1
  %t143 = load { i64, ptr }, ptr %t142, !tbaa !27
  store { i64, ptr } %t143, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t145 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t145, 0
  store i64 %t147, ptr %l10, !tbaa !24
  br label %bb42
bb42:
  store %olang.scope zeroinitializer, ptr %s7
  %t149 = load i64, ptr %l9, !tbaa !24
  %t150 = load i64, ptr %l10, !tbaa !24
  %t153 = icmp slt i64 %t149, %t150
  %t155 = xor i1 %t153, true
  br i1 %t155, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s7)
  br label %bb51
bb44:
  br label %bb45
bb45:
  %t157 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t157, ptr %l81, !tbaa !27
  %t158 = load i64, ptr %l9, !tbaa !24
  %t160 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !27
  %t162 = getelementptr ptr, ptr %t161, i64 %t158
  %t163 = load ptr, ptr %t162, !tbaa !39
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t170 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsConst(ptr %v0, ptr %v1, ptr %t165, ptr %t163)
  store i1 %t170, ptr %l87
  br label %bb46
bb46:
  %t171 = load i1, ptr %l87, !tbaa !21
  br i1 %t171, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s7)
  store i1 true, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s7)
  br label %bb50
bb50:
  %t173 = load i64, ptr %l9, !tbaa !24
  %t175 = add i64 %t173, 1
  store i64 %t175, ptr %l9, !tbaa !24
  br label %bb42
bb51:
  store i1 false, ptr %rv
  br label %ret
bb52:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroBorrowedFrom(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i1
  %l21 = alloca i1
  %l27 = alloca ptr
  %l34 = alloca i64
  %l44 = alloca i64
  %l47 = alloca i64
  %l70 = alloca i64
  %l74 = alloca i1
  %l78 = alloca i1
  %l82 = alloca i1
  %s4 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Call", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t8 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyOfCallee(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store i64 %t8, ptr %l15
  br label %bb1
bb1:
  %t9 = load i64, ptr %l15, !tbaa !24
  store i64 %t9, ptr %l2, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp slt i64 %t10, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb5
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i64, ptr %l2, !tbaa !24
  %t18 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %t14, i64 %t15)
  store i1 %t18, ptr %l21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l21, !tbaa !21
  %t20 = xor i1 %t19, true
  store i1 %t20, ptr %l18, !tbaa !21
  br label %bb5
bb5:
  %t22 = load i1, ptr %l18, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  store i64 -1, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 11
  %t27 = load i64, ptr %l2, !tbaa !24
  %t30 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t26, i64 %t27)
  store ptr %t30, ptr %l27
  br label %bb9
bb9:
  %t31 = load ptr, ptr %l27, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Body", ptr %t31, i32 0, i32 2
  %t34 = load i32, ptr %t33, !tbaa !23
  store i32 %t34, ptr %l3, !tbaa !23
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = getelementptr %"compiler/generic:Program", ptr %t39, i32 0, i32 2
  %t42 = load i32, ptr %l3, !tbaa !23
  %t45 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t41, i32 %t42, i64 0)
  store i64 %t45, ptr %l34
  br label %bb10
bb10:
  %t46 = load i64, ptr %l34, !tbaa !24
  store i64 %t46, ptr %l4, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t49 = icmp slt i64 %t47, 0
  br i1 %t49, label %bb11, label %bb12
bb11:
  store i64 -1, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  store i64 0, ptr %l5, !tbaa !24
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr %"compiler/typed:Call", ptr %t52, i32 0, i32 1
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 0
  store i64 %t57, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t59 = load i64, ptr %l6, !tbaa !24
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = icmp sgt i64 %t59, %t60
  br i1 %t63, label %bb14, label %bb15
bb14:
  %t65 = load i64, ptr %l7, !tbaa !24
  %t67 = icmp sgt i64 %t65, 0
  br i1 %t67, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb19
bb16:
  %t69 = load i64, ptr %l6, !tbaa !24
  %t70 = load i64, ptr %l5, !tbaa !24
  %t73 = sub i64 %t69, %t70
  %t74 = load i64, ptr %l7, !tbaa !24
  %t77 = add i64 %t73, %t74
  %t79 = sub i64 %t77, 1
  %t80 = load i64, ptr %l7, !tbaa !24
  %t83 = sdiv i64 %t79, %t80
  store i64 %t83, ptr %l47, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb18
bb18:
  %t85 = load i64, ptr %l47, !tbaa !24
  store i64 %t85, ptr %l44, !tbaa !24
  br label %bb19
bb19:
  %t86 = load i64, ptr %l44, !tbaa !24
  store i64 %t86, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s4
  %t87 = load i64, ptr %l9, !tbaa !24
  %t88 = load i64, ptr %l8, !tbaa !24
  %t91 = icmp slt i64 %t87, %t88
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s4)
  br label %bb36
bb22:
  br label %bb23
bb23:
  %t95 = load i64, ptr %l5, !tbaa !24
  %t96 = load i64, ptr %l9, !tbaa !24
  %t97 = load i64, ptr %l7, !tbaa !24
  %t100 = mul i64 %t96, %t97
  %t103 = add i64 %t95, %t100
  store i64 %t103, ptr %l10, !tbaa !24
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/check:Checker", ptr %t105, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = getelementptr %"compiler/generic:Program", ptr %t108, i32 0, i32 2
  %t111 = load i32, ptr %l3, !tbaa !23
  %t112 = load i64, ptr %l10, !tbaa !24
  %t116 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t110, i32 %t111, i64 %t112)
  store i64 %t116, ptr %l70
  br label %bb24
bb24:
  %t117 = load i64, ptr %l70, !tbaa !24
  store i64 %t117, ptr %l11, !tbaa !24
  %t118 = load i64, ptr %l10, !tbaa !24
  %t119 = load i64, ptr %l4, !tbaa !24
  %t122 = icmp eq i64 %t118, %t119
  br i1 %t122, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb27
bb26:
  %t124 = load i64, ptr %l11, !tbaa !24
  %t125 = load i64, ptr %l4, !tbaa !24
  %t128 = icmp eq i64 %t124, %t125
  store i1 %t128, ptr %l74, !tbaa !21
  br label %bb27
bb27:
  %t130 = load i1, ptr %l74, !tbaa !21
  br i1 %t130, label %bb28, label %bb29
bb28:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i64, ptr %l2, !tbaa !24
  %t133 = load i64, ptr %l10, !tbaa !24
  %t137 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %t131, i64 %t132, i64 %t133)
  store i1 %t137, ptr %l82
  br label %bb30
bb29:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb31
bb30:
  %t138 = load i1, ptr %l82, !tbaa !21
  store i1 %t138, ptr %l78, !tbaa !21
  br label %bb31
bb31:
  %t139 = load i1, ptr %l78, !tbaa !21
  br i1 %t139, label %bb32, label %bb33
bb32:
  %t140 = load i64, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  store i64 %t140, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s4)
  br label %bb35
bb35:
  %t142 = load i64, ptr %l9, !tbaa !24
  %t144 = add i64 %t142, 1
  store i64 %t144, ptr %l9, !tbaa !24
  br label %bb20
bb36:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCallRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i1
  %l14 = alloca i1
  %l17 = alloca { i64, ptr }
  %l21 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroBorrowedFrom(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l2, !tbaa !24
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Call", ptr %t12, i32 0, i32 1
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t20 = icmp slt i64 %t11, %t17
  store i1 %t20, ptr %l8, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t22 = load i1, ptr %l8, !tbaa !21
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Call", ptr %t24, i32 0, i32 1
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l17, !tbaa !27
  %t28 = load i64, ptr %l2, !tbaa !24
  %t30 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr ptr, ptr %t31, i64 %t28
  %t33 = load ptr, ptr %t32, !tbaa !39
  %t37 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %t23, ptr %t33)
  store i1 %t37, ptr %l21
  br label %bb7
bb6:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb8
bb7:
  %t38 = load i1, ptr %l21, !tbaa !21
  store i1 %t38, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t39 = load i1, ptr %l14, !tbaa !21
  store i1 %t39, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKeep(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i32
  %l9 = alloca ptr
  %l14 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l9, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 0
  %t7 = load i64, ptr %t6, !tbaa !24
  store i64 %t7, ptr %l2, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %t9, i64 %t10)
  store i1 %t13, ptr %l14
  br label %bb2
bb2:
  %t14 = load i1, ptr %l14, !tbaa !21
  %t15 = xor i1 %t14, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %ret
bb4:
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l1, !tbaa !29
  store ptr %t17, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t18 = load ptr, ptr %l16, !tbaa !29
  %t19 = icmp ne ptr %t18, null
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %l16, !tbaa !29
  %t22 = load i64, ptr %t21
  %t24 = icmp eq i64 %t22, 0
  store i1 %t24, ptr %l17, !tbaa !21
  br label %bb7
bb7:
  %t25 = load i1, ptr %l17, !tbaa !21
  br i1 %t25, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr { i64, [3 x i64] }, ptr %t26, i32 0, i32 1
  %t29 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t28, i32 0, i32 1
  %t30 = load i32, ptr %t29
  store i32 %t30, ptr %l3, !tbaa !23
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr { i64, [3 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t34, i32 0, i32 2
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l4, !tbaa !29
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load i32, ptr %l3, !tbaa !23
  %t42 = sext i32 %t40 to i64
  %t43 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKeepVal(ptr %v0, ptr %v1, ptr %t38, i64 %t39, i64 %t42, ptr %t43)
  br label %bb11
bb11:
  br label %bb27
bb12:
  %t49 = load ptr, ptr %l1, !tbaa !29
  store ptr %t49, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t50 = load ptr, ptr %l30, !tbaa !29
  %t51 = icmp ne ptr %t50, null
  br i1 %t51, label %bb13, label %bb14
bb13:
  %t53 = load ptr, ptr %l30, !tbaa !29
  %t54 = load i64, ptr %t53
  %t56 = icmp eq i64 %t54, 1
  store i1 %t56, ptr %l31, !tbaa !21
  br label %bb14
bb14:
  %t57 = load i1, ptr %l31, !tbaa !21
  br i1 %t57, label %bb15, label %bb16
bb15:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr { i64, [3 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t60, i32 0, i32 1
  %t62 = load ptr, ptr %t61
  store ptr %t62, ptr %l5, !tbaa !29
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr { i64, [3 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t66, i32 0, i32 2
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l6, !tbaa !29
  br label %bb17
bb16:
  br label %bb26
bb17:
  %t70 = load ptr, ptr %l5, !tbaa !29
  store ptr %t70, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t71 = load ptr, ptr %l38, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb18, label %bb19
bb18:
  %t74 = load ptr, ptr %l38, !tbaa !29
  %t75 = load i64, ptr %t74
  %t77 = icmp eq i64 %t75, 0
  store i1 %t77, ptr %l39, !tbaa !21
  br label %bb19
bb19:
  %t78 = load i1, ptr %l39, !tbaa !21
  br i1 %t78, label %bb20, label %bb21
bb20:
  %t79 = load ptr, ptr %l5, !tbaa !29
  %t81 = getelementptr { i64, [4 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t81, i32 0, i32 2
  %t83 = load i32, ptr %t82
  store i32 %t83, ptr %l7, !tbaa !23
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i64, ptr %l2, !tbaa !24
  %t87 = load i32, ptr %l7, !tbaa !23
  %t89 = sext i32 %t87 to i64
  %t90 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKeepVal(ptr %v0, ptr %v1, ptr %t85, i64 %t86, i64 %t89, ptr %t90)
  br label %bb23
bb23:
  br label %bb25
bb24:
  br label %bb25
bb25:
  br label %bb27
bb26:
  br label %bb27
bb27:
  br label %ret
ret:
  ret void
}

define dso_local %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l3 = alloca ptr
  %l7 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0)
  store ptr %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 0
  %t7 = load i64, ptr %t6, !tbaa !24
  %t11 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t7, i64 %a1)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t11, ptr %l7
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t12 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l7
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %rv
  ret %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroName(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i1
  %l12 = alloca i32
  %rv = alloca i32
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceName(ptr %v0, ptr %v1, ptr %a0, ptr %t17)
  store i32 %t20, ptr %l12
  br label %bb6
bb6:
  %t21 = load i32, ptr %l12, !tbaa !23
  store i32 %t21, ptr %l3, !tbaa !23
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i32 0, ptr %l3, !tbaa !23
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_b4fa9ecc50f06b0b_d6ee486f71837477)
  unreachable
bb12:
  %t22 = load i32, ptr %l3, !tbaa !23
  store i32 %t22, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroSettleResults(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"std/pair:Pair.1eb2466213689e002f25e81e83536e78"
  %l8 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l17 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i32
  %l30 = alloca { i64, ptr }
  %l36 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l42 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i32
  %l55 = alloca { i64, ptr }
  %l59 = alloca ptr
  %l62 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 66
  store ptr %t3, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %l3, !tbaa !24
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20compil_Hd792a4b485af98ba4ad9cd9a7f4f4722(ptr %v0, ptr %t5, i64 %t6)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l21
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13
ok.13:
  store { i64, ptr } %t10, ptr %l20
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t14, ptr %l17, !tbaa !27
  br label %bb7
bb3:
  %t15 = load i32, ptr %l21, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_674cd1771ebc67df_c0fbe9e0645b3c13)
  unreachable
bb6:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb37
bb7:
  %t20 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load i64, ptr %l6, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb35
bb10:
  br label %bb11
bb11:
  %t33 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t33, ptr %l30, !tbaa !27
  %t34 = load i64, ptr %l6, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr %"std/pair:Pair.1eb2466213689e002f25e81e83536e78", ptr %t37, i64 %t34
  %t39 = load %"std/pair:Pair.1eb2466213689e002f25e81e83536e78", ptr %t38
  store %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %t39, ptr %l7
  %t41 = getelementptr %"std/pair:Pair.1eb2466213689e002f25e81e83536e78", ptr %l7, i32 0, i32 0
  %t42 = load i64, ptr %t41, !tbaa !24
  %t43 = load i64, ptr %l1, !tbaa !24
  %t46 = icmp ne i64 %t42, %t43
  br i1 %t46, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb34
bb13:
  br label %bb14
bb14:
  %t48 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %s3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t48, ptr %l36
  br label %bb15
bb15:
  %t49 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l36
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t49, ptr %l8
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load i64, ptr %l1, !tbaa !24
  %t52 = getelementptr %"std/pair:Pair.1eb2466213689e002f25e81e83536e78", ptr %l7, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeep(ptr %v0, ptr %v0, ptr %s3, ptr %t50, i64 %t51, ptr %t53, ptr %l8)
  br label %bb16
bb16:
  store ptr %l8, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  %t59 = load ptr, ptr %l9, !tbaa !29
  %t60 = load i64, ptr %l10, !tbaa !24
  %t63 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s3, ptr %t59, i64 %t60)
  %t64 = extractvalue { i32, { i64, ptr } } %t63, 1
  %t65 = extractvalue { i32, { i64, ptr } } %t63, 0
  store i32 %t65, ptr %l46
  %t66 = icmp ne i32 %t65, 0
  br i1 %t66, label %bb19, label %ok.67
ok.67:
  store { i64, ptr } %t64, ptr %l45
  br label %bb18
bb18:
  %t68 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t68, ptr %l42, !tbaa !27
  br label %bb23
bb19:
  %t69 = load i32, ptr %l46, !tbaa !23
  %t70 = ashr i32 %t69, 16
  %t72 = icmp eq i32 %t70, 1
  br i1 %t72, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_4accb82e327e9b5e_83bcad9ba4931212)
  unreachable
bb22:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s6)
  br label %bb33
bb23:
  %t74 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t74, ptr %l11, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t75, 0
  store i64 %t77, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s7
  %t79 = load i64, ptr %l13, !tbaa !24
  %t80 = load i64, ptr %l12, !tbaa !24
  %t83 = icmp slt i64 %t79, %t80
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s7)
  br label %bb31
bb26:
  br label %bb27
bb27:
  %t87 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t87, ptr %l55, !tbaa !27
  %t88 = load i64, ptr %l13, !tbaa !24
  %t90 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr i64, ptr %t91, i64 %t88
  %t93 = load i64, ptr %t92, !tbaa !34
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/check:Checker", ptr %t95, i32 0, i32 65
  store ptr %t97, ptr %l59, !tbaa !29
  %t98 = load i64, ptr %l1, !tbaa !24
  %t102 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s7, i64 %t98, i64 %t93)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t102, ptr %l62
  br label %bb28
bb28:
  %t103 = load ptr, ptr %l59, !tbaa !29
  %t104 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l62
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t103, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t104, i1 true)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s7)
  br label %bb30
bb30:
  %t105 = load i64, ptr %l13, !tbaa !24
  %t107 = add i64 %t105, 1
  store i64 %t107, ptr %l13, !tbaa !24
  br label %bb24
bb31:
  %t109 = load i64, ptr %l10, !tbaa !24
  %t110 = load i64, ptr %l12, !tbaa !24
  %t113 = add i64 %t109, %t110
  store i64 %t113, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb32
bb32:
  br label %bb17
bb33:
  call void @__olang_scope_close(ptr %s3)
  br label %bb34
bb34:
  %t115 = load i64, ptr %l6, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l6, !tbaa !24
  br label %bb8
bb35:
  %t119 = load i64, ptr %l3, !tbaa !24
  %t120 = load i64, ptr %l5, !tbaa !24
  %t123 = add i64 %t119, %t120
  store i64 %t123, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb36
bb36:
  br label %bb1
bb37:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i1
  %l20 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb5
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t9 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t6)
  store i32 %t9, ptr %l8
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l5, !tbaa !29
  %t11 = load i32, ptr %l8, !tbaa !23
  %t12 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t10, i32 %t11)
  store i1 %t12, ptr %l9
  br label %bb4
bb4:
  %t13 = load i1, ptr %l9, !tbaa !21
  store i1 %t13, ptr %l4, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l4, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb10
bb7:
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l11, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t19 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t16)
  store i32 %t19, ptr %l14
  br label %bb8
bb8:
  %t20 = load ptr, ptr %l11, !tbaa !29
  %t21 = load i32, ptr %l14, !tbaa !23
  %t22 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %t20, i32 %t21)
  store i1 %t22, ptr %l15
  br label %bb9
bb9:
  %t23 = load i1, ptr %l15, !tbaa !21
  %t24 = xor i1 %t23, true
  store i1 %t24, ptr %l10, !tbaa !21
  br label %bb10
bb10:
  %t26 = load i1, ptr %l10, !tbaa !21
  br i1 %t26, label %bb11, label %bb12
bb11:
  store i1 false, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t32 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCopied(ptr %v0, ptr %v1, ptr %t28, ptr %t29)
  store i1 %t32, ptr %l20
  br label %bb14
bb14:
  %t33 = load i1, ptr %l20, !tbaa !21
  store i1 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootIn(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca %"compiler/check:roOrigin"
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca %"compiler/check:roOrigin"
  %l16 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l26 = alloca %"compiler/check:roOrigin"
  %l28 = alloca ptr
  %l32 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l33 = alloca %"compiler/check:roOrigin"
  %l34 = alloca i32
  %l35 = alloca %"compiler/check:roOrigin"
  %l43 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca i1
  %l57 = alloca i64
  %l58 = alloca ptr
  %l59 = alloca i1
  %l70 = alloca i64
  %l71 = alloca ptr
  %l72 = alloca i1
  %l83 = alloca i64
  %l84 = alloca ptr
  %l85 = alloca i1
  %l91 = alloca ptr
  %l96 = alloca ptr
  %l98 = alloca ptr
  %l101 = alloca i64
  %l102 = alloca ptr
  %l103 = alloca i1
  %l109 = alloca ptr
  %l110 = alloca ptr
  %l111 = alloca ptr
  %l112 = alloca i1
  %l117 = alloca %"compiler/check:roOrigin"
  %l119 = alloca ptr
  %l123 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l124 = alloca %"compiler/check:roOrigin"
  %l125 = alloca i32
  %l126 = alloca %"compiler/check:roOrigin"
  %l130 = alloca i1
  %l136 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp sgt i64 %t5, 32
  store i1 %t7, ptr %l16, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l16, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i64 -1, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t12 = load ptr, ptr %l20, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l20, !tbaa !29
  %t16 = load i64, ptr %t15
  %t18 = icmp eq i64 %t16, 0
  store i1 %t18, ptr %l21, !tbaa !21
  br label %bb8
bb8:
  %t19 = load i1, ptr %l21, !tbaa !21
  br i1 %t19, label %bb9, label %bb10
bb9:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t22, i32 0, i32 2
  %t24 = load i32, ptr %t23
  store i32 %t24, ptr %l3, !tbaa !23
  br label %bb11
bb10:
  br label %bb22
bb11:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 59
  store ptr %t28, ptr %l28, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l3, !tbaa !23
  %t32 = sext i32 %t30 to i64
  %t35 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %t29, i64 %t32)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t35, ptr %l32
  br label %bb12
bb12:
  %t36 = load ptr, ptr %l28, !tbaa !29
  %t37 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l32
  %t38 = call { i32, %"compiler/check:roOrigin" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hfc56ff01c357e6bb827daf7012f18a86(ptr %v0, ptr %v0, ptr %t36, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t37)
  %t39 = extractvalue { i32, %"compiler/check:roOrigin" } %t38, 1
  %t40 = extractvalue { i32, %"compiler/check:roOrigin" } %t38, 0
  store i32 %t40, ptr %l34
  %t41 = icmp ne i32 %t40, 0
  br i1 %t41, label %bb14, label %ok.42
ok.42:
  store %"compiler/check:roOrigin" %t39, ptr %l33
  br label %bb13
bb13:
  %t43 = load %"compiler/check:roOrigin", ptr %l33
  store %"compiler/check:roOrigin" %t43, ptr %l26
  br label %bb17
bb14:
  br label %bb15
bb15:
  call void @__olang_ert_req_clear()
  %t44 = call %"compiler/check:roOrigin" @compiler_2fcheck_3aroOrigin_2ector(ptr %v0, ptr %v0, ptr null, i1 false)
  store %"compiler/check:roOrigin" %t44, ptr %l35
  br label %bb16
bb16:
  %t45 = load %"compiler/check:roOrigin", ptr %l35
  store %"compiler/check:roOrigin" %t45, ptr %l26
  br label %bb17
bb17:
  %t46 = load %"compiler/check:roOrigin", ptr %l26
  store %"compiler/check:roOrigin" %t46, ptr %l4
  %t47 = getelementptr %"compiler/check:roOrigin", ptr %l4, i32 0, i32 0
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = icmp eq ptr %t48, null
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb18, label %bb19
bb18:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:roOrigin", ptr %l4, i32 0, i32 0
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t57 = load i64, ptr %l2, !tbaa !24
  %t59 = add i64 %t57, 1
  %t63 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootIn(ptr %v0, ptr %v0, ptr %t54, ptr %t56, i64 %t59)
  store i64 %t63, ptr %l43
  br label %bb20
bb19:
  br label %bb21
bb20:
  %t64 = load i64, ptr %l43, !tbaa !24
  store i64 %t64, ptr %rv
  br label %ret
bb21:
  %t65 = load i32, ptr %l3, !tbaa !23
  %t67 = sext i32 %t65 to i64
  store i64 %t67, ptr %rv
  br label %ret
bb22:
  %t69 = load ptr, ptr %l1, !tbaa !29
  store ptr %t69, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t70 = load ptr, ptr %l46, !tbaa !29
  %t71 = icmp ne ptr %t70, null
  br i1 %t71, label %bb23, label %bb24
bb23:
  %t73 = load ptr, ptr %l46, !tbaa !29
  %t74 = load i64, ptr %t73
  %t76 = icmp eq i64 %t74, 3
  store i1 %t76, ptr %l47, !tbaa !21
  br label %bb24
bb24:
  %t77 = load i1, ptr %l47, !tbaa !21
  br i1 %t77, label %bb25, label %bb26
bb25:
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t80 = getelementptr { i64, [4 x i64] }, ptr %t78, i32 0, i32 1
  %t81 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t80, i32 0, i32 2
  %t82 = load ptr, ptr %t81
  store ptr %t82, ptr %l5, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load ptr, ptr %l5, !tbaa !29
  %t87 = load i64, ptr %l2, !tbaa !24
  %t89 = add i64 %t87, 1
  %t93 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootIn(ptr %v0, ptr %v1, ptr %t84, ptr %t85, i64 %t89)
  store i64 %t93, ptr %l57
  br label %bb28
bb28:
  %t94 = load i64, ptr %l57, !tbaa !24
  store i64 %t94, ptr %rv
  br label %ret
bb29:
  %t95 = load ptr, ptr %l1, !tbaa !29
  store ptr %t95, ptr %l58, !tbaa !29
  store i1 false, ptr %l59, !tbaa !21
  %t96 = load ptr, ptr %l58, !tbaa !29
  %t97 = icmp ne ptr %t96, null
  br i1 %t97, label %bb30, label %bb31
bb30:
  %t99 = load ptr, ptr %l58, !tbaa !29
  %t100 = load i64, ptr %t99
  %t102 = icmp eq i64 %t100, 4
  store i1 %t102, ptr %l59, !tbaa !21
  br label %bb31
bb31:
  %t103 = load i1, ptr %l59, !tbaa !21
  br i1 %t103, label %bb32, label %bb33
bb32:
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr { i64, [4 x i64] }, ptr %t104, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t106, i32 0, i32 2
  %t108 = load ptr, ptr %t107
  store ptr %t108, ptr %l6, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load ptr, ptr %l6, !tbaa !29
  %t113 = getelementptr %"compiler/typed:Elem", ptr %t111, i32 0, i32 0
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = load i64, ptr %l2, !tbaa !24
  %t118 = add i64 %t116, 1
  %t122 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootIn(ptr %v0, ptr %v1, ptr %t110, ptr %t114, i64 %t118)
  store i64 %t122, ptr %l70
  br label %bb35
bb35:
  %t123 = load i64, ptr %l70, !tbaa !24
  store i64 %t123, ptr %rv
  br label %ret
bb36:
  %t124 = load ptr, ptr %l1, !tbaa !29
  store ptr %t124, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t125 = load ptr, ptr %l71, !tbaa !29
  %t126 = icmp ne ptr %t125, null
  br i1 %t126, label %bb37, label %bb38
bb37:
  %t128 = load ptr, ptr %l71, !tbaa !29
  %t129 = load i64, ptr %t128
  %t131 = icmp eq i64 %t129, 5
  store i1 %t131, ptr %l72, !tbaa !21
  br label %bb38
bb38:
  %t132 = load i1, ptr %l72, !tbaa !21
  br i1 %t132, label %bb39, label %bb40
bb39:
  %t133 = load ptr, ptr %l1, !tbaa !29
  %t135 = getelementptr { i64, [4 x i64] }, ptr %t133, i32 0, i32 1
  %t136 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t135, i32 0, i32 2
  %t137 = load ptr, ptr %t136
  store ptr %t137, ptr %l7, !tbaa !29
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load ptr, ptr %l7, !tbaa !29
  %t142 = getelementptr %"compiler/typed:Payload", ptr %t140, i32 0, i32 0
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t145 = load i64, ptr %l2, !tbaa !24
  %t147 = add i64 %t145, 1
  %t151 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootIn(ptr %v0, ptr %v1, ptr %t139, ptr %t143, i64 %t147)
  store i64 %t151, ptr %l83
  br label %bb42
bb42:
  %t152 = load i64, ptr %l83, !tbaa !24
  store i64 %t152, ptr %rv
  br label %ret
bb43:
  %t153 = load ptr, ptr %l1, !tbaa !29
  store ptr %t153, ptr %l84, !tbaa !29
  store i1 false, ptr %l85, !tbaa !21
  %t154 = load ptr, ptr %l84, !tbaa !29
  %t155 = icmp ne ptr %t154, null
  br i1 %t155, label %bb44, label %bb45
bb44:
  %t157 = load ptr, ptr %l84, !tbaa !29
  %t158 = load i64, ptr %t157
  %t160 = icmp eq i64 %t158, 6
  store i1 %t160, ptr %l85, !tbaa !21
  br label %bb45
bb45:
  %t161 = load i1, ptr %l85, !tbaa !21
  br i1 %t161, label %bb46, label %bb47
bb46:
  %t162 = load ptr, ptr %l1, !tbaa !29
  %t164 = getelementptr { i64, [4 x i64] }, ptr %t162, i32 0, i32 1
  %t165 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t164, i32 0, i32 2
  %t166 = load ptr, ptr %t165
  store ptr %t166, ptr %l8, !tbaa !29
  br label %bb48
bb47:
  br label %bb55
bb48:
  %t168 = load ptr, ptr %l8, !tbaa !29
  %t170 = call ptr @compiler_2fcheck_2eunwrapped(ptr %v1, ptr %t168)
  store ptr %t170, ptr %l91
  br label %bb49
bb49:
  %t171 = load ptr, ptr %l91, !tbaa !29
  store ptr %t171, ptr %l9, !tbaa !29
  %t172 = load ptr, ptr %l9, !tbaa !29
  %t173 = load ptr, ptr %l8, !tbaa !29
  %t176 = icmp eq ptr %t172, %t173
  br i1 %t176, label %bb50, label %bb51
bb50:
  store i64 -1, ptr %rv
  br label %ret
bb51:
  br label %bb52
bb52:
  %t179 = load ptr, ptr %l0, !tbaa !29
  store ptr %t179, ptr %l96, !tbaa !29
  %t180 = load ptr, ptr %l9, !tbaa !29
  %t182 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %t180)
  store ptr %t182, ptr %l98
  br label %bb53
bb53:
  %t183 = load i64, ptr %l2, !tbaa !24
  %t185 = add i64 %t183, 1
  %t186 = load ptr, ptr %l96, !tbaa !29
  %t187 = load ptr, ptr %l98, !tbaa !29
  %t189 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootIn(ptr %v0, ptr %v1, ptr %t186, ptr %t187, i64 %t185)
  store i64 %t189, ptr %l101
  br label %bb54
bb54:
  %t190 = load i64, ptr %l101, !tbaa !24
  store i64 %t190, ptr %rv
  br label %ret
bb55:
  %t191 = load ptr, ptr %l1, !tbaa !29
  store ptr %t191, ptr %l102, !tbaa !29
  store i1 false, ptr %l103, !tbaa !21
  %t192 = load ptr, ptr %l102, !tbaa !29
  %t193 = icmp ne ptr %t192, null
  br i1 %t193, label %bb56, label %bb57
bb56:
  %t195 = load ptr, ptr %l102, !tbaa !29
  %t196 = load i64, ptr %t195
  %t198 = icmp eq i64 %t196, 2
  store i1 %t198, ptr %l103, !tbaa !21
  br label %bb57
bb57:
  %t199 = load i1, ptr %l103, !tbaa !21
  br i1 %t199, label %bb58, label %bb59
bb58:
  %t200 = load ptr, ptr %l1, !tbaa !29
  %t202 = getelementptr { i64, [4 x i64] }, ptr %t200, i32 0, i32 1
  %t203 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t202, i32 0, i32 2
  %t204 = load ptr, ptr %t203
  store ptr %t204, ptr %l10, !tbaa !29
  br label %bb60
bb59:
  br label %bb83
bb60:
  %t206 = load ptr, ptr %l10, !tbaa !29
  %t208 = call ptr @compiler_2fcheck_2eunwrapped(ptr %v1, ptr %t206)
  store ptr %t208, ptr %l109
  br label %bb61
bb61:
  %t209 = load ptr, ptr %l109, !tbaa !29
  %t210 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %t209)
  store ptr %t210, ptr %l110
  br label %bb62
bb62:
  %t211 = load ptr, ptr %l110, !tbaa !29
  store ptr %t211, ptr %l11, !tbaa !29
  %t212 = load ptr, ptr %l11, !tbaa !29
  store ptr %t212, ptr %l111, !tbaa !29
  store i1 false, ptr %l112, !tbaa !21
  %t213 = load ptr, ptr %l111, !tbaa !29
  %t214 = icmp ne ptr %t213, null
  br i1 %t214, label %bb63, label %bb64
bb63:
  %t216 = load ptr, ptr %l111, !tbaa !29
  %t217 = load i64, ptr %t216
  %t219 = icmp eq i64 %t217, 0
  store i1 %t219, ptr %l112, !tbaa !21
  br label %bb64
bb64:
  %t220 = load i1, ptr %l112, !tbaa !21
  br i1 %t220, label %bb65, label %bb66
bb65:
  %t221 = load ptr, ptr %l11, !tbaa !29
  %t223 = getelementptr { i64, [4 x i64] }, ptr %t221, i32 0, i32 1
  %t224 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t223, i32 0, i32 2
  %t225 = load i32, ptr %t224
  store i32 %t225, ptr %l12, !tbaa !23
  br label %bb67
bb66:
  br label %bb81
bb67:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/check:Checker", ptr %t227, i32 0, i32 59
  store ptr %t229, ptr %l119, !tbaa !29
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load i32, ptr %l12, !tbaa !23
  %t233 = sext i32 %t231 to i64
  %t236 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %t230, i64 %t233)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t236, ptr %l123
  br label %bb68
bb68:
  %t237 = load ptr, ptr %l119, !tbaa !29
  %t238 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l123
  %t239 = call { i32, %"compiler/check:roOrigin" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hfc56ff01c357e6bb827daf7012f18a86(ptr %v0, ptr %v0, ptr %t237, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t238)
  %t240 = extractvalue { i32, %"compiler/check:roOrigin" } %t239, 1
  %t241 = extractvalue { i32, %"compiler/check:roOrigin" } %t239, 0
  store i32 %t241, ptr %l125
  %t242 = icmp ne i32 %t241, 0
  br i1 %t242, label %bb70, label %ok.243
ok.243:
  store %"compiler/check:roOrigin" %t240, ptr %l124
  br label %bb69
bb69:
  %t244 = load %"compiler/check:roOrigin", ptr %l124
  store %"compiler/check:roOrigin" %t244, ptr %l117
  br label %bb73
bb70:
  br label %bb71
bb71:
  call void @__olang_ert_req_clear()
  %t245 = call %"compiler/check:roOrigin" @compiler_2fcheck_3aroOrigin_2ector(ptr %v0, ptr %v0, ptr null, i1 false)
  store %"compiler/check:roOrigin" %t245, ptr %l126
  br label %bb72
bb72:
  %t246 = load %"compiler/check:roOrigin", ptr %l126
  store %"compiler/check:roOrigin" %t246, ptr %l117
  br label %bb73
bb73:
  %t247 = load %"compiler/check:roOrigin", ptr %l117
  store %"compiler/check:roOrigin" %t247, ptr %l13
  %t248 = getelementptr %"compiler/check:roOrigin", ptr %l13, i32 0, i32 0
  %t249 = load ptr, ptr %t248, !tbaa !29
  %t251 = icmp eq ptr %t249, null
  %t253 = xor i1 %t251, true
  br i1 %t253, label %bb74, label %bb75
bb74:
  %t255 = getelementptr %"compiler/check:roOrigin", ptr %l13, i32 0, i32 1
  %t256 = load i1, ptr %t255, !tbaa !21
  store i1 %t256, ptr %l130, !tbaa !21
  br label %bb76
bb75:
  store i1 false, ptr %l130, !tbaa !21
  br label %bb76
bb76:
  %t258 = load i1, ptr %l130, !tbaa !21
  br i1 %t258, label %bb77, label %bb78
bb77:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = getelementptr %"compiler/check:roOrigin", ptr %l13, i32 0, i32 0
  %t261 = load ptr, ptr %t260, !tbaa !29
  %t262 = load i64, ptr %l2, !tbaa !24
  %t264 = add i64 %t262, 1
  %t268 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootIn(ptr %v0, ptr %v0, ptr %t259, ptr %t261, i64 %t264)
  store i64 %t268, ptr %l136
  br label %bb79
bb78:
  br label %bb80
bb79:
  %t269 = load i64, ptr %l136, !tbaa !24
  store i64 %t269, ptr %rv
  br label %ret
bb80:
  br label %bb82
bb81:
  br label %bb82
bb82:
  store i64 -1, ptr %rv
  br label %ret
bb83:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunArrayValue(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i1
  %l10 = alloca i1
  %l15 = alloca i32
  %l18 = alloca i1
  %l23 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t7, i32 %t8)
  store i1 %t11, ptr %l8
  br label %bb2
bb2:
  %t12 = load i1, ptr %l8, !tbaa !21
  %t13 = xor i1 %t12, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/generic:Program", ptr %t18, i32 0, i32 2
  %t21 = load i32, ptr %l2, !tbaa !23
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t24, ptr %l15
  br label %bb5
bb4:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb6
bb5:
  %t25 = load i32, ptr %l15
  %t27 = trunc i64 19 to i32
  %t28 = icmp eq i32 %t25, %t27
  store i1 %t28, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t30 = load i1, ptr %l10, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 2
  %t37 = load i32, ptr %l2, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t40, ptr %l23
  br label %bb9
bb8:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb10
bb9:
  %t41 = load i32, ptr %l23, !tbaa !23
  %t42 = icmp eq i32 %t41, 0
  store i1 %t42, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t44 = load i1, ptr %l18, !tbaa !21
  store i1 %t44, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2escopeVarOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, %"compiler/check:ctSource" %a3, i32 %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"compiler/check:ctSource"
  %l4 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l45 = alloca { i64, ptr }
  %l59 = alloca ptr
  %l60 = alloca i64
  %l61 = alloca %"compiler/source:Span"
  %l64 = alloca { i64, ptr }
  %l66 = alloca %"compiler/msgs:Msg"
  %l67 = alloca i64
  %l72 = alloca i64
  %l75 = alloca i64
  %l98 = alloca i64
  %l109 = alloca i64
  %l112 = alloca i64
  %l130 = alloca { i64, ptr }
  %l138 = alloca ptr
  %l139 = alloca i64
  %l140 = alloca %"compiler/source:Span"
  %l143 = alloca { i64, ptr }
  %l146 = alloca { i64, ptr }
  %l148 = alloca %"compiler/msgs:Msg"
  %l149 = alloca i64
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store %"compiler/check:ctSource" %a3, ptr %l3
  store i32 %a4, ptr %l4
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 -3, ptr %l6, !tbaa !24
  %t1 = load i32, ptr %l4, !tbaa !23
  %t3 = icmp eq i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr @G_2ecompiler_2ftypes_2eResultVar, !tbaa !24
  store i64 %t5, ptr %l6, !tbaa !24
  br label %bb43
bb2:
  store i64 0, ptr %l7, !tbaa !24
  %t7 = getelementptr %"compiler/check:ctSource", ptr %l3, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = icmp eq ptr %t8, null
  %t12 = xor i1 %t10, true
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = getelementptr %"compiler/check:ctSource", ptr %l3, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = icmp eq ptr %t15, null
  br i1 %t17, label %bb5, label %bb6
bb4:
  br label %bb11
bb5:
  call void @__olang_check_failed(ptr @olang_loc_de80a8bbdf5854b0_34f8ecda9179f3f4)
  unreachable
bb6:
  br label %bb7
bb7:
  %t19 = getelementptr %"compiler/check:ctSource", ptr %l3, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t23 = getelementptr %"compiler/ast:Param", ptr %t20, i32 0, i32 1
  %t24 = load i32, ptr %t23, !tbaa !23
  %t25 = load i32, ptr %l4, !tbaa !23
  %t28 = icmp eq i32 %t24, %t25
  br i1 %t28, label %bb8, label %bb9
bb8:
  store i64 0, ptr %l6, !tbaa !24
  br label %bb10
bb9:
  br label %bb10
bb10:
  store i64 1, ptr %l7, !tbaa !24
  br label %bb11
bb11:
  %t30 = getelementptr %"compiler/check:ctSource", ptr %l3, i32 0, i32 2
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  store { i64, ptr } %t31, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  store i64 %t35, ptr %l10, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s6
  %t37 = load i64, ptr %l9, !tbaa !24
  %t38 = load i64, ptr %l10, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s6)
  br label %bb20
bb14:
  br label %bb15
bb15:
  %t45 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t45, ptr %l45, !tbaa !27
  %t46 = load i64, ptr %l9, !tbaa !24
  %t48 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr ptr, ptr %t49, i64 %t46
  %t51 = load ptr, ptr %t50, !tbaa !39
  %t55 = getelementptr %"compiler/ast:Param", ptr %t51, i32 0, i32 1
  %t56 = load i32, ptr %t55, !tbaa !23
  %t57 = load i32, ptr %l4, !tbaa !23
  %t60 = icmp eq i32 %t56, %t57
  br i1 %t60, label %bb16, label %bb17
bb16:
  %t62 = load i64, ptr %l7, !tbaa !24
  store i64 %t62, ptr %l6, !tbaa !24
  br label %bb18
bb17:
  br label %bb18
bb18:
  %t64 = load i64, ptr %l7, !tbaa !24
  %t66 = add i64 %t64, 1
  store i64 %t66, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb19
bb19:
  %t68 = load i64, ptr %l9, !tbaa !24
  %t70 = add i64 %t68, 1
  store i64 %t70, ptr %l9, !tbaa !24
  br label %bb12
bb20:
  %t72 = load i64, ptr %l6, !tbaa !24
  %t74 = icmp eq i64 %t72, -3
  br i1 %t74, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s9
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l59, !tbaa !29
  %t77 = getelementptr %"compiler/check:ctSource", ptr %l3, i32 0, i32 3
  %t78 = load i64, ptr %t77, !tbaa !24
  store i64 %t78, ptr %l60, !tbaa !24
  %t79 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t79, ptr %l61
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i32, ptr %l4, !tbaa !23
  %t84 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s9, ptr %t80, i32 %t81)
  store { i64, ptr } %t84, ptr %l64
  br label %bb23
bb22:
  br label %bb26
bb23:
  %t85 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 0
  %t87 = extractvalue { i64, ptr } %t85, 1
  %t88 = mul i64 %t86, 1
  %t89 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t88)
  call void @llvm.memcpy.p0.p0.i64(ptr %t89, ptr %t87, i64 %t88, i1 false)
  %t90 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  %t93 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eContractOutlivesNotParam(ptr %s9, ptr %s9, { i64, ptr } %t91)
  store %"compiler/msgs:Msg" %t93, ptr %l66
  br label %bb24
bb24:
  %t94 = load ptr, ptr %l59, !tbaa !29
  %t95 = load i64, ptr %l60, !tbaa !24
  %t96 = load %"compiler/source:Span", ptr %l61
  %t97 = load %"compiler/msgs:Msg", ptr %l66
  %t98 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectErr(ptr %v0, ptr %s9, ptr %t94, i64 %t95, %"compiler/source:Span" %t96, %"compiler/msgs:Msg" %t97)
  store i64 %t98, ptr %l67
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb26:
  store i64 0, ptr %l12, !tbaa !24
  store i64 64, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t100 = load i64, ptr %l13, !tbaa !24
  %t101 = load i64, ptr %l12, !tbaa !24
  %t104 = icmp sgt i64 %t100, %t101
  br i1 %t104, label %bb27, label %bb28
bb27:
  %t106 = load i64, ptr %l14, !tbaa !24
  %t108 = icmp sgt i64 %t106, 0
  br i1 %t108, label %bb29, label %bb30
bb28:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb32
bb29:
  %t110 = load i64, ptr %l13, !tbaa !24
  %t111 = load i64, ptr %l12, !tbaa !24
  %t114 = sub i64 %t110, %t111
  %t115 = load i64, ptr %l14, !tbaa !24
  %t118 = add i64 %t114, %t115
  %t120 = sub i64 %t118, 1
  %t121 = load i64, ptr %l14, !tbaa !24
  %t124 = sdiv i64 %t120, %t121
  store i64 %t124, ptr %l75, !tbaa !24
  br label %bb31
bb30:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb31
bb31:
  %t126 = load i64, ptr %l75, !tbaa !24
  store i64 %t126, ptr %l72, !tbaa !24
  br label %bb32
bb32:
  %t127 = load i64, ptr %l72, !tbaa !24
  store i64 %t127, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s11
  %t128 = load i64, ptr %l16, !tbaa !24
  %t129 = load i64, ptr %l15, !tbaa !24
  %t132 = icmp slt i64 %t128, %t129
  %t134 = xor i1 %t132, true
  br i1 %t134, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s11)
  br label %bb42
bb35:
  br label %bb36
bb36:
  %t136 = load i64, ptr %l12, !tbaa !24
  %t137 = load i64, ptr %l16, !tbaa !24
  %t138 = load i64, ptr %l14, !tbaa !24
  %t141 = mul i64 %t137, %t138
  %t144 = add i64 %t136, %t141
  store i64 %t144, ptr %l17, !tbaa !24
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/check:Checker", ptr %t146, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t151 = getelementptr %"compiler/generic:Program", ptr %t149, i32 0, i32 2
  %t153 = load i64, ptr %l6, !tbaa !24
  %t157 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t151, i32 %a1, i64 %t153)
  store i64 %t157, ptr %l98
  br label %bb37
bb37:
  %t158 = load i64, ptr %l98, !tbaa !24
  store i64 %t158, ptr %l18, !tbaa !24
  %t159 = load i64, ptr %l18, !tbaa !24
  %t161 = icmp slt i64 %t159, 0
  br i1 %t161, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s11)
  br label %bb42
bb39:
  br label %bb40
bb40:
  %t163 = load i64, ptr %l18, !tbaa !24
  store i64 %t163, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s11)
  br label %bb41
bb41:
  %t165 = load i64, ptr %l16, !tbaa !24
  %t167 = add i64 %t165, 1
  store i64 %t167, ptr %l16, !tbaa !24
  br label %bb33
bb42:
  br label %bb43
bb43:
  store i64 0, ptr %l19, !tbaa !24
  %t169 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t169, 0
  store i64 %t171, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t173 = load i64, ptr %l20, !tbaa !24
  %t174 = load i64, ptr %l19, !tbaa !24
  %t177 = icmp sgt i64 %t173, %t174
  br i1 %t177, label %bb44, label %bb45
bb44:
  %t179 = load i64, ptr %l21, !tbaa !24
  %t181 = icmp sgt i64 %t179, 0
  br i1 %t181, label %bb46, label %bb47
bb45:
  store i64 0, ptr %l109, !tbaa !24
  br label %bb49
bb46:
  %t183 = load i64, ptr %l20, !tbaa !24
  %t184 = load i64, ptr %l19, !tbaa !24
  %t187 = sub i64 %t183, %t184
  %t188 = load i64, ptr %l21, !tbaa !24
  %t191 = add i64 %t187, %t188
  %t193 = sub i64 %t191, 1
  %t194 = load i64, ptr %l21, !tbaa !24
  %t197 = sdiv i64 %t193, %t194
  store i64 %t197, ptr %l112, !tbaa !24
  br label %bb48
bb47:
  store i64 0, ptr %l112, !tbaa !24
  br label %bb48
bb48:
  %t199 = load i64, ptr %l112, !tbaa !24
  store i64 %t199, ptr %l109, !tbaa !24
  br label %bb49
bb49:
  %t200 = load i64, ptr %l109, !tbaa !24
  store i64 %t200, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s15
  %t201 = load i64, ptr %l23, !tbaa !24
  %t202 = load i64, ptr %l22, !tbaa !24
  %t205 = icmp slt i64 %t201, %t202
  %t207 = xor i1 %t205, true
  br i1 %t207, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s15)
  br label %bb58
bb52:
  br label %bb53
bb53:
  %t209 = load i64, ptr %l19, !tbaa !24
  %t210 = load i64, ptr %l23, !tbaa !24
  %t211 = load i64, ptr %l21, !tbaa !24
  %t214 = mul i64 %t210, %t211
  %t217 = add i64 %t209, %t214
  store i64 %t217, ptr %l24, !tbaa !24
  %t219 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t219, ptr %l130, !tbaa !27
  %t220 = load i64, ptr %l24, !tbaa !24
  %t222 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t223 = load ptr, ptr %t222, !tbaa !27
  %t224 = getelementptr i64, ptr %t223, i64 %t220
  %t225 = load i64, ptr %t224, !tbaa !34
  %t226 = load i64, ptr %l6, !tbaa !24
  %t229 = icmp eq i64 %t225, %t226
  br i1 %t229, label %bb54, label %bb55
bb54:
  %t231 = load i64, ptr %l24, !tbaa !24
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  store i64 %t231, ptr %rv
  br label %ret
bb55:
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s15)
  br label %bb57
bb57:
  %t233 = load i64, ptr %l23, !tbaa !24
  %t235 = add i64 %t233, 1
  store i64 %t235, ptr %l23, !tbaa !24
  br label %bb50
bb58:
  %t237 = load ptr, ptr %l0, !tbaa !29
  store ptr %t237, ptr %l138, !tbaa !29
  %t238 = getelementptr %"compiler/check:ctSource", ptr %l3, i32 0, i32 3
  %t239 = load i64, ptr %t238, !tbaa !24
  store i64 %t239, ptr %l139, !tbaa !24
  %t240 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t240, ptr %l140
  %t241 = load i32, ptr %l4, !tbaa !23
  %t243 = icmp eq i32 %t241, 0
  br i1 %t243, label %bb59, label %bb60
bb59:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d34, i32 0, i32 1) }, ptr %l143, !tbaa !27
  br label %bb62
bb60:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load i32, ptr %l4, !tbaa !23
  %t249 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s0, ptr %t245, i32 %t246)
  store { i64, ptr } %t249, ptr %l146
  br label %bb61
bb61:
  %t250 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t251 = extractvalue { i64, ptr } %t250, 0
  %t252 = extractvalue { i64, ptr } %t250, 1
  %t253 = mul i64 %t251, 1
  %t254 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t253)
  call void @llvm.memcpy.p0.p0.i64(ptr %t254, ptr %t252, i64 %t253, i1 false)
  %t255 = insertvalue { i64, ptr } undef, i64 %t251, 0
  %t256 = insertvalue { i64, ptr } %t255, ptr %t254, 1
  store { i64, ptr } %t256, ptr %l143, !tbaa !27
  br label %bb62
bb62:
  %t258 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t259 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eContractOutlivesNoScope(ptr %s0, ptr %s0, { i64, ptr } %t258)
  store %"compiler/msgs:Msg" %t259, ptr %l148
  br label %bb63
bb63:
  %t260 = load ptr, ptr %l138, !tbaa !29
  %t261 = load i64, ptr %l139, !tbaa !24
  %t262 = load %"compiler/source:Span", ptr %l140
  %t263 = load %"compiler/msgs:Msg", ptr %l148
  %t264 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectErr(ptr %v0, ptr %s0, ptr %t260, i64 %t261, %"compiler/source:Span" %t262, %"compiler/msgs:Msg" %t263)
  store i64 %t264, ptr %l149
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i1
  %l17 = alloca i64
  %l18 = alloca i32
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l25 = alloca i1
  %l26 = alloca i1
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i32
  %l50 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca { i64, ptr }
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i64
  %l78 = alloca i1
  %l79 = alloca ptr
  %l82 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l95 = alloca i32
  %l120 = alloca i32
  %l121 = alloca ptr
  %l124 = alloca ptr
  %l129 = alloca i32
  %l130 = alloca i32
  %l131 = alloca { i64, ptr }
  %l134 = alloca ptr
  %l137 = alloca ptr
  %l142 = alloca i32
  %l143 = alloca i64
  %l144 = alloca { i64, ptr }
  %l149 = alloca ptr
  %l154 = alloca i32
  %l155 = alloca { i64, ptr }
  %l160 = alloca i64
  %l166 = alloca i64
  %l169 = alloca i64
  %l189 = alloca i1
  %l191 = alloca i64
  %l198 = alloca ptr
  %l199 = alloca { i64, ptr }
  %l201 = alloca { i64, ptr }
  %l204 = alloca { i64, ptr }
  %l213 = alloca ptr
  %l214 = alloca ptr
  %l217 = alloca ptr
  %l222 = alloca i32
  %l223 = alloca i64
  %l224 = alloca { i64, ptr }
  %l226 = alloca ptr
  %l227 = alloca ptr
  %l230 = alloca ptr
  %l235 = alloca i32
  %l236 = alloca i32
  %l237 = alloca { i64, ptr }
  %l238 = alloca ptr
  %l239 = alloca ptr
  %l244 = alloca i32
  %l248 = alloca ptr
  %l249 = alloca ptr
  %l254 = alloca i32
  %l261 = alloca ptr
  %l262 = alloca ptr
  %l267 = alloca i32
  %l277 = alloca i64
  %l285 = alloca i1
  %l291 = alloca ptr
  %l292 = alloca ptr
  %l297 = alloca i32
  %l298 = alloca ptr
  %l303 = alloca { i64, ptr }
  %l310 = alloca i32
  %l313 = alloca ptr
  %l318 = alloca i32
  %l319 = alloca { i64, ptr }
  %l327 = alloca { i64, ptr }
  %l341 = alloca i32
  %l344 = alloca i1
  %l347 = alloca ptr
  %l352 = alloca i32
  %l353 = alloca { i64, ptr }
  %l356 = alloca i1
  %l361 = alloca i1
  %l364 = alloca i1
  %l370 = alloca ptr
  %l372 = alloca { i64, ptr }
  %l375 = alloca ptr
  %l380 = alloca i32
  %l381 = alloca { i64, ptr }
  %l386 = alloca { i64, ptr }
  %l392 = alloca i64
  %l395 = alloca i64
  %l421 = alloca ptr
  %l423 = alloca { i64, ptr }
  %l428 = alloca { i64, ptr }
  %l432 = alloca { i64, ptr }
  %l440 = alloca i64
  %l443 = alloca i1
  %l447 = alloca i1
  %l452 = alloca i1
  %l458 = alloca ptr
  %l460 = alloca { i64, ptr }
  %l465 = alloca { i64, ptr }
  %l473 = alloca i32
  %l478 = alloca ptr
  %l483 = alloca i32
  %l484 = alloca { i64, ptr }
  %l490 = alloca i64
  %l493 = alloca i64
  %l511 = alloca ptr
  %l514 = alloca { i64, ptr }
  %l517 = alloca { i64, ptr }
  %l530 = alloca i32
  %l533 = alloca i64
  %l538 = alloca i64
  %l543 = alloca ptr
  %l544 = alloca ptr
  %l547 = alloca ptr
  %l552 = alloca i32
  %l554 = alloca i32
  %l555 = alloca ptr
  %l559 = alloca i1
  %l564 = alloca i32
  %l567 = alloca i1
  %l570 = alloca ptr
  %l575 = alloca i32
  %l576 = alloca { i64, ptr }
  %l585 = alloca i1
  %l590 = alloca i1
  %l596 = alloca ptr
  %l598 = alloca { i64, ptr }
  %l603 = alloca { i64, ptr }
  %l617 = alloca { i64, ptr }
  %l623 = alloca ptr
  %l626 = alloca { i64, ptr }
  %l638 = alloca ptr
  %l639 = alloca ptr
  %l644 = alloca i32
  %l652 = alloca { i64, ptr }
  %l655 = alloca ptr
  %l660 = alloca i32
  %l661 = alloca { i64, ptr }
  %l666 = alloca { i64, ptr }
  %l672 = alloca i64
  %l675 = alloca i64
  %l694 = alloca ptr
  %l696 = alloca { i64, ptr }
  %l699 = alloca { i64, ptr }
  %l704 = alloca i1
  %l705 = alloca { i64, ptr }
  %l711 = alloca ptr
  %l715 = alloca { i64, ptr }
  %l718 = alloca i32
  %l719 = alloca { i64, ptr }
  %l730 = alloca ptr
  %l731 = alloca ptr
  %l735 = alloca { i64, ptr }
  %l738 = alloca i32
  %l745 = alloca i64
  %l748 = alloca i64
  %l769 = alloca ptr
  %l771 = alloca { i64, ptr }
  %l776 = alloca { i64, ptr }
  %l780 = alloca { i64, ptr }
  %l795 = alloca ptr
  %l800 = alloca i64
  %l805 = alloca ptr
  %l806 = alloca ptr
  %l808 = alloca ptr
  %l813 = alloca i64
  %l818 = alloca i64
  %l819 = alloca %"compiler/generic:varRow"
  %l821 = alloca { i64, ptr }
  %l826 = alloca ptr
  %l831 = alloca i32
  %l832 = alloca { i64, ptr }
  %l842 = alloca i64
  %l845 = alloca i64
  %l868 = alloca { i64, ptr }
  %l873 = alloca ptr
  %l878 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s44 = alloca %olang.scope
  %s46 = alloca %olang.scope
  %s50 = alloca %olang.scope
  %s51 = alloca %olang.scope
  %s53 = alloca %olang.scope
  %s56 = alloca %olang.scope
  %s58 = alloca %olang.scope
  %s59 = alloca %olang.scope
  %s62 = alloca %olang.scope
  %s66 = alloca %olang.scope
  %s68 = alloca %olang.scope
  %s69 = alloca %olang.scope
  %s71 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l78
  br label %bb1
bb1:
  %t11 = load i1, ptr %l78, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t12 = load ptr, ptr %l1, !tbaa !29
  store ptr %t12, ptr %l79, !tbaa !29
  %t13 = load i32, ptr %l2, !tbaa !23
  %t15 = icmp sle i32 %t13, 14
  br i1 %t15, label %bb4, label %bb5
bb3:
  br label %bb10
bb4:
  %t17 = load i32, ptr %l2, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2fcheck_2eprimName(ptr %s1, i32 %t17)
  store { i64, ptr } %t19, ptr %l84
  br label %bb6
bb5:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  %t26 = load i32, ptr %l2, !tbaa !23
  %t29 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s1, ptr %t25, i32 %t26)
  store { i64, ptr } %t29, ptr %l89
  br label %bb7
bb6:
  %t30 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t30, ptr %l82, !tbaa !27
  br label %bb8
bb7:
  %t31 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  %t33 = extractvalue { i64, ptr } %t31, 1
  %t34 = mul i64 %t32, 1
  %t35 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t34)
  call void @llvm.memcpy.p0.p0.i64(ptr %t35, ptr %t33, i64 %t34, i1 false)
  %t36 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  store { i64, ptr } %t37, ptr %l82, !tbaa !27
  br label %bb8
bb8:
  %t39 = load ptr, ptr %l79, !tbaa !29
  %t40 = load { i64, ptr }, ptr %l82, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s1, ptr %t39, { i64, ptr } %t40)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb10:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 2
  %t47 = load i32, ptr %l2, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t50, ptr %l95
  br label %bb11
bb11:
  %t51 = load i32, ptr %l95
  store i32 %t51, ptr %l4
  %t52 = load i32, ptr %l4
  %t54 = trunc i64 2 to i32
  %t55 = icmp eq i32 %t52, %t54
  br i1 %t55, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb16
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t57 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t57, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d35, i32 0, i32 1) })
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb408
bb16:
  %t59 = load i32, ptr %l4
  %t61 = trunc i64 0 to i32
  %t62 = icmp eq i32 %t59, %t61
  br i1 %t62, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t64 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t64, i8 63)
  br label %bb20
bb20:
  br label %bb408
bb21:
  %t66 = load i32, ptr %l4
  %t68 = trunc i64 1 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb26
bb24:
  store %olang.scope zeroinitializer, ptr %s4
  %t71 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s4, ptr %t71, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d36, i32 0, i32 1) })
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s4)
  br label %bb408
bb26:
  %t73 = load i32, ptr %l4
  %t75 = trunc i64 15 to i32
  %t76 = icmp eq i32 %t73, %t75
  br i1 %t76, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb31
bb29:
  store %olang.scope zeroinitializer, ptr %s5
  %t78 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s5, ptr %t78, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d37, i32 0, i32 1) })
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb408
bb31:
  %t80 = load i32, ptr %l4
  %t82 = trunc i64 16 to i32
  %t83 = icmp eq i32 %t80, %t82
  br i1 %t83, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb36
bb34:
  store %olang.scope zeroinitializer, ptr %s6
  %t85 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s6, ptr %t85, { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d38, i32 0, i32 1) })
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s6)
  br label %bb408
bb36:
  %t87 = load i32, ptr %l4
  %t89 = trunc i64 17 to i32
  %t90 = icmp eq i32 %t87, %t89
  br i1 %t90, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb41
bb39:
  store %olang.scope zeroinitializer, ptr %s7
  %t92 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s7, ptr %t92, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d39, i32 0, i32 1) })
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s7)
  br label %bb408
bb41:
  %t94 = load i32, ptr %l4
  %t96 = trunc i64 28 to i32
  %t97 = icmp eq i32 %t94, %t96
  br i1 %t97, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb82
bb44:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = getelementptr %"compiler/generic:Program", ptr %t102, i32 0, i32 2
  %t105 = load i32, ptr %l2, !tbaa !23
  %t108 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t104, i32 %t105)
  store i32 %t108, ptr %l120
  br label %bb45
bb45:
  %t109 = load i32, ptr %l120, !tbaa !23
  store i32 %t109, ptr %l5, !tbaa !23
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l121, !tbaa !29
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/check:Checker", ptr %t111, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = getelementptr %"compiler/generic:Program", ptr %t114, i32 0, i32 2
  store ptr %t116, ptr %l124, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = getelementptr %"compiler/generic:Program", ptr %t120, i32 0, i32 2
  %t123 = load i32, ptr %l5, !tbaa !23
  %t126 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t122, i32 %t123)
  store i32 %t126, ptr %l129
  br label %bb46
bb46:
  %t127 = load ptr, ptr %l124, !tbaa !29
  %t128 = load i32, ptr %l129, !tbaa !23
  %t129 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t127, i32 %t128)
  store i32 %t129, ptr %l130
  br label %bb47
bb47:
  %t130 = load ptr, ptr %l121, !tbaa !29
  %t131 = load i32, ptr %l130, !tbaa !23
  %t132 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t130, i32 %t131)
  store { i64, ptr } %t132, ptr %l131
  br label %bb48
bb48:
  %t133 = load { i64, ptr }, ptr %l131, !tbaa !27
  store { i64, ptr } %t133, ptr %l6, !tbaa !27
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t134, i32 0, i32 5
  %t137 = load i1, ptr %t136, !tbaa !21
  br i1 %t137, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s9
  %t139 = load ptr, ptr %l0, !tbaa !29
  store ptr %t139, ptr %l134, !tbaa !29
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/check:Checker", ptr %t140, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t145 = getelementptr %"compiler/generic:Program", ptr %t143, i32 0, i32 2
  store ptr %t145, ptr %l137, !tbaa !29
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/check:Checker", ptr %t146, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t151 = getelementptr %"compiler/generic:Program", ptr %t149, i32 0, i32 2
  %t152 = load i32, ptr %l5, !tbaa !23
  %t155 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t151, i32 %t152)
  store i32 %t155, ptr %l142
  br label %bb51
bb50:
  br label %bb54
bb51:
  %t156 = load ptr, ptr %l137, !tbaa !29
  %t157 = load i32, ptr %l142, !tbaa !23
  %t158 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t156, i32 %t157)
  store i64 %t158, ptr %l143
  br label %bb52
bb52:
  %t159 = load ptr, ptr %l134, !tbaa !29
  %t160 = load i64, ptr %l143, !tbaa !24
  %t161 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2equalifierFor(ptr %v0, ptr %s9, ptr %t159, i64 %t160)
  store { i64, ptr } %t161, ptr %l144
  br label %bb53
bb53:
  %t162 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t163 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t164 = extractvalue { i64, ptr } %t163, 1
  %t165 = extractvalue { i64, ptr } %t163, 0
  %t167 = extractvalue { i64, ptr } %t162, 1
  %t168 = extractvalue { i64, ptr } %t162, 0
  %t169 = add i64 %t165, %t168
  %t170 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t169)
  call void @olang_textcopy(ptr %t170, ptr %t164, i64 %t165)
  %t171 = getelementptr i8, ptr %t170, i64 %t165
  call void @olang_textcopy(ptr %t171, ptr %t167, i64 %t168)
  %t172 = insertvalue { i64, ptr } undef, i64 %t169, 0
  %t173 = insertvalue { i64, ptr } %t172, ptr %t170, 1
  %t175 = extractvalue { i64, ptr } %t173, 0
  %t176 = extractvalue { i64, ptr } %t173, 1
  %t177 = mul i64 %t175, 1
  %t178 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t177)
  call void @llvm.memcpy.p0.p0.i64(ptr %t178, ptr %t176, i64 %t177, i1 false)
  %t179 = insertvalue { i64, ptr } undef, i64 %t175, 0
  %t180 = insertvalue { i64, ptr } %t179, ptr %t178, 1
  store { i64, ptr } %t180, ptr %l6, !tbaa !27
  call void @__olang_scope_close(ptr %s9)
  br label %bb54
bb54:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/check:Checker", ptr %t182, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !29
  store ptr %t185, ptr %l149, !tbaa !29
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = getelementptr %"compiler/check:Checker", ptr %t186, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !29
  %t191 = getelementptr %"compiler/generic:Program", ptr %t189, i32 0, i32 2
  %t192 = load i32, ptr %l5, !tbaa !23
  %t195 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t191, i32 %t192)
  store i32 %t195, ptr %l154
  br label %bb55
bb55:
  %t196 = load ptr, ptr %l149, !tbaa !29
  %t197 = load i32, ptr %l154, !tbaa !23
  %t198 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %t196, i32 %t197)
  store { i64, ptr } %t198, ptr %l155
  br label %bb56
bb56:
  %t199 = load { i64, ptr }, ptr %l155, !tbaa !27
  store { i64, ptr } %t199, ptr %l7, !tbaa !27
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/check:Checker", ptr %t200, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !29
  %t205 = getelementptr %"compiler/generic:Program", ptr %t203, i32 0, i32 2
  %t206 = load i32, ptr %l2, !tbaa !23
  %t209 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t205, i32 %t206)
  store i64 %t209, ptr %l160
  br label %bb57
bb57:
  %t210 = load i64, ptr %l160, !tbaa !65
  store i64 %t210, ptr %l8, !tbaa !65
  store i1 true, ptr %l9, !tbaa !21
  store i64 0, ptr %l10, !tbaa !24
  %t211 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t211, 0
  store i64 %t213, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t215 = load i64, ptr %l11, !tbaa !24
  %t216 = load i64, ptr %l10, !tbaa !24
  %t219 = icmp sgt i64 %t215, %t216
  br i1 %t219, label %bb58, label %bb59
bb58:
  %t221 = load i64, ptr %l12, !tbaa !24
  %t223 = icmp sgt i64 %t221, 0
  br i1 %t223, label %bb60, label %bb61
bb59:
  store i64 0, ptr %l166, !tbaa !24
  br label %bb63
bb60:
  %t225 = load i64, ptr %l11, !tbaa !24
  %t226 = load i64, ptr %l10, !tbaa !24
  %t229 = sub i64 %t225, %t226
  %t230 = load i64, ptr %l12, !tbaa !24
  %t233 = add i64 %t229, %t230
  %t235 = sub i64 %t233, 1
  %t236 = load i64, ptr %l12, !tbaa !24
  %t239 = sdiv i64 %t235, %t236
  store i64 %t239, ptr %l169, !tbaa !24
  br label %bb62
bb61:
  store i64 0, ptr %l169, !tbaa !24
  br label %bb62
bb62:
  %t241 = load i64, ptr %l169, !tbaa !24
  store i64 %t241, ptr %l166, !tbaa !24
  br label %bb63
bb63:
  %t242 = load i64, ptr %l166, !tbaa !24
  store i64 %t242, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb64
bb64:
  store %olang.scope zeroinitializer, ptr %s12
  %t243 = load i64, ptr %l14, !tbaa !24
  %t244 = load i64, ptr %l13, !tbaa !24
  %t247 = icmp slt i64 %t243, %t244
  %t249 = xor i1 %t247, true
  br i1 %t249, label %bb65, label %bb66
bb65:
  call void @__olang_scope_close(ptr %s12)
  br label %bb81
bb66:
  br label %bb67
bb67:
  %t251 = load i64, ptr %l10, !tbaa !24
  %t252 = load i64, ptr %l14, !tbaa !24
  %t253 = load i64, ptr %l12, !tbaa !24
  %t256 = mul i64 %t252, %t253
  %t259 = add i64 %t251, %t256
  store i64 %t259, ptr %l15, !tbaa !24
  %t261 = load i64, ptr %l15, !tbaa !24
  %t263 = icmp slt i64 %t261, 64
  br i1 %t263, label %bb68, label %bb69
bb68:
  %t265 = load i64, ptr %l8, !tbaa !65
  %t266 = load i64, ptr %l15, !tbaa !24
  store i64 %t266, ptr %l191, !tbaa !24
  %t267 = load i64, ptr %l191, !tbaa !24
  %t268 = load i64, ptr %l191, !tbaa !24
  %t269 = shl i64 1, %t268
  %t272 = and i64 %t265, %t269
  %t274 = icmp ne i64 %t272, 0
  store i1 %t274, ptr %l189, !tbaa !21
  br label %bb70
bb69:
  store i1 false, ptr %l189, !tbaa !21
  br label %bb70
bb70:
  %t276 = load i1, ptr %l189, !tbaa !21
  br i1 %t276, label %bb71, label %bb72
bb71:
  store %olang.scope zeroinitializer, ptr %s13
  %t277 = load i1, ptr %l9, !tbaa !21
  %t279 = xor i1 %t277, true
  br i1 %t279, label %bb73, label %bb74
bb72:
  br label %bb79
bb73:
  store %olang.scope zeroinitializer, ptr %s14
  %t281 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s14, ptr %t281, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d40, i32 0, i32 1) })
  br label %bb75
bb74:
  br label %bb76
bb75:
  call void @__olang_scope_close(ptr %s14)
  br label %bb76
bb76:
  %t283 = load ptr, ptr %l1, !tbaa !29
  store ptr %t283, ptr %l198, !tbaa !29
  %t284 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t284, ptr %l199, !tbaa !27
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t286 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t286, ptr %l201, !tbaa !27
  %t287 = load i64, ptr %l15, !tbaa !24
  %t289 = getelementptr { i64, ptr }, ptr %l201, i32 0, i32 1
  %t290 = load ptr, ptr %t289, !tbaa !27
  %t291 = getelementptr i32, ptr %t290, i64 %t287
  %t292 = load i32, ptr %t291, !tbaa !33
  %t295 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t285, i32 %t292)
  store { i64, ptr } %t295, ptr %l204
  br label %bb77
bb77:
  %t296 = load { i64, ptr }, ptr %l199, !tbaa !27
  %t297 = extractvalue { i64, ptr } %t296, 1
  %t298 = extractvalue { i64, ptr } %t296, 0
  %t299 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t300 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t301 = add i64 %t298, %t300
  %t302 = load { i64, ptr }, ptr %l204, !tbaa !27
  %t303 = extractvalue { i64, ptr } %t302, 1
  %t304 = extractvalue { i64, ptr } %t302, 0
  %t305 = add i64 %t301, %t304
  %t306 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t305)
  call void @olang_textcopy(ptr %t306, ptr %t297, i64 %t298)
  %t307 = getelementptr i8, ptr %t306, i64 %t298
  call void @olang_textcopy(ptr %t307, ptr %t299, i64 %t300)
  %t308 = getelementptr i8, ptr %t307, i64 %t300
  call void @olang_textcopy(ptr %t308, ptr %t303, i64 %t304)
  %t309 = insertvalue { i64, ptr } undef, i64 %t305, 0
  %t310 = insertvalue { i64, ptr } %t309, ptr %t306, 1
  %t312 = extractvalue { i64, ptr } %t310, 0
  %t313 = extractvalue { i64, ptr } %t310, 1
  %t314 = mul i64 %t312, 1
  %t315 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t314)
  call void @llvm.memcpy.p0.p0.i64(ptr %t315, ptr %t313, i64 %t314, i1 false)
  %t316 = insertvalue { i64, ptr } undef, i64 %t312, 0
  %t317 = insertvalue { i64, ptr } %t316, ptr %t315, 1
  %t318 = load ptr, ptr %l198, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s13, ptr %t318, { i64, ptr } %t317)
  br label %bb78
bb78:
  store i1 false, ptr %l9, !tbaa !21
  call void @__olang_scope_close(ptr %s13)
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s12)
  br label %bb80
bb80:
  %t320 = load i64, ptr %l14, !tbaa !24
  %t322 = add i64 %t320, 1
  store i64 %t322, ptr %l14, !tbaa !24
  br label %bb64
bb81:
  br label %bb408
bb82:
  %t324 = load i32, ptr %l4
  %t326 = trunc i64 18 to i32
  %t327 = icmp eq i32 %t324, %t326
  br i1 %t327, label %bb83, label %bb84
bb83:
  br label %bb85
bb84:
  br label %bb99
bb85:
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t331 = getelementptr %"compiler/check:Checker", ptr %t329, i32 0, i32 5
  %t332 = load i1, ptr %t331, !tbaa !21
  br i1 %t332, label %bb86, label %bb87
bb86:
  store %olang.scope zeroinitializer, ptr %s18
  %t334 = load ptr, ptr %l1, !tbaa !29
  store ptr %t334, ptr %l213, !tbaa !29
  %t335 = load ptr, ptr %l0, !tbaa !29
  store ptr %t335, ptr %l214, !tbaa !29
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t338 = getelementptr %"compiler/check:Checker", ptr %t336, i32 0, i32 1
  %t339 = load ptr, ptr %t338, !tbaa !29
  %t341 = getelementptr %"compiler/generic:Program", ptr %t339, i32 0, i32 2
  store ptr %t341, ptr %l217, !tbaa !29
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t344 = getelementptr %"compiler/check:Checker", ptr %t342, i32 0, i32 1
  %t345 = load ptr, ptr %t344, !tbaa !29
  %t347 = getelementptr %"compiler/generic:Program", ptr %t345, i32 0, i32 2
  %t348 = load i32, ptr %l2, !tbaa !23
  %t351 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t347, i32 %t348)
  store i32 %t351, ptr %l222
  br label %bb88
bb87:
  br label %bb92
bb88:
  %t352 = load ptr, ptr %l217, !tbaa !29
  %t353 = load i32, ptr %l222, !tbaa !23
  %t354 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t352, i32 %t353)
  store i64 %t354, ptr %l223
  br label %bb89
bb89:
  %t355 = load ptr, ptr %l214, !tbaa !29
  %t356 = load i64, ptr %l223, !tbaa !24
  %t357 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2equalifierFor(ptr %v0, ptr %s18, ptr %t355, i64 %t356)
  store { i64, ptr } %t357, ptr %l224
  br label %bb90
bb90:
  %t358 = load { i64, ptr }, ptr %l224, !tbaa !27
  %t359 = extractvalue { i64, ptr } %t358, 0
  %t360 = extractvalue { i64, ptr } %t358, 1
  %t361 = mul i64 %t359, 1
  %t362 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t361)
  call void @llvm.memcpy.p0.p0.i64(ptr %t362, ptr %t360, i64 %t361, i1 false)
  %t363 = insertvalue { i64, ptr } undef, i64 %t359, 0
  %t364 = insertvalue { i64, ptr } %t363, ptr %t362, 1
  %t365 = load ptr, ptr %l213, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s18, ptr %t365, { i64, ptr } %t364)
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s18)
  br label %bb92
bb92:
  %t367 = load ptr, ptr %l1, !tbaa !29
  store ptr %t367, ptr %l226, !tbaa !29
  %t368 = load ptr, ptr %l0, !tbaa !29
  store ptr %t368, ptr %l227, !tbaa !29
  %t369 = load ptr, ptr %l0, !tbaa !29
  %t371 = getelementptr %"compiler/check:Checker", ptr %t369, i32 0, i32 1
  %t372 = load ptr, ptr %t371, !tbaa !29
  %t374 = getelementptr %"compiler/generic:Program", ptr %t372, i32 0, i32 2
  store ptr %t374, ptr %l230, !tbaa !29
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t377 = getelementptr %"compiler/check:Checker", ptr %t375, i32 0, i32 1
  %t378 = load ptr, ptr %t377, !tbaa !29
  %t380 = getelementptr %"compiler/generic:Program", ptr %t378, i32 0, i32 2
  %t381 = load i32, ptr %l2, !tbaa !23
  %t384 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t380, i32 %t381)
  store i32 %t384, ptr %l235
  br label %bb93
bb93:
  %t385 = load ptr, ptr %l230, !tbaa !29
  %t386 = load i32, ptr %l235, !tbaa !23
  %t387 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t385, i32 %t386)
  store i32 %t387, ptr %l236
  br label %bb94
bb94:
  %t388 = load ptr, ptr %l227, !tbaa !29
  %t389 = load i32, ptr %l236, !tbaa !23
  %t390 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t388, i32 %t389)
  store { i64, ptr } %t390, ptr %l237
  br label %bb95
bb95:
  %t391 = load ptr, ptr %l226, !tbaa !29
  %t392 = load { i64, ptr }, ptr %l237, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %v0, ptr %t391, { i64, ptr } %t392)
  br label %bb96
bb96:
  %t393 = load ptr, ptr %l0, !tbaa !29
  store ptr %t393, ptr %l238, !tbaa !29
  %t394 = load ptr, ptr %l1, !tbaa !29
  store ptr %t394, ptr %l239, !tbaa !29
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t397 = getelementptr %"compiler/check:Checker", ptr %t395, i32 0, i32 1
  %t398 = load ptr, ptr %t397, !tbaa !29
  %t400 = getelementptr %"compiler/generic:Program", ptr %t398, i32 0, i32 2
  %t401 = load i32, ptr %l2, !tbaa !23
  %t404 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t400, i32 %t401)
  store i32 %t404, ptr %l244
  br label %bb97
bb97:
  %t405 = load ptr, ptr %l238, !tbaa !29
  %t406 = load ptr, ptr %l239, !tbaa !29
  %t407 = load i32, ptr %l244, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espellArgs(ptr %v0, ptr %v1, ptr %t405, ptr %t406, i32 %t407)
  br label %bb98
bb98:
  br label %bb408
bb99:
  %t408 = load i32, ptr %l4
  %t410 = trunc i64 29 to i32
  %t411 = icmp eq i32 %t408, %t410
  br i1 %t411, label %bb100, label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb106
bb102:
  store %olang.scope zeroinitializer, ptr %s19
  %t413 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s19, ptr %t413, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d42, i32 0, i32 1) })
  br label %bb103
bb103:
  %t415 = load ptr, ptr %l0, !tbaa !29
  store ptr %t415, ptr %l248, !tbaa !29
  %t416 = load ptr, ptr %l1, !tbaa !29
  store ptr %t416, ptr %l249, !tbaa !29
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t419 = getelementptr %"compiler/check:Checker", ptr %t417, i32 0, i32 1
  %t420 = load ptr, ptr %t419, !tbaa !29
  %t422 = getelementptr %"compiler/generic:Program", ptr %t420, i32 0, i32 2
  %t423 = load i32, ptr %l2, !tbaa !23
  %t426 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t422, i32 %t423)
  store i32 %t426, ptr %l254
  br label %bb104
bb104:
  %t427 = load ptr, ptr %l248, !tbaa !29
  %t428 = load ptr, ptr %l249, !tbaa !29
  %t429 = load i32, ptr %l254, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %v1, ptr %t427, ptr %t428, i32 %t429, i1 false)
  br label %bb105
bb105:
  call void @__olang_scope_close(ptr %s19)
  br label %bb408
bb106:
  %t430 = load i32, ptr %l4
  %t432 = trunc i64 19 to i32
  %t433 = icmp eq i32 %t430, %t432
  br i1 %t433, label %bb107, label %bb108
bb107:
  br label %bb109
bb108:
  br label %bb114
bb109:
  store %olang.scope zeroinitializer, ptr %s20
  %t435 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s20, ptr %t435, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d43, i32 0, i32 1) })
  br label %bb110
bb110:
  %t437 = load ptr, ptr %l0, !tbaa !29
  %t439 = getelementptr %"compiler/check:Checker", ptr %t437, i32 0, i32 4
  %t440 = load i1, ptr %t439, !tbaa !21
  store i1 %t440, ptr %l16, !tbaa !21
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t444 = getelementptr %"compiler/check:Checker", ptr %t442, i32 0, i32 4
  store i1 true, ptr %t444, !tbaa !21
  %t445 = load ptr, ptr %l0, !tbaa !29
  store ptr %t445, ptr %l261, !tbaa !29
  %t446 = load ptr, ptr %l1, !tbaa !29
  store ptr %t446, ptr %l262, !tbaa !29
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t449 = getelementptr %"compiler/check:Checker", ptr %t447, i32 0, i32 1
  %t450 = load ptr, ptr %t449, !tbaa !29
  %t452 = getelementptr %"compiler/generic:Program", ptr %t450, i32 0, i32 2
  %t453 = load i32, ptr %l2, !tbaa !23
  %t456 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t452, i32 %t453)
  store i32 %t456, ptr %l267
  br label %bb111
bb111:
  %t457 = load ptr, ptr %l261, !tbaa !29
  %t458 = load ptr, ptr %l262, !tbaa !29
  %t459 = load i32, ptr %l267, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %v1, ptr %t457, ptr %t458, i32 %t459, i1 false)
  br label %bb112
bb112:
  %t460 = load ptr, ptr %l0, !tbaa !29
  %t461 = load i1, ptr %l16, !tbaa !21
  %t464 = getelementptr %"compiler/check:Checker", ptr %t460, i32 0, i32 4
  store i1 %t461, ptr %t464, !tbaa !21
  %t465 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t465, i8 62)
  br label %bb113
bb113:
  call void @__olang_scope_close(ptr %s20)
  br label %bb408
bb114:
  %t467 = load i32, ptr %l4
  %t469 = trunc i64 20 to i32
  %t470 = icmp eq i32 %t467, %t469
  br i1 %t470, label %bb115, label %bb116
bb115:
  br label %bb117
bb116:
  br label %bb136
bb117:
  store %olang.scope zeroinitializer, ptr %s21
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t474 = getelementptr %"compiler/check:Checker", ptr %t472, i32 0, i32 1
  %t475 = load ptr, ptr %t474, !tbaa !29
  %t477 = getelementptr %"compiler/generic:Program", ptr %t475, i32 0, i32 2
  %t478 = load i32, ptr %l2, !tbaa !23
  %t481 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t477, i32 %t478)
  store i64 %t481, ptr %l277
  br label %bb118
bb118:
  %t482 = load i64, ptr %l277, !tbaa !24
  store i64 %t482, ptr %l17, !tbaa !24
  %t483 = load i64, ptr %l17, !tbaa !24
  %t484 = load i64, ptr @G_2ecompiler_2ftypes_2eOwning, !tbaa !24
  %t487 = and i64 %t483, %t484
  %t489 = icmp ne i64 %t487, 0
  br i1 %t489, label %bb119, label %bb120
bb119:
  store %olang.scope zeroinitializer, ptr %s22
  %t491 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s22, ptr %t491, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d44, i32 0, i32 1) })
  br label %bb121
bb120:
  br label %bb122
bb121:
  call void @__olang_scope_close(ptr %s22)
  br label %bb122
bb122:
  %t495 = xor i1 %a3, true
  br i1 %t495, label %bb123, label %bb124
bb123:
  %t497 = load i64, ptr %l17, !tbaa !24
  %t498 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t501 = and i64 %t497, %t498
  %t503 = icmp ne i64 %t501, 0
  store i1 %t503, ptr %l285, !tbaa !21
  br label %bb125
bb124:
  store i1 false, ptr %l285, !tbaa !21
  br label %bb125
bb125:
  %t505 = load i1, ptr %l285, !tbaa !21
  br i1 %t505, label %bb126, label %bb127
bb126:
  store %olang.scope zeroinitializer, ptr %s23
  %t506 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s23, ptr %t506, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d45, i32 0, i32 1) })
  br label %bb128
bb127:
  br label %bb129
bb128:
  call void @__olang_scope_close(ptr %s23)
  br label %bb129
bb129:
  %t508 = load ptr, ptr %l0, !tbaa !29
  store ptr %t508, ptr %l291, !tbaa !29
  %t509 = load ptr, ptr %l1, !tbaa !29
  store ptr %t509, ptr %l292, !tbaa !29
  %t510 = load ptr, ptr %l0, !tbaa !29
  %t512 = getelementptr %"compiler/check:Checker", ptr %t510, i32 0, i32 1
  %t513 = load ptr, ptr %t512, !tbaa !29
  %t515 = getelementptr %"compiler/generic:Program", ptr %t513, i32 0, i32 2
  %t516 = load i32, ptr %l2, !tbaa !23
  %t519 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t515, i32 %t516)
  store i32 %t519, ptr %l297
  br label %bb130
bb130:
  %t520 = load ptr, ptr %l291, !tbaa !29
  %t521 = load ptr, ptr %l292, !tbaa !29
  %t522 = load i32, ptr %l297, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %v1, ptr %t520, ptr %t521, i32 %t522, i1 false)
  br label %bb131
bb131:
  %t523 = load ptr, ptr %l1, !tbaa !29
  store ptr %t523, ptr %l298, !tbaa !29
  %t524 = load i64, ptr %l17, !tbaa !24
  %t525 = load i64, ptr @G_2ecompiler_2ftypes_2eNullable, !tbaa !24
  %t528 = and i64 %t524, %t525
  %t530 = icmp ne i64 %t528, 0
  br i1 %t530, label %bb132, label %bb133
bb132:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d46, i32 0, i32 1) }, ptr %l303, !tbaa !27
  br label %bb134
bb133:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d47, i32 0, i32 1) }, ptr %l303, !tbaa !27
  br label %bb134
bb134:
  %t532 = load ptr, ptr %l298, !tbaa !29
  %t533 = load { i64, ptr }, ptr %l303, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s21, ptr %t532, { i64, ptr } %t533)
  br label %bb135
bb135:
  call void @__olang_scope_close(ptr %s21)
  br label %bb408
bb136:
  %t534 = load i32, ptr %l4
  %t536 = trunc i64 21 to i32
  %t537 = icmp eq i32 %t534, %t536
  br i1 %t537, label %bb137, label %bb138
bb137:
  br label %bb139
bb138:
  br label %bb294
bb139:
  store %olang.scope zeroinitializer, ptr %s24
  %t539 = load ptr, ptr %l0, !tbaa !29
  %t541 = getelementptr %"compiler/check:Checker", ptr %t539, i32 0, i32 1
  %t542 = load ptr, ptr %t541, !tbaa !29
  %t544 = getelementptr %"compiler/generic:Program", ptr %t542, i32 0, i32 2
  %t545 = load i32, ptr %l2, !tbaa !23
  %t548 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t544, i32 %t545)
  store i32 %t548, ptr %l310
  br label %bb140
bb140:
  %t549 = load i32, ptr %l310, !tbaa !23
  store i32 %t549, ptr %l18, !tbaa !23
  %t550 = load ptr, ptr %l0, !tbaa !29
  %t552 = getelementptr %"compiler/check:Checker", ptr %t550, i32 0, i32 1
  %t553 = load ptr, ptr %t552, !tbaa !29
  %t555 = getelementptr %"compiler/generic:Program", ptr %t553, i32 0, i32 2
  store ptr %t555, ptr %l313, !tbaa !29
  %t556 = load ptr, ptr %l0, !tbaa !29
  %t558 = getelementptr %"compiler/check:Checker", ptr %t556, i32 0, i32 1
  %t559 = load ptr, ptr %t558, !tbaa !29
  %t561 = getelementptr %"compiler/generic:Program", ptr %t559, i32 0, i32 2
  %t562 = load i32, ptr %l2, !tbaa !23
  %t565 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t561, i32 %t562)
  store i32 %t565, ptr %l318
  br label %bb141
bb141:
  %t566 = load ptr, ptr %l313, !tbaa !29
  %t567 = load i32, ptr %l318, !tbaa !23
  %t568 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t566, i32 %t567)
  store { i64, ptr } %t568, ptr %l319
  br label %bb142
bb142:
  %t569 = load { i64, ptr }, ptr %l319, !tbaa !27
  store { i64, ptr } %t569, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t570 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t570, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t572 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t574 = extractvalue { i64, ptr } %t572, 0
  store i64 %t574, ptr %l23, !tbaa !24
  br label %bb143
bb143:
  store %olang.scope zeroinitializer, ptr %s26
  %t576 = load i64, ptr %l22, !tbaa !24
  %t577 = load i64, ptr %l23, !tbaa !24
  %t580 = icmp slt i64 %t576, %t577
  %t582 = xor i1 %t580, true
  br i1 %t582, label %bb144, label %bb145
bb144:
  call void @__olang_scope_close(ptr %s26)
  br label %bb151
bb145:
  br label %bb146
bb146:
  %t584 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t584, ptr %l327, !tbaa !27
  %t585 = load i64, ptr %l22, !tbaa !24
  %t587 = getelementptr { i64, ptr }, ptr %l327, i32 0, i32 1
  %t588 = load ptr, ptr %t587, !tbaa !27
  %t589 = getelementptr i32, ptr %t588, i64 %t585
  %t590 = load i32, ptr %t589, !tbaa !33
  %t593 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  %t596 = icmp ne i32 %t590, %t593
  br i1 %t596, label %bb147, label %bb148
bb147:
  %t598 = load i64, ptr %l20, !tbaa !24
  %t600 = add i64 %t598, 1
  store i64 %t600, ptr %l20, !tbaa !24
  br label %bb149
bb148:
  br label %bb149
bb149:
  call void @__olang_scope_close(ptr %s26)
  br label %bb150
bb150:
  %t602 = load i64, ptr %l22, !tbaa !24
  %t604 = add i64 %t602, 1
  store i64 %t604, ptr %l22, !tbaa !24
  br label %bb143
bb151:
  %t606 = load ptr, ptr %l0, !tbaa !29
  %t608 = getelementptr %"compiler/check:Checker", ptr %t606, i32 0, i32 1
  %t609 = load ptr, ptr %t608, !tbaa !29
  %t611 = getelementptr %"compiler/generic:Program", ptr %t609, i32 0, i32 2
  %t612 = load i32, ptr %l18, !tbaa !23
  %t615 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t611, i32 %t612)
  store i32 %t615, ptr %l341
  br label %bb152
bb152:
  %t616 = load i32, ptr %l341
  %t618 = trunc i64 22 to i32
  %t619 = icmp eq i32 %t616, %t618
  br i1 %t619, label %bb153, label %bb154
bb153:
  %t621 = load ptr, ptr %l0, !tbaa !29
  %t623 = getelementptr %"compiler/check:Checker", ptr %t621, i32 0, i32 1
  %t624 = load ptr, ptr %t623, !tbaa !29
  %t626 = getelementptr %"compiler/generic:Program", ptr %t624, i32 0, i32 2
  store ptr %t626, ptr %l347, !tbaa !29
  %t627 = load ptr, ptr %l0, !tbaa !29
  %t629 = getelementptr %"compiler/check:Checker", ptr %t627, i32 0, i32 1
  %t630 = load ptr, ptr %t629, !tbaa !29
  %t632 = getelementptr %"compiler/generic:Program", ptr %t630, i32 0, i32 2
  %t633 = load i32, ptr %l18, !tbaa !23
  %t636 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t632, i32 %t633)
  store i32 %t636, ptr %l352
  br label %bb155
bb154:
  store i1 false, ptr %l344, !tbaa !21
  br label %bb157
bb155:
  %t637 = load ptr, ptr %l347, !tbaa !29
  %t638 = load i32, ptr %l352, !tbaa !23
  %t639 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t637, i32 %t638)
  store { i64, ptr } %t639, ptr %l353
  br label %bb156
bb156:
  %t640 = load { i64, ptr }, ptr %l353, !tbaa !27
  %t641 = extractvalue { i64, ptr } %t640, 0
  %t643 = icmp sgt i64 %t641, 1
  store i1 %t643, ptr %l344, !tbaa !21
  br label %bb157
bb157:
  %t645 = load i1, ptr %l344, !tbaa !21
  br i1 %t645, label %bb158, label %bb159
bb158:
  store i1 true, ptr %l356, !tbaa !21
  br label %bb160
bb159:
  %t646 = load i64, ptr %l20, !tbaa !24
  %t648 = icmp sgt i64 %t646, 1
  store i1 %t648, ptr %l356, !tbaa !21
  br label %bb160
bb160:
  %t650 = load i1, ptr %l356, !tbaa !21
  store i1 %t650, ptr %l25, !tbaa !21
  %t651 = load ptr, ptr %l0, !tbaa !29
  %t653 = getelementptr %"compiler/check:Checker", ptr %t651, i32 0, i32 7
  %t654 = load i1, ptr %t653, !tbaa !21
  br i1 %t654, label %bb161, label %bb162
bb161:
  store i1 true, ptr %l361, !tbaa !21
  br label %bb166
bb162:
  %t656 = load ptr, ptr %l0, !tbaa !29
  %t658 = getelementptr %"compiler/check:Checker", ptr %t656, i32 0, i32 4
  %t659 = load i1, ptr %t658, !tbaa !21
  br i1 %t659, label %bb163, label %bb164
bb163:
  %t661 = load i1, ptr %l25, !tbaa !21
  store i1 %t661, ptr %l364, !tbaa !21
  br label %bb165
bb164:
  store i1 false, ptr %l364, !tbaa !21
  br label %bb165
bb165:
  %t663 = load i1, ptr %l364, !tbaa !21
  store i1 %t663, ptr %l361, !tbaa !21
  br label %bb166
bb166:
  %t664 = load i1, ptr %l361, !tbaa !21
  store i1 %t664, ptr %l26, !tbaa !21
  %t665 = load ptr, ptr %l0, !tbaa !29
  %t667 = getelementptr %"compiler/check:Checker", ptr %t665, i32 0, i32 7
  store i1 false, ptr %t667, !tbaa !21
  %t668 = load ptr, ptr %l0, !tbaa !29
  %t670 = getelementptr %"compiler/check:Checker", ptr %t668, i32 0, i32 4
  %t671 = load i1, ptr %t670, !tbaa !21
  store i1 %t671, ptr %l27, !tbaa !21
  %t673 = load ptr, ptr %l0, !tbaa !29
  %t675 = getelementptr %"compiler/check:Checker", ptr %t673, i32 0, i32 4
  store i1 true, ptr %t675, !tbaa !21
  %t676 = load ptr, ptr %l1, !tbaa !29
  store ptr %t676, ptr %l370, !tbaa !29
  %t677 = load i1, ptr %l26, !tbaa !21
  br i1 %t677, label %bb167, label %bb168
bb167:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %l372, !tbaa !27
  br label %bb169
bb168:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d49, i32 0, i32 1) }, ptr %l372, !tbaa !27
  br label %bb169
bb169:
  %t679 = load ptr, ptr %l370, !tbaa !29
  %t680 = load { i64, ptr }, ptr %l372, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s24, ptr %t679, { i64, ptr } %t680)
  br label %bb170
bb170:
  %t681 = load ptr, ptr %l0, !tbaa !29
  %t683 = getelementptr %"compiler/check:Checker", ptr %t681, i32 0, i32 1
  %t684 = load ptr, ptr %t683, !tbaa !29
  %t686 = getelementptr %"compiler/generic:Program", ptr %t684, i32 0, i32 2
  store ptr %t686, ptr %l375, !tbaa !29
  %t687 = load ptr, ptr %l0, !tbaa !29
  %t689 = getelementptr %"compiler/check:Checker", ptr %t687, i32 0, i32 1
  %t690 = load ptr, ptr %t689, !tbaa !29
  %t692 = getelementptr %"compiler/generic:Program", ptr %t690, i32 0, i32 2
  %t693 = load i32, ptr %l2, !tbaa !23
  %t696 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t692, i32 %t693)
  store i32 %t696, ptr %l380
  br label %bb171
bb171:
  %t697 = load ptr, ptr %l375, !tbaa !29
  %t698 = load i32, ptr %l380, !tbaa !23
  %t699 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t697, i32 %t698)
  store { i64, ptr } %t699, ptr %l381
  br label %bb172
bb172:
  %t700 = load { i64, ptr }, ptr %l381, !tbaa !27
  store { i64, ptr } %t700, ptr %l28, !tbaa !27
  %t701 = load ptr, ptr %l0, !tbaa !29
  %t703 = getelementptr %"compiler/check:Checker", ptr %t701, i32 0, i32 1
  %t704 = load ptr, ptr %t703, !tbaa !29
  %t706 = getelementptr %"compiler/generic:Program", ptr %t704, i32 0, i32 2
  %t707 = load i32, ptr %l2, !tbaa !23
  %t710 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesOf(ptr %v0, ptr %t706, i32 %t707)
  store { i64, ptr } %t710, ptr %l386
  br label %bb173
bb173:
  %t711 = load { i64, ptr }, ptr %l386, !tbaa !27
  store { i64, ptr } %t711, ptr %l29, !tbaa !27
  store i64 0, ptr %l30, !tbaa !24
  %t712 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t714 = extractvalue { i64, ptr } %t712, 0
  store i64 %t714, ptr %l31, !tbaa !24
  store i64 1, ptr %l32, !tbaa !24
  %t716 = load i64, ptr %l31, !tbaa !24
  %t717 = load i64, ptr %l30, !tbaa !24
  %t720 = icmp sgt i64 %t716, %t717
  br i1 %t720, label %bb174, label %bb175
bb174:
  %t722 = load i64, ptr %l32, !tbaa !24
  %t724 = icmp sgt i64 %t722, 0
  br i1 %t724, label %bb176, label %bb177
bb175:
  store i64 0, ptr %l392, !tbaa !24
  br label %bb179
bb176:
  %t726 = load i64, ptr %l31, !tbaa !24
  %t727 = load i64, ptr %l30, !tbaa !24
  %t730 = sub i64 %t726, %t727
  %t731 = load i64, ptr %l32, !tbaa !24
  %t734 = add i64 %t730, %t731
  %t736 = sub i64 %t734, 1
  %t737 = load i64, ptr %l32, !tbaa !24
  %t740 = sdiv i64 %t736, %t737
  store i64 %t740, ptr %l395, !tbaa !24
  br label %bb178
bb177:
  store i64 0, ptr %l395, !tbaa !24
  br label %bb178
bb178:
  %t742 = load i64, ptr %l395, !tbaa !24
  store i64 %t742, ptr %l392, !tbaa !24
  br label %bb179
bb179:
  %t743 = load i64, ptr %l392, !tbaa !24
  store i64 %t743, ptr %l33, !tbaa !24
  store i64 0, ptr %l34, !tbaa !24
  br label %bb180
bb180:
  store %olang.scope zeroinitializer, ptr %s30
  %t744 = load i64, ptr %l34, !tbaa !24
  %t745 = load i64, ptr %l33, !tbaa !24
  %t748 = icmp slt i64 %t744, %t745
  %t750 = xor i1 %t748, true
  br i1 %t750, label %bb181, label %bb182
bb181:
  call void @__olang_scope_close(ptr %s30)
  br label %bb211
bb182:
  br label %bb183
bb183:
  %t752 = load i64, ptr %l30, !tbaa !24
  %t753 = load i64, ptr %l34, !tbaa !24
  %t754 = load i64, ptr %l32, !tbaa !24
  %t757 = mul i64 %t753, %t754
  %t760 = add i64 %t752, %t757
  store i64 %t760, ptr %l35, !tbaa !24
  %t762 = load i64, ptr %l35, !tbaa !24
  %t764 = icmp sgt i64 %t762, 0
  br i1 %t764, label %bb184, label %bb185
bb184:
  store %olang.scope zeroinitializer, ptr %s31
  %t766 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s31, ptr %t766, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d50, i32 0, i32 1) })
  br label %bb186
bb185:
  br label %bb187
bb186:
  call void @__olang_scope_close(ptr %s31)
  br label %bb187
bb187:
  %t768 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t770 = extractvalue { i64, ptr } %t768, 0
  %t771 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t773 = extractvalue { i64, ptr } %t771, 0
  %t776 = icmp eq i64 %t770, %t773
  br i1 %t776, label %bb188, label %bb189
bb188:
  %t778 = load ptr, ptr %l1, !tbaa !29
  store ptr %t778, ptr %l421, !tbaa !29
  %t779 = load ptr, ptr %l0, !tbaa !29
  %t780 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t780, ptr %l423, !tbaa !27
  %t781 = load i64, ptr %l35, !tbaa !24
  %t783 = getelementptr { i64, ptr }, ptr %l423, i32 0, i32 1
  %t784 = load ptr, ptr %t783, !tbaa !27
  %t785 = getelementptr i64, ptr %t784, i64 %t781
  %t786 = load i64, ptr %t785, !tbaa !34
  %t788 = trunc i64 %t786 to i32
  %t792 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t779, i32 %t788)
  store { i64, ptr } %t792, ptr %l428
  br label %bb190
bb189:
  br label %bb193
bb190:
  %t793 = load ptr, ptr %l421, !tbaa !29
  %t794 = load { i64, ptr }, ptr %l428, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %v0, ptr %t793, { i64, ptr } %t794)
  br label %bb191
bb191:
  %t795 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t795, i8 32)
  br label %bb192
bb192:
  br label %bb193
bb193:
  %t797 = load ptr, ptr %l0, !tbaa !29
  %t798 = load ptr, ptr %l1, !tbaa !29
  %t799 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t799, ptr %l432, !tbaa !27
  %t800 = load i64, ptr %l35, !tbaa !24
  %t802 = getelementptr { i64, ptr }, ptr %l432, i32 0, i32 1
  %t803 = load ptr, ptr %t802, !tbaa !27
  %t804 = getelementptr i32, ptr %t803, i64 %t800
  %t805 = load i32, ptr %t804, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %v1, ptr %t797, ptr %t798, i32 %t805, i1 false)
  br label %bb194
bb194:
  %t809 = load ptr, ptr %l0, !tbaa !29
  %t811 = getelementptr %"compiler/check:Checker", ptr %t809, i32 0, i32 1
  %t812 = load ptr, ptr %t811, !tbaa !29
  %t814 = getelementptr %"compiler/generic:Program", ptr %t812, i32 0, i32 2
  %t815 = load i32, ptr %l2, !tbaa !23
  %t816 = load i64, ptr %l35, !tbaa !24
  %t820 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t814, i32 %t815, i64 %t816)
  store i64 %t820, ptr %l440
  br label %bb195
bb195:
  %t821 = load i64, ptr %l440, !tbaa !24
  store i64 %t821, ptr %l36, !tbaa !24
  %t822 = load i64, ptr %l36, !tbaa !24
  %t824 = icmp sge i64 %t822, 0
  br i1 %t824, label %bb196, label %bb197
bb196:
  %t826 = load i64, ptr %l36, !tbaa !24
  %t827 = load i64, ptr %l35, !tbaa !24
  %t830 = icmp ne i64 %t826, %t827
  store i1 %t830, ptr %l443, !tbaa !21
  br label %bb198
bb197:
  store i1 false, ptr %l443, !tbaa !21
  br label %bb198
bb198:
  %t832 = load i1, ptr %l443, !tbaa !21
  br i1 %t832, label %bb199, label %bb200
bb199:
  %t833 = load i64, ptr %l36, !tbaa !24
  %t834 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t836 = extractvalue { i64, ptr } %t834, 0
  %t839 = icmp slt i64 %t833, %t836
  store i1 %t839, ptr %l447, !tbaa !21
  br label %bb201
bb200:
  store i1 false, ptr %l447, !tbaa !21
  br label %bb201
bb201:
  %t841 = load i1, ptr %l447, !tbaa !21
  br i1 %t841, label %bb202, label %bb203
bb202:
  %t842 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t844 = extractvalue { i64, ptr } %t842, 0
  %t845 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t847 = extractvalue { i64, ptr } %t845, 0
  %t850 = icmp eq i64 %t844, %t847
  store i1 %t850, ptr %l452, !tbaa !21
  br label %bb204
bb203:
  store i1 false, ptr %l452, !tbaa !21
  br label %bb204
bb204:
  %t852 = load i1, ptr %l452, !tbaa !21
  br i1 %t852, label %bb205, label %bb206
bb205:
  %t853 = load ptr, ptr %l1, !tbaa !29
  store ptr %t853, ptr %l458, !tbaa !29
  %t854 = load ptr, ptr %l0, !tbaa !29
  %t855 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t855, ptr %l460, !tbaa !27
  %t856 = load i64, ptr %l36, !tbaa !24
  %t858 = getelementptr { i64, ptr }, ptr %l460, i32 0, i32 1
  %t859 = load ptr, ptr %t858, !tbaa !27
  %t860 = getelementptr i64, ptr %t859, i64 %t856
  %t861 = load i64, ptr %t860, !tbaa !34
  %t863 = trunc i64 %t861 to i32
  %t867 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t854, i32 %t863)
  store { i64, ptr } %t867, ptr %l465
  br label %bb207
bb206:
  br label %bb209
bb207:
  %t868 = load ptr, ptr %l458, !tbaa !29
  %t869 = load { i64, ptr }, ptr %l465, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %v0, ptr %t868, { i64, ptr } %t869)
  br label %bb208
bb208:
  br label %bb209
bb209:
  call void @__olang_scope_close(ptr %s30)
  br label %bb210
bb210:
  %t870 = load i64, ptr %l34, !tbaa !24
  %t872 = add i64 %t870, 1
  store i64 %t872, ptr %l34, !tbaa !24
  br label %bb180
bb211:
  %t874 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t874, i8 41)
  br label %bb212
bb212:
  %t876 = load ptr, ptr %l0, !tbaa !29
  %t878 = getelementptr %"compiler/check:Checker", ptr %t876, i32 0, i32 1
  %t879 = load ptr, ptr %t878, !tbaa !29
  %t881 = getelementptr %"compiler/generic:Program", ptr %t879, i32 0, i32 2
  %t882 = load i32, ptr %l18, !tbaa !23
  %t885 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t881, i32 %t882)
  store i32 %t885, ptr %l473
  br label %bb213
bb213:
  %t886 = load i32, ptr %l473
  %t888 = trunc i64 22 to i32
  %t889 = icmp eq i32 %t886, %t888
  br i1 %t889, label %bb214, label %bb215
bb214:
  %t891 = load ptr, ptr %l0, !tbaa !29
  %t893 = getelementptr %"compiler/check:Checker", ptr %t891, i32 0, i32 1
  %t894 = load ptr, ptr %t893, !tbaa !29
  %t896 = getelementptr %"compiler/generic:Program", ptr %t894, i32 0, i32 2
  store ptr %t896, ptr %l478, !tbaa !29
  %t897 = load ptr, ptr %l0, !tbaa !29
  %t899 = getelementptr %"compiler/check:Checker", ptr %t897, i32 0, i32 1
  %t900 = load ptr, ptr %t899, !tbaa !29
  %t902 = getelementptr %"compiler/generic:Program", ptr %t900, i32 0, i32 2
  %t903 = load i32, ptr %l18, !tbaa !23
  %t906 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t902, i32 %t903)
  store i32 %t906, ptr %l483
  br label %bb216
bb215:
  %t907 = load i32, ptr %l18, !tbaa !23
  %t908 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t911 = icmp ne i32 %t907, %t908
  br i1 %t911, label %bb235, label %bb236
bb216:
  %t913 = load ptr, ptr %l478, !tbaa !29
  %t914 = load i32, ptr %l483, !tbaa !23
  %t915 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t913, i32 %t914)
  store { i64, ptr } %t915, ptr %l484
  br label %bb217
bb217:
  %t916 = load { i64, ptr }, ptr %l484, !tbaa !27
  store { i64, ptr } %t916, ptr %l37, !tbaa !27
  store i64 0, ptr %l38, !tbaa !24
  %t917 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t919 = extractvalue { i64, ptr } %t917, 0
  store i64 %t919, ptr %l39, !tbaa !24
  store i64 1, ptr %l40, !tbaa !24
  %t921 = load i64, ptr %l39, !tbaa !24
  %t922 = load i64, ptr %l38, !tbaa !24
  %t925 = icmp sgt i64 %t921, %t922
  br i1 %t925, label %bb218, label %bb219
bb218:
  %t927 = load i64, ptr %l40, !tbaa !24
  %t929 = icmp sgt i64 %t927, 0
  br i1 %t929, label %bb220, label %bb221
bb219:
  store i64 0, ptr %l490, !tbaa !24
  br label %bb223
bb220:
  %t931 = load i64, ptr %l39, !tbaa !24
  %t932 = load i64, ptr %l38, !tbaa !24
  %t935 = sub i64 %t931, %t932
  %t936 = load i64, ptr %l40, !tbaa !24
  %t939 = add i64 %t935, %t936
  %t941 = sub i64 %t939, 1
  %t942 = load i64, ptr %l40, !tbaa !24
  %t945 = sdiv i64 %t941, %t942
  store i64 %t945, ptr %l493, !tbaa !24
  br label %bb222
bb221:
  store i64 0, ptr %l493, !tbaa !24
  br label %bb222
bb222:
  %t947 = load i64, ptr %l493, !tbaa !24
  store i64 %t947, ptr %l490, !tbaa !24
  br label %bb223
bb223:
  %t948 = load i64, ptr %l490, !tbaa !24
  store i64 %t948, ptr %l41, !tbaa !24
  store i64 0, ptr %l42, !tbaa !24
  br label %bb224
bb224:
  store %olang.scope zeroinitializer, ptr %s37
  %t949 = load i64, ptr %l42, !tbaa !24
  %t950 = load i64, ptr %l41, !tbaa !24
  %t953 = icmp slt i64 %t949, %t950
  %t955 = xor i1 %t953, true
  br i1 %t955, label %bb225, label %bb226
bb225:
  call void @__olang_scope_close(ptr %s37)
  br label %bb234
bb226:
  br label %bb227
bb227:
  %t957 = load i64, ptr %l38, !tbaa !24
  %t958 = load i64, ptr %l42, !tbaa !24
  %t959 = load i64, ptr %l40, !tbaa !24
  %t962 = mul i64 %t958, %t959
  %t965 = add i64 %t957, %t962
  store i64 %t965, ptr %l43, !tbaa !24
  %t967 = load ptr, ptr %l1, !tbaa !29
  store ptr %t967, ptr %l511, !tbaa !29
  %t968 = load i64, ptr %l43, !tbaa !24
  %t970 = icmp sgt i64 %t968, 0
  br i1 %t970, label %bb228, label %bb229
bb228:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d51, i32 0, i32 1) }, ptr %l514, !tbaa !27
  br label %bb230
bb229:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, ptr %l514, !tbaa !27
  br label %bb230
bb230:
  %t972 = load ptr, ptr %l511, !tbaa !29
  %t973 = load { i64, ptr }, ptr %l514, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s37, ptr %t972, { i64, ptr } %t973)
  br label %bb231
bb231:
  %t974 = load ptr, ptr %l0, !tbaa !29
  %t975 = load ptr, ptr %l1, !tbaa !29
  %t976 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t976, ptr %l517, !tbaa !27
  %t977 = load i64, ptr %l43, !tbaa !24
  %t979 = getelementptr { i64, ptr }, ptr %l517, i32 0, i32 1
  %t980 = load ptr, ptr %t979, !tbaa !27
  %t981 = getelementptr i32, ptr %t980, i64 %t977
  %t982 = load i32, ptr %t981, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %v1, ptr %t974, ptr %t975, i32 %t982, i1 false)
  br label %bb232
bb232:
  call void @__olang_scope_close(ptr %s37)
  br label %bb233
bb233:
  %t986 = load i64, ptr %l42, !tbaa !24
  %t988 = add i64 %t986, 1
  store i64 %t988, ptr %l42, !tbaa !24
  br label %bb224
bb234:
  br label %bb271
bb235:
  %t990 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t990, i8 32)
  br label %bb237
bb236:
  br label %bb270
bb237:
  %t992 = load ptr, ptr %l0, !tbaa !29
  %t994 = getelementptr %"compiler/check:Checker", ptr %t992, i32 0, i32 1
  %t995 = load ptr, ptr %t994, !tbaa !29
  %t997 = getelementptr %"compiler/generic:Program", ptr %t995, i32 0, i32 2
  %t998 = load i32, ptr %l18, !tbaa !23
  %t1001 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t997, i32 %t998)
  store i32 %t1001, ptr %l530
  br label %bb238
bb238:
  %t1002 = load i32, ptr %l530
  %t1004 = trunc i64 20 to i32
  %t1005 = icmp eq i32 %t1002, %t1004
  br i1 %t1005, label %bb239, label %bb240
bb239:
  %t1007 = load ptr, ptr %l0, !tbaa !29
  %t1009 = getelementptr %"compiler/check:Checker", ptr %t1007, i32 0, i32 1
  %t1010 = load ptr, ptr %t1009, !tbaa !29
  %t1012 = getelementptr %"compiler/generic:Program", ptr %t1010, i32 0, i32 2
  %t1013 = load i32, ptr %l2, !tbaa !23
  %t1016 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t1012, i32 %t1013, i64 0)
  store i64 %t1016, ptr %l538
  br label %bb241
bb240:
  %t1017 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  store i64 %t1017, ptr %l533, !tbaa !24
  br label %bb242
bb241:
  %t1019 = load i64, ptr %l538, !tbaa !24
  store i64 %t1019, ptr %l533, !tbaa !24
  br label %bb242
bb242:
  %t1020 = load i64, ptr %l533, !tbaa !24
  store i64 %t1020, ptr %l44, !tbaa !24
  %t1021 = load i64, ptr %l44, !tbaa !24
  %t1022 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t1025 = icmp eq i64 %t1021, %t1022
  br i1 %t1025, label %bb243, label %bb244
bb243:
  %t1027 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1027, ptr %l543, !tbaa !29
  %t1028 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1028, ptr %l544, !tbaa !29
  %t1029 = load ptr, ptr %l0, !tbaa !29
  %t1031 = getelementptr %"compiler/check:Checker", ptr %t1029, i32 0, i32 1
  %t1032 = load ptr, ptr %t1031, !tbaa !29
  %t1034 = getelementptr %"compiler/generic:Program", ptr %t1032, i32 0, i32 2
  store ptr %t1034, ptr %l547, !tbaa !29
  %t1035 = load ptr, ptr %l0, !tbaa !29
  %t1037 = getelementptr %"compiler/check:Checker", ptr %t1035, i32 0, i32 1
  %t1038 = load ptr, ptr %t1037, !tbaa !29
  %t1040 = getelementptr %"compiler/generic:Program", ptr %t1038, i32 0, i32 2
  %t1041 = load i32, ptr %l18, !tbaa !23
  %t1044 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t1040, i32 %t1041)
  store i32 %t1044, ptr %l552
  br label %bb245
bb244:
  %t1045 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1045, ptr %l555, !tbaa !29
  %t1046 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t1048 = extractvalue { i64, ptr } %t1046, 0
  %t1050 = icmp sgt i64 %t1048, 0
  br i1 %t1050, label %bb248, label %bb249
bb245:
  %t1052 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t1053 = load ptr, ptr %l547, !tbaa !29
  %t1054 = load i32, ptr %l552, !tbaa !23
  %t1056 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t1053, i32 %t1054, i64 %t1052)
  store i32 %t1056, ptr %l554
  br label %bb246
bb246:
  %t1057 = load ptr, ptr %l543, !tbaa !29
  %t1058 = load ptr, ptr %l544, !tbaa !29
  %t1059 = load i32, ptr %l554, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %v1, ptr %t1057, ptr %t1058, i32 %t1059, i1 false)
  br label %bb247
bb247:
  br label %bb269
bb248:
  %t1060 = load ptr, ptr %l0, !tbaa !29
  %t1062 = getelementptr %"compiler/check:Checker", ptr %t1060, i32 0, i32 1
  %t1063 = load ptr, ptr %t1062, !tbaa !29
  %t1065 = getelementptr %"compiler/generic:Program", ptr %t1063, i32 0, i32 2
  %t1066 = load i32, ptr %l18, !tbaa !23
  %t1069 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1065, i32 %t1066)
  store i32 %t1069, ptr %l564
  br label %bb250
bb249:
  store i1 false, ptr %l559, !tbaa !21
  br label %bb251
bb250:
  %t1070 = load i32, ptr %l564
  %t1072 = trunc i64 21 to i32
  %t1073 = icmp eq i32 %t1070, %t1072
  store i1 %t1073, ptr %l559, !tbaa !21
  br label %bb251
bb251:
  %t1075 = load i1, ptr %l559, !tbaa !21
  br i1 %t1075, label %bb252, label %bb253
bb252:
  %t1076 = load ptr, ptr %l0, !tbaa !29
  %t1078 = getelementptr %"compiler/check:Checker", ptr %t1076, i32 0, i32 1
  %t1079 = load ptr, ptr %t1078, !tbaa !29
  %t1081 = getelementptr %"compiler/generic:Program", ptr %t1079, i32 0, i32 2
  store ptr %t1081, ptr %l570, !tbaa !29
  %t1082 = load ptr, ptr %l0, !tbaa !29
  %t1084 = getelementptr %"compiler/check:Checker", ptr %t1082, i32 0, i32 1
  %t1085 = load ptr, ptr %t1084, !tbaa !29
  %t1087 = getelementptr %"compiler/generic:Program", ptr %t1085, i32 0, i32 2
  %t1088 = load i32, ptr %l18, !tbaa !23
  %t1091 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t1087, i32 %t1088)
  store i32 %t1091, ptr %l575
  br label %bb254
bb253:
  store i1 false, ptr %l567, !tbaa !21
  br label %bb256
bb254:
  %t1092 = load ptr, ptr %l570, !tbaa !29
  %t1093 = load i32, ptr %l575, !tbaa !23
  %t1094 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t1092, i32 %t1093)
  store { i64, ptr } %t1094, ptr %l576
  br label %bb255
bb255:
  %t1095 = load { i64, ptr }, ptr %l576, !tbaa !27
  %t1096 = extractvalue { i64, ptr } %t1095, 0
  %t1098 = icmp eq i64 %t1096, 0
  store i1 %t1098, ptr %l567, !tbaa !21
  br label %bb256
bb256:
  %t1100 = load i1, ptr %l567, !tbaa !21
  %t1101 = load ptr, ptr %l555, !tbaa !29
  %t1102 = getelementptr %"compiler/check:Checker", ptr %t1101, i32 0, i32 7
  store i1 %t1100, ptr %t1102, !tbaa !21
  %t1103 = load ptr, ptr %l0, !tbaa !29
  %t1104 = load ptr, ptr %l1, !tbaa !29
  %t1105 = load i32, ptr %l18, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %v1, ptr %t1103, ptr %t1104, i32 %t1105, i1 false)
  br label %bb257
bb257:
  %t1109 = load ptr, ptr %l0, !tbaa !29
  %t1111 = getelementptr %"compiler/check:Checker", ptr %t1109, i32 0, i32 7
  store i1 false, ptr %t1111, !tbaa !21
  %t1112 = load i64, ptr %l44, !tbaa !24
  %t1114 = icmp sge i64 %t1112, 0
  br i1 %t1114, label %bb258, label %bb259
bb258:
  %t1116 = load i64, ptr %l44, !tbaa !24
  %t1117 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t1119 = extractvalue { i64, ptr } %t1117, 0
  %t1122 = icmp slt i64 %t1116, %t1119
  store i1 %t1122, ptr %l585, !tbaa !21
  br label %bb260
bb259:
  store i1 false, ptr %l585, !tbaa !21
  br label %bb260
bb260:
  %t1124 = load i1, ptr %l585, !tbaa !21
  br i1 %t1124, label %bb261, label %bb262
bb261:
  %t1125 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t1127 = extractvalue { i64, ptr } %t1125, 0
  %t1128 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t1130 = extractvalue { i64, ptr } %t1128, 0
  %t1133 = icmp eq i64 %t1127, %t1130
  store i1 %t1133, ptr %l590, !tbaa !21
  br label %bb263
bb262:
  store i1 false, ptr %l590, !tbaa !21
  br label %bb263
bb263:
  %t1135 = load i1, ptr %l590, !tbaa !21
  br i1 %t1135, label %bb264, label %bb265
bb264:
  %t1136 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1136, ptr %l596, !tbaa !29
  %t1137 = load ptr, ptr %l0, !tbaa !29
  %t1138 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t1138, ptr %l598, !tbaa !27
  %t1139 = load i64, ptr %l44, !tbaa !24
  %t1141 = getelementptr { i64, ptr }, ptr %l598, i32 0, i32 1
  %t1142 = load ptr, ptr %t1141, !tbaa !27
  %t1143 = getelementptr i64, ptr %t1142, i64 %t1139
  %t1144 = load i64, ptr %t1143, !tbaa !34
  %t1146 = trunc i64 %t1144 to i32
  %t1150 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t1137, i32 %t1146)
  store { i64, ptr } %t1150, ptr %l603
  br label %bb266
bb265:
  br label %bb268
bb266:
  %t1151 = load ptr, ptr %l596, !tbaa !29
  %t1152 = load { i64, ptr }, ptr %l603, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %v0, ptr %t1151, { i64, ptr } %t1152)
  br label %bb267
bb267:
  br label %bb268
bb268:
  br label %bb269
bb269:
  br label %bb270
bb270:
  br label %bb271
bb271:
  %t1153 = load ptr, ptr %l0, !tbaa !29
  %t1154 = load i1, ptr %l27, !tbaa !21
  %t1157 = getelementptr %"compiler/check:Checker", ptr %t1153, i32 0, i32 4
  store i1 %t1154, ptr %t1157, !tbaa !21
  %t1158 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t1160 = extractvalue { i64, ptr } %t1158, 0
  %t1162 = icmp sgt i64 %t1160, 0
  br i1 %t1162, label %bb272, label %bb273
bb272:
  store %olang.scope zeroinitializer, ptr %s44
  %t1164 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s44, ptr %t1164, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d53, i32 0, i32 1) })
  br label %bb274
bb273:
  br label %bb289
bb274:
  store i64 0, ptr %l45, !tbaa !24
  %t1166 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t1166, ptr %l46, !tbaa !27
  store i64 0, ptr %l47, !tbaa !24
  %t1168 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t1170 = extractvalue { i64, ptr } %t1168, 0
  store i64 %t1170, ptr %l48, !tbaa !24
  br label %bb275
bb275:
  store %olang.scope zeroinitializer, ptr %s46
  %t1172 = load i64, ptr %l47, !tbaa !24
  %t1173 = load i64, ptr %l48, !tbaa !24
  %t1176 = icmp slt i64 %t1172, %t1173
  %t1178 = xor i1 %t1176, true
  br i1 %t1178, label %bb276, label %bb277
bb276:
  call void @__olang_scope_close(ptr %s46)
  br label %bb288
bb277:
  br label %bb278
bb278:
  %t1180 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t1180, ptr %l617, !tbaa !27
  %t1181 = load i64, ptr %l47, !tbaa !24
  %t1183 = getelementptr { i64, ptr }, ptr %l617, i32 0, i32 1
  %t1184 = load ptr, ptr %t1183, !tbaa !27
  %t1185 = getelementptr i32, ptr %t1184, i64 %t1181
  %t1186 = load i32, ptr %t1185, !tbaa !33
  store i32 %t1186, ptr %l49, !tbaa !23
  %t1188 = load i32, ptr %l49, !tbaa !23
  %t1189 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  %t1192 = icmp eq i32 %t1188, %t1189
  br i1 %t1192, label %bb279, label %bb280
bb279:
  call void @__olang_scope_close(ptr %s46)
  br label %bb287
bb280:
  br label %bb281
bb281:
  %t1194 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1194, ptr %l623, !tbaa !29
  %t1195 = load i64, ptr %l45, !tbaa !24
  %t1197 = icmp eq i64 %t1195, 0
  br i1 %t1197, label %bb282, label %bb283
bb282:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d54, i32 0, i32 1) }, ptr %l626, !tbaa !27
  br label %bb284
bb283:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %l626, !tbaa !27
  br label %bb284
bb284:
  %t1199 = load ptr, ptr %l623, !tbaa !29
  %t1200 = load { i64, ptr }, ptr %l626, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s46, ptr %t1199, { i64, ptr } %t1200)
  br label %bb285
bb285:
  %t1201 = load ptr, ptr %l0, !tbaa !29
  %t1202 = load ptr, ptr %l1, !tbaa !29
  %t1203 = load i32, ptr %l49, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %v1, ptr %t1201, ptr %t1202, i32 %t1203, i1 false)
  br label %bb286
bb286:
  %t1207 = load i64, ptr %l45, !tbaa !24
  %t1209 = add i64 %t1207, 1
  store i64 %t1209, ptr %l45, !tbaa !24
  call void @__olang_scope_close(ptr %s46)
  br label %bb287
bb287:
  %t1211 = load i64, ptr %l47, !tbaa !24
  %t1213 = add i64 %t1211, 1
  store i64 %t1213, ptr %l47, !tbaa !24
  br label %bb275
bb288:
  call void @__olang_scope_close(ptr %s44)
  br label %bb289
bb289:
  %t1215 = load i1, ptr %l26, !tbaa !21
  br i1 %t1215, label %bb290, label %bb291
bb290:
  %t1217 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t1217, i8 41)
  br label %bb292
bb291:
  br label %bb293
bb292:
  br label %bb293
bb293:
  call void @__olang_scope_close(ptr %s24)
  br label %bb408
bb294:
  %t1219 = load i32, ptr %l4
  %t1221 = trunc i64 22 to i32
  %t1222 = icmp eq i32 %t1219, %t1221
  br i1 %t1222, label %bb295, label %bb296
bb295:
  br label %bb297
bb296:
  br label %bb300
bb297:
  store %olang.scope zeroinitializer, ptr %s50
  %t1224 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1224, ptr %l638, !tbaa !29
  %t1225 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1225, ptr %l639, !tbaa !29
  %t1226 = load ptr, ptr %l0, !tbaa !29
  %t1228 = getelementptr %"compiler/check:Checker", ptr %t1226, i32 0, i32 1
  %t1229 = load ptr, ptr %t1228, !tbaa !29
  %t1231 = getelementptr %"compiler/generic:Program", ptr %t1229, i32 0, i32 2
  %t1232 = load i32, ptr %l2, !tbaa !23
  %t1235 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t1231, i32 %t1232)
  store i32 %t1235, ptr %l644
  br label %bb298
bb298:
  %t1236 = load ptr, ptr %l638, !tbaa !29
  %t1237 = load ptr, ptr %l639, !tbaa !29
  %t1238 = load i32, ptr %l644, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espellList(ptr %v0, ptr %v1, ptr %s50, ptr %s50, ptr %t1236, ptr %t1237, i32 %t1238, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d57, i32 0, i32 1) })
  br label %bb299
bb299:
  call void @__olang_scope_close(ptr %s50)
  br label %bb408
bb300:
  %t1239 = load i32, ptr %l4
  %t1241 = trunc i64 24 to i32
  %t1242 = icmp eq i32 %t1239, %t1241
  br i1 %t1242, label %bb301, label %bb302
bb301:
  br label %bb303
bb302:
  br label %bb363
bb303:
  store %olang.scope zeroinitializer, ptr %s51
  %t1244 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s51, ptr %t1244, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d58, i32 0, i32 1) })
  br label %bb304
bb304:
  %t1246 = load ptr, ptr %l0, !tbaa !29
  %t1248 = getelementptr %"compiler/check:Checker", ptr %t1246, i32 0, i32 1
  %t1249 = load ptr, ptr %t1248, !tbaa !29
  %t1251 = getelementptr %"compiler/generic:Program", ptr %t1249, i32 0, i32 2
  %t1252 = load i32, ptr %l2, !tbaa !23
  %t1255 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeNames(ptr %v0, ptr %t1251, i32 %t1252)
  store { i64, ptr } %t1255, ptr %l652
  br label %bb305
bb305:
  %t1256 = load { i64, ptr }, ptr %l652, !tbaa !27
  store { i64, ptr } %t1256, ptr %l50, !tbaa !27
  %t1257 = load ptr, ptr %l0, !tbaa !29
  %t1259 = getelementptr %"compiler/check:Checker", ptr %t1257, i32 0, i32 1
  %t1260 = load ptr, ptr %t1259, !tbaa !29
  %t1262 = getelementptr %"compiler/generic:Program", ptr %t1260, i32 0, i32 2
  store ptr %t1262, ptr %l655, !tbaa !29
  %t1263 = load ptr, ptr %l0, !tbaa !29
  %t1265 = getelementptr %"compiler/check:Checker", ptr %t1263, i32 0, i32 1
  %t1266 = load ptr, ptr %t1265, !tbaa !29
  %t1268 = getelementptr %"compiler/generic:Program", ptr %t1266, i32 0, i32 2
  %t1269 = load i32, ptr %l2, !tbaa !23
  %t1272 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t1268, i32 %t1269)
  store i32 %t1272, ptr %l660
  br label %bb306
bb306:
  %t1273 = load ptr, ptr %l655, !tbaa !29
  %t1274 = load i32, ptr %l660, !tbaa !23
  %t1275 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t1273, i32 %t1274)
  store { i64, ptr } %t1275, ptr %l661
  br label %bb307
bb307:
  %t1276 = load { i64, ptr }, ptr %l661, !tbaa !27
  store { i64, ptr } %t1276, ptr %l51, !tbaa !27
  %t1277 = load ptr, ptr %l0, !tbaa !29
  %t1279 = getelementptr %"compiler/check:Checker", ptr %t1277, i32 0, i32 1
  %t1280 = load ptr, ptr %t1279, !tbaa !29
  %t1282 = getelementptr %"compiler/generic:Program", ptr %t1280, i32 0, i32 2
  %t1283 = load i32, ptr %l2, !tbaa !23
  %t1286 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeFields(ptr %v0, ptr %t1282, i32 %t1283)
  store { i64, ptr } %t1286, ptr %l666
  br label %bb308
bb308:
  %t1287 = load { i64, ptr }, ptr %l666, !tbaa !27
  store { i64, ptr } %t1287, ptr %l52, !tbaa !27
  store i64 0, ptr %l53, !tbaa !24
  store i64 0, ptr %l54, !tbaa !24
  %t1288 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t1290 = extractvalue { i64, ptr } %t1288, 0
  store i64 %t1290, ptr %l55, !tbaa !24
  store i64 1, ptr %l56, !tbaa !24
  %t1292 = load i64, ptr %l55, !tbaa !24
  %t1293 = load i64, ptr %l54, !tbaa !24
  %t1296 = icmp sgt i64 %t1292, %t1293
  br i1 %t1296, label %bb309, label %bb310
bb309:
  %t1298 = load i64, ptr %l56, !tbaa !24
  %t1300 = icmp sgt i64 %t1298, 0
  br i1 %t1300, label %bb311, label %bb312
bb310:
  store i64 0, ptr %l672, !tbaa !24
  br label %bb314
bb311:
  %t1302 = load i64, ptr %l55, !tbaa !24
  %t1303 = load i64, ptr %l54, !tbaa !24
  %t1306 = sub i64 %t1302, %t1303
  %t1307 = load i64, ptr %l56, !tbaa !24
  %t1310 = add i64 %t1306, %t1307
  %t1312 = sub i64 %t1310, 1
  %t1313 = load i64, ptr %l56, !tbaa !24
  %t1316 = sdiv i64 %t1312, %t1313
  store i64 %t1316, ptr %l675, !tbaa !24
  br label %bb313
bb312:
  store i64 0, ptr %l675, !tbaa !24
  br label %bb313
bb313:
  %t1318 = load i64, ptr %l675, !tbaa !24
  store i64 %t1318, ptr %l672, !tbaa !24
  br label %bb314
bb314:
  %t1319 = load i64, ptr %l672, !tbaa !24
  store i64 %t1319, ptr %l57, !tbaa !24
  store i64 0, ptr %l58, !tbaa !24
  br label %bb315
bb315:
  store %olang.scope zeroinitializer, ptr %s53
  %t1320 = load i64, ptr %l58, !tbaa !24
  %t1321 = load i64, ptr %l57, !tbaa !24
  %t1324 = icmp slt i64 %t1320, %t1321
  %t1326 = xor i1 %t1324, true
  br i1 %t1326, label %bb316, label %bb317
bb316:
  call void @__olang_scope_close(ptr %s53)
  br label %bb361
bb317:
  br label %bb318
bb318:
  %t1328 = load i64, ptr %l54, !tbaa !24
  %t1329 = load i64, ptr %l58, !tbaa !24
  %t1330 = load i64, ptr %l56, !tbaa !24
  %t1333 = mul i64 %t1329, %t1330
  %t1336 = add i64 %t1328, %t1333
  store i64 %t1336, ptr %l59, !tbaa !24
  %t1338 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t1338, i8 32)
  br label %bb319
bb319:
  %t1340 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1340, ptr %l694, !tbaa !29
  %t1341 = load ptr, ptr %l0, !tbaa !29
  %t1342 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t1342, ptr %l696, !tbaa !27
  %t1343 = load i64, ptr %l59, !tbaa !24
  %t1345 = getelementptr { i64, ptr }, ptr %l696, i32 0, i32 1
  %t1346 = load ptr, ptr %t1345, !tbaa !27
  %t1347 = getelementptr i32, ptr %t1346, i64 %t1343
  %t1348 = load i32, ptr %t1347, !tbaa !33
  %t1351 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t1341, i32 %t1348)
  store { i64, ptr } %t1351, ptr %l699
  br label %bb320
bb320:
  %t1352 = load ptr, ptr %l694, !tbaa !29
  %t1353 = load { i64, ptr }, ptr %l699, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %v0, ptr %t1352, { i64, ptr } %t1353)
  br label %bb321
bb321:
  %t1354 = load i64, ptr %l59, !tbaa !24
  %t1355 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t1357 = extractvalue { i64, ptr } %t1355, 0
  %t1360 = icmp sge i64 %t1354, %t1357
  br i1 %t1360, label %bb322, label %bb323
bb322:
  store i1 true, ptr %l704, !tbaa !21
  br label %bb324
bb323:
  %t1362 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t1362, ptr %l705, !tbaa !27
  %t1363 = load i64, ptr %l59, !tbaa !24
  %t1365 = getelementptr { i64, ptr }, ptr %l705, i32 0, i32 1
  %t1366 = load ptr, ptr %t1365, !tbaa !27
  %t1367 = getelementptr i32, ptr %t1366, i64 %t1363
  %t1368 = load i32, ptr %t1367, !tbaa !33
  %t1370 = icmp eq i32 %t1368, 0
  store i1 %t1370, ptr %l704, !tbaa !21
  br label %bb324
bb324:
  %t1372 = load i1, ptr %l704, !tbaa !21
  br i1 %t1372, label %bb325, label %bb326
bb325:
  call void @__olang_scope_close(ptr %s53)
  br label %bb360
bb326:
  br label %bb327
bb327:
  %t1373 = load ptr, ptr %l0, !tbaa !29
  %t1375 = getelementptr %"compiler/check:Checker", ptr %t1373, i32 0, i32 1
  %t1376 = load ptr, ptr %t1375, !tbaa !29
  %t1378 = getelementptr %"compiler/generic:Program", ptr %t1376, i32 0, i32 2
  store ptr %t1378, ptr %l711, !tbaa !29
  %t1379 = load ptr, ptr %l0, !tbaa !29
  %t1381 = getelementptr %"compiler/check:Checker", ptr %t1379, i32 0, i32 1
  %t1382 = load ptr, ptr %t1381, !tbaa !29
  %t1384 = getelementptr %"compiler/generic:Program", ptr %t1382, i32 0, i32 2
  %t1385 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t1385, ptr %l715, !tbaa !27
  %t1386 = load i64, ptr %l59, !tbaa !24
  %t1388 = getelementptr { i64, ptr }, ptr %l715, i32 0, i32 1
  %t1389 = load ptr, ptr %t1388, !tbaa !27
  %t1390 = getelementptr i32, ptr %t1389, i64 %t1386
  %t1391 = load i32, ptr %t1390, !tbaa !33
  %t1394 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t1384, i32 %t1391)
  store i32 %t1394, ptr %l718
  br label %bb328
bb328:
  %t1395 = load ptr, ptr %l711, !tbaa !29
  %t1396 = load i32, ptr %l718, !tbaa !23
  %t1397 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t1395, i32 %t1396)
  store { i64, ptr } %t1397, ptr %l719
  br label %bb329
bb329:
  %t1398 = load { i64, ptr }, ptr %l719, !tbaa !27
  store { i64, ptr } %t1398, ptr %l60, !tbaa !27
  %t1399 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t1401 = extractvalue { i64, ptr } %t1399, 0
  %t1403 = icmp eq i64 %t1401, 0
  br i1 %t1403, label %bb330, label %bb331
bb330:
  call void @__olang_scope_close(ptr %s53)
  br label %bb360
bb331:
  br label %bb332
bb332:
  %t1405 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t1407 = extractvalue { i64, ptr } %t1405, 0
  %t1408 = load i64, ptr %l53, !tbaa !24
  %t1409 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t1411 = extractvalue { i64, ptr } %t1409, 0
  %t1414 = add i64 %t1408, %t1411
  %t1417 = icmp slt i64 %t1407, %t1414
  br i1 %t1417, label %bb333, label %bb334
bb333:
  store %olang.scope zeroinitializer, ptr %s56
  %t1419 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1419, ptr %l730, !tbaa !29
  %t1420 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1420, ptr %l731, !tbaa !29
  %t1421 = load ptr, ptr %l0, !tbaa !29
  %t1423 = getelementptr %"compiler/check:Checker", ptr %t1421, i32 0, i32 1
  %t1424 = load ptr, ptr %t1423, !tbaa !29
  %t1426 = getelementptr %"compiler/generic:Program", ptr %t1424, i32 0, i32 2
  %t1427 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t1427, ptr %l735, !tbaa !27
  %t1428 = load i64, ptr %l59, !tbaa !24
  %t1430 = getelementptr { i64, ptr }, ptr %l735, i32 0, i32 1
  %t1431 = load ptr, ptr %t1430, !tbaa !27
  %t1432 = getelementptr i32, ptr %t1431, i64 %t1428
  %t1433 = load i32, ptr %t1432, !tbaa !33
  %t1436 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t1426, i32 %t1433)
  store i32 %t1436, ptr %l738
  br label %bb335
bb334:
  br label %bb337
bb335:
  %t1437 = load ptr, ptr %l730, !tbaa !29
  %t1438 = load ptr, ptr %l731, !tbaa !29
  %t1439 = load i32, ptr %l738, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espellList(ptr %v0, ptr %v1, ptr %s56, ptr %s56, ptr %t1437, ptr %t1438, i32 %t1439, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) })
  br label %bb336
bb336:
  call void @__olang_scope_close(ptr %s56)
  call void @__olang_scope_close(ptr %s53)
  br label %bb360
bb337:
  %t1440 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t1440, i8 40)
  br label %bb338
bb338:
  store i64 0, ptr %l61, !tbaa !24
  %t1442 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t1444 = extractvalue { i64, ptr } %t1442, 0
  store i64 %t1444, ptr %l62, !tbaa !24
  store i64 1, ptr %l63, !tbaa !24
  %t1446 = load i64, ptr %l62, !tbaa !24
  %t1447 = load i64, ptr %l61, !tbaa !24
  %t1450 = icmp sgt i64 %t1446, %t1447
  br i1 %t1450, label %bb339, label %bb340
bb339:
  %t1452 = load i64, ptr %l63, !tbaa !24
  %t1454 = icmp sgt i64 %t1452, 0
  br i1 %t1454, label %bb341, label %bb342
bb340:
  store i64 0, ptr %l745, !tbaa !24
  br label %bb344
bb341:
  %t1456 = load i64, ptr %l62, !tbaa !24
  %t1457 = load i64, ptr %l61, !tbaa !24
  %t1460 = sub i64 %t1456, %t1457
  %t1461 = load i64, ptr %l63, !tbaa !24
  %t1464 = add i64 %t1460, %t1461
  %t1466 = sub i64 %t1464, 1
  %t1467 = load i64, ptr %l63, !tbaa !24
  %t1470 = sdiv i64 %t1466, %t1467
  store i64 %t1470, ptr %l748, !tbaa !24
  br label %bb343
bb342:
  store i64 0, ptr %l748, !tbaa !24
  br label %bb343
bb343:
  %t1472 = load i64, ptr %l748, !tbaa !24
  store i64 %t1472, ptr %l745, !tbaa !24
  br label %bb344
bb344:
  %t1473 = load i64, ptr %l745, !tbaa !24
  store i64 %t1473, ptr %l64, !tbaa !24
  store i64 0, ptr %l65, !tbaa !24
  br label %bb345
bb345:
  store %olang.scope zeroinitializer, ptr %s58
  %t1474 = load i64, ptr %l65, !tbaa !24
  %t1475 = load i64, ptr %l64, !tbaa !24
  %t1478 = icmp slt i64 %t1474, %t1475
  %t1480 = xor i1 %t1478, true
  br i1 %t1480, label %bb346, label %bb347
bb346:
  call void @__olang_scope_close(ptr %s58)
  br label %bb358
bb347:
  br label %bb348
bb348:
  %t1482 = load i64, ptr %l61, !tbaa !24
  %t1483 = load i64, ptr %l65, !tbaa !24
  %t1484 = load i64, ptr %l63, !tbaa !24
  %t1487 = mul i64 %t1483, %t1484
  %t1490 = add i64 %t1482, %t1487
  store i64 %t1490, ptr %l66, !tbaa !24
  %t1492 = load i64, ptr %l66, !tbaa !24
  %t1494 = icmp sgt i64 %t1492, 0
  br i1 %t1494, label %bb349, label %bb350
bb349:
  store %olang.scope zeroinitializer, ptr %s59
  %t1496 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s59, ptr %t1496, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d61, i32 0, i32 1) })
  br label %bb351
bb350:
  br label %bb352
bb351:
  call void @__olang_scope_close(ptr %s59)
  br label %bb352
bb352:
  %t1498 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1498, ptr %l769, !tbaa !29
  %t1499 = load ptr, ptr %l0, !tbaa !29
  %t1500 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t1500, ptr %l771, !tbaa !27
  %t1501 = load i64, ptr %l53, !tbaa !24
  %t1502 = load i64, ptr %l66, !tbaa !24
  %t1505 = add i64 %t1501, %t1502
  %t1507 = getelementptr { i64, ptr }, ptr %l771, i32 0, i32 1
  %t1508 = load ptr, ptr %t1507, !tbaa !27
  %t1509 = getelementptr i32, ptr %t1508, i64 %t1505
  %t1510 = load i32, ptr %t1509, !tbaa !33
  %t1513 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t1499, i32 %t1510)
  store { i64, ptr } %t1513, ptr %l776
  br label %bb353
bb353:
  %t1514 = load ptr, ptr %l769, !tbaa !29
  %t1515 = load { i64, ptr }, ptr %l776, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %v0, ptr %t1514, { i64, ptr } %t1515)
  br label %bb354
bb354:
  %t1516 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t1516, i8 32)
  br label %bb355
bb355:
  %t1518 = load ptr, ptr %l0, !tbaa !29
  %t1519 = load ptr, ptr %l1, !tbaa !29
  %t1520 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t1520, ptr %l780, !tbaa !27
  %t1521 = load i64, ptr %l66, !tbaa !24
  %t1523 = getelementptr { i64, ptr }, ptr %l780, i32 0, i32 1
  %t1524 = load ptr, ptr %t1523, !tbaa !27
  %t1525 = getelementptr i32, ptr %t1524, i64 %t1521
  %t1526 = load i32, ptr %t1525, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %v1, ptr %t1518, ptr %t1519, i32 %t1526, i1 false)
  br label %bb356
bb356:
  call void @__olang_scope_close(ptr %s58)
  br label %bb357
bb357:
  %t1530 = load i64, ptr %l65, !tbaa !24
  %t1532 = add i64 %t1530, 1
  store i64 %t1532, ptr %l65, !tbaa !24
  br label %bb345
bb358:
  %t1534 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t1534, i8 41)
  br label %bb359
bb359:
  %t1536 = load i64, ptr %l53, !tbaa !24
  %t1537 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t1539 = extractvalue { i64, ptr } %t1537, 0
  %t1542 = add i64 %t1536, %t1539
  store i64 %t1542, ptr %l53, !tbaa !24
  call void @__olang_scope_close(ptr %s53)
  br label %bb360
bb360:
  %t1544 = load i64, ptr %l58, !tbaa !24
  %t1546 = add i64 %t1544, 1
  store i64 %t1546, ptr %l58, !tbaa !24
  br label %bb315
bb361:
  %t1548 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s51, ptr %t1548, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d62, i32 0, i32 1) })
  br label %bb362
bb362:
  call void @__olang_scope_close(ptr %s51)
  br label %bb408
bb363:
  %t1550 = load i32, ptr %l4
  %t1552 = trunc i64 26 to i32
  %t1553 = icmp eq i32 %t1550, %t1552
  br i1 %t1553, label %bb364, label %bb365
bb364:
  br label %bb366
bb365:
  br label %bb369
bb366:
  store %olang.scope zeroinitializer, ptr %s62
  %t1555 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1555, ptr %l795, !tbaa !29
  %t1556 = load ptr, ptr %l0, !tbaa !29
  %t1558 = getelementptr %"compiler/check:Checker", ptr %t1556, i32 0, i32 1
  %t1559 = load ptr, ptr %t1558, !tbaa !29
  %t1561 = getelementptr %"compiler/generic:Program", ptr %t1559, i32 0, i32 2
  %t1562 = load i32, ptr %l2, !tbaa !23
  %t1565 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t1561, i32 %t1562)
  store i64 %t1565, ptr %l800
  br label %bb367
bb367:
  %t1566 = load i64, ptr %l800, !tbaa !24
  %t1567 = call i64 @__olang_fmt_i64(ptr null, i64 %t1566)
  %t1568 = call ptr @__olang_scope_alloc(ptr %s62, i64 %t1567)
  %t1569 = call i64 @__olang_fmt_i64(ptr %t1568, i64 %t1566)
  %t1570 = insertvalue { i64, ptr } undef, i64 %t1567, 0
  %t1571 = insertvalue { i64, ptr } %t1570, ptr %t1568, 1
  %t1573 = extractvalue { i64, ptr } %t1571, 0
  %t1574 = extractvalue { i64, ptr } %t1571, 1
  %t1575 = mul i64 %t1573, 1
  %t1576 = call ptr @__olang_scope_alloc(ptr %s62, i64 %t1575)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1576, ptr %t1574, i64 %t1575, i1 false)
  %t1577 = insertvalue { i64, ptr } undef, i64 %t1573, 0
  %t1578 = insertvalue { i64, ptr } %t1577, ptr %t1576, 1
  %t1579 = load ptr, ptr %l795, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s62, ptr %t1579, { i64, ptr } %t1578)
  br label %bb368
bb368:
  call void @__olang_scope_close(ptr %s62)
  br label %bb408
bb369:
  %t1581 = load i32, ptr %l4
  %t1583 = trunc i64 25 to i32
  %t1584 = icmp eq i32 %t1581, %t1583
  br i1 %t1584, label %bb370, label %bb371
bb370:
  br label %bb372
bb371:
  br label %bb378
bb372:
  %t1586 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1586, ptr %l805, !tbaa !29
  %t1587 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1587, ptr %l806, !tbaa !29
  %t1588 = load ptr, ptr %l0, !tbaa !29
  %t1590 = getelementptr %"compiler/check:Checker", ptr %t1588, i32 0, i32 1
  %t1591 = load ptr, ptr %t1590, !tbaa !29
  store ptr %t1591, ptr %l808, !tbaa !29
  %t1592 = load ptr, ptr %l0, !tbaa !29
  %t1594 = getelementptr %"compiler/check:Checker", ptr %t1592, i32 0, i32 1
  %t1595 = load ptr, ptr %t1594, !tbaa !29
  %t1597 = getelementptr %"compiler/generic:Program", ptr %t1595, i32 0, i32 2
  %t1598 = load i32, ptr %l2, !tbaa !23
  %t1601 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t1597, i32 %t1598)
  store i64 %t1601, ptr %l813
  br label %bb373
bb373:
  %t1602 = load ptr, ptr %l0, !tbaa !29
  %t1604 = getelementptr %"compiler/check:Checker", ptr %t1602, i32 0, i32 1
  %t1605 = load ptr, ptr %t1604, !tbaa !29
  %t1607 = getelementptr %"compiler/generic:Program", ptr %t1605, i32 0, i32 2
  %t1608 = load i32, ptr %l2, !tbaa !23
  %t1611 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t1607, i32 %t1608)
  store i64 %t1611, ptr %l818
  br label %bb374
bb374:
  %t1612 = load ptr, ptr %l808, !tbaa !29
  %t1613 = load i64, ptr %l813, !tbaa !24
  %t1614 = load i64, ptr %l818, !tbaa !24
  %t1615 = call %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %t1612, i64 %t1613, i64 %t1614)
  store %"compiler/generic:varRow" %t1615, ptr %l819
  br label %bb375
bb375:
  %t1616 = getelementptr %"compiler/generic:varRow", ptr %l819, i32 0, i32 1
  %t1617 = load i32, ptr %t1616, !tbaa !23
  %t1618 = load ptr, ptr %l806, !tbaa !29
  %t1620 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t1618, i32 %t1617)
  store { i64, ptr } %t1620, ptr %l821
  br label %bb376
bb376:
  %t1621 = load ptr, ptr %l805, !tbaa !29
  %t1622 = load { i64, ptr }, ptr %l821, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %v0, ptr %t1621, { i64, ptr } %t1622)
  br label %bb377
bb377:
  br label %bb408
bb378:
  %t1623 = load i32, ptr %l4
  %t1625 = trunc i64 30 to i32
  %t1626 = icmp eq i32 %t1623, %t1625
  br i1 %t1626, label %bb379, label %bb380
bb379:
  br label %bb381
bb380:
  br label %bb405
bb381:
  %t1628 = load ptr, ptr %l0, !tbaa !29
  %t1630 = getelementptr %"compiler/check:Checker", ptr %t1628, i32 0, i32 1
  %t1631 = load ptr, ptr %t1630, !tbaa !29
  %t1633 = getelementptr %"compiler/generic:Program", ptr %t1631, i32 0, i32 2
  store ptr %t1633, ptr %l826, !tbaa !29
  %t1634 = load ptr, ptr %l0, !tbaa !29
  %t1636 = getelementptr %"compiler/check:Checker", ptr %t1634, i32 0, i32 1
  %t1637 = load ptr, ptr %t1636, !tbaa !29
  %t1639 = getelementptr %"compiler/generic:Program", ptr %t1637, i32 0, i32 2
  %t1640 = load i32, ptr %l2, !tbaa !23
  %t1643 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %t1639, i32 %t1640)
  store i32 %t1643, ptr %l831
  br label %bb382
bb382:
  %t1644 = load ptr, ptr %l826, !tbaa !29
  %t1645 = load i32, ptr %l831, !tbaa !23
  %t1646 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t1644, i32 %t1645)
  store { i64, ptr } %t1646, ptr %l832
  br label %bb383
bb383:
  %t1647 = load { i64, ptr }, ptr %l832, !tbaa !27
  store { i64, ptr } %t1647, ptr %l67, !tbaa !27
  %t1648 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t1650 = extractvalue { i64, ptr } %t1648, 0
  %t1652 = icmp eq i64 %t1650, 0
  br i1 %t1652, label %bb384, label %bb385
bb384:
  store %olang.scope zeroinitializer, ptr %s66
  %t1654 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s66, ptr %t1654, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d63, i32 0, i32 1) })
  br label %bb386
bb385:
  br label %bb387
bb386:
  call void @__olang_scope_close(ptr %s66)
  br label %bb387
bb387:
  store i64 0, ptr %l68, !tbaa !24
  %t1656 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t1658 = extractvalue { i64, ptr } %t1656, 0
  store i64 %t1658, ptr %l69, !tbaa !24
  store i64 1, ptr %l70, !tbaa !24
  %t1660 = load i64, ptr %l69, !tbaa !24
  %t1661 = load i64, ptr %l68, !tbaa !24
  %t1664 = icmp sgt i64 %t1660, %t1661
  br i1 %t1664, label %bb388, label %bb389
bb388:
  %t1666 = load i64, ptr %l70, !tbaa !24
  %t1668 = icmp sgt i64 %t1666, 0
  br i1 %t1668, label %bb390, label %bb391
bb389:
  store i64 0, ptr %l842, !tbaa !24
  br label %bb393
bb390:
  %t1670 = load i64, ptr %l69, !tbaa !24
  %t1671 = load i64, ptr %l68, !tbaa !24
  %t1674 = sub i64 %t1670, %t1671
  %t1675 = load i64, ptr %l70, !tbaa !24
  %t1678 = add i64 %t1674, %t1675
  %t1680 = sub i64 %t1678, 1
  %t1681 = load i64, ptr %l70, !tbaa !24
  %t1684 = sdiv i64 %t1680, %t1681
  store i64 %t1684, ptr %l845, !tbaa !24
  br label %bb392
bb391:
  store i64 0, ptr %l845, !tbaa !24
  br label %bb392
bb392:
  %t1686 = load i64, ptr %l845, !tbaa !24
  store i64 %t1686, ptr %l842, !tbaa !24
  br label %bb393
bb393:
  %t1687 = load i64, ptr %l842, !tbaa !24
  store i64 %t1687, ptr %l71, !tbaa !24
  store i64 0, ptr %l72, !tbaa !24
  br label %bb394
bb394:
  store %olang.scope zeroinitializer, ptr %s68
  %t1688 = load i64, ptr %l72, !tbaa !24
  %t1689 = load i64, ptr %l71, !tbaa !24
  %t1692 = icmp slt i64 %t1688, %t1689
  %t1694 = xor i1 %t1692, true
  br i1 %t1694, label %bb395, label %bb396
bb395:
  call void @__olang_scope_close(ptr %s68)
  br label %bb404
bb396:
  br label %bb397
bb397:
  %t1696 = load i64, ptr %l68, !tbaa !24
  %t1697 = load i64, ptr %l72, !tbaa !24
  %t1698 = load i64, ptr %l70, !tbaa !24
  %t1701 = mul i64 %t1697, %t1698
  %t1704 = add i64 %t1696, %t1701
  store i64 %t1704, ptr %l73, !tbaa !24
  %t1706 = load i64, ptr %l73, !tbaa !24
  %t1708 = icmp sgt i64 %t1706, 0
  br i1 %t1708, label %bb398, label %bb399
bb398:
  store %olang.scope zeroinitializer, ptr %s69
  %t1710 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s69, ptr %t1710, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d64, i32 0, i32 1) })
  br label %bb400
bb399:
  br label %bb401
bb400:
  call void @__olang_scope_close(ptr %s69)
  br label %bb401
bb401:
  %t1712 = load ptr, ptr %l0, !tbaa !29
  %t1713 = load ptr, ptr %l1, !tbaa !29
  %t1714 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t1714, ptr %l868, !tbaa !27
  %t1715 = load i64, ptr %l73, !tbaa !24
  %t1717 = getelementptr { i64, ptr }, ptr %l868, i32 0, i32 1
  %t1718 = load ptr, ptr %t1717, !tbaa !27
  %t1719 = getelementptr i32, ptr %t1718, i64 %t1715
  %t1720 = load i32, ptr %t1719, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %v1, ptr %t1712, ptr %t1713, i32 %t1720, i1 false)
  br label %bb402
bb402:
  call void @__olang_scope_close(ptr %s68)
  br label %bb403
bb403:
  %t1724 = load i64, ptr %l72, !tbaa !24
  %t1726 = add i64 %t1724, 1
  store i64 %t1726, ptr %l72, !tbaa !24
  br label %bb394
bb404:
  br label %bb408
bb405:
  store %olang.scope zeroinitializer, ptr %s71
  %t1728 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1728, ptr %l873, !tbaa !29
  %t1729 = load ptr, ptr %l0, !tbaa !29
  %t1731 = getelementptr %"compiler/check:Checker", ptr %t1729, i32 0, i32 1
  %t1732 = load ptr, ptr %t1731, !tbaa !29
  %t1734 = getelementptr %"compiler/generic:Program", ptr %t1732, i32 0, i32 2
  %t1735 = load i32, ptr %l2, !tbaa !23
  %t1738 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s71, ptr %t1734, i32 %t1735)
  store { i64, ptr } %t1738, ptr %l878
  br label %bb406
bb406:
  %t1739 = load { i64, ptr }, ptr %l878, !tbaa !27
  %t1740 = extractvalue { i64, ptr } %t1739, 0
  %t1741 = extractvalue { i64, ptr } %t1739, 1
  %t1742 = mul i64 %t1740, 1
  %t1743 = call ptr @__olang_scope_alloc(ptr %s71, i64 %t1742)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1743, ptr %t1741, i64 %t1742, i1 false)
  %t1744 = insertvalue { i64, ptr } undef, i64 %t1740, 0
  %t1745 = insertvalue { i64, ptr } %t1744, ptr %t1743, 1
  %t1746 = load ptr, ptr %l873, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s71, ptr %t1746, { i64, ptr } %t1745)
  br label %bb407
bb407:
  call void @__olang_scope_close(ptr %s71)
  br label %bb408
bb408:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espread(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l18 = alloca ptr
  %l21 = alloca i32
  %l24 = alloca i64
  %l29 = alloca i32
  %l39 = alloca { i64, ptr }
  %l41 = alloca %"compiler/source:Span"
  %l45 = alloca i64
  %l57 = alloca ptr
  %l62 = alloca i32
  %l63 = alloca { i64, ptr }
  %l69 = alloca i64
  %l72 = alloca i64
  %l91 = alloca ptr
  %l95 = alloca { i64, ptr }
  %l108 = alloca ptr
  %l114 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t73 = alloca { i64, [3 x i64] }, align 8
  %t176 = alloca { i64, [4 x i64] }, align 8
  %t189 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t8 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t1, ptr %t2, i32 %t4)
  store ptr %t8, ptr %l18
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l18, !tbaa !29
  store ptr %t9, ptr %l2, !tbaa !29
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t13 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t10)
  store i32 %t13, ptr %l21
  br label %bb2
bb2:
  %t14 = load i32, ptr %l21, !tbaa !23
  store i32 %t14, ptr %l3, !tbaa !23
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 32
  %t19 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t17)
  store i64 %t19, ptr %l24
  br label %bb3
bb3:
  %t20 = load i64, ptr %l24, !tbaa !24
  store i64 %t20, ptr %l4, !tbaa !24
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 2
  %t27 = load i32, ptr %l3, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t30, ptr %l29
  br label %bb4
bb4:
  %t31 = load i32, ptr %l29
  %t33 = trunc i64 22 to i32
  %t34 = icmp eq i32 %t31, %t33
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb5, label %bb6
bb5:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 32
  %t41 = load ptr, ptr %l2, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t40, ptr %t41)
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 32
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t46, i64 %t47)
  store { i64, ptr } %t50, ptr %l39
  br label %bb8
bb8:
  %t51 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t51, ptr %rv
  br label %ret
bb9:
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t52)
  store %"compiler/source:Span" %t54, ptr %l41
  br label %bb10
bb10:
  %t55 = load %"compiler/source:Span", ptr %l41
  store %"compiler/source:Span" %t55, ptr %l5
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load %"compiler/source:Span", ptr %l5
  %t58 = load i32, ptr %l3, !tbaa !23
  %t62 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t56, %"compiler/source:Span" %t57, i32 %t58)
  store i64 %t62, ptr %l45
  br label %bb11
bb11:
  %t63 = load i64, ptr %l45, !tbaa !24
  store i64 %t63, ptr %l6, !tbaa !24
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 33
  %t67 = load %"compiler/source:Span", ptr %l5
  %t68 = load i64, ptr %l6, !tbaa !24
  %t70 = trunc i64 %t68 to i32
  %t72 = load ptr, ptr %l2, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t73
  %t74 = getelementptr { i64, [3 x i64] }, ptr %t73, i32 0, i32 0
  store i64 0, ptr %t74
  %t76 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t67, 0
  %t78 = insertvalue { %"compiler/source:Span", i32, ptr } %t76, i32 %t70, 1
  %t80 = insertvalue { %"compiler/source:Span", i32, ptr } %t78, ptr %t72, 2
  %t81 = getelementptr { i64, [3 x i64] }, ptr %t73, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t80, ptr %t81
  %t82 = load { i64, [3 x i64] }, ptr %t73
  %t84 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t82, ptr %t84
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v0, ptr %t66, ptr %t84)
  br label %bb12
bb12:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/check:Checker", ptr %t87, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t92 = getelementptr %"compiler/generic:Program", ptr %t90, i32 0, i32 2
  store ptr %t92, ptr %l57, !tbaa !29
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 2
  %t99 = load i32, ptr %l3, !tbaa !23
  %t102 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t98, i32 %t99)
  store i32 %t102, ptr %l62
  br label %bb13
bb13:
  %t103 = load ptr, ptr %l57, !tbaa !29
  %t104 = load i32, ptr %l62, !tbaa !23
  %t105 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t103, i32 %t104)
  store { i64, ptr } %t105, ptr %l63
  br label %bb14
bb14:
  %t106 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t106, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t107 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t107, 0
  store i64 %t109, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t111 = load i64, ptr %l9, !tbaa !24
  %t112 = load i64, ptr %l8, !tbaa !24
  %t115 = icmp sgt i64 %t111, %t112
  br i1 %t115, label %bb15, label %bb16
bb15:
  %t117 = load i64, ptr %l10, !tbaa !24
  %t119 = icmp sgt i64 %t117, 0
  br i1 %t119, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb20
bb17:
  %t121 = load i64, ptr %l9, !tbaa !24
  %t122 = load i64, ptr %l8, !tbaa !24
  %t125 = sub i64 %t121, %t122
  %t126 = load i64, ptr %l10, !tbaa !24
  %t129 = add i64 %t125, %t126
  %t131 = sub i64 %t129, 1
  %t132 = load i64, ptr %l10, !tbaa !24
  %t135 = sdiv i64 %t131, %t132
  store i64 %t135, ptr %l72, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb19
bb19:
  %t137 = load i64, ptr %l72, !tbaa !24
  store i64 %t137, ptr %l69, !tbaa !24
  br label %bb20
bb20:
  %t138 = load i64, ptr %l69, !tbaa !24
  store i64 %t138, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  %t139 = load i64, ptr %l12, !tbaa !24
  %t140 = load i64, ptr %l11, !tbaa !24
  %t143 = icmp slt i64 %t139, %t140
  %t145 = xor i1 %t143, true
  br i1 %t145, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb28
bb23:
  br label %bb24
bb24:
  %t147 = load i64, ptr %l8, !tbaa !24
  %t148 = load i64, ptr %l12, !tbaa !24
  %t149 = load i64, ptr %l10, !tbaa !24
  %t152 = mul i64 %t148, %t149
  %t155 = add i64 %t147, %t152
  store i64 %t155, ptr %l13, !tbaa !24
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/check:Checker", ptr %t157, i32 0, i32 32
  store ptr %t159, ptr %l91, !tbaa !29
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load %"compiler/source:Span", ptr %l5
  %t162 = load %"compiler/source:Span", ptr %l5
  %t163 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t163, ptr %l95, !tbaa !27
  %t164 = load i64, ptr %l13, !tbaa !24
  %t166 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr i32, ptr %t167, i64 %t164
  %t169 = load i32, ptr %t168, !tbaa !33
  %t170 = load %"compiler/source:Span", ptr %l5
  %t171 = load i32, ptr %l3, !tbaa !23
  %t172 = load i64, ptr %l6, !tbaa !24
  %t174 = trunc i64 %t172 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t176
  %t177 = getelementptr { i64, [4 x i64] }, ptr %t176, i32 0, i32 0
  store i64 0, ptr %t177
  %t179 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t170, 0
  %t181 = insertvalue { %"compiler/source:Span", i32, i32 } %t179, i32 %t171, 1
  %t183 = insertvalue { %"compiler/source:Span", i32, i32 } %t181, i32 %t174, 2
  %t184 = getelementptr { i64, [4 x i64] }, ptr %t176, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t183, ptr %t184
  %t185 = load { i64, [4 x i64] }, ptr %t176
  %t187 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t185, ptr %t187
  %t188 = load i64, ptr %l13, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t189
  %t190 = getelementptr { i64, [4 x i64] }, ptr %t189, i32 0, i32 0
  store i64 3, ptr %t190
  %t192 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t162, 0
  %t194 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t192, i32 %t169, 1
  %t196 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t194, ptr %t187, 2
  %t198 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t196, i64 %t188, 3
  %t199 = getelementptr { i64, [4 x i64] }, ptr %t189, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t198, ptr %t199
  %t200 = load { i64, [4 x i64] }, ptr %t189
  %t202 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t200, ptr %t202
  %t206 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t160, %"compiler/source:Span" %t161, ptr %t202)
  store ptr %t206, ptr %l108
  br label %bb25
bb25:
  %t207 = load ptr, ptr %l91, !tbaa !29
  %t208 = load ptr, ptr %l108, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t207, ptr %t208)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s3)
  br label %bb27
bb27:
  %t209 = load i64, ptr %l12, !tbaa !24
  %t211 = add i64 %t209, 1
  store i64 %t211, ptr %l12, !tbaa !24
  br label %bb21
bb28:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/check:Checker", ptr %t213, i32 0, i32 32
  %t216 = load i64, ptr %l4, !tbaa !24
  %t219 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t215, i64 %t216)
  store { i64, ptr } %t219, ptr %l114
  br label %bb29
bb29:
  %t220 = load { i64, ptr }, ptr %l114, !tbaa !27
  store { i64, ptr } %t220, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estepMethod(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i1
  %l5 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i32
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l44 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca %"compiler/source:Span"
  %l47 = alloca ptr
  %l52 = alloca ptr
  %l56 = alloca ptr
  %l57 = alloca i32
  %l59 = alloca { i64, ptr }
  %l60 = alloca i64
  %l63 = alloca ptr
  %l64 = alloca i32
  %l66 = alloca { i64, ptr }
  %l67 = alloca %"compiler/source:Span"
  %l69 = alloca { i64, ptr }
  %l70 = alloca i1
  %l71 = alloca ptr
  %l74 = alloca ptr
  %l77 = alloca ptr
  %l81 = alloca i32
  %l82 = alloca i32
  %l83 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l86 = alloca i32
  %l89 = alloca i1
  %l92 = alloca ptr
  %l93 = alloca %"compiler/source:Span"
  %l94 = alloca i32
  %l97 = alloca ptr
  %l100 = alloca i32
  %l101 = alloca i1
  %l102 = alloca i64
  %l105 = alloca i32
  %l106 = alloca i64
  %l107 = alloca ptr
  %l108 = alloca ptr
  %l109 = alloca %"compiler/source:Span"
  %l110 = alloca %"compiler/source:Span"
  %l111 = alloca i64
  %l118 = alloca ptr
  %l119 = alloca ptr
  %l122 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l129 = alloca ptr
  %l130 = alloca ptr
  %l131 = alloca %"compiler/source:Span"
  %l132 = alloca ptr
  %l137 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  %t31 = alloca { i64, [4 x i64] }, align 8
  %t92 = alloca { i64, [3 x i64] }, align 8
  %t219 = alloca { i64, [4 x i64] }, align 8
  %t277 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l3, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load i1, ptr %l13, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l16, !tbaa !29
  %t11 = load i32, ptr %l3, !tbaa !23
  store i32 %t11, ptr %l17, !tbaa !23
  %t12 = load i1, ptr %l4, !tbaa !21
  br i1 %t12, label %bb5, label %bb6
bb5:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d65, i32 0, i32 1) }, ptr %l19, !tbaa !27
  br label %bb7
bb6:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d66, i32 0, i32 1) }, ptr %l19, !tbaa !27
  br label %bb7
bb7:
  %t14 = load ptr, ptr %l16, !tbaa !29
  %t15 = load i32, ptr %l17, !tbaa !23
  %t16 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t17 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t14, i32 %t15, { i64, ptr } %t16, i64 0)
  store i64 %t17, ptr %l20
  br label %bb8
bb8:
  %t18 = load i64, ptr %l20, !tbaa !24
  store i64 %t18, ptr %l5, !tbaa !24
  %t19 = load i64, ptr %l5, !tbaa !24
  %t21 = icmp sge i64 %t19, 0
  br i1 %t21, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l23, !tbaa !29
  %t24 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t24, ptr %l24
  %t25 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t25, ptr %l25
  %t26 = load i64, ptr %l5, !tbaa !24
  store i64 %t26, ptr %l26, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l1
  %t29 = load %"compiler/source:Span", ptr %l1
  %t30 = load i32, ptr %l3, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t31
  %t32 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 0
  store i64 7, ptr %t32
  %t34 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t29, 0
  %t36 = insertvalue { %"compiler/source:Span", i32 } %t34, i32 %t30, 1
  %t37 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t36, ptr %t37
  %t38 = load { i64, [4 x i64] }, ptr %t31
  %t40 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t38, ptr %t40
  %t44 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t27, %"compiler/source:Span" %t28, ptr %t40)
  store ptr %t44, ptr %l33
  br label %bb11
bb10:
  br label %bb27
bb11:
  %t45 = load ptr, ptr %l33, !tbaa !29
  store ptr %t45, ptr %l34, !tbaa !29
  %t46 = icmp sge i64 0, 0
  br i1 %t46, label %bb12, label %bb13
bb12:
  %t48 = icmp sle i64 0, 1152921504606846975
  br i1 %t48, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_fe73ad2ef66395ad_6bb388f528f40629)
  unreachable
bb14:
  %t50 = mul i64 0, 8
  %t51 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t50)
  %t52 = insertvalue { i64, ptr } undef, i64 0, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t51, 1
  store { i64, ptr } %t53, ptr %l37, !tbaa !27
  %t54 = icmp sge i64 0, 0
  br i1 %t54, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_fe73ad2ef66395ad_6bb388f528f40629)
  unreachable
bb16:
  %t56 = icmp sle i64 0, 1152921504606846975
  br i1 %t56, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_fe73ad2ef66395ad_6bb388f528f40629)
  unreachable
bb18:
  %t58 = mul i64 0, 8
  %t59 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t58)
  %t60 = insertvalue { i64, ptr } undef, i64 0, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l40, !tbaa !27
  %t62 = icmp sge i64 0, 0
  br i1 %t62, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_fe73ad2ef66395ad_6bb388f528f40629)
  unreachable
bb20:
  %t64 = icmp sle i64 0, 2305843009213693951
  br i1 %t64, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_97840d8df2a94e80_8f65c6ae19d7bb5c)
  unreachable
bb22:
  %t66 = mul i64 0, 4
  %t67 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 0, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  %t70 = load ptr, ptr %l23, !tbaa !29
  %t71 = load %"compiler/source:Span", ptr %l24
  %t72 = load %"compiler/source:Span", ptr %l25
  %t73 = load i64, ptr %l26, !tbaa !24
  %t74 = load ptr, ptr %l34, !tbaa !29
  %t75 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t78 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %s2, ptr %t70, %"compiler/source:Span" %t71, %"compiler/source:Span" %t72, i64 %t73, ptr %t74, { i64, ptr } %t75, { i64, ptr } %t76, { i64, ptr } %t69)
  store ptr %t78, ptr %l44
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_97840d8df2a94e80_8f65c6ae19d7bb5c)
  unreachable
bb24:
  %t79 = load ptr, ptr %l44, !tbaa !29
  %t80 = load ptr, ptr %l0, !tbaa !29
  store ptr %t80, ptr %l45, !tbaa !29
  %t81 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t81, ptr %l46
  %t82 = load ptr, ptr %l2, !tbaa !29
  store ptr %t82, ptr %l47, !tbaa !29
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i32, ptr %l3, !tbaa !23
  %t86 = load %"compiler/source:Span", ptr %l1
  %t91 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t83, ptr %t79, i32 %t85, %"compiler/source:Span" %t86)
  store ptr %t91, ptr %l52
  br label %bb25
bb25:
  store { i64, [3 x i64] } zeroinitializer, ptr %t92
  %t93 = getelementptr { i64, [3 x i64] }, ptr %t92, i32 0, i32 0
  store i64 1, ptr %t93
  %t94 = load %"compiler/source:Span", ptr %l46
  %t95 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t94, 0
  %t96 = load ptr, ptr %l47, !tbaa !29
  %t97 = insertvalue { %"compiler/source:Span", ptr, ptr } %t95, ptr %t96, 1
  %t98 = load ptr, ptr %l52, !tbaa !29
  %t99 = insertvalue { %"compiler/source:Span", ptr, ptr } %t97, ptr %t98, 2
  %t100 = getelementptr { i64, [3 x i64] }, ptr %t92, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t99, ptr %t100
  %t101 = load { i64, [3 x i64] }, ptr %t92
  %t103 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t101, ptr %t103
  %t104 = load ptr, ptr %l45, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t104, ptr %t103)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb27:
  %t107 = load ptr, ptr %l0, !tbaa !29
  store ptr %t107, ptr %l56, !tbaa !29
  %t108 = load i32, ptr %l3, !tbaa !23
  store i32 %t108, ptr %l57, !tbaa !23
  %t109 = load i1, ptr %l4, !tbaa !21
  br i1 %t109, label %bb28, label %bb29
bb28:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d67, i32 0, i32 1) }, ptr %l59, !tbaa !27
  br label %bb30
bb29:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d68, i32 0, i32 1) }, ptr %l59, !tbaa !27
  br label %bb30
bb30:
  %t111 = load ptr, ptr %l56, !tbaa !29
  %t112 = load i32, ptr %l57, !tbaa !23
  %t113 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t114 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t111, i32 %t112, { i64, ptr } %t113, i64 1)
  store i64 %t114, ptr %l60
  br label %bb31
bb31:
  %t115 = load i64, ptr %l60, !tbaa !24
  store i64 %t115, ptr %l7, !tbaa !24
  %t116 = load i64, ptr %l7, !tbaa !24
  %t118 = icmp slt i64 %t116, 0
  br i1 %t118, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s3
  %t120 = load ptr, ptr %l0, !tbaa !29
  store ptr %t120, ptr %l63, !tbaa !29
  %t121 = load i32, ptr %l3, !tbaa !23
  store i32 %t121, ptr %l64, !tbaa !23
  %t122 = load i1, ptr %l4, !tbaa !21
  br i1 %t122, label %bb34, label %bb35
bb33:
  br label %bb41
bb34:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d69, i32 0, i32 1) }, ptr %l66, !tbaa !27
  br label %bb36
bb35:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d70, i32 0, i32 1) }, ptr %l66, !tbaa !27
  br label %bb36
bb36:
  %t124 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t124, ptr %l67
  %t125 = load i1, ptr %l4, !tbaa !21
  br i1 %t125, label %bb37, label %bb38
bb37:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d71, i32 0, i32 1) }, ptr %l69, !tbaa !27
  br label %bb39
bb38:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d72, i32 0, i32 1) }, ptr %l69, !tbaa !27
  br label %bb39
bb39:
  %t127 = load ptr, ptr %l63, !tbaa !29
  %t128 = load i32, ptr %l64, !tbaa !23
  %t129 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t130 = load %"compiler/source:Span", ptr %l67
  %t131 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t132 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %s3, ptr %s3, ptr %t127, i32 %t128, { i64, ptr } %t129, %"compiler/source:Span" %t130, { i64, ptr } %t131, i64 0, i1 false)
  store i1 %t132, ptr %l70
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t133 = load i1, ptr %l70, !tbaa !21
  store i1 %t133, ptr %rv
  br label %ret
bb41:
  %t134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t134, ptr %l71, !tbaa !29
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = getelementptr %"compiler/generic:Program", ptr %t138, i32 0, i32 2
  store ptr %t140, ptr %l74, !tbaa !29
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/check:Checker", ptr %t141, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t146 = getelementptr %"compiler/generic:Program", ptr %t144, i32 0, i32 2
  store ptr %t146, ptr %l77, !tbaa !29
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/check:Checker", ptr %t147, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t151 = load i64, ptr %l7, !tbaa !24
  %t154 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t150, i64 %t151)
  store i32 %t154, ptr %l81
  br label %bb42
bb42:
  %t155 = load ptr, ptr %l77, !tbaa !29
  %t156 = load i32, ptr %l81, !tbaa !23
  %t157 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t155, i32 %t156)
  store i32 %t157, ptr %l82
  br label %bb43
bb43:
  %t158 = load ptr, ptr %l74, !tbaa !29
  %t159 = load i32, ptr %l82, !tbaa !23
  %t160 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t158, i32 %t159)
  store { i64, ptr } %t160, ptr %l83
  br label %bb44
bb44:
  %t161 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t161, ptr %l84, !tbaa !27
  %t162 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !27
  %t164 = getelementptr i32, ptr %t163, i64 1
  %t165 = load i32, ptr %t164, !tbaa !33
  %t166 = load ptr, ptr %l71, !tbaa !29
  %t168 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t166, i32 %t165)
  store i32 %t168, ptr %l86
  br label %bb45
bb45:
  %t169 = load i32, ptr %l86, !tbaa !23
  store i32 %t169, ptr %l8, !tbaa !23
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load i32, ptr %l8, !tbaa !23
  %t174 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t170, i32 %t171)
  store i1 %t174, ptr %l89
  br label %bb46
bb46:
  %t175 = load i1, ptr %l89, !tbaa !21
  %t176 = xor i1 %t175, true
  br i1 %t176, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  %t179 = load ptr, ptr %l0, !tbaa !29
  store ptr %t179, ptr %l92, !tbaa !29
  %t180 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t180, ptr %l93
  %t181 = load i32, ptr %l8, !tbaa !23
  store i32 %t181, ptr %l94, !tbaa !23
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/check:Checker", ptr %t182, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !29
  %t187 = getelementptr %"compiler/generic:Program", ptr %t185, i32 0, i32 2
  store ptr %t187, ptr %l97, !tbaa !29
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load i32, ptr %l8, !tbaa !23
  %t192 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t188, i32 %t189)
  store i32 %t192, ptr %l100
  br label %bb50
bb50:
  %t193 = load ptr, ptr %l97, !tbaa !29
  %t194 = load i32, ptr %l100, !tbaa !23
  %t195 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t193, i32 %t194)
  store i1 %t195, ptr %l101
  br label %bb51
bb51:
  %t196 = load i1, ptr %l101, !tbaa !21
  br i1 %t196, label %bb52, label %bb53
bb52:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load i32, ptr %l8, !tbaa !23
  %t201 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t197, i32 %t198)
  store i32 %t201, ptr %l105
  br label %bb54
bb53:
  store i64 1, ptr %l102, !tbaa !24
  br label %bb56
bb54:
  %t202 = load i32, ptr %l105, !tbaa !23
  %t203 = call i64 @compiler_2fcheck_2efloatBits(i32 %t202, double 0x3ff0000000000000)
  store i64 %t203, ptr %l106
  br label %bb55
bb55:
  %t204 = load i64, ptr %l106, !tbaa !24
  store i64 %t204, ptr %l102, !tbaa !24
  br label %bb56
bb56:
  %t205 = load ptr, ptr %l92, !tbaa !29
  %t206 = load %"compiler/source:Span", ptr %l93
  %t207 = load i32, ptr %l94, !tbaa !23
  %t208 = load i64, ptr %l102, !tbaa !24
  %t209 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t205, %"compiler/source:Span" %t206, i32 %t207, i64 %t208)
  store ptr %t209, ptr %l107
  br label %bb57
bb57:
  %t210 = load ptr, ptr %l107, !tbaa !29
  store ptr %t210, ptr %l9, !tbaa !29
  %t211 = load ptr, ptr %l0, !tbaa !29
  store ptr %t211, ptr %l108, !tbaa !29
  %t212 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t212, ptr %l109
  %t213 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t213, ptr %l110
  %t214 = load i64, ptr %l7, !tbaa !24
  store i64 %t214, ptr %l111, !tbaa !24
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load %"compiler/source:Span", ptr %l1
  %t217 = load %"compiler/source:Span", ptr %l1
  %t218 = load i32, ptr %l3, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t219
  %t220 = getelementptr { i64, [4 x i64] }, ptr %t219, i32 0, i32 0
  store i64 7, ptr %t220
  %t222 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t217, 0
  %t224 = insertvalue { %"compiler/source:Span", i32 } %t222, i32 %t218, 1
  %t225 = getelementptr { i64, [4 x i64] }, ptr %t219, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t224, ptr %t225
  %t226 = load { i64, [4 x i64] }, ptr %t219
  %t228 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t226, ptr %t228
  %t232 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t215, %"compiler/source:Span" %t216, ptr %t228)
  store ptr %t232, ptr %l118
  br label %bb58
bb58:
  %t233 = load ptr, ptr %l118, !tbaa !29
  store ptr %t233, ptr %l119, !tbaa !29
  %t234 = icmp sge i64 0, 0
  br i1 %t234, label %bb59, label %bb60
bb59:
  %t236 = icmp sle i64 0, 1152921504606846975
  br i1 %t236, label %bb61, label %bb62
bb60:
  call void @__olang_check_failed(ptr @olang_loc_729de81d3b051823_7dce08f61f50e4bf)
  unreachable
bb61:
  %t238 = mul i64 0, 8
  %t239 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t238)
  %t240 = insertvalue { i64, ptr } undef, i64 0, 0
  %t241 = insertvalue { i64, ptr } %t240, ptr %t239, 1
  store { i64, ptr } %t241, ptr %l122, !tbaa !27
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load ptr, ptr %l9, !tbaa !29
  %t246 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %t242, ptr %t243)
  store { i64, ptr } %t246, ptr %l125
  br label %bb63
bb62:
  call void @__olang_check_failed(ptr @olang_loc_729de81d3b051823_7dce08f61f50e4bf)
  unreachable
bb63:
  %t247 = icmp sge i64 0, 0
  br i1 %t247, label %bb64, label %bb65
bb64:
  %t249 = icmp sle i64 0, 2305843009213693951
  br i1 %t249, label %bb66, label %bb67
bb65:
  call void @__olang_check_failed(ptr @olang_loc_97840d8df2a94e80_8f65c6ae19d7bb5c)
  unreachable
bb66:
  %t251 = mul i64 0, 4
  %t252 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t251)
  %t253 = insertvalue { i64, ptr } undef, i64 0, 0
  %t254 = insertvalue { i64, ptr } %t253, ptr %t252, 1
  %t255 = load ptr, ptr %l108, !tbaa !29
  %t256 = load %"compiler/source:Span", ptr %l109
  %t257 = load %"compiler/source:Span", ptr %l110
  %t258 = load i64, ptr %l111, !tbaa !24
  %t259 = load ptr, ptr %l119, !tbaa !29
  %t260 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t261 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t263 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %s0, ptr %t255, %"compiler/source:Span" %t256, %"compiler/source:Span" %t257, i64 %t258, ptr %t259, { i64, ptr } %t260, { i64, ptr } %t261, { i64, ptr } %t254)
  store ptr %t263, ptr %l129
  br label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_97840d8df2a94e80_8f65c6ae19d7bb5c)
  unreachable
bb68:
  %t264 = load ptr, ptr %l129, !tbaa !29
  %t265 = load ptr, ptr %l0, !tbaa !29
  store ptr %t265, ptr %l130, !tbaa !29
  %t266 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t266, ptr %l131
  %t267 = load ptr, ptr %l2, !tbaa !29
  store ptr %t267, ptr %l132, !tbaa !29
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = load i32, ptr %l3, !tbaa !23
  %t271 = load %"compiler/source:Span", ptr %l1
  %t276 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t268, ptr %t264, i32 %t270, %"compiler/source:Span" %t271)
  store ptr %t276, ptr %l137
  br label %bb69
bb69:
  store { i64, [3 x i64] } zeroinitializer, ptr %t277
  %t278 = getelementptr { i64, [3 x i64] }, ptr %t277, i32 0, i32 0
  store i64 1, ptr %t278
  %t279 = load %"compiler/source:Span", ptr %l131
  %t280 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t279, 0
  %t281 = load ptr, ptr %l132, !tbaa !29
  %t282 = insertvalue { %"compiler/source:Span", ptr, ptr } %t280, ptr %t281, 1
  %t283 = load ptr, ptr %l137, !tbaa !29
  %t284 = insertvalue { %"compiler/source:Span", ptr, ptr } %t282, ptr %t283, 2
  %t285 = getelementptr { i64, [3 x i64] }, ptr %t277, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t284, ptr %t285
  %t286 = load { i64, [3 x i64] }, ptr %t277
  %t288 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t286, ptr %t288
  %t289 = load ptr, ptr %l130, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t289, ptr %t288)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextConst(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2, i32 %a3) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %lp4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l42 = alloca { i64, ptr }
  %l48 = alloca %"compiler/source:Span"
  %l49 = alloca i32
  %l51 = alloca ptr
  %s2 = alloca %olang.scope
  %rv = alloca ptr
  %t95 = alloca { i64, [2 x i64] }, align 8
  %t103 = alloca { i64, [5 x i64] }, align 8
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l12, !tbaa !24
  %t4 = load i64, ptr %l12, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l12, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  %t12 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t12, ptr %lp4
  %t14 = load ptr, ptr %lp4
  store { i64, ptr } %t11, ptr %t14, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  store i64 %t17, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t19 = load i64, ptr %l6, !tbaa !24
  %t20 = load i64, ptr %l5, !tbaa !24
  %t23 = icmp sgt i64 %t19, %t20
  br i1 %t23, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_35044444f92db59c_e1f3123be845f968)
  unreachable
bb3:
  %t25 = load i64, ptr %l7, !tbaa !24
  %t27 = icmp sgt i64 %t25, 0
  br i1 %t27, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb8
bb5:
  %t29 = load i64, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = sub i64 %t29, %t30
  %t34 = load i64, ptr %l7, !tbaa !24
  %t37 = add i64 %t33, %t34
  %t39 = sub i64 %t37, 1
  %t40 = load i64, ptr %l7, !tbaa !24
  %t43 = sdiv i64 %t39, %t40
  store i64 %t43, ptr %l23, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t45 = load i64, ptr %l23, !tbaa !24
  store i64 %t45, ptr %l20, !tbaa !24
  br label %bb8
bb8:
  %t46 = load i64, ptr %l20, !tbaa !24
  store i64 %t46, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t47 = load i64, ptr %l9, !tbaa !24
  %t48 = load i64, ptr %l8, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb11:
  br label %bb12
bb12:
  %t55 = load i64, ptr %l5, !tbaa !24
  %t56 = load i64, ptr %l9, !tbaa !24
  %t57 = load i64, ptr %l7, !tbaa !24
  %t60 = mul i64 %t56, %t57
  %t63 = add i64 %t55, %t60
  store i64 %t63, ptr %l10, !tbaa !24
  %t65 = load i64, ptr %l10, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t66, ptr %l42, !tbaa !27
  %t67 = load i64, ptr %l10, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr i8, ptr %t70, i64 %t67
  %t72 = load i8, ptr %t71, !tbaa !32
  %t75 = load ptr, ptr %lp4
  %t77 = getelementptr { i64, ptr }, ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr i8, ptr %t78, i64 %t65
  store i8 %t72, ptr %t79, !tbaa !32
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  %t80 = load i64, ptr %l9, !tbaa !24
  %t82 = add i64 %t80, 1
  store i64 %t82, ptr %l9, !tbaa !24
  br label %bb9
bb14:
  store %"compiler/source:Span" %a1, ptr %l48
  store i32 %a3, ptr %l49, !tbaa !23
  %t88 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0)
  store ptr %t88, ptr %l51
  br label %bb15
bb15:
  %t89 = load ptr, ptr %l51, !tbaa !29
  %t91 = getelementptr %"compiler/check:frame", ptr %t89, i32 0, i32 2
  %t92 = load i64, ptr %t91, !tbaa !24
  %t93 = load ptr, ptr %lp4
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  store { i64, [2 x i64] } zeroinitializer, ptr %t95
  %t96 = getelementptr { i64, [2 x i64] }, ptr %t95, i32 0, i32 0
  store i64 1, ptr %t96
  %t98 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t94, 0
  %t99 = getelementptr { i64, [2 x i64] }, ptr %t95, i32 0, i32 1
  store { { i64, ptr } } %t98, ptr %t99
  %t100 = load { i64, [2 x i64] }, ptr %t95
  %t102 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t100, ptr %t102
  store { i64, [5 x i64] } zeroinitializer, ptr %t103
  %t104 = getelementptr { i64, [5 x i64] }, ptr %t103, i32 0, i32 0
  store i64 1, ptr %t104
  %t105 = load %"compiler/source:Span", ptr %l48
  %t106 = insertvalue { %"compiler/source:Span", i32, i64, ptr } undef, %"compiler/source:Span" %t105, 0
  %t107 = load i32, ptr %l49, !tbaa !23
  %t108 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t106, i32 %t107, 1
  %t110 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t108, i64 %t92, 2
  %t112 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t110, ptr %t102, 3
  %t113 = getelementptr { i64, [5 x i64] }, ptr %t103, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, ptr } %t112, ptr %t113
  %t114 = load { i64, [5 x i64] }, ptr %t103
  %t116 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t114, ptr %t116
  store ptr %t116, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitContracts(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i1
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i1
  %l26 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l46 = alloca { i64, ptr }
  %l50 = alloca i1
  %l65 = alloca i64
  %l69 = alloca ptr
  %l74 = alloca i32
  %l75 = alloca i32
  %l79 = alloca { i64, ptr }
  %l85 = alloca i64
  %l88 = alloca i64
  %l106 = alloca { i64, ptr }
  %l110 = alloca i1
  %l114 = alloca { i64, ptr }
  %l117 = alloca i32
  %l122 = alloca i32
  %l127 = alloca { i64, ptr }
  %l132 = alloca i64
  %l137 = alloca i1
  %s4 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %t237 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/ast:TypeDecl", ptr %t5, i32 0, i32 3
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = icmp eq ptr %t8, null
  store i1 %t10, ptr %l22, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l22, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb6
bb5:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t15 = getelementptr %"compiler/ast:TypeDecl", ptr %t13, i32 0, i32 1
  %t16 = load { i64, ptr }, ptr %t15, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  %t20 = icmp sgt i64 %t18, 0
  store i1 %t20, ptr %l26, !tbaa !21
  br label %bb6
bb6:
  %t22 = load i1, ptr %l26, !tbaa !21
  br i1 %t22, label %bb7, label %bb8
bb7:
  br label %ret
bb8:
  br label %bb9
bb9:
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t25 = getelementptr %"compiler/ast:TypeDecl", ptr %t23, i32 0, i32 3
  %t26 = load ptr, ptr %t25, !tbaa !29
  store ptr %t26, ptr %l3, !tbaa !29
  %t28 = load ptr, ptr %l3, !tbaa !29
  store ptr %t28, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t29 = load ptr, ptr %l33, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t32 = load ptr, ptr %l33, !tbaa !29
  %t33 = load i64, ptr %t32
  %t35 = icmp eq i64 %t33, 2
  store i1 %t35, ptr %l34, !tbaa !21
  br label %bb11
bb11:
  %t36 = load i1, ptr %l34, !tbaa !21
  br i1 %t36, label %bb12, label %bb13
bb12:
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t39 = getelementptr { i64, [6 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t39, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40
  store { i64, ptr } %t41, ptr %l4, !tbaa !27
  br label %bb14
bb13:
  br label %bb59
bb14:
  store i1 false, ptr %l5, !tbaa !21
  %t43 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t43, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t45 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  store i64 %t47, ptr %l8, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t49 = load i64, ptr %l7, !tbaa !24
  %t50 = load i64, ptr %l8, !tbaa !24
  %t53 = icmp slt i64 %t49, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb17:
  br label %bb18
bb18:
  %t57 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t57, ptr %l46, !tbaa !27
  %t58 = load i64, ptr %l7, !tbaa !24
  %t60 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr ptr, ptr %t61, i64 %t58
  %t63 = load ptr, ptr %t62, !tbaa !39
  store ptr %t63, ptr %l9, !tbaa !29
  %t65 = load i1, ptr %l5, !tbaa !21
  br i1 %t65, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb21
bb20:
  %t67 = load ptr, ptr %l9, !tbaa !29
  %t69 = getelementptr %"compiler/ast:Func", ptr %t67, i32 0, i32 3
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/ast:Sig", ptr %t70, i32 0, i32 5
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = icmp eq ptr %t73, null
  %t77 = xor i1 %t75, true
  store i1 %t77, ptr %l50, !tbaa !21
  br label %bb21
bb21:
  %t79 = load i1, ptr %l50, !tbaa !21
  store i1 %t79, ptr %l5, !tbaa !21
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb22:
  %t80 = load i64, ptr %l7, !tbaa !24
  %t82 = add i64 %t80, 1
  store i64 %t82, ptr %l7, !tbaa !24
  br label %bb15
bb23:
  %t84 = load i1, ptr %l5, !tbaa !21
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb24, label %bb25
bb24:
  br label %ret
bb25:
  br label %bb26
bb26:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/check:Checker", ptr %t88, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t92 = load i64, ptr %l1, !tbaa !24
  %t93 = load ptr, ptr %l2, !tbaa !29
  %t95 = getelementptr %"compiler/ast:TypeDecl", ptr %t93, i32 0, i32 0
  %t96 = load i32, ptr %t95, !tbaa !23
  %t100 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %t91, i64 %t92, i32 %t96)
  store i64 %t100, ptr %l65
  br label %bb27
bb27:
  %t101 = load i64, ptr %l65, !tbaa !24
  store i64 %t101, ptr %l10, !tbaa !24
  %t102 = load i64, ptr %l10, !tbaa !24
  %t104 = icmp slt i64 %t102, 0
  br i1 %t104, label %bb28, label %bb29
bb28:
  br label %ret
bb29:
  br label %bb30
bb30:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  store ptr %t109, ptr %l69, !tbaa !29
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/check:Checker", ptr %t110, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t114 = load i64, ptr %l1, !tbaa !24
  %t115 = load i64, ptr %l10, !tbaa !24
  %t119 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t113, i64 %t114, i64 %t115)
  store i32 %t119, ptr %l74
  br label %bb31
bb31:
  %t120 = load ptr, ptr %l69, !tbaa !29
  %t121 = load i32, ptr %l74, !tbaa !23
  %t122 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t120, i32 %t121)
  store i32 %t122, ptr %l75
  br label %bb32
bb32:
  %t123 = load i32, ptr %l75, !tbaa !23
  store i32 %t123, ptr %l11, !tbaa !23
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/check:Checker", ptr %t124, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t128 = load i32, ptr %l11, !tbaa !23
  %t131 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %t127, i32 %t128)
  store { i64, ptr } %t131, ptr %l79
  br label %bb33
bb33:
  %t132 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t132, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t133 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t133, 0
  store i64 %t135, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t137 = load i64, ptr %l14, !tbaa !24
  %t138 = load i64, ptr %l13, !tbaa !24
  %t141 = icmp sgt i64 %t137, %t138
  br i1 %t141, label %bb34, label %bb35
bb34:
  %t143 = load i64, ptr %l15, !tbaa !24
  %t145 = icmp sgt i64 %t143, 0
  br i1 %t145, label %bb36, label %bb37
bb35:
  store i64 0, ptr %l85, !tbaa !24
  br label %bb39
bb36:
  %t147 = load i64, ptr %l14, !tbaa !24
  %t148 = load i64, ptr %l13, !tbaa !24
  %t151 = sub i64 %t147, %t148
  %t152 = load i64, ptr %l15, !tbaa !24
  %t155 = add i64 %t151, %t152
  %t157 = sub i64 %t155, 1
  %t158 = load i64, ptr %l15, !tbaa !24
  %t161 = sdiv i64 %t157, %t158
  store i64 %t161, ptr %l88, !tbaa !24
  br label %bb38
bb37:
  store i64 0, ptr %l88, !tbaa !24
  br label %bb38
bb38:
  %t163 = load i64, ptr %l88, !tbaa !24
  store i64 %t163, ptr %l85, !tbaa !24
  br label %bb39
bb39:
  %t164 = load i64, ptr %l85, !tbaa !24
  store i64 %t164, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s9
  %t165 = load i64, ptr %l17, !tbaa !24
  %t166 = load i64, ptr %l16, !tbaa !24
  %t169 = icmp slt i64 %t165, %t166
  %t171 = xor i1 %t169, true
  br i1 %t171, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s9)
  br label %bb58
bb42:
  br label %bb43
bb43:
  %t173 = load i64, ptr %l13, !tbaa !24
  %t174 = load i64, ptr %l17, !tbaa !24
  %t175 = load i64, ptr %l15, !tbaa !24
  %t178 = mul i64 %t174, %t175
  %t181 = add i64 %t173, %t178
  store i64 %t181, ptr %l18, !tbaa !24
  %t183 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t183, ptr %l106, !tbaa !27
  %t184 = load i64, ptr %l18, !tbaa !24
  %t186 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !27
  %t188 = getelementptr %"compiler/generic:AnySlot", ptr %t187, i64 %t184
  %t189 = getelementptr %"compiler/generic:AnySlot", ptr %t188, i32 0, i32 2
  %t190 = load i64, ptr %t189, !tbaa !24
  %t192 = icmp slt i64 %t190, 0
  br i1 %t192, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l110, !tbaa !21
  br label %bb48
bb45:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/check:Checker", ptr %t194, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !29
  %t199 = getelementptr %"compiler/generic:Program", ptr %t197, i32 0, i32 2
  %t200 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t200, ptr %l114, !tbaa !27
  %t201 = load i64, ptr %l18, !tbaa !24
  %t203 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !27
  %t205 = getelementptr %"compiler/generic:AnySlot", ptr %t204, i64 %t201
  %t206 = getelementptr %"compiler/generic:AnySlot", ptr %t205, i32 0, i32 1
  %t207 = load i32, ptr %t206, !tbaa !23
  %t210 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t199, i32 %t207)
  store i32 %t210, ptr %l117
  br label %bb46
bb46:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/check:Checker", ptr %t211, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t216 = getelementptr %"compiler/generic:Program", ptr %t214, i32 0, i32 2
  %t217 = load i32, ptr %l11, !tbaa !23
  %t220 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t216, i32 %t217)
  store i32 %t220, ptr %l122
  br label %bb47
bb47:
  %t221 = load i32, ptr %l117, !tbaa !23
  %t222 = load i32, ptr %l122, !tbaa !23
  %t223 = icmp ne i32 %t221, %t222
  store i1 %t223, ptr %l110, !tbaa !21
  br label %bb48
bb48:
  %t225 = load i1, ptr %l110, !tbaa !21
  br i1 %t225, label %bb49, label %bb50
bb49:
  call void @__olang_scope_close(ptr %s9)
  br label %bb57
bb50:
  br label %bb51
bb51:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t227 = load i32, ptr %l11, !tbaa !23
  %t228 = load i64, ptr %l18, !tbaa !24
  %t229 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t229, ptr %l127, !tbaa !27
  %t230 = load i64, ptr %l18, !tbaa !24
  %t232 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !27
  %t234 = getelementptr %"compiler/generic:AnySlot", ptr %t233, i64 %t230
  %t235 = getelementptr %"compiler/generic:AnySlot", ptr %t234, i32 0, i32 5
  %t236 = load i32, ptr %t235, !tbaa !23
  store { i64, [3 x i64] } zeroinitializer, ptr %t237
  %t238 = getelementptr { i64, [3 x i64] }, ptr %t237, i32 0, i32 0
  store i64 3, ptr %t238
  %t240 = insertvalue { i32, i64, i32 } undef, i32 %t227, 0
  %t242 = insertvalue { i32, i64, i32 } %t240, i64 %t228, 1
  %t244 = insertvalue { i32, i64, i32 } %t242, i32 %t236, 2
  %t245 = getelementptr { i64, [3 x i64] }, ptr %t237, i32 0, i32 1
  store { i32, i64, i32 } %t244, ptr %t245
  %t246 = load { i64, [3 x i64] }, ptr %t237
  %t248 = call ptr @__olang_scope_alloc_a(ptr %s9, i64 32, i64 8)
  store { i64, [3 x i64] } %t246, ptr %t248
  %t251 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eslotContract(ptr %v0, ptr %s9, ptr %t226, ptr %t248)
  store i64 %t251, ptr %l132
  br label %bb52
bb52:
  %t252 = load i64, ptr %l132, !tbaa !24
  store i64 %t252, ptr %l19, !tbaa !24
  %t253 = load i64, ptr %l19, !tbaa !24
  %t255 = icmp sge i64 %t253, 0
  br i1 %t255, label %bb53, label %bb54
bb53:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load i64, ptr %l19, !tbaa !24
  %t261 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasContract(ptr %v0, ptr %t257, i64 %t258)
  store i1 %t261, ptr %l137
  br label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s9)
  br label %bb57
bb57:
  %t262 = load i64, ptr %l17, !tbaa !24
  %t264 = add i64 %t262, 1
  store i64 %t264, ptr %l17, !tbaa !24
  br label %bb40
bb58:
  br label %bb60
bb59:
  br label %bb60
bb60:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitMethod(ptr %v0, ptr %a0, %"compiler/generic:AnySlot" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/generic:AnySlot"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca ptr
  %l18 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca { i64, ptr }
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/generic:AnySlot" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/generic:AnySlot", ptr %l1, i32 0, i32 2
  %t2 = load i64, ptr %t1, !tbaa !24
  %t4 = icmp slt i64 %t2, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  store ptr null, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l9, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 2
  %t17 = getelementptr %"compiler/generic:AnySlot", ptr %l1, i32 0, i32 1
  %t18 = load i32, ptr %t17, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t16, i32 %t18)
  store i32 %t21, ptr %l14
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l9, !tbaa !29
  %t23 = load i32, ptr %l14, !tbaa !23
  %t24 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t22, i32 %t23)
  store ptr %t24, ptr %l15
  br label %bb5
bb5:
  %t25 = load ptr, ptr %l15, !tbaa !29
  store ptr %t25, ptr %l2, !tbaa !29
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = icmp eq ptr %t26, null
  br i1 %t28, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb8
bb7:
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t32 = getelementptr %"compiler/ast:TypeDecl", ptr %t30, i32 0, i32 3
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = icmp eq ptr %t33, null
  store i1 %t35, ptr %l18, !tbaa !21
  br label %bb8
bb8:
  %t37 = load i1, ptr %l18, !tbaa !21
  br i1 %t37, label %bb9, label %bb10
bb9:
  store ptr null, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t39 = load ptr, ptr %l2, !tbaa !29
  %t41 = getelementptr %"compiler/ast:TypeDecl", ptr %t39, i32 0, i32 3
  %t42 = load ptr, ptr %t41, !tbaa !29
  store ptr %t42, ptr %l3, !tbaa !29
  %t44 = load ptr, ptr %l3, !tbaa !29
  store ptr %t44, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t45 = load ptr, ptr %l25, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb12, label %bb13
bb12:
  %t48 = load ptr, ptr %l25, !tbaa !29
  %t49 = load i64, ptr %t48
  %t51 = icmp eq i64 %t49, 2
  store i1 %t51, ptr %l26, !tbaa !21
  br label %bb13
bb13:
  %t52 = load i1, ptr %l26, !tbaa !21
  br i1 %t52, label %bb14, label %bb15
bb14:
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t55 = getelementptr { i64, [6 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t55, i32 0, i32 0
  %t57 = load { i64, ptr }, ptr %t56
  store { i64, ptr } %t57, ptr %l4, !tbaa !27
  br label %bb16
bb15:
  br label %bb20
bb16:
  %t59 = getelementptr %"compiler/generic:AnySlot", ptr %l1, i32 0, i32 2
  %t60 = load i64, ptr %t59, !tbaa !24
  %t61 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t66 = icmp slt i64 %t60, %t63
  br i1 %t66, label %bb17, label %bb18
bb17:
  %t68 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t68, ptr %l36, !tbaa !27
  %t69 = getelementptr %"compiler/generic:AnySlot", ptr %l1, i32 0, i32 2
  %t70 = load i64, ptr %t69, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr ptr, ptr %t73, i64 %t70
  %t75 = load ptr, ptr %t74, !tbaa !39
  store ptr %t75, ptr %l35, !tbaa !29
  br label %bb19
bb18:
  store ptr null, ptr %l35, !tbaa !29
  br label %bb19
bb19:
  %t78 = load ptr, ptr %l35, !tbaa !29
  store ptr %t78, ptr %rv
  br label %ret
bb20:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etyOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i1
  %l27 = alloca i32
  %l29 = alloca i32
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca ptr
  %l38 = alloca i32
  %l39 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t18, i32 0, i32 3
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb26
bb5:
  %t22 = load ptr, ptr %l3, !tbaa !29
  store ptr %t22, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t23 = load ptr, ptr %l13, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = load ptr, ptr %l13, !tbaa !29
  %t27 = load i64, ptr %t26
  %t29 = icmp eq i64 %t27, 1
  store i1 %t29, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t30 = load i1, ptr %l14, !tbaa !21
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t31 = load ptr, ptr %l3, !tbaa !29
  %t33 = getelementptr { i64, [2 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { { i64, ptr } }, ptr %t33, i32 0, i32 0
  %t35 = load { i64, ptr }, ptr %t34
  store { i64, ptr } %t35, ptr %l4, !tbaa !27
  br label %bb10
bb9:
  br label %bb20
bb10:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i32, ptr %l2, !tbaa !23
  %t41 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t37, i32 %t38)
  store i1 %t41, ptr %l21
  br label %bb11
bb11:
  %t42 = load i1, ptr %l21, !tbaa !21
  br i1 %t42, label %bb12, label %bb13
bb12:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 2
  %t49 = load i32, ptr %l2, !tbaa !23
  %t52 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t48, i32 %t49)
  store i32 %t52, ptr %l27
  br label %bb14
bb13:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb16
bb14:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t53)
  store i32 %t55, ptr %l29
  br label %bb15
bb15:
  %t56 = load i32, ptr %l27, !tbaa !23
  %t57 = load i32, ptr %l29, !tbaa !23
  %t58 = icmp eq i32 %t56, %t57
  store i1 %t58, ptr %l22, !tbaa !21
  br label %bb16
bb16:
  %t60 = load i1, ptr %l22, !tbaa !21
  br i1 %t60, label %bb17, label %bb18
bb17:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d73, i32 0, i32 1) }, ptr %l31, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t61, ptr %l32, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t62, 0
  store i64 %t63, ptr %l33, !tbaa !24
  %t64 = load i64, ptr %l33, !tbaa !24
  %t65 = mul i64 %t64, 1
  %t66 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t65)
  %t67 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  store { i64, ptr } %t68, ptr %l34, !tbaa !27
  %t69 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = load i64, ptr %l33, !tbaa !24
  %t74 = mul i64 %t73, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t70, ptr %t72, i64 %t74, i1 false)
  %t75 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t75, ptr %l32, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t76, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_e722c21055ee6b49_58bcebf0b772fb7d)
  unreachable
bb25:
  br label %bb31
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_eca48244095fc078_aacf4c954a6e214c)
  unreachable
bb31:
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l35, !tbaa !29
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t81 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t78)
  store i32 %t81, ptr %l38
  br label %bb32
bb32:
  %t82 = load ptr, ptr %l35, !tbaa !29
  %t83 = load i32, ptr %l38, !tbaa !23
  %t84 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v2, ptr %t82, i32 %t83)
  store { i64, ptr } %t84, ptr %l39
  br label %bb33
bb33:
  %t85 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t85, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeCaseCovers(ptr %v0, ptr %a0, %"compiler/check:typeCase" %a1, %"compiler/check:typeCase" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/check:typeCase"
  %l2 = alloca %"compiler/check:typeCase"
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l17 = alloca i1
  %l20 = alloca i1
  %l26 = alloca i1
  %l29 = alloca i1
  %l32 = alloca i1
  %l37 = alloca i1
  %l50 = alloca i1
  %l54 = alloca i1
  %l55 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca i32
  %l62 = alloca ptr
  %l67 = alloca i32
  %l72 = alloca i64
  %l76 = alloca i32
  %l77 = alloca i1
  %l82 = alloca i32
  %l86 = alloca i1
  %l91 = alloca i32
  %l100 = alloca i32
  %l105 = alloca i32
  %l110 = alloca ptr
  %l115 = alloca i32
  %l116 = alloca { i64, ptr }
  %l117 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l125 = alloca { i64, ptr }
  %l132 = alloca i32
  %l136 = alloca i1
  %l141 = alloca i64
  %l144 = alloca i1
  %l145 = alloca ptr
  %l150 = alloca i64
  %l151 = alloca i1
  %l153 = alloca ptr
  %l158 = alloca i64
  %s0 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/check:typeCase" %a1, ptr %l1
  store %"compiler/check:typeCase" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 0
  %t2 = load i1, ptr %t1, !tbaa !21
  br i1 %t2, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 0
  %t6 = load i1, ptr %t5, !tbaa !21
  br i1 %t6, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t9 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 1
  %t10 = load i1, ptr %t9, !tbaa !21
  br i1 %t10, label %bb7, label %bb8
bb7:
  %t12 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 1
  %t13 = load i1, ptr %t12, !tbaa !21
  br i1 %t13, label %bb9, label %bb10
bb8:
  br label %bb26
bb9:
  %t15 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 3
  %t16 = load i64, ptr %t15, !tbaa !24
  %t18 = icmp eq i64 %t16, 0
  br i1 %t18, label %bb11, label %bb12
bb10:
  br label %bb18
bb11:
  %t20 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 3
  %t21 = load i64, ptr %t20, !tbaa !24
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l17, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb13
bb13:
  %t25 = load i1, ptr %l17, !tbaa !21
  br i1 %t25, label %bb14, label %bb15
bb14:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 2
  %t32 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t33 = load i32, ptr %t32, !tbaa !23
  %t34 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 2
  %t35 = load i32, ptr %t34, !tbaa !23
  %t39 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t31, i32 %t33, i32 %t35)
  store i1 %t39, ptr %l26
  br label %bb16
bb15:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb17
bb16:
  %t40 = load i1, ptr %l26, !tbaa !21
  store i1 %t40, ptr %l20, !tbaa !21
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t41 = load i1, ptr %l20, !tbaa !21
  store i1 %t41, ptr %rv
  br label %ret
bb18:
  %t42 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 3
  %t43 = load i64, ptr %t42, !tbaa !24
  %t45 = icmp eq i64 %t43, 0
  br i1 %t45, label %bb19, label %bb20
bb19:
  %t47 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 3
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = icmp eq i64 %t48, 0
  store i1 %t50, ptr %l29, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb21
bb21:
  %t52 = load i1, ptr %l29, !tbaa !21
  br i1 %t52, label %bb22, label %bb23
bb22:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t57 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 2
  %t58 = load i32, ptr %t57, !tbaa !23
  %t59 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t60 = load i32, ptr %t59, !tbaa !23
  %t64 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSatisfies(ptr %v0, ptr %t56, i32 %t58, i32 %t60)
  store i1 %t64, ptr %l37
  br label %bb24
bb23:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb25
bb24:
  %t65 = load i1, ptr %l37, !tbaa !21
  store i1 %t65, ptr %l32, !tbaa !21
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t66 = load i1, ptr %l32, !tbaa !21
  store i1 %t66, ptr %rv
  br label %ret
bb26:
  %t67 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 1
  %t68 = load i1, ptr %t67, !tbaa !21
  br i1 %t68, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t71 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 3
  %t72 = load i64, ptr %t71, !tbaa !24
  %t74 = icmp eq i64 %t72, 0
  br i1 %t74, label %bb30, label %bb31
bb30:
  %t76 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 3
  %t77 = load i64, ptr %t76, !tbaa !24
  %t79 = icmp ne i64 %t77, 0
  br i1 %t79, label %bb32, label %bb33
bb31:
  br label %bb47
bb32:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/generic:Program", ptr %t85, i32 0, i32 2
  %t88 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t89 = load i32, ptr %t88, !tbaa !23
  %t90 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 2
  %t91 = load i32, ptr %t90, !tbaa !23
  %t95 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t87, i32 %t89, i32 %t91)
  store i1 %t95, ptr %l50
  br label %bb35
bb35:
  %t96 = load i1, ptr %l50, !tbaa !21
  br i1 %t96, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 2
  %t100 = load i32, ptr %t99, !tbaa !23
  %t103 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t98, i32 %t100)
  store i1 %t103, ptr %l54
  br label %bb39
bb39:
  %t104 = load i1, ptr %l54, !tbaa !21
  br i1 %t104, label %bb40, label %bb41
bb40:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/check:Checker", ptr %t105, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = getelementptr %"compiler/generic:Program", ptr %t108, i32 0, i32 2
  store ptr %t110, ptr %l58, !tbaa !29
  %t111 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t112 = load i32, ptr %t111, !tbaa !23
  store i32 %t112, ptr %l59, !tbaa !23
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/check:Checker", ptr %t113, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = getelementptr %"compiler/generic:Program", ptr %t116, i32 0, i32 2
  store ptr %t118, ptr %l62, !tbaa !29
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/check:Checker", ptr %t119, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t124 = getelementptr %"compiler/generic:Program", ptr %t122, i32 0, i32 2
  %t125 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 2
  %t126 = load i32, ptr %t125, !tbaa !23
  %t129 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t124, i32 %t126)
  store i32 %t129, ptr %l67
  br label %bb42
bb41:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb46
bb42:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/check:Checker", ptr %t130, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t135 = getelementptr %"compiler/generic:Program", ptr %t133, i32 0, i32 2
  %t136 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 2
  %t137 = load i32, ptr %t136, !tbaa !23
  %t140 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t135, i32 %t137)
  store i64 %t140, ptr %l72
  br label %bb43
bb43:
  %t141 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t143 = xor i64 %t141, -1
  %t144 = load i64, ptr %l72, !tbaa !24
  %t146 = and i64 %t144, %t143
  %t147 = load ptr, ptr %l62, !tbaa !29
  %t148 = load i32, ptr %l67, !tbaa !23
  %t150 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t147, i32 %t148, i64 %t146)
  store i32 %t150, ptr %l76
  br label %bb44
bb44:
  %t151 = load ptr, ptr %l58, !tbaa !29
  %t152 = load i32, ptr %l59, !tbaa !23
  %t153 = load i32, ptr %l76, !tbaa !23
  %t154 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t151, i32 %t152, i32 %t153)
  store i1 %t154, ptr %l77
  br label %bb45
bb45:
  %t155 = load i1, ptr %l77, !tbaa !21
  store i1 %t155, ptr %l55, !tbaa !21
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s0)
  %t156 = load i1, ptr %l55, !tbaa !21
  store i1 %t156, ptr %rv
  br label %ret
bb47:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/check:Checker", ptr %t157, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t162 = getelementptr %"compiler/generic:Program", ptr %t160, i32 0, i32 2
  %t163 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t164 = load i32, ptr %t163, !tbaa !23
  %t167 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t162, i32 %t164)
  store i32 %t167, ptr %l82
  br label %bb48
bb48:
  %t168 = load i32, ptr %l82
  %t170 = trunc i64 18 to i32
  %t171 = icmp eq i32 %t168, %t170
  %t173 = xor i1 %t171, true
  br i1 %t173, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l86, !tbaa !21
  br label %bb52
bb50:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/check:Checker", ptr %t175, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !29
  %t180 = getelementptr %"compiler/generic:Program", ptr %t178, i32 0, i32 2
  %t181 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 2
  %t182 = load i32, ptr %t181, !tbaa !23
  %t185 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t180, i32 %t182)
  store i32 %t185, ptr %l91
  br label %bb51
bb51:
  %t186 = load i32, ptr %l91
  %t188 = trunc i64 18 to i32
  %t189 = icmp eq i32 %t186, %t188
  %t191 = xor i1 %t189, true
  store i1 %t191, ptr %l86, !tbaa !21
  br label %bb52
bb52:
  %t193 = load i1, ptr %l86, !tbaa !21
  br i1 %t193, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb54:
  br label %bb55
bb55:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/check:Checker", ptr %t195, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t200 = getelementptr %"compiler/generic:Program", ptr %t198, i32 0, i32 2
  %t201 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t202 = load i32, ptr %t201, !tbaa !23
  %t205 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t200, i32 %t202)
  store i32 %t205, ptr %l100
  br label %bb56
bb56:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/check:Checker", ptr %t206, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !29
  %t211 = getelementptr %"compiler/generic:Program", ptr %t209, i32 0, i32 2
  %t212 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 2
  %t213 = load i32, ptr %t212, !tbaa !23
  %t216 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t211, i32 %t213)
  store i32 %t216, ptr %l105
  br label %bb57
bb57:
  %t217 = load i32, ptr %l100, !tbaa !23
  %t218 = load i32, ptr %l105, !tbaa !23
  %t219 = icmp ne i32 %t217, %t218
  br i1 %t219, label %bb58, label %bb59
bb58:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb59:
  br label %bb60
bb60:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/check:Checker", ptr %t222, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !29
  %t227 = getelementptr %"compiler/generic:Program", ptr %t225, i32 0, i32 2
  store ptr %t227, ptr %l110, !tbaa !29
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/check:Checker", ptr %t228, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !29
  %t233 = getelementptr %"compiler/generic:Program", ptr %t231, i32 0, i32 2
  %t234 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t235 = load i32, ptr %t234, !tbaa !23
  %t238 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t233, i32 %t235)
  store i32 %t238, ptr %l115
  br label %bb61
bb61:
  %t239 = load ptr, ptr %l110, !tbaa !29
  %t240 = load i32, ptr %l115, !tbaa !23
  %t241 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t239, i32 %t240)
  store { i64, ptr } %t241, ptr %l116
  br label %bb62
bb62:
  %t242 = load { i64, ptr }, ptr %l116, !tbaa !27
  store { i64, ptr } %t242, ptr %l3, !tbaa !27
  %t243 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t243, ptr %l117
  br label %bb63
bb63:
  %t244 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l117
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t244, ptr %l4
  %t245 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t245, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t247 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t249 = extractvalue { i64, ptr } %t247, 0
  store i64 %t249, ptr %l7, !tbaa !24
  br label %bb64
bb64:
  store %olang.scope zeroinitializer, ptr %s12
  %t251 = load i64, ptr %l6, !tbaa !24
  %t252 = load i64, ptr %l7, !tbaa !24
  %t255 = icmp slt i64 %t251, %t252
  %t257 = xor i1 %t255, true
  br i1 %t257, label %bb65, label %bb66
bb65:
  call void @__olang_scope_close(ptr %s12)
  br label %bb84
bb66:
  br label %bb67
bb67:
  %t259 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t259, ptr %l125, !tbaa !27
  %t260 = load i64, ptr %l6, !tbaa !24
  %t262 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t263 = load ptr, ptr %t262, !tbaa !27
  %t264 = getelementptr i32, ptr %t263, i64 %t260
  %t265 = load i32, ptr %t264, !tbaa !33
  store i32 %t265, ptr %l8, !tbaa !23
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/check:Checker", ptr %t267, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !29
  %t272 = getelementptr %"compiler/generic:Program", ptr %t270, i32 0, i32 2
  %t273 = load i32, ptr %l8, !tbaa !23
  %t276 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t272, i32 %t273)
  store i32 %t276, ptr %l132
  br label %bb68
bb68:
  %t277 = load i32, ptr %l132
  %t279 = trunc i64 25 to i32
  %t280 = icmp eq i32 %t277, %t279
  %t282 = xor i1 %t280, true
  br i1 %t282, label %bb69, label %bb70
bb69:
  store i1 true, ptr %l136, !tbaa !21
  br label %bb72
bb70:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t286 = getelementptr %"compiler/check:Checker", ptr %t284, i32 0, i32 1
  %t287 = load ptr, ptr %t286, !tbaa !29
  %t289 = getelementptr %"compiler/generic:Program", ptr %t287, i32 0, i32 2
  %t290 = load i32, ptr %l8, !tbaa !23
  %t293 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t289, i32 %t290)
  store i64 %t293, ptr %l141
  br label %bb71
bb71:
  %t294 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 4
  %t295 = load i64, ptr %t294, !tbaa !24
  %t296 = load i64, ptr %l141, !tbaa !24
  %t298 = icmp ne i64 %t296, %t295
  store i1 %t298, ptr %l136, !tbaa !21
  br label %bb72
bb72:
  %t300 = load i1, ptr %l136, !tbaa !21
  br i1 %t300, label %bb73, label %bb74
bb73:
  store i1 true, ptr %l144, !tbaa !21
  br label %bb77
bb74:
  store ptr %l4, ptr %l145, !tbaa !29
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t303 = getelementptr %"compiler/check:Checker", ptr %t301, i32 0, i32 1
  %t304 = load ptr, ptr %t303, !tbaa !29
  %t306 = getelementptr %"compiler/generic:Program", ptr %t304, i32 0, i32 2
  %t307 = load i32, ptr %l8, !tbaa !23
  %t310 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t306, i32 %t307)
  store i64 %t310, ptr %l150
  br label %bb75
bb75:
  %t311 = load ptr, ptr %l145, !tbaa !29
  %t312 = load i64, ptr %l150, !tbaa !24
  %t313 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eHas_3cI64_3e(ptr %s0, ptr %t311, i64 %t312)
  store i1 %t313, ptr %l151
  br label %bb76
bb76:
  %t314 = load i1, ptr %l151, !tbaa !21
  store i1 %t314, ptr %l144, !tbaa !21
  br label %bb77
bb77:
  %t315 = load i1, ptr %l144, !tbaa !21
  br i1 %t315, label %bb78, label %bb79
bb78:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb79:
  br label %bb80
bb80:
  store ptr %l4, ptr %l153, !tbaa !29
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t319 = getelementptr %"compiler/check:Checker", ptr %t317, i32 0, i32 1
  %t320 = load ptr, ptr %t319, !tbaa !29
  %t322 = getelementptr %"compiler/generic:Program", ptr %t320, i32 0, i32 2
  %t323 = load i32, ptr %l8, !tbaa !23
  %t326 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t322, i32 %t323)
  store i64 %t326, ptr %l158
  br label %bb81
bb81:
  %t327 = load ptr, ptr %l153, !tbaa !29
  %t328 = load i64, ptr %l158, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t327, i64 %t328)
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s12)
  br label %bb83
bb83:
  %t329 = load i64, ptr %l6, !tbaa !24
  %t331 = add i64 %t329, 1
  store i64 %t331, ptr %l6, !tbaa !24
  br label %bb64
bb84:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca %"compiler/names:Ref"
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca %"compiler/names:Ref"
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i32
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca i1
  %l26 = alloca ptr
  %l28 = alloca ptr
  %l32 = alloca %"compiler/names:Ref"
  %l37 = alloca i32
  %l41 = alloca i32
  %l45 = alloca i1
  %l48 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca i32
  %l57 = alloca i1
  %l60 = alloca i32
  %l62 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca i32
  %l70 = alloca i1
  %l75 = alloca i32
  %l79 = alloca i1
  %l84 = alloca i32
  %l89 = alloca ptr
  %l90 = alloca i1
  %l97 = alloca ptr
  %l99 = alloca ptr
  %l103 = alloca %"compiler/names:Ref"
  %l106 = alloca i1
  %l109 = alloca ptr
  %l114 = alloca i32
  %l115 = alloca i32
  %l116 = alloca ptr
  %l117 = alloca i1
  %l128 = alloca i32
  %l131 = alloca i1
  %l136 = alloca i32
  %l142 = alloca { i64, ptr }
  %l156 = alloca i32
  %l160 = alloca i32
  %l166 = alloca i1
  %l168 = alloca ptr
  %l172 = alloca %"compiler/source:Span"
  %l173 = alloca { i64, ptr }
  %l175 = alloca %"compiler/source:Span"
  %l178 = alloca { i64, ptr }
  %l183 = alloca { i64, ptr }
  %l187 = alloca i64
  %l189 = alloca i64
  %l190 = alloca %"compiler/msgs:Msg"
  %l191 = alloca i64
  %l194 = alloca ptr
  %l196 = alloca ptr
  %l201 = alloca i32
  %l205 = alloca i1
  %l209 = alloca i1
  %l211 = alloca i1
  %l215 = alloca i1
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca i32
  %t307 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t2 = load ptr, ptr %l16, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l16, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l17, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l17, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb45
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  store ptr %t28, ptr %l26, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t29)
  store ptr %t31, ptr %l28
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l28, !tbaa !29
  %t34 = getelementptr %"compiler/check:frame", ptr %t32, i32 0, i32 2
  %t35 = load i64, ptr %t34, !tbaa !24
  %t36 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t37 = load i32, ptr %t36, !tbaa !23
  %t38 = load ptr, ptr %l26, !tbaa !29
  %t41 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t38, i64 %t35, i32 %t37)
  store %"compiler/names:Ref" %t41, ptr %l32
  br label %bb7
bb7:
  %t42 = load %"compiler/names:Ref", ptr %l32
  store %"compiler/names:Ref" %t42, ptr %l4
  %t43 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t44 = load i32, ptr %t43
  %t46 = trunc i64 7 to i32
  %t47 = icmp eq i32 %t44, %t46
  br i1 %t47, label %bb8, label %bb9
bb8:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i32, ptr %l3, !tbaa !23
  %t53 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuiltinType(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t53, ptr %l37
  br label %bb10
bb9:
  br label %bb14
bb10:
  %t54 = load i32, ptr %l37, !tbaa !23
  store i32 %t54, ptr %l5, !tbaa !23
  %t55 = load i32, ptr %l5, !tbaa !23
  %t56 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t59 = icmp ne i32 %t55, %t56
  br i1 %t59, label %bb11, label %bb12
bb11:
  %t61 = load i32, ptr %l5, !tbaa !23
  store i32 %t61, ptr %l41, !tbaa !23
  br label %bb13
bb12:
  store i32 -1, ptr %l41, !tbaa !23
  br label %bb13
bb13:
  %t63 = load i32, ptr %l41, !tbaa !23
  store i32 %t63, ptr %rv
  br label %ret
bb14:
  %t64 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t65 = load i32, ptr %t64
  %t67 = trunc i64 4 to i32
  %t68 = icmp eq i32 %t65, %t67
  br i1 %t68, label %bb15, label %bb16
bb15:
  %t70 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 2
  %t71 = load i64, ptr %t70, !tbaa !24
  %t73 = icmp sge i64 %t71, 0
  store i1 %t73, ptr %l45, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb17
bb17:
  %t75 = load i1, ptr %l45, !tbaa !21
  br i1 %t75, label %bb18, label %bb19
bb18:
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l48, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t81 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 1
  %t82 = load i64, ptr %t81, !tbaa !24
  %t83 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 2
  %t84 = load i64, ptr %t83, !tbaa !24
  %t88 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t80, i64 %t82, i64 %t84)
  store i32 %t88, ptr %l53
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t89 = load ptr, ptr %l48, !tbaa !29
  %t90 = load i32, ptr %l53, !tbaa !23
  %t91 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclType(ptr %v0, ptr %t89, i32 %t90)
  store i32 %t91, ptr %l54
  br label %bb21
bb21:
  %t92 = load i32, ptr %l54, !tbaa !23
  store i32 %t92, ptr %rv
  br label %ret
bb22:
  %t93 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t94 = load i32, ptr %t93
  %t96 = trunc i64 8 to i32
  %t97 = icmp eq i32 %t94, %t96
  br i1 %t97, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb25
bb24:
  %t99 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t100 = load i32, ptr %t99
  %t102 = trunc i64 0 to i32
  %t103 = icmp eq i32 %t100, %t102
  store i1 %t103, ptr %l57, !tbaa !21
  br label %bb25
bb25:
  %t105 = load i1, ptr %l57, !tbaa !21
  br i1 %t105, label %bb26, label %bb27
bb26:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t106)
  store ptr %t108, ptr %l62
  br label %bb28
bb27:
  br label %bb44
bb28:
  %t109 = load ptr, ptr %l62, !tbaa !29
  %t111 = getelementptr %"compiler/check:frame", ptr %t109, i32 0, i32 4
  %t112 = getelementptr %"compiler/generic:Context", ptr %t111, i32 0, i32 2
  %t113 = load i32, ptr %l3, !tbaa !23
  %t116 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v0, ptr %t112, i32 %t113)
  %t117 = extractvalue { i32, i32 } %t116, 1
  %t118 = extractvalue { i32, i32 } %t116, 0
  store i32 %t118, ptr %l67
  %t119 = icmp ne i32 %t118, 0
  br i1 %t119, label %bb30, label %ok.120
ok.120:
  store i32 %t117, ptr %l66
  br label %bb29
bb29:
  %t121 = load i32, ptr %l66, !tbaa !23
  store i32 %t121, ptr %l60, !tbaa !23
  br label %bb32
bb30:
  br label %bb31
bb31:
  call void @__olang_ert_req_clear()
  store i32 -1, ptr %l60, !tbaa !23
  br label %bb32
bb32:
  %t122 = load i32, ptr %l60, !tbaa !23
  store i32 %t122, ptr %l6, !tbaa !23
  %t123 = load i32, ptr %l6, !tbaa !23
  %t125 = icmp sge i32 %t123, 0
  br i1 %t125, label %bb33, label %bb34
bb33:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/check:Checker", ptr %t127, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t132 = getelementptr %"compiler/generic:Program", ptr %t130, i32 0, i32 2
  %t133 = load i32, ptr %l6, !tbaa !23
  %t136 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t132, i32 %t133)
  store i32 %t136, ptr %l75
  br label %bb35
bb34:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb36
bb35:
  %t137 = load i32, ptr %l75
  %t139 = trunc i64 26 to i32
  %t140 = icmp eq i32 %t137, %t139
  %t142 = xor i1 %t140, true
  store i1 %t142, ptr %l70, !tbaa !21
  br label %bb36
bb36:
  %t144 = load i1, ptr %l70, !tbaa !21
  br i1 %t144, label %bb37, label %bb38
bb37:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/check:Checker", ptr %t145, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !29
  %t150 = getelementptr %"compiler/generic:Program", ptr %t148, i32 0, i32 2
  %t151 = load i32, ptr %l6, !tbaa !23
  %t154 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t150, i32 %t151)
  store i32 %t154, ptr %l84
  br label %bb39
bb38:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb40
bb39:
  %t155 = load i32, ptr %l84
  %t157 = trunc i64 27 to i32
  %t158 = icmp eq i32 %t155, %t157
  %t160 = xor i1 %t158, true
  store i1 %t160, ptr %l79, !tbaa !21
  br label %bb40
bb40:
  %t162 = load i1, ptr %l79, !tbaa !21
  br i1 %t162, label %bb41, label %bb42
bb41:
  %t163 = load i32, ptr %l6, !tbaa !23
  store i32 %t163, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  br label %bb44
bb44:
  br label %bb113
bb45:
  %t165 = load ptr, ptr %l1, !tbaa !29
  store ptr %t165, ptr %l89, !tbaa !29
  store i1 false, ptr %l90, !tbaa !21
  %t166 = load ptr, ptr %l89, !tbaa !29
  %t167 = icmp ne ptr %t166, null
  br i1 %t167, label %bb46, label %bb47
bb46:
  %t169 = load ptr, ptr %l89, !tbaa !29
  %t170 = load i64, ptr %t169
  %t172 = icmp eq i64 %t170, 15
  store i1 %t172, ptr %l90, !tbaa !21
  br label %bb47
bb47:
  %t173 = load i1, ptr %l90, !tbaa !21
  br i1 %t173, label %bb48, label %bb49
bb48:
  %t174 = load ptr, ptr %l1, !tbaa !29
  %t176 = getelementptr { i64, [5 x i64] }, ptr %t174, i32 0, i32 1
  %t177 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t176, i32 0, i32 0
  %t178 = load %"compiler/source:Span", ptr %t177
  store %"compiler/source:Span" %t178, ptr %l7
  br label %bb50
bb49:
  br label %bb61
bb50:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/check:Checker", ptr %t180, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !29
  %t185 = getelementptr %"compiler/generic:Program", ptr %t183, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !29
  store ptr %t186, ptr %l97, !tbaa !29
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t187)
  store ptr %t189, ptr %l99
  br label %bb51
bb51:
  %t190 = load ptr, ptr %l99, !tbaa !29
  %t192 = getelementptr %"compiler/check:frame", ptr %t190, i32 0, i32 2
  %t193 = load i64, ptr %t192, !tbaa !24
  %t194 = getelementptr %"compiler/source:Span", ptr %l7, i32 0, i32 1
  %t195 = load i32, ptr %t194, !tbaa !23
  %t196 = load ptr, ptr %l97, !tbaa !29
  %t199 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %t196, i64 %t193, i32 %t195)
  store %"compiler/names:Ref" %t199, ptr %l103
  br label %bb52
bb52:
  %t200 = load %"compiler/names:Ref", ptr %l103
  store %"compiler/names:Ref" %t200, ptr %l8
  %t201 = getelementptr %"compiler/names:Ref", ptr %l8, i32 0, i32 0
  %t202 = load i32, ptr %t201
  %t204 = trunc i64 4 to i32
  %t205 = icmp eq i32 %t202, %t204
  br i1 %t205, label %bb53, label %bb54
bb53:
  %t207 = getelementptr %"compiler/names:Ref", ptr %l8, i32 0, i32 2
  %t208 = load i64, ptr %t207, !tbaa !24
  %t210 = icmp sge i64 %t208, 0
  store i1 %t210, ptr %l106, !tbaa !21
  br label %bb55
bb54:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb55
bb55:
  %t212 = load i1, ptr %l106, !tbaa !21
  br i1 %t212, label %bb56, label %bb57
bb56:
  %t213 = load ptr, ptr %l0, !tbaa !29
  store ptr %t213, ptr %l109, !tbaa !29
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/check:Checker", ptr %t214, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !29
  %t218 = getelementptr %"compiler/names:Ref", ptr %l8, i32 0, i32 1
  %t219 = load i64, ptr %t218, !tbaa !24
  %t220 = getelementptr %"compiler/names:Ref", ptr %l8, i32 0, i32 2
  %t221 = load i64, ptr %t220, !tbaa !24
  %t225 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t217, i64 %t219, i64 %t221)
  store i32 %t225, ptr %l114
  br label %bb58
bb57:
  br label %bb60
bb58:
  %t226 = load ptr, ptr %l109, !tbaa !29
  %t227 = load i32, ptr %l114, !tbaa !23
  %t228 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclType(ptr %v0, ptr %t226, i32 %t227)
  store i32 %t228, ptr %l115
  br label %bb59
bb59:
  %t229 = load i32, ptr %l115, !tbaa !23
  store i32 %t229, ptr %rv
  br label %ret
bb60:
  br label %bb113
bb61:
  %t230 = load ptr, ptr %l1, !tbaa !29
  store ptr %t230, ptr %l116, !tbaa !29
  store i1 false, ptr %l117, !tbaa !21
  %t231 = load ptr, ptr %l116, !tbaa !29
  %t232 = icmp ne ptr %t231, null
  br i1 %t232, label %bb62, label %bb63
bb62:
  %t234 = load ptr, ptr %l116, !tbaa !29
  %t235 = load i64, ptr %t234
  %t237 = icmp eq i64 %t235, 14
  store i1 %t237, ptr %l117, !tbaa !21
  br label %bb63
bb63:
  %t238 = load i1, ptr %l117, !tbaa !21
  br i1 %t238, label %bb64, label %bb65
bb64:
  %t239 = load ptr, ptr %l1, !tbaa !29
  %t241 = getelementptr { i64, [5 x i64] }, ptr %t239, i32 0, i32 1
  %t242 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t241, i32 0, i32 0
  %t243 = load %"compiler/source:Span", ptr %t242
  store %"compiler/source:Span" %t243, ptr %l9
  %t245 = load ptr, ptr %l1, !tbaa !29
  %t247 = getelementptr { i64, [5 x i64] }, ptr %t245, i32 0, i32 1
  %t248 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t247, i32 0, i32 1
  %t249 = load ptr, ptr %t248
  store ptr %t249, ptr %l10, !tbaa !29
  %t251 = load ptr, ptr %l1, !tbaa !29
  %t253 = getelementptr { i64, [5 x i64] }, ptr %t251, i32 0, i32 1
  %t254 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t253, i32 0, i32 2
  %t255 = load { i64, ptr }, ptr %t254
  store { i64, ptr } %t255, ptr %l11, !tbaa !27
  br label %bb66
bb65:
  br label %bb112
bb66:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load ptr, ptr %l10, !tbaa !29
  %t261 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericNamed(ptr %v0, ptr %v1, ptr %t257, ptr %t258)
  store i32 %t261, ptr %l128
  br label %bb67
bb67:
  %t262 = load i32, ptr %l128, !tbaa !23
  store i32 %t262, ptr %l12, !tbaa !23
  %t263 = load i32, ptr %l12, !tbaa !23
  %t265 = icmp slt i32 %t263, 0
  br i1 %t265, label %bb68, label %bb69
bb68:
  store i1 true, ptr %l131, !tbaa !21
  br label %bb71
bb69:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/check:Checker", ptr %t267, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !29
  %t272 = getelementptr %"compiler/generic:Program", ptr %t270, i32 0, i32 2
  %t273 = load i32, ptr %l12, !tbaa !23
  %t276 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t272, i32 %t273)
  store i32 %t276, ptr %l136
  br label %bb70
bb70:
  %t277 = load i32, ptr %l136
  %t279 = trunc i64 1 to i32
  %t280 = icmp eq i32 %t277, %t279
  %t282 = xor i1 %t280, true
  store i1 %t282, ptr %l131, !tbaa !21
  br label %bb71
bb71:
  %t284 = load i1, ptr %l131, !tbaa !21
  br i1 %t284, label %bb72, label %bb73
bb72:
  store i32 -1, ptr %rv
  br label %ret
bb73:
  br label %bb74
bb74:
  %t286 = load ptr, ptr %l10, !tbaa !29
  %t288 = call { i64, ptr } @compiler_2fcheck_2etypePathOf(ptr %v1, ptr %t286)
  store { i64, ptr } %t288, ptr %l142
  br label %bb75
bb75:
  %t289 = load { i64, ptr }, ptr %l142, !tbaa !27
  store { i64, ptr } %t289, ptr %l13, !tbaa !27
  %t290 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t292 = extractvalue { i64, ptr } %t290, 0
  %t294 = icmp eq i64 %t292, 0
  br i1 %t294, label %bb76, label %bb77
bb76:
  store i32 -1, ptr %rv
  br label %ret
bb77:
  br label %bb78
bb78:
  %t297 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t299 = extractvalue { i64, ptr } %t297, 0
  %t301 = icmp eq i64 %t299, 1
  br i1 %t301, label %bb79, label %bb80
bb79:
  store %olang.scope zeroinitializer, ptr %s11
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t304 = load %"compiler/source:Span", ptr %l9
  %t305 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t306 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t307
  %t308 = getelementptr { i64, [5 x i64] }, ptr %t307, i32 0, i32 0
  store i64 0, ptr %t308
  %t310 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t304, 0
  %t312 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t310, { i64, ptr } %t305, 1
  %t314 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t312, { i64, ptr } %t306, 2
  %t315 = getelementptr { i64, [5 x i64] }, ptr %t307, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t314, ptr %t315
  %t316 = load { i64, [5 x i64] }, ptr %t307
  %t318 = call ptr @__olang_scope_alloc_a(ptr %s11, i64 48, i64 8)
  store { i64, [5 x i64] } %t316, ptr %t318
  %t321 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %s11, ptr %t303, ptr %t318)
  store i32 %t321, ptr %l156
  br label %bb81
bb80:
  br label %bb85
bb81:
  %t322 = load i32, ptr %l156, !tbaa !23
  store i32 %t322, ptr %l14, !tbaa !23
  %t323 = load i32, ptr %l14, !tbaa !23
  %t324 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t327 = icmp ne i32 %t323, %t324
  br i1 %t327, label %bb82, label %bb83
bb82:
  %t329 = load i32, ptr %l14, !tbaa !23
  store i32 %t329, ptr %l160, !tbaa !23
  br label %bb84
bb83:
  store i32 -1, ptr %l160, !tbaa !23
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s11)
  %t331 = load i32, ptr %l160, !tbaa !23
  store i32 %t331, ptr %rv
  br label %ret
bb85:
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t334 = getelementptr %"compiler/check:Checker", ptr %t332, i32 0, i32 1
  %t335 = load ptr, ptr %t334, !tbaa !29
  %t336 = load i32, ptr %l12, !tbaa !23
  %t337 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t341 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eArgsFit(ptr %v0, ptr %v1, ptr %t335, i32 %t336, { i64, ptr } %t337)
  store i1 %t341, ptr %l166
  br label %bb86
bb86:
  %t342 = load i1, ptr %l166, !tbaa !21
  %t343 = xor i1 %t342, true
  br i1 %t343, label %bb87, label %bb88
bb87:
  store %olang.scope zeroinitializer, ptr %s12
  %t345 = load ptr, ptr %l0, !tbaa !29
  store ptr %t345, ptr %l168, !tbaa !29
  %t346 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t348 = extractvalue { i64, ptr } %t346, 0
  %t350 = icmp sgt i64 %t348, 0
  br i1 %t350, label %bb89, label %bb90
bb88:
  br label %bb98
bb89:
  %t352 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t352, ptr %l173, !tbaa !27
  %t353 = getelementptr { i64, ptr }, ptr %l173, i32 0, i32 1
  %t354 = load ptr, ptr %t353, !tbaa !27
  %t355 = getelementptr ptr, ptr %t354, i64 0
  %t356 = load ptr, ptr %t355, !tbaa !39
  %t358 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t356)
  store %"compiler/source:Span" %t358, ptr %l175
  br label %bb91
bb90:
  %t359 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t359, ptr %l172
  br label %bb92
bb91:
  %t361 = load %"compiler/source:Span", ptr %l175
  store %"compiler/source:Span" %t361, ptr %l172
  br label %bb92
bb92:
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t363 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t363, ptr %l178, !tbaa !27
  %t364 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t366 = extractvalue { i64, ptr } %t364, 0
  %t368 = sub i64 %t366, 1
  %t370 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t371 = load ptr, ptr %t370, !tbaa !27
  %t372 = getelementptr i32, ptr %t371, i64 %t368
  %t373 = load i32, ptr %t372, !tbaa !33
  %t376 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t362, i32 %t373)
  store { i64, ptr } %t376, ptr %l183
  br label %bb93
bb93:
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t379 = getelementptr %"compiler/check:Checker", ptr %t377, i32 0, i32 1
  %t380 = load ptr, ptr %t379, !tbaa !29
  %t381 = load i32, ptr %l12, !tbaa !23
  %t384 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWrittenArity(ptr %v0, ptr %t380, i32 %t381)
  store i64 %t384, ptr %l187
  br label %bb94
bb94:
  %t385 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t387 = call i64 @compiler_2fgeneric_2eWrittenTypes(ptr %v1, { i64, ptr } %t385)
  store i64 %t387, ptr %l189
  br label %bb95
bb95:
  %t388 = load { i64, ptr }, ptr %l183, !tbaa !27
  %t389 = load i64, ptr %l187, !tbaa !24
  %t390 = load i64, ptr %l189, !tbaa !24
  %t391 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgCount(ptr %v0, ptr %s12, { i64, ptr } %t388, i64 %t389, i64 %t390)
  store %"compiler/msgs:Msg" %t391, ptr %l190
  br label %bb96
bb96:
  %t392 = load ptr, ptr %l168, !tbaa !29
  %t393 = load %"compiler/source:Span", ptr %l172
  %t394 = load %"compiler/msgs:Msg", ptr %l190
  %t395 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s12, ptr %t392, %"compiler/source:Span" %t393, %"compiler/msgs:Msg" %t394)
  store i64 %t395, ptr %l191
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s12)
  store i32 -1, ptr %rv
  br label %ret
bb98:
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t399 = getelementptr %"compiler/check:Checker", ptr %t397, i32 0, i32 1
  %t400 = load ptr, ptr %t399, !tbaa !29
  store ptr %t400, ptr %l194, !tbaa !29
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t403 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t401)
  store ptr %t403, ptr %l196
  br label %bb99
bb99:
  %t404 = load ptr, ptr %l196, !tbaa !29
  %t406 = getelementptr %"compiler/check:frame", ptr %t404, i32 0, i32 4
  %t407 = load i32, ptr %l12, !tbaa !23
  %t408 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t409 = load ptr, ptr %l194, !tbaa !29
  %t413 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eApply(ptr %v0, ptr %v0, ptr %v1, ptr %t409, ptr %t406, i32 %t407, { i64, ptr } %t408)
  store i32 %t413, ptr %l201
  br label %bb100
bb100:
  %t414 = load i32, ptr %l201, !tbaa !23
  store i32 %t414, ptr %l15, !tbaa !23
  %t415 = load i32, ptr %l15, !tbaa !23
  %t416 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t419 = icmp eq i32 %t415, %t416
  br i1 %t419, label %bb101, label %bb102
bb101:
  store i1 true, ptr %l205, !tbaa !21
  br label %bb104
bb102:
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t422 = load i32, ptr %l15, !tbaa !23
  %t423 = load %"compiler/source:Span", ptr %l9
  %t427 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesMet(ptr %v0, ptr %t421, i32 %t422, %"compiler/source:Span" %t423)
  store i1 %t427, ptr %l209
  br label %bb103
bb103:
  %t428 = load i1, ptr %l209, !tbaa !21
  %t429 = xor i1 %t428, true
  store i1 %t429, ptr %l205, !tbaa !21
  br label %bb104
bb104:
  %t431 = load i1, ptr %l205, !tbaa !21
  br i1 %t431, label %bb105, label %bb106
bb105:
  store i1 true, ptr %l211, !tbaa !21
  br label %bb108
bb106:
  %t432 = load ptr, ptr %l0, !tbaa !29
  %t434 = getelementptr %"compiler/check:Checker", ptr %t432, i32 0, i32 1
  %t435 = load ptr, ptr %t434, !tbaa !29
  %t436 = load i32, ptr %l15, !tbaa !23
  %t439 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t435, i32 %t436)
  store i1 %t439, ptr %l215
  br label %bb107
bb107:
  %t440 = load i1, ptr %l215, !tbaa !21
  %t441 = xor i1 %t440, true
  store i1 %t441, ptr %l211, !tbaa !21
  br label %bb108
bb108:
  %t443 = load i1, ptr %l211, !tbaa !21
  br i1 %t443, label %bb109, label %bb110
bb109:
  store i32 -1, ptr %rv
  br label %ret
bb110:
  br label %bb111
bb111:
  %t445 = load i32, ptr %l15, !tbaa !23
  store i32 %t445, ptr %rv
  br label %ret
bb112:
  br label %bb113
bb113:
  store i32 -1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2eexprKindName(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i1
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 4
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d74, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb77
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t11 = load ptr, ptr %l6, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l6, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 9
  store i1 %t17, ptr %l7, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l7, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d75, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb77
bb12:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb13, label %bb14
bb13:
  %t23 = load ptr, ptr %l10, !tbaa !29
  %t24 = load i64, ptr %t23
  %t26 = icmp eq i64 %t24, 11
  store i1 %t26, ptr %l11, !tbaa !21
  br label %bb14
bb14:
  %t27 = load i1, ptr %l11, !tbaa !21
  br i1 %t27, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d76, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb77
bb18:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t29 = load ptr, ptr %l14, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb19, label %bb20
bb19:
  %t32 = load ptr, ptr %l14, !tbaa !29
  %t33 = load i64, ptr %t32
  %t35 = icmp eq i64 %t33, 13
  store i1 %t35, ptr %l15, !tbaa !21
  br label %bb20
bb20:
  %t36 = load i1, ptr %l15, !tbaa !21
  br i1 %t36, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d77, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb77
bb24:
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t38 = load ptr, ptr %l18, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb25, label %bb26
bb25:
  %t41 = load ptr, ptr %l18, !tbaa !29
  %t42 = load i64, ptr %t41
  %t44 = icmp eq i64 %t42, 14
  store i1 %t44, ptr %l19, !tbaa !21
  br label %bb26
bb26:
  %t45 = load i1, ptr %l19, !tbaa !21
  br i1 %t45, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  store { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d78, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb77
bb30:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t47 = load ptr, ptr %l22, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb31, label %bb32
bb31:
  %t50 = load ptr, ptr %l22, !tbaa !29
  %t51 = load i64, ptr %t50
  %t53 = icmp eq i64 %t51, 19
  store i1 %t53, ptr %l23, !tbaa !21
  br label %bb32
bb32:
  %t54 = load i1, ptr %l23, !tbaa !21
  br i1 %t54, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d79, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb77
bb36:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t56 = load ptr, ptr %l26, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb37, label %bb38
bb37:
  %t59 = load ptr, ptr %l26, !tbaa !29
  %t60 = load i64, ptr %t59
  %t62 = icmp eq i64 %t60, 20
  store i1 %t62, ptr %l27, !tbaa !21
  br label %bb38
bb38:
  %t63 = load i1, ptr %l27, !tbaa !21
  br i1 %t63, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d80, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb77
bb42:
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t65 = load ptr, ptr %l30, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb43, label %bb44
bb43:
  %t68 = load ptr, ptr %l30, !tbaa !29
  %t69 = load i64, ptr %t68
  %t71 = icmp eq i64 %t69, 23
  store i1 %t71, ptr %l31, !tbaa !21
  br label %bb44
bb44:
  %t72 = load i1, ptr %l31, !tbaa !21
  br i1 %t72, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d81, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb77
bb48:
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t74 = load ptr, ptr %l34, !tbaa !29
  %t75 = icmp ne ptr %t74, null
  br i1 %t75, label %bb49, label %bb50
bb49:
  %t77 = load ptr, ptr %l34, !tbaa !29
  %t78 = load i64, ptr %t77
  %t80 = icmp eq i64 %t78, 24
  store i1 %t80, ptr %l35, !tbaa !21
  br label %bb50
bb50:
  %t81 = load i1, ptr %l35, !tbaa !21
  br i1 %t81, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  store { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d82, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb77
bb54:
  %t82 = load ptr, ptr %l0, !tbaa !29
  store ptr %t82, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t83 = load ptr, ptr %l38, !tbaa !29
  %t84 = icmp ne ptr %t83, null
  br i1 %t84, label %bb55, label %bb56
bb55:
  %t86 = load ptr, ptr %l38, !tbaa !29
  %t87 = load i64, ptr %t86
  %t89 = icmp eq i64 %t87, 25
  store i1 %t89, ptr %l39, !tbaa !21
  br label %bb56
bb56:
  %t90 = load i1, ptr %l39, !tbaa !21
  br i1 %t90, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb60
bb59:
  store { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d83, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb77
bb60:
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t92 = load ptr, ptr %l42, !tbaa !29
  %t93 = icmp ne ptr %t92, null
  br i1 %t93, label %bb61, label %bb62
bb61:
  %t95 = load ptr, ptr %l42, !tbaa !29
  %t96 = load i64, ptr %t95
  %t98 = icmp eq i64 %t96, 26
  store i1 %t98, ptr %l43, !tbaa !21
  br label %bb62
bb62:
  %t99 = load i1, ptr %l43, !tbaa !21
  br i1 %t99, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb66
bb65:
  store { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d84, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb77
bb66:
  %t100 = load ptr, ptr %l0, !tbaa !29
  store ptr %t100, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t101 = load ptr, ptr %l46, !tbaa !29
  %t102 = icmp ne ptr %t101, null
  br i1 %t102, label %bb67, label %bb68
bb67:
  %t104 = load ptr, ptr %l46, !tbaa !29
  %t105 = load i64, ptr %t104
  %t107 = icmp eq i64 %t105, 16
  store i1 %t107, ptr %l47, !tbaa !21
  br label %bb68
bb68:
  %t108 = load i1, ptr %l47, !tbaa !21
  br i1 %t108, label %bb69, label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb72
bb71:
  store { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d85, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb77
bb72:
  br i1 true, label %bb73, label %bb74
bb73:
  br label %bb75
bb74:
  br label %bb76
bb75:
  store { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d86, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb77
bb76:
  call void @__olang_check_failed(ptr @olang_loc_d149dd778abfbb99_ce32867ac8840ced)
  unreachable
bb77:
  %t109 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t109, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2elitText(ptr %v0, %"compiler/check:litv" %a0) #0 {
entry:
  %l0 = alloca %"compiler/check:litv"
  %l2 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store %"compiler/check:litv" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 2
  %t2 = load i1, ptr %t1, !tbaa !21
  br i1 %t2, label %bb1, label %bb2
bb1:
  %t4 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 3
  %t5 = load i64, ptr %t4, !tbaa !24
  %t8 = call i64 @__olang_fmt_u64(ptr null, i64 %t5)
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = call i64 @__olang_fmt_u64(ptr %t9, i64 %t5)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t9, 1
  store { i64, ptr } %t12, ptr %l2, !tbaa !27
  br label %bb3
bb2:
  %t14 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 3
  %t15 = load i64, ptr %t14, !tbaa !24
  %t17 = call i64 @__olang_fmt_i64(ptr null, i64 %t15)
  %t18 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t17)
  %t19 = call i64 @__olang_fmt_i64(ptr %t18, i64 %t15)
  %t20 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t18, 1
  store { i64, ptr } %t21, ptr %l2, !tbaa !27
  br label %bb3
bb3:
  %t23 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t23, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcheck_2eliteralOrder_2einit() #0 {
entry:
  %l0 = alloca [12 x { i64, ptr }]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 0
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d87, i32 0, i32 1) }, ptr %t1, !tbaa !37
  %t2 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 1
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d88, i32 0, i32 1) }, ptr %t2, !tbaa !37
  %t3 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 2
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d89, i32 0, i32 1) }, ptr %t3, !tbaa !37
  %t4 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 3
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d90, i32 0, i32 1) }, ptr %t4, !tbaa !37
  %t5 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 4
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d91, i32 0, i32 1) }, ptr %t5, !tbaa !37
  %t6 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 5
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d92, i32 0, i32 1) }, ptr %t6, !tbaa !37
  %t7 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 6
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d93, i32 0, i32 1) }, ptr %t7, !tbaa !37
  %t8 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 7
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d94, i32 0, i32 1) }, ptr %t8, !tbaa !37
  %t9 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 8
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d95, i32 0, i32 1) }, ptr %t9, !tbaa !37
  %t10 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 9
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d96, i32 0, i32 1) }, ptr %t10, !tbaa !37
  %t11 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 10
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d97, i32 0, i32 1) }, ptr %t11, !tbaa !37
  %t12 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 11
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d98, i32 0, i32 1) }, ptr %t12, !tbaa !37
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2fcheck_2eliteralOrder, ptr %l0, i64 192, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2enamedFn(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i1
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 15
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l11, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_a1143936e424f416_6a846c9af99dae82)
  unreachable
bb16:
  %t25 = load i1, ptr %l9, !tbaa !21
  store i1 %t25, ptr %l2, !tbaa !21
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_b0c5dfd122db8337_2ed6598a574b6003)
  unreachable
bb22:
  %t26 = load i1, ptr %l2, !tbaa !21
  store i1 %t26, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %rv
  br label %ret
bb6:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2estoredIf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/ast:If", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t4, ptr %t5)
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/ast:If", ptr %t8, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = icmp eq ptr %t11, null
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/ast:If", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = icmp eq ptr %t20, null
  br i1 %t22, label %bb4, label %bb5
bb3:
  br label %bb8
bb4:
  call void @__olang_check_failed(ptr @olang_loc_b4de3dcccf9032b4_264e366d03c66670)
  unreachable
bb5:
  br label %bb6
bb6:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/ast:If", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t30 = getelementptr %"compiler/ast:Branch", ptr %t27, i32 0, i32 1
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  %t32 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %t31, ptr %t32)
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/ast:If", ptr %t35, i32 0, i32 2
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t39 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredStmt(ptr %v0, ptr %v1, ptr %t38, ptr %t39)
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2eunwrapped(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l12 = alloca i1
  %l18 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 12
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb19
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Seq", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = icmp eq ptr %t19, null
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Seq", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = icmp eq ptr %t28, null
  br i1 %t30, label %bb8, label %bb9
bb7:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb12
bb8:
  call void @__olang_check_failed(ptr @olang_loc_db336c98c3d140f2_e2aca3dd623cb216)
  unreachable
bb9:
  br label %bb10
bb10:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr %"compiler/typed:Seq", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = call i1 @compiler_2fcheck_2epureRead(ptr %v0, ptr %t35)
  store i1 %t37, ptr %l18
  br label %bb11
bb11:
  %t38 = load i1, ptr %l18, !tbaa !21
  store i1 %t38, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  %t39 = load i1, ptr %l12, !tbaa !21
  br i1 %t39, label %bb13, label %bb14
bb13:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr %"compiler/typed:Seq", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = icmp eq ptr %t43, null
  br i1 %t45, label %bb15, label %bb16
bb14:
  br label %bb18
bb15:
  call void @__olang_check_failed(ptr @olang_loc_db336c98c3d140f2_e2aca3dd623cb216)
  unreachable
bb16:
  br label %bb17
bb17:
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr %"compiler/typed:Seq", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  store ptr %t50, ptr %rv
  br label %ret
bb18:
  br label %bb20
bb19:
  br label %bb20
bb20:
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/check:laneVals" @compiler_2fcheck_3alaneVals_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca i64
  %l2 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/check:laneVals"
  br label %start
start:
  br label %bb0
bb0:
  store i64 -1, ptr %l0, !tbaa !24
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l2
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l2
  %t3 = load i64, ptr %l0, !tbaa !24
  %t4 = insertvalue %"compiler/check:laneVals" undef, i64 %t3, 0
  %t6 = insertvalue %"compiler/check:laneVals" %t4, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, 1
  store %"compiler/check:laneVals" %t6, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:laneVals", ptr %rv
  ret %"compiler/check:laneVals" %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %v0, i1 %a0, i1 %a1, i1 %a2, i64 %a3, double %a4) #0 {
entry:
  %rv = alloca %"compiler/check:litv"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/check:litv" undef, i1 %a0, 0
  %t14 = insertvalue %"compiler/check:litv" %t12, i1 %a1, 1
  %t16 = insertvalue %"compiler/check:litv" %t14, i1 %a2, 2
  %t18 = insertvalue %"compiler/check:litv" %t16, i64 %a3, 3
  %t20 = insertvalue %"compiler/check:litv" %t18, double %a4, 4
  %t22 = insertvalue %"compiler/check:litv" %t20, i1 false, 5
  store %"compiler/check:litv" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local %"compiler/check:reflVal" @compiler_2fcheck_3areflVal_2ector(ptr %v0, ptr %v1, i1 %a0, i64 %a1, i64 %a2, { i64, ptr } %a3, i32 %a4) #0 {
entry:
  %rv = alloca %"compiler/check:reflVal"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/check:reflVal" undef, i1 %a0, 0
  %t14 = insertvalue %"compiler/check:reflVal" %t12, i64 %a1, 1
  %t16 = insertvalue %"compiler/check:reflVal" %t14, i64 %a2, 2
  %t18 = insertvalue %"compiler/check:reflVal" %t16, { i64, ptr } %a3, 3
  %t20 = insertvalue %"compiler/check:reflVal" %t18, i32 %a4, 4
  store %"compiler/check:reflVal" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:reflVal", ptr %rv
  ret %"compiler/check:reflVal" %rr
}

define dso_local void @olang_2einit_2ecompiler_2fcheck() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fcheck_2eCtReq_2einit()
  br label %bb1
bb1:
  call void @compiler_2fcheck_2eCtEns_2einit()
  br label %bb2
bb2:
  call void @compiler_2fcheck_2eCtEntry_2einit()
  br label %bb3
bb3:
  call void @compiler_2fcheck_2eOpShapes_2einit()
  br label %bb4
bb4:
  call void @compiler_2fcheck_2eRoStored_2einit()
  br label %bb5
bb5:
  call void @compiler_2fcheck_2eRoDecl_2einit()
  br label %bb6
bb6:
  call void @compiler_2fcheck_2eRoReturned_2einit()
  br label %bb7
bb7:
  call void @compiler_2fcheck_2eRoGlobal_2einit()
  br label %bb8
bb8:
  call void @compiler_2fcheck_2eliteralOrder_2einit()
  br label %bb9
bb9:
  call void @compiler_2fcheck_2eRvInt_2einit()
  br label %bb10
bb10:
  call void @compiler_2fcheck_2eRvBool_2einit()
  br label %bb11
bb11:
  call void @compiler_2fcheck_2eRvText_2einit()
  br label %bb12
bb12:
  call void @compiler_2fcheck_2eRvCase_2einit()
  br label %bb13
bb13:
  call void @compiler_2fcheck_2eLaneArr_2einit()
  br label %bb14
bb14:
  call void @compiler_2fcheck_2eLaneScalar_2einit()
  br label %bb15
bb15:
  call void @compiler_2fcheck_2eLaneBin_2einit()
  br label %bb16
bb16:
  call void @compiler_2fcheck_2eLaneUn_2einit()
  br label %bb17
bb17:
  call void @compiler_2fcheck_2eLaneCmp_2einit()
  br label %bb18
bb18:
  call void @compiler_2fcheck_2eLaneSel_2einit()
  br label %bb19
bb19:
  call void @compiler_2fcheck_2eLaneMagic_2einit()
  br label %bb20
bb20:
  br label %ret
ret:
  ret void
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr)
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.d0 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
@.d1 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d2 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Array" }>, align 8
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare void @__olang_ert_req_clear()
@.d3 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Plus" }>, align 8
@.d4 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Mul" }>, align 8
@.d5 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"BitAnd" }>, align 8
@.d6 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"BitOr" }>, align 8
@.d7 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"BitXor" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d8 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Plus" }>, align 8
@.d9 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'+'" }>, align 8
@.d10 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Mul" }>, align 8
@.d11 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'*'" }>, align 8
@.d12 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"BitAnd" }>, align 8
@.d13 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'&'" }>, align 8
@.d14 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"BitOr" }>, align 8
@.d15 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'|'" }>, align 8
@.d16 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'^'" }>, align 8
@.d17 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d18 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d19 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
@.d20 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
@.d21 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d22 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"a field the checker cannot place" }>, align 8
@.d23 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"std/prelude/argument" }>, align 8
@.d24 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"ArgumentError" }>, align 8
@.d25 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d26 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"'not'" }>, align 8
@.d27 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"break" }>, align 8
@.d28 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"=>" }>, align 8
@.d29 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"?" }>, align 8
@.d30 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d31 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Array" }>, align 8
@.d32 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c") noreturn" }>, align 8
@.d33 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"true" }>, align 8
@.d34 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"'return'" }>, align 8
@.d35 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d36 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"nothing" }>, align 8
@.d37 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d38 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"what its body can fail with" }>, align 8
@.d39 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"noreturn" }>, align 8
@.d40 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d41 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d42 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"any " }>, align 8
@.d43 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Array<" }>, align 8
@.d44 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"own " }>, align 8
@.d45 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"mut " }>, align 8
@.d46 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"?&" }>, align 8
@.d47 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"&" }>, align 8
@.d48 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"(fn(" }>, align 8
@.d49 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn(" }>, align 8
@.d50 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d51 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d52 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d53 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" ?" }>, align 8
@.d54 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d55 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d56 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d57 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d58 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"enum {" }>, align 8
@.d59 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d60 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d61 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d62 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" }" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d63 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"nothing" }>, align 8
@.d64 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d65 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Inc" }>, align 8
@.d66 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Dec" }>, align 8
@.d67 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Plus" }>, align 8
@.d68 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Minus" }>, align 8
@.d69 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Inc" }>, align 8
@.d70 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Dec" }>, align 8
@.d71 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"'++'" }>, align 8
@.d72 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"'--'" }>, align 8
@.d73 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"String" }>, align 8
@.d74 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"an increment as a value (S3a)" }>, align 8
@.d75 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"'is' with a type (E32)" }>, align 8
@.d76 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"'as' (E32)" }>, align 8
@.d77 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"a scope argument (E25)" }>, align 8
@.d78 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"a generic name as a value" }>, align 8
@.d79 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"a nested row (E21)" }>, align 8
@.d80 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"a comprehension (E27)" }>, align 8
@.d81 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"a lambda (D16)" }>, align 8
@.d82 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"a match value (S12b)" }>, align 8
@.d83 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"a range outside a for (S9b)" }>, align 8
@.d84 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"'default' outside a call (E14a)" }>, align 8
@.d85 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"an index of this kind" }>, align 8
@.d86 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"an expression of this kind" }>, align 8
declare i64 @__olang_fmt_u64(ptr, i64)
@.d87 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
@.d88 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d89 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d90 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F32" }>, align 8
@.d91 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d92 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U32" }>, align 8
@.d93 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F16" }>, align 8
@.d94 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"BF16" }>, align 8
@.d95 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I16" }>, align 8
@.d96 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U16" }>, align 8
@.d97 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"I8" }>, align 8
@.d98 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare i1 @compiler_2fcheck_2eisHexDigit(i8 %a0)
declare i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_76c98d42818871e4_51853c380fcafc70 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStmt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
@olang_loc_5b6dfd884f12314a_d55d816e86cc2196 = external constant [0 x i8]
@olang_loc_fdeda218c1a4d1e1_676c59a9a8adaaad = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@olang_loc_d8b8a4cfeb0897ac_ce33cd750b46e790 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eOwning = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i1 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTrack(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %a0, ptr %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eReopen(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ewrittenMut(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eDefined(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknownType(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eArgsFit(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWrittenArity(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2eWrittenTypes(ptr %v0, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgCount(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/msgs:Msg" %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_He6be2b0836caba7ddc59483ff74db438(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorSetItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %v0, i32 %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %a0, %"compiler/typed:Item" %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsErrVar(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsErrorSet(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eEntriesOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_1cd9defc72140005_b2649171260378c9 = external constant [0 x i8]
declare { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorWord(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorItemKnown(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCommutesNotHere(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCommutesSameType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCommutesClash(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %v0, i32 %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econstCond(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anullNarrow_3e_2e_H86c927da52ed537ecb3749a8061e4fd7(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushNulls(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2, i64 %a3)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anullNarrow_3e_2e_H929f17842d04d84b7252ab4439481a7f(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondBranchTypes(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eNullT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\0F\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2emeetPerm(i64 %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_db85c439bc9f5684_3c0400873f27ba78 = external constant [0 x i8]
declare %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectSourceOf(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_4d78ccd557b2cb07_4b61304073c9a48b = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eToAr_H9d0f958437b2bc29fe1d416dfb9901d7(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2ftypes_2eDefaultErrT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eRoleFn = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
@G_2ecompiler_2ftypes_2eOwnScope = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopes(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/generic:Context" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectContext(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %a0)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3)
@olang_loc_82a7c94587506de8_24388316e0066d9c = external constant [0 x i8]
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparam(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i64 %a4, ptr %a5)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eSetVars(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, { %"compiler/cond:Value", i1 } } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eValueOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2eintFloatBits(i32 %a0, %"compiler/check:litv" %a1)
declare i64 @compiler_2fcheck_2efloatBits(i32 %a0, double %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuildConst(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeck(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewakeThunks(ptr %v0, ptr %a0)
@olang_loc_2d16f3aa36d067c5_95008946090581a1 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estrBytes(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H4b90e82c7a9c5937397e46eef988cfe3(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H031c7c147cc8ce0b988dd3fed8d142ad(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eEmbedPathUndecided(ptr %v0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i32 %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eEmbedPathUnknown(ptr %v0)
declare %"compiler/check:EmbedAsk" @compiler_2fcheck_3aEmbedAsk_2ector(ptr %v0, i64 %a0, i64 %a1, i32 %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aEmbedAsk_3e_2ePu_Hace14f5ea0faa2954e863427c94d4269(ptr %v0, ptr %a0, %"compiler/check:EmbedAsk" %a1)
declare { { i64, ptr }, { i64, ptr } } @compiler_2fload_2ecompiler_2fload_3aLoader_2eEmbed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eEmbedNotRead(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitCtor(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_12a7e56ab193c888_f3ea9b5a769b449c = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullRead(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eFieldOfEnum(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSuchMember(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldIndex(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ementionsVar(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckNow(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMemberIsPrivate(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/check:b5aWalk" @compiler_2fcheck_3ab5aWalk_2ector(ptr %v0, i64 %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aFn(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eL_H39694dc3b7c161b4999ab170e8f3fd84(ptr %v0, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleft(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aContractAsk_3e_2_Hb6ae083c0cacd8c0f7c4b8758a199876(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aContractAsk_3e_2_H588006d0a62537be0708297bfbeb4a05(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsWritable(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeclFromNoreturn(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeclFromNull(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeNotInferable(ptr %v0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9109cadfb541186e_2a46ab96c2b41f0a = external constant [0 x i8]
@olang_loc_4bb92e4e6aa9fa92_ae49a41c9a1a92ee = external constant [0 x i8]
declare %"compiler/check:laneNode" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3alaneNode_3e_2eAt_H1a82638d5202f9f6649df5fa501425e5(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
@olang_loc_24a46e21631caff9_33b011dc8e05d16d = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneBool(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunaryOn(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOut(ptr %v0, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5, %"compiler/source:Span" %a6, %"compiler/source:Span" %a7)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneType(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistItems(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/check:reflList" %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflIndexRange(ptr %v0, i64 %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescriptor(ptr %v0, ptr %a0, %"compiler/check:reflList" %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebreakUnless(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare %"compiler/check:nullNarrow" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anullNarrow_3e_2e_H9251d6c69ab4c1f2fc390a801d12eb1a(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/check:nullNarrow" @compiler_2fcheck_3anullNarrow_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i1 %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anullNarrow_3e_2e_H4655d3a13eddeb483b63f4107fff886e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/check:nullNarrow" %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, [2 x i64] } %a5)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aArm_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cBool_3e_2ector(ptr %v0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsClosedTrait(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMembers(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3ccompiler_2fast_3aPattern_26_3e_26_3e_2ector(ptr %v0)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseAfterWildcard(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aAlt_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0)
declare i1 @compiler_2fcheck_2eisWild(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eWildcardNotAlone(ptr %v0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindsType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyCaseAlone(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBind_26_3e_2ector(ptr %v0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseName(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
@olang_loc_d3fec93f25782e10_68d55d5867a9701c = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epattern(ptr %v0, ptr %v1, ptr %a0, ptr %a1, ptr %a2, i32 %a3, ptr %a4, i64 %a5)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ealtNames(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i64 %a3, ptr %a4)
@olang_loc_55099387dbe6ec6f_8ffe0a81fb6ca70b = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBind_26_3e_2eToA_Haa3aaef1a08a39694cf52a6e640ce172(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/typed:Alt" @compiler_2ftyped_3aAlt_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aAlt_26_3e_2ePush_3ccompiler_2ftyped_3aAlt_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecover(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, ptr %a3, i1 %a4)
declare { i64, ptr } @compiler_2fcheck_2epatRow(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fast_3aPattern_26_H1d860e259259c4952a7ac353d360c942(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_43973455075247be_e5a2b369b5afd60a = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
@olang_loc_65d4e94bd43e965_f352b379463fef11 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eGuardNotBool(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_d6337ada1dd29694_8ce46a4ddad80bd8 = external constant [0 x i8]
@olang_loc_922951d2017ae1a3_4c5f7ef571495bf7 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordBefore(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrowInStatement(ptr %v0)
@olang_loc_ce31ac887a0ebd22_30602d5443d77806 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2enullValue(ptr %v0, ptr %a0)
@olang_loc_14962851291ac789_3280c2851d649aed = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitArray(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_cfe87ec003b82748_d94fc5f0b326c124 = external constant [0 x i8]
declare { ptr, i1 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efitQuiet(ptr %v0, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
@olang_loc_2d3bd09159184b67_8c3194b4e7d06af3 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchValueMismatch(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4)
declare i1 @compiler_2fcheck_2eleavesValue(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebraceAfter(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseBlockStays(ptr %v0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aAlt_26_3e_2eToAr_H3e99e7a5e111f31f686caa567ecdef7c(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/typed:Arm" @compiler_2ftyped_3aArm_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, %"compiler/source:Span" %a0, { i64, ptr } %a1, ptr %a2, ptr %a3, ptr %a4)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aArm_26_3e_2ePush_3ccompiler_2ftyped_3aArm_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_ce7cfa545e041e73_169b678143e0167 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eRunFrom_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_643d73169027a84b_389e1bbb110ca97f = external constant [0 x i8]
@olang_loc_655dce139344447_4241f7f5f2334ea3 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecoversRows(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3)
@olang_loc_dcdc4b5c1e449f32_62ceda096b9852b6 = external constant [0 x i8]
@olang_loc_d9c718d647bddfff_22edbe4f84dc963b = external constant [0 x i8]
@olang_loc_3a843a558863e2e0_22d07d3cfe1539cc = external constant [0 x i8]
@olang_loc_3e82470ef2956af5_ad5cca336f09c301 = external constant [0 x i8]
@olang_loc_ddb0759225e71b4e_d466412c7868a47a = external constant [0 x i8]
@olang_loc_d249702171a05a8b_2937796e970ca26f = external constant [0 x i8]
@olang_loc_ab20c2f7dddd239c_a82caf25e09de410 = external constant [0 x i8]
@olang_loc_1cb8a67bcda73d28_932f2868e4afd59c = external constant [0 x i8]
@olang_loc_f97b348e6d625e47_ba57d59278730c8b = external constant [0 x i8]
@olang_loc_814511bd48ee038e_643da95161de4c6a = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efirstUncovered(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatchNotExhaustive(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatchValueNeedsNomatch(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1)
@olang_loc_2c70c8b858b42283_1a594eed4640d73f = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aArm_26_3e_2eToAr_H5bf9b1ae81338b8dbc841edb7f38b9b5(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/typed:Match" @compiler_2ftyped_3aMatch_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, ptr %a2, i1 %a3)
@olang_loc_6cbd96901f6df06f_ceca876e38978373 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordCount(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_e5a247dfc16ec462_1cb55c2f24e67da6 = external constant [0 x i8]
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecaseDecl(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamLen(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyOfCallee(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKeepVal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceName(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_b4fa9ecc50f06b0b_d6ee486f71837477 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20compil_Hd792a4b485af98ba4ad9cd9a7f4f4722(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_674cd1771ebc67df_c0fbe9e0645b3c13 = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeep(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_4accb82e327e9b5e_83bcad9ba4931212 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCopied(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, %"compiler/check:roOrigin" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hfc56ff01c357e6bb827daf7012f18a86(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare %"compiler/check:roOrigin" @compiler_2fcheck_3aroOrigin_2ector(ptr %v0, ptr %v1, ptr %a0, i1 %a1)
@G_2ecompiler_2ftypes_2eResultVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@olang_loc_de80a8bbdf5854b0_34f8ecda9179f3f4 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eContractOutlivesNotParam(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectErr(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, %"compiler/msgs:Msg" %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eContractOutlivesNoScope(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2eprimName(ptr %v0, i32 %a0)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2equalifierFor(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espellArgs(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eNullable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eFromTypeVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espellList(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i32 %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeNames(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeFields(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_fe73ad2ef66395ad_6bb388f528f40629 = external constant [0 x i8]
@olang_loc_97840d8df2a94e80_8f65c6ae19d7bb5c = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, ptr } %a7)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4, i64 %a5, i1 %a6)
@olang_loc_729de81d3b051823_7dce08f61f50e4bf = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %a0, ptr %a1)
@olang_loc_35044444f92db59c_e1f3123be845f968 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eslotContract(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasContract(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_e722c21055ee6b49_58bcebf0b772fb7d = external constant [0 x i8]
@olang_loc_eca48244095fc078_aacf4c954a6e214c = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSatisfies(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclType(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2etypePathOf(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eApply(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, { i64, ptr } %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesMet(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
@olang_loc_d149dd778abfbb99_ce32867ac8840ced = external constant [0 x i8]
@olang_loc_a1143936e424f416_6a846c9af99dae82 = external constant [0 x i8]
@olang_loc_b0c5dfd122db8337_2ed6598a574b6003 = external constant [0 x i8]
declare void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_b4de3dcccf9032b4_264e366d03c66670 = external constant [0 x i8]
declare void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare void @compiler_2fcheck_2estoredStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_db336c98c3d140f2_e2aca3dd623cb216 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2epureRead(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2eCtReq_2einit()
declare void @compiler_2fcheck_2eCtEns_2einit()
declare void @compiler_2fcheck_2eCtEntry_2einit()
declare void @compiler_2fcheck_2eOpShapes_2einit()
declare void @compiler_2fcheck_2eRoStored_2einit()
declare void @compiler_2fcheck_2eRoDecl_2einit()
declare void @compiler_2fcheck_2eRoReturned_2einit()
declare void @compiler_2fcheck_2eRoGlobal_2einit()
declare void @compiler_2fcheck_2eRvBool_2einit()
declare void @compiler_2fcheck_2eRvText_2einit()
declare void @compiler_2fcheck_2eRvCase_2einit()
declare void @compiler_2fcheck_2eLaneArr_2einit()
declare void @compiler_2fcheck_2eLaneScalar_2einit()
declare void @compiler_2fcheck_2eLaneBin_2einit()
declare void @compiler_2fcheck_2eLaneUn_2einit()
declare void @compiler_2fcheck_2eLaneCmp_2einit()
declare void @compiler_2fcheck_2eLaneSel_2einit()
declare void @compiler_2fcheck_2eLaneMagic_2einit()
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
