; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/generic:AnySlot" = type { i32, i32, i64, i64, i1, i32 }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, i64, i64, i64, i64, i64, i64, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i1, i1, %"std/prelude/text:StringBuilder", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr } }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, ptr, i1, i1 }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr, { i64, ptr } }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i32, i64, i64, i64, i1, i64, i1, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i64, i1 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i32, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/check:b5aWalk" = type { i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, { i64, ptr } }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/check:UnrollAsk" = type { { i64, ptr }, { i64, ptr }, i64, i32 }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/check:reflList" = type { i1, i32, i64, i64 }
%"compiler/check:reflVal" = type { i1, i64, i64, { i64, ptr }, i32 }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/generic:Desc" = type { i64, i32, i64, i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/check:errNarrow" = type { i32, i32, i64, i1 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, { i64, ptr }, i1 }
%"compiler/check:laneNode" = type { i64, i32, %"compiler/source:Span", %"compiler/source:Span", i64, i64, i64, ptr, i32, i64, i32 }
%"compiler/check:laneVals" = type { i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1, i1, i1, i128 }
%"compiler/msgs:Nearest" = type { { i64, ptr }, { i64, ptr }, i64 }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/check:roArg" = type { i64, i64, { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"std/pair:Pair.b139c4f75a6545712256427180a82a06" = type { %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" }
%"compiler/check:roDeepArg" = type { i64, ptr, i64, i64 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] }, i1 }
%"compiler/names:Unread" = type { i64, %"compiler/source:Span", i32, i1 }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/check:signMag" = type { i1, i128 }
%"compiler/check:errBind" = type { i32, i64, i32, %"compiler/source:Span" }
%"compiler/check:fixedInit" = type { ptr, i32 }
%"compiler/check:idleCall" = type { i64, i64, %"compiler/source:Span", { i64, ptr }, ptr }
%"compiler/check:typeCase" = type { i1, i1, i32, i64, i64, i1 }
@G_2ecompiler_2fcheck_2eCtEns = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eCtEntry = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eCtReq = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eLaneArr = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eLaneBin = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eLaneCmp = constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eLaneMagic = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\01\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eLaneScalar = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eLaneSel = constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eLaneUn = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eMaxUnroll = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\10\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes = constant <{ [8 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k1, [24 x i8] c"\01\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k2, [24 x i8] c"\01\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k3, [24 x i8] c"\01\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k4, [24 x i8] c"\01\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k5, [24 x i8] c"\01\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k6, [24 x i8] c"\01\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k7, [24 x i8] c"\00\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k8, [24 x i8] c"\01\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k9, [24 x i8] c"\01\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k10, [24 x i8] c"\02\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k11, [24 x i8] c"\02\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k12, [24 x i8] c"\01\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k13, [24 x i8] c"\01\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k14, [24 x i8] c"\01\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k15, [24 x i8] c"\01\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\0A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k16, [24 x i8] c"\01\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k17, [24 x i8] c"\00\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k18, [24 x i8] c"\00\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k19, [24 x i8] c"\00\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k20, [24 x i8] c"\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k21, [24 x i8] c"\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k22, [16 x i8] c"\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2fcheck_2eOpShapes.k1 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\50\6C\75\73" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k2 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\4D\69\6E\75\73" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k3 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\4D\75\6C" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k4 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\44\69\76" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k5 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\52\65\6D" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k6 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\4D\61\74\4D\75\6C" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k7 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\4E\65\67" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k8 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\4C\65\73\73" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k9 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\41\74" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k10 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\53\65\74\41\74" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k11 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\53\6C\69\63\65" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k12 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\42\69\74\41\6E\64" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k13 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\42\69\74\4F\72" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k14 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\42\69\74\58\6F\72" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k15 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\53\68\69\66\74\4C\65\66\74" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k16 = internal constant <{ [10 x i8] }> <{ [10 x i8] c"\53\68\69\66\74\52\69\67\68\74" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k17 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\42\69\74\4E\6F\74" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k18 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\49\6E\63" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k19 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\44\65\63" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k20 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\4C\65\6E" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k21 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\45\71" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k22 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\53\74\72" }>, align 8
@G_2ecompiler_2fcheck_2eRoDecl = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eRoGlobal = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eRoReturned = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eRoStored = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eRvBool = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eRvCase = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eRvInt = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eRvText = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eliteralOrder = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eliteralOrder.k1, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eliteralOrder.k2, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eliteralOrder.k3, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eliteralOrder.k4, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eliteralOrder.k5, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eliteralOrder.k6, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eliteralOrder.k7, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eliteralOrder.k8, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eliteralOrder.k9, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eliteralOrder.k10, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eliteralOrder.k11, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eliteralOrder.k12 }>, align 64
@G_2ecompiler_2fcheck_2eliteralOrder.k1 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\46\36\34" }>, align 8
@G_2ecompiler_2fcheck_2eliteralOrder.k2 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\49\36\34" }>, align 8
@G_2ecompiler_2fcheck_2eliteralOrder.k3 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\55\36\34" }>, align 8
@G_2ecompiler_2fcheck_2eliteralOrder.k4 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\46\33\32" }>, align 8
@G_2ecompiler_2fcheck_2eliteralOrder.k5 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\49\33\32" }>, align 8
@G_2ecompiler_2fcheck_2eliteralOrder.k6 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\55\33\32" }>, align 8
@G_2ecompiler_2fcheck_2eliteralOrder.k7 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\46\31\36" }>, align 8
@G_2ecompiler_2fcheck_2eliteralOrder.k8 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\42\46\31\36" }>, align 8
@G_2ecompiler_2fcheck_2eliteralOrder.k9 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\49\31\36" }>, align 8
@G_2ecompiler_2fcheck_2eliteralOrder.k10 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\55\31\36" }>, align 8
@G_2ecompiler_2fcheck_2eliteralOrder.k11 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\49\38" }>, align 8
@G_2ecompiler_2fcheck_2eliteralOrder.k12 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\55\38" }>, align 8
define dso_local i1 @compiler_2fcheck_2ecallLike(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l27 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 29}
  %t8 = icmp eq i64 %t6, 12
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t11 = load ptr, ptr %l7, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l7, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 29}
  %t17 = icmp eq i64 %t15, 13
  store i1 %t17, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l8, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t21 = load ptr, ptr %l12, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb11, label %bb12
bb11:
  %t24 = load ptr, ptr %l12, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 29}
  %t27 = icmp eq i64 %t25, 2
  store i1 %t27, ptr %l13, !tbaa !21
  br label %bb12
bb12:
  %t28 = load i1, ptr %l13, !tbaa !21
  br i1 %t28, label %bb13, label %bb14
bb13:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", ptr }, ptr %t31, i32 0, i32 1
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l1, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = call i1 @compiler_2fcheck_2ecallLike(ptr %v0, ptr %t35)
  store i1 %t37, ptr %l19
  br label %bb16
bb16:
  %t38 = load i1, ptr %l19, !tbaa !21
  store i1 %t38, ptr %rv
  br label %ret
bb17:
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t40 = load ptr, ptr %l20, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb18, label %bb19
bb18:
  %t43 = load ptr, ptr %l20, !tbaa !29
  %t44 = load i64, ptr %t43, !range !{i64 0, i64 29}
  %t46 = icmp eq i64 %t44, 22
  store i1 %t46, ptr %l21, !tbaa !21
  br label %bb19
bb19:
  %t47 = load i1, ptr %l21, !tbaa !21
  br i1 %t47, label %bb20, label %bb21
bb20:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr { i64, [5 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t50, i32 0, i32 1
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l2, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t54 = load ptr, ptr %l2, !tbaa !29
  %t56 = call i1 @compiler_2fcheck_2ecallLike(ptr %v0, ptr %t54)
  store i1 %t56, ptr %l27
  br label %bb23
bb23:
  %t57 = load i1, ptr %l27, !tbaa !21
  store i1 %t57, ptr %rv
  br label %ret
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store i1 false, ptr %rv
  br label %ret
bb28:
  call void @__olang_check_failed(ptr @olang_loc_6e7767865267b99e_88e6ff5d2bea5fe2)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargDefault(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, i64 %a4, i1 %a5, i32 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l4 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"compiler/generic:AnySlot"
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i1
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l47 = alloca ptr
  %l50 = alloca ptr
  %l55 = alloca i1
  %l58 = alloca i1
  %l65 = alloca i1
  %l68 = alloca { i64, ptr }
  %l76 = alloca i64
  %l81 = alloca ptr
  %l82 = alloca %"compiler/source:Span"
  %l83 = alloca i64
  %l86 = alloca { i64, ptr }
  %l88 = alloca %"compiler/msgs:Msg"
  %l89 = alloca i64
  %l92 = alloca ptr
  %l97 = alloca i32
  %l102 = alloca i64
  %l104 = alloca ptr
  %l108 = alloca ptr
  %l114 = alloca ptr
  %l115 = alloca ptr
  %l119 = alloca %"compiler/generic:Context"
  %l123 = alloca ptr
  %l126 = alloca { i64, ptr }
  %l134 = alloca ptr
  %l139 = alloca ptr
  %l152 = alloca ptr
  %l153 = alloca %"compiler/source:Span"
  %l154 = alloca i64
  %l155 = alloca i64
  %l156 = alloca i1
  %l157 = alloca i32
  %l160 = alloca i32
  %l161 = alloca ptr
  %s3 = alloca %olang.scope
  %rv = alloca ptr
  %t278 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a4, ptr %l4
  store i32 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t2 = load ptr, ptr %l22, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l22, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 5}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l23, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l23, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i32, i64, i32 }, ptr %t12, i32 0, i32 0
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l7, !tbaa !23
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { i32, i64, i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l8, !tbaa !24
  br label %bb5
bb4:
  br label %bb49
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t26 = load i32, ptr %l7, !tbaa !23
  %t29 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %t25, i32 %t26)
  store { i64, ptr } %t29, ptr %l33
  br label %bb6
bb6:
  %t30 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t30, ptr %l9, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t31, ptr %l34, !tbaa !27
  %t32 = load i64, ptr %l8, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t38 = srem i64 %t32, %t35
  %t40 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr %"compiler/generic:AnySlot", ptr %t41, i64 %t38
  %t43 = load %"compiler/generic:AnySlot", ptr %t42
  store %"compiler/generic:AnySlot" %t43, ptr %l10
  %t45 = getelementptr %"compiler/generic:AnySlot", ptr %l10, i32 0, i32 2
  %t46 = load i64, ptr %t45, !tbaa !24
  %t48 = icmp slt i64 %t46, 0
  br i1 %t48, label %bb7, label %bb8
bb7:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load %"compiler/source:Span", ptr %l1
  %t52 = getelementptr %"compiler/generic:AnySlot", ptr %l10, i32 0, i32 3
  %t53 = load i64, ptr %t52, !tbaa !24
  %t54 = load i64, ptr %l4, !tbaa !24
  %t55 = load i32, ptr %l6, !tbaa !23
  %t61 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultArg(ptr %v0, ptr %t50, %"compiler/source:Span" %t51, i64 %t53, i64 %t54, i1 true, i32 %t55, i32 0)
  store ptr %t61, ptr %l47
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t62 = load ptr, ptr %l47, !tbaa !29
  store ptr %t62, ptr %rv
  br label %ret
bb10:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load %"compiler/generic:AnySlot", ptr %l10
  %t67 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitMethod(ptr %v0, ptr %t63, %"compiler/generic:AnySlot" %t64)
  store ptr %t67, ptr %l50
  br label %bb11
bb11:
  %t68 = load ptr, ptr %l50, !tbaa !29
  store ptr %t68, ptr %l11, !tbaa !29
  %t69 = load i64, ptr %l4, !tbaa !24
  %t71 = sub i64 %t69, 1
  store i64 %t71, ptr %l12, !tbaa !24
  %t73 = load ptr, ptr %l11, !tbaa !29
  %t75 = icmp eq ptr %t73, null
  br i1 %t75, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l55, !tbaa !21
  br label %bb14
bb13:
  %t77 = load i64, ptr %l12, !tbaa !24
  %t79 = icmp slt i64 %t77, 0
  store i1 %t79, ptr %l55, !tbaa !21
  br label %bb14
bb14:
  %t81 = load i1, ptr %l55, !tbaa !21
  br i1 %t81, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l58, !tbaa !21
  br label %bb17
bb16:
  %t82 = load i64, ptr %l12, !tbaa !24
  %t83 = load ptr, ptr %l11, !tbaa !29
  %t85 = getelementptr %"compiler/ast:Func", ptr %t83, i32 0, i32 3
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/ast:Sig", ptr %t86, i32 0, i32 0
  %t89 = load { i64, ptr }, ptr %t88, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t94 = icmp sge i64 %t82, %t91
  store i1 %t94, ptr %l58, !tbaa !21
  br label %bb17
bb17:
  %t96 = load i1, ptr %l58, !tbaa !21
  br i1 %t96, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb20
bb19:
  %t97 = load ptr, ptr %l11, !tbaa !29
  %t99 = getelementptr %"compiler/ast:Func", ptr %t97, i32 0, i32 3
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/ast:Sig", ptr %t100, i32 0, i32 0
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  store { i64, ptr } %t103, ptr %l68, !tbaa !27
  %t104 = load i64, ptr %l12, !tbaa !24
  %t106 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr ptr, ptr %t107, i64 %t104
  %t109 = load ptr, ptr %t108, !tbaa !39
  %t111 = getelementptr %"compiler/ast:Param", ptr %t109, i32 0, i32 3
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = icmp eq ptr %t112, null
  store i1 %t114, ptr %l65, !tbaa !21
  br label %bb20
bb20:
  %t116 = load i1, ptr %l65, !tbaa !21
  br i1 %t116, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  %t117 = load ptr, ptr %l11, !tbaa !29
  %t119 = icmp eq ptr %t117, null
  %t121 = xor i1 %t119, true
  br i1 %t121, label %bb23, label %bb24
bb22:
  br label %bb32
bb23:
  %t123 = load ptr, ptr %l11, !tbaa !29
  %t125 = getelementptr %"compiler/ast:Func", ptr %t123, i32 0, i32 3
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t128 = getelementptr %"compiler/ast:Sig", ptr %t126, i32 0, i32 0
  %t129 = load { i64, ptr }, ptr %t128, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t129, 0
  store i64 %t131, ptr %l76, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l76, !tbaa !24
  br label %bb25
bb25:
  %t133 = load i64, ptr %l76, !tbaa !24
  store i64 %t133, ptr %l13, !tbaa !24
  %t134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t134, ptr %l81, !tbaa !29
  %t135 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t135, ptr %l82
  %t136 = load i64, ptr %l13, !tbaa !24
  store i64 %t136, ptr %l83, !tbaa !24
  %t137 = load i64, ptr %l13, !tbaa !24
  %t139 = icmp eq i64 %t137, 1
  br i1 %t139, label %bb26, label %bb27
bb26:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %l86, !tbaa !27
  br label %bb28
bb27:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l86, !tbaa !27
  br label %bb28
bb28:
  %t141 = load i64, ptr %l12, !tbaa !24
  %t142 = load i64, ptr %l83, !tbaa !24
  %t143 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t145 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %s3, ptr %s3, i64 %t142, { i64, ptr } %t143, i64 %t141)
  store %"compiler/msgs:Msg" %t145, ptr %l88
  br label %bb29
bb29:
  %t146 = load ptr, ptr %l81, !tbaa !29
  %t147 = load %"compiler/source:Span", ptr %l82
  %t148 = load %"compiler/msgs:Msg", ptr %l88
  %t149 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t146, %"compiler/source:Span" %t147, %"compiler/msgs:Msg" %t148)
  store i64 %t149, ptr %l89
  br label %bb30
bb30:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load %"compiler/source:Span", ptr %l1
  %t154 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t150, %"compiler/source:Span" %t151)
  store ptr %t154, ptr %l92
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s3)
  %t155 = load ptr, ptr %l92, !tbaa !29
  store ptr %t155, ptr %rv
  br label %ret
bb32:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/check:Checker", ptr %t156, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t161 = getelementptr %"compiler/generic:Program", ptr %t159, i32 0, i32 2
  %t162 = getelementptr %"compiler/generic:AnySlot", ptr %l10, i32 0, i32 1
  %t163 = load i32, ptr %t162, !tbaa !23
  %t166 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t161, i32 %t163)
  store i32 %t166, ptr %l97
  br label %bb33
bb33:
  %t167 = load i32, ptr %l97, !tbaa !23
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/check:Checker", ptr %t168, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !29
  %t173 = getelementptr %"compiler/generic:Program", ptr %t171, i32 0, i32 2
  %t177 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t173, i32 %t167)
  store i64 %t177, ptr %l102
  br label %bb34
bb34:
  %t178 = load i64, ptr %l102, !tbaa !24
  store i64 %t178, ptr %l15, !tbaa !24
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t179)
  store ptr %t181, ptr %l104
  br label %bb35
bb35:
  %t182 = load ptr, ptr %l104, !tbaa !29
  %t184 = getelementptr %"compiler/check:frame", ptr %t182, i32 0, i32 2
  %t185 = load i64, ptr %t184, !tbaa !24
  store i64 %t185, ptr %l16, !tbaa !24
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t187)
  store ptr %t189, ptr %l108
  br label %bb36
bb36:
  %t190 = load ptr, ptr %l108, !tbaa !29
  store ptr %t190, ptr %l17, !tbaa !29
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t192 = load ptr, ptr %l17, !tbaa !29
  %t194 = getelementptr %"compiler/check:frame", ptr %t192, i32 0, i32 0
  %t195 = load i64, ptr %t194, !tbaa !24
  %t196 = load i64, ptr %l15, !tbaa !24
  %t197 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t202 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t191, i64 %t195, i64 %t196, i32 %t197, i32 0)
  store ptr %t202, ptr %l114
  br label %bb37
bb37:
  %t203 = load ptr, ptr %l114, !tbaa !29
  store ptr %t203, ptr %l18, !tbaa !29
  %t204 = load ptr, ptr %l18, !tbaa !29
  store ptr %t204, ptr %l115, !tbaa !29
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/check:Checker", ptr %t205, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !29
  %t209 = getelementptr %"compiler/generic:AnySlot", ptr %l10, i32 0, i32 1
  %t210 = load i32, ptr %t209, !tbaa !23
  %t213 = call %"compiler/generic:Context" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceContext(ptr %v0, ptr %v0, ptr %t208, i32 %t210)
  store %"compiler/generic:Context" %t213, ptr %l119
  br label %bb38
bb38:
  %t214 = load %"compiler/generic:Context", ptr %l119
  %t215 = load ptr, ptr %l115, !tbaa !29
  %t216 = getelementptr %"compiler/check:frame", ptr %t215, i32 0, i32 4
  store %"compiler/generic:Context" %t214, ptr %t216
  %t217 = load ptr, ptr %l18, !tbaa !29
  %t218 = load ptr, ptr %l17, !tbaa !29
  %t220 = getelementptr %"compiler/check:frame", ptr %t218, i32 0, i32 7
  %t221 = load i64, ptr %t220, !tbaa !24
  %t224 = getelementptr %"compiler/check:frame", ptr %t217, i32 0, i32 7
  store i64 %t221, ptr %t224, !tbaa !24
  %t225 = load ptr, ptr %l0, !tbaa !29
  store ptr %t225, ptr %l123, !tbaa !29
  %t226 = load ptr, ptr %l11, !tbaa !29
  %t228 = getelementptr %"compiler/ast:Func", ptr %t226, i32 0, i32 3
  %t229 = load ptr, ptr %t228, !tbaa !29
  %t231 = getelementptr %"compiler/ast:Sig", ptr %t229, i32 0, i32 0
  %t232 = load { i64, ptr }, ptr %t231, !tbaa !27
  store { i64, ptr } %t232, ptr %l126, !tbaa !27
  %t233 = load i64, ptr %l12, !tbaa !24
  %t235 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t236 = load ptr, ptr %t235, !tbaa !27
  %t237 = getelementptr ptr, ptr %t236, i64 %t233
  %t238 = load ptr, ptr %t237, !tbaa !39
  %t240 = getelementptr %"compiler/ast:Param", ptr %t238, i32 0, i32 3
  %t241 = load ptr, ptr %t240, !tbaa !29
  store ptr %t241, ptr %l19, !tbaa !29
  %t243 = load ptr, ptr %l19, !tbaa !29
  %t245 = icmp eq ptr %t243, null
  br i1 %t245, label %bb39, label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_87950e0971945cd5_bece9ab6826c95c9)
  unreachable
bb40:
  br label %bb41
bb41:
  %t247 = load ptr, ptr %l19, !tbaa !29
  %t248 = load i32, ptr %l6, !tbaa !23
  %t249 = load ptr, ptr %l123, !tbaa !29
  %t252 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v0, ptr %t249, ptr %t247, i32 %t248)
  store ptr %t252, ptr %l134
  br label %bb42
bb42:
  %t253 = load ptr, ptr %l134, !tbaa !29
  store ptr %t253, ptr %l20, !tbaa !29
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultReads(ptr %v0, ptr %v0, ptr %t254, ptr %t255)
  br label %bb43
bb43:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t261 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t259)
  store ptr %t261, ptr %l139
  br label %bb44
bb44:
  %t262 = load ptr, ptr %l139, !tbaa !29
  %t264 = getelementptr %"compiler/check:frame", ptr %t262, i32 0, i32 2
  %t265 = load i64, ptr %t264, !tbaa !24
  store i64 %t265, ptr %l21, !tbaa !24
  %t267 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t267)
  br label %bb45
bb45:
  %t269 = load i64, ptr %l21, !tbaa !24
  %t270 = load i64, ptr %l16, !tbaa !24
  %t273 = icmp ne i64 %t269, %t270
  br i1 %t273, label %bb46, label %bb47
bb46:
  %t275 = load %"compiler/source:Span", ptr %l1
  %t276 = load i64, ptr %l21, !tbaa !24
  %t277 = load ptr, ptr %l20, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t278
  %t279 = getelementptr { i64, [5 x i64] }, ptr %t278, i32 0, i32 0
  store i64 17, ptr %t279
  %t281 = insertvalue { %"compiler/source:Span", i64, ptr } undef, %"compiler/source:Span" %t275, 0
  %t283 = insertvalue { %"compiler/source:Span", i64, ptr } %t281, i64 %t276, 1
  %t285 = insertvalue { %"compiler/source:Span", i64, ptr } %t283, ptr %t277, 2
  %t286 = getelementptr { i64, [5 x i64] }, ptr %t278, i32 0, i32 1
  store { %"compiler/source:Span", i64, ptr } %t285, ptr %t286
  %t287 = load { i64, [5 x i64] }, ptr %t278
  %t289 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t287, ptr %t289
  store ptr %t289, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t291 = load ptr, ptr %l20, !tbaa !29
  store ptr %t291, ptr %rv
  br label %ret
bb49:
  br i1 true, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb55
bb52:
  %t293 = load ptr, ptr %l0, !tbaa !29
  store ptr %t293, ptr %l152, !tbaa !29
  %t294 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t294, ptr %l153
  store i64 %a3, ptr %l154, !tbaa !24
  %t296 = load i64, ptr %l4, !tbaa !24
  store i64 %t296, ptr %l155, !tbaa !24
  store i1 %a5, ptr %l156, !tbaa !21
  %t298 = load i32, ptr %l6, !tbaa !23
  store i32 %t298, ptr %l157, !tbaa !23
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t300 = load ptr, ptr %l2, !tbaa !29
  %t303 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeArgs(ptr %v0, ptr %v0, ptr %t299, ptr %t300)
  store i32 %t303, ptr %l160
  br label %bb53
bb53:
  %t304 = load ptr, ptr %l152, !tbaa !29
  %t305 = load %"compiler/source:Span", ptr %l153
  %t306 = load i64, ptr %l154, !tbaa !24
  %t307 = load i64, ptr %l155, !tbaa !24
  %t308 = load i1, ptr %l156, !tbaa !21
  %t309 = load i32, ptr %l157, !tbaa !23
  %t310 = load i32, ptr %l160, !tbaa !23
  %t311 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultArg(ptr %v0, ptr %t304, %"compiler/source:Span" %t305, i64 %t306, i64 %t307, i1 %t308, i32 %t309, i32 %t310)
  store ptr %t311, ptr %l161
  br label %bb54
bb54:
  %t312 = load ptr, ptr %l161, !tbaa !29
  store ptr %t312, ptr %rv
  br label %ret
bb55:
  call void @__olang_check_failed(ptr @olang_loc_f8c90d07629b23d_673d56dd932bf211)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %rv = alloca { i64, [3 x i64] }
  %t16 = alloca { i64, [3 x i64] }, align 8
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0)
  store ptr %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 2
  %t7 = load i64, ptr %t6, !tbaa !24
  %t8 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t9 = load i32, ptr %t8, !tbaa !23
  %t11 = sext i32 %t9 to i64
  %t12 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t15 = sext i32 %t13 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t16
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 0
  store i64 3, ptr %t17
  %t19 = insertvalue { i64, i64, i64 } undef, i64 %t7, 0
  %t21 = insertvalue { i64, i64, i64 } %t19, i64 %t11, 1
  %t23 = insertvalue { i64, i64, i64 } %t21, i64 %t15, 2
  %t24 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 1
  store { i64, i64, i64 } %t23, ptr %t24
  %t25 = load { i64, [3 x i64] }, ptr %t16
  store { i64, [3 x i64] } %t25, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [3 x i64] }, ptr %rv
  ret { i64, [3 x i64] } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrCall(ptr %v0, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l14 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca i1
  %l24 = alloca i32
  %l30 = alloca %"compiler/source:Span"
  %l31 = alloca ptr
  %rv = alloca ptr
  %t67 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 false, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 29}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t11 = load ptr, ptr %l8, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 29}
  %t17 = icmp eq i64 %t15, 15
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l9, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t23 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v0, ptr %t19, ptr %t20)
  store i32 %t23, ptr %l14
  br label %bb10
bb10:
  %t24 = load i32, ptr %l14, !tbaa !23
  %t25 = icmp sge i32 %t24, 0
  store i1 %t25, ptr %l2, !tbaa !21
  br label %bb23
bb11:
  %t27 = load ptr, ptr %l1, !tbaa !29
  store ptr %t27, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t28 = load ptr, ptr %l16, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb12, label %bb13
bb12:
  %t31 = load ptr, ptr %l16, !tbaa !29
  %t32 = load i64, ptr %t31, !range !{i64 0, i64 29}
  %t34 = icmp eq i64 %t32, 14
  store i1 %t34, ptr %l17, !tbaa !21
  br label %bb13
bb13:
  %t35 = load i1, ptr %l17, !tbaa !21
  br i1 %t35, label %bb14, label %bb15
bb14:
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t38, i32 0, i32 1
  %t40 = load ptr, ptr %t39
  store ptr %t40, ptr %l3, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t46 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericNamed(ptr %v0, ptr %v0, ptr %t42, ptr %t43)
  store i32 %t46, ptr %l24
  br label %bb17
bb17:
  %t47 = load i32, ptr %l24, !tbaa !23
  %t48 = icmp sge i32 %t47, 0
  store i1 %t48, ptr %l2, !tbaa !21
  br label %bb23
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_e3737a5db5d2f43e_f6d8b09c7cd8c09a)
  unreachable
bb23:
  %t50 = load i1, ptr %l2, !tbaa !21
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb24, label %bb25
bb24:
  %t54 = load ptr, ptr %l1, !tbaa !29
  store ptr %t54, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t58 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t56)
  store %"compiler/source:Span" %t58, ptr %l30
  br label %bb27
bb27:
  %t59 = load ptr, ptr %l1, !tbaa !29
  store ptr %t59, ptr %l31, !tbaa !29
  %t60 = icmp sge i64 0, 0
  br i1 %t60, label %bb28, label %bb29
bb28:
  %t62 = icmp sle i64 0, 1152921504606846975
  br i1 %t62, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_a6278e1b7f6dba40_6fee99e557dde034)
  unreachable
bb30:
  %t64 = mul i64 0, 8
  %t65 = insertvalue { i64, ptr } undef, i64 0, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, [5 x i64] } zeroinitializer, ptr %t67
  %t68 = getelementptr { i64, [5 x i64] }, ptr %t67, i32 0, i32 0
  store i64 12, ptr %t68
  %t69 = load %"compiler/source:Span", ptr %l30
  %t70 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t69, 0
  %t71 = load ptr, ptr %l31, !tbaa !29
  %t72 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t70, ptr %t71, 1
  %t74 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t72, { i64, ptr } %t66, 2
  %t75 = getelementptr { i64, [5 x i64] }, ptr %t67, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t74, ptr %t75
  %t76 = load { i64, [5 x i64] }, ptr %t67
  %t78 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t76, ptr %t78
  store ptr %t78, ptr %rv
  br label %ret
bb31:
  call void @__olang_check_failed(ptr @olang_loc_a6278e1b7f6dba40_6fee99e557dde034)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aHoldsFn(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l6 = alloca i1
  %l15 = alloca i32
  %l16 = alloca i1
  %l21 = alloca ptr
  %l26 = alloca i32
  %l29 = alloca i1
  %l34 = alloca ptr
  %l37 = alloca ptr
  %l42 = alloca i32
  %l43 = alloca { i64, ptr }
  %l45 = alloca i1
  %l51 = alloca i1
  %l52 = alloca i1
  %l53 = alloca ptr
  %l56 = alloca ptr
  %l61 = alloca i32
  %l62 = alloca { i64, ptr }
  %l64 = alloca i1
  %l65 = alloca i1
  %l66 = alloca ptr
  %l69 = alloca ptr
  %l74 = alloca i32
  %l75 = alloca { i64, ptr }
  %l77 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 8
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  store i1 %t9, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l6, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l15
  br label %bb7
bb7:
  %t23 = load i32, ptr %l15, !range !{i32 0, i32 33}
  store i32 %t23, ptr %l3
  %t24 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t26 = trunc i64 21 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb48
bb11:
  %t29 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t31 = trunc i64 19 to i32
  %t32 = icmp eq i32 %t29, %t31
  br i1 %t32, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb17
bb14:
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l21, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/generic:Program", ptr %t38, i32 0, i32 2
  %t41 = load i32, ptr %l1, !tbaa !23
  %t44 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t40, i32 %t41)
  store i32 %t44, ptr %l26
  br label %bb15
bb15:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t47 = add i64 %t45, 1
  %t48 = load ptr, ptr %l21, !tbaa !29
  %t49 = load i32, ptr %l26, !tbaa !23
  %t51 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aHoldsFn(ptr %v0, ptr %t48, i32 %t49, i64 %t47)
  store i1 %t51, ptr %l29
  br label %bb16
bb16:
  %t52 = load i1, ptr %l29, !tbaa !21
  store i1 %t52, ptr %l16, !tbaa !21
  br label %bb48
bb17:
  %t53 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t55 = trunc i64 22 to i32
  %t56 = icmp eq i32 %t53, %t55
  br i1 %t56, label %bb18, label %bb19
bb18:
  br label %bb22
bb19:
  %t58 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t60 = trunc i64 23 to i32
  %t61 = icmp eq i32 %t58, %t60
  br i1 %t61, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb26
bb22:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l34, !tbaa !29
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  store ptr %t69, ptr %l37, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/check:Checker", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/generic:Program", ptr %t73, i32 0, i32 2
  %t76 = load i32, ptr %l1, !tbaa !23
  %t79 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t75, i32 %t76)
  store i32 %t79, ptr %l42
  br label %bb23
bb23:
  %t80 = load ptr, ptr %l37, !tbaa !29
  %t81 = load i32, ptr %l42, !tbaa !23
  %t82 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t80, i32 %t81)
  store { i64, ptr } %t82, ptr %l43
  br label %bb24
bb24:
  %t83 = load i64, ptr %l2, !tbaa !24
  %t84 = load ptr, ptr %l34, !tbaa !29
  %t85 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t87 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aHoldsAny(ptr %v0, ptr %v0, ptr %t84, { i64, ptr } %t85, i64 %t83)
  store i1 %t87, ptr %l45
  br label %bb25
bb25:
  %t88 = load i1, ptr %l45, !tbaa !21
  store i1 %t88, ptr %l16, !tbaa !21
  br label %bb48
bb26:
  %t89 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t91 = trunc i64 18 to i32
  %t92 = icmp eq i32 %t89, %t91
  br i1 %t92, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb43
bb29:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t98 = load i32, ptr %l1, !tbaa !23
  %t101 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t97, i32 %t98)
  store i1 %t101, ptr %l51
  br label %bb30
bb30:
  %t102 = load i1, ptr %l51, !tbaa !21
  br i1 %t102, label %bb31, label %bb32
bb31:
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l53, !tbaa !29
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/check:Checker", ptr %t104, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t109 = getelementptr %"compiler/generic:Program", ptr %t107, i32 0, i32 2
  store ptr %t109, ptr %l56, !tbaa !29
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/check:Checker", ptr %t110, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = getelementptr %"compiler/generic:Program", ptr %t113, i32 0, i32 2
  %t116 = load i32, ptr %l1, !tbaa !23
  %t119 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t115, i32 %t116)
  store i32 %t119, ptr %l61
  br label %bb33
bb32:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb42
bb33:
  %t120 = load ptr, ptr %l56, !tbaa !29
  %t121 = load i32, ptr %l61, !tbaa !23
  %t122 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t120, i32 %t121)
  store { i64, ptr } %t122, ptr %l62
  br label %bb34
bb34:
  %t123 = load i64, ptr %l2, !tbaa !24
  %t124 = load ptr, ptr %l53, !tbaa !29
  %t125 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t127 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aHoldsAny(ptr %v0, ptr %v0, ptr %t124, { i64, ptr } %t125, i64 %t123)
  store i1 %t127, ptr %l64
  br label %bb35
bb35:
  %t128 = load i1, ptr %l64, !tbaa !21
  br i1 %t128, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb41
bb37:
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l66, !tbaa !29
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/check:Checker", ptr %t130, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t135 = getelementptr %"compiler/generic:Program", ptr %t133, i32 0, i32 2
  store ptr %t135, ptr %l69, !tbaa !29
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/check:Checker", ptr %t136, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t141 = getelementptr %"compiler/generic:Program", ptr %t139, i32 0, i32 2
  %t142 = load i32, ptr %l1, !tbaa !23
  %t145 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t141, i32 %t142)
  store i32 %t145, ptr %l74
  br label %bb38
bb38:
  %t146 = load ptr, ptr %l69, !tbaa !29
  %t147 = load i32, ptr %l74, !tbaa !23
  %t148 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t146, i32 %t147)
  store { i64, ptr } %t148, ptr %l75
  br label %bb39
bb39:
  %t149 = load i64, ptr %l2, !tbaa !24
  %t150 = load ptr, ptr %l66, !tbaa !29
  %t151 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t153 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aHoldsAny(ptr %v0, ptr %v0, ptr %t150, { i64, ptr } %t151, i64 %t149)
  store i1 %t153, ptr %l77
  br label %bb40
bb40:
  %t154 = load i1, ptr %l77, !tbaa !21
  store i1 %t154, ptr %l65, !tbaa !21
  br label %bb41
bb41:
  %t155 = load i1, ptr %l65, !tbaa !21
  store i1 %t155, ptr %l52, !tbaa !21
  br label %bb42
bb42:
  %t156 = load i1, ptr %l52, !tbaa !21
  store i1 %t156, ptr %l16, !tbaa !21
  br label %bb48
bb43:
  br i1 true, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb47
bb46:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_6d92d89bf6179935_a746df8e6ee4ce11)
  unreachable
bb48:
  %t157 = load i1, ptr %l16, !tbaa !21
  store i1 %t157, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aInit(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l13 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l34 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 12
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a2)
  store ptr %t7, ptr %l13
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l13, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 11
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Body", ptr %t16, i32 0, i32 11
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = icmp eq ptr %t19, null
  br i1 %t21, label %bb5, label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_76c98d42818871e4_51853c380fcafc70)
  unreachable
bb6:
  br label %bb7
bb7:
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t25 = getelementptr %"compiler/typed:Body", ptr %t23, i32 0, i32 11
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Block", ptr %t26, i32 0, i32 1
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  store { i64, ptr } %t30, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  store i64 %t34, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t36 = load i64, ptr %l5, !tbaa !24
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb9, label %bb10
bb9:
  br label %bb38
bb10:
  br label %bb11
bb11:
  %t44 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t44, ptr %l30, !tbaa !27
  %t45 = load i64, ptr %l5, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr ptr, ptr %t48, i64 %t45
  %t50 = load ptr, ptr %t49, !tbaa !39
  store ptr %t50, ptr %l7, !tbaa !29
  %t52 = load ptr, ptr %l7, !tbaa !29
  store ptr %t52, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t53 = load ptr, ptr %l33, !tbaa !29
  %t54 = icmp ne ptr %t53, null
  br i1 %t54, label %bb12, label %bb13
bb12:
  %t56 = load ptr, ptr %l33, !tbaa !29
  %t57 = load i64, ptr %t56, !range !{i64 0, i64 17}
  %t59 = icmp eq i64 %t57, 1
  store i1 %t59, ptr %l34, !tbaa !21
  br label %bb13
bb13:
  %t60 = load i1, ptr %l34, !tbaa !21
  br i1 %t60, label %bb14, label %bb15
bb14:
  %t61 = load ptr, ptr %l7, !tbaa !29
  %t63 = getelementptr { i64, [3 x i64] }, ptr %t61, i32 0, i32 1
  %t64 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t63, i32 0, i32 1
  %t65 = load ptr, ptr %t64
  store ptr %t65, ptr %l8, !tbaa !29
  %t67 = load ptr, ptr %l7, !tbaa !29
  %t69 = getelementptr { i64, [3 x i64] }, ptr %t67, i32 0, i32 1
  %t70 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t69, i32 0, i32 2
  %t71 = load ptr, ptr %t70
  store ptr %t71, ptr %l9, !tbaa !29
  br label %bb16
bb15:
  br label %bb30
bb16:
  %t73 = load ptr, ptr %l8, !tbaa !29
  store ptr %t73, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t74 = load ptr, ptr %l41, !tbaa !29
  %t75 = icmp ne ptr %t74, null
  br i1 %t75, label %bb17, label %bb18
bb17:
  %t77 = load ptr, ptr %l41, !tbaa !29
  %t78 = load i64, ptr %t77, !range !{i64 0, i64 8}
  %t80 = icmp eq i64 %t78, 1
  store i1 %t80, ptr %l42, !tbaa !21
  br label %bb18
bb18:
  %t81 = load i1, ptr %l42, !tbaa !21
  br i1 %t81, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t84 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v0, ptr %t82, ptr %t83, ptr %t84)
  br label %bb22
bb22:
  br label %bb29
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load ptr, ptr %l1, !tbaa !29
  %t91 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStmt(ptr %v0, ptr %v1, ptr %v0, ptr %t89, ptr %t90, ptr %t91)
  br label %bb27
bb27:
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_5b6dfd884f12314a_d55d816e86cc2196)
  unreachable
bb29:
  br label %bb36
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t98 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStmt(ptr %v0, ptr %v1, ptr %v0, ptr %t96, ptr %t97, ptr %t98)
  br label %bb34
bb34:
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_fdeda218c1a4d1e1_676c59a9a8adaaad)
  unreachable
bb36:
  br label %bb37
bb37:
  %t103 = load i64, ptr %l5, !tbaa !24
  %t105 = add i64 %t103, 1
  store i64 %t105, ptr %l5, !tbaa !24
  br label %bb8
bb38:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l8 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/check:b5aWalk", ptr %t3, i32 0, i32 2
  %t9 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v1, ptr %t5, i64 %t1)
  store i1 %t9, ptr %l8
  br label %bb1
bb1:
  %t10 = load i1, ptr %l8, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/check:b5aWalk", ptr %t13, i32 0, i32 2
  %t16 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t15, i64 %t16)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindsType(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i1
  %l11 = alloca { i64, ptr }
  %l12 = alloca i1
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 6}
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb8
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %a0, i32 %t17)
  store { i64, ptr } %t20, ptr %l11
  br label %bb6
bb6:
  %t21 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t22 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t21, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i1 %t22, ptr %l12
  br label %bb7
bb7:
  %t23 = load i1, ptr %l12, !tbaa !21
  %t24 = xor i1 %t23, true
  call void @__olang_scope_close(ptr %s1)
  store i1 %t24, ptr %rv
  br label %ret
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 false, ptr %rv
  br label %ret
bb12:
  call void @__olang_check_failed(ptr @olang_loc_357157b7b16ebf19_d0077534c0a9b60d)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuiltinType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l7 = alloca i1
  %l10 = alloca i1
  %l16 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t1, i32 %a1)
  store { i64, ptr } %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t7, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i1 %t9, ptr %l7
  br label %bb2
bb2:
  %t10 = load i1, ptr %l7, !tbaa !21
  br i1 %t10, label %bb3, label %bb4
bb3:
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t11, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t15 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t13, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store i1 %t15, ptr %l10
  br label %bb6
bb6:
  %t16 = load i1, ptr %l10, !tbaa !21
  br i1 %t16, label %bb7, label %bb8
bb7:
  %t17 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t17, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 2
  %t25 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v0, ptr %t24, { i64, ptr } %t25)
  store i32 %t28, ptr %l16
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load i32, ptr %l16, !tbaa !23
  store i32 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecVoidRef(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeForeign(ptr %v0, ptr %s0, ptr %a0, i32 %a1, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t6 = load i1, ptr %l4, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainFrom(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, { i64, ptr } %a4, i64 %a5, ptr %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %lp12 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l37 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l44 = alloca %"compiler/source:Span"
  %l45 = alloca i32
  %l51 = alloca ptr
  %l59 = alloca ptr
  %l60 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca %"compiler/typed:Cond"
  %l75 = alloca ptr
  %l77 = alloca i32
  %l81 = alloca i64
  %l84 = alloca i64
  %l86 = alloca ptr
  %l87 = alloca %"compiler/source:Span"
  %l90 = alloca i32
  %l97 = alloca ptr
  %l100 = alloca ptr
  %l101 = alloca %"compiler/source:Span"
  %l102 = alloca ptr
  %l103 = alloca i64
  %l104 = alloca ptr
  %l108 = alloca ptr
  %l110 = alloca ptr
  %l111 = alloca %"compiler/source:Span"
  %l112 = alloca i32
  %l116 = alloca { i64, ptr }
  %l119 = alloca %"compiler/typed:Seq"
  %l122 = alloca ptr
  %l123 = alloca %"compiler/source:Span"
  %l124 = alloca ptr
  %l125 = alloca i64
  %l126 = alloca { i64, ptr }
  %l128 = alloca i64
  %l132 = alloca ptr
  %l134 = alloca ptr
  %l135 = alloca %"compiler/source:Span"
  %l136 = alloca i32
  %l137 = alloca ptr
  %l139 = alloca ptr
  %l143 = alloca ptr
  %l144 = alloca %"compiler/typed:Cond"
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t106 = alloca { i64, [5 x i64] }, align 8
  %t171 = alloca { i64, [3 x i64] }, align 8
  %t222 = alloca { i64, [5 x i64] }, align 8
  %t278 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store i64 %a5, ptr %l5
  store ptr %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Chain", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = load i64, ptr %l5, !tbaa !24
  %t10 = add i64 %t8, 2
  %t14 = icmp sge i64 %t10, %t6
  br i1 %t14, label %bb1, label %bb2
bb1:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l21, !tbaa !29
  %t17 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t17, ptr %l22
  %t18 = load ptr, ptr %l2, !tbaa !29
  store ptr %t18, ptr %l23, !tbaa !29
  %t19 = load i64, ptr %l5, !tbaa !24
  store i64 %t19, ptr %l24, !tbaa !24
  %t20 = load ptr, ptr %l6, !tbaa !29
  store ptr %t20, ptr %l25, !tbaa !29
  %t21 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t21, ptr %l26, !tbaa !27
  %t22 = load i64, ptr %l5, !tbaa !24
  %t24 = add i64 %t22, 1
  %t26 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i1, ptr %t27, i64 %t24
  %t29 = load i1, ptr %t28, !tbaa !31
  br i1 %t29, label %bb3, label %bb4
bb2:
  br label %bb8
bb3:
  store ptr null, ptr %l30, !tbaa !29
  br label %bb6
bb4:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 36
  %t34 = load i64, ptr %l3, !tbaa !24
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = add i64 %t34, %t35
  %t40 = add i64 %t38, 1
  %t43 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t33, i64 %t40)
  store ptr %t43, ptr %l37
  br label %bb5
bb5:
  %t44 = load ptr, ptr %l37, !tbaa !29
  store ptr %t44, ptr %l30, !tbaa !29
  br label %bb6
bb6:
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t47 = load %"compiler/source:Span", ptr %l22
  %t48 = load ptr, ptr %l23, !tbaa !29
  %t49 = load i64, ptr %l24, !tbaa !24
  %t50 = load ptr, ptr %l25, !tbaa !29
  %t51 = load ptr, ptr %l30, !tbaa !29
  %t52 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainCmp(ptr %v0, ptr %v1, ptr %t46, %"compiler/source:Span" %t47, ptr %t48, i64 %t49, ptr %t50, ptr %t51)
  store ptr %t52, ptr %l39
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t53 = load ptr, ptr %l39, !tbaa !29
  store ptr %t53, ptr %rv
  br label %ret
bb8:
  %t54 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t54, ptr %l40, !tbaa !27
  %t55 = load i64, ptr %l5, !tbaa !24
  %t57 = add i64 %t55, 1
  %t59 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i1, ptr %t60, i64 %t57
  %t62 = load i1, ptr %t61, !tbaa !31
  br i1 %t62, label %bb9, label %bb10
bb9:
  %t64 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t64, ptr %l44
  %t65 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t65, ptr %l45, !tbaa !23
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load %"compiler/source:Span", ptr %l1
  %t68 = load ptr, ptr %l2, !tbaa !29
  %t69 = load i64, ptr %l5, !tbaa !24
  %t70 = load ptr, ptr %l6, !tbaa !29
  %t76 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainCmp(ptr %v0, ptr %v1, ptr %t66, %"compiler/source:Span" %t67, ptr %t68, i64 %t69, ptr %t70, ptr null)
  store ptr %t76, ptr %l51
  br label %bb11
bb10:
  br label %bb15
bb11:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load %"compiler/source:Span", ptr %l1
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t80 = load i64, ptr %l3, !tbaa !24
  %t81 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t82 = load i64, ptr %l5, !tbaa !24
  %t84 = add i64 %t82, 1
  %t91 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainFrom(ptr %v0, ptr %v1, ptr %v2, ptr %t77, %"compiler/source:Span" %t78, ptr %t79, i64 %t80, { i64, ptr } %t81, i64 %t84, ptr null)
  store ptr %t91, ptr %l59
  br label %bb12
bb12:
  %t92 = load ptr, ptr %l59, !tbaa !29
  store ptr %t92, ptr %l60, !tbaa !29
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load %"compiler/source:Span", ptr %l1
  %t95 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t99 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t93, %"compiler/source:Span" %t94, i32 %t95, i64 0)
  store ptr %t99, ptr %l64
  br label %bb13
bb13:
  %t100 = load ptr, ptr %l51, !tbaa !29
  %t101 = load ptr, ptr %l60, !tbaa !29
  %t102 = load ptr, ptr %l64, !tbaa !29
  %t103 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t100, ptr %t101, ptr %t102)
  store %"compiler/typed:Cond" %t103, ptr %l65
  br label %bb14
bb14:
  %t104 = load %"compiler/typed:Cond", ptr %l65
  %t105 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Cond" %t104, ptr %t105
  store { i64, [5 x i64] } zeroinitializer, ptr %t106
  %t107 = getelementptr { i64, [5 x i64] }, ptr %t106, i32 0, i32 0
  store i64 11, ptr %t107
  %t108 = load %"compiler/source:Span", ptr %l44
  %t109 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t108, 0
  %t110 = load i32, ptr %l45, !tbaa !23
  %t111 = insertvalue { %"compiler/source:Span", i32, ptr } %t109, i32 %t110, 1
  %t113 = insertvalue { %"compiler/source:Span", i32, ptr } %t111, ptr %t105, 2
  %t114 = getelementptr { i64, [5 x i64] }, ptr %t106, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t113, ptr %t114
  %t115 = load { i64, [5 x i64] }, ptr %t106
  %t117 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t115, ptr %t117
  call void @__olang_scope_close(ptr %s0)
  store ptr %t117, ptr %rv
  br label %ret
bb15:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/check:Checker", ptr %t119, i32 0, i32 36
  %t122 = load i64, ptr %l3, !tbaa !24
  %t123 = load i64, ptr %l5, !tbaa !24
  %t126 = add i64 %t122, %t123
  %t128 = add i64 %t126, 1
  %t131 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %s0, ptr %t121, i64 %t128)
  store ptr %t131, ptr %l75
  br label %bb16
bb16:
  %t132 = load ptr, ptr %l75, !tbaa !29
  %t134 = call i32 @compiler_2fcheck_2etypeOf(ptr %s0, ptr %t132)
  store i32 %t134, ptr %l77
  br label %bb17
bb17:
  %t135 = load i32, ptr %l77, !tbaa !23
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load %"compiler/source:Span", ptr %l1
  %t142 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t136, %"compiler/source:Span" %t137, i32 %t135)
  store i64 %t142, ptr %l81
  br label %bb18
bb18:
  %t143 = load i64, ptr %l81, !tbaa !24
  store i64 %t143, ptr %l9, !tbaa !24
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/check:Checker", ptr %t144, i32 0, i32 37
  %t148 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t146)
  store i64 %t148, ptr %l84
  br label %bb19
bb19:
  %t149 = load i64, ptr %l84, !tbaa !24
  store i64 %t149, ptr %l10, !tbaa !24
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/check:Checker", ptr %t150, i32 0, i32 37
  store ptr %t152, ptr %l86, !tbaa !29
  %t153 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t153, ptr %l87
  %t154 = load i64, ptr %l9, !tbaa !24
  %t156 = trunc i64 %t154 to i32
  store i32 %t156, ptr %l90, !tbaa !23
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/check:Checker", ptr %t158, i32 0, i32 36
  %t161 = load i64, ptr %l3, !tbaa !24
  %t162 = load i64, ptr %l5, !tbaa !24
  %t165 = add i64 %t161, %t162
  %t167 = add i64 %t165, 1
  %t170 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t160, i64 %t167)
  store ptr %t170, ptr %l97
  br label %bb20
bb20:
  store { i64, [3 x i64] } zeroinitializer, ptr %t171
  %t172 = getelementptr { i64, [3 x i64] }, ptr %t171, i32 0, i32 0
  store i64 0, ptr %t172
  %t173 = load %"compiler/source:Span", ptr %l87
  %t174 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t173, 0
  %t175 = load i32, ptr %l90, !tbaa !23
  %t176 = insertvalue { %"compiler/source:Span", i32, ptr } %t174, i32 %t175, 1
  %t177 = load ptr, ptr %l97, !tbaa !29
  %t178 = insertvalue { %"compiler/source:Span", i32, ptr } %t176, ptr %t177, 2
  %t179 = getelementptr { i64, [3 x i64] }, ptr %t171, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t178, ptr %t179
  %t180 = load { i64, [3 x i64] }, ptr %t171
  %t182 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t180, ptr %t182
  %t183 = load ptr, ptr %l86, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t183, ptr %t182)
  br label %bb21
bb21:
  %t185 = load ptr, ptr %l0, !tbaa !29
  store ptr %t185, ptr %l100, !tbaa !29
  %t186 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t186, ptr %l101
  %t187 = load ptr, ptr %l2, !tbaa !29
  store ptr %t187, ptr %l102, !tbaa !29
  %t188 = load i64, ptr %l5, !tbaa !24
  store i64 %t188, ptr %l103, !tbaa !24
  %t189 = load ptr, ptr %l6, !tbaa !29
  store ptr %t189, ptr %l104, !tbaa !29
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load %"compiler/source:Span", ptr %l1
  %t192 = load i64, ptr %l9, !tbaa !24
  %t196 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t190, %"compiler/source:Span" %t191, i64 %t192)
  store ptr %t196, ptr %l108
  br label %bb22
bb22:
  %t197 = load ptr, ptr %l108, !tbaa !29
  %t198 = load ptr, ptr %l100, !tbaa !29
  %t199 = load %"compiler/source:Span", ptr %l101
  %t200 = load ptr, ptr %l102, !tbaa !29
  %t201 = load i64, ptr %l103, !tbaa !24
  %t202 = load ptr, ptr %l104, !tbaa !29
  %t204 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainCmp(ptr %v0, ptr %v1, ptr %t198, %"compiler/source:Span" %t199, ptr %t200, i64 %t201, ptr %t202, ptr %t197)
  store ptr %t204, ptr %l110
  br label %bb23
bb23:
  %t205 = load ptr, ptr %l110, !tbaa !29
  store ptr %t205, ptr %l11, !tbaa !29
  %t206 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t206, ptr %l111
  %t207 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t207, ptr %l112, !tbaa !23
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/check:Checker", ptr %t208, i32 0, i32 37
  %t211 = load i64, ptr %l10, !tbaa !24
  %t214 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t210, i64 %t211)
  store { i64, ptr } %t214, ptr %l116
  br label %bb24
bb24:
  %t215 = load ptr, ptr %l11, !tbaa !29
  %t217 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t219 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t217, ptr %t215)
  store %"compiler/typed:Seq" %t219, ptr %l119
  br label %bb25
bb25:
  %t220 = load %"compiler/typed:Seq", ptr %l119
  %t221 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Seq" %t220, ptr %t221
  store { i64, [5 x i64] } zeroinitializer, ptr %t222
  %t223 = getelementptr { i64, [5 x i64] }, ptr %t222, i32 0, i32 0
  store i64 12, ptr %t223
  %t224 = load %"compiler/source:Span", ptr %l111
  %t225 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t224, 0
  %t226 = load i32, ptr %l112, !tbaa !23
  %t227 = insertvalue { %"compiler/source:Span", i32, ptr } %t225, i32 %t226, 1
  %t229 = insertvalue { %"compiler/source:Span", i32, ptr } %t227, ptr %t221, 2
  %t230 = getelementptr { i64, [5 x i64] }, ptr %t222, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t229, ptr %t230
  %t231 = load { i64, [5 x i64] }, ptr %t222
  %t232 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store ptr %t232, ptr %lp12
  %t234 = load ptr, ptr %lp12
  store { i64, [5 x i64] } %t231, ptr %t234
  %t235 = load ptr, ptr %l0, !tbaa !29
  store ptr %t235, ptr %l122, !tbaa !29
  %t236 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t236, ptr %l123
  %t237 = load ptr, ptr %l2, !tbaa !29
  store ptr %t237, ptr %l124, !tbaa !29
  %t238 = load i64, ptr %l3, !tbaa !24
  store i64 %t238, ptr %l125, !tbaa !24
  %t239 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t239, ptr %l126, !tbaa !27
  %t240 = load i64, ptr %l5, !tbaa !24
  %t242 = add i64 %t240, 1
  store i64 %t242, ptr %l128, !tbaa !24
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t244 = load %"compiler/source:Span", ptr %l1
  %t245 = load i64, ptr %l9, !tbaa !24
  %t249 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t243, %"compiler/source:Span" %t244, i64 %t245)
  store ptr %t249, ptr %l132
  br label %bb26
bb26:
  %t250 = load ptr, ptr %l132, !tbaa !29
  %t251 = load ptr, ptr %l122, !tbaa !29
  %t252 = load %"compiler/source:Span", ptr %l123
  %t253 = load ptr, ptr %l124, !tbaa !29
  %t254 = load i64, ptr %l125, !tbaa !24
  %t255 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t256 = load i64, ptr %l128, !tbaa !24
  %t258 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainFrom(ptr %v0, ptr %v1, ptr %v2, ptr %t251, %"compiler/source:Span" %t252, ptr %t253, i64 %t254, { i64, ptr } %t255, i64 %t256, ptr %t250)
  store ptr %t258, ptr %l134
  br label %bb27
bb27:
  %t259 = load ptr, ptr %l134, !tbaa !29
  %t260 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t260, ptr %l135
  %t261 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t261, ptr %l136, !tbaa !23
  %t262 = load ptr, ptr %lp12
  store ptr %t262, ptr %l137, !tbaa !29
  store ptr %t259, ptr %l139, !tbaa !29
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t266 = load %"compiler/source:Span", ptr %l1
  %t267 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t271 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t265, %"compiler/source:Span" %t266, i32 %t267, i64 0)
  store ptr %t271, ptr %l143
  br label %bb28
bb28:
  %t272 = load ptr, ptr %l137, !tbaa !29
  %t273 = load ptr, ptr %l139, !tbaa !29
  %t274 = load ptr, ptr %l143, !tbaa !29
  %t275 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t272, ptr %t273, ptr %t274)
  store %"compiler/typed:Cond" %t275, ptr %l144
  br label %bb29
bb29:
  %t276 = load %"compiler/typed:Cond", ptr %l144
  %t277 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Cond" %t276, ptr %t277
  store { i64, [5 x i64] } zeroinitializer, ptr %t278
  %t279 = getelementptr { i64, [5 x i64] }, ptr %t278, i32 0, i32 0
  store i64 11, ptr %t279
  %t280 = load %"compiler/source:Span", ptr %l135
  %t281 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t280, 0
  %t282 = load i32, ptr %l136, !tbaa !23
  %t283 = insertvalue { %"compiler/source:Span", i32, ptr } %t281, i32 %t282, 1
  %t285 = insertvalue { %"compiler/source:Span", i32, ptr } %t283, ptr %t277, 2
  %t286 = getelementptr { i64, [5 x i64] }, ptr %t278, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t285, ptr %t286
  %t287 = load { i64, [5 x i64] }, ptr %t278
  %t289 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t287, ptr %t289
  call void @__olang_scope_close(ptr %s0)
  store ptr %t289, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckDtor(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l17 = alloca i32
  %l21 = alloca ptr
  %l26 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l36 = alloca %"compiler/generic:Context"
  %l38 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca %"compiler/source:Span"
  %l41 = alloca i32
  %l44 = alloca ptr
  %l47 = alloca ptr
  %l49 = alloca ptr
  %l52 = alloca i32
  %l53 = alloca { i64, ptr }
  %l54 = alloca ptr
  %l55 = alloca %"compiler/source:Span"
  %l56 = alloca { i64, ptr }
  %l60 = alloca i64
  %l62 = alloca ptr
  %l69 = alloca ptr
  %l73 = alloca ptr
  %l75 = alloca ptr
  %l77 = alloca ptr
  %l80 = alloca { i64, ptr }
  %l87 = alloca ptr
  %l88 = alloca i1
  %l94 = alloca ptr
  %l102 = alloca i64
  %l106 = alloca { i64, ptr }
  %l107 = alloca i64
  %l108 = alloca i32
  %l109 = alloca ptr
  %l121 = alloca %"compiler/source:Span"
  %l122 = alloca %"compiler/msgs:Msg"
  %l123 = alloca i64
  %l127 = alloca ptr
  %l132 = alloca %"compiler/typed:Block"
  %l135 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %t95 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l17
  br label %bb1
bb1:
  %t11 = load i32, ptr %l17, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t16 = load i32, ptr %l3, !tbaa !23
  %t19 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t15, i32 %t16)
  store ptr %t19, ptr %l21
  br label %bb2
bb2:
  %t20 = load ptr, ptr %l21, !tbaa !29
  store ptr %t20, ptr %l4, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 2
  %t27 = load i32, ptr %l3, !tbaa !23
  %t30 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t26, i32 %t27)
  store i64 %t30, ptr %l26
  br label %bb3
bb3:
  %t31 = load i64, ptr %l26, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t40 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t32, i64 %a1, i64 %t31, i32 %t35, i32 0)
  store ptr %t40, ptr %l31
  br label %bb4
bb4:
  %t41 = load ptr, ptr %l31, !tbaa !29
  store ptr %t41, ptr %l32, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t47 = load i32, ptr %l2, !tbaa !23
  %t50 = call %"compiler/generic:Context" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceContext(ptr %v0, ptr %v0, ptr %t46, i32 %t47)
  store %"compiler/generic:Context" %t50, ptr %l36
  br label %bb5
bb5:
  %t51 = load %"compiler/generic:Context", ptr %l36
  %t52 = load ptr, ptr %l32, !tbaa !29
  %t53 = getelementptr %"compiler/check:frame", ptr %t52, i32 0, i32 4
  store %"compiler/generic:Context" %t51, ptr %t53
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t54)
  store ptr %t56, ptr %l38
  br label %bb6
bb6:
  store i32 0, ptr %l39
  %t57 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t57, ptr %l40
  br label %bb7
bb7:
  %t58 = load ptr, ptr %l38, !tbaa !29
  %t59 = load i32, ptr %l39, !range !{i32 0, i32 9}
  %t60 = load %"compiler/source:Span", ptr %l40
  %t61 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t58, i32 -1, i32 %t59, %"compiler/source:Span" %t60)
  store i32 %t61, ptr %l41
  br label %bb8
bb8:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  store ptr %t67, ptr %l44, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/check:Checker", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/generic:Program", ptr %t71, i32 0, i32 2
  store ptr %t73, ptr %l47, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t74)
  store ptr %t76, ptr %l49
  br label %bb9
bb9:
  %t77 = load ptr, ptr %l49, !tbaa !29
  %t79 = getelementptr %"compiler/typed:Body", ptr %t77, i32 0, i32 2
  %t80 = load i32, ptr %t79, !tbaa !23
  %t81 = load ptr, ptr %l47, !tbaa !29
  %t83 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t81, i32 %t80)
  store i32 %t83, ptr %l52
  br label %bb10
bb10:
  %t84 = load ptr, ptr %l44, !tbaa !29
  %t85 = load i32, ptr %l52, !tbaa !23
  %t86 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t84, i32 %t85)
  store { i64, ptr } %t86, ptr %l53
  br label %bb11
bb11:
  %t87 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t87, ptr %l7, !tbaa !27
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l54, !tbaa !29
  %t89 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t89, ptr %l55
  br label %bb12
bb12:
  %t90 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t90, ptr %l56, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr i32, ptr %t92, i64 0
  %t94 = load i32, ptr %t93, !tbaa !33
  store { i64, [2 x i64] } zeroinitializer, ptr %t95
  %t96 = getelementptr { i64, [2 x i64] }, ptr %t95, i32 0, i32 0
  store i64 1, ptr %t96
  %t97 = load { i64, [2 x i64] }, ptr %t95
  %t98 = load ptr, ptr %l54, !tbaa !29
  %t99 = load %"compiler/source:Span", ptr %l55
  %t103 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t98, i32 0, %"compiler/source:Span" %t99, i32 %t94, i32 0, { i64, [2 x i64] } %t97)
  store i64 %t103, ptr %l60
  br label %bb13
bb13:
  %t104 = load i64, ptr %l60, !tbaa !24
  store i64 %t104, ptr %l8, !tbaa !24
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t105)
  store ptr %t107, ptr %l62
  br label %bb14
bb14:
  %t108 = load ptr, ptr %l62, !tbaa !29
  %t110 = getelementptr %"compiler/typed:Body", ptr %t108, i32 0, i32 5
  %t111 = load i64, ptr %l8, !tbaa !24
  %t113 = trunc i64 %t111 to i32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ePush_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t110, i32 %t113)
  br label %bb15
bb15:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t117)
  store ptr %t119, ptr %l69
  br label %bb16
bb16:
  %t120 = load ptr, ptr %l69, !tbaa !29
  %t121 = load i64, ptr %l8, !tbaa !24
  %t124 = getelementptr %"compiler/check:frame", ptr %t120, i32 0, i32 29
  store i64 %t121, ptr %t124, !tbaa !24
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t125)
  store ptr %t127, ptr %l73
  br label %bb17
bb17:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/check:Checker", ptr %t128, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !29
  store ptr %t131, ptr %l75, !tbaa !29
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t132)
  store ptr %t134, ptr %l77
  br label %bb18
bb18:
  %t135 = load ptr, ptr %l77, !tbaa !29
  %t137 = getelementptr %"compiler/typed:Body", ptr %t135, i32 0, i32 2
  %t138 = load i32, ptr %t137, !tbaa !23
  %t139 = load ptr, ptr %l75, !tbaa !29
  %t141 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t139, i32 %t138)
  store { i64, ptr } %t141, ptr %l80
  br label %bb19
bb19:
  %t142 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t142, 0
  %t144 = extractvalue { i64, ptr } %t142, 1
  %t145 = mul i64 %t143, 8
  %t146 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t145)
  call void @llvm.memcpy.p0.p0.i64(ptr %t146, ptr %t144, i64 %t145, i1 false)
  %t147 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  %t149 = load ptr, ptr %l73, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eSetVars(ptr %v0, ptr %s0, ptr %t149, { i64, ptr } %t148)
  br label %bb20
bb20:
  store ptr null, ptr %l9, !tbaa !29
  %t151 = load ptr, ptr %l4, !tbaa !29
  %t153 = icmp eq ptr %t151, null
  br i1 %t153, label %bb21, label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_f2da914bb6134d5f_3ef82b9ab3e359c3)
  unreachable
bb22:
  br label %bb23
bb23:
  %t155 = load ptr, ptr %l4, !tbaa !29
  %t158 = getelementptr %"compiler/ast:TypeDecl", ptr %t155, i32 0, i32 3
  %t159 = load ptr, ptr %t158, !tbaa !29
  store ptr %t159, ptr %l10, !tbaa !29
  %t161 = load ptr, ptr %l10, !tbaa !29
  store ptr %t161, ptr %l87, !tbaa !29
  store i1 false, ptr %l88, !tbaa !21
  %t162 = load ptr, ptr %l87, !tbaa !29
  %t163 = icmp ne ptr %t162, null
  br i1 %t163, label %bb24, label %bb25
bb24:
  %t165 = load ptr, ptr %l87, !tbaa !29
  %t166 = load i64, ptr %t165, !range !{i64 0, i64 5}
  %t168 = icmp eq i64 %t166, 0
  store i1 %t168, ptr %l88, !tbaa !21
  br label %bb25
bb25:
  %t169 = load i1, ptr %l88, !tbaa !21
  br i1 %t169, label %bb26, label %bb27
bb26:
  %t170 = load ptr, ptr %l10, !tbaa !29
  %t172 = getelementptr { i64, [6 x i64] }, ptr %t170, i32 0, i32 1
  %t173 = getelementptr { ptr }, ptr %t172, i32 0, i32 0
  %t174 = load ptr, ptr %t173
  store ptr %t174, ptr %l11, !tbaa !29
  br label %bb28
bb27:
  br label %bb42
bb28:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t176)
  store ptr %t178, ptr %l94
  br label %bb29
bb29:
  %t179 = load ptr, ptr %l94, !tbaa !29
  %t180 = load ptr, ptr %l11, !tbaa !29
  %t182 = getelementptr %"compiler/ast:StructBody", ptr %t180, i32 0, i32 3
  %t183 = load %"compiler/source:Span", ptr %t182
  %t186 = getelementptr %"compiler/typed:Body", ptr %t179, i32 0, i32 4
  store %"compiler/source:Span" %t183, ptr %t186
  %t187 = load ptr, ptr %l11, !tbaa !29
  %t189 = getelementptr %"compiler/ast:StructBody", ptr %t187, i32 0, i32 4
  %t190 = load { i64, ptr }, ptr %t189, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t190, 0
  %t194 = icmp eq i64 %t192, 0
  br i1 %t194, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s2
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load ptr, ptr %l11, !tbaa !29
  %t199 = getelementptr %"compiler/ast:StructBody", ptr %t197, i32 0, i32 3
  %t200 = load %"compiler/source:Span", ptr %t199
  %t203 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t196, %"compiler/source:Span" %t200)
  store { i64, ptr } %t203, ptr %l106
  br label %bb32
bb31:
  br label %bb40
bb32:
  %t204 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t205 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s2, { i64, ptr } %t204, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) })
  %t206 = extractvalue { i32, i64 } %t205, 1
  %t207 = extractvalue { i32, i64 } %t205, 0
  store i32 %t207, ptr %l108
  %t208 = icmp ne i32 %t207, 0
  br i1 %t208, label %bb34, label %ok.209, !prof !99
ok.209:
  store i64 %t206, ptr %l107
  br label %bb33
bb33:
  %t210 = load i64, ptr %l107, !tbaa !24
  store i64 %t210, ptr %l102, !tbaa !24
  br label %bb36
bb34:
  br label %bb35
bb35:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l102, !tbaa !24
  br label %bb36
bb36:
  %t211 = load i64, ptr %l102, !tbaa !24
  store i64 %t211, ptr %l12, !tbaa !24
  %t212 = load ptr, ptr %l0, !tbaa !29
  store ptr %t212, ptr %l109, !tbaa !29
  %t213 = load ptr, ptr %l11, !tbaa !29
  %t215 = getelementptr %"compiler/ast:StructBody", ptr %t213, i32 0, i32 3
  %t216 = getelementptr %"compiler/source:Span", ptr %t215, i32 0, i32 0
  %t217 = load i32, ptr %t216, !tbaa !23
  %t218 = load i64, ptr %l12, !tbaa !24
  %t220 = trunc i64 %t218 to i32
  %t223 = add i32 %t217, %t220
  %t224 = load ptr, ptr %l11, !tbaa !29
  %t226 = getelementptr %"compiler/ast:StructBody", ptr %t224, i32 0, i32 3
  %t227 = getelementptr %"compiler/source:Span", ptr %t226, i32 0, i32 0
  %t228 = load i32, ptr %t227, !tbaa !23
  %t229 = load i64, ptr %l12, !tbaa !24
  %t231 = add i64 %t229, 1
  %t233 = trunc i64 %t231 to i32
  %t236 = add i32 %t228, %t233
  %t239 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s2, i32 %t223, i32 %t236)
  store %"compiler/source:Span" %t239, ptr %l121
  br label %bb37
bb37:
  %t240 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eEmptyDestructor(ptr %s2)
  store %"compiler/msgs:Msg" %t240, ptr %l122
  br label %bb38
bb38:
  %t241 = load ptr, ptr %l109, !tbaa !29
  %t242 = load %"compiler/source:Span", ptr %l121
  %t243 = load %"compiler/msgs:Msg", ptr %l122
  %t244 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t241, %"compiler/source:Span" %t242, %"compiler/msgs:Msg" %t243)
  store i64 %t244, ptr %l123
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s2)
  br label %bb40
bb40:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load ptr, ptr %l11, !tbaa !29
  %t248 = getelementptr %"compiler/ast:StructBody", ptr %t246, i32 0, i32 4
  %t249 = load { i64, ptr }, ptr %t248, !tbaa !27
  %t252 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootStmts(ptr %v0, ptr %v0, ptr %t245, { i64, ptr } %t249)
  store ptr %t252, ptr %l127
  br label %bb41
bb41:
  %t253 = load ptr, ptr %l127, !tbaa !29
  store ptr %t253, ptr %l9, !tbaa !29
  br label %bb52
bb42:
  br i1 true, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb51
bb45:
  %t255 = icmp sge i64 0, 0
  br i1 %t255, label %bb46, label %bb47
bb46:
  %t257 = icmp sle i64 0, 1152921504606846975
  br i1 %t257, label %bb48, label %bb49
bb47:
  call void @__olang_check_failed(ptr @olang_loc_e7a3ae7e66c3138_2e8ed5b6f09d874)
  unreachable
bb48:
  %t259 = mul i64 0, 8
  %t260 = insertvalue { i64, ptr } undef, i64 0, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t263 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 0, { i64, ptr } %t261)
  store %"compiler/typed:Block" %t263, ptr %l132
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_e7a3ae7e66c3138_2e8ed5b6f09d874)
  unreachable
bb50:
  %t264 = load %"compiler/typed:Block", ptr %l132
  %t265 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t264, ptr %t265
  store ptr %t265, ptr %l9, !tbaa !29
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_de922dec49c7f00c_86e7828aa2d91a60)
  unreachable
bb52:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t267)
  store ptr %t269, ptr %l135
  br label %bb53
bb53:
  %t270 = load ptr, ptr %l135, !tbaa !29
  %t271 = load ptr, ptr %l9, !tbaa !29
  %t274 = getelementptr %"compiler/typed:Body", ptr %t270, i32 0, i32 11
  store ptr %t271, ptr %t274, !tbaa !29
  %t275 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t275)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomprOpen(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, i64, i64 }
  %l12 = alloca ptr
  %l15 = alloca i64
  %l19 = alloca { i64, i64, i64 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 91
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp ne i64 %t4, 1
  br i1 %t6, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l12, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 37
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t11)
  store i64 %t13, ptr %l15
  br label %bb4
bb4:
  %t14 = load i64, ptr %l15, !tbaa !24
  %t15 = load ptr, ptr %l12, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 95
  store i64 %t14, ptr %t16, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t22 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t17, i32 8, %"compiler/source:Span" %a1)
  store { i64, i64, i64 } %t22, ptr %l19
  br label %bb5
bb5:
  %t23 = load { i64, i64, i64 }, ptr %l19
  store { i64, i64, i64 } %t23, ptr %l2
  %t24 = getelementptr { i64, i64, i64 }, ptr %l2, i32 0, i32 0
  %t25 = load i64, ptr %t24, !tbaa !24
  %t27 = getelementptr { i64, i64, i64 }, ptr %l2, i32 0, i32 1
  %t28 = load i64, ptr %t27, !tbaa !24
  %t30 = getelementptr { i64, i64, i64 }, ptr %l2, i32 0, i32 2
  %t31 = load i64, ptr %t30, !tbaa !24
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 92
  store i64 %t25, ptr %t43, !tbaa !24
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 93
  store i64 %t28, ptr %t48, !tbaa !24
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 94
  store i64 %t31, ptr %t53, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 91
  store i64 2, ptr %t56, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomptimeFor(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l18 = alloca %"compiler/source:Span"
  %l21 = alloca ptr
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca %"compiler/msgs:Msg"
  %l24 = alloca i64
  %l28 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l30 = alloca i32
  %l33 = alloca ptr
  %l34 = alloca i1
  %l46 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca i64
  %l61 = alloca i64
  %l64 = alloca i32
  %l69 = alloca i32
  %l72 = alloca i1
  %l73 = alloca i1
  %l81 = alloca ptr
  %l83 = alloca ptr
  %l88 = alloca { i64, ptr }
  %l94 = alloca i1
  %l95 = alloca ptr
  %l98 = alloca %"compiler/source:Span"
  %l99 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l105 = alloca i32
  %l106 = alloca %"compiler/msgs:Msg"
  %l107 = alloca i64
  %l111 = alloca { i64, ptr }
  %l116 = alloca { i64, ptr }
  %l117 = alloca i32
  %l119 = alloca ptr
  %l122 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l127 = alloca %"compiler/check:UnrollAsk"
  %l132 = alloca ptr
  %l133 = alloca %"compiler/source:Span"
  %l137 = alloca %"compiler/msgs:Msg"
  %l138 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t2 = load i32, ptr %t1, !tbaa !23
  %t3 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = add i32 %t4, 8
  %t9 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t2, i32 %t6)
  store %"compiler/source:Span" %t9, ptr %l18
  br label %bb1
bb1:
  %t10 = load %"compiler/source:Span", ptr %l18
  store %"compiler/source:Span" %t10, ptr %l3
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = getelementptr %"compiler/ast:ForIn", ptr %t11, i32 0, i32 3
  %t14 = load i1, ptr %t13, !tbaa !21
  br i1 %t14, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l21, !tbaa !29
  %t17 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t17, ptr %l22
  %t18 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eComptimeForTry(ptr %s1)
  store %"compiler/msgs:Msg" %t18, ptr %l23
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t19 = load ptr, ptr %l21, !tbaa !29
  %t20 = load %"compiler/source:Span", ptr %l22
  %t21 = load %"compiler/msgs:Msg", ptr %l23
  %t22 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t19, %"compiler/source:Span" %t20, %"compiler/msgs:Msg" %t21)
  store i64 %t22, ptr %l24
  br label %bb5
bb5:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load %"compiler/source:Span", ptr %l1
  %t25 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollOnce(ptr %v0, ptr %v1, ptr %t23, %"compiler/source:Span" %t24, ptr %t25)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  %t29 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t29, ptr %l28
  br label %bb8
bb8:
  %t30 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l28
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t30, ptr %l4
  store i64 -1, ptr %l5, !tbaa !24
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t31)
  store i32 %t33, ptr %l30
  br label %bb9
bb9:
  %t34 = load i32, ptr %l30, !tbaa !23
  store i32 %t34, ptr %l6, !tbaa !23
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"compiler/ast:ForIn", ptr %t35, i32 0, i32 2
  %t38 = load ptr, ptr %t37, !tbaa !29
  store ptr %t38, ptr %l7, !tbaa !29
  %t40 = load ptr, ptr %l7, !tbaa !29
  store ptr %t40, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t41 = load ptr, ptr %l33, !tbaa !29
  %t42 = icmp ne ptr %t41, null
  br i1 %t42, label %bb10, label %bb11
bb10:
  %t44 = load ptr, ptr %l33, !tbaa !29
  %t45 = load i64, ptr %t44, !range !{i64 0, i64 29}
  %t47 = icmp eq i64 %t45, 25
  store i1 %t47, ptr %l34, !tbaa !21
  br label %bb11
bb11:
  %t48 = load i1, ptr %l34, !tbaa !21
  br i1 %t48, label %bb12, label %bb13
bb12:
  %t49 = load ptr, ptr %l7, !tbaa !29
  %t51 = getelementptr { i64, [5 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t51, i32 0, i32 1
  %t53 = load { i64, ptr }, ptr %t52
  store { i64, ptr } %t53, ptr %l8, !tbaa !27
  br label %bb14
bb13:
  br label %bb24
bb14:
  %t55 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t55, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t57 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t57, 0
  store i64 %t59, ptr %l11, !tbaa !24
  br label %bb15
bb15:
  %t61 = load i64, ptr %l10, !tbaa !24
  %t62 = load i64, ptr %l11, !tbaa !24
  %t65 = icmp slt i64 %t61, %t62
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb16, label %bb17
bb16:
  br label %bb23
bb17:
  br label %bb18
bb18:
  %t69 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t69, ptr %l46, !tbaa !27
  %t70 = load i64, ptr %l10, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr ptr, ptr %t73, i64 %t70
  %t75 = load ptr, ptr %t74, !tbaa !39
  store ptr %l4, ptr %l49, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l50, !tbaa !29
  store ptr %t75, ptr %l51, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t79)
  store i32 %t81, ptr %l53
  br label %bb19
bb19:
  %t82 = load ptr, ptr %l50, !tbaa !29
  %t83 = load ptr, ptr %l51, !tbaa !29
  %t84 = load i32, ptr %l53, !tbaa !23
  %t85 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollBody(ptr %v0, ptr %v1, ptr %t82, ptr %t83, i32 %t84)
  store i64 %t85, ptr %l54
  br label %bb20
bb20:
  %t86 = load ptr, ptr %l49, !tbaa !29
  %t87 = load i64, ptr %l54, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t86, i64 %t87)
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t88 = load i64, ptr %l10, !tbaa !24
  %t90 = add i64 %t88, 1
  store i64 %t90, ptr %l10, !tbaa !24
  br label %bb15
bb23:
  br label %bb34
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb33
bb27:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l2, !tbaa !29
  %t95 = getelementptr %"compiler/ast:ForIn", ptr %t93, i32 0, i32 2
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t97 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t101 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollBody(ptr %v0, ptr %v1, ptr %t92, ptr %t96, i32 %t97)
  store i64 %t101, ptr %l61
  br label %bb28
bb28:
  %t102 = load i64, ptr %l61, !tbaa !24
  store i64 %t102, ptr %l5, !tbaa !24
  %t103 = load i64, ptr %l5, !tbaa !24
  %t105 = icmp sge i64 %t103, 0
  br i1 %t105, label %bb29, label %bb30
bb29:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load ptr, ptr %l2, !tbaa !29
  %t110 = getelementptr %"compiler/ast:ForIn", ptr %t108, i32 0, i32 2
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t112 = load i64, ptr %l5, !tbaa !24
  %t116 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollElem(ptr %v0, ptr %v1, ptr %t107, ptr %t111, i64 %t112)
  store i32 %t116, ptr %l69
  br label %bb31
bb30:
  %t117 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t117, ptr %l64, !tbaa !23
  br label %bb32
bb31:
  %t119 = load i32, ptr %l69, !tbaa !23
  store i32 %t119, ptr %l64, !tbaa !23
  br label %bb32
bb32:
  %t120 = load i32, ptr %l64, !tbaa !23
  store i32 %t120, ptr %l6, !tbaa !23
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_d826e759488f41a6_3ea05b0e10c73972)
  unreachable
bb34:
  %t122 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %s0, ptr %l4, i64 -1)
  store i1 %t122, ptr %l72
  br label %bb35
bb35:
  %t123 = load i1, ptr %l72, !tbaa !21
  br i1 %t123, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb38
bb37:
  %t124 = load i32, ptr %l6, !tbaa !23
  %t125 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t128 = icmp eq i32 %t124, %t125
  store i1 %t128, ptr %l73, !tbaa !21
  br label %bb38
bb38:
  %t130 = load i1, ptr %l73, !tbaa !21
  br i1 %t130, label %bb39, label %bb40
bb39:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load %"compiler/source:Span", ptr %l1
  %t133 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollOnce(ptr %v0, ptr %v1, ptr %t131, %"compiler/source:Span" %t132, ptr %t133)
  br label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb42:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/check:Checker", ptr %t137, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !29
  store ptr %t140, ptr %l81, !tbaa !29
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t141)
  store ptr %t143, ptr %l83
  br label %bb43
bb43:
  %t144 = load ptr, ptr %l83, !tbaa !29
  %t146 = getelementptr %"compiler/check:frame", ptr %t144, i32 0, i32 4
  %t147 = load ptr, ptr %l2, !tbaa !29
  %t149 = getelementptr %"compiler/ast:ForIn", ptr %t147, i32 0, i32 2
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t151 = load ptr, ptr %l81, !tbaa !29
  %t154 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLengthKey(ptr %v0, ptr %v0, ptr %v1, ptr %s0, ptr %t151, ptr %t146, ptr %t150)
  store { i64, ptr } %t154, ptr %l88
  br label %bb44
bb44:
  %t155 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t156 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t157 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t157, 1
  %t159 = extractvalue { i64, ptr } %t157, 0
  %t160 = add i64 %t156, %t159
  %t161 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t160)
  call void @olang_textcopy(ptr %t161, ptr %t155, i64 %t156)
  %t162 = getelementptr i8, ptr %t161, i64 %t156
  call void @olang_textcopy(ptr %t162, ptr %t158, i64 %t159)
  %t163 = insertvalue { i64, ptr } undef, i64 %t160, 0
  %t164 = insertvalue { i64, ptr } %t163, ptr %t161, 1
  store { i64, ptr } %t164, ptr %l13, !tbaa !27
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/check:Checker", ptr %t166, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t171 = getelementptr %"compiler/generic:Program", ptr %t169, i32 0, i32 44
  %t172 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t175 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_He27db0a1785588531472bfd2db42574f(ptr %v0, ptr %s0, ptr %t171, { i64, ptr } %t172)
  store i1 %t175, ptr %l94
  br label %bb45
bb45:
  %t176 = load i1, ptr %l94, !tbaa !21
  br i1 %t176, label %bb46, label %bb47
bb46:
  store %olang.scope zeroinitializer, ptr %s9
  %t177 = load ptr, ptr %l0, !tbaa !29
  store ptr %t177, ptr %l95, !tbaa !29
  %t178 = load ptr, ptr %l2, !tbaa !29
  %t180 = getelementptr %"compiler/ast:ForIn", ptr %t178, i32 0, i32 2
  %t181 = load ptr, ptr %t180, !tbaa !29
  %t183 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t181)
  store %"compiler/source:Span" %t183, ptr %l98
  br label %bb48
bb47:
  br label %bb56
bb48:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/check:Checker", ptr %t184, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !29
  %t189 = getelementptr %"compiler/generic:Program", ptr %t187, i32 0, i32 44
  %t190 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t193 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %s0, ptr %v0, ptr %t189, { i64, ptr } %t190)
  %t194 = extractvalue { i32, { i64, ptr } } %t193, 1
  %t195 = extractvalue { i32, { i64, ptr } } %t193, 0
  store i32 %t195, ptr %l105
  %t196 = icmp ne i32 %t195, 0
  br i1 %t196, label %bb50, label %ok.197, !prof !99
ok.197:
  store { i64, ptr } %t194, ptr %l104
  br label %bb49
bb49:
  %t198 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t198, ptr %l99, !tbaa !27
  br label %bb52
bb50:
  br label %bb51
bb51:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l99, !tbaa !27
  br label %bb52
bb52:
  %t199 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t200 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eComptimeForUnknown(ptr %v0, ptr %s9, { i64, ptr } %t199)
  store %"compiler/msgs:Msg" %t200, ptr %l106
  br label %bb53
bb53:
  %t201 = load ptr, ptr %l95, !tbaa !29
  %t202 = load %"compiler/source:Span", ptr %l98
  %t203 = load %"compiler/msgs:Msg", ptr %l106
  %t204 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s9, ptr %t201, %"compiler/source:Span" %t202, %"compiler/msgs:Msg" %t203)
  store i64 %t204, ptr %l107
  br label %bb54
bb54:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load %"compiler/source:Span", ptr %l1
  %t207 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollOnce(ptr %v0, ptr %v1, ptr %t205, %"compiler/source:Span" %t206, ptr %t207)
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb56:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/check:Checker", ptr %t211, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t216 = getelementptr %"compiler/generic:Program", ptr %t214, i32 0, i32 43
  %t217 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t220 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H09835701baa5b197f16fe6901ed0f7b4(ptr %v0, ptr %s0, ptr %v0, ptr %t216, { i64, ptr } %t217)
  %t221 = extractvalue { i32, { i64, ptr } } %t220, 1
  %t222 = extractvalue { i32, { i64, ptr } } %t220, 0
  store i32 %t222, ptr %l117
  %t223 = icmp ne i32 %t222, 0
  br i1 %t223, label %bb58, label %ok.224, !prof !99
ok.224:
  store { i64, ptr } %t221, ptr %l116
  br label %bb57
bb57:
  %t225 = load { i64, ptr }, ptr %l116, !tbaa !27
  store { i64, ptr } %t225, ptr %l111, !tbaa !27
  br label %bb63
bb58:
  br label %bb59
bb59:
  call void @__olang_ert_req_clear()
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/check:Checker", ptr %t226, i32 0, i32 109
  store ptr %t228, ptr %l119, !tbaa !29
  %t229 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t231 = extractvalue { i64, ptr } %t229, 1
  %t232 = extractvalue { i64, ptr } %t229, 0
  %t233 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t232)
  call void @olang_textcopy(ptr %t233, ptr %t231, i64 %t232)
  %t234 = insertvalue { i64, ptr } undef, i64 %t232, 0
  %t235 = insertvalue { i64, ptr } %t234, ptr %t233, 1
  %t237 = extractvalue { i64, ptr } %t235, 0
  %t238 = extractvalue { i64, ptr } %t235, 1
  %t239 = mul i64 %t237, 1
  %t240 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t239)
  call void @llvm.memcpy.p0.p0.i64(ptr %t240, ptr %t238, i64 %t239, i1 false)
  %t241 = insertvalue { i64, ptr } undef, i64 %t237, 0
  %t242 = insertvalue { i64, ptr } %t241, ptr %t240, 1
  store { i64, ptr } %t242, ptr %l122, !tbaa !27
  %t244 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %v0, ptr %l4)
  store { i64, ptr } %t244, ptr %l124
  br label %bb60
bb60:
  %t245 = load i64, ptr %l5, !tbaa !24
  %t246 = load i32, ptr %l6, !tbaa !23
  %t247 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t248 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t251 = call %"compiler/check:UnrollAsk" @compiler_2fcheck_3aUnrollAsk_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t247, { i64, ptr } %t248, i64 %t245, i32 %t246)
  store %"compiler/check:UnrollAsk" %t251, ptr %l127
  br label %bb61
bb61:
  %t252 = load ptr, ptr %l119, !tbaa !29
  %t253 = load %"compiler/check:UnrollAsk", ptr %l127
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aUnrollAsk_3e_2ePush_He90a5e781e5223c39ec692b3f1e8f929(ptr %v0, ptr %v0, ptr %t252, %"compiler/check:UnrollAsk" %t253)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb63:
  %t254 = load { i64, ptr }, ptr %l111, !tbaa !27
  store { i64, ptr } %t254, ptr %l14, !tbaa !27
  %t255 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t257 = extractvalue { i64, ptr } %t255, 0
  %t258 = load i64, ptr @G_2ecompiler_2fcheck_2eMaxUnroll, !tbaa !24
  %t261 = icmp sgt i64 %t257, %t258
  br i1 %t261, label %bb64, label %bb65
bb64:
  store %olang.scope zeroinitializer, ptr %s12
  %t263 = load ptr, ptr %l0, !tbaa !29
  store ptr %t263, ptr %l132, !tbaa !29
  %t264 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t264, ptr %l133
  %t265 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t267 = extractvalue { i64, ptr } %t265, 0
  %t268 = load i64, ptr @G_2ecompiler_2fcheck_2eMaxUnroll, !tbaa !24
  %t271 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eComptimeForTooMany(ptr %s12, i64 %t267, i64 %t268)
  store %"compiler/msgs:Msg" %t271, ptr %l137
  br label %bb66
bb65:
  br label %bb69
bb66:
  %t272 = load ptr, ptr %l132, !tbaa !29
  %t273 = load %"compiler/source:Span", ptr %l133
  %t274 = load %"compiler/msgs:Msg", ptr %l137
  %t275 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s12, ptr %t272, %"compiler/source:Span" %t273, %"compiler/msgs:Msg" %t274)
  store i64 %t275, ptr %l138
  br label %bb67
bb67:
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t277 = load %"compiler/source:Span", ptr %l1
  %t278 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollOnce(ptr %v0, ptr %v1, ptr %t276, %"compiler/source:Span" %t277, ptr %t278)
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb69:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t283 = load %"compiler/source:Span", ptr %l1
  %t284 = load ptr, ptr %l2, !tbaa !29
  %t285 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t286 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollConsts(ptr %v0, ptr %v1, ptr %v0, ptr %t282, %"compiler/source:Span" %t283, ptr %t284, { i64, ptr } %t285, i32 %t286)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"compiler/check:reflList"
  %l10 = alloca %"compiler/check:reflVal"
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i1
  %l22 = alloca ptr
  %l24 = alloca ptr
  %l28 = alloca %"compiler/names:Ref"
  %l33 = alloca i32
  %l35 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca i32
  %l43 = alloca i1
  %l48 = alloca i32
  %l55 = alloca i64
  %l58 = alloca i1
  %l60 = alloca ptr
  %l63 = alloca i32
  %l64 = alloca %"compiler/generic:Desc"
  %l70 = alloca i32
  %l72 = alloca ptr
  %l73 = alloca i1
  %l84 = alloca %"compiler/check:reflList"
  %l87 = alloca i1
  %l93 = alloca { i64, ptr }
  %l95 = alloca %"compiler/check:reflVal"
  %l103 = alloca i32
  %l104 = alloca ptr
  %l105 = alloca i1
  %l112 = alloca i32
  %s5 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t2 = load ptr, ptr %l12, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l12, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 29}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l13, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l13, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb33
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  store ptr %t28, ptr %l22, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t29)
  store ptr %t31, ptr %l24
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l24, !tbaa !29
  %t34 = getelementptr %"compiler/check:frame", ptr %t32, i32 0, i32 2
  %t35 = load i64, ptr %t34, !tbaa !24
  %t36 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t37 = load i32, ptr %t36, !tbaa !23
  %t38 = load ptr, ptr %l22, !tbaa !29
  %t41 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t38, i64 %t35, i32 %t37)
  store %"compiler/names:Ref" %t41, ptr %l28
  br label %bb7
bb7:
  %t42 = getelementptr %"compiler/names:Ref", ptr %l28, i32 0, i32 0
  %t43 = load i32, ptr %t42, !range !{i32 0, i32 9}
  %t45 = trunc i64 1 to i32
  %t46 = icmp eq i32 %t43, %t45
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb8, label %bb9
bb8:
  store i32 -1, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t51)
  store ptr %t53, ptr %l35
  br label %bb11
bb11:
  %t54 = load ptr, ptr %l35, !tbaa !29
  %t56 = getelementptr %"compiler/check:frame", ptr %t54, i32 0, i32 4
  %t57 = getelementptr %"compiler/generic:Context", ptr %t56, i32 0, i32 3
  %t58 = load i32, ptr %l3, !tbaa !23
  %t61 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v0, ptr %t57, i32 %t58)
  %t62 = extractvalue { i32, i32 } %t61, 1
  %t63 = extractvalue { i32, i32 } %t61, 0
  store i32 %t63, ptr %l40
  %t64 = icmp ne i32 %t63, 0
  br i1 %t64, label %bb13, label %ok.65, !prof !99
ok.65:
  store i32 %t62, ptr %l39
  br label %bb12
bb12:
  %t66 = load i32, ptr %l39, !tbaa !23
  store i32 %t66, ptr %l33, !tbaa !23
  br label %bb15
bb13:
  br label %bb14
bb14:
  call void @__olang_ert_req_clear()
  store i32 -1, ptr %l33, !tbaa !23
  br label %bb15
bb15:
  %t67 = load i32, ptr %l33, !tbaa !23
  store i32 %t67, ptr %l4, !tbaa !23
  %t68 = load i32, ptr %l4, !tbaa !23
  %t70 = icmp sge i32 %t68, 0
  br i1 %t70, label %bb16, label %bb17
bb16:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/check:Checker", ptr %t72, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = getelementptr %"compiler/generic:Program", ptr %t75, i32 0, i32 2
  %t78 = load i32, ptr %l4, !tbaa !23
  %t81 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t77, i32 %t78)
  store i32 %t81, ptr %l48
  br label %bb18
bb17:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb19
bb18:
  %t82 = load i32, ptr %l48, !range !{i32 0, i32 33}
  %t84 = trunc i64 26 to i32
  %t85 = icmp eq i32 %t82, %t84
  %t87 = xor i1 %t85, true
  store i1 %t87, ptr %l43, !tbaa !21
  br label %bb19
bb19:
  %t89 = load i1, ptr %l43, !tbaa !21
  br i1 %t89, label %bb20, label %bb21
bb20:
  %t90 = load i32, ptr %l4, !tbaa !23
  store i32 %t90, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load i32, ptr %l3, !tbaa !23
  %t96 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t92, i32 %t93)
  store i64 %t96, ptr %l55
  br label %bb23
bb23:
  %t97 = load i64, ptr %l55, !tbaa !24
  store i64 %t97, ptr %l5, !tbaa !24
  %t98 = load i64, ptr %l5, !tbaa !24
  %t100 = icmp sge i64 %t98, 0
  br i1 %t100, label %bb24, label %bb25
bb24:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/check:Checker", ptr %t102, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  store ptr %t105, ptr %l60, !tbaa !29
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i64, ptr %l5, !tbaa !24
  %t110 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t106, i64 %t107)
  store i32 %t110, ptr %l63
  br label %bb26
bb25:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb28
bb26:
  %t111 = load ptr, ptr %l60, !tbaa !29
  %t112 = load i32, ptr %l63, !tbaa !23
  %t113 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t111, i32 %t112)
  store %"compiler/generic:Desc" %t113, ptr %l64
  br label %bb27
bb27:
  %t114 = getelementptr %"compiler/generic:Desc", ptr %l64, i32 0, i32 0
  %t115 = load i64, ptr %t114, !tbaa !24
  %t116 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescNone, !tbaa !24
  %t119 = icmp ne i64 %t115, %t116
  store i1 %t119, ptr %l58, !tbaa !21
  br label %bb28
bb28:
  %t121 = load i1, ptr %l58, !tbaa !21
  br i1 %t121, label %bb29, label %bb30
bb29:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load i64, ptr %l5, !tbaa !24
  %t126 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t122, i64 %t123)
  store i32 %t126, ptr %l70
  br label %bb31
bb30:
  br label %bb32
bb31:
  %t127 = load i32, ptr %l70, !tbaa !23
  store i32 %t127, ptr %rv
  br label %ret
bb32:
  store i32 -1, ptr %rv
  br label %ret
bb33:
  %t129 = load ptr, ptr %l1, !tbaa !29
  store ptr %t129, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t130 = load ptr, ptr %l72, !tbaa !29
  %t131 = icmp ne ptr %t130, null
  br i1 %t131, label %bb34, label %bb35
bb34:
  %t133 = load ptr, ptr %l72, !tbaa !29
  %t134 = load i64, ptr %t133, !range !{i64 0, i64 29}
  %t136 = icmp eq i64 %t134, 16
  store i1 %t136, ptr %l73, !tbaa !21
  br label %bb35
bb35:
  %t137 = load i1, ptr %l73, !tbaa !21
  br i1 %t137, label %bb36, label %bb37
bb36:
  %t138 = load ptr, ptr %l1, !tbaa !29
  %t140 = getelementptr { i64, [5 x i64] }, ptr %t138, i32 0, i32 1
  %t141 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t140, i32 0, i32 0
  %t142 = load %"compiler/source:Span", ptr %t141
  store %"compiler/source:Span" %t142, ptr %l6
  %t144 = load ptr, ptr %l1, !tbaa !29
  %t146 = getelementptr { i64, [5 x i64] }, ptr %t144, i32 0, i32 1
  %t147 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t146, i32 0, i32 1
  %t148 = load ptr, ptr %t147
  store ptr %t148, ptr %l7, !tbaa !29
  %t150 = load ptr, ptr %l1, !tbaa !29
  %t152 = getelementptr { i64, [5 x i64] }, ptr %t150, i32 0, i32 1
  %t153 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t152, i32 0, i32 2
  %t154 = load { i64, ptr }, ptr %t153
  store { i64, ptr } %t154, ptr %l8, !tbaa !27
  br label %bb38
bb37:
  br label %bb51
bb38:
  store %olang.scope zeroinitializer, ptr %s5
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load ptr, ptr %l7, !tbaa !29
  %t160 = call %"compiler/check:reflList" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistOf(ptr %v0, ptr %v1, ptr %t156, ptr %t157)
  store %"compiler/check:reflList" %t160, ptr %l84
  br label %bb39
bb39:
  %t161 = load %"compiler/check:reflList", ptr %l84
  store %"compiler/check:reflList" %t161, ptr %l9
  %t162 = getelementptr %"compiler/check:reflList", ptr %l9, i32 0, i32 0
  %t163 = load i1, ptr %t162, !tbaa !21
  %t165 = xor i1 %t163, true
  br i1 %t165, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l87, !tbaa !21
  br label %bb42
bb41:
  %t167 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t167, 0
  %t171 = icmp ne i64 %t169, 1
  store i1 %t171, ptr %l87, !tbaa !21
  br label %bb42
bb42:
  %t173 = load i1, ptr %l87, !tbaa !21
  br i1 %t173, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s5)
  store i32 -1, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t176, ptr %l93, !tbaa !27
  %t177 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = getelementptr ptr, ptr %t178, i64 0
  %t180 = load ptr, ptr %t179, !tbaa !39
  %t183 = call %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflInt(ptr %v0, ptr %v1, ptr %s5, ptr %t175, ptr %t180)
  store %"compiler/check:reflVal" %t183, ptr %l95
  br label %bb46
bb46:
  %t184 = load %"compiler/check:reflVal", ptr %l95
  store %"compiler/check:reflVal" %t184, ptr %l10
  %t185 = getelementptr %"compiler/check:reflVal", ptr %l10, i32 0, i32 0
  %t186 = load i1, ptr %t185, !tbaa !21
  %t188 = xor i1 %t186, true
  br i1 %t188, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s5)
  store i32 -1, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t192 = load %"compiler/source:Span", ptr %l6
  %t193 = load %"compiler/check:reflList", ptr %l9
  %t194 = getelementptr %"compiler/check:reflVal", ptr %l10, i32 0, i32 2
  %t195 = load i64, ptr %t194, !tbaa !24
  %t200 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistItem(ptr %v0, ptr %t191, %"compiler/source:Span" %t192, %"compiler/check:reflList" %t193, i64 %t195)
  store i32 %t200, ptr %l103
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s5)
  %t201 = load i32, ptr %l103, !tbaa !23
  store i32 %t201, ptr %rv
  br label %ret
bb51:
  %t202 = load ptr, ptr %l1, !tbaa !29
  store ptr %t202, ptr %l104, !tbaa !29
  store i1 false, ptr %l105, !tbaa !21
  %t203 = load ptr, ptr %l104, !tbaa !29
  %t204 = icmp ne ptr %t203, null
  br i1 %t204, label %bb52, label %bb53
bb52:
  %t206 = load ptr, ptr %l104, !tbaa !29
  %t207 = load i64, ptr %t206, !range !{i64 0, i64 29}
  %t209 = icmp eq i64 %t207, 2
  store i1 %t209, ptr %l105, !tbaa !21
  br label %bb53
bb53:
  %t210 = load i1, ptr %l105, !tbaa !21
  br i1 %t210, label %bb54, label %bb55
bb54:
  %t211 = load ptr, ptr %l1, !tbaa !29
  %t213 = getelementptr { i64, [5 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", ptr }, ptr %t213, i32 0, i32 1
  %t215 = load ptr, ptr %t214
  store ptr %t215, ptr %l11, !tbaa !29
  br label %bb56
bb55:
  br label %bb58
bb56:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load ptr, ptr %l11, !tbaa !29
  %t221 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %t217, ptr %t218)
  store i32 %t221, ptr %l112
  br label %bb57
bb57:
  %t222 = load i32, ptr %l112, !tbaa !23
  store i32 %t222, ptr %rv
  br label %ret
bb58:
  br i1 true, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb62
bb61:
  store i32 -1, ptr %rv
  br label %ret
bb62:
  call void @__olang_check_failed(ptr @olang_loc_b90f60f44557575f_8372487000419b6b)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescriptor(ptr %v0, ptr %a0, %"compiler/check:reflList" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/check:reflList"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l12 = alloca i32
  %l20 = alloca i32
  %l22 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca i64
  %l42 = alloca i32
  %l45 = alloca i64
  %l48 = alloca i32
  %l57 = alloca i32
  %l63 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store %"compiler/check:reflList" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/check:reflList", ptr %l1, i32 0, i32 2
  %t2 = load i64, ptr %t1, !tbaa !24
  %t3 = load i64, ptr @G_2ecompiler_2fgeneric_2eListFunctions, !tbaa !24
  %t6 = icmp eq i64 %t2, %t3
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t8, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t12 = load i64, ptr %l2, !tbaa !24
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t17 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFuncDescriptor(ptr %v0, ptr %t11, i64 %t12, i32 %t13)
  store i32 %t17, ptr %l12
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t18 = load i32, ptr %l12, !tbaa !23
  store i32 %t18, ptr %rv
  br label %ret
bb4:
  %t19 = getelementptr %"compiler/check:reflList", ptr %l1, i32 0, i32 2
  %t20 = load i64, ptr %t19, !tbaa !24
  %t21 = load i64, ptr @G_2ecompiler_2fgeneric_2eListMethods, !tbaa !24
  %t24 = icmp eq i64 %t20, %t21
  br i1 %t24, label %bb5, label %bb6
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t30 = load i64, ptr %l2, !tbaa !24
  %t31 = getelementptr %"compiler/check:reflList", ptr %l1, i32 0, i32 1
  %t32 = load i32, ptr %t31, !tbaa !23
  %t36 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFuncDescriptor(ptr %v0, ptr %t29, i64 %t30, i32 %t32)
  store i32 %t36, ptr %l20
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t37 = load i32, ptr %l20, !tbaa !23
  store i32 %t37, ptr %rv
  br label %ret
bb8:
  %t38 = getelementptr %"compiler/check:reflList", ptr %l1, i32 0, i32 2
  %t39 = load i64, ptr %t38, !tbaa !24
  store i64 %t39, ptr %l3, !tbaa !24
  %t41 = load i64, ptr %l3, !tbaa !24
  %t42 = load i64, ptr @G_2ecompiler_2fgeneric_2eListFields, !tbaa !24
  %t45 = icmp eq i64 %t41, %t42
  br i1 %t45, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t47 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescField, !tbaa !24
  store i64 %t47, ptr %l22, !tbaa !24
  br label %bb25
bb12:
  %t49 = load i64, ptr %l3, !tbaa !24
  %t50 = load i64, ptr @G_2ecompiler_2fgeneric_2eListCases, !tbaa !24
  %t53 = icmp eq i64 %t49, %t50
  br i1 %t53, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t55 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescCase, !tbaa !24
  store i64 %t55, ptr %l22, !tbaa !24
  br label %bb25
bb16:
  %t57 = load i64, ptr %l3, !tbaa !24
  %t58 = load i64, ptr @G_2ecompiler_2fgeneric_2eListParams, !tbaa !24
  %t61 = icmp eq i64 %t57, %t58
  br i1 %t61, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t63 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescParam, !tbaa !24
  store i64 %t63, ptr %l22, !tbaa !24
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  %t65 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescResult, !tbaa !24
  store i64 %t65, ptr %l22, !tbaa !24
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_56167ce98e06ac0c_8ddb750e2bed0608)
  unreachable
bb25:
  %t67 = load i64, ptr %l22, !tbaa !24
  store i64 %t67, ptr %l4, !tbaa !24
  %t68 = load i64, ptr %l4, !tbaa !24
  %t69 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescField, !tbaa !24
  %t72 = icmp eq i64 %t68, %t69
  br i1 %t72, label %bb26, label %bb27
bb26:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  store ptr %t77, ptr %l40, !tbaa !29
  %t78 = load i64, ptr %l4, !tbaa !24
  store i64 %t78, ptr %l41, !tbaa !24
  %t79 = getelementptr %"compiler/check:reflList", ptr %l1, i32 0, i32 1
  %t80 = load i32, ptr %t79, !tbaa !23
  store i32 %t80, ptr %l42, !tbaa !23
  %t81 = getelementptr %"compiler/check:reflList", ptr %l1, i32 0, i32 3
  %t82 = load i64, ptr %t81, !tbaa !24
  %t84 = icmp slt i64 %t82, 0
  br i1 %t84, label %bb28, label %bb29
bb27:
  br label %bb32
bb28:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb30
bb29:
  %t86 = getelementptr %"compiler/check:reflList", ptr %l1, i32 0, i32 3
  %t87 = load i64, ptr %t86, !tbaa !24
  store i64 %t87, ptr %l45, !tbaa !24
  br label %bb30
bb30:
  %t89 = load i64, ptr %l2, !tbaa !24
  %t90 = load ptr, ptr %l40, !tbaa !29
  %t91 = load i64, ptr %l41, !tbaa !24
  %t92 = load i32, ptr %l42, !tbaa !23
  %t93 = load i64, ptr %l45, !tbaa !24
  %t95 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescriptor(ptr %v0, ptr %t90, i64 %t91, i32 %t92, i64 %t93, i64 %t89)
  store i32 %t95, ptr %l48
  br label %bb31
bb31:
  %t96 = load i32, ptr %l48, !tbaa !23
  store i32 %t96, ptr %rv
  br label %ret
bb32:
  %t97 = load i64, ptr %l4, !tbaa !24
  %t98 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescCase, !tbaa !24
  %t101 = icmp eq i64 %t97, %t98
  br i1 %t101, label %bb33, label %bb34
bb33:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t107 = load i64, ptr %l4, !tbaa !24
  %t108 = getelementptr %"compiler/check:reflList", ptr %l1, i32 0, i32 1
  %t109 = load i32, ptr %t108, !tbaa !23
  %t110 = load i64, ptr %l2, !tbaa !24
  %t115 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescriptor(ptr %v0, ptr %t106, i64 %t107, i32 %t109, i64 %t110, i64 0)
  store i32 %t115, ptr %l57
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t116 = load i32, ptr %l57, !tbaa !23
  store i32 %t116, ptr %rv
  br label %ret
bb36:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t121 = load i64, ptr %l4, !tbaa !24
  %t122 = getelementptr %"compiler/check:reflList", ptr %l1, i32 0, i32 1
  %t123 = load i32, ptr %t122, !tbaa !23
  %t124 = load i64, ptr %l2, !tbaa !24
  %t129 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescriptor(ptr %v0, ptr %t120, i64 %t121, i32 %t123, i64 0, i64 %t124)
  store i32 %t129, ptr %l63
  br label %bb37
bb37:
  %t130 = load i32, ptr %l63, !tbaa !23
  store i32 %t130, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeqMethod(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i64
  %l17 = alloca i1
  %l18 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca i32
  %l27 = alloca i32
  %l28 = alloca i64
  %l31 = alloca i1
  %l34 = alloca ptr
  %l37 = alloca ptr
  %l41 = alloca i32
  %l42 = alloca i32
  %l43 = alloca { i64, ptr }
  %l50 = alloca i64
  %l52 = alloca ptr
  %l56 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  store i32 %t5, ptr %l5, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/load:Loader", ptr %t12, i32 0, i32 3
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t15, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store i32 %t17, ptr %l10
  br label %bb1
bb1:
  %t18 = load ptr, ptr %l4, !tbaa !29
  %t19 = load i32, ptr %l5, !tbaa !23
  %t20 = load i32, ptr %l10, !tbaa !23
  %t21 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t18, i32 %t19, i32 %t20)
  store i64 %t21, ptr %l11
  br label %bb2
bb2:
  %t22 = load i64, ptr %l11, !tbaa !24
  store i64 %t22, ptr %l2, !tbaa !24
  %t23 = load i64, ptr %l2, !tbaa !24
  %t25 = icmp sge i64 %t23, 0
  br i1 %t25, label %bb3, label %bb4
bb3:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l1, !tbaa !23
  %t29 = load i64, ptr %l2, !tbaa !24
  %t33 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeqShaped(ptr %v0, ptr %t27, i32 %t28, i64 %t29)
  store i1 %t33, ptr %l17
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t34 = load i1, ptr %l17, !tbaa !21
  br i1 %t34, label %bb6, label %bb7
bb6:
  %t35 = load i64, ptr %l2, !tbaa !24
  store i64 %t35, ptr %l18, !tbaa !24
  br label %bb8
bb7:
  store i64 -1, ptr %l18, !tbaa !24
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t37 = load i64, ptr %l18, !tbaa !24
  store i64 %t37, ptr %rv
  br label %ret
bb9:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  store ptr %t41, ptr %l21, !tbaa !29
  %t42 = load i32, ptr %l1, !tbaa !23
  store i32 %t42, ptr %l22, !tbaa !23
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 0
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/load:Loader", ptr %t49, i32 0, i32 3
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t52, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i32 %t54, ptr %l27
  br label %bb10
bb10:
  %t55 = load ptr, ptr %l21, !tbaa !29
  %t56 = load i32, ptr %l22, !tbaa !23
  %t57 = load i32, ptr %l27, !tbaa !23
  %t58 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t55, i32 %t56, i32 %t57)
  store i64 %t58, ptr %l28
  br label %bb11
bb11:
  %t59 = load i64, ptr %l28, !tbaa !24
  store i64 %t59, ptr %l2, !tbaa !24
  %t60 = load i64, ptr %l2, !tbaa !24
  %t62 = icmp slt i64 %t60, 0
  br i1 %t62, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb17
bb13:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  store ptr %t69, ptr %l34, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/check:Checker", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/generic:Program", ptr %t73, i32 0, i32 2
  store ptr %t75, ptr %l37, !tbaa !29
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t80 = load i64, ptr %l2, !tbaa !24
  %t83 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t79, i64 %t80)
  store i32 %t83, ptr %l41
  br label %bb14
bb14:
  %t84 = load ptr, ptr %l37, !tbaa !29
  %t85 = load i32, ptr %l41, !tbaa !23
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t84, i32 %t85)
  store i32 %t86, ptr %l42
  br label %bb15
bb15:
  %t87 = load ptr, ptr %l34, !tbaa !29
  %t88 = load i32, ptr %l42, !tbaa !23
  %t89 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t87, i32 %t88)
  store { i64, ptr } %t89, ptr %l43
  br label %bb16
bb16:
  %t90 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  %t93 = icmp ne i64 %t91, 2
  store i1 %t93, ptr %l31, !tbaa !21
  br label %bb17
bb17:
  %t95 = load i1, ptr %l31, !tbaa !21
  br i1 %t95, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t101 = load i64, ptr %l2, !tbaa !24
  %t104 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t100, i64 %t101)
  store i64 %t104, ptr %l50
  br label %bb21
bb21:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t105)
  store ptr %t107, ptr %l52
  br label %bb22
bb22:
  %t108 = load ptr, ptr %l52, !tbaa !29
  %t110 = getelementptr %"compiler/check:frame", ptr %t108, i32 0, i32 1
  %t111 = load i64, ptr %t110, !tbaa !24
  %t112 = load i64, ptr %l50, !tbaa !24
  %t114 = icmp eq i64 %t112, %t111
  br i1 %t114, label %bb23, label %bb24
bb23:
  %t116 = load i64, ptr %l2, !tbaa !24
  store i64 %t116, ptr %l56, !tbaa !24
  br label %bb25
bb24:
  store i64 -2, ptr %l56, !tbaa !24
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t118 = load i64, ptr %l56, !tbaa !24
  store i64 %t118, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrBefore(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i32
  %l18 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i32
  %l28 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca ptr
  %l40 = alloca ptr
  %l45 = alloca i64
  %l46 = alloca ptr
  %l51 = alloca i1
  %l55 = alloca i1
  %l56 = alloca ptr
  %l61 = alloca i32
  %l62 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l68 = alloca i32
  %l69 = alloca { i64, ptr }
  %l70 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l9, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t12, i32 %a1)
  store i32 %t16, ptr %l14
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l9, !tbaa !29
  %t18 = load i32, ptr %l14, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t19, ptr %l15
  br label %bb2
bb2:
  %t20 = load i32, ptr %l15, !tbaa !23
  store i32 %t20, ptr %l3, !tbaa !23
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 2
  store ptr %t26, ptr %l18, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/generic:Program", ptr %t30, i32 0, i32 2
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t32, i32 %a2)
  store i32 %t36, ptr %l23
  br label %bb3
bb3:
  %t37 = load ptr, ptr %l18, !tbaa !29
  %t38 = load i32, ptr %l23, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t39, ptr %l24
  br label %bb4
bb4:
  %t40 = load i32, ptr %l24, !tbaa !23
  store i32 %t40, ptr %l4, !tbaa !23
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/load:Loader", ptr %t47, i32 0, i32 5
  store ptr %t49, ptr %l28, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %l3, !tbaa !23
  %t59 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t55, i32 %t56)
  store i64 %t59, ptr %l33
  br label %bb5
bb5:
  %t60 = load ptr, ptr %l28, !tbaa !29
  %t61 = load i64, ptr %l33, !tbaa !24
  %t62 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t60, i64 %t61)
  store ptr %t62, ptr %l34
  br label %bb6
bb6:
  %t63 = load ptr, ptr %l34, !tbaa !29
  %t65 = getelementptr %"compiler/load:Module", ptr %t63, i32 0, i32 2
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !27
  store { i64, ptr } %t66, ptr %l5, !tbaa !27
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/check:Checker", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/generic:Program", ptr %t71, i32 0, i32 0
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/load:Loader", ptr %t74, i32 0, i32 5
  store ptr %t76, ptr %l40, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/generic:Program", ptr %t80, i32 0, i32 2
  %t83 = load i32, ptr %l4, !tbaa !23
  %t86 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t82, i32 %t83)
  store i64 %t86, ptr %l45
  br label %bb7
bb7:
  %t87 = load ptr, ptr %l40, !tbaa !29
  %t88 = load i64, ptr %l45, !tbaa !24
  %t89 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t87, i64 %t88)
  store ptr %t89, ptr %l46
  br label %bb8
bb8:
  %t90 = load ptr, ptr %l46, !tbaa !29
  %t92 = getelementptr %"compiler/load:Module", ptr %t90, i32 0, i32 2
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  store { i64, ptr } %t93, ptr %l6, !tbaa !27
  %t95 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t99 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v0, { i64, ptr } %t95, { i64, ptr } %t96)
  store i1 %t99, ptr %l51
  br label %bb9
bb9:
  %t100 = load i1, ptr %l51, !tbaa !21
  %t101 = xor i1 %t100, true
  br i1 %t101, label %bb10, label %bb11
bb10:
  %t103 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t107 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v0, { i64, ptr } %t103, { i64, ptr } %t104)
  store i1 %t107, ptr %l55
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t108 = load i1, ptr %l55, !tbaa !21
  store i1 %t108, ptr %rv
  br label %ret
bb13:
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l56, !tbaa !29
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/check:Checker", ptr %t110, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = getelementptr %"compiler/generic:Program", ptr %t113, i32 0, i32 2
  %t116 = load i32, ptr %l3, !tbaa !23
  %t119 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t115, i32 %t116)
  store i32 %t119, ptr %l61
  br label %bb14
bb14:
  %t120 = load ptr, ptr %l56, !tbaa !29
  %t121 = load i32, ptr %l61, !tbaa !23
  %t122 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t120, i32 %t121)
  store { i64, ptr } %t122, ptr %l62
  br label %bb15
bb15:
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l63, !tbaa !29
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/check:Checker", ptr %t124, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t129 = getelementptr %"compiler/generic:Program", ptr %t127, i32 0, i32 2
  %t130 = load i32, ptr %l4, !tbaa !23
  %t133 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t129, i32 %t130)
  store i32 %t133, ptr %l68
  br label %bb16
bb16:
  %t134 = load ptr, ptr %l63, !tbaa !29
  %t135 = load i32, ptr %l68, !tbaa !23
  %t136 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t134, i32 %t135)
  store { i64, ptr } %t136, ptr %l69
  br label %bb17
bb17:
  %t137 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t138 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t139 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v0, { i64, ptr } %t137, { i64, ptr } %t138)
  store i1 %t139, ptr %l70
  br label %bb18
bb18:
  %t140 = load i1, ptr %l70, !tbaa !21
  store i1 %t140, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrNow(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l6 = alloca ptr
  %l9 = alloca i64
  %l17 = alloca %"compiler/check:errNarrow"
  %l21 = alloca i1
  %l25 = alloca %"compiler/check:errNarrow"
  %l28 = alloca ptr
  %l32 = alloca %"compiler/check:errNarrow"
  %l34 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l39 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l6, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 56
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eLen__H3cdfcddd9c493bd8bcefc7b766e0438b(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l9
  br label %bb2
bb2:
  %t10 = load i64, ptr %l9, !tbaa !24
  %t11 = sub i64 %t10, 1
  store i64 %t11, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp sge i64 %t13, 0
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb4, label %bb5
bb4:
  br label %bb18
bb5:
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t21 = getelementptr %"compiler/check:frame", ptr %t19, i32 0, i32 56
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = call %"compiler/check:errNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eAt_3ccompiler_2fcheck_3aerrNarrow_3e(ptr %v0, ptr %t21, i64 %t22)
  store %"compiler/check:errNarrow" %t25, ptr %l17
  br label %bb7
bb7:
  %t26 = getelementptr %"compiler/check:errNarrow", ptr %l17, i32 0, i32 0
  %t27 = load i32, ptr %t26, !tbaa !23
  %t31 = icmp eq i32 %t27, %a1
  br i1 %t31, label %bb8, label %bb9
bb8:
  %t33 = load ptr, ptr %l3, !tbaa !29
  %t35 = getelementptr %"compiler/check:frame", ptr %t33, i32 0, i32 56
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = call %"compiler/check:errNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eAt_3ccompiler_2fcheck_3aerrNarrow_3e(ptr %v0, ptr %t35, i64 %t36)
  store %"compiler/check:errNarrow" %t39, ptr %l25
  br label %bb10
bb9:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb11
bb10:
  %t40 = getelementptr %"compiler/check:errNarrow", ptr %l25, i32 0, i32 3
  %t41 = load i1, ptr %t40, !tbaa !21
  %t43 = xor i1 %t41, true
  store i1 %t43, ptr %l21, !tbaa !21
  br label %bb11
bb11:
  %t45 = load i1, ptr %l21, !tbaa !21
  br i1 %t45, label %bb12, label %bb13
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l28, !tbaa !29
  %t47 = load ptr, ptr %l3, !tbaa !29
  %t49 = getelementptr %"compiler/check:frame", ptr %t47, i32 0, i32 56
  %t50 = load i64, ptr %l4, !tbaa !24
  %t53 = call %"compiler/check:errNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eAt_3ccompiler_2fcheck_3aerrNarrow_3e(ptr %v0, ptr %t49, i64 %t50)
  store %"compiler/check:errNarrow" %t53, ptr %l32
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t54 = getelementptr %"compiler/check:errNarrow", ptr %l32, i32 0, i32 1
  %t55 = load i32, ptr %t54, !tbaa !23
  %t56 = load ptr, ptr %l28, !tbaa !29
  %t58 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetItems(ptr %v0, ptr %v1, ptr %t56, i32 %t55)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t58, ptr %l34
  br label %bb15
bb15:
  %t59 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l34
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t59, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t60 = load i64, ptr %l4, !tbaa !24
  %t62 = sub i64 %t60, 1
  store i64 %t62, ptr %l4, !tbaa !24
  br label %bb3
bb18:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t68 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetItems(ptr %v0, ptr %v1, ptr %t64, i32 %a2)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t68, ptr %l39
  br label %bb19
bb19:
  %t69 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l39
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t69, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrsCover(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l11 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l24 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t6, i32 %a2)
  store { i64, ptr } %t10, ptr %l11
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t16 = load i64, ptr %l4, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t24, ptr %l18, !tbaa !27
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i32, ptr %t28, i64 %t25
  %t30 = load i32, ptr %t29, !tbaa !33
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t38 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euncovered(ptr %v0, ptr %t32, i32 %a1, i32 %t30)
  store i32 %t38, ptr %l24
  br label %bb6
bb6:
  %t39 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t40 = load i32, ptr %l24, !tbaa !23
  %t42 = icmp ne i32 %t40, %t39
  br i1 %t42, label %bb7, label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t45 = load i64, ptr %l4, !tbaa !24
  %t47 = add i64 %t45, 1
  store i64 %t47, ptr %l4, !tbaa !24
  br label %bb2
bb11:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eescapeRules(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i1
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"compiler/msgs:Msg"
  %l17 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca %"compiler/msgs:Msg"
  %l24 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca %"compiler/source:Span"
  %l33 = alloca { i64, ptr }
  %l34 = alloca %"compiler/msgs:Msg"
  %l35 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca %"compiler/source:Span"
  %l40 = alloca %"compiler/msgs:Msg"
  %l41 = alloca i64
  %l44 = alloca i1
  %l54 = alloca i64
  %l57 = alloca i64
  %l78 = alloca i32
  %l82 = alloca i1
  %l86 = alloca i1
  %l87 = alloca ptr
  %l88 = alloca %"compiler/source:Span"
  %l89 = alloca %"compiler/msgs:Msg"
  %l90 = alloca i64
  %l95 = alloca i32
  %l104 = alloca { i64, ptr }
  %l108 = alloca %"compiler/msgs:Msg"
  %l110 = alloca ptr
  %l114 = alloca %"compiler/msgs:Msg"
  %l116 = alloca i1
  %l118 = alloca %"compiler/msgs:Msg"
  %l122 = alloca i64
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l17
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l17, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 32
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = icmp sge i64 %t8, 0
  br i1 %t10, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l21, !tbaa !29
  %t13 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t13, ptr %l22
  %t14 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeferErrorEscapes(ptr %s1)
  store %"compiler/msgs:Msg" %t14, ptr %l23
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t15 = load ptr, ptr %l21, !tbaa !29
  %t16 = load %"compiler/source:Span", ptr %l22
  %t17 = load %"compiler/msgs:Msg", ptr %l23
  %t18 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t15, %"compiler/source:Span" %t16, %"compiler/msgs:Msg" %t17)
  store i64 %t18, ptr %l24
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb6:
  %t19 = load ptr, ptr %l4, !tbaa !29
  %t21 = getelementptr %"compiler/check:frame", ptr %t19, i32 0, i32 33
  %t22 = load i64, ptr %t21, !tbaa !24
  %t24 = icmp sge i64 %t22, 0
  br i1 %t24, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l28, !tbaa !29
  %t27 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t27, ptr %l29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l4, !tbaa !29
  %t31 = getelementptr %"compiler/check:frame", ptr %t29, i32 0, i32 34
  %t32 = load i1, ptr %t31, !tbaa !21
  %t35 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emsgOwner(ptr %v0, ptr %s2, ptr %t28, i1 %t32)
  store { i64, ptr } %t35, ptr %l33
  br label %bb9
bb8:
  br label %bb12
bb9:
  %t36 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t37 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertMsgError(ptr %s2, ptr %s2, { i64, ptr } %t36)
  store %"compiler/msgs:Msg" %t37, ptr %l34
  br label %bb10
bb10:
  %t38 = load ptr, ptr %l28, !tbaa !29
  %t39 = load %"compiler/source:Span", ptr %l29
  %t40 = load %"compiler/msgs:Msg", ptr %l34
  %t41 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t38, %"compiler/source:Span" %t39, %"compiler/msgs:Msg" %t40)
  store i64 %t41, ptr %l35
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb12:
  %t42 = load ptr, ptr %l4, !tbaa !29
  %t44 = getelementptr %"compiler/check:frame", ptr %t42, i32 0, i32 30
  %t45 = load i1, ptr %t44, !tbaa !21
  br i1 %t45, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l38, !tbaa !29
  %t48 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t48, ptr %l39
  %t49 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskClauseError(ptr %s3)
  store %"compiler/msgs:Msg" %t49, ptr %l40
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t50 = load ptr, ptr %l38, !tbaa !29
  %t51 = load %"compiler/source:Span", ptr %l39
  %t52 = load %"compiler/msgs:Msg", ptr %l40
  %t53 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t50, %"compiler/source:Span" %t51, %"compiler/msgs:Msg" %t52)
  store i64 %t53, ptr %l41
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %ret
bb17:
  %t54 = load ptr, ptr %l4, !tbaa !29
  %t56 = getelementptr %"compiler/check:frame", ptr %t54, i32 0, i32 12
  %t57 = load i1, ptr %t56, !tbaa !21
  br i1 %t57, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb20
bb19:
  %t59 = load ptr, ptr %l4, !tbaa !29
  %t61 = getelementptr %"compiler/check:frame", ptr %t59, i32 0, i32 24
  %t62 = load i1, ptr %t61, !tbaa !21
  store i1 %t62, ptr %l44, !tbaa !21
  br label %bb20
bb20:
  %t64 = load i1, ptr %l44, !tbaa !21
  br i1 %t64, label %bb21, label %bb22
bb21:
  br label %ret
bb22:
  br label %bb23
bb23:
  %t65 = load i64, ptr %l2, !tbaa !24
  store i64 %t65, ptr %l5, !tbaa !24
  %t67 = load i64, ptr %l2, !tbaa !24
  %t71 = add i64 %t67, %a3
  store i64 %t71, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t73 = load i64, ptr %l6, !tbaa !24
  %t74 = load i64, ptr %l5, !tbaa !24
  %t77 = icmp sgt i64 %t73, %t74
  br i1 %t77, label %bb24, label %bb25
bb24:
  %t79 = load i64, ptr %l7, !tbaa !24
  %t81 = icmp sgt i64 %t79, 0
  br i1 %t81, label %bb26, label %bb27
bb25:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb29
bb26:
  %t83 = load i64, ptr %l6, !tbaa !24
  %t84 = load i64, ptr %l5, !tbaa !24
  %t87 = sub i64 %t83, %t84
  %t88 = load i64, ptr %l7, !tbaa !24
  %t91 = add i64 %t87, %t88
  %t93 = sub i64 %t91, 1
  %t94 = load i64, ptr %l7, !tbaa !24
  %t97 = sdiv i64 %t93, %t94
  store i64 %t97, ptr %l57, !tbaa !24
  br label %bb28
bb27:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb28
bb28:
  %t99 = load i64, ptr %l57, !tbaa !24
  store i64 %t99, ptr %l54, !tbaa !24
  br label %bb29
bb29:
  %t100 = load i64, ptr %l54, !tbaa !24
  store i64 %t100, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb30
bb30:
  %t101 = load i64, ptr %l9, !tbaa !24
  %t102 = load i64, ptr %l8, !tbaa !24
  %t105 = icmp slt i64 %t101, %t102
  %t107 = xor i1 %t105, true
  br i1 %t107, label %bb31, label %bb32
bb31:
  br label %bb62
bb32:
  br label %bb33
bb33:
  %t109 = load i64, ptr %l5, !tbaa !24
  %t110 = load i64, ptr %l9, !tbaa !24
  %t111 = load i64, ptr %l7, !tbaa !24
  %t114 = mul i64 %t110, %t111
  %t117 = add i64 %t109, %t114
  %t119 = load ptr, ptr %l4, !tbaa !29
  %t121 = getelementptr %"compiler/check:frame", ptr %t119, i32 0, i32 26
  %t125 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t121, i64 %t117)
  store i32 %t125, ptr %l78
  br label %bb34
bb34:
  %t126 = load i32, ptr %l78, !tbaa !23
  store i32 %t126, ptr %l11, !tbaa !23
  %t127 = load ptr, ptr %l4, !tbaa !29
  %t129 = getelementptr %"compiler/check:frame", ptr %t127, i32 0, i32 0
  %t130 = load i64, ptr %t129, !tbaa !24
  %t132 = icmp slt i64 %t130, 0
  br i1 %t132, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l82, !tbaa !21
  br label %bb38
bb36:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load ptr, ptr %l4, !tbaa !29
  %t137 = getelementptr %"compiler/check:frame", ptr %t135, i32 0, i32 0
  %t138 = load i64, ptr %t137, !tbaa !24
  %t141 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisGlobalBody(ptr %v0, ptr %t134, i64 %t138)
  store i1 %t141, ptr %l86
  br label %bb37
bb37:
  %t142 = load i1, ptr %l86, !tbaa !21
  store i1 %t142, ptr %l82, !tbaa !21
  br label %bb38
bb38:
  %t143 = load i1, ptr %l82, !tbaa !21
  br i1 %t143, label %bb39, label %bb40
bb39:
  store %olang.scope zeroinitializer, ptr %s7
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l87, !tbaa !29
  %t145 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t145, ptr %l88
  %t146 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTryNowhereToGo(ptr %s7)
  store %"compiler/msgs:Msg" %t146, ptr %l89
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t147 = load ptr, ptr %l87, !tbaa !29
  %t148 = load %"compiler/source:Span", ptr %l88
  %t149 = load %"compiler/msgs:Msg", ptr %l89
  %t150 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t147, %"compiler/source:Span" %t148, %"compiler/msgs:Msg" %t149)
  store i64 %t150, ptr %l90
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s7)
  br label %ret
bb43:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load ptr, ptr %l4, !tbaa !29
  %t154 = getelementptr %"compiler/check:frame", ptr %t152, i32 0, i32 6
  %t155 = load i32, ptr %t154, !tbaa !23
  %t156 = load i32, ptr %l11, !tbaa !23
  %t160 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euncovered(ptr %v0, ptr %t151, i32 %t155, i32 %t156)
  store i32 %t160, ptr %l95
  br label %bb44
bb44:
  %t161 = load i32, ptr %l95, !tbaa !23
  store i32 %t161, ptr %l12, !tbaa !23
  %t162 = load i32, ptr %l12, !tbaa !23
  %t163 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t166 = icmp ne i32 %t162, %t163
  br i1 %t166, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s8
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/check:Checker", ptr %t168, i32 0, i32 5
  %t171 = load i1, ptr %t170, !tbaa !21
  store i1 %t171, ptr %l13, !tbaa !21
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/check:Checker", ptr %t173, i32 0, i32 5
  store i1 true, ptr %t175, !tbaa !21
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load i32, ptr %l12, !tbaa !23
  %t180 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s8, ptr %t176, i32 %t177)
  store { i64, ptr } %t180, ptr %l104
  br label %bb47
bb46:
  br label %bb60
bb47:
  %t181 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t181, ptr %l14, !tbaa !27
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load i1, ptr %l13, !tbaa !21
  %t186 = getelementptr %"compiler/check:Checker", ptr %t182, i32 0, i32 5
  store i1 %t183, ptr %t186, !tbaa !21
  %t187 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t189 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTryErrorNotDeclared(ptr %s8, ptr %s8, { i64, ptr } %t187)
  store %"compiler/msgs:Msg" %t189, ptr %l108
  br label %bb48
bb48:
  %t190 = load %"compiler/msgs:Msg", ptr %l108
  store %"compiler/msgs:Msg" %t190, ptr %l15
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t191)
  store ptr %t193, ptr %l110
  br label %bb49
bb49:
  %t194 = load ptr, ptr %l110, !tbaa !29
  %t196 = getelementptr %"compiler/check:frame", ptr %t194, i32 0, i32 20
  %t197 = load i1, ptr %t196, !tbaa !21
  br i1 %t197, label %bb50, label %bb51
bb50:
  %t199 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t201 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenErrorNotDeclared(ptr %s8, ptr %s8, { i64, ptr } %t199)
  store %"compiler/msgs:Msg" %t201, ptr %l114
  br label %bb52
bb51:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritesNoQuestion(ptr %v0, ptr %t202)
  store i1 %t204, ptr %l116
  br label %bb53
bb52:
  %t205 = load %"compiler/msgs:Msg", ptr %l114
  store %"compiler/msgs:Msg" %t205, ptr %l15
  br label %bb58
bb53:
  %t206 = load i1, ptr %l116, !tbaa !21
  br i1 %t206, label %bb54, label %bb55
bb54:
  %t207 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t209 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTryNeedsQuestion(ptr %s8, ptr %s8, { i64, ptr } %t207)
  store %"compiler/msgs:Msg" %t209, ptr %l118
  br label %bb56
bb55:
  br label %bb57
bb56:
  %t210 = load %"compiler/msgs:Msg", ptr %l118
  store %"compiler/msgs:Msg" %t210, ptr %l15
  br label %bb57
bb57:
  br label %bb58
bb58:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t212 = load %"compiler/source:Span", ptr %l1
  %t213 = load %"compiler/msgs:Msg", ptr %l15
  %t217 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t211, %"compiler/source:Span" %t212, %"compiler/msgs:Msg" %t213)
  store i64 %t217, ptr %l122
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s8)
  br label %ret
bb60:
  br label %bb61
bb61:
  %t218 = load i64, ptr %l9, !tbaa !24
  %t220 = add i64 %t218, 1
  store i64 %t220, ptr %l9, !tbaa !24
  br label %bb30
bb62:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eescapes(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i64
  %l22 = alloca ptr
  %l32 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l38 = alloca i64
  %l42 = alloca i64
  %l45 = alloca i64
  %l63 = alloca ptr
  %l67 = alloca i32
  %l77 = alloca i64
  %l80 = alloca i64
  %l99 = alloca ptr
  %l103 = alloca i32
  %l110 = alloca i64
  %l112 = alloca i64
  %l117 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l22
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l22, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i64, ptr %l2, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eescapeRules(ptr %v0, ptr %t9, %"compiler/source:Span" %a1, i64 %t11, i64 %t12)
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t19 = getelementptr %"compiler/check:frame", ptr %t17, i32 0, i32 15
  %t20 = load i64, ptr %t19, !tbaa !24
  %t22 = icmp eq i64 %t20, 0
  br i1 %t22, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  br label %bb8
bb8:
  %t24 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l32
  br label %bb9
bb9:
  %t25 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l32
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l5
  %t26 = load i64, ptr %l2, !tbaa !24
  %t27 = load i64, ptr %l3, !tbaa !24
  %t30 = add i64 %t26, %t27
  store i64 %t30, ptr %l6, !tbaa !24
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = getelementptr %"compiler/check:frame", ptr %t32, i32 0, i32 26
  %t36 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t34)
  store i64 %t36, ptr %l38
  br label %bb10
bb10:
  %t37 = load i64, ptr %l38, !tbaa !24
  store i64 %t37, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t38 = load i64, ptr %l7, !tbaa !24
  %t39 = load i64, ptr %l6, !tbaa !24
  %t42 = icmp sgt i64 %t38, %t39
  br i1 %t42, label %bb11, label %bb12
bb11:
  %t44 = load i64, ptr %l8, !tbaa !24
  %t46 = icmp sgt i64 %t44, 0
  br i1 %t46, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb16
bb13:
  %t48 = load i64, ptr %l7, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = sub i64 %t48, %t49
  %t53 = load i64, ptr %l8, !tbaa !24
  %t56 = add i64 %t52, %t53
  %t58 = sub i64 %t56, 1
  %t59 = load i64, ptr %l8, !tbaa !24
  %t62 = sdiv i64 %t58, %t59
  store i64 %t62, ptr %l45, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb15
bb15:
  %t64 = load i64, ptr %l45, !tbaa !24
  store i64 %t64, ptr %l42, !tbaa !24
  br label %bb16
bb16:
  %t65 = load i64, ptr %l42, !tbaa !24
  store i64 %t65, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb17
bb17:
  %t66 = load i64, ptr %l10, !tbaa !24
  %t67 = load i64, ptr %l9, !tbaa !24
  %t70 = icmp slt i64 %t66, %t67
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb18, label %bb19
bb18:
  br label %bb24
bb19:
  br label %bb20
bb20:
  %t74 = load i64, ptr %l6, !tbaa !24
  %t75 = load i64, ptr %l10, !tbaa !24
  %t76 = load i64, ptr %l8, !tbaa !24
  %t79 = mul i64 %t75, %t76
  %t82 = add i64 %t74, %t79
  store ptr %l5, ptr %l63, !tbaa !29
  %t84 = load ptr, ptr %l4, !tbaa !29
  %t86 = getelementptr %"compiler/check:frame", ptr %t84, i32 0, i32 26
  %t90 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t86, i64 %t82)
  store i32 %t90, ptr %l67
  br label %bb21
bb21:
  %t91 = load ptr, ptr %l63, !tbaa !29
  %t92 = load i32, ptr %l67, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t91, i32 %t92)
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t93 = load i64, ptr %l10, !tbaa !24
  %t95 = add i64 %t93, 1
  store i64 %t95, ptr %l10, !tbaa !24
  br label %bb17
bb24:
  %t97 = load i64, ptr %l2, !tbaa !24
  store i64 %t97, ptr %l12, !tbaa !24
  %t99 = load i64, ptr %l2, !tbaa !24
  %t100 = load i64, ptr %l3, !tbaa !24
  %t103 = add i64 %t99, %t100
  store i64 %t103, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t105 = load i64, ptr %l13, !tbaa !24
  %t106 = load i64, ptr %l12, !tbaa !24
  %t109 = icmp sgt i64 %t105, %t106
  br i1 %t109, label %bb25, label %bb26
bb25:
  %t111 = load i64, ptr %l14, !tbaa !24
  %t113 = icmp sgt i64 %t111, 0
  br i1 %t113, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l77, !tbaa !24
  br label %bb30
bb27:
  %t115 = load i64, ptr %l13, !tbaa !24
  %t116 = load i64, ptr %l12, !tbaa !24
  %t119 = sub i64 %t115, %t116
  %t120 = load i64, ptr %l14, !tbaa !24
  %t123 = add i64 %t119, %t120
  %t125 = sub i64 %t123, 1
  %t126 = load i64, ptr %l14, !tbaa !24
  %t129 = sdiv i64 %t125, %t126
  store i64 %t129, ptr %l80, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l80, !tbaa !24
  br label %bb29
bb29:
  %t131 = load i64, ptr %l80, !tbaa !24
  store i64 %t131, ptr %l77, !tbaa !24
  br label %bb30
bb30:
  %t132 = load i64, ptr %l77, !tbaa !24
  store i64 %t132, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb31
bb31:
  %t133 = load i64, ptr %l16, !tbaa !24
  %t134 = load i64, ptr %l15, !tbaa !24
  %t137 = icmp slt i64 %t133, %t134
  %t139 = xor i1 %t137, true
  br i1 %t139, label %bb32, label %bb33
bb32:
  br label %bb38
bb33:
  br label %bb34
bb34:
  %t141 = load i64, ptr %l12, !tbaa !24
  %t142 = load i64, ptr %l16, !tbaa !24
  %t143 = load i64, ptr %l14, !tbaa !24
  %t146 = mul i64 %t142, %t143
  %t149 = add i64 %t141, %t146
  %t151 = load ptr, ptr %l4, !tbaa !29
  %t153 = getelementptr %"compiler/check:frame", ptr %t151, i32 0, i32 27
  store ptr %t153, ptr %l99, !tbaa !29
  %t154 = load ptr, ptr %l4, !tbaa !29
  %t156 = getelementptr %"compiler/check:frame", ptr %t154, i32 0, i32 26
  %t160 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t156, i64 %t149)
  store i32 %t160, ptr %l103
  br label %bb35
bb35:
  %t161 = load ptr, ptr %l99, !tbaa !29
  %t162 = load i32, ptr %l103, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t161, i32 %t162)
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t163 = load i64, ptr %l16, !tbaa !24
  %t165 = add i64 %t163, 1
  store i64 %t165, ptr %l16, !tbaa !24
  br label %bb31
bb38:
  %t167 = load ptr, ptr %l4, !tbaa !29
  %t169 = getelementptr %"compiler/check:frame", ptr %t167, i32 0, i32 26
  %t170 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t169, i64 %t170)
  br label %bb39
bb39:
  store ptr %l5, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb40
bb40:
  %t174 = load i64, ptr %l19, !tbaa !24
  store i64 %t174, ptr %l110, !tbaa !24
  %t175 = load ptr, ptr %l18, !tbaa !29
  %t177 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t175)
  store i64 %t177, ptr %l112
  br label %bb41
bb41:
  %t178 = load i64, ptr %l110, !tbaa !24
  %t179 = load i64, ptr %l112, !tbaa !24
  %t180 = icmp slt i64 %t178, %t179
  %t182 = xor i1 %t180, true
  br i1 %t182, label %bb42, label %bb43
bb42:
  br label %bb48
bb43:
  br label %bb44
bb44:
  %t184 = load ptr, ptr %l18, !tbaa !29
  %t185 = load i64, ptr %l19, !tbaa !24
  %t188 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t184, i64 %t185)
  store i32 %t188, ptr %l117
  br label %bb45
bb45:
  %t189 = load i32, ptr %l117, !tbaa !23
  %t190 = load ptr, ptr %l4, !tbaa !29
  %t192 = getelementptr %"compiler/check:frame", ptr %t190, i32 0, i32 26
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t192, i32 %t189)
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t196 = load i64, ptr %l19, !tbaa !24
  %t198 = add i64 %t196, 1
  store i64 %t198, ptr %l19, !tbaa !24
  br label %bb40
bb48:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprPattern(ptr %v0, ptr %v1, ptr %a0, ptr %a1, ptr %a2, i32 %a3, ptr %a4, i64 %a5, i1 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l7 = alloca i32
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca i32
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %lp19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %lp26 = alloca ptr
  %l27 = alloca i32
  %l30 = alloca i32
  %l32 = alloca %"compiler/source:Span"
  %l33 = alloca ptr
  %l34 = alloca i1
  %l45 = alloca { i64, ptr }
  %l46 = alloca i1
  %l50 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca ptr
  %l62 = alloca i1
  %l68 = alloca i64
  %l75 = alloca ptr
  %l76 = alloca ptr
  %l77 = alloca i1
  %l87 = alloca i64
  %l94 = alloca ptr
  %l97 = alloca ptr
  %l100 = alloca ptr
  %l105 = alloca i32
  %l106 = alloca i32
  %l107 = alloca { i64, ptr }
  %l113 = alloca ptr
  %l114 = alloca %"compiler/source:Span"
  %l116 = alloca i64
  %l120 = alloca { i64, ptr }
  %l123 = alloca %"compiler/msgs:Msg"
  %l124 = alloca i64
  %l128 = alloca ptr
  %l132 = alloca i1
  %l133 = alloca %"compiler/source:Span"
  %l134 = alloca i32
  %l138 = alloca ptr
  %l143 = alloca ptr
  %l148 = alloca i32
  %l149 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l153 = alloca %"compiler/source:Span"
  %l154 = alloca i32
  %l158 = alloca %"compiler/typed:Payload"
  %l166 = alloca i64
  %l169 = alloca i64
  %l187 = alloca { i64, ptr }
  %l190 = alloca %"compiler/source:Span"
  %l191 = alloca { i64, ptr }
  %l197 = alloca ptr
  %l198 = alloca %"compiler/source:Span"
  %l199 = alloca ptr
  %l201 = alloca { i64, ptr }
  %l205 = alloca { i64, ptr }
  %l210 = alloca ptr
  %l211 = alloca ptr
  %l217 = alloca i1
  %l220 = alloca i32
  %l223 = alloca ptr
  %l225 = alloca %"compiler/source:Span"
  %l226 = alloca ptr
  %l229 = alloca i32
  %l230 = alloca { i64, ptr }
  %l231 = alloca { i64, ptr }
  %l234 = alloca { i64, ptr }
  %l236 = alloca %"compiler/msgs:Msg"
  %l237 = alloca i64
  %l241 = alloca ptr
  %l247 = alloca ptr
  %s2 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca ptr
  %t55 = alloca { i64, [4 x i64] }, align 8
  %t237 = alloca { i64, [4 x i64] }, align 8
  %t287 = alloca { i64, [4 x i64] }, align 8
  %t368 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l3, !tbaa !23
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l30
  br label %bb1
bb1:
  %t6 = load i32, ptr %l30, !tbaa !23
  store i32 %t6, ptr %l7, !tbaa !23
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t7)
  store %"compiler/source:Span" %t9, ptr %l32
  br label %bb2
bb2:
  %t10 = load %"compiler/source:Span", ptr %l32
  store %"compiler/source:Span" %t10, ptr %l8
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t12 = load ptr, ptr %l33, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l33, !tbaa !29
  %t16 = load i64, ptr %t15, !range !{i64 0, i64 29}
  %t18 = icmp eq i64 %t16, 0
  store i1 %t18, ptr %l34, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l34, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [5 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32 }, ptr %t22, i32 0, i32 0
  %t24 = load %"compiler/source:Span", ptr %t23
  store %"compiler/source:Span" %t24, ptr %l9
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr { i64, [5 x i64] }, ptr %t26, i32 0, i32 1
  %t29 = getelementptr { %"compiler/source:Span", i32 }, ptr %t28, i32 0, i32 1
  %t30 = load i32, ptr %t29
  store i32 %t30, ptr %l10, !tbaa !23
  br label %bb7
bb6:
  br label %bb18
bb7:
  %t34 = xor i1 %a6, true
  br i1 %t34, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l10, !tbaa !23
  %t40 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t36, i32 %t37)
  store { i64, ptr } %t40, ptr %l45
  br label %bb10
bb9:
  br label %bb17
bb10:
  %t41 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t42 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t41, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i1 %t42, ptr %l46
  br label %bb11
bb11:
  %t43 = load i1, ptr %l46, !tbaa !21
  br i1 %t43, label %bb12, label %bb13
bb12:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load %"compiler/source:Span", ptr %l9
  %t46 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t50 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t44, %"compiler/source:Span" %t45, i32 %t46, i64 1)
  store ptr %t50, ptr %l50
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  %t51 = load ptr, ptr %l50, !tbaa !29
  store ptr %t51, ptr %rv
  br label %ret
bb15:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load %"compiler/source:Span", ptr %l9
  %t54 = load i32, ptr %l10, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t55
  %t56 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 0
  store i64 3, ptr %t56
  %t58 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t53, 0
  %t60 = insertvalue { %"compiler/source:Span", i32 } %t58, i32 %t54, 1
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t60, ptr %t61
  %t62 = load { i64, [4 x i64] }, ptr %t55
  %t64 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t62, ptr %t64
  %t65 = load ptr, ptr %l2, !tbaa !29
  %t66 = load i32, ptr %l3, !tbaa !23
  %t67 = load ptr, ptr %l4, !tbaa !29
  %t68 = load i64, ptr %l5, !tbaa !24
  %t75 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epattern(ptr %v0, ptr %v0, ptr %t52, ptr %t64, ptr %t65, i32 %t66, ptr %t67, i64 %t68)
  store ptr %t75, ptr %l60
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  %t76 = load ptr, ptr %l60, !tbaa !29
  store ptr %t76, ptr %rv
  br label %ret
bb17:
  br label %bb95
bb18:
  %t77 = load ptr, ptr %l1, !tbaa !29
  store ptr %t77, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t78 = load ptr, ptr %l61, !tbaa !29
  %t79 = icmp ne ptr %t78, null
  br i1 %t79, label %bb19, label %bb20
bb19:
  %t81 = load ptr, ptr %l61, !tbaa !29
  %t82 = load i64, ptr %t81, !range !{i64 0, i64 29}
  %t84 = icmp eq i64 %t82, 15
  store i1 %t84, ptr %l62, !tbaa !21
  br label %bb20
bb20:
  %t85 = load i1, ptr %l62, !tbaa !21
  br i1 %t85, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb29
bb23:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t88 = load i32, ptr %l7, !tbaa !23
  %t92 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %t86, ptr %t87, i32 %t88)
  store i64 %t92, ptr %l68
  br label %bb24
bb24:
  %t93 = load i64, ptr %l68, !tbaa !24
  store i64 %t93, ptr %l11, !tbaa !24
  %t94 = load i64, ptr %l11, !tbaa !24
  %t96 = icmp sge i64 %t94, 0
  br i1 %t96, label %bb25, label %bb26
bb25:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load %"compiler/source:Span", ptr %l8
  %t100 = load ptr, ptr %l2, !tbaa !29
  %t101 = load i64, ptr %l11, !tbaa !24
  %t106 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCase(ptr %v0, ptr %t98, %"compiler/source:Span" %t99, ptr %t100, i64 %t101)
  store ptr %t106, ptr %l75
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t107 = load ptr, ptr %l75, !tbaa !29
  store ptr %t107, ptr %rv
  br label %ret
bb28:
  br label %bb95
bb29:
  %t108 = load ptr, ptr %l1, !tbaa !29
  store ptr %t108, ptr %l76, !tbaa !29
  store i1 false, ptr %l77, !tbaa !21
  %t109 = load ptr, ptr %l76, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb30, label %bb31
bb30:
  %t112 = load ptr, ptr %l76, !tbaa !29
  %t113 = load i64, ptr %t112, !range !{i64 0, i64 29}
  %t115 = icmp eq i64 %t113, 12
  store i1 %t115, ptr %l77, !tbaa !21
  br label %bb31
bb31:
  %t116 = load i1, ptr %l77, !tbaa !21
  br i1 %t116, label %bb32, label %bb33
bb32:
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr { i64, [5 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t119, i32 0, i32 1
  %t121 = load ptr, ptr %t120
  store ptr %t121, ptr %l12, !tbaa !29
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr { i64, [5 x i64] }, ptr %t123, i32 0, i32 1
  %t126 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t125, i32 0, i32 2
  %t127 = load { i64, ptr }, ptr %t126
  store { i64, ptr } %t127, ptr %l13, !tbaa !27
  br label %bb34
bb33:
  br label %bb90
bb34:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load ptr, ptr %l12, !tbaa !29
  %t131 = load i32, ptr %l7, !tbaa !23
  %t135 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %t129, ptr %t130, i32 %t131)
  store i64 %t135, ptr %l87
  br label %bb35
bb35:
  %t136 = load i64, ptr %l87, !tbaa !24
  store i64 %t136, ptr %l14, !tbaa !24
  %t137 = load i64, ptr %l14, !tbaa !24
  %t139 = icmp sge i64 %t137, 0
  br i1 %t139, label %bb36, label %bb37
bb36:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load %"compiler/source:Span", ptr %l8
  %t143 = load ptr, ptr %l2, !tbaa !29
  %t144 = load i64, ptr %l14, !tbaa !24
  %t149 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCase(ptr %v0, ptr %t141, %"compiler/source:Span" %t142, ptr %t143, i64 %t144)
  store ptr %t149, ptr %l94
  br label %bb38
bb37:
  br label %bb74
bb38:
  %t150 = load ptr, ptr %l94, !tbaa !29
  store ptr %t150, ptr %l15, !tbaa !29
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/check:Checker", ptr %t151, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t156 = getelementptr %"compiler/generic:Program", ptr %t154, i32 0, i32 2
  store ptr %t156, ptr %l97, !tbaa !29
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/check:Checker", ptr %t157, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t162 = getelementptr %"compiler/generic:Program", ptr %t160, i32 0, i32 2
  store ptr %t162, ptr %l100, !tbaa !29
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/check:Checker", ptr %t163, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !29
  %t167 = load i32, ptr %l7, !tbaa !23
  %t168 = load i64, ptr %l14, !tbaa !24
  %t172 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %t166, i32 %t167, i64 %t168)
  store i32 %t172, ptr %l105
  br label %bb39
bb39:
  %t173 = load ptr, ptr %l100, !tbaa !29
  %t174 = load i32, ptr %l105, !tbaa !23
  %t175 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t173, i32 %t174)
  store i32 %t175, ptr %l106
  br label %bb40
bb40:
  %t176 = load ptr, ptr %l97, !tbaa !29
  %t177 = load i32, ptr %l106, !tbaa !23
  %t178 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t176, i32 %t177)
  store { i64, ptr } %t178, ptr %l107
  br label %bb41
bb41:
  %t179 = load { i64, ptr }, ptr %l107, !tbaa !27
  store { i64, ptr } %t179, ptr %l16, !tbaa !27
  %t180 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t180, 0
  %t183 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t183, 0
  %t188 = icmp ne i64 %t182, %t185
  br i1 %t188, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s8
  %t190 = load ptr, ptr %l0, !tbaa !29
  store ptr %t190, ptr %l113, !tbaa !29
  %t191 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t191, ptr %l114
  %t192 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t194 = extractvalue { i64, ptr } %t192, 0
  store i64 %t194, ptr %l116, !tbaa !24
  %t195 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t197 = extractvalue { i64, ptr } %t195, 0
  %t199 = icmp eq i64 %t197, 1
  br i1 %t199, label %bb44, label %bb45
bb43:
  br label %bb50
bb44:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr %l120, !tbaa !27
  br label %bb46
bb45:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, ptr %l120, !tbaa !27
  br label %bb46
bb46:
  %t201 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t203 = extractvalue { i64, ptr } %t201, 0
  %t204 = load i64, ptr %l116, !tbaa !24
  %t205 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t207 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %s8, ptr %s8, i64 %t204, { i64, ptr } %t205, i64 %t203)
  store %"compiler/msgs:Msg" %t207, ptr %l123
  br label %bb47
bb47:
  %t208 = load ptr, ptr %l113, !tbaa !29
  %t209 = load %"compiler/source:Span", ptr %l114
  %t210 = load %"compiler/msgs:Msg", ptr %l123
  %t211 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t208, %"compiler/source:Span" %t209, %"compiler/msgs:Msg" %t210)
  store i64 %t211, ptr %l124
  br label %bb48
bb48:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load %"compiler/source:Span", ptr %l8
  %t214 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t218 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t212, %"compiler/source:Span" %t213, i32 %t214, i64 0)
  store ptr %t218, ptr %l128
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s8)
  %t219 = load ptr, ptr %l128, !tbaa !29
  store ptr %t219, ptr %rv
  br label %ret
bb50:
  %t220 = load ptr, ptr %l2, !tbaa !29
  store ptr %t220, ptr %l17, !tbaa !29
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t223 = load i32, ptr %l3, !tbaa !23
  %t226 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t222, i32 %t223)
  store i1 %t226, ptr %l132
  br label %bb51
bb51:
  %t227 = load i1, ptr %l132, !tbaa !21
  br i1 %t227, label %bb52, label %bb53
bb52:
  %t228 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t228, ptr %l133
  %t229 = load i32, ptr %l7, !tbaa !23
  store i32 %t229, ptr %l134, !tbaa !23
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load %"compiler/source:Span", ptr %l8
  %t232 = load ptr, ptr %l2, !tbaa !29
  %t236 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t230, %"compiler/source:Span" %t231, ptr %t232)
  store ptr %t236, ptr %l138
  br label %bb54
bb53:
  br label %bb55
bb54:
  store { i64, [4 x i64] } zeroinitializer, ptr %t237
  %t238 = getelementptr { i64, [4 x i64] }, ptr %t237, i32 0, i32 0
  store i64 2, ptr %t238
  %t239 = load %"compiler/source:Span", ptr %l133
  %t240 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t239, 0
  %t241 = load i32, ptr %l134, !tbaa !23
  %t242 = insertvalue { %"compiler/source:Span", i32, ptr } %t240, i32 %t241, 1
  %t243 = load ptr, ptr %l138, !tbaa !29
  %t244 = insertvalue { %"compiler/source:Span", i32, ptr } %t242, ptr %t243, 2
  %t245 = getelementptr { i64, [4 x i64] }, ptr %t237, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t244, ptr %t245
  %t246 = load { i64, [4 x i64] }, ptr %t237
  %t248 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t246, ptr %t248
  store ptr %t248, ptr %l17, !tbaa !29
  br label %bb55
bb55:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t252 = getelementptr %"compiler/check:Checker", ptr %t250, i32 0, i32 1
  %t253 = load ptr, ptr %t252, !tbaa !29
  %t255 = getelementptr %"compiler/generic:Program", ptr %t253, i32 0, i32 2
  store ptr %t255, ptr %l143, !tbaa !29
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr %"compiler/check:Checker", ptr %t256, i32 0, i32 1
  %t259 = load ptr, ptr %t258, !tbaa !29
  %t261 = getelementptr %"compiler/generic:Program", ptr %t259, i32 0, i32 2
  %t262 = load i32, ptr %l7, !tbaa !23
  %t265 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t261, i32 %t262)
  store i32 %t265, ptr %l148
  br label %bb56
bb56:
  %t266 = load ptr, ptr %l143, !tbaa !29
  %t267 = load i32, ptr %l148, !tbaa !23
  %t268 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t266, i32 %t267)
  store { i64, ptr } %t268, ptr %l149
  br label %bb57
bb57:
  %t269 = load { i64, ptr }, ptr %l149, !tbaa !27
  store { i64, ptr } %t269, ptr %l150, !tbaa !27
  %t270 = load i64, ptr %l14, !tbaa !24
  %t272 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !27
  %t274 = getelementptr i32, ptr %t273, i64 %t270
  %t275 = load i32, ptr %t274, !tbaa !33
  %t277 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t277, ptr %l153
  store i32 %t275, ptr %l154, !tbaa !23
  %t279 = load ptr, ptr %l17, !tbaa !29
  %t280 = load i64, ptr %l14, !tbaa !24
  %t284 = call %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v0, ptr %t279, i64 %t280, i32 0)
  store %"compiler/typed:Payload" %t284, ptr %l158
  br label %bb58
bb58:
  %t285 = load %"compiler/typed:Payload", ptr %l158
  %t286 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Payload" %t285, ptr %t286
  store { i64, [4 x i64] } zeroinitializer, ptr %t287
  %t288 = getelementptr { i64, [4 x i64] }, ptr %t287, i32 0, i32 0
  store i64 5, ptr %t288
  %t289 = load %"compiler/source:Span", ptr %l153
  %t290 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t289, 0
  %t291 = load i32, ptr %l154, !tbaa !23
  %t292 = insertvalue { %"compiler/source:Span", i32, ptr } %t290, i32 %t291, 1
  %t294 = insertvalue { %"compiler/source:Span", i32, ptr } %t292, ptr %t286, 2
  %t295 = getelementptr { i64, [4 x i64] }, ptr %t287, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t294, ptr %t295
  %t296 = load { i64, [4 x i64] }, ptr %t287
  %t297 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store ptr %t297, ptr %lp19
  %t299 = load ptr, ptr %lp19
  store { i64, [4 x i64] } %t296, ptr %t299
  store i64 0, ptr %l20, !tbaa !24
  %t300 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t302 = extractvalue { i64, ptr } %t300, 0
  store i64 %t302, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t304 = load i64, ptr %l21, !tbaa !24
  %t305 = load i64, ptr %l20, !tbaa !24
  %t308 = icmp sgt i64 %t304, %t305
  br i1 %t308, label %bb59, label %bb60
bb59:
  %t310 = load i64, ptr %l22, !tbaa !24
  %t312 = icmp sgt i64 %t310, 0
  br i1 %t312, label %bb61, label %bb62
bb60:
  store i64 0, ptr %l166, !tbaa !24
  br label %bb64
bb61:
  %t314 = load i64, ptr %l21, !tbaa !24
  %t315 = load i64, ptr %l20, !tbaa !24
  %t318 = sub i64 %t314, %t315
  %t319 = load i64, ptr %l22, !tbaa !24
  %t322 = add i64 %t318, %t319
  %t324 = sub i64 %t322, 1
  %t325 = load i64, ptr %l22, !tbaa !24
  %t328 = sdiv i64 %t324, %t325
  store i64 %t328, ptr %l169, !tbaa !24
  br label %bb63
bb62:
  store i64 0, ptr %l169, !tbaa !24
  br label %bb63
bb63:
  %t330 = load i64, ptr %l169, !tbaa !24
  store i64 %t330, ptr %l166, !tbaa !24
  br label %bb64
bb64:
  %t331 = load i64, ptr %l166, !tbaa !24
  store i64 %t331, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb65
bb65:
  %t332 = load i64, ptr %l24, !tbaa !24
  %t333 = load i64, ptr %l23, !tbaa !24
  %t336 = icmp slt i64 %t332, %t333
  %t338 = xor i1 %t336, true
  br i1 %t338, label %bb66, label %bb67
bb66:
  br label %bb73
bb67:
  br label %bb68
bb68:
  %t340 = load i64, ptr %l20, !tbaa !24
  %t341 = load i64, ptr %l24, !tbaa !24
  %t342 = load i64, ptr %l22, !tbaa !24
  %t345 = mul i64 %t341, %t342
  %t348 = add i64 %t340, %t345
  store i64 %t348, ptr %l25, !tbaa !24
  %t350 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t350, ptr %l187, !tbaa !27
  %t351 = load i64, ptr %l25, !tbaa !24
  %t353 = getelementptr { i64, ptr }, ptr %l187, i32 0, i32 1
  %t354 = load ptr, ptr %t353, !tbaa !27
  %t355 = getelementptr ptr, ptr %t354, i64 %t351
  %t356 = load ptr, ptr %t355, !tbaa !39
  %t358 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t356)
  store %"compiler/source:Span" %t358, ptr %l190
  br label %bb69
bb69:
  %t359 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t359, ptr %l191, !tbaa !27
  %t360 = load i64, ptr %l25, !tbaa !24
  %t362 = getelementptr { i64, ptr }, ptr %l191, i32 0, i32 1
  %t363 = load ptr, ptr %t362, !tbaa !27
  %t364 = getelementptr i32, ptr %t363, i64 %t360
  %t365 = load i32, ptr %t364, !tbaa !33
  %t366 = load ptr, ptr %lp19
  %t367 = load i64, ptr %l25, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t368
  %t369 = getelementptr { i64, [4 x i64] }, ptr %t368, i32 0, i32 0
  store i64 3, ptr %t369
  %t370 = load %"compiler/source:Span", ptr %l190
  %t371 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t370, 0
  %t373 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t371, i32 %t365, 1
  %t375 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t373, ptr %t366, 2
  %t377 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t375, i64 %t367, 3
  %t378 = getelementptr { i64, [4 x i64] }, ptr %t368, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t377, ptr %t378
  %t379 = load { i64, [4 x i64] }, ptr %t368
  %t380 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store ptr %t380, ptr %lp26
  %t382 = load ptr, ptr %lp26
  store { i64, [4 x i64] } %t379, ptr %t382
  %t383 = load ptr, ptr %l0, !tbaa !29
  store ptr %t383, ptr %l197, !tbaa !29
  %t384 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t384, ptr %l198
  %t385 = load ptr, ptr %l15, !tbaa !29
  store ptr %t385, ptr %l199, !tbaa !29
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t387 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t387, ptr %l201, !tbaa !27
  %t388 = load i64, ptr %l25, !tbaa !24
  %t390 = getelementptr { i64, ptr }, ptr %l201, i32 0, i32 1
  %t391 = load ptr, ptr %t390, !tbaa !27
  %t392 = getelementptr ptr, ptr %t391, i64 %t388
  %t393 = load ptr, ptr %t392, !tbaa !39
  %t394 = load ptr, ptr %lp26
  %t395 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t395, ptr %l205, !tbaa !27
  %t396 = load i64, ptr %l25, !tbaa !24
  %t398 = getelementptr { i64, ptr }, ptr %l205, i32 0, i32 1
  %t399 = load ptr, ptr %t398, !tbaa !27
  %t400 = getelementptr i32, ptr %t399, i64 %t396
  %t401 = load i32, ptr %t400, !tbaa !33
  %t402 = load ptr, ptr %l4, !tbaa !29
  %t403 = load i64, ptr %l5, !tbaa !24
  %t410 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprPattern(ptr %v0, ptr %v1, ptr %t386, ptr %t393, ptr %t394, i32 %t401, ptr %t402, i64 %t403, i1 false)
  store ptr %t410, ptr %l210
  br label %bb70
bb70:
  %t411 = load ptr, ptr %l197, !tbaa !29
  %t412 = load %"compiler/source:Span", ptr %l198
  %t413 = load ptr, ptr %l199, !tbaa !29
  %t414 = load ptr, ptr %l210, !tbaa !29
  %t415 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eand2(ptr %v0, ptr %t411, %"compiler/source:Span" %t412, ptr %t413, ptr %t414)
  store ptr %t415, ptr %l211
  br label %bb71
bb71:
  %t416 = load ptr, ptr %l211, !tbaa !29
  store ptr %t416, ptr %l15, !tbaa !29
  br label %bb72
bb72:
  %t417 = load i64, ptr %l24, !tbaa !24
  %t419 = add i64 %t417, 1
  store i64 %t419, ptr %l24, !tbaa !24
  br label %bb65
bb73:
  %t421 = load ptr, ptr %l15, !tbaa !29
  store ptr %t421, ptr %rv
  br label %ret
bb74:
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t424 = load ptr, ptr %l12, !tbaa !29
  %t427 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseWritten(ptr %v0, ptr %v1, ptr %t423, ptr %t424)
  store i1 %t427, ptr %l217
  br label %bb75
bb75:
  %t428 = load i1, ptr %l217, !tbaa !21
  br i1 %t428, label %bb76, label %bb77
bb76:
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t430 = load ptr, ptr %l12, !tbaa !29
  %t433 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenEnum(ptr %v0, ptr %v1, ptr %t429, ptr %t430)
  store i32 %t433, ptr %l220
  br label %bb78
bb77:
  br label %bb89
bb78:
  %t434 = load i32, ptr %l220, !tbaa !23
  store i32 %t434, ptr %l27, !tbaa !23
  %t435 = load i32, ptr %l27, !tbaa !23
  %t437 = icmp sge i32 %t435, 0
  br i1 %t437, label %bb79, label %bb80
bb79:
  store %olang.scope zeroinitializer, ptr %s14
  %t439 = load ptr, ptr %l0, !tbaa !29
  store ptr %t439, ptr %l223, !tbaa !29
  %t440 = load ptr, ptr %l1, !tbaa !29
  %t442 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t440)
  store %"compiler/source:Span" %t442, ptr %l225
  br label %bb81
bb80:
  br label %bb88
bb81:
  %t443 = load ptr, ptr %l0, !tbaa !29
  store ptr %t443, ptr %l226, !tbaa !29
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t445 = load i32, ptr %l3, !tbaa !23
  %t448 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t444, i32 %t445)
  store i32 %t448, ptr %l229
  br label %bb82
bb82:
  %t449 = load ptr, ptr %l226, !tbaa !29
  %t450 = load i32, ptr %l229, !tbaa !23
  %t451 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s14, ptr %t449, i32 %t450)
  store { i64, ptr } %t451, ptr %l230
  br label %bb83
bb83:
  %t452 = load { i64, ptr }, ptr %l230, !tbaa !27
  %t453 = extractvalue { i64, ptr } %t452, 0
  %t454 = extractvalue { i64, ptr } %t452, 1
  %t455 = mul i64 %t453, 1
  %t456 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t455)
  call void @llvm.memcpy.p0.p0.i64(ptr %t456, ptr %t454, i64 %t455, i1 false)
  %t457 = insertvalue { i64, ptr } undef, i64 %t453, 0
  %t458 = insertvalue { i64, ptr } %t457, ptr %t456, 1
  store { i64, ptr } %t458, ptr %l231, !tbaa !27
  %t459 = load ptr, ptr %l0, !tbaa !29
  %t460 = load i32, ptr %l27, !tbaa !23
  %t463 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s14, ptr %t459, i32 %t460)
  store { i64, ptr } %t463, ptr %l234
  br label %bb84
bb84:
  %t464 = load { i64, ptr }, ptr %l234, !tbaa !27
  %t465 = extractvalue { i64, ptr } %t464, 0
  %t466 = extractvalue { i64, ptr } %t464, 1
  %t467 = mul i64 %t465, 1
  %t468 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t467)
  call void @llvm.memcpy.p0.p0.i64(ptr %t468, ptr %t466, i64 %t467, i1 false)
  %t469 = insertvalue { i64, ptr } undef, i64 %t465, 0
  %t470 = insertvalue { i64, ptr } %t469, ptr %t468, 1
  %t471 = load { i64, ptr }, ptr %l231, !tbaa !27
  %t473 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseValueType(ptr %s14, ptr %s14, ptr %s14, { i64, ptr } %t471, { i64, ptr } %t470)
  store %"compiler/msgs:Msg" %t473, ptr %l236
  br label %bb85
bb85:
  %t474 = load ptr, ptr %l223, !tbaa !29
  %t475 = load %"compiler/source:Span", ptr %l225
  %t476 = load %"compiler/msgs:Msg", ptr %l236
  %t477 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s14, ptr %t474, %"compiler/source:Span" %t475, %"compiler/msgs:Msg" %t476)
  store i64 %t477, ptr %l237
  br label %bb86
bb86:
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t479 = load %"compiler/source:Span", ptr %l8
  %t480 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t484 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t478, %"compiler/source:Span" %t479, i32 %t480, i64 0)
  store ptr %t484, ptr %l241
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s14)
  %t485 = load ptr, ptr %l241, !tbaa !29
  store ptr %t485, ptr %rv
  br label %ret
bb88:
  br label %bb89
bb89:
  br label %bb95
bb90:
  br i1 true, label %bb91, label %bb92
bb91:
  br label %bb93
bb92:
  br label %bb94
bb93:
  br label %bb95
bb94:
  call void @__olang_check_failed(ptr @olang_loc_d21fae414ff68ab0_be44aac3c4a6c53c)
  unreachable
bb95:
  %t486 = load ptr, ptr %l0, !tbaa !29
  %t487 = load %"compiler/source:Span", ptr %l8
  %t488 = load ptr, ptr %l2, !tbaa !29
  %t489 = load ptr, ptr %l1, !tbaa !29
  %t490 = load i32, ptr %l3, !tbaa !23
  %t496 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTest(ptr %v0, ptr %v1, ptr %t486, %"compiler/source:Span" %t487, ptr %t488, ptr %t489, i32 %t490)
  store ptr %t496, ptr %l247
  br label %bb96
bb96:
  %t497 = load ptr, ptr %l247, !tbaa !29
  store ptr %t497, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldIndex(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l17 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca ptr
  %l26 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l52 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca i1
  %l71 = alloca { i64, ptr }
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l17, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/generic:Program", ptr %t8, i32 0, i32 2
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t10, i32 %a1)
  store i32 %t14, ptr %l22
  br label %bb1
bb1:
  %t15 = load ptr, ptr %l17, !tbaa !29
  %t16 = load i32, ptr %l22, !tbaa !23
  %t17 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t15, i32 %t16)
  store ptr %t17, ptr %l23
  br label %bb2
bb2:
  %t18 = load ptr, ptr %l23, !tbaa !29
  store ptr %t18, ptr %l3, !tbaa !29
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t21 = icmp eq ptr %t19, null
  br i1 %t21, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb5
bb4:
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t25 = getelementptr %"compiler/ast:TypeDecl", ptr %t23, i32 0, i32 3
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = icmp eq ptr %t26, null
  store i1 %t28, ptr %l26, !tbaa !21
  br label %bb5
bb5:
  %t30 = load i1, ptr %l26, !tbaa !21
  br i1 %t30, label %bb6, label %bb7
bb6:
  store i64 -1, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t32 = load ptr, ptr %l3, !tbaa !29
  %t34 = getelementptr %"compiler/ast:TypeDecl", ptr %t32, i32 0, i32 3
  %t35 = load ptr, ptr %t34, !tbaa !29
  store ptr %t35, ptr %l4, !tbaa !29
  %t37 = load ptr, ptr %l4, !tbaa !29
  store ptr %t37, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t38 = load ptr, ptr %l33, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb9, label %bb10
bb9:
  %t41 = load ptr, ptr %l33, !tbaa !29
  %t42 = load i64, ptr %t41, !range !{i64 0, i64 5}
  %t44 = icmp eq i64 %t42, 0
  store i1 %t44, ptr %l34, !tbaa !21
  br label %bb10
bb10:
  %t45 = load i1, ptr %l34, !tbaa !21
  br i1 %t45, label %bb11, label %bb12
bb11:
  %t46 = load ptr, ptr %l4, !tbaa !29
  %t48 = getelementptr { i64, [6 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { ptr }, ptr %t48, i32 0, i32 0
  %t50 = load ptr, ptr %t49
  store ptr %t50, ptr %l5, !tbaa !29
  br label %bb13
bb12:
  br label %bb46
bb13:
  %t52 = load ptr, ptr %l5, !tbaa !29
  %t54 = getelementptr %"compiler/ast:StructBody", ptr %t52, i32 0, i32 2
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 0
  %t59 = icmp eq i64 %t57, 0
  br i1 %t59, label %bb14, label %bb15
bb14:
  store i64 -1, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  store i64 0, ptr %l6, !tbaa !24
  %t62 = load ptr, ptr %l5, !tbaa !29
  %t64 = getelementptr %"compiler/ast:StructBody", ptr %t62, i32 0, i32 2
  %t65 = load { i64, ptr }, ptr %t64, !tbaa !27
  store { i64, ptr } %t65, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t67 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 0
  store i64 %t69, ptr %l9, !tbaa !24
  br label %bb17
bb17:
  %t71 = load i64, ptr %l8, !tbaa !24
  %t72 = load i64, ptr %l9, !tbaa !24
  %t75 = icmp slt i64 %t71, %t72
  %t77 = xor i1 %t75, true
  br i1 %t77, label %bb18, label %bb19
bb18:
  br label %bb45
bb19:
  br label %bb20
bb20:
  %t79 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t79, ptr %l52, !tbaa !27
  %t80 = load i64, ptr %l8, !tbaa !24
  %t82 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr ptr, ptr %t83, i64 %t80
  %t85 = load ptr, ptr %t84, !tbaa !39
  store ptr %t85, ptr %l10, !tbaa !29
  %t87 = load ptr, ptr %l10, !tbaa !29
  store ptr %t87, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t88 = load ptr, ptr %l55, !tbaa !29
  %t89 = icmp ne ptr %t88, null
  br i1 %t89, label %bb21, label %bb22
bb21:
  %t91 = load ptr, ptr %l55, !tbaa !29
  %t92 = load i64, ptr %t91, !range !{i64 0, i64 22}
  %t94 = icmp eq i64 %t92, 1
  store i1 %t94, ptr %l56, !tbaa !21
  br label %bb22
bb22:
  %t95 = load i1, ptr %l56, !tbaa !21
  br i1 %t95, label %bb23, label %bb24
bb23:
  %t96 = load ptr, ptr %l10, !tbaa !29
  %t98 = getelementptr { i64, [4 x i64] }, ptr %t96, i32 0, i32 1
  %t99 = getelementptr { %"compiler/source:Span", ptr }, ptr %t98, i32 0, i32 1
  %t100 = load ptr, ptr %t99
  store ptr %t100, ptr %l11, !tbaa !29
  br label %bb25
bb24:
  br label %bb38
bb25:
  %t102 = load ptr, ptr %l11, !tbaa !29
  %t104 = getelementptr %"compiler/ast:VarDecl", ptr %t102, i32 0, i32 5
  %t105 = load i1, ptr %t104, !tbaa !21
  br i1 %t105, label %bb26, label %bb27
bb26:
  %t107 = load ptr, ptr %l11, !tbaa !29
  %t109 = getelementptr %"compiler/ast:VarDecl", ptr %t107, i32 0, i32 0
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !27
  store { i64, ptr } %t110, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t112 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t112, 0
  store i64 %t114, ptr %l14, !tbaa !24
  br label %bb28
bb27:
  br label %bb37
bb28:
  %t116 = load i64, ptr %l13, !tbaa !24
  %t117 = load i64, ptr %l14, !tbaa !24
  %t120 = icmp slt i64 %t116, %t117
  %t122 = xor i1 %t120, true
  br i1 %t122, label %bb29, label %bb30
bb29:
  br label %bb36
bb30:
  br label %bb31
bb31:
  %t124 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t124, ptr %l71, !tbaa !27
  %t125 = load i64, ptr %l13, !tbaa !24
  %t127 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = getelementptr i32, ptr %t128, i64 %t125
  %t130 = load i32, ptr %t129, !tbaa !33
  %t136 = icmp eq i32 %t130, %a2
  br i1 %t136, label %bb32, label %bb33
bb32:
  %t138 = load i64, ptr %l6, !tbaa !24
  store i64 %t138, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  %t140 = load i64, ptr %l6, !tbaa !24
  %t142 = add i64 %t140, 1
  store i64 %t142, ptr %l6, !tbaa !24
  br label %bb35
bb35:
  %t144 = load i64, ptr %l13, !tbaa !24
  %t146 = add i64 %t144, 1
  store i64 %t146, ptr %l13, !tbaa !24
  br label %bb28
bb36:
  br label %bb37
bb37:
  br label %bb43
bb38:
  br i1 true, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_ef1b19b21c725e8b_7a0ef433936b1ef)
  unreachable
bb43:
  br label %bb44
bb44:
  %t148 = load i64, ptr %l8, !tbaa !24
  %t150 = add i64 %t148, 1
  store i64 %t150, ptr %l8, !tbaa !24
  br label %bb17
bb45:
  store i64 -1, ptr %rv
  br label %ret
bb46:
  br i1 true, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  store i64 -1, ptr %rv
  br label %ret
bb50:
  call void @__olang_check_failed(ptr @olang_loc_3671e63a1443f44a_b1e16b3f6a36352e)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldTypeAt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l11 = alloca i1
  %l14 = alloca i1
  %l19 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca { i64, ptr }
  %l30 = alloca i32
  %l31 = alloca { i64, ptr }
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l5, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 14
  %t7 = load i32, ptr %t6, !tbaa !23
  store i32 %t7, ptr %l2, !tbaa !23
  %t9 = load i32, ptr %l2, !tbaa !23
  %t10 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t13 = icmp eq i32 %t9, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb5
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l2, !tbaa !23
  %t19 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l14
  br label %bb4
bb4:
  %t20 = load i1, ptr %l14, !tbaa !21
  %t21 = xor i1 %t20, true
  store i1 %t21, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t23 = load i1, ptr %l11, !tbaa !21
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t24 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t24, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 2
  store ptr %t31, ptr %l19, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  %t38 = load i32, ptr %l2, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l24
  br label %bb9
bb9:
  %t42 = load ptr, ptr %l19, !tbaa !29
  %t43 = load i32, ptr %l24, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t42, i32 %t43)
  store { i64, ptr } %t44, ptr %l25
  br label %bb10
bb10:
  %t45 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t45, ptr %l3, !tbaa !27
  %t46 = load i64, ptr %l1, !tbaa !24
  %t47 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t52 = icmp slt i64 %t46, %t49
  br i1 %t52, label %bb11, label %bb12
bb11:
  %t54 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t54, ptr %l31, !tbaa !27
  %t55 = load i64, ptr %l1, !tbaa !24
  %t57 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr i32, ptr %t58, i64 %t55
  %t60 = load i32, ptr %t59, !tbaa !33
  store i32 %t60, ptr %l30, !tbaa !23
  br label %bb13
bb12:
  %t62 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t62, ptr %l30, !tbaa !23
  br label %bb13
bb13:
  %t64 = load i32, ptr %l30, !tbaa !23
  store i32 %t64, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l8 = alloca i1
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca ptr
  %l19 = alloca i32
  %l21 = alloca i1
  %l27 = alloca i32
  %l30 = alloca i1
  %l35 = alloca i32
  %l42 = alloca i32
  %l44 = alloca i1
  %l48 = alloca i1
  %l53 = alloca ptr
  %l58 = alloca i32
  %l63 = alloca i32
  %l64 = alloca i1
  %l65 = alloca i1
  %l66 = alloca ptr
  %l71 = alloca i32
  %l76 = alloca i32
  %l77 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t8 = load i32, ptr %l2, !tbaa !23
  %t12 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t6, i32 %t7, i32 %t8)
  store i1 %t12, ptr %l8
  br label %bb1
bb1:
  %t13 = load i1, ptr %l8, !tbaa !21
  br i1 %t13, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l1, !tbaa !23
  %t19 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l12
  br label %bb5
bb5:
  %t20 = load i1, ptr %l12, !tbaa !21
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l14, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l1, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l19
  br label %bb8
bb7:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb10
bb8:
  %t32 = load i32, ptr %l2, !tbaa !23
  %t33 = load ptr, ptr %l14, !tbaa !29
  %t34 = load i32, ptr %l19, !tbaa !23
  %t36 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t33, i32 %t34, i32 %t32)
  store i1 %t36, ptr %l21
  br label %bb9
bb9:
  %t37 = load i1, ptr %l21, !tbaa !21
  store i1 %t37, ptr %l13, !tbaa !21
  br label %bb10
bb10:
  %t38 = load i1, ptr %l13, !tbaa !21
  br i1 %t38, label %bb11, label %bb12
bb11:
  store i1 true, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/check:Checker", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/generic:Program", ptr %t43, i32 0, i32 2
  %t46 = load i32, ptr %l1, !tbaa !23
  %t49 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t45, i32 %t46)
  store i32 %t49, ptr %l27
  br label %bb14
bb14:
  %t50 = load i32, ptr %l27, !range !{i32 0, i32 33}
  %t52 = trunc i64 19 to i32
  %t53 = icmp eq i32 %t50, %t52
  br i1 %t53, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = getelementptr %"compiler/generic:Program", ptr %t58, i32 0, i32 2
  %t61 = load i32, ptr %l2, !tbaa !23
  %t64 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t60, i32 %t61)
  store i32 %t64, ptr %l35
  br label %bb17
bb16:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb18
bb17:
  %t65 = load i32, ptr %l35, !range !{i32 0, i32 33}
  %t67 = trunc i64 19 to i32
  %t68 = icmp eq i32 %t65, %t67
  store i1 %t68, ptr %l30, !tbaa !21
  br label %bb18
bb18:
  %t70 = load i1, ptr %l30, !tbaa !21
  br i1 %t70, label %bb19, label %bb20
bb19:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 2
  %t77 = load i32, ptr %l2, !tbaa !23
  %t80 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t76, i32 %t77)
  store i32 %t80, ptr %l42
  br label %bb21
bb20:
  br label %bb38
bb21:
  %t81 = load i32, ptr %l42, !tbaa !23
  %t82 = icmp ne i32 %t81, 0
  br i1 %t82, label %bb22, label %bb23
bb22:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i32, ptr %l1, !tbaa !23
  %t86 = load i32, ptr %l2, !tbaa !23
  %t90 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elengthsMeet(ptr %v0, ptr %t84, i32 %t85, i32 %t86)
  store i1 %t90, ptr %l48
  br label %bb24
bb23:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb25
bb24:
  %t91 = load i1, ptr %l48, !tbaa !21
  %t92 = xor i1 %t91, true
  store i1 %t92, ptr %l44, !tbaa !21
  br label %bb25
bb25:
  %t94 = load i1, ptr %l44, !tbaa !21
  br i1 %t94, label %bb26, label %bb27
bb26:
  store i1 false, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/check:Checker", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/generic:Program", ptr %t99, i32 0, i32 2
  store ptr %t101, ptr %l53, !tbaa !29
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/check:Checker", ptr %t102, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = getelementptr %"compiler/generic:Program", ptr %t105, i32 0, i32 2
  %t108 = load i32, ptr %l1, !tbaa !23
  %t111 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t107, i32 %t108)
  store i32 %t111, ptr %l58
  br label %bb29
bb29:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/check:Checker", ptr %t112, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t117 = getelementptr %"compiler/generic:Program", ptr %t115, i32 0, i32 2
  %t118 = load i32, ptr %l2, !tbaa !23
  %t121 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t117, i32 %t118)
  store i32 %t121, ptr %l63
  br label %bb30
bb30:
  %t122 = load ptr, ptr %l53, !tbaa !29
  %t123 = load i32, ptr %l58, !tbaa !23
  %t124 = load i32, ptr %l63, !tbaa !23
  %t125 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t122, i32 %t123, i32 %t124)
  store i1 %t125, ptr %l64
  br label %bb31
bb31:
  %t126 = load i1, ptr %l64, !tbaa !21
  br i1 %t126, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb37
bb33:
  %t127 = load ptr, ptr %l0, !tbaa !29
  store ptr %t127, ptr %l66, !tbaa !29
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/check:Checker", ptr %t128, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !29
  %t133 = getelementptr %"compiler/generic:Program", ptr %t131, i32 0, i32 2
  %t134 = load i32, ptr %l1, !tbaa !23
  %t137 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t133, i32 %t134)
  store i32 %t137, ptr %l71
  br label %bb34
bb34:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/check:Checker", ptr %t138, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t143 = getelementptr %"compiler/generic:Program", ptr %t141, i32 0, i32 2
  %t144 = load i32, ptr %l2, !tbaa !23
  %t147 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t143, i32 %t144)
  store i32 %t147, ptr %l76
  br label %bb35
bb35:
  %t148 = load ptr, ptr %l66, !tbaa !29
  %t149 = load i32, ptr %l71, !tbaa !23
  %t150 = load i32, ptr %l76, !tbaa !23
  %t151 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t148, i32 %t149, i32 %t150)
  store i1 %t151, ptr %l77
  br label %bb36
bb36:
  %t152 = load i1, ptr %l77, !tbaa !21
  store i1 %t152, ptr %l65, !tbaa !21
  br label %bb37
bb37:
  %t153 = load i1, ptr %l65, !tbaa !21
  store i1 %t153, ptr %rv
  br label %ret
bb38:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einGeneric(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca ptr
  %l5 = alloca i64
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0)
  store ptr %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 4
  %t7 = getelementptr %"compiler/generic:Context", ptr %t6, i32 0, i32 2
  %t9 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H0e73c22773457b60eb954c2c4a2643e9(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp sgt i64 %t10, 0
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eindexPlace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca ptr
  %l16 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %t1, ptr %a2)
  store ptr %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l7, !tbaa !29
  store ptr %t6, ptr %l4, !tbaa !29
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb2, label %bb3
bb2:
  store ptr null, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = load ptr, ptr %l4, !tbaa !29
  %t21 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelemPlace(ptr %v0, ptr %v2, ptr %t12, %"compiler/source:Span" %a1, ptr %t14, { i64, ptr } %a3, i32 0)
  store ptr %t21, ptr %l16
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l16, !tbaa !29
  store ptr %t22, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCase(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l15 = alloca i32
  %l17 = alloca ptr
  %l19 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t2, ptr %l5
  %t3 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t3, ptr %l6, !tbaa !23
  store i32 23, ptr %l7
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t5 = load %"compiler/source:Span", ptr %l1
  %t10 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t4, %"compiler/source:Span" %t5, ptr %a2)
  store ptr %t10, ptr %l11
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l12, !tbaa !29
  %t12 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t12, ptr %l13
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t13)
  store i32 %t15, ptr %l15
  br label %bb2
bb2:
  %t17 = load ptr, ptr %l12, !tbaa !29
  %t18 = load %"compiler/source:Span", ptr %l13
  %t19 = load i32, ptr %l15, !tbaa !23
  %t21 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t17, %"compiler/source:Span" %t18, i32 %t19, i64 %a3)
  store ptr %t21, ptr %l17
  br label %bb3
bb3:
  %t22 = load ptr, ptr %l17, !tbaa !29
  %t23 = load ptr, ptr %l4, !tbaa !29
  %t24 = load %"compiler/source:Span", ptr %l5
  %t25 = load i32, ptr %l6, !tbaa !23
  %t26 = load i32, ptr %l7, !range !{i32 0, i32 43}
  %t27 = load ptr, ptr %l11, !tbaa !29
  %t29 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t23, %"compiler/source:Span" %t24, i32 %t25, i32 %t26, ptr %t27, ptr %t22)
  store ptr %t29, ptr %l19
  br label %bb4
bb4:
  %t30 = load ptr, ptr %l19, !tbaa !29
  store ptr %t30, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisZeroLit(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i1
  %l15 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca i1
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 29}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19, !range !{i32 0, i32 96}
  store i32 %t20, ptr %l3
  br label %bb5
bb4:
  br label %bb11
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load i32, ptr %l3, !range !{i32 0, i32 96}
  %t24 = trunc i64 2 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t28 = load %"compiler/source:Span", ptr %l2
  %t31 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %a0, %"compiler/source:Span" %t28)
  store { i64, ptr } %t31, ptr %l18
  br label %bb8
bb7:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb10
bb8:
  %t32 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t33 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t32, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i1 %t33, ptr %l19
  br label %bb9
bb9:
  %t34 = load i1, ptr %l19, !tbaa !21
  store i1 %t34, ptr %l15, !tbaa !21
  br label %bb10
bb10:
  %t35 = load i1, ptr %l15, !tbaa !21
  store i1 %t35, ptr %l4, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_4a75f471ea948b24_16ed41ec7c1e5db8)
  unreachable
bb16:
  %t36 = load i1, ptr %l4, !tbaa !21
  store i1 %t36, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneBinary(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca [2 x i64]
  %l12 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i32
  %l21 = alloca %"compiler/check:laneNode"
  %l22 = alloca i32
  %l26 = alloca %"compiler/check:laneNode"
  %l28 = alloca i32
  %l32 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l34 = alloca ptr
  %l35 = alloca i64
  %l36 = alloca i32
  %l37 = alloca %"compiler/source:Span"
  %l38 = alloca %"compiler/source:Span"
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i32
  %l46 = alloca i64
  %l51 = alloca i32
  %l52 = alloca %"compiler/check:laneNode"
  %l53 = alloca i64
  %l54 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %t1, ptr %a4)
  store i64 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i64, ptr %l12, !tbaa !24
  store i64 %t6, ptr %l6, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %t7, ptr %a5)
  store i64 %t11, ptr %l15
  br label %bb2
bb2:
  %t12 = load i64, ptr %l15, !tbaa !24
  store i64 %t12, ptr %l7, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l16, !tbaa !29
  %t14 = load i32, ptr %l3, !range !{i32 0, i32 96}
  store i32 %t14, ptr %l17
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 39
  %t18 = load i64, ptr %l6, !tbaa !24
  %t21 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s0, ptr %t17, i64 %t18)
  store %"compiler/check:laneNode" %t21, ptr %l21
  br label %bb3
bb3:
  %t22 = getelementptr %"compiler/check:laneNode", ptr %l21, i32 0, i32 8
  %t23 = load i32, ptr %t22, !tbaa !23
  store i32 %t23, ptr %l22, !tbaa !23
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 39
  %t27 = load i64, ptr %l7, !tbaa !24
  %t30 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s0, ptr %t26, i64 %t27)
  store %"compiler/check:laneNode" %t30, ptr %l26
  br label %bb4
bb4:
  %t31 = getelementptr %"compiler/check:laneNode", ptr %l26, i32 0, i32 8
  %t32 = load i32, ptr %t31, !tbaa !23
  %t33 = load ptr, ptr %l16, !tbaa !29
  %t34 = load i32, ptr %l17, !range !{i32 0, i32 96}
  %t35 = load i32, ptr %l22, !tbaa !23
  %t37 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneBinType(ptr %v0, ptr %t33, i32 %t34, i32 %t35, i32 %t32)
  store i32 %t37, ptr %l28
  br label %bb5
bb5:
  %t38 = load i32, ptr %l28, !tbaa !23
  store i32 %t38, ptr %l8, !tbaa !23
  %t39 = load i64, ptr %l6, !tbaa !24
  %t40 = load i64, ptr %l7, !tbaa !24
  %t42 = insertvalue [2 x i64] undef, i64 %t39, 0
  %t44 = insertvalue [2 x i64] %t42, i64 %t40, 1
  store [2 x i64] %t44, ptr %l9
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l32, !tbaa !29
  %t47 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t47, ptr %l33
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l34, !tbaa !29
  %t49 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneBin, !tbaa !24
  store i64 %t49, ptr %l35, !tbaa !24
  %t50 = load i32, ptr %l3, !range !{i32 0, i32 96}
  store i32 %t50, ptr %l36
  %t51 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t51, ptr %l37
  %t52 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t52, ptr %l38
  %t53 = load i64, ptr %l6, !tbaa !24
  store i64 %t53, ptr %l39, !tbaa !24
  %t54 = load i64, ptr %l7, !tbaa !24
  store i64 %t54, ptr %l40, !tbaa !24
  %t55 = load i32, ptr %l8, !tbaa !23
  store i32 %t55, ptr %l41, !tbaa !23
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = insertvalue { i64, ptr } undef, i64 2, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %l9, 1
  %t60 = load %"compiler/source:Span", ptr %l2
  %t64 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLen(ptr %v0, ptr %s0, ptr %t56, { i64, ptr } %t59, %"compiler/source:Span" %t60)
  store i64 %t64, ptr %l46
  br label %bb6
bb6:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = insertvalue { i64, ptr } undef, i64 2, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %l9, 1
  %t69 = load i32, ptr %l8, !tbaa !23
  %t73 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneDecl(ptr %v0, ptr %s0, ptr %t65, { i64, ptr } %t68, i32 %t69)
  store i32 %t73, ptr %l51
  br label %bb7
bb7:
  %t74 = load i64, ptr %l35, !tbaa !24
  %t75 = load i32, ptr %l36, !range !{i32 0, i32 96}
  %t76 = load %"compiler/source:Span", ptr %l37
  %t77 = load %"compiler/source:Span", ptr %l38
  %t78 = load i64, ptr %l39, !tbaa !24
  %t79 = load i64, ptr %l40, !tbaa !24
  %t80 = load i32, ptr %l41, !tbaa !23
  %t81 = load i64, ptr %l46, !tbaa !24
  %t82 = load i32, ptr %l51, !tbaa !23
  %t83 = call %"compiler/check:laneNode" @compiler_2fcheck_3alaneNode_2ector(ptr %v0, ptr %v0, i64 %t74, i32 %t75, %"compiler/source:Span" %t76, %"compiler/source:Span" %t77, i64 %t78, i64 %t79, i64 -1, ptr null, i32 %t80, i64 %t81, i32 %t82)
  store %"compiler/check:laneNode" %t83, ptr %l52
  br label %bb8
bb8:
  %t84 = load ptr, ptr %l34, !tbaa !29
  %t85 = load %"compiler/check:laneNode", ptr %l52
  %t86 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneAdd(ptr %v0, ptr %v0, ptr %t84, %"compiler/check:laneNode" %t85)
  store i64 %t86, ptr %l53
  br label %bb9
bb9:
  %t87 = load ptr, ptr %l32, !tbaa !29
  %t88 = load %"compiler/source:Span", ptr %l33
  %t89 = load i64, ptr %l53, !tbaa !24
  %t90 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneHold(ptr %v0, ptr %t87, %"compiler/source:Span" %t88, i64 %t89)
  store ptr %t90, ptr %l54
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t91 = load ptr, ptr %l54, !tbaa !29
  store ptr %t91, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLen(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l16 = alloca { i64, ptr }
  %l22 = alloca %"compiler/check:laneNode"
  %l28 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l36 = alloca %"compiler/msgs:Msg"
  %l37 = alloca i64
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 -1, ptr %l3, !tbaa !24
  store { i64, ptr } %a1, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l6, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l6, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t15, ptr %l16, !tbaa !27
  %t16 = load i64, ptr %l5, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i64, ptr %t19, i64 %t16
  %t21 = load i64, ptr %t20, !tbaa !34
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 39
  %t29 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s2, ptr %t25, i64 %t21)
  store %"compiler/check:laneNode" %t29, ptr %l22
  br label %bb5
bb5:
  %t30 = getelementptr %"compiler/check:laneNode", ptr %l22, i32 0, i32 9
  %t31 = load i64, ptr %t30, !tbaa !24
  store i64 %t31, ptr %l8, !tbaa !24
  %t33 = load i64, ptr %l8, !tbaa !24
  %t35 = icmp slt i64 %t33, 0
  br i1 %t35, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb7:
  br label %bb8
bb8:
  %t37 = load i64, ptr %l3, !tbaa !24
  %t39 = icmp sge i64 %t37, 0
  br i1 %t39, label %bb9, label %bb10
bb9:
  %t41 = load i64, ptr %l8, !tbaa !24
  %t42 = load i64, ptr %l3, !tbaa !24
  %t45 = icmp ne i64 %t41, %t42
  store i1 %t45, ptr %l28, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb11
bb11:
  %t47 = load i1, ptr %l28, !tbaa !21
  br i1 %t47, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l32, !tbaa !29
  store %"compiler/source:Span" %a2, ptr %l33
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i64, ptr %l8, !tbaa !24
  %t54 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLaneLengths(ptr %s4, i64 %t50, i64 %t51)
  store %"compiler/msgs:Msg" %t54, ptr %l36
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t55 = load ptr, ptr %l32, !tbaa !29
  %t56 = load %"compiler/source:Span", ptr %l33
  %t57 = load %"compiler/msgs:Msg", ptr %l36
  %t58 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t55, %"compiler/source:Span" %t56, %"compiler/msgs:Msg" %t57)
  store i64 %t58, ptr %l37
  br label %bb15
bb15:
  %t59 = load i64, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  store i64 %t59, ptr %rv
  br label %ret
bb16:
  %t61 = load i64, ptr %l8, !tbaa !24
  store i64 %t61, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  %t63 = load i64, ptr %l5, !tbaa !24
  %t65 = add i64 %t63, 1
  store i64 %t65, ptr %l5, !tbaa !24
  br label %bb1
bb18:
  %t67 = load i64, ptr %l3, !tbaa !24
  store i64 %t67, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneResult(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i32
  %l7 = alloca i32
  %l9 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l17 = alloca i32
  %l22 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t4, i64 %t5)
  store i32 %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load i32, ptr %l7, !tbaa !23
  store i32 %t9, ptr %l3, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  store ptr %t13, ptr %l9, !tbaa !29
  %t14 = load i64, ptr %l1, !tbaa !24
  %t16 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t14)
  store i64 %t16, ptr %l11
  br label %bb2
bb2:
  %t17 = load ptr, ptr %l9, !tbaa !29
  %t18 = load i64, ptr %l11, !tbaa !24
  %t19 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t17, i64 %t18)
  store i64 %t19, ptr %l12
  br label %bb3
bb3:
  %t20 = load i64, ptr %l12, !tbaa !24
  %t21 = icmp sgt i64 %t20, 0
  br i1 %t21, label %bb4, label %bb5
bb4:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i64, ptr %l1, !tbaa !24
  %t29 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimplSig(ptr %v0, ptr %t23, i64 %t24, i32 %a2)
  store i32 %t29, ptr %l17
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t30 = load i32, ptr %l17, !tbaa !23
  store i32 %t30, ptr %l3, !tbaa !23
  br label %bb7
bb7:
  %t31 = load i32, ptr %l3, !tbaa !23
  %t32 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t35 = icmp eq i32 %t31, %t32
  br i1 %t35, label %bb8, label %bb9
bb8:
  %t37 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t37, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l22, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/check:Checker", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/generic:Program", ptr %t43, i32 0, i32 2
  %t46 = load i32, ptr %l3, !tbaa !23
  %t49 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t45, i32 %t46)
  store i32 %t49, ptr %l27
  br label %bb11
bb11:
  %t50 = load ptr, ptr %l22, !tbaa !29
  %t51 = load i32, ptr %l27, !tbaa !23
  %t52 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t50, i32 %t51)
  store i32 %t52, ptr %l28
  br label %bb12
bb12:
  %t53 = load i32, ptr %l28, !tbaa !23
  store i32 %t53, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneTotal(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca %"compiler/check:laneNode"
  %l6 = alloca i32
  %l7 = alloca i64
  %lp8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, i64, i64, i64, i64 }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca i1
  %l19 = alloca i64
  %l20 = alloca { i64, i64, i64, i64, i64 }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i64
  %lp28 = alloca ptr
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca { i64, i64, i64, i64, i64 }
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca i64
  %lp44 = alloca ptr
  %l48 = alloca %"compiler/check:laneNode"
  %l56 = alloca ptr
  %l58 = alloca i1
  %l59 = alloca i1
  %l61 = alloca i1
  %l62 = alloca i1
  %l66 = alloca ptr
  %l67 = alloca %"compiler/source:Span"
  %l70 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l75 = alloca %"compiler/msgs:Msg"
  %l76 = alloca i64
  %l79 = alloca ptr
  %l82 = alloca i64
  %l86 = alloca %"compiler/check:laneVals"
  %l91 = alloca ptr
  %l93 = alloca i1
  %l97 = alloca i64
  %l98 = alloca ptr
  %l99 = alloca %"compiler/source:Span"
  %l102 = alloca i32
  %l106 = alloca ptr
  %l112 = alloca { i64, i64, i64, i64, i64 }
  %l118 = alloca ptr
  %l119 = alloca %"compiler/source:Span"
  %l120 = alloca %"compiler/source:Span"
  %l121 = alloca i32
  %l125 = alloca ptr
  %l126 = alloca ptr
  %l127 = alloca %"compiler/source:Span"
  %l128 = alloca i64
  %l129 = alloca ptr
  %l133 = alloca ptr
  %l134 = alloca ptr
  %l137 = alloca ptr
  %l138 = alloca ptr
  %l139 = alloca %"compiler/source:Span"
  %l146 = alloca ptr
  %l151 = alloca ptr
  %l161 = alloca %"compiler/source:Span"
  %l162 = alloca i32
  %l166 = alloca { i64, ptr }
  %l170 = alloca ptr
  %l172 = alloca %"compiler/typed:Seq"
  %l177 = alloca i1
  %l178 = alloca i1
  %l180 = alloca i1
  %l182 = alloca i1
  %l186 = alloca i64
  %l187 = alloca ptr
  %l188 = alloca %"compiler/source:Span"
  %l191 = alloca i32
  %l192 = alloca ptr
  %l193 = alloca %"compiler/source:Span"
  %l194 = alloca i32
  %l196 = alloca i64
  %l197 = alloca ptr
  %l203 = alloca { i64, i64, i64, i64, i64 }
  %l209 = alloca ptr
  %l210 = alloca %"compiler/source:Span"
  %l211 = alloca i64
  %l212 = alloca ptr
  %l216 = alloca ptr
  %l217 = alloca ptr
  %l220 = alloca i64
  %l222 = alloca ptr
  %l223 = alloca %"compiler/source:Span"
  %l230 = alloca ptr
  %l231 = alloca ptr
  %l232 = alloca %"compiler/source:Span"
  %l233 = alloca i32
  %l235 = alloca i64
  %l236 = alloca ptr
  %l249 = alloca ptr
  %l253 = alloca i32
  %l257 = alloca { i64, ptr }
  %l258 = alloca %"compiler/typed:Block"
  %l259 = alloca ptr
  %l260 = alloca %"compiler/source:Span"
  %l262 = alloca ptr
  %l267 = alloca ptr
  %l269 = alloca %"compiler/typed:If"
  %l280 = alloca %"compiler/source:Span"
  %l281 = alloca i32
  %l285 = alloca { i64, ptr }
  %l289 = alloca ptr
  %l291 = alloca %"compiler/typed:Seq"
  %l295 = alloca ptr
  %l297 = alloca i32
  %l298 = alloca { i64, ptr }
  %l300 = alloca i32
  %l301 = alloca ptr
  %l302 = alloca %"compiler/source:Span"
  %l303 = alloca %"compiler/source:Span"
  %l304 = alloca i32
  %l305 = alloca i32
  %l306 = alloca i32
  %l309 = alloca { i64, ptr }
  %l314 = alloca ptr
  %l315 = alloca %"compiler/source:Span"
  %l317 = alloca i32
  %l318 = alloca i64
  %l319 = alloca ptr
  %l320 = alloca %"compiler/source:Span"
  %l323 = alloca i32
  %l324 = alloca ptr
  %l325 = alloca %"compiler/source:Span"
  %l327 = alloca i32
  %l328 = alloca ptr
  %l335 = alloca i64
  %l336 = alloca ptr
  %l337 = alloca %"compiler/source:Span"
  %l338 = alloca i64
  %l339 = alloca ptr
  %l343 = alloca ptr
  %l344 = alloca ptr
  %l357 = alloca i64
  %l358 = alloca ptr
  %l359 = alloca %"compiler/source:Span"
  %l362 = alloca i32
  %l367 = alloca ptr
  %l370 = alloca ptr
  %l371 = alloca %"compiler/source:Span"
  %l376 = alloca ptr
  %l377 = alloca { i64, i64, i64, i64, i64 }
  %l386 = alloca i64
  %l387 = alloca ptr
  %l388 = alloca %"compiler/source:Span"
  %l391 = alloca i32
  %l392 = alloca ptr
  %l393 = alloca ptr
  %l394 = alloca %"compiler/source:Span"
  %l395 = alloca i64
  %l396 = alloca ptr
  %l400 = alloca ptr
  %l401 = alloca ptr
  %l404 = alloca ptr
  %l408 = alloca i1
  %l409 = alloca ptr
  %l410 = alloca ptr
  %l411 = alloca %"compiler/source:Span"
  %l412 = alloca %"compiler/source:Span"
  %l413 = alloca i32
  %l417 = alloca ptr
  %l421 = alloca ptr
  %l424 = alloca ptr
  %l425 = alloca ptr
  %l426 = alloca %"compiler/source:Span"
  %l427 = alloca %"compiler/source:Span"
  %l428 = alloca i32
  %l432 = alloca ptr
  %l436 = alloca ptr
  %l439 = alloca ptr
  %l442 = alloca ptr
  %l445 = alloca i32
  %l446 = alloca i1
  %l447 = alloca ptr
  %l448 = alloca %"compiler/source:Span"
  %l449 = alloca i32
  %l450 = alloca i32
  %l454 = alloca ptr
  %l458 = alloca ptr
  %l460 = alloca ptr
  %l461 = alloca %"compiler/source:Span"
  %l462 = alloca i32
  %l463 = alloca ptr
  %l467 = alloca ptr
  %l470 = alloca %"compiler/typed:Cond"
  %l476 = alloca i64
  %l478 = alloca ptr
  %l479 = alloca %"compiler/source:Span"
  %l486 = alloca ptr
  %l490 = alloca ptr
  %l494 = alloca ptr
  %l498 = alloca i32
  %l502 = alloca { i64, ptr }
  %l503 = alloca %"compiler/typed:Block"
  %l504 = alloca ptr
  %l505 = alloca %"compiler/source:Span"
  %l508 = alloca %"compiler/typed:If"
  %l519 = alloca %"compiler/source:Span"
  %l520 = alloca i32
  %l524 = alloca { i64, ptr }
  %l528 = alloca ptr
  %l530 = alloca %"compiler/typed:Seq"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca ptr
  %t142 = alloca { i64, [3 x i64] }, align 8
  %t226 = alloca { i64, [4 x i64] }, align 8
  %t247 = alloca { i64, [3 x i64] }, align 8
  %t297 = alloca { i64, [5 x i64] }, align 8
  %t347 = alloca { i64, [3 x i64] }, align 8
  %t418 = alloca { i64, [4 x i64] }, align 8
  %t440 = alloca { i64, [3 x i64] }, align 8
  %t462 = alloca { i64, [3 x i64] }, align 8
  %t519 = alloca { i64, [3 x i64] }, align 8
  %t567 = alloca { i64, [5 x i64] }, align 8
  %t608 = alloca { i64, [5 x i64] }, align 8
  %t624 = alloca { i64, [3 x i64] }, align 8
  %t661 = alloca { i64, [3 x i64] }, align 8
  %t753 = alloca { i64, [3 x i64] }, align 8
  %t837 = alloca { i64, [3 x i64] }, align 8
  %t973 = alloca { i64, [5 x i64] }, align 8
  %t1002 = alloca { i64, [4 x i64] }, align 8
  %t1021 = alloca { i64, [3 x i64] }, align 8
  %t1067 = alloca { i64, [3 x i64] }, align 8
  %t1115 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 39
  %t4 = load i64, ptr %l4, !tbaa !24
  %t7 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store %"compiler/check:laneNode" %t7, ptr %l48
  br label %bb1
bb1:
  %t8 = load %"compiler/check:laneNode", ptr %l48
  store %"compiler/check:laneNode" %t8, ptr %l5
  %t9 = getelementptr %"compiler/check:laneNode", ptr %l5, i32 0, i32 8
  %t10 = load i32, ptr %t9, !tbaa !23
  store i32 %t10, ptr %l6, !tbaa !23
  %t12 = load i32, ptr %l6, !tbaa !23
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t16 = icmp eq i32 %t12, %t13
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load %"compiler/source:Span", ptr %l1
  %t20 = load i64, ptr %l4, !tbaa !24
  %t24 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneSay(ptr %v0, ptr %t18, %"compiler/source:Span" %t19, i64 %t20)
  store ptr %t24, ptr %l56
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load ptr, ptr %l56, !tbaa !29
  store ptr %t25, ptr %rv
  br label %ret
bb5:
  %t26 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t28 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t26, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t28, ptr %l58
  br label %bb6
bb6:
  %t29 = load i1, ptr %l58, !tbaa !21
  br i1 %t29, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l59, !tbaa !21
  br label %bb10
bb8:
  %t30 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t32 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t30, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store i1 %t32, ptr %l61
  br label %bb9
bb9:
  %t33 = load i1, ptr %l61, !tbaa !21
  store i1 %t33, ptr %l59, !tbaa !21
  br label %bb10
bb10:
  %t34 = load i1, ptr %l59, !tbaa !21
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t35 = load i32, ptr %l6, !tbaa !23
  %t36 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t39 = icmp ne i32 %t35, %t36
  store i1 %t39, ptr %l62, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb13
bb13:
  %t41 = load i1, ptr %l62, !tbaa !21
  br i1 %t41, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l66, !tbaa !29
  %t43 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t43, ptr %l67
  %t44 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t45 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t48 = extractvalue { i64, ptr } %t44, 1
  %t49 = extractvalue { i64, ptr } %t44, 0
  %t50 = add i64 %t46, %t49
  %t51 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t52 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t53 = add i64 %t50, %t52
  %t54 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t53)
  call void @olang_textcopy(ptr %t54, ptr %t45, i64 %t46)
  %t55 = getelementptr i8, ptr %t54, i64 %t46
  call void @olang_textcopy(ptr %t55, ptr %t48, i64 %t49)
  %t56 = getelementptr i8, ptr %t55, i64 %t49
  call void @olang_textcopy(ptr %t56, ptr %t51, i64 %t52)
  %t57 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t54, 1
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t61 = extractvalue { i64, ptr } %t58, 1
  %t62 = mul i64 %t60, 1
  %t63 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t62)
  call void @llvm.memcpy.p0.p0.i64(ptr %t63, ptr %t61, i64 %t62, i1 false)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  store { i64, ptr } %t65, ptr %l70, !tbaa !27
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i32, ptr %l6, !tbaa !23
  %t70 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t66, i32 %t67)
  store { i64, ptr } %t70, ptr %l73
  br label %bb16
bb15:
  br label %bb20
bb16:
  %t71 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 0
  %t73 = extractvalue { i64, ptr } %t71, 1
  %t74 = mul i64 %t72, 1
  %t75 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t74)
  call void @llvm.memcpy.p0.p0.i64(ptr %t75, ptr %t73, i64 %t74, i1 false)
  %t76 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  %t78 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t80 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLaneMaskBool(ptr %s2, ptr %s2, ptr %s2, { i64, ptr } %t78, { i64, ptr } %t77)
  store %"compiler/msgs:Msg" %t80, ptr %l75
  br label %bb17
bb17:
  %t81 = load ptr, ptr %l66, !tbaa !29
  %t82 = load %"compiler/source:Span", ptr %l67
  %t83 = load %"compiler/msgs:Msg", ptr %l75
  %t84 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t81, %"compiler/source:Span" %t82, %"compiler/msgs:Msg" %t83)
  store i64 %t84, ptr %l76
  br label %bb18
bb18:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load %"compiler/source:Span", ptr %l1
  %t89 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t85, %"compiler/source:Span" %t86)
  store ptr %t89, ptr %l79
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t90 = load ptr, ptr %l79, !tbaa !29
  store ptr %t90, ptr %rv
  br label %ret
bb20:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/check:Checker", ptr %t91, i32 0, i32 37
  %t95 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t93)
  store i64 %t95, ptr %l82
  br label %bb21
bb21:
  %t96 = load i64, ptr %l82, !tbaa !24
  store i64 %t96, ptr %l7, !tbaa !24
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load %"compiler/source:Span", ptr %l1
  %t99 = load i64, ptr %l4, !tbaa !24
  %t103 = call %"compiler/check:laneVals" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneSetup(ptr %v0, ptr %v0, ptr %t97, %"compiler/source:Span" %t98, i64 %t99)
  store %"compiler/check:laneVals" %t103, ptr %l86
  br label %bb22
bb22:
  %t104 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t104, ptr %lp8
  %t105 = load %"compiler/check:laneVals", ptr %l86
  %t106 = load ptr, ptr %lp8
  store %"compiler/check:laneVals" %t105, ptr %t106
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load %"compiler/source:Span", ptr %l1
  %t109 = load i64, ptr %l4, !tbaa !24
  %t110 = load ptr, ptr %lp8
  %t115 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneCount(ptr %v0, ptr %v0, ptr %t107, %"compiler/source:Span" %t108, i64 %t109, ptr %t110)
  store ptr %t115, ptr %l91
  br label %bb23
bb23:
  %t116 = load ptr, ptr %l91, !tbaa !29
  store ptr %t116, ptr %l9, !tbaa !29
  %t117 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t119 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t117, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d19, i32 0, i32 1) })
  store i1 %t119, ptr %l93
  br label %bb24
bb24:
  %t120 = load i1, ptr %l93, !tbaa !21
  br i1 %t120, label %bb25, label %bb26
bb25:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load %"compiler/source:Span", ptr %l1
  %t123 = load i32, ptr %l6, !tbaa !23
  %t127 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t121, %"compiler/source:Span" %t122, i32 %t123)
  store i64 %t127, ptr %l97
  br label %bb27
bb26:
  br label %bb41
bb27:
  %t128 = load i64, ptr %l97, !tbaa !24
  store i64 %t128, ptr %l10, !tbaa !24
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l98, !tbaa !29
  %t130 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t130, ptr %l99
  %t131 = load i64, ptr %l10, !tbaa !24
  %t133 = trunc i64 %t131 to i32
  store i32 %t133, ptr %l102, !tbaa !23
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load %"compiler/source:Span", ptr %l1
  %t137 = load i32, ptr %l6, !tbaa !23
  %t141 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %t135, %"compiler/source:Span" %t136, i32 %t137)
  store ptr %t141, ptr %l106
  br label %bb28
bb28:
  store { i64, [3 x i64] } zeroinitializer, ptr %t142
  %t143 = getelementptr { i64, [3 x i64] }, ptr %t142, i32 0, i32 0
  store i64 0, ptr %t143
  %t144 = load %"compiler/source:Span", ptr %l99
  %t145 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t144, 0
  %t146 = load i32, ptr %l102, !tbaa !23
  %t147 = insertvalue { %"compiler/source:Span", i32, ptr } %t145, i32 %t146, 1
  %t148 = load ptr, ptr %l106, !tbaa !29
  %t149 = insertvalue { %"compiler/source:Span", i32, ptr } %t147, ptr %t148, 2
  %t150 = getelementptr { i64, [3 x i64] }, ptr %t142, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t149, ptr %t150
  %t151 = load { i64, [3 x i64] }, ptr %t142
  %t153 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t151, ptr %t153
  %t154 = load ptr, ptr %l98, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t154, ptr %t153)
  br label %bb29
bb29:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load %"compiler/source:Span", ptr %l1
  %t158 = load ptr, ptr %l9, !tbaa !29
  %t162 = call { i64, i64, i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLoopOpen(ptr %v0, ptr %t156, %"compiler/source:Span" %t157, ptr %t158, i64 0)
  store { i64, i64, i64, i64, i64 } %t162, ptr %l112
  br label %bb30
bb30:
  %t163 = load { i64, i64, i64, i64, i64 }, ptr %l112
  store { i64, i64, i64, i64, i64 } %t163, ptr %l11
  %t164 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l11, i32 0, i32 0
  %t165 = load i64, ptr %t164, !tbaa !24
  store i64 %t165, ptr %l12, !tbaa !24
  %t167 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l11, i32 0, i32 1
  %t168 = load i64, ptr %t167, !tbaa !24
  store i64 %t168, ptr %l13, !tbaa !24
  %t170 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l11, i32 0, i32 2
  %t171 = load i64, ptr %t170, !tbaa !24
  store i64 %t171, ptr %l14, !tbaa !24
  %t173 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l11, i32 0, i32 3
  %t174 = load i64, ptr %t173, !tbaa !24
  store i64 %t174, ptr %l15, !tbaa !24
  %t176 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l11, i32 0, i32 4
  %t177 = load i64, ptr %t176, !tbaa !24
  store i64 %t177, ptr %l16, !tbaa !24
  %t179 = load ptr, ptr %l0, !tbaa !29
  store ptr %t179, ptr %l118, !tbaa !29
  %t180 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t180, ptr %l119
  %t181 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t181, ptr %l120
  store i32 52, ptr %l121
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load %"compiler/source:Span", ptr %l1
  %t184 = load i64, ptr %l10, !tbaa !24
  %t188 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t182, %"compiler/source:Span" %t183, i64 %t184)
  store ptr %t188, ptr %l125
  br label %bb31
bb31:
  %t189 = load ptr, ptr %l0, !tbaa !29
  store ptr %t189, ptr %l126, !tbaa !29
  %t190 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t190, ptr %l127
  %t191 = load i64, ptr %l4, !tbaa !24
  store i64 %t191, ptr %l128, !tbaa !24
  %t192 = load ptr, ptr %lp8
  store ptr %t192, ptr %l129, !tbaa !29
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load %"compiler/source:Span", ptr %l1
  %t195 = load i64, ptr %l12, !tbaa !24
  %t199 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t193, %"compiler/source:Span" %t194, i64 %t195)
  store ptr %t199, ptr %l133
  br label %bb32
bb32:
  %t200 = load ptr, ptr %l126, !tbaa !29
  %t201 = load %"compiler/source:Span", ptr %l127
  %t202 = load i64, ptr %l128, !tbaa !24
  %t203 = load ptr, ptr %l129, !tbaa !29
  %t204 = load ptr, ptr %l133, !tbaa !29
  %t205 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v0, ptr %t200, %"compiler/source:Span" %t201, i64 %t202, ptr %t203, ptr %t204)
  store ptr %t205, ptr %l134
  br label %bb33
bb33:
  %t206 = load %"compiler/source:Span", ptr %l1
  %t207 = load %"compiler/source:Span", ptr %l1
  %t208 = load ptr, ptr %l118, !tbaa !29
  %t209 = load %"compiler/source:Span", ptr %l119
  %t210 = load %"compiler/source:Span", ptr %l120
  %t211 = load i32, ptr %l121, !range !{i32 0, i32 96}
  %t212 = load ptr, ptr %l125, !tbaa !29
  %t213 = load ptr, ptr %l134, !tbaa !29
  %t216 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %t208, %"compiler/source:Span" %t209, %"compiler/source:Span" %t210, i32 %t211, ptr %t212, ptr %t213, %"compiler/source:Span" %t206, %"compiler/source:Span" %t207)
  store ptr %t216, ptr %l137
  br label %bb34
bb34:
  %t217 = load ptr, ptr %l137, !tbaa !29
  %t218 = load ptr, ptr %l0, !tbaa !29
  store ptr %t218, ptr %l138, !tbaa !29
  %t219 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t219, ptr %l139
  %t220 = load %"compiler/source:Span", ptr %l1
  %t221 = load i32, ptr %l6, !tbaa !23
  %t222 = load i64, ptr %l10, !tbaa !24
  %t224 = trunc i64 %t222 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t226
  %t227 = getelementptr { i64, [4 x i64] }, ptr %t226, i32 0, i32 0
  store i64 0, ptr %t227
  %t229 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t220, 0
  %t231 = insertvalue { %"compiler/source:Span", i32, i32 } %t229, i32 %t221, 1
  %t233 = insertvalue { %"compiler/source:Span", i32, i32 } %t231, i32 %t224, 2
  %t234 = getelementptr { i64, [4 x i64] }, ptr %t226, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t233, ptr %t234
  %t235 = load { i64, [4 x i64] }, ptr %t226
  %t237 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t235, ptr %t237
  store ptr %t237, ptr %l146, !tbaa !29
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = load i32, ptr %l6, !tbaa !23
  %t241 = load %"compiler/source:Span", ptr %l1
  %t246 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t238, ptr %t217, i32 %t240, %"compiler/source:Span" %t241)
  store ptr %t246, ptr %l151
  br label %bb35
bb35:
  store { i64, [3 x i64] } zeroinitializer, ptr %t247
  %t248 = getelementptr { i64, [3 x i64] }, ptr %t247, i32 0, i32 0
  store i64 1, ptr %t248
  %t249 = load %"compiler/source:Span", ptr %l139
  %t250 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t249, 0
  %t251 = load ptr, ptr %l146, !tbaa !29
  %t252 = insertvalue { %"compiler/source:Span", ptr, ptr } %t250, ptr %t251, 1
  %t253 = load ptr, ptr %l151, !tbaa !29
  %t254 = insertvalue { %"compiler/source:Span", ptr, ptr } %t252, ptr %t253, 2
  %t255 = getelementptr { i64, [3 x i64] }, ptr %t247, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t254, ptr %t255
  %t256 = load { i64, [3 x i64] }, ptr %t247
  %t258 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t256, ptr %t258
  %t259 = load ptr, ptr %l138, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t259, ptr %t258)
  br label %bb36
bb36:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t262 = load %"compiler/source:Span", ptr %l1
  %t263 = load i64, ptr %l12, !tbaa !24
  %t264 = load i64, ptr %l13, !tbaa !24
  %t265 = load i64, ptr %l14, !tbaa !24
  %t266 = load i64, ptr %l15, !tbaa !24
  %t267 = load i64, ptr %l16, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLoopClose(ptr %v0, ptr %t261, %"compiler/source:Span" %t262, i64 %t263, i64 %t264, i64 %t265, i64 %t266, i64 %t267)
  br label %bb37
bb37:
  %t275 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t275, ptr %l161
  %t276 = load i32, ptr %l6, !tbaa !23
  store i32 %t276, ptr %l162, !tbaa !23
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t279 = getelementptr %"compiler/check:Checker", ptr %t277, i32 0, i32 37
  %t280 = load i64, ptr %l7, !tbaa !24
  %t283 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t279, i64 %t280)
  store { i64, ptr } %t283, ptr %l166
  br label %bb38
bb38:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load %"compiler/source:Span", ptr %l1
  %t286 = load i64, ptr %l10, !tbaa !24
  %t290 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t284, %"compiler/source:Span" %t285, i64 %t286)
  store ptr %t290, ptr %l170
  br label %bb39
bb39:
  %t291 = load ptr, ptr %l170, !tbaa !29
  %t292 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t294 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t292, ptr %t291)
  store %"compiler/typed:Seq" %t294, ptr %l172
  br label %bb40
bb40:
  %t295 = load %"compiler/typed:Seq", ptr %l172
  %t296 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Seq" %t295, ptr %t296
  store { i64, [5 x i64] } zeroinitializer, ptr %t297
  %t298 = getelementptr { i64, [5 x i64] }, ptr %t297, i32 0, i32 0
  store i64 12, ptr %t298
  %t299 = load %"compiler/source:Span", ptr %l161
  %t300 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t299, 0
  %t301 = load i32, ptr %l162, !tbaa !23
  %t302 = insertvalue { %"compiler/source:Span", i32, ptr } %t300, i32 %t301, 1
  %t304 = insertvalue { %"compiler/source:Span", i32, ptr } %t302, ptr %t296, 2
  %t305 = getelementptr { i64, [5 x i64] }, ptr %t297, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t304, ptr %t305
  %t306 = load { i64, [5 x i64] }, ptr %t297
  %t308 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t306, ptr %t308
  call void @__olang_scope_close(ptr %s0)
  store ptr %t308, ptr %rv
  br label %ret
bb41:
  %t310 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t312 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t310, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d20, i32 0, i32 1) })
  store i1 %t312, ptr %l177
  br label %bb42
bb42:
  %t313 = load i1, ptr %l177, !tbaa !21
  br i1 %t313, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l178, !tbaa !21
  br label %bb46
bb44:
  %t314 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t316 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t314, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d21, i32 0, i32 1) })
  store i1 %t316, ptr %l180
  br label %bb45
bb45:
  %t317 = load i1, ptr %l180, !tbaa !21
  store i1 %t317, ptr %l178, !tbaa !21
  br label %bb46
bb46:
  %t318 = load i1, ptr %l178, !tbaa !21
  br i1 %t318, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s5
  %t319 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t321 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s5, { i64, ptr } %t319, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store i1 %t321, ptr %l182
  br label %bb49
bb48:
  br label %bb79
bb49:
  %t322 = load i1, ptr %l182, !tbaa !21
  store i1 %t322, ptr %l18, !tbaa !21
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load %"compiler/source:Span", ptr %l1
  %t325 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t329 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t323, %"compiler/source:Span" %t324, i32 %t325)
  store i64 %t329, ptr %l186
  br label %bb50
bb50:
  %t330 = load i64, ptr %l186, !tbaa !24
  store i64 %t330, ptr %l19, !tbaa !24
  %t331 = load ptr, ptr %l0, !tbaa !29
  store ptr %t331, ptr %l187, !tbaa !29
  %t332 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t332, ptr %l188
  %t333 = load i64, ptr %l19, !tbaa !24
  %t335 = trunc i64 %t333 to i32
  store i32 %t335, ptr %l191, !tbaa !23
  %t337 = load ptr, ptr %l0, !tbaa !29
  store ptr %t337, ptr %l192, !tbaa !29
  %t338 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t338, ptr %l193
  %t339 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t339, ptr %l194, !tbaa !23
  %t340 = load i1, ptr %l18, !tbaa !21
  br i1 %t340, label %bb51, label %bb52
bb51:
  store i64 0, ptr %l196, !tbaa !24
  br label %bb53
bb52:
  store i64 1, ptr %l196, !tbaa !24
  br label %bb53
bb53:
  %t342 = load ptr, ptr %l192, !tbaa !29
  %t343 = load %"compiler/source:Span", ptr %l193
  %t344 = load i32, ptr %l194, !tbaa !23
  %t345 = load i64, ptr %l196, !tbaa !24
  %t346 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t342, %"compiler/source:Span" %t343, i32 %t344, i64 %t345)
  store ptr %t346, ptr %l197
  br label %bb54
bb54:
  store { i64, [3 x i64] } zeroinitializer, ptr %t347
  %t348 = getelementptr { i64, [3 x i64] }, ptr %t347, i32 0, i32 0
  store i64 0, ptr %t348
  %t349 = load %"compiler/source:Span", ptr %l188
  %t350 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t349, 0
  %t351 = load i32, ptr %l191, !tbaa !23
  %t352 = insertvalue { %"compiler/source:Span", i32, ptr } %t350, i32 %t351, 1
  %t353 = load ptr, ptr %l197, !tbaa !29
  %t354 = insertvalue { %"compiler/source:Span", i32, ptr } %t352, ptr %t353, 2
  %t355 = getelementptr { i64, [3 x i64] }, ptr %t347, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t354, ptr %t355
  %t356 = load { i64, [3 x i64] }, ptr %t347
  %t358 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t356, ptr %t358
  %t359 = load ptr, ptr %l187, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t359, ptr %t358)
  br label %bb55
bb55:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load %"compiler/source:Span", ptr %l1
  %t363 = load ptr, ptr %l9, !tbaa !29
  %t367 = call { i64, i64, i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLoopOpen(ptr %v0, ptr %t361, %"compiler/source:Span" %t362, ptr %t363, i64 0)
  store { i64, i64, i64, i64, i64 } %t367, ptr %l203
  br label %bb56
bb56:
  %t368 = load { i64, i64, i64, i64, i64 }, ptr %l203
  store { i64, i64, i64, i64, i64 } %t368, ptr %l20
  %t369 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l20, i32 0, i32 0
  %t370 = load i64, ptr %t369, !tbaa !24
  store i64 %t370, ptr %l21, !tbaa !24
  %t372 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l20, i32 0, i32 1
  %t373 = load i64, ptr %t372, !tbaa !24
  store i64 %t373, ptr %l22, !tbaa !24
  %t375 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l20, i32 0, i32 2
  %t376 = load i64, ptr %t375, !tbaa !24
  store i64 %t376, ptr %l23, !tbaa !24
  %t378 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l20, i32 0, i32 3
  %t379 = load i64, ptr %t378, !tbaa !24
  store i64 %t379, ptr %l24, !tbaa !24
  %t381 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l20, i32 0, i32 4
  %t382 = load i64, ptr %t381, !tbaa !24
  store i64 %t382, ptr %l25, !tbaa !24
  %t384 = load ptr, ptr %l0, !tbaa !29
  store ptr %t384, ptr %l209, !tbaa !29
  %t385 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t385, ptr %l210
  %t386 = load i64, ptr %l4, !tbaa !24
  store i64 %t386, ptr %l211, !tbaa !24
  %t387 = load ptr, ptr %lp8
  store ptr %t387, ptr %l212, !tbaa !29
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t389 = load %"compiler/source:Span", ptr %l1
  %t390 = load i64, ptr %l21, !tbaa !24
  %t394 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t388, %"compiler/source:Span" %t389, i64 %t390)
  store ptr %t394, ptr %l216
  br label %bb57
bb57:
  %t395 = load ptr, ptr %l209, !tbaa !29
  %t396 = load %"compiler/source:Span", ptr %l210
  %t397 = load i64, ptr %l211, !tbaa !24
  %t398 = load ptr, ptr %l212, !tbaa !29
  %t399 = load ptr, ptr %l216, !tbaa !29
  %t400 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v0, ptr %t395, %"compiler/source:Span" %t396, i64 %t397, ptr %t398, ptr %t399)
  store ptr %t400, ptr %l217
  br label %bb58
bb58:
  %t401 = load ptr, ptr %l217, !tbaa !29
  store ptr %t401, ptr %l26, !tbaa !29
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t404 = getelementptr %"compiler/check:Checker", ptr %t402, i32 0, i32 37
  %t406 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t404)
  store i64 %t406, ptr %l220
  br label %bb59
bb59:
  %t407 = load i64, ptr %l220, !tbaa !24
  store i64 %t407, ptr %l27, !tbaa !24
  %t408 = load ptr, ptr %l0, !tbaa !29
  %t410 = getelementptr %"compiler/check:Checker", ptr %t408, i32 0, i32 37
  store ptr %t410, ptr %l222, !tbaa !29
  %t411 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t411, ptr %l223
  %t412 = load %"compiler/source:Span", ptr %l1
  %t413 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t414 = load i64, ptr %l19, !tbaa !24
  %t416 = trunc i64 %t414 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t418
  %t419 = getelementptr { i64, [4 x i64] }, ptr %t418, i32 0, i32 0
  store i64 0, ptr %t419
  %t421 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t412, 0
  %t423 = insertvalue { %"compiler/source:Span", i32, i32 } %t421, i32 %t413, 1
  %t425 = insertvalue { %"compiler/source:Span", i32, i32 } %t423, i32 %t416, 2
  %t426 = getelementptr { i64, [4 x i64] }, ptr %t418, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t425, ptr %t426
  %t427 = load { i64, [4 x i64] }, ptr %t418
  %t429 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t427, ptr %t429
  store ptr %t429, ptr %l230, !tbaa !29
  %t430 = load ptr, ptr %l0, !tbaa !29
  store ptr %t430, ptr %l231, !tbaa !29
  %t431 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t431, ptr %l232
  %t432 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t432, ptr %l233, !tbaa !23
  %t433 = load i1, ptr %l18, !tbaa !21
  br i1 %t433, label %bb60, label %bb61
bb60:
  store i64 1, ptr %l235, !tbaa !24
  br label %bb62
bb61:
  store i64 0, ptr %l235, !tbaa !24
  br label %bb62
bb62:
  %t435 = load ptr, ptr %l231, !tbaa !29
  %t436 = load %"compiler/source:Span", ptr %l232
  %t437 = load i32, ptr %l233, !tbaa !23
  %t438 = load i64, ptr %l235, !tbaa !24
  %t439 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t435, %"compiler/source:Span" %t436, i32 %t437, i64 %t438)
  store ptr %t439, ptr %l236
  br label %bb63
bb63:
  store { i64, [3 x i64] } zeroinitializer, ptr %t440
  %t441 = getelementptr { i64, [3 x i64] }, ptr %t440, i32 0, i32 0
  store i64 1, ptr %t441
  %t442 = load %"compiler/source:Span", ptr %l223
  %t443 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t442, 0
  %t444 = load ptr, ptr %l230, !tbaa !29
  %t445 = insertvalue { %"compiler/source:Span", ptr, ptr } %t443, ptr %t444, 1
  %t446 = load ptr, ptr %l236, !tbaa !29
  %t447 = insertvalue { %"compiler/source:Span", ptr, ptr } %t445, ptr %t446, 2
  %t448 = getelementptr { i64, [3 x i64] }, ptr %t440, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t447, ptr %t448
  %t449 = load { i64, [3 x i64] }, ptr %t440
  %t451 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t449, ptr %t451
  %t452 = load ptr, ptr %l222, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t452, ptr %t451)
  br label %bb64
bb64:
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t456 = getelementptr %"compiler/check:Checker", ptr %t454, i32 0, i32 37
  %t457 = load %"compiler/source:Span", ptr %l1
  %t458 = load i64, ptr %l22, !tbaa !24
  %t460 = trunc i64 %t458 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t462
  %t463 = getelementptr { i64, [3 x i64] }, ptr %t462, i32 0, i32 0
  store i64 5, ptr %t463
  %t465 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t457, 0
  %t467 = insertvalue { %"compiler/source:Span", i32, i32 } %t465, i32 0, 1
  %t469 = insertvalue { %"compiler/source:Span", i32, i32 } %t467, i32 %t460, 2
  %t470 = getelementptr { i64, [3 x i64] }, ptr %t462, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t469, ptr %t470
  %t471 = load { i64, [3 x i64] }, ptr %t462
  %t473 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t471, ptr %t473
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t456, ptr %t473)
  br label %bb65
bb65:
  %t476 = load ptr, ptr %l0, !tbaa !29
  %t478 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t476)
  store ptr %t478, ptr %l249
  br label %bb66
bb66:
  %t479 = load ptr, ptr %l249, !tbaa !29
  %t481 = getelementptr %"compiler/check:frame", ptr %t479, i32 0, i32 7
  %t482 = load i64, ptr %t481, !tbaa !24
  %t484 = trunc i64 %t482 to i32
  store i32 %t484, ptr %l253, !tbaa !23
  %t486 = load ptr, ptr %l0, !tbaa !29
  %t488 = getelementptr %"compiler/check:Checker", ptr %t486, i32 0, i32 37
  %t489 = load i64, ptr %l27, !tbaa !24
  %t492 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t488, i64 %t489)
  store { i64, ptr } %t492, ptr %l257
  br label %bb67
bb67:
  %t493 = load i32, ptr %l253, !tbaa !23
  %t494 = load { i64, ptr }, ptr %l257, !tbaa !27
  %t495 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 %t493, { i64, ptr } %t494)
  store %"compiler/typed:Block" %t495, ptr %l258
  br label %bb68
bb68:
  %t496 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store ptr %t496, ptr %lp28
  %t497 = load %"compiler/typed:Block", ptr %l258
  %t498 = load ptr, ptr %lp28
  store %"compiler/typed:Block" %t497, ptr %t498
  %t499 = load ptr, ptr %l0, !tbaa !29
  store ptr %t499, ptr %l259, !tbaa !29
  %t500 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t500, ptr %l260
  %t501 = load i1, ptr %l18, !tbaa !21
  br i1 %t501, label %bb69, label %bb70
bb69:
  %t503 = load ptr, ptr %l26, !tbaa !29
  store ptr %t503, ptr %l262, !tbaa !29
  br label %bb72
bb70:
  %t505 = load ptr, ptr %l0, !tbaa !29
  %t506 = load %"compiler/source:Span", ptr %l1
  %t507 = load ptr, ptr %l26, !tbaa !29
  %t511 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %t505, %"compiler/source:Span" %t506, ptr %t507)
  store ptr %t511, ptr %l267
  br label %bb71
bb71:
  %t512 = load ptr, ptr %l267, !tbaa !29
  store ptr %t512, ptr %l262, !tbaa !29
  br label %bb72
bb72:
  %t513 = load ptr, ptr %lp28
  %t514 = load ptr, ptr %l262, !tbaa !29
  %t516 = call %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t514, ptr %t513, ptr null)
  store %"compiler/typed:If" %t516, ptr %l269
  br label %bb73
bb73:
  %t517 = load %"compiler/typed:If", ptr %l269
  %t518 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:If" %t517, ptr %t518
  store { i64, [3 x i64] } zeroinitializer, ptr %t519
  %t520 = getelementptr { i64, [3 x i64] }, ptr %t519, i32 0, i32 0
  store i64 3, ptr %t520
  %t521 = load %"compiler/source:Span", ptr %l260
  %t522 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t521, 0
  %t524 = insertvalue { %"compiler/source:Span", ptr } %t522, ptr %t518, 1
  %t525 = getelementptr { i64, [3 x i64] }, ptr %t519, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t524, ptr %t525
  %t526 = load { i64, [3 x i64] }, ptr %t519
  %t528 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t526, ptr %t528
  %t529 = load ptr, ptr %l259, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t529, ptr %t528)
  br label %bb74
bb74:
  %t531 = load ptr, ptr %l0, !tbaa !29
  %t532 = load %"compiler/source:Span", ptr %l1
  %t533 = load i64, ptr %l21, !tbaa !24
  %t534 = load i64, ptr %l22, !tbaa !24
  %t535 = load i64, ptr %l23, !tbaa !24
  %t536 = load i64, ptr %l24, !tbaa !24
  %t537 = load i64, ptr %l25, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLoopClose(ptr %v0, ptr %t531, %"compiler/source:Span" %t532, i64 %t533, i64 %t534, i64 %t535, i64 %t536, i64 %t537)
  br label %bb75
bb75:
  %t545 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t545, ptr %l280
  %t546 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t546, ptr %l281, !tbaa !23
  %t547 = load ptr, ptr %l0, !tbaa !29
  %t549 = getelementptr %"compiler/check:Checker", ptr %t547, i32 0, i32 37
  %t550 = load i64, ptr %l7, !tbaa !24
  %t553 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t549, i64 %t550)
  store { i64, ptr } %t553, ptr %l285
  br label %bb76
bb76:
  %t554 = load ptr, ptr %l0, !tbaa !29
  %t555 = load %"compiler/source:Span", ptr %l1
  %t556 = load i64, ptr %l19, !tbaa !24
  %t560 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t554, %"compiler/source:Span" %t555, i64 %t556)
  store ptr %t560, ptr %l289
  br label %bb77
bb77:
  %t561 = load ptr, ptr %l289, !tbaa !29
  %t562 = load { i64, ptr }, ptr %l285, !tbaa !27
  %t564 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t562, ptr %t561)
  store %"compiler/typed:Seq" %t564, ptr %l291
  br label %bb78
bb78:
  %t565 = load %"compiler/typed:Seq", ptr %l291
  %t566 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Seq" %t565, ptr %t566
  store { i64, [5 x i64] } zeroinitializer, ptr %t567
  %t568 = getelementptr { i64, [5 x i64] }, ptr %t567, i32 0, i32 0
  store i64 12, ptr %t568
  %t569 = load %"compiler/source:Span", ptr %l280
  %t570 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t569, 0
  %t571 = load i32, ptr %l281, !tbaa !23
  %t572 = insertvalue { %"compiler/source:Span", i32, ptr } %t570, i32 %t571, 1
  %t574 = insertvalue { %"compiler/source:Span", i32, ptr } %t572, ptr %t566, 2
  %t575 = getelementptr { i64, [5 x i64] }, ptr %t567, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t574, ptr %t575
  %t576 = load { i64, [5 x i64] }, ptr %t567
  %t578 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t576, ptr %t578
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t578, ptr %rv
  br label %ret
bb79:
  %t580 = load ptr, ptr %l0, !tbaa !29
  store ptr %t580, ptr %l295, !tbaa !29
  %t581 = load ptr, ptr %l0, !tbaa !29
  %t583 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t581, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d23, i32 0, i32 1) }, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d24, i32 0, i32 1) }, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d25, i32 0, i32 1) })
  store i32 %t583, ptr %l297
  br label %bb80
bb80:
  %t584 = mul i64 1, 4
  %t585 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t584)
  %t586 = insertvalue { i64, ptr } undef, i64 1, 0
  %t587 = insertvalue { i64, ptr } %t586, ptr %t585, 1
  store { i64, ptr } %t587, ptr %l298, !tbaa !27
  %t588 = load i32, ptr %l297, !tbaa !23
  %t589 = getelementptr { i64, ptr }, ptr %l298, i32 0, i32 1
  %t590 = load ptr, ptr %t589, !tbaa !27
  %t591 = getelementptr i32, ptr %t590, i64 0
  store i32 %t588, ptr %t591, !tbaa !33
  %t592 = load %"compiler/source:Span", ptr %l2
  %t593 = load ptr, ptr %l295, !tbaa !29
  %t594 = load { i64, ptr }, ptr %l298, !tbaa !27
  %t596 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailOp(ptr %v0, ptr %s0, ptr %t593, { i64, ptr } %t594, %"compiler/source:Span" %t592, i1 false)
  store i32 %t596, ptr %l300
  br label %bb81
bb81:
  %t597 = load i32, ptr %l300, !range !{i32 0, i32 3}
  %t598 = load ptr, ptr %l0, !tbaa !29
  store ptr %t598, ptr %l301, !tbaa !29
  %t599 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t599, ptr %l302
  %t600 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t600, ptr %l303
  %t601 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t601, ptr %l304, !tbaa !23
  store i32 39, ptr %l305
  store i32 %t597, ptr %l306
  %t603 = load ptr, ptr %l0, !tbaa !29
  %t604 = load ptr, ptr %l9, !tbaa !29
  %t607 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %t603, ptr %t604)
  store { i64, ptr } %t607, ptr %l309
  br label %bb82
bb82:
  store { i64, [5 x i64] } zeroinitializer, ptr %t608
  %t609 = getelementptr { i64, [5 x i64] }, ptr %t608, i32 0, i32 0
  store i64 9, ptr %t609
  %t610 = load %"compiler/source:Span", ptr %l303
  %t611 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t610, 0
  %t612 = load i32, ptr %l304, !tbaa !23
  %t613 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t611, i32 %t612, 1
  %t614 = load i32, ptr %l305, !range !{i32 0, i32 43}
  %t615 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t613, i32 %t614, 2
  %t616 = load i32, ptr %l306, !range !{i32 0, i32 3}
  %t617 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t615, i32 %t616, 3
  %t618 = load { i64, ptr }, ptr %l309, !tbaa !27
  %t619 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t617, { i64, ptr } %t618, 4
  %t620 = getelementptr { i64, [5 x i64] }, ptr %t608, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t619, ptr %t620
  %t621 = load { i64, [5 x i64] }, ptr %t608
  %t623 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t621, ptr %t623
  store { i64, [3 x i64] } zeroinitializer, ptr %t624
  %t625 = getelementptr { i64, [3 x i64] }, ptr %t624, i32 0, i32 0
  store i64 2, ptr %t625
  %t626 = load %"compiler/source:Span", ptr %l302
  %t627 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t626, 0
  %t629 = insertvalue { %"compiler/source:Span", ptr } %t627, ptr %t623, 1
  %t630 = getelementptr { i64, [3 x i64] }, ptr %t624, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t629, ptr %t630
  %t631 = load { i64, [3 x i64] }, ptr %t624
  %t633 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t631, ptr %t633
  %t634 = load ptr, ptr %l301, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t634, ptr %t633)
  br label %bb83
bb83:
  %t636 = load ptr, ptr %l0, !tbaa !29
  store ptr %t636, ptr %l314, !tbaa !29
  %t637 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t637, ptr %l315
  %t638 = load ptr, ptr %l0, !tbaa !29
  %t640 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t638)
  store i32 %t640, ptr %l317
  br label %bb84
bb84:
  %t641 = load ptr, ptr %l314, !tbaa !29
  %t642 = load %"compiler/source:Span", ptr %l315
  %t643 = load i32, ptr %l317, !tbaa !23
  %t644 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t641, %"compiler/source:Span" %t642, i32 %t643)
  store i64 %t644, ptr %l318
  br label %bb85
bb85:
  %t645 = load i64, ptr %l318, !tbaa !24
  store i64 %t645, ptr %l30, !tbaa !24
  %t646 = load ptr, ptr %l0, !tbaa !29
  store ptr %t646, ptr %l319, !tbaa !29
  %t647 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t647, ptr %l320
  %t648 = load i64, ptr %l30, !tbaa !24
  %t650 = trunc i64 %t648 to i32
  store i32 %t650, ptr %l323, !tbaa !23
  %t652 = load ptr, ptr %l0, !tbaa !29
  store ptr %t652, ptr %l324, !tbaa !29
  %t653 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t653, ptr %l325
  %t654 = load ptr, ptr %l0, !tbaa !29
  %t656 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t654)
  store i32 %t656, ptr %l327
  br label %bb86
bb86:
  %t657 = load ptr, ptr %l324, !tbaa !29
  %t658 = load %"compiler/source:Span", ptr %l325
  %t659 = load i32, ptr %l327, !tbaa !23
  %t660 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t657, %"compiler/source:Span" %t658, i32 %t659, i64 0)
  store ptr %t660, ptr %l328
  br label %bb87
bb87:
  store { i64, [3 x i64] } zeroinitializer, ptr %t661
  %t662 = getelementptr { i64, [3 x i64] }, ptr %t661, i32 0, i32 0
  store i64 0, ptr %t662
  %t663 = load %"compiler/source:Span", ptr %l320
  %t664 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t663, 0
  %t665 = load i32, ptr %l323, !tbaa !23
  %t666 = insertvalue { %"compiler/source:Span", i32, ptr } %t664, i32 %t665, 1
  %t667 = load ptr, ptr %l328, !tbaa !29
  %t668 = insertvalue { %"compiler/source:Span", i32, ptr } %t666, ptr %t667, 2
  %t669 = getelementptr { i64, [3 x i64] }, ptr %t661, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t668, ptr %t669
  %t670 = load { i64, [3 x i64] }, ptr %t661
  %t672 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t670, ptr %t672
  %t673 = load ptr, ptr %l319, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t673, ptr %t672)
  br label %bb88
bb88:
  %t675 = load ptr, ptr %l0, !tbaa !29
  %t677 = getelementptr %"compiler/check:Checker", ptr %t675, i32 0, i32 1
  %t678 = load ptr, ptr %t677, !tbaa !29
  %t680 = getelementptr %"compiler/generic:Program", ptr %t678, i32 0, i32 0
  %t681 = load ptr, ptr %t680, !tbaa !29
  %t683 = getelementptr %"compiler/load:Loader", ptr %t681, i32 0, i32 4
  %t684 = load ptr, ptr %t683, !tbaa !29
  %t686 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %t684)
  store i64 %t686, ptr %l335
  br label %bb89
bb89:
  %t687 = load i64, ptr %l335, !tbaa !24
  store i64 %t687, ptr %l31, !tbaa !24
  %t688 = load ptr, ptr %l0, !tbaa !29
  store ptr %t688, ptr %l336, !tbaa !29
  %t689 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t689, ptr %l337
  %t690 = load i64, ptr %l4, !tbaa !24
  store i64 %t690, ptr %l338, !tbaa !24
  %t691 = load ptr, ptr %lp8
  store ptr %t691, ptr %l339, !tbaa !29
  %t692 = load ptr, ptr %l0, !tbaa !29
  %t693 = load %"compiler/source:Span", ptr %l1
  %t694 = load i64, ptr %l30, !tbaa !24
  %t698 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t692, %"compiler/source:Span" %t693, i64 %t694)
  store ptr %t698, ptr %l343
  br label %bb90
bb90:
  %t699 = load ptr, ptr %l336, !tbaa !29
  %t700 = load %"compiler/source:Span", ptr %l337
  %t701 = load i64, ptr %l338, !tbaa !24
  %t702 = load ptr, ptr %l339, !tbaa !29
  %t703 = load ptr, ptr %l343, !tbaa !29
  %t704 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v0, ptr %t699, %"compiler/source:Span" %t700, i64 %t701, ptr %t702, ptr %t703)
  store ptr %t704, ptr %l344
  br label %bb91
bb91:
  %t705 = load ptr, ptr %l344, !tbaa !29
  store ptr %t705, ptr %l32, !tbaa !29
  %t706 = load ptr, ptr %l0, !tbaa !29
  %t708 = getelementptr %"compiler/check:Checker", ptr %t706, i32 0, i32 1
  %t709 = load ptr, ptr %t708, !tbaa !29
  %t711 = getelementptr %"compiler/generic:Program", ptr %t709, i32 0, i32 0
  %t712 = load ptr, ptr %t711, !tbaa !29
  %t714 = getelementptr %"compiler/load:Loader", ptr %t712, i32 0, i32 4
  %t715 = load ptr, ptr %t714, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t715)
  br label %bb92
bb92:
  %t717 = load ptr, ptr %l0, !tbaa !29
  %t719 = getelementptr %"compiler/check:Checker", ptr %t717, i32 0, i32 1
  %t720 = load ptr, ptr %t719, !tbaa !29
  %t722 = getelementptr %"compiler/generic:Program", ptr %t720, i32 0, i32 0
  %t723 = load ptr, ptr %t722, !tbaa !29
  %t725 = getelementptr %"compiler/load:Loader", ptr %t723, i32 0, i32 4
  %t726 = load ptr, ptr %t725, !tbaa !29
  %t727 = load i64, ptr %l31, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eDrop(ptr %v0, ptr %t726, i64 %t727)
  br label %bb93
bb93:
  %t730 = load ptr, ptr %l0, !tbaa !29
  %t731 = load %"compiler/source:Span", ptr %l1
  %t732 = load i32, ptr %l6, !tbaa !23
  %t736 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t730, %"compiler/source:Span" %t731, i32 %t732)
  store i64 %t736, ptr %l357
  br label %bb94
bb94:
  %t737 = load i64, ptr %l357, !tbaa !24
  store i64 %t737, ptr %l33, !tbaa !24
  %t738 = load ptr, ptr %l0, !tbaa !29
  store ptr %t738, ptr %l358, !tbaa !29
  %t739 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t739, ptr %l359
  %t740 = load i64, ptr %l33, !tbaa !24
  %t742 = trunc i64 %t740 to i32
  store i32 %t742, ptr %l362, !tbaa !23
  %t744 = load ptr, ptr %l0, !tbaa !29
  %t745 = load ptr, ptr %l32, !tbaa !29
  %t746 = load i32, ptr %l6, !tbaa !23
  %t747 = load %"compiler/source:Span", ptr %l1
  %t752 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t744, ptr %t745, i32 %t746, %"compiler/source:Span" %t747)
  store ptr %t752, ptr %l367
  br label %bb95
bb95:
  store { i64, [3 x i64] } zeroinitializer, ptr %t753
  %t754 = getelementptr { i64, [3 x i64] }, ptr %t753, i32 0, i32 0
  store i64 0, ptr %t754
  %t755 = load %"compiler/source:Span", ptr %l359
  %t756 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t755, 0
  %t757 = load i32, ptr %l362, !tbaa !23
  %t758 = insertvalue { %"compiler/source:Span", i32, ptr } %t756, i32 %t757, 1
  %t759 = load ptr, ptr %l367, !tbaa !29
  %t760 = insertvalue { %"compiler/source:Span", i32, ptr } %t758, ptr %t759, 2
  %t761 = getelementptr { i64, [3 x i64] }, ptr %t753, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t760, ptr %t761
  %t762 = load { i64, [3 x i64] }, ptr %t753
  %t764 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t762, ptr %t764
  %t765 = load ptr, ptr %l358, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t765, ptr %t764)
  br label %bb96
bb96:
  %t767 = load ptr, ptr %l0, !tbaa !29
  store ptr %t767, ptr %l370, !tbaa !29
  %t768 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t768, ptr %l371
  %t769 = load ptr, ptr %l0, !tbaa !29
  %t770 = load %"compiler/source:Span", ptr %l1
  %t771 = load i64, ptr %l4, !tbaa !24
  %t772 = load ptr, ptr %lp8
  %t777 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneCount(ptr %v0, ptr %v0, ptr %t769, %"compiler/source:Span" %t770, i64 %t771, ptr %t772)
  store ptr %t777, ptr %l376
  br label %bb97
bb97:
  %t778 = load ptr, ptr %l370, !tbaa !29
  %t779 = load %"compiler/source:Span", ptr %l371
  %t780 = load ptr, ptr %l376, !tbaa !29
  %t781 = call { i64, i64, i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLoopOpen(ptr %v0, ptr %t778, %"compiler/source:Span" %t779, ptr %t780, i64 1)
  store { i64, i64, i64, i64, i64 } %t781, ptr %l377
  br label %bb98
bb98:
  %t782 = load { i64, i64, i64, i64, i64 }, ptr %l377
  store { i64, i64, i64, i64, i64 } %t782, ptr %l34
  %t783 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l34, i32 0, i32 0
  %t784 = load i64, ptr %t783, !tbaa !24
  store i64 %t784, ptr %l35, !tbaa !24
  %t786 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l34, i32 0, i32 1
  %t787 = load i64, ptr %t786, !tbaa !24
  store i64 %t787, ptr %l36, !tbaa !24
  %t789 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l34, i32 0, i32 2
  %t790 = load i64, ptr %t789, !tbaa !24
  store i64 %t790, ptr %l37, !tbaa !24
  %t792 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l34, i32 0, i32 3
  %t793 = load i64, ptr %t792, !tbaa !24
  store i64 %t793, ptr %l38, !tbaa !24
  %t795 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l34, i32 0, i32 4
  %t796 = load i64, ptr %t795, !tbaa !24
  store i64 %t796, ptr %l39, !tbaa !24
  %t798 = load ptr, ptr %l0, !tbaa !29
  %t799 = load %"compiler/source:Span", ptr %l1
  %t800 = load i32, ptr %l6, !tbaa !23
  %t804 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t798, %"compiler/source:Span" %t799, i32 %t800)
  store i64 %t804, ptr %l386
  br label %bb99
bb99:
  %t805 = load i64, ptr %l386, !tbaa !24
  store i64 %t805, ptr %l40, !tbaa !24
  %t806 = load ptr, ptr %l0, !tbaa !29
  store ptr %t806, ptr %l387, !tbaa !29
  %t807 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t807, ptr %l388
  %t808 = load i64, ptr %l40, !tbaa !24
  %t810 = trunc i64 %t808 to i32
  store i32 %t810, ptr %l391, !tbaa !23
  %t812 = load ptr, ptr %l0, !tbaa !29
  store ptr %t812, ptr %l392, !tbaa !29
  %t813 = load ptr, ptr %l0, !tbaa !29
  store ptr %t813, ptr %l393, !tbaa !29
  %t814 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t814, ptr %l394
  %t815 = load i64, ptr %l4, !tbaa !24
  store i64 %t815, ptr %l395, !tbaa !24
  %t816 = load ptr, ptr %lp8
  store ptr %t816, ptr %l396, !tbaa !29
  %t817 = load ptr, ptr %l0, !tbaa !29
  %t818 = load %"compiler/source:Span", ptr %l1
  %t819 = load i64, ptr %l35, !tbaa !24
  %t823 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t817, %"compiler/source:Span" %t818, i64 %t819)
  store ptr %t823, ptr %l400
  br label %bb100
bb100:
  %t824 = load ptr, ptr %l393, !tbaa !29
  %t825 = load %"compiler/source:Span", ptr %l394
  %t826 = load i64, ptr %l395, !tbaa !24
  %t827 = load ptr, ptr %l396, !tbaa !29
  %t828 = load ptr, ptr %l400, !tbaa !29
  %t829 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v0, ptr %t824, %"compiler/source:Span" %t825, i64 %t826, ptr %t827, ptr %t828)
  store ptr %t829, ptr %l401
  br label %bb101
bb101:
  %t830 = load i32, ptr %l6, !tbaa !23
  %t831 = load %"compiler/source:Span", ptr %l1
  %t832 = load ptr, ptr %l392, !tbaa !29
  %t833 = load ptr, ptr %l401, !tbaa !29
  %t836 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t832, ptr %t833, i32 %t830, %"compiler/source:Span" %t831)
  store ptr %t836, ptr %l404
  br label %bb102
bb102:
  store { i64, [3 x i64] } zeroinitializer, ptr %t837
  %t838 = getelementptr { i64, [3 x i64] }, ptr %t837, i32 0, i32 0
  store i64 0, ptr %t838
  %t839 = load %"compiler/source:Span", ptr %l388
  %t840 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t839, 0
  %t841 = load i32, ptr %l391, !tbaa !23
  %t842 = insertvalue { %"compiler/source:Span", i32, ptr } %t840, i32 %t841, 1
  %t843 = load ptr, ptr %l404, !tbaa !29
  %t844 = insertvalue { %"compiler/source:Span", i32, ptr } %t842, ptr %t843, 2
  %t845 = getelementptr { i64, [3 x i64] }, ptr %t837, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t844, ptr %t845
  %t846 = load { i64, [3 x i64] }, ptr %t837
  %t848 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t846, ptr %t848
  %t849 = load ptr, ptr %l387, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t849, ptr %t848)
  br label %bb103
bb103:
  %t851 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t853 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t851, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d26, i32 0, i32 1) })
  store i1 %t853, ptr %l408
  br label %bb104
bb104:
  %t854 = load i1, ptr %l408, !tbaa !21
  br i1 %t854, label %bb105, label %bb106
bb105:
  %t855 = load ptr, ptr %l0, !tbaa !29
  store ptr %t855, ptr %l410, !tbaa !29
  %t856 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t856, ptr %l411
  %t857 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t857, ptr %l412
  store i32 79, ptr %l413
  %t858 = load ptr, ptr %l0, !tbaa !29
  %t859 = load %"compiler/source:Span", ptr %l1
  %t860 = load i64, ptr %l40, !tbaa !24
  %t864 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t858, %"compiler/source:Span" %t859, i64 %t860)
  store ptr %t864, ptr %l417
  br label %bb107
bb106:
  %t865 = load ptr, ptr %l0, !tbaa !29
  store ptr %t865, ptr %l425, !tbaa !29
  %t866 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t866, ptr %l426
  %t867 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t867, ptr %l427
  store i32 79, ptr %l428
  %t868 = load ptr, ptr %l0, !tbaa !29
  %t869 = load %"compiler/source:Span", ptr %l1
  %t870 = load i64, ptr %l33, !tbaa !24
  %t874 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t868, %"compiler/source:Span" %t869, i64 %t870)
  store ptr %t874, ptr %l432
  br label %bb110
bb107:
  %t875 = load ptr, ptr %l0, !tbaa !29
  %t876 = load %"compiler/source:Span", ptr %l1
  %t877 = load i64, ptr %l33, !tbaa !24
  %t881 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t875, %"compiler/source:Span" %t876, i64 %t877)
  store ptr %t881, ptr %l421
  br label %bb108
bb108:
  %t882 = load %"compiler/source:Span", ptr %l1
  %t883 = load %"compiler/source:Span", ptr %l1
  %t884 = load ptr, ptr %l410, !tbaa !29
  %t885 = load %"compiler/source:Span", ptr %l411
  %t886 = load %"compiler/source:Span", ptr %l412
  %t887 = load i32, ptr %l413, !range !{i32 0, i32 96}
  %t888 = load ptr, ptr %l417, !tbaa !29
  %t889 = load ptr, ptr %l421, !tbaa !29
  %t892 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %t884, %"compiler/source:Span" %t885, %"compiler/source:Span" %t886, i32 %t887, ptr %t888, ptr %t889, %"compiler/source:Span" %t882, %"compiler/source:Span" %t883)
  store ptr %t892, ptr %l424
  br label %bb109
bb109:
  %t893 = load ptr, ptr %l424, !tbaa !29
  store ptr %t893, ptr %l409, !tbaa !29
  br label %bb113
bb110:
  %t894 = load ptr, ptr %l0, !tbaa !29
  %t895 = load %"compiler/source:Span", ptr %l1
  %t896 = load i64, ptr %l40, !tbaa !24
  %t900 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t894, %"compiler/source:Span" %t895, i64 %t896)
  store ptr %t900, ptr %l436
  br label %bb111
bb111:
  %t901 = load %"compiler/source:Span", ptr %l1
  %t902 = load %"compiler/source:Span", ptr %l1
  %t903 = load ptr, ptr %l425, !tbaa !29
  %t904 = load %"compiler/source:Span", ptr %l426
  %t905 = load %"compiler/source:Span", ptr %l427
  %t906 = load i32, ptr %l428, !range !{i32 0, i32 96}
  %t907 = load ptr, ptr %l432, !tbaa !29
  %t908 = load ptr, ptr %l436, !tbaa !29
  %t911 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %t903, %"compiler/source:Span" %t904, %"compiler/source:Span" %t905, i32 %t906, ptr %t907, ptr %t908, %"compiler/source:Span" %t901, %"compiler/source:Span" %t902)
  store ptr %t911, ptr %l439
  br label %bb112
bb112:
  %t912 = load ptr, ptr %l439, !tbaa !29
  store ptr %t912, ptr %l409, !tbaa !29
  br label %bb113
bb113:
  %t913 = load ptr, ptr %l409, !tbaa !29
  store ptr %t913, ptr %l41, !tbaa !29
  %t914 = load ptr, ptr %l0, !tbaa !29
  %t916 = getelementptr %"compiler/check:Checker", ptr %t914, i32 0, i32 1
  %t917 = load ptr, ptr %t916, !tbaa !29
  %t919 = getelementptr %"compiler/generic:Program", ptr %t917, i32 0, i32 2
  store ptr %t919, ptr %l442, !tbaa !29
  %t920 = load ptr, ptr %l0, !tbaa !29
  %t921 = load i32, ptr %l6, !tbaa !23
  %t924 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t920, i32 %t921)
  store i32 %t924, ptr %l445
  br label %bb114
bb114:
  %t925 = load ptr, ptr %l442, !tbaa !29
  %t926 = load i32, ptr %l445, !tbaa !23
  %t927 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t925, i32 %t926)
  store i1 %t927, ptr %l446
  br label %bb115
bb115:
  %t928 = load i1, ptr %l446, !tbaa !21
  br i1 %t928, label %bb116, label %bb117
bb116:
  %t929 = load ptr, ptr %l0, !tbaa !29
  store ptr %t929, ptr %l447, !tbaa !29
  %t930 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t930, ptr %l448
  %t931 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t931, ptr %l449, !tbaa !23
  store i32 14, ptr %l450
  %t932 = load ptr, ptr %l0, !tbaa !29
  %t933 = load %"compiler/source:Span", ptr %l1
  %t934 = load i64, ptr %l40, !tbaa !24
  %t938 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t932, %"compiler/source:Span" %t933, i64 %t934)
  store ptr %t938, ptr %l454
  br label %bb118
bb117:
  br label %bb123
bb118:
  %t939 = load ptr, ptr %l0, !tbaa !29
  %t940 = load %"compiler/source:Span", ptr %l1
  %t941 = load i64, ptr %l40, !tbaa !24
  %t945 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t939, %"compiler/source:Span" %t940, i64 %t941)
  store ptr %t945, ptr %l458
  br label %bb119
bb119:
  %t946 = load ptr, ptr %l458, !tbaa !29
  %t947 = load ptr, ptr %l447, !tbaa !29
  %t948 = load %"compiler/source:Span", ptr %l448
  %t949 = load i32, ptr %l449, !tbaa !23
  %t950 = load i32, ptr %l450, !range !{i32 0, i32 43}
  %t951 = load ptr, ptr %l454, !tbaa !29
  %t953 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t947, %"compiler/source:Span" %t948, i32 %t949, i32 %t950, ptr %t951, ptr %t946)
  store ptr %t953, ptr %l460
  br label %bb120
bb120:
  %t954 = load ptr, ptr %l460, !tbaa !29
  store ptr %t954, ptr %l42, !tbaa !29
  %t955 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t955, ptr %l461
  %t956 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t956, ptr %l462, !tbaa !23
  %t957 = load ptr, ptr %l41, !tbaa !29
  store ptr %t957, ptr %l463, !tbaa !29
  %t958 = load ptr, ptr %l0, !tbaa !29
  %t959 = load %"compiler/source:Span", ptr %l1
  %t960 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t964 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t958, %"compiler/source:Span" %t959, i32 %t960, i64 1)
  store ptr %t964, ptr %l467
  br label %bb121
bb121:
  %t965 = load ptr, ptr %l467, !tbaa !29
  %t966 = load ptr, ptr %l42, !tbaa !29
  %t967 = load ptr, ptr %l463, !tbaa !29
  %t970 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t967, ptr %t965, ptr %t966)
  store %"compiler/typed:Cond" %t970, ptr %l470
  br label %bb122
bb122:
  %t971 = load %"compiler/typed:Cond", ptr %l470
  %t972 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Cond" %t971, ptr %t972
  store { i64, [5 x i64] } zeroinitializer, ptr %t973
  %t974 = getelementptr { i64, [5 x i64] }, ptr %t973, i32 0, i32 0
  store i64 11, ptr %t974
  %t975 = load %"compiler/source:Span", ptr %l461
  %t976 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t975, 0
  %t977 = load i32, ptr %l462, !tbaa !23
  %t978 = insertvalue { %"compiler/source:Span", i32, ptr } %t976, i32 %t977, 1
  %t980 = insertvalue { %"compiler/source:Span", i32, ptr } %t978, ptr %t972, 2
  %t981 = getelementptr { i64, [5 x i64] }, ptr %t973, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t980, ptr %t981
  %t982 = load { i64, [5 x i64] }, ptr %t973
  %t984 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t982, ptr %t984
  store ptr %t984, ptr %l41, !tbaa !29
  br label %bb123
bb123:
  %t986 = load ptr, ptr %l0, !tbaa !29
  %t988 = getelementptr %"compiler/check:Checker", ptr %t986, i32 0, i32 37
  %t990 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t988)
  store i64 %t990, ptr %l476
  br label %bb124
bb124:
  %t991 = load i64, ptr %l476, !tbaa !24
  store i64 %t991, ptr %l43, !tbaa !24
  %t992 = load ptr, ptr %l0, !tbaa !29
  %t994 = getelementptr %"compiler/check:Checker", ptr %t992, i32 0, i32 37
  store ptr %t994, ptr %l478, !tbaa !29
  %t995 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t995, ptr %l479
  %t996 = load %"compiler/source:Span", ptr %l1
  %t997 = load i32, ptr %l6, !tbaa !23
  %t998 = load i64, ptr %l33, !tbaa !24
  %t1000 = trunc i64 %t998 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t1002
  %t1003 = getelementptr { i64, [4 x i64] }, ptr %t1002, i32 0, i32 0
  store i64 0, ptr %t1003
  %t1005 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t996, 0
  %t1007 = insertvalue { %"compiler/source:Span", i32, i32 } %t1005, i32 %t997, 1
  %t1009 = insertvalue { %"compiler/source:Span", i32, i32 } %t1007, i32 %t1000, 2
  %t1010 = getelementptr { i64, [4 x i64] }, ptr %t1002, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t1009, ptr %t1010
  %t1011 = load { i64, [4 x i64] }, ptr %t1002
  %t1013 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t1011, ptr %t1013
  store ptr %t1013, ptr %l486, !tbaa !29
  %t1014 = load ptr, ptr %l0, !tbaa !29
  %t1015 = load %"compiler/source:Span", ptr %l1
  %t1016 = load i64, ptr %l40, !tbaa !24
  %t1020 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t1014, %"compiler/source:Span" %t1015, i64 %t1016)
  store ptr %t1020, ptr %l490
  br label %bb125
bb125:
  store { i64, [3 x i64] } zeroinitializer, ptr %t1021
  %t1022 = getelementptr { i64, [3 x i64] }, ptr %t1021, i32 0, i32 0
  store i64 1, ptr %t1022
  %t1023 = load %"compiler/source:Span", ptr %l479
  %t1024 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t1023, 0
  %t1025 = load ptr, ptr %l486, !tbaa !29
  %t1026 = insertvalue { %"compiler/source:Span", ptr, ptr } %t1024, ptr %t1025, 1
  %t1027 = load ptr, ptr %l490, !tbaa !29
  %t1028 = insertvalue { %"compiler/source:Span", ptr, ptr } %t1026, ptr %t1027, 2
  %t1029 = getelementptr { i64, [3 x i64] }, ptr %t1021, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t1028, ptr %t1029
  %t1030 = load { i64, [3 x i64] }, ptr %t1021
  %t1032 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t1030, ptr %t1032
  %t1033 = load ptr, ptr %l478, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t1033, ptr %t1032)
  br label %bb126
bb126:
  %t1035 = load ptr, ptr %l0, !tbaa !29
  %t1037 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1035)
  store ptr %t1037, ptr %l494
  br label %bb127
bb127:
  %t1038 = load ptr, ptr %l494, !tbaa !29
  %t1040 = getelementptr %"compiler/check:frame", ptr %t1038, i32 0, i32 7
  %t1041 = load i64, ptr %t1040, !tbaa !24
  %t1043 = trunc i64 %t1041 to i32
  store i32 %t1043, ptr %l498, !tbaa !23
  %t1045 = load ptr, ptr %l0, !tbaa !29
  %t1047 = getelementptr %"compiler/check:Checker", ptr %t1045, i32 0, i32 37
  %t1048 = load i64, ptr %l43, !tbaa !24
  %t1051 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t1047, i64 %t1048)
  store { i64, ptr } %t1051, ptr %l502
  br label %bb128
bb128:
  %t1052 = load i32, ptr %l498, !tbaa !23
  %t1053 = load { i64, ptr }, ptr %l502, !tbaa !27
  %t1054 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 %t1052, { i64, ptr } %t1053)
  store %"compiler/typed:Block" %t1054, ptr %l503
  br label %bb129
bb129:
  %t1055 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store ptr %t1055, ptr %lp44
  %t1056 = load %"compiler/typed:Block", ptr %l503
  %t1057 = load ptr, ptr %lp44
  store %"compiler/typed:Block" %t1056, ptr %t1057
  %t1058 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1058, ptr %l504, !tbaa !29
  %t1059 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1059, ptr %l505
  %t1060 = load ptr, ptr %l41, !tbaa !29
  %t1061 = load ptr, ptr %lp44
  %t1064 = call %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t1060, ptr %t1061, ptr null)
  store %"compiler/typed:If" %t1064, ptr %l508
  br label %bb130
bb130:
  %t1065 = load %"compiler/typed:If", ptr %l508
  %t1066 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:If" %t1065, ptr %t1066
  store { i64, [3 x i64] } zeroinitializer, ptr %t1067
  %t1068 = getelementptr { i64, [3 x i64] }, ptr %t1067, i32 0, i32 0
  store i64 3, ptr %t1068
  %t1069 = load %"compiler/source:Span", ptr %l505
  %t1070 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t1069, 0
  %t1072 = insertvalue { %"compiler/source:Span", ptr } %t1070, ptr %t1066, 1
  %t1073 = getelementptr { i64, [3 x i64] }, ptr %t1067, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t1072, ptr %t1073
  %t1074 = load { i64, [3 x i64] }, ptr %t1067
  %t1076 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t1074, ptr %t1076
  %t1077 = load ptr, ptr %l504, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t1077, ptr %t1076)
  br label %bb131
bb131:
  %t1079 = load ptr, ptr %l0, !tbaa !29
  %t1080 = load %"compiler/source:Span", ptr %l1
  %t1081 = load i64, ptr %l35, !tbaa !24
  %t1082 = load i64, ptr %l36, !tbaa !24
  %t1083 = load i64, ptr %l37, !tbaa !24
  %t1084 = load i64, ptr %l38, !tbaa !24
  %t1085 = load i64, ptr %l39, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLoopClose(ptr %v0, ptr %t1079, %"compiler/source:Span" %t1080, i64 %t1081, i64 %t1082, i64 %t1083, i64 %t1084, i64 %t1085)
  br label %bb132
bb132:
  %t1093 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1093, ptr %l519
  %t1094 = load i32, ptr %l6, !tbaa !23
  store i32 %t1094, ptr %l520, !tbaa !23
  %t1095 = load ptr, ptr %l0, !tbaa !29
  %t1097 = getelementptr %"compiler/check:Checker", ptr %t1095, i32 0, i32 37
  %t1098 = load i64, ptr %l7, !tbaa !24
  %t1101 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t1097, i64 %t1098)
  store { i64, ptr } %t1101, ptr %l524
  br label %bb133
bb133:
  %t1102 = load ptr, ptr %l0, !tbaa !29
  %t1103 = load %"compiler/source:Span", ptr %l1
  %t1104 = load i64, ptr %l33, !tbaa !24
  %t1108 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t1102, %"compiler/source:Span" %t1103, i64 %t1104)
  store ptr %t1108, ptr %l528
  br label %bb134
bb134:
  %t1109 = load ptr, ptr %l528, !tbaa !29
  %t1110 = load { i64, ptr }, ptr %l524, !tbaa !27
  %t1112 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t1110, ptr %t1109)
  store %"compiler/typed:Seq" %t1112, ptr %l530
  br label %bb135
bb135:
  %t1113 = load %"compiler/typed:Seq", ptr %l530
  %t1114 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Seq" %t1113, ptr %t1114
  store { i64, [5 x i64] } zeroinitializer, ptr %t1115
  %t1116 = getelementptr { i64, [5 x i64] }, ptr %t1115, i32 0, i32 0
  store i64 12, ptr %t1116
  %t1117 = load %"compiler/source:Span", ptr %l519
  %t1118 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1117, 0
  %t1119 = load i32, ptr %l520, !tbaa !23
  %t1120 = insertvalue { %"compiler/source:Span", i32, ptr } %t1118, i32 %t1119, 1
  %t1122 = insertvalue { %"compiler/source:Span", i32, ptr } %t1120, ptr %t1114, 2
  %t1123 = getelementptr { i64, [5 x i64] }, ptr %t1115, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1122, ptr %t1123
  %t1124 = load { i64, [5 x i64] }, ptr %t1115
  %t1126 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t1124, ptr %t1126
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1126, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elastName(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca { i64, ptr }
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l22 = alloca i1
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l42 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = load %"compiler/source:Span", ptr %l1
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %a0, %"compiler/source:Span" %t2)
  store { i64, ptr } %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l12, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = sub i64 %t16, 1
  %t20 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 %t18
  %t23 = load i8, ptr %t22, !tbaa !32
  %t25 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t23)
  store i1 %t25, ptr %l16
  br label %bb5
bb4:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb13
bb5:
  %t26 = load i1, ptr %l16, !tbaa !21
  br i1 %t26, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb9
bb7:
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t27, ptr %l18, !tbaa !27
  %t28 = load i64, ptr %l3, !tbaa !24
  %t30 = sub i64 %t28, 1
  %t32 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr i8, ptr %t33, i64 %t30
  %t35 = load i8, ptr %t34, !tbaa !32
  %t37 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t35)
  store i1 %t37, ptr %l22
  br label %bb8
bb8:
  %t38 = load i1, ptr %l22, !tbaa !21
  store i1 %t38, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t39 = load i1, ptr %l17, !tbaa !21
  br i1 %t39, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb12
bb11:
  %t40 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t40, ptr %l24, !tbaa !27
  %t41 = load i64, ptr %l3, !tbaa !24
  %t43 = sub i64 %t41, 1
  %t45 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr i8, ptr %t46, i64 %t43
  %t48 = load i8, ptr %t47, !tbaa !32
  %t50 = icmp eq i8 %t48, 95
  store i1 %t50, ptr %l23, !tbaa !21
  br label %bb12
bb12:
  %t52 = load i1, ptr %l23, !tbaa !21
  store i1 %t52, ptr %l11, !tbaa !21
  br label %bb13
bb13:
  %t53 = load i1, ptr %l11, !tbaa !21
  %t54 = xor i1 %t53, true
  br i1 %t54, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t56 = load i64, ptr %l3, !tbaa !24
  %t58 = sub i64 %t56, 1
  store i64 %t58, ptr %l3, !tbaa !24
  br label %bb17
bb17:
  br label %bb2
bb18:
  %t60 = load i64, ptr %l3, !tbaa !24
  %t61 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t66 = icmp eq i64 %t60, %t63
  br i1 %t66, label %bb19, label %bb20
bb19:
  %t68 = load %"compiler/source:Span", ptr %l1
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/source:Span" %t68, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t70 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t71 = load i32, ptr %t70, !tbaa !23
  %t72 = load i64, ptr %l3, !tbaa !24
  %t74 = trunc i64 %t72 to i32
  %t77 = add i32 %t71, %t74
  %t78 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t79 = load i32, ptr %t78, !tbaa !23
  %t82 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t77, i32 %t79)
  store %"compiler/source:Span" %t82, ptr %l42
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t83 = load %"compiler/source:Span", ptr %l42
  store %"compiler/source:Span" %t83, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsBy(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l12 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l24 = alloca i1
  %l30 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t6, i32 %a1)
  store { i64, ptr } %t10, ptr %l12
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  %t16 = load i64, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l6, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb3, label %bb4
bb3:
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t24 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t24, ptr %l19, !tbaa !27
  %t25 = load i64, ptr %l5, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i32, ptr %t28, i64 %t25
  %t30 = load i32, ptr %t29, !tbaa !33
  store i32 %t30, ptr %l7, !tbaa !23
  %t32 = load i32, ptr %l7, !tbaa !23
  %t34 = icmp ne i32 %t32, 0
  br i1 %t34, label %bb6, label %bb7
bb6:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l7, !tbaa !23
  %t41 = add i64 %a3, 1
  %t46 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsBy(ptr %v0, ptr %t36, i32 %t37, i32 %a2, i64 %t41)
  store i1 %t46, ptr %l30
  br label %bb8
bb7:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb9
bb8:
  %t47 = load i1, ptr %l30, !tbaa !21
  store i1 %t47, ptr %l24, !tbaa !21
  br label %bb9
bb9:
  %t48 = load i1, ptr %l24, !tbaa !21
  br i1 %t48, label %bb10, label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t50 = load i64, ptr %l5, !tbaa !24
  %t52 = add i64 %t50, 1
  store i64 %t52, ptr %l5, !tbaa !24
  br label %bb2
bb14:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsInst(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l12 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l24 = alloca i1
  %l30 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t6, i32 %a1)
  store { i64, ptr } %t10, ptr %l12
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  %t16 = load i64, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l6, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb3, label %bb4
bb3:
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t24 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t24, ptr %l19, !tbaa !27
  %t25 = load i64, ptr %l5, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i32, ptr %t28, i64 %t25
  %t30 = load i32, ptr %t29, !tbaa !33
  store i32 %t30, ptr %l7, !tbaa !23
  %t32 = load i32, ptr %l7, !tbaa !23
  %t34 = icmp ne i32 %t32, 0
  br i1 %t34, label %bb6, label %bb7
bb6:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l7, !tbaa !23
  %t41 = add i64 %a3, 1
  %t46 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsInst(ptr %v0, ptr %t36, i32 %t37, i32 %a2, i64 %t41)
  store i1 %t46, ptr %l30
  br label %bb8
bb7:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb9
bb8:
  %t47 = load i1, ptr %l30, !tbaa !21
  store i1 %t47, ptr %l24, !tbaa !21
  br label %bb9
bb9:
  %t48 = load i1, ptr %l24, !tbaa !21
  br i1 %t48, label %bb10, label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t50 = load i64, ptr %l5, !tbaa !24
  %t52 = add i64 %t50, 1
  store i64 %t52, ptr %l5, !tbaa !24
  br label %bb2
bb14:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsWritable(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l11 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l23 = alloca i1
  %l28 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t6, i32 %a1)
  store { i64, ptr } %t10, ptr %l11
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t16 = load i64, ptr %l4, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb3, label %bb4
bb3:
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t24, ptr %l18, !tbaa !27
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i32, ptr %t28, i64 %t25
  %t30 = load i32, ptr %t29, !tbaa !33
  store i32 %t30, ptr %l6, !tbaa !23
  %t32 = load i32, ptr %l6, !tbaa !23
  %t34 = icmp ne i32 %t32, 0
  br i1 %t34, label %bb6, label %bb7
bb6:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l6, !tbaa !23
  %t40 = add i64 %a2, 1
  %t44 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritableAt(ptr %v0, ptr %t36, i32 %t37, i64 %t40)
  store i1 %t44, ptr %l28
  br label %bb8
bb7:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb9
bb8:
  %t45 = load i1, ptr %l28, !tbaa !21
  store i1 %t45, ptr %l23, !tbaa !21
  br label %bb9
bb9:
  %t46 = load i1, ptr %l23, !tbaa !21
  br i1 %t46, label %bb10, label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t48 = load i64, ptr %l4, !tbaa !24
  %t50 = add i64 %t48, 1
  store i64 %t50, ptr %l4, !tbaa !24
  br label %bb2
bb14:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitBeside(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/check:litv" %a2, ptr %a3, i32 %a4, %"compiler/source:Span" %a5, i1 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/check:litv"
  %l4 = alloca i32
  %l6 = alloca i1
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca ptr
  %l12 = alloca i32
  %l15 = alloca i32
  %l17 = alloca i1
  %l20 = alloca i1
  %l25 = alloca i32
  %l28 = alloca i1
  %l31 = alloca i1
  %l36 = alloca i32
  %l40 = alloca i1
  %l41 = alloca ptr
  %l46 = alloca ptr
  %l51 = alloca ptr
  %l55 = alloca i1
  %l57 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca %"compiler/source:Span"
  %l60 = alloca i32
  %l63 = alloca i32
  %l64 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/check:litv" %a2, ptr %l2
  store i32 %a4, ptr %l4
  store i1 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a3)
  store i32 %t4, ptr %l12
  br label %bb1
bb1:
  %t5 = load i32, ptr %l12, !tbaa !23
  store i32 %t5, ptr %l7, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l7, !tbaa !23
  %t10 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l15
  br label %bb2
bb2:
  %t11 = load i32, ptr %l15, !tbaa !23
  store i32 %t11, ptr %l8, !tbaa !23
  %t12 = load i1, ptr %l6, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l8, !tbaa !23
  %t18 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t14, i32 %t15)
  store i1 %t18, ptr %l20
  br label %bb5
bb4:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb6
bb5:
  %t19 = load i1, ptr %l20, !tbaa !21
  %t20 = xor i1 %t19, true
  store i1 %t20, ptr %l17, !tbaa !21
  br label %bb6
bb6:
  %t22 = load i1, ptr %l17, !tbaa !21
  br i1 %t22, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l7, !tbaa !23
  %t25 = load i32, ptr %l4, !range !{i32 0, i32 96}
  %t29 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopParam(ptr %v0, ptr %t23, i32 %t24, i32 %t25)
  store i32 %t29, ptr %l25
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t30 = load i32, ptr %l25, !tbaa !23
  store i32 %t30, ptr %l8, !tbaa !23
  br label %bb10
bb10:
  %t31 = load i1, ptr %l6, !tbaa !21
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb11, label %bb12
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l8, !tbaa !23
  %t39 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t35, i32 %t36)
  store i1 %t39, ptr %l31
  br label %bb13
bb12:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb14
bb13:
  %t40 = load i1, ptr %l31, !tbaa !21
  %t41 = xor i1 %t40, true
  store i1 %t41, ptr %l28, !tbaa !21
  br label %bb14
bb14:
  %t43 = load i1, ptr %l28, !tbaa !21
  br i1 %t43, label %bb15, label %bb16
bb15:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i32, ptr %l7, !tbaa !23
  %t46 = load i32, ptr %l4, !range !{i32 0, i32 96}
  %t50 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecommuteParam(ptr %v0, ptr %t44, i32 %t45, i32 %t46)
  store i32 %t50, ptr %l36
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t51 = load i32, ptr %l36, !tbaa !23
  store i32 %t51, ptr %l8, !tbaa !23
  br label %bb18
bb18:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load %"compiler/check:litv", ptr %l2
  %t54 = load i32, ptr %l8, !tbaa !23
  %t58 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %t52, %"compiler/check:litv" %t53, i32 %t54)
  store i1 %t58, ptr %l40
  br label %bb19
bb19:
  %t59 = load i1, ptr %l40, !tbaa !21
  br i1 %t59, label %bb20, label %bb21
bb20:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t62 = load %"compiler/check:litv", ptr %l2
  %t63 = load i32, ptr %l8, !tbaa !23
  %t68 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitOf(ptr %v0, ptr %v1, ptr %t60, ptr %t61, %"compiler/check:litv" %t62, i32 %t63)
  store ptr %t68, ptr %l46
  br label %bb22
bb21:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t71 = load %"compiler/check:litv", ptr %l2
  %t72 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t77 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitOf(ptr %v0, ptr %v1, ptr %t69, ptr %t70, %"compiler/check:litv" %t71, i32 %t72)
  store ptr %t77, ptr %l51
  br label %bb23
bb22:
  %t78 = load ptr, ptr %l46, !tbaa !29
  store ptr %t78, ptr %l41, !tbaa !29
  br label %bb24
bb23:
  %t79 = load ptr, ptr %l51, !tbaa !29
  store ptr %t79, ptr %l41, !tbaa !29
  br label %bb24
bb24:
  %t80 = load ptr, ptr %l41, !tbaa !29
  store ptr %t80, ptr %l9, !tbaa !29
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load %"compiler/check:litv", ptr %l2
  %t83 = load i32, ptr %l8, !tbaa !23
  %t87 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %t81, %"compiler/check:litv" %t82, i32 %t83)
  store i1 %t87, ptr %l55
  br label %bb25
bb25:
  %t88 = load i1, ptr %l55, !tbaa !21
  %t89 = xor i1 %t88, true
  br i1 %t89, label %bb26, label %bb27
bb26:
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l58, !tbaa !29
  store %"compiler/source:Span" %a5, ptr %l59
  %t93 = load i32, ptr %l7, !tbaa !23
  store i32 %t93, ptr %l60, !tbaa !23
  %t94 = load ptr, ptr %l9, !tbaa !29
  %t97 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t94)
  store i32 %t97, ptr %l63
  br label %bb28
bb27:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb30
bb28:
  %t98 = load ptr, ptr %l58, !tbaa !29
  %t99 = load %"compiler/source:Span", ptr %l59
  %t100 = load i32, ptr %l60, !tbaa !23
  %t101 = load i32, ptr %l63, !tbaa !23
  %t102 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoMeet(ptr %v0, ptr %t98, %"compiler/source:Span" %t99, i32 %t100, i32 %t101)
  store i1 %t102, ptr %l64
  br label %bb29
bb29:
  %t103 = load i1, ptr %l64, !tbaa !21
  store i1 %t103, ptr %l57, !tbaa !21
  br label %bb30
bb30:
  %t104 = load i1, ptr %l57, !tbaa !21
  br i1 %t104, label %bb31, label %bb32
bb31:
  store ptr null, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t106 = load ptr, ptr %l9, !tbaa !29
  store ptr %t106, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitCtor(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l14 = alloca i1
  %l17 = alloca i1
  %l22 = alloca i32
  %l26 = alloca i1
  %l30 = alloca i1
  %l32 = alloca i1
  %l36 = alloca i32
  %l40 = alloca ptr
  %l42 = alloca %"compiler/source:Span"
  %l44 = alloca %"compiler/source:Span"
  %l45 = alloca i32
  %l46 = alloca ptr
  %l50 = alloca ptr
  %rv = alloca ptr
  %t86 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i32, ptr %l2, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  store i1 %t9, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l5, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb7
bb5:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l2, !tbaa !23
  %t16 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t16, ptr %l12
  br label %bb6
bb6:
  %t17 = load i1, ptr %l12, !tbaa !21
  %t18 = xor i1 %t17, true
  store i1 %t18, ptr %l9, !tbaa !21
  br label %bb7
bb7:
  %t20 = load i1, ptr %l9, !tbaa !21
  br i1 %t20, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb11
bb9:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t25 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t21, ptr %t22)
  store i1 %t25, ptr %l17
  br label %bb10
bb10:
  %t26 = load i1, ptr %l17, !tbaa !21
  %t27 = xor i1 %t26, true
  store i1 %t27, ptr %l14, !tbaa !21
  br label %bb11
bb11:
  %t29 = load i1, ptr %l14, !tbaa !21
  br i1 %t29, label %bb12, label %bb13
bb12:
  store ptr null, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l2, !tbaa !23
  %t35 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t35, ptr %l22
  br label %bb15
bb15:
  %t36 = load i32, ptr %l22, !range !{i32 0, i32 6}
  %t38 = trunc i64 4 to i32
  %t39 = icmp eq i32 %t36, %t38
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb19
bb17:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t47 = load i32, ptr %l2, !tbaa !23
  %t50 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t46, i32 %t47)
  store i1 %t50, ptr %l30
  br label %bb18
bb18:
  %t51 = load i1, ptr %l30, !tbaa !21
  %t52 = xor i1 %t51, true
  store i1 %t52, ptr %l26, !tbaa !21
  br label %bb19
bb19:
  %t54 = load i1, ptr %l26, !tbaa !21
  br i1 %t54, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb23
bb21:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t59 = load i32, ptr %l2, !tbaa !23
  %t62 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l36
  br label %bb22
bb22:
  %t63 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t64 = load i32, ptr %l36, !tbaa !23
  %t66 = icmp eq i32 %t64, %t63
  store i1 %t66, ptr %l32, !tbaa !21
  br label %bb23
bb23:
  %t68 = load i1, ptr %l32, !tbaa !21
  br i1 %t68, label %bb24, label %bb25
bb24:
  store ptr null, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l40, !tbaa !29
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t71)
  store %"compiler/source:Span" %t73, ptr %l42
  br label %bb27
bb27:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t74)
  store %"compiler/source:Span" %t76, ptr %l44
  br label %bb28
bb28:
  %t77 = load i32, ptr %l2, !tbaa !23
  store i32 %t77, ptr %l45, !tbaa !23
  %t78 = load ptr, ptr %l1, !tbaa !29
  store ptr %t78, ptr %l46, !tbaa !29
  %t79 = icmp sge i64 1, 0
  br i1 %t79, label %bb29, label %bb30
bb29:
  %t81 = icmp sle i64 1, 1152921504606846975
  br i1 %t81, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_89233ed815a81c43_385dc0f6d58c413f)
  unreachable
bb31:
  %t83 = mul i64 1, 8
  %t84 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t83)
  %t85 = load ptr, ptr %l46, !tbaa !29
  store i64 0, ptr %t86
  br label %fill.87
fill.87:
  %t90 = load i64, ptr %t86
  %t91 = icmp slt i64 %t90, 1
  br i1 %t91, label %fillb.88, label %filld.89
fillb.88:
  %t92 = getelementptr ptr, ptr %t84, i64 %t90
  store ptr %t85, ptr %t92
  %t93 = add i64 %t90, 1
  store i64 %t93, ptr %t86
  br label %fill.87
filld.89:
  %t94 = insertvalue { i64, ptr } undef, i64 1, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t84, 1
  %t96 = load ptr, ptr %l40, !tbaa !29
  %t97 = load %"compiler/source:Span", ptr %l42
  %t98 = load %"compiler/source:Span", ptr %l44
  %t99 = load i32, ptr %l45, !tbaa !23
  %t101 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econstruct(ptr %v0, ptr %v0, ptr %t96, %"compiler/source:Span" %t97, %"compiler/source:Span" %t98, i32 %t99, { i64, ptr } %t95)
  store ptr %t101, ptr %l50
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_89233ed815a81c43_385dc0f6d58c413f)
  unreachable
bb33:
  %t102 = load ptr, ptr %l50, !tbaa !29
  store ptr %t102, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %a0, %"compiler/check:litv" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/check:litv"
  %l3 = alloca i32
  %l6 = alloca i32
  %l11 = alloca i1
  %l19 = alloca i1
  %l20 = alloca i1
  %l23 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i32
  %l32 = alloca double
  %l33 = alloca i1
  %l40 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/check:litv" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t1, i32 %a2)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i32, ptr %l6, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t16, ptr %l11
  br label %bb2
bb2:
  %t17 = load i1, ptr %l11, !tbaa !21
  %t18 = xor i1 %t17, true
  br i1 %t18, label %bb3, label %bb4
bb3:
  store i1 false, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t21 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 1
  %t22 = load i1, ptr %t21, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t30 = load i32, ptr %l3, !tbaa !23
  %t33 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t29, i32 %t30)
  store i1 %t33, ptr %l19
  br label %bb8
bb7:
  br label %bb13
bb8:
  %t34 = load i1, ptr %l19, !tbaa !21
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t35 = load i32, ptr %l3, !tbaa !23
  %t36 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 4
  %t37 = load double, ptr %t36, !tbaa !26
  %t40 = call i1 @compiler_2fcheck_2efloatOverflows(i32 %t35, double %t37)
  store i1 %t40, ptr %l23
  br label %bb11
bb10:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb12
bb11:
  %t41 = load i1, ptr %l23, !tbaa !21
  %t42 = xor i1 %t41, true
  store i1 %t42, ptr %l20, !tbaa !21
  br label %bb12
bb12:
  %t44 = load i1, ptr %l20, !tbaa !21
  store i1 %t44, ptr %rv
  br label %ret
bb13:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = getelementptr %"compiler/generic:Program", ptr %t48, i32 0, i32 2
  %t51 = load i32, ptr %l3, !tbaa !23
  %t54 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t50, i32 %t51)
  store i1 %t54, ptr %l29
  br label %bb14
bb14:
  %t55 = load i1, ptr %l29, !tbaa !21
  br i1 %t55, label %bb15, label %bb16
bb15:
  %t56 = load i32, ptr %l3, !tbaa !23
  store i32 %t56, ptr %l30, !tbaa !23
  %t57 = load %"compiler/check:litv", ptr %l1
  %t59 = call double @compiler_2fcheck_2elitF64(%"compiler/check:litv" %t57)
  store double %t59, ptr %l32
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t60 = load i32, ptr %l30, !tbaa !23
  %t61 = load double, ptr %l32, !tbaa !26
  %t62 = call i1 @compiler_2fcheck_2efloatOverflows(i32 %t60, double %t61)
  store i1 %t62, ptr %l33
  br label %bb18
bb18:
  %t63 = load i1, ptr %l33, !tbaa !21
  %t64 = xor i1 %t63, true
  store i1 %t64, ptr %rv
  br label %ret
bb19:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = getelementptr %"compiler/generic:Program", ptr %t69, i32 0, i32 2
  %t72 = load %"compiler/check:litv", ptr %l1
  %t73 = load i32, ptr %l3, !tbaa !23
  %t77 = call i1 @compiler_2fcheck_2eintFits(ptr %v0, ptr %t71, %"compiler/check:litv" %t72, i32 %t73)
  store i1 %t77, ptr %l40
  br label %bb20
bb20:
  %t78 = load i1, ptr %l40, !tbaa !21
  store i1 %t78, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emessage(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i32
  %l12 = alloca ptr
  %l17 = alloca ptr
  %l20 = alloca i64
  %l23 = alloca ptr
  %l25 = alloca ptr
  %l28 = alloca ptr
  %l30 = alloca i32
  %l32 = alloca i32
  %l33 = alloca ptr
  %l35 = alloca ptr
  %l39 = alloca ptr
  %l42 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca i32
  %l50 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i32
  %l54 = alloca i32
  %l55 = alloca i1
  %l57 = alloca ptr
  %l59 = alloca %"compiler/source:Span"
  %l60 = alloca ptr
  %l63 = alloca i32
  %l64 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l69 = alloca %"compiler/msgs:Msg"
  %l70 = alloca i64
  %l72 = alloca ptr
  %l73 = alloca ptr
  %l76 = alloca ptr
  %l78 = alloca i32
  %l80 = alloca i32
  %l82 = alloca %"compiler/source:Span"
  %l83 = alloca ptr
  %s2 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store ptr null, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t6)
  store ptr %t8, ptr %l12
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l12, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t12 = getelementptr %"compiler/check:frame", ptr %t10, i32 0, i32 33
  %t13 = load i64, ptr %t12, !tbaa !24
  store i64 %t13, ptr %l4, !tbaa !24
  %t15 = load ptr, ptr %l3, !tbaa !29
  %t17 = getelementptr %"compiler/check:frame", ptr %t15, i32 0, i32 34
  %t18 = load i1, ptr %t17, !tbaa !21
  store i1 %t18, ptr %l5, !tbaa !21
  %t20 = load ptr, ptr %l3, !tbaa !29
  store ptr %t20, ptr %l17, !tbaa !29
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = getelementptr %"compiler/check:frame", ptr %t21, i32 0, i32 10
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t23)
  store i64 %t25, ptr %l20
  br label %bb5
bb5:
  %t26 = load i64, ptr %l20, !tbaa !24
  %t27 = load ptr, ptr %l17, !tbaa !29
  %t28 = getelementptr %"compiler/check:frame", ptr %t27, i32 0, i32 33
  store i64 %t26, ptr %t28, !tbaa !24
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t30 = load i1, ptr %l2, !tbaa !21
  %t33 = getelementptr %"compiler/check:frame", ptr %t29, i32 0, i32 34
  store i1 %t30, ptr %t33, !tbaa !21
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l23, !tbaa !29
  %t35 = load ptr, ptr %l1, !tbaa !29
  store ptr %t35, ptr %l25, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 2
  store ptr %t42, ptr %l28, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t43)
  store i32 %t45, ptr %l30
  br label %bb6
bb6:
  %t46 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t47 = load ptr, ptr %l28, !tbaa !29
  %t48 = load i32, ptr %l30, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t47, i32 %t48, i64 %t46)
  store i32 %t50, ptr %l32
  br label %bb7
bb7:
  %t51 = load ptr, ptr %l23, !tbaa !29
  %t52 = load ptr, ptr %l25, !tbaa !29
  %t53 = load i32, ptr %l32, !tbaa !23
  %t54 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t51, ptr %t52, i32 %t53)
  store ptr %t54, ptr %l33
  br label %bb8
bb8:
  %t55 = load ptr, ptr %l33, !tbaa !29
  store ptr %t55, ptr %l6, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t56)
  store ptr %t58, ptr %l35
  br label %bb9
bb9:
  %t59 = load ptr, ptr %l35, !tbaa !29
  %t60 = load i64, ptr %l4, !tbaa !24
  %t63 = getelementptr %"compiler/check:frame", ptr %t59, i32 0, i32 33
  store i64 %t60, ptr %t63, !tbaa !24
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t64)
  store ptr %t66, ptr %l39
  br label %bb10
bb10:
  %t67 = load ptr, ptr %l39, !tbaa !29
  %t68 = load i1, ptr %l5, !tbaa !21
  %t71 = getelementptr %"compiler/check:frame", ptr %t67, i32 0, i32 34
  store i1 %t68, ptr %t71, !tbaa !21
  %t72 = load ptr, ptr %l0, !tbaa !29
  store ptr %t72, ptr %l42, !tbaa !29
  %t73 = load ptr, ptr %l6, !tbaa !29
  %t76 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t73)
  store i32 %t76, ptr %l45
  br label %bb11
bb11:
  %t77 = load ptr, ptr %l42, !tbaa !29
  %t78 = load i32, ptr %l45, !tbaa !23
  %t79 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t77, i32 %t78)
  store i32 %t79, ptr %l46
  br label %bb12
bb12:
  %t80 = load i32, ptr %l46, !tbaa !23
  store i32 %t80, ptr %l7, !tbaa !23
  %t81 = load i32, ptr %l7, !tbaa !23
  %t82 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t85 = icmp ne i32 %t81, %t82
  br i1 %t85, label %bb13, label %bb14
bb13:
  %t87 = load ptr, ptr %l0, !tbaa !29
  store ptr %t87, ptr %l51, !tbaa !29
  %t88 = load i32, ptr %l7, !tbaa !23
  store i32 %t88, ptr %l52, !tbaa !23
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t89)
  store i32 %t91, ptr %l54
  br label %bb15
bb14:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb17
bb15:
  %t92 = load ptr, ptr %l51, !tbaa !29
  %t93 = load i32, ptr %l52, !tbaa !23
  %t94 = load i32, ptr %l54, !tbaa !23
  %t95 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esameRepr(ptr %v0, ptr %t92, i32 %t93, i32 %t94)
  store i1 %t95, ptr %l55
  br label %bb16
bb16:
  %t96 = load i1, ptr %l55, !tbaa !21
  %t97 = xor i1 %t96, true
  store i1 %t97, ptr %l50, !tbaa !21
  br label %bb17
bb17:
  %t99 = load i1, ptr %l50, !tbaa !21
  br i1 %t99, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s2
  %t100 = load ptr, ptr %l0, !tbaa !29
  store ptr %t100, ptr %l57, !tbaa !29
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t101)
  store %"compiler/source:Span" %t103, ptr %l59
  br label %bb20
bb19:
  br label %bb26
bb20:
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l60, !tbaa !29
  %t105 = load ptr, ptr %l6, !tbaa !29
  %t108 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t105)
  store i32 %t108, ptr %l63
  br label %bb21
bb21:
  %t109 = load ptr, ptr %l60, !tbaa !29
  %t110 = load i32, ptr %l63, !tbaa !23
  %t111 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t109, i32 %t110)
  store { i64, ptr } %t111, ptr %l64
  br label %bb22
bb22:
  %t112 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t112, 0
  %t114 = extractvalue { i64, ptr } %t112, 1
  %t115 = mul i64 %t113, 1
  %t116 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t115)
  call void @llvm.memcpy.p0.p0.i64(ptr %t116, ptr %t114, i64 %t115, i1 false)
  %t117 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t116, 1
  store { i64, ptr } %t118, ptr %l65, !tbaa !27
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load i1, ptr %l2, !tbaa !21
  %t123 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emsgOwner(ptr %v0, ptr %s2, ptr %t119, i1 %t120)
  store { i64, ptr } %t123, ptr %l68
  br label %bb23
bb23:
  %t124 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t125 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t126 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertMessageNotText(ptr %s2, ptr %s2, ptr %s2, { i64, ptr } %t124, { i64, ptr } %t125)
  store %"compiler/msgs:Msg" %t126, ptr %l69
  br label %bb24
bb24:
  %t127 = load ptr, ptr %l57, !tbaa !29
  %t128 = load %"compiler/source:Span", ptr %l59
  %t129 = load %"compiler/msgs:Msg", ptr %l69
  %t130 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t127, %"compiler/source:Span" %t128, %"compiler/msgs:Msg" %t129)
  store i64 %t130, ptr %l70
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s2)
  store ptr null, ptr %rv
  br label %ret
bb26:
  %t132 = load ptr, ptr %l0, !tbaa !29
  store ptr %t132, ptr %l72, !tbaa !29
  %t133 = load ptr, ptr %l6, !tbaa !29
  store ptr %t133, ptr %l73, !tbaa !29
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t134, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t139 = getelementptr %"compiler/generic:Program", ptr %t137, i32 0, i32 2
  store ptr %t139, ptr %l76, !tbaa !29
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t140)
  store i32 %t142, ptr %l78
  br label %bb27
bb27:
  %t143 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t144 = load ptr, ptr %l76, !tbaa !29
  %t145 = load i32, ptr %l78, !tbaa !23
  %t147 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t144, i32 %t145, i64 %t143)
  store i32 %t147, ptr %l80
  br label %bb28
bb28:
  %t148 = load ptr, ptr %l1, !tbaa !29
  %t150 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t148)
  store %"compiler/source:Span" %t150, ptr %l82
  br label %bb29
bb29:
  %t151 = load ptr, ptr %l72, !tbaa !29
  %t152 = load ptr, ptr %l73, !tbaa !29
  %t153 = load i32, ptr %l80, !tbaa !23
  %t154 = load %"compiler/source:Span", ptr %l82
  %t155 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t151, ptr %t152, i32 %t153, %"compiler/source:Span" %t154)
  store ptr %t155, ptr %l83
  br label %bb30
bb30:
  %t156 = load ptr, ptr %l83, !tbaa !29
  store ptr %t156, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowedName(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca i64
  %l19 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 29}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l3, !tbaa !23
  %t20 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t16, i32 %t17)
  store i64 %t20, ptr %l13
  br label %bb6
bb6:
  %t21 = load i64, ptr %l13, !tbaa !24
  store i64 %t21, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = icmp sge i64 %t22, 0
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i64, ptr %l4, !tbaa !24
  %t32 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowedField(ptr %v0, ptr %t26, i64 %t27, i32 %a2)
  store i64 %t32, ptr %l19
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t33 = load i64, ptr %l19, !tbaa !24
  store i64 %t33, ptr %rv
  br label %ret
bb10:
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_bddcfdd9cfe1623c_a2c83caf107f9198)
  unreachable
bb16:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoCase(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l12 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l19 = alloca %"compiler/msgs:Nearest"
  %l31 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l54 = alloca %"compiler/msgs:Msg"
  %l57 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l63 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %t12, i32 %t13)
  store { i64, ptr } %t16, ptr %l17
  br label %bb2
bb2:
  %t17 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t17, ptr %l4, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t20 = call %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v0, ptr %s0, { i64, ptr } %t18)
  store %"compiler/msgs:Nearest" %t20, ptr %l19
  br label %bb3
bb3:
  %t21 = load %"compiler/msgs:Nearest", ptr %l19
  %t22 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 40, i64 8)
  store %"compiler/msgs:Nearest" %t21, ptr %t22
  store ptr %t22, ptr %l5, !tbaa !29
  %t24 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = icmp sgt i64 %t26, 0
  br i1 %t28, label %bb4, label %bb5
bb4:
  %t30 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t30, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  store i64 %t34, ptr %l8, !tbaa !24
  br label %bb6
bb5:
  br label %bb14
bb6:
  %t36 = load i64, ptr %l7, !tbaa !24
  %t37 = load i64, ptr %l8, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  br label %bb9
bb9:
  %t44 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t44, ptr %l31, !tbaa !27
  %t45 = load i64, ptr %l7, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr i32, ptr %t48, i64 %t45
  %t50 = load i32, ptr %t49, !tbaa !33
  %t52 = load ptr, ptr %l5, !tbaa !29
  store ptr %t52, ptr %l34, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t57 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t53, i32 %t50)
  store { i64, ptr } %t57, ptr %l37
  br label %bb10
bb10:
  %t58 = load ptr, ptr %l34, !tbaa !29
  %t59 = load { i64, ptr }, ptr %l37, !tbaa !27
  call void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %s0, ptr %v0, ptr %t58, { i64, ptr } %t59)
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t60 = load i64, ptr %l7, !tbaa !24
  %t62 = add i64 %t60, 1
  store i64 %t62, ptr %l7, !tbaa !24
  br label %bb6
bb13:
  br label %bb14
bb14:
  %t64 = load ptr, ptr %l5, !tbaa !29
  %t66 = getelementptr %"compiler/msgs:Nearest", ptr %t64, i32 0, i32 1
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t71 = icmp sgt i64 %t69, 0
  br i1 %t71, label %bb15, label %bb16
bb15:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i32, ptr %l1, !tbaa !23
  %t77 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %t73, i32 %t74)
  store { i64, ptr } %t77, ptr %l46
  br label %bb17
bb16:
  br label %bb20
bb17:
  %t78 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 0
  %t80 = extractvalue { i64, ptr } %t78, 1
  %t81 = mul i64 %t79, 1
  %t82 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t81)
  call void @llvm.memcpy.p0.p0.i64(ptr %t82, ptr %t80, i64 %t81, i1 false)
  %t83 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  store { i64, ptr } %t84, ptr %l47, !tbaa !27
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i32, ptr %l2, !tbaa !23
  %t89 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %t85, i32 %t86)
  store { i64, ptr } %t89, ptr %l50
  br label %bb18
bb18:
  %t90 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  %t92 = extractvalue { i64, ptr } %t90, 1
  %t93 = mul i64 %t91, 1
  %t94 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t93)
  call void @llvm.memcpy.p0.p0.i64(ptr %t94, ptr %t92, i64 %t93, i1 false)
  %t95 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  %t97 = load ptr, ptr %l5, !tbaa !29
  %t99 = getelementptr %"compiler/msgs:Nearest", ptr %t97, i32 0, i32 1
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t104 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSuchCaseMeant(ptr %v1, ptr %v1, ptr %s0, ptr %v1, { i64, ptr } %t101, { i64, ptr } %t96, { i64, ptr } %t100)
  store %"compiler/msgs:Msg" %t104, ptr %l54
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  %t105 = load %"compiler/msgs:Msg", ptr %l54
  store %"compiler/msgs:Msg" %t105, ptr %rv
  br label %ret
bb20:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i32, ptr %l1, !tbaa !23
  %t110 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %t106, i32 %t107)
  store { i64, ptr } %t110, ptr %l57
  br label %bb21
bb21:
  %t111 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 0
  %t113 = extractvalue { i64, ptr } %t111, 1
  %t114 = mul i64 %t112, 1
  %t115 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t114)
  call void @llvm.memcpy.p0.p0.i64(ptr %t115, ptr %t113, i64 %t114, i1 false)
  %t116 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t115, 1
  store { i64, ptr } %t117, ptr %l58, !tbaa !27
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load i32, ptr %l2, !tbaa !23
  %t122 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %t118, i32 %t119)
  store { i64, ptr } %t122, ptr %l61
  br label %bb22
bb22:
  %t123 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  %t125 = extractvalue { i64, ptr } %t123, 1
  %t126 = mul i64 %t124, 1
  %t127 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t126)
  call void @llvm.memcpy.p0.p0.i64(ptr %t127, ptr %t125, i64 %t126, i1 false)
  %t128 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  %t130 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t132 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSuchCase(ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t130, { i64, ptr } %t129)
  store %"compiler/msgs:Msg" %t132, ptr %l63
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  %t133 = load %"compiler/msgs:Msg", ptr %l63
  store %"compiler/msgs:Msg" %t133, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l9 = alloca ptr
  %l11 = alloca ptr
  %l14 = alloca ptr
  %l28 = alloca i1
  %l29 = alloca { i64, ptr }
  %l33 = alloca i1
  %l34 = alloca { i64, ptr }
  %l52 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 5
  store ptr %t9, ptr %l9, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t10)
  store ptr %t12, ptr %l11
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l11, !tbaa !29
  %t15 = getelementptr %"compiler/check:frame", ptr %t13, i32 0, i32 1
  %t16 = load i64, ptr %t15, !tbaa !24
  %t17 = load ptr, ptr %l9, !tbaa !29
  %t19 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t17, i64 %t16)
  store ptr %t19, ptr %l14
  br label %bb2
bb2:
  %t20 = load ptr, ptr %l14, !tbaa !29
  %t22 = getelementptr %"compiler/load:Module", ptr %t20, i32 0, i32 6
  %t23 = load ptr, ptr %t22, !tbaa !29
  store ptr %t23, ptr %l3, !tbaa !29
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t27 = icmp eq ptr %t25, null
  br i1 %t27, label %bb3, label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_cabdf486839d2fe5_195cd685fa5544d9)
  unreachable
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t32 = getelementptr %"compiler/source:Source", ptr %t29, i32 0, i32 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l4, !tbaa !27
  %t35 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t36 = load i32, ptr %t35, !tbaa !23
  %t38 = sext i32 %t36 to i64
  store i64 %t38, ptr %l5, !tbaa !24
  br label %bb6
bb6:
  %t40 = load i64, ptr %l5, !tbaa !24
  %t41 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t46 = icmp slt i64 %t40, %t43
  br i1 %t46, label %bb7, label %bb8
bb7:
  %t48 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t48, ptr %l29, !tbaa !27
  %t49 = load i64, ptr %l5, !tbaa !24
  %t51 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr i8, ptr %t52, i64 %t49
  %t54 = load i8, ptr %t53, !tbaa !32
  %t56 = icmp eq i8 %t54, 32
  br i1 %t56, label %bb9, label %bb10
bb8:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb12
bb9:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb11
bb10:
  %t58 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t58, ptr %l34, !tbaa !27
  %t59 = load i64, ptr %l5, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i8, ptr %t62, i64 %t59
  %t64 = load i8, ptr %t63, !tbaa !32
  %t66 = icmp eq i8 %t64, 41
  store i1 %t66, ptr %l33, !tbaa !21
  br label %bb11
bb11:
  %t68 = load i1, ptr %l33, !tbaa !21
  store i1 %t68, ptr %l28, !tbaa !21
  br label %bb12
bb12:
  %t69 = load i1, ptr %l28, !tbaa !21
  %t70 = xor i1 %t69, true
  br i1 %t70, label %bb13, label %bb14
bb13:
  br label %bb17
bb14:
  br label %bb15
bb15:
  %t72 = load i64, ptr %l5, !tbaa !24
  %t74 = add i64 %t72, 1
  store i64 %t74, ptr %l5, !tbaa !24
  br label %bb16
bb16:
  br label %bb6
bb17:
  %t76 = load i64, ptr %l5, !tbaa !24
  %t77 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t77, 0
  %t82 = icmp sge i64 %t76, %t79
  br i1 %t82, label %bb18, label %bb19
bb18:
  %t84 = load %"compiler/source:Span", ptr %l1
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/source:Span" %t84, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t86 = load i64, ptr %l5, !tbaa !24
  %t88 = trunc i64 %t86 to i32
  %t89 = load i64, ptr %l5, !tbaa !24
  %t93 = add i64 %t89, %a2
  %t95 = trunc i64 %t93 to i32
  %t98 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t88, i32 %t95)
  store %"compiler/source:Span" %t98, ptr %l52
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s0)
  %t99 = load %"compiler/source:Span", ptr %l52
  store %"compiler/source:Span" %t99, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca %"compiler/names:Ref"
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca %"compiler/names:Ref"
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca %"compiler/source:Span"
  %l21 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca i1
  %l40 = alloca ptr
  %l42 = alloca ptr
  %l46 = alloca %"compiler/names:Ref"
  %l49 = alloca i1
  %l51 = alloca i1
  %l54 = alloca i64
  %l58 = alloca ptr
  %l59 = alloca %"compiler/source:Span"
  %l62 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l67 = alloca %"compiler/msgs:Msg"
  %l68 = alloca i64
  %l73 = alloca i1
  %l76 = alloca i64
  %l78 = alloca i64
  %l81 = alloca i64
  %l85 = alloca i64
  %l88 = alloca i1
  %l90 = alloca ptr
  %l97 = alloca ptr
  %l101 = alloca i64
  %l104 = alloca i64
  %l106 = alloca %"compiler/source:Span"
  %l109 = alloca i32
  %l113 = alloca ptr
  %l117 = alloca i32
  %l121 = alloca %"compiler/source:Span"
  %l124 = alloca i32
  %l133 = alloca ptr
  %l137 = alloca %"compiler/source:Span"
  %l141 = alloca i32
  %l146 = alloca ptr
  %l147 = alloca i1
  %l154 = alloca ptr
  %l155 = alloca ptr
  %l156 = alloca i1
  %l167 = alloca ptr
  %l169 = alloca ptr
  %l173 = alloca %"compiler/names:Ref"
  %l176 = alloca %"compiler/source:Span"
  %l180 = alloca i32
  %l187 = alloca i1
  %l190 = alloca i32
  %l195 = alloca i64
  %l198 = alloca %"compiler/source:Span"
  %l201 = alloca i32
  %l205 = alloca ptr
  %l209 = alloca i32
  %l214 = alloca ptr
  %l218 = alloca ptr
  %l219 = alloca %"compiler/source:Span"
  %l220 = alloca %"compiler/source:Span"
  %l223 = alloca { i64, ptr }
  %l225 = alloca %"compiler/source:Span"
  %l228 = alloca ptr
  %l229 = alloca ptr
  %l230 = alloca i1
  %l241 = alloca i32
  %l243 = alloca i1
  %l246 = alloca %"compiler/check:reflList"
  %l253 = alloca ptr
  %l254 = alloca ptr
  %l255 = alloca i1
  %l264 = alloca ptr
  %l265 = alloca i1
  %l276 = alloca { i64, ptr }
  %l277 = alloca i1
  %l280 = alloca i32
  %l287 = alloca ptr
  %l288 = alloca %"compiler/source:Span"
  %l290 = alloca %"compiler/source:Span"
  %l293 = alloca ptr
  %l298 = alloca ptr
  %l301 = alloca i32
  %l307 = alloca ptr
  %l314 = alloca %"compiler/source:Span"
  %l315 = alloca i32
  %l316 = alloca ptr
  %l317 = alloca ptr
  %l318 = alloca i32
  %l320 = alloca %"compiler/source:Span"
  %l321 = alloca i32
  %s2 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca ptr
  %t189 = alloca { i64, [4 x i64] }, align 8
  %t216 = alloca { i64, [4 x i64] }, align 8
  %t256 = alloca { i64, [4 x i64] }, align 8
  %t358 = alloca { i64, [4 x i64] }, align 8
  %t419 = alloca { i64, [4 x i64] }, align 8
  %t663 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 9
  %t4 = load i1, ptr %t3, !tbaa !21
  store i1 %t4, ptr %l2, !tbaa !21
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 9
  store i1 false, ptr %t8, !tbaa !21
  %t9 = load ptr, ptr %l1, !tbaa !29
  store ptr %t9, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t10 = load ptr, ptr %l30, !tbaa !29
  %t11 = icmp ne ptr %t10, null
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load ptr, ptr %l30, !tbaa !29
  %t14 = load i64, ptr %t13, !range !{i64 0, i64 29}
  %t16 = icmp eq i64 %t14, 0
  store i1 %t16, ptr %l31, !tbaa !21
  br label %bb2
bb2:
  %t17 = load i1, ptr %l31, !tbaa !21
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr { i64, [5 x i64] }, ptr %t18, i32 0, i32 1
  %t21 = getelementptr { %"compiler/source:Span", i32 }, ptr %t20, i32 0, i32 0
  %t22 = load %"compiler/source:Span", ptr %t21
  store %"compiler/source:Span" %t22, ptr %l3
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr { i64, [5 x i64] }, ptr %t24, i32 0, i32 1
  %t27 = getelementptr { %"compiler/source:Span", i32 }, ptr %t26, i32 0, i32 1
  %t28 = load i32, ptr %t27
  store i32 %t28, ptr %l4, !tbaa !23
  br label %bb5
bb4:
  br label %bb62
bb5:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  store ptr %t36, ptr %l40, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t37)
  store ptr %t39, ptr %l42
  br label %bb6
bb6:
  %t40 = load ptr, ptr %l42, !tbaa !29
  %t42 = getelementptr %"compiler/check:frame", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t44 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t45 = load i32, ptr %t44, !tbaa !23
  %t46 = load ptr, ptr %l40, !tbaa !29
  %t49 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t46, i64 %t43, i32 %t45)
  store %"compiler/names:Ref" %t49, ptr %l46
  br label %bb7
bb7:
  %t50 = load %"compiler/names:Ref", ptr %l46
  store %"compiler/names:Ref" %t50, ptr %l5
  %t51 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t52 = load i32, ptr %t51, !range !{i32 0, i32 9}
  %t54 = trunc i64 1 to i32
  %t55 = icmp eq i32 %t52, %t54
  br i1 %t55, label %bb8, label %bb9
bb8:
  %t57 = load i1, ptr %l2, !tbaa !21
  store i1 %t57, ptr %l49, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb10
bb10:
  %t59 = load i1, ptr %l49, !tbaa !21
  br i1 %t59, label %bb11, label %bb12
bb11:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load i32, ptr %l4, !tbaa !23
  %t64 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtNamed(ptr %v0, ptr %t60, i32 %t61)
  store i64 %t64, ptr %l54
  br label %bb13
bb12:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb14
bb13:
  %t65 = load i64, ptr %l54, !tbaa !24
  %t66 = icmp sge i64 %t65, 0
  store i1 %t66, ptr %l51, !tbaa !21
  br label %bb14
bb14:
  %t68 = load i1, ptr %l51, !tbaa !21
  br i1 %t68, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtUsed(ptr %v0, ptr %t69, i32 %t70)
  br label %bb17
bb16:
  br label %bb22
bb17:
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l58, !tbaa !29
  %t74 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t74, ptr %l59
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i32, ptr %l4, !tbaa !23
  %t79 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s2, ptr %t75, i32 %t76)
  store { i64, ptr } %t79, ptr %l62
  br label %bb18
bb18:
  %t80 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 0
  %t82 = extractvalue { i64, ptr } %t80, 1
  %t83 = mul i64 %t81, 1
  %t84 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t83)
  call void @llvm.memcpy.p0.p0.i64(ptr %t84, ptr %t82, i64 %t83, i1 false)
  %t85 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  store { i64, ptr } %t86, ptr %l63, !tbaa !27
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load i32, ptr %l4, !tbaa !23
  %t91 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t87, i32 %t88)
  store { i64, ptr } %t91, ptr %l66
  br label %bb19
bb19:
  %t92 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t93 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t94 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtAssigned(ptr %s2, ptr %v0, ptr %s2, { i64, ptr } %t92, { i64, ptr } %t93)
  store %"compiler/msgs:Msg" %t94, ptr %l67
  br label %bb20
bb20:
  %t95 = load ptr, ptr %l58, !tbaa !29
  %t96 = load %"compiler/source:Span", ptr %l59
  %t97 = load %"compiler/msgs:Msg", ptr %l67
  %t98 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t95, %"compiler/source:Span" %t96, %"compiler/msgs:Msg" %t97)
  store i64 %t98, ptr %l68
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  store ptr null, ptr %rv
  br label %ret
bb22:
  %t100 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t101 = load i32, ptr %t100, !range !{i32 0, i32 9}
  %t103 = trunc i64 1 to i32
  %t104 = icmp eq i32 %t101, %t103
  br i1 %t104, label %bb23, label %bb24
bb23:
  %t106 = load i1, ptr %l2, !tbaa !21
  br i1 %t106, label %bb25, label %bb26
bb24:
  br label %bb57
bb25:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load i32, ptr %l4, !tbaa !23
  %t112 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t108, i32 %t109)
  store i64 %t112, ptr %l76
  br label %bb27
bb26:
  store i1 false, ptr %l73, !tbaa !21
  br label %bb28
bb27:
  %t113 = load i64, ptr %l76, !tbaa !24
  %t114 = icmp sge i64 %t113, 0
  store i1 %t114, ptr %l73, !tbaa !21
  br label %bb28
bb28:
  %t116 = load i1, ptr %l73, !tbaa !21
  br i1 %t116, label %bb29, label %bb30
bb29:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i32, ptr %l4, !tbaa !23
  %t121 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t117, i32 %t118)
  store i64 %t121, ptr %l81
  br label %bb31
bb30:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load i32, ptr %l4, !tbaa !23
  %t124 = load %"compiler/source:Span", ptr %l3
  %t128 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalOrCapture(ptr %v0, ptr %t122, i32 %t123, %"compiler/source:Span" %t124)
  store i64 %t128, ptr %l85
  br label %bb32
bb31:
  %t129 = load i64, ptr %l81, !tbaa !24
  store i64 %t129, ptr %l78, !tbaa !24
  br label %bb33
bb32:
  %t130 = load i64, ptr %l85, !tbaa !24
  store i64 %t130, ptr %l78, !tbaa !24
  br label %bb33
bb33:
  %t131 = load i64, ptr %l78, !tbaa !24
  store i64 %t131, ptr %l6, !tbaa !24
  %t132 = load i64, ptr %l6, !tbaa !24
  %t134 = icmp slt i64 %t132, 0
  br i1 %t134, label %bb34, label %bb35
bb34:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t136)
  store ptr %t138, ptr %l90
  br label %bb36
bb35:
  store i1 false, ptr %l88, !tbaa !21
  br label %bb37
bb36:
  %t139 = load ptr, ptr %l90, !tbaa !29
  %t141 = getelementptr %"compiler/check:frame", ptr %t139, i32 0, i32 29
  %t142 = load i64, ptr %t141, !tbaa !24
  %t144 = icmp sge i64 %t142, 0
  store i1 %t144, ptr %l88, !tbaa !21
  br label %bb37
bb37:
  %t146 = load i1, ptr %l88, !tbaa !21
  br i1 %t146, label %bb38, label %bb39
bb38:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load %"compiler/source:Span", ptr %l3
  %t149 = load i32, ptr %l4, !tbaa !23
  %t153 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstField(ptr %v0, ptr %t147, %"compiler/source:Span" %t148, i32 %t149)
  store ptr %t153, ptr %l97
  br label %bb40
bb39:
  br label %bb41
bb40:
  %t154 = load ptr, ptr %l97, !tbaa !29
  store ptr %t154, ptr %rv
  br label %ret
bb41:
  %t155 = load i64, ptr %l6, !tbaa !24
  %t157 = icmp slt i64 %t155, 0
  br i1 %t157, label %bb42, label %bb43
bb42:
  store ptr null, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  %t160 = load i64, ptr %l6, !tbaa !24
  store i64 %t160, ptr %l101, !tbaa !24
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load i32, ptr %l4, !tbaa !23
  %t165 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t161, i32 %t162)
  store i64 %t165, ptr %l104
  br label %bb45
bb45:
  %t166 = load i64, ptr %l101, !tbaa !24
  %t167 = load i64, ptr %l104, !tbaa !24
  %t168 = icmp ne i64 %t166, %t167
  br i1 %t168, label %bb46, label %bb47
bb46:
  %t170 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t170, ptr %l106
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load i64, ptr %l6, !tbaa !24
  %t175 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t171, i64 %t172)
  store i32 %t175, ptr %l109
  br label %bb48
bb47:
  br label %bb51
bb48:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load %"compiler/source:Span", ptr %l3
  %t178 = load i64, ptr %l6, !tbaa !24
  %t182 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t176, %"compiler/source:Span" %t177, i64 %t178)
  store ptr %t182, ptr %l113
  br label %bb49
bb49:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load %"compiler/source:Span", ptr %l3
  %t188 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t183, i32 8, %"compiler/source:Span" %t184)
  store i32 %t188, ptr %l117
  br label %bb50
bb50:
  store { i64, [4 x i64] } zeroinitializer, ptr %t189
  %t190 = getelementptr { i64, [4 x i64] }, ptr %t189, i32 0, i32 0
  store i64 6, ptr %t190
  %t191 = load %"compiler/source:Span", ptr %l106
  %t192 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t191, 0
  %t193 = load i32, ptr %l109, !tbaa !23
  %t194 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t192, i32 %t193, 1
  %t195 = load ptr, ptr %l113, !tbaa !29
  %t196 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t194, ptr %t195, 2
  %t197 = load i32, ptr %l117, !tbaa !23
  %t198 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t196, i32 %t197, 3
  %t199 = getelementptr { i64, [4 x i64] }, ptr %t189, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t198, ptr %t199
  %t200 = load { i64, [4 x i64] }, ptr %t189
  %t202 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t200, ptr %t202
  store ptr %t202, ptr %rv
  br label %ret
bb51:
  %t204 = load i1, ptr %l2, !tbaa !21
  br i1 %t204, label %bb52, label %bb53
bb52:
  %t206 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t206, ptr %l121
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load i64, ptr %l6, !tbaa !24
  %t211 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t207, i64 %t208)
  store i32 %t211, ptr %l124
  br label %bb54
bb53:
  br label %bb55
bb54:
  %t212 = load i64, ptr %l6, !tbaa !24
  %t214 = trunc i64 %t212 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t216
  %t217 = getelementptr { i64, [4 x i64] }, ptr %t216, i32 0, i32 0
  store i64 0, ptr %t217
  %t218 = load %"compiler/source:Span", ptr %l121
  %t219 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t218, 0
  %t220 = load i32, ptr %l124, !tbaa !23
  %t221 = insertvalue { %"compiler/source:Span", i32, i32 } %t219, i32 %t220, 1
  %t223 = insertvalue { %"compiler/source:Span", i32, i32 } %t221, i32 %t214, 2
  %t224 = getelementptr { i64, [4 x i64] }, ptr %t216, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t223, ptr %t224
  %t225 = load { i64, [4 x i64] }, ptr %t216
  %t227 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t225, ptr %t227
  store ptr %t227, ptr %rv
  br label %ret
bb55:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t230 = load %"compiler/source:Span", ptr %l3
  %t231 = load i64, ptr %l6, !tbaa !24
  %t235 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalPlace(ptr %v0, ptr %t229, %"compiler/source:Span" %t230, i64 %t231)
  store ptr %t235, ptr %l133
  br label %bb56
bb56:
  %t236 = load ptr, ptr %l133, !tbaa !29
  store ptr %t236, ptr %rv
  br label %ret
bb57:
  %t238 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t239 = load i32, ptr %t238, !range !{i32 0, i32 9}
  %t241 = trunc i64 2 to i32
  %t242 = icmp eq i32 %t239, %t241
  br i1 %t242, label %bb58, label %bb59
bb58:
  %t244 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t244, ptr %l137
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 1
  %t247 = load i64, ptr %t246, !tbaa !24
  %t248 = load i32, ptr %l4, !tbaa !23
  %t252 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalType(ptr %v0, ptr %t245, i64 %t247, i32 %t248)
  store i32 %t252, ptr %l141
  br label %bb60
bb59:
  br label %bb61
bb60:
  %t253 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 1
  %t254 = load i64, ptr %t253, !tbaa !24
  %t255 = load i32, ptr %l4, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t256
  %t257 = getelementptr { i64, [4 x i64] }, ptr %t256, i32 0, i32 0
  store i64 1, ptr %t257
  %t258 = load %"compiler/source:Span", ptr %l137
  %t259 = insertvalue { %"compiler/source:Span", i32, i64, i32 } undef, %"compiler/source:Span" %t258, 0
  %t260 = load i32, ptr %l141, !tbaa !23
  %t261 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t259, i32 %t260, 1
  %t263 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t261, i64 %t254, 2
  %t265 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t263, i32 %t255, 3
  %t266 = getelementptr { i64, [4 x i64] }, ptr %t256, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, i32 } %t265, ptr %t266
  %t267 = load { i64, [4 x i64] }, ptr %t256
  %t269 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t267, ptr %t269
  store ptr %t269, ptr %rv
  br label %ret
bb61:
  br label %bb153
bb62:
  %t271 = load ptr, ptr %l1, !tbaa !29
  store ptr %t271, ptr %l146, !tbaa !29
  store i1 false, ptr %l147, !tbaa !21
  %t272 = load ptr, ptr %l146, !tbaa !29
  %t273 = icmp ne ptr %t272, null
  br i1 %t273, label %bb63, label %bb64
bb63:
  %t275 = load ptr, ptr %l146, !tbaa !29
  %t276 = load i64, ptr %t275, !range !{i64 0, i64 29}
  %t278 = icmp eq i64 %t276, 2
  store i1 %t278, ptr %l147, !tbaa !21
  br label %bb64
bb64:
  %t279 = load i1, ptr %l147, !tbaa !21
  br i1 %t279, label %bb65, label %bb66
bb65:
  %t280 = load ptr, ptr %l1, !tbaa !29
  %t282 = getelementptr { i64, [5 x i64] }, ptr %t280, i32 0, i32 1
  %t283 = getelementptr { %"compiler/source:Span", ptr }, ptr %t282, i32 0, i32 1
  %t284 = load ptr, ptr %t283
  store ptr %t284, ptr %l7, !tbaa !29
  br label %bb67
bb66:
  br label %bb69
bb67:
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t287 = load ptr, ptr %l7, !tbaa !29
  %t290 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %t286, ptr %t287)
  store ptr %t290, ptr %l154
  br label %bb68
bb68:
  %t291 = load ptr, ptr %l154, !tbaa !29
  store ptr %t291, ptr %rv
  br label %ret
bb69:
  %t292 = load ptr, ptr %l1, !tbaa !29
  store ptr %t292, ptr %l155, !tbaa !29
  store i1 false, ptr %l156, !tbaa !21
  %t293 = load ptr, ptr %l155, !tbaa !29
  %t294 = icmp ne ptr %t293, null
  br i1 %t294, label %bb70, label %bb71
bb70:
  %t296 = load ptr, ptr %l155, !tbaa !29
  %t297 = load i64, ptr %t296, !range !{i64 0, i64 29}
  %t299 = icmp eq i64 %t297, 15
  store i1 %t299, ptr %l156, !tbaa !21
  br label %bb71
bb71:
  %t300 = load i1, ptr %l156, !tbaa !21
  br i1 %t300, label %bb72, label %bb73
bb72:
  %t301 = load ptr, ptr %l1, !tbaa !29
  %t303 = getelementptr { i64, [5 x i64] }, ptr %t301, i32 0, i32 1
  %t304 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t303, i32 0, i32 0
  %t305 = load %"compiler/source:Span", ptr %t304
  store %"compiler/source:Span" %t305, ptr %l8
  %t307 = load ptr, ptr %l1, !tbaa !29
  %t309 = getelementptr { i64, [5 x i64] }, ptr %t307, i32 0, i32 1
  %t310 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t309, i32 0, i32 1
  %t311 = load ptr, ptr %t310
  store ptr %t311, ptr %l9, !tbaa !29
  %t313 = load ptr, ptr %l1, !tbaa !29
  %t315 = getelementptr { i64, [5 x i64] }, ptr %t313, i32 0, i32 1
  %t316 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t315, i32 0, i32 2
  %t317 = load i32, ptr %t316
  store i32 %t317, ptr %l10, !tbaa !23
  br label %bb74
bb73:
  br label %bb102
bb74:
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t321 = getelementptr %"compiler/check:Checker", ptr %t319, i32 0, i32 1
  %t322 = load ptr, ptr %t321, !tbaa !29
  %t324 = getelementptr %"compiler/generic:Program", ptr %t322, i32 0, i32 1
  %t325 = load ptr, ptr %t324, !tbaa !29
  store ptr %t325, ptr %l167, !tbaa !29
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t328 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t326)
  store ptr %t328, ptr %l169
  br label %bb75
bb75:
  %t329 = load ptr, ptr %l169, !tbaa !29
  %t331 = getelementptr %"compiler/check:frame", ptr %t329, i32 0, i32 2
  %t332 = load i64, ptr %t331, !tbaa !24
  %t333 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 1
  %t334 = load i32, ptr %t333, !tbaa !23
  %t335 = load ptr, ptr %l167, !tbaa !29
  %t338 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %t335, i64 %t332, i32 %t334)
  store %"compiler/names:Ref" %t338, ptr %l173
  br label %bb76
bb76:
  %t339 = load %"compiler/names:Ref", ptr %l173
  store %"compiler/names:Ref" %t339, ptr %l11
  %t340 = getelementptr %"compiler/names:Ref", ptr %l11, i32 0, i32 0
  %t341 = load i32, ptr %t340, !range !{i32 0, i32 9}
  %t343 = trunc i64 2 to i32
  %t344 = icmp eq i32 %t341, %t343
  br i1 %t344, label %bb77, label %bb78
bb77:
  %t346 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t346, ptr %l176
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t348 = getelementptr %"compiler/names:Ref", ptr %l11, i32 0, i32 1
  %t349 = load i64, ptr %t348, !tbaa !24
  %t350 = load i32, ptr %l10, !tbaa !23
  %t354 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalType(ptr %v0, ptr %t347, i64 %t349, i32 %t350)
  store i32 %t354, ptr %l180
  br label %bb79
bb78:
  br label %bb80
bb79:
  %t355 = getelementptr %"compiler/names:Ref", ptr %l11, i32 0, i32 1
  %t356 = load i64, ptr %t355, !tbaa !24
  %t357 = load i32, ptr %l10, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t358
  %t359 = getelementptr { i64, [4 x i64] }, ptr %t358, i32 0, i32 0
  store i64 1, ptr %t359
  %t360 = load %"compiler/source:Span", ptr %l176
  %t361 = insertvalue { %"compiler/source:Span", i32, i64, i32 } undef, %"compiler/source:Span" %t360, 0
  %t362 = load i32, ptr %l180, !tbaa !23
  %t363 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t361, i32 %t362, 1
  %t365 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t363, i64 %t356, 2
  %t367 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t365, i32 %t357, 3
  %t368 = getelementptr { i64, [4 x i64] }, ptr %t358, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, i32 } %t367, ptr %t368
  %t369 = load { i64, [4 x i64] }, ptr %t358
  %t371 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t369, ptr %t371
  store ptr %t371, ptr %rv
  br label %ret
bb80:
  %t373 = getelementptr %"compiler/names:Ref", ptr %l11, i32 0, i32 0
  %t374 = load i32, ptr %t373, !range !{i32 0, i32 9}
  %t376 = trunc i64 0 to i32
  %t377 = icmp eq i32 %t374, %t376
  br i1 %t377, label %bb81, label %bb82
bb81:
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t380 = load ptr, ptr %l9, !tbaa !29
  %t383 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t379, ptr %t380)
  store i32 %t383, ptr %l190
  br label %bb83
bb82:
  store i1 false, ptr %l187, !tbaa !21
  br label %bb84
bb83:
  %t384 = load i32, ptr %l190, !tbaa !23
  %t385 = icmp slt i32 %t384, 0
  store i1 %t385, ptr %l187, !tbaa !21
  br label %bb84
bb84:
  %t387 = load i1, ptr %l187, !tbaa !21
  br i1 %t387, label %bb85, label %bb86
bb85:
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t389 = load ptr, ptr %l9, !tbaa !29
  %t390 = load i32, ptr %l10, !tbaa !23
  %t394 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowedName(ptr %v0, ptr %v1, ptr %t388, ptr %t389, i32 %t390)
  store i64 %t394, ptr %l195
  br label %bb87
bb86:
  br label %bb101
bb87:
  %t395 = load i64, ptr %l195, !tbaa !24
  store i64 %t395, ptr %l12, !tbaa !24
  %t396 = load i64, ptr %l12, !tbaa !24
  %t398 = icmp sge i64 %t396, 0
  br i1 %t398, label %bb88, label %bb89
bb88:
  %t400 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t400, ptr %l198
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t402 = load i64, ptr %l12, !tbaa !24
  %t405 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t401, i64 %t402)
  store i32 %t405, ptr %l201
  br label %bb90
bb89:
  br label %bb93
bb90:
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t407 = load %"compiler/source:Span", ptr %l8
  %t408 = load i64, ptr %l12, !tbaa !24
  %t412 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t406, %"compiler/source:Span" %t407, i64 %t408)
  store ptr %t412, ptr %l205
  br label %bb91
bb91:
  %t413 = load ptr, ptr %l0, !tbaa !29
  %t414 = load %"compiler/source:Span", ptr %l8
  %t418 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t413, i32 8, %"compiler/source:Span" %t414)
  store i32 %t418, ptr %l209
  br label %bb92
bb92:
  store { i64, [4 x i64] } zeroinitializer, ptr %t419
  %t420 = getelementptr { i64, [4 x i64] }, ptr %t419, i32 0, i32 0
  store i64 6, ptr %t420
  %t421 = load %"compiler/source:Span", ptr %l198
  %t422 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t421, 0
  %t423 = load i32, ptr %l201, !tbaa !23
  %t424 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t422, i32 %t423, 1
  %t425 = load ptr, ptr %l205, !tbaa !29
  %t426 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t424, ptr %t425, 2
  %t427 = load i32, ptr %l209, !tbaa !23
  %t428 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t426, i32 %t427, 3
  %t429 = getelementptr { i64, [4 x i64] }, ptr %t419, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t428, ptr %t429
  %t430 = load { i64, [4 x i64] }, ptr %t419
  %t432 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t430, ptr %t432
  store ptr %t432, ptr %rv
  br label %ret
bb93:
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t435 = load ptr, ptr %l9, !tbaa !29
  %t438 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %t434, ptr %t435)
  store ptr %t438, ptr %l214
  br label %bb94
bb94:
  %t439 = load ptr, ptr %l214, !tbaa !29
  store ptr %t439, ptr %l13, !tbaa !29
  %t440 = load ptr, ptr %l13, !tbaa !29
  %t442 = icmp eq ptr %t440, null
  br i1 %t442, label %bb95, label %bb96
bb95:
  store ptr null, ptr %rv
  br label %ret
bb96:
  br label %bb97
bb97:
  %t445 = load ptr, ptr %l0, !tbaa !29
  store ptr %t445, ptr %l218, !tbaa !29
  %t446 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t446, ptr %l219
  %t447 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t447, ptr %l220
  %t448 = load ptr, ptr %l0, !tbaa !29
  %t449 = load i32, ptr %l10, !tbaa !23
  %t452 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t448, i32 %t449)
  store { i64, ptr } %t452, ptr %l223
  br label %bb98
bb98:
  %t453 = load { i64, ptr }, ptr %l223, !tbaa !27
  %t454 = extractvalue { i64, ptr } %t453, 0
  %t455 = load %"compiler/source:Span", ptr %l220
  %t457 = call %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %t455, i64 %t454)
  store %"compiler/source:Span" %t457, ptr %l225
  br label %bb99
bb99:
  %t458 = load ptr, ptr %l13, !tbaa !29
  %t459 = load i32, ptr %l10, !tbaa !23
  %t460 = load ptr, ptr %l218, !tbaa !29
  %t461 = load %"compiler/source:Span", ptr %l219
  %t462 = load %"compiler/source:Span", ptr %l225
  %t465 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efield(ptr %v0, ptr %t460, %"compiler/source:Span" %t461, %"compiler/source:Span" %t462, ptr %t458, i32 %t459)
  store ptr %t465, ptr %l228
  br label %bb100
bb100:
  %t466 = load ptr, ptr %l228, !tbaa !29
  store ptr %t466, ptr %rv
  br label %ret
bb101:
  br label %bb153
bb102:
  %t467 = load ptr, ptr %l1, !tbaa !29
  store ptr %t467, ptr %l229, !tbaa !29
  store i1 false, ptr %l230, !tbaa !21
  %t468 = load ptr, ptr %l229, !tbaa !29
  %t469 = icmp ne ptr %t468, null
  br i1 %t469, label %bb103, label %bb104
bb103:
  %t471 = load ptr, ptr %l229, !tbaa !29
  %t472 = load i64, ptr %t471, !range !{i64 0, i64 29}
  %t474 = icmp eq i64 %t472, 16
  store i1 %t474, ptr %l230, !tbaa !21
  br label %bb104
bb104:
  %t475 = load i1, ptr %l230, !tbaa !21
  br i1 %t475, label %bb105, label %bb106
bb105:
  %t476 = load ptr, ptr %l1, !tbaa !29
  %t478 = getelementptr { i64, [5 x i64] }, ptr %t476, i32 0, i32 1
  %t479 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t478, i32 0, i32 0
  %t480 = load %"compiler/source:Span", ptr %t479
  store %"compiler/source:Span" %t480, ptr %l14
  %t482 = load ptr, ptr %l1, !tbaa !29
  %t484 = getelementptr { i64, [5 x i64] }, ptr %t482, i32 0, i32 1
  %t485 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t484, i32 0, i32 1
  %t486 = load ptr, ptr %t485
  store ptr %t486, ptr %l15, !tbaa !29
  %t488 = load ptr, ptr %l1, !tbaa !29
  %t490 = getelementptr { i64, [5 x i64] }, ptr %t488, i32 0, i32 1
  %t491 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t490, i32 0, i32 2
  %t492 = load { i64, ptr }, ptr %t491
  store { i64, ptr } %t492, ptr %l16, !tbaa !27
  br label %bb107
bb106:
  br label %bb117
bb107:
  %t494 = load ptr, ptr %l0, !tbaa !29
  %t495 = load ptr, ptr %l15, !tbaa !29
  %t498 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t494, ptr %t495)
  store i32 %t498, ptr %l241
  br label %bb108
bb108:
  %t499 = load i32, ptr %l241, !tbaa !23
  %t500 = icmp slt i32 %t499, 0
  br i1 %t500, label %bb109, label %bb110
bb109:
  %t502 = load ptr, ptr %l0, !tbaa !29
  %t503 = load ptr, ptr %l15, !tbaa !29
  %t506 = call %"compiler/check:reflList" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistOf(ptr %v0, ptr %v1, ptr %t502, ptr %t503)
  store %"compiler/check:reflList" %t506, ptr %l246
  br label %bb111
bb110:
  store i1 false, ptr %l243, !tbaa !21
  br label %bb112
bb111:
  %t507 = getelementptr %"compiler/check:reflList", ptr %l246, i32 0, i32 0
  %t508 = load i1, ptr %t507, !tbaa !21
  %t510 = xor i1 %t508, true
  store i1 %t510, ptr %l243, !tbaa !21
  br label %bb112
bb112:
  %t512 = load i1, ptr %l243, !tbaa !21
  br i1 %t512, label %bb113, label %bb114
bb113:
  %t513 = load ptr, ptr %l0, !tbaa !29
  %t514 = load %"compiler/source:Span", ptr %l14
  %t515 = load ptr, ptr %l15, !tbaa !29
  %t516 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t521 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eindexPlace(ptr %v0, ptr %v1, ptr %v1, ptr %t513, %"compiler/source:Span" %t514, ptr %t515, { i64, ptr } %t516)
  store ptr %t521, ptr %l253
  br label %bb115
bb114:
  br label %bb116
bb115:
  %t522 = load ptr, ptr %l253, !tbaa !29
  store ptr %t522, ptr %rv
  br label %ret
bb116:
  br label %bb153
bb117:
  %t523 = load ptr, ptr %l1, !tbaa !29
  store ptr %t523, ptr %l254, !tbaa !29
  store i1 false, ptr %l255, !tbaa !21
  %t524 = load ptr, ptr %l254, !tbaa !29
  %t525 = icmp ne ptr %t524, null
  br i1 %t525, label %bb118, label %bb119
bb118:
  %t527 = load ptr, ptr %l254, !tbaa !29
  %t528 = load i64, ptr %t527, !range !{i64 0, i64 29}
  %t530 = icmp eq i64 %t528, 12
  store i1 %t530, ptr %l255, !tbaa !21
  br label %bb119
bb119:
  %t531 = load i1, ptr %l255, !tbaa !21
  br i1 %t531, label %bb120, label %bb121
bb120:
  %t532 = load ptr, ptr %l1, !tbaa !29
  %t534 = getelementptr { i64, [5 x i64] }, ptr %t532, i32 0, i32 1
  %t535 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t534, i32 0, i32 0
  %t536 = load %"compiler/source:Span", ptr %t535
  store %"compiler/source:Span" %t536, ptr %l17
  %t538 = load ptr, ptr %l1, !tbaa !29
  %t540 = getelementptr { i64, [5 x i64] }, ptr %t538, i32 0, i32 1
  %t541 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t540, i32 0, i32 1
  %t542 = load ptr, ptr %t541
  store ptr %t542, ptr %l18, !tbaa !29
  %t544 = load ptr, ptr %l1, !tbaa !29
  %t546 = getelementptr { i64, [5 x i64] }, ptr %t544, i32 0, i32 1
  %t547 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t546, i32 0, i32 2
  %t548 = load { i64, ptr }, ptr %t547
  store { i64, ptr } %t548, ptr %l19, !tbaa !27
  br label %bb122
bb121:
  br label %bb148
bb122:
  %t550 = load ptr, ptr %l18, !tbaa !29
  store ptr %t550, ptr %l264, !tbaa !29
  store i1 false, ptr %l265, !tbaa !21
  %t551 = load ptr, ptr %l264, !tbaa !29
  %t552 = icmp ne ptr %t551, null
  br i1 %t552, label %bb123, label %bb124
bb123:
  %t554 = load ptr, ptr %l264, !tbaa !29
  %t555 = load i64, ptr %t554, !range !{i64 0, i64 29}
  %t557 = icmp eq i64 %t555, 15
  store i1 %t557, ptr %l265, !tbaa !21
  br label %bb124
bb124:
  %t558 = load i1, ptr %l265, !tbaa !21
  br i1 %t558, label %bb125, label %bb126
bb125:
  %t559 = load ptr, ptr %l18, !tbaa !29
  %t561 = getelementptr { i64, [5 x i64] }, ptr %t559, i32 0, i32 1
  %t562 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t561, i32 0, i32 0
  %t563 = load %"compiler/source:Span", ptr %t562
  store %"compiler/source:Span" %t563, ptr %l20
  %t565 = load ptr, ptr %l18, !tbaa !29
  %t567 = getelementptr { i64, [5 x i64] }, ptr %t565, i32 0, i32 1
  %t568 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t567, i32 0, i32 1
  %t569 = load ptr, ptr %t568
  store ptr %t569, ptr %l21, !tbaa !29
  %t571 = load ptr, ptr %l18, !tbaa !29
  %t573 = getelementptr { i64, [5 x i64] }, ptr %t571, i32 0, i32 1
  %t574 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t573, i32 0, i32 2
  %t575 = load i32, ptr %t574
  store i32 %t575, ptr %l22, !tbaa !23
  br label %bb127
bb126:
  br label %bb142
bb127:
  store %olang.scope zeroinitializer, ptr %s18
  %t577 = load ptr, ptr %l0, !tbaa !29
  %t578 = load i32, ptr %l22, !tbaa !23
  %t581 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t577, i32 %t578)
  store { i64, ptr } %t581, ptr %l276
  br label %bb128
bb128:
  %t582 = load { i64, ptr }, ptr %l276, !tbaa !27
  %t583 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s18, { i64, ptr } %t582, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d27, i32 0, i32 1) })
  store i1 %t583, ptr %l277
  br label %bb129
bb129:
  %t584 = load i1, ptr %l277, !tbaa !21
  br i1 %t584, label %bb130, label %bb131
bb130:
  %t585 = load ptr, ptr %l0, !tbaa !29
  %t586 = load ptr, ptr %l21, !tbaa !29
  %t589 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %t585, ptr %t586)
  store i32 %t589, ptr %l280
  br label %bb132
bb131:
  br label %bb141
bb132:
  %t590 = load i32, ptr %l280, !tbaa !23
  store i32 %t590, ptr %l23, !tbaa !23
  %t591 = load i32, ptr %l23, !tbaa !23
  %t593 = icmp sge i32 %t591, 0
  br i1 %t593, label %bb133, label %bb134
bb133:
  %t595 = load i32, ptr %l23, !tbaa !23
  %t596 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t599 = icmp eq i32 %t595, %t596
  br i1 %t599, label %bb135, label %bb136
bb134:
  br label %bb140
bb135:
  call void @__olang_scope_close(ptr %s18)
  store ptr null, ptr %rv
  br label %ret
bb136:
  br label %bb137
bb137:
  %t602 = load ptr, ptr %l0, !tbaa !29
  store ptr %t602, ptr %l287, !tbaa !29
  %t603 = load %"compiler/source:Span", ptr %l17
  store %"compiler/source:Span" %t603, ptr %l288
  %t604 = load %"compiler/source:Span", ptr %l20
  %t606 = call %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %t604, i64 2)
  store %"compiler/source:Span" %t606, ptr %l290
  br label %bb138
bb138:
  %t607 = load i32, ptr %l23, !tbaa !23
  %t608 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t609 = load ptr, ptr %l287, !tbaa !29
  %t610 = load %"compiler/source:Span", ptr %l288
  %t611 = load %"compiler/source:Span", ptr %l290
  %t614 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflOf(ptr %v0, ptr %v1, ptr %t609, %"compiler/source:Span" %t610, %"compiler/source:Span" %t611, i32 %t607, { i64, ptr } %t608)
  store ptr %t614, ptr %l293
  br label %bb139
bb139:
  call void @__olang_scope_close(ptr %s18)
  %t615 = load ptr, ptr %l293, !tbaa !29
  store ptr %t615, ptr %rv
  br label %ret
bb140:
  br label %bb141
bb141:
  call void @__olang_scope_close(ptr %s18)
  br label %bb147
bb142:
  br i1 true, label %bb143, label %bb144
bb143:
  br label %bb145
bb144:
  br label %bb146
bb145:
  br label %bb147
bb146:
  call void @__olang_check_failed(ptr @olang_loc_c89e58dd43b8c5a0_98fae7e2dc40ed34)
  unreachable
bb147:
  br label %bb153
bb148:
  br i1 true, label %bb149, label %bb150
bb149:
  br label %bb151
bb150:
  br label %bb152
bb151:
  br label %bb153
bb152:
  call void @__olang_check_failed(ptr @olang_loc_69ec6e21e27849b1_edfd59555f73f465)
  unreachable
bb153:
  %t616 = load ptr, ptr %l0, !tbaa !29
  %t617 = load ptr, ptr %l1, !tbaa !29
  %t619 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t623 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t616, ptr %t617, i32 %t619)
  store ptr %t623, ptr %l298
  br label %bb154
bb154:
  %t624 = load ptr, ptr %l298, !tbaa !29
  store ptr %t624, ptr %l24, !tbaa !29
  %t625 = load ptr, ptr %l24, !tbaa !29
  %t628 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t625)
  store i32 %t628, ptr %l301
  br label %bb155
bb155:
  %t629 = load i32, ptr %l301, !tbaa !23
  store i32 %t629, ptr %l25, !tbaa !23
  %t630 = load i32, ptr %l25, !tbaa !23
  %t631 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t634 = icmp eq i32 %t630, %t631
  br i1 %t634, label %bb156, label %bb157
bb156:
  store ptr null, ptr %rv
  br label %ret
bb157:
  br label %bb158
bb158:
  %t637 = load ptr, ptr %l24, !tbaa !29
  %t639 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %t637)
  store ptr %t639, ptr %l307
  br label %bb159
bb159:
  %t640 = load ptr, ptr %l307, !tbaa !29
  store ptr %t640, ptr %l26, !tbaa !29
  %t641 = load ptr, ptr %l26, !tbaa !29
  %t643 = icmp eq ptr %t641, null
  %t645 = xor i1 %t643, true
  br i1 %t645, label %bb160, label %bb161
bb160:
  %t647 = load ptr, ptr %l26, !tbaa !29
  store ptr %t647, ptr %rv
  br label %ret
bb161:
  br label %bb162
bb162:
  %t650 = load ptr, ptr %l1, !tbaa !29
  %t652 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t650)
  store %"compiler/source:Span" %t652, ptr %l314
  br label %bb163
bb163:
  %t653 = load i32, ptr %l25, !tbaa !23
  store i32 %t653, ptr %l315, !tbaa !23
  %t654 = load ptr, ptr %l24, !tbaa !29
  store ptr %t654, ptr %l316, !tbaa !29
  %t655 = load ptr, ptr %l0, !tbaa !29
  store ptr %t655, ptr %l317, !tbaa !29
  store i32 8, ptr %l318
  %t656 = load ptr, ptr %l1, !tbaa !29
  %t658 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t656)
  store %"compiler/source:Span" %t658, ptr %l320
  br label %bb164
bb164:
  %t659 = load ptr, ptr %l317, !tbaa !29
  %t660 = load i32, ptr %l318, !range !{i32 0, i32 9}
  %t661 = load %"compiler/source:Span", ptr %l320
  %t662 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t659, i32 %t660, %"compiler/source:Span" %t661)
  store i32 %t662, ptr %l321
  br label %bb165
bb165:
  store { i64, [4 x i64] } zeroinitializer, ptr %t663
  %t664 = getelementptr { i64, [4 x i64] }, ptr %t663, i32 0, i32 0
  store i64 6, ptr %t664
  %t665 = load %"compiler/source:Span", ptr %l314
  %t666 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t665, 0
  %t667 = load i32, ptr %l315, !tbaa !23
  %t668 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t666, i32 %t667, 1
  %t669 = load ptr, ptr %l316, !tbaa !29
  %t670 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t668, ptr %t669, 2
  %t671 = load i32, ptr %l321, !tbaa !23
  %t672 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t670, i32 %t671, 3
  %t673 = getelementptr { i64, [4 x i64] }, ptr %t663, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t672, ptr %t673
  %t674 = load { i64, [4 x i64] }, ptr %t663
  %t676 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t674, ptr %t676
  store ptr %t676, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainField(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l6 = alloca i32
  %l9 = alloca i1
  %l10 = alloca i1
  %l14 = alloca i1
  %l17 = alloca i1
  %l23 = alloca i32
  %l28 = alloca ptr
  %l33 = alloca i32
  %l34 = alloca i32
  %l37 = alloca i1
  %l38 = alloca ptr
  %l43 = alloca i32
  %l46 = alloca i1
  %l50 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i32, ptr %l6, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l3, !tbaa !23
  %t11 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecNumber(ptr %v0, ptr %t7, i32 %t8)
  store i1 %t11, ptr %l9
  br label %bb2
bb2:
  %t12 = load i1, ptr %l9, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb5
bb4:
  %t13 = load i32, ptr %l3, !tbaa !23
  %t14 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t17 = icmp eq i32 %t13, %t14
  store i1 %t17, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l10, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb9
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  %t24 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforeignRef(ptr %v0, ptr %t20, i32 %t21)
  store i1 %t24, ptr %l17
  br label %bb8
bb8:
  %t25 = load i1, ptr %l17, !tbaa !21
  store i1 %t25, ptr %l14, !tbaa !21
  br label %bb9
bb9:
  %t26 = load i1, ptr %l14, !tbaa !21
  br i1 %t26, label %bb10, label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  %t34 = load i32, ptr %l3, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l23
  br label %bb13
bb13:
  %t38 = load i32, ptr %l23, !range !{i32 0, i32 33}
  %t40 = trunc i64 19 to i32
  %t41 = icmp eq i32 %t38, %t40
  br i1 %t41, label %bb14, label %bb15
bb14:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 2
  store ptr %t48, ptr %l28, !tbaa !29
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/generic:Program", ptr %t52, i32 0, i32 2
  %t55 = load i32, ptr %l3, !tbaa !23
  %t58 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t54, i32 %t55)
  store i32 %t58, ptr %l33
  br label %bb16
bb15:
  br label %bb23
bb16:
  %t59 = load ptr, ptr %l28, !tbaa !29
  %t60 = load i32, ptr %l33, !tbaa !23
  %t61 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t59, i32 %t60)
  store i32 %t61, ptr %l34
  br label %bb17
bb17:
  %t62 = load i32, ptr %l34, !range !{i32 0, i32 33}
  %t64 = trunc i64 26 to i32
  %t65 = icmp eq i32 %t62, %t64
  br i1 %t65, label %bb18, label %bb19
bb18:
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l38, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/check:Checker", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/generic:Program", ptr %t71, i32 0, i32 2
  %t74 = load i32, ptr %l3, !tbaa !23
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t73, i32 %t74)
  store i32 %t77, ptr %l43
  br label %bb20
bb19:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb22
bb20:
  %t78 = load i64, ptr %l2, !tbaa !24
  %t80 = add i64 %t78, 1
  %t81 = load ptr, ptr %l38, !tbaa !29
  %t82 = load i32, ptr %l43, !tbaa !23
  %t84 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainField(ptr %v0, ptr %t81, i32 %t82, i64 %t80)
  store i1 %t84, ptr %l46
  br label %bb21
bb21:
  %t85 = load i1, ptr %l46, !tbaa !21
  store i1 %t85, ptr %l37, !tbaa !21
  br label %bb22
bb22:
  %t86 = load i1, ptr %l37, !tbaa !21
  store i1 %t86, ptr %rv
  br label %ret
bb23:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load i32, ptr %l1, !tbaa !23
  %t89 = load i64, ptr %l2, !tbaa !24
  %t93 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainStruct(ptr %v0, ptr %t87, i32 %t88, i64 %t89)
  store i1 %t93, ptr %l50
  br label %bb24
bb24:
  %t94 = load i1, ptr %l50, !tbaa !21
  store i1 %t94, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroArgFor(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i64 %a2, ptr %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i1
  %l17 = alloca ptr
  %l20 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i1
  %l28 = alloca i1
  %l32 = alloca ptr
  %l35 = alloca ptr
  %l38 = alloca ptr
  %l42 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca i32
  %l53 = alloca i1
  %l58 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca i64
  %l62 = alloca i64
  %l65 = alloca { i64, [3 x i64] }
  %l66 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l71 = alloca %"compiler/check:roArg"
  %l72 = alloca ptr
  %l73 = alloca i1
  %l81 = alloca i64
  %l85 = alloca ptr
  %l88 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l91 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l92 = alloca %"std/pair:Pair.b139c4f75a6545712256427180a82a06"
  %l95 = alloca i1
  %l97 = alloca ptr
  %l102 = alloca %"compiler/check:roDeepArg"
  %l103 = alloca ptr
  %l106 = alloca i32
  %l107 = alloca i1
  %l112 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca i64
  %l116 = alloca i64
  %l119 = alloca { i64, [3 x i64] }
  %l120 = alloca { i64, ptr }
  %l121 = alloca ptr
  %l124 = alloca i32
  %l125 = alloca { i64, ptr }
  %l126 = alloca { i64, ptr }
  %l127 = alloca ptr
  %l130 = alloca i32
  %l133 = alloca i32
  %l134 = alloca { i64, ptr }
  %l136 = alloca %"compiler/check:roArg"
  %l137 = alloca ptr
  %l139 = alloca ptr
  %l140 = alloca i64
  %l144 = alloca ptr
  %l147 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l150 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l151 = alloca %"std/pair:Pair.b139c4f75a6545712256427180a82a06"
  %l154 = alloca i1
  %l156 = alloca ptr
  %l161 = alloca %"compiler/check:roDeepArg"
  %s7 = alloca %olang.scope
  %s12 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  store i1 %t7, ptr %l13, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l13, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t10)
  store ptr %t12, ptr %l17
  br label %bb7
bb7:
  %t13 = load ptr, ptr %l17, !tbaa !29
  %t15 = getelementptr %"compiler/check:frame", ptr %t13, i32 0, i32 0
  %t16 = load i64, ptr %t15, !tbaa !24
  store i64 %t16, ptr %l6, !tbaa !24
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l20, !tbaa !29
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t22 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t19)
  store i32 %t22, ptr %l23
  br label %bb8
bb8:
  %t23 = load ptr, ptr %l20, !tbaa !29
  %t24 = load i32, ptr %l23, !tbaa !23
  %t25 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t23, i32 %t24)
  store i1 %t25, ptr %l24
  br label %bb9
bb9:
  %t26 = load i1, ptr %l24, !tbaa !21
  br i1 %t26, label %bb10, label %bb11
bb10:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i64, ptr %l1, !tbaa !24
  %t29 = load i64, ptr %l2, !tbaa !24
  %t33 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %t27, i64 %t28, i64 %t29)
  store i1 %t33, ptr %l28
  br label %bb12
bb11:
  br label %bb57
bb12:
  %t34 = load i1, ptr %l28, !tbaa !21
  %t35 = xor i1 %t34, true
  br i1 %t35, label %bb13, label %bb14
bb13:
  br label %ret
bb14:
  br label %bb15
bb15:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 2
  store ptr %t42, ptr %l32, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 2
  store ptr %t48, ptr %l35, !tbaa !29
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/generic:Program", ptr %t52, i32 0, i32 2
  store ptr %t54, ptr %l38, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 12
  %t58 = load i64, ptr %l1, !tbaa !24
  %t61 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t57, i64 %t58)
  store ptr %t61, ptr %l42
  br label %bb16
bb16:
  %t62 = load ptr, ptr %l42, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Body", ptr %t62, i32 0, i32 2
  %t65 = load i32, ptr %t64, !tbaa !23
  %t66 = load ptr, ptr %l38, !tbaa !29
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t66, i32 %t65)
  store i32 %t68, ptr %l45
  br label %bb17
bb17:
  %t69 = load ptr, ptr %l35, !tbaa !29
  %t70 = load i32, ptr %l45, !tbaa !23
  %t71 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t69, i32 %t70)
  store { i64, ptr } %t71, ptr %l46
  br label %bb18
bb18:
  %t72 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t72, ptr %l47, !tbaa !27
  %t73 = load i64, ptr %l2, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr i32, ptr %t76, i64 %t73
  %t78 = load i32, ptr %t77, !tbaa !33
  %t79 = load ptr, ptr %l32, !tbaa !29
  %t81 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t79, i32 %t78)
  store i32 %t81, ptr %l50
  br label %bb19
bb19:
  %t82 = load i32, ptr %l50, !tbaa !23
  store i32 %t82, ptr %l7, !tbaa !23
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i32, ptr %l7, !tbaa !23
  %t87 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedHolds(ptr %v0, ptr %t83, i32 %t84)
  store i1 %t87, ptr %l53
  br label %bb20
bb20:
  %t88 = load i1, ptr %l53, !tbaa !21
  %t89 = xor i1 %t88, true
  br i1 %t89, label %bb21, label %bb22
bb21:
  br label %ret
bb22:
  br label %bb23
bb23:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l3, !tbaa !29
  %t96 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %t91, ptr %t92)
  store i1 %t96, ptr %l58
  br label %bb24
bb24:
  %t97 = load i1, ptr %l58, !tbaa !21
  br i1 %t97, label %bb25, label %bb26
bb25:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/check:Checker", ptr %t98, i32 0, i32 73
  store ptr %t100, ptr %l60, !tbaa !29
  %t101 = load i64, ptr %l1, !tbaa !24
  store i64 %t101, ptr %l61, !tbaa !24
  %t102 = load i64, ptr %l2, !tbaa !24
  store i64 %t102, ptr %l62, !tbaa !24
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load %"compiler/source:Span", ptr %l4
  %t107 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t103, %"compiler/source:Span" %t104)
  store { i64, [3 x i64] } %t107, ptr %l65
  br label %bb27
bb26:
  br label %bb31
bb27:
  %t108 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t108, ptr %l66, !tbaa !27
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load i32, ptr %l7, !tbaa !23
  %t113 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v0, ptr %t109, i32 %t110)
  store { i64, ptr } %t113, ptr %l69
  br label %bb28
bb28:
  %t114 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t114, 0
  %t116 = extractvalue { i64, ptr } %t114, 1
  %t117 = mul i64 %t115, 1
  %t118 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t117)
  call void @llvm.memcpy.p0.p0.i64(ptr %t118, ptr %t116, i64 %t117, i1 false)
  %t119 = insertvalue { i64, ptr } undef, i64 %t115, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t118, 1
  %t121 = load i64, ptr %l61, !tbaa !24
  %t122 = load i64, ptr %l62, !tbaa !24
  %t123 = load { i64, [3 x i64] }, ptr %l65
  %t124 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t126 = call %"compiler/check:roArg" @compiler_2fcheck_3aroArg_2ector(ptr %v2, ptr %v0, ptr %v0, ptr %v0, i64 %t121, i64 %t122, { i64, [3 x i64] } %t123, { i64, ptr } %t124, { i64, ptr } %t120, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d28, i32 0, i32 1) })
  store %"compiler/check:roArg" %t126, ptr %l71
  br label %bb29
bb29:
  %t127 = load ptr, ptr %l60, !tbaa !29
  %t128 = load %"compiler/check:roArg", ptr %l71
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroArg_3e_2ePush_3ccompiler_2fcheck_3aroArg_3e(ptr %v0, ptr %v0, ptr %t127, %"compiler/check:roArg" %t128)
  br label %bb30
bb30:
  br label %ret
bb31:
  %t129 = load ptr, ptr %l3, !tbaa !29
  store ptr %t129, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t130 = load ptr, ptr %l72, !tbaa !29
  %t131 = icmp ne ptr %t130, null
  br i1 %t131, label %bb32, label %bb33
bb32:
  %t133 = load ptr, ptr %l72, !tbaa !29
  %t134 = load i64, ptr %t133, !range !{i64 0, i64 18}
  %t136 = icmp eq i64 %t134, 3
  store i1 %t136, ptr %l73, !tbaa !21
  br label %bb33
bb33:
  %t137 = load i1, ptr %l73, !tbaa !21
  br i1 %t137, label %bb34, label %bb35
bb34:
  %t138 = load ptr, ptr %l3, !tbaa !29
  %t140 = getelementptr { i64, [5 x i64] }, ptr %t138, i32 0, i32 1
  %t141 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t140, i32 0, i32 2
  %t142 = load ptr, ptr %t141
  store ptr %t142, ptr %l8, !tbaa !29
  br label %bb36
bb35:
  br label %bb45
bb36:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load ptr, ptr %l8, !tbaa !29
  %t149 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamOf(ptr %v0, ptr %v1, ptr %t144, ptr %t145)
  store i64 %t149, ptr %l81
  br label %bb37
bb37:
  %t150 = load i64, ptr %l81, !tbaa !24
  store i64 %t150, ptr %l9, !tbaa !24
  %t151 = load i64, ptr %l9, !tbaa !24
  %t153 = icmp sge i64 %t151, 0
  br i1 %t153, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s7
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/check:Checker", ptr %t155, i32 0, i32 65
  store ptr %t157, ptr %l85, !tbaa !29
  %t158 = load i64, ptr %l6, !tbaa !24
  %t159 = load i64, ptr %l9, !tbaa !24
  %t162 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s7, i64 %t158, i64 %t159)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t162, ptr %l88
  br label %bb40
bb39:
  br label %bb44
bb40:
  %t163 = load i64, ptr %l1, !tbaa !24
  %t164 = load i64, ptr %l2, !tbaa !24
  %t167 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s7, i64 %t163, i64 %t164)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t167, ptr %l91
  br label %bb41
bb41:
  %t168 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l88
  %t169 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l91
  %t170 = call %"std/pair:Pair.b139c4f75a6545712256427180a82a06" @std_2fpair_3aPair_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20std_2fpair_3aPair_3cI64_2c_20I64_3e_3e_2ector(ptr %s7, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t168, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t169)
  store %"std/pair:Pair.b139c4f75a6545712256427180a82a06" %t170, ptr %l92
  br label %bb42
bb42:
  %t171 = load ptr, ptr %l85, !tbaa !29
  %t172 = load %"std/pair:Pair.b139c4f75a6545712256427180a82a06", ptr %l92
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cstd_2fpair_3aPair__H9be680f663aa81558c844970355ca108(ptr %v0, ptr %t171, %"std/pair:Pair.b139c4f75a6545712256427180a82a06" %t172)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s7)
  br label %bb44
bb44:
  br label %bb50
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_3ba07a3e63e86523_b4e2f85113e27c0f)
  unreachable
bb50:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i64, ptr %l6, !tbaa !24
  %t177 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %t173, i64 %t174)
  store i1 %t177, ptr %l95
  br label %bb51
bb51:
  %t178 = load i1, ptr %l95, !tbaa !21
  br i1 %t178, label %bb52, label %bb53
bb52:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t179, i32 0, i32 72
  store ptr %t181, ptr %l97, !tbaa !29
  %t182 = load i64, ptr %l6, !tbaa !24
  %t183 = load ptr, ptr %l3, !tbaa !29
  %t184 = load i64, ptr %l1, !tbaa !24
  %t185 = load i64, ptr %l2, !tbaa !24
  %t190 = call %"compiler/check:roDeepArg" @compiler_2fcheck_3aroDeepArg_2ector(ptr %v1, ptr %v0, i64 %t182, ptr %t183, i64 %t184, i64 %t185)
  store %"compiler/check:roDeepArg" %t190, ptr %l102
  br label %bb54
bb53:
  br label %bb56
bb54:
  %t191 = load ptr, ptr %l97, !tbaa !29
  %t192 = load %"compiler/check:roDeepArg", ptr %l102
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroDeepArg_3e_2ePush_H0e30e0389c54f9bfc05db61d637e277e(ptr %v0, ptr %v0, ptr %t191, %"compiler/check:roDeepArg" %t192)
  br label %bb55
bb55:
  br label %bb56
bb56:
  br label %ret
bb57:
  %t193 = load ptr, ptr %l0, !tbaa !29
  store ptr %t193, ptr %l103, !tbaa !29
  %t194 = load ptr, ptr %l3, !tbaa !29
  %t197 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t194)
  store i32 %t197, ptr %l106
  br label %bb58
bb58:
  %t198 = load ptr, ptr %l103, !tbaa !29
  %t199 = load i32, ptr %l106, !tbaa !23
  %t200 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %t198, i32 %t199)
  store i1 %t200, ptr %l107
  br label %bb59
bb59:
  %t201 = load i1, ptr %l107, !tbaa !21
  %t202 = xor i1 %t201, true
  br i1 %t202, label %bb60, label %bb61
bb60:
  br label %ret
bb61:
  br label %bb62
bb62:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load ptr, ptr %l3, !tbaa !29
  %t209 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroValue(ptr %v0, ptr %v1, ptr %t204, ptr %t205)
  store i1 %t209, ptr %l112
  br label %bb63
bb63:
  %t210 = load i1, ptr %l112, !tbaa !21
  br i1 %t210, label %bb64, label %bb65
bb64:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/check:Checker", ptr %t211, i32 0, i32 66
  store ptr %t213, ptr %l114, !tbaa !29
  %t214 = load i64, ptr %l1, !tbaa !24
  store i64 %t214, ptr %l115, !tbaa !24
  %t215 = load i64, ptr %l2, !tbaa !24
  store i64 %t215, ptr %l116, !tbaa !24
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load %"compiler/source:Span", ptr %l4
  %t220 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t216, %"compiler/source:Span" %t217)
  store { i64, [3 x i64] } %t220, ptr %l119
  br label %bb66
bb65:
  br label %bb74
bb66:
  %t221 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t221, ptr %l120, !tbaa !27
  %t222 = load ptr, ptr %l0, !tbaa !29
  store ptr %t222, ptr %l121, !tbaa !29
  %t223 = load ptr, ptr %l3, !tbaa !29
  %t226 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t223)
  store i32 %t226, ptr %l124
  br label %bb67
bb67:
  %t227 = load ptr, ptr %l121, !tbaa !29
  %t228 = load i32, ptr %l124, !tbaa !23
  %t229 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v0, ptr %t227, i32 %t228)
  store { i64, ptr } %t229, ptr %l125
  br label %bb68
bb68:
  %t230 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t231 = extractvalue { i64, ptr } %t230, 0
  %t232 = extractvalue { i64, ptr } %t230, 1
  %t233 = mul i64 %t231, 1
  %t234 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t233)
  call void @llvm.memcpy.p0.p0.i64(ptr %t234, ptr %t232, i64 %t233, i1 false)
  %t235 = insertvalue { i64, ptr } undef, i64 %t231, 0
  %t236 = insertvalue { i64, ptr } %t235, ptr %t234, 1
  store { i64, ptr } %t236, ptr %l126, !tbaa !27
  %t237 = load ptr, ptr %l0, !tbaa !29
  store ptr %t237, ptr %l127, !tbaa !29
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load ptr, ptr %l3, !tbaa !29
  %t242 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroName(ptr %v0, ptr %v1, ptr %t238, ptr %t239)
  store i32 %t242, ptr %l130
  br label %bb69
bb69:
  %t243 = load ptr, ptr %l3, !tbaa !29
  %t246 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t243)
  store i32 %t246, ptr %l133
  br label %bb70
bb70:
  %t247 = load ptr, ptr %l127, !tbaa !29
  %t248 = load i32, ptr %l130, !tbaa !23
  %t249 = load i32, ptr %l133, !tbaa !23
  %t250 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFix(ptr %v0, ptr %v0, ptr %t247, i32 %t248, i32 %t249)
  store { i64, ptr } %t250, ptr %l134
  br label %bb71
bb71:
  %t251 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t251, 0
  %t253 = extractvalue { i64, ptr } %t251, 1
  %t254 = mul i64 %t252, 1
  %t255 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t254)
  call void @llvm.memcpy.p0.p0.i64(ptr %t255, ptr %t253, i64 %t254, i1 false)
  %t256 = insertvalue { i64, ptr } undef, i64 %t252, 0
  %t257 = insertvalue { i64, ptr } %t256, ptr %t255, 1
  %t258 = load i64, ptr %l115, !tbaa !24
  %t259 = load i64, ptr %l116, !tbaa !24
  %t260 = load { i64, [3 x i64] }, ptr %l119
  %t261 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t262 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t264 = call %"compiler/check:roArg" @compiler_2fcheck_3aroArg_2ector(ptr %v2, ptr %v0, ptr %v0, ptr %v0, i64 %t258, i64 %t259, { i64, [3 x i64] } %t260, { i64, ptr } %t261, { i64, ptr } %t262, { i64, ptr } %t257)
  store %"compiler/check:roArg" %t264, ptr %l136
  br label %bb72
bb72:
  %t265 = load ptr, ptr %l114, !tbaa !29
  %t266 = load %"compiler/check:roArg", ptr %l136
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroArg_3e_2ePush_3ccompiler_2fcheck_3aroArg_3e(ptr %v0, ptr %v0, ptr %t265, %"compiler/check:roArg" %t266)
  br label %bb73
bb73:
  br label %ret
bb74:
  %t267 = load ptr, ptr %l0, !tbaa !29
  store ptr %t267, ptr %l137, !tbaa !29
  %t268 = load ptr, ptr %l3, !tbaa !29
  %t270 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %t268)
  store ptr %t270, ptr %l139
  br label %bb75
bb75:
  %t271 = load ptr, ptr %l137, !tbaa !29
  %t272 = load ptr, ptr %l139, !tbaa !29
  %t273 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamOf(ptr %v0, ptr %v1, ptr %t271, ptr %t272)
  store i64 %t273, ptr %l140
  br label %bb76
bb76:
  %t274 = load i64, ptr %l140, !tbaa !24
  store i64 %t274, ptr %l10, !tbaa !24
  %t275 = load i64, ptr %l10, !tbaa !24
  %t277 = icmp sge i64 %t275, 0
  br i1 %t277, label %bb77, label %bb78
bb77:
  store %olang.scope zeroinitializer, ptr %s12
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr %"compiler/check:Checker", ptr %t279, i32 0, i32 65
  store ptr %t281, ptr %l144, !tbaa !29
  %t282 = load i64, ptr %l6, !tbaa !24
  %t283 = load i64, ptr %l10, !tbaa !24
  %t286 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s12, i64 %t282, i64 %t283)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t286, ptr %l147
  br label %bb79
bb78:
  br label %bb83
bb79:
  %t287 = load i64, ptr %l1, !tbaa !24
  %t288 = load i64, ptr %l2, !tbaa !24
  %t291 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s12, i64 %t287, i64 %t288)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t291, ptr %l150
  br label %bb80
bb80:
  %t292 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l147
  %t293 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l150
  %t294 = call %"std/pair:Pair.b139c4f75a6545712256427180a82a06" @std_2fpair_3aPair_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20std_2fpair_3aPair_3cI64_2c_20I64_3e_3e_2ector(ptr %s12, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t292, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t293)
  store %"std/pair:Pair.b139c4f75a6545712256427180a82a06" %t294, ptr %l151
  br label %bb81
bb81:
  %t295 = load ptr, ptr %l144, !tbaa !29
  %t296 = load %"std/pair:Pair.b139c4f75a6545712256427180a82a06", ptr %l151
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cstd_2fpair_3aPair__H9be680f663aa81558c844970355ca108(ptr %v0, ptr %t295, %"std/pair:Pair.b139c4f75a6545712256427180a82a06" %t296)
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s12)
  br label %bb83
bb83:
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load i64, ptr %l6, !tbaa !24
  %t301 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %t297, i64 %t298)
  store i1 %t301, ptr %l154
  br label %bb84
bb84:
  %t302 = load i1, ptr %l154, !tbaa !21
  br i1 %t302, label %bb85, label %bb86
bb85:
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"compiler/check:Checker", ptr %t303, i32 0, i32 72
  store ptr %t305, ptr %l156, !tbaa !29
  %t306 = load i64, ptr %l6, !tbaa !24
  %t307 = load ptr, ptr %l3, !tbaa !29
  %t308 = load i64, ptr %l1, !tbaa !24
  %t309 = load i64, ptr %l2, !tbaa !24
  %t314 = call %"compiler/check:roDeepArg" @compiler_2fcheck_3aroDeepArg_2ector(ptr %v1, ptr %v0, i64 %t306, ptr %t307, i64 %t308, i64 %t309)
  store %"compiler/check:roDeepArg" %t314, ptr %l161
  br label %bb87
bb86:
  br label %bb89
bb87:
  %t315 = load ptr, ptr %l156, !tbaa !29
  %t316 = load %"compiler/check:roDeepArg", ptr %l161
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroDeepArg_3e_2ePush_H0e30e0389c54f9bfc05db61d637e277e(ptr %v0, ptr %v0, ptr %t315, %"compiler/check:roDeepArg" %t316)
  br label %bb88
bb88:
  br label %bb89
bb89:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLend(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca ptr
  %l15 = alloca i32
  %l18 = alloca i32
  %l19 = alloca { i64, ptr }
  %l21 = alloca %"compiler/msgs:Msg"
  %l22 = alloca i64
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t6 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroValue(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i1 %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load i1, ptr %l6, !tbaa !21
  br i1 %t7, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l7, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t15 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCallAt(ptr %v0, ptr %v1, ptr %t9, ptr %t10, %"compiler/source:Span" %a2)
  store %"compiler/source:Span" %t15, ptr %l11
  br label %bb4
bb3:
  br label %bb10
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l12, !tbaa !29
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t21 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroName(ptr %v0, ptr %v1, ptr %t17, ptr %t18)
  store i32 %t21, ptr %l15
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t25 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t22)
  store i32 %t25, ptr %l18
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l12, !tbaa !29
  %t27 = load i32, ptr %l15, !tbaa !23
  %t28 = load i32, ptr %l18, !tbaa !23
  %t29 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFix(ptr %v0, ptr %s1, ptr %t26, i32 %t27, i32 %t28)
  store { i64, ptr } %t29, ptr %l19
  br label %bb7
bb7:
  %t30 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t30, 0
  %t32 = extractvalue { i64, ptr } %t30, 1
  %t33 = mul i64 %t31, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t33)
  call void @llvm.memcpy.p0.p0.i64(ptr %t34, ptr %t32, i64 %t33, i1 false)
  %t35 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  %t38 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyLent(ptr %s1, ptr %s1, { i64, ptr } %t36)
  store %"compiler/msgs:Msg" %t38, ptr %l21
  br label %bb8
bb8:
  %t39 = load ptr, ptr %l7, !tbaa !29
  %t40 = load %"compiler/source:Span", ptr %l11
  %t41 = load %"compiler/msgs:Msg", ptr %l21
  %t42 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t39, %"compiler/source:Span" %t40, %"compiler/msgs:Msg" %t41)
  store i64 %t42, ptr %l22
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb10:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepNeed(ptr %v0, ptr %v1, ptr %t43, ptr %t44)
  br label %bb11
bb11:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootLocal(ptr %v0, ptr %v1, ptr %t1, ptr %a1)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i64, ptr %l2, !tbaa !24
  %t15 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLocal(ptr %v0, ptr %t11, i64 %t12)
  store i1 %t15, ptr %l11
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb5
bb4:
  %t16 = load i1, ptr %l11, !tbaa !21
  store i1 %t16, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l8, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t18 = load i64, ptr %l2, !tbaa !24
  store i64 %t18, ptr %l12, !tbaa !24
  br label %bb8
bb7:
  store i64 -1, ptr %l12, !tbaa !24
  br label %bb8
bb8:
  %t20 = load i64, ptr %l12, !tbaa !24
  store i64 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetLess(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca i64
  %l16 = alloca i64
  %l21 = alloca i32
  %l26 = alloca i64
  %l28 = alloca i64
  %l30 = alloca i64
  %l35 = alloca i32
  %l40 = alloca i32
  %l45 = alloca i32
  %l47 = alloca i64
  %l52 = alloca i64
  %l57 = alloca ptr
  %l62 = alloca i32
  %l64 = alloca i32
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l12
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 8, i64 8)
  store ptr %t2, ptr %lp3
  %t3 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  %t4 = load ptr, ptr %lp3
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  store ptr %a1, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l5, !tbaa !24
  store i64 %t7, ptr %l14, !tbaa !24
  %t8 = load ptr, ptr %l4, !tbaa !29
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t8)
  store i64 %t10, ptr %l16
  br label %bb3
bb3:
  %t11 = load i64, ptr %l14, !tbaa !24
  %t12 = load i64, ptr %l16, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb4, label %bb5
bb4:
  br label %bb30
bb5:
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t18 = load i64, ptr %l5, !tbaa !24
  %t21 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t17, i64 %t18)
  store i32 %t21, ptr %l21
  br label %bb7
bb7:
  %t22 = load i32, ptr %l21, !tbaa !23
  store i32 %t22, ptr %l6, !tbaa !23
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  %t29 = load i32, ptr %l6, !tbaa !23
  %t32 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t28, i32 %t29)
  store i64 %t32, ptr %l26
  br label %bb8
bb8:
  %t33 = load i64, ptr %l26, !tbaa !65
  store i64 %t33, ptr %l7, !tbaa !65
  store ptr %a2, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  %t36 = load i64, ptr %l9, !tbaa !24
  store i64 %t36, ptr %l28, !tbaa !24
  %t37 = load ptr, ptr %l8, !tbaa !29
  %t39 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t37)
  store i64 %t39, ptr %l30
  br label %bb10
bb10:
  %t40 = load i64, ptr %l28, !tbaa !24
  %t41 = load i64, ptr %l30, !tbaa !24
  %t42 = icmp slt i64 %t40, %t41
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb11, label %bb12
bb11:
  br label %bb22
bb12:
  br label %bb13
bb13:
  %t46 = load ptr, ptr %l8, !tbaa !29
  %t47 = load i64, ptr %l9, !tbaa !24
  %t50 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t46, i64 %t47)
  store i32 %t50, ptr %l35
  br label %bb14
bb14:
  %t51 = load i32, ptr %l35, !tbaa !23
  store i32 %t51, ptr %l10, !tbaa !23
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 2
  %t58 = load i32, ptr %l6, !tbaa !23
  %t61 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t57, i32 %t58)
  store i32 %t61, ptr %l40
  br label %bb15
bb15:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l10, !tbaa !23
  %t71 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t67, i32 %t68)
  store i32 %t71, ptr %l45
  br label %bb16
bb16:
  %t72 = load i32, ptr %l40, !tbaa !23
  %t73 = load i32, ptr %l45, !tbaa !23
  %t74 = icmp eq i32 %t72, %t73
  br i1 %t74, label %bb17, label %bb18
bb17:
  %t76 = load i64, ptr %l7, !tbaa !65
  store i64 %t76, ptr %l47, !tbaa !65
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/generic:Program", ptr %t80, i32 0, i32 2
  %t83 = load i32, ptr %l10, !tbaa !23
  %t86 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t82, i32 %t83)
  store i64 %t86, ptr %l52
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t87 = load i64, ptr %l52, !tbaa !65
  %t88 = xor i64 %t87, -1
  %t89 = load i64, ptr %l47, !tbaa !65
  %t91 = and i64 %t89, %t88
  store i64 %t91, ptr %l7, !tbaa !65
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t93 = load i64, ptr %l9, !tbaa !24
  %t95 = add i64 %t93, 1
  store i64 %t95, ptr %l9, !tbaa !24
  br label %bb9
bb22:
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l57, !tbaa !29
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/check:Checker", ptr %t98, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = getelementptr %"compiler/generic:Program", ptr %t101, i32 0, i32 2
  %t104 = load i32, ptr %l6, !tbaa !23
  %t107 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t103, i32 %t104)
  store i32 %t107, ptr %l62
  br label %bb23
bb23:
  %t108 = load i64, ptr %l7, !tbaa !65
  %t109 = load ptr, ptr %l57, !tbaa !29
  %t110 = load i32, ptr %l62, !tbaa !23
  %t112 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryOf(ptr %v0, ptr %t109, i32 %t110, i64 %t108)
  store i32 %t112, ptr %l64
  br label %bb24
bb24:
  %t113 = load i32, ptr %l64, !tbaa !23
  store i32 %t113, ptr %l11, !tbaa !23
  %t114 = load i32, ptr %l11, !tbaa !23
  %t115 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t118 = icmp ne i32 %t114, %t115
  br i1 %t118, label %bb25, label %bb26
bb25:
  %t120 = load ptr, ptr %lp3
  %t121 = load i32, ptr %l11, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v3, ptr %t120, i32 %t121)
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t124 = load i64, ptr %l5, !tbaa !24
  %t126 = add i64 %t124, 1
  store i64 %t126, ptr %l5, !tbaa !24
  br label %bb2
bb30:
  %t128 = load ptr, ptr %lp3
  %t129 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t128
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t129, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleUnread(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/typed:Local"
  %l8 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca %"compiler/names:Unread"
  %l13 = alloca { i64, [3 x i64] }
  %l19 = alloca i64
  %l25 = alloca i64
  %l27 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l30 = alloca i64
  %l32 = alloca i64
  %l37 = alloca ptr
  %l43 = alloca i64
  %l45 = alloca i64
  %l50 = alloca %"compiler/typed:Local"
  %l54 = alloca i1
  %l65 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l69 = alloca i1
  %l72 = alloca i1
  %l76 = alloca i1
  %l77 = alloca i1
  %l78 = alloca i1
  %l81 = alloca i1
  %l82 = alloca i32
  %l95 = alloca i64
  %l97 = alloca i64
  %l102 = alloca %"compiler/names:Unread"
  %l113 = alloca ptr
  %l114 = alloca { i64, [3 x i64] }
  %l117 = alloca { i64, ptr }
  %l119 = alloca %"compiler/msgs:Msg"
  %l120 = alloca i64
  %l128 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l129 = alloca i1
  %l132 = alloca i1
  %l133 = alloca i32
  %l138 = alloca ptr
  %l139 = alloca { i64, [3 x i64] }
  %l142 = alloca { i64, ptr }
  %l144 = alloca %"compiler/msgs:Msg"
  %l145 = alloca i64
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %t202 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/names:Resolver", ptr %t7, i32 0, i32 18
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aUnread_3e_2eLen_3ccompiler_2fnames_3aUnread_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l19
  br label %bb1
bb1:
  %t12 = load i64, ptr %l19, !tbaa !24
  %t13 = icmp eq i64 %t12, 0
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/generic:Program", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/load:Loader", ptr %t21, i32 0, i32 4
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %t24)
  store i64 %t26, ptr %l25
  br label %bb5
bb5:
  %t27 = load i64, ptr %l25, !tbaa !24
  %t28 = icmp sgt i64 %t27, 0
  br i1 %t28, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  br label %bb8
bb8:
  %t30 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t30, ptr %l27
  br label %bb9
bb9:
  %t31 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l27
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t31, ptr %l1
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 12
  store ptr %t34, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb10
bb10:
  %t36 = load i64, ptr %l3, !tbaa !24
  store i64 %t36, ptr %l30, !tbaa !24
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t37)
  store i64 %t39, ptr %l32
  br label %bb11
bb11:
  %t40 = load i64, ptr %l30, !tbaa !24
  %t41 = load i64, ptr %l32, !tbaa !24
  %t42 = icmp slt i64 %t40, %t41
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb12, label %bb13
bb12:
  br label %bb51
bb13:
  br label %bb14
bb14:
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t47 = load i64, ptr %l3, !tbaa !24
  %t50 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t46, i64 %t47)
  store ptr %t50, ptr %l37
  br label %bb15
bb15:
  %t51 = load ptr, ptr %l37, !tbaa !29
  store ptr %t51, ptr %l4, !tbaa !29
  %t52 = load ptr, ptr %l4, !tbaa !29
  %t54 = getelementptr %"compiler/typed:Body", ptr %t52, i32 0, i32 11
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = icmp eq ptr %t55, null
  br i1 %t57, label %bb16, label %bb17
bb16:
  br label %bb50
bb17:
  br label %bb18
bb18:
  %t59 = load ptr, ptr %l4, !tbaa !29
  %t61 = getelementptr %"compiler/typed:Body", ptr %t59, i32 0, i32 7
  store ptr %t61, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s7
  %t63 = load i64, ptr %l6, !tbaa !24
  store i64 %t63, ptr %l43, !tbaa !24
  %t64 = load ptr, ptr %l5, !tbaa !29
  %t66 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t64)
  store i64 %t66, ptr %l45
  br label %bb20
bb20:
  %t67 = load i64, ptr %l43, !tbaa !24
  %t68 = load i64, ptr %l45, !tbaa !24
  %t69 = icmp slt i64 %t67, %t68
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s7)
  br label %bb49
bb22:
  br label %bb23
bb23:
  %t73 = load ptr, ptr %l5, !tbaa !29
  %t74 = load i64, ptr %l6, !tbaa !24
  %t77 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t73, i64 %t74)
  store %"compiler/typed:Local" %t77, ptr %l50
  br label %bb24
bb24:
  %t78 = load %"compiler/typed:Local", ptr %l50
  store %"compiler/typed:Local" %t78, ptr %l7
  %t79 = getelementptr %"compiler/typed:Local", ptr %l7, i32 0, i32 4
  %t80 = load i32, ptr %t79, !range !{i32 0, i32 7}
  %t82 = trunc i64 1 to i32
  %t83 = icmp eq i32 %t80, %t82
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb27
bb26:
  %t87 = getelementptr %"compiler/typed:Local", ptr %l7, i32 0, i32 0
  %t88 = load i32, ptr %t87, !tbaa !23
  %t90 = icmp eq i32 %t88, 0
  store i1 %t90, ptr %l54, !tbaa !21
  br label %bb27
bb27:
  %t92 = load i1, ptr %l54, !tbaa !21
  br i1 %t92, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s7)
  br label %bb48
bb29:
  br label %bb30
bb30:
  %t93 = load ptr, ptr %l4, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Body", ptr %t93, i32 0, i32 3
  %t96 = load i64, ptr %t95, !tbaa !24
  %t97 = getelementptr %"compiler/typed:Local", ptr %l7, i32 0, i32 1
  %t98 = getelementptr %"compiler/source:Span", ptr %t97, i32 0, i32 0
  %t99 = load i32, ptr %t98, !tbaa !23
  %t101 = sext i32 %t99 to i64
  %t103 = shl i64 %t101, 32
  %t104 = getelementptr %"compiler/typed:Local", ptr %l7, i32 0, i32 1
  %t105 = getelementptr %"compiler/source:Span", ptr %t104, i32 0, i32 1
  %t106 = load i32, ptr %t105, !tbaa !23
  %t108 = sext i32 %t106 to i64
  %t111 = or i64 %t103, %t108
  %t114 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s7, i64 %t96, i64 %t111)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t114, ptr %l65
  br label %bb31
bb31:
  %t115 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l65
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t115, ptr %l8
  %t116 = getelementptr %"compiler/typed:Local", ptr %l7, i32 0, i32 2
  %t117 = load i32, ptr %t116, !tbaa !23
  %t118 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t121 = icmp ne i32 %t117, %t118
  br i1 %t121, label %bb32, label %bb33
bb32:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/typed:Local", ptr %l7, i32 0, i32 2
  %t125 = load i32, ptr %t124, !tbaa !23
  %t128 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edestructs(ptr %v0, ptr %t123, i32 %t125)
  store i1 %t128, ptr %l72
  br label %bb34
bb33:
  store i1 false, ptr %l69, !tbaa !21
  br label %bb35
bb34:
  %t129 = load i1, ptr %l72, !tbaa !21
  %t130 = xor i1 %t129, true
  store i1 %t130, ptr %l69, !tbaa !21
  br label %bb35
bb35:
  %t132 = load i1, ptr %l69, !tbaa !21
  store i1 %t132, ptr %l9, !tbaa !21
  %t133 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l8
  %t136 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %s0, ptr %l1, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t133)
  store i1 %t136, ptr %l76
  br label %bb36
bb36:
  %t137 = load i1, ptr %l76, !tbaa !21
  br i1 %t137, label %bb37, label %bb38
bb37:
  %t138 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l8
  %t141 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H190b78e3c1eec037529224679e114a85(ptr %s0, ptr %l1, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t138)
  %t142 = extractvalue { i32, i1 } %t141, 1
  %t143 = extractvalue { i32, i1 } %t141, 0
  store i32 %t143, ptr %l82
  %t144 = icmp ne i32 %t143, 0
  br i1 %t144, label %bb40, label %ok.145, !prof !99
ok.145:
  store i1 %t142, ptr %l81
  br label %bb39
bb38:
  store i1 false, ptr %l77, !tbaa !21
  br label %bb43
bb39:
  %t146 = load i1, ptr %l81, !tbaa !21
  store i1 %t146, ptr %l78, !tbaa !21
  br label %bb42
bb40:
  br label %bb41
bb41:
  call void @__olang_ert_req_clear()
  store i1 true, ptr %l78, !tbaa !21
  br label %bb42
bb42:
  %t147 = load i1, ptr %l78, !tbaa !21
  %t148 = xor i1 %t147, true
  store i1 %t148, ptr %l77, !tbaa !21
  br label %bb43
bb43:
  %t150 = load i1, ptr %l77, !tbaa !21
  br i1 %t150, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s7)
  br label %bb48
bb45:
  br label %bb46
bb46:
  %t151 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l8
  %t152 = load i1, ptr %l9, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %s0, ptr %l1, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t151, i1 %t152)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s7)
  br label %bb48
bb48:
  %t156 = load i64, ptr %l6, !tbaa !24
  %t158 = add i64 %t156, 1
  store i64 %t158, ptr %l6, !tbaa !24
  br label %bb19
bb49:
  br label %bb50
bb50:
  %t160 = load i64, ptr %l3, !tbaa !24
  %t162 = add i64 %t160, 1
  store i64 %t162, ptr %l3, !tbaa !24
  br label %bb10
bb51:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/check:Checker", ptr %t164, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t169 = getelementptr %"compiler/generic:Program", ptr %t167, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t172 = getelementptr %"compiler/names:Resolver", ptr %t170, i32 0, i32 18
  store ptr %t172, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb52
bb52:
  store %olang.scope zeroinitializer, ptr %s13
  %t174 = load i64, ptr %l11, !tbaa !24
  store i64 %t174, ptr %l95, !tbaa !24
  %t175 = load ptr, ptr %l10, !tbaa !29
  %t177 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aUnread_3e_2eLen_3ccompiler_2fnames_3aUnread_3e(ptr %v0, ptr %t175)
  store i64 %t177, ptr %l97
  br label %bb53
bb53:
  %t178 = load i64, ptr %l95, !tbaa !24
  %t179 = load i64, ptr %l97, !tbaa !24
  %t180 = icmp slt i64 %t178, %t179
  %t182 = xor i1 %t180, true
  br i1 %t182, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s13)
  br label %bb76
bb55:
  br label %bb56
bb56:
  %t184 = load ptr, ptr %l10, !tbaa !29
  %t185 = load i64, ptr %l11, !tbaa !24
  %t188 = call %"compiler/names:Unread" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aUnread_3e_2eAt_3ccompiler_2fnames_3aUnread_3e(ptr %v0, ptr %t184, i64 %t185)
  store %"compiler/names:Unread" %t188, ptr %l102
  br label %bb57
bb57:
  %t189 = load %"compiler/names:Unread", ptr %l102
  store %"compiler/names:Unread" %t189, ptr %l12
  %t190 = getelementptr %"compiler/names:Unread", ptr %l12, i32 0, i32 0
  %t191 = load i64, ptr %t190, !tbaa !24
  %t192 = getelementptr %"compiler/names:Unread", ptr %l12, i32 0, i32 1
  %t193 = getelementptr %"compiler/source:Span", ptr %t192, i32 0, i32 0
  %t194 = load i32, ptr %t193, !tbaa !23
  %t196 = sext i32 %t194 to i64
  %t197 = getelementptr %"compiler/names:Unread", ptr %l12, i32 0, i32 1
  %t198 = getelementptr %"compiler/source:Span", ptr %t197, i32 0, i32 1
  %t199 = load i32, ptr %t198, !tbaa !23
  %t201 = sext i32 %t199 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t202
  %t203 = getelementptr { i64, [3 x i64] }, ptr %t202, i32 0, i32 0
  store i64 3, ptr %t203
  %t205 = insertvalue { i64, i64, i64 } undef, i64 %t191, 0
  %t207 = insertvalue { i64, i64, i64 } %t205, i64 %t196, 1
  %t209 = insertvalue { i64, i64, i64 } %t207, i64 %t201, 2
  %t210 = getelementptr { i64, [3 x i64] }, ptr %t202, i32 0, i32 1
  store { i64, i64, i64 } %t209, ptr %t210
  %t211 = load { i64, [3 x i64] }, ptr %t202
  store { i64, [3 x i64] } %t211, ptr %l13
  %t213 = getelementptr %"compiler/names:Unread", ptr %l12, i32 0, i32 3
  %t214 = load i1, ptr %t213, !tbaa !21
  br i1 %t214, label %bb58, label %bb59
bb58:
  store %olang.scope zeroinitializer, ptr %s14
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/check:Checker", ptr %t216, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !29
  %t221 = getelementptr %"compiler/generic:Program", ptr %t219, i32 0, i32 0
  %t222 = load ptr, ptr %t221, !tbaa !29
  %t224 = getelementptr %"compiler/load:Loader", ptr %t222, i32 0, i32 4
  %t225 = load ptr, ptr %t224, !tbaa !29
  store ptr %t225, ptr %l113, !tbaa !29
  %t226 = load { i64, [3 x i64] }, ptr %l13
  store { i64, [3 x i64] } %t226, ptr %l114
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/names:Unread", ptr %l12, i32 0, i32 2
  %t229 = load i32, ptr %t228, !tbaa !23
  %t232 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s14, ptr %t227, i32 %t229)
  store { i64, ptr } %t232, ptr %l117
  br label %bb60
bb59:
  br label %bb63
bb60:
  %t233 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t234 = extractvalue { i64, ptr } %t233, 0
  %t235 = extractvalue { i64, ptr } %t233, 1
  %t236 = mul i64 %t234, 1
  %t237 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t236)
  call void @llvm.memcpy.p0.p0.i64(ptr %t237, ptr %t235, i64 %t236, i1 false)
  %t238 = insertvalue { i64, ptr } undef, i64 %t234, 0
  %t239 = insertvalue { i64, ptr } %t238, ptr %t237, 1
  %t241 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLocalUnusedBare(ptr %s14, ptr %s14, { i64, ptr } %t239)
  store %"compiler/msgs:Msg" %t241, ptr %l119
  br label %bb61
bb61:
  %t242 = load ptr, ptr %l113, !tbaa !29
  %t243 = load { i64, [3 x i64] }, ptr %l114
  %t244 = load %"compiler/msgs:Msg", ptr %l119
  %t245 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s14, ptr %t242, { i64, [3 x i64] } %t243, %"compiler/msgs:Msg" %t244)
  store i64 %t245, ptr %l120
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s13)
  br label %bb75
bb63:
  %t246 = getelementptr %"compiler/names:Unread", ptr %l12, i32 0, i32 0
  %t247 = load i64, ptr %t246, !tbaa !24
  %t248 = getelementptr %"compiler/names:Unread", ptr %l12, i32 0, i32 1
  %t249 = getelementptr %"compiler/source:Span", ptr %t248, i32 0, i32 0
  %t250 = load i32, ptr %t249, !tbaa !23
  %t252 = sext i32 %t250 to i64
  %t254 = shl i64 %t252, 32
  %t255 = getelementptr %"compiler/names:Unread", ptr %l12, i32 0, i32 1
  %t256 = getelementptr %"compiler/source:Span", ptr %t255, i32 0, i32 1
  %t257 = load i32, ptr %t256, !tbaa !23
  %t259 = sext i32 %t257 to i64
  %t262 = or i64 %t254, %t259
  %t265 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s13, i64 %t247, i64 %t262)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t265, ptr %l128
  br label %bb64
bb64:
  %t266 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l128
  %t270 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H190b78e3c1eec037529224679e114a85(ptr %s0, ptr %l1, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t266)
  %t271 = extractvalue { i32, i1 } %t270, 1
  %t272 = extractvalue { i32, i1 } %t270, 0
  store i32 %t272, ptr %l133
  %t273 = icmp ne i32 %t272, 0
  br i1 %t273, label %bb66, label %ok.274, !prof !99
ok.274:
  store i1 %t271, ptr %l132
  br label %bb65
bb65:
  %t275 = load i1, ptr %l132, !tbaa !21
  store i1 %t275, ptr %l129, !tbaa !21
  br label %bb68
bb66:
  br label %bb67
bb67:
  call void @__olang_ert_req_clear()
  store i1 false, ptr %l129, !tbaa !21
  br label %bb68
bb68:
  %t276 = load i1, ptr %l129, !tbaa !21
  %t277 = xor i1 %t276, true
  br i1 %t277, label %bb69, label %bb70
bb69:
  call void @__olang_scope_close(ptr %s13)
  br label %bb75
bb70:
  br label %bb71
bb71:
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr %"compiler/check:Checker", ptr %t279, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !29
  %t284 = getelementptr %"compiler/generic:Program", ptr %t282, i32 0, i32 0
  %t285 = load ptr, ptr %t284, !tbaa !29
  %t287 = getelementptr %"compiler/load:Loader", ptr %t285, i32 0, i32 4
  %t288 = load ptr, ptr %t287, !tbaa !29
  store ptr %t288, ptr %l138, !tbaa !29
  %t289 = load { i64, [3 x i64] }, ptr %l13
  store { i64, [3 x i64] } %t289, ptr %l139
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t291 = getelementptr %"compiler/names:Unread", ptr %l12, i32 0, i32 2
  %t292 = load i32, ptr %t291, !tbaa !23
  %t295 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s13, ptr %t290, i32 %t292)
  store { i64, ptr } %t295, ptr %l142
  br label %bb72
bb72:
  %t296 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t297 = extractvalue { i64, ptr } %t296, 0
  %t298 = extractvalue { i64, ptr } %t296, 1
  %t299 = mul i64 %t297, 1
  %t300 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t299)
  call void @llvm.memcpy.p0.p0.i64(ptr %t300, ptr %t298, i64 %t299, i1 false)
  %t301 = insertvalue { i64, ptr } undef, i64 %t297, 0
  %t302 = insertvalue { i64, ptr } %t301, ptr %t300, 1
  %t304 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLocalUnused(ptr %s13, ptr %s13, { i64, ptr } %t302)
  store %"compiler/msgs:Msg" %t304, ptr %l144
  br label %bb73
bb73:
  %t305 = load ptr, ptr %l138, !tbaa !29
  %t306 = load { i64, [3 x i64] }, ptr %l139
  %t307 = load %"compiler/msgs:Msg", ptr %l144
  %t308 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s13, ptr %t305, { i64, [3 x i64] } %t306, %"compiler/msgs:Msg" %t307)
  store i64 %t308, ptr %l145
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s13)
  br label %bb75
bb75:
  %t309 = load i64, ptr %l11, !tbaa !24
  %t311 = add i64 %t309, 1
  store i64 %t311, ptr %l11, !tbaa !24
  br label %bb52
bb76:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estaticArray(ptr %v0, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l6 = alloca ptr
  %lp7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca ptr
  %l22 = alloca i64
  %l26 = alloca i1
  %l29 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca i32
  %l42 = alloca ptr
  %l47 = alloca i32
  %l48 = alloca i32
  %l49 = alloca ptr
  %l50 = alloca i1
  %l63 = alloca i1
  %l66 = alloca ptr
  %l71 = alloca i32
  %l73 = alloca i1
  %l78 = alloca i1
  %l79 = alloca i1
  %l83 = alloca i1
  %l84 = alloca i32
  %l87 = alloca ptr
  %l89 = alloca i32
  %l91 = alloca i32
  %l97 = alloca i64
  %l99 = alloca ptr
  %l109 = alloca i64
  %l112 = alloca i64
  %l131 = alloca { i64, ptr }
  %l134 = alloca ptr
  %l135 = alloca i1
  %l150 = alloca ptr
  %l151 = alloca i1
  %l161 = alloca %"compiler/source:Span"
  %l162 = alloca i32
  %l164 = alloca ptr
  %rv = alloca ptr
  %t171 = alloca { i64, [2 x i64] }, align 8
  %t188 = alloca i64
  %t295 = alloca { i64, [2 x i64] }, align 8
  %t348 = alloca { i64, [2 x i64] }, align 8
  %t356 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t6, i32 %t7)
  store i64 %t10, ptr %l22
  br label %bb1
bb1:
  %t11 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t12 = load i64, ptr %l22, !tbaa !24
  %t14 = and i64 %t12, %t11
  %t16 = icmp ne i64 %t14, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb6
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 2
  store ptr %t23, ptr %l29, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t30 = load i32, ptr %l2, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l34
  br label %bb4
bb4:
  %t34 = load ptr, ptr %l29, !tbaa !29
  %t35 = load i32, ptr %l34, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t36, ptr %l35
  br label %bb5
bb5:
  %t37 = load i32, ptr %l35, !range !{i32 0, i32 33}
  %t39 = trunc i64 19 to i32
  %t40 = icmp eq i32 %t37, %t39
  %t42 = xor i1 %t40, true
  store i1 %t42, ptr %l26, !tbaa !21
  br label %bb6
bb6:
  %t44 = load i1, ptr %l26, !tbaa !21
  br i1 %t44, label %bb7, label %bb8
bb7:
  store ptr null, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 2
  store ptr %t51, ptr %l42, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 2
  %t58 = load i32, ptr %l2, !tbaa !23
  %t61 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t57, i32 %t58)
  store i32 %t61, ptr %l47
  br label %bb10
bb10:
  %t62 = load ptr, ptr %l42, !tbaa !29
  %t63 = load i32, ptr %l47, !tbaa !23
  %t64 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t62, i32 %t63)
  store i32 %t64, ptr %l48
  br label %bb11
bb11:
  %t65 = load i32, ptr %l48, !tbaa !23
  store i32 %t65, ptr %l3, !tbaa !23
  %t66 = load ptr, ptr %l1, !tbaa !29
  store ptr %t66, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t67 = load ptr, ptr %l49, !tbaa !29
  %t68 = icmp ne ptr %t67, null
  br i1 %t68, label %bb12, label %bb13
bb12:
  %t70 = load ptr, ptr %l49, !tbaa !29
  %t71 = load i64, ptr %t70, !range !{i64 0, i64 18}
  %t73 = icmp eq i64 %t71, 7
  store i1 %t73, ptr %l50, !tbaa !21
  br label %bb13
bb13:
  %t74 = load i1, ptr %l50, !tbaa !21
  br i1 %t74, label %bb14, label %bb15
bb14:
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t77 = getelementptr { i64, [5 x i64] }, ptr %t75, i32 0, i32 1
  %t78 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t77, i32 0, i32 0
  %t79 = load %"compiler/source:Span", ptr %t78
  store %"compiler/source:Span" %t79, ptr %l4
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr { i64, [5 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t83, i32 0, i32 1
  %t85 = load i32, ptr %t84
  store i32 %t85, ptr %l5, !tbaa !23
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 2
  %t91 = load ptr, ptr %t90
  store ptr %t91, ptr %l6, !tbaa !29
  br label %bb16
bb15:
  br label %bb74
bb16:
  %t93 = load ptr, ptr %l6, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Make", ptr %t93, i32 0, i32 0
  %t96 = load i32, ptr %t95, !range !{i32 0, i32 4}
  %t98 = trunc i64 2 to i32
  %t99 = icmp eq i32 %t96, %t98
  %t101 = xor i1 %t99, true
  br i1 %t101, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l63, !tbaa !21
  br label %bb21
bb18:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/generic:Program", ptr %t106, i32 0, i32 2
  store ptr %t108, ptr %l66, !tbaa !29
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/check:Checker", ptr %t109, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = getelementptr %"compiler/generic:Program", ptr %t112, i32 0, i32 2
  %t115 = load i32, ptr %l5, !tbaa !23
  %t118 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t114, i32 %t115)
  store i32 %t118, ptr %l71
  br label %bb19
bb19:
  %t119 = load i32, ptr %l3, !tbaa !23
  %t120 = load ptr, ptr %l66, !tbaa !29
  %t121 = load i32, ptr %l71, !tbaa !23
  %t123 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t120, i32 %t121, i32 %t119)
  store i1 %t123, ptr %l73
  br label %bb20
bb20:
  %t124 = load i1, ptr %l73, !tbaa !21
  %t125 = xor i1 %t124, true
  store i1 %t125, ptr %l63, !tbaa !21
  br label %bb21
bb21:
  %t127 = load i1, ptr %l63, !tbaa !21
  br i1 %t127, label %bb22, label %bb23
bb22:
  store ptr null, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load i32, ptr %l3, !tbaa !23
  %t133 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t129, i32 %t130)
  store i1 %t133, ptr %l78
  br label %bb25
bb25:
  %t134 = load i1, ptr %l78, !tbaa !21
  br i1 %t134, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb28
bb27:
  %t135 = load i32, ptr %l3, !tbaa !23
  %t136 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t139 = icmp eq i32 %t135, %t136
  store i1 %t139, ptr %l79, !tbaa !21
  br label %bb28
bb28:
  %t141 = load i1, ptr %l79, !tbaa !21
  br i1 %t141, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l83, !tbaa !21
  br label %bb33
bb30:
  %t142 = load i32, ptr %l3, !tbaa !23
  store i32 %t142, ptr %l84, !tbaa !23
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/check:Checker", ptr %t143, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t148 = getelementptr %"compiler/generic:Program", ptr %t146, i32 0, i32 2
  store ptr %t148, ptr %l87, !tbaa !29
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t149)
  store i32 %t151, ptr %l89
  br label %bb31
bb31:
  %t152 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t153 = load ptr, ptr %l87, !tbaa !29
  %t154 = load i32, ptr %l89, !tbaa !23
  %t156 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t153, i32 %t154, i64 %t152)
  store i32 %t156, ptr %l91
  br label %bb32
bb32:
  %t157 = load i32, ptr %l84, !tbaa !23
  %t158 = load i32, ptr %l91, !tbaa !23
  %t159 = icmp eq i32 %t157, %t158
  store i1 %t159, ptr %l83, !tbaa !21
  br label %bb33
bb33:
  %t161 = load i1, ptr %l83, !tbaa !21
  %t162 = xor i1 %t161, true
  br i1 %t162, label %bb34, label %bb35
bb34:
  store ptr null, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t165 = load ptr, ptr %l6, !tbaa !29
  %t167 = getelementptr %"compiler/typed:Make", ptr %t165, i32 0, i32 2
  %t168 = load { i64, ptr }, ptr %t167, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t168, 0
  store i64 %t170, ptr %l97, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t171
  %t172 = getelementptr { i64, [2 x i64] }, ptr %t171, i32 0, i32 0
  store i64 0, ptr %t172
  %t173 = insertvalue { i64 } undef, i64 0, 0
  %t174 = getelementptr { i64, [2 x i64] }, ptr %t171, i32 0, i32 1
  store { i64 } %t173, ptr %t174
  %t175 = load { i64, [2 x i64] }, ptr %t171
  %t177 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t175, ptr %t177
  store ptr %t177, ptr %l99, !tbaa !29
  %t178 = load i64, ptr %l97, !tbaa !24
  %t179 = icmp sge i64 %t178, 0
  br i1 %t179, label %bb37, label %bb38
bb37:
  %t181 = load i64, ptr %l97, !tbaa !24
  %t182 = icmp sle i64 %t181, 1152921504606846975
  br i1 %t182, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_3727962a9e2e15db_7cf774666c9d4227)
  unreachable
bb39:
  %t184 = load i64, ptr %l97, !tbaa !24
  %t185 = mul i64 %t184, 8
  %t186 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t185)
  %t187 = load ptr, ptr %l99, !tbaa !29
  store i64 0, ptr %t188
  br label %fill.189
fill.189:
  %t192 = load i64, ptr %t188
  %t193 = icmp slt i64 %t192, %t184
  br i1 %t193, label %fillb.190, label %filld.191
fillb.190:
  %t194 = getelementptr ptr, ptr %t186, i64 %t192
  store ptr %t187, ptr %t194
  %t195 = add i64 %t192, 1
  store i64 %t195, ptr %t188
  br label %fill.189
filld.191:
  %t196 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t197 = insertvalue { i64, ptr } %t196, ptr %t186, 1
  %t198 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t198, ptr %lp7
  %t200 = load ptr, ptr %lp7
  store { i64, ptr } %t197, ptr %t200, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t201 = load ptr, ptr %l6, !tbaa !29
  %t203 = getelementptr %"compiler/typed:Make", ptr %t201, i32 0, i32 2
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  %t206 = extractvalue { i64, ptr } %t204, 0
  store i64 %t206, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t208 = load i64, ptr %l9, !tbaa !24
  %t209 = load i64, ptr %l8, !tbaa !24
  %t212 = icmp sgt i64 %t208, %t209
  br i1 %t212, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_3727962a9e2e15db_7cf774666c9d4227)
  unreachable
bb41:
  %t214 = load i64, ptr %l10, !tbaa !24
  %t216 = icmp sgt i64 %t214, 0
  br i1 %t216, label %bb43, label %bb44
bb42:
  store i64 0, ptr %l109, !tbaa !24
  br label %bb46
bb43:
  %t218 = load i64, ptr %l9, !tbaa !24
  %t219 = load i64, ptr %l8, !tbaa !24
  %t222 = sub i64 %t218, %t219
  %t223 = load i64, ptr %l10, !tbaa !24
  %t226 = add i64 %t222, %t223
  %t228 = sub i64 %t226, 1
  %t229 = load i64, ptr %l10, !tbaa !24
  %t232 = sdiv i64 %t228, %t229
  store i64 %t232, ptr %l112, !tbaa !24
  br label %bb45
bb44:
  store i64 0, ptr %l112, !tbaa !24
  br label %bb45
bb45:
  %t234 = load i64, ptr %l112, !tbaa !24
  store i64 %t234, ptr %l109, !tbaa !24
  br label %bb46
bb46:
  %t235 = load i64, ptr %l109, !tbaa !24
  store i64 %t235, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb47
bb47:
  %t236 = load i64, ptr %l12, !tbaa !24
  %t237 = load i64, ptr %l11, !tbaa !24
  %t240 = icmp slt i64 %t236, %t237
  %t242 = xor i1 %t240, true
  br i1 %t242, label %bb48, label %bb49
bb48:
  br label %bb72
bb49:
  br label %bb50
bb50:
  %t244 = load i64, ptr %l8, !tbaa !24
  %t245 = load i64, ptr %l12, !tbaa !24
  %t246 = load i64, ptr %l10, !tbaa !24
  %t249 = mul i64 %t245, %t246
  %t252 = add i64 %t244, %t249
  store i64 %t252, ptr %l13, !tbaa !24
  %t254 = load ptr, ptr %l6, !tbaa !29
  %t256 = getelementptr %"compiler/typed:Make", ptr %t254, i32 0, i32 2
  %t257 = load { i64, ptr }, ptr %t256, !tbaa !27
  store { i64, ptr } %t257, ptr %l131, !tbaa !27
  %t258 = load i64, ptr %l13, !tbaa !24
  %t260 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t261 = load ptr, ptr %t260, !tbaa !27
  %t262 = getelementptr ptr, ptr %t261, i64 %t258
  %t263 = load ptr, ptr %t262, !tbaa !39
  store ptr %t263, ptr %l14, !tbaa !29
  %t265 = load ptr, ptr %l14, !tbaa !29
  store ptr %t265, ptr %l134, !tbaa !29
  store i1 false, ptr %l135, !tbaa !21
  %t266 = load ptr, ptr %l134, !tbaa !29
  %t267 = icmp ne ptr %t266, null
  br i1 %t267, label %bb51, label %bb52
bb51:
  %t269 = load ptr, ptr %l134, !tbaa !29
  %t270 = load i64, ptr %t269, !range !{i64 0, i64 18}
  %t272 = icmp eq i64 %t270, 0
  store i1 %t272, ptr %l135, !tbaa !21
  br label %bb52
bb52:
  %t273 = load i1, ptr %l135, !tbaa !21
  br i1 %t273, label %bb53, label %bb54
bb53:
  %t274 = load ptr, ptr %l14, !tbaa !29
  %t276 = getelementptr { i64, [5 x i64] }, ptr %t274, i32 0, i32 1
  %t277 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t276, i32 0, i32 1
  %t278 = load i32, ptr %t277
  store i32 %t278, ptr %l15, !tbaa !23
  %t280 = load ptr, ptr %l14, !tbaa !29
  %t282 = getelementptr { i64, [5 x i64] }, ptr %t280, i32 0, i32 1
  %t283 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t282, i32 0, i32 2
  %t284 = load i64, ptr %t283
  store i64 %t284, ptr %l16, !tbaa !24
  br label %bb55
bb54:
  br label %bb59
bb55:
  %t286 = load i32, ptr %l15, !tbaa !23
  %t287 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t290 = icmp eq i32 %t286, %t287
  br i1 %t290, label %bb56, label %bb57
bb56:
  store ptr null, ptr %rv
  br label %ret
bb57:
  br label %bb58
bb58:
  %t293 = load i64, ptr %l13, !tbaa !24
  %t294 = load i64, ptr %l16, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t295
  %t296 = getelementptr { i64, [2 x i64] }, ptr %t295, i32 0, i32 0
  store i64 0, ptr %t296
  %t298 = insertvalue { i64 } undef, i64 %t294, 0
  %t299 = getelementptr { i64, [2 x i64] }, ptr %t295, i32 0, i32 1
  store { i64 } %t298, ptr %t299
  %t300 = load { i64, [2 x i64] }, ptr %t295
  %t302 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t300, ptr %t302
  %t304 = load ptr, ptr %lp7
  %t306 = getelementptr { i64, ptr }, ptr %t304, i32 0, i32 1
  %t307 = load ptr, ptr %t306, !tbaa !27
  %t308 = getelementptr ptr, ptr %t307, i64 %t293
  store ptr %t302, ptr %t308, !tbaa !39
  br label %bb70
bb59:
  %t309 = load ptr, ptr %l14, !tbaa !29
  store ptr %t309, ptr %l150, !tbaa !29
  store i1 false, ptr %l151, !tbaa !21
  %t310 = load ptr, ptr %l150, !tbaa !29
  %t311 = icmp ne ptr %t310, null
  br i1 %t311, label %bb60, label %bb61
bb60:
  %t313 = load ptr, ptr %l150, !tbaa !29
  %t314 = load i64, ptr %t313, !range !{i64 0, i64 18}
  %t316 = icmp eq i64 %t314, 1
  store i1 %t316, ptr %l151, !tbaa !21
  br label %bb61
bb61:
  %t317 = load i1, ptr %l151, !tbaa !21
  br i1 %t317, label %bb62, label %bb63
bb62:
  %t318 = load ptr, ptr %l14, !tbaa !29
  %t320 = getelementptr { i64, [5 x i64] }, ptr %t318, i32 0, i32 1
  %t321 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t320, i32 0, i32 3
  %t322 = load ptr, ptr %t321
  store ptr %t322, ptr %l17, !tbaa !29
  br label %bb64
bb63:
  br label %bb65
bb64:
  %t324 = load i64, ptr %l13, !tbaa !24
  %t325 = load ptr, ptr %l17, !tbaa !29
  %t327 = load ptr, ptr %lp7
  %t329 = getelementptr { i64, ptr }, ptr %t327, i32 0, i32 1
  %t330 = load ptr, ptr %t329, !tbaa !27
  %t331 = getelementptr ptr, ptr %t330, i64 %t324
  store ptr %t325, ptr %t331, !tbaa !39
  br label %bb70
bb65:
  br i1 true, label %bb66, label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb69
bb68:
  store ptr null, ptr %rv
  br label %ret
bb69:
  call void @__olang_check_failed(ptr @olang_loc_81d441761e2a717d_f45e749fdf1e1e81)
  unreachable
bb70:
  br label %bb71
bb71:
  %t333 = load i64, ptr %l12, !tbaa !24
  %t335 = add i64 %t333, 1
  store i64 %t335, ptr %l12, !tbaa !24
  br label %bb47
bb72:
  %t337 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t337, ptr %l161
  %t338 = load i32, ptr %l2, !tbaa !23
  store i32 %t338, ptr %l162, !tbaa !23
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t341 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t339)
  store ptr %t341, ptr %l164
  br label %bb73
bb73:
  %t342 = load ptr, ptr %l164, !tbaa !29
  %t344 = getelementptr %"compiler/check:frame", ptr %t342, i32 0, i32 2
  %t345 = load i64, ptr %t344, !tbaa !24
  %t346 = load ptr, ptr %lp7
  %t347 = load { i64, ptr }, ptr %t346, !tbaa !27
  store { i64, [2 x i64] } zeroinitializer, ptr %t348
  %t349 = getelementptr { i64, [2 x i64] }, ptr %t348, i32 0, i32 0
  store i64 2, ptr %t349
  %t351 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t347, 0
  %t352 = getelementptr { i64, [2 x i64] }, ptr %t348, i32 0, i32 1
  store { { i64, ptr } } %t351, ptr %t352
  %t353 = load { i64, [2 x i64] }, ptr %t348
  %t355 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t353, ptr %t355
  store { i64, [5 x i64] } zeroinitializer, ptr %t356
  %t357 = getelementptr { i64, [5 x i64] }, ptr %t356, i32 0, i32 0
  store i64 1, ptr %t357
  %t358 = load %"compiler/source:Span", ptr %l161
  %t359 = insertvalue { %"compiler/source:Span", i32, i64, ptr } undef, %"compiler/source:Span" %t358, 0
  %t360 = load i32, ptr %l162, !tbaa !23
  %t361 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t359, i32 %t360, 1
  %t363 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t361, i64 %t345, 2
  %t365 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t363, ptr %t355, 3
  %t366 = getelementptr { i64, [5 x i64] }, ptr %t356, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, ptr } %t365, ptr %t366
  %t367 = load { i64, [5 x i64] }, ptr %t356
  %t369 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t367, ptr %t369
  store ptr %t369, ptr %rv
  br label %ret
bb74:
  br i1 true, label %bb75, label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb78
bb77:
  store ptr null, ptr %rv
  br label %ret
bb78:
  call void @__olang_check_failed(ptr @olang_loc_64cdadb0ead6eee6_ae7a9e6dd8bef26a)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca i64
  %l11 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca ptr
  %l29 = alloca { i64, [2 x i64] }
  %l34 = alloca i32
  %l37 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca ptr
  %l48 = alloca %"compiler/generic:Context"
  %l50 = alloca ptr
  %l53 = alloca i32
  %l56 = alloca i64
  %l60 = alloca ptr
  %l63 = alloca ptr
  %l64 = alloca ptr
  %l69 = alloca ptr
  %l72 = alloca ptr
  %l81 = alloca ptr
  %l82 = alloca ptr
  %l86 = alloca { i64, ptr }
  %l87 = alloca %"compiler/typed:Block"
  %l95 = alloca i64
  %l98 = alloca i1
  %l101 = alloca i64
  %l104 = alloca i1
  %l112 = alloca ptr
  %rv = alloca i64
  %t35 = alloca { i64, [2 x i64] }, align 8
  %t135 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 4
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l4, !tbaa !29
  %t12 = load ptr, ptr %l4, !tbaa !29
  %t14 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l18
  br label %bb1
bb1:
  %t15 = load i64, ptr %l18, !tbaa !24
  store i64 %t15, ptr %l5, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 13
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2eLen_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %t18)
  store i64 %t20, ptr %l21
  br label %bb2
bb2:
  %t21 = load i64, ptr %l21, !tbaa !24
  store i64 %t21, ptr %l6, !tbaa !24
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 110
  %t25 = load i64, ptr %t24, !tbaa !24
  store i64 %t25, ptr %l7, !tbaa !24
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t29 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t27)
  store %"compiler/source:Span" %t29, ptr %l25
  br label %bb3
bb3:
  %t30 = load %"compiler/source:Span", ptr %l25
  store %"compiler/source:Span" %t30, ptr %l8
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l26, !tbaa !29
  %t32 = load i64, ptr %l1, !tbaa !24
  %t33 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t34 = load i32, ptr %t33, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t35
  %t36 = getelementptr { i64, [2 x i64] }, ptr %t35, i32 0, i32 0
  store i64 7, ptr %t36
  %t38 = insertvalue { i64, i32 } undef, i64 %t32, 0
  %t40 = insertvalue { i64, i32 } %t38, i32 %t34, 1
  %t41 = getelementptr { i64, [2 x i64] }, ptr %t35, i32 0, i32 1
  store { i64, i32 } %t40, ptr %t41
  %t42 = load { i64, [2 x i64] }, ptr %t35
  store { i64, [2 x i64] } %t42, ptr %l29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 2
  %t49 = load i32, ptr %l3, !tbaa !23
  %t52 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t48, i32 0, i32 %t49, i32 0, i32 0, i64 0)
  store i32 %t52, ptr %l34
  br label %bb4
bb4:
  %t53 = load i64, ptr %l1, !tbaa !24
  %t54 = load %"compiler/source:Span", ptr %l8
  %t55 = load ptr, ptr %l26, !tbaa !29
  %t56 = load { i64, [2 x i64] }, ptr %l29
  %t57 = load i32, ptr %l34, !tbaa !23
  %t60 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t55, { i64, [2 x i64] } %t56, i32 %t57, i64 %t53, %"compiler/source:Span" %t54)
  store i64 %t60, ptr %l37
  br label %bb5
bb5:
  %t61 = load i64, ptr %l37, !tbaa !24
  store i64 %t61, ptr %l9, !tbaa !24
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 17
  %t65 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t64, i64 %t65, i64 1)
  br label %bb6
bb6:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i64, ptr %l9, !tbaa !24
  %t70 = load i64, ptr %l1, !tbaa !24
  %t71 = load i32, ptr %l3, !tbaa !23
  %t76 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t68, i64 %t69, i64 %t70, i32 %t71, i32 0)
  store ptr %t76, ptr %l45
  br label %bb7
bb7:
  %t77 = load ptr, ptr %l45, !tbaa !29
  store ptr %t77, ptr %l46, !tbaa !29
  %t79 = load i64, ptr %l1, !tbaa !24
  %t81 = call %"compiler/generic:Context" @compiler_2fgeneric_3aContext_2ector(ptr %v0, i64 %t79, i64 -1)
  store %"compiler/generic:Context" %t81, ptr %l48
  br label %bb8
bb8:
  %t82 = load %"compiler/generic:Context", ptr %l48
  %t83 = load ptr, ptr %l46, !tbaa !29
  %t84 = getelementptr %"compiler/check:frame", ptr %t83, i32 0, i32 4
  store %"compiler/generic:Context" %t82, ptr %t84
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t85)
  store ptr %t87, ptr %l50
  br label %bb9
bb9:
  %t88 = load %"compiler/source:Span", ptr %l8
  %t89 = load ptr, ptr %l50, !tbaa !29
  %t92 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t89, i32 -1, i32 0, %"compiler/source:Span" %t88)
  store i32 %t92, ptr %l53
  br label %bb10
bb10:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 37
  %t97 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t95)
  store i64 %t97, ptr %l56
  br label %bb11
bb11:
  %t98 = load i64, ptr %l56, !tbaa !24
  store i64 %t98, ptr %l11, !tbaa !24
  %t99 = load i32, ptr %l3, !tbaa !23
  %t100 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t103 = icmp eq i32 %t99, %t100
  br i1 %t103, label %bb12, label %bb13
bb12:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load ptr, ptr %l2, !tbaa !29
  %t109 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v1, ptr %t105, ptr %t106)
  store ptr %t109, ptr %l63
  br label %bb14
bb13:
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l64, !tbaa !29
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load ptr, ptr %l2, !tbaa !29
  %t114 = load i32, ptr %l3, !tbaa !23
  %t118 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t111, ptr %t112, i32 %t114)
  store ptr %t118, ptr %l69
  br label %bb15
bb14:
  %t119 = load ptr, ptr %l63, !tbaa !29
  store ptr %t119, ptr %l60, !tbaa !29
  br label %bb17
bb15:
  %t120 = load i32, ptr %l3, !tbaa !23
  %t121 = load %"compiler/source:Span", ptr %l8
  %t122 = load ptr, ptr %l64, !tbaa !29
  %t123 = load ptr, ptr %l69, !tbaa !29
  %t126 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t122, ptr %t123, i32 %t120, %"compiler/source:Span" %t121)
  store ptr %t126, ptr %l72
  br label %bb16
bb16:
  %t127 = load ptr, ptr %l72, !tbaa !29
  store ptr %t127, ptr %l60, !tbaa !29
  br label %bb17
bb17:
  %t128 = load ptr, ptr %l60, !tbaa !29
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/check:Checker", ptr %t129, i32 0, i32 37
  %t132 = load %"compiler/source:Span", ptr %l8
  store { i64, [3 x i64] } zeroinitializer, ptr %t135
  %t136 = getelementptr { i64, [3 x i64] }, ptr %t135, i32 0, i32 0
  store i64 6, ptr %t136
  %t138 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t132, 0
  %t140 = insertvalue { %"compiler/source:Span", ptr } %t138, ptr %t128, 1
  %t141 = getelementptr { i64, [3 x i64] }, ptr %t135, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t140, ptr %t141
  %t142 = load { i64, [3 x i64] }, ptr %t135
  %t144 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t142, ptr %t144
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t131, ptr %t144)
  br label %bb18
bb18:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t147)
  store ptr %t149, ptr %l81
  br label %bb19
bb19:
  %t150 = load ptr, ptr %l81, !tbaa !29
  store ptr %t150, ptr %l82, !tbaa !29
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/check:Checker", ptr %t151, i32 0, i32 37
  %t154 = load i64, ptr %l11, !tbaa !24
  %t157 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t153, i64 %t154)
  store { i64, ptr } %t157, ptr %l86
  br label %bb20
bb20:
  %t158 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t159 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 0, { i64, ptr } %t158)
  store %"compiler/typed:Block" %t159, ptr %l87
  br label %bb21
bb21:
  %t160 = load %"compiler/typed:Block", ptr %l87
  %t161 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t160, ptr %t161
  %t163 = load ptr, ptr %l82, !tbaa !29
  %t164 = getelementptr %"compiler/typed:Body", ptr %t163, i32 0, i32 11
  store ptr %t161, ptr %t164, !tbaa !29
  %t165 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t165)
  br label %bb22
bb22:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/check:Checker", ptr %t167, i32 0, i32 17
  %t170 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t169, i64 %t170, i64 2)
  br label %bb23
bb23:
  %t173 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edrain(ptr %v0, ptr %t173)
  br label %bb24
bb24:
  %t175 = load ptr, ptr %l4, !tbaa !29
  %t177 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t175)
  store i64 %t177, ptr %l95
  br label %bb25
bb25:
  %t178 = load i64, ptr %l5, !tbaa !24
  %t179 = load i64, ptr %l95, !tbaa !24
  %t181 = icmp sgt i64 %t179, %t178
  br i1 %t181, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l98, !tbaa !21
  br label %bb29
bb27:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/check:Checker", ptr %t183, i32 0, i32 13
  %t187 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2eLen_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %t185)
  store i64 %t187, ptr %l101
  br label %bb28
bb28:
  %t188 = load i64, ptr %l6, !tbaa !24
  %t189 = load i64, ptr %l101, !tbaa !24
  %t191 = icmp sgt i64 %t189, %t188
  store i1 %t191, ptr %l98, !tbaa !21
  br label %bb29
bb29:
  %t193 = load i1, ptr %l98, !tbaa !21
  br i1 %t193, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l104, !tbaa !21
  br label %bb32
bb31:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/check:Checker", ptr %t194, i32 0, i32 110
  %t197 = load i64, ptr %t196, !tbaa !24
  %t198 = load i64, ptr %l7, !tbaa !24
  %t201 = icmp sgt i64 %t197, %t198
  store i1 %t201, ptr %l104, !tbaa !21
  br label %bb32
bb32:
  %t203 = load i1, ptr %l104, !tbaa !21
  br i1 %t203, label %bb33, label %bb34
bb33:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/check:Checker", ptr %t204, i32 0, i32 12
  %t207 = load i64, ptr %l9, !tbaa !24
  %t210 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t206, i64 %t207)
  store ptr %t210, ptr %l112
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t211 = load ptr, ptr %l112, !tbaa !29
  %t213 = getelementptr %"compiler/typed:Body", ptr %t211, i32 0, i32 11
  store ptr null, ptr %t213, !tbaa !29
  store i64 -1, ptr %rv
  br label %ret
bb36:
  %t215 = load i64, ptr %l9, !tbaa !24
  store i64 %t215, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopSetOf(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l11 = alloca ptr
  %l16 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  store i64 %t2, ptr %l5, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/check:Checker", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = getelementptr %"compiler/generic:Program", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/load:Loader", ptr %t9, i32 0, i32 5
  %t12 = load i64, ptr %l1, !tbaa !24
  %t15 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t11, i64 %t12)
  store ptr %t15, ptr %l11
  br label %bb1
bb1:
  %t16 = load ptr, ptr %l11, !tbaa !29
  %t18 = getelementptr %"compiler/load:Module", ptr %t16, i32 0, i32 8
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  %t22 = load ptr, ptr %l4, !tbaa !29
  %t23 = load i64, ptr %l5, !tbaa !24
  %t27 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopSetIn(ptr %v0, ptr %v0, ptr %t22, i64 %t23, { i64, ptr } %t19, i32 %a2, %"compiler/source:Span" %a3, i1 false)
  store ptr %t27, ptr %l16
  br label %bb2
bb2:
  %t28 = load ptr, ptr %l16, !tbaa !29
  store ptr %t28, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunsettle(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l10 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l36 = alloca ptr
  %l39 = alloca i64
  %l43 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 14
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i64, ptr %l10, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr %l1, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l2, !tbaa !24
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l17, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l17, !tbaa !24
  store i64 %t33, ptr %l14, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l14, !tbaa !24
  store i64 %t34, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l5, !tbaa !24
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb19
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l1, !tbaa !24
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l3, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l6, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 14
  store ptr %t55, ptr %l36, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 14
  %t60 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t58)
  store i64 %t60, ptr %l39
  br label %bb12
bb12:
  %t61 = load i64, ptr %l39, !tbaa !24
  %t62 = sub i64 %t61, 1
  %t63 = load i64, ptr %l6, !tbaa !24
  %t66 = sub i64 %t62, %t63
  %t67 = load ptr, ptr %l36, !tbaa !29
  %t69 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_Hc8503b2b20cde402cc7bde6f68d96fc0(ptr %v0, ptr %v0, ptr %t67, i64 %t66)
  store ptr %t69, ptr %l43
  br label %bb13
bb13:
  %t70 = load ptr, ptr %l43, !tbaa !29
  store ptr %t70, ptr %l7, !tbaa !29
  %t71 = load ptr, ptr %l7, !tbaa !29
  %t73 = getelementptr %"compiler/check:frame", ptr %t71, i32 0, i32 25
  %t74 = load i1, ptr %t73, !tbaa !21
  br i1 %t74, label %bb14, label %bb15
bb14:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 56
  %t79 = load ptr, ptr %l7, !tbaa !29
  %t81 = getelementptr %"compiler/check:frame", ptr %t79, i32 0, i32 0
  %t82 = load i64, ptr %t81, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t78, i64 %t82, i1 true)
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %ret
bb17:
  br label %bb18
bb18:
  %t85 = load i64, ptr %l5, !tbaa !24
  %t87 = add i64 %t85, 1
  store i64 %t87, ptr %l5, !tbaa !24
  br label %bb8
bb19:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarArg(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/check:litv"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i32
  %l13 = alloca %"compiler/check:litv"
  %l16 = alloca i32
  %l20 = alloca i32
  %l22 = alloca i32
  %l26 = alloca i32
  %l29 = alloca i1
  %l32 = alloca i32
  %l36 = alloca i32
  %l38 = alloca i32
  %l43 = alloca ptr
  %l48 = alloca ptr
  %l51 = alloca i32
  %l60 = alloca i32
  %l65 = alloca i32
  %l70 = alloca i1
  %l75 = alloca i64
  %l78 = alloca ptr
  %l80 = alloca %"compiler/source:Span"
  %l81 = alloca ptr
  %l85 = alloca i32
  %l86 = alloca ptr
  %l89 = alloca i1
  %l92 = alloca ptr
  %l95 = alloca %"compiler/source:Span"
  %l98 = alloca { i64, ptr }
  %l100 = alloca %"compiler/msgs:Msg"
  %l101 = alloca i64
  %l102 = alloca ptr
  %l104 = alloca %"compiler/source:Span"
  %l105 = alloca ptr
  %l108 = alloca i1
  %l111 = alloca i1
  %l114 = alloca ptr
  %l116 = alloca %"compiler/source:Span"
  %l117 = alloca ptr
  %l122 = alloca i1
  %l123 = alloca i32
  %l127 = alloca i32
  %l129 = alloca i32
  %l130 = alloca ptr
  %l134 = alloca ptr
  %l135 = alloca ptr
  %l137 = alloca %"compiler/source:Span"
  %l140 = alloca ptr
  %l146 = alloca i1
  %l150 = alloca ptr
  %l152 = alloca %"compiler/source:Span"
  %l153 = alloca ptr
  %l157 = alloca i32
  %l158 = alloca ptr
  %l162 = alloca ptr
  %l163 = alloca ptr
  %l165 = alloca %"compiler/source:Span"
  %l168 = alloca ptr
  %l172 = alloca i1
  %l173 = alloca i32
  %l178 = alloca i32
  %l182 = alloca i1
  %l183 = alloca i1
  %l186 = alloca ptr
  %l191 = alloca i32
  %l192 = alloca i32
  %l196 = alloca ptr
  %l199 = alloca %"compiler/source:Span"
  %l202 = alloca { i64, ptr }
  %l204 = alloca %"compiler/msgs:Msg"
  %l205 = alloca i64
  %l206 = alloca ptr
  %l208 = alloca %"compiler/source:Span"
  %l209 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t6 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store %"compiler/check:litv" %t6, ptr %l13
  br label %bb1
bb1:
  %t7 = load %"compiler/check:litv", ptr %l13
  store %"compiler/check:litv" %t7, ptr %l2
  %t8 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 0
  %t9 = load i1, ptr %t8, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 1
  %t12 = load i1, ptr %t11, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb3:
  br label %bb21
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 2
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s1, ptr %t19, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store i32 %t21, ptr %l20
  br label %bb6
bb5:
  %t22 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 2
  %t23 = load i1, ptr %t22, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb6:
  %t25 = load i32, ptr %l20, !tbaa !23
  store i32 %t25, ptr %l16, !tbaa !23
  br label %bb19
bb7:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 2
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s1, ptr %t31, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store i32 %t33, ptr %l26
  br label %bb9
bb8:
  %t34 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 3
  %t35 = load i64, ptr %t34, !tbaa !24
  %t37 = icmp sge i64 %t35, -2147483648
  br i1 %t37, label %bb10, label %bb11
bb9:
  %t39 = load i32, ptr %l26, !tbaa !23
  store i32 %t39, ptr %l22, !tbaa !23
  br label %bb18
bb10:
  %t40 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 3
  %t41 = load i64, ptr %t40, !tbaa !24
  %t43 = icmp sle i64 %t41, 2147483647
  store i1 %t43, ptr %l29, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb12
bb12:
  %t45 = load i1, ptr %l29, !tbaa !21
  br i1 %t45, label %bb13, label %bb14
bb13:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 2
  %t53 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s1, ptr %t51, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store i32 %t53, ptr %l36
  br label %bb15
bb14:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t54)
  store i32 %t56, ptr %l38
  br label %bb16
bb15:
  %t57 = load i32, ptr %l36, !tbaa !23
  store i32 %t57, ptr %l32, !tbaa !23
  br label %bb17
bb16:
  %t58 = load i32, ptr %l38, !tbaa !23
  store i32 %t58, ptr %l32, !tbaa !23
  br label %bb17
bb17:
  %t59 = load i32, ptr %l32, !tbaa !23
  store i32 %t59, ptr %l22, !tbaa !23
  br label %bb18
bb18:
  %t60 = load i32, ptr %l22, !tbaa !23
  store i32 %t60, ptr %l16, !tbaa !23
  br label %bb19
bb19:
  %t61 = load i32, ptr %l16, !tbaa !23
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t69 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t62, ptr %t63, i32 %t61)
  store ptr %t69, ptr %l43
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t70 = load ptr, ptr %l43, !tbaa !29
  store ptr %t70, ptr %rv
  br label %ret
bb21:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t78 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t71, ptr %t72, i32 %t74)
  store ptr %t78, ptr %l48
  br label %bb22
bb22:
  %t79 = load ptr, ptr %l48, !tbaa !29
  store ptr %t79, ptr %l4, !tbaa !29
  %t80 = load ptr, ptr %l4, !tbaa !29
  %t83 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t80)
  store i32 %t83, ptr %l51
  br label %bb23
bb23:
  %t84 = load i32, ptr %l51, !tbaa !23
  store i32 %t84, ptr %l5, !tbaa !23
  %t85 = load i32, ptr %l5, !tbaa !23
  %t86 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t89 = icmp eq i32 %t85, %t86
  br i1 %t89, label %bb24, label %bb25
bb24:
  %t91 = load ptr, ptr %l4, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t91, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 2
  %t99 = load i32, ptr %l5, !tbaa !23
  %t102 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t98, i32 %t99)
  store i32 %t102, ptr %l60
  br label %bb27
bb27:
  %t103 = load i32, ptr %l60, !tbaa !23
  store i32 %t103, ptr %l6, !tbaa !23
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/check:Checker", ptr %t104, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t109 = getelementptr %"compiler/generic:Program", ptr %t107, i32 0, i32 2
  %t110 = load i32, ptr %l6, !tbaa !23
  %t113 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t109, i32 %t110)
  store i32 %t113, ptr %l65
  br label %bb28
bb28:
  %t114 = load i32, ptr %l65, !range !{i32 0, i32 33}
  store i32 %t114, ptr %l7
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/check:Checker", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = getelementptr %"compiler/generic:Program", ptr %t118, i32 0, i32 2
  %t121 = load i32, ptr %l6, !tbaa !23
  %t124 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t120, i32 %t121)
  store i1 %t124, ptr %l70
  br label %bb29
bb29:
  %t125 = load i1, ptr %l70, !tbaa !21
  br i1 %t125, label %bb30, label %bb31
bb30:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/generic:Program", ptr %t129, i32 0, i32 2
  %t132 = load i32, ptr %l6, !tbaa !23
  %t135 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t131, i32 %t132)
  store i64 %t135, ptr %l75
  br label %bb32
bb31:
  br label %bb73
bb32:
  %t136 = load i64, ptr %l75, !tbaa !24
  store i64 %t136, ptr %l8, !tbaa !24
  %t137 = load i64, ptr %l8, !tbaa !24
  %t139 = icmp slt i64 %t137, 32
  br i1 %t139, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s4
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l78, !tbaa !29
  %t142 = load ptr, ptr %l1, !tbaa !29
  %t144 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t142)
  store %"compiler/source:Span" %t144, ptr %l80
  br label %bb35
bb34:
  br label %bb38
bb35:
  %t145 = load ptr, ptr %l4, !tbaa !29
  store ptr %t145, ptr %l81, !tbaa !29
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/check:Checker", ptr %t146, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t151 = getelementptr %"compiler/generic:Program", ptr %t149, i32 0, i32 2
  %t153 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s4, ptr %t151, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d32, i32 0, i32 1) })
  store i32 %t153, ptr %l85
  br label %bb36
bb36:
  %t154 = load ptr, ptr %l78, !tbaa !29
  %t155 = load %"compiler/source:Span", ptr %l80
  %t156 = load ptr, ptr %l81, !tbaa !29
  %t157 = load i32, ptr %l85, !tbaa !23
  %t158 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t154, %"compiler/source:Span" %t155, ptr %t156, i32 %t157)
  store ptr %t158, ptr %l86
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t159 = load ptr, ptr %l86, !tbaa !29
  store ptr %t159, ptr %rv
  br label %ret
bb38:
  %t160 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t162 = trunc i64 31 to i32
  %t163 = icmp eq i32 %t160, %t162
  br i1 %t163, label %bb39, label %bb40
bb39:
  %t165 = load i64, ptr %l8, !tbaa !24
  %t167 = icmp sgt i64 %t165, 64
  store i1 %t167, ptr %l89, !tbaa !21
  br label %bb41
bb40:
  store i1 false, ptr %l89, !tbaa !21
  br label %bb41
bb41:
  %t169 = load i1, ptr %l89, !tbaa !21
  br i1 %t169, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s5
  %t170 = load ptr, ptr %l0, !tbaa !29
  store ptr %t170, ptr %l92, !tbaa !29
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load ptr, ptr %l1, !tbaa !29
  %t175 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %t171, ptr %t172)
  store %"compiler/source:Span" %t175, ptr %l95
  br label %bb44
bb43:
  br label %bb50
bb44:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load i32, ptr %l5, !tbaa !23
  %t180 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t176, i32 %t177)
  store { i64, ptr } %t180, ptr %l98
  br label %bb45
bb45:
  %t181 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t181, 0
  %t183 = extractvalue { i64, ptr } %t181, 1
  %t184 = mul i64 %t182, 1
  %t185 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t184)
  call void @llvm.memcpy.p0.p0.i64(ptr %t185, ptr %t183, i64 %t184, i1 false)
  %t186 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t185, 1
  %t189 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eVarArgWide(ptr %s5, ptr %s5, { i64, ptr } %t187)
  store %"compiler/msgs:Msg" %t189, ptr %l100
  br label %bb46
bb46:
  %t190 = load ptr, ptr %l92, !tbaa !29
  %t191 = load %"compiler/source:Span", ptr %l95
  %t192 = load %"compiler/msgs:Msg", ptr %l100
  %t193 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t190, %"compiler/source:Span" %t191, %"compiler/msgs:Msg" %t192)
  store i64 %t193, ptr %l101
  br label %bb47
bb47:
  %t194 = load ptr, ptr %l0, !tbaa !29
  store ptr %t194, ptr %l102, !tbaa !29
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t195)
  store %"compiler/source:Span" %t197, ptr %l104
  br label %bb48
bb48:
  %t198 = load ptr, ptr %l102, !tbaa !29
  %t199 = load %"compiler/source:Span", ptr %l104
  %t200 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t198, %"compiler/source:Span" %t199)
  store ptr %t200, ptr %l105
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t201 = load ptr, ptr %l105, !tbaa !29
  store ptr %t201, ptr %rv
  br label %ret
bb50:
  %t202 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t204 = trunc i64 31 to i32
  %t205 = icmp eq i32 %t202, %t204
  br i1 %t205, label %bb51, label %bb52
bb51:
  %t207 = load i64, ptr %l8, !tbaa !24
  %t209 = icmp ne i64 %t207, 32
  store i1 %t209, ptr %l108, !tbaa !21
  br label %bb53
bb52:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb53
bb53:
  %t211 = load i1, ptr %l108, !tbaa !21
  br i1 %t211, label %bb54, label %bb55
bb54:
  %t212 = load i64, ptr %l8, !tbaa !24
  %t214 = icmp ne i64 %t212, 64
  store i1 %t214, ptr %l111, !tbaa !21
  br label %bb56
bb55:
  store i1 false, ptr %l111, !tbaa !21
  br label %bb56
bb56:
  %t216 = load i1, ptr %l111, !tbaa !21
  br i1 %t216, label %bb57, label %bb58
bb57:
  store %olang.scope zeroinitializer, ptr %s6
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l114, !tbaa !29
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t218)
  store %"compiler/source:Span" %t220, ptr %l116
  br label %bb59
bb58:
  br label %bb67
bb59:
  %t221 = load ptr, ptr %l4, !tbaa !29
  store ptr %t221, ptr %l117, !tbaa !29
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/check:Checker", ptr %t222, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !29
  %t227 = getelementptr %"compiler/generic:Program", ptr %t225, i32 0, i32 2
  %t228 = load i32, ptr %l6, !tbaa !23
  %t231 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t227, i32 %t228)
  store i1 %t231, ptr %l122
  br label %bb60
bb60:
  %t232 = load i1, ptr %l122, !tbaa !21
  br i1 %t232, label %bb61, label %bb62
bb61:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t235 = getelementptr %"compiler/check:Checker", ptr %t233, i32 0, i32 1
  %t236 = load ptr, ptr %t235, !tbaa !29
  %t238 = getelementptr %"compiler/generic:Program", ptr %t236, i32 0, i32 2
  %t240 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s6, ptr %t238, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i32 %t240, ptr %l127
  br label %bb63
bb62:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t241)
  store i32 %t243, ptr %l129
  br label %bb64
bb63:
  %t244 = load i32, ptr %l127, !tbaa !23
  store i32 %t244, ptr %l123, !tbaa !23
  br label %bb65
bb64:
  %t245 = load i32, ptr %l129, !tbaa !23
  store i32 %t245, ptr %l123, !tbaa !23
  br label %bb65
bb65:
  %t246 = load ptr, ptr %l114, !tbaa !29
  %t247 = load %"compiler/source:Span", ptr %l116
  %t248 = load ptr, ptr %l117, !tbaa !29
  %t249 = load i32, ptr %l123, !tbaa !23
  %t250 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t246, %"compiler/source:Span" %t247, ptr %t248, i32 %t249)
  store ptr %t250, ptr %l130
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t251 = load ptr, ptr %l130, !tbaa !29
  store ptr %t251, ptr %rv
  br label %ret
bb67:
  %t252 = load i32, ptr %l6, !tbaa !23
  %t253 = load i32, ptr %l5, !tbaa !23
  %t256 = icmp ne i32 %t252, %t253
  br i1 %t256, label %bb68, label %bb69
bb68:
  %t258 = load ptr, ptr %l0, !tbaa !29
  store ptr %t258, ptr %l135, !tbaa !29
  %t259 = load ptr, ptr %l1, !tbaa !29
  %t261 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t259)
  store %"compiler/source:Span" %t261, ptr %l137
  br label %bb70
bb69:
  %t262 = load ptr, ptr %l4, !tbaa !29
  store ptr %t262, ptr %l134, !tbaa !29
  br label %bb72
bb70:
  %t264 = load ptr, ptr %l4, !tbaa !29
  %t265 = load i32, ptr %l6, !tbaa !23
  %t266 = load ptr, ptr %l135, !tbaa !29
  %t267 = load %"compiler/source:Span", ptr %l137
  %t270 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t266, %"compiler/source:Span" %t267, ptr %t264, i32 %t265)
  store ptr %t270, ptr %l140
  br label %bb71
bb71:
  %t271 = load ptr, ptr %l140, !tbaa !29
  store ptr %t271, ptr %l134, !tbaa !29
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s0)
  %t272 = load ptr, ptr %l134, !tbaa !29
  store ptr %t272, ptr %rv
  br label %ret
bb73:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/check:Checker", ptr %t273, i32 0, i32 1
  %t276 = load ptr, ptr %t275, !tbaa !29
  %t278 = getelementptr %"compiler/generic:Program", ptr %t276, i32 0, i32 2
  %t279 = load i32, ptr %l6, !tbaa !23
  %t282 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t278, i32 %t279)
  store i1 %t282, ptr %l146
  br label %bb74
bb74:
  %t283 = load i1, ptr %l146, !tbaa !21
  br i1 %t283, label %bb75, label %bb76
bb75:
  %t284 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t286 = trunc i64 14 to i32
  %t287 = icmp eq i32 %t284, %t286
  %t289 = xor i1 %t287, true
  br i1 %t289, label %bb77, label %bb78
bb76:
  br label %bb88
bb77:
  store %olang.scope zeroinitializer, ptr %s8
  %t291 = load ptr, ptr %l0, !tbaa !29
  store ptr %t291, ptr %l150, !tbaa !29
  %t292 = load ptr, ptr %l1, !tbaa !29
  %t294 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t292)
  store %"compiler/source:Span" %t294, ptr %l152
  br label %bb79
bb78:
  br label %bb82
bb79:
  %t295 = load ptr, ptr %l4, !tbaa !29
  store ptr %t295, ptr %l153, !tbaa !29
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t298 = getelementptr %"compiler/check:Checker", ptr %t296, i32 0, i32 1
  %t299 = load ptr, ptr %t298, !tbaa !29
  %t301 = getelementptr %"compiler/generic:Program", ptr %t299, i32 0, i32 2
  %t303 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s8, ptr %t301, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d34, i32 0, i32 1) })
  store i32 %t303, ptr %l157
  br label %bb80
bb80:
  %t304 = load ptr, ptr %l150, !tbaa !29
  %t305 = load %"compiler/source:Span", ptr %l152
  %t306 = load ptr, ptr %l153, !tbaa !29
  %t307 = load i32, ptr %l157, !tbaa !23
  %t308 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t304, %"compiler/source:Span" %t305, ptr %t306, i32 %t307)
  store ptr %t308, ptr %l158
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t309 = load ptr, ptr %l158, !tbaa !29
  store ptr %t309, ptr %rv
  br label %ret
bb82:
  %t310 = load i32, ptr %l6, !tbaa !23
  %t311 = load i32, ptr %l5, !tbaa !23
  %t314 = icmp ne i32 %t310, %t311
  br i1 %t314, label %bb83, label %bb84
bb83:
  %t316 = load ptr, ptr %l0, !tbaa !29
  store ptr %t316, ptr %l163, !tbaa !29
  %t317 = load ptr, ptr %l1, !tbaa !29
  %t319 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t317)
  store %"compiler/source:Span" %t319, ptr %l165
  br label %bb85
bb84:
  %t320 = load ptr, ptr %l4, !tbaa !29
  store ptr %t320, ptr %l162, !tbaa !29
  br label %bb87
bb85:
  %t322 = load ptr, ptr %l4, !tbaa !29
  %t323 = load i32, ptr %l6, !tbaa !23
  %t324 = load ptr, ptr %l163, !tbaa !29
  %t325 = load %"compiler/source:Span", ptr %l165
  %t328 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t324, %"compiler/source:Span" %t325, ptr %t322, i32 %t323)
  store ptr %t328, ptr %l168
  br label %bb86
bb86:
  %t329 = load ptr, ptr %l168, !tbaa !29
  store ptr %t329, ptr %l162, !tbaa !29
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s0)
  %t330 = load ptr, ptr %l162, !tbaa !29
  store ptr %t330, ptr %rv
  br label %ret
bb88:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t332 = load i32, ptr %l6, !tbaa !23
  %t335 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t331, i32 %t332)
  store i1 %t335, ptr %l172
  br label %bb89
bb89:
  %t336 = load i1, ptr %l172, !tbaa !21
  br i1 %t336, label %bb90, label %bb91
bb90:
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t339 = getelementptr %"compiler/check:Checker", ptr %t337, i32 0, i32 1
  %t340 = load ptr, ptr %t339, !tbaa !29
  %t342 = getelementptr %"compiler/generic:Program", ptr %t340, i32 0, i32 2
  %t343 = load i32, ptr %l6, !tbaa !23
  %t346 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t342, i32 %t343)
  store i32 %t346, ptr %l178
  br label %bb92
bb91:
  %t347 = load i32, ptr %l6, !tbaa !23
  store i32 %t347, ptr %l173, !tbaa !23
  br label %bb93
bb92:
  %t349 = load i32, ptr %l178, !tbaa !23
  store i32 %t349, ptr %l173, !tbaa !23
  br label %bb93
bb93:
  %t350 = load i32, ptr %l173, !tbaa !23
  store i32 %t350, ptr %l9, !tbaa !23
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t352 = load i32, ptr %l6, !tbaa !23
  %t355 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t351, i32 %t352)
  store i1 %t355, ptr %l182
  br label %bb94
bb94:
  %t356 = load i1, ptr %l182, !tbaa !21
  br i1 %t356, label %bb95, label %bb96
bb95:
  store i1 true, ptr %l183, !tbaa !21
  br label %bb99
bb96:
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t359 = getelementptr %"compiler/check:Checker", ptr %t357, i32 0, i32 1
  %t360 = load ptr, ptr %t359, !tbaa !29
  %t362 = getelementptr %"compiler/generic:Program", ptr %t360, i32 0, i32 2
  store ptr %t362, ptr %l186, !tbaa !29
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t365 = getelementptr %"compiler/check:Checker", ptr %t363, i32 0, i32 1
  %t366 = load ptr, ptr %t365, !tbaa !29
  %t368 = getelementptr %"compiler/generic:Program", ptr %t366, i32 0, i32 2
  %t369 = load i32, ptr %l9, !tbaa !23
  %t372 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t368, i32 %t369)
  store i32 %t372, ptr %l191
  br label %bb97
bb97:
  %t373 = load ptr, ptr %l186, !tbaa !29
  %t374 = load i32, ptr %l191, !tbaa !23
  %t375 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t373, i32 %t374)
  store i32 %t375, ptr %l192
  br label %bb98
bb98:
  %t376 = load i32, ptr %l192, !range !{i32 0, i32 33}
  %t378 = trunc i64 19 to i32
  %t379 = icmp eq i32 %t376, %t378
  store i1 %t379, ptr %l183, !tbaa !21
  br label %bb99
bb99:
  %t381 = load i1, ptr %l183, !tbaa !21
  br i1 %t381, label %bb100, label %bb101
bb100:
  %t382 = load ptr, ptr %l4, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t382, ptr %rv
  br label %ret
bb101:
  br label %bb102
bb102:
  %t384 = load ptr, ptr %l0, !tbaa !29
  store ptr %t384, ptr %l196, !tbaa !29
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t386 = load ptr, ptr %l1, !tbaa !29
  %t389 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %t385, ptr %t386)
  store %"compiler/source:Span" %t389, ptr %l199
  br label %bb103
bb103:
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t391 = load i32, ptr %l5, !tbaa !23
  %t394 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t390, i32 %t391)
  store { i64, ptr } %t394, ptr %l202
  br label %bb104
bb104:
  %t395 = load { i64, ptr }, ptr %l202, !tbaa !27
  %t396 = extractvalue { i64, ptr } %t395, 0
  %t397 = extractvalue { i64, ptr } %t395, 1
  %t398 = mul i64 %t396, 1
  %t399 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t398)
  call void @llvm.memcpy.p0.p0.i64(ptr %t399, ptr %t397, i64 %t398, i1 false)
  %t400 = insertvalue { i64, ptr } undef, i64 %t396, 0
  %t401 = insertvalue { i64, ptr } %t400, ptr %t399, 1
  %t403 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eVarArgType(ptr %s0, ptr %s0, { i64, ptr } %t401)
  store %"compiler/msgs:Msg" %t403, ptr %l204
  br label %bb105
bb105:
  %t404 = load ptr, ptr %l196, !tbaa !29
  %t405 = load %"compiler/source:Span", ptr %l199
  %t406 = load %"compiler/msgs:Msg", ptr %l204
  %t407 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t404, %"compiler/source:Span" %t405, %"compiler/msgs:Msg" %t406)
  store i64 %t407, ptr %l205
  br label %bb106
bb106:
  %t408 = load ptr, ptr %l0, !tbaa !29
  store ptr %t408, ptr %l206, !tbaa !29
  %t409 = load ptr, ptr %l1, !tbaa !29
  %t411 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t409)
  store %"compiler/source:Span" %t411, ptr %l208
  br label %bb107
bb107:
  %t412 = load ptr, ptr %l206, !tbaa !29
  %t413 = load %"compiler/source:Span", ptr %l208
  %t414 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t412, %"compiler/source:Span" %t413)
  store ptr %t414, ptr %l209
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s0)
  %t415 = load ptr, ptr %l209, !tbaa !29
  store ptr %t415, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordIndex(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l13 = alloca { i64, ptr }
  %l19 = alloca i64
  %l22 = alloca i64
  %l40 = alloca { i64, ptr }
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %t4, i32 %a1)
  store { i64, ptr } %t8, ptr %l13
  br label %bb1
bb1:
  %t9 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t9, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp sgt i64 %t14, %t15
  br i1 %t18, label %bb2, label %bb3
bb2:
  %t20 = load i64, ptr %l6, !tbaa !24
  %t22 = icmp sgt i64 %t20, 0
  br i1 %t22, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb7
bb4:
  %t24 = load i64, ptr %l5, !tbaa !24
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = sub i64 %t24, %t25
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = add i64 %t28, %t29
  %t34 = sub i64 %t32, 1
  %t35 = load i64, ptr %l6, !tbaa !24
  %t38 = sdiv i64 %t34, %t35
  store i64 %t38, ptr %l22, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb6
bb6:
  %t40 = load i64, ptr %l22, !tbaa !24
  store i64 %t40, ptr %l19, !tbaa !24
  br label %bb7
bb7:
  %t41 = load i64, ptr %l19, !tbaa !24
  store i64 %t41, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  %t42 = load i64, ptr %l8, !tbaa !24
  %t43 = load i64, ptr %l7, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb9, label %bb10
bb9:
  br label %bb16
bb10:
  br label %bb11
bb11:
  %t50 = load i64, ptr %l4, !tbaa !24
  %t51 = load i64, ptr %l8, !tbaa !24
  %t52 = load i64, ptr %l6, !tbaa !24
  %t55 = mul i64 %t51, %t52
  %t58 = add i64 %t50, %t55
  store i64 %t58, ptr %l9, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t60, ptr %l40, !tbaa !27
  %t61 = load i64, ptr %l9, !tbaa !24
  %t63 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i32, ptr %t64, i64 %t61
  %t66 = load i32, ptr %t65, !tbaa !33
  %t70 = icmp eq i32 %t66, %a2
  br i1 %t70, label %bb12, label %bb13
bb12:
  %t72 = load i64, ptr %l9, !tbaa !24
  store i64 %t72, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t74 = load i64, ptr %l8, !tbaa !24
  %t76 = add i64 %t74, 1
  store i64 %t76, ptr %l8, !tbaa !24
  br label %bb8
bb16:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eyieldStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l6 = alloca { i64, [3 x i64] }
  %l7 = alloca ptr
  %l9 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l17 = alloca ptr
  %l18 = alloca %"compiler/source:Span"
  %l22 = alloca i1
  %l26 = alloca %"compiler/msgs:Msg"
  %l27 = alloca %"compiler/msgs:Msg"
  %l28 = alloca %"compiler/msgs:Msg"
  %l29 = alloca i64
  %l34 = alloca ptr
  %l38 = alloca ptr
  %l39 = alloca %"compiler/source:Span"
  %l40 = alloca %"compiler/msgs:Msg"
  %l41 = alloca i64
  %l44 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca %"compiler/source:Span"
  %l48 = alloca %"compiler/msgs:Msg"
  %l49 = alloca i64
  %l52 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca %"compiler/source:Span"
  %l56 = alloca %"compiler/msgs:Msg"
  %l57 = alloca i64
  %l62 = alloca ptr
  %l64 = alloca { i64, [3 x i64] }
  %l68 = alloca ptr
  %l71 = alloca i32
  %l73 = alloca i32
  %l75 = alloca i1
  %l76 = alloca ptr
  %l79 = alloca i32
  %l80 = alloca i1
  %l88 = alloca ptr
  %l91 = alloca i1
  %l93 = alloca ptr
  %l95 = alloca ptr
  %l97 = alloca %"compiler/source:Span"
  %l99 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %t152 = alloca { i64, [4 x i64] }, align 8
  %t193 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l9, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  %t7 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t8 = load i32, ptr %t7, !tbaa !23
  %t10 = add i32 %t8, 5
  %t13 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t6, i32 %t10)
  store %"compiler/source:Span" %t13, ptr %l13
  br label %bb2
bb2:
  %t14 = load %"compiler/source:Span", ptr %l13
  store %"compiler/source:Span" %t14, ptr %l4
  %t15 = load ptr, ptr %l3, !tbaa !29
  %t17 = getelementptr %"compiler/check:frame", ptr %t15, i32 0, i32 20
  %t18 = load i1, ptr %t17, !tbaa !21
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l17, !tbaa !29
  %t23 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t23, ptr %l18
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t26 = getelementptr %"compiler/check:frame", ptr %t24, i32 0, i32 19
  %t27 = load i64, ptr %t26, !tbaa !24
  %t29 = icmp sge i64 %t27, 0
  br i1 %t29, label %bb5, label %bb6
bb4:
  br label %bb15
bb5:
  %t31 = load ptr, ptr %l3, !tbaa !29
  %t33 = getelementptr %"compiler/check:frame", ptr %t31, i32 0, i32 32
  %t34 = load i64, ptr %t33, !tbaa !24
  %t36 = icmp slt i64 %t34, 0
  store i1 %t36, ptr %l22, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb7
bb7:
  %t38 = load i1, ptr %l22, !tbaa !21
  br i1 %t38, label %bb8, label %bb9
bb8:
  %t39 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eYieldInLambda(ptr %s1)
  store %"compiler/msgs:Msg" %t39, ptr %l27
  br label %bb10
bb9:
  %t40 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eYieldOutside(ptr %s1)
  store %"compiler/msgs:Msg" %t40, ptr %l28
  br label %bb11
bb10:
  %t41 = load %"compiler/msgs:Msg", ptr %l27
  store %"compiler/msgs:Msg" %t41, ptr %l26
  br label %bb12
bb11:
  %t42 = load %"compiler/msgs:Msg", ptr %l28
  store %"compiler/msgs:Msg" %t42, ptr %l26
  br label %bb12
bb12:
  %t43 = load ptr, ptr %l17, !tbaa !29
  %t44 = load %"compiler/source:Span", ptr %l18
  %t45 = load %"compiler/msgs:Msg", ptr %l26
  %t46 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t43, %"compiler/source:Span" %t44, %"compiler/msgs:Msg" %t45)
  store i64 %t46, ptr %l29
  br label %bb13
bb13:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t50 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t54 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t47, ptr %t48, i32 %t50)
  store ptr %t54, ptr %l34
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb15:
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t57 = getelementptr %"compiler/check:frame", ptr %t55, i32 0, i32 32
  %t58 = load i64, ptr %t57, !tbaa !24
  %t60 = icmp sge i64 %t58, 0
  br i1 %t60, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s2
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l38, !tbaa !29
  %t63 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t63, ptr %l39
  %t64 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eYieldInDefer(ptr %s2)
  store %"compiler/msgs:Msg" %t64, ptr %l40
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t65 = load ptr, ptr %l38, !tbaa !29
  %t66 = load %"compiler/source:Span", ptr %l39
  %t67 = load %"compiler/msgs:Msg", ptr %l40
  %t68 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t65, %"compiler/source:Span" %t66, %"compiler/msgs:Msg" %t67)
  store i64 %t68, ptr %l41
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb20:
  %t69 = load ptr, ptr %l3, !tbaa !29
  %t71 = getelementptr %"compiler/check:frame", ptr %t69, i32 0, i32 36
  %t73 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t71)
  store i64 %t73, ptr %l44
  br label %bb21
bb21:
  %t74 = load i64, ptr %l44, !tbaa !24
  %t75 = icmp sgt i64 %t74, 0
  br i1 %t75, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s3
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l46, !tbaa !29
  %t78 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t78, ptr %l47
  %t79 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eYieldInJoin(ptr %s3)
  store %"compiler/msgs:Msg" %t79, ptr %l48
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t80 = load ptr, ptr %l46, !tbaa !29
  %t81 = load %"compiler/source:Span", ptr %l47
  %t82 = load %"compiler/msgs:Msg", ptr %l48
  %t83 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t80, %"compiler/source:Span" %t81, %"compiler/msgs:Msg" %t82)
  store i64 %t83, ptr %l49
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb26:
  %t84 = load ptr, ptr %l3, !tbaa !29
  %t86 = getelementptr %"compiler/check:frame", ptr %t84, i32 0, i32 22
  %t88 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t86)
  store i64 %t88, ptr %l52
  br label %bb27
bb27:
  %t89 = load i64, ptr %l52, !tbaa !24
  %t90 = icmp sgt i64 %t89, 0
  br i1 %t90, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s4
  %t92 = load ptr, ptr %l0, !tbaa !29
  store ptr %t92, ptr %l54, !tbaa !29
  %t93 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t93, ptr %l55
  %t94 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eYieldPastDefer(ptr %s4)
  store %"compiler/msgs:Msg" %t94, ptr %l56
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t95 = load ptr, ptr %l54, !tbaa !29
  %t96 = load %"compiler/source:Span", ptr %l55
  %t97 = load %"compiler/msgs:Msg", ptr %l56
  %t98 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t95, %"compiler/source:Span" %t96, %"compiler/msgs:Msg" %t97)
  store i64 %t98, ptr %l57
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb32:
  %t99 = load ptr, ptr %l3, !tbaa !29
  %t101 = getelementptr %"compiler/check:frame", ptr %t99, i32 0, i32 5
  %t102 = load i32, ptr %t101, !tbaa !23
  store i32 %t102, ptr %l5, !tbaa !23
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/check:Checker", ptr %t104, i32 0, i32 11
  %t107 = load { i64, [3 x i64] }, ptr %t106
  store { i64, [3 x i64] } %t107, ptr %l6
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l62, !tbaa !29
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresultAt(ptr %v0, ptr %t110, i64 0)
  store { i64, [3 x i64] } %t112, ptr %l64
  br label %bb33
bb33:
  %t113 = load { i64, [3 x i64] }, ptr %l64
  %t114 = load ptr, ptr %l62, !tbaa !29
  %t115 = getelementptr %"compiler/check:Checker", ptr %t114, i32 0, i32 11
  store { i64, [3 x i64] } %t113, ptr %t115
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load ptr, ptr %l2, !tbaa !29
  %t118 = load i32, ptr %l5, !tbaa !23
  %t122 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %t116, ptr %t117, i32 %t118)
  store ptr %t122, ptr %l68
  br label %bb34
bb34:
  %t123 = load ptr, ptr %l68, !tbaa !29
  store ptr %t123, ptr %l7, !tbaa !29
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load { i64, [3 x i64] }, ptr %l6
  %t128 = getelementptr %"compiler/check:Checker", ptr %t124, i32 0, i32 11
  store { i64, [3 x i64] } %t125, ptr %t128
  %t129 = load i32, ptr %l5, !tbaa !23
  store i32 %t129, ptr %l71, !tbaa !23
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t130)
  store i32 %t132, ptr %l73
  br label %bb35
bb35:
  %t133 = load i32, ptr %l71, !tbaa !23
  %t134 = load i32, ptr %l73, !tbaa !23
  %t135 = icmp eq i32 %t133, %t134
  br i1 %t135, label %bb36, label %bb37
bb36:
  %t137 = load ptr, ptr %l0, !tbaa !29
  store ptr %t137, ptr %l76, !tbaa !29
  %t138 = load ptr, ptr %l7, !tbaa !29
  %t141 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t138)
  store i32 %t141, ptr %l79
  br label %bb38
bb37:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb40
bb38:
  %t142 = load ptr, ptr %l76, !tbaa !29
  %t143 = load i32, ptr %l79, !tbaa !23
  %t144 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t142, i32 %t143)
  store i1 %t144, ptr %l80
  br label %bb39
bb39:
  %t145 = load i1, ptr %l80, !tbaa !21
  store i1 %t145, ptr %l75, !tbaa !21
  br label %bb40
bb40:
  %t146 = load i1, ptr %l75, !tbaa !21
  br i1 %t146, label %bb41, label %bb42
bb41:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load %"compiler/source:Span", ptr %l1
  %t149 = load %"compiler/source:Span", ptr %l1
  %t150 = load i32, ptr %l5, !tbaa !23
  %t151 = load ptr, ptr %l7, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t152
  %t153 = getelementptr { i64, [4 x i64] }, ptr %t152, i32 0, i32 0
  store i64 2, ptr %t153
  %t155 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t149, 0
  %t157 = insertvalue { %"compiler/source:Span", i32, ptr } %t155, i32 %t150, 1
  %t159 = insertvalue { %"compiler/source:Span", i32, ptr } %t157, ptr %t151, 2
  %t160 = getelementptr { i64, [4 x i64] }, ptr %t152, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t159, ptr %t160
  %t161 = load { i64, [4 x i64] }, ptr %t152
  %t163 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t161, ptr %t163
  %t167 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t147, %"compiler/source:Span" %t148, ptr %t163)
  store ptr %t167, ptr %l88
  br label %bb43
bb42:
  br label %bb44
bb43:
  %t168 = load ptr, ptr %l88, !tbaa !29
  store ptr %t168, ptr %l7, !tbaa !29
  br label %bb44
bb44:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load i32, ptr %l5, !tbaa !23
  %t173 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t169, i32 %t170)
  store i1 %t173, ptr %l91
  br label %bb45
bb45:
  %t174 = load i1, ptr %l91, !tbaa !21
  %t175 = xor i1 %t174, true
  br i1 %t175, label %bb46, label %bb47
bb46:
  %t177 = load ptr, ptr %l0, !tbaa !29
  store ptr %t177, ptr %l93, !tbaa !29
  %t178 = load ptr, ptr %l7, !tbaa !29
  store ptr %t178, ptr %l95, !tbaa !29
  %t180 = load ptr, ptr %l2, !tbaa !29
  %t182 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t180)
  store %"compiler/source:Span" %t182, ptr %l97
  br label %bb48
bb47:
  br label %bb50
bb48:
  %t183 = load i64, ptr @G_2ecompiler_2fcheck_2eRoReturned, !tbaa !24
  %t184 = load ptr, ptr %l93, !tbaa !29
  %t185 = load ptr, ptr %l95, !tbaa !29
  %t186 = load %"compiler/source:Span", ptr %l97
  %t188 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v0, ptr %t184, ptr %t185, %"compiler/source:Span" %t186, i64 %t183)
  store i1 %t188, ptr %l99
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load %"compiler/source:Span", ptr %l1
  %t191 = load ptr, ptr %l7, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t193
  %t194 = getelementptr { i64, [3 x i64] }, ptr %t193, i32 0, i32 0
  store i64 16, ptr %t194
  %t196 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t190, 0
  %t198 = insertvalue { %"compiler/source:Span", ptr } %t196, ptr %t191, 1
  %t199 = getelementptr { i64, [3 x i64] }, ptr %t193, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t198, ptr %t199
  %t200 = load { i64, [3 x i64] }, ptr %t193
  %t202 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t200, ptr %t202
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t189, ptr %t202)
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ectKey(%"compiler/source:Span" %a0) #0 {
entry:
  %l0 = alloca %"compiler/source:Span"
  %rv = alloca i64
  store %"compiler/source:Span" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/source:Span", ptr %l0, i32 0, i32 0
  %t2 = load i32, ptr %t1, !tbaa !23
  %t4 = sext i32 %t2 to i64
  %t6 = shl i64 %t4, 32
  %t7 = getelementptr %"compiler/source:Span", ptr %l0, i32 0, i32 1
  %t8 = load i32, ptr %t7, !tbaa !23
  %t10 = sext i32 %t8 to i64
  %t13 = or i64 %t6, %t10
  store i64 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2edeclNames(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca i1
  %l29 = alloca i32
  %l32 = alloca i1
  %l35 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb5, label %bb6
bb5:
  br label %bb36
bb6:
  br label %bb7
bb7:
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t21, ptr %l19, !tbaa !27
  %t22 = load i64, ptr %l3, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr ptr, ptr %t25, i64 %t22
  %t27 = load ptr, ptr %t26, !tbaa !39
  store ptr %t27, ptr %l5, !tbaa !29
  %t29 = load ptr, ptr %l5, !tbaa !29
  store ptr %t29, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t30 = load ptr, ptr %l22, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb8, label %bb9
bb8:
  %t33 = load ptr, ptr %l22, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 11}
  %t36 = icmp eq i64 %t34, 8
  store i1 %t36, ptr %l23, !tbaa !21
  br label %bb9
bb9:
  %t37 = load i1, ptr %l23, !tbaa !21
  br i1 %t37, label %bb10, label %bb11
bb10:
  %t38 = load ptr, ptr %l5, !tbaa !29
  %t40 = getelementptr { i64, [6 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t40, i32 0, i32 1
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l6, !tbaa !29
  br label %bb12
bb11:
  br label %bb22
bb12:
  %t44 = load ptr, ptr %l6, !tbaa !29
  %t46 = call i32 @compiler_2fcheck_2esetName(ptr %v0, ptr %t44)
  store i32 %t46, ptr %l29
  br label %bb13
bb13:
  %t47 = load i32, ptr %l29, !tbaa !23
  store i32 %t47, ptr %l7, !tbaa !23
  %t48 = load i32, ptr %l7, !tbaa !23
  %t50 = icmp ne i32 %t48, 0
  br i1 %t50, label %bb14, label %bb15
bb14:
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t53 = load i32, ptr %l7, !tbaa !23
  %t56 = call i1 @compiler_2fcheck_2ehasName(ptr %v1, ptr %t52, i32 %t53)
  store i1 %t56, ptr %l35
  br label %bb16
bb15:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb17
bb16:
  %t57 = load i1, ptr %l35, !tbaa !21
  %t58 = xor i1 %t57, true
  store i1 %t58, ptr %l32, !tbaa !21
  br label %bb17
bb17:
  %t60 = load i1, ptr %l32, !tbaa !21
  br i1 %t60, label %bb18, label %bb19
bb18:
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t62 = load i32, ptr %l7, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v1, ptr %t61, i32 %t62)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  br label %bb34
bb22:
  %t65 = load ptr, ptr %l5, !tbaa !29
  store ptr %t65, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t66 = load ptr, ptr %l39, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb23, label %bb24
bb23:
  %t69 = load ptr, ptr %l39, !tbaa !29
  %t70 = load i64, ptr %t69, !range !{i64 0, i64 11}
  %t72 = icmp eq i64 %t70, 7
  store i1 %t72, ptr %l40, !tbaa !21
  br label %bb24
bb24:
  %t73 = load i1, ptr %l40, !tbaa !21
  br i1 %t73, label %bb25, label %bb26
bb25:
  %t74 = load ptr, ptr %l5, !tbaa !29
  %t76 = getelementptr { i64, [6 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", ptr }, ptr %t76, i32 0, i32 1
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l8, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t80 = load ptr, ptr %l8, !tbaa !29
  %t81 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2echainNames(ptr %v0, ptr %v1, ptr %t80, ptr %t81)
  br label %bb28
bb28:
  br label %bb34
bb29:
  br i1 true, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_bae3cd237d905c4d_ccae9f7ce38212b9)
  unreachable
bb34:
  br label %bb35
bb35:
  %t84 = load i64, ptr %l3, !tbaa !24
  %t86 = add i64 %t84, 1
  store i64 %t86, ptr %l3, !tbaa !24
  br label %bb4
bb36:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2efloatBits(i32 %a0, double %a1) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca double
  %rv = alloca i64
  store i32 %a0, ptr %l0
  store double %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !tbaa !23
  %t3 = icmp eq i32 %t1, 13
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load double, ptr %l1, !tbaa !26
  %t7 = fptrunc double %t5 to float
  %t9 = bitcast float %t7 to i32
  %t11 = zext i32 %t9 to i64
  store i64 %t11, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t13 = load i32, ptr %l0, !tbaa !23
  %t15 = icmp eq i32 %t13, 11
  br i1 %t15, label %bb4, label %bb5
bb4:
  %t17 = load double, ptr %l1, !tbaa !26
  %t19 = fptrunc double %t17 to half
  %t21 = bitcast half %t19 to i16
  %t22 = call i16 asm "", "=r,0"(i16 %t21)
  %t24 = zext i16 %t22 to i64
  store i64 %t24, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t26 = load i32, ptr %l0, !tbaa !23
  %t28 = icmp eq i32 %t26, 12
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t30 = load double, ptr %l1, !tbaa !26
  %t32 = fptrunc double %t30 to bfloat
  %t34 = bitcast bfloat %t32 to i16
  %t35 = call i16 asm "", "=r,0"(i16 %t34)
  %t37 = zext i16 %t35 to i64
  store i64 %t37, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t39 = load double, ptr %l1, !tbaa !26
  %t41 = bitcast double %t39 to i64
  store i64 %t41, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2efloatLit(double %a0) #0 {
entry:
  %l2 = alloca %"compiler/check:litv"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/check:litv"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %s0, i1 true, i1 true, i1 false, i64 0, double %a0)
  store %"compiler/check:litv" %t3, ptr %l2
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t4 = load %"compiler/check:litv", ptr %l2
  store %"compiler/check:litv" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local i1 @compiler_2fcheck_2eisArrayMake(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 7
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Make", ptr %t16, i32 0, i32 0
  %t19 = load i32, ptr %t18, !range !{i32 0, i32 4}
  %t21 = trunc i64 2 to i32
  %t22 = icmp eq i32 %t19, %t21
  store i1 %t22, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_f62b02ebb614301c_75e9b5b90c5bfe48)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2elimitBits(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %l7 = alloca i64
  %l10 = alloca i1
  %l13 = alloca i1
  %l17 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l25 = alloca i64
  %l29 = alloca i64
  %l31 = alloca i64
  %l36 = alloca [6 x i64]
  %l41 = alloca [6 x i64]
  %l46 = alloca [6 x i64]
  %l49 = alloca [6 x i64]
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i64, ptr %l7, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t7, i32 %t8)
  store i1 %t11, ptr %l10
  br label %bb2
bb2:
  %t12 = load i1, ptr %l10, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t13, i32 %t14)
  store i1 %t17, ptr %l13
  br label %bb5
bb4:
  br label %bb18
bb5:
  %t18 = load i1, ptr %l13, !tbaa !21
  store i1 %t18, ptr %l4, !tbaa !21
  %t19 = load i64, ptr %l2, !tbaa !24
  %t21 = icmp eq i64 %t19, 0
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t23 = load i1, ptr %l4, !tbaa !21
  br i1 %t23, label %bb8, label %bb9
bb7:
  br label %bb14
bb8:
  %t25 = load i64, ptr %l3, !tbaa !24
  %t27 = icmp eq i64 %t25, 64
  br i1 %t27, label %bb10, label %bb11
bb9:
  %t29 = load i64, ptr %l3, !tbaa !24
  %t31 = sub i64 %t29, 1
  store i64 %t31, ptr %l25, !tbaa !24
  %t32 = load i64, ptr %l25, !tbaa !24
  %t33 = load i64, ptr %l25, !tbaa !24
  %t34 = shl i64 1, %t33
  %t36 = sub i64 %t34, 1
  store i64 %t36, ptr %l17, !tbaa !24
  br label %bb13
bb10:
  store i64 -1, ptr %l20, !tbaa !24
  br label %bb12
bb11:
  %t38 = load i64, ptr %l3, !tbaa !24
  store i64 %t38, ptr %l21, !tbaa !24
  %t39 = load i64, ptr %l21, !tbaa !24
  %t40 = load i64, ptr %l21, !tbaa !24
  %t41 = shl i64 1, %t40
  %t43 = sub i64 %t41, 1
  store i64 %t43, ptr %l20, !tbaa !24
  br label %bb12
bb12:
  %t45 = load i64, ptr %l20, !tbaa !24
  store i64 %t45, ptr %l17, !tbaa !24
  br label %bb13
bb13:
  %t46 = load i64, ptr %l17, !tbaa !24
  store i64 %t46, ptr %rv
  br label %ret
bb14:
  %t47 = load i1, ptr %l4, !tbaa !21
  br i1 %t47, label %bb15, label %bb16
bb15:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb17
bb16:
  %t49 = load i64, ptr %l3, !tbaa !24
  %t51 = sub i64 %t49, 1
  store i64 %t51, ptr %l31, !tbaa !24
  %t52 = load i64, ptr %l31, !tbaa !24
  %t53 = load i64, ptr %l31, !tbaa !24
  %t54 = shl i64 1, %t53
  %t56 = sub i64 0, %t54
  store i64 %t56, ptr %l29, !tbaa !24
  br label %bb17
bb17:
  %t58 = load i64, ptr %l29, !tbaa !24
  store i64 %t58, ptr %rv
  br label %ret
bb18:
  %t59 = load i32, ptr %l1, !tbaa !23
  %t61 = icmp eq i32 %t59, 13
  br i1 %t61, label %bb19, label %bb20
bb19:
  %t63 = insertvalue [6 x i64] undef, i64 2139095039, 0
  %t64 = insertvalue [6 x i64] %t63, i64 4286578687, 1
  %t65 = insertvalue [6 x i64] %t64, i64 2139095040, 2
  %t66 = insertvalue [6 x i64] %t65, i64 2143289344, 3
  %t67 = insertvalue [6 x i64] %t66, i64 872415232, 4
  %t68 = insertvalue [6 x i64] %t67, i64 8388608, 5
  store [6 x i64] %t68, ptr %l36
  %t69 = load i64, ptr %l2, !tbaa !24
  %t71 = getelementptr [6 x i64], ptr %l36, i64 0, i64 %t69
  %t72 = load i64, ptr %t71, !tbaa !34
  store i64 %t72, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t74 = load i32, ptr %l1, !tbaa !23
  %t76 = icmp eq i32 %t74, 11
  br i1 %t76, label %bb22, label %bb23
bb22:
  %t78 = insertvalue [6 x i64] undef, i64 31743, 0
  %t79 = insertvalue [6 x i64] %t78, i64 64511, 1
  %t80 = insertvalue [6 x i64] %t79, i64 31744, 2
  %t81 = insertvalue [6 x i64] %t80, i64 32256, 3
  %t82 = insertvalue [6 x i64] %t81, i64 5120, 4
  %t83 = insertvalue [6 x i64] %t82, i64 1024, 5
  store [6 x i64] %t83, ptr %l41
  %t84 = load i64, ptr %l2, !tbaa !24
  %t86 = getelementptr [6 x i64], ptr %l41, i64 0, i64 %t84
  %t87 = load i64, ptr %t86, !tbaa !34
  store i64 %t87, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t89 = load i32, ptr %l1, !tbaa !23
  %t91 = icmp eq i32 %t89, 12
  br i1 %t91, label %bb25, label %bb26
bb25:
  %t93 = insertvalue [6 x i64] undef, i64 32639, 0
  %t94 = insertvalue [6 x i64] %t93, i64 65407, 1
  %t95 = insertvalue [6 x i64] %t94, i64 32640, 2
  %t96 = insertvalue [6 x i64] %t95, i64 32704, 3
  %t97 = insertvalue [6 x i64] %t96, i64 15360, 4
  %t98 = insertvalue [6 x i64] %t97, i64 128, 5
  store [6 x i64] %t98, ptr %l46
  %t99 = load i64, ptr %l2, !tbaa !24
  %t101 = getelementptr [6 x i64], ptr %l46, i64 0, i64 %t99
  %t102 = load i64, ptr %t101, !tbaa !34
  store i64 %t102, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t104 = insertvalue [6 x i64] undef, i64 9218868437227405311, 0
  %t105 = insertvalue [6 x i64] %t104, i64 -4503599627370497, 1
  %t106 = insertvalue [6 x i64] %t105, i64 9218868437227405312, 2
  %t107 = insertvalue [6 x i64] %t106, i64 9221120237041090560, 3
  %t108 = insertvalue [6 x i64] %t107, i64 4372995238176751616, 4
  %t109 = insertvalue [6 x i64] %t108, i64 4503599627370496, 5
  store [6 x i64] %t109, ptr %l49
  %t110 = load i64, ptr %l2, !tbaa !24
  %t112 = getelementptr [6 x i64], ptr %l49, i64 0, i64 %t110
  %t113 = load i64, ptr %t112, !tbaa !34
  store i64 %t113, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fcheck_2elimitIndex(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca [6 x { i64, ptr }]
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l38 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = insertvalue [6 x { i64, ptr }] undef, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t2 = insertvalue [6 x { i64, ptr }] %t1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t3 = insertvalue [6 x { i64, ptr }] %t2, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d37, i32 0, i32 1) }, 2
  %t4 = insertvalue [6 x { i64, ptr }] %t3, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d38, i32 0, i32 1) }, 3
  %t5 = insertvalue [6 x { i64, ptr }] %t4, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d39, i32 0, i32 1) }, 4
  %t6 = insertvalue [6 x { i64, ptr }] %t5, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d40, i32 0, i32 1) }, 5
  store [6 x { i64, ptr }] %t6, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t8 = load [6 x { i64, ptr }], ptr %l1
  store i64 6, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l2, !tbaa !24
  %t15 = icmp sgt i64 %t11, %t12
  br i1 %t15, label %bb1, label %bb2
bb1:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t21 = load i64, ptr %l3, !tbaa !24
  %t22 = load i64, ptr %l2, !tbaa !24
  %t25 = sub i64 %t21, %t22
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = add i64 %t25, %t26
  %t31 = sub i64 %t29, 1
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = sdiv i64 %t31, %t32
  store i64 %t35, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t37 = load i64, ptr %l17, !tbaa !24
  store i64 %t37, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t38 = load i64, ptr %l14, !tbaa !24
  store i64 %t38, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  %t39 = load i64, ptr %l6, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb8, label %bb9
bb8:
  br label %bb16
bb9:
  br label %bb10
bb10:
  %t47 = load i64, ptr %l2, !tbaa !24
  %t48 = load i64, ptr %l6, !tbaa !24
  %t49 = load i64, ptr %l4, !tbaa !24
  %t52 = mul i64 %t48, %t49
  %t55 = add i64 %t47, %t52
  store i64 %t55, ptr %l7, !tbaa !24
  %t57 = load i64, ptr %l7, !tbaa !24
  %t59 = getelementptr [6 x { i64, ptr }], ptr %l1, i64 0, i64 %t57
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !37
  %t64 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %v0, { i64, ptr } %t60, { i64, ptr } %a0)
  store i1 %t64, ptr %l38
  br label %bb11
bb11:
  %t65 = load i1, ptr %l38, !tbaa !21
  br i1 %t65, label %bb12, label %bb13
bb12:
  %t66 = load i64, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t66, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t68 = load i64, ptr %l6, !tbaa !24
  %t70 = add i64 %t68, 1
  store i64 %t70, ptr %l6, !tbaa !24
  br label %bb7
bb16:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fcheck_2emeetPerm(i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %rv = alloca i64
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = and i64 %t1, %t2
  %t6 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t7 = load i64, ptr @G_2ecompiler_2ftypes_2eOwning, !tbaa !24
  %t10 = or i64 %t6, %t7
  %t13 = and i64 %t5, %t10
  %t14 = load i64, ptr %l0, !tbaa !24
  %t15 = load i64, ptr %l1, !tbaa !24
  %t18 = or i64 %t14, %t15
  %t19 = load i64, ptr @G_2ecompiler_2ftypes_2eNullable, !tbaa !24
  %t22 = and i64 %t18, %t19
  %t25 = or i64 %t13, %t22
  store i64 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %a0, i64 %a1) #0 {
entry:
  %l0 = alloca %"compiler/source:Span"
  %l7 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store %"compiler/source:Span" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/source:Span", ptr %l0, i32 0, i32 1
  %t2 = load i32, ptr %t1, !tbaa !23
  %t5 = trunc i64 %a1 to i32
  %t8 = sub i32 %t2, %t5
  %t9 = getelementptr %"compiler/source:Span", ptr %l0, i32 0, i32 1
  %t10 = load i32, ptr %t9, !tbaa !23
  %t13 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t8, i32 %t10)
  store %"compiler/source:Span" %t13, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t14 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t14, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2ewideBits(i32 %a0, %"compiler/check:litv" %a1, %"compiler/check:litv" %a2) #0 {
entry:
  %l0 = alloca i32
  %l3 = alloca %"compiler/check:signMag"
  %l4 = alloca i1
  %l5 = alloca i128
  %l6 = alloca %"compiler/check:signMag"
  %l7 = alloca i1
  %l8 = alloca i128
  %l9 = alloca i1
  %l10 = alloca i128
  %l12 = alloca %"compiler/check:signMag"
  %l16 = alloca %"compiler/check:signMag"
  %l21 = alloca i1
  %l23 = alloca i1
  %l27 = alloca i1
  %l29 = alloca i1
  %l36 = alloca i128
  %l42 = alloca i128
  %l52 = alloca %"compiler/check:litv"
  %l55 = alloca %"compiler/check:litv"
  %l58 = alloca %"compiler/check:litv"
  %rv = alloca %"compiler/check:litv"
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call %"compiler/check:signMag" @compiler_2fcheck_2etwos(%"compiler/check:litv" %a1)
  store %"compiler/check:signMag" %t3, ptr %l12
  br label %bb1
bb1:
  %t4 = load %"compiler/check:signMag", ptr %l12
  store %"compiler/check:signMag" %t4, ptr %l3
  %t5 = getelementptr %"compiler/check:signMag", ptr %l3, i32 0, i32 0
  %t6 = load i1, ptr %t5, !tbaa !21
  store i1 %t6, ptr %l4, !tbaa !21
  %t8 = getelementptr %"compiler/check:signMag", ptr %l3, i32 0, i32 1
  %t9 = load i128, ptr %t8
  store i128 %t9, ptr %l5
  %t13 = call %"compiler/check:signMag" @compiler_2fcheck_2etwos(%"compiler/check:litv" %a2)
  store %"compiler/check:signMag" %t13, ptr %l16
  br label %bb2
bb2:
  %t14 = load %"compiler/check:signMag", ptr %l16
  store %"compiler/check:signMag" %t14, ptr %l6
  %t15 = getelementptr %"compiler/check:signMag", ptr %l6, i32 0, i32 0
  %t16 = load i1, ptr %t15, !tbaa !21
  store i1 %t16, ptr %l7, !tbaa !21
  %t18 = getelementptr %"compiler/check:signMag", ptr %l6, i32 0, i32 1
  %t19 = load i128, ptr %t18
  store i128 %t19, ptr %l8
  %t21 = load i32, ptr %l0, !range !{i32 0, i32 96}
  %t23 = trunc i64 83 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb3, label %bb4
bb3:
  %t26 = load i1, ptr %l4, !tbaa !21
  br i1 %t26, label %bb5, label %bb6
bb4:
  %t28 = load i32, ptr %l0, !range !{i32 0, i32 96}
  %t30 = trunc i64 84 to i32
  %t31 = icmp eq i32 %t28, %t30
  br i1 %t31, label %bb8, label %bb9
bb5:
  %t33 = load i1, ptr %l7, !tbaa !21
  store i1 %t33, ptr %l23, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb7
bb7:
  %t35 = load i1, ptr %l23, !tbaa !21
  store i1 %t35, ptr %l21, !tbaa !21
  br label %bb14
bb8:
  %t36 = load i1, ptr %l4, !tbaa !21
  br i1 %t36, label %bb10, label %bb11
bb9:
  %t38 = load i1, ptr %l4, !tbaa !21
  %t39 = load i1, ptr %l7, !tbaa !21
  %t42 = icmp ne i1 %t38, %t39
  store i1 %t42, ptr %l27, !tbaa !21
  br label %bb13
bb10:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb12
bb11:
  %t44 = load i1, ptr %l7, !tbaa !21
  store i1 %t44, ptr %l29, !tbaa !21
  br label %bb12
bb12:
  %t46 = load i1, ptr %l29, !tbaa !21
  store i1 %t46, ptr %l27, !tbaa !21
  br label %bb13
bb13:
  %t47 = load i1, ptr %l27, !tbaa !21
  store i1 %t47, ptr %l21, !tbaa !21
  br label %bb14
bb14:
  %t48 = load i1, ptr %l21, !tbaa !21
  store i1 %t48, ptr %l9, !tbaa !21
  %t49 = load i32, ptr %l0, !range !{i32 0, i32 96}
  %t51 = trunc i64 83 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb15, label %bb16
bb15:
  %t54 = load i128, ptr %l5
  %t55 = load i128, ptr %l8
  %t58 = and i128 %t54, %t55
  store i128 %t58, ptr %l36
  br label %bb20
bb16:
  %t60 = load i32, ptr %l0, !range !{i32 0, i32 96}
  %t62 = trunc i64 84 to i32
  %t63 = icmp eq i32 %t60, %t62
  br i1 %t63, label %bb17, label %bb18
bb17:
  %t65 = load i128, ptr %l5
  %t66 = load i128, ptr %l8
  %t69 = or i128 %t65, %t66
  store i128 %t69, ptr %l42
  br label %bb19
bb18:
  %t71 = load i128, ptr %l5
  %t72 = load i128, ptr %l8
  %t75 = xor i128 %t71, %t72
  store i128 %t75, ptr %l42
  br label %bb19
bb19:
  %t77 = load i128, ptr %l42
  store i128 %t77, ptr %l36
  br label %bb20
bb20:
  %t78 = load i128, ptr %l36
  store i128 %t78, ptr %l10
  %t79 = load i1, ptr %l9, !tbaa !21
  %t81 = xor i1 %t79, true
  br i1 %t81, label %bb21, label %bb22
bb21:
  %t83 = load i128, ptr %l10
  %t85 = call %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 false, i128 %t83)
  store %"compiler/check:litv" %t85, ptr %l52
  br label %bb23
bb22:
  br label %bb24
bb23:
  %t86 = load %"compiler/check:litv", ptr %l52
  store %"compiler/check:litv" %t86, ptr %rv
  br label %ret
bb24:
  %t87 = load i128, ptr %l10
  %t89 = icmp eq i128 %t87, 0
  br i1 %t89, label %bb25, label %bb26
bb25:
  %t91 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t91, ptr %l55
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t92 = load %"compiler/check:litv", ptr %l55
  store %"compiler/check:litv" %t92, ptr %rv
  br label %ret
bb28:
  %t93 = load i128, ptr %l10
  %t95 = sub i128 0, %t93
  %t97 = call %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 true, i128 %t95)
  store %"compiler/check:litv" %t97, ptr %l58
  br label %bb29
bb29:
  %t98 = load %"compiler/check:litv", ptr %l58
  store %"compiler/check:litv" %t98, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local i64 @compiler_2fcheck_2ewordCount(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca i1
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l27 = alloca i1
  %l30 = alloca i1
  %l31 = alloca { i64, ptr }
  %l35 = alloca i1
  %l36 = alloca i1
  %l37 = alloca { i64, ptr }
  %l41 = alloca i1
  %l42 = alloca i1
  %l43 = alloca { i64, ptr }
  %l57 = alloca i1
  %l58 = alloca { i64, ptr }
  %l61 = alloca i1
  %l62 = alloca i1
  %l63 = alloca { i64, ptr }
  %l66 = alloca i1
  %l67 = alloca i1
  %l68 = alloca { i64, ptr }
  %l74 = alloca i1
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t2, 0
  %t7 = add i64 %t1, %t4
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t13 = icmp sle i64 %t7, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb2, label %bb3
bb2:
  br label %bb44
bb3:
  br label %bb4
bb4:
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t17, ptr %l15, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  store i64 %t18, ptr %l16, !tbaa !24
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t25 = add i64 %t19, %t22
  store i64 %t25, ptr %l20, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t26, 0
  store i64 %t27, ptr %l21, !tbaa !24
  %t28 = load i64, ptr %l16, !tbaa !24
  %t29 = icmp sge i64 %t28, 0
  br i1 %t29, label %bb5, label %bb6
bb5:
  %t31 = load i64, ptr %l16, !tbaa !24
  %t32 = load i64, ptr %l20, !tbaa !24
  %t33 = icmp sle i64 %t31, %t32
  br i1 %t33, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_a18b02733ea53beb_f9e22fb852fb348f)
  unreachable
bb7:
  %t35 = load i64, ptr %l20, !tbaa !24
  %t36 = load i64, ptr %l21, !tbaa !24
  %t37 = icmp sle i64 %t35, %t36
  br i1 %t37, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_a18b02733ea53beb_f9e22fb852fb348f)
  unreachable
bb9:
  %t39 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = load i64, ptr %l16, !tbaa !24
  %t42 = load i64, ptr %l20, !tbaa !24
  %t43 = getelementptr i8, ptr %t40, i64 %t41
  %t44 = sub i64 %t42, %t41
  %t45 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t43, 1
  %t47 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t50 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t46, { i64, ptr } %t47)
  store i1 %t50, ptr %l27
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_a18b02733ea53beb_f9e22fb852fb348f)
  unreachable
bb11:
  %t51 = load i1, ptr %l27, !tbaa !21
  br i1 %t51, label %bb12, label %bb13
bb12:
  %t52 = load i64, ptr %l3, !tbaa !24
  %t54 = icmp eq i64 %t52, 0
  br i1 %t54, label %bb14, label %bb15
bb13:
  br label %bb42
bb14:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb24
bb15:
  %t56 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t56, ptr %l31, !tbaa !27
  %t57 = load i64, ptr %l3, !tbaa !24
  %t59 = sub i64 %t57, 1
  %t61 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i8, ptr %t62, i64 %t59
  %t64 = load i8, ptr %t63, !tbaa !32
  %t66 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t64)
  store i1 %t66, ptr %l35
  br label %bb16
bb16:
  %t67 = load i1, ptr %l35, !tbaa !21
  br i1 %t67, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb20
bb18:
  %t68 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t68, ptr %l37, !tbaa !27
  %t69 = load i64, ptr %l3, !tbaa !24
  %t71 = sub i64 %t69, 1
  %t73 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr i8, ptr %t74, i64 %t71
  %t76 = load i8, ptr %t75, !tbaa !32
  %t78 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t76)
  store i1 %t78, ptr %l41
  br label %bb19
bb19:
  %t79 = load i1, ptr %l41, !tbaa !21
  store i1 %t79, ptr %l36, !tbaa !21
  br label %bb20
bb20:
  %t80 = load i1, ptr %l36, !tbaa !21
  br i1 %t80, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb23
bb22:
  %t81 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t81, ptr %l43, !tbaa !27
  %t82 = load i64, ptr %l3, !tbaa !24
  %t84 = sub i64 %t82, 1
  %t86 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr i8, ptr %t87, i64 %t84
  %t89 = load i8, ptr %t88, !tbaa !32
  %t91 = icmp eq i8 %t89, 95
  store i1 %t91, ptr %l42, !tbaa !21
  br label %bb23
bb23:
  %t93 = load i1, ptr %l42, !tbaa !21
  %t94 = xor i1 %t93, true
  store i1 %t94, ptr %l30, !tbaa !21
  br label %bb24
bb24:
  %t96 = load i1, ptr %l30, !tbaa !21
  store i1 %t96, ptr %l4, !tbaa !21
  %t97 = load i64, ptr %l3, !tbaa !24
  %t98 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t98, 0
  %t103 = add i64 %t97, %t100
  store i64 %t103, ptr %l5, !tbaa !24
  %t105 = load i64, ptr %l5, !tbaa !24
  %t106 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t106, 0
  %t111 = icmp sge i64 %t105, %t108
  br i1 %t111, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb35
bb26:
  %t113 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t113, ptr %l58, !tbaa !27
  %t114 = load i64, ptr %l5, !tbaa !24
  %t116 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr i8, ptr %t117, i64 %t114
  %t119 = load i8, ptr %t118, !tbaa !32
  %t121 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t119)
  store i1 %t121, ptr %l61
  br label %bb27
bb27:
  %t122 = load i1, ptr %l61, !tbaa !21
  br i1 %t122, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb31
bb29:
  %t123 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t123, ptr %l63, !tbaa !27
  %t124 = load i64, ptr %l5, !tbaa !24
  %t126 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr i8, ptr %t127, i64 %t124
  %t129 = load i8, ptr %t128, !tbaa !32
  %t131 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t129)
  store i1 %t131, ptr %l66
  br label %bb30
bb30:
  %t132 = load i1, ptr %l66, !tbaa !21
  store i1 %t132, ptr %l62, !tbaa !21
  br label %bb31
bb31:
  %t133 = load i1, ptr %l62, !tbaa !21
  br i1 %t133, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb34
bb33:
  %t134 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t134, ptr %l68, !tbaa !27
  %t135 = load i64, ptr %l5, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr i8, ptr %t138, i64 %t135
  %t140 = load i8, ptr %t139, !tbaa !32
  %t142 = icmp eq i8 %t140, 95
  store i1 %t142, ptr %l67, !tbaa !21
  br label %bb34
bb34:
  %t144 = load i1, ptr %l67, !tbaa !21
  %t145 = xor i1 %t144, true
  store i1 %t145, ptr %l57, !tbaa !21
  br label %bb35
bb35:
  %t147 = load i1, ptr %l57, !tbaa !21
  store i1 %t147, ptr %l6, !tbaa !21
  %t148 = load i1, ptr %l4, !tbaa !21
  br i1 %t148, label %bb36, label %bb37
bb36:
  %t150 = load i1, ptr %l6, !tbaa !21
  store i1 %t150, ptr %l74, !tbaa !21
  br label %bb38
bb37:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb38
bb38:
  %t152 = load i1, ptr %l74, !tbaa !21
  br i1 %t152, label %bb39, label %bb40
bb39:
  %t153 = load i64, ptr %l2, !tbaa !24
  %t155 = add i64 %t153, 1
  store i64 %t155, ptr %l2, !tbaa !24
  br label %bb41
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t157 = load i64, ptr %l3, !tbaa !24
  %t159 = add i64 %t157, 1
  store i64 %t159, ptr %l3, !tbaa !24
  br label %bb43
bb43:
  br label %bb1
bb44:
  %t161 = load i64, ptr %l2, !tbaa !24
  store i64 %t161, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/check:errBind" @compiler_2fcheck_3aerrBind_2ector(ptr %v0, i32 %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %rv = alloca %"compiler/check:errBind"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/check:errBind" undef, i32 %a0, 0
  %t12 = insertvalue %"compiler/check:errBind" %t10, i64 %a1, 1
  %t14 = insertvalue %"compiler/check:errBind" %t12, i32 %a2, 2
  %t16 = insertvalue %"compiler/check:errBind" %t14, %"compiler/source:Span" %a3, 3
  store %"compiler/check:errBind" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:errBind", ptr %rv
  ret %"compiler/check:errBind" %rr
}

define dso_local %"compiler/check:fixedInit" @compiler_2fcheck_3afixedInit_2ector(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %rv = alloca %"compiler/check:fixedInit"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/check:fixedInit" undef, ptr %a0, 0
  %t8 = insertvalue %"compiler/check:fixedInit" %t6, i32 %a1, 1
  store %"compiler/check:fixedInit" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:fixedInit", ptr %rv
  ret %"compiler/check:fixedInit" %rr
}

define dso_local %"compiler/check:idleCall" @compiler_2fcheck_3aidleCall_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, i64 %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %rv = alloca %"compiler/check:idleCall"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/check:idleCall" undef, i64 %a0, 0
  %t14 = insertvalue %"compiler/check:idleCall" %t12, i64 %a1, 1
  %t16 = insertvalue %"compiler/check:idleCall" %t14, %"compiler/source:Span" %a2, 2
  %t18 = insertvalue %"compiler/check:idleCall" %t16, { i64, ptr } %a3, 3
  %t20 = insertvalue %"compiler/check:idleCall" %t18, ptr %a4, 4
  store %"compiler/check:idleCall" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:idleCall", ptr %rv
  ret %"compiler/check:idleCall" %rr
}

define dso_local %"compiler/check:typeCase" @compiler_2fcheck_3atypeCase_2ector(ptr %v0, i1 %a0, i1 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %rv = alloca %"compiler/check:typeCase"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/check:typeCase" undef, i1 %a0, 0
  %t12 = insertvalue %"compiler/check:typeCase" %t10, i1 %a1, 1
  %t14 = insertvalue %"compiler/check:typeCase" %t12, i32 %a2, 2
  %t16 = insertvalue %"compiler/check:typeCase" %t14, i64 %a3, 3
  %t18 = insertvalue %"compiler/check:typeCase" %t16, i64 0, 4
  %t20 = insertvalue %"compiler/check:typeCase" %t18, i1 false, 5
  store %"compiler/check:typeCase" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:typeCase", ptr %rv
  ret %"compiler/check:typeCase" %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d1 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@__olang_empty_array = external constant [16 x i64]
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d3 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d4 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Array" }>, align 8
@.d5 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"CVoid" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"{" }>, align 8
declare void @__olang_ert_req_clear()
@.d7 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"u:" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d9 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"Eq" }>, align 8
@.d10 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"eq" }>, align 8
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d12 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d13 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
@.d15 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Some" }>, align 8
@.d16 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Every" }>, align 8
@.d17 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d18 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"()'" }>, align 8
@.d19 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Sum" }>, align 8
@.d20 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Some" }>, align 8
@.d21 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Every" }>, align 8
@.d22 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Some" }>, align 8
@.d23 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"std/prelude/array" }>, align 8
@.d24 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"ArrayError" }>, align 8
@.d25 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Empty" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d26 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Min" }>, align 8
@.d27 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"Of" }>, align 8
@.d28 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d29 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
@.d30 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d31 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d32 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d33 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d34 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
@.d35 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Max" }>, align 8
@.d36 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Min" }>, align 8
@.d37 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Inf" }>, align 8
@.d38 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"NaN" }>, align 8
@.d39 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"Epsilon" }>, align 8
@.d40 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"SmallestNormal" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@olang_loc_6e7767865267b99e_88e6ff5d2bea5fe2 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultArg(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3, i1 %a4, i32 %a5, i32 %a6)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitMethod(ptr %v0, ptr %a0, %"compiler/generic:AnySlot" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1, i64 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/msgs:Msg" %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4)
declare %"compiler/generic:Context" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceContext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_87950e0971945cd5_bece9ab6826c95c9 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultReads(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeArgs(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_f8c90d07629b23d_673d56dd932bf211 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_e3737a5db5d2f43e_f6d8b09c7cd8c09a = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
@olang_loc_a6278e1b7f6dba40_6fee99e557dde034 = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aHoldsAny(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_6d92d89bf6179935_a746df8e6ee4ce11 = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_76c98d42818871e4_51853c380fcafc70 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStmt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
@olang_loc_5b6dfd884f12314a_d55d816e86cc2196 = external constant [0 x i8]
@olang_loc_fdeda218c1a4d1e1_676c59a9a8adaaad = external constant [0 x i8]
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_357157b7b16ebf19_d0077534c0a9b60d = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeForeign(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainCmp(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, ptr %a4, ptr %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
declare %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, [2 x i64] } %a5)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ePush_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eSetVars(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_f2da914bb6134d5f_3ef82b9ab3e359c3 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eEmptyDestructor(ptr %v0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootStmts(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_e7a3ae7e66c3138_2e8ed5b6f09d874 = external constant [0 x i8]
declare %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1)
@olang_loc_de922dec49c7f00c_86e7828aa2d91a60 = external constant [0 x i8]
declare { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eComptimeForTry(ptr %v0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollOnce(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollBody(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollElem(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
@olang_loc_d826e759488f41a6_3ea05b0e10c73972 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLengthKey(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_He27db0a1785588531472bfd2db42574f(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eComptimeForUnknown(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H09835701baa5b197f16fe6901ed0f7b4(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/check:UnrollAsk" @compiler_2fcheck_3aUnrollAsk_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i64 %a2, i32 %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aUnrollAsk_3e_2ePush_He90a5e781e5223c39ec692b3f1e8f929(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:UnrollAsk" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eComptimeForTooMany(ptr %v0, i64 %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollConsts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3, i32 %a4)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fgeneric_2eDescNone = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/check:reflList" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflInt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistItem(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/check:reflList" %a2, i64 %a3)
@olang_loc_b90f60f44557575f_8372487000419b6b = external constant [0 x i8]
@G_2ecompiler_2fgeneric_2eListFunctions = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFuncDescriptor(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@G_2ecompiler_2fgeneric_2eListMethods = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eListFields = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eDescField = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eListCases = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eDescCase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eListParams = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eDescParam = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eDescResult = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@olang_loc_56167ce98e06ac0c_8ddb750e2bed0608 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescriptor(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i64 %a3, i64 %a4)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeqShaped(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eLen__H3cdfcddd9c493bd8bcefc7b766e0438b(ptr %v0, ptr %a0)
declare %"compiler/check:errNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eAt_3ccompiler_2fcheck_3aerrNarrow_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euncovered(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeferErrorEscapes(ptr %v0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emsgOwner(ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertMsgError(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskClauseError(ptr %v0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisGlobalBody(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTryNowhereToGo(ptr %v0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTryErrorNotDeclared(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenErrorNotDeclared(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritesNoQuestion(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTryNeedsQuestion(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epattern(ptr %v0, ptr %v1, ptr %a0, ptr %a1, ptr %a2, i32 %a3, ptr %a4, i64 %a5)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eand2(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenEnum(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseValueType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_d21fae414ff68ab0_be44aac3c4a6c53c = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTest(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4)
@olang_loc_ef1b19b21c725e8b_7a0ef433936b1ef = external constant [0 x i8]
@olang_loc_3671e63a1443f44a_b1e16b3f6a36352e = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elengthsMeet(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H0e73c22773457b60eb954c2c4a2643e9(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelemPlace(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3, i32 %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
@olang_loc_4a75f471ea948b24_16ed41ec7c1e5db8 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %a0, ptr %a1)
declare %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneBinType(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneDecl(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare %"compiler/check:laneNode" @compiler_2fcheck_3alaneNode_2ector(ptr %v0, ptr %v1, i64 %a0, i32 %a1, %"compiler/source:Span" %a2, %"compiler/source:Span" %a3, i64 %a4, i64 %a5, i64 %a6, ptr %a7, i32 %a8, i64 %a9, i32 %a10)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneAdd(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:laneNode" %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneHold(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLaneLengths(ptr %v0, i64 %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimplSig(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneSay(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLaneMaskBool(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/check:laneVals" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneSetup(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneCount(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %a0, ptr %a1)
declare { i64, i64, i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLoopOpen(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3, ptr %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5, %"compiler/source:Span" %a6, %"compiler/source:Span" %a7)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLoopClose(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3, i64 %a4, i64 %a5, i64 %a6)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailOp(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/source:Span" %a2, i1 %a3)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %a0, ptr %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eDrop(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsBy(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsInst(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritableAt(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopParam(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecommuteParam(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/check:litv" %a2, i32 %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoMeet(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_89233ed815a81c43_385dc0f6d58c413f = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econstruct(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, { i64, ptr } %a4)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2efloatOverflows(i32 %a0, double %a1)
declare double @compiler_2fcheck_2elitF64(%"compiler/check:litv" %a0)
declare i1 @compiler_2fcheck_2eintFits(ptr %v0, ptr %a0, %"compiler/check:litv" %a1, i32 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esameRepr(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertMessageNotText(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowedField(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_bddcfdd9cfe1623c_a2c83caf107f9198 = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSuchCaseMeant(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSuchCase(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_cabdf486839d2fe5_195cd685fa5544d9 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtNamed(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtUsed(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtAssigned(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalOrCapture(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstField(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalPlace(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalType(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efield(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, i32 %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflOf(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, { i64, ptr } %a4)
@olang_loc_c89e58dd43b8c5a0_98fae7e2dc40ed34 = external constant [0 x i8]
@olang_loc_69ec6e21e27849b1_edfd59555f73f465 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecNumber(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforeignRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainStruct(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedHolds(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/check:roArg" @compiler_2fcheck_3aroArg_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, i64 %a0, i64 %a1, { i64, [3 x i64] } %a2, { i64, ptr } %a3, { i64, ptr } %a4, { i64, ptr } %a5)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroArg_3e_2ePush_3ccompiler_2fcheck_3aroArg_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:roArg" %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare %"std/pair:Pair.b139c4f75a6545712256427180a82a06" @std_2fpair_3aPair_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20std_2fpair_3aPair_3cI64_2c_20I64_3e_3e_2ector(ptr %v0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cstd_2fpair_3aPair__H9be680f663aa81558c844970355ca108(ptr %v0, ptr %a0, %"std/pair:Pair.b139c4f75a6545712256427180a82a06" %a1)
@olang_loc_3ba07a3e63e86523_b4e2f85113e27c0f = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/check:roDeepArg" @compiler_2fcheck_3aroDeepArg_2ector(ptr %v0, ptr %v1, i64 %a0, ptr %a1, i64 %a2, i64 %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroDeepArg_3e_2ePush_H0e30e0389c54f9bfc05db61d637e277e(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:roDeepArg" %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroName(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFix(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCallAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyLent(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepNeed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLocal(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aUnread_3e_2eLen_3ccompiler_2fnames_3aUnread_3e(ptr %v0, ptr %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edestructs(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H190b78e3c1eec037529224679e114a85(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i1 %a2)
declare %"compiler/names:Unread" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aUnread_3e_2eAt_3ccompiler_2fnames_3aUnread_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLocalUnusedBare(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLocalUnused(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@olang_loc_3727962a9e2e15db_7cf774666c9d4227 = external constant [0 x i8]
@olang_loc_81d441761e2a717d_f45e749fdf1e1e81 = external constant [0 x i8]
@olang_loc_64cdadb0ead6eee6_ae7a9e6dd8bef26a = external constant [0 x i8]
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2eLen_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare %"compiler/generic:Context" @compiler_2fgeneric_3aContext_2ector(ptr %v0, i64 %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edrain(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopSetIn(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2, i32 %a3, %"compiler/source:Span" %a4, i1 %a5)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_Hc8503b2b20cde402cc7bde6f68d96fc0(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eVarArgWide(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eVarArgType(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eYieldInLambda(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eYieldOutside(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eYieldInDefer(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eYieldInJoin(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eYieldPastDefer(ptr %v0)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresultAt(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i64 %a3)
declare i32 @compiler_2fcheck_2esetName(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ehasName(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2echainNames(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_bae3cd237d905c4d_ccae9f7ce38212b9 = external constant [0 x i8]
declare %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %v0, i1 %a0, i1 %a1, i1 %a2, i64 %a3, double %a4)
@olang_loc_f62b02ebb614301c_75e9b5b90c5bfe48 = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eOwning = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNullable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/check:signMag" @compiler_2fcheck_2etwos(%"compiler/check:litv" %a0)
declare %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 %a0, i128 %a1)
declare %"compiler/check:litv" @compiler_2fcheck_2enoLit()
@olang_loc_a18b02733ea53beb_f9e22fb852fb348f = external constant [0 x i8]
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
